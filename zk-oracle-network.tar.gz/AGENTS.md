# AGENTS.md

## Goal

Build a ZK oracle network for verifiable external data feeds. Data submission, proof generation, on-chain verification.

## Stack

- Family: `fullstack-ts`
- Layers: `database:sqlite`, `sdk:none`, `auth:none`, `payments:none`, `queue:none`

## Architecture

- Node.js HTTP server
- TypeScript with experimental strip-types
- Server-rendered HTML
- JSON API endpoints

## Entry Points

- `src/server.ts`
- `src/client.ts`
- `web/index.html`

## Commands

- `node --experimental-strip-types src/server.ts`
- `npm install`
- `npm run dev`

## Design

DESIGN RULES (follow these when generating UI code):

General:
- Build polished, production-quality interfaces — not prototypes.
- Use consistent spacing (p-4, p-6, gap-4, gap-6). Avoid arbitrary values.
- Every interactive element needs hover and focus states.
- Support dark mode via the .dark class and CSS custom properties.
- Use subtle transitions (transition-colors, duration-150) on interactive elements.
- Prefer rounded-lg for cards and rounded-md for buttons and inputs.

Quality bar:
- Every page should look intentionally designed, not like a code demo.
- Use proper empty states with illustrations or icons.
- Loading states: use Skeleton components, not spinners.
- Error states: use destructive variant Badge or Alert, not raw text.

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
