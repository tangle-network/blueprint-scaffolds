import type {
  DataFeed,
  FeedValue,
  AggregatedResult,
  Submission,
  NetworkConfig,
} from "./types.js";
import { AggregationMethod } from "./types.js";
import {
  aggregate,
  createMockDataSource,
  validateSubmissions,
} from "./aggregation.js";
import {
  generateFetchProof,
  generateAggregationProof,
} from "./prover.js";
import { OperatorRegistry, SlashingManager } from "./operators.js";

export class OracleNetwork {
  private feeds = new Map<string, DataFeed>();
  private values = new Map<string, FeedValue[]>();
  private submissions = new Map<string, Submission[]>();
  private results = new Map<string, AggregatedResult>();
  private _registry: OperatorRegistry;
  private _slashing: SlashingManager;
  private config: NetworkConfig;

  constructor(config?: Partial<NetworkConfig>) {
    this.config = {
      minStake: 1000n,
      slashingThreshold: 0.05,
      aggregationMethod: AggregationMethod.Median,
      twapWindowSize: 3600000,
      maxSubmissionAge: 300000,
      requiredOperators: 3,
      ...config,
    };
    this._registry = new OperatorRegistry();
    this._slashing = new SlashingManager();
  }

  get registry(): OperatorRegistry {
    return this._registry;
  }

  get slashing(): SlashingManager {
    return this._slashing;
  }

  getConfig(): NetworkConfig {
    return { ...this.config };
  }

  registerFeed(feed: DataFeed): void {
    this.feeds.set(feed.id, feed);
    this.values.set(feed.id, []);
    this.submissions.set(feed.id, []);
  }

  getFeed(id: string): DataFeed | undefined {
    return this.feeds.get(id);
  }

  getAllFeeds(): DataFeed[] {
    return [...this.feeds.values()];
  }

  async fetchFeedValue(feedId: string): Promise<FeedValue> {
    const feed = this.feeds.get(feedId);
    if (!feed) throw new Error("Feed " + feedId + " not found");

    const mockValue = BigInt(Math.floor(Math.random() * 100000000) + 1000000);
    const source = createMockDataSource(feed.apiEndpoint, mockValue);
    const proof = await generateFetchProof(
      feed.apiEndpoint,
      new TextEncoder().encode(mockValue.toString()),
      new TextEncoder().encode(JSON.stringify(source.tlsAttestation))
    );

    const feedValue: FeedValue = {
      feedId,
      value: mockValue,
      timestamp: Date.now(),
      sources: [source],
      proof,
    };

    const history = this.values.get(feedId) ?? [];
    history.push(feedValue);
    this.values.set(feedId, history);

    return feedValue;
  }

  async submitValue(
    operatorId: string,
    feedId: string,
    value: bigint,
    proofBytes: Uint8Array
  ): Promise<Submission> {
    const operator = this._registry.getById(operatorId);
    if (!operator || !operator.isActive) {
      throw new Error("Operator " + operatorId + " not registered or inactive");
    }
    if (operator.stake < this.config.minStake) {
      throw new Error("Operator stake below minimum");
    }

    const submission: Submission = {
      operatorId,
      feedId,
      value,
      timestamp: Date.now(),
      proof: {
        proofBytes,
        publicInputs: new Uint8Array(32),
        seal: btoa(String.fromCharCode(...proofBytes.slice(0, 32))),
        journal: "",
        imageId: "submit-v1",
      },
      stake: operator.stake,
    };

    const subs = this.submissions.get(feedId) ?? [];
    subs.push(submission);
    this.submissions.set(feedId, subs);

    return submission;
  }

  async aggregateFeed(feedId: string): Promise<AggregatedResult> {
    const subs = this.submissions.get(feedId) ?? [];
    const valid = validateSubmissions(subs, this.config.maxSubmissionAge);

    if (valid.length < this.config.requiredOperators) {
      throw new Error(
        "Not enough valid submissions: " + valid.length + " < " + this.config.requiredOperators
      );
    }

    const resultValue = aggregate(
      valid,
      this.config.aggregationMethod,
      this.config.twapWindowSize
    );

    const proof = await generateAggregationProof(
      valid.map((s) => s.value),
      resultValue,
      this.config.aggregationMethod
    );

    const result: AggregatedResult = {
      feedId,
      value: resultValue,
      timestamp: Date.now(),
      methodology: this.config.aggregationMethod,
      submissions: valid,
      proof,
    };

    this.results.set(feedId, result);

    for (const sub of valid) {
      this._slashing.detectInvalidSubmission(
        sub,
        resultValue,
        this.config.slashingThreshold,
        this._registry,
        sub.stake / 10n
      );
    }

    return result;
  }

  getLatestResult(feedId: string): AggregatedResult | undefined {
    return this.results.get(feedId);
  }

  getSubmissionHistory(feedId: string): Submission[] {
    return [...(this.submissions.get(feedId) ?? [])];
  }

  getValueHistory(feedId: string): FeedValue[] {
    return [...(this.values.get(feedId) ?? [])];
  }
}
