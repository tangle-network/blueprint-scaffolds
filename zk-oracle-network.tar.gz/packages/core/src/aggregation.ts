import type {
  Submission,
  DataSource,
  TLSAttestation,
} from "./types.js";

export function computeMedian(values: bigint[]): bigint {
  if (values.length === 0) throw new Error("Empty values");
  const sorted = [...values].sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));
  const mid = Math.floor(sorted.length / 2);
  if (sorted.length % 2 === 0) {
    return (sorted[mid - 1]! + sorted[mid]!) / 2n;
  }
  return sorted[mid]!;
}

export function computeTWAP(
  entries: { value: bigint; timestamp: number }[],
  windowMs: number
): bigint {
  if (entries.length === 0) throw new Error("Empty entries");
  const now = Date.now();
  const cutoff = now - windowMs;
  const filtered = entries.filter((e) => e.timestamp >= cutoff);
  if (filtered.length === 0) return entries[entries.length - 1]!.value;

  let weightedSum = 0n;
  let totalWeight = 0n;

  for (let i = 0; i < filtered.length; i++) {
    const current = filtered[i]!;
    const next = filtered[i + 1];
    const duration = next
      ? BigInt(next.timestamp - current.timestamp)
      : BigInt(now - current.timestamp);
    weightedSum += current.value * duration;
    totalWeight += duration;
  }

  return totalWeight > 0n ? weightedSum / totalWeight : filtered[0]!.value;
}

export function computeMean(values: bigint[]): bigint {
  if (values.length === 0) throw new Error("Empty values");
  const sum = values.reduce((a, b) => a + b, 0n);
  return sum / BigInt(values.length);
}

export function aggregate(
  submissions: Submission[],
  method: string,
  twapWindowMs?: number
): bigint {
  const values = submissions.map((s) => s.value);
  switch (method) {
    case "median":
      return computeMedian(values);
    case "twap":
      return computeTWAP(
        submissions.map((s) => ({ value: s.value, timestamp: s.timestamp })),
        twapWindowMs ?? 3600000
      );
    case "mean":
      return computeMean(values);
    default:
      throw new Error("Unknown method: " + method);
  }
}

export function createMockTLSAttestation(url: string): TLSAttestation {
  const host = new URL(url).hostname;
  return {
    certificateFingerprint: simpleHash(host + ":cert:sha256"),
    serverName: host,
    cipherSuite: "TLS_AES_256_GCM_SHA384",
    tlsVersion: "1.3",
    handshakeHash: simpleHash(host + ":handshake"),
  };
}

export function createMockDataSource(url: string, value: bigint): DataSource {
  return {
    url,
    rawValue: value,
    timestamp: Date.now(),
    tlsAttestation: createMockTLSAttestation(url),
  };
}

function simpleHash(input: string): string {
  let hash = 0;
  for (let i = 0; i < input.length; i++) {
    const char = input.charCodeAt(i);
    hash = ((hash << 5) - hash + char) | 0;
  }
  return Math.abs(hash).toString(16).padStart(64, "0");
}

export function validateSubmissions(
  submissions: Submission[],
  maxAge: number
): Submission[] {
  const now = Date.now();
  return submissions.filter((s) => now - s.timestamp < maxAge);
}

export function stakeWeightedValue(
  submissions: Submission[]
): { value: bigint; totalStake: bigint } {
  let weightedSum = 0n;
  let totalStake = 0n;
  for (const s of submissions) {
    weightedSum += s.value * s.stake;
    totalStake += s.stake;
  }
  return {
    value: totalStake > 0n ? weightedSum / totalStake : 0n,
    totalStake,
  };
}
