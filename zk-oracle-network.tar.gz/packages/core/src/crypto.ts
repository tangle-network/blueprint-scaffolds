import { sha256 } from "@noble/hashes/sha256";
import { bytesToHex } from "@noble/hashes/utils";

export function hashBytes(data: Uint8Array): string {
  return bytesToHex(sha256(data));
}

export function bigIntToBytes(n: bigint, length: number = 32): Uint8Array {
  const hex = n.toString(16).padStart(length * 2, "0");
  const bytes = new Uint8Array(length);
  for (let i = 0; i < length; i++) {
    bytes[i] = parseInt(hex.substring(i * 2, i * 2 + 2), 16);
  }
  return bytes;
}

export function bytesToBigInt(bytes: Uint8Array): bigint {
  let result = 0n;
  for (const b of bytes) {
    result = (result << 8n) | BigInt(b);
  }
  return result;
}

export function combineHashes(hashes: string[]): string {
  const combined = new Uint8Array(hashes.length * 32);
  for (let i = 0; i < hashes.length; i++) {
    const bytes = hexToBytes(hashes[i]);
    combined.set(bytes, i * 32);
  }
  return hashBytes(combined);
}

export function hexToBytes(hex: string): Uint8Array {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < hex.length; i += 2) {
    bytes[i / 2] = parseInt(hex.substring(i, i + 2), 16);
  }
  return bytes;
}

export function serializeForProof(data: Record<string, unknown>): Uint8Array {
  const json = JSON.stringify(data, (_, v) =>
    typeof v === "bigint" ? "0x" + v.toString(16) : v
  );
  return new TextEncoder().encode(json);
}

export function generateImageId(methodName: string): string {
  const encoder = new TextEncoder();
  const data = encoder.encode("zk-oracle:" + methodName + ":risc0-v1");
  return hashBytes(data);
}
