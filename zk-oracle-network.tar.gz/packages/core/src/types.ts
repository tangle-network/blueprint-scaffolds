export interface DataFeed {
  id: string;
  name: string;
  description: string;
  apiEndpoint: string;
  updateInterval: number;
  decimals: number;
}

export interface FeedValue {
  feedId: string;
  value: bigint;
  timestamp: number;
  sources: DataSource[];
  proof?: ZKProof;
}

export interface DataSource {
  url: string;
  rawValue: bigint;
  timestamp: number;
  tlsAttestation: TLSAttestation;
}

export interface TLSAttestation {
  certificateFingerprint: string;
  serverName: string;
  cipherSuite: string;
  tlsVersion: string;
  handshakeHash: string;
}

export interface ZKProof {
  proofBytes: Uint8Array;
  publicInputs: Uint8Array;
  seal: string;
  journal: string;
  imageId: string;
}

export interface Operator {
  id: string;
  address: string;
  stake: bigint;
  publicKey: string;
  endpoint: string;
  reputation: number;
  isActive: boolean;
}

export interface Submission {
  operatorId: string;
  feedId: string;
  value: bigint;
  timestamp: number;
  proof: ZKProof;
  stake: bigint;
}

export interface AggregatedResult {
  feedId: string;
  value: bigint;
  timestamp: number;
  methodology: AggregationMethod;
  submissions: Submission[];
  proof: ZKProof;
}

export enum AggregationMethod {
  Median = "median",
  TWAP = "twap",
  Mean = "mean",
}

export enum FeedStatus {
  Active = "active",
  Paused = "paused",
  Degraded = "degraded",
}

export interface NetworkConfig {
  minStake: bigint;
  slashingThreshold: number;
  aggregationMethod: AggregationMethod;
  twapWindowSize: number;
  maxSubmissionAge: number;
  requiredOperators: number;
}

export interface SlashingEvent {
  operatorId: string;
  reason: string;
  amount: bigint;
  timestamp: number;
  evidenceProof: ZKProof;
}
