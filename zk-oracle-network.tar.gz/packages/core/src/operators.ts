import type { Operator, SlashingEvent, ZKProof, Submission } from "./types.js";

export class OperatorRegistry {
  private operators = new Map<string, Operator>();

  register(operator: Operator): void {
    this.operators.set(operator.id, { ...operator, isActive: true });
  }

  deregister(operatorId: string): void {
    const op = this.operators.get(operatorId);
    if (op) op.isActive = false;
  }

  getActive(): Operator[] {
    return [...this.operators.values()].filter((o) => o.isActive);
  }

  getById(id: string): Operator | undefined {
    return this.operators.get(id);
  }

  updateStake(operatorId: string, delta: bigint): void {
    const op = this.operators.get(operatorId);
    if (!op) throw new Error("Operator " + operatorId + " not found");
    op.stake += delta;
    if (op.stake <= 0n) {
      op.isActive = false;
      op.stake = 0n;
    }
  }

  totalStake(): bigint {
    return this.getActive().reduce((sum, o) => sum + o.stake, 0n);
  }

  selectCommittee(count: number): Operator[] {
    const active = this.getActive();
    if (active.length <= count) return active;

    const totalStake = active.reduce((s, o) => s + o.stake, 0n);
    const seed = BigInt(Date.now());
    const indices = new Set<number>();

    for (let i = 0; i < count; i++) {
      const idx = Number((seed * BigInt(i + 1) * 2654435761n) % BigInt(active.length));
      indices.add(idx);
    }

    return [...indices].map((i) => active[i]!);
  }
}

export class SlashingManager {
  private events: SlashingEvent[] = [];

  slash(
    operator: Operator,
    reason: string,
    amount: bigint,
    evidenceProof: ZKProof,
    registry: OperatorRegistry
  ): SlashingEvent {
    const event: SlashingEvent = {
      operatorId: operator.id,
      reason,
      amount,
      timestamp: Date.now(),
      evidenceProof,
    };

    registry.updateStake(operator.id, -amount);
    this.events.push(event);
    return event;
  }

  detectInvalidSubmission(
    submission: Submission,
    expectedValue: bigint,
    tolerance: number,
    registry: OperatorRegistry,
    slashAmount: bigint
  ): SlashingEvent | null {
    const diff =
      submission.value > expectedValue
        ? submission.value - expectedValue
        : expectedValue - submission.value;
    const toleranceAbs =
      (expectedValue * BigInt(Math.floor(tolerance * 10000))) / 10000n;

    if (diff > toleranceAbs) {
      const operator = registry.getById(submission.operatorId);
      if (!operator) return null;
      return this.slash(
        operator,
        "Value deviates from expected by more than " + tolerance * 100 + "%",
        slashAmount,
        submission.proof,
        registry
      );
    }
    return null;
  }

  getEvents(operatorId?: string): SlashingEvent[] {
    if (operatorId) return this.events.filter((e) => e.operatorId === operatorId);
    return [...this.events];
  }
}
