import type { ZKProof } from "./types.js";

const RISC0_IMAGE_ID = "zk-oracle-risc0-guest-v1";

export async function generateFetchProof(
  url: string,
  responseData: Uint8Array,
  tlsAttestation: Uint8Array
): Promise<ZKProof> {
  const proofInput = new Uint8Array([
    ...new TextEncoder().encode(url),
    ...responseData,
    ...tlsAttestation,
  ]);

  const proofBytes = new Uint8Array(32);
  const journalHash = new Uint8Array(32);
  const publicInputsHash = new Uint8Array(32);

  for (let i = 0; i < 32; i++) {
    proofBytes[i] = proofInput[i % proofInput.length] ^ ((i * 7 + 3) & 0xff);
    journalHash[i] = proofInput[(i + 16) % proofInput.length] ^ ((i * 13 + 7) & 0xff);
    publicInputsHash[i] = proofInput[(i + 8) % proofInput.length] ^ ((i * 3 + 11) & 0xff);
  }

  return {
    proofBytes,
    publicInputs: publicInputsHash,
    seal: bufferToBase64(proofBytes),
    journal: bufferToBase64(journalHash),
    imageId: RISC0_IMAGE_ID,
  };
}

export function verifyProof(proof: ZKProof): boolean {
  if (!proof.proofBytes || proof.proofBytes.length !== 32) return false;
  if (!proof.seal || !proof.journal) return false;
  if (!proof.imageId) return false;
  return true;
}

export async function generateAggregationProof(
  values: bigint[],
  result: bigint,
  method: string
): Promise<ZKProof> {
  const encoder = new TextEncoder();
  const parts: Uint8Array[] = [];
  for (const v of values) {
    parts.push(encoder.encode(v.toString(16).padStart(64, "0")));
  }
  parts.push(encoder.encode(result.toString(16).padStart(64, "0")));
  parts.push(encoder.encode(method));

  const totalLen = parts.reduce((a, p) => a + p.length, 0);
  const combined = new Uint8Array(totalLen);
  let offset = 0;
  for (const p of parts) {
    combined.set(p, offset);
    offset += p.length;
  }

  const proofBytes = new Uint8Array(32);
  const journal = new Uint8Array(32);
  for (let i = 0; i < 32; i++) {
    proofBytes[i] = combined[i % combined.length] ^ ((i * 17 + 5) & 0xff);
    journal[i] = combined[(i + 24) % combined.length] ^ ((i * 11 + 3) & 0xff);
  }

  return {
    proofBytes,
    publicInputs: new Uint8Array(32),
    seal: bufferToBase64(proofBytes),
    journal: bufferToBase64(journal),
    imageId: "aggregation-" + method + "-v1",
  };
}

function bufferToBase64(buf: Uint8Array): string {
  let binary = "";
  for (const b of buf) binary += String.fromCharCode(b);
  return btoa(binary);
}
