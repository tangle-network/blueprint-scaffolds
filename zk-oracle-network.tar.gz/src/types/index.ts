export interface DataFeed {
  id: string;
  name: string;
  pair: string;
  value: number;
  previousValue: number;
  decimals: number;
  sources: DataSource[];
  lastUpdated: number;
  proofStatus: ProofStatus;
  medianProof: string;
  twapValue: number;
  twapPeriod: number;
  deviationBps: number;
  heartbeatSec: number;
}

export interface DataSource {
  url: string;
  name: string;
  value: number;
  timestamp: number;
  tlsAttestation: TLSAttestation;
  status: 'healthy' | 'degraded' | 'down';
}

export interface TLSAttestation {
  certificateHash: string;
  serverName: string;
  cipherSuite: string;
  notBefore: number;
  notAfter: number;
  verified: boolean;
}

export type ProofStatus = 'proved' | 'proving' | 'pending' | 'failed';

export interface ZKProof {
  receipt: string;
  journal: string;
  imageId: string;
  seal: string;
  timestamp: number;
  method: 'median' | 'twap' | 'aggregation';
}

export interface Operator {
  id: string;
  address: string;
  stake: number;
  reputation: number;
  status: 'active' | 'slashed' | 'jailed' | 'pending';
  totalSubmissions: number;
  successfulProofs: number;
  failedProofs: number;
  lastActive: number;
  endpoints: string[];
  slashingEvents: SlashingEvent[];
}

export interface SlashingEvent {
  id: string;
  operatorId: string;
  reason: string;
  amount: number;
  timestamp: number;
  proofHash: string;
}

export interface NetworkStats {
  totalOperators: number;
  activeOperators: number;
  totalStake: number;
  totalFeeds: number;
  avgProofTime: number;
  totalProofsGenerated: number;
  slashingRate: number;
  networkUptime: number;
}

export interface AggregationResult {
  feedId: string;
  median: number;
  twap: number;
  mean: number;
  min: number;
  max: number;
  stdDev: number;
  sourceCount: number;
  timestamp: number;
  proof: ZKProof;
}
