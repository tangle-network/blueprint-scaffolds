export interface DataFeed {
  id: string;
  name: string;
  description: string;
  apiEndpoint: string;
  value: number;
  previousValue: number;
  change24h: number;
  changePercent24h: number;
  lastUpdated: number;
  updateInterval: number;
  sources: DataSource[];
  aggregationMethod: AggregationMethod;
  proofStatus: ProofStatus;
  subscribers: number;
  category: FeedCategory;
}

export type FeedCategory = 'price' | 'weather' | 'sports' | 'defi' | 'randomness';
export type AggregationMethod = 'median' | 'twap' | 'mean' | 'first';
export type ProofStatus = 'verified' | 'pending' | 'generating' | 'failed';

export interface DataSource {
  id: string;
  name: string;
  url: string;
  tlsVerified: boolean;
  lastFetch: number;
  responseHash: string;
  value: number;
  status: 'healthy' | 'degraded' | 'down';
}

export interface Operator {
  id: string;
  address: string;
  name: string;
  stake: number;
  reputation: number;
  feedsServing: string[];
  proofsGenerated: number;
  proofsVerified: number;
  slashCount: number;
  uptime: number;
  lastActive: number;
  status: 'active' | 'inactive' | 'slashed';
  totalRewards: number;
  riscZeroImageId: string;
}

export interface Proof {
  id: string;
  feedId: string;
  operatorId: string;
  type: 'data_fetch' | 'tls_attestation' | 'aggregation' | 'computation';
  status: 'generating' | 'submitted' | 'verified' | 'rejected';
  receipt: string;
  imageId: string;
  journal: string;
  seal: string;
  submittedAt: number;
  verifiedAt?: number;
  gasUsed?: number;
  blockNumber?: number;
  inputHash: string;
  outputHash: string;
}

export interface NetworkStats {
  totalOperators: number;
  activeOperators: number;
  totalFeeds: number;
  totalProofs: number;
  totalStake: number;
  avgBlockTime: number;
  networkUptime: number;
  slashingEvents: number;
  totalGasSaved: number;
}

export interface AggregationSnapshot {
  timestamp: number;
  values: number[];
  median: number;
  twap: number;
  mean: number;
  weights: number[];
}

export interface SlashingEvent {
  id: string;
  operatorId: string;
  operatorName: string;
  reason: string;
  amount: number;
  timestamp: number;
  proofId: string;
  status: 'executed' | 'disputed' | 'overturned';
}

export interface FeedHistoryPoint {
  timestamp: number;
  value: number;
  proofVerified: boolean;
}
