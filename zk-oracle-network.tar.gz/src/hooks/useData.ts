import { useState, useEffect, useCallback } from 'react';
import type { DataFeed, Operator, NetworkStats } from '../types';
import { generateFeeds, generateOperators, generateNetworkStats } from '../utils/mockData';

function useSimulatedData<T>(generator: () => T[], intervalMs: number = 5000): T[] {
  const [data, setData] = useState<T[]>(() => generator());

  const refresh = useCallback(() => {
    setData(generator());
  }, [generator]);

  useEffect(() => {
    const id = setInterval(refresh, intervalMs);
    return () => clearInterval(id);
  }, [refresh, intervalMs]);

  return data;
}

export function useFeeds() {
  return useSimulatedData<DataFeed>(generateFeeds, 4000);
}

export function useOperators() {
  return useSimulatedData<Operator>(generateOperators, 8000);
}

export function useNetworkStats(): NetworkStats {
  const [stats, setStats] = useState<NetworkStats>(generateNetworkStats);
  useEffect(() => {
    const id = setInterval(() => setStats(generateNetworkStats()), 6000);
    return () => clearInterval(id);
  }, []);
  return stats;
}

export function useSelectedFeed(feeds: DataFeed[], feedId: string | undefined) {
  return feedId ? feeds.find((f) => f.id === feedId) : feeds[0];
}
