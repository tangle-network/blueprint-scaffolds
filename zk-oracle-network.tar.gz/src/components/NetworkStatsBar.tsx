import type { NetworkStats } from '../types';
import { formatNumber } from '../utils/format';

interface Props {
  stats: NetworkStats;
}

function StatCard({ label, value, sub, color }: { label: string; value: string; sub?: string; color: string }) {
  return (
    <div className="glass p-4 flex flex-col gap-1">
      <span className="text-xs text-gray-500 uppercase tracking-wide">{label}</span>
      <span className={`text-2xl font-bold ${color}`}>{value}</span>
      {sub && <span className="text-xs text-gray-500">{sub}</span>}
    </div>
  );
}

export default function NetworkStatsBar({ stats }: Props) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 mb-6">
      <StatCard label="Feeds" value={String(stats.totalFeeds)} color="text-zk-400" />
      <StatCard label="Operators" value={`${stats.activeOperators}/${stats.totalOperators}`} sub="active/total" color="text-oracle-400" />
      <StatCard label="Total Stake" value={`$${formatNumber(stats.totalStake)}`} color="text-white" />
      <StatCard label="Proofs" value={formatNumber(stats.totalProofsGenerated)} color="text-zk-400" />
      <StatCard label="Avg Proof" value={`${stats.avgProofTime.toFixed(1)}s`} sub="RISC Zero zkVM" color="text-oracle-400" />
      <StatCard label="Slashing" value={`${(stats.slashingRate * 100).toFixed(2)}%`} color="text-danger-400" />
      <StatCard label="Uptime" value={`${stats.networkUptime}%`} color="text-oracle-400" />
      <StatCard label="Epoch" value={`#${Math.floor(Date.now() / 1000 / 300)}`} sub="5 min epochs" color="text-gray-300" />
    </div>
  );
}
