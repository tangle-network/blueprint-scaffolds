import type { DataFeed } from '../types';
import { formatUsd, formatTimeAgo, statusBg, deviationColor } from '../utils/format';

interface Props {
  feeds: DataFeed[];
  selectedId: string | undefined;
  onSelect: (id: string) => void;
}

function ChangeIndicator({ current, previous }: { current: number; previous: number }) {
  const pct = ((current - previous) / previous) * 100;
  const positive = pct >= 0;
  return (
    <span className={`text-xs font-mono ${positive ? 'text-emerald-400' : 'text-red-400'}`}>
      {positive ? '+' : ''}{pct.toFixed(3)}%
    </span>
  );
}

function ProofBadge({ status }: { status: string }) {
  const icon = status === 'proved' ? '✓' : status === 'proving' ? '⟳' : status === 'failed' ? '✗' : '·';
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium border ${statusBg(status)}`}>
      <span className="text-[10px]">{icon}</span>
      {status}
    </span>
  );
}

export default function FeedTable({ feeds, selectedId, onSelect }: Props) {
  return (
    <div className="glass overflow-hidden">
      <div className="px-4 py-3 border-b border-gray-800/40 flex items-center justify-between">
        <h2 className="text-sm font-semibold text-gray-200">Data Feeds</h2>
        <span className="text-xs text-gray-500">{feeds.length} feeds · live</span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-xs text-gray-500 uppercase tracking-wider border-b border-gray-800/30">
              <th className="px-4 py-2 text-left font-medium">Pair</th>
              <th className="px-4 py-2 text-right font-medium">Price</th>
              <th className="px-4 py-2 text-right font-medium">24h Δ</th>
              <th className="px-4 py-2 text-right font-medium">Sources</th>
              <th className="px-4 py-2 text-center font-medium">Proof</th>
              <th className="px-4 py-2 text-right font-medium">Dev (bps)</th>
              <th className="px-4 py-2 text-right font-medium">Updated</th>
            </tr>
          </thead>
          <tbody>
            {feeds.map((feed) => (
              <tr
                key={feed.id}
                onClick={() => onSelect(feed.id)}
                className={`border-b border-gray-800/20 cursor-pointer transition-colors ${
                  selectedId === feed.id ? 'bg-zk-600/10' : 'hover:bg-gray-800/30'
                }`}
              >
                <td className="px-4 py-3 font-medium text-white">{feed.pair}</td>
                <td className="px-4 py-3 text-right font-mono text-gray-200">{formatUsd(feed.value, feed.decimals)}</td>
                <td className="px-4 py-3 text-right"><ChangeIndicator current={feed.value} previous={feed.previousValue} /></td>
                <td className="px-4 py-3 text-right text-gray-400">{feed.sources.length}</td>
                <td className="px-4 py-3 text-center"><ProofBadge status={feed.proofStatus} /></td>
                <td className={`px-4 py-3 text-right font-mono ${deviationColor(feed.deviationBps)}`}>{feed.deviationBps}</td>
                <td className="px-4 py-3 text-right text-gray-500 text-xs">{formatTimeAgo(feed.lastUpdated)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
