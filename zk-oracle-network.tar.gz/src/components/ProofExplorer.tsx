import { useState } from 'react';
import { generateProof, computeAggregation } from '../utils/mockData';
import { formatAddress } from '../utils/format';
import type { ZKProof, AggregationResult } from '../types';

export default function ProofExplorer() {
  const [proofs, setProofs] = useState<ZKProof[]>([]);
  const [selectedProof, setSelectedProof] = useState<ZKProof | null>(null);
  const [aggregationResult, setAggregationResult] = useState<AggregationResult | null>(null);

  const generateNewProof = (method: ZKProof['method']) => {
    const proof = generateProof(method);
    setProofs((prev) => [proof, ...prev].slice(0, 20));
    setSelectedProof(proof);

    const sampleValues = [67842.1, 67845.3, 67840.7, 67838.9, 67850.2];
    const agg = computeAggregation(sampleValues);
    setAggregationResult({
      feedId: 'btc-usd',
      ...agg,
      timestamp: Date.now(),
      proof,
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">ZK Proof Explorer</h2>
          <p className="text-sm text-gray-500">Generate and inspect RISC Zero zkVM proofs</p>
        </div>
        <div className="flex gap-2">
          {(['median', 'twap', 'aggregation'] as const).map((method) => (
            <button
              key={method}
              onClick={() => generateNewProof(method)}
              className="px-4 py-2 bg-zk-600 hover:bg-zk-700 text-white text-sm font-medium rounded-lg transition-colors"
            >
              Prove {method.charAt(0).toUpperCase() + method.slice(1)}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="glass p-4 lg:col-span-1">
          <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">Generated Proofs</h3>
          {proofs.length === 0 ? (
            <p className="text-sm text-gray-600 text-center py-8">Click a button above to generate a proof</p>
          ) : (
            <div className="space-y-2 max-h-[500px] overflow-y-auto">
              {proofs.map((p, i) => (
                <button
                  key={i}
                  onClick={() => setSelectedProof(p)}
                  className={`w-full text-left p-3 rounded-lg border transition-colors ${
                    selectedProof === p ? 'bg-zk-600/15 border-zk-500/30' : 'bg-gray-900/40 border-gray-800/30 hover:bg-gray-800/30'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-medium text-zk-400 uppercase">{p.method}</span>
                    <span className="text-[10px] text-gray-600">#{proofs.length - i}</span>
                  </div>
                  <code className="text-[10px] text-gray-500 font-mono">{formatAddress(p.receipt)}</code>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="glass p-4 lg:col-span-2 space-y-4">
          {selectedProof ? (
            <>
              <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Proof Details — {selectedProof.method.toUpperCase()}</h3>

              <div className="space-y-2">
                <div className="p-3 bg-gray-950 rounded-lg border border-gray-800/30">
                  <p className="text-xs text-gray-500 mb-1">Seal (Groth16)</p>
                  <code className="text-[10px] text-oracle-400 break-all font-mono leading-relaxed">{selectedProof.seal}</code>
                </div>
                <div className="p-3 bg-gray-950 rounded-lg border border-gray-800/30">
                  <p className="text-xs text-gray-500 mb-1">Journal (Public Outputs)</p>
                  <code className="text-[10px] text-zk-400 break-all font-mono leading-relaxed">{selectedProof.journal}</code>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-gray-950 rounded-lg border border-gray-800/30">
                  <span className="text-xs text-gray-500">Image ID</span>
                  <code className="block text-xs text-gray-300 font-mono mt-1">{selectedProof.imageId}</code>
                </div>
                <div className="p-3 bg-gray-950 rounded-lg border border-gray-800/30">
                  <span className="text-xs text-gray-500">Timestamp</span>
                  <code className="block text-xs text-gray-300 font-mono mt-1">{new Date(selectedProof.timestamp * 1000).toISOString()}</code>
                </div>
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center h-64 text-gray-600 text-sm">
              Select or generate a proof to view details
            </div>
          )}
        </div>
      </div>

      {aggregationResult && (
        <div className="glass p-4">
          <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">Aggregation Result</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
            {[
              { label: 'Median', value: `$${aggregationResult.median.toFixed(2)}` },
              { label: 'TWAP', value: `$${aggregationResult.twap.toFixed(2)}` },
              { label: 'Mean', value: `$${aggregationResult.mean.toFixed(2)}` },
              { label: 'Min', value: `$${aggregationResult.min.toFixed(2)}` },
              { label: 'Max', value: `$${aggregationResult.max.toFixed(2)}` },
              { label: 'Std Dev', value: aggregationResult.stdDev.toFixed(4) },
              { label: 'Sources', value: String(aggregationResult.sourceCount) },
            ].map((item) => (
              <div key={item.label} className="p-3 bg-gray-950 rounded-lg border border-gray-800/30 text-center">
                <span className="text-xs text-gray-500 block">{item.label}</span>
                <span className="text-sm font-mono text-gray-200 mt-1 block">{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
