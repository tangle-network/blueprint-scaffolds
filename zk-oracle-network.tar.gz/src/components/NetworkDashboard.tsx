import type { NetworkStats } from '../types';
import { formatNumber } from '../utils/format';

interface Props {
  stats: NetworkStats;
}

function RingChart({ pct, label, color, size = 80 }: { pct: number; label: string; color: string; size?: number }) {
  const r = (size - 12) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ - (pct / 100) * circ;
  return (
    <div className="flex flex-col items-center gap-2">
      <svg width={size} height={size} className="transform -rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(75,85,99,0.3)" strokeWidth="6" />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth="6" strokeDasharray={circ} strokeDashoffset={offset} strokeLinecap="round" />
      </svg>
      <div className="text-center">
        <span className="text-lg font-bold text-white">{pct.toFixed(1)}%</span>
        <p className="text-xs text-gray-500">{label}</p>
      </div>
    </div>
  );
}

function StackedBar({ segments }: { segments: { pct: number; color: string; label: string }[] }) {
  return (
    <div>
      <div className="flex h-3 rounded-full overflow-hidden mb-2">
        {segments.map((s, i) => (
          <div key={i} style={{ width: `${s.pct}%`, backgroundColor: s.color }} />
        ))}
      </div>
      <div className="flex flex-wrap gap-x-4 gap-y-1">
        {segments.map((s, i) => (
          <span key={i} className="text-xs text-gray-400 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: s.color }} />
            {s.label}: {s.pct.toFixed(1)}%
          </span>
        ))}
      </div>
    </div>
  );
}

export default function NetworkDashboard({ stats }: Props) {
  const epochsPerDay = 288;
  const proofsPerDay = Math.round((stats.totalProofsGenerated / (30 * epochsPerDay)) * epochsPerDay);
  const stakeActivePct = (stats.activeOperators / stats.totalOperators) * 100;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white">Network Dashboard</h2>
        <p className="text-sm text-gray-500">Real-time ZK Oracle Network metrics</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="glass p-6 flex flex-col items-center">
          <RingChart pct={stats.networkUptime} label="Network Uptime" color="#10b981" size={100} />
          <div className="mt-3 text-xs text-gray-500 text-center">Target: 99.9% — Status: <span className="text-oracle-400">Healthy</span></div>
        </div>

        <div className="glass p-6 flex flex-col items-center">
          <RingChart pct={stakeActivePct} label="Active Stake" color="#6366f1" size={100} />
          <div className="mt-3 text-xs text-gray-500 text-center">
            Total: ${formatNumber(stats.totalStake)} — {stats.activeOperators} of {stats.totalOperators} operators
          </div>
        </div>

        <div className="glass p-6 flex flex-col items-center">
          <RingChart pct={(1 - stats.slashingRate) * 100} label="Honesty Rate" color="#818cf8" size={100} />
          <div className="mt-3 text-xs text-gray-500 text-center">
            Slashing rate: {(stats.slashingRate * 100).toFixed(2)}% — <span className="text-oracle-400">Secure</span>
          </div>
        </div>
      </div>

      <div className="glass p-5">
        <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-4">Operator Distribution</h3>
        <StackedBar
          segments={[
            { pct: 70, color: '#10b981', label: 'Active' },
            { pct: 10, color: '#f59e0b', label: 'Pending' },
            { pct: 10, color: '#ef4444', label: 'Slashed' },
            { pct: 10, color: '#f97316', label: 'Jailed' },
          ]}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="glass p-5">
          <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-4">Proof Generation</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-sm text-gray-400">Method</span>
              <span className="text-sm text-gray-200 font-mono">RISC Zero zkVM (SHA-256)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-400">Avg Proof Time</span>
              <span className="text-sm text-oracle-400 font-mono">{stats.avgProofTime.toFixed(1)}s</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-400">Total Proofs</span>
              <span className="text-sm text-gray-200 font-mono">{formatNumber(stats.totalProofsGenerated)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-400">Est. Proofs/Day</span>
              <span className="text-sm text-gray-200 font-mono">{formatNumber(proofsPerDay)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-400">Proof Size</span>
              <span className="text-sm text-gray-200 font-mono">~1.2 KB (Groth16)</span>
            </div>
          </div>
        </div>

        <div className="glass p-5">
          <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-4">Stake-Weighted Consensus</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-sm text-gray-400">Quorum</span>
              <span className="text-sm text-gray-200 font-mono">2/3 + 1 stake</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-400">Min Stake</span>
              <span className="text-sm text-gray-200 font-mono">$10,000</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-400">Slashing Penalty</span>
              <span className="text-sm text-danger-400 font-mono">5-10% of stake</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-400">Jail Duration</span>
              <span className="text-sm text-gray-200 font-mono">24h — 7d</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-400">Epoch Length</span>
              <span className="text-sm text-gray-200 font-mono">300s (5 min)</span>
            </div>
          </div>
        </div>
      </div>

      <div className="glass p-5">
        <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-4">Architecture</h3>
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
          {[
            { title: 'Data Fetch', desc: 'TLS-notarized API calls with certificate chain verification', icon: '🌐' },
            { title: 'Aggregation', desc: 'Multi-source median & TWAP computation in zkVM guest', icon: '⚙️' },
            { title: 'ZK Proof', desc: 'RISC Zero zkVM proves correct execution on Bonsai', icon: '🔮' },
            { title: 'On-chain', desc: 'Verifier contract checks proof, updates feed state', icon: '⛓️' },
          ].map((step) => (
            <div key={step.title} className="p-3 bg-gray-950 rounded-lg border border-gray-800/30 text-center">
              <div className="text-2xl mb-2">{step.icon}</div>
              <h4 className="text-sm font-semibold text-gray-200 mb-1">{step.title}</h4>
              <p className="text-xs text-gray-500">{step.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
