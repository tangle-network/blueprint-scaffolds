import { NavLink, Outlet } from 'react-router-dom';
import { Activity, Database, Users, ShieldCheck, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { useState } from 'react';

const navItems = [
  { to: '/', label: 'Dashboard', icon: Activity },
  { to: '/feeds', label: 'Data Feeds', icon: Database },
  { to: '/operators', label: 'Operators', icon: Users },
  { to: '/proofs', label: 'Proofs', icon: ShieldCheck },
];

export default function Layout() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto flex h-14 items-center px-4">
          <div className="flex items-center gap-2 mr-8">
            <ShieldCheck className="h-6 w-6 text-primary" />
            <span className="font-bold text-lg hidden sm:inline">ZK Oracle Network</span>
            <span className="font-bold text-lg sm:hidden">ZK Oracle</span>
          </div>
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <NavLink key={item.to} to={item.to} end={item.to === '/'}>
                {({ isActive }) => (
                  <Button
                    variant={isActive ? 'secondary' : 'ghost'}
                    size="sm"
                    className="gap-2"
                  >
                    <item.icon className="h-4 w-4" />
                    {item.label}
                  </Button>
                )}
              </NavLink>
            ))}
          </nav>
          <div className="ml-auto md:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setMobileOpen(!mobileOpen)}
            >
              {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
          <div className="ml-auto hidden md:flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs text-muted-foreground">Mainnet</span>
          </div>
        </div>
        {mobileOpen && (
          <div className="md:hidden border-t p-2">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === '/'}
                onClick={() => setMobileOpen(false)}
              >
                {({ isActive }) => (
                  <Button
                    variant={isActive ? 'secondary' : 'ghost'}
                    size="sm"
                    className="w-full justify-start gap-2 mb-1"
                  >
                    <item.icon className="h-4 w-4" />
                    {item.label}
                  </Button>
                )}
              </NavLink>
            ))}
          </div>
        )}
      </header>
      <Separator />
      <main className="container mx-auto px-4 py-6">
        <Outlet />
      </main>
      <footer className="border-t mt-12">
        <div className="container mx-auto px-4 py-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground">
            ZK Oracle Network — Powered by RISC Zero
          </p>
          <p className="text-sm text-muted-foreground">
            Secured by zero-knowledge proofs on Ethereum
          </p>
        </div>
      </footer>
    </div>
  );
}
