import { NavLink, Outlet } from 'react-router-dom';

const links = [
  { to: '/', label: 'Feed Explorer' },
  { to: '/operators', label: 'Operators' },
  { to: '/proofs', label: 'Proofs' },
  { to: '/network', label: 'Network' },
];

export default function Layout() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-gray-800/60 bg-gray-950/80 backdrop-blur-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-zk-500 to-oracle-500 flex items-center justify-center text-white font-bold text-sm">ZK</div>
            <div>
              <h1 className="text-lg font-semibold text-white leading-tight">ZK Oracle Network</h1>
              <p className="text-xs text-gray-500">RISC Zero Verified Data Feeds</p>
            </div>
          </div>
          <nav className="flex gap-1">
            {links.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                end={l.to === '/'}
                className={({ isActive }) =>
                  `px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                    isActive ? 'bg-zk-600/20 text-zk-400' : 'text-gray-400 hover:text-gray-200 hover:bg-gray-800/40'
                  }`
                }
              >
                {l.label}
              </NavLink>
            ))}
          </nav>
        </div>
      </header>
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        <Outlet />
      </main>
      <footer className="border-t border-gray-800/40 py-4 text-center text-xs text-gray-600">
        ZK Oracle Network — Powered by RISC Zero zkVM — Decentralized Verifiable Data
      </footer>
    </div>
  );
}
