import type { DataFeed } from '../types';
import { formatUsd, formatTimeAgo, statusBg, formatAddress } from '../utils/format';

interface Props {
  feed: DataFeed;
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="glass p-4">
      <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">{title}</h3>
      {children}
    </div>
  );
}

function Row({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex justify-between py-1.5 text-sm">
      <span className="text-gray-500">{label}</span>
      <span className={mono ? 'font-mono text-gray-300' : 'text-gray-200'}>{value}</span>
    </div>
  );
}

export default function FeedDetail({ feed }: Props) {
  return (
    <div className="space-y-4">
      <Section title="Feed Overview">
        <Row label="Pair" value={feed.pair} />
        <Row label="Current Price" value={formatUsd(feed.value, feed.decimals)} mono />
        <Row label="TWAP (1h)" value={formatUsd(feed.twapValue, feed.decimals)} mono />
        <Row label="Previous" value={formatUsd(feed.previousValue, feed.decimals)} mono />
        <Row label="Deviation" value={`${feed.deviationBps} bps`} mono />
        <Row label="Heartbeat" value={`${feed.heartbeatSec}s`} />
        <Row label="Last Updated" value={formatTimeAgo(feed.lastUpdated)} />
      </Section>

      <Section title="ZK Proof (RISC Zero)">
        <Row label="Status" value={feed.proofStatus} />
        <Row label="Method" value="SHA-256 Continuation" />
        <Row label="Image ID" value={formatAddress(feed.medianProof)} mono />
        <Row label="Receipt" value={formatAddress('0x' + feed.medianProof.slice(2, 66))} mono />
        <div className="mt-3 p-3 bg-gray-950 rounded-lg border border-gray-800/30">
          <p className="text-xs text-gray-500 mb-1">Proof Seal</p>
          <code className="text-[10px] text-zk-400 break-all font-mono leading-relaxed">{feed.medianProof}</code>
        </div>
      </Section>

      <Section title="Data Sources & TLS Attestation">
        <div className="space-y-3">
          {feed.sources.map((src, i) => (
            <div key={i} className="p-3 bg-gray-950/60 rounded-lg border border-gray-800/30 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-200">{src.name}</span>
                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs border ${statusBg(src.status)}`}>{src.status}</span>
              </div>
              <Row label="Value" value={formatUsd(src.value, feed.decimals)} mono />
              <Row label="TLS Host" value={src.tlsAttestation.serverName} mono />
              <Row label="Cert Hash" value={formatAddress(src.tlsAttestation.certificateHash)} mono />
              <Row label="Cipher" value={src.tlsAttestation.cipherSuite} mono />
              <Row label="Verified" value={src.tlsAttestation.verified ? '✓ Yes' : '✗ No'} />
            </div>
          ))}
        </div>
      </Section>
    </div>
  );
}
