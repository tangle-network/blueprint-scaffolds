import type { Operator } from '../types';
import { formatNumber, formatAddress, formatTimeAgo, statusBg } from '../utils/format';

interface Props {
  operators: Operator[];
}

function ProgressBar({ value, max, color }: { value: number; max: number; color: string }) {
  const pct = Math.min(100, (value / max) * 100);
  return (
    <div className="w-full bg-gray-800 rounded-full h-1.5">
      <div className={`h-1.5 rounded-full ${color}`} style={{ width: `${pct}%` }} />
    </div>
  );
}

export default function OperatorTable({ operators }: Props) {
  const maxStake = Math.max(...operators.map((o) => o.stake));
  return (
    <div className="glass overflow-hidden">
      <div className="px-4 py-3 border-b border-gray-800/40 flex items-center justify-between">
        <h2 className="text-sm font-semibold text-gray-200">Network Operators</h2>
        <span className="text-xs text-gray-500">{operators.filter((o) => o.status === 'active').length} active</span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-xs text-gray-500 uppercase tracking-wider border-b border-gray-800/30">
              <th className="px-4 py-2 text-left font-medium">Operator</th>
              <th className="px-4 py-2 text-left font-medium">Stake</th>
              <th className="px-4 py-2 text-center font-medium">Status</th>
              <th className="px-4 py-2 text-right font-medium">Reputation</th>
              <th className="px-4 py-2 text-right font-medium">Submissions</th>
              <th className="px-4 py-2 text-right font-medium">Success Rate</th>
              <th className="px-4 py-2 text-right font-medium">Last Active</th>
            </tr>
          </thead>
          <tbody>
            {operators.map((op) => {
              const successRate = op.totalSubmissions > 0 ? (op.successfulProofs / op.totalSubmissions) * 100 : 0;
              return (
                <tr key={op.id} className="border-b border-gray-800/20 hover:bg-gray-800/20 transition-colors">
                  <td className="px-4 py-3">
                    <div>
                      <span className="font-mono text-gray-200">{formatAddress(op.address)}</span>
                      <div className="flex gap-1 mt-1">
                        {op.endpoints.map((ep, i) => (
                          <span key={i} className="text-[10px] text-gray-600 truncate max-w-[140px]">{ep}</span>
                        ))}
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="font-mono text-gray-200">${formatNumber(op.stake)}</span>
                    <ProgressBar value={op.stake} max={maxStake} color="bg-zk-500" />
                  </td>
                  <td className="px-4 py-3 text-center">
                    <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium border ${statusBg(op.status)}`}>{op.status}</span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <span className={`font-mono ${op.reputation >= 80 ? 'text-oracle-400' : op.reputation >= 50 ? 'text-yellow-400' : 'text-danger-400'}`}>
                      {op.reputation.toFixed(1)}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right font-mono text-gray-300">{formatNumber(op.totalSubmissions)}</td>
                  <td className="px-4 py-3 text-right">
                    <span className={`font-mono ${successRate >= 99 ? 'text-oracle-400' : successRate >= 95 ? 'text-yellow-400' : 'text-danger-400'}`}>
                      {successRate.toFixed(2)}%
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right text-xs text-gray-500">{formatTimeAgo(op.lastActive)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {operators.some((op) => op.slashingEvents.length > 0) && (
        <div className="p-4 border-t border-gray-800/40">
          <h3 className="text-xs font-semibold text-danger-400 uppercase tracking-wider mb-3">Recent Slashing Events</h3>
          <div className="space-y-2">
            {operators
              .filter((op) => op.slashingEvents.length > 0)
              .flatMap((op) => op.slashingEvents)
              .map((evt) => (
                <div key={evt.id} className="p-3 bg-red-950/20 border border-red-900/30 rounded-lg">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-danger-400 font-medium">{evt.reason}</span>
                    <span className="text-xs text-gray-500">{formatTimeAgo(evt.timestamp)}</span>
                  </div>
                  <div className="flex gap-4 text-xs text-gray-500">
                    <span>Operator: {formatAddress(evt.proofHash)}</span>
                    <span>Slashed: ${formatNumber(evt.amount)}</span>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}
    </div>
  );
}
