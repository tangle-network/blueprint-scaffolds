import type { DataFeed, DataSource, TLSAttestation, Operator, SlashingEvent, NetworkStats, ZKProof, AggregationResult } from '../types';

const randomHex = (len: number) => Array.from({ length: len }, () => Math.floor(Math.random() * 16).toString(16)).join('');
const now = () => Math.floor(Date.now() / 1000);
const jitter = (base: number, pct: number) => base * (1 + (Math.random() - 0.5) * pct);

function makeTLSAttestation(host: string): TLSAttestation {
  return {
    certificateHash: '0x' + randomHex(32),
    serverName: host,
    cipherSuite: 'TLS_AES_256_GCM_SHA384',
    notBefore: now() - 86400 * 30,
    notAfter: now() + 86400 * 60,
    verified: true,
  };
}

function makeSources(basePrice: number): DataSource[] {
  const apis = [
    { url: 'https://api.coingecko.com/api/v3/simple/price', name: 'CoinGecko' },
    { url: 'https://api.binance.com/api/v3/ticker/price', name: 'Binance' },
    { url: 'https://api.coinbase.com/v2/prices/spot', name: 'Coinbase' },
    { url: 'https://api.kraken.com/0/public/Ticker', name: 'Kraken' },
    { url: 'https://api.gemini.com/v1/pubticker', name: 'Gemini' },
  ];
  return apis.map((api) => ({
    ...api,
    url: `${api.url}?symbol=BTC`,
    value: jitter(basePrice, 0.002),
    timestamp: now() - Math.floor(Math.random() * 60),
    tlsAttestation: makeTLSAttestation(new URL(api.url).hostname),
    status: Math.random() > 0.1 ? 'healthy' : Math.random() > 0.5 ? 'degraded' : 'down',
  }));
}

export function generateFeeds(): DataFeed[] {
  const feeds: DataFeed[] = [
    { id: 'btc-usd', name: 'BTC/USD', pair: 'BTC/USD', value: 67842.5, previousValue: 67650.2, decimals: 2, sources: [], lastUpdated: 0, proofStatus: 'proved', medianProof: '', twapValue: 67780.3, twapPeriod: 3600, deviationBps: 28, heartbeatSec: 60 },
    { id: 'eth-usd', name: 'ETH/USD', pair: 'ETH/USD', value: 3456.78, previousValue: 3442.1, decimals: 2, sources: [], lastUpdated: 0, proofStatus: 'proved', medianProof: '', twapValue: 3450.2, twapPeriod: 3600, deviationBps: 42, heartbeatSec: 60 },
    { id: 'sol-usd', name: 'SOL/USD', pair: 'SOL/USD', value: 178.45, previousValue: 176.9, decimals: 2, sources: [], lastUpdated: 0, proofStatus: 'proving', medianProof: '', twapValue: 177.2, twapPeriod: 3600, deviationBps: 87, heartbeatSec: 60 },
    { id: 'link-usd', name: 'LINK/USD', pair: 'LINK/USD', value: 14.56, previousValue: 14.62, decimals: 2, sources: [], lastUpdated: 0, proofStatus: 'proved', medianProof: '', twapValue: 14.59, twapPeriod: 3600, deviationBps: 41, heartbeatSec: 120 },
    { id: 'arb-usd', name: 'ARB/USD', pair: 'ARB/USD', value: 1.12, previousValue: 1.14, decimals: 4, sources: [], lastUpdated: 0, proofStatus: 'proved', medianProof: '', twapValue: 1.13, twapPeriod: 3600, deviationBps: 177, heartbeatSec: 120 },
    { id: 'matic-usd', name: 'MATIC/USD', pair: 'MATIC/USD', value: 0.5842, previousValue: 0.5891, decimals: 4, sources: [], lastUpdated: 0, proofStatus: 'pending', medianProof: '', twapValue: 0.5867, twapPeriod: 3600, deviationBps: 83, heartbeatSec: 120 },
    { id: 'avax-usd', name: 'AVAX/USD', pair: 'AVAX/USD', value: 36.78, previousValue: 37.12, decimals: 2, sources: [], lastUpdated: 0, proofStatus: 'proved', medianProof: '', twapValue: 36.95, twapPeriod: 3600, deviationBps: 92, heartbeatSec: 60 },
    { id: 'dot-usd', name: 'DOT/USD', pair: 'DOT/USD', value: 6.42, previousValue: 6.38, decimals: 2, sources: [], lastUpdated: 0, proofStatus: 'failed', medianProof: '', twapValue: 6.40, twapPeriod: 3600, deviationBps: 63, heartbeatSec: 120 },
  ];

  const priceMap: Record<string, number> = {
    'btc-usd': 67842, 'eth-usd': 3456, 'sol-usd': 178,
    'link-usd': 14.5, 'arb-usd': 1.12, 'matic-usd': 0.58,
    'avax-usd': 36.7, 'dot-usd': 6.4,
  };

  return feeds.map((f) => ({
    ...f,
    sources: makeSources(priceMap[f.id] ?? 100),
    lastUpdated: now() - Math.floor(Math.random() * 30),
    medianProof: '0x' + randomHex(64),
  }));
}

export function generateOperators(): Operator[] {
  const statuses: Operator['status'][] = ['active', 'active', 'active', 'active', 'active', 'active', 'slashed', 'pending', 'active', 'jailed'];
  return statuses.map((status, i) => ({
    id: `op-${i}`,
    address: '0x' + randomHex(40),
    stake: jitter(50000, 0.8),
    reputation: Math.min(100, jitter(85, 0.3)),
    status,
    totalSubmissions: Math.floor(jitter(12000, 0.6)),
    successfulProofs: Math.floor(jitter(11500, 0.6)),
    failedProofs: Math.floor(jitter(50, 0.8)),
    lastActive: now() - Math.floor(Math.random() * 300),
    endpoints: [`https://operator-${i}.zkoracle.network`, `https://op-${i}-backup.zkoracle.network`],
    slashingEvents: status === 'slashed' ? [{
      id: `slash-${i}`,
      operatorId: `op-${i}`,
      reason: 'Invalid ZK proof — journal commitment mismatch',
      amount: 5000,
      timestamp: now() - 86400,
      proofHash: '0x' + randomHex(32),
    }] : [],
  }));
}

export function generateNetworkStats(): NetworkStats {
  return {
    totalOperators: 10,
    activeOperators: 7,
    totalStake: 485000,
    totalFeeds: 8,
    avgProofTime: 4.2,
    totalProofsGenerated: 284910,
    slashingRate: 0.003,
    networkUptime: 99.97,
  };
}

export function generateProof(method: ZKProof['method']): ZKProof {
  return {
    receipt: '0x' + randomHex(128),
    journal: '0x' + randomHex(256),
    imageId: '0x' + randomHex(32),
    seal: '0x' + randomHex(64),
    timestamp: now(),
    method,
  };
}

export function computeAggregation(values: number[]): Omit<AggregationResult, 'feedId' | 'timestamp' | 'proof'> {
  const sorted = [...values].sort((a, b) => a - b);
  const n = sorted.length;
  const median = n % 2 === 0 ? (sorted[n / 2 - 1] + sorted[n / 2]) / 2 : sorted[Math.floor(n / 2)];
  const mean = sorted.reduce((s, v) => s + v, 0) / n;
  const variance = sorted.reduce((s, v) => s + (v - mean) ** 2, 0) / n;
  const twap = mean * (1 + (Math.random() - 0.5) * 0.001);
  return {
    median,
    twap,
    mean,
    min: sorted[0],
    max: sorted[n - 1],
    stdDev: Math.sqrt(variance),
    sourceCount: n,
  };
}
