export function formatUsd(value: number, decimals: number = 2): string {
  if (value >= 1000) return `$${value.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}`;
  if (value >= 1) return `$${value.toFixed(decimals)}`;
  return `$${value.toFixed(4)}`;
}

export function formatAddress(addr: string): string {
  return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
}

export function formatTimeAgo(ts: number): string {
  const diff = Math.floor(Date.now() / 1000) - ts;
  if (diff < 60) return `${diff}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

export function formatNumber(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n.toLocaleString();
}

export function deviationColor(bps: number): string {
  if (bps < 50) return 'text-oracle-400';
  if (bps < 100) return 'text-yellow-400';
  return 'text-danger-400';
}

export function statusColor(status: string): string {
  switch (status) {
    case 'proved': case 'healthy': case 'active': return 'text-oracle-400';
    case 'proving': case 'pending': case 'degraded': return 'text-yellow-400';
    case 'failed': case 'slashed': case 'down': return 'text-danger-400';
    case 'jailed': return 'text-orange-400';
    default: return 'text-gray-400';
  }
}

export function statusBg(status: string): string {
  switch (status) {
    case 'proved': case 'healthy': case 'active': return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
    case 'proving': case 'pending': case 'degraded': return 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20';
    case 'failed': case 'slashed': case 'down': return 'bg-red-500/10 text-red-400 border-red-500/20';
    case 'jailed': return 'bg-orange-500/10 text-orange-400 border-orange-500/20';
    default: return 'bg-gray-500/10 text-gray-400 border-gray-500/20';
  }
}
