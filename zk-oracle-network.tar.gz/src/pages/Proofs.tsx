import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Search, FileCheck2, Clock, Zap, ExternalLink,
  Shield, Database, Server
} from 'lucide-react';
import { useState } from 'react';
import { proofs, dataFeeds, operators } from '@/lib/data';
import type { Proof } from '@/lib/types';

function timeAgo(ts: number): string {
  const diff = Date.now() - ts;
  if (diff < 60000) return `${Math.floor(diff / 1000)}s ago`;
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
  return `${Math.floor(diff / 86400000)}d ago`;
}

function proofStatusBadge(status: Proof['status']) {
  const map: Record<string, { variant: 'success' | 'warning' | 'secondary' | 'destructive'; label: string }> = {
    verified: { variant: 'success', label: 'Verified' },
    submitted: { variant: 'warning', label: 'Submitted' },
    generating: { variant: 'secondary', label: 'Generating' },
    rejected: { variant: 'destructive', label: 'Rejected' },
  };
  const s = map[status];
  return <Badge variant={s.variant}>{s.label}</Badge>;
}

function typeLabel(type: Proof['type']): string {
  return type.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
}

function ProofRow({ proof }: { proof: Proof }) {
  const feed = dataFeeds.find(f => f.id === proof.feedId);
  const operator = operators.find(o => o.id === proof.operatorId);

  return (
    <Card>
      <CardContent className="py-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center shrink-0">
              <FileCheck2 className="h-5 w-5" />
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-medium text-sm">{proof.id}</span>
                {proofStatusBadge(proof.status)}
                <Badge variant="outline" className="text-xs">{typeLabel(proof.type)}</Badge>
              </div>
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Database className="h-3 w-3" />
                  {feed?.name ?? proof.feedId}
                </span>
                <span className="flex items-center gap-1">
                  <Server className="h-3 w-3" />
                  {operator?.name ?? proof.operatorId}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4 sm:gap-6 text-xs">
            {proof.gasUsed && (
              <div className="text-center">
                <p className="text-muted-foreground">Gas Used</p>
                <p className="font-medium">{proof.gasUsed.toLocaleString()}</p>
              </div>
            )}
            {proof.blockNumber && (
              <div className="text-center">
                <p className="text-muted-foreground">Block</p>
                <p className="font-medium">#{proof.blockNumber.toLocaleString()}</p>
              </div>
            )}
            <div className="text-center">
              <p className="text-muted-foreground">Submitted</p>
              <p className="font-medium">{timeAgo(proof.submittedAt)}</p>
            </div>
            {proof.verifiedAt && (
              <div className="text-center">
                <p className="text-muted-foreground">Verified</p>
                <p className="font-medium text-emerald-400">{timeAgo(proof.verifiedAt)}</p>
              </div>
            )}
            <Button variant="outline" size="sm" className="gap-1 text-xs shrink-0">
              <ExternalLink className="h-3 w-3" />
              View
            </Button>
          </div>
        </div>

        {proof.status === 'verified' && (
          <>
            <Separator className="my-3" />
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
              <div>
                <span className="text-muted-foreground">Image ID: </span>
                <span className="font-mono">{proof.imageId.slice(0, 18)}...</span>
              </div>
              <div>
                <span className="text-muted-foreground">Input: </span>
                <span className="font-mono">{proof.inputHash.slice(0, 18)}...</span>
              </div>
              <div>
                <span className="text-muted-foreground">Output: </span>
                <span className="font-mono">{proof.outputHash.slice(0, 18)}...</span>
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

export default function Proofs() {
  const [search, setSearch] = useState('');
  const [tab, setTab] = useState('all');

  const filtered = proofs.filter((proof) => {
    const feed = dataFeeds.find(f => f.id === proof.feedId);
    const operator = operators.find(o => o.id === proof.operatorId);
    const matchesSearch =
      proof.id.toLowerCase().includes(search.toLowerCase()) ||
      (feed?.name ?? '').toLowerCase().includes(search.toLowerCase()) ||
      (operator?.name ?? '').toLowerCase().includes(search.toLowerCase());
    const matchesTab = tab === 'all' || proof.status === tab;
    return matchesSearch && matchesTab;
  }).sort((a, b) => b.submittedAt - a.submittedAt);

  const verifiedCount = proofs.filter(p => p.status === 'verified').length;
  const totalGas = proofs.reduce((sum, p) => sum + (p.gasUsed ?? 0), 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Zero-Knowledge Proofs</h1>
          <p className="text-muted-foreground mt-1">
            {proofs.length} proofs · {verifiedCount} verified · {totalGas.toLocaleString()} gas used
          </p>
        </div>
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search proofs..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="all">All ({proofs.length})</TabsTrigger>
          <TabsTrigger value="verified">Verified ({proofs.filter(p => p.status === 'verified').length})</TabsTrigger>
          <TabsTrigger value="submitted">Submitted ({proofs.filter(p => p.status === 'submitted').length})</TabsTrigger>
          <TabsTrigger value="generating">Generating ({proofs.filter(p => p.status === 'generating').length})</TabsTrigger>
          <TabsTrigger value="rejected">Rejected ({proofs.filter(p => p.status === 'rejected').length})</TabsTrigger>
        </TabsList>
        <TabsContent value={tab} className="mt-4">
          {filtered.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              No proofs match your search criteria.
            </div>
          ) : (
            <div className="space-y-3">
              {filtered.map((proof) => (
                <ProofRow key={proof.id} proof={proof} />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
