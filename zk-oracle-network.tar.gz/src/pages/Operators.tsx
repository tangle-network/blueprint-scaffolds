import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Search, ArrowUpRight, ExternalLink, Shield, Coins,
  Activity, Clock, Zap, CircleDot, Server
} from 'lucide-react';
import { useState } from 'react';
import { operators, dataFeeds } from '@/lib/data';
import type { Operator } from '@/lib/types';

function timeAgo(ts: number): string {
  const diff = Date.now() - ts;
  if (diff < 60000) return `${Math.floor(diff / 1000)}s ago`;
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
  if (diff < 86400000) return `${Math.floor(diff / 86400000)}d ago`;
  return `${Math.floor(diff / 86400000)}d ago`;
}

function statusBadge(status: Operator['status']) {
  const map: Record<string, { variant: 'success' | 'secondary' | 'destructive'; label: string }> = {
    active: { variant: 'success', label: 'Active' },
    inactive: { variant: 'secondary', label: 'Inactive' },
    slashed: { variant: 'destructive', label: 'Slashed' },
  };
  const s = map[status];
  return <Badge variant={s.variant}>{s.label}</Badge>;
}

function OperatorCard({ operator }: { operator: Operator }) {
  const feedNames = operator.feedsServing
    .map(id => dataFeeds.find(f => f.id === id)?.name)
    .filter(Boolean) as string[];

  const successRate = operator.proofsGenerated > 0
    ? ((operator.proofsVerified / operator.proofsGenerated) * 100).toFixed(2)
    : '0';

  return (
    <Card className={operator.status === 'slashed' ? 'border-red-500/30' : operator.status === 'inactive' ? 'opacity-60' : ''}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
              <Server className="h-4 w-4 text-primary" />
            </div>
            <div>
              <CardTitle className="text-base">{operator.name}</CardTitle>
              <p className="text-xs text-muted-foreground font-mono mt-0.5">
                {operator.address.slice(0, 10)}...{operator.address.slice(-8)}
              </p>
            </div>
          </div>
          {statusBadge(operator.status)}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              <Coins className="h-3 w-3" /> Stake
            </p>
            <p className="text-sm font-semibold">${(operator.stake).toLocaleString()}</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              <Shield className="h-3 w-3" /> Reputation
            </p>
            <div className="flex items-center gap-2">
              <Progress value={operator.reputation} className="h-2 flex-1" />
              <span className="text-xs font-medium">{operator.reputation}%</span>
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              <Activity className="h-3 w-3" /> Uptime
            </p>
            <p className="text-sm font-semibold">{operator.uptime}%</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              <Clock className="h-3 w-3" /> Last Active
            </p>
            <p className="text-sm font-semibold">{timeAgo(operator.lastActive)}</p>
          </div>
        </div>

        <Separator />

        <div className="space-y-2">
          <p className="text-xs text-muted-foreground">Proof Statistics</p>
          <div className="flex justify-between text-sm">
            <span>Generated</span>
            <span className="font-medium">{operator.proofsGenerated.toLocaleString()}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span>Verified</span>
            <span className="font-medium">{operator.proofsVerified.toLocaleString()}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span>Success Rate</span>
            <span className="font-medium text-emerald-400">{successRate}%</span>
          </div>
          {operator.slashCount > 0 && (
            <div className="flex justify-between text-sm">
              <span>Slash Events</span>
              <span className="font-medium text-red-400">{operator.slashCount}</span>
            </div>
          )}
        </div>

        {feedNames.length > 0 && (
          <>
            <Separator />
            <div className="space-y-2">
              <p className="text-xs text-muted-foreground">Feeds Serving</p>
              <div className="flex flex-wrap gap-1">
                {feedNames.map((name) => (
                  <Badge key={name} variant="outline" className="text-xs">{name}</Badge>
                ))}
              </div>
            </div>
          </>
        )}

        <div className="flex justify-between items-center pt-1">
          <span className="text-xs text-muted-foreground">
            Rewards: <span className="text-foreground font-medium">{operator.totalRewards.toLocaleString()} tokens</span>
          </span>
          <Button variant="outline" size="sm" className="gap-1 text-xs">
            <ExternalLink className="h-3 w-3" />
            Profile
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Operators() {
  const [search, setSearch] = useState('');
  const [tab, setTab] = useState('all');

  const filtered = operators.filter((op) => {
    const matchesSearch = op.name.toLowerCase().includes(search.toLowerCase()) ||
      op.address.toLowerCase().includes(search.toLowerCase());
    const matchesTab = tab === 'all' || op.status === tab;
    return matchesSearch && matchesTab;
  });

  const totalStake = operators.reduce((sum, op) => sum + op.stake, 0);
  const activeCount = operators.filter(o => o.status === 'active').length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Operators</h1>
          <p className="text-muted-foreground mt-1">
            {activeCount} active operators securing ${totalStake.toLocaleString()} in total stake
          </p>
        </div>
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search operators..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="all">All ({operators.length})</TabsTrigger>
          <TabsTrigger value="active">Active ({operators.filter(o => o.status === 'active').length})</TabsTrigger>
          <TabsTrigger value="inactive">Inactive ({operators.filter(o => o.status === 'inactive').length})</TabsTrigger>
          <TabsTrigger value="slashed">Slashed ({operators.filter(o => o.status === 'slashed').length})</TabsTrigger>
        </TabsList>
        <TabsContent value={tab} className="mt-4">
          {filtered.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              No operators match your search criteria.
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filtered.map((op) => (
                <OperatorCard key={op.id} operator={op} />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
