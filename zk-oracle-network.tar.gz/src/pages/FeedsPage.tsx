import { useState } from 'react';
import { useFeeds, useNetworkStats, useSelectedFeed } from '../hooks/useData';
import { NetworkStatsBar, FeedTable, FeedDetail } from '../components';

export default function FeedsPage() {
  const feeds = useFeeds();
  const stats = useNetworkStats();
  const [selectedId, setSelectedId] = useState<string | undefined>(feeds[0]?.id);
  const selectedFeed = useSelectedFeed(feeds, selectedId);

  return (
    <div className="space-y-6">
      <NetworkStatsBar stats={stats} />
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <div className="lg:col-span-3">
          <FeedTable feeds={feeds} selectedId={selectedId} onSelect={setSelectedId} />
        </div>
        <div className="lg:col-span-2">
          {selectedFeed ? <FeedDetail feed={selectedFeed} /> : <div className="glass p-8 text-center text-gray-600">Select a feed</div>}
        </div>
      </div>
    </div>
  );
}
