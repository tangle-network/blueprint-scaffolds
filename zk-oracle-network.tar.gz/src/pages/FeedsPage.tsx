import { useState } from 'react';
import { Search, RefreshCw, ExternalLink } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { dataFeeds } from '@/lib/data';
import type { DataFeed, FeedCategory } from '@/lib/types';

function timeAgo(ts: number): string {
  const diff = Date.now() - ts;
  const secs = Math.floor(diff / 1000);
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.floor(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  return `${hours}h ago`;
}

function formatValue(value: number, category: FeedCategory): string {
  if (category === 'price' || category === 'defi') {
    if (value >= 1e9) return `$${(value / 1e9).toFixed(2)}B`;
    if (value >= 1e6) return `$${(value / 1e6).toFixed(2)}M`;
    if (value >= 1e3) return `$${value.toLocaleString(undefined, { maximumFractionDigits: 2 })}`;
    return `$${value.toFixed(2)}`;
  }
  if (category === 'weather') return `${value.toFixed(1)}°F`;
  if (category === 'randomness') return value.toFixed(6);
  return value.toLocaleString();
}

const categoryLabels: Record<FeedCategory, string> = {
  price: 'Price Feeds',
  defi: 'DeFi Metrics',
  weather: 'Weather',
  sports: 'Sports',
  randomness: 'Randomness',
};

function FeedCard({ feed }: { feed: DataFeed }) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CardTitle className="text-lg">{feed.name}</CardTitle>
            <Badge variant="outline" className="text-xs capitalize">{feed.category}</Badge>
          </div>
          <Badge
            variant={
              feed.proofStatus === 'verified' ? 'success' :
              feed.proofStatus === 'generating' ? 'warning' :
              feed.proofStatus === 'pending' ? 'secondary' : 'destructive'
            }
          >
            {feed.proofStatus === 'verified' && '✓ Verified'}
            {feed.proofStatus === 'generating' && '⟳ Generating'}
            {feed.proofStatus === 'pending' && '◦ Pending'}
            {feed.proofStatus === 'failed' && '✕ Failed'}
          </Badge>
        </div>
        <CardDescription className="text-xs">{feed.description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
          <div>
            <p className="text-xs text-muted-foreground">Current Value</p>
            <p className="text-lg font-mono font-semibold">{formatValue(feed.value, feed.category)}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">24h Change</p>
            <p className={`text-lg font-mono font-semibold ${feed.changePercent24h >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {feed.changePercent24h >= 0 ? '+' : ''}{feed.changePercent24h.toFixed(2)}%
            </p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Sources</p>
            <p className="text-lg font-semibold">{feed.sources.length}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Subscribers</p>
            <p className="text-lg font-semibold">{feed.subscribers.toLocaleString()}</p>
          </div>
        </div>

        <Separator className="my-3" />

        <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
          <span>Aggregation: <span className="text-foreground font-medium uppercase">{feed.aggregationMethod}</span></span>
          <span className="flex items-center gap-1">
            <RefreshCw className="h-3 w-3" />
            Updated {timeAgo(feed.lastUpdated)}
          </span>
        </div>

        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground">Data Sources</p>
          {feed.sources.map(src => (
            <div key={src.id} className="flex items-center justify-between text-xs p-2 rounded bg-muted/50">
              <div className="flex items-center gap-2">
                <div className={`h-1.5 w-1.5 rounded-full ${src.status === 'healthy' ? 'bg-emerald-400' : src.status === 'degraded' ? 'bg-amber-400' : 'bg-red-400'}`} />
                <span className="font-medium">{src.name}</span>
              </div>
              <div className="flex items-center gap-3">
                <span>TLS: {src.tlsVerified ? '✓' : '✕'}</span>
                <span className="font-mono">{formatValue(src.value, feed.category)}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between mt-3 text-xs text-muted-foreground">
          <span className="font-mono">{feed.apiEndpoint}</span>
          <Button variant="ghost" size="sm" className="h-6 text-xs gap-1">
            <ExternalLink className="h-3 w-3" />
            Details
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export default function FeedsPage() {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState<string>('all');

  const filtered = dataFeeds.filter(f => {
    const matchesSearch = f.name.toLowerCase().includes(search.toLowerCase()) ||
      f.description.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = category === 'all' || f.category === category;
    return matchesSearch && matchesCategory;
  });

  const categories = ['all', ...new Set(dataFeeds.map(f => f.category))];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Data Feeds</h1>
        <p className="text-muted-foreground mt-1">
          ZK-verified data feeds with multi-source aggregation
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search feeds by name or description..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      <Tabs value={category} onValueChange={setCategory}>
        <TabsList>
          {categories.map(cat => (
            <TabsTrigger key={cat} value={cat}>
              {cat === 'all' ? 'All Feeds' : categoryLabels[cat as FeedCategory] ?? cat}
            </TabsTrigger>
          ))}
        </TabsList>
        {categories.map(cat => (
          <TabsContent key={cat} value={cat}>
            <div className="grid gap-4">
              {(cat === 'all' ? filtered : filtered.filter(f => f.category === cat)).map(feed => (
                <FeedCard key={feed.id} feed={feed} />
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>

      {filtered.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground">No feeds match your search criteria.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
