import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import {
  Users, ShieldCheck, Database, Activity, TrendingUp,
  Clock, Zap, AlertTriangle, ArrowUpRight, CircleDot,
  FileCheck2, Coins, Server
} from 'lucide-react';
import { networkStats, dataFeeds, operators, proofs, slashingEvents } from '@/lib/data';

function timeAgo(ts: number): string {
  const diff = Date.now() - ts;
  if (diff < 60000) return `${Math.floor(diff / 1000)}s ago`;
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
  return `${Math.floor(diff / 86400000)}d ago`;
}

function StatCard({ icon: Icon, title, value, subtitle, trend }: {
  icon: React.ElementType;
  title: string;
  value: string;
  subtitle: string;
  trend?: string;
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <div className="flex items-center gap-1 mt-1">
          {trend && (
            <span className="text-xs text-emerald-400 flex items-center gap-0.5">
              <ArrowUpRight className="h-3 w-3" />
              {trend}
            </span>
          )}
          <p className="text-xs text-muted-foreground">{subtitle}</p>
        </div>
      </CardContent>
    </Card>
  );
}

function RecentProofRow({ proof }: { proof: typeof proofs[0] }) {
  const feed = dataFeeds.find(f => f.id === proof.feedId);
  const operator = operators.find(o => o.id === proof.operatorId);
  const statusMap: Record<string, { variant: 'success' | 'warning' | 'secondary' | 'destructive'; label: string }> = {
    verified: { variant: 'success', label: 'Verified' },
    submitted: { variant: 'warning', label: 'Submitted' },
    generating: { variant: 'secondary', label: 'Generating' },
    rejected: { variant: 'destructive', label: 'Rejected' },
  };
  const s = statusMap[proof.status] ?? { variant: 'secondary' as const, label: proof.status };
  return (
    <div className="flex items-center justify-between py-3">
      <div className="flex items-center gap-3">
        <div className="h-8 w-8 rounded-full bg-secondary flex items-center justify-center">
          <FileCheck2 className="h-4 w-4" />
        </div>
        <div>
          <p className="text-sm font-medium">{feed?.name ?? proof.feedId}</p>
          <p className="text-xs text-muted-foreground">
            by {operator?.name ?? proof.operatorId} · {proof.type.replace('_', ' ')}
          </p>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <span className="text-xs text-muted-foreground">{timeAgo(proof.submittedAt)}</span>
        <Badge variant={s.variant}>{s.label}</Badge>
      </div>
    </div>
  );
}

function SlashingAlertRow({ event }: { event: typeof slashingEvents[0] }) {
  return (
    <div className="flex items-start gap-3 py-3">
      <AlertTriangle className="h-5 w-5 text-amber-400 mt-0.5 shrink-0" />
      <div className="flex-1">
        <div className="flex items-center justify-between">
          <p className="text-sm font-medium">{event.operatorName}</p>
          <Badge variant={event.status === 'executed' ? 'destructive' : 'warning'}>{event.status}</Badge>
        </div>
        <p className="text-xs text-muted-foreground mt-0.5">{event.reason}</p>
        <p className="text-xs text-muted-foreground mt-0.5">
          Slashed: <span className="text-foreground">{event.amount.toLocaleString()} tokens</span> · {timeAgo(event.timestamp)}
        </p>
      </div>
    </div>
  );
}

function TopOperatorRow({ operator, rank }: { operator: typeof operators[0]; rank: number }) {
  return (
    <div className="flex items-center justify-between py-2">
      <div className="flex items-center gap-3">
        <span className="text-sm font-bold text-muted-foreground w-5">#{rank}</span>
        <div>
          <p className="text-sm font-medium">{operator.name}</p>
          <p className="text-xs text-muted-foreground">
            {operator.proofsVerified.toLocaleString()} proofs · {operator.feedsServing.length} feeds
          </p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <Progress value={operator.reputation} className="w-20 h-2" />
        <span className="text-xs font-medium w-10 text-right">{operator.reputation}%</span>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const activeFeeds = dataFeeds.filter(f => f.proofStatus === 'verified');
  const recentProofs = [...proofs].sort((a, b) => b.submittedAt - a.submittedAt).slice(0, 5);
  const topOperators = [...operators].filter(o => o.status === 'active').sort((a, b) => b.reputation - a.reputation).slice(0, 5);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Network Dashboard</h1>
        <p className="text-muted-foreground mt-1">
          Real-time overview of the ZK Oracle Network powered by RISC Zero
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          icon={Users}
          title="Active Operators"
          value={networkStats.activeOperators.toString()}
          subtitle={`of ${networkStats.totalOperators} total`}
          trend="+2 this week"
        />
        <StatCard
          icon={Database}
          title="Total Feeds"
          value={networkStats.totalFeeds.toString()}
          subtitle={`${activeFeeds.length} currently verified`}
        />
        <StatCard
          icon={ShieldCheck}
          title="Total Proofs"
          value={`${(networkStats.totalProofs / 1000).toFixed(1)}K`}
          subtitle="generated & verified"
          trend="+1.2K today"
        />
        <StatCard
          icon={Coins}
          title="Total Stake"
          value={`$${(networkStats.totalStake / 1e6).toFixed(1)}M`}
          subtitle="secured in staking"
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          icon={Clock}
          title="Avg Block Time"
          value={`${networkStats.avgBlockTime}s`}
          subtitle="proof verification"
        />
        <StatCard
          icon={Activity}
          title="Network Uptime"
          value={`${networkStats.networkUptime}%`}
          subtitle="last 30 days"
        />
        <StatCard
          icon={Zap}
          title="Gas Saved"
          value={`${(networkStats.totalGasSaved / 1e6).toFixed(1)}M`}
          subtitle="via ZK rollups"
          trend="+12% vs last month"
        />
        <StatCard
          icon={AlertTriangle}
          title="Slashing Events"
          value={networkStats.slashingEvents.toString()}
          subtitle="total on-chain"
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileCheck2 className="h-5 w-5" />
              Recent Proofs
            </CardTitle>
            <CardDescription>Latest proof submissions across the network</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="divide-y">
              {recentProofs.map((proof) => (
                <RecentProofRow key={proof.id} proof={proof} />
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Server className="h-5 w-5" />
              Top Operators by Reputation
            </CardTitle>
            <CardDescription>Highest-reputation active operators</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="divide-y">
              {topOperators.map((operator, i) => (
                <TopOperatorRow key={operator.id} operator={operator} rank={i + 1} />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {slashingEvents.length > 0 && (
        <Card className="border-amber-500/30">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-amber-400">
              <AlertTriangle className="h-5 w-5" />
              Recent Slashing Events
            </CardTitle>
            <CardDescription>On-chain slashing actions and disputes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="divide-y">
              {slashingEvents.map((event) => (
                <SlashingAlertRow key={event.id} event={event} />
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
