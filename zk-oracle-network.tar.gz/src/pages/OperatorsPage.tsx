import { useState } from 'react';
import { Search, ArrowUpDown, ShieldCheck, AlertTriangle, XCircle } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { operators, dataFeeds } from '@/lib/data';
import type { Operator } from '@/lib/types';

function timeAgo(ts: number): string {
  const diff = Date.now() - ts;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

function StatusIcon({ status }: { status: Operator['status'] }) {
  if (status === 'active') return <ShieldCheck className="h-4 w-4 text-emerald-400" />;
  if (status === 'inactive') return <AlertTriangle className="h-4 w-4 text-amber-400" />;
  return <XCircle className="h-4 w-4 text-red-400" />;
}

function OperatorCard({ operator }: { operator: Operator }) {
  const feeds = operator.feedsServing.map(id => dataFeeds.find(f => f.id === id)).filter(Boolean);
  const verifiedRate = operator.proofsGenerated > 0
    ? ((operator.proofsVerified / operator.proofsGenerated) * 100).toFixed(2)
    : '0';

  return (
    <Card className={operator.status === 'slashed' ? 'border-red-900/50' : ''}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <StatusIcon status={operator.status} />
            <CardTitle className="text-lg">{operator.name}</CardTitle>
          </div>
          <Badge
            variant={
              operator.status === 'active' ? 'success' :
              operator.status === 'inactive' ? 'warning' : 'destructive'
            }
          >
            {operator.status}
          </Badge>
        </div>
        <CardDescription className="font-mono text-xs">{operator.address}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
          <div>
            <p className="text-xs text-muted-foreground">Stake</p>
            <p className="text-lg font-mono font-semibold">${operator.stake.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Reputation</p>
            <p className="text-lg font-mono font-semibold">{operator.reputation}%</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Proofs Generated</p>
            <p className="text-lg font-mono font-semibold">{operator.proofsGenerated.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Total Rewards</p>
            <p className="text-lg font-mono font-semibold">${operator.totalRewards.toLocaleString()}</p>
          </div>
        </div>

        <div className="space-y-2 mb-4">
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Verification Rate</span>
            <span className="font-mono">{verifiedRate}%</span>
          </div>
          <Progress value={parseFloat(verifiedRate)} className="h-2" />
        </div>

        <div className="space-y-2 mb-4">
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Uptime</span>
            <span className="font-mono">{operator.uptime}%</span>
          </div>
          <Progress value={operator.uptime} className="h-2" />
        </div>

        <Separator className="my-3" />

        <div className="grid grid-cols-2 gap-4 text-xs">
          <div>
            <p className="text-muted-foreground">Proofs Verified</p>
            <p className="font-mono">{operator.proofsVerified.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Slash Count</p>
            <p className={`font-mono ${operator.slashCount > 0 ? 'text-red-400' : 'text-emerald-400'}`}>
              {operator.slashCount}
            </p>
          </div>
          <div>
            <p className="text-muted-foreground">Last Active</p>
            <p className="font-mono">{timeAgo(operator.lastActive)}</p>
          </div>
          <div>
            <p className="text-muted-foreground">RISC Zero Image</p>
            <p className="font-mono truncate">{operator.riscZeroImageId}</p>
          </div>
        </div>

        {feeds.length > 0 && (
          <>
            <Separator className="my-3" />
            <div>
              <p className="text-xs text-muted-foreground mb-2">Feeds Serving</p>
              <div className="flex flex-wrap gap-1">
                {feeds.map(f => f && (
                  <Badge key={f.id} variant="outline" className="text-xs">
                    {f.name}
                  </Badge>
                ))}
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

type SortKey = 'reputation' | 'stake' | 'proofsGenerated' | 'uptime';

export default function OperatorsPage() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<SortKey>('reputation');

  const filtered = operators
    .filter(op => {
      const matchesSearch = op.name.toLowerCase().includes(search.toLowerCase()) ||
        op.address.toLowerCase().includes(search.toLowerCase());
      const matchesStatus = statusFilter === 'all' || op.status === statusFilter;
      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      if (sortBy === 'proofsGenerated') return b.proofsGenerated - a.proofsGenerated;
      if (sortBy === 'stake') return b.stake - a.stake;
      if (sortBy === 'uptime') return b.uptime - a.uptime;
      return b.reputation - a.reputation;
    });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Operators</h1>
        <p className="text-muted-foreground mt-1">
          Network operators running RISC Zero prover nodes
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by name or address..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex gap-2">
          {(['all', 'active', 'inactive', 'slashed'] as const).map(s => (
            <Button
              key={s}
              variant={statusFilter === s ? 'secondary' : 'outline'}
              size="sm"
              onClick={() => setStatusFilter(s)}
              className="capitalize"
            >
              {s}
            </Button>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-2">
        <ArrowUpDown className="h-4 w-4 text-muted-foreground" />
        <span className="text-sm text-muted-foreground">Sort by:</span>
        {([
          { key: 'reputation' as SortKey, label: 'Reputation' },
          { key: 'stake' as SortKey, label: 'Stake' },
          { key: 'proofsGenerated' as SortKey, label: 'Proofs' },
          { key: 'uptime' as SortKey, label: 'Uptime' },
        ]).map(item => (
          <Button
            key={item.key}
            variant={sortBy === item.key ? 'secondary' : 'ghost'}
            size="sm"
            onClick={() => setSortBy(item.key)}
          >
            {item.label}
          </Button>
        ))}
      </div>

      <div className="grid gap-4">
        {filtered.map(op => (
          <OperatorCard key={op.id} operator={op} />
        ))}
      </div>

      {filtered.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground">No operators match your criteria.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
