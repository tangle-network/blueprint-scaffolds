import { Activity, ShieldCheck, Users, Database, Zap, TrendingUp, Clock, Fuel } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { networkStats, dataFeeds, operators, proofs, slashingEvents } from '@/lib/data';

function formatNumber(n: number): string {
  if (n >= 1e9) return `$${(n / 1e9).toFixed(2)}B`;
  if (n >= 1e6) return `$${(n / 1e6).toFixed(2)}M`;
  if (n >= 1e3) return `${(n / 1e3).toFixed(1)}K`;
  return n.toLocaleString();
}

function timeAgo(ts: number): string {
  const diff = Date.now() - ts;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

export default function DashboardPage() {
  const activeFeeds = dataFeeds.filter(f => f.proofStatus === 'verified');
  const activeOps = operators.filter(o => o.status === 'active');
  const recentProofs = [...proofs].sort((a, b) => b.submittedAt - a.submittedAt).slice(0, 5);
  const recentSlashing = slashingEvents.slice(0, 3);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Network Dashboard</h1>
        <p className="text-muted-foreground mt-1">
          Real-time overview of the ZK Oracle Network powered by RISC Zero
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Operators</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{networkStats.activeOperators} / {networkStats.totalOperators}</div>
            <Progress value={(networkStats.activeOperators / networkStats.totalOperators) * 100} className="mt-2 h-2" />
            <p className="text-xs text-muted-foreground mt-1">{((networkStats.activeOperators / networkStats.totalOperators) * 100).toFixed(1)}% participation</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Data Feeds</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeFeeds.length} / {dataFeeds.length}</div>
            <Progress value={(activeFeeds.length / dataFeeds.length) * 100} className="mt-2 h-2" />
            <p className="text-xs text-muted-foreground mt-1">feeds with verified proofs</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Proofs</CardTitle>
            <ShieldCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{networkStats.totalProofs.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
              <TrendingUp className="h-3 w-3 text-emerald-400" />
              <span className="text-emerald-400">+847</span> in last 24h
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Network Uptime</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{networkStats.networkUptime}%</div>
            <Progress value={networkStats.networkUptime} className="mt-2 h-2" />
            <p className="text-xs text-muted-foreground mt-1">avg block time: {networkStats.avgBlockTime}s</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Staked</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(networkStats.totalStake)}</div>
            <p className="text-xs text-muted-foreground mt-1">across {networkStats.activeOperators} active operators</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Gas Saved</CardTitle>
            <Fuel className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(networkStats.totalGasSaved)}</div>
            <p className="text-xs text-muted-foreground mt-1">via proof verification batching</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Slashing Events</CardTitle>
            <Fuel className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{networkStats.slashingEvents}</div>
            <p className="text-xs text-muted-foreground mt-1">total slashing events recorded</p>
          </CardContent>
        </Card>
      </div>

      <Separator />

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Live Data Feeds</CardTitle>
            <CardDescription>Top feeds by subscriber count</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[...dataFeeds].sort((a, b) => b.subscribers - a.subscribers).slice(0, 5).map(feed => (
                <div key={feed.id} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-2 w-2 rounded-full bg-primary" />
                    <div>
                      <p className="text-sm font-medium">{feed.name}</p>
                      <p className="text-xs text-muted-foreground">{feed.subscribers.toLocaleString()} subscribers</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-mono">
                      {feed.value >= 1e6 ? `$${(feed.value / 1e9).toFixed(2)}B` : feed.value.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                    </p>
                    <p className={`text-xs ${feed.changePercent24h >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                      {feed.changePercent24h >= 0 ? '+' : ''}{feed.changePercent24h.toFixed(2)}%
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Recent Proof Activity</CardTitle>
            <CardDescription>Latest proof submissions and verifications</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentProofs.map(proof => {
                const feed = dataFeeds.find(f => f.id === proof.feedId);
                const op = operators.find(o => o.id === proof.operatorId);
                return (
                  <div key={proof.id} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div>
                        <p className="text-sm font-medium">{feed?.name ?? proof.feedId}</p>
                        <p className="text-xs text-muted-foreground">by {op?.name ?? proof.operatorId}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">
                        {proof.type.replace('_', ' ')}
                      </Badge>
                      <Badge
                        variant={
                          proof.status === 'verified' ? 'success' :
                          proof.status === 'rejected' ? 'destructive' :
                          proof.status === 'generating' ? 'warning' : 'secondary'
                        }
                      >
                        {proof.status}
                      </Badge>
                      <span className="text-xs text-muted-foreground">{timeAgo(proof.submittedAt)}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {recentSlashing.length > 0 && (
        <Card className="border-red-900/50">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Fuel className="h-5 w-5 text-red-400" />
              Recent Slashing Events
            </CardTitle>
            <CardDescription>Operator slashing incidents requiring attention</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentSlashing.map(event => (
                <div key={event.id} className="flex items-center justify-between p-3 rounded-md bg-destructive/10">
                  <div>
                    <p className="text-sm font-medium">{event.operatorName}</p>
                    <p className="text-xs text-muted-foreground">{event.reason}</p>
                  </div>
                  <div className="text-right flex items-center gap-3">
                    <Badge variant={event.status === 'executed' ? 'destructive' : 'warning'}>
                      {event.status}
                    </Badge>
                    <span className="text-sm font-mono text-red-400">-{event.amount.toLocaleString()} stake</span>
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {timeAgo(event.timestamp)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Top Operators by Reputation</CardTitle>
          <CardDescription>Ranked by proof verification rate and uptime</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[...activeOps].sort((a, b) => b.reputation - a.reputation).slice(0, 5).map((op, i) => (
              <div key={op.id} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-sm font-mono text-muted-foreground w-6">#{i + 1}</span>
                  <div>
                    <p className="text-sm font-medium">{op.name}</p>
                    <p className="text-xs text-muted-foreground">{op.proofsGenerated.toLocaleString()} proofs generated</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="text-sm font-mono">{op.reputation}%</p>
                    <p className="text-xs text-muted-foreground">reputation</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-mono">{op.uptime}%</p>
                    <p className="text-xs text-muted-foreground">uptime</p>
                  </div>
                  <Badge variant="success">{op.status}</Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
