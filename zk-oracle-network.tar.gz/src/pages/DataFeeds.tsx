import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Search, ArrowUpRight, ArrowDownRight, Shield, Clock, Eye, Users } from 'lucide-react';
import { useState } from 'react';
import { dataFeeds, networkStats, slashingEvents } from '@/lib/data';
import type { DataFeed, ProofStatus, FeedCategory } from '@/lib/types';

function formatValue(value: number, category: FeedCategory): string {
  if (category === 'defi' || value > 1000000) return `$${(value / 1e9).toFixed(2)}B`;
  if (category === 'price') return `$${value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  if (category === 'weather') return `${value.toFixed(1)}°F`;
  if (category === 'randomness') return value.toFixed(6);
  return value.toLocaleString();
}

function timeAgo(ts: number): string {
  const diff = Date.now() - ts;
  if (diff < 60000) return `${Math.floor(diff / 1000)}s ago`;
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
  return `${Math.floor(diff / 86400000)}d ago`;
}

function proofStatusBadge(status: ProofStatus) {
  const map: Record<ProofStatus, { variant: 'success' | 'warning' | 'secondary' | 'destructive'; label: string }> = {
    verified: { variant: 'success', label: 'Verified' },
    pending: { variant: 'warning', label: 'Pending' },
    generating: { variant: 'secondary', label: 'Generating' },
    failed: { variant: 'destructive', label: 'Failed' },
  };
  const s = map[status];
  return <Badge variant={s.variant}>{s.label}</Badge>;
}

function categoryIcon(category: FeedCategory): string {
  const map: Record<FeedCategory, string> = {
    price: 'Price',
    defi: 'DeFi',
    weather: 'Weather',
    sports: 'Sports',
    randomness: 'VRF',
  };
  return map[category];
}

function FeedCard({ feed }: { feed: DataFeed }) {
  const isPositive = feed.change24h >= 0;
  return (
    <Card className="hover:border-primary/50 transition-colors">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CardTitle className="text-lg">{feed.name}</CardTitle>
            <Badge variant="outline" className="text-xs">{categoryIcon(feed.category)}</Badge>
          </div>
          {proofStatusBadge(feed.proofStatus)}
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-end gap-3">
          <span className="text-3xl font-bold tracking-tight">
            {formatValue(feed.value, feed.category)}
          </span>
          <div className={`flex items-center gap-1 text-sm font-medium ${isPositive ? 'text-emerald-400' : 'text-red-400'}`}>
            {isPositive ? <ArrowUpRight className="h-4 w-4" /> : <ArrowDownRight className="h-4 w-4" />}
            {isPositive ? '+' : ''}{feed.changePercent24h.toFixed(2)}%
          </div>
        </div>
        <p className="text-sm text-muted-foreground line-clamp-2">{feed.description}</p>
        <Separator />
        <div className="grid grid-cols-3 gap-2 text-xs text-muted-foreground">
          <div className="flex items-center gap-1">
            <Shield className="h-3 w-3" />
            {feed.sources.length} sources
          </div>
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            {timeAgo(feed.lastUpdated)}
          </div>
          <div className="flex items-center gap-1">
            <Users className="h-3 w-3" />
            {feed.subscribers} subs
          </div>
        </div>
        <div className="flex items-center justify-between pt-1">
          <span className="text-xs text-muted-foreground">
            Method: <span className="text-foreground font-medium">{feed.aggregationMethod.toUpperCase()}</span>
          </span>
          <Button variant="outline" size="sm" className="gap-1 text-xs">
            <Eye className="h-3 w-3" />
            Details
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export default function DataFeeds() {
  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState<string>('all');

  const filtered = dataFeeds.filter((feed) => {
    const matchesSearch = feed.name.toLowerCase().includes(search.toLowerCase()) ||
      feed.description.toLowerCase().includes(search.toLowerCase());
    const matchesTab = activeTab === 'all' || feed.category === activeTab;
    return matchesSearch && matchesTab;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Data Feeds</h1>
          <p className="text-muted-foreground mt-1">
            {networkStats.totalFeeds} verified oracle feeds across {new Set(dataFeeds.map(f => f.category)).size} categories
          </p>
        </div>
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search feeds..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="all">All Feeds</TabsTrigger>
          <TabsTrigger value="price">Price</TabsTrigger>
          <TabsTrigger value="defi">DeFi</TabsTrigger>
          <TabsTrigger value="weather">Weather</TabsTrigger>
          <TabsTrigger value="sports">Sports</TabsTrigger>
          <TabsTrigger value="randomness">VRF</TabsTrigger>
        </TabsList>
        <TabsContent value={activeTab} className="mt-4">
          {filtered.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              No feeds match your search criteria.
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filtered.map((feed) => (
                <FeedCard key={feed.id} feed={feed} />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
