import { useState } from 'react';
import { Search, FileCheck, Clock, AlertCircle, Loader2 } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { proofs, dataFeeds, operators } from '@/lib/data';
import type { Proof } from '@/lib/types';

function timeAgo(ts: number): string {
  const diff = Date.now() - ts;
  const secs = Math.floor(diff / 1000);
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.floor(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  return `${hours}h ago`;
}

function StatusIcon({ status }: { status: Proof['status'] }) {
  switch (status) {
    case 'verified': return <FileCheck className="h-4 w-4 text-emerald-400" />;
    case 'submitted': return <Clock className="h-4 w-4 text-blue-400" />;
    case 'generating': return <Loader2 className="h-4 w-4 text-amber-400 animate-spin" />;
    case 'rejected': return <AlertCircle className="h-4 w-4 text-red-400" />;
  }
}

function ProofRow({ proof }: { proof: Proof }) {
  const feed = dataFeeds.find(f => f.id === proof.feedId);
  const op = operators.find(o => o.id === proof.operatorId);
  const [expanded, setExpanded] = useState(false);

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <StatusIcon status={proof.status} />
            <div>
              <p className="text-sm font-medium">{feed?.name ?? proof.feedId}</p>
              <p className="text-xs text-muted-foreground">
                by {op?.name ?? proof.operatorId} &middot; {proof.type.replace('_', ' ')}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs">{proof.type.replace('_', ' ')}</Badge>
            <Badge
              variant={
                proof.status === 'verified' ? 'success' :
                proof.status === 'rejected' ? 'destructive' :
                proof.status === 'generating' ? 'warning' : 'secondary'
              }
            >
              {proof.status}
            </Badge>
            <span className="text-xs text-muted-foreground">{timeAgo(proof.submittedAt)}</span>
            <Button variant="ghost" size="sm" className="text-xs" onClick={() => setExpanded(!expanded)}>
              {expanded ? 'Hide' : 'Details'}
            </Button>
          </div>
        </div>

        {expanded && (
          <>
            <Separator className="my-3" />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="space-y-2">
                <div>
                  <span className="text-muted-foreground">Proof ID:</span>
                  <p className="font-mono mt-0.5">{proof.id}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">RISC Zero Image ID:</span>
                  <p className="font-mono mt-0.5">{proof.imageId}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Receipt:</span>
                  <p className="font-mono mt-0.5 truncate">{proof.receipt || '—'}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Input Hash:</span>
                  <p className="font-mono mt-0.5">{proof.inputHash}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Output Hash:</span>
                  <p className="font-mono mt-0.5">{proof.outputHash}</p>
                </div>
              </div>
              <div className="space-y-2">
                <div>
                  <span className="text-muted-foreground">Seal:</span>
                  <p className="font-mono mt-0.5 truncate">{proof.seal || '—'}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Journal:</span>
                  <p className="font-mono mt-0.5 truncate max-w-md">{proof.journal || '—'}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Submitted:</span>
                  <p className="mt-0.5">{new Date(proof.submittedAt).toLocaleString()}</p>
                </div>
                {proof.verifiedAt && (
                  <div>
                    <span className="text-muted-foreground">Verified:</span>
                    <p className="mt-0.5">{new Date(proof.verifiedAt).toLocaleString()}</p>
                  </div>
                )}
                {proof.gasUsed && (
                  <div>
                    <span className="text-muted-foreground">Gas Used:</span>
                    <p className="font-mono mt-0.5">{proof.gasUsed.toLocaleString()}</p>
                  </div>
                )}
                {proof.blockNumber && (
                  <div>
                    <span className="text-muted-foreground">Block Number:</span>
                    <p className="font-mono mt-0.5">{proof.blockNumber.toLocaleString()}</p>
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

export default function ProofsPage() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');

  const filtered = proofs
    .filter(p => {
      const feed = dataFeeds.find(f => f.id === p.feedId);
      const op = operators.find(o => o.id === p.operatorId);
      const matchesSearch =
        p.id.toLowerCase().includes(search.toLowerCase()) ||
        (feed?.name ?? '').toLowerCase().includes(search.toLowerCase()) ||
        (op?.name ?? '').toLowerCase().includes(search.toLowerCase());
      const matchesStatus = statusFilter === 'all' || p.status === statusFilter;
      const matchesType = typeFilter === 'all' || p.type === typeFilter;
      return matchesSearch && matchesStatus && matchesType;
    })
    .sort((a, b) => b.submittedAt - a.submittedAt);

  const verifiedCount = proofs.filter(p => p.status === 'verified').length;
  const totalGas = proofs.reduce((sum, p) => sum + (p.gasUsed ?? 0), 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Zero-Knowledge Proofs</h1>
        <p className="text-muted-foreground mt-1">
          RISC Zero proof submissions, verifications, and attestations
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Verified Proofs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{verifiedCount} / {proofs.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Gas Used</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalGas.toLocaleString()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Proof Types</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{new Set(proofs.map(p => p.type)).size}</div>
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by proof ID, feed, or operator..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      <div className="flex flex-wrap gap-4">
        <div>
          <p className="text-xs text-muted-foreground mb-2">Status</p>
          <div className="flex gap-1">
            {(['all', 'verified', 'submitted', 'generating', 'rejected'] as const).map(s => (
              <Button
                key={s}
                variant={statusFilter === s ? 'secondary' : 'outline'}
                size="sm"
                onClick={() => setStatusFilter(s)}
                className="capitalize"
              >
                {s}
              </Button>
            ))}
          </div>
        </div>
        <div>
          <p className="text-xs text-muted-foreground mb-2">Type</p>
          <div className="flex gap-1">
            {(['all', 'data_fetch', 'tls_attestation', 'aggregation', 'computation'] as const).map(t => (
              <Button
                key={t}
                variant={typeFilter === t ? 'secondary' : 'outline'}
                size="sm"
                onClick={() => setTypeFilter(t)}
                className="capitalize"
              >
                {t === 'all' ? 'All' : t.replace('_', ' ')}
              </Button>
            ))}
          </div>
        </div>
      </div>

      <Separator />

      <div className="space-y-3">
        {filtered.map(proof => (
          <ProofRow key={proof.id} proof={proof} />
        ))}
      </div>

      {filtered.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground">No proofs match your criteria.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
