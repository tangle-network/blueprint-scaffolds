import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from '@/components/Layout';
import DashboardPage from '@/pages/DashboardPage';
import FeedsPage from '@/pages/FeedsPage';
import OperatorsPage from '@/pages/OperatorsPage';
import ProofsPage from '@/pages/ProofsPage';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<DashboardPage />} />
          <Route path="/feeds" element={<FeedsPage />} />
          <Route path="/operators" element={<OperatorsPage />} />
          <Route path="/proofs" element={<ProofsPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
