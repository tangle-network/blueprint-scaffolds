/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        zk: { 50: '#eef2ff', 100: '#e0e7ff', 400: '#818cf8', 500: '#6366f1', 600: '#4f46e5', 700: '#4338ca', 900: '#312e81' },
        oracle: { 400: '#34d399', 500: '#10b981', 600: '#059669' },
        danger: { 400: '#f87171', 500: '#ef4444', 600: '#dc2626' },
      },
    },
  },
  plugins: [],
};
