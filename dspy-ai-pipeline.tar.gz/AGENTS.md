# AGENTS.md

## Goal

Build an optimized AI pipeline using DSPy for automated prompt engineering. Multi-step reasoning, optimizer integration, evaluation harness.

## Stack

- Family: `dspy-pipeline-py`
- Layers: `database:sqlite`, `sdk:none`, `auth:none`, `payments:none`, `queue:none`

## Entry Points

- `main.py`
- `pipeline.json`

## Commands

- `python3 main.py`

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
