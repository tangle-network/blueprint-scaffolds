import { useState } from "react";
import { Routes, Route, NavLink } from "react-router-dom";
import { GitBranch, Play, FileCode, Settings2, Activity } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { TooltipProvider } from "@/components/ui/tooltip";
import PipelineVisualizer from "@/components/PipelineVisualizer";
import Playground from "@/components/Playground";
import SignatureEditor from "@/components/SignatureEditor";
import OptimizationPanel from "@/components/OptimizationPanel";

const navItems = [
  { to: "/", icon: GitBranch, label: "Pipeline" },
  { to: "/playground", icon: Play, label: "Playground" },
  { to: "/signatures", icon: FileCode, label: "Signatures" },
  { to: "/optimization", icon: Settings2, label: "Optimization" },
];

export default function App() {
  const [darkMode, setDarkMode] = useState(false);

  return (
    <TooltipProvider>
      <div className={darkMode ? "dark" : ""}>
        <div className="min-h-screen bg-background text-foreground flex">
          <nav className="w-16 border-r bg-card flex flex-col items-center py-4 gap-2 shrink-0">
            <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center mb-4">
              <Activity className="w-5 h-5 text-primary-foreground" />
            </div>
            <Separator className="w-8 mb-2" />
            {navItems.map((item) => (
              <NavLink key={item.to} to={item.to} end={item.to === "/"}>
                {({ isActive }) => (
                  <Button
                    variant={isActive ? "secondary" : "ghost"}
                    size="icon"
                    className="w-10 h-10"
                    title={item.label}
                  >
                    <item.icon className="w-5 h-5" />
                  </Button>
                )}
              </NavLink>
            ))}
            <div className="flex-1" />
            <Button
              variant="ghost"
              size="icon"
              className="w-10 h-10"
              onClick={() => setDarkMode(!darkMode)}
              title="Toggle theme"
            >
              {darkMode ? "☀️" : "🌙"}
            </Button>
          </nav>

          <main className="flex-1 overflow-auto">
            <Routes>
              <Route path="/" element={<PipelineVisualizer />} />
              <Route path="/playground" element={<Playground />} />
              <Route path="/signatures" element={<SignatureEditor />} />
              <Route path="/optimization" element={<OptimizationPanel />} />
            </Routes>
          </main>
        </div>
      </div>
    </TooltipProvider>
  );
}
