import { useState } from 'react'
import Header from './components/Header'
import PipelineVisualization from './components/PipelineVisualization'
import Playground from './components/Playground'
import ConfigPanel from './components/ConfigPanel'
import ResultsPanel from './components/ResultsPanel'
import OptimizationPanel from './components/OptimizationPanel'

export default function App() {
  const [tab, setTab] = useState<'pipeline' | 'playground' | 'config'>('pipeline')

  return (
    <div className="min-h-screen bg-surface-900 text-surface-100 flex flex-col">
      <Header tab={tab} onTabChange={setTab} />
      <main className="flex-1 overflow-hidden">
        {tab === 'pipeline' && (
          <div className="h-full flex flex-col lg:flex-row">
            <div className="flex-1 overflow-auto">
              <PipelineVisualization />
            </div>
            <div className="w-full lg:w-96 border-t lg:border-t-0 lg:border-l border-surface-700 overflow-auto">
              <ResultsPanel />
            </div>
          </div>
        )}
        {tab === 'playground' && <Playground />}
        {tab === 'config' && <ConfigPanel />}
      </main>
      <OptimizationPanel />
    </div>
  )
}
