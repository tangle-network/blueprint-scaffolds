import { useMemo, useState } from "react";
import {
  ArrowRight,
  BrainCircuit,
  CheckCheck,
  Database,
  FileSearch,
  Gauge,
  Layers3,
  Sparkles
} from "lucide-react";
import {
  backends,
  optimizationTracks,
  pipelineStages,
  scenarios,
  vectorStores
} from "./data";
import type { BackendId, PipelineStageId, VectorStoreId } from "./types";
import "./styles.css";

const stageIcons = {
  retrieve: FileSearch,
  decompose: Layers3,
  synthesize: BrainCircuit,
  verify: CheckCheck
} satisfies Record<PipelineStageId, typeof FileSearch>;

function App() {
  const [selectedStage, setSelectedStage] = useState<PipelineStageId>("retrieve");
  const [selectedScenario, setSelectedScenario] = useState(scenarios[0].id);
  const [selectedBackend, setSelectedBackend] = useState<BackendId>("openai");
  const [selectedVectorStore, setSelectedVectorStore] =
    useState<VectorStoreId>("pinecone");

  const scenario = useMemo(
    () => scenarios.find((item) => item.id === selectedScenario) ?? scenarios[0],
    [selectedScenario]
  );

  const stage = useMemo(
    () => pipelineStages.find((item) => item.id === selectedStage) ?? pipelineStages[0],
    [selectedStage]
  );

  const backend = useMemo(
    () => backends.find((item) => item.id === selectedBackend) ?? backends[0],
    [selectedBackend]
  );

  const vectorStore = useMemo(
    () =>
      vectorStores.find((item) => item.id === selectedVectorStore) ?? vectorStores[0],
    [selectedVectorStore]
  );

  const systemScore = Math.round(
    backend.quality * 0.45 + vectorStore.recall * 0.2 + 35
  );
  const compileWindow = `${Math.round(backend.latency / 8)} training traces`;
  const expectedLatency = `${backend.latency + 260} ms`;

  return (
    <div className="app-shell">
      <header className="hero">
        <div className="hero__copy">
          <div className="eyebrow">
            <Sparkles size={16} />
            Optimized prompt engineering with DSPy
          </div>
          <h1>Pipeline Studio for retrieval, reasoning, synthesis, and verification.</h1>
          <p>
            Signature-based modules compile prompts from traces, tune few-shot
            demonstrations, and expose each pipeline stage for inspection.
          </p>
          <div className="hero__stats">
            <div>
              <span>Compiled Quality</span>
              <strong>{systemScore}%</strong>
            </div>
            <div>
              <span>Expected Latency</span>
              <strong>{expectedLatency}</strong>
            </div>
            <div>
              <span>Tuning Window</span>
              <strong>{compileWindow}</strong>
            </div>
          </div>
        </div>

        <div className="hero__panel glass">
          <div className="panel__header">
            <Gauge size={18} />
            <span>Compiler Controls</span>
          </div>

          <label>
            Scenario
            <select
              value={selectedScenario}
              onChange={(event) => setSelectedScenario(event.target.value)}
            >
              {scenarios.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name}
                </option>
              ))}
            </select>
          </label>

          <label>
            LLM Backend
            <select
              value={selectedBackend}
              onChange={(event) => setSelectedBackend(event.target.value as BackendId)}
            >
              {backends.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name} · {item.model}
                </option>
              ))}
            </select>
          </label>

          <label>
            Vector DB
            <select
              value={selectedVectorStore}
              onChange={(event) =>
                setSelectedVectorStore(event.target.value as VectorStoreId)
              }
            >
              {vectorStores.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name}
                </option>
              ))}
            </select>
          </label>

          <div className="mini-grid">
            <article>
              <Database size={16} />
              <strong>{vectorStore.name}</strong>
              <span>{vectorStore.indexing}</span>
            </article>
            <article>
              <BrainCircuit size={16} />
              <strong>{backend.name}</strong>
              <span>{backend.notes}</span>
            </article>
          </div>
        </div>
      </header>

      <main className="layout">
        <section className="glass section">
          <div className="section__heading">
            <h2>Pipeline Stages</h2>
            <p>Inspect the typed module contract, generated prompt, reasoning path, and optimizer behavior.</p>
          </div>

          <div className="stage-tabs">
            {pipelineStages.map((item) => {
              const Icon = stageIcons[item.id];
              const active = item.id === selectedStage;

              return (
                <button
                  key={item.id}
                  className={active ? "stage-tab stage-tab--active" : "stage-tab"}
                  onClick={() => setSelectedStage(item.id)}
                  type="button"
                >
                  <Icon size={18} />
                  <span>{item.title}</span>
                </button>
              );
            })}
          </div>

          <div className="stage-detail">
            <div className="stage-detail__main">
              <p className="stage-summary">{stage.summary}</p>

              <article className="code-card">
                <span>Signature</span>
                <code>{stage.signature}</code>
              </article>

              <article className="prompt-card">
                <div className="card-title">
                  <Sparkles size={16} />
                  Generated prompt
                </div>
                <p>{stage.generatedPrompt}</p>
              </article>

              <article className="reasoning-card">
                <div className="card-title">
                  <BrainCircuit size={16} />
                  Chain-of-thought plan
                </div>
                <ol>
                  {stage.chainOfThought.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ol>
              </article>
            </div>

            <aside className="stage-detail__side">
              <article className="optimizer-card">
                <div className="card-title">
                  <Gauge size={16} />
                  Optimization strategy
                </div>
                <p>{stage.optimization}</p>
              </article>

              <article className="metrics-card">
                <div className="card-title">
                  <CheckCheck size={16} />
                  Stage metrics
                </div>
                <div className="metric-list">
                  {stage.metrics.map((metric) => (
                    <div key={metric.label} className="metric-list__item">
                      <span>{metric.label}</span>
                      <strong>{metric.value}</strong>
                    </div>
                  ))}
                </div>
              </article>
            </aside>
          </div>
        </section>

        <section className="glass section section--split">
          <div>
            <div className="section__heading">
              <h2>Playground</h2>
              <p>Switch scenarios to see how retrieval context, decomposition depth, and verification rules change the compiled program.</p>
            </div>

            <article className="scenario-card">
              <span className="scenario-card__label">Question</span>
              <h3>{scenario.question}</h3>
              <div className="scenario-card__corpus">
                {scenario.corpus.map((item) => (
                  <span key={item}>{item}</span>
                ))}
              </div>
            </article>

            <div className="flow-row">
              {pipelineStages.map((item, index) => (
                <div key={item.id} className="flow-row__item">
                  <strong>{item.title}</strong>
                  <span>{item.summary}</span>
                  {index < pipelineStages.length - 1 ? <ArrowRight size={18} /> : null}
                </div>
              ))}
            </div>
          </div>

          <div>
            <div className="section__heading">
              <h2>Compiler Wins</h2>
              <p>How DSPy improves the program before runtime.</p>
            </div>
            <div className="tracks">
              {optimizationTracks.map((track) => (
                <article key={track.label} className="track-card">
                  <strong>{track.label}</strong>
                  <p>{track.before}</p>
                  <p>{track.after}</p>
                  <span>{track.impact}</span>
                </article>
              ))}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;
