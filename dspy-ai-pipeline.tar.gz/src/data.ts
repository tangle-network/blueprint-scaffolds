import type {
  BackendOption,
  OptimizationTrack,
  PipelineStage,
  Scenario,
  VectorStoreOption
} from "./types";

export const scenarios: Scenario[] = [
  {
    id: "trust-ai",
    name: "Enterprise RAG Governance",
    question:
      "How should a fintech team tune a DSPy pipeline to answer compliance questions with citations and low hallucination risk?",
    corpus: [
      "Compliance handbook with policy sections and change logs.",
      "Incident postmortems describing false-positive and false-negative answers.",
      "Risk committee notes on acceptable latency and auditability thresholds."
    ]
  },
  {
    id: "biomed",
    name: "Biomedical Literature QA",
    question:
      "What pipeline structure best extracts evidence from studies, decomposes claims, and verifies dosage guidance?",
    corpus: [
      "Peer-reviewed papers with abstracts, methods, and dosage tables.",
      "Clinical recommendations from a hospital knowledge base.",
      "Curated contradiction examples for claim verification."
    ]
  },
  {
    id: "support",
    name: "Support Deflection Assistant",
    question:
      "How can an AI assistant retrieve product docs, break down troubleshooting steps, and produce grounded support responses?",
    corpus: [
      "Troubleshooting runbooks and feature release notes.",
      "Past support tickets tagged with resolution quality.",
      "Verification checklist for unsafe or outdated advice."
    ]
  }
];

export const backends: BackendOption[] = [
  {
    id: "openai",
    name: "OpenAI",
    model: "gpt-4.1",
    latency: 820,
    quality: 95,
    notes: "Best balanced for synthesis quality and compiler-guided prompt rewrites."
  },
  {
    id: "anthropic",
    name: "Anthropic",
    model: "claude-3-7-sonnet",
    latency: 910,
    quality: 93,
    notes: "Strong decomposition and verifier reasoning with robust long-context behavior."
  },
  {
    id: "local",
    name: "Local OSS",
    model: "Llama 3.1 70B",
    latency: 1320,
    quality: 84,
    notes: "Useful for cost-sensitive or private deployments with smaller compiled traces."
  }
];

export const vectorStores: VectorStoreOption[] = [
  {
    id: "pinecone",
    name: "Pinecone",
    indexing: "Serverless hybrid search",
    recall: 92,
    notes: "Fast namespace isolation and strong operational simplicity."
  },
  {
    id: "weaviate",
    name: "Weaviate",
    indexing: "Hybrid search + metadata filters",
    recall: 89,
    notes: "Flexible schemas, rich filtering, and self-hosting options."
  }
];

export const pipelineStages: PipelineStage[] = [
  {
    id: "retrieve",
    title: "1. Document Retrieval",
    summary:
      "A typed retriever signature selects evidence chunks and structured metadata before any answering begins.",
    signature:
      "RetrieveDocs(question, domain_context) -> passages[], scores[], citation_ids[]",
    generatedPrompt:
      "Find the smallest set of passages that jointly answer the question. Prefer high-recall evidence, preserve citation ids, and return contradictory passages when confidence is low.",
    chainOfThought: [
      "Normalize the question into retrieval intents and required evidence types.",
      "Query Pinecone or Weaviate with hybrid semantic + keyword search.",
      "Re-rank passages using compiled examples that maximize citation recall."
    ],
    optimization:
      "Bootstrap few-shot optimization promotes examples with complete citation coverage and low redundancy.",
    metrics: [
      { label: "Top-k Recall", value: "92%" },
      { label: "Median Latency", value: "180 ms" },
      { label: "Evidence Kept", value: "6 chunks" }
    ]
  },
  {
    id: "decompose",
    title: "2. Question Decomposition",
    summary:
      "DSPy emits sub-questions with explicit dependencies so complex prompts become traceable modules.",
    signature:
      "DecomposeQuestion(question, passages) -> sub_questions[], dependency_graph",
    generatedPrompt:
      "Break the task into minimal answerable sub-questions. Map each sub-question to supporting passages and identify any missing evidence before reasoning further.",
    chainOfThought: [
      "Identify hidden assumptions and claim boundaries inside the user query.",
      "Generate dependent sub-questions covering policy, evidence, and exceptions.",
      "Route unanswered branches back to retrieval instead of guessing."
    ],
    optimization:
      "Compile-time tuning penalizes decompositions that create unsupported branches or duplicate evidence requests.",
    metrics: [
      { label: "Branch Accuracy", value: "90%" },
      { label: "Unsupported Claims", value: "-41%" },
      { label: "Avg. Sub-questions", value: "4.2" }
    ]
  },
  {
    id: "synthesize",
    title: "3. Answer Synthesis",
    summary:
      "The synthesis module combines retrieved evidence and sub-answers into a concise response with grounded reasoning.",
    signature:
      "SynthesizeAnswer(question, sub_answers, citations) -> answer, rationale, confidence",
    generatedPrompt:
      "Compose a direct answer using only cited evidence. Summarize rationale, surface uncertainty, and preserve the strongest supporting references for each claim.",
    chainOfThought: [
      "Resolve sub-question outputs into a unified answer plan.",
      "Draft the final answer while aligning every claim to at least one citation.",
      "Estimate confidence from evidence agreement and verifier readiness."
    ],
    optimization:
      "Automatic prompt generation selects concise, citation-heavy exemplars to improve faithfulness without adding latency.",
    metrics: [
      { label: "Answer Faithfulness", value: "96%" },
      { label: "Avg. Tokens", value: "612" },
      { label: "User Rating", value: "4.8/5" }
    ]
  },
  {
    id: "verify",
    title: "4. Fact Verification",
    summary:
      "A verifier signature checks factual support, contradiction risk, and missing citations before the answer is returned.",
    signature:
      "VerifyFacts(answer, passages, citations) -> verdict, edits[], risk_flags[]",
    generatedPrompt:
      "Inspect the answer claim by claim. Mark unsupported statements, contradictory evidence, stale references, and recommend precise edits before approval.",
    chainOfThought: [
      "Split the answer into atomic claims and attach their evidence spans.",
      "Search for contradictions or stale policy statements in the retrieved set.",
      "Patch or reject the answer when support is incomplete."
    ],
    optimization:
      "Few-shot verifier traces are selected for high contradiction sensitivity and calibrated confidence thresholds.",
    metrics: [
      { label: "Hallucination Rate", value: "1.9%" },
      { label: "Verifier Precision", value: "94%" },
      { label: "Escalation Rate", value: "7%" }
    ]
  }
];

export const optimizationTracks: OptimizationTrack[] = [
  {
    label: "Prompt Compiler",
    before: "Manual system prompts with inconsistent citation instructions.",
    after: "Generated prompts tuned from traces and evaluator feedback.",
    impact: "19% gain in grounded answer quality."
  },
  {
    label: "Bootstrap Few-Shot",
    before: "Hand-picked demos that overfit easy examples.",
    after: "Teacher-generated demonstrations filtered by verifier success.",
    impact: "31% drop in unsupported claims."
  },
  {
    label: "Chain-of-Thought",
    before: "Opaque single-pass answers.",
    after: "Structured reasoning hidden behind typed stage outputs.",
    impact: "Higher debuggability with controlled latency."
  }
];
