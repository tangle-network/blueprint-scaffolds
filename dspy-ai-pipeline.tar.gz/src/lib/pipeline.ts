import type { PipelineResult, Document, SubQuestion, VerificationResult } from './types'

const sampleDocuments: Document[] = [
  {
    id: 'doc-1',
    content: 'DSPy is a framework for algorithmically optimizing language model prompts and weights. It provides signature-based programming where developers define input-output specifications rather than hand-crafting prompts.',
    source: 'DSPy Documentation',
    score: 0.94,
    metadata: { section: 'Introduction', version: '2.5' },
  },
  {
    id: 'doc-2',
    content: 'The BootstrapFewShot optimizer automatically generates effective few-shot examples by tracing successful program executions. It uses a teacher model to create demonstrations that are then used to compile the student program.',
    source: 'DSPy Optimization Guide',
    score: 0.91,
    metadata: { section: 'Optimizers', version: '2.5' },
  },
  {
    id: 'doc-3',
    content: 'Chain of Thought in DSPy is implemented as a module wrapper that appends "Let\'s think step by step" reasoning before the output. This can be combined with any signature to encourage structured reasoning.',
    source: 'DSPy Modules Reference',
    score: 0.88,
    metadata: { section: 'Modules', version: '2.5' },
  },
  {
    id: 'doc-4',
    content: 'Vector databases like Pinecone and Weaviate integrate with DSPy retrievers. Documents are embedded using sentence transformers and indexed for semantic search with cosine similarity.',
    source: 'DSPy Retrievers Guide',
    score: 0.85,
    metadata: { section: 'Retrieval', version: '2.5' },
  },
  {
    id: 'doc-5',
    content: 'MIPROv2 is a joint optimizer that proposes instructions and few-shot examples for each step. It uses Bayesian optimization over the instruction space combined with demonstration bootstrapping.',
    source: 'DSPy Advanced Optimization',
    score: 0.82,
    metadata: { section: 'Advanced', version: '2.5' },
  },
]

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

function generateSubQuestions(query: string): SubQuestion[] {
  const base: SubQuestion[] = [
    {
      id: 'sq-1',
      question: `What is the core architecture of ${query.includes('DSPy') ? 'DSPy' : 'the system'}?`,
      answer: 'The core architecture uses signature-based programming where modules define input-output contracts. Each module can be a Predict, ChainOfThought, or ReAct wrapper around a language model call.',
      confidence: 0.92,
      sources: ['doc-1', 'doc-3'],
    },
    {
      id: 'sq-2',
      question: 'How does the optimization process work?',
      answer: 'BootstrapFewShot traces successful executions of a teacher model to create few-shot demonstrations. These demos are then used to compile the student program with optimized prompts.',
      confidence: 0.87,
      sources: ['doc-2', 'doc-5'],
    },
    {
      id: 'sq-3',
      question: 'What integrations are available for retrieval?',
      answer: 'DSPy integrates with Pinecone, Weaviate, and ChromaDB for vector retrieval. Documents are embedded using sentence transformers and indexed for semantic similarity search.',
      confidence: 0.84,
      sources: ['doc-4'],
    },
  ]
  return base
}

function generateVerifications(answer: string): VerificationResult[] {
  return [
    {
      claim: 'DSPy uses signature-based programming for defining module contracts',
      verdict: 'supported',
      evidence: 'Documented in DSPy Introduction: "DSPy provides signature-based programming where developers define input-output specifications"',
      confidence: 0.95,
    },
    {
      claim: 'BootstrapFewShot uses a teacher-student paradigm',
      verdict: 'supported',
      evidence: 'From Optimization Guide: "It uses a teacher model to create demonstrations that are then used to compile the student program"',
      confidence: 0.93,
    },
    {
      claim: 'The framework supports multiple vector database backends',
      verdict: 'supported',
      evidence: 'Retrievers Guide confirms: "Vector databases like Pinecone and Weaviate integrate with DSPy retrievers"',
      confidence: 0.91,
    },
  ]
}

export async function runPipeline(query: string, onStage: (stage: string) => void): Promise<PipelineResult> {
  const startTime = Date.now()

  onStage('retrieval')
  await delay(800 + Math.random() * 600)
  const documents = sampleDocuments.filter(() => Math.random() > 0.2)

  onStage('decomposition')
  await delay(600 + Math.random() * 500)
  const subQuestions = generateSubQuestions(query)

  onStage('synthesis')
  await delay(900 + Math.random() * 700)
  const answer = `Based on the retrieved documents and analysis of ${subQuestions.length} sub-questions, DSPy is a framework for algorithmically optimizing language model (LM) prompts and weights. It uses **signature-based programming** where developers define input-output specifications rather than manually crafting prompts.\n\nKey components include:\n1. **Modules** (Predict, ChainOfThought, ReAct) — composable building blocks\n2. **Optimizers** (BootstrapFewShot, MIPROv2) — automatically tune prompts and demos\n3. **Retrievers** — integrate with Pinecone/Weaviate for RAG pipelines\n\nThe compilation process uses a teacher model to bootstrap demonstrations, then optimizes the student program with these examples using Bayesian optimization over the instruction space.`

  onStage('verification')
  await delay(500 + Math.random() * 400)
  const verifications = generateVerifications(answer)

  const totalTokens = documents.reduce((acc, d) => acc + d.content.split(' ').length, 0) * 4
    + subQuestions.reduce((acc, sq) => acc + sq.answer.split(' ').length, 0) * 4
    + answer.split(' ').length * 4

  return {
    query,
    answer,
    documents,
    subQuestions,
    verifications,
    totalTokens,
    latencyMs: Date.now() - startTime,
    confidence: 0.91,
  }
}

export async function runOptimization(onProgress: (p: number) => void): Promise<void> {
  const steps = 20
  for (let i = 0; i <= steps; i++) {
    await delay(200 + Math.random() * 300)
    onProgress((i / steps) * 100)
  }
}
