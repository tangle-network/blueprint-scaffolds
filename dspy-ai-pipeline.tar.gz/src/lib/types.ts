export interface PipelineStage {
  id: string;
  name: string;
  type: "retrieval" | "decomposition" | "synthesis" | "verification";
  status: "idle" | "running" | "completed" | "error";
  output?: string;
  duration?: number;
}

export interface PipelineRun {
  id: string;
  stages: PipelineStage[];
  input: string;
  output?: string;
  status: "idle" | "running" | "completed" | "error";
  startedAt?: string;
  completedAt?: string;
}

export interface Signature {
  id: string;
  name: string;
  description: string;
  inputs: SignatureField[];
  outputs: SignatureField[];
  instruction?: string;
  createdAt: string;
  updatedAt: string;
}

export interface SignatureField {
  name: string;
  type: "string" | "number" | "boolean" | "list";
  description?: string;
  prefix?: string;
}

export interface OptimizationResult {
  id: string;
  type: "bootstrap" | "compile";
  status: "running" | "completed" | "error";
  score?: number;
  previousScore?: number;
  improvement?: number;
  examples?: FewShotExample[];
  compiledPrompt?: string;
  duration?: number;
  completedAt?: string;
}

export interface FewShotExample {
  input: Record<string, unknown>;
  output: Record<string, unknown>;
  score: number;
}

export interface Metrics {
  totalRuns: number;
  averageScore: number;
  bestScore: number;
  optimizationHistory: { timestamp: string; score: number; type: string }[];
  stageMetrics: {
    name: string;
    avgDuration: number;
    successRate: number;
    callCount: number;
  }[];
}

export interface RetrievalResult {
  id: string;
  content: string;
  score: number;
  metadata?: Record<string, unknown>;
}

export interface PlaygroundRequest {
  query: string;
  signatureId?: string;
  useChainOfThought: boolean;
  temperature?: number;
  maxTokens?: number;
}

export interface PlaygroundResponse {
  answer: string;
  reasoning: string[];
  confidence: number;
  sources?: RetrievalResult[];
  stageOutputs: { stage: string; output: string }[];
}

const API_BASE = "/api";

async function fetchAPI<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) throw new Error(`API Error: ${res.status} ${res.statusText}`);
  return res.json();
}

export const api = {
  pipeline: {
    run: (input: string) => fetchAPI<PipelineRun>("/pipeline/run", { method: "POST", body: JSON.stringify({ input }) }),
    runStage: (name: string, input: Record<string, unknown>) =>
      fetchAPI<PipelineStage>(`/pipeline/stage/${name}`, { method: "POST", body: JSON.stringify(input) }),
  },
  signatures: {
    list: () => fetchAPI<Signature[]>("/signatures"),
    create: (sig: Omit<Signature, "id" | "createdAt" | "updatedAt">) =>
      fetchAPI<Signature>("/signatures", { method: "POST", body: JSON.stringify(sig) }),
    update: (id: string, sig: Partial<Signature>) =>
      fetchAPI<Signature>(`/signatures/${id}`, { method: "PUT", body: JSON.stringify(sig) }),
    delete: (id: string) => fetchAPI<void>(`/signatures/${id}`, { method: "DELETE" }),
  },
  optimize: {
    bootstrap: (params: { signatureId: string; numExamples: number }) =>
      fetchAPI<OptimizationResult>("/optimize/bootstrap", { method: "POST", body: JSON.stringify(params) }),
    compile: (params: { signatureId: string; teacherModel: string }) =>
      fetchAPI<OptimizationResult>("/optimize/compile", { method: "POST", body: JSON.stringify(params) }),
  },
  metrics: {
    get: () => fetchAPI<Metrics>("/metrics"),
  },
  retrieval: {
    query: (query: string, topK?: number) =>
      fetchAPI<RetrievalResult[]>("/retrieval/query", { method: "POST", body: JSON.stringify({ query, topK }) }),
    index: (documents: { content: string; metadata?: Record<string, unknown> }[]) =>
      fetchAPI<{ indexed: number }>("/retrieval/index", { method: "POST", body: JSON.stringify({ documents }) }),
  },
  playground: {
    run: (req: PlaygroundRequest) =>
      fetchAPI<PlaygroundResponse>("/pipeline/run", { method: "POST", body: JSON.stringify(req) }),
  },
};
