export type PipelineStageId =
  | "retrieve"
  | "decompose"
  | "synthesize"
  | "verify";

export type BackendId = "openai" | "anthropic" | "local";

export type VectorStoreId = "pinecone" | "weaviate";

export interface StageMetric {
  label: string;
  value: string;
}

export interface PipelineStage {
  id: PipelineStageId;
  title: string;
  summary: string;
  signature: string;
  generatedPrompt: string;
  chainOfThought: string[];
  optimization: string;
  metrics: StageMetric[];
}

export interface BackendOption {
  id: BackendId;
  name: string;
  model: string;
  latency: number;
  quality: number;
  notes: string;
}

export interface VectorStoreOption {
  id: VectorStoreId;
  name: string;
  indexing: string;
  recall: number;
  notes: string;
}

export interface Scenario {
  id: string;
  name: string;
  question: string;
  corpus: string[];
}

export interface OptimizationTrack {
  label: string;
  before: string;
  after: string;
  impact: string;
}
