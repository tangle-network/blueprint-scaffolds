export type PipelineStage = 'idle' | 'retrieval' | 'decomposition' | 'synthesis' | 'verification' | 'complete' | 'error'

export interface Document {
  id: string
  content: string
  source: string
  score: number
  metadata: Record<string, string>
}

export interface SubQuestion {
  id: string
  question: string
  answer: string
  confidence: number
  sources: string[]
}

export interface VerificationResult {
  claim: string
  verdict: 'supported' | 'refuted' | 'unverifiable'
  evidence: string
  confidence: number
}

export interface PipelineResult {
  query: string
  answer: string
  documents: Document[]
  subQuestions: SubQuestion[]
  verifications: VerificationResult[]
  totalTokens: number
  latencyMs: number
  confidence: number
}

export interface SignatureDef {
  name: string
  inputs: string[]
  outputs: string[]
  instruction: string
}

export interface ModuleConfig {
  name: string
  type: 'Predict' | 'ChainOfThought' | 'ReAct' | 'ProgramOfThought' | 'MultiChainComparison'
  signature: SignatureDef
  demos: number
}

export interface LLMBackend {
  id: string
  name: string
  provider: 'openai' | 'anthropic' | 'cohere' | 'local'
  model: string
  apiKey: string
  maxTokens: number
  temperature: number
}

export interface VectorDBConfig {
  provider: 'pinecone' | 'weaviate' | 'chroma'
  indexName: string
  apiKey: string
  environment: string
  dimension: number
  metric: 'cosine' | 'euclidean' | 'dotproduct'
}

export interface OptimizationConfig {
  metric: string
  maxBootstrappedDemos: number
  maxLabeledDemos: number
  maxRounds: number
  numCandidates: number
  teacherModel: string
}

export interface AppState {
  stage: PipelineStage
  query: string
  result: PipelineResult | null
  error: string | null
  llmBackends: LLMBackend[]
  activeBackend: string
  vectorDB: VectorDBConfig
  modules: ModuleConfig[]
  optimizationConfig: OptimizationConfig
  isOptimizing: boolean
  optimizationProgress: number
  playgroundHistory: Array<{ query: string; result: PipelineResult }>
}

export type AppAction =
  | { type: 'SET_STAGE'; payload: PipelineStage }
  | { type: 'SET_QUERY'; payload: string }
  | { type: 'SET_RESULT'; payload: PipelineResult }
  | { type: 'SET_ERROR'; payload: string }
  | { type: 'ADD_BACKEND'; payload: LLMBackend }
  | { type: 'SET_ACTIVE_BACKEND'; payload: string }
  | { type: 'SET_VECTOR_DB'; payload: Partial<VectorDBConfig> }
  | { type: 'SET_MODULES'; payload: ModuleConfig[] }
  | { type: 'SET_OPTIMIZATION_CONFIG'; payload: Partial<OptimizationConfig> }
  | { type: 'SET_OPTIMIZING'; payload: boolean }
  | { type: 'SET_OPTIMIZATION_PROGRESS'; payload: number }
  | { type: 'ADD_PLAYGROUND_HISTORY'; payload: { query: string; result: PipelineResult } }
  | { type: 'RESET_PIPELINE' }
