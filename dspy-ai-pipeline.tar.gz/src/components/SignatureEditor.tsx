import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Plus,
  Trash2,
  FileCode,
  Eye,
  Pencil,
  ArrowRight,
  Copy,
} from "lucide-react";
import type { Signature, SignatureField } from "@/lib/types";

const DEFAULT_SIGNATURES: Signature[] = [
  {
    id: "sig-1",
    name: "QuestionAnswer",
    description: "Basic question answering signature",
    inputs: [
      { name: "question", type: "string", description: "The question to answer", prefix: "Question:" },
    ],
    outputs: [
      { name: "answer", type: "string", description: "The answer to the question", prefix: "Answer:" },
    ],
    instruction: "Given the question, provide a factual and concise answer.",
    createdAt: "2025-01-15T10:00:00Z",
    updatedAt: "2025-01-15T10:00:00Z",
  },
  {
    id: "sig-2",
    name: "RAGRetrieval",
    description: "Retrieval-augmented generation signature",
    inputs: [
      { name: "context", type: "string", description: "Retrieved context passages", prefix: "Context:" },
      { name: "question", type: "string", description: "The user question", prefix: "Question:" },
    ],
    outputs: [
      { name: "answer", type: "string", description: "Grounded answer", prefix: "Answer:" },
    ],
    instruction: "Answer the question using only the provided context. If the context does not contain enough information, say so.",
    createdAt: "2025-01-16T14:30:00Z",
    updatedAt: "2025-01-16T14:30:00Z",
  },
  {
    id: "sig-3",
    name: "ChainOfThought",
    description: "Step-by-step reasoning with answer",
    inputs: [
      { name: "question", type: "string", description: "The question to reason about", prefix: "Question:" },
    ],
    outputs: [
      { name: "reasoning", type: "string", description: "Step-by-step reasoning", prefix: "Reasoning:" },
      { name: "answer", type: "string", description: "Final answer", prefix: "Answer:" },
    ],
    instruction: "Think step by step to arrive at the correct answer. Show your reasoning process clearly.",
    createdAt: "2025-01-17T09:00:00Z",
    updatedAt: "2025-01-17T09:00:00Z",
  },
  {
    id: "sig-4",
    name: "FactVerification",
    description: "Verify factual claims against sources",
    inputs: [
      { name: "claim", type: "string", description: "The claim to verify", prefix: "Claim:" },
      { name: "evidence", type: "string", description: "Supporting evidence", prefix: "Evidence:" },
    ],
    outputs: [
      { name: "verdict", type: "string", description: "TRUE, FALSE, or UNCERTAIN", prefix: "Verdict:" },
      { name: "explanation", type: "string", description: "Explanation of the verdict", prefix: "Explanation:" },
    ],
    instruction: "Verify the claim against the provided evidence. Classify as TRUE, FALSE, or UNCERTAIN with explanation.",
    createdAt: "2025-01-18T11:00:00Z",
    updatedAt: "2025-01-18T11:00:00Z",
  },
];

const FIELD_TYPES: SignatureField["type"][] = ["string", "number", "boolean", "list"];

function emptyField(): SignatureField {
  return { name: "", type: "string", description: "", prefix: "" };
}

function SignaturePreview({ signature }: { signature: Signature }) {
  return (
    <Card className="border-dashed">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-mono">{signature.name}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {signature.instruction && (
          <div className="p-2 rounded bg-muted text-xs font-mono italic">
            {signature.instruction}
          </div>
        )}
        <div>
          <div className="text-xs font-medium text-muted-foreground mb-1">Inputs</div>
          {signature.inputs.map((f, i) => (
            <div key={i} className="flex items-center gap-2 text-xs font-mono py-0.5">
              <Badge variant="outline" className="text-[10px] h-4 px-1">{f.type}</Badge>
              <span className="text-blue-500">{f.prefix || f.name + ":"}</span>
              <span className="text-muted-foreground">{f.description}</span>
            </div>
          ))}
        </div>
        <div className="flex items-center justify-center">
          <ArrowRight className="w-4 h-4 text-muted-foreground" />
        </div>
        <div>
          <div className="text-xs font-medium text-muted-foreground mb-1">Outputs</div>
          {signature.outputs.map((f, i) => (
            <div key={i} className="flex items-center gap-2 text-xs font-mono py-0.5">
              <Badge variant="outline" className="text-[10px] h-4 px-1">{f.type}</Badge>
              <span className="text-green-500">{f.prefix || f.name + ":"}</span>
              <span className="text-muted-foreground">{f.description}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

export default function SignatureEditor() {
  const [signatures, setSignatures] = useState<Signature[]>(DEFAULT_SIGNATURES);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [editing, setEditing] = useState<Signature | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const selected = signatures.find((s) => s.id === selectedId);

  const handleNew = () => {
    setEditing({
      id: "",
      name: "",
      description: "",
      inputs: [emptyField()],
      outputs: [emptyField()],
      instruction: "",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
    setDialogOpen(true);
  };

  const handleEdit = (sig: Signature) => {
    setEditing({ ...sig, inputs: sig.inputs.map((f) => ({ ...f })), outputs: sig.outputs.map((f) => ({ ...f })) });
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!editing) return;
    if (!editing.name.trim()) return;
    const now = new Date().toISOString();
    if (editing.id) {
      setSignatures((prev) =>
        prev.map((s) => (s.id === editing.id ? { ...editing, updatedAt: now } : s))
      );
    } else {
      const newSig = { ...editing, id: `sig-${Date.now()}`, createdAt: now, updatedAt: now };
      setSignatures((prev) => [...prev, newSig]);
      setSelectedId(newSig.id);
    }
    setDialogOpen(false);
    setEditing(null);
  };

  const handleDelete = (id: string) => {
    setSignatures((prev) => prev.filter((s) => s.id !== id));
    if (selectedId === id) setSelectedId(null);
  };

  const handleDuplicate = (sig: Signature) => {
    const dup: Signature = {
      ...sig,
      id: `sig-${Date.now()}`,
      name: sig.name + " (Copy)",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setSignatures((prev) => [...prev, dup]);
  };

  const updateEditField = (
    section: "inputs" | "outputs",
    index: number,
    field: keyof SignatureField,
    value: string
  ) => {
    if (!editing) return;
    const list = [...editing[section]];
    list[index] = { ...list[index], [field]: value };
    setEditing({ ...editing, [section]: list });
  };

  const addField = (section: "inputs" | "outputs") => {
    if (!editing) return;
    setEditing({ ...editing, [section]: [...editing[section], emptyField()] });
  };

  const removeField = (section: "inputs" | "outputs", index: number) => {
    if (!editing) return;
    const list = [...editing[section]];
    list.splice(index, 1);
    setEditing({ ...editing, [section]: list });
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Signature Editor</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Create and edit DSPy signatures with live preview
          </p>
        </div>
        <Button onClick={handleNew}>
          <Plus className="w-4 h-4 mr-2" />
          New Signature
        </Button>
      </div>

      <div className="grid grid-cols-3 gap-6">
        <div className="space-y-3">
          {signatures.map((sig) => (
            <Card
              key={sig.id}
              className={`cursor-pointer transition-colors ${
                selectedId === sig.id ? "border-primary bg-primary/5" : "hover:border-primary/50"
              }`}
              onClick={() => setSelectedId(sig.id)}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <FileCode className="w-4 h-4 text-muted-foreground shrink-0" />
                      <span className="font-medium text-sm truncate">{sig.name}</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                      {sig.description}
                    </p>
                    <div className="flex gap-2 mt-2">
                      <Badge variant="outline" className="text-[10px]">
                        {sig.inputs.length} in
                      </Badge>
                      <Badge variant="outline" className="text-[10px]">
                        {sig.outputs.length} out
                      </Badge>
                    </div>
                  </div>
                  <div className="flex gap-1 ml-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="w-7 h-7"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEdit(sig);
                      }}
                    >
                      <Pencil className="w-3 h-3" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="w-7 h-7"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDuplicate(sig);
                      }}
                    >
                      <Copy className="w-3 h-3" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="w-7 h-7 text-destructive"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(sig.id);
                      }}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="col-span-2">
          {selected ? (
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{selected.name}</CardTitle>
                    <Button variant="outline" size="sm" onClick={() => handleEdit(selected)}>
                      <Pencil className="w-4 h-4 mr-1" />
                      Edit
                    </Button>
                  </div>
                  <CardDescription>{selected.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {selected.instruction && (
                    <div>
                      <label className="text-sm font-medium">Instruction</label>
                      <p className="text-sm text-muted-foreground mt-1 p-2 rounded bg-muted font-mono">
                        {selected.instruction}
                      </p>
                    </div>
                  )}
                  <Separator />
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h4 className="text-sm font-medium mb-2 text-blue-500">Input Fields</h4>
                      {selected.inputs.map((f, i) => (
                        <div key={i} className="p-2 rounded border mb-2">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="text-[10px]">{f.type}</Badge>
                            <span className="text-sm font-mono">{f.prefix || f.name}</span>
                          </div>
                          {f.description && (
                            <p className="text-xs text-muted-foreground mt-1">{f.description}</p>
                          )}
                        </div>
                      ))}
                    </div>
                    <div>
                      <h4 className="text-sm font-medium mb-2 text-green-500">Output Fields</h4>
                      {selected.outputs.map((f, i) => (
                        <div key={i} className="p-2 rounded border mb-2">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="text-[10px]">{f.type}</Badge>
                            <span className="text-sm font-mono">{f.prefix || f.name}</span>
                          </div>
                          {f.description && (
                            <p className="text-xs text-muted-foreground mt-1">{f.description}</p>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
              <div>
                <h3 className="text-sm font-medium mb-2 flex items-center gap-1">
                  <Eye className="w-4 h-4" />
                  Live Preview
                </h3>
                <SignaturePreview signature={selected} />
              </div>
            </div>
          ) : (
            <Card className="flex items-center justify-center h-64 text-muted-foreground">
              <div className="text-center">
                <FileCode className="w-12 h-12 mx-auto mb-2 opacity-30" />
                <p className="text-sm">Select a signature to preview</p>
              </div>
            </Card>
          )}
        </div>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing?.id ? "Edit Signature" : "New Signature"}</DialogTitle>
          </DialogHeader>
          {editing && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Name</label>
                  <Input
                    value={editing.name}
                    onChange={(e) => setEditing({ ...editing, name: e.target.value })}
                    placeholder="SignatureName"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Description</label>
                  <Input
                    value={editing.description}
                    onChange={(e) => setEditing({ ...editing, description: e.target.value })}
                    placeholder="What does this signature do?"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Instruction</label>
                <Textarea
                  value={editing.instruction || ""}
                  onChange={(e) => setEditing({ ...editing, instruction: e.target.value })}
                  placeholder="Natural language instruction for the LLM..."
                  className="min-h-[60px]"
                />
              </div>

              <Separator />
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-medium text-blue-500">Input Fields</h4>
                  <Button variant="outline" size="sm" onClick={() => addField("inputs")}>
                    <Plus className="w-3 h-3 mr-1" /> Add
                  </Button>
                </div>
                {editing.inputs.map((f, i) => (
                  <div key={i} className="flex gap-2 mb-2 items-end">
                    <div className="flex-1">
                      <Input
                        placeholder="Field name"
                        value={f.name}
                        onChange={(e) => updateEditField("inputs", i, "name", e.target.value)}
                      />
                    </div>
                    <Select
                      value={f.type}
                      onValueChange={(v) => updateEditField("inputs", i, "type", v)}
                    >
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {FIELD_TYPES.map((t) => (
                          <SelectItem key={t} value={t}>{t}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Input
                      className="flex-1"
                      placeholder="Description"
                      value={f.description || ""}
                      onChange={(e) => updateEditField("inputs", i, "description", e.target.value)}
                    />
                    <Input
                      className="w-24"
                      placeholder="Prefix"
                      value={f.prefix || ""}
                      onChange={(e) => updateEditField("inputs", i, "prefix", e.target.value)}
                    />
                    <Button variant="ghost" size="icon" className="shrink-0" onClick={() => removeField("inputs", i)}>
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-medium text-green-500">Output Fields</h4>
                  <Button variant="outline" size="sm" onClick={() => addField("outputs")}>
                    <Plus className="w-3 h-3 mr-1" /> Add
                  </Button>
                </div>
                {editing.outputs.map((f, i) => (
                  <div key={i} className="flex gap-2 mb-2 items-end">
                    <div className="flex-1">
                      <Input
                        placeholder="Field name"
                        value={f.name}
                        onChange={(e) => updateEditField("outputs", i, "name", e.target.value)}
                      />
                    </div>
                    <Select
                      value={f.type}
                      onValueChange={(v) => updateEditField("outputs", i, "type", v)}
                    >
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {FIELD_TYPES.map((t) => (
                          <SelectItem key={t} value={t}>{t}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Input
                      className="flex-1"
                      placeholder="Description"
                      value={f.description || ""}
                      onChange={(e) => updateEditField("outputs", i, "description", e.target.value)}
                    />
                    <Input
                      className="w-24"
                      placeholder="Prefix"
                      value={f.prefix || ""}
                      onChange={(e) => updateEditField("outputs", i, "prefix", e.target.value)}
                    />
                    <Button variant="ghost" size="icon" className="shrink-0" onClick={() => removeField("outputs", i)}>
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>

              <Separator />
              <div>
                <h4 className="text-sm font-medium mb-2">Preview</h4>
                <SignaturePreview signature={editing} />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={!editing?.name.trim()}>
              {editing?.id ? "Save Changes" : "Create Signature"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
