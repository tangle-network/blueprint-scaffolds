import { useState } from 'react'
import { useStore, dispatch } from '../store'
import { Database, Brain, Server, ChevronDown, ChevronRight } from 'lucide-react'

function Section({ title, icon: Icon, children }: { title: string; icon: any; children: React.ReactNode }) {
  const [open, setOpen] = useState(true)
  return (
    <div className="border border-surface-700 rounded-xl overflow-hidden">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between px-4 py-3 bg-surface-800 hover:bg-surface-750 transition-colors"
      >
        <div className="flex items-center gap-2">
          <Icon className="w-4 h-4 text-primary-400" />
          <span className="text-sm font-medium">{title}</span>
        </div>
        {open ? <ChevronDown className="w-4 h-4 text-surface-400" /> : <ChevronRight className="w-4 h-4 text-surface-400" />}
      </button>
      {open && <div className="p-4 space-y-3">{children}</div>}
    </div>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="text-xs text-surface-400 mb-1 block">{label}</label>
      {children}
    </div>
  )
}

const inputClass =
  'w-full bg-surface-800 border border-surface-600 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary-500'

export default function ConfigPanel() {
  const llmBackends = useStore((s) => s.llmBackends)
  const activeBackend = useStore((s) => s.activeBackend)
  const vectorDB = useStore((s) => s.vectorDB)
  const optimizationConfig = useStore((s) => s.optimizationConfig)
  const modules = useStore((s) => s.modules)

  return (
    <div className="max-w-3xl mx-auto p-6 space-y-4">
      <Section title="LLM Backends" icon={Brain}>
        <Field label="Active Backend">
          <select
            value={activeBackend}
            onChange={(e) => dispatch({ type: 'SET_ACTIVE_BACKEND', payload: e.target.value })}
            className={inputClass}
          >
            {llmBackends.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name} ({b.provider}/{b.model})
              </option>
            ))}
          </select>
        </Field>

        {llmBackends.map((b) => (
          <div
            key={b.id}
            className={`p-3 rounded-lg border ${
              b.id === activeBackend ? 'border-primary-500 bg-primary-500/5' : 'border-surface-700 bg-surface-800'
            }`}
          >
            <div className="grid grid-cols-2 gap-3">
              <Field label="Provider">
                <input className={inputClass} value={b.provider} readOnly />
              </Field>
              <Field label="Model">
                <input className={inputClass} value={b.model} readOnly />
              </Field>
              <Field label="Max Tokens">
                <input className={inputClass} type="number" value={b.maxTokens} readOnly />
              </Field>
              <Field label="Temperature">
                <input className={inputClass} type="number" step="0.1" value={b.temperature} readOnly />
              </Field>
            </div>
          </div>
        ))}
      </Section>

      <Section title="Vector Database" icon={Database}>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Provider">
            <select
              value={vectorDB.provider}
              onChange={(e) => dispatch({ type: 'SET_VECTOR_DB', payload: { provider: e.target.value as any } })}
              className={inputClass}
            >
              <option value="pinecone">Pinecone</option>
              <option value="weaviate">Weaviate</option>
              <option value="chroma">ChromaDB</option>
            </select>
          </Field>
          <Field label="Index Name">
            <input
              className={inputClass}
              value={vectorDB.indexName}
              onChange={(e) => dispatch({ type: 'SET_VECTOR_DB', payload: { indexName: e.target.value } })}
            />
          </Field>
          <Field label="Dimension">
            <input className={inputClass} type="number" value={vectorDB.dimension} readOnly />
          </Field>
          <Field label="Metric">
            <select
              value={vectorDB.metric}
              onChange={(e) => dispatch({ type: 'SET_VECTOR_DB', payload: { metric: e.target.value as any } })}
              className={inputClass}
            >
              <option value="cosine">Cosine</option>
              <option value="euclidean">Euclidean</option>
              <option value="dotproduct">Dot Product</option>
            </select>
          </Field>
        </div>
      </Section>

      <Section title="Pipeline Modules" icon={Server}>
        <div className="space-y-3">
          {modules.map((m) => (
            <div key={m.name} className="p-3 rounded-lg border border-surface-700 bg-surface-800">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">{m.name}</span>
                <span className="stage-badge bg-primary-500/20 text-primary-300">{m.type}</span>
              </div>
              <p className="text-xs text-surface-400 mb-2">{m.signature.instruction}</p>
              <div className="flex gap-2">
                <span className="text-xs text-surface-500">
                  In: {m.signature.inputs.join(', ')}
                </span>
                <span className="text-xs text-surface-600">→</span>
                <span className="text-xs text-surface-500">
                  Out: {m.signature.outputs.join(', ')}
                </span>
              </div>
            </div>
          ))}
        </div>
      </Section>

      <Section title="Optimization" icon={Brain}>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Metric">
            <input
              className={inputClass}
              value={optimizationConfig.metric}
              onChange={(e) => dispatch({ type: 'SET_OPTIMIZATION_CONFIG', payload: { metric: e.target.value } })}
            />
          </Field>
          <Field label="Teacher Model">
            <input
              className={inputClass}
              value={optimizationConfig.teacherModel}
              onChange={(e) => dispatch({ type: 'SET_OPTIMIZATION_CONFIG', payload: { teacherModel: e.target.value } })}
            />
          </Field>
          <Field label="Max Bootstrapped Demos">
            <input
              className={inputClass}
              type="number"
              value={optimizationConfig.maxBootstrappedDemos}
              onChange={(e) =>
                dispatch({ type: 'SET_OPTIMIZATION_CONFIG', payload: { maxBootstrappedDemos: parseInt(e.target.value) } })
              }
            />
          </Field>
          <Field label="Max Labeled Demos">
            <input
              className={inputClass}
              type="number"
              value={optimizationConfig.maxLabeledDemos}
              onChange={(e) =>
                dispatch({ type: 'SET_OPTIMIZATION_CONFIG', payload: { maxLabeledDemos: parseInt(e.target.value) } })
              }
            />
          </Field>
          <Field label="Max Rounds">
            <input
              className={inputClass}
              type="number"
              value={optimizationConfig.maxRounds}
              onChange={(e) =>
                dispatch({ type: 'SET_OPTIMIZATION_CONFIG', payload: { maxRounds: parseInt(e.target.value) } })
              }
            />
          </Field>
          <Field label="Num Candidates">
            <input
              className={inputClass}
              type="number"
              value={optimizationConfig.numCandidates}
              onChange={(e) =>
                dispatch({ type: 'SET_OPTIMIZATION_CONFIG', payload: { numCandidates: parseInt(e.target.value) } })
              }
            />
          </Field>
        </div>
      </Section>
    </div>
  )
}
