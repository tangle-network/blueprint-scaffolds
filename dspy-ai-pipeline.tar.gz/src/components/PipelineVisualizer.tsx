import { useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import {
  Search,
  GitBranch,
  Brain,
  ShieldCheck,
  Play,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Loader2,
  Clock,
  ArrowRight,
} from "lucide-react";
import type { PipelineStage, PipelineRun } from "@/lib/types";

const STAGE_CONFIG: {
  id: PipelineStage["type"];
  name: string;
  icon: typeof Search;
  color: string;
  bgColor: string;
  description: string;
}[] = [
  {
    id: "retrieval",
    name: "Document Retrieval",
    icon: Search,
    color: "text-blue-500",
    bgColor: "bg-blue-500/10 border-blue-500/30",
    description: "Query vector DB for relevant documents",
  },
  {
    id: "decomposition",
    name: "Question Decomposition",
    icon: GitBranch,
    color: "text-purple-500",
    bgColor: "bg-purple-500/10 border-purple-500/30",
    description: "Break complex questions into sub-questions",
  },
  {
    id: "synthesis",
    name: "Answer Synthesis",
    icon: Brain,
    color: "text-green-500",
    bgColor: "bg-green-500/10 border-green-500/30",
    description: "Synthesize answers from retrieved context",
  },
  {
    id: "verification",
    name: "Fact Verification",
    icon: ShieldCheck,
    color: "text-amber-500",
    bgColor: "bg-amber-500/10 border-amber-500/30",
    description: "Verify factual accuracy of synthesized answers",
  },
];

const MOCK_OUTPUTS: Record<PipelineStage["type"], string> = {
  retrieval:
    'Retrieved 5 relevant documents from vector DB (scores: 0.94, 0.89, 0.85, 0.82, 0.78). Top result: "DSPy is a framework for algorithmically optimizing language model prompts and weights..."',
  decomposition:
    "Decomposed into 3 sub-questions:\n1. What is DSPy's core architecture?\n2. How does signature-based programming work?\n3. What optimization strategies are available?",
  synthesis:
    "Synthesized answer: DSPy is a framework that introduces signature-based programming for LMs, allowing developers to define modular pipeline components declaratively. It supports automatic prompt optimization through bootstrap few-shot learning and compiled prompt strategies.",
  verification:
    "Verification passed with 92% confidence. Cross-referenced against 3 independent sources. No factual contradictions detected. Claim strength: Strong for architecture and signatures, Moderate for optimization benchmarks.",
};

function simulateStage(
  run: PipelineRun,
  stageIndex: number,
  onComplete: (run: PipelineRun) => void
) {
  const stage = run.stages[stageIndex];
  stage.status = "running";
  stage.duration = undefined;
  onComplete({ ...run, stages: [...run.stages] });

  const duration = 800 + Math.random() * 1200;
  const start = Date.now();

  setTimeout(() => {
    stage.status = "completed";
    stage.output = MOCK_OUTPUTS[stage.type];
    stage.duration = Date.now() - start;
    onComplete({ ...run, stages: [...run.stages] });

    if (stageIndex < run.stages.length - 1) {
      simulateStage(run, stageIndex + 1, onComplete);
    } else {
      onComplete({
        ...run,
        status: "completed",
        output: "Pipeline completed successfully.",
        completedAt: new Date().toISOString(),
        stages: [...run.stages],
      });
    }
  }, duration);
}

export default function PipelineVisualizer() {
  const [input, setInput] = useState(
    "How does DSPy optimize prompt engineering workflows?"
  );
  const [run, setRun] = useState<PipelineRun>({
    id: "",
    stages: STAGE_CONFIG.map((s) => ({
      id: s.id,
      name: s.name,
      type: s.id,
      status: "idle" as const,
    })),
    input: "",
    status: "idle",
  });

  const handleRun = useCallback(() => {
    const newRun: PipelineRun = {
      id: crypto.randomUUID(),
      stages: STAGE_CONFIG.map((s) => ({
        id: s.id,
        name: s.name,
        type: s.id,
        status: "idle" as const,
      })),
      input,
      status: "running",
      startedAt: new Date().toISOString(),
    };
    simulateStage(newRun, 0, setRun);
  }, [input]);

  const handleReset = useCallback(() => {
    setRun({
      id: "",
      stages: STAGE_CONFIG.map((s) => ({
        id: s.id,
        name: s.name,
        type: s.id,
        status: "idle" as const,
      })),
      input: "",
      status: "idle",
    });
  }, []);

  const completedCount = run.stages.filter(
    (s) => s.status === "completed"
  ).length;
  const progress = (completedCount / run.stages.length) * 100;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Pipeline Visualizer</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Visual DAG of DSPy pipeline stages
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline">
            {completedCount}/{run.stages.length} stages
          </Badge>
          {run.status === "running" && (
            <Badge className="bg-blue-500/10 text-blue-500 border-blue-500/30">
              <Loader2 className="w-3 h-3 mr-1 animate-spin" />
              Running
            </Badge>
          )}
          {run.status === "completed" && (
            <Badge className="bg-green-500/10 text-green-500 border-green-500/30">
              <CheckCircle2 className="w-3 h-3 mr-1" />
              Complete
            </Badge>
          )}
        </div>
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="flex gap-3">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Enter your query to run through the pipeline..."
              className="min-h-[60px] flex-1"
              disabled={run.status === "running"}
            />
            <div className="flex flex-col gap-2">
              <Button
                onClick={handleRun}
                disabled={run.status === "running" || !input.trim()}
              >
                {run.status === "running" ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Play className="w-4 h-4 mr-2" />
                )}
                Run Pipeline
              </Button>
              <Button variant="outline" onClick={handleReset}>
                <RotateCcw className="w-4 h-4 mr-2" />
                Reset
              </Button>
            </div>
          </div>
          {run.status !== "idle" && (
            <div className="mt-4">
              <Progress value={progress} className="h-2" />
            </div>
          )}
        </CardContent>
      </Card>

      <div className="relative">
        <div className="grid grid-cols-4 gap-4">
          {STAGE_CONFIG.map((config, i) => {
            const stage = run.stages[i];
            const Icon = config.icon;
            return (
              <div key={config.id} className="relative">
                <Card
                  className={`pipeline-node border-2 transition-all ${
                    stage?.status === "running"
                      ? config.bgColor + " animate-pulse"
                      : stage?.status === "completed"
                      ? "border-green-500/50 bg-green-500/5"
                      : stage?.status === "error"
                      ? "border-red-500/50 bg-red-500/5"
                      : "border-border"
                  }`}
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div
                        className={`w-10 h-10 rounded-lg ${config.bgColor} flex items-center justify-center`}
                      >
                        <Icon className={`w-5 h-5 ${config.color}`} />
                      </div>
                      {stage?.status === "completed" && (
                        <CheckCircle2 className="w-5 h-5 text-green-500" />
                      )}
                      {stage?.status === "running" && (
                        <Loader2 className="w-5 h-5 text-blue-500 animate-spin" />
                      )}
                      {stage?.status === "error" && (
                        <XCircle className="w-5 h-5 text-red-500" />
                      )}
                    </div>
                    <CardTitle className="text-sm mt-2">
                      {config.name}
                    </CardTitle>
                    <CardDescription className="text-xs">
                      {config.description}
                    </CardDescription>
                  </CardHeader>
                  {stage?.output && (
                    <CardContent>
                      <Separator className="mb-3" />
                      <p className="text-xs text-muted-foreground whitespace-pre-wrap leading-relaxed">
                        {stage.output}
                      </p>
                      {stage.duration && (
                        <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                          <Clock className="w-3 h-3" />
                          {stage.duration}ms
                        </div>
                      )}
                    </CardContent>
                  )}
                </Card>
                {i < STAGE_CONFIG.length - 1 && (
                  <div className="absolute -right-6 top-1/2 -translate-y-1/2 z-10">
                    <ArrowRight className="w-5 h-5 text-muted-foreground" />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {run.status === "completed" && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Pipeline Result</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div>
                <span className="text-sm font-medium">Input:</span>
                <p className="text-sm text-muted-foreground mt-1">{run.input}</p>
              </div>
              <Separator />
              <div>
                <span className="text-sm font-medium">Final Output:</span>
                <p className="text-sm text-muted-foreground mt-1">
                  Pipeline executed successfully across {run.stages.length} stages.
                  Average stage duration:{" "}
                  {Math.round(
                    run.stages.reduce((a, s) => a + (s.duration || 0), 0) /
                      run.stages.length
                  )}
                  ms
                </p>
              </div>
              <div className="grid grid-cols-4 gap-4 pt-2">
                {run.stages.map((stage) => (
                  <div key={stage.id} className="text-center">
                    <div className="text-lg font-bold text-green-500">
                      {stage.duration}ms
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {stage.name}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
