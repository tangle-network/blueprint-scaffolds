import { useStore } from '../store'
import { FileText, AlertCircle, Loader } from 'lucide-react'

export default function ResultsPanel() {
  const stage = useStore((s) => s.stage)
  const result = useStore((s) => s.result)
  const error = useStore((s) => s.error)

  if (error) {
    return (
      <div className="p-4">
        <div className="flex items-center gap-2 text-red-400 mb-2">
          <AlertCircle className="w-4 h-4" />
          <span className="text-sm font-medium">Error</span>
        </div>
        <p className="text-xs text-surface-400">{error}</p>
      </div>
    )
  }

  if (!result) {
    return (
      <div className="p-4">
        <div className="flex items-center gap-2 text-surface-500 mb-3">
          {stage !== 'idle' ? (
            <Loader className="w-4 h-4 animate-spin" />
          ) : (
            <FileText className="w-4 h-4" />
          )}
          <span className="text-sm font-medium">
            {stage === 'idle' ? 'Pipeline Results' : 'Running pipeline...'}
          </span>
        </div>
        {stage === 'idle' && (
          <div className="space-y-2">
            <div className="h-3 bg-surface-700 rounded w-full" />
            <div className="h-3 bg-surface-700 rounded w-4/5" />
            <div className="h-3 bg-surface-700 rounded w-3/5" />
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center gap-2 text-emerald-400">
        <FileText className="w-4 h-4" />
        <span className="text-sm font-medium">Results</span>
        <span className="text-xs text-surface-400 ml-auto">{result.latencyMs}ms</span>
      </div>

      <div className="space-y-3">
        <div>
          <h4 className="text-xs text-surface-400 mb-1">Retrieved Docs ({result.documents.length})</h4>
          {result.documents.slice(0, 3).map((doc) => (
            <div key={doc.id} className="text-xs bg-surface-800 rounded p-2 mb-1 border border-surface-700">
              <div className="flex justify-between mb-1">
                <span className="text-primary-300 font-medium">{doc.source}</span>
                <span className="text-surface-500">{(doc.score * 100).toFixed(0)}%</span>
              </div>
              <p className="text-surface-400 line-clamp-2">{doc.content}</p>
            </div>
          ))}
        </div>

        <div>
          <h4 className="text-xs text-surface-400 mb-1">Sub-Questions ({result.subQuestions.length})</h4>
          {result.subQuestions.map((sq) => (
            <div key={sq.id} className="text-xs bg-surface-800 rounded p-2 mb-1 border border-surface-700">
              <p className="text-primary-300">{sq.question}</p>
              <p className="text-surface-400 mt-1 line-clamp-2">{sq.answer}</p>
            </div>
          ))}
        </div>

        <div>
          <h4 className="text-xs text-surface-400 mb-1">Verifications ({result.verifications.length})</h4>
          <div className="flex gap-2 flex-wrap">
            {result.verifications.map((v, i) => (
              <span
                key={i}
                className={`stage-badge ${
                  v.verdict === 'supported'
                    ? 'bg-emerald-500/20 text-emerald-300'
                    : v.verdict === 'refuted'
                      ? 'bg-red-500/20 text-red-300'
                      : 'bg-amber-500/20 text-amber-300'
                }`}
              >
                {v.verdict}
              </span>
            ))}
          </div>
        </div>

        <div className="pt-2 border-t border-surface-700">
          <div className="flex justify-between text-xs">
            <span className="text-surface-400">Confidence</span>
            <span className="text-emerald-400 font-medium">{(result.confidence * 100).toFixed(0)}%</span>
          </div>
          <div className="w-full bg-surface-700 rounded-full h-1.5 mt-1">
            <div
              className="bg-emerald-500 h-1.5 rounded-full transition-all"
              style={{ width: `${result.confidence * 100}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  )
}
