import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Rocket,
  Zap,
  TrendingUp,
  Activity,
  Clock,
  CheckCircle2,
  Loader2,
  BarChart3,
  Target,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react";
import type { OptimizationResult, Metrics } from "@/lib/types";

const MOCK_METRICS: Metrics = {
  totalRuns: 247,
  averageScore: 0.84,
  bestScore: 0.96,
  optimizationHistory: [
    { timestamp: "2025-01-10", score: 0.65, type: "baseline" },
    { timestamp: "2025-01-11", score: 0.72, type: "bootstrap" },
    { timestamp: "2025-01-12", score: 0.78, type: "bootstrap" },
    { timestamp: "2025-01-13", score: 0.83, type: "compile" },
    { timestamp: "2025-01-14", score: 0.87, type: "bootstrap" },
    { timestamp: "2025-01-15", score: 0.91, type: "compile" },
    { timestamp: "2025-01-16", score: 0.89, type: "bootstrap" },
    { timestamp: "2025-01-17", score: 0.93, type: "compile" },
    { timestamp: "2025-01-18", score: 0.96, type: "compile" },
  ],
  stageMetrics: [
    { name: "Retrieval", avgDuration: 245, successRate: 0.98, callCount: 1247 },
    { name: "Decomposition", avgDuration: 380, successRate: 0.95, callCount: 1247 },
    { name: "Synthesis", avgDuration: 890, successRate: 0.92, callCount: 1247 },
    { name: "Verification", avgDuration: 520, successRate: 0.97, callCount: 1247 },
  ],
};

const MOCK_PROMPT = `Given the fields \`question\`, produce the fields \`answer\`.

---

Follow the following format.

Question: ${"$"}{question}
Reasoning: Let's think step by step in order to
Answer: ${"$"}{answer}

---

Question: What is DSPy?
Reasoning: Let's think step by step in order to identify the core framework and its purpose. DSPy stands for Declarative Self-improving Python. It's a framework for optimizing language model prompts.
Answer: DSPy is a framework for algorithmically optimizing language model prompts and weights through declarative programming.

Question: How does bootstrap optimization work?
Reasoning: Let's think step by step in order to explain the bootstrap process. It generates few-shot examples by running the pipeline on training data and filtering by quality metrics.
Answer: Bootstrap optimization works by executing the pipeline on training examples, collecting successful demonstrations, and using them as few-shot examples to improve performance.`;

export default function OptimizationPanel() {
  const [bootstrapResult, setBootstrapResult] = useState<OptimizationResult | null>(null);
  const [compileResult, setCompileResult] = useState<OptimizationResult | null>(null);
  const [bootstrapRunning, setBootstrapRunning] = useState(false);
  const [compileRunning, setCompileRunning] = useState(false);
  const [numExamples, setNumExamples] = useState("8");
  const [teacherModel, setTeacherModel] = useState("gpt-4");
  const [signatureId, setSignatureId] = useState("sig-1");
  const [metrics] = useState<Metrics>(MOCK_METRICS);

  const runBootstrap = () => {
    setBootstrapRunning(true);
    setBootstrapResult(null);
    setTimeout(() => {
      const n = parseInt(numExamples);
      setBootstrapResult({
        id: `opt-${Date.now()}`,
        type: "bootstrap",
        status: "completed",
        score: 0.87 + Math.random() * 0.08,
        previousScore: 0.72,
        improvement: 0.18 + Math.random() * 0.05,
        examples: Array.from({ length: n }, (_, i) => ({
          input: { question: `Sample question ${i + 1}` },
          output: { answer: `Sample answer ${i + 1}` },
          score: 0.8 + Math.random() * 0.18,
        })),
        duration: 2400 + Math.random() * 1600,
        completedAt: new Date().toISOString(),
      });
      setBootstrapRunning(false);
    }, 3000);
  };

  const runCompile = () => {
    setCompileRunning(true);
    setCompileResult(null);
    setTimeout(() => {
      setCompileResult({
        id: `opt-${Date.now()}`,
        type: "compile",
        status: "completed",
        score: 0.91 + Math.random() * 0.05,
        previousScore: bootstrapResult?.score || 0.84,
        improvement: 0.08 + Math.random() * 0.04,
        compiledPrompt: MOCK_PROMPT,
        duration: 4200 + Math.random() * 2000,
        completedAt: new Date().toISOString(),
      });
      setCompileRunning(false);
    }, 4000);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Optimization Panel</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Bootstrap few-shot optimization, compile-time tuning, and metrics
          </p>
        </div>
        <Badge variant="outline" className="text-sm">
          <Activity className="w-3 h-3 mr-1" />
          {metrics.totalRuns} total runs
        </Badge>
      </div>

      <Tabs defaultValue="optimize">
        <TabsList>
          <TabsTrigger value="optimize">
            <Zap className="w-3 h-3 mr-1" />
            Optimize
          </TabsTrigger>
          <TabsTrigger value="metrics">
            <BarChart3 className="w-3 h-3 mr-1" />
            Metrics
          </TabsTrigger>
          <TabsTrigger value="history">
            <TrendingUp className="w-3 h-3 mr-1" />
            History
          </TabsTrigger>
        </TabsList>

        <TabsContent value="optimize" className="mt-4 space-y-6">
          <div className="grid grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Rocket className="w-4 h-4 text-blue-500" />
                  Bootstrap Few-Shot
                </CardTitle>
                <CardDescription>
                  Generate optimized few-shot examples from training data
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Target Signature</label>
                  <Select value={signatureId} onValueChange={setSignatureId}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sig-1">QuestionAnswer</SelectItem>
                      <SelectItem value="sig-2">RAGRetrieval</SelectItem>
                      <SelectItem value="sig-3">ChainOfThought</SelectItem>
                      <SelectItem value="sig-4">FactVerification</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Number of Examples</label>
                  <Input
                    type="number"
                    min={1}
                    max={20}
                    value={numExamples}
                    onChange={(e) => setNumExamples(e.target.value)}
                  />
                </div>
                <Button
                  className="w-full"
                  onClick={runBootstrap}
                  disabled={bootstrapRunning}
                >
                  {bootstrapRunning ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Bootstrapping...
                    </>
                  ) : (
                    <>
                      <Rocket className="w-4 h-4 mr-2" />
                      Run Bootstrap
                    </>
                  )}
                </Button>
                {bootstrapRunning && (
                  <Progress value={66} className="h-2" />
                )}
                {bootstrapResult && (
                  <div className="space-y-3 p-3 rounded-md border bg-muted/30">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-500" />
                      <span className="text-sm font-medium">Bootstrap Complete</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div>
                        <div className="text-lg font-bold text-green-500">
                          {(bootstrapResult.score! * 100).toFixed(1)}%
                        </div>
                        <div className="text-xs text-muted-foreground">Score</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-blue-500 flex items-center justify-center">
                          <ArrowUpRight className="w-4 h-4" />
                          {((bootstrapResult.improvement || 0) * 100).toFixed(1)}%
                        </div>
                        <div className="text-xs text-muted-foreground">Improvement</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold">
                          {bootstrapResult.duration?.toFixed(0)}ms
                        </div>
                        <div className="text-xs text-muted-foreground">Duration</div>
                      </div>
                    </div>
                    <div>
                      <span className="text-xs text-muted-foreground">
                        Generated {bootstrapResult.examples?.length} few-shot examples
                      </span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-500" />
                  Compile Prompt
                </CardTitle>
                <CardDescription>
                  Compile an optimized prompt with tuned instructions
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Target Signature</label>
                  <Select value={signatureId} onValueChange={setSignatureId}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sig-1">QuestionAnswer</SelectItem>
                      <SelectItem value="sig-2">RAGRetrieval</SelectItem>
                      <SelectItem value="sig-3">ChainOfThought</SelectItem>
                      <SelectItem value="sig-4">FactVerification</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Teacher Model</label>
                  <Select value={teacherModel} onValueChange={setTeacherModel}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="gpt-4">GPT-4</SelectItem>
                      <SelectItem value="claude-3">Claude 3</SelectItem>
                      <SelectItem value="gpt-3.5-turbo">GPT-3.5 Turbo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button
                  className="w-full"
                  onClick={runCompile}
                  disabled={compileRunning}
                >
                  {compileRunning ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Compiling...
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4 mr-2" />
                      Compile Prompt
                    </>
                  )}
                </Button>
                {compileRunning && <Progress value={45} className="h-2" />}
                {compileResult && (
                  <div className="space-y-3">
                    <div className="p-3 rounded-md border bg-muted/30">
                      <div className="flex items-center gap-2 mb-2">
                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                        <span className="text-sm font-medium">Compilation Complete</span>
                      </div>
                      <div className="grid grid-cols-3 gap-2 text-center">
                        <div>
                          <div className="text-lg font-bold text-green-500">
                            {(compileResult.score! * 100).toFixed(1)}%
                          </div>
                          <div className="text-xs text-muted-foreground">Score</div>
                        </div>
                        <div>
                          <div className="text-lg font-bold text-blue-500 flex items-center justify-center">
                            <ArrowUpRight className="w-4 h-4" />
                            {((compileResult.improvement || 0) * 100).toFixed(1)}%
                          </div>
                          <div className="text-xs text-muted-foreground">Improvement</div>
                        </div>
                        <div>
                          <div className="text-lg font-bold">
                            {compileResult.duration?.toFixed(0)}ms
                          </div>
                          <div className="text-xs text-muted-foreground">Duration</div>
                        </div>
                      </div>
                    </div>
                    {compileResult.compiledPrompt && (
                      <div>
                        <label className="text-sm font-medium">Compiled Prompt</label>
                        <pre className="mt-1 p-3 rounded-md bg-muted text-xs font-mono whitespace-pre-wrap overflow-x-auto max-h-64 overflow-y-auto">
                          {compileResult.compiledPrompt}
                        </pre>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="metrics" className="mt-4 space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                    <Target className="w-5 h-5 text-blue-500" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">
                      {(metrics.averageScore * 100).toFixed(1)}%
                    </div>
                    <div className="text-xs text-muted-foreground">Average Score</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-green-500" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">
                      {(metrics.bestScore * 100).toFixed(1)}%
                    </div>
                    <div className="text-xs text-muted-foreground">Best Score</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center">
                    <Activity className="w-5 h-5 text-amber-500" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">{metrics.totalRuns}</div>
                    <div className="text-xs text-muted-foreground">Total Runs</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Stage Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {metrics.stageMetrics.map((stage) => (
                  <div key={stage.name} className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-medium">{stage.name}</span>
                      <div className="flex items-center gap-4 text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {stage.avgDuration}ms avg
                        </span>
                        <span>{stage.callCount} calls</span>
                        <Badge
                          variant="outline"
                          className={
                            stage.successRate >= 0.95
                              ? "bg-green-500/10 text-green-500 border-green-500/30"
                              : "bg-amber-500/10 text-amber-500 border-amber-500/30"
                          }
                        >
                          {(stage.successRate * 100).toFixed(1)}% success
                        </Badge>
                      </div>
                    </div>
                    <Progress value={stage.successRate * 100} className="h-1.5" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Optimization History</CardTitle>
              <CardDescription>Score progression over optimization runs</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {metrics.optimizationHistory.map((entry, i) => {
                  const prevScore = i > 0 ? metrics.optimizationHistory[i - 1].score : entry.score;
                  const improved = entry.score >= prevScore;
                  return (
                    <div
                      key={i}
                      className="flex items-center justify-between p-3 rounded-md border"
                    >
                      <div className="flex items-center gap-3">
                        <Badge
                          variant="outline"
                          className={
                            entry.type === "compile"
                              ? "bg-amber-500/10 text-amber-500 border-amber-500/30"
                              : entry.type === "bootstrap"
                              ? "bg-blue-500/10 text-blue-500 border-blue-500/30"
                              : "bg-muted text-muted-foreground"
                          }
                        >
                          {entry.type}
                        </Badge>
                        <span className="text-sm text-muted-foreground">
                          {entry.timestamp}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sm font-medium">
                          {(entry.score * 100).toFixed(1)}%
                        </span>
                        {i > 0 && (
                          <span
                            className={`text-xs flex items-center ${
                              improved ? "text-green-500" : "text-red-500"
                            }`}
                          >
                            {improved ? (
                              <ArrowUpRight className="w-3 h-3" />
                            ) : (
                              <ArrowDownRight className="w-3 h-3" />
                            )}
                            {Math.abs(((entry.score - prevScore) * 100)).toFixed(1)}%
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
