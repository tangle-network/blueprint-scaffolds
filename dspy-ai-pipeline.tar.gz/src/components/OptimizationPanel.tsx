import { useStore, dispatch } from '../store'
import { runOptimization } from '../lib/pipeline'
import { Zap, X } from 'lucide-react'
import { useState } from 'react'

export default function OptimizationPanel() {
  const isOptimizing = useStore((s) => s.isOptimizing)
  const progress = useStore((s) => s.optimizationProgress)
  const [showPanel, setShowPanel] = useState(false)

  const handleOptimize = async () => {
    dispatch({ type: 'SET_OPTIMIZING', payload: true })
    dispatch({ type: 'SET_OPTIMIZATION_PROGRESS', payload: 0 })
    try {
      await runOptimization((p) => {
        dispatch({ type: 'SET_OPTIMIZATION_PROGRESS', payload: p })
      })
    } finally {
      dispatch({ type: 'SET_OPTIMIZING', payload: false })
      dispatch({ type: 'SET_OPTIMIZATION_PROGRESS', payload: 0 })
    }
  }

  if (!showPanel && !isOptimizing) {
    return (
      <div className="fixed bottom-4 right-4">
        <button
          onClick={() => setShowPanel(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-primary-600 hover:bg-primary-700 rounded-xl text-sm font-medium shadow-lg shadow-primary-500/20 transition-colors"
        >
          <Zap className="w-4 h-4" />
          Optimize Pipeline
        </button>
      </div>
    )
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 glass border-t border-surface-700 p-4">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-primary-400" />
            <span className="text-sm font-medium">
              {isOptimizing ? 'Bootstrap Few-Shot Optimization' : 'Pipeline Optimization'}
            </span>
          </div>
          <button onClick={() => setShowPanel(false)} className="text-surface-400 hover:text-surface-200">
            <X className="w-4 h-4" />
          </button>
        </div>

        {isOptimizing && (
          <div className="space-y-2">
            <div className="w-full bg-surface-700 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-primary-500 to-purple-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
            <div className="flex justify-between text-xs text-surface-400">
              <span>
                {progress < 25
                  ? 'Bootstrapping demonstrations...'
                  : progress < 50
                    ? 'Evaluating candidates...'
                    : progress < 75
                      ? 'Compiling optimized prompts...'
                      : 'Finalizing pipeline...'}
              </span>
              <span>{progress.toFixed(0)}%</span>
            </div>
          </div>
        )}

        {!isOptimizing && (
          <div className="flex items-center justify-between">
            <p className="text-xs text-surface-400">
              Run BootstrapFewShot optimization to automatically generate and tune few-shot demonstrations for each pipeline module.
            </p>
            <button
              onClick={handleOptimize}
              className="px-4 py-2 bg-primary-600 hover:bg-primary-700 rounded-lg text-sm font-medium transition-colors ml-4"
            >
              Start Optimization
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
