import { useState } from 'react'
import { useStore } from '../store'
import { runPipeline } from '../lib/pipeline'
import type { PipelineResult } from '../types'
import { Send, Clock, Hash, CheckCircle, XCircle, HelpCircle } from 'lucide-react'

export default function Playground() {
  const history = useStore((s) => s.playgroundHistory)
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [selectedResult, setSelectedResult] = useState<{
    query: string
    result: PipelineResult
  } | null>(null)

  const handleSend = async () => {
    if (!input.trim() || loading) return
    setLoading(true)
    const { dispatch } = await import('../store')
    try {
      const result = await runPipeline(input, () => {})
      dispatch({ type: 'ADD_PLAYGROUND_HISTORY', payload: { query: input, result } })
      setSelectedResult({ query: input, result })
      setInput('')
    } catch {
    } finally {
      setLoading(false)
    }
  }

  const display = selectedResult || (history.length > 0 ? history[history.length - 1] : null)

  return (
    <div className="h-full flex">
      <div className="w-72 border-r border-surface-700 flex flex-col shrink-0">
        <div className="p-3 border-b border-surface-700">
          <h3 className="text-sm font-semibold text-surface-300">History</h3>
        </div>
        <div className="flex-1 overflow-auto p-2 space-y-1 scrollbar-thin">
          {history.length === 0 && (
            <p className="text-xs text-surface-500 p-2">No queries yet. Try asking something!</p>
          )}
          {[...history].reverse().map((h, i) => (
            <button
              key={i}
              onClick={() => setSelectedResult(h)}
              className={`w-full text-left px-3 py-2 rounded-lg text-xs transition-colors ${
                selectedResult?.query === h.query && selectedResult?.result === h.result
                  ? 'bg-primary-600/20 text-primary-300'
                  : 'text-surface-400 hover:bg-surface-700'
              }`}
            >
              <span className="line-clamp-2">{h.query}</span>
              <span className="text-surface-500 mt-1 block">
                {h.result.latencyMs}ms · {h.result.confidence}% conf
              </span>
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 flex flex-col">
        <div className="flex-1 overflow-auto p-6 scrollbar-thin">
          {display ? (
            <div className="space-y-6 max-w-3xl">
              <div>
                <h2 className="text-sm font-medium text-surface-400 mb-1">Query</h2>
                <p className="text-base font-medium">{display.query}</p>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="glass rounded-lg p-3">
                  <div className="flex items-center gap-2 text-xs text-surface-400 mb-1">
                    <Clock className="w-3 h-3" /> Latency
                  </div>
                  <p className="text-lg font-semibold">{display.result.latencyMs}ms</p>
                </div>
                <div className="glass rounded-lg p-3">
                  <div className="flex items-center gap-2 text-xs text-surface-400 mb-1">
                    <Hash className="w-3 h-3" /> Tokens
                  </div>
                  <p className="text-lg font-semibold">{display.result.totalTokens}</p>
                </div>
                <div className="glass rounded-lg p-3">
                  <div className="flex items-center gap-2 text-xs text-surface-400 mb-1">
                    <CheckCircle className="w-3 h-3" /> Confidence
                  </div>
                  <p className="text-lg font-semibold">{(display.result.confidence * 100).toFixed(0)}%</p>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium text-surface-400 mb-2">Answer</h3>
                <div className="glass rounded-lg p-4 text-sm leading-relaxed whitespace-pre-wrap">
                  {display.result.answer}
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium text-surface-400 mb-2">
                  Sub-Questions ({display.result.subQuestions.length})
                </h3>
                <div className="space-y-2">
                  {display.result.subQuestions.map((sq) => (
                    <div key={sq.id} className="glass rounded-lg p-3">
                      <p className="text-xs font-medium text-primary-300">{sq.question}</p>
                      <p className="text-xs text-surface-300 mt-1">{sq.answer}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <span className="stage-badge bg-surface-700 text-surface-300">
                          {(sq.confidence * 100).toFixed(0)}% confidence
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium text-surface-400 mb-2">Verifications</h3>
                <div className="space-y-2">
                  {display.result.verifications.map((v, i) => (
                    <div key={i} className="glass rounded-lg p-3 flex items-start gap-3">
                      {v.verdict === 'supported' ? (
                        <CheckCircle className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                      ) : v.verdict === 'refuted' ? (
                        <XCircle className="w-4 h-4 text-red-400 mt-0.5 shrink-0" />
                      ) : (
                        <HelpCircle className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
                      )}
                      <div>
                        <p className="text-xs font-medium">{v.claim}</p>
                        <p className="text-xs text-surface-400 mt-1">{v.evidence}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-full">
              <div className="text-center text-surface-500">
                <p className="text-lg font-medium mb-1">DSPy Playground</p>
                <p className="text-sm">Enter a query to start exploring the pipeline</p>
              </div>
            </div>
          )}
        </div>

        <div className="border-t border-surface-700 p-4">
          <div className="flex gap-3">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask a question about DSPy, prompt engineering, or AI pipelines..."
              className="flex-1 bg-surface-800 border border-surface-600 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-primary-500 placeholder-surface-500"
              disabled={loading}
            />
            <button
              onClick={handleSend}
              disabled={loading || !input.trim()}
              className="px-4 py-3 bg-primary-600 hover:bg-primary-700 disabled:bg-surface-700 rounded-xl transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
