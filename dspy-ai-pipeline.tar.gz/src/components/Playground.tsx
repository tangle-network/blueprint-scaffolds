import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Play,
  Loader2,
  Brain,
  MessageSquare,
  Sparkles,
  ChevronRight,
  Thermometer,
} from "lucide-react";
import type { PlaygroundResponse } from "@/lib/types";

const MOCK_REASONING = [
  "Analyzing query structure and intent...",
  "Identifying key concepts: 'DSPy', 'prompt optimization', 'automated engineering'",
  "Decomposing into retrieval-augmented reasoning steps...",
  "Querying vector database for relevant context (5 documents found)...",
  "Applying chain-of-thought reasoning with retrieved context...",
  "Synthesizing answer from evidence...",
  "Verifying factual consistency across sources...",
  "Computing confidence score based on evidence strength...",
];

const MOCK_RESPONSE: PlaygroundResponse = {
  answer:
    "DSPy optimizes prompt engineering through a declarative signature-based programming model. Instead of manually crafting prompts, developers define input/output signatures (e.g., 'question -> answer'), and DSPy automatically generates, tests, and optimizes prompts using techniques like bootstrap few-shot learning. The framework compiles these into optimized prompts by selecting effective demonstrations and tuning instruction text, achieving performance that often exceeds hand-crafted prompts.",
  reasoning: MOCK_REASONING,
  confidence: 0.92,
  sources: [
    {
      id: "1",
      content:
        "DSPy: Compiling Declarative Language Model Calls into Self-Improving Pipelines",
      score: 0.94,
    },
    {
      id: "2",
      content: "Bootstrap Few-Shot Learning for Automated Prompt Engineering",
      score: 0.89,
    },
    {
      id: "3",
      content: "Signature-Based Programming for Language Models",
      score: 0.85,
    },
  ],
  stageOutputs: [
    { stage: "retrieval", output: "Retrieved 5 documents with avg score 0.86" },
    {
      stage: "decomposition",
      output: "3 sub-questions generated from query analysis",
    },
    { stage: "synthesis", output: "Answer synthesized from 5 sources" },
    {
      stage: "verification",
      output: "92% confidence, no contradictions found",
    },
  ],
};

export default function Playground() {
  const [query, setQuery] = useState("");
  const [useCoT, setUseCoT] = useState(true);
  const [temperature, setTemperature] = useState("0.7");
  const [model, setModel] = useState("gpt-4");
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState<PlaygroundResponse | null>(null);
  const [currentReasoningStep, setCurrentReasoningStep] = useState(-1);

  const handleRun = () => {
    if (!query.trim()) return;
    setLoading(true);
    setResponse(null);
    setCurrentReasoningStep(0);

    let step = 0;
    const interval = setInterval(() => {
      step++;
      if (step < MOCK_REASONING.length) {
        setCurrentReasoningStep(step);
      } else {
        clearInterval(interval);
        setResponse(MOCK_RESPONSE);
        setLoading(false);
        setCurrentReasoningStep(-1);
      }
    }, 500);
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Playground</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Interactive prompt testing with chain-of-thought reasoning
        </p>
      </div>

      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2 space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <MessageSquare className="w-4 h-4" />
                Query Input
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Enter your question or prompt to test..."
                className="min-h-[100px]"
              />
              <div className="flex items-center gap-3 mt-3">
                <Button
                  onClick={handleRun}
                  disabled={loading || !query.trim()}
                >
                  {loading ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Play className="w-4 h-4 mr-2" />
                  )}
                  {loading ? "Processing..." : "Run Query"}
                </Button>
                <Button
                  variant={useCoT ? "default" : "outline"}
                  size="sm"
                  onClick={() => setUseCoT(!useCoT)}
                >
                  <Brain className="w-4 h-4 mr-1" />
                  Chain-of-Thought
                </Button>
              </div>
            </CardContent>
          </Card>

          {(loading || response) && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Brain className="w-4 h-4" />
                  {useCoT ? "Reasoning Chain" : "Output"}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loading && (
                  <div className="space-y-2">
                    {MOCK_REASONING.slice(0, currentReasoningStep + 1).map(
                      (step, i) => (
                        <div
                          key={i}
                          className="reasoning-step flex items-start gap-2 text-sm"
                        >
                          <ChevronRight className="w-4 h-4 mt-0.5 text-muted-foreground shrink-0" />
                          <span
                            className={
                              i === currentReasoningStep
                                ? "text-foreground"
                                : "text-muted-foreground"
                            }
                          >
                            {step}
                          </span>
                          {i === currentReasoningStep && (
                            <Loader2 className="w-3 h-3 mt-1 animate-spin text-blue-500 shrink-0" />
                          )}
                        </div>
                      )
                    )}
                  </div>
                )}
                {response && (
                  <Tabs defaultValue="answer">
                    <TabsList>
                      <TabsTrigger value="answer">Answer</TabsTrigger>
                      <TabsTrigger value="reasoning">Reasoning</TabsTrigger>
                      <TabsTrigger value="stages">Stage Outputs</TabsTrigger>
                    </TabsList>
                    <TabsContent value="answer" className="mt-4">
                      <div className="space-y-3">
                        <p className="text-sm leading-relaxed">
                          {response.answer}
                        </p>
                        <Separator />
                        <div className="flex items-center gap-2">
                          <Sparkles className="w-4 h-4 text-amber-500" />
                          <span className="text-sm font-medium">
                            Confidence:{" "}
                            {(response.confidence * 100).toFixed(0)}%
                          </span>
                          <Badge
                            variant="outline"
                            className="bg-green-500/10 text-green-500 border-green-500/30"
                          >
                            High
                          </Badge>
                        </div>
                      </div>
                    </TabsContent>
                    <TabsContent value="reasoning" className="mt-4">
                      <div className="space-y-2">
                        {response.reasoning.map((step, i) => (
                          <div
                            key={i}
                            className="reasoning-step flex items-start gap-2 text-sm"
                          >
                            <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0 text-xs font-medium">
                              {i + 1}
                            </div>
                            <span className="text-muted-foreground">
                              {step}
                            </span>
                          </div>
                        ))}
                      </div>
                    </TabsContent>
                    <TabsContent value="stages" className="mt-4">
                      <div className="space-y-2">
                        {response.stageOutputs.map((stage, i) => (
                          <div
                            key={i}
                            className="flex items-center gap-3 p-2 rounded-md bg-muted/50"
                          >
                            <Badge variant="outline" className="text-xs">
                              {stage.stage}
                            </Badge>
                            <span className="text-sm text-muted-foreground">
                              {stage.output}
                            </span>
                          </div>
                        ))}
                      </div>
                    </TabsContent>
                  </Tabs>
                )}
              </CardContent>
            </Card>
          )}
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Model</label>
                <Select value={model} onValueChange={setModel}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="gpt-4">GPT-4</SelectItem>
                    <SelectItem value="gpt-3.5-turbo">GPT-3.5 Turbo</SelectItem>
                    <SelectItem value="claude-3">Claude 3</SelectItem>
                    <SelectItem value="llama-3.1">Llama 3.1</SelectItem>
                    <SelectItem value="mistral-large">
                      Mistral Large
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-1">
                  <Thermometer className="w-3 h-3" />
                  Temperature: {temperature}
                </label>
                <Input
                  type="range"
                  min="0"
                  max="2"
                  step="0.1"
                  value={temperature}
                  onChange={(e) => setTemperature(e.target.value)}
                  className="cursor-pointer"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Max Tokens</label>
                <Input type="number" defaultValue={2048} />
              </div>
              <Separator />
              <div className="space-y-2">
                <label className="text-sm font-medium">
                  Pipeline Signature
                </label>
                <Select defaultValue="default">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="default">
                      Default (question → answer)
                    </SelectItem>
                    <SelectItem value="rag">
                      RAG (context, question → answer)
                    </SelectItem>
                    <SelectItem value="cot">
                      CoT (question → reasoning, answer)
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {response && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Sources</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {response.sources?.map((source) => (
                    <div
                      key={source.id}
                      className="p-2 rounded-md border text-sm"
                    >
                      <p className="text-muted-foreground">{source.content}</p>
                      <Badge variant="outline" className="mt-1 text-xs">
                        Score: {source.score.toFixed(2)}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
