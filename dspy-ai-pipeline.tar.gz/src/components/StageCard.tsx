import { motion } from 'framer-motion'

interface StageInfo {
  id: string
  label: string
  description: string
  color: string
  icon: string
}

interface StageCardProps {
  stage: StageInfo
  isActive: boolean
  isComplete: boolean
  result: any
}

export default function StageCard({ stage, isActive, isComplete, result }: StageCardProps) {
  return (
    <motion.div
      initial={false}
      animate={{
        scale: isActive ? 1.02 : 1,
        borderColor: isActive
          ? stage.color
          : isComplete
            ? '#10b981'
            : 'rgba(51,65,85,0.5)',
      }}
      className={`pipeline-node relative overflow-hidden transition-all ${
        isActive ? 'animate-pulse-glow' : ''
      }`}
    >
      <div
        className="absolute inset-0 opacity-5"
        style={{ background: `linear-gradient(135deg, ${stage.color}, transparent)` }}
      />

      <div className="relative flex items-center gap-4">
        <div
          className={`w-10 h-10 rounded-lg flex items-center justify-center text-lg shrink-0 ${
            isActive
              ? 'bg-primary-500/20'
              : isComplete
                ? 'bg-emerald-500/20'
                : 'bg-surface-700'
          }`}
        >
          {stage.icon}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold">{stage.label}</h3>
            {isActive && (
              <span className="stage-badge bg-primary-500/20 text-primary-300">
                Processing
              </span>
            )}
            {isComplete && !isActive && (
              <span className="stage-badge bg-emerald-500/20 text-emerald-300">
                Complete
              </span>
            )}
          </div>
          <p className="text-xs text-surface-400 mt-0.5">{stage.description}</p>
        </div>

        <div className="text-right shrink-0">
          {isComplete && result && (
            <span className="text-xs text-surface-400">
              {stage.id === 'retrieval' && `${result.documents.length} docs`}
              {stage.id === 'decomposition' && `${result.subQuestions.length} questions`}
              {stage.id === 'synthesis' && `${result.answer.split(' ').length} words`}
              {stage.id === 'verification' &&
                `${result.verifications.filter((v: any) => v.verdict === 'supported').length}/${result.verifications.length} verified`}
            </span>
          )}
        </div>
      </div>

      {isActive && (
        <motion.div
          className="absolute bottom-0 left-0 h-0.5"
          style={{ background: stage.color }}
          initial={{ width: '0%' }}
          animate={{ width: '100%' }}
          transition={{ duration: 2, repeat: Infinity }}
        />
      )}
    </motion.div>
  )
}
