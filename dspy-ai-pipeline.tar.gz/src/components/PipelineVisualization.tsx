import { useStore } from '../store'
import { runPipeline } from '../lib/pipeline'
import StageCard from './StageCard'

const stages = [
  {
    id: 'retrieval',
    label: 'Document Retrieval',
    description: 'Query vector DB for relevant documents',
    color: 'var(--color-retrieval)',
    icon: '🔍',
  },
  {
    id: 'decomposition',
    label: 'Question Decomposition',
    description: 'Break query into sub-questions',
    color: 'var(--color-decomposition)',
    icon: '🧩',
  },
  {
    id: 'synthesis',
    label: 'Answer Synthesis',
    description: 'Compose answer from sub-questions',
    color: 'var(--color-synthesis)',
    icon: '✨',
  },
  {
    id: 'verification',
    label: 'Fact Verification',
    description: 'Verify claims against sources',
    color: 'var(--color-verification)',
    icon: '✅',
  },
]

export default function PipelineVisualization() {
  const stage = useStore((s) => s.stage)
  const query = useStore((s) => s.query)
  const result = useStore((s) => s.result)

  const handleRun = async () => {
    if (!query.trim()) return
    const { dispatch } = await import('../store')
    dispatch({ type: 'SET_STAGE', payload: 'retrieval' })
    dispatch({ type: 'SET_ERROR', payload: '' })
    dispatch({ type: 'RESET_PIPELINE' })
    dispatch({ type: 'SET_STAGE', payload: 'retrieval' })

    try {
      const r = await runPipeline(query, (s) => {
        dispatch({ type: 'SET_STAGE', payload: s as any })
      })
      dispatch({ type: 'SET_RESULT', payload: r })
      dispatch({ type: 'SET_STAGE', payload: 'complete' })
      dispatch({ type: 'ADD_PLAYGROUND_HISTORY', payload: { query, result: r } })
    } catch (e: any) {
      dispatch({ type: 'SET_ERROR', payload: e.message || 'Pipeline failed' })
    }
  }

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="mb-8">
        <div className="flex gap-3">
          <input
            type="text"
            value={query}
            onChange={(e) => {
              import('../store').then(({ dispatch }) =>
                dispatch({ type: 'SET_QUERY', payload: e.target.value })
              )
            }}
            onKeyDown={(e) => e.key === 'Enter' && handleRun()}
            placeholder="Enter your query... (e.g., 'How does DSPy optimize prompts?')"
            className="flex-1 bg-surface-800 border border-surface-600 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-primary-500 focus:ring-1 focus:ring-primary-500 placeholder-surface-500"
          />
          <button
            onClick={handleRun}
            disabled={stage !== 'idle' && stage !== 'complete' && stage !== 'error'}
            className="px-6 py-3 bg-primary-600 hover:bg-primary-700 disabled:bg-surface-700 disabled:text-surface-500 rounded-xl text-sm font-medium transition-colors"
          >
            Run Pipeline
          </button>
        </div>
      </div>

      <div className="flex flex-col gap-4">
        {stages.map((s, i) => (
          <div key={s.id}>
            <StageCard
              stage={s}
              isActive={stage === s.id}
              isComplete={
                stage === 'complete' ||
                stages.findIndex((x) => x.id === stage) > i
              }
              result={result}
            />
            {i < stages.length - 1 && (
              <div className="flex justify-center py-1">
                <div
                  className={`w-0.5 h-6 transition-colors ${
                    stage === 'complete' ||
                    stages.findIndex((x) => x.id === stage) > i
                      ? 'bg-primary-500'
                      : 'bg-surface-700'
                  }`}
                />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
