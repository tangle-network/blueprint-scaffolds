import { Search, Settings, Workflow, Cpu } from 'lucide-react'
import { useStore } from '../store'

interface HeaderProps {
  tab: 'pipeline' | 'playground' | 'config'
  onTabChange: (t: 'pipeline' | 'playground' | 'config') => void
}

export default function Header({ tab, onTabChange }: HeaderProps) {
  const stage = useStore((s) => s.stage)
  const isOptimizing = useStore((s) => s.isOptimizing)

  const stageColor =
    stage === 'idle'
      ? 'bg-surface-600'
      : stage === 'complete'
        ? 'bg-emerald-500'
        : stage === 'error'
          ? 'bg-red-500'
          : 'bg-primary-500 animate-pulse'

  return (
    <header className="glass border-b border-surface-700 px-4 py-3 flex items-center justify-between shrink-0">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <Cpu className="w-6 h-6 text-primary-400" />
          <h1 className="text-lg font-bold tracking-tight">
            DSPy <span className="text-primary-400">Pipeline</span>
          </h1>
        </div>
        <span className={`w-2 h-2 rounded-full ${stageColor}`} />
        {isOptimizing && (
          <span className="text-xs text-amber-400 font-medium animate-pulse">Optimizing...</span>
        )}
      </div>

      <nav className="flex items-center gap-1">
        {[
          { id: 'pipeline' as const, icon: Workflow, label: 'Pipeline' },
          { id: 'playground' as const, icon: Search, label: 'Playground' },
          { id: 'config' as const, icon: Settings, label: 'Config' },
        ].map(({ id, icon: Icon, label }) => (
          <button
            key={id}
            onClick={() => onTabChange(id)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
              tab === id
                ? 'bg-primary-600 text-white'
                : 'text-surface-400 hover:text-surface-200 hover:bg-surface-700'
            }`}
          >
            <Icon className="w-4 h-4" />
            {label}
          </button>
        ))}
      </nav>
    </header>
  )
}
