import { create } from 'zustand'
import type { AppState, AppAction } from './types'

const defaultModules = [
  {
    name: 'Retriever',
    type: 'Predict' as const,
    signature: {
      name: 'DocumentRetrieval',
      inputs: ['query'],
      outputs: ['documents', 'scores'],
      instruction: 'Given a query, retrieve the most relevant documents from the vector database.',
    },
    demos: 3,
  },
  {
    name: 'Decomposer',
    type: 'ChainOfThought' as const,
    signature: {
      name: 'QuestionDecomposition',
      inputs: ['query', 'documents'],
      outputs: ['sub_questions'],
      instruction: 'Break down a complex query into simpler sub-questions that can be answered from the retrieved documents.',
    },
    demos: 5,
  },
  {
    name: 'Synthesizer',
    type: 'ChainOfThought' as const,
    signature: {
      name: 'AnswerSynthesis',
      inputs: ['query', 'sub_questions', 'documents'],
      outputs: ['answer', 'confidence'],
      instruction: 'Synthesize a comprehensive answer from the sub-question answers and retrieved documents.',
    },
    demos: 5,
  },
  {
    name: 'Verifier',
    type: 'ReAct' as const,
    signature: {
      name: 'FactVerification',
      inputs: ['answer', 'documents'],
      outputs: ['verifications', 'overall_confidence'],
      instruction: 'Verify each claim in the answer against the retrieved documents. Assess factual accuracy.',
    },
    demos: 3,
  },
]

const initialState: AppState = {
  stage: 'idle',
  query: '',
  result: null,
  error: null,
  llmBackends: [
    {
      id: 'openai-default',
      name: 'GPT-4o',
      provider: 'openai',
      model: 'gpt-4o',
      apiKey: '',
      maxTokens: 4096,
      temperature: 0.7,
    },
    {
      id: 'anthropic-default',
      name: 'Claude 3.5 Sonnet',
      provider: 'anthropic',
      model: 'claude-3-5-sonnet-20241022',
      apiKey: '',
      maxTokens: 4096,
      temperature: 0.7,
    },
  ],
  activeBackend: 'openai-default',
  vectorDB: {
    provider: 'pinecone',
    indexName: 'dspy-documents',
    apiKey: '',
    environment: 'us-east-1',
    dimension: 1536,
    metric: 'cosine',
  },
  modules: defaultModules,
  optimizationConfig: {
    metric: 'answer_correctness',
    maxBootstrappedDemos: 4,
    maxLabeledDemos: 8,
    maxRounds: 12,
    numCandidates: 6,
    teacherModel: 'gpt-4o',
  },
  isOptimizing: false,
  optimizationProgress: 0,
  playgroundHistory: [],
}

function reducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_STAGE':
      return { ...state, stage: action.payload }
    case 'SET_QUERY':
      return { ...state, query: action.payload }
    case 'SET_RESULT':
      return { ...state, result: action.payload }
    case 'SET_ERROR':
      return { ...state, error: action.payload, stage: 'error' }
    case 'ADD_BACKEND':
      return { ...state, llmBackends: [...state.llmBackends, action.payload] }
    case 'SET_ACTIVE_BACKEND':
      return { ...state, activeBackend: action.payload }
    case 'SET_VECTOR_DB':
      return { ...state, vectorDB: { ...state.vectorDB, ...action.payload } }
    case 'SET_MODULES':
      return { ...state, modules: action.payload }
    case 'SET_OPTIMIZATION_CONFIG':
      return { ...state, optimizationConfig: { ...state.optimizationConfig, ...action.payload } }
    case 'SET_OPTIMIZING':
      return { ...state, isOptimizing: action.payload }
    case 'SET_OPTIMIZATION_PROGRESS':
      return { ...state, optimizationProgress: action.payload }
    case 'ADD_PLAYGROUND_HISTORY':
      return { ...state, playgroundHistory: [...state.playgroundHistory, action.payload] }
    case 'RESET_PIPELINE':
      return { ...state, stage: 'idle', result: null, error: null }
    default:
      return state
  }
}

export const useStore = create<AppState>()(() => initialState)

export function dispatch(action: AppAction) {
  const state = useStore.getState()
  useStore.setState(reducer(state, action))
}
