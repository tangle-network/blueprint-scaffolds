import { ProofRequest, JobPriority } from "./types";
import { generateId } from "./proof-engine";

const jobQueue: ProofRequest[] = [];

const PRIORITY_ORDER: Record<JobPriority, number> = {
  critical: 0,
  high: 1,
  medium: 2,
  low: 3,
};

export function createProofRequest(params: {
  circuitName: string;
  proofType: ProofRequest["proofType"];
  priority: JobPriority;
  constraintCount: number;
  framework: ProofRequest["framework"];
  cost: number;
}): ProofRequest {
  const request: ProofRequest = {
    id: generateId(),
    circuitName: params.circuitName,
    proofType: params.proofType,
    priority: params.priority,
    status: "queued",
    progress: 0,
    submittedAt: new Date().toISOString(),
    cost: params.cost,
    constraintCount: params.constraintCount,
    framework: params.framework,
  };
  jobQueue.push(request);
  sortQueue();
  return request;
}

export function sortQueue(): void {
  jobQueue.sort((a, b) => {
    const pa = PRIORITY_ORDER[a.priority];
    const pb = PRIORITY_ORDER[b.priority];
    if (pa !== pb) return pa - pb;
    return new Date(a.submittedAt).getTime() - new Date(b.submittedAt).getTime();
  });
}

export function getJob(id: string): ProofRequest | undefined {
  return jobQueue.find((j) => j.id === id);
}

export function getAllJobs(): ProofRequest[] {
  return [...jobQueue];
}

export function updateJob(id: string, updates: Partial<ProofRequest>): ProofRequest | undefined {
  const idx = jobQueue.findIndex((j) => j.id === id);
  if (idx === -1) return undefined;
  jobQueue[idx] = { ...jobQueue[idx], ...updates };
  return jobQueue[idx];
}

export function getQueuedJobs(): ProofRequest[] {
  return jobQueue.filter((j) => j.status === "queued");
}

export function getActiveJobs(): ProofRequest[] {
  return jobQueue.filter((j) => !["completed", "failed", "queued"].includes(j.status));
}

export function getCompletedJobs(): ProofRequest[] {
  return jobQueue.filter((j) => j.status === "completed");
}

export function seedMockJobs(): void {
  if (jobQueue.length > 0) return;
  const circuits = [
    { name: "hash-preimage", constraints: 25000, type: "groth16" as const, framework: "circom" as const },
    { name: "merkle-tree-inclusion", constraints: 50000, type: "groth16" as const, framework: "snarkjs" as const },
    { name: "range-proof", constraints: 15000, type: "plonk" as const, framework: "halo2" as const },
    { name: "zk-rollup-batch", constraints: 100000, type: "stark" as const, framework: "cairo" as const },
    { name: "identity-verification", constraints: 30000, type: "groth16" as const, framework: "circom" as const },
    { name: "private-vote", constraints: 10000, type: "plonk" as const, framework: "circom" as const },
    { name: "asset-transfer", constraints: 45000, type: "groth16" as const, framework: "snarkjs" as const },
    { name: "state-update", constraints: 80000, type: "stark" as const, framework: "cairo" as const },
  ];
  const priorities: JobPriority[] = ["low", "medium", "high", "critical"];
  const statuses: ProofRequest["status"][] = [
    "completed", "completed", "completed", "generating_proof",
    "generating_witness", "queued", "queued", "queued",
  ];
  const now = Date.now();
  circuits.forEach((c, i) => {
    const submitted = new Date(now - (circuits.length - i) * 120000);
    const status = statuses[i];
    const progress = status === "completed" ? 100 : status === "queued" ? 0 : Math.floor(Math.random() * 80 + 10);
    jobQueue.push({
      id: generateId(),
      circuitName: c.name,
      proofType: c.type,
      priority: priorities[i % priorities.length],
      status,
      progress,
      submittedAt: submitted.toISOString(),
      startedAt: status !== "queued" ? new Date(submitted.getTime() + 5000).toISOString() : undefined,
      completedAt: status === "completed" ? new Date(submitted.getTime() + 60000).toISOString() : undefined,
      proverNodeId: status !== "queued" ? `node_${String(i + 1).padStart(3, "0")}` : undefined,
      cost: 0.05 + Math.random() * 0.2,
      constraintCount: c.constraints,
      framework: c.framework,
    });
  });
}

seedMockJobs();
