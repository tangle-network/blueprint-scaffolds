import { ProofSystem, ProofResult } from '@/types';

export interface ProofValidator {
  validate(proof: ProofResult): Promise<boolean>;
  verifySystemRequirements(proof: ProofResult): boolean;
}

export interface VerificationKey {
  system: ProofSystem;
  curve: string;
  key: string;
}

const SUPPORTED_CURVES: Record<ProofSystem, string[]> = {
  groth16: ['bn128', 'bls12-381'],
  plonk: ['bn128', 'bls12-381'],
  stark: ['goldilocks', 'babybear'],
};

export function validateProofStructure(proof: ProofResult): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!proof.proof || proof.proof.length < 10) {
    errors.push('Proof data is empty or too short');
  }

  if (!proof.publicSignals || !Array.isArray(proof.publicSignals)) {
    errors.push('Public signals must be an array');
  }

  if (!proof.verifierKey || proof.verifierKey.length < 10) {
    errors.push('Verifier key is missing or invalid');
  }

  if (proof.generationTimeMs <= 0) {
    errors.push('Generation time must be positive');
  }

  if (proof.proofBytes <= 0) {
    errors.push('Proof size must be positive');
  }

  return { valid: errors.length === 0, errors };
}

export function extractProofFields(proof: string, system: ProofSystem): Record<string, string> | null {
  try {
    switch (system) {
      case 'groth16': {
        const parts = proof.split(',');
        return {
          pi_a: parts[0] || '',
          pi_b: parts[1] || '',
          pi_c: parts[2] || '',
        };
      }
      case 'plonk': {
        const parts = proof.split(',');
        return {
          A: parts[0] || '',
          B: parts[1] || '',
          C: parts[2] || '',
          Z: parts[3] || '',
          T1: parts[4] || '',
          T2: parts[5] || '',
          Wxi: parts[6] || '',
          Wxiw: parts[7] || '',
        };
      }
      case 'stark': {
        return {
          traceCommitment: proof.slice(0, 64),
          constraintCommitment: proof.slice(64, 128),
          quotientCommitment: proof.slice(128, 192),
          openingProof: proof.slice(192, 256),
        };
      }
      default:
        return null;
    }
  } catch {
    return null;
  }
}

export function checkCurveCompatibility(system: ProofSystem, curve: string): boolean {
  return SUPPORTED_CURVES[system]?.includes(curve) ?? false;
}

export function validatePublicSignals(signals: string[]): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  for (let i = 0; i < signals.length; i++) {
    const signal = signals[i];
    if (!signal.startsWith('0x')) {
      errors.push(`Signal ${i} must be hex string starting with 0x`);
    }
    if (signal.length < 4) {
      errors.push(`Signal ${i} appears too short`);
    }
  }

  return { valid: errors.length === 0, errors };
}

export function mockVerifyProof(system: ProofSystem): boolean {
  const verificationRates: Record<ProofSystem, number> = {
    groth16: 0.995,
    plonk: 0.993,
    stark: 0.997,
  };
  return Math.random() < verificationRates[system];
}

export async function batchVerifyProofs(
  proofs: ProofResult[]
): Promise<Map<string, boolean>> {
  const results = new Map<string, boolean>();

  await Promise.all(
    proofs.map(async (proof) => {
      const validation = validateProofStructure(proof);
      if (!validation.valid) {
        results.set(proof.proof, false);
        return;
      }
      const verified = mockVerifyProof('groth16');
      results.set(proof.proof, verified);
    })
  );

  return results;
}
