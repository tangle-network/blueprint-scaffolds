import { ProofType, ProofRequest, ProofStatus, ProverNode, ProverStatus } from "./types";

const PROOF_TYPE_CONFIG: Record<ProofType, { baseTime: number; baseCost: number; speedFactor: number }> = {
  groth16: { baseTime: 5000, baseCost: 0.05, speedFactor: 1.0 },
  plonk: { baseTime: 8000, baseCost: 0.08, speedFactor: 0.7 },
  stark: { baseTime: 12000, baseCost: 0.12, speedFactor: 0.5 },
};

export function generateId(): string {
  return `proof_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

export function generateNodeId(): string {
  return `node_${Math.random().toString(36).slice(2, 8)}`;
}

export function simulateProofProgress(
  request: ProofRequest,
  elapsed: number
): { status: ProofStatus; progress: number } {
  const config = PROOF_TYPE_CONFIG[request.proofType];
  const totalTime = config.baseTime * Math.log10(request.constraintCount + 1);
  const ratio = Math.min(elapsed / totalTime, 1);

  if (ratio < 0.2) return { status: "generating_witness", progress: ratio * 100 };
  if (ratio < 0.85) return { status: "generating_proof", progress: ratio * 100 };
  if (ratio < 0.95) return { status: "verifying", progress: ratio * 100 };
  if (ratio >= 1) return { status: "completed", progress: 100 };
  return { status: request.status, progress: request.progress };
}

export function estimateProofTime(proofType: ProofType, constraintCount: number, gpuEnabled: boolean): number {
  const config = PROOF_TYPE_CONFIG[proofType];
  const baseTime = config.baseTime * Math.log10(constraintCount + 1);
  return gpuEnabled ? baseTime * 0.3 : baseTime;
}

export function generateMockProverNodes(): ProverNode[] {
  const nodes: ProverNode[] = [];
  const locations = ["US-East", "US-West", "EU-West", "EU-Central", "AP-Southeast", "AP-Northeast"];
  const proofTypes: ProofType[] = ["groth16", "plonk", "stark"];

  for (let i = 0; i < 8; i++) {
    const status: ProverStatus = i < 2 ? "offline" : i < 5 ? "busy" : "online";
    nodes.push({
      id: generateNodeId(),
      name: `prover-${String(i + 1).padStart(3, "0")}`,
      status,
      proofType: proofTypes[i % 3],
      gpuEnabled: i % 3 === 0,
      currentJobs: status === "offline" ? 0 : Math.floor(Math.random() * 4),
      maxJobs: 8,
      avgProofTime: 2000 + Math.random() * 8000,
      uptime: 95 + Math.random() * 5,
      location: locations[i % locations.length],
      benchmarkScore: 80 + Math.random() * 20,
    });
  }
  return nodes;
}

export function getProofTypeConfig(proofType: ProofType) {
  return PROOF_TYPE_CONFIG[proofType];
}
