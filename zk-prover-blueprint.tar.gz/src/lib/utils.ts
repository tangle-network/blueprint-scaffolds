import {
  ProofRequest,
  CostEstimate,
  CostBreakdown,
  ProofSystem,
  CircuitFramework,
} from '@/types';
import { MOCK_CIRCUITS } from './mock-data';

const BASE_COST = BigInt('10000000000000000');
const COST_PER_CONSTRAINT = BigInt('500000000000');
const COST_PER_PRIORITY = BigInt('2000000000000000');
const GPU_PREMIUM_MULTIPLIER = 1.5;

const TIME_PER_CONSTRAINT: Record<ProofSystem, number> = {
  groth16: 0.15,
  plonk: 0.35,
  stark: 0.65,
};

const FRAMEWORK_MULTIPLIER: Record<CircuitFramework, number> = {
  circom: 1.0,
  halo2: 1.3,
  cairo: 1.5,
};

export function estimateCost(request: ProofRequest): CostEstimate {
  const circuit = MOCK_CIRCUITS.find((c) => c.name === request.circuitName);
  const constraints = circuit?.constraints ?? 50000;

  const constraintCost = Number(BASE_COST) + constraints * Number(COST_PER_CONSTRAINT);
  const witnessCost = constraints * 0.01 * Number(FRAMEWORK_MULTIPLIER[request.framework]);
  const proofCost = constraints * TIME_PER_CONSTRAINT[request.proofSystem];
  const verificationCost = 0.5;
  const complexityCost = witnessCost + proofCost + verificationCost;
  const priorityCost = request.priority * Number(COST_PER_PRIORITY);

  const gpuPremium = BigInt(Math.floor(complexityCost * GPU_PREMIUM_MULTIPLIER * 0.3));

  const totalCost =
    BASE_COST +
    BigInt(Math.floor(constraintCost)) +
    BigInt(Math.floor(complexityCost)) +
    BigInt(Math.floor(priorityCost));

  const estimatedTimeMs = (proofCost + witnessCost) * FRAMEWORK_MULTIPLIER[request.framework] * 1000;

  return {
    baseCost: BASE_COST,
    complexityCost: BigInt(Math.floor(complexityCost)),
    priorityCost: BigInt(Math.floor(priorityCost)),
    gpuPremium,
    totalCost,
    estimatedTimeMs: Math.floor(estimatedTimeMs),
    breakdown: {
      constraintCost: Math.floor(constraintCost),
      witnessCost: Math.floor(witnessCost),
      proofCost: Math.floor(proofCost),
      verificationCost: Math.floor(verificationCost),
    },
  };
}

export function formatTNTC(cost: bigint): string {
  const value = Number(cost) / 1e18;
  if (value >= 1) return `${value.toFixed(4)} TNT`;
  const micro = Number(cost) / 1e12;
  return `${micro.toFixed(2)} μTNT`;
}

export function formatDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
  const minutes = Math.floor(ms / 60000);
  const seconds = Math.floor((ms % 60000) / 1000);
  return `${minutes}m ${seconds}s`;
}

export function formatAddress(address: string): string {
  return `${address.slice(0, 8)}...${address.slice(-6)}`;
}
