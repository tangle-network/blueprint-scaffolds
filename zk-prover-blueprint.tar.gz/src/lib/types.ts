export type ProofType = "groth16" | "plonk" | "stark";

export type ProofStatus = "queued" | "generating_witness" | "generating_proof" | "verifying" | "completed" | "failed";

export type JobPriority = "low" | "medium" | "high" | "critical";

export type ProverStatus = "online" | "busy" | "offline";

export interface ProofRequest {
  id: string;
  circuitName: string;
  proofType: ProofType;
  priority: JobPriority;
  status: ProofStatus;
  progress: number;
  submittedAt: string;
  startedAt?: string;
  completedAt?: string;
  estimatedCompletion?: string;
  proverNodeId?: string;
  cost: number;
  constraintCount: number;
  error?: string;
  framework: "circom" | "snarkjs" | "halo2" | "cairo";
}

export interface ProverNode {
  id: string;
  name: string;
  status: ProverStatus;
  proofType: ProofType;
  gpuEnabled: boolean;
  currentJobs: number;
  maxJobs: number;
  avgProofTime: number;
  uptime: number;
  location: string;
  benchmarkScore: number;
}

export interface NetworkStatus {
  totalProvers: number;
  activeProvers: number;
  totalJobsCompleted: number;
  jobsInProgress: number;
  queuedJobs: number;
  avgProofTime: number;
  networkLoad: number;
  totalRevenue: number;
}

export interface BenchmarkResult {
  proofType: ProofType;
  circuitSize: string;
  constraintCount: number;
  witnessGenTime: number;
  proofGenTime: number;
  verifyTime: number;
  proofSize: number;
  framework: string;
  gpuAccelerated: boolean;
}

export interface CostEstimate {
  proofType: ProofType;
  constraintCount: number;
  priority: JobPriority;
  estimatedCost: number;
  estimatedTime: number;
  gpuSurcharge: number;
  breakdown: {
    baseCost: number;
    complexityMultiplier: number;
    priorityMultiplier: number;
    gpuCost: number;
  };
}

export interface CircuitTemplate {
  name: string;
  description: string;
  framework: "circom" | "snarkjs" | "halo2" | "cairo";
  proofType: ProofType;
  defaultConstraints: number;
  category: string;
}
