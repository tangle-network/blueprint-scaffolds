import { ProofRequest, ProofJob, ProofStatus } from '@/types';
import { getProofNetwork } from './proof-network';
import { estimateCost } from './utils';

export interface SchedulerMetrics {
  totalScheduled: number;
  totalCompleted: number;
  totalFailed: number;
  averageQueueTime: number;
  averageGenerationTime: number;
  throughput: number;
}

class ProofScheduler {
  private metrics: SchedulerMetrics = {
    totalScheduled: 0,
    totalCompleted: 0,
    totalFailed: 0,
    averageQueueTime: 0,
    averageGenerationTime: 0,
    throughput: 0,
  };

  private queue: ProofJob[] = [];
  private processing = false;

  submit(request: ProofRequest): ProofJob {
    const network = getProofNetwork();
    const job = network.submitJob(request);
    this.queue.push(job);
    this.metrics.totalScheduled++;

    if (!this.processing) {
      this.processQueue();
    }

    return job;
  }

  private async processQueue(): Promise<void> {
    this.processing = true;
    const network = getProofNetwork();

    while (this.queue.length > 0) {
      this.queue.sort((a, b) => b.priority - a.priority);
      const job = this.queue.shift()!;

      if (job.status === 'queued') {
        const prover = network.selectProver(job.proofSystem);
        if (!prover) {
          this.queue.unshift(job);
          await new Promise((r) => setTimeout(r, 1000));
          continue;
        }
        job.status = 'assigned';
        job.proverNodeId = prover.id;
      }

      job.status = 'generating';
      job.startedAt = Date.now();

      for (let progress = 10; progress <= 100; progress += 10) {
        await new Promise((r) => setTimeout(r, 50));
        job.progress = progress;
      }

      if (Math.random() < 0.95) {
        job.status = 'completed';
        job.progress = 100;
        job.completedAt = Date.now();
        this.metrics.totalCompleted++;
      } else {
        job.status = 'failed';
        job.error = 'Proof generation failed: constraint timeout';
        this.metrics.totalFailed++;
      }
    }

    this.processing = false;
  }

  getJobStatus(jobId: string): ProofJob | undefined {
    return getProofNetwork().getJobById(jobId);
  }

  getMetrics(): SchedulerMetrics {
    const network = getProofNetwork();
    const stats = network.getQueueStats();
    return {
      ...this.metrics,
      averageGenerationTime: stats.averageGenerationTime,
      throughput: stats.completedJobs > 0 ? stats.completedJobs / (stats.averageGenerationTime / 1000 || 1) : 0,
    };
  }

  cancelJob(jobId: string): boolean {
    const idx = this.queue.findIndex((j) => j.id === jobId);
    if (idx !== -1) {
      const job = this.queue[idx];
      job.status = 'failed';
      job.error = 'Cancelled by user';
      this.queue.splice(idx, 1);
      this.metrics.totalFailed++;
      return true;
    }
    return false;
  }
}

let _scheduler: ProofScheduler | null = null;

export function getScheduler(): ProofScheduler {
  if (!_scheduler) _scheduler = new ProofScheduler();
  return _scheduler;
}

export { ProofScheduler };
