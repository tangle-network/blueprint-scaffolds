import {
  ProofSystem,
  CircuitFramework,
  ProverNode,
  ProofJob,
  ProofRequest,
  ProofResult,
  AggregatedProof,
  QueueStats,
  CostEstimate,
  CircuitMetadata,
} from '@/types';

export interface TangleOperatorConfig {
  operatorId: string;
  stakeAmount: bigint;
  supportedProofSystems: ProofSystem[];
  supportedFrameworks: CircuitFramework[];
  gpuDevices: number;
  maxConcurrentJobs: number;
  heartbeatIntervalMs: number;
  reputation: number;
}

export interface TangleBlueprint {
  id: string;
  name: string;
  description: string;
  version: string;
  author: string;
  operatorConfig: TangleOperatorConfig;
  jobTypes: BlueprintJobType[];
  pricing: BlueprintPricing;
}

export interface BlueprintJobType {
  id: string;
  name: string;
  proofSystem: ProofSystem;
  framework: CircuitFramework;
  maxConstraints: number;
  estimatedTimeMs: number;
}

export interface BlueprintPricing {
  baseFeePerJob: bigint;
  feePerConstraint: bigint;
  priorityMultiplier: Record<number, number>;
  gpuSurcharge: number;
  bulkDiscount: number;
}

const DEFAULT_BLUEPRINT: TangleBlueprint = {
  id: '0xzk-proof-network-v1',
  name: 'ZK Proof Generation Network',
  description: 'Distributed zero-knowledge proof generation using Tangle Blueprints with support for Groth16, PLONK, and STARK proof systems',
  version: '1.0.0',
  author: '0xZKNetwork',
  operatorConfig: {
    operatorId: '',
    stakeAmount: BigInt('100000000000000000000'),
    supportedProofSystems: ['groth16', 'plonk', 'stark'],
    supportedFrameworks: ['circom', 'halo2', 'cairo'],
    gpuDevices: 0,
    maxConcurrentJobs: 8,
    heartbeatIntervalMs: 10000,
    reputation: 100,
  },
  jobTypes: [
    { id: 'groth16-circom', name: 'Groth16 Proof (Circom)', proofSystem: 'groth16', framework: 'circom', maxConstraints: 500000, estimatedTimeMs: 5000 },
    { id: 'groth16-halo2', name: 'Groth16 Proof (Halo2)', proofSystem: 'groth16', framework: 'halo2', maxConstraints: 1000000, estimatedTimeMs: 8000 },
    { id: 'plonk-circom', name: 'PLONK Proof (Circom)', proofSystem: 'plonk', framework: 'circom', maxConstraints: 500000, estimatedTimeMs: 12000 },
    { id: 'plonk-halo2', name: 'PLONK Proof (Halo2)', proofSystem: 'plonk', framework: 'halo2', maxConstraints: 1000000, estimatedTimeMs: 18000 },
    { id: 'stark-cairo', name: 'STARK Proof (Cairo)', proofSystem: 'stark', framework: 'cairo', maxConstraints: 2000000, estimatedTimeMs: 30000 },
  ],
  pricing: {
    baseFeePerJob: BigInt('10000000000000000'),
    feePerConstraint: BigInt('500000000000'),
    priorityMultiplier: { 1: 3.0, 2: 2.5, 3: 2.0, 4: 1.5, 5: 1.0 },
    gpuSurcharge: 1.5,
    bulkDiscount: 0.1,
  },
};

export function getDefaultBlueprint(): TangleBlueprint {
  return { ...DEFAULT_BLUEPRINT };
}

export function createOperatorBlueprint(overrides: Partial<TangleOperatorConfig>): TangleBlueprint {
  const blueprint = getDefaultBlueprint();
  return {
    ...blueprint,
    operatorConfig: { ...blueprint.operatorConfig, ...overrides },
  };
}

export function calculateJobPrice(
  blueprint: TangleBlueprint,
  constraints: number,
  priority: number,
  useGpu: boolean
): CostEstimate {
  const baseCost = blueprint.pricing.baseFeePerJob;
  const complexityCost = BigInt(constraints) * blueprint.pricing.feePerConstraint;
  const priorityMult = blueprint.pricing.priorityMultiplier[priority] ?? 1.0;
  const priorityCost = BigInt(Math.floor(Number(baseCost + complexityCost) * (priorityMult - 1)));
  const gpuPremium = useGpu
    ? BigInt(Math.floor(Number(baseCost) * (blueprint.pricing.gpuSurcharge - 1)))
    : BigInt(0);

  return {
    baseCost,
    complexityCost,
    priorityCost,
    gpuPremium,
    totalCost: baseCost + complexityCost + priorityCost + gpuPremium,
    estimatedTimeMs: constraints * 0.2 * priorityMult * 1000,
    breakdown: {
      constraintCost: Number(complexityCost),
      witnessCost: Math.floor(constraints * 0.01),
      proofCost: Math.floor(constraints * 0.15),
      verificationCost: 500,
    },
  };
}

export function selectOperatorForJob(
  operators: TangleOperatorConfig[],
  proofSystem: ProofSystem,
  framework: CircuitFramework,
  useGpu: boolean
): TangleOperatorConfig | null {
  const eligible = operators.filter(
    (op) =>
      op.supportedProofSystems.includes(proofSystem) &&
      op.supportedFrameworks.includes(framework) &&
      op.maxConcurrentJobs > 0 &&
      (!useGpu || op.gpuDevices > 0)
  );

  if (eligible.length === 0) return null;

  eligible.sort((a, b) => b.reputation - a.reputation);
  return eligible[0];
}
