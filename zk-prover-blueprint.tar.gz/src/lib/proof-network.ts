import {
  ProverNode,
  ProofJob,
  ProofRequest,
  ProofSystem,
  AggregatedProof,
} from '@/types';
import { generateMockProverNodes, generateMockJobs } from './mock-data';

class ProofNetwork {
  private nodes: ProverNode[] = [];
  private jobs: ProofJob[] = [];
  private listeners: Map<string, Array<(job: ProofJob) => void>> = new Map();

  constructor() {
    this.nodes = generateMockProverNodes(8);
    this.jobs = generateMockJobs(15);
  }

  getNodes(): ProverNode[] {
    return this.nodes;
  }

  getOnlineNodes(): ProverNode[] {
    return this.nodes.filter((n) => n.status === 'online' || n.status === 'busy');
  }

  getJobs(): ProofJob[] {
    return this.jobs.sort((a, b) => b.createdAt - a.createdAt);
  }

  getJobById(id: string): ProofJob | undefined {
    return this.jobs.find((j) => j.id === id);
  }

  selectProver(proofSystem: ProofSystem): ProverNode | null {
    const available = this.nodes.filter(
      (n) =>
        (n.status === 'online') &&
        n.supportedSystems.includes(proofSystem) &&
        n.currentJobs < n.maxJobs
    );

    if (available.length === 0) return null;

    available.sort((a, b) => {
      const loadA = a.currentJobs / a.maxJobs;
      const loadB = b.currentJobs / b.maxJobs;
      if (loadA !== loadB) return loadA - loadB;
      return b.reputation - a.reputation;
    });

    return available[0];
  }

  submitJob(request: ProofRequest): ProofJob {
    const prover = this.selectProver(request.proofSystem);
    const job: ProofJob = {
      id: `job-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      circuitName: request.circuitName,
      framework: request.framework,
      proofSystem: request.proofSystem,
      status: prover ? 'assigned' : 'queued',
      priority: request.priority,
      submitter: '0x' + Math.random().toString(16).slice(2, 22),
      createdAt: Date.now(),
      inputSize: Object.keys(request.inputs).length,
      estimatedCost: BigInt('50000000000000000'),
      progress: 0,
      proverNodeId: prover?.id,
    };

    this.jobs.unshift(job);
    return job;
  }

  simulateProgress(jobId: string): ProofJob | null {
    const job = this.jobs.find((j) => j.id === jobId);
    if (!job || job.status === 'completed' || job.status === 'failed') return null;

    const steps: Array<{ status: ProofJob['status']; progress: number }> = [
      { status: 'assigned', progress: 10 },
      { status: 'generating', progress: 30 },
      { status: 'generating', progress: 60 },
      { status: 'verifying', progress: 90 },
      { status: 'completed', progress: 100 },
    ];

    const currentIdx = steps.findIndex(
      (s) => job.progress < s.progress || job.status !== s.status
    );
    const next = steps[Math.min(currentIdx + 1, steps.length - 1)];

    job.status = next.status;
    job.progress = next.progress;

    if (next.status === 'completed') {
      job.completedAt = Date.now();
    }

    return job;
  }

  aggregateProofs(proofIds: string[]): AggregatedProof | null {
    const proofs = proofIds
      .map((id) => this.jobs.find((j) => j.id === id))
      .filter((j) => j?.status === 'completed');

    if (proofs.length === 0) return null;

    return {
      id: `agg-${Date.now()}`,
      proofIds,
      aggregatedProof: '0x' + Buffer.from(Math.random().toString()).toString('hex'),
      verified: true,
      createdAt: Date.now(),
    };
  }

  getQueueStats() {
    const total = this.jobs.length;
    const queued = this.jobs.filter((j) => j.status === 'queued').length;
    const active = this.jobs.filter((j) => j.status === 'generating' || j.status === 'assigned' || j.status === 'verifying').length;
    const completed = this.jobs.filter((j) => j.status === 'completed').length;
    const failed = this.jobs.filter((j) => j.status === 'failed').length;

    const completedJobs = this.jobs.filter((j) => j.status === 'completed' && j.startedAt && j.completedAt);
    const averageGenerationTime = completedJobs.length > 0
      ? completedJobs.reduce((sum, j) => sum + (j.completedAt! - j.startedAt!), 0) / completedJobs.length
      : 0;

    return {
      totalJobs: total,
      queuedJobs: queued,
      activeJobs: active,
      completedJobs: completed,
      failedJobs: failed,
      averageWaitTime: 15000,
      averageGenerationTime,
    };
  }
}

let _instance: ProofNetwork | null = null;

export function getProofNetwork(): ProofNetwork {
  if (!_instance) {
    _instance = new ProofNetwork();
  }
  return _instance;
}

export { ProofNetwork };
