import {
  ProofJob,
  ProofSystem,
  ProofStatus,
  CircuitFramework,
  ProverNode,
  NodeBenchmark,
  CircuitMetadata,
} from '@/types';

const PROOF_SYSTEMS: ProofSystem[] = ['groth16', 'plonk', 'stark'];
const FRAMEWORKS: CircuitFramework[] = ['circom', 'halo2', 'cairo'];

function randomHex(length: number): string {
  let result = '0x';
  for (let i = 0; i < length; i++) {
    result += Math.floor(Math.random() * 16).toString(16);
  }
  return result;
}

function randomId(): string {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

export function generateMockProverNodes(count: number = 8): ProverNode[] {
  const statuses: ProverNode['status'][] = ['online', 'online', 'online', 'busy', 'online', 'offline', 'online', 'busy'];
  return Array.from({ length: count }, (_, i) => {
    const gpuEnabled = Math.random() > 0.4;
    return {
      id: `prover-${randomId()}`,
      address: randomHex(40),
      status: statuses[i % statuses.length],
      supportedSystems: PROOF_SYSTEMS.slice(0, 1 + Math.floor(Math.random() * 3)),
      supportedFrameworks: FRAMEWORKS.slice(0, 1 + Math.floor(Math.random() * 3)),
      gpuEnabled,
      benchmark: {
        groth16Ms: 2000 + Math.floor(Math.random() * 8000),
        plonkMs: 5000 + Math.floor(Math.random() * 15000),
        starkMs: 10000 + Math.floor(Math.random() * 30000),
        witnessGenMs: 500 + Math.floor(Math.random() * 3000),
        gpuSpeedup: gpuEnabled ? 3 + Math.random() * 5 : 1,
      } as NodeBenchmark,
      currentJobs: Math.floor(Math.random() * 4),
      maxJobs: 4 + Math.floor(Math.random() * 4),
      reputation: 80 + Math.floor(Math.random() * 20),
      costPerUnit: BigInt(Math.floor(1e15 * (0.5 + Math.random() * 2))),
      lastHeartbeat: Date.now() - Math.floor(Math.random() * 60000),
    };
  });
}

export function generateMockJobs(count: number = 15): ProofJob[] {
  const circuitNames = [
    'hash-preimage', 'merkle-membership', 'range-proof', 'signature-verification',
    'private-transfer', 'vote-proof', 'identity-credential', 'nullifier',
    'state-transition', 'balance-proof', 'encryption-proof', 'commitment-scheme',
    'randomness-beacon', 'set-membership', 'graph-coloring',
  ];

  const statuses: ProofStatus[] = ['queued', 'assigned', 'generating', 'completed', 'completed', 'completed', 'failed', 'verifying'];
  const now = Date.now();

  return Array.from({ length: count }, (_, i) => {
    const status = statuses[i % statuses.length];
    const framework: CircuitFramework = FRAMEWORKS[i % 3];
    const proofSystem: ProofSystem = PROOF_SYSTEMS[i % 3];
    const createdAt = now - Math.floor(Math.random() * 3600000);
    const startedAt = status === 'queued' ? undefined : createdAt + Math.floor(Math.random() * 30000);
    const completedAt = status === 'completed' || status === 'failed'
      ? startedAt! + Math.floor(Math.random() * 60000)
      : undefined;
    const progress = status === 'completed' ? 100
      : status === 'failed' ? Math.floor(Math.random() * 80)
      : status === 'generating' ? Math.floor(Math.random() * 90)
      : status === 'verifying' ? 95
      : 0;

    return {
      id: `job-${randomId()}`,
      circuitName: circuitNames[i % circuitNames.length],
      framework,
      proofSystem,
      status,
      priority: Math.floor(Math.random() * 10),
      submitter: randomHex(20),
      createdAt,
      startedAt,
      completedAt,
      inputSize: 100 + Math.floor(Math.random() * 10000),
      estimatedCost: BigInt(Math.floor(1e16 * (1 + Math.random() * 10))),
      actualCost: status === 'completed' ? BigInt(Math.floor(1e16 * (1 + Math.random() * 10))) : undefined,
      proverNodeId: status !== 'queued' ? `prover-${randomId()}` : undefined,
      progress,
      eta: status === 'generating' ? Math.floor(Math.random() * 60000) : undefined,
      error: status === 'failed' ? 'Witness generation failed: constraint system unsatisfiable' : undefined,
    } as ProofJob;
  });
}

export const MOCK_CIRCUITS: CircuitMetadata[] = [
  { name: 'hash-preimage', framework: 'circom', constraints: 12544, privateInputs: 1, publicInputs: 1, setupRequired: true, trustedSetup: true },
  { name: 'merkle-membership', framework: 'circom', constraints: 50176, privateInputs: 2, publicInputs: 2, setupRequired: true, trustedSetup: true },
  { name: 'range-proof', framework: 'circom', constraints: 25344, privateInputs: 1, publicInputs: 1, setupRequired: true, trustedSetup: true },
  { name: 'signature-verification', framework: 'circom', constraints: 100352, privateInputs: 2, publicInputs: 2, setupRequired: true, trustedSetup: true },
  { name: 'private-transfer', framework: 'halo2', constraints: 250000, privateInputs: 3, publicInputs: 4, setupRequired: true, trustedSetup: false },
  { name: 'vote-proof', framework: 'halo2', constraints: 150000, privateInputs: 2, publicInputs: 2, setupRequired: true, trustedSetup: false },
  { name: 'identity-credential', framework: 'halo2', constraints: 300000, privateInputs: 4, publicInputs: 3, setupRequired: true, trustedSetup: false },
  { name: 'state-transition', framework: 'cairo', constraints: 500000, privateInputs: 5, publicInputs: 3, setupRequired: false, trustedSetup: false },
  { name: 'nullifier', framework: 'circom', constraints: 8704, privateInputs: 1, publicInputs: 1, setupRequired: true, trustedSetup: true },
  { name: 'set-membership', framework: 'cairo', constraints: 200000, privateInputs: 2, publicInputs: 2, setupRequired: false, trustedSetup: false },
];
