import { ProofSystem, CircuitFramework, ProofJob } from '@/types';

export interface CircuitCacheEntry {
  circuitName: string;
  framework: CircuitFramework;
  compiledCircuit: string;
  provingKey: string;
  verificationKey: string;
  constraints: number;
  cachedAt: number;
  hitCount: number;
}

export interface GPUCapability {
  available: boolean;
  deviceName: string;
  memoryMB: number;
  computeCapability: string;
  currentUtilization: number;
}

export interface WitnessGenConfig {
  parallelThreads: number;
  batchSize: number;
  useGPU: boolean;
  cacheResults: boolean;
}

const CACHE_TTL_MS = 24 * 60 * 60 * 1000;

class CircuitCache {
  private cache = new Map<string, CircuitCacheEntry>();

  get(circuitName: string, framework: CircuitFramework): CircuitCacheEntry | null {
    const key = `${framework}:${circuitName}`;
    const entry = this.cache.get(key);
    if (!entry) return null;
    if (Date.now() - entry.cachedAt > CACHE_TTL_MS) {
      this.cache.delete(key);
      return null;
    }
    entry.hitCount++;
    return entry;
  }

  set(entry: Omit<CircuitCacheEntry, 'cachedAt' | 'hitCount'>): CircuitCacheEntry {
    const key = `${entry.framework}:${entry.circuitName}`;
    const fullEntry: CircuitCacheEntry = {
      ...entry,
      cachedAt: Date.now(),
      hitCount: 0,
    };
    this.cache.set(key, fullEntry);
    return fullEntry;
  }

  invalidate(circuitName: string, framework: CircuitFramework): boolean {
    const key = `${framework}:${circuitName}`;
    return this.cache.delete(key);
  }

  stats() {
    const entries = Array.from(this.cache.values());
    return {
      size: entries.length,
      totalHits: entries.reduce((s, e) => s + e.hitCount, 0),
      avgHitCount: entries.length > 0 ? entries.reduce((s, e) => s + e.hitCount, 0) / entries.length : 0,
    };
  }

  clear() {
    this.cache.clear();
  }
}

let _cache: CircuitCache | null = null;
export function getCircuitCache(): CircuitCache {
  if (!_cache) _cache = new CircuitCache();
  return _cache;
}

export function detectGPUCapabilities(): GPUCapability {
  return {
    available: typeof process !== 'undefined' && process.env.ZK_GPU_ENABLED === 'true',
    deviceName: 'NVIDIA A100 80GB',
    memoryMB: 81920,
    computeCapability: '8.0',
    currentUtilization: Math.floor(Math.random() * 100),
  };
}

export function estimateWitnessGenTime(
  constraints: number,
  config: WitnessGenConfig
): number {
  const baseMsPerConstraint = 0.01;
  const parallelSpeedup = config.useGPU ? 8 : Math.min(config.parallelThreads, 4);
  return Math.floor((constraints * baseMsPerConstraint * 1000) / parallelSpeedup);
}

export function estimateProofGenTime(
  constraints: number,
  proofSystem: ProofSystem,
  useGPU: boolean
): number {
  const baseMs: Record<ProofSystem, number> = {
    groth16: 0.15,
    plonk: 0.35,
    stark: 0.65,
  };
  const gpuSpeedup = useGPU ? 5 : 1;
  return Math.floor((constraints * baseMs[proofSystem] * 1000) / gpuSpeedup);
}

export function estimateProofSize(proofSystem: ProofSystem, publicInputs: number): number {
  const baseBytes: Record<ProofSystem, number> = {
    groth16: 192,
    plonk: 512,
    stark: 2048,
  };
  return baseBytes[proofSystem] + publicInputs * 32;
}

export function calculateCompressionRatio(proofSystem: ProofSystem): number {
  const ratios: Record<ProofSystem, number> = {
    groth16: 0.95,
    plonk: 0.85,
    stark: 0.70,
  };
  return ratios[proofSystem];
}

export function generateBatchETAs(jobs: ProofJob[], proverCapacity: number): Map<string, number> {
  const etas = new Map<string, number>();
  const sorted = [...jobs]
    .filter((j) => j.status === 'queued' || j.status === 'assigned')
    .sort((a, b) => b.priority - a.priority);

  let cumulativeTime = 0;
  const batchSize = Math.max(1, proverCapacity);

  for (let i = 0; i < sorted.length; i++) {
    const job = sorted[i];
    const estimatedJobTime = estimateProofGenTime(
      job.inputSize * 50,
      job.proofSystem,
      false
    );
    const batchPosition = Math.floor(i / batchSize);
    cumulativeTime += estimatedJobTime;

    if (i % batchSize === 0 && i > 0) {
      cumulativeTime = estimatedJobTime;
    }

    etas.set(job.id, cumulativeTime);
  }

  return etas;
}
