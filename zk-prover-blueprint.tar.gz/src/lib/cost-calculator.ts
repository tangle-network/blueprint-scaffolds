import { ProofType, JobPriority, CostEstimate, BenchmarkResult, CircuitTemplate } from "./types";

const PRIORITY_MULTIPLIER: Record<JobPriority, number> = {
  low: 1.0,
  medium: 1.5,
  high: 2.0,
  critical: 3.0,
};

const PROOF_BASE_COST: Record<ProofType, number> = {
  groth16: 0.05,
  plonk: 0.08,
  stark: 0.12,
};

const PROOF_BASE_TIME: Record<ProofType, number> = {
  groth16: 5,
  plonk: 8,
  stark: 12,
};

export function calculateCost(
  proofType: ProofType,
  constraintCount: number,
  priority: JobPriority,
  gpuEnabled: boolean = false
): CostEstimate {
  const baseCost = PROOF_BASE_COST[proofType];
  const complexityMultiplier = Math.log10(constraintCount + 1) / 3;
  const priorityMultiplier = PRIORITY_MULTIPLIER[priority];
  const gpuCost = gpuEnabled ? baseCost * 0.5 : 0;
  const estimatedCost = baseCost * complexityMultiplier * priorityMultiplier + gpuCost;
  const estimatedTime = PROOF_BASE_TIME[proofType] * Math.log10(constraintCount + 1) * (gpuEnabled ? 0.3 : 1);

  return {
    proofType,
    constraintCount,
    priority,
    estimatedCost: Math.round(estimatedCost * 1000) / 1000,
    estimatedTime: Math.round(estimatedTime * 10) / 10,
    gpuSurcharge: gpuCost,
    breakdown: {
      baseCost,
      complexityMultiplier: Math.round(complexityMultiplier * 100) / 100,
      priorityMultiplier,
      gpuCost: Math.round(gpuCost * 1000) / 1000,
    },
  };
}

export function generateBenchmarks(): BenchmarkResult[] {
  const results: BenchmarkResult[] = [];
  const circuits = [
    { size: "Small (1K)", constraints: 1000 },
    { size: "Medium (10K)", constraints: 10000 },
    { size: "Large (100K)", constraints: 100000 },
    { size: "XL (1M)", constraints: 1000000 },
  ];
  const types: ProofType[] = ["groth16", "plonk", "stark"];
  const frameworks: Record<ProofType, string> = { groth16: "Circom/SnarkJS", plonk: "Halo2", stark: "Cairo" };

  for (const circuit of circuits) {
    for (const proofType of types) {
      const base = proofType === "groth16" ? 1 : proofType === "plonk" ? 1.6 : 2.4;
      const factor = Math.log10(circuit.constraints) * base;
      results.push({
        proofType,
        circuitSize: circuit.size,
        constraintCount: circuit.constraints,
        witnessGenTime: Math.round(factor * 200),
        proofGenTime: Math.round(factor * 800),
        verifyTime: Math.round(factor * 10),
        proofSize: Math.round(proofType === "stark" ? factor * 50 : factor * 20),
        framework: frameworks[proofType],
        gpuAccelerated: false,
      });
      results.push({
        proofType,
        circuitSize: circuit.size,
        constraintCount: circuit.constraints,
        witnessGenTime: Math.round(factor * 60),
        proofGenTime: Math.round(factor * 240),
        verifyTime: Math.round(factor * 8),
        proofSize: Math.round(proofType === "stark" ? factor * 45 : factor * 18),
        framework: frameworks[proofType],
        gpuAccelerated: true,
      });
    }
  }
  return results;
}

export function getCircuitTemplates(): CircuitTemplate[] {
  return [
    { name: "hash-preimage", description: "SHA256 preimage proof", framework: "circom", proofType: "groth16", defaultConstraints: 25000, category: "Hashing" },
    { name: "merkle-tree", description: "Merkle tree membership proof", framework: "circom", proofType: "groth16", defaultConstraints: 50000, category: "Trees" },
    { name: "range-proof", description: "Value range verification", framework: "halo2", proofType: "plonk", defaultConstraints: 15000, category: "Arithmetic" },
    { name: "zk-rollup", description: "Batch transaction rollup", framework: "cairo", proofType: "stark", defaultConstraints: 100000, category: "Scaling" },
    { name: "identity", description: "Identity verification proof", framework: "circom", proofType: "groth16", defaultConstraints: 30000, category: "Identity" },
    { name: "private-vote", description: "Anonymous voting proof", framework: "circom", proofType: "plonk", defaultConstraints: 10000, category: "Governance" },
    { name: "asset-transfer", description: "Private asset transfer", framework: "snarkjs", proofType: "groth16", defaultConstraints: 45000, category: "Finance" },
    { name: "state-transition", description: "State transition verification", framework: "cairo", proofType: "stark", defaultConstraints: 80000, category: "Verification" },
  ];
}
