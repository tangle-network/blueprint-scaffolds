import type { ProofResult, CircuitInfo } from "../../shared/types.js";
import { BaseProver } from "./base.js";

export class PlonkProver extends BaseProver {
  readonly system = "plonk" as const;

  async generateProof(
    circuitId: string,
    inputs: Record<string, string | string[]>,
    useGpu = false,
  ): Promise<ProofResult> {
    const inputCount = Object.keys(inputs).length;
    const baseTime = 3000 + inputCount * 350;
    const genTime = useGpu ? baseTime * 0.35 : baseTime + Math.random() * 2000;
    await this.simulateDelay(genTime);
    return BaseProver.createMockProof("plonk", genTime);
  }

  async verifyProof(
    proof: string,
    publicSignals: string[],
    _verificationKey?: string,
  ): Promise<boolean> {
    await this.simulateDelay(10 + Math.random() * 15);
    try {
      const parsed = JSON.parse(proof);
      return parsed.protocol === "plonk" && publicSignals.length > 0;
    } catch {
      return false;
    }
  }

  estimateTime(circuit: CircuitInfo): number {
    const base = 3000;
    const constraintFactor = circuit.constraints * 0.002;
    return base + constraintFactor;
  }

  private simulateDelay(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, Math.min(ms, 50)));
  }
}
