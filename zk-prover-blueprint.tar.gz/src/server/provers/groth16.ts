import type { ProofResult, CircuitInfo } from "../../shared/types.js";
import { BaseProver } from "./base.js";

export class Groth16Prover extends BaseProver {
  readonly system = "groth16" as const;

  async generateProof(
    circuitId: string,
    inputs: Record<string, string | string[]>,
    useGpu = false,
  ): Promise<ProofResult> {
    const inputCount = Object.keys(inputs).length;
    const baseTime = 1500 + inputCount * 200;
    const genTime = useGpu ? baseTime * 0.3 : baseTime + Math.random() * 1000;
    await this.simulateDelay(genTime);
    return BaseProver.createMockProof("groth16", genTime);
  }

  async verifyProof(
    proof: string,
    publicSignals: string[],
    _verificationKey?: string,
  ): Promise<boolean> {
    await this.simulateDelay(5 + Math.random() * 10);
    try {
      const parsed = JSON.parse(proof);
      return parsed.protocol === "groth16" && publicSignals.length > 0;
    } catch {
      return false;
    }
  }

  estimateTime(circuit: CircuitInfo): number {
    const base = 1500;
    const constraintFactor = circuit.constraints * 0.001;
    return base + constraintFactor;
  }

  private simulateDelay(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, Math.min(ms, 50)));
  }
}
