import type {
  ProofResult,
  ProofSystem,
  CircuitInfo,
  ProverNode,
  ProverMetrics,
} from "../../shared/types.js";
import { v4 as uuid } from "uuid";

export abstract class BaseProver {
  abstract readonly system: ProofSystem;
  protected id: string;

  constructor(id?: string) {
    this.id = id ?? uuid();
  }

  getId(): string {
    return this.id;
  }

  abstract generateProof(
    circuitId: string,
    inputs: Record<string, string | string[]>,
    useGpu?: boolean,
  ): Promise<ProofResult>;

  abstract verifyProof(
    proof: string,
    publicSignals: string[],
    verificationKey?: string,
  ): Promise<boolean>;

  abstract estimateTime(circuit: CircuitInfo): number;

  static createMockProof(system: ProofSystem, genTime: number): ProofResult {
    const proofData = JSON.stringify({
      pi_a: [
        "0x" + Buffer.from(uuid()).toString("hex"),
        "0x" + Buffer.from(uuid()).toString("hex"),
        "0x0000000000000000000000000000000000000000000000000000000000000001",
      ],
      pi_b: [
        [
          "0x" + Buffer.from(uuid()).toString("hex"),
          "0x" + Buffer.from(uuid()).toString("hex"),
        ],
        [
          "0x" + Buffer.from(uuid()).toString("hex"),
          "0x" + Buffer.from(uuid()).toString("hex"),
        ],
        [
          "0x0000000000000000000000000000000000000000000000000000000000000001",
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        ],
      ],
      pi_c: [
        "0x" + Buffer.from(uuid()).toString("hex"),
        "0x" + Buffer.from(uuid()).toString("hex"),
        "0x0000000000000000000000000000000000000000000000000000000000000001",
      ],
      protocol: system,
      curve: "bn128",
    });

    const publicSignals = [
      "0x" + Buffer.from(uuid()).toString("hex"),
      "0x0000000000000000000000000000000000000000000000000000000000000001",
    ];

    return {
      proof: proofData,
      publicSignals,
      proofSystem: system,
      verificationKey: "0xvk_" + system + "_" + uuid().slice(0, 8),
      size: Buffer.byteLength(proofData),
      generationTime: genTime,
    };
  }

  static createMockNode(
    id: string,
    systems: ProofSystem[],
    gpu: boolean,
  ): ProverNode {
    return {
      id,
      name: `prover-${id.slice(0, 8)}`,
      endpoint: `https://${id.slice(0, 8)}.prover.zknet.io`,
      status: "online",
      supportedSystems: systems,
      gpuAvailable: gpu,
      maxConcurrentJobs: gpu ? 8 : 4,
      currentJobs: 0,
      performanceMetrics: {
        avgGroth16Time: 2000 + Math.random() * 3000,
        avgPlonkTime: 4000 + Math.random() * 6000,
        avgStarkTime: 6000 + Math.random() * 8000,
        totalProofsGenerated: Math.floor(Math.random() * 10000),
        successRate: 0.95 + Math.random() * 0.05,
        uptime: 0.99,
      } satisfies ProverMetrics,
      costPerUnit: gpu ? 0.002 : 0.001,
      lastHeartbeat: Date.now(),
    };
  }
}
