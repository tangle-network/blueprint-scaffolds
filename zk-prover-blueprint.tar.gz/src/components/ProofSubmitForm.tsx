import React from 'react'

export function ProofSubmitForm({ children }: { children?: React.ReactNode }) { return <div>{children}</div> }
