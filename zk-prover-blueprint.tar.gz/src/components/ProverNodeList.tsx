"use client";

import { ProverNode } from "@/lib/types";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Server, MapPin, Cpu, Gauge, Wifi } from "lucide-react";

const statusVariant: Record<string, "default" | "secondary" | "destructive"> = {
  online: "default",
  busy: "secondary",
  offline: "destructive",
};

export function ProverNodeList({ nodes }: { nodes: ProverNode[] }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {nodes.map((node) => (
        <Card key={node.id}>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-mono">{node.name}</CardTitle>
              <Badge variant={statusVariant[node.status]}>{node.status}</Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-3 text-xs">
            <div className="flex items-center gap-2 text-muted-foreground">
              <MapPin className="h-3 w-3" />
              <span>{node.location}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1 text-muted-foreground">
                <Server className="h-3 w-3" /> {node.proofType.toUpperCase()}
              </span>
              {node.gpuEnabled && (
                <Badge variant="outline" className="text-xs">GPU</Badge>
              )}
            </div>
            <div className="space-y-1">
              <div className="flex justify-between text-muted-foreground">
                <span>Jobs</span>
                <span>{node.currentJobs}/{node.maxJobs}</span>
              </div>
              <Progress value={(node.currentJobs / node.maxJobs) * 100} className="h-1.5" />
            </div>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <div className="flex items-center gap-1 text-muted-foreground">
                <Clock className="h-3 w-3" />
                <span>{(node.avgProofTime / 1000).toFixed(1)}s</span>
              </div>
              <div className="flex items-center gap-1 text-muted-foreground">
                <Gauge className="h-3 w-3" />
                <span>{node.benchmarkScore.toFixed(0)}</span>
              </div>
              <div className="flex items-center gap-1 text-muted-foreground">
                <Wifi className="h-3 w-3" />
                <span>{node.uptime.toFixed(1)}%</span>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function Clock({ className }: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" />
    </svg>
  );
}
