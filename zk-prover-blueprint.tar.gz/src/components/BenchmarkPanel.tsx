import React from 'react'

export function BenchmarkPanel({ children }: { children?: React.ReactNode }) { return <div>{children}</div> }
