"use client";

import { useState } from "react";
import { ProofType, JobPriority, CircuitTemplate } from "@/lib/types";
import { getCircuitTemplates, calculateCost } from "@/lib/cost-calculator";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";

export function ProofSubmissionForm() {
  const templates = getCircuitTemplates();
  const [selectedTemplate, setSelectedTemplate] = useState<string>("");
  const [circuitName, setCircuitName] = useState("");
  const [proofType, setProofType] = useState<ProofType>("groth16");
  const [priority, setPriority] = useState<JobPriority>("medium");
  const [constraintCount, setConstraintCount] = useState(25000);
  const [framework, setFramework] = useState<string>("circom");
  const [gpuEnabled, setGpuEnabled] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleTemplateChange = (name: string) => {
    setSelectedTemplate(name);
    const t = templates.find((t) => t.name === name);
    if (t) {
      setCircuitName(t.name);
      setProofType(t.proofType);
      setConstraintCount(t.defaultConstraints);
      setFramework(t.framework);
    }
  };

  const costEstimate = calculateCost(proofType, constraintCount, priority, gpuEnabled);

  const handleSubmit = async () => {
    try {
      await fetch("/api/proof", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          circuitName: circuitName || "custom-circuit",
          proofType,
          priority,
          constraintCount,
          framework,
          gpuEnabled,
        }),
      });
      setSubmitted(true);
      setTimeout(() => setSubmitted(false), 3000);
    } catch {
      /* handle error */
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Submit Proof Request</CardTitle>
        <CardDescription>Configure and submit a zero-knowledge proof generation job</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <label className="text-sm font-medium">Circuit Template</label>
          <Select value={selectedTemplate} onValueChange={handleTemplateChange}>
            <SelectTrigger><SelectValue placeholder="Select a circuit template" /></SelectTrigger>
            <SelectContent>
              {templates.map((t) => (
                <SelectItem key={t.name} value={t.name}>
                  {t.name} - {t.description}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Circuit Name</label>
            <Input value={circuitName} onChange={(e) => setCircuitName(e.target.value)} placeholder="my-circuit" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Constraint Count</label>
            <Input
              type="number"
              value={constraintCount}
              onChange={(e) => setConstraintCount(Number(e.target.value))}
              min={100}
              max={10000000}
            />
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Proof Type</label>
            <Select value={proofType} onValueChange={(v) => setProofType(v as ProofType)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="groth16">Groth16</SelectItem>
                <SelectItem value="plonk">PLONK</SelectItem>
                <SelectItem value="stark">STARK</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Framework</label>
            <Select value={framework} onValueChange={setFramework}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="circom">Circom</SelectItem>
                <SelectItem value="snarkjs">SnarkJS</SelectItem>
                <SelectItem value="halo2">Halo2</SelectItem>
                <SelectItem value="cairo">Cairo</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Priority</label>
            <Select value={priority} onValueChange={(v) => setPriority(v as JobPriority)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            id="gpu"
            checked={gpuEnabled}
            onChange={(e) => setGpuEnabled(e.target.checked)}
            className="rounded border-input"
          />
          <label htmlFor="gpu" className="text-sm font-medium">
            Enable GPU Acceleration (+50% cost)
          </label>
        </div>

        <Separator />

        <div className="rounded-lg bg-muted/50 p-4 space-y-2">
          <h4 className="font-medium text-sm">Cost Estimate</h4>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <span className="text-muted-foreground">Estimated Cost:</span>
            <span className="font-mono">${costEstimate.estimatedCost.toFixed(4)}</span>
            <span className="text-muted-foreground">Estimated Time:</span>
            <span className="font-mono">{costEstimate.estimatedTime.toFixed(1)}s</span>
            <span className="text-muted-foreground">Base Cost:</span>
            <span className="font-mono">${costEstimate.breakdown.baseCost.toFixed(3)}</span>
            <span className="text-muted-foreground">Complexity Multiplier:</span>
            <span className="font-mono">x{costEstimate.breakdown.complexityMultiplier.toFixed(2)}</span>
            <span className="text-muted-foreground">Priority Multiplier:</span>
            <span className="font-mono">x{costEstimate.breakdown.priorityMultiplier.toFixed(1)}</span>
            {gpuEnabled && (
              <>
                <span className="text-muted-foreground">GPU Surcharge:</span>
                <span className="font-mono">${costEstimate.breakdown.gpuCost.toFixed(3)}</span>
              </>
            )}
          </div>
        </div>

        <Button onClick={handleSubmit} className="w-full" disabled={submitted}>
          {submitted ? "Submitted!" : "Submit Proof Request"}
        </Button>
      </CardContent>
    </Card>
  );
}
