interface MetricsCardsProps {
  totalJobs: number;
  activeJobs: number;
  completedJobs: number;
  onlineNodes: number;
  totalNodes: number;
  avgGenerationTime: number;
  throughput: number;
}

export function MetricsCards({
  totalJobs,
  activeJobs,
  completedJobs,
  onlineNodes,
  totalNodes,
  avgGenerationTime,
  throughput,
}: MetricsCardsProps) {
  const cards = [
    {
      label: 'Total Jobs',
      value: totalJobs.toString(),
      sublabel: `${activeJobs} active`,
      color: 'from-blue-500 to-purple-500',
    },
    {
      label: 'Completed',
      value: completedJobs.toString(),
      sublabel: `${((completedJobs / Math.max(totalJobs, 1)) * 100).toFixed(1)}% success`,
      color: 'from-green-500 to-emerald-500',
    },
    {
      label: 'Active Provers',
      value: `${onlineNodes}/${totalNodes}`,
      sublabel: 'nodes online',
      color: 'from-cyan-500 to-blue-500',
    },
    {
      label: 'Avg Generation',
      value: `${(avgGenerationTime / 1000).toFixed(1)}s`,
      sublabel: 'per proof',
      color: 'from-purple-500 to-pink-500',
    },
    {
      label: 'Throughput',
      value: `${throughput.toFixed(1)}`,
      sublabel: 'proofs/min',
      color: 'from-orange-500 to-red-500',
    },
  ];

  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
      {cards.map((card) => (
        <div key={card.label} className="card">
          <p className="text-xs font-medium uppercase tracking-wider text-[var(--text-secondary)]">
            {card.label}
          </p>
          <p className="mt-2 text-2xl font-bold" style={{
            background: `linear-gradient(135deg, var(--accent), #9090ff)`,
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
          }}>
            {card.value}
          </p>
          <p className="mt-1 text-xs text-[var(--text-secondary)]">{card.sublabel}</p>
        </div>
      ))}
    </div>
  );
}
