"use client";

import { BenchmarkResult } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
} from "recharts";

interface BenchmarkChartProps {
  data: BenchmarkResult[];
}

const COLORS: Record<string, string> = {
  groth16: "#8b5cf6",
  plonk: "#06b6d4",
  stark: "#f59e0b",
};

export function BenchmarkChart({ data }: BenchmarkChartProps) {
  const cpuData = data.filter((d) => !d.gpuAccelerated);
  const gpuData = data.filter((d) => d.gpuAccelerated);

  const proofGenBySize = () => {
    const sizeSet = new Set(cpuData.map((d) => d.circuitSize));
    const sizes = Array.from(sizeSet);
    return sizes.map((size) => {
      const row: Record<string, string | number> = { size };
      for (const pt of ["groth16", "plonk", "stark"]) {
        const match = cpuData.find((d) => d.circuitSize === size && d.proofType === pt);
        if (match) row[pt] = match.proofGenTime;
      }
      return row;
    });
  };

  const gpuVsCpu = () => {
    const sizeSet = new Set(cpuData.map((d) => d.circuitSize));
    const sizes = Array.from(sizeSet);
    return sizes.map((size) => {
      const row: Record<string, string | number> = { size };
      const cpuGroth = cpuData.find((d) => d.circuitSize === size && d.proofType === "groth16");
      const gpuGroth = gpuData.find((d) => d.circuitSize === size && d.proofType === "groth16");
      if (cpuGroth) row["CPU"] = cpuGroth.proofGenTime;
      if (gpuGroth) row["GPU"] = gpuGroth.proofGenTime;
      return row;
    });
  };

  const verifyTimeData = () => {
    const sizeSet = new Set(cpuData.map((d) => d.circuitSize));
    const sizes = Array.from(sizeSet);
    return sizes.map((size) => {
      const row: Record<string, string | number> = { size };
      for (const pt of ["groth16", "plonk", "stark"]) {
        const match = cpuData.find((d) => d.circuitSize === size && d.proofType === pt);
        if (match) row[pt] = match.verifyTime;
      }
      return row;
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Benchmark Results</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="proofgen">
          <TabsList>
            <TabsTrigger value="proofgen">Proof Generation</TabsTrigger>
            <TabsTrigger value="gpu">GPU vs CPU</TabsTrigger>
            <TabsTrigger value="verify">Verification Time</TabsTrigger>
            <TabsTrigger value="size">Proof Size</TabsTrigger>
          </TabsList>
          <TabsContent value="proofgen">
            <div className="h-[400px] mt-4">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={proofGenBySize()}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(217.2, 32.6%, 17.5%)" />
                  <XAxis dataKey="size" stroke="hsl(215, 20.2%, 65.1%)" />
                  <YAxis stroke="hsl(215, 20.2%, 65.1%)" label={{ value: "ms", angle: -90, position: "insideLeft", fill: "hsl(215, 20.2%, 65.1%)" }} />
                  <Tooltip contentStyle={{ backgroundColor: "hsl(222.2, 84%, 4.9%)", border: "1px solid hsl(217.2, 32.6%, 17.5%)" }} />
                  <Legend />
                  <Bar dataKey="groth16" fill={COLORS.groth16} name="Groth16" />
                  <Bar dataKey="plonk" fill={COLORS.plonk} name="PLONK" />
                  <Bar dataKey="stark" fill={COLORS.stark} name="STARK" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
          <TabsContent value="gpu">
            <div className="h-[400px] mt-4">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={gpuVsCpu()}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(217.2, 32.6%, 17.5%)" />
                  <XAxis dataKey="size" stroke="hsl(215, 20.2%, 65.1%)" />
                  <YAxis stroke="hsl(215, 20.2%, 65.1%)" label={{ value: "ms", angle: -90, position: "insideLeft", fill: "hsl(215, 20.2%, 65.1%)" }} />
                  <Tooltip contentStyle={{ backgroundColor: "hsl(222.2, 84%, 4.9%)", border: "1px solid hsl(217.2, 32.6%, 17.5%)" }} />
                  <Legend />
                  <Line type="monotone" dataKey="CPU" stroke="#ef4444" strokeWidth={2} />
                  <Line type="monotone" dataKey="GPU" stroke="#22c55e" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
          <TabsContent value="verify">
            <div className="h-[400px] mt-4">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={verifyTimeData()}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(217.2, 32.6%, 17.5%)" />
                  <XAxis dataKey="size" stroke="hsl(215, 20.2%, 65.1%)" />
                  <YAxis stroke="hsl(215, 20.2%, 65.1%)" label={{ value: "ms", angle: -90, position: "insideLeft", fill: "hsl(215, 20.2%, 65.1%)" }} />
                  <Tooltip contentStyle={{ backgroundColor: "hsl(222.2, 84%, 4.9%)", border: "1px solid hsl(217.2, 32.6%, 17.5%)" }} />
                  <Legend />
                  <Bar dataKey="groth16" fill={COLORS.groth16} name="Groth16" />
                  <Bar dataKey="plonk" fill={COLORS.plonk} name="PLONK" />
                  <Bar dataKey="stark" fill={COLORS.stark} name="STARK" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
          <TabsContent value="size">
            <div className="h-[400px] mt-4">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={cpuData.map((d) => ({
                    name: `${d.circuitSize} (${d.proofType})`,
                    bytes: d.proofSize,
                  }))}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(217.2, 32.6%, 17.5%)" />
                  <XAxis dataKey="name" stroke="hsl(215, 20.2%, 65.1%)" tick={{ fontSize: 10 }} angle={-45} textAnchor="end" height={80} />
                  <YAxis stroke="hsl(215, 20.2%, 65.1%)" label={{ value: "bytes", angle: -90, position: "insideLeft", fill: "hsl(215, 20.2%, 65.1%)" }} />
                  <Tooltip contentStyle={{ backgroundColor: "hsl(222.2, 84%, 4.9%)", border: "1px solid hsl(217.2, 32.6%, 17.5%)" }} />
                  <Bar dataKey="bytes" fill="#8b5cf6" name="Proof Size" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
