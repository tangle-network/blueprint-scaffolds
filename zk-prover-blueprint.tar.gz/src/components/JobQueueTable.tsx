import React from 'react'

export function JobQueueTable({ children }: { children?: React.ReactNode }) { return <div>{children}</div> }
