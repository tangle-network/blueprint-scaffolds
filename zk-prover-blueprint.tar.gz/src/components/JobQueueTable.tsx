"use client";

import { ProofRequest } from "@/lib/types";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const statusColor: Record<string, string> = {
  queued: "secondary",
  generating_witness: "default",
  generating_proof: "default",
  verifying: "default",
  completed: "default",
  failed: "destructive",
};

const priorityColor: Record<string, string> = {
  critical: "destructive",
  high: "default",
  medium: "secondary",
  low: "secondary",
};

export function JobQueueTable({ jobs }: { jobs: ProofRequest[] }) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>ID</TableHead>
          <TableHead>Circuit</TableHead>
          <TableHead>Type</TableHead>
          <TableHead>Framework</TableHead>
          <TableHead>Priority</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Progress</TableHead>
          <TableHead>Constraints</TableHead>
          <TableHead>Cost</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {jobs.length === 0 && (
          <TableRow>
            <TableCell colSpan={9} className="text-center text-muted-foreground py-8">
              No jobs found
            </TableCell>
          </TableRow>
        )}
        {jobs.map((job) => (
          <TableRow key={job.id}>
            <TableCell className="font-mono text-xs">{job.id.slice(0, 16)}...</TableCell>
            <TableCell>{job.circuitName}</TableCell>
            <TableCell>
              <Badge variant="outline" className="uppercase text-xs">
                {job.proofType}
              </Badge>
            </TableCell>
            <TableCell className="text-xs">{job.framework}</TableCell>
            <TableCell>
              <Badge variant={priorityColor[job.priority] as "default" | "secondary" | "destructive"}>
                {job.priority}
              </Badge>
            </TableCell>
            <TableCell>
              <Badge variant={statusColor[job.status] as "default" | "secondary" | "destructive"}>
                {job.status.replace(/_/g, " ")}
              </Badge>
            </TableCell>
            <TableCell className="min-w-[120px]">
              <Progress value={job.progress} className="h-2" />
              <span className="text-xs text-muted-foreground">{job.progress.toFixed(0)}%</span>
            </TableCell>
            <TableCell>{job.constraintCount.toLocaleString()}</TableCell>
            <TableCell>${job.cost.toFixed(3)}</TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
