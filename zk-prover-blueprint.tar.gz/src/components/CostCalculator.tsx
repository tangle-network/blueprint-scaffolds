import React from 'react'

export function CostCalculator({ children }: { children?: React.ReactNode }) { return <div>{children}</div> }
