"use client";

import { useState } from "react";
import { ProofType, JobPriority } from "@/lib/types";
import { calculateCost } from "@/lib/cost-calculator";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Separator } from "@/components/ui/separator";

export function CostCalculator() {
  const [proofType, setProofType] = useState<ProofType>("groth16");
  const [priority, setPriority] = useState<JobPriority>("medium");
  const [constraints, setConstraints] = useState([50000]);
  const [gpuEnabled, setGpuEnabled] = useState(false);

  const estimate = calculateCost(proofType, constraints[0], priority, gpuEnabled);
  const gpuEstimate = calculateCost(proofType, constraints[0], priority, true);
  const cpuEstimate = calculateCost(proofType, constraints[0], priority, false);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Cost Calculator</CardTitle>
          <CardDescription>Estimate the cost and time for proof generation based on circuit complexity</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Proof Type</label>
              <Select value={proofType} onValueChange={(v) => setProofType(v as ProofType)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="groth16">Groth16</SelectItem>
                  <SelectItem value="plonk">PLONK</SelectItem>
                  <SelectItem value="stark">STARK</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Priority</label>
              <Select value={priority} onValueChange={(v) => setPriority(v as JobPriority)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <label className="text-sm font-medium">Constraint Count</label>
              <span className="text-sm font-mono text-muted-foreground">{constraints[0].toLocaleString()}</span>
            </div>
            <Slider
              value={constraints}
              onValueChange={setConstraints}
              min={100}
              max={1000000}
              step={100}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>100</span>
              <span>1,000,000</span>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="gpu-calc"
              checked={gpuEnabled}
              onChange={(e) => setGpuEnabled(e.target.checked)}
              className="rounded"
            />
            <label htmlFor="gpu-calc" className="text-sm">GPU Acceleration</label>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">CPU Estimate</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="text-3xl font-bold">${cpuEstimate.estimatedCost.toFixed(4)}</div>
            <div className="text-sm text-muted-foreground">
              Est. Time: <span className="font-mono">{cpuEstimate.estimatedTime.toFixed(1)}s</span>
            </div>
            <Separator />
            <div className="space-y-1 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">Base</span><span>${cpuEstimate.breakdown.baseCost.toFixed(3)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Complexity</span><span>x{cpuEstimate.breakdown.complexityMultiplier.toFixed(2)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Priority</span><span>x{cpuEstimate.breakdown.priorityMultiplier.toFixed(1)}</span></div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">GPU Estimate</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="text-3xl font-bold">${gpuEstimate.estimatedCost.toFixed(4)}</div>
            <div className="text-sm text-muted-foreground">
              Est. Time: <span className="font-mono">{gpuEstimate.estimatedTime.toFixed(1)}s</span>
            </div>
            <Separator />
            <div className="space-y-1 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">Base</span><span>${gpuEstimate.breakdown.baseCost.toFixed(3)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Complexity</span><span>x{gpuEstimate.breakdown.complexityMultiplier.toFixed(2)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Priority</span><span>x{gpuEstimate.breakdown.priorityMultiplier.toFixed(1)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">GPU</span><span>+${gpuEstimate.breakdown.gpuCost.toFixed(3)}</span></div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Proof Type Comparison</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {(["groth16", "plonk", "stark"] as ProofType[]).map((pt) => {
              const est = calculateCost(pt, constraints[0], priority, gpuEnabled);
              return (
                <div key={pt} className="flex items-center justify-between rounded-lg border p-3">
                  <div>
                    <div className="font-medium">{pt.toUpperCase()}</div>
                    <div className="text-sm text-muted-foreground">
                      {est.estimatedTime.toFixed(1)}s estimated
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-mono font-bold">${est.estimatedCost.toFixed(4)}</div>
                    <div className="text-xs text-muted-foreground">{est.constraintCount.toLocaleString()} constraints</div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
