"use client";

import { NetworkStatus } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Activity, Cpu, DollarSign, Clock, Layers, Server } from "lucide-react";

interface NetworkMetricsProps {
  status: NetworkStatus;
}

export function NetworkMetrics({ status }: NetworkMetricsProps) {
  const metrics = [
    {
      title: "Active Provers",
      value: `${status.activeProvers} / ${status.totalProvers}`,
      icon: Server,
      color: "text-blue-400",
    },
    {
      title: "Jobs in Progress",
      value: status.jobsInProgress,
      icon: Activity,
      color: "text-green-400",
    },
    {
      title: "Queued Jobs",
      value: status.queuedJobs,
      icon: Layers,
      color: "text-yellow-400",
    },
    {
      title: "Jobs Completed",
      value: status.totalJobsCompleted,
      icon: Cpu,
      color: "text-purple-400",
    },
    {
      title: "Avg Proof Time",
      value: `${(status.avgProofTime / 1000).toFixed(1)}s`,
      icon: Clock,
      color: "text-orange-400",
    },
    {
      title: "Network Load",
      value: `${status.networkLoad.toFixed(0)}%`,
      icon: Activity,
      color: "text-cyan-400",
    },
    {
      title: "Total Revenue",
      value: `$${status.totalRevenue.toFixed(2)}`,
      icon: DollarSign,
      color: "text-emerald-400",
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
      {metrics.map((m) => (
        <Card key={m.title}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{m.title}</CardTitle>
            <m.icon className={`h-4 w-4 ${m.color}`} />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{m.value}</div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
