import { NetworkMetrics } from "@/components/NetworkMetrics";
import { ProverNodeList } from "@/components/ProverNodeList";
import { JobQueueTable } from "@/components/JobQueueTable";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, Zap, Globe, Lock } from "lucide-react";

async function getNetworkStatus() {
  const baseUrl = process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : "http://localhost:3000";
  try {
    const res = await fetch(`${baseUrl}/api/status`, { cache: "no-store" });
    return res.json();
  } catch {
    return {
      totalProvers: 8,
      activeProvers: 6,
      totalJobsCompleted: 3,
      jobsInProgress: 2,
      queuedJobs: 3,
      avgProofTime: 5000,
      networkLoad: 15,
      totalRevenue: 0.45,
      proverNodes: [],
    };
  }
}

async function getJobs() {
  const baseUrl = process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : "http://localhost:3000";
  try {
    const res = await fetch(`${baseUrl}/api/jobs`, { cache: "no-store" });
    const data = await res.json();
    return data.jobs || [];
  } catch {
    return [];
  }
}

export default async function DashboardPage() {
  const [status, jobsData] = await Promise.all([getNetworkStatus(), getJobs()]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">ZK Proof Network Dashboard</h1>
        <p className="text-muted-foreground mt-1">
          Distributed zero-knowledge proof generation network powered by Tangle Blueprints
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Trusted Setup</CardTitle>
            <Shield className="h-4 w-4 text-purple-400" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold">Groth16 + PLONK</div>
            <p className="text-xs text-muted-foreground">Multi-proof support</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">GPU Acceleration</CardTitle>
            <Zap className="h-4 w-4 text-yellow-400" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold">3x Faster</div>
            <p className="text-xs text-muted-foreground">CUDA/OpenCL enabled</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Global Network</CardTitle>
            <Globe className="h-4 w-4 text-blue-400" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold">6 Regions</div>
            <p className="text-xs text-muted-foreground">Distributed provers</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Recursive Proofs</CardTitle>
            <Lock className="h-4 w-4 text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold">Halo2 + STARK</div>
            <p className="text-xs text-muted-foreground">Proof composition</p>
          </CardContent>
        </Card>
      </div>

      <NetworkMetrics status={status} />

      <Card>
        <CardHeader>
          <CardTitle>Prover Nodes</CardTitle>
          <CardDescription>Distributed prover nodes across the network</CardDescription>
        </CardHeader>
        <CardContent>
          <ProverNodeList nodes={status.proverNodes || []} />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Recent Jobs</CardTitle>
              <CardDescription>Latest proof generation jobs</CardDescription>
            </div>
            <Badge variant="outline">{jobsData.length} total</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <JobQueueTable jobs={jobsData.slice(0, 5)} />
        </CardContent>
      </Card>
    </div>
  );
}
