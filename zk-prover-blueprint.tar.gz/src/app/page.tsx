import { MetricsCards } from '@/components/MetricsCards';
import { JobQueueTable } from '@/components/JobQueueTable';
import { ProverNodesPanel } from '@/components/ProverNodesPanel';
import { ProofSubmitForm } from '@/components/ProofSubmitForm';
import { CostCalculator } from '@/components/CostCalculator';
import { BenchmarkPanel } from '@/components/BenchmarkPanel';
import { generateMockProverNodes, generateMockJobs, MOCK_CIRCUITS } from '@/lib/mock-data';

export default function Home() {
  const nodes = generateMockProverNodes(8);
  const jobs = generateMockJobs(15);
  const onlineNodes = nodes.filter((n) => n.status === 'online' || n.status === 'busy');
  const completedJobs = jobs.filter((j) => j.status === 'completed');
  const activeJobs = jobs.filter((j) => ['assigned', 'generating', 'verifying'].includes(j.status));

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-[var(--text-primary)]">Dashboard</h2>
        <p className="mt-1 text-[var(--text-secondary)]">
          Distributed ZK proof generation network status and management
        </p>
      </div>

      <MetricsCards
        totalJobs={jobs.length}
        activeJobs={activeJobs.length}
        completedJobs={completedJobs.length}
        onlineNodes={onlineNodes.length}
        totalNodes={nodes.length}
        avgGenerationTime={12500}
        throughput={8.5}
      />

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <JobQueueTable jobs={jobs} />
        </div>
        <div>
          <ProverNodesPanel nodes={nodes} />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
        <ProofSubmitForm circuits={MOCK_CIRCUITS} />
        <CostCalculator circuits={MOCK_CIRCUITS} />
      </div>

      <BenchmarkPanel />
    </div>
  );
}
