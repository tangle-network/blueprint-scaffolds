import { BenchmarkChart } from "@/components/BenchmarkChart";
import { generateBenchmarks } from "@/lib/cost-calculator";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function BenchmarksPage() {
  const benchmarks = generateBenchmarks();
  const cpuData = benchmarks.filter((b) => !b.gpuAccelerated);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Benchmarks</h1>
        <p className="text-muted-foreground mt-1">
          Performance metrics for different proof types and circuit sizes
        </p>
      </div>

      <BenchmarkChart data={benchmarks} />

      <Card>
        <CardHeader>
          <CardTitle>Detailed Results (CPU)</CardTitle>
          <CardDescription>Benchmark results for CPU-based proof generation</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Proof Type</TableHead>
                <TableHead>Circuit Size</TableHead>
                <TableHead>Framework</TableHead>
                <TableHead>Witness Gen (ms)</TableHead>
                <TableHead>Proof Gen (ms)</TableHead>
                <TableHead>Verify (ms)</TableHead>
                <TableHead>Proof Size (bytes)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {cpuData.map((b, i) => (
                <TableRow key={i}>
                  <TableCell className="font-medium uppercase text-xs">{b.proofType}</TableCell>
                  <TableCell>{b.circuitSize}</TableCell>
                  <TableCell>{b.framework}</TableCell>
                  <TableCell>{b.witnessGenTime.toLocaleString()}</TableCell>
                  <TableCell>{b.proofGenTime.toLocaleString()}</TableCell>
                  <TableCell>{b.verifyTime.toLocaleString()}</TableCell>
                  <TableCell>{b.proofSize.toLocaleString()}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
