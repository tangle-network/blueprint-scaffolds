import { CostCalculator } from "@/components/CostCalculator";

export default function CalculatorPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Cost Calculator</h1>
        <p className="text-muted-foreground mt-1">
          Estimate costs and time for different proof generation configurations
        </p>
      </div>
      <CostCalculator />
    </div>
  );
}
