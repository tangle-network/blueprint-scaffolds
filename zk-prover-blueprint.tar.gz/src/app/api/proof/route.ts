import { NextResponse } from "next/server";
import { createProofRequest } from "@/lib/job-manager";
import { calculateCost } from "@/lib/cost-calculator";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { circuitName, proofType, priority, constraintCount, framework, gpuEnabled } = body;

    if (!circuitName || !proofType || !priority || !constraintCount || !framework) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    const cost = calculateCost(proofType, constraintCount, priority, gpuEnabled);
    const proofRequest = createProofRequest({
      circuitName,
      proofType,
      priority,
      constraintCount,
      framework,
      cost: cost.estimatedCost,
    });

    return NextResponse.json(proofRequest, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }
}
