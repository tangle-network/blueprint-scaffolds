import { NextResponse } from "next/server";
import { generateBenchmarks } from "@/lib/cost-calculator";

export async function GET() {
  const benchmarks = generateBenchmarks();
  return NextResponse.json(benchmarks);
}
