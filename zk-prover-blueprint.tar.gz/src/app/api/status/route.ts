import { NextResponse } from "next/server";
import { generateMockProverNodes } from "@/lib/proof-engine";
import { getAllJobs, getActiveJobs, getQueuedJobs, getCompletedJobs } from "@/lib/job-manager";

export async function GET() {
  const nodes = generateMockProverNodes();
  const allJobs = getAllJobs();
  const active = getActiveJobs();
  const queued = getQueuedJobs();
  const completed = getCompletedJobs();
  const onlineNodes = nodes.filter((n) => n.status !== "offline");

  const totalRevenue = completed.reduce((sum, j) => sum + j.cost, 0);

  return NextResponse.json({
    totalProvers: nodes.length,
    activeProvers: onlineNodes.length,
    totalJobsCompleted: completed.length,
    jobsInProgress: active.length,
    queuedJobs: queued.length,
    avgProofTime: onlineNodes.reduce((s, n) => s + n.avgProofTime, 0) / (onlineNodes.length || 1),
    networkLoad: (active.length / (onlineNodes.length * 8)) * 100,
    totalRevenue: Math.round(totalRevenue * 1000) / 1000,
    proverNodes: nodes,
  });
}
