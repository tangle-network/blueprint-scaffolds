import { NextResponse } from "next/server";
import { getAllJobs, getQueuedJobs, getActiveJobs, getCompletedJobs } from "@/lib/job-manager";

export async function GET() {
  const all = getAllJobs();
  const queued = getQueuedJobs();
  const active = getActiveJobs();
  const completed = getCompletedJobs();

  return NextResponse.json({
    jobs: all,
    summary: {
      total: all.length,
      queued: queued.length,
      active: active.length,
      completed: completed.length,
    },
  });
}
