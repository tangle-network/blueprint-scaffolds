import { ProofSubmissionForm } from "@/components/ProofSubmissionForm";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function ProofsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Submit Proof</h1>
        <p className="text-muted-foreground mt-1">
          Configure and submit a zero-knowledge proof generation request
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <ProofSubmissionForm />
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Supported Frameworks</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { name: "Circom", desc: "Circuit description language for R1CS", proof: "Groth16/PLONK" },
                { name: "SnarkJS", desc: "JavaScript zk-SNARK library", proof: "Groth16" },
                { name: "Halo2", desc: "Recursive proof composition", proof: "PLONK" },
                { name: "Cairo", desc: "Turing-complete STARK language", proof: "STARK" },
              ].map((fw) => (
                <div key={fw.name} className="rounded-lg border p-3">
                  <div className="font-medium">{fw.name}</div>
                  <div className="text-xs text-muted-foreground">{fw.desc}</div>
                  <div className="text-xs mt-1 text-primary">{fw.proof}</div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Proof Types</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { name: "Groth16", desc: "Smallest proof size, requires trusted setup", time: "~5s" },
                { name: "PLONK", desc: "Universal setup, slightly larger proofs", time: "~8s" },
                { name: "STARK", desc: "Transparent setup, largest proofs, quantum-resistant", time: "~12s" },
              ].map((pt) => (
                <div key={pt.name} className="rounded-lg border p-3">
                  <div className="flex justify-between">
                    <div className="font-medium">{pt.name}</div>
                    <span className="text-xs text-muted-foreground">{pt.time}</span>
                  </div>
                  <div className="text-xs text-muted-foreground">{pt.desc}</div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
