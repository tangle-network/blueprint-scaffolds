import { JobQueueTable } from "@/components/JobQueueTable";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getAllJobs, getQueuedJobs, getActiveJobs, getCompletedJobs } from "@/lib/job-manager";

export default function JobsPage() {
  const allJobs = getAllJobs();
  const queued = getQueuedJobs();
  const active = getActiveJobs();
  const completed = getCompletedJobs();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Job Queue</h1>
        <p className="text-muted-foreground mt-1">
          Monitor proof generation jobs and their status
        </p>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Jobs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{allJobs.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Queued</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-400">{queued.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">In Progress</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-400">{active.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Completed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400">{completed.length}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>All Jobs</CardTitle>
              <CardDescription>Complete job queue with priority scheduling</CardDescription>
            </div>
            <div className="flex gap-2">
              <Badge variant="secondary">{queued.length} queued</Badge>
              <Badge variant="default">{active.length} active</Badge>
              <Badge variant="outline">{completed.length} done</Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <JobQueueTable jobs={allJobs} />
        </CardContent>
      </Card>
    </div>
  );
}
