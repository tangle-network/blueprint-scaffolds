import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'ZK Proof Network - Distributed Proof Generation',
  description: 'Distributed zero-knowledge proof generation network using Tangle Blueprints',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-[var(--bg-primary)]">
        <nav className="border-b border-[var(--border-color)] bg-[var(--bg-secondary)]">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex h-16 items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[var(--accent)]">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <polygon points="12 2 22 8.5 22 15.5 12 22 2 15.5 2 8.5 12 2" />
                    <line x1="12" y1="22" x2="12" y2="15.5" />
                    <polyline points="22 8.5 12 15.5 2 8.5" />
                  </svg>
                </div>
                <div>
                  <h1 className="text-lg font-bold text-[var(--text-primary)]">ZK Proof Network</h1>
                  <p className="text-xs text-[var(--text-secondary)]">Powered by Tangle Blueprints</p>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-green-400"></span>
                  <span className="text-sm text-[var(--text-secondary)]">Network Online</span>
                </div>
                <div className="rounded-lg bg-[var(--bg-card)] px-3 py-1.5 text-sm text-[var(--text-secondary)]">
                  8 Provers Active
                </div>
              </div>
            </div>
          </div>
        </nav>
        <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          {children}
        </main>
        <footer className="border-t border-[var(--border-color)] py-6 text-center text-sm text-[var(--text-secondary)]">
          ZK Proof Generation Network &middot; Built on Tangle Blueprints &middot; {new Date().getFullYear()}
        </footer>
      </body>
    </html>
  );
}
