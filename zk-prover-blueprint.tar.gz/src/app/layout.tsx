import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Link from "next/link";
import { Shield } from "lucide-react";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "ZK Proof Generation Network",
  description: "Distributed zero-knowledge proof generation network powered by Tangle Blueprints",
};

function Navbar() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center px-4 mx-auto">
        <Link href="/" className="flex items-center space-x-2 mr-8">
          <Shield className="h-6 w-6 text-primary" />
          <span className="font-bold text-lg">ZK Proof Net</span>
        </Link>
        <nav className="flex items-center space-x-6 text-sm font-medium">
          <NavLink href="/">Dashboard</NavLink>
          <NavLink href="/proofs">Submit Proof</NavLink>
          <NavLink href="/jobs">Job Queue</NavLink>
          <NavLink href="/benchmarks">Benchmarks</NavLink>
          <NavLink href="/calculator">Calculator</NavLink>
        </nav>
      </div>
    </header>
  );
}

function NavLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link
      href={href}
      className="transition-colors hover:text-foreground/80 text-foreground/60"
    >
      {children}
    </Link>
  );
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body className={inter.className}>
        <Navbar />
        <main className="container mx-auto px-4 py-6">{children}</main>
      </body>
    </html>
  );
}
