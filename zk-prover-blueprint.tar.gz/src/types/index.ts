export type ProofSystem = 'groth16' | 'plonk' | 'stark';

export type ProofStatus = 'queued' | 'assigned' | 'generating' | 'completed' | 'failed' | 'verifying';

export type CircuitFramework = 'circom' | 'halo2' | 'cairo';

export interface ProofJob {
  id: string;
  circuitName: string;
  framework: CircuitFramework;
  proofSystem: ProofSystem;
  status: ProofStatus;
  priority: number;
  submitter: string;
  createdAt: number;
  startedAt?: number;
  completedAt?: number;
  inputSize: number;
  estimatedCost: bigint;
  actualCost?: bigint;
  proverNodeId?: string;
  progress: number;
  eta?: number;
  error?: string;
  proofResult?: ProofResult;
}

export interface ProofResult {
  proof: string;
  publicSignals: string[];
  verifierKey: string;
  proofBytes: number;
  generationTimeMs: number;
  verified: boolean;
}

export interface ProverNode {
  id: string;
  address: string;
  status: 'online' | 'offline' | 'busy';
  supportedSystems: ProofSystem[];
  supportedFrameworks: CircuitFramework[];
  gpuEnabled: boolean;
  benchmark: NodeBenchmark;
  currentJobs: number;
  maxJobs: number;
  reputation: number;
  costPerUnit: bigint;
  lastHeartbeat: number;
}

export interface NodeBenchmark {
  groth16Ms: number;
  plonkMs: number;
  starkMs: number;
  witnessGenMs: number;
  gpuSpeedup: number;
}

export interface CircuitMetadata {
  name: string;
  framework: CircuitFramework;
  constraints: number;
  privateInputs: number;
  publicInputs: number;
  setupRequired: boolean;
  trustedSetup: boolean;
}

export interface ProofRequest {
  circuitName: string;
  framework: CircuitFramework;
  proofSystem: ProofSystem;
  priority: number;
  inputs: Record<string, string | string[]>;
  callbackUrl?: string;
}

export interface CostEstimate {
  baseCost: bigint;
  complexityCost: bigint;
  priorityCost: bigint;
  gpuPremium: bigint;
  totalCost: bigint;
  estimatedTimeMs: number;
  breakdown: CostBreakdown;
}

export interface CostBreakdown {
  constraintCost: number;
  witnessCost: number;
  proofCost: number;
  verificationCost: number;
}

export interface QueueStats {
  totalJobs: number;
  queuedJobs: number;
  activeJobs: number;
  completedJobs: number;
  failedJobs: number;
  averageWaitTime: number;
  averageGenerationTime: number;
}

export interface AggregatedProof {
  id: string;
  proofIds: string[];
  aggregatedProof: string;
  verified: boolean;
  createdAt: number;
}
