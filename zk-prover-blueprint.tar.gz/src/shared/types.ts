export type ProofSystem = "groth16" | "plonk" | "stark";

export type JobStatus =
  | "queued"
  | "assigned"
  | "generating_witness"
  | "generating_proof"
  | "verifying"
  | "completed"
  | "failed";

export type JobPriority = "low" | "medium" | "high" | "urgent";

export interface ProofJob {
  id: string;
  status: JobStatus;
  proofSystem: ProofSystem;
  circuitId: string;
  inputs: Record<string, string | string[]>;
  priority: JobPriority;
  submittedAt: number;
  startedAt?: number;
  completedAt?: number;
  assignedProver?: string;
  proof?: ProofResult;
  error?: string;
  estimatedCost: number;
  actualCost?: number;
  progress: number;
  eta?: number;
}

export interface ProofResult {
  proof: string;
  publicSignals: string[];
  proofSystem: ProofSystem;
  verificationKey?: string;
  size: number;
  generationTime: number;
}

export interface ProverNode {
  id: string;
  name: string;
  endpoint: string;
  status: "online" | "offline" | "busy";
  supportedSystems: ProofSystem[];
  gpuAvailable: boolean;
  maxConcurrentJobs: number;
  currentJobs: number;
  performanceMetrics: ProverMetrics;
  costPerUnit: number;
  lastHeartbeat: number;
}

export interface ProverMetrics {
  avgGroth16Time: number;
  avgPlonkTime: number;
  avgStarkTime: number;
  totalProofsGenerated: number;
  successRate: number;
  uptime: number;
}

export interface CircuitInfo {
  id: string;
  name: string;
  proofSystem: ProofSystem;
  constraints: number;
  privateInputs: number;
  publicInputs: number;
  setupComplete: boolean;
  description: string;
}

export interface CostEstimate {
  proofSystem: ProofSystem;
  constraints: number;
  estimatedTime: number;
  estimatedCost: number;
  gpuAcceleration: boolean;
  breakdown: CostBreakdown;
}

export interface CostBreakdown {
  witnessGeneration: number;
  proofGeneration: number;
  verification: number;
  networkOverhead: number;
  total: number;
}

export interface JobSubmission {
  circuitId: string;
  proofSystem: ProofSystem;
  inputs: Record<string, string | string[]>;
  priority?: JobPriority;
  gpuRequired?: boolean;
  callbackUrl?: string;
}

export interface AggregatedProof {
  id: string;
  proofIds: string[];
  proofSystem: ProofSystem;
  aggregatedProof: string;
  verificationKey: string;
  batchSize: number;
  generationTime: number;
}

export interface BenchmarkResult {
  proofSystem: ProofSystem;
  circuitId: string;
  constraintCount: number;
  witnessGenerationTime: number;
  proofGenerationTime: number;
  verificationTime: number;
  proofSize: number;
  peakMemory: number;
  gpuUsed: boolean;
  timestamp: number;
}

export interface NetworkStats {
  totalProvers: number;
  activeProvers: number;
  queuedJobs: number;
  activeJobs: number;
  completedJobs: number;
  failedJobs: number;
  avgProofTime: number;
  totalThroughput: number;
}

export interface TangleBlueprint {
  id: string;
  name: string;
  description: string;
  author: string;
  version: string;
  jobTypes: TangleJobType[];
}

export interface TangleJobType {
  id: string;
  name: string;
  description: string;
  proofSystem: ProofSystem;
  paramsSchema: Record<string, unknown>;
  resultSchema: Record<string, unknown>;
  xdmArgs: TangleXdmArg[];
}

export interface TangleXdmArg {
  name: string;
  ty: string;
  desc: string;
}

export type TangleJobResult = {
  jobId: string;
  result: ProofResult;
  proverId: string;
  timestamp: number;
};
