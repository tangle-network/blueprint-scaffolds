/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        zk: {
          50: '#f0f0ff',
          100: '#e0e0ff',
          200: '#c0c0ff',
          300: '#9090ff',
          400: '#6060ff',
          500: '#4040dd',
          600: '#3030bb',
          700: '#202099',
          800: '#101077',
          900: '#080855',
        },
      },
    },
  },
  plugins: [],
};
