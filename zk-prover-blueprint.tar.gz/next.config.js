/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  experimental: {
    serverComponentsExternalPackages: ['snarkjs', 'ffjavascript'],
  },
};

module.exports = nextConfig;
