# AGENTS.md

## Goal

Build a distributed ZK proof generation network using Tangle Blueprints. Proof request submission, operator assignment, verification.

## Stack

- Family: `tangle-blueprint`
- Layers: 
- Partner: `tangle`

## Entry Points

- `zk-prover-blueprint-bin/src/main.rs`
- `zk-prover-blueprint-lib/src/lib.rs`
- `blueprint.json`
- `contracts/src/HelloBlueprint.sol`
- `Cargo.toml`

## Commands

- `cargo test -p zk-prover-blueprint-lib`
- `cargo build --release`

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
