# ZK Proof Generation Network - Build Plan

## Architecture
- Next.js 14 App Router with TypeScript
- Tailwind CSS + shadcn/ui for UI
- Recharts for data visualization
- Simulated ZK proof engine (real architecture, simulated computation)

## Pages
- `/` - Dashboard overview with network stats, active jobs, prover nodes
- `/proofs` - Submit proof generation requests
- `/jobs` - Monitor job queue and status
- `/benchmarks` - Performance metrics and benchmark results
- `/calculator` - Cost calculator for different proof types

## API Routes
- `POST /api/proof` - Submit proof generation request
- `GET /api/proof/[id]` - Get proof status
- `GET /api/jobs` - List all jobs
- `GET /api/status` - Network status & prover nodes
- `GET /api/benchmarks` - Benchmark results

## Components
- shadcn/ui: button, card, input, select, badge, tabs, progress, table, dialog, slider, separator, tooltip
- Custom: JobQueueTable, ProofSubmissionForm, NetworkMetrics, CostCalculator, ProverNodeList, BenchmarkChart

## Lib
- `utils.ts` - cn() helper
- `types.ts` - TypeScript interfaces
- `proof-engine.ts` - Simulated ZK proof engine with Groth16/PLONK/STARK support
- `job-manager.ts` - Job queue with priority scheduling
- `cost-calculator.ts` - Cost estimation based on circuit complexity

## Build & Test
- `npm run build` must pass with zero errors
