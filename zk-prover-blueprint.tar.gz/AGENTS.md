# AGENTS.md

Build a distributed ZK proof generation network using Tangle Blueprints. Proof request submission, operator assignment, verification.

## What's here

This project was scaffolded by starter-foundry. The user's prompt drove the choices below — read their prompt first, it takes priority over everything in this file.

- **Family:** `tangle-blueprint`
- **Layers:** `framework:tangle-blueprint`
- **Partner:** `tangle`

## Getting started

```bash
cargo test -p zk-prover-blueprint-lib
cargo build --release
```

Key files: `zk-prover-blueprint-bin/src/main.rs`, `zk-prover-blueprint-lib/src/lib.rs`, `blueprint.json`, `contracts/src/HelloBlueprint.sol`, `Cargo.toml`

## How to use this scaffold

This is a starting point, not a contract. You own every file.

- **Customize freely.** Replace components, change the layout, swap the color scheme — whatever fits the user's product.
- **The scaffold saves you setup time** — Tailwind, shadcn/ui, path aliases, and framework config are ready. Don't redo them.
- **Check `.starter-foundry/compose-report.json`** if you want to see which layer wrote which file.
- **Update this file** as the project evolves. Delete sections that no longer apply.
