import type { ArchitectureNode, ContractSnippet, Metric, Operator, Route, SecurityStep } from './types';

export const metrics: Metric[] = [
  { label: 'Quorum threshold', value: '7 / 10 operators', description: 'Weighted by delegated AVS stake.' },
  { label: 'Challenge period', value: '30 minutes', description: 'Disputes can pause execution before final settlement.' },
  { label: 'Finality targets', value: '< 2 blocks', description: 'Fast path after light-client verification on supported chains.' },
  { label: 'Bridge modes', value: '5 modes', description: 'Data, calls, native, fungible, and non-fungible assets.' },
];

export const securitySteps: SecurityStep[] = [
  {
    title: 'Source event capture',
    description: 'Watchers subscribe to router and bridge events on Ethereum, rollups, and alt-L1 endpoints.',
  },
  {
    title: 'Multi-operator attestation',
    description: 'Operators sign merkle roots for observed messages and submit quorum certificates to the AVS.',
  },
  {
    title: 'Fraud-proof window',
    description: 'Any challenger can provide contradictory headers, invalid roots, or malformed calldata before execution.',
  },
  {
    title: 'Destination execution',
    description: 'The message router releases payloads, performs contract calls, or mints/releases canonical assets.',
  },
];

export const routes: Route[] = [
  {
    source: 'Ethereum',
    destination: 'Base',
    latency: '45s expected',
    security: 'Light client + AVS quorum',
    description: 'L1-to-L2 route optimized for data and token bridging with optimistic challenge windows.',
    features: ['ERC-20 escrow', 'Native ETH wrapping', 'Contract calls'],
  },
  {
    source: 'Arbitrum',
    destination: 'Ethereum',
    latency: '2-5m expected',
    security: 'Rollup proof + AVS quorum',
    description: 'Withdrawals are accelerated with operator attestations while preserving fraud-proof fallback.',
    features: ['Fast exits', 'Proof fallback', 'Replay protection'],
  },
  {
    source: 'Avalanche',
    destination: 'Ethereum',
    latency: '90s expected',
    security: 'Header sync + AVS quorum',
    description: 'Alt-L1 route where the Bridge AVS light client tracks validator set transitions and signatures.',
    features: ['BLS set updates', 'NFT bridging', 'Arbitrary payloads'],
  },
];

export const architecture: ArchitectureNode[] = [
  {
    title: 'Message Router',
    description: 'Normalizes arbitrary payloads and contract-call requests into challengeable message commitments.',
    icon: 'MR',
    supports: ['Arbitrary Data', 'Contract Call', 'ERC-20', 'NFT', 'Native'],
  },
  {
    title: 'Token Bridge',
    description: 'Escrows native/ERC-20/NFT assets and settles canonical mint/burn flows on supported destinations.',
    icon: 'TB',
    supports: ['Native', 'ERC-20', 'NFT'],
  },
  {
    title: 'Light Client',
    description: 'Tracks remote headers, operator roots, and finality hints for Ethereum, rollups, and alt-L1s.',
    icon: 'LC',
    supports: ['Arbitrary Data', 'Contract Call', 'ERC-20', 'NFT', 'Native'],
  },
];

export const operators: Operator[] = [
  { name: 'Atlas One', stake: '120k EIGEN', role: 'Header watcher', status: 'Ready' },
  { name: 'Beacon Mesh', stake: '96k EIGEN', role: 'Fraud prover', status: 'Watching' },
  { name: 'Cinder Relay', stake: '83k EIGEN', role: 'Destination executor', status: 'Ready' },
  { name: 'Delta Quorum', stake: '75k EIGEN', role: 'Root aggregator', status: 'Ready' },
];

export const contractSnippets: ContractSnippet[] = [
  {
    title: 'MessageRouter.sol',
    path: 'contracts/MessageRouter.sol',
    code: `function executeMessage(bytes32 messageId, bytes calldata payload) external {
    require(lightClient.isMessageFinalized(messageId), "not finalized");
    require(!executed[messageId], "already executed");
    executed[messageId] = true;
    (bool ok,) = target.call(payload);
    require(ok, "execution failed");
}`,
  },
  {
    title: 'TokenBridge.sol',
    path: 'contracts/TokenBridge.sol',
    code: `function releaseERC20(bytes32 transferId, address token, address to, uint256 amount) external {
    require(router.consumeTransfer(transferId), "invalid proof");
    IERC20(token).transfer(to, amount);
    emit ERC20Released(transferId, token, to, amount);
}`,
  },
  {
    title: 'LightClient.sol',
    path: 'contracts/LightClient.sol',
    code: `function challengeRoot(bytes32 root, bytes calldata proof) external {
    require(block.timestamp < roots[root].finalizeAt, "window closed");
    bool valid = verifier.verifyFraudProof(root, proof);
    require(valid, "bad challenge");
    roots[root].invalidated = true;
}`,
  },
];
