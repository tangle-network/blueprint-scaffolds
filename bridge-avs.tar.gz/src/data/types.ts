export type AssetKind = 'Native' | 'ERC-20' | 'NFT' | 'Contract Call' | 'Arbitrary Data';

export type BridgeIntent = {
  sourceChain: string;
  destinationChain: string;
  assetKind: AssetKind;
  amount: string;
  payload: string;
  challengeWindow: string;
};

export type Metric = {
  label: string;
  value: string;
  description: string;
};

export type SecurityStep = {
  title: string;
  description: string;
};

export type Route = {
  source: string;
  destination: string;
  latency: string;
  security: string;
  description: string;
  features: string[];
};

export type ArchitectureNode = {
  title: string;
  description: string;
  icon: string;
  supports: AssetKind[];
};

export type Operator = {
  name: string;
  stake: string;
  role: string;
  status: 'Ready' | 'Watching';
};

export type ContractSnippet = {
  title: string;
  path: string;
  code: string;
};
