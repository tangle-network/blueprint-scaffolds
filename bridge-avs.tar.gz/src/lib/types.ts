export interface Chain {
  id: number;
  name: string;
  symbol: string;
  type: "ethereum" | "l2" | "alt-l1";
  icon: string;
  blockTime: number;
  confirmations: number;
}

export interface Token {
  address: string;
  name: string;
  symbol: string;
  decimals: number;
  type: "native" | "erc20" | "erc721";
  chainId: number;
  icon?: string;
}

export interface BridgeMessage {
  id: string;
  sender: string;
  recipient: string;
  sourceChain: number;
  destChain: number;
  payload: string;
  messageType: "data" | "contract-call" | "token-transfer" | "nft-transfer";
  nonce: number;
  timestamp: number;
  status: MessageStatus;
  attestations: Attestation[];
  fee: string;
}

export enum MessageStatus {
  Pending = "pending",
  Attesting = "attesting",
  Submitted = "submitted",
  Confirmed = "confirmed",
  Challenged = "challenged",
  Failed = "failed",
}

export interface Attestation {
  operator: string;
  signature: string;
  timestamp: number;
  messageRoot: string;
}

export interface Challenge {
  id: string;
  messageId: string;
  challenger: string;
  operator: string;
  reason: string;
  evidence: string;
  status: "open" | "resolved-valid" | "resolved-fraud";
  bond: string;
  createdAt: number;
  resolvedAt?: number;
}

export interface OperatorInfo {
  address: string;
  stake: string;
  status: "active" | "jailed" | "deregistered";
  totalAttestations: number;
  successfulAttestations: number;
  lastActive: number;
  endpoint: string;
}

export const SUPPORTED_CHAINS: Chain[] = [
  { id: 1, name: "Ethereum", symbol: "ETH", type: "ethereum", icon: "⟠", blockTime: 12, confirmations: 12 },
  { id: 10, name: "Optimism", symbol: "ETH", type: "l2", icon: "🔴", blockTime: 2, confirmations: 1 },
  { id: 42161, name: "Arbitrum", symbol: "ETH", type: "l2", icon: "🔵", blockTime: 0.25, confirmations: 1 },
  { id: 8453, name: "Base", symbol: "ETH", type: "l2", icon: "🔷", blockTime: 2, confirmations: 1 },
  { id: 137, name: "Polygon", symbol: "MATIC", type: "alt-l1", icon: "🟣", blockTime: 2, confirmations: 128 },
  { id: 56, name: "BSC", symbol: "BNB", type: "alt-l1", icon: "💛", blockTime: 3, confirmations: 15 },
  { id: 43114, name: "Avalanche", symbol: "AVAX", type: "alt-l1", icon: "🔺", blockTime: 2, confirmations: 12 },
  { id: 250, name: "Fantom", symbol: "FTM", type: "alt-l1", icon: "👻", blockTime: 1, confirmations: 5 },
];

export const MOCK_TOKENS: Token[] = [
  { address: "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE", name: "Ether", symbol: "ETH", decimals: 18, type: "native", chainId: 1 },
  { address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48", name: "USD Coin", symbol: "USDC", decimals: 6, type: "erc20", chainId: 1 },
  { address: "0x6B175474E89094C44Da98b954EedeAC495271d0F", name: "Dai Stablecoin", symbol: "DAI", decimals: 18, type: "erc20", chainId: 1 },
  { address: "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599", name: "Wrapped BTC", symbol: "WBTC", decimals: 8, type: "erc20", chainId: 1 },
  { address: "0x514910771AF9Ca656af840dff83E8264EcF986CA", name: "ChainLink", symbol: "LINK", decimals: 18, type: "erc20", chainId: 1 },
  { address: "0xBC4CA029A8153b0fEa0D9cDA3E7aF63c7f9B5cE6", name: "Bored Ape Yacht Club", symbol: "BAYC", decimals: 0, type: "erc721", chainId: 1 },
];

export const MESSAGE_TYPE_LABELS: Record<BridgeMessage["messageType"], string> = {
  "data": "Arbitrary Data",
  "contract-call": "Contract Call",
  "token-transfer": "Token Transfer",
  "nft-transfer": "NFT Transfer",
};
