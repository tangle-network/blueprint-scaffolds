import { SUPPORTED_CHAINS, MESSAGE_TYPE_LABELS } from "./types";
export { SUPPORTED_CHAINS, MOCK_TOKENS, MESSAGE_TYPE_LABELS, MessageStatus } from "./types";
export { MOCK_MESSAGES, MOCK_OPERATORS, MOCK_CHALLENGES, CONTRACT_ADDRESSES } from "./mock-data";

export const REQUIRED_ATTESTATIONS = 3;
export const CHALLENGE_PERIOD_SECONDS = 43200;
export const FRAUD_PROOF_BOND = "0.5 ETH";

export function getChainById(id: number) {
  return SUPPORTED_CHAINS.find(c => c.id === id);
}

export function getChainName(id: number): string {
  return getChainById(id)?.name ?? `Chain ${id}`;
}

export function getChainIcon(id: number): string {
  return getChainById(id)?.icon ?? "⛓";
}
