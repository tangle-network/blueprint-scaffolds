import type { Chain, Token, BridgeMessage, OperatorInfo, Challenge, Attestation } from "./types";
import { MessageStatus } from "./types";

export { SUPPORTED_CHAINS, MOCK_TOKENS, MESSAGE_TYPE_LABELS } from "./types";
export { MessageStatus } from "./types";

export const REQUIRED_ATTESTATIONS = 3;
export const CHALLENGE_PERIOD_SECONDS = 43200;
export const FRAUD_PROOF_BOND = "0.5 ETH";

export const MOCK_MESSAGES: BridgeMessage[] = [
  {
    id: "msg-001", sender: "0x742d35Cc6634C0532925a3b844Bc9e7595f2bD18",
    recipient: "0xAb5801a7D398351b8bE11C439e05C5B3259aeC9B",
    sourceChain: 1, destChain: 10, payload: "0xdeadbeef",
    messageType: "data", nonce: 42, timestamp: Date.now() - 3600000,
    status: MessageStatus.Confirmed, fee: "0.001 ETH",
    attestations: [
      { operator: "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266", signature: "0xsig1...", timestamp: Date.now() - 3500000, messageRoot: "0xroot1..." },
      { operator: "0x70997970C51812dc3A010C7d01b50e0d17dc79C8", signature: "0xsig2...", timestamp: Date.now() - 3400000, messageRoot: "0xroot1..." },
      { operator: "0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC", signature: "0xsig3...", timestamp: Date.now() - 3300000, messageRoot: "0xroot1..." },
      { operator: "0x90F79bf6EB2c4f870365E785982E1f101E93b906", signature: "0xsig4...", timestamp: Date.now() - 3200000, messageRoot: "0xroot1..." },
      { operator: "0x15d34AAf54267DB7D7c367839AAf71A00a2C6A65", signature: "0xsig5...", timestamp: Date.now() - 3100000, messageRoot: "0xroot1..." },
    ],
  },
  {
    id: "msg-002", sender: "0xCA35b7d915458EF540aDe6068dFe2F44E8fa733c",
    recipient: "0x14723A09ACff6D2A60DcdF7aA4AFf308FDDC160C",
    sourceChain: 42161, destChain: 1, payload: "transfer(address,uint256)",
    messageType: "contract-call", nonce: 43, timestamp: Date.now() - 1800000,
    status: MessageStatus.Attesting, fee: "0.002 ETH",
    attestations: [
      { operator: "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266", signature: "0xsig6...", timestamp: Date.now() - 1700000, messageRoot: "0xroot2..." },
      { operator: "0x70997970C51812dc3A010C7d01b50e0d17dc79C8", signature: "0xsig7...", timestamp: Date.now() - 1600000, messageRoot: "0xroot2..." },
    ],
  },
  {
    id: "msg-003", sender: "0x4B0897b0513fdC7C541B6d9D7E929C4e5364D2dB",
    recipient: "0x1aE0EA34a72D944a8C7603FfB3eC30a6669E454C",
    sourceChain: 137, destChain: 8453, payload: "1000 USDC",
    messageType: "token-transfer", nonce: 44, timestamp: Date.now() - 600000,
    status: MessageStatus.Pending, fee: "0.003 ETH",
    attestations: [],
  },
  {
    id: "msg-004", sender: "0xdD870fA1b7C4700F2BD7f44238821C26f7392148",
    recipient: "0x583031D1113aD414F02576BD6afaBfb302140225",
    sourceChain: 1, destChain: 43114, payload: "1.5 ETH",
    messageType: "token-transfer", nonce: 45, timestamp: Date.now() - 7200000,
    status: MessageStatus.Challenged, fee: "0.001 ETH",
    attestations: [
      { operator: "0x90F79bf6EB2c4f870365E785982E1f101E93b906", signature: "0xsig8...", timestamp: Date.now() - 7100000, messageRoot: "0xroot3..." },
    ],
  },
  {
    id: "msg-005", sender: "0x0A098Eda01Ce92ff4A4CCb7A4fFFb5A43EBC70DC",
    recipient: "0x5B38Da6a701c568545dCfcB03FcB875f56beddC4",
    sourceChain: 1, destChain: 137, payload: "BAYC #1234",
    messageType: "nft-transfer", nonce: 46, timestamp: Date.now() - 900000,
    status: MessageStatus.Attesting, fee: "0.005 ETH",
    attestations: [
      { operator: "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266", signature: "0xsig9...", timestamp: Date.now() - 800000, messageRoot: "0xroot4..." },
      { operator: "0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC", signature: "0xsig10...", timestamp: Date.now() - 750000, messageRoot: "0xroot4..." },
      { operator: "0x90F79bf6EB2c4f870365E785982E1f101E93b906", signature: "0xsig11...", timestamp: Date.now() - 700000, messageRoot: "0xroot4..." },
      { operator: "0x70997970C51812dc3A010C7d01b50e0d17dc79C8", signature: "0xsig12...", timestamp: Date.now() - 650000, messageRoot: "0xroot4..." },
    ],
  },
];

export const MOCK_OPERATORS: OperatorInfo[] = [
  { address: "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266", stake: "32 ETH", status: "active", totalAttestations: 12453, successfulAttestations: 12450, lastActive: Date.now() - 30000, endpoint: "https://op1.bridge-avs.example.com" },
  { address: "0x70997970C51812dc3A010C7d01b50e0d17dc79C8", stake: "32 ETH", status: "active", totalAttestations: 11287, successfulAttestations: 11280, lastActive: Date.now() - 120000, endpoint: "https://op2.bridge-avs.example.com" },
  { address: "0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC", stake: "32 ETH", status: "active", totalAttestations: 9876, successfulAttestations: 9870, lastActive: Date.now() - 60000, endpoint: "https://op3.bridge-avs.example.com" },
  { address: "0x90F79bf6EB2c4f870365E785982E1f101E93b906", stake: "32 ETH", status: "active", totalAttestations: 10542, successfulAttestations: 10535, lastActive: Date.now() - 45000, endpoint: "https://op4.bridge-avs.example.com" },
  { address: "0x15d34AAf54267DB7D7c367839AAf71A00a2C6A65", stake: "16 ETH", status: "jailed", totalAttestations: 3210, successfulAttestations: 3180, lastActive: Date.now() - 86400000, endpoint: "https://op5.bridge-avs.example.com" },
  { address: "0x9965507D1a55bcC2695C58ba16FB37d819B0A4dc", stake: "0 ETH", status: "deregistered", totalAttestations: 450, successfulAttestations: 390, lastActive: Date.now() - 604800000, endpoint: "" },
];

export const MOCK_CHALLENGES: Challenge[] = [
  { id: "ch-001", messageId: "msg-004", challenger: "0x23618e81E3f5cdF7f54C3d65f7FBc0aBf5B21E8f", operator: "0x90F79bf6EB2c4f870365E785982E1f101E93b906", reason: "Invalid state root in message attestation", evidence: "State root mismatch: expected 0xabcd..., got 0x1234...", status: "open", bond: "0.5 ETH", createdAt: Date.now() - 7200000 },
  { id: "ch-002", messageId: "msg-006", challenger: "0xA0Ee7A142d267C1f36714E4a8F75612F20a79720", operator: "0x9965507D1a55bcC2695C58ba16FB37d819B0A4dc", reason: "Fraudulent message with forged operator signatures", evidence: "Signature recovery mismatch on attestation #3", status: "resolved-fraud", bond: "0.5 ETH", createdAt: Date.now() - 172800000, resolvedAt: Date.now() - 86400000 },
];

export const CONTRACT_ADDRESSES = {
  MessageRouter: { address: "0x5FbDB2315678afecb367f032d93F642f64180aa3", chain: 1, version: "2.1.0" },
  TokenBridge: { address: "0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512", chain: 1, version: "2.1.0" },
  LightClient: { address: "0x9fE46736679d2D9a65F0992F2272De9f3c7fa6e0", chain: 1, version: "1.3.0" },
  OperatorRegistry: { address: "0xDc64a140Aa78E8456c1a83B4B1E1F0Eec6C46F90", chain: 1, version: "1.2.0" },
  FraudProofVerifier: { address: "0x5FC8d32690cc91D4c39d9d3abcBD16989F875707", chain: 1, version: "1.1.0" },
  MessageRouter_Optimism: { address: "0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D", chain: 10, version: "2.1.0" },
  TokenBridge_Optimism: { address: "0x6B175474E89094C44Da98b954EedeAC495271d0F", chain: 10, version: "2.1.0" },
  MessageRouter_Arbitrum: { address: "0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984", chain: 42161, version: "2.1.0" },
};
