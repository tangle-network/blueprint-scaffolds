import React from "react";
import { Routes, Route } from "react-router-dom";
import { Layout } from "./components/Layout";
import { Dashboard } from "./pages/Dashboard";
import { BridgePage } from "./pages/Bridge";
import { MessagesPage } from "./pages/Messages";
import { OperatorsPage } from "./pages/Operators";
import { ContractsPage } from "./pages/Contracts";
import { ExplorerPage } from "./pages/Explorer";

export default function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/bridge" element={<BridgePage />} />
        <Route path="/messages" element={<MessagesPage />} />
        <Route path="/operators" element={<OperatorsPage />} />
        <Route path="/contracts" element={<ContractsPage />} />
        <Route path="/explorer" element={<ExplorerPage />} />
      </Routes>
    </Layout>
  );
}
