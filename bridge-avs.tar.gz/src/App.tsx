import { useMemo, useState } from 'react';
import { AssetCard } from './components/AssetCard';
import { CodePanel } from './components/CodePanel';
import { MetricCard } from './components/MetricCard';
import { OperatorTable } from './components/OperatorTable';
import { StepRail } from './components/StepRail';
import { architecture, contractSnippets, metrics, operators, routes, securitySteps } from './data/bridgeData';
import type { AssetKind, BridgeIntent } from './data/types';

const assetKinds: AssetKind[] = ['Native', 'ERC-20', 'NFT', 'Contract Call', 'Arbitrary Data'];

const initialIntent: BridgeIntent = {
  sourceChain: 'Ethereum',
  destinationChain: 'Base',
  assetKind: 'ERC-20',
  amount: '250000',
  payload: '0xaabbccdd',
  challengeWindow: '30 minutes',
};

export default function App() {
  const [intent, setIntent] = useState<BridgeIntent>(initialIntent);

  const selectedRoute = useMemo(
    () =>
      routes.find(
        (route) =>
          route.source === intent.sourceChain &&
          route.destination === intent.destinationChain,
      ) ?? routes[0],
    [intent.destinationChain, intent.sourceChain],
  );

  const selectedAssets = useMemo(
    () =>
      architecture.filter((item) =>
        item.supports.includes(intent.assetKind),
      ),
    [intent.assetKind],
  );

  return (
    <div className="app-shell">
      <header className="hero">
        <div className="hero-copy">
          <p className="eyebrow">EigenLayer AVS</p>
          <h1>Secure cross-chain messaging, bridging, and attestation in one stack.</h1>
          <p className="hero-text">
            Bridge AVS combines multi-operator attestations, challenge windows, fraud proofs,
            and light-client verification to move arbitrary data, contract calls, native assets,
            ERC-20s, and NFTs across Ethereum, rollups, and alt-L1s.
          </p>
          <div className="hero-tags">
            <span>Ethereum</span>
            <span>L2 Rollups</span>
            <span>Alt-L1s</span>
            <span>Fraud Proofs</span>
            <span>Challenge Periods</span>
          </div>
        </div>
        <div className="intent-panel">
          <h2>Bridge intent</h2>
          <label>
            Source chain
            <select
              value={intent.sourceChain}
              onChange={(event) =>
                setIntent((current) => ({ ...current, sourceChain: event.target.value }))
              }
            >
              {['Ethereum', 'Arbitrum', 'Optimism', 'Base', 'Avalanche'].map((chain) => (
                <option key={chain}>{chain}</option>
              ))}
            </select>
          </label>
          <label>
            Destination chain
            <select
              value={intent.destinationChain}
              onChange={(event) =>
                setIntent((current) => ({ ...current, destinationChain: event.target.value }))
              }
            >
              {['Base', 'Arbitrum', 'Optimism', 'Ethereum', 'Solana SVM', 'Avalanche'].map(
                (chain) => (
                  <option key={chain}>{chain}</option>
                ),
              )}
            </select>
          </label>
          <label>
            Transfer type
            <div className="pill-row">
              {assetKinds.map((kind) => (
                <button
                  key={kind}
                  className={kind === intent.assetKind ? 'pill active' : 'pill'}
                  onClick={() => setIntent((current) => ({ ...current, assetKind: kind }))}
                  type="button"
                >
                  {kind}
                </button>
              ))}
            </div>
          </label>
          <label>
            Amount / call value
            <input
              value={intent.amount}
              onChange={(event) =>
                setIntent((current) => ({ ...current, amount: event.target.value }))
              }
            />
          </label>
          <label>
            Payload / calldata
            <textarea
              rows={4}
              value={intent.payload}
              onChange={(event) =>
                setIntent((current) => ({ ...current, payload: event.target.value }))
              }
            />
          </label>
          <div className="intent-summary">
            <span>{selectedRoute.latency}</span>
            <span>{selectedRoute.security}</span>
            <span>{intent.challengeWindow}</span>
          </div>
        </div>
      </header>

      <main>
        <section className="metrics-grid">
          {metrics.map((metric) => (
            <MetricCard key={metric.label} metric={metric} />
          ))}
        </section>

        <section className="section-grid">
          <div className="panel">
            <div className="panel-heading">
              <p className="eyebrow">Execution flow</p>
              <h2>How a message clears the challenge window</h2>
            </div>
            <StepRail steps={securitySteps} />
          </div>
          <div className="panel">
            <div className="panel-heading">
              <p className="eyebrow">Supported routes</p>
              <h2>Attestation profile</h2>
            </div>
            <div className="route-card">
              <h3>
                {selectedRoute.source} to {selectedRoute.destination}
              </h3>
              <p>{selectedRoute.description}</p>
              <ul className="inline-list">
                {selectedRoute.features.map((feature) => (
                  <li key={feature}>{feature}</li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        <section className="panel">
          <div className="panel-heading">
            <p className="eyebrow">Bridge primitives</p>
            <h2>Contracts activated by the selected flow</h2>
          </div>
          <div className="asset-grid">
            {selectedAssets.map((asset) => (
              <AssetCard key={asset.title} asset={asset} />
            ))}
          </div>
        </section>

        <section className="section-grid">
          <div className="panel">
            <div className="panel-heading">
              <p className="eyebrow">Operator quorum</p>
              <h2>Relay and watcher set</h2>
            </div>
            <OperatorTable operators={operators} />
          </div>
          <div className="panel">
            <div className="panel-heading">
              <p className="eyebrow">Reference contracts</p>
              <h2>Core Solidity modules</h2>
            </div>
            <div className="code-stack">
              {contractSnippets.map((snippet) => (
                <CodePanel key={snippet.title} snippet={snippet} />
              ))}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
