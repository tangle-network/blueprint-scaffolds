import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import {
  SUPPORTED_CHAINS,
  MOCK_MESSAGES,
  MOCK_OPERATORS,
  MOCK_CHALLENGES,
  REQUIRED_ATTESTATIONS,
} from "../lib/constants";
import { MessageStatus } from "../lib/types";
import {
  ArrowLeftRight,
  MessageSquare,
  Users,
  AlertTriangle,
  Activity,
  Shield,
} from "lucide-react";
import { formatTimeAgo, formatAddress } from "../lib/hooks";

export function Dashboard() {
  const totalMessages = MOCK_MESSAGES.length;
  const confirmedMessages = MOCK_MESSAGES.filter(
    (m) => m.status === MessageStatus.Confirmed
  ).length;
  const activeOperators = MOCK_OPERATORS.filter((o) => o.status === "active").length;
  const openChallenges = MOCK_CHALLENGES.filter((c) => c.status === "open").length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">
          Bridge AVS Overview — EigenLayer Secured Cross-Chain Messaging
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Messages</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalMessages}</div>
            <p className="text-xs text-muted-foreground">
              {confirmedMessages} confirmed
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Operators</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeOperators}</div>
            <p className="text-xs text-muted-foreground">
              of {MOCK_OPERATORS.length} registered
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Supported Chains</CardTitle>
            <ArrowLeftRight className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{SUPPORTED_CHAINS.length}</div>
            <p className="text-xs text-muted-foreground">
              Ethereum, L2s, alt-L1s
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Open Challenges</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{openChallenges}</div>
            <p className="text-xs text-muted-foreground">
              {MOCK_CHALLENGES.filter((c) => c.status === "resolved-fraud").length} resolved fraud
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Recent Messages</CardTitle>
            <CardDescription>Latest cross-chain bridge activity</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {MOCK_MESSAGES.slice(0, 5).map((msg) => (
                <div key={msg.id} className="flex items-center justify-between">
                  <div className="space-y-1">
                    <p className="text-sm font-medium">
                      {SUPPORTED_CHAINS.find((c) => c.id === msg.sourceChain)?.icon}{" "}
                      <span className="text-muted-foreground">→</span>{" "}
                      {SUPPORTED_CHAINS.find((c) => c.id === msg.destChain)?.icon}{" "}
                      <span className="font-mono text-xs">
                        {formatAddress(msg.sender)}
                      </span>
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {formatTimeAgo(msg.timestamp)}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">
                      {msg.attestations.length}/{REQUIRED_ATTESTATIONS}
                    </span>
                    <StatusBadge status={msg.status} />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Network Status</CardTitle>
            <CardDescription>Connected chain health</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {SUPPORTED_CHAINS.map((chain) => (
                <div key={chain.id} className="flex items-center gap-3">
                  <span className="text-lg">{chain.icon}</span>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium">{chain.name}</span>
                      <span className="text-xs text-muted-foreground">{chain.type}</span>
                    </div>
                    <Progress value={100} className="h-1" />
                  </div>
                  <div className="h-2 w-2 rounded-full bg-green-500" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">AVS Architecture</CardTitle>
          <CardDescription>Core contracts securing the bridge</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 md:grid-cols-3">
            <div className="rounded-lg border p-4 space-y-2">
              <div className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4 text-primary" />
                <span className="font-medium text-sm">MessageRouter</span>
              </div>
              <p className="text-xs text-muted-foreground">
                Routes arbitrary data, contract calls, and token transfer messages across chains
              </p>
              <Badge variant="secondary" className="text-xs">v2.1.0</Badge>
            </div>
            <div className="rounded-lg border p-4 space-y-2">
              <div className="flex items-center gap-2">
                <ArrowLeftRight className="h-4 w-4 text-primary" />
                <span className="font-medium text-sm">TokenBridge</span>
              </div>
              <p className="text-xs text-muted-foreground">
                Lock-and-mint bridge for native ETH, ERC-20 tokens, and NFTs
              </p>
              <Badge variant="secondary" className="text-xs">v2.1.0</Badge>
            </div>
            <div className="rounded-lg border p-4 space-y-2">
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-primary" />
                <span className="font-medium text-sm">LightClient</span>
              </div>
              <p className="text-xs text-muted-foreground">
                Stores verified block headers for trustless cross-chain verification
              </p>
              <Badge variant="secondary" className="text-xs">v1.3.0</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function StatusBadge({ status }: { status: MessageStatus }) {
  const variants: Record<MessageStatus, "default" | "secondary" | "destructive" | "outline"> = {
    [MessageStatus.Pending]: "outline",
    [MessageStatus.Attesting]: "secondary",
    [MessageStatus.Submitted]: "secondary",
    [MessageStatus.Confirmed]: "default",
    [MessageStatus.Challenged]: "destructive",
    [MessageStatus.Failed]: "destructive",
  };
  return (
    <Badge variant={variants[status]} className="text-xs capitalize">
      {status}
    </Badge>
  );
}
