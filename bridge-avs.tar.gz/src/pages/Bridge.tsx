import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Select } from "../components/ui/select";
import { Badge } from "../components/ui/badge";
import { Separator } from "../components/ui/separator";
import {
  SUPPORTED_CHAINS,
  MOCK_TOKENS,
  MESSAGE_TYPE_LABELS,
  REQUIRED_ATTESTATIONS,
} from "../lib/constants";
import { formatAddress } from "../lib/hooks";
import {
  ArrowLeftRight,
  ArrowRight,
  AlertCircle,
  CheckCircle2,
  Clock,
  Shield,
} from "lucide-react";

type BridgeTab = "data" | "contract-call" | "token-transfer" | "nft-transfer";

export function BridgePage() {
  const [activeTab, setActiveTab] = useState<BridgeTab>("token-transfer");
  const [sourceChain, setSourceChain] = useState(1);
  const [destChain, setDestChain] = useState(10);
  const [recipient, setRecipient] = useState("");
  const [amount, setAmount] = useState("");
  const [payload, setPayload] = useState("");
  const [contractAddress, setContractAddress] = useState("");
  const [tokenId, setTokenId] = useState("");
  const [selectedToken, setSelectedToken] = useState("ETH");
  const [bridgeState, setBridgeState] = useState<"idle" | "confirming" | "sent">("idle");

  const swapChains = () => {
    setSourceChain(destChain);
    setDestChain(sourceChain);
  };

  const sourceIcon = SUPPORTED_CHAINS.find((c) => c.id === sourceChain)?.icon ?? "";
  const destIcon = SUPPORTED_CHAINS.find((c) => c.id === destChain)?.icon ?? "";

  const handleBridge = () => {
    if (bridgeState === "idle") {
      setBridgeState("confirming");
    } else {
      setBridgeState("sent");
      setTimeout(() => setBridgeState("idle"), 3000);
    }
  };

  const tabs: { key: BridgeTab; label: string }[] = [
    { key: "data", label: "Arbitrary Data" },
    { key: "contract-call", label: "Contract Call" },
    { key: "token-transfer", label: "Token Transfer" },
    { key: "nft-transfer", label: "NFT Bridge" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Bridge</h1>
        <p className="text-muted-foreground">
          Send data, tokens, and NFTs across chains with multi-operator attestation
        </p>
      </div>

      <div className="flex gap-2 flex-wrap">
        {tabs.map((tab) => (
          <Button
            key={tab.key}
            variant={activeTab === tab.key ? "default" : "outline"}
            size="sm"
            onClick={() => setActiveTab(tab.key)}
          >
            {tab.label}
          </Button>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Route Selection</CardTitle>
              <CardDescription>Choose source and destination chains</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-[1fr_auto_1fr] gap-4 items-end">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Source</label>
                  <Select
                    value={sourceChain}
                    onChange={(e) => setSourceChain(Number(e.target.value))}
                  >
                    {SUPPORTED_CHAINS.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.icon} {c.name}
                      </option>
                    ))}
                  </Select>
                </div>
                <Button variant="ghost" size="icon" onClick={swapChains}>
                  <ArrowLeftRight className="h-4 w-4" />
                </Button>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Destination</label>
                  <Select
                    value={destChain}
                    onChange={(e) => setDestChain(Number(e.target.value))}
                  >
                    {SUPPORTED_CHAINS.filter((c) => c.id !== sourceChain).map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.icon} {c.name}
                      </option>
                    ))}
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">
                {activeTab === "data"
                  ? "Arbitrary Data"
                  : activeTab === "contract-call"
                  ? "Contract Call"
                  : activeTab === "token-transfer"
                  ? "Token Transfer"
                  : "NFT Transfer"}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Recipient Address</label>
                <Input
                  placeholder="0x..."
                  value={recipient}
                  onChange={(e) => setRecipient(e.target.value)}
                />
              </div>

              {activeTab === "data" && (
                <div className="space-y-2">
                  <label className="text-sm font-medium">Payload (hex)</label>
                  <Input
                    placeholder="0x..."
                    value={payload}
                    onChange={(e) => setPayload(e.target.value)}
                  />
                </div>
              )}

              {activeTab === "contract-call" && (
                <>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Target Contract</label>
                    <Input
                      placeholder="0x..."
                      value={contractAddress}
                      onChange={(e) => setContractAddress(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Calldata (hex)</label>
                    <Input
                      placeholder="0x..."
                      value={payload}
                      onChange={(e) => setPayload(e.target.value)}
                    />
                  </div>
                </>
              )}

              {activeTab === "token-transfer" && (
                <>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Token</label>
                    <Select
                      value={selectedToken}
                      onChange={(e) => setSelectedToken(e.target.value)}
                    >
                      {MOCK_TOKENS.filter((t) => t.type !== "erc721").map((t) => (
                        <option key={t.symbol} value={t.symbol}>
                          {t.name} ({t.symbol})
                        </option>
                      ))}
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Amount</label>
                    <Input
                      type="number"
                      placeholder="0.0"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                    />
                  </div>
                </>
              )}

              {activeTab === "nft-transfer" && (
                <>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">NFT Collection</label>
                    <Select
                      value={selectedToken}
                      onChange={(e) => setSelectedToken(e.target.value)}
                    >
                      {MOCK_TOKENS.filter((t) => t.type === "erc721").map((t) => (
                        <option key={t.symbol} value={t.symbol}>
                          {t.name} ({t.symbol})
                        </option>
                      ))}
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Token ID</label>
                    <Input
                      placeholder="1234"
                      value={tokenId}
                      onChange={(e) => setTokenId(e.target.value)}
                    />
                  </div>
                </>
              )}

              <Separator />

              {bridgeState === "sent" ? (
                <div className="flex items-center gap-2 p-4 rounded-lg bg-green-50 dark:bg-green-950">
                  <CheckCircle2 className="h-5 w-5 text-green-600" />
                  <div>
                    <p className="text-sm font-medium text-green-800 dark:text-green-200">
                      Transaction submitted
                    </p>
                    <p className="text-xs text-green-600 dark:text-green-400">
                      Message is being attested by operators
                    </p>
                  </div>
                </div>
              ) : bridgeState === "confirming" ? (
                <div className="space-y-3">
                  <div className="p-4 rounded-lg border space-y-2">
                    <p className="text-sm font-medium">Transaction Summary</p>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <span className="text-muted-foreground">Route:</span>
                      <span>
                        {sourceIcon} {SUPPORTED_CHAINS.find((c) => c.id === sourceChain)?.name} → {destIcon}{" "}
                        {SUPPORTED_CHAINS.find((c) => c.id === destChain)?.name}
                      </span>
                      <span className="text-muted-foreground">Type:</span>
                      <span>{MESSAGE_TYPE_LABELS[activeTab]}</span>
                      <span className="text-muted-foreground">Recipient:</span>
                      <span className="font-mono">{recipient ? formatAddress(recipient) : "—"}</span>
                      {activeTab === "token-transfer" && (
                        <>
                          <span className="text-muted-foreground">Amount:</span>
                          <span>{amount} {selectedToken}</span>
                        </>
                      )}
                      <span className="text-muted-foreground">Attestations Required:</span>
                      <span>{REQUIRED_ATTESTATIONS}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={() => setBridgeState("idle")} className="flex-1">
                      Back
                    </Button>
                    <Button onClick={handleBridge} className="flex-1">
                      Confirm & Send
                    </Button>
                  </div>
                </div>
              ) : (
                <Button onClick={handleBridge} className="w-full">
                  <ArrowRight className="mr-2 h-4 w-4" />
                  Send {MESSAGE_TYPE_LABELS[activeTab]}
                </Button>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Security Info</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-start gap-2">
                <Shield className="h-4 w-4 text-primary mt-0.5" />
                <div>
                  <p className="text-sm font-medium">EigenLayer Secured</p>
                  <p className="text-xs text-muted-foreground">
                    Operators restake ETH via EigenLayer for economic security
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5" />
                <div>
                  <p className="text-sm font-medium">Multi-Operator Attestation</p>
                  <p className="text-xs text-muted-foreground">
                    {REQUIRED_ATTESTATIONS} of {REQUIRED_ATTESTATIONS + 2} operators must attest
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Clock className="h-4 w-4 text-yellow-500 mt-0.5" />
                <div>
                  <p className="text-sm font-medium">Challenge Period</p>
                  <p className="text-xs text-muted-foreground">
                    12-hour window for fraud proof submission
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <AlertCircle className="h-4 w-4 text-destructive mt-0.5" />
                <div>
                  <p className="text-sm font-medium">Fraud Proofs</p>
                  <p className="text-xs text-muted-foreground">
                    Invalid attestations can be challenged with cryptographic proof
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Supported Chains</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {SUPPORTED_CHAINS.map((chain) => (
                  <div key={chain.id} className="flex items-center gap-2 text-sm">
                    <span>{chain.icon}</span>
                    <span className="font-medium">{chain.name}</span>
                    <Badge variant="outline" className="text-xs ml-auto">
                      {chain.type}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Estimated Fees</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Gas (source)</span>
                  <span>~0.001 ETH</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Bridge fee</span>
                  <span>~0.0005 ETH</span>
                </div>
                <Separator />
                <div className="flex justify-between font-medium">
                  <span>Total</span>
                  <span>~0.0015 ETH</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
