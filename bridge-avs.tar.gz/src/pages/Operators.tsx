import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Select } from "../components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import { MOCK_OPERATORS, MOCK_CHALLENGES, REQUIRED_ATTESTATIONS } from "../lib/constants";
import { formatAddress, formatTimeAgo } from "../lib/hooks";
import { Users, Shield, AlertTriangle, CheckCircle2, XCircle } from "lucide-react";

export function OperatorsPage() {
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const filtered = MOCK_OPERATORS.filter(
    (op) => statusFilter === "all" || op.status === statusFilter
  );

  const activeCount = MOCK_OPERATORS.filter((o) => o.status === "active").length;
  const totalStake = "144 ETH";
  const avgSuccess =
    MOCK_OPERATORS.filter((o) => o.status === "active").reduce(
      (acc, o) => acc + (o.successfulAttestations / Math.max(o.totalAttestations, 1)) * 100,
      0
    ) / activeCount;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Operators</h1>
        <p className="text-muted-foreground">
          EigenLayer restaked operators securing the Bridge AVS
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Operators</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeCount}</div>
            <p className="text-xs text-muted-foreground">of {MOCK_OPERATORS.length} registered</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Stake</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalStake}</div>
            <p className="text-xs text-muted-foreground">EigenLayer restaked</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Avg Success Rate</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{avgSuccess.toFixed(2)}%</div>
            <p className="text-xs text-muted-foreground">Attestation accuracy</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Open Challenges</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {MOCK_CHALLENGES.filter((c) => c.status === "open").length}
            </div>
            <p className="text-xs text-muted-foreground">
              {MOCK_CHALLENGES.filter((c) => c.status === "resolved-fraud").length} fraud resolved
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="flex gap-3">
        <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="all">All Statuses</option>
          <option value="active">Active</option>
          <option value="jailed">Jailed</option>
          <option value="deregistered">Deregistered</option>
        </Select>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Operator</TableHead>
                <TableHead>Stake</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Total Attestations</TableHead>
                <TableHead>Success Rate</TableHead>
                <TableHead>Last Active</TableHead>
                <TableHead>Endpoint</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((op) => {
                const successRate =
                  op.totalAttestations > 0
                    ? ((op.successfulAttestations / op.totalAttestations) * 100).toFixed(2)
                    : "0";
                return (
                  <TableRow key={op.address}>
                    <TableCell className="font-mono text-xs">
                      {formatAddress(op.address)}
                    </TableCell>
                    <TableCell className="font-medium">{op.stake}</TableCell>
                    <TableCell>
                      <OperatorStatusBadge status={op.status} />
                    </TableCell>
                    <TableCell>{op.totalAttestations.toLocaleString()}</TableCell>
                    <TableCell>
                      <span
                        className={
                          Number(successRate) >= 99
                            ? "text-green-600"
                            : Number(successRate) >= 95
                            ? "text-yellow-600"
                            : "text-red-600"
                        }
                      >
                        {successRate}%
                      </span>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {formatTimeAgo(op.lastActive)}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground max-w-[200px] truncate">
                      {op.endpoint || "—"}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Operator Software (Go)</CardTitle>
            <CardDescription>Chain watchers and relay infrastructure</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="rounded-lg border p-3 space-y-1">
                <p className="text-sm font-medium">Chain Watcher</p>
                <p className="text-xs text-muted-foreground">
                  Monitors MessageRouter events on each connected chain, validates block headers against LightClient
                </p>
              </div>
              <div className="rounded-lg border p-3 space-y-1">
                <p className="text-sm font-medium">Attestation Signer</p>
                <p className="text-xs text-muted-foreground">
                  Signs validated messages with operator key, submits attestation to MessageRouter
                </p>
              </div>
              <div className="rounded-lg border p-3 space-y-1">
                <p className="text-sm font-medium">Relay Service</p>
                <p className="text-xs text-muted-foreground">
                  Collects attestations and relays confirmed messages to destination chain MessageRouter
                </p>
              </div>
              <div className="rounded-lg border p-3 space-y-1">
                <p className="text-sm font-medium">Fraud Monitor</p>
                <p className="text-xs text-muted-foreground">
                  Watches for suspicious messages during challenge period, generates fraud proofs if needed
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Challenges & Fraud Proofs</CardTitle>
          </CardHeader>
          <CardContent>
            {MOCK_CHALLENGES.length === 0 ? (
              <p className="text-sm text-muted-foreground">No challenges found</p>
            ) : (
              <div className="space-y-3">
                {MOCK_CHALLENGES.map((ch) => (
                  <div key={ch.id} className="rounded-lg border p-3 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Challenge {ch.id}</span>
                      <Badge
                        variant={
                          ch.status === "open"
                            ? "destructive"
                            : ch.status === "resolved-fraud"
                            ? "default"
                            : "secondary"
                        }
                        className="text-xs"
                      >
                        {ch.status}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">{ch.reason}</p>
                    <div className="flex gap-4 text-xs text-muted-foreground">
                      <span>Challenger: {formatAddress(ch.challenger)}</span>
                      <span>Operator: {formatAddress(ch.operator)}</span>
                    </div>
                    <div className="flex gap-4 text-xs text-muted-foreground">
                      <span>Bond: {ch.bond}</span>
                      <span>{formatTimeAgo(ch.createdAt)}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function OperatorStatusBadge({ status }: { status: string }) {
  if (status === "active") return <Badge className="text-xs">Active</Badge>;
  if (status === "jailed") return <Badge variant="destructive" className="text-xs">Jailed</Badge>;
  return <Badge variant="outline" className="text-xs">Deregistered</Badge>;
}
