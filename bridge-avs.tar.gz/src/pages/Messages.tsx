import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Input } from "../components/ui/input";
import { Select } from "../components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import {
  SUPPORTED_CHAINS,
  MOCK_MESSAGES,
  MESSAGE_TYPE_LABELS,
  REQUIRED_ATTESTATIONS,
} from "../lib/constants";
import { MessageStatus } from "../lib/types";
import { formatAddress, formatTimeAgo } from "../lib/hooks";

export function MessagesPage() {
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [search, setSearch] = useState("");

  const filtered = MOCK_MESSAGES.filter((msg) => {
    if (statusFilter !== "all" && msg.status !== statusFilter) return false;
    if (typeFilter !== "all" && msg.messageType !== typeFilter) return false;
    if (search) {
      const s = search.toLowerCase();
      return (
        msg.id.toLowerCase().includes(s) ||
        msg.sender.toLowerCase().includes(s) ||
        msg.recipient.toLowerCase().includes(s) ||
        msg.payload.toLowerCase().includes(s)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Messages</h1>
        <p className="text-muted-foreground">
          Cross-chain message tracking with operator attestation status
        </p>
      </div>

      <div className="flex flex-wrap gap-3">
        <Input
          placeholder="Search by ID, address, or payload..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="max-w-xs"
        />
        <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="all">All Statuses</option>
          <option value={MessageStatus.Pending}>Pending</option>
          <option value={MessageStatus.Attesting}>Attesting</option>
          <option value={MessageStatus.Submitted}>Submitted</option>
          <option value={MessageStatus.Confirmed}>Confirmed</option>
          <option value={MessageStatus.Challenged}>Challenged</option>
          <option value={MessageStatus.Failed}>Failed</option>
        </Select>
        <Select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)}>
          <option value="all">All Types</option>
          <option value="data">Arbitrary Data</option>
          <option value="contract-call">Contract Call</option>
          <option value="token-transfer">Token Transfer</option>
          <option value="nft-transfer">NFT Transfer</option>
        </Select>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Route</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Sender → Recipient</TableHead>
                <TableHead>Attestations</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Time</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((msg) => {
                const src = SUPPORTED_CHAINS.find((c) => c.id === msg.sourceChain);
                const dst = SUPPORTED_CHAINS.find((c) => c.id === msg.destChain);
                return (
                  <TableRow key={msg.id}>
                    <TableCell className="font-mono text-xs">{msg.id}</TableCell>
                    <TableCell>
                      <span className="text-sm">
                        {src?.icon} {src?.name} → {dst?.icon} {dst?.name}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-xs">
                        {MESSAGE_TYPE_LABELS[msg.messageType]}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-mono text-xs">
                      {formatAddress(msg.sender)} → {formatAddress(msg.recipient)}
                    </TableCell>
                    <TableCell>
                      <span className="text-sm">
                        {msg.attestations.length}/{REQUIRED_ATTESTATIONS}
                      </span>
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={msg.status} />
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {formatTimeAgo(msg.timestamp)}
                    </TableCell>
                  </TableRow>
                );
              })}
              {filtered.length === 0 && (
                <TableRow>
                  <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                    No messages found matching filters
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Message Flow</CardTitle>
          </CardHeader>
          <CardContent>
            <ol className="space-y-2 text-xs text-muted-foreground list-decimal list-inside">
              <li>Sender submits message to MessageRouter on source chain</li>
              <li>Operators detect event via chain watchers (Go software)</li>
              <li>Each operator validates and submits attestation signature</li>
              <li>Once {REQUIRED_ATTESTATIONS} attestations collected, message submitted on dest chain</li>
              <li>Challenge period begins (12 hours) for fraud proof submission</li>
              <li>If no valid fraud proof, message is finalized</li>
            </ol>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Attestation Details</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {MOCK_MESSAGES[0].attestations.slice(0, 3).map((att, i) => (
                <div key={i} className="flex items-center justify-between text-xs">
                  <span className="font-mono">{formatAddress(att.operator)}</span>
                  <Badge variant="secondary" className="text-xs">Signed</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Status Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {Object.values(MessageStatus).map((status) => {
                const count = MOCK_MESSAGES.filter((m) => m.status === status).length;
                return (
                  <div key={status} className="flex items-center justify-between text-sm">
                    <StatusBadge status={status} />
                    <span className="font-medium">{count}</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: MessageStatus }) {
  const variants: Record<MessageStatus, "default" | "secondary" | "destructive" | "outline"> = {
    [MessageStatus.Pending]: "outline",
    [MessageStatus.Attesting]: "secondary",
    [MessageStatus.Submitted]: "secondary",
    [MessageStatus.Confirmed]: "default",
    [MessageStatus.Challenged]: "destructive",
    [MessageStatus.Failed]: "destructive",
  };
  return (
    <Badge variant={variants[status]} className="text-xs capitalize">
      {status}
    </Badge>
  );
}
