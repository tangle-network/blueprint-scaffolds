import type { SecurityStep } from '../data/types';

type StepRailProps = {
  steps: SecurityStep[];
};

export function StepRail({ steps }: StepRailProps) {
  return (
    <div className="step-rail">
      {steps.map((step, index) => (
        <article key={step.title} className="step-card">
          <span className="step-index">{String(index + 1).padStart(2, '0')}</span>
          <div>
            <h3>{step.title}</h3>
            <p>{step.description}</p>
          </div>
        </article>
      ))}
    </div>
  );
}
