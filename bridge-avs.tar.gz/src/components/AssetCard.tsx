import type { ArchitectureNode } from '../data/types';

type AssetCardProps = {
  asset: ArchitectureNode;
};

export function AssetCard({ asset }: AssetCardProps) {
  return (
    <article className="asset-card">
      <div className="asset-icon">{asset.icon}</div>
      <div>
        <h3>{asset.title}</h3>
        <p>{asset.description}</p>
      </div>
      <ul className="inline-list">
        {asset.supports.map((item) => (
          <li key={item}>{item}</li>
        ))}
      </ul>
    </article>
  );
}
