import type { Metric } from '../data/types';

type MetricCardProps = {
  metric: Metric;
};

export function MetricCard({ metric }: MetricCardProps) {
  return (
    <article className="metric-card">
      <p>{metric.label}</p>
      <strong>{metric.value}</strong>
      <span>{metric.description}</span>
    </article>
  );
}
