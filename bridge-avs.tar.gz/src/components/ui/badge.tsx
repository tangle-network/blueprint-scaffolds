import * as React from "react";
import { cn } from "@/lib/utils";

const Badge = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement> & { variant?: "default" | "secondary" | "success" | "warning" | "destructive" | "outline" }>(
  ({ className, variant = "default", ...props }, ref) => {
    const variants: Record<string, string> = {
      default: "bg-bridge-600/20 text-bridge-400 border-bridge-600/30",
      secondary: "bg-gray-800 text-gray-300 border-gray-700",
      success: "bg-green-600/20 text-green-400 border-green-600/30",
      warning: "bg-yellow-600/20 text-yellow-400 border-yellow-600/30",
      destructive: "bg-red-600/20 text-red-400 border-red-600/30",
      outline: "border-gray-600 text-gray-400",
    };
    return (
      <div
        ref={ref}
        className={cn("inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors", variants[variant], className)}
        {...props}
      />
    );
  }
);
Badge.displayName = "Badge";

export { Badge };
