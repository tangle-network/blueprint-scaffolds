import type { Operator } from '../data/types';

type OperatorTableProps = {
  operators: Operator[];
};

export function OperatorTable({ operators }: OperatorTableProps) {
  return (
    <div className="operator-table">
      <div className="operator-row operator-head">
        <span>Operator</span>
        <span>Stake</span>
        <span>Role</span>
        <span>Status</span>
      </div>
      {operators.map((operator) => (
        <div key={operator.name} className="operator-row">
          <span>{operator.name}</span>
          <span>{operator.stake}</span>
          <span>{operator.role}</span>
          <span className={operator.status === 'Ready' ? 'status ready' : 'status watch'}>
            {operator.status}
          </span>
        </div>
      ))}
    </div>
  );
}
