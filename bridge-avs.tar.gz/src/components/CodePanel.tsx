import type { ContractSnippet } from '../data/types';

type CodePanelProps = {
  snippet: ContractSnippet;
};

export function CodePanel({ snippet }: CodePanelProps) {
  return (
    <article className="code-panel">
      <div className="code-header">
        <div>
          <p className="eyebrow">{snippet.path}</p>
          <h3>{snippet.title}</h3>
        </div>
      </div>
      <pre>{snippet.code}</pre>
    </article>
  );
}
