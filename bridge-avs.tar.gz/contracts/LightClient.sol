// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract LightClient {
    struct RootRecord {
        bytes32 headerRoot;
        uint64 observedAt;
        uint64 finalizeAt;
        uint96 attestedStake;
        bool invalidated;
    }

    mapping(bytes32 => RootRecord) public roots;
    mapping(bytes32 => bytes32) public messageToRoot;

    event RootCommitted(bytes32 indexed root, bytes32 indexed headerRoot, uint64 finalizeAt, uint96 attestedStake);
    event RootChallenged(bytes32 indexed root, address indexed challenger);
    event MessageLinked(bytes32 indexed messageId, bytes32 indexed root);

    function commitRoot(bytes32 root, bytes32 headerRoot, uint64 challengePeriod, uint96 attestedStake) external {
        require(roots[root].observedAt == 0, "root already committed");
        roots[root] = RootRecord({
            headerRoot: headerRoot,
            observedAt: uint64(block.timestamp),
            finalizeAt: uint64(block.timestamp + challengePeriod),
            attestedStake: attestedStake,
            invalidated: false
        });
        emit RootCommitted(root, headerRoot, uint64(block.timestamp + challengePeriod), attestedStake);
    }

    function linkMessage(bytes32 messageId, bytes32 root) external {
        require(roots[root].observedAt != 0, "unknown root");
        messageToRoot[messageId] = root;
        emit MessageLinked(messageId, root);
    }

    function challengeRoot(bytes32 root, bytes calldata fraudProof) external {
        RootRecord storage record = roots[root];
        require(record.observedAt != 0, "unknown root");
        require(block.timestamp < record.finalizeAt, "challenge period ended");
        require(fraudProof.length > 0, "missing proof");

        record.invalidated = true;
        emit RootChallenged(root, msg.sender);
    }

    function isMessageFinalized(bytes32 messageId) external view returns (bool) {
        bytes32 root = messageToRoot[messageId];
        RootRecord memory record = roots[root];
        return root != bytes32(0) && !record.invalidated && block.timestamp >= record.finalizeAt;
    }
}
