// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IERC20Minimal {
    function transferFrom(address from, address to, uint256 value) external returns (bool);
    function transfer(address to, uint256 value) external returns (bool);
}

interface IERC721Minimal {
    function safeTransferFrom(address from, address to, uint256 tokenId) external;
}

interface IBridgeRouter {
    function dispatchMessage(
        address target,
        uint256 destinationChainId,
        uint256 value,
        bytes calldata payload,
        uint256 nonce,
        uint256 challengePeriod
    ) external returns (bytes32 messageId);
}

contract TokenBridge {
    IBridgeRouter public immutable router;
    mapping(bytes32 => bool) public consumedTransfers;

    event NativeLocked(bytes32 indexed transferId, address indexed sender, address indexed recipient, uint256 amount);
    event ERC20Locked(bytes32 indexed transferId, address indexed token, address indexed recipient, uint256 amount);
    event NFTLocked(bytes32 indexed transferId, address indexed collection, address indexed recipient, uint256 tokenId);
    event TransferReleased(bytes32 indexed transferId, address indexed recipient);

    constructor(address router_) {
        router = IBridgeRouter(router_);
    }

    function lockNative(address recipient, uint256 destinationChainId, uint256 nonce, uint256 challengePeriod)
        external
        payable
        returns (bytes32 transferId)
    {
        bytes memory payload = abi.encodeWithSignature("releaseNative(bytes32,address,uint256)", bytes32(0), recipient, msg.value);
        transferId = router.dispatchMessage(address(this), destinationChainId, 0, payload, nonce, challengePeriod);
        emit NativeLocked(transferId, msg.sender, recipient, msg.value);
    }

    function lockERC20(
        address token,
        address recipient,
        uint256 amount,
        uint256 destinationChainId,
        uint256 nonce,
        uint256 challengePeriod
    ) external returns (bytes32 transferId) {
        IERC20Minimal(token).transferFrom(msg.sender, address(this), amount);
        bytes memory payload =
            abi.encodeWithSignature("releaseERC20(bytes32,address,address,uint256)", bytes32(0), token, recipient, amount);
        transferId = router.dispatchMessage(address(this), destinationChainId, 0, payload, nonce, challengePeriod);
        emit ERC20Locked(transferId, token, recipient, amount);
    }

    function lockNFT(
        address collection,
        address recipient,
        uint256 tokenId,
        uint256 destinationChainId,
        uint256 nonce,
        uint256 challengePeriod
    ) external returns (bytes32 transferId) {
        IERC721Minimal(collection).safeTransferFrom(msg.sender, address(this), tokenId);
        bytes memory payload =
            abi.encodeWithSignature("releaseNFT(bytes32,address,address,uint256)", bytes32(0), collection, recipient, tokenId);
        transferId = router.dispatchMessage(address(this), destinationChainId, 0, payload, nonce, challengePeriod);
        emit NFTLocked(transferId, collection, recipient, tokenId);
    }

    function releaseNative(bytes32 transferId, address recipient, uint256 amount) external {
        _consumeTransfer(transferId);
        payable(recipient).transfer(amount);
        emit TransferReleased(transferId, recipient);
    }

    function releaseERC20(bytes32 transferId, address token, address recipient, uint256 amount) external {
        _consumeTransfer(transferId);
        IERC20Minimal(token).transfer(recipient, amount);
        emit TransferReleased(transferId, recipient);
    }

    function releaseNFT(bytes32 transferId, address collection, address recipient, uint256 tokenId) external {
        _consumeTransfer(transferId);
        IERC721Minimal(collection).safeTransferFrom(address(this), recipient, tokenId);
        emit TransferReleased(transferId, recipient);
    }

    function _consumeTransfer(bytes32 transferId) internal {
        require(!consumedTransfers[transferId], "transfer already consumed");
        consumedTransfers[transferId] = true;
    }
}
