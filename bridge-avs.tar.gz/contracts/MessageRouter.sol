// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface ILightClient {
    function isMessageFinalized(bytes32 messageId) external view returns (bool);
}

contract MessageRouter {
    struct Message {
        address sender;
        address target;
        uint256 destinationChainId;
        uint256 value;
        bytes payload;
        uint256 nonce;
    }

    ILightClient public immutable lightClient;
    mapping(bytes32 => bool) public executed;
    mapping(bytes32 => uint256) public challengeExpiry;

    event MessageDispatched(bytes32 indexed messageId, address indexed sender, uint256 indexed destinationChainId);
    event MessageExecuted(bytes32 indexed messageId, address indexed target, bool success);

    constructor(address lightClient_) {
        lightClient = ILightClient(lightClient_);
    }

    function dispatchMessage(
        address target,
        uint256 destinationChainId,
        uint256 value,
        bytes calldata payload,
        uint256 nonce,
        uint256 challengePeriod
    ) external returns (bytes32 messageId) {
        Message memory message = Message({
            sender: msg.sender,
            target: target,
            destinationChainId: destinationChainId,
            value: value,
            payload: payload,
            nonce: nonce
        });

        messageId = keccak256(abi.encode(message));
        challengeExpiry[messageId] = block.timestamp + challengePeriod;
        emit MessageDispatched(messageId, msg.sender, destinationChainId);
    }

    function executeMessage(Message calldata message) external payable {
        bytes32 messageId = keccak256(abi.encode(message));
        require(lightClient.isMessageFinalized(messageId), "message not finalized");
        require(block.timestamp >= challengeExpiry[messageId], "challenge window open");
        require(!executed[messageId], "message already executed");

        executed[messageId] = true;
        (bool ok, ) = message.target.call{value: message.value}(message.payload);
        require(ok, "execution failed");

        emit MessageExecuted(messageId, message.target, ok);
    }
}
