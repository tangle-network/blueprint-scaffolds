package main

import (
	"context"
	"flag"
	"log"
	"time"

	"bridgeavs/operator/internal/config"
	"bridgeavs/operator/internal/relay"
	"bridgeavs/operator/internal/watcher"
)

func main() {
	configPath := flag.String("config", "config.json", "path to config file")
	flag.Parse()

	cfg, err := config.Load(*configPath)
	if err != nil {
		log.Fatalf("load config: %v", err)
	}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	observations := make(chan watcher.Observation, len(cfg.Chains)*2)
	relayer := relay.New(cfg.QuorumThreshold)
	go relayer.Run(ctx, observations)

	pollInterval := time.Duration(cfg.PollIntervalSecs) * time.Second
	for _, chain := range cfg.Chains {
		go watcher.New(chain).Run(ctx, observations, pollInterval)
	}

	select {}
}
