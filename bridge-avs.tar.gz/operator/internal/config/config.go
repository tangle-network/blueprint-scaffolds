package config

import (
	"encoding/json"
	"os"
)

type ChainConfig struct {
	Name       string `json:"name"`
	RPCURL     string `json:"rpcUrl"`
	ChainID    uint64 `json:"chainId"`
	Router     string `json:"router"`
	LightClient string `json:"lightClient"`
}

type Config struct {
	Chains           []ChainConfig `json:"chains"`
	PollIntervalSecs int           `json:"pollIntervalSecs"`
	QuorumThreshold  int           `json:"quorumThreshold"`
}

func Load(path string) (Config, error) {
	var cfg Config
	data, err := os.ReadFile(path)
	if err != nil {
		return cfg, err
	}

	err = json.Unmarshal(data, &cfg)
	return cfg, err
}
