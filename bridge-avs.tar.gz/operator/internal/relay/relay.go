package relay

import (
	"context"
	"log"
	"sync"

	"bridgeavs/operator/internal/watcher"
)

type Relayer struct {
	quorumThreshold int
	mu              sync.Mutex
	seen            map[string]int
}

func New(quorumThreshold int) *Relayer {
	return &Relayer{
		quorumThreshold: quorumThreshold,
		seen:            make(map[string]int),
	}
}

func (r *Relayer) Run(ctx context.Context, observations <-chan watcher.Observation) {
	for {
		select {
		case <-ctx.Done():
			return
		case obs := <-observations:
			r.mu.Lock()
			r.seen[obs.MessageID]++
			count := r.seen[obs.MessageID]
			r.mu.Unlock()

			if count >= r.quorumThreshold {
				log.Printf("relay quorum reached for %s on root %s", obs.MessageID, obs.Root)
			} else {
				log.Printf("relay progress for %s: %d/%d attestations", obs.MessageID, count, r.quorumThreshold)
			}
		}
	}
}
