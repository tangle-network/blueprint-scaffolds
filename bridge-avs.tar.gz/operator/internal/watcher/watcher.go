package watcher

import (
	"context"
	"log"
	"time"

	"bridgeavs/operator/internal/config"
)

type Observation struct {
	Chain     string
	MessageID string
	Root      string
	Timestamp time.Time
}

type Watcher struct {
	cfg config.ChainConfig
}

func New(cfg config.ChainConfig) *Watcher {
	return &Watcher{cfg: cfg}
}

func (w *Watcher) Run(ctx context.Context, out chan<- Observation, pollInterval time.Duration) {
	ticker := time.NewTicker(pollInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			observation := Observation{
				Chain:     w.cfg.Name,
				MessageID: "0xmessage-" + w.cfg.Name,
				Root:      "0xroot-" + w.cfg.Name,
				Timestamp: time.Now().UTC(),
			}
			log.Printf("watcher observed message on %s via %s", w.cfg.Name, w.cfg.RPCURL)
			out <- observation
		}
	}
}
