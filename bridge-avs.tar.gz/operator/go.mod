module bridgeavs/operator

go 1.22
