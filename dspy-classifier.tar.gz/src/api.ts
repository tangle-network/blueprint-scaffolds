import {
  ClassificationResult,
  CrossValidationMetrics,
  OptimizationResult,
  UncertainSample,
  TrainingExample,
  CategoryNode,
} from './types';

const BASE = '/api';

async function request<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${url}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(err.detail || 'Request failed');
  }
  return res.json();
}

export async function classifySingle(
  text: string,
  multiLabel = false,
  categoryTree?: CategoryNode,
): Promise<ClassificationResult> {
  return request<ClassificationResult>('/classify', {
    method: 'POST',
    body: JSON.stringify({ text, multi_label: multiLabel, category_tree: categoryTree }),
  });
}

export async function classifyBatch(
  texts: string[],
  multiLabel = false,
  categoryTree?: CategoryNode,
): Promise<ClassificationResult[]> {
  return request<ClassificationResult[]>('/classify/batch', {
    method: 'POST',
    body: JSON.stringify({ text: texts, multi_label: multiLabel, category_tree: categoryTree }),
  });
}

export async function optimize(
  examples: TrainingExample[],
  numIterations = 5,
): Promise<OptimizationResult> {
  return request<OptimizationResult>('/optimize', {
    method: 'POST',
    body: JSON.stringify({ examples, num_iterations: numIterations }),
  });
}

export async function crossValidate(
  examples: TrainingExample[],
  k = 5,
): Promise<CrossValidationMetrics> {
  return request<CrossValidationMetrics>('/cross-validate', {
    method: 'POST',
    body: JSON.stringify({ examples, k }),
  });
}

export async function getUncertainSamples(
  count = 10,
): Promise<UncertainSample[]> {
  return request<UncertainSample[]>(`/active-learning/uncertain?count=${count}`);
}

export async function submitLabels(
  samples: { id: number; labels: string[] }[],
): Promise<{ accepted: number }> {
  return request<{ accepted: number }>('/active-learning/label', {
    method: 'POST',
    body: JSON.stringify({ samples }),
  });
}
