export interface ClassificationRequest {
  text: string | string[];
  multi_label?: boolean;
  category_tree?: CategoryNode;
}

export interface CategoryNode {
  name: string;
  children?: CategoryNode[];
}

export interface ClassificationResult {
  text: string;
  labels: PredictedLabel[];
  reasoning: string;
  confidence: number;
}

export interface PredictedLabel {
  label: string;
  score: number;
  path?: string[];
}

export interface CrossValidationMetrics {
  accuracy: number;
  f1_macro: number;
  f1_weighted: number;
  precision_macro: number;
  recall_macro: number;
  per_class: Record<string, ClassMetrics>;
  confusion_matrix: number[][];
  class_names: string[];
}

export interface ClassMetrics {
  precision: number;
  recall: number;
  f1: number;
  support: number;
}

export interface OptimizationResult {
  score_before: number;
  score_after: number;
  demonstrations_used: number;
  iterations: number;
}

export interface UncertainSample {
  id: number;
  text: string;
  predictions: PredictedLabel[];
  entropy: number;
}

export interface TrainingExample {
  text: string;
  labels: string[];
}

export type TabId = 'classify' | 'batch' | 'hierarchy' | 'optimize' | 'metrics' | 'active';
