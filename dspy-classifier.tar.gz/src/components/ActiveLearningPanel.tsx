import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { getActiveLearningSuggestions } from "@/lib/api";
import type { ActiveLearningSuggestion } from "@/types";

export function ActiveLearningPanel() {
  const [suggestions, setSuggestions] = useState<ActiveLearningSuggestion[]>([]);
  const [count, setCount] = useState(5);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadSuggestions = async () => {
    setLoading(true);
    setError(null);
    try {
      const s = await getActiveLearningSuggestions(count);
      setSuggestions(s);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load suggestions");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSuggestions();
  }, []);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Active Learning</CardTitle>
              <CardDescription>
                Texts the model is most uncertain about — labeling these improves performance the most
              </CardDescription>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <Label htmlFor="count" className="text-sm whitespace-nowrap">
                  Count
                </Label>
                <Input
                  id="count"
                  type="number"
                  min={1}
                  max={50}
                  value={count}
                  onChange={(e) => setCount(Number(e.target.value))}
                  className="w-20"
                />
              </div>
              <Button onClick={loadSuggestions} disabled={loading} variant="outline" size="sm">
                {loading ? "Loading..." : "Refresh"}
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {error && (
        <Card>
          <CardContent className="py-4">
            <p className="text-sm text-destructive">{error}</p>
          </CardContent>
        </Card>
      )}

      {suggestions.map((s, idx) => (
        <Card key={idx}>
          <CardContent className="pt-6 space-y-3">
            <div className="flex items-start justify-between gap-4">
              <p className="text-sm font-medium flex-1">{s.text}</p>
              <div className="flex-shrink-0 text-right">
                <p className="text-xs text-muted-foreground">Uncertainty</p>
                <p className="text-lg font-bold">
                  {(s.uncertainty_score * 100).toFixed(0)}%
                </p>
              </div>
            </div>
            <Progress value={s.uncertainty_score * 100} className="h-2" />
            <div className="flex flex-wrap gap-1">
              {s.suggested_labels.map((label, i) => (
                <span
                  key={i}
                  className="inline-flex items-center rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-primary"
                >
                  {label}
                </span>
              ))}
            </div>
            <p className="text-xs text-muted-foreground italic">{s.reason}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
