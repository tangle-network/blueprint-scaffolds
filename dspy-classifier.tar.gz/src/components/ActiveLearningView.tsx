import { useState } from 'react';
import { getUncertainSamples, submitLabels } from '../api';
import type { UncertainSample } from '../types';

const AVAILABLE_LABELS = [
  'Technology', 'Science', 'Health', 'Finance', 'Business',
  'Politics', 'Sports', 'Entertainment', 'Environment', 'Education',
  'AI', 'Web', 'Mobile', 'Space', 'Biology', 'Physics', 'Chemistry',
];

export function ActiveLearningView() {
  const [samples, setSamples] = useState<UncertainSample[]>([]);
  const [selectedLabels, setSelectedLabels] = useState<Record<number, string[]>>({});
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const fetchUncertain = async () => {
    setLoading(true);
    setError('');
    try {
      const s = await getUncertainSamples(10);
      setSamples(s);
      setSelectedLabels({});
      setSubmitted(false);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const toggleLabel = (sampleId: number, label: string) => {
    setSelectedLabels((prev) => {
      const current = prev[sampleId] || [];
      const next = current.includes(label)
        ? current.filter((l) => l !== label)
        : [...current, label];
      return { ...prev, [sampleId]: next };
    });
  };

  const handleSubmit = async () => {
    const labeled = Object.entries(selectedLabels)
      .filter(([, labels]) => labels.length > 0)
      .map(([id, labels]) => ({ id: Number(id), labels }));
    if (!labeled.length) return;
    setSubmitting(true);
    setError('');
    try {
      await submitLabels(labeled);
      setSubmitted(true);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div>
      <div className="card">
        <h2>Active Learning</h2>
        <p style={{ color: 'var(--text-dim)', fontSize: 14, marginBottom: 16 }}>
          Query the model for its most uncertain predictions. Label them to improve
          the classifier through iterative human-in-the-loop feedback.
        </p>
        <div className="actions">
          <button className="btn btn-primary" onClick={fetchUncertain} disabled={loading}>
            {loading && <span className="spinner" />}
            {loading ? 'Fetching...' : 'Fetch Uncertain Samples'}
          </button>
        </div>
      </div>

      {error && (
        <div className="card" style={{ borderColor: 'var(--danger)' }}>
          <p style={{ color: 'var(--danger)' }}>{error}</p>
        </div>
      )}

      {submitted && (
        <div className="card" style={{ borderColor: 'var(--success)' }}>
          <p style={{ color: 'var(--success)' }}>Labels submitted successfully!</p>
        </div>
      )}

      {samples.length > 0 && (
        <div className="card">
          <h3>Uncertain Samples ({samples.length})</h3>
          {samples.map((s) => (
            <div className="uncertain-item" key={s.id}>
              <div className="uncertainty-text">{s.text}</div>
              <div style={{ marginBottom: 8 }}>
                <small style={{ color: 'var(--text-dim)' }}>Model predictions:</small>
                <div className="result-labels" style={{ marginTop: 4 }}>
                  {s.predictions.map((p, i) => (
                    <span key={i} className="tag tag-warning">
                      {p.label} ({(p.score * 100).toFixed(1)}%)
                    </span>
                  ))}
                </div>
              </div>
              <div style={{ marginBottom: 4 }}>
                <small style={{ color: 'var(--text-dim)' }}>
                  Entropy: <span style={{ color: 'var(--warning)' }}>{s.entropy.toFixed(3)}</span>
                </small>
              </div>
              <div>
                <small style={{ color: 'var(--text-dim)' }}>Select correct labels:</small>
                <div className="label-selector">
                  {AVAILABLE_LABELS.map((label) => (
                    <button
                      key={label}
                      className={`label-option ${(selectedLabels[s.id] || []).includes(label) ? 'selected' : ''}`}
                      onClick={() => toggleLabel(s.id, label)}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ))}
          <div className="actions">
            <button
              className="btn btn-success"
              onClick={handleSubmit}
              disabled={submitting || Object.values(selectedLabels).every((l) => l.length === 0)}
            >
              {submitting && <span className="spinner" />}
              Submit Labels
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
