import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { getMetrics } from "@/lib/api";
import type { CrossValidationMetrics } from "@/types";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from "recharts";

export function MetricsPanel() {
  const [metrics, setMetrics] = useState<CrossValidationMetrics | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadMetrics = async () => {
    setLoading(true);
    setError(null);
    try {
      const m = await getMetrics();
      setMetrics(m);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load metrics");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadMetrics();
  }, []);

  const perLabelData = metrics
    ? Object.entries(metrics.per_label_metrics).map(([label, m]) => ({
        label,
        precision: Number((m.precision * 100).toFixed(1)),
        recall: Number((m.recall * 100).toFixed(1)),
        f1: Number((m.f1 * 100).toFixed(1)),
        support: m.support,
      }))
    : [];

  const radarData = metrics
    ? [
        { metric: "Accuracy", value: Number((metrics.accuracy * 100).toFixed(1)) },
        { metric: "Precision", value: Number((metrics.precision * 100).toFixed(1)) },
        { metric: "Recall", value: Number((metrics.recall * 100).toFixed(1)) },
        { metric: "F1", value: Number((metrics.f1 * 100).toFixed(1)) },
      ]
    : [];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Cross-Validation Metrics</CardTitle>
              <CardDescription>Model performance from k-fold cross-validation</CardDescription>
            </div>
            <Button onClick={loadMetrics} disabled={loading} variant="outline" size="sm">
              {loading ? "Loading..." : "Refresh"}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {error && <p className="text-sm text-destructive mb-4">{error}</p>}
          {metrics && (
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-3">
                <h3 className="text-sm font-semibold uppercase text-muted-foreground">
                  Overall Metrics
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { label: "Accuracy", value: metrics.accuracy },
                    { label: "Precision", value: metrics.precision },
                    { label: "Recall", value: metrics.recall },
                    { label: "F1 Score", value: metrics.f1 },
                  ].map(({ label, value }) => (
                    <div key={label} className="rounded-lg border p-3 text-center">
                      <p className="text-2xl font-bold">{(value * 100).toFixed(1)}%</p>
                      <p className="text-xs text-muted-foreground">{label}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-sm font-semibold uppercase text-muted-foreground mb-3">
                  Radar Overview
                </h3>
                <ResponsiveContainer width="100%" height={200}>
                  <RadarChart data={radarData}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="metric" tick={{ fontSize: 11 }} />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} />
                    <Radar
                      name="Score"
                      dataKey="value"
                      stroke="hsl(222.2, 47.4%, 11.2%)"
                      fill="hsl(222.2, 47.4%, 11.2%)"
                      fillOpacity={0.3}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {metrics && perLabelData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Per-Label Metrics</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={Math.max(300, perLabelData.length * 40)}>
              <BarChart data={perLabelData} layout="vertical" margin={{ left: 80 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 11 }} />
                <YAxis dataKey="label" type="category" tick={{ fontSize: 11 }} width={80} />
                <Tooltip />
                <Legend />
                <Bar dataKey="precision" fill="hsl(221, 83%, 53%)" name="Precision" />
                <Bar dataKey="recall" fill="hsl(142, 71%, 45%)" name="Recall" />
                <Bar dataKey="f1" fill="hsl(38, 92%, 50%)" name="F1" />
              </BarChart>
            </ResponsiveContainer>

            <Separator className="my-4" />

            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-2 px-3">Label</th>
                    <th className="text-right py-2 px-3">Precision</th>
                    <th className="text-right py-2 px-3">Recall</th>
                    <th className="text-right py-2 px-3">F1</th>
                    <th className="text-right py-2 px-3">Support</th>
                  </tr>
                </thead>
                <tbody>
                  {perLabelData.map((row) => (
                    <tr key={row.label} className="border-b last:border-0">
                      <td className="py-2 px-3 font-medium">{row.label}</td>
                      <td className="text-right py-2 px-3">{row.precision}%</td>
                      <td className="text-right py-2 px-3">{row.recall}%</td>
                      <td className="text-right py-2 px-3">{row.f1}%</td>
                      <td className="text-right py-2 px-3">{row.support}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
