import { useState } from 'react';
import { optimize } from '../api';
import type { OptimizationResult, TrainingExample } from '../types';

const SAMPLE_DATA: TrainingExample[] = [
  { text: 'New breakthrough in quantum computing achieves error correction', labels: ['Technology', 'Science'] },
  { text: 'Stock market reaches all-time high on tech earnings', labels: ['Business', 'Finance'] },
  { text: 'Machine learning model predicts protein structures accurately', labels: ['Technology', 'AI', 'Science'] },
  { text: 'Federal Reserve signals potential rate cuts in coming months', labels: ['Business', 'Finance'] },
  { text: 'NASA discovers high concentrations of organic molecules on Mars', labels: ['Science', 'Space'] },
  { text: 'New JavaScript framework promises faster rendering with zero config', labels: ['Technology', 'Web'] },
  { text: 'Global supply chain disruptions continue to affect semiconductor industry', labels: ['Business', 'Technology'] },
  { text: 'Clinical trials show promising results for new Alzheimer treatment', labels: ['Science', 'Health'] },
];

export function OptimizeView() {
  const [examples, setExamples] = useState<TrainingExample[]>(SAMPLE_DATA);
  const [iterations, setIterations] = useState(5);
  const [result, setResult] = useState<OptimizationResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const addExample = () => setExamples([...examples, { text: '', labels: [] }]);
  const removeExample = (i: number) => setExamples(examples.filter((_, idx) => idx !== i));
  const updateText = (i: number, text: string) => {
    const next = [...examples];
    next[i] = { ...next[i], text };
    setExamples(next);
  };
  const updateLabels = (i: number, labels: string) => {
    const next = [...examples];
    next[i] = { ...next[i], labels: labels.split(',').map((l) => l.trim()).filter(Boolean) };
    setExamples(next);
  };

  const handleOptimize = async () => {
    const valid = examples.filter((e) => e.text.trim() && e.labels.length > 0);
    if (!valid.length) return;
    setLoading(true);
    setError('');
    try {
      const r = await optimize(valid, iterations);
      setResult(r);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <div className="card">
        <h2>Few-Shot Bootstrap Optimization</h2>
        <p style={{ color: 'var(--text-dim)', fontSize: 14, marginBottom: 16 }}>
          Provide labeled examples for DSPy's BootstrapFewShot optimizer. The system will
          automatically select the best demonstrations and compile an optimized classifier.
        </p>

        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th style={{ width: '60%' }}>Text</th>
                <th style={{ width: '30%' }}>Labels (comma-separated)</th>
                <th style={{ width: '10%' }}></th>
              </tr>
            </thead>
            <tbody>
              {examples.map((ex, i) => (
                <tr key={i}>
                  <td>
                    <input
                      type="text"
                      value={ex.text}
                      onChange={(e) => updateText(i, e.target.value)}
                      placeholder="Enter training text..."
                      style={{ width: '100%' }}
                    />
                  </td>
                  <td>
                    <input
                      type="text"
                      value={ex.labels.join(', ')}
                      onChange={(e) => updateLabels(i, e.target.value)}
                      placeholder="label1, label2"
                      style={{ width: '100%' }}
                    />
                  </td>
                  <td>
                    <button className="btn btn-danger" onClick={() => removeExample(i)} style={{ padding: '4px 10px' }}>
                      ×
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="actions">
          <button className="btn btn-secondary" onClick={addExample}>+ Add Example</button>
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'var(--text-dim)', fontSize: 14 }}>
            Iterations:
            <input
              type="text"
              value={iterations}
              onChange={(e) => setIterations(Number(e.target.value) || 5)}
              style={{ width: 60, textAlign: 'center' }}
            />
          </label>
          <button className="btn btn-primary" onClick={handleOptimize} disabled={loading}>
            {loading && <span className="spinner" />}
            {loading ? 'Optimizing...' : 'Run Optimization'}
          </button>
        </div>
      </div>

      {error && (
        <div className="card" style={{ borderColor: 'var(--danger)' }}>
          <p style={{ color: 'var(--danger)' }}>{error}</p>
        </div>
      )}

      {result && (
        <div className="card">
          <h2>Optimization Result</h2>
          <div className="stats-grid">
            <div className="stat-card">
              <div className="stat-value">{(result.score_before * 100).toFixed(1)}%</div>
              <div className="stat-label">Score Before</div>
            </div>
            <div className="stat-card">
              <div className="stat-value" style={{ color: 'var(--success)' }}>
                {(result.score_after * 100).toFixed(1)}%
              </div>
              <div className="stat-label">Score After</div>
            </div>
            <div className="stat-card">
              <div className="stat-value">{result.demonstrations_used}</div>
              <div className="stat-label">Demos Used</div>
            </div>
            <div className="stat-card">
              <div className="stat-value">{result.iterations}</div>
              <div className="stat-label">Iterations</div>
            </div>
          </div>
          <div className="confidence-bar" style={{ height: 12 }}>
            <div
              className="confidence-fill"
              style={{ width: `${result.score_after * 100}%`, background: 'var(--success)' }}
            />
          </div>
          <p style={{ color: 'var(--text-dim)', fontSize: 13, marginTop: 8 }}>
            Improvement: +{((result.score_after - result.score_before) * 100).toFixed(1)} percentage points
          </p>
        </div>
      )}
    </div>
  );
}
