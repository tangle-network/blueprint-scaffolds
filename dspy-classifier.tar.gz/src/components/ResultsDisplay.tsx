import type { ClassificationResult, LabelScore } from "@/types";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";

interface ResultsDisplayProps {
  results: ClassificationResult[];
}

function HierarchyBadge({ path }: { path: string[] }) {
  return (
    <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
      {path.map((p, i) => (
        <span key={i} className="flex items-center gap-1">
          {i > 0 && <span className="text-muted-foreground/50">&rsaquo;</span>}
          <span className="bg-muted px-1.5 py-0.5 rounded">{p}</span>
        </span>
      ))}
    </span>
  );
}

function LabelRow({ label }: { label: LabelScore }) {
  const pct = Math.round(label.confidence * 100);
  return (
    <div className="flex items-center gap-3 py-2">
      <div className="w-32 flex-shrink-0">
        <span className="font-medium text-sm">{label.label}</span>
      </div>
      <div className="flex-1">
        <Progress value={pct} className="h-3" />
      </div>
      <div className="w-16 text-right text-sm font-mono">{pct}%</div>
      <div className="flex-shrink-0">
        <HierarchyBadge path={label.hierarchy_path} />
      </div>
    </div>
  );
}

export function ResultsDisplay({ results }: ResultsDisplayProps) {
  if (results.length === 0) return null;

  return (
    <div className="space-y-4">
      {results.map((result, idx) => (
        <Card key={idx}>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">
              Result {results.length > 1 ? `#${idx + 1}` : ""}
            </CardTitle>
            <p className="text-sm text-muted-foreground line-clamp-2 italic">
              "{result.text.slice(0, 200)}
              {result.text.length > 200 ? "..." : ""}"
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            {result.reasoning && (
              <div className="rounded-md bg-muted/50 p-3">
                <p className="text-xs font-semibold uppercase text-muted-foreground mb-1">
                  Chain-of-Thought Reasoning
                </p>
                <p className="text-sm whitespace-pre-wrap">{result.reasoning}</p>
              </div>
            )}

            <Separator />

            <div>
              <p className="text-xs font-semibold uppercase text-muted-foreground mb-2">
                Predicted Labels
              </p>
              <div className="space-y-1">
                {result.labels.map((label, i) => (
                  <LabelRow key={i} label={label} />
                ))}
              </div>
            </div>

            <p className="text-xs text-muted-foreground">
              Model: {result.model_used}
            </p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
