import { useState } from "react";
import { api } from "../api";
import type { ClassifyResponse } from "../types";
import ConfidenceChart from "./ConfidenceChart";

export default function ClassifyPanel() {
  const [text, setText] = useState("");
  const [cats, setCats] = useState("");
  const [multiLabel, setMultiLabel] = useState(false);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ClassifyResponse | null>(null);
  const [error, setError] = useState("");

  const handleClassify = async () => {
    if (!text.trim()) return;
    setLoading(true);
    setError("");
    setResult(null);
    try {
      const categories = cats.trim()
        ? cats.split(",").map((c) => c.trim())
        : undefined;
      const res = await api.classify(text, categories, multiLabel);
      setResult(res);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "Classification failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ display: "grid", gap: 16 }}>
      <div className="card">
        <h3 style={{ marginBottom: 12 }}>Single Text Classification</h3>
        <div style={{ display: "grid", gap: 12 }}>
          <textarea
            rows={4}
            placeholder="Enter text to classify..."
            value={text}
            onChange={(e) => setText(e.target.value)}
            style={{ resize: "vertical" }}
          />
          <input
            placeholder="Categories (comma-separated, leave empty for server defaults)"
            value={cats}
            onChange={(e) => setCats(e.target.value)}
          />
          <label
            style={{
              display: "flex",
              alignItems: "center",
              gap: 8,
              fontSize: 14,
            }}
          >
            <input
              type="checkbox"
              checked={multiLabel}
              onChange={(e) => setMultiLabel(e.target.checked)}
            />
            Multi-label classification
          </label>
          <button
            className="primary-btn"
            disabled={loading || !text.trim()}
            onClick={handleClassify}
          >
            {loading ? "Classifying..." : "Classify"}
          </button>
        </div>
      </div>

      {error && (
        <div className="card" style={{ borderLeft: "3px solid var(--danger)" }}>
          <p style={{ color: "var(--danger)" }}>{error}</p>
        </div>
      )}

      {result && (
        <div className="card">
          <h3 style={{ marginBottom: 12 }}>Result</h3>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: 16,
            }}
          >
            <div>
              <p style={{ color: "var(--text-dim)", fontSize: 13 }}>
                Predicted Label
              </p>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                {result.label.split(",").map((l) => (
                  <span key={l} className="tag tag-primary">
                    {l.trim()}
                  </span>
                ))}
              </div>
            </div>
            <div>
              <p style={{ color: "var(--text-dim)", fontSize: 13 }}>
                Confidence
              </p>
              <span
                className={`tag ${
                  result.confidence >= 0.8
                    ? "tag-success"
                    : result.confidence >= 0.5
                    ? "tag-warning"
                    : "tag-danger"
                }`}
                style={{ fontSize: 16, fontWeight: 700 }}
              >
                {(result.confidence * 100).toFixed(1)}%
              </span>
            </div>
          </div>
          <div style={{ marginTop: 16 }}>
            <p style={{ color: "var(--text-dim)", fontSize: 13, marginBottom: 6 }}>
              Chain-of-Thought Reasoning
            </p>
            <div
              style={{
                background: "var(--bg)",
                padding: 12,
                borderRadius: "var(--radius)",
                fontSize: 14,
                whiteSpace: "pre-wrap",
                lineHeight: 1.5,
              }}
            >
              {result.reasoning}
            </div>
          </div>
          <div style={{ marginTop: 16 }}>
            <ConfidenceChart confidence={result.confidence} />
          </div>
        </div>
      )}
    </div>
  );
}
