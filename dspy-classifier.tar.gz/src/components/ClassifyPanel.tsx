import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ResultsDisplay } from "@/components/ResultsDisplay";
import { classifySingle } from "@/lib/api";
import type { ClassificationResult } from "@/types";

export function ClassifyPanel() {
  const [text, setText] = useState("");
  const [mode, setMode] = useState<"multi_class" | "multi_label">("multi_class");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ClassificationResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleClassify = async () => {
    if (!text.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const res = await classifySingle(text, mode);
      setResult(res);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Classification failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Single Classification</CardTitle>
          <CardDescription>
            Enter text to classify using the optimized DSPy model
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="input-text">Text Input</Label>
            <Textarea
              id="input-text"
              placeholder="Enter text to classify..."
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={6}
            />
          </div>

          <div className="space-y-2">
            <Label>Classification Mode</Label>
            <div className="flex gap-2">
              <Button
                variant={mode === "multi_class" ? "default" : "outline"}
                size="sm"
                onClick={() => setMode("multi_class")}
              >
                Multi-Class
              </Button>
              <Button
                variant={mode === "multi_label" ? "default" : "outline"}
                size="sm"
                onClick={() => setMode("multi_label")}
              >
                Multi-Label
              </Button>
            </div>
          </div>

          <Button
            onClick={handleClassify}
            disabled={loading || !text.trim()}
            className="w-full"
          >
            {loading ? "Classifying..." : "Classify"}
          </Button>

          {error && (
            <p className="text-sm text-destructive">{error}</p>
          )}
        </CardContent>
      </Card>

      <div>
        {result ? (
          <ResultsDisplay results={[result]} />
        ) : (
          <Card>
            <CardContent className="flex items-center justify-center h-64 text-muted-foreground">
              Enter text and click Classify to see results
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
