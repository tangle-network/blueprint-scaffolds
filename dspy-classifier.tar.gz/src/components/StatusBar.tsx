import { useEffect } from "react";
import { api } from "../api";
import type { StatusResponse } from "../types";

interface Props {
  status: StatusResponse | null;
  onRefresh: (s: StatusResponse) => void;
}

export default function StatusBar({ status, onRefresh }: Props) {
  useEffect(() => {
    api.getStatus().then(onRefresh).catch(() => {});
  }, []);

  return (
    <div
      className="card"
      style={{
        display: "flex",
        gap: 24,
        alignItems: "center",
        marginBottom: 20,
        padding: "12px 20px",
        fontSize: 13,
      }}
    >
      <span>
        <span style={{ color: "var(--text-dim)" }}>Status:</span>{" "}
        <span
          className={`tag ${
            status?.status === "ready" ? "tag-success" : "tag-warning"
          }`}
        >
          {status?.status ?? "checking..."}
        </span>
      </span>
      <span>
        <span style={{ color: "var(--text-dim)" }}>Model:</span>{" "}
        {status?.model ?? "none"}
      </span>
      <span>
        <span style={{ color: "var(--text-dim)" }}>Categories:</span>{" "}
        {status?.categories.length ? status.categories.join(", ") : "none"}
      </span>
      <span>
        <span style={{ color: "var(--text-dim)" }}>Training examples:</span>{" "}
        {status?.training_examples ?? 0}
      </span>
      <button
        className="secondary-btn"
        style={{ marginLeft: "auto", padding: "6px 14px", fontSize: 12 }}
        onClick={() => api.getStatus().then(onRefresh)}
      >
        Refresh
      </button>
    </div>
  );
}
