import { useState } from 'react';
import { crossValidate } from '../api';
import type { CrossValidationMetrics, TrainingExample, ClassMetrics } from '../types';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
  Legend,
} from 'recharts';

const SAMPLE_DATA: TrainingExample[] = [
  { text: 'Quantum computing breakthrough announced by Google', labels: ['Technology'] },
  { text: 'New cancer treatment shows 90% remission rate', labels: ['Health'] },
  { text: 'S&P 500 surges to record high on strong earnings', labels: ['Finance'] },
  { text: 'Mars rover discovers evidence of ancient water flows', labels: ['Science'] },
  { text: 'React 19 introduces server components by default', labels: ['Technology'] },
  { text: 'WHO declares end to global health emergency', labels: ['Health'] },
  { text: 'Bitcoin mining difficulty reaches all-time high', labels: ['Finance'] },
  { text: 'CRISPR gene editing trials approved for sickle cell', labels: ['Science'] },
  { text: 'Apple announces M5 chip with neural engine upgrades', labels: ['Technology'] },
  { text: 'New study links ultra-processed foods to heart disease', labels: ['Health'] },
  { text: 'Fed signals pause in interest rate hikes', labels: ['Finance'] },
  { text: 'James Webb telescope captures new galaxy formation images', labels: ['Science'] },
];

export function MetricsView() {
  const [examples, setExamples] = useState<TrainingExample[]>(SAMPLE_DATA);
  const [k, setK] = useState(5);
  const [metrics, setMetrics] = useState<CrossValidationMetrics | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleValidate = async () => {
    const valid = examples.filter((e) => e.text.trim() && e.labels.length > 0);
    if (!valid.length) return;
    setLoading(true);
    setError('');
    try {
      const r = await crossValidate(valid, k);
      setMetrics(r);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const barData = metrics
    ? Object.entries(metrics.per_class).map(([name, m]: [string, ClassMetrics]) => ({
        name,
        precision: +(m.precision * 100).toFixed(1),
        recall: +(m.recall * 100).toFixed(1),
        f1: +(m.f1 * 100).toFixed(1),
      }))
    : [];

  const radarData = metrics
    ? [
        { metric: 'Accuracy', value: +(metrics.accuracy * 100).toFixed(1) },
        { metric: 'F1 Macro', value: +(metrics.f1_macro * 100).toFixed(1) },
        { metric: 'F1 Weighted', value: +(metrics.f1_weighted * 100).toFixed(1) },
        { metric: 'Precision Macro', value: +(metrics.precision_macro * 100).toFixed(1) },
        { metric: 'Recall Macro', value: +(metrics.recall_macro * 100).toFixed(1) },
      ]
    : [];

  return (
    <div>
      <div className="card">
        <h2>Cross-Validation Metrics</h2>
        <p style={{ color: 'var(--text-dim)', fontSize: 14, marginBottom: 16 }}>
          Run k-fold cross-validation on labeled data to evaluate classifier performance
          with precision, recall, F1, and confusion matrix visualization.
        </p>

        <div className="table-wrapper">
          <table>
            <thead>
              <tr><th>Text</th><th>Labels</th></tr>
            </thead>
            <tbody>
              {examples.map((ex, i) => (
                <tr key={i}>
                  <td style={{ maxWidth: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {ex.text}
                  </td>
                  <td>
                    {ex.labels.map((l, j) => (
                      <span key={j} className="tag tag-info" style={{ marginRight: 4 }}>{l}</span>
                    ))}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="actions">
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'var(--text-dim)', fontSize: 14 }}>
            K-Folds:
            <input type="text" value={k} onChange={(e) => setK(Number(e.target.value) || 5)} style={{ width: 60, textAlign: 'center' }} />
          </label>
          <button className="btn btn-primary" onClick={handleValidate} disabled={loading}>
            {loading && <span className="spinner" />}
            {loading ? 'Evaluating...' : `Run ${k}-Fold CV`}
          </button>
        </div>
      </div>

      {error && (
        <div className="card" style={{ borderColor: 'var(--danger)' }}>
          <p style={{ color: 'var(--danger)' }}>{error}</p>
        </div>
      )}

      {metrics && (
        <>
          <div className="stats-grid">
            <div className="stat-card">
              <div className="stat-value">{(metrics.accuracy * 100).toFixed(1)}%</div>
              <div className="stat-label">Accuracy</div>
            </div>
            <div className="stat-card">
              <div className="stat-value">{(metrics.f1_macro * 100).toFixed(1)}%</div>
              <div className="stat-label">F1 Macro</div>
            </div>
            <div className="stat-card">
              <div className="stat-value">{(metrics.precision_macro * 100).toFixed(1)}%</div>
              <div className="stat-label">Precision Macro</div>
            </div>
            <div className="stat-card">
              <div className="stat-value">{(metrics.recall_macro * 100).toFixed(1)}%</div>
              <div className="stat-label">Recall Macro</div>
            </div>
          </div>

          <div className="grid-2">
            <div className="card">
              <h3>Per-Class Metrics</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={barData}>
                  <XAxis dataKey="name" stroke="#8b8da0" fontSize={12} />
                  <YAxis stroke="#8b8da0" fontSize={12} />
                  <Tooltip
                    contentStyle={{ background: '#1a1b26', border: '1px solid #2e3047', borderRadius: 8 }}
                  />
                  <Legend />
                  <Bar dataKey="precision" fill="#6366f1" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="recall" fill="#22c55e" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="f1" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="card">
              <h3>Overall Metrics</h3>
              <ResponsiveContainer width="100%" height={300}>
                <RadarChart data={radarData}>
                  <PolarGrid stroke="#2e3047" />
                  <PolarAngleAxis dataKey="metric" stroke="#8b8da0" fontSize={12} />
                  <PolarRadiusAxis angle={90} domain={[0, 100]} stroke="#2e3047" fontSize={10} />
                  <Radar name="Score" dataKey="value" stroke="#6366f1" fill="#6366f1" fillOpacity={0.3} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {metrics.confusion_matrix.length > 0 && (
            <div className="card">
              <h3>Confusion Matrix</h3>
              <div className="table-wrapper">
                <table>
                  <thead>
                    <tr>
                      <th>Predicted →</th>
                      {metrics.class_names.map((n) => (
                        <th key={n} style={{ fontSize: 11 }}>{n}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {metrics.confusion_matrix.map((row, i) => (
                      <tr key={i}>
                        <td style={{ fontWeight: 600 }}>{metrics.class_names[i]}</td>
                        {row.map((val, j) => (
                          <td
                            key={j}
                            style={{
                              background: i === j ? 'rgba(34, 197, 94, 0.15)' : val > 0 ? 'rgba(239, 68, 68, 0.1)' : 'transparent',
                              textAlign: 'center',
                              fontWeight: i === j ? 700 : 400,
                            }}
                          >
                            {val}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
