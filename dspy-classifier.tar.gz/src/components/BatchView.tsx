import { useState } from 'react';
import { classifyBatch } from '../api';
import type { ClassificationResult } from '../types';

export function BatchView() {
  const [items, setItems] = useState<string[]>(['']);
  const [multiLabel, setMultiLabel] = useState(false);
  const [results, setResults] = useState<ClassificationResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const addItem = () => setItems([...items, '']);
  const removeItem = (i: number) => setItems(items.filter((_, idx) => idx !== i));
  const updateItem = (i: number, v: string) => {
    const next = [...items];
    next[i] = v;
    setItems(next);
  };

  const handleBatch = async () => {
    const texts = items.filter((t) => t.trim());
    if (!texts.length) return;
    setLoading(true);
    setError('');
    try {
      const r = await classifyBatch(texts, multiLabel);
      setResults(r);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const confidenceColor = (c: number) => {
    if (c >= 0.8) return 'var(--success)';
    if (c >= 0.5) return 'var(--warning)';
    return 'var(--danger)';
  };

  return (
    <div>
      <div className="card">
        <h2>Batch Classification</h2>
        {items.map((item, i) => (
          <div className="batch-item" key={i}>
            <input
              type="text"
              placeholder={`Text ${i + 1}...`}
              value={item}
              onChange={(e) => updateItem(i, e.target.value)}
              style={{ flex: 1 }}
            />
            {items.length > 1 && (
              <button className="btn btn-danger" onClick={() => removeItem(i)} style={{ fontSize: 18 }}>
                ×
              </button>
            )}
          </div>
        ))}
        <div className="actions">
          <button className="btn btn-secondary" onClick={addItem}>+ Add Item</button>
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'var(--text-dim)', fontSize: 14 }}>
            <input type="checkbox" checked={multiLabel} onChange={(e) => setMultiLabel(e.target.checked)} />
            Multi-label
          </label>
          <button className="btn btn-primary" onClick={handleBatch} disabled={loading}>
            {loading && <span className="spinner" />}
            {loading ? 'Processing...' : 'Classify All'}
          </button>
        </div>
      </div>

      {error && (
        <div className="card" style={{ borderColor: 'var(--danger)' }}>
          <p style={{ color: 'var(--danger)' }}>{error}</p>
        </div>
      )}

      {results.length > 0 && (
        <div className="card">
          <h2>Batch Results ({results.length} items)</h2>
          {results.map((r, i) => (
            <div className="result-item" key={i}>
              <div className="result-text">
                <strong>#{i + 1}</strong> {r.text}
              </div>
              {r.reasoning && (
                <div className="reasoning-block">{r.reasoning}</div>
              )}
              <div className="result-labels">
                {r.labels.map((l, j) => (
                  <span key={j} className="tag tag-primary">
                    {l.label} <small>({(l.score * 100).toFixed(1)}%)</small>
                  </span>
                ))}
              </div>
              <div className="confidence-bar" style={{ maxWidth: 200 }}>
                <div
                  className="confidence-fill"
                  style={{
                    width: `${r.confidence * 100}%`,
                    background: confidenceColor(r.confidence),
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
