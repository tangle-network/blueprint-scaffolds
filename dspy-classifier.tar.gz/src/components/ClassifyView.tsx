import { useState } from 'react';
import { classifySingle } from '../api';
import type { ClassificationResult, CategoryNode } from '../types';
import { CategoryTreeInput } from './CategoryTreeInput';

export function ClassifyView() {
  const [text, setText] = useState('');
  const [multiLabel, setMultiLabel] = useState(false);
  const [categoryTree, setCategoryTree] = useState<CategoryNode | undefined>(undefined);
  const [useHierarchy, setUseHierarchy] = useState(false);
  const [result, setResult] = useState<ClassificationResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleClassify = async () => {
    if (!text.trim()) return;
    setLoading(true);
    setError('');
    try {
      const r = await classifySingle(text, multiLabel, useHierarchy ? categoryTree : undefined);
      setResult(r);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const confidenceColor = (c: number) => {
    if (c >= 0.8) return 'var(--success)';
    if (c >= 0.5) return 'var(--warning)';
    return 'var(--danger)';
  };

  return (
    <div>
      <div className="card">
        <h2>Single Text Classification</h2>
        <textarea
          placeholder="Enter text to classify..."
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        <div className="actions">
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'var(--text-dim)', fontSize: 14 }}>
            <input type="checkbox" checked={multiLabel} onChange={(e) => setMultiLabel(e.target.checked)} />
            Multi-label
          </label>
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'var(--text-dim)', fontSize: 14 }}>
            <input type="checkbox" checked={useHierarchy} onChange={(e) => setUseHierarchy(e.target.checked)} />
            Hierarchical
          </label>
          <button className="btn btn-primary" onClick={handleClassify} disabled={loading || !text.trim()}>
            {loading && <span className="spinner" />}
            {loading ? 'Classifying...' : 'Classify'}
          </button>
        </div>
      </div>

      {useHierarchy && (
        <CategoryTreeInput tree={categoryTree} onChange={setCategoryTree} />
      )}

      {error && (
        <div className="card" style={{ borderColor: 'var(--danger)' }}>
          <p style={{ color: 'var(--danger)' }}>{error}</p>
        </div>
      )}

      {result && (
        <div className="card">
          <h2>Result</h2>
          <div className="result-item">
            <div className="result-text">{result.text}</div>

            {result.reasoning && (
              <div className="reasoning-block">
                <strong>Reasoning:</strong> {result.reasoning}
              </div>
            )}

            <div className="result-labels">
              {result.labels.map((l, i) => (
                <span key={i} className="tag tag-primary">
                  {l.path ? l.path.join(' > ') + ' > ' : ''}{l.label}
                  <small style={{ opacity: 0.7 }}>({(l.score * 100).toFixed(1)}%)</small>
                </span>
              ))}
            </div>

            <div style={{ marginTop: 12 }}>
              <small style={{ color: 'var(--text-dim)' }}>Overall Confidence</small>
              <div className="confidence-bar">
                <div
                  className="confidence-fill"
                  style={{
                    width: `${result.confidence * 100}%`,
                    background: confidenceColor(result.confidence),
                  }}
                />
              </div>
              <small style={{ color: confidenceColor(result.confidence) }}>
                {(result.confidence * 100).toFixed(1)}%
              </small>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
