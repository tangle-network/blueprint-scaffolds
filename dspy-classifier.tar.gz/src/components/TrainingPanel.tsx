import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { trainModel, getOptimizationStatus } from "@/lib/api";
import type { OptimizationStatus } from "@/types";

export function TrainingPanel() {
  const [examples, setExamples] = useState(
    `{"text": "The stock market rallied today", "labels": ["finance", "markets"], "reasoning": "Text discusses stock market movements"}\n{"text": "New AI model achieves state-of-the-art results", "labels": ["technology", "artificial-intelligence"], "reasoning": "Text is about AI technology advancement"}\n{"text": "The team won the championship game", "labels": ["sports", "basketball"], "reasoning": "Text describes a sports championship"}`
  );
  const [numFolds, setNumFolds] = useState(5);
  const [maxDemos, setMaxDemos] = useState(4);
  const [training, setTraining] = useState(false);
  const [status, setStatus] = useState<OptimizationStatus | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleTrain = async () => {
    setTraining(true);
    setError(null);
    setStatus(null);

    try {
      const lines = examples.split("\n").filter((l) => l.trim());
      const parsedExamples = lines.map((line) => JSON.parse(line));

      const result = await trainModel({
        examples: parsedExamples,
        num_folds: numFolds,
        max_bootstrapped_demos: maxDemos,
      });
      setStatus(result);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Training failed");
    } finally {
      setTraining(false);
    }
  };

  const handleCheckStatus = async () => {
    try {
      const s = await getOptimizationStatus();
      setStatus(s);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to check status");
    }
  };

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Train Model</CardTitle>
          <CardDescription>
            Optimize the DSPy classifier using few-shot bootstrap from labeled examples
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="examples">Training Examples (JSONL)</Label>
            <Textarea
              id="examples"
              value={examples}
              onChange={(e) => setExamples(e.target.value)}
              rows={10}
              className="font-mono text-xs"
              placeholder={'{"text": "...", "labels": ["..."], "reasoning": "..."}'}
            />
            <p className="text-xs text-muted-foreground">
              One JSON object per line with text, labels, and optional reasoning
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="folds">Cross-Validation Folds</Label>
              <Input
                id="folds"
                type="number"
                min={2}
                max={10}
                value={numFolds}
                onChange={(e) => setNumFolds(Number(e.target.value))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="demos">Max Bootstrapped Demos</Label>
              <Input
                id="demos"
                type="number"
                min={1}
                max={16}
                value={maxDemos}
                onChange={(e) => setMaxDemos(Number(e.target.value))}
              />
            </div>
          </div>

          <div className="flex gap-2">
            <Button onClick={handleTrain} disabled={training} className="flex-1">
              {training ? "Training..." : "Start Training"}
            </Button>
            <Button onClick={handleCheckStatus} variant="outline">
              Check Status
            </Button>
          </div>

          {error && <p className="text-sm text-destructive">{error}</p>}
        </CardContent>
      </Card>

      <div>
        {status ? (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Training Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3">
                <span
                  className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                    status.status === "completed"
                      ? "bg-green-100 text-green-800"
                      : status.status === "running"
                        ? "bg-blue-100 text-blue-800"
                        : status.status === "error"
                          ? "bg-red-100 text-red-800"
                          : "bg-gray-100 text-gray-800"
                  }`}
                >
                  {status.status}
                </span>
                <span className="text-sm">{status.message}</span>
              </div>

              <Progress value={status.progress * 100} className="h-2" />

              <Separator />

              {status.metrics && (
                <div className="space-y-2">
                  <p className="text-xs font-semibold uppercase text-muted-foreground">
                    Cross-Validation Results
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { label: "Accuracy", value: status.metrics.accuracy },
                      { label: "Precision", value: status.metrics.precision },
                      { label: "Recall", value: status.metrics.recall },
                      { label: "F1 Score", value: status.metrics.f1 },
                    ].map(({ label, value }) => (
                      <div key={label} className="rounded-md border p-2 text-center">
                        <p className="text-lg font-bold">{(value * 100).toFixed(1)}%</p>
                        <p className="text-xs text-muted-foreground">{label}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="flex items-center justify-center h-64 text-muted-foreground">
              Submit training examples to begin optimization
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
