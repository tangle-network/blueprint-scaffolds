import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ResultsDisplay } from "@/components/ResultsDisplay";
import { classifyBatch } from "@/lib/api";
import type { BatchClassificationResult } from "@/types";

export function BatchPanel() {
  const [texts, setTexts] = useState("");
  const [mode, setMode] = useState<"multi_class" | "multi_label">("multi_class");
  const [loading, setLoading] = useState(false);
  const [batchResult, setBatchResult] = useState<BatchClassificationResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleBatch = async () => {
    const lines = texts.split("\n").map((l) => l.trim()).filter(Boolean);
    if (lines.length === 0) return;
    setLoading(true);
    setError(null);
    try {
      const res = await classifyBatch(lines, mode);
      setBatchResult(res);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Batch classification failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Batch Classification</CardTitle>
          <CardDescription>
            Enter one text per line to classify multiple items at once
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="batch-text">Texts (one per line)</Label>
            <Textarea
              id="batch-text"
              placeholder={"Enter first text here...\nEnter second text here...\nEnter third text here..."}
              value={texts}
              onChange={(e) => setTexts(e.target.value)}
              rows={8}
            />
            <p className="text-xs text-muted-foreground">
              {texts.split("\n").filter((l) => l.trim()).length} items
            </p>
          </div>

          <div className="flex gap-4 items-end">
            <div className="space-y-2">
              <Label>Mode</Label>
              <div className="flex gap-2">
                <Button
                  variant={mode === "multi_class" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setMode("multi_class")}
                >
                  Multi-Class
                </Button>
                <Button
                  variant={mode === "multi_label" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setMode("multi_label")}
                >
                  Multi-Label
                </Button>
              </div>
            </div>
            <Button
              onClick={handleBatch}
              disabled={loading || texts.trim().length === 0}
            >
              {loading ? "Processing..." : "Classify Batch"}
            </Button>
          </div>

          {error && <p className="text-sm text-destructive">{error}</p>}
        </CardContent>
      </Card>

      {batchResult && (
        <div className="space-y-4">
          <div className="flex gap-4 text-sm text-muted-foreground">
            <span>Total: {batchResult.total} items</span>
            <span>Processing time: {batchResult.processing_time_ms}ms</span>
          </div>
          <ResultsDisplay results={batchResult.results} />
        </div>
      )}
    </div>
  );
}
