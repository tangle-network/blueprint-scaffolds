import { useState } from 'react';
import type { CategoryNode } from '../types';

interface Props {
  tree: CategoryNode | undefined;
  onChange: (tree: CategoryNode | undefined) => void;
}

export function CategoryTreeInput({ tree, onChange }: Props) {
  const [json, setJson] = useState(
    JSON.stringify(
      tree || {
        name: 'Root',
        children: [
          { name: 'Technology', children: [{ name: 'AI' }, { name: 'Web' }, { name: 'Mobile' }] },
          { name: 'Science', children: [{ name: 'Physics' }, { name: 'Biology' }, { name: 'Chemistry' }] },
          { name: 'Business', children: [{ name: 'Finance' }, { name: 'Marketing' }, { name: 'Operations' }] },
        ],
      },
      null,
      2,
    ),
  );
  const [error, setError] = useState('');

  const apply = () => {
    try {
      const parsed = JSON.parse(json);
      onChange(parsed);
      setError('');
    } catch {
      setError('Invalid JSON');
    }
  };

  return (
    <div className="card">
      <h3>Category Hierarchy</h3>
      <textarea
        value={json}
        onChange={(e) => setJson(e.target.value)}
        rows={12}
        style={{ fontFamily: 'monospace', fontSize: 13 }}
      />
      {error && <p style={{ color: 'var(--danger)', fontSize: 13, marginTop: 8 }}>{error}</p>}
      <div className="actions">
        <button className="btn btn-secondary" onClick={apply}>
          Apply Tree
        </button>
        <button className="btn btn-secondary" onClick={() => onChange(undefined)}>
          Clear
        </button>
      </div>
    </div>
  );
}
