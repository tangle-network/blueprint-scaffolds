import type {
  ClassifyResponse,
  BatchClassifyResponse,
  HierarchicalClassifyResponse,
  TrainResponse,
  EvaluateResponse,
  ActiveLearningResponse,
  StatusResponse,
  ConfigResponse,
} from "../types";

const API_BASE = "/api";

async function post<T>(path: string, body: unknown): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(err.detail || res.statusText);
  }
  return res.json();
}

async function get<T>(path: string): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`);
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(err.detail || res.statusText);
  }
  return res.json();
}

export const api = {
  classify(
    text: string,
    categories?: string[],
    multiLabel = false
  ): Promise<ClassifyResponse> {
    return post("/classify", { text, categories, multi_label: multiLabel });
  },

  classifyBatch(
    texts: string[],
    categories?: string[],
    multiLabel = false
  ): Promise<BatchClassifyResponse> {
    return post("/classify/batch", {
      texts,
      categories,
      multi_label: multiLabel,
    });
  },

  classifyHierarchical(
    text: string,
    hierarchy?: Record<string, string[]>
  ): Promise<HierarchicalClassifyResponse> {
    return post("/classify/hierarchical", { text, hierarchy });
  },

  train(
    examples: { text: string; label: string }[],
    categories: string[],
    multiLabel = false,
    method = "bootstrap"
  ): Promise<TrainResponse> {
    return post("/train", {
      examples,
      categories,
      multi_label: multiLabel,
      method,
    });
  },

  evaluate(
    examples: { text: string; label: string }[],
    categories: string[],
    nSplits = 5
  ): Promise<EvaluateResponse> {
    return post("/evaluate", {
      examples,
      categories,
      n_splits: nSplits,
    });
  },

  activeLearning(
    texts: string[],
    categories: string[],
    threshold = 0.6,
    maxSamples = 10,
    multiLabel = false
  ): Promise<ActiveLearningResponse> {
    return post("/active-learning", {
      texts,
      categories,
      threshold,
      max_samples: maxSamples,
      multi_label: multiLabel,
    });
  },

  configureLM(
    model: string,
    apiKey?: string,
    apiBase?: string
  ): Promise<{ status: string; model: string }> {
    return post("/configure-lm", { model, api_key: apiKey, api_base: apiBase });
  },

  getStatus(): Promise<StatusResponse> {
    return get("/status");
  },

  getConfig(): Promise<ConfigResponse> {
    return get("/config");
  },
};
