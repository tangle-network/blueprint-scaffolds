export interface ClassificationResult {
  text: string;
  labels: LabelScore[];
  reasoning: string;
  model_used: string;
}

export interface LabelScore {
  label: string;
  score: number;
  confidence: number;
  hierarchy_path: string[];
}

export interface BatchClassificationResult {
  results: ClassificationResult[];
  total: number;
  processing_time_ms: number;
}

export interface CategoryHierarchy {
  name: string;
  children: CategoryHierarchy[];
  description: string;
}

export interface CrossValidationMetrics {
  accuracy: number;
  precision: number;
  recall: number;
  f1: number;
  per_label_metrics: Record<string, LabelMetrics>;
  confusion_matrix: number[][];
}

export interface LabelMetrics {
  precision: number;
  recall: number;
  f1: number;
  support: number;
}

export interface ActiveLearningSuggestion {
  text: string;
  uncertainty_score: number;
  suggested_labels: string[];
  reason: string;
}

export interface OptimizationStatus {
  status: "idle" | "running" | "completed" | "error";
  progress: number;
  message: string;
  metrics?: CrossValidationMetrics;
}

export interface ClassificationRequest {
  text: string | string[];
  mode: "multi_class" | "multi_label";
  top_k?: number;
  min_confidence?: number;
}

export interface TrainRequest {
  examples: TrainExample[];
  num_folds?: number;
  max_bootstrapped_demos?: number;
}

export interface TrainExample {
  text: string;
  labels: string[];
  reasoning?: string;
}
