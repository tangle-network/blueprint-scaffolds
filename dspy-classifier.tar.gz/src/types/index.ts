export interface ClassifyResponse {
  label: string;
  confidence: number;
  reasoning: string;
}

export interface BatchClassifyResponse {
  results: ClassifyResponse[];
}

export interface HierarchicalClassifyResponse {
  parent_label: string;
  child_label: string;
  confidence: number;
  reasoning: string;
}

export interface TrainResponse {
  status: string;
  message: string;
}

export interface EvaluateResponse {
  metrics: Record<string, unknown>;
}

export interface ActiveLearningSample {
  text: string;
  predicted_label: string;
  confidence: number;
  reasoning: string;
}

export interface ActiveLearningResponse {
  uncertain_samples: ActiveLearningSample[];
}

export interface StatusResponse {
  status: string;
  model: string | null;
  categories: string[];
  training_examples: number;
}

export interface ConfigResponse {
  categories: string[];
  hierarchy: Record<string, string[]>;
  training_examples_count: number;
}
