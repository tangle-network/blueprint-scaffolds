import { useState } from 'react';
import { ClassifyView } from './components/ClassifyView';
import { BatchView } from './components/BatchView';
import { OptimizeView } from './components/OptimizeView';
import { MetricsView } from './components/MetricsView';
import { ActiveLearningView } from './components/ActiveLearningView';
import type { TabId } from './types';

const tabs: { id: TabId; label: string }[] = [
  { id: 'classify', label: 'Classify' },
  { id: 'batch', label: 'Batch' },
  { id: 'optimize', label: 'Optimize' },
  { id: 'metrics', label: 'Metrics' },
  { id: 'active', label: 'Active Learning' },
];

export default function App() {
  const [tab, setTab] = useState<TabId>('classify');

  return (
    <>
      <header>
        <div className="container">
          <h1>DSPy Text Classifier</h1>
          <nav>
            {tabs.map((t) => (
              <button
                key={t.id}
                className={tab === t.id ? 'active' : ''}
                onClick={() => setTab(t.id)}
              >
                {t.label}
              </button>
            ))}
          </nav>
        </div>
      </header>
      <main className="container">
        {tab === 'classify' && <ClassifyView />}
        {tab === 'batch' && <BatchView />}
        {tab === 'optimize' && <OptimizeView />}
        {tab === 'metrics' && <MetricsView />}
        {tab === 'active' && <ActiveLearningView />}
      </main>
    </>
  );
}
