import { useState } from "react";
import ClassifyPanel from "./components/ClassifyPanel";
import BatchPanel from "./components/BatchPanel";
import HierarchicalPanel from "./components/HierarchicalPanel";
import TrainPanel from "./components/TrainPanel";
import EvaluatePanel from "./components/EvaluatePanel";
import ActiveLearningPanel from "./components/ActiveLearningPanel";
import StatusBar from "./components/StatusBar";
import type { StatusResponse } from "./types";

const tabs = [
  { id: "classify", label: "Classify" },
  { id: "batch", label: "Batch" },
  { id: "hierarchical", label: "Hierarchical" },
  { id: "train", label: "Train" },
  { id: "evaluate", label: "Evaluate" },
  { id: "active", label: "Active Learning" },
] as const;

type TabId = (typeof tabs)[number]["id"];

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>("classify");
  const [status, setStatus] = useState<StatusResponse | null>(null);

  return (
    <div style={{ maxWidth: 1200, margin: "0 auto", padding: "20px" }}>
      <header style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 24, fontWeight: 700, marginBottom: 4 }}>
          DSPy Text Classifier
        </h1>
        <p style={{ color: "var(--text-dim)", fontSize: 14 }}>
          Optimized multi-class / multi-label classification with chain-of-thought
          reasoning, few-shot bootstrapping, and active learning.
        </p>
      </header>

      <StatusBar status={status} onRefresh={setStatus} />

      <nav
        style={{
          display: "flex",
          gap: 4,
          marginBottom: 20,
          borderBottom: "1px solid var(--border)",
          paddingBottom: 8,
          flexWrap: "wrap",
        }}
      >
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            style={{
              padding: "8px 16px",
              borderRadius: "var(--radius)",
              background: activeTab === t.id ? "var(--primary)" : "transparent",
              color: activeTab === t.id ? "#fff" : "var(--text-dim)",
              fontWeight: activeTab === t.id ? 600 : 400,
              fontSize: 14,
              transition: "all 0.2s",
            }}
          >
            {t.label}
          </button>
        ))}
      </nav>

      <main>
        {activeTab === "classify" && <ClassifyPanel />}
        {activeTab === "batch" && <BatchPanel />}
        {activeTab === "hierarchical" && <HierarchicalPanel />}
        {activeTab === "train" && <TrainPanel />}
        {activeTab === "evaluate" && <EvaluatePanel />}
        {activeTab === "active" && <ActiveLearningPanel />}
      </main>
    </div>
  );
}
