import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ClassifyPanel } from "@/components/ClassifyPanel";
import { BatchPanel } from "@/components/BatchPanel";
import { MetricsPanel } from "@/components/MetricsPanel";
import { ActiveLearningPanel } from "@/components/ActiveLearningPanel";
import { TrainingPanel } from "@/components/TrainingPanel";

export default function App() {
  const [activeTab, setActiveTab] = useState("classify");

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold">DSPy Text Classifier</h1>
          <p className="text-sm text-muted-foreground">
            Optimized multi-class &amp; multi-label text classification with chain-of-thought reasoning
          </p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="classify">Classify</TabsTrigger>
            <TabsTrigger value="batch">Batch</TabsTrigger>
            <TabsTrigger value="metrics">Metrics</TabsTrigger>
            <TabsTrigger value="active-learning">Active Learning</TabsTrigger>
            <TabsTrigger value="training">Training</TabsTrigger>
          </TabsList>

          <TabsContent value="classify">
            <ClassifyPanel />
          </TabsContent>

          <TabsContent value="batch">
            <BatchPanel />
          </TabsContent>

          <TabsContent value="metrics">
            <MetricsPanel />
          </TabsContent>

          <TabsContent value="active-learning">
            <ActiveLearningPanel />
          </TabsContent>

          <TabsContent value="training">
            <TrainingPanel />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
