import type {
  ClassificationResult,
  BatchClassificationResult,
  CategoryHierarchy,
  CrossValidationMetrics,
  ActiveLearningSuggestion,
  OptimizationStatus,
  ClassificationRequest,
  TrainRequest,
} from "@/types";

const API_BASE = "/api";

async function fetchAPI<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${endpoint}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(err.detail || res.statusText);
  }
  return res.json();
}

export async function classifySingle(
  text: string,
  mode: "multi_class" | "multi_label" = "multi_class",
  topK = 5,
  minConfidence = 0.1
): Promise<ClassificationResult> {
  return fetchAPI<ClassificationResult>("/classify", {
    method: "POST",
    body: JSON.stringify({ text, mode, top_k: topK, min_confidence: minConfidence } as ClassificationRequest),
  });
}

export async function classifyBatch(
  texts: string[],
  mode: "multi_class" | "multi_label" = "multi_class",
  topK = 5,
  minConfidence = 0.1
): Promise<BatchClassificationResult> {
  return fetchAPI<BatchClassificationResult>("/classify/batch", {
    method: "POST",
    body: JSON.stringify({ text: texts, mode, top_k: topK, min_confidence: minConfidence } as ClassificationRequest),
  });
}

export async function getCategories(): Promise<CategoryHierarchy[]> {
  return fetchAPI<CategoryHierarchy[]>("/categories");
}

export async function getMetrics(): Promise<CrossValidationMetrics> {
  return fetchAPI<CrossValidationMetrics>("/metrics");
}

export async function getActiveLearningSuggestions(
  count = 5
): Promise<ActiveLearningSuggestion[]> {
  return fetchAPI<ActiveLearningSuggestion[]>(`/active-learning?count=${count}`);
}

export async function trainModel(
  request: TrainRequest
): Promise<OptimizationStatus> {
  return fetchAPI<OptimizationStatus>("/train", {
    method: "POST",
    body: JSON.stringify(request),
  });
}

export async function getOptimizationStatus(): Promise<OptimizationStatus> {
  return fetchAPI<OptimizationStatus>("/optimization-status");
}
