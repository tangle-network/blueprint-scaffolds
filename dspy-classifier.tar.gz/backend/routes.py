import random
import time
import hashlib
from typing import Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from .classifier import DSPyClassifier
from .hierarchy import CATEGORY_HIERARCHY

router = APIRouter()

classifier = DSPyClassifier()


class ClassifyRequest(BaseModel):
    text: str | list[str]
    mode: str = "multi_class"
    top_k: int = 5
    min_confidence: float = 0.1


class TrainExample(BaseModel):
    text: str
    labels: list[str]
    reasoning: Optional[str] = None


class TrainRequest(BaseModel):
    examples: list[TrainExample]
    num_folds: int = 5
    max_bootstrapped_demos: int = 4


@router.post("/classify")
async def classify_single(request: ClassifyRequest):
    if isinstance(request.text, list):
        raise HTTPException(400, "Use /classify/batch for multiple texts")
    result = classifier.classify(
        request.text,
        mode=request.mode,
        top_k=request.top_k,
        min_confidence=request.min_confidence,
    )
    return result


@router.post("/classify/batch")
async def classify_batch(request: ClassifyRequest):
    if not isinstance(request.text, list):
        raise HTTPException(400, "Send a list of texts for batch classification")
    start = time.time()
    results = [
        classifier.classify(
            t,
            mode=request.mode,
            top_k=request.top_k,
            min_confidence=request.min_confidence,
        )
        for t in request.text
    ]
    elapsed = (time.time() - start) * 1000
    return {
        "results": results,
        "total": len(results),
        "processing_time_ms": round(elapsed, 1),
    }


@router.get("/categories")
async def get_categories():
    return CATEGORY_HIERARCHY


@router.get("/metrics")
async def get_metrics():
    return classifier.get_cross_validation_metrics()


@router.get("/active-learning")
async def active_learning(count: int = 5):
    return classifier.get_active_learning_suggestions(count)


@router.post("/train")
async def train(request: TrainRequest):
    result = classifier.train(
        [ex.model_dump() for ex in request.examples],
        num_folds=request.num_folds,
        max_bootstrapped_demos=request.max_bootstrapped_demos,
    )
    return result


@router.get("/optimization-status")
async def optimization_status():
    return classifier.get_optimization_status()
