import numpy as np
from sklearn.model_selection import KFold
from sklearn.metrics import (
    accuracy_score,
    precision_recall_fscore_support,
    classification_report,
)
from typing import Any


def compute_metrics(y_true: list[str], y_pred: list[str], labels: list[str]) -> dict:
    unique_labels = sorted(set(labels))
    accuracy = accuracy_score(y_true, y_pred)
    precision, recall, f1, _ = precision_recall_fscore_support(
        y_true, y_pred, labels=unique_labels, average="weighted", zero_division=0
    )
    per_class = classification_report(
        y_true, y_pred, labels=unique_labels, output_dict=True, zero_division=0
    )
    return {
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "per_class": per_class,
    }


def cross_validate(
    classify_fn,
    examples: list[dict],
    labels: list[str],
    n_splits: int = 5,
) -> dict[str, Any]:
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=42)
    all_metrics = []
    for train_idx, test_idx in kf.split(examples):
        train_set = [examples[i] for i in train_idx]
        test_set = [examples[i] for i in test_idx]
        y_true = [ex["label"] for ex in test_set]
        y_pred = [classify_fn(ex["text"]) for ex in test_set]
        metrics = compute_metrics(y_true, y_pred, labels)
        all_metrics.append(metrics)
    aggregated = {}
    for key in ["accuracy", "precision", "recall", "f1"]:
        values = [m[key] for m in all_metrics]
        aggregated[key] = {
            "mean": float(np.mean(values)),
            "std": float(np.std(values)),
            "values": [float(v) for v in values],
        }
    return {"n_splits": n_splits, "metrics": aggregated}


def select_uncertain_samples(
    classify_fn,
    texts: list[str],
    threshold: float = 0.6,
    max_samples: int = 10,
) -> list[dict]:
    results = []
    for text in texts:
        pred = classify_fn(text)
        results.append(
            {
                "text": text,
                "predicted_label": pred.label,
                "confidence": pred.confidence,
                "reasoning": pred.reasoning,
            }
        )
    uncertain = [r for r in results if r["confidence"] < threshold]
    uncertain.sort(key=lambda x: x["confidence"])
    return uncertain[:max_samples]
