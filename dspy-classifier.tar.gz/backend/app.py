from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import os
import json
import dspy

from classifier import TextClassifier, HierarchicalClassifier
from optimizer import cross_validate, select_uncertain_samples, compute_metrics
from training import bootstrap_few_shot, optimize_with_bootstrap

app = FastAPI(title="Text Classification System", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

lm = None
classifier = None
hierarchy_classifier = None
categories_store: list[str] = []
hierarchy_store: dict[str, list[str]] = {}
training_data: list[dict] = []


class ClassifyRequest(BaseModel):
    text: str
    categories: Optional[list[str]] = None
    multi_label: bool = False


class ClassifyResponse(BaseModel):
    label: str
    confidence: float
    reasoning: str


class BatchClassifyRequest(BaseModel):
    texts: list[str]
    categories: Optional[list[str]] = None
    multi_label: bool = False


class BatchClassifyResponse(BaseModel):
    results: list[ClassifyResponse]


class HierarchicalClassifyRequest(BaseModel):
    text: str
    hierarchy: Optional[dict[str, list[str]]] = None


class HierarchicalClassifyResponse(BaseModel):
    parent_label: str
    child_label: str
    confidence: float
    reasoning: str


class TrainRequest(BaseModel):
    examples: list[dict]
    categories: list[str]
    multi_label: bool = False
    method: str = "bootstrap"


class TrainResponse(BaseModel):
    status: str
    message: str


class EvaluateRequest(BaseModel):
    examples: list[dict]
    categories: list[str]
    n_splits: int = 5


class EvaluateResponse(BaseModel):
    metrics: dict


class ActiveLearningRequest(BaseModel):
    texts: list[str]
    categories: list[str]
    threshold: float = 0.6
    max_samples: int = 10
    multi_label: bool = False


class ActiveLearningResponse(BaseModel):
    uncertain_samples: list[dict]


class ConfigureLMRequest(BaseModel):
    model: str = "gpt-3.5-turbo"
    api_key: Optional[str] = None
    api_base: Optional[str] = None


class StatusResponse(BaseModel):
    status: str
    model: Optional[str] = None
    categories: list[str] = []
    training_examples: int = 0


class ConfigResponse(BaseModel):
    categories: list[str]
    hierarchy: dict[str, list[str]]
    training_examples_count: int


@app.post("/api/configure-lm")
def configure_lm(req: ConfigureLMRequest):
    global lm
    api_key = req.api_key or os.environ.get("OPENAI_API_KEY", "")
    kwargs = {"model": req.model}
    if req.api_base:
        kwargs["api_base"] = req.api_base
    if api_key:
        kwargs["api_key"] = api_key
    lm = dspy.LM(**kwargs)
    dspy.configure(lm=lm)
    return {"status": "configured", "model": req.model}


@app.get("/api/status", response_model=StatusResponse)
def get_status():
    return StatusResponse(
        status="ready" if lm else "not_configured",
        model=lm.model if lm else None,
        categories=categories_store,
        training_examples=len(training_data),
    )


@app.get("/api/config", response_model=ConfigResponse)
def get_config():
    return ConfigResponse(
        categories=categories_store,
        hierarchy=hierarchy_store,
        training_examples_count=len(training_data),
    )


@app.post("/api/classify", response_model=ClassifyResponse)
def classify_text(req: ClassifyRequest):
    global classifier
    cats = req.categories or categories_store
    if not cats:
        raise HTTPException(status_code=400, detail="No categories configured")
    clf = TextClassifier(cats, multi_label=req.multi_label)
    try:
        result = clf(req.text)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    return ClassifyResponse(
        label=result.label,
        confidence=result.confidence,
        reasoning=result.reasoning,
    )


@app.post("/api/classify/batch", response_model=BatchClassifyResponse)
def classify_batch(req: BatchClassifyRequest):
    cats = req.categories or categories_store
    if not cats:
        raise HTTPException(status_code=400, detail="No categories configured")
    clf = TextClassifier(cats, multi_label=req.multi_label)
    results = []
    for text in req.texts:
        try:
            result = clf(text)
            results.append(
                ClassifyResponse(
                    label=result.label,
                    confidence=result.confidence,
                    reasoning=result.reasoning,
                )
            )
        except Exception as e:
            results.append(
                ClassifyResponse(
                    label="error", confidence=0.0, reasoning=str(e)
                )
            )
    return BatchClassifyResponse(results=results)


@app.post("/api/classify/hierarchical", response_model=HierarchicalClassifyResponse)
def classify_hierarchical(req: HierarchicalClassifyRequest):
    hierarchy = req.hierarchy or hierarchy_store
    if not hierarchy:
        raise HTTPException(
            status_code=400, detail="No hierarchy configured"
        )
    clf = HierarchicalClassifier(hierarchy)
    try:
        result = clf(req.text)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    return HierarchicalClassifyResponse(
        parent_label=result.parent_label,
        child_label=result.child_label,
        confidence=result.confidence,
        reasoning=result.reasoning,
    )


@app.post("/api/train", response_model=TrainResponse)
def train_classifier(req: TrainRequest):
    global classifier, categories_store, training_data
    categories_store = req.categories
    training_data.extend(req.examples)
    clf = TextClassifier(req.categories, multi_label=req.multi_label)
    try:
        if req.method == "bootstrap":
            classifier = bootstrap_few_shot(clf, req.examples)
        else:
            classifier = optimize_with_bootstrap(clf, req.examples)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    return TrainResponse(
        status="trained",
        message=f"Trained on {len(req.examples)} examples with {len(req.categories)} categories",
    )


@app.post("/api/evaluate", response_model=EvaluateResponse)
def evaluate_classifier(req: EvaluateRequest):
    cats = req.categories or categories_store
    if not cats:
        raise HTTPException(status_code=400, detail="No categories configured")
    clf = TextClassifier(cats)

    def classify_fn(text):
        r = clf(text)
        return r.label

    results = cross_validate(classify_fn, req.examples, cats, n_splits=req.n_splits)
    return EvaluateResponse(metrics=results)


@app.post("/api/active-learning", response_model=ActiveLearningResponse)
def active_learning(req: ActiveLearningRequest):
    cats = req.categories or categories_store
    if not cats:
        raise HTTPException(status_code=400, detail="No categories configured")
    clf = TextClassifier(cats, multi_label=req.multi_label)

    uncertain = select_uncertain_samples(
        lambda t: clf(t),
        req.texts,
        threshold=req.threshold,
        max_samples=req.max_samples,
    )
    return ActiveLearningResponse(uncertain_samples=uncertain)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
