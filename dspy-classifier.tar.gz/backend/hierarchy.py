CATEGORY_HIERARCHY = [
    {
        "name": "Technology",
        "description": "Technology and computing topics",
        "children": [
            {
                "name": "Artificial Intelligence",
                "description": "AI, machine learning, deep learning",
                "children": [
                    {"name": "NLP", "description": "Natural language processing", "children": []},
                    {"name": "Computer Vision", "description": "Image and video analysis", "children": []},
                    {"name": "Robotics", "description": "Autonomous systems and robots", "children": []},
                ],
            },
            {
                "name": "Software Engineering",
                "description": "Software development topics",
                "children": [
                    {"name": "Web Development", "description": "Frontend and backend web", "children": []},
                    {"name": "DevOps", "description": "CI/CD, infrastructure, deployment", "children": []},
                    {"name": "Security", "description": "Cybersecurity and infosec", "children": []},
                ],
            },
            {
                "name": "Hardware",
                "description": "Physical computing components",
                "children": [
                    {"name": "Processors", "description": "CPUs, GPUs, TPUs", "children": []},
                    {"name": "Networking", "description": "Network infrastructure", "children": []},
                ],
            },
        ],
    },
    {
        "name": "Science",
        "description": "Scientific disciplines",
        "children": [
            {
                "name": "Physics",
                "description": "Physical sciences",
                "children": [
                    {"name": "Quantum Physics", "description": "Quantum mechanics and computing", "children": []},
                    {"name": "Astrophysics", "description": "Space and celestial objects", "children": []},
                ],
            },
            {
                "name": "Biology",
                "description": "Life sciences",
                "children": [
                    {"name": "Genetics", "description": "DNA, genomics, heredity", "children": []},
                    {"name": "Ecology", "description": "Ecosystems and environment", "children": []},
                ],
            },
            {"name": "Chemistry", "description": "Chemical sciences", "children": []},
            {"name": "Medicine", "description": "Healthcare and medical research", "children": []},
        ],
    },
    {
        "name": "Business",
        "description": "Business and finance",
        "children": [
            {
                "name": "Finance",
                "description": "Financial markets and services",
                "children": [
                    {"name": "Markets", "description": "Stock markets and trading", "children": []},
                    {"name": "Cryptocurrency", "description": "Digital currencies and blockchain", "children": []},
                ],
            },
            {"name": "Marketing", "description": "Advertising and brand strategy", "children": []},
            {"name": "Management", "description": "Leadership and organizational behavior", "children": []},
            {"name": "Entrepreneurship", "description": "Startups and innovation", "children": []},
        ],
    },
    {
        "name": "Sports",
        "description": "Sports and athletics",
        "children": [
            {"name": "Basketball", "description": "NBA and basketball news", "children": []},
            {"name": "Football", "description": "NFL, soccer, and football", "children": []},
            {"name": "Tennis", "description": "Tennis tournaments and players", "children": []},
            {"name": "Olympics", "description": "Olympic games and athletes", "children": []},
        ],
    },
    {
        "name": "Entertainment",
        "description": "Entertainment and culture",
        "children": [
            {"name": "Movies", "description": "Film industry and cinema", "children": []},
            {"name": "Music", "description": "Music industry and artists", "children": []},
            {"name": "Gaming", "description": "Video games and gaming culture", "children": []},
            {"name": "Books", "description": "Literature and publishing", "children": []},
        ],
    },
    {
        "name": "Politics",
        "description": "Political news and governance",
        "children": [
            {"name": "Domestic Policy", "description": "National politics and legislation", "children": []},
            {"name": "International Relations", "description": "Global diplomacy and foreign affairs", "children": []},
            {"name": "Elections", "description": "Campaigns and voting", "children": []},
        ],
    },
]
