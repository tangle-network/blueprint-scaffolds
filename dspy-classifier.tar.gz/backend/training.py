import dspy
from typing import Optional


def bootstrap_few_shot(
    classifier_module: dspy.Module,
    train_examples: list[dict],
    metric_fn=None,
    max_bootstrapped_demos: int = 4,
    max_labeled_demos: int = 16,
    num_candidate_sets: int = 3,
) -> dspy.Module:
    if metric_fn is None:
        def metric_fn(example, prediction, trace=None):
            expected = example.get("label", "").strip().lower()
            predicted = prediction.label.strip().lower()
            if expected == predicted:
                return True
            expected_labels = set(l.strip() for l in expected.split(","))
            predicted_labels = set(l.strip() for l in predicted.split(","))
            return bool(expected_labels & predicted_labels)

    trainset = []
    for ex in train_examples:
        trainset.append(
            dspy.Example(
                text=ex["text"],
                categories="",
                label=ex["label"],
            ).with_inputs("text", "categories")
        )

    teleprompter = dspy.BootstrapFewShot(
        metric=metric_fn,
        max_bootstrapped_demos=max_bootstrapped_demos,
        max_labeled_demos=max_labeled_demos,
        num_candidate_sets=num_candidate_sets,
    )

    compiled = teleprompter.compile(classifier_module, trainset=trainset)
    return compiled


def optimize_with_bootstrap(
    classifier_module: dspy.Module,
    train_examples: list[dict],
    val_examples: Optional[list[dict]] = None,
    num_trials: int = 10,
) -> dspy.Module:
    def metric_fn(example, prediction, trace=None):
        expected = example.get("label", "").strip().lower()
        predicted = prediction.label.strip().lower()
        if expected == predicted:
            return 1.0
        expected_labels = set(l.strip() for l in expected.split(","))
        predicted_labels = set(l.strip() for l in predicted.split(","))
        overlap = expected_labels & predicted_labels
        if overlap:
            return len(overlap) / max(len(expected_labels), len(predicted_labels))
        return 0.0

    all_examples = train_examples + (val_examples or [])
    trainset = []
    for ex in all_examples:
        trainset.append(
            dspy.Example(
                text=ex["text"],
                categories="",
                label=ex["label"],
            ).with_inputs("text", "categories")
        )

    teleprompter = dspy.BootstrapFewShotWithRandomSearch(
        metric=metric_fn,
        max_bootstrapped_demos=4,
        num_candidate_sets=num_trials,
        num_threads=1,
    )

    compiled = teleprompter.compile(classifier_module, trainset=trainset)
    return compiled
