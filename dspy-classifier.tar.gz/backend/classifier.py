import dspy
from typing import Optional
from pydantic import BaseModel


class ClassificationSignature(dspy.Signature):
    """Classify text into one or more categories with reasoning."""

    text: str = dspy.InputField(desc="The text to classify")
    categories: str = dspy.InputField(
        desc="Comma-separated list of valid categories"
    )
    reasoning: str = dspy.OutputField(
        desc="Step-by-step reasoning about the classification"
    )
    label: str = dspy.OutputField(
        desc="The predicted category label(s), comma-separated for multi-label"
    )
    confidence: float = dspy.OutputField(
        desc="Confidence score between 0.0 and 1.0"
    )


class HierarchicalClassificationSignature(dspy.Signature):
    """Classify text into a hierarchical category path with reasoning."""

    text: str = dspy.InputField(desc="The text to classify")
    parent_categories: str = dspy.InputField(
        desc="Comma-separated list of valid parent categories"
    )
    child_categories: str = dspy.InputField(
        desc="Comma-separated list of valid child categories for the predicted parent"
    )
    reasoning: str = dspy.OutputField(
        desc="Step-by-step reasoning about the hierarchical classification"
    )
    parent_label: str = dspy.OutputField(
        desc="The predicted parent category"
    )
    child_label: str = dspy.OutputField(
        desc="The predicted child category"
    )
    confidence: float = dspy.OutputField(
        desc="Confidence score between 0.0 and 1.0"
    )


class TextClassifier(dspy.Module):
    def __init__(self, categories: list[str], multi_label: bool = False):
        super().__init__()
        self.categories = categories
        self.multi_label = multi_label
        self.classifier = dspy.ChainOfThought(ClassificationSignature)

    def forward(self, text: str):
        cats = ", ".join(self.categories)
        result = self.classifier(text=text, categories=cats)
        labels = [l.strip() for l in result.label.split(",")]
        valid_labels = [l for l in labels if l in self.categories]
        if not valid_labels:
            valid_labels = [self.categories[0]]
        if not self.multi_label:
            valid_labels = valid_labels[:1]
        return dspy.Prediction(
            reasoning=result.reasoning,
            label=", ".join(valid_labels),
            confidence=max(0.0, min(1.0, result.confidence)),
        )


class HierarchicalClassifier(dspy.Module):
    def __init__(self, hierarchy: dict[str, list[str]]):
        super().__init__()
        self.hierarchy = hierarchy
        self.classifier = dspy.ChainOfThought(HierarchicalClassificationSignature)

    def forward(self, text: str):
        parents = ", ".join(self.hierarchy.keys())
        first_parent = list(self.hierarchy.keys())[0]
        first_children = ", ".join(self.hierarchy[first_parent])
        result = self.classifier(
            text=text,
            parent_categories=parents,
            child_categories=first_children,
        )
        parent = result.parent_label.strip()
        if parent not in self.hierarchy:
            parent = list(self.hierarchy.keys())[0]
        children = self.hierarchy[parent]
        child = result.child_label.strip()
        if child not in children:
            child = children[0] if children else ""
        return dspy.Prediction(
            reasoning=result.reasoning,
            parent_label=parent,
            child_label=child,
            confidence=max(0.0, min(1.0, result.confidence)),
        )
