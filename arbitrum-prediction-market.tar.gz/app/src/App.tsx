import { BrowserRouter, Routes, Route } from "react-router-dom"
import { Layout } from "@/components/Layout"
import HomePage from "@/pages/HomePage"
import MarketPage from "@/pages/MarketPage"
import PortfolioPage from "@/pages/PortfolioPage"
import CreatePage from "@/pages/CreatePage"
import AnalyticsPage from "@/pages/AnalyticsPage"

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<HomePage />} />
          <Route path="/market/:id" element={<MarketPage />} />
          <Route path="/portfolio" element={<PortfolioPage />} />
          <Route path="/create" element={<CreatePage />} />
          <Route path="/analytics" element={<AnalyticsPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}
