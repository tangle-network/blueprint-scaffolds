// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "./MarketTypes.sol";
import "./IOracle.sol";

contract Settlement {
    mapping(uint256 => SettlementInfo) public settlements;

    struct SettlementInfo {
        bool settled;
        int256 winningOutcome;
        uint256 totalPool;
        uint256 settlementTime;
        mapping(address => uint256) claims;
    }

    event MarketSettled(uint256 indexed marketId, int256 winningOutcome, uint256 totalPool);
    event Claimed(address indexed user, uint256 indexed marketId, uint256 amount);

    function settle(
        uint256 marketId,
        IOracle oracle,
        bytes32 requestId
    ) external {
        SettlementInfo storage info = settlements[marketId];
        require(!info.settled, "Already settled");

        int256 result = oracle.resolveMarket(address(this), requestId);
        info.settled = true;
        info.winningOutcome = result;
        info.settlementTime = block.timestamp;

        emit MarketSettled(marketId, result, info.totalPool);
    }

    function claim(
        uint256 marketId,
        address user,
        uint256 amount
    ) external {
        SettlementInfo storage info = settlements[marketId];
        require(info.settled, "Not settled");
        require(info.claims[user] == 0, "Already claimed");
        require(amount > 0, "Invalid amount");

        info.claims[user] = amount;

        emit Claimed(user, marketId, amount);
    }

    function getSettlement(uint256 marketId) external view returns (
        bool settled,
        int256 winningOutcome,
        uint256 totalPool,
        uint256 settlementTime
    ) {
        SettlementInfo storage info = settlements[marketId];
        return (info.settled, info.winningOutcome, info.totalPool, info.settlementTime);
    }
}
