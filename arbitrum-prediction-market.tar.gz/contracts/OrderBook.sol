// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

library OrderBookLib {
    struct Order {
        bytes32 id;
        address trader;
        uint256 marketId;
        uint256 outcomeIndex;
        uint256 amount;
        uint256 price;
        bool isBuy;
        uint256 timestamp;
    }

    struct OrderBook {
        mapping(uint256 => mapping(uint256 => Order[])) buyOrders;
        mapping(uint256 => mapping(uint256 => Order[])) sellOrders;
    }

    function insertBuyOrder(
        OrderBook storage book,
        uint256 marketId,
        uint256 outcomeIndex,
        Order memory order
    ) internal {
        Order[] storage orders = book.buyOrders[marketId][outcomeIndex];
        uint256 i = orders.length;
        for (; i > 0 && orders[i - 1].price < order.price; i--) {}
        orders.push();
        for (uint256 j = orders.length - 1; j > i; j--) {
            orders[j] = orders[j - 1];
        }
        orders[i] = order;
    }

    function insertSellOrder(
        OrderBook storage book,
        uint256 marketId,
        uint256 outcomeIndex,
        Order memory order
    ) internal {
        Order[] storage orders = book.sellOrders[marketId][outcomeIndex];
        uint256 i = orders.length;
        for (; i > 0 && orders[i - 1].price > order.price; i--) {}
        orders.push();
        for (uint256 j = orders.length - 1; j > i; j--) {
            orders[j] = orders[j - 1];
        }
        orders[i] = order;
    }

    function matchOrders(
        OrderBook storage book,
        uint256 marketId,
        uint256 outcomeIndex
    ) internal returns (uint256 totalMatched) {
        Order[] storage buys = book.buyOrders[marketId][outcomeIndex];
        Order[] storage sells = book.sellOrders[marketId][outcomeIndex];

        while (buys.length > 0 && sells.length > 0 && buys[0].price >= sells[0].price) {
            uint256 matchAmount = _min(buys[0].amount, sells[0].amount);
            totalMatched += matchAmount;

            buys[0].amount -= matchAmount;
            sells[0].amount -= matchAmount;

            if (buys[0].amount == 0) {
                _removeFirst(buys);
            }
            if (sells[0].amount == 0) {
                _removeFirst(sells);
            }
        }
    }

    function _removeFirst(Order[] storage orders) internal {
        for (uint256 i = 0; i < orders.length - 1; i++) {
            orders[i] = orders[i + 1];
        }
        orders.pop();
    }

    function _min(uint256 a, uint256 b) internal pure returns (uint256) {
        return a < b ? a : b;
    }
}
