// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

library AMMLib {
    uint256 public constant FEE_BPS = 30;

    struct Pool {
        uint256 outcomeCount;
        mapping(uint256 => uint256) reserves;
        uint256 totalLiquidity;
        uint256 totalFee;
    }

    function getSpotPrice(
        Pool storage pool,
        uint256 outcomeIndex,
        uint256[] memory allReserves
    ) internal view returns (uint256) {
        uint256 numerator = allReserves[outcomeIndex];
        uint256 denominator = 0;
        for (uint256 i = 0; i < pool.outcomeCount; i++) {
            denominator += allReserves[i];
        }
        require(denominator > 0, "No liquidity");
        return (numerator * 1e18) / denominator;
    }

    function getBuyAmount(
        uint256[] memory reserves,
        uint256 outcomeIndex,
        uint256 investmentAmount
    ) internal pure returns (uint256) {
        uint256 totalReserve = 0;
        for (uint256 i = 0; i < reserves.length; i++) {
            totalReserve += reserves[i];
        }

        uint256 fee = (investmentAmount * FEE_BPS) / 10000;
        uint256 netInvestment = investmentAmount - fee;

        uint256 resultIndex = reserves[outcomeIndex];
        uint256 newResultIndex = resultIndex - (netInvestment * totalReserve) / (totalReserve + netInvestment);

        require(newResultIndex > 0, "Insufficient liquidity");
        return newResultIndex;
    }

    function getSellAmount(
        uint256[] memory reserves,
        uint256 outcomeIndex,
        uint256 shareAmount
    ) internal pure returns (uint256) {
        uint256 totalReserve = 0;
        for (uint256 i = 0; i < reserves.length; i++) {
            totalReserve += reserves[i];
        }

        uint256 resultIndex = reserves[outcomeIndex];
        uint256 sellValue = (shareAmount * totalReserve) / (resultIndex + shareAmount);

        uint256 fee = (sellValue * FEE_BPS) / 10000;
        return sellValue - fee;
    }
}
