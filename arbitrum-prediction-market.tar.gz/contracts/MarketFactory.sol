// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "./MarketTypes.sol";
import "./IOracle.sol";
import "./TradingEngine.sol";
import "./Settlement.sol";

contract MarketFactory {
    uint256 public marketCount;
    address public tradingEngine;
    address public settlement;
    address public owner;

    mapping(uint256 => MarketInfo) public markets;
    mapping(address => uint256[]) public creatorMarkets;

    struct MarketInfo {
        address creator;
        string question;
        MarketType marketType;
        MarketState state;
        OracleType oracleType;
        uint256 createdAt;
        uint256 expiresAt;
        string[] outcomes;
        uint256[] scalarRange;
        bool usesAMM;
        address oracle;
    }

    event MarketCreated(
        uint256 indexed marketId,
        address indexed creator,
        string question,
        MarketType marketType,
        OracleType oracleType,
        bool usesAMM
    );
    event MarketStateChanged(uint256 indexed marketId, MarketState newState);

    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }

    constructor(address _tradingEngine, address _settlement) {
        tradingEngine = _tradingEngine;
        settlement = _settlement;
        owner = msg.sender;
    }

    function createBinaryMarket(
        string calldata question,
        OracleType oracleType,
        address oracle,
        uint256 expiresAt,
        bool usesAMM
    ) external returns (uint256 marketId) {
        string[] memory outcomes = new string[](2);
        outcomes[0] = "Yes";
        outcomes[1] = "No";

        return _createMarket(question, MarketType.Binary, oracleType, oracle, expiresAt, outcomes, new uint256[](0), usesAMM);
    }

    function createScalarMarket(
        string calldata question,
        OracleType oracleType,
        address oracle,
        uint256 expiresAt,
        uint256[] calldata scalarRange,
        bool usesAMM
    ) external returns (uint256 marketId) {
        string[] memory outcomes = new string[](1);
        outcomes[0] = "Value";

        return _createMarket(question, MarketType.Scalar, oracleType, oracle, expiresAt, outcomes, scalarRange, usesAMM);
    }

    function createMultiOutcomeMarket(
        string calldata question,
        OracleType oracleType,
        address oracle,
        uint256 expiresAt,
        string[] calldata outcomes,
        bool usesAMM
    ) external returns (uint256 marketId) {
        return _createMarket(question, MarketType.MultiOutcome, oracleType, oracle, expiresAt, outcomes, new uint256[](0), usesAMM);
    }

    function _createMarket(
        string memory question,
        MarketType marketType,
        OracleType oracleType,
        address oracle,
        uint256 expiresAt,
        string[] memory outcomes,
        uint256[] memory scalarRange,
        bool usesAMM
    ) internal returns (uint256 marketId) {
        marketId = marketCount++;

        markets[marketId] = MarketInfo({
            creator: msg.sender,
            question: question,
            marketType: marketType,
            state: MarketState.Active,
            oracleType: oracleType,
            createdAt: block.timestamp,
            expiresAt: expiresAt,
            outcomes: outcomes,
            scalarRange: scalarRange,
            usesAMM: usesAMM,
            oracle: oracle
        });

        creatorMarkets[msg.sender].push(marketId);

        emit MarketCreated(marketId, msg.sender, question, marketType, oracleType, usesAMM);
    }

    function getMarket(uint256 marketId) external view returns (MarketInfo memory) {
        return markets[marketId];
    }

    function getCreatorMarkets(address creator) external view returns (uint256[] memory) {
        return creatorMarkets[creator];
    }

    function setMarketState(uint256 marketId, MarketState newState) external onlyOwner {
        markets[marketId].state = newState;
        emit MarketStateChanged(marketId, newState);
    }
}
