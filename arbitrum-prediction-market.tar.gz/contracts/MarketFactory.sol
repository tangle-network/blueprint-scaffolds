// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "./TradingEngine.sol";
import "./SettlementRouter.sol";

contract MarketFactory {
    enum MarketType {
        Binary,
        Scalar,
        MultiOutcome
    }

    struct MarketConfig {
        string question;
        MarketType marketType;
        address collateralToken;
        uint64 resolveTimestamp;
        uint16 feeBps;
        address oracleAdapter;
    }

    event MarketCreated(uint256 indexed marketId, address engine, address settlement, MarketType marketType);

    uint256 public marketCount;
    mapping(uint256 => MarketConfig) public markets;
    mapping(uint256 => address) public engines;
    mapping(uint256 => address) public settlements;

    function createMarket(MarketConfig calldata config) external returns (uint256 marketId) {
        marketId = ++marketCount;
        TradingEngine engine = new TradingEngine(config.collateralToken, config.feeBps);
        SettlementRouter settlement = new SettlementRouter(config.oracleAdapter, config.resolveTimestamp);

        markets[marketId] = config;
        engines[marketId] = address(engine);
        settlements[marketId] = address(settlement);

        emit MarketCreated(marketId, address(engine), address(settlement), config.marketType);
    }
}
