// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "./MarketTypes.sol";
import "./OrderBook.sol";
import "./AMM.sol";
import "./IOracle.sol";

contract TradingEngine {
    using OrderBookLib for OrderBookLib.OrderBook;

    OrderBookLib.OrderBook public orderBook;
    mapping(uint256 => AMMLib.Pool) public ammPools;
    mapping(uint256 => bool) public useAMM;

    struct TradeResult {
        uint256 amount;
        uint256 price;
        uint256 fee;
        bool fullyFilled;
    }

    event OrderPlaced(
        bytes32 indexed orderId,
        address indexed trader,
        uint256 indexed marketId,
        uint256 outcomeIndex,
        uint256 amount,
        uint256 price,
        bool isBuy
    );
    event TradeExecuted(
        address indexed buyer,
        address indexed seller,
        uint256 indexed marketId,
        uint256 outcomeIndex,
        uint256 amount,
        uint256 price
    );
    event AMMBuy(
        address indexed buyer,
        uint256 indexed marketId,
        uint256 outcomeIndex,
        uint256 investmentAmount,
        uint256 sharesBought
    );
    event AMMSell(
        address indexed seller,
        uint256 indexed marketId,
        uint256 outcomeIndex,
        uint256 sharesSold,
        uint256 payout
    );

    function placeOrder(
        uint256 marketId,
        uint256 outcomeIndex,
        uint256 amount,
        uint256 price,
        bool isBuy
    ) external returns (bytes32 orderId) {
        orderId = keccak256(abi.encodePacked(msg.sender, marketId, outcomeIndex, block.timestamp));

        OrderBookLib.Order memory order = OrderBookLib.Order({
            id: orderId,
            trader: msg.sender,
            marketId: marketId,
            outcomeIndex: outcomeIndex,
            amount: amount,
            price: price,
            isBuy: isBuy,
            timestamp: block.timestamp
        });

        if (isBuy) {
            orderBook.insertBuyOrder(marketId, outcomeIndex, order);
        } else {
            orderBook.insertSellOrder(marketId, outcomeIndex, order);
        }

        uint256 matched = orderBook.matchOrders(marketId, outcomeIndex);

        emit OrderPlaced(orderId, msg.sender, marketId, outcomeIndex, amount - matched, price, isBuy);
    }

    function buyAMM(
        uint256 marketId,
        uint256 outcomeIndex,
        uint256 investmentAmount
    ) external returns (uint256 sharesBought) {
        require(useAMM[marketId], "Not AMM market");
        AMMLib.Pool storage pool = ammPools[marketId];

        uint256[] memory reserves = _getReserves(pool);
        sharesBought = AMMLib.getBuyAmount(reserves, outcomeIndex, investmentAmount);

        pool.reserves[outcomeIndex] -= sharesBought;
        for (uint256 i = 0; i < pool.outcomeCount; i++) {
            if (i != outcomeIndex) {
                pool.reserves[i] += (investmentAmount / pool.outcomeCount);
            }
        }
        pool.totalLiquidity += investmentAmount;

        emit AMMBuy(msg.sender, marketId, outcomeIndex, investmentAmount, sharesBought);
    }

    function sellAMM(
        uint256 marketId,
        uint256 outcomeIndex,
        uint256 shareAmount
    ) external returns (uint256 payout) {
        require(useAMM[marketId], "Not AMM market");
        AMMLib.Pool storage pool = ammPools[marketId];

        uint256[] memory reserves = _getReserves(pool);
        payout = AMMLib.getSellAmount(reserves, outcomeIndex, shareAmount);

        pool.reserves[outcomeIndex] += shareAmount;
        pool.totalLiquidity -= payout;

        emit AMMSell(msg.sender, marketId, outcomeIndex, shareAmount, payout);
    }

    function getAMMPrice(uint256 marketId, uint256 outcomeIndex) external view returns (uint256) {
        AMMLib.Pool storage pool = ammPools[marketId];
        uint256[] memory reserves = _getReserves(pool);
        return AMMLib.getSpotPrice(pool, outcomeIndex, reserves);
    }

    function _getReserves(AMMLib.Pool storage pool) internal view returns (uint256[] memory) {
        uint256[] memory reserves = new uint256[](pool.outcomeCount);
        for (uint256 i = 0; i < pool.outcomeCount; i++) {
            reserves[i] = pool.reserves[i];
        }
        return reserves;
    }
}
