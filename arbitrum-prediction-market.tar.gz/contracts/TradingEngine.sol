// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract TradingEngine {
    struct Order {
        address trader;
        uint256 outcomeId;
        uint256 price;
        uint256 amount;
        bool isBuy;
    }

    event OrderPlaced(bytes32 indexed orderId, address indexed trader, uint256 outcomeId, uint256 price, uint256 amount, bool isBuy);
    event AMMSwap(address indexed trader, uint256 outcomeId, uint256 collateralIn, uint256 sharesOut);

    address public immutable collateralToken;
    uint16 public immutable feeBps;

    constructor(address collateral_, uint16 feeBps_) {
        collateralToken = collateral_;
        feeBps = feeBps_;
    }

    function placeOrder(uint256 outcomeId, uint256 price, uint256 amount, bool isBuy) external returns (bytes32 orderId) {
        orderId = keccak256(abi.encode(msg.sender, outcomeId, price, amount, isBuy, block.timestamp));
        emit OrderPlaced(orderId, msg.sender, outcomeId, price, amount, isBuy);
    }

    function swapAgainstAMM(uint256 outcomeId, uint256 collateralIn, uint256 minSharesOut) external returns (uint256 sharesOut) {
        sharesOut = collateralIn - ((collateralIn * feeBps) / 10_000);
        require(sharesOut >= minSharesOut, "slippage");
        emit AMMSwap(msg.sender, outcomeId, collateralIn, sharesOut);
    }
}
