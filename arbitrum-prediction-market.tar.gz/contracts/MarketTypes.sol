// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

enum MarketType {
    Binary,
    Scalar,
    MultiOutcome
}

enum MarketState {
    Active,
    PendingResolution,
    Resolved,
    Disputed,
    Cancelled
}

enum OracleType {
    Chainlink,
    UMA,
    RealityETH
}

struct Market {
    address id;
    address creator;
    string question;
    MarketType marketType;
    MarketState state;
    OracleType oracleType;
    uint256 createdAt;
    uint256 expiresAt;
    uint256 resolutionTime;
    int256 resolutionValue;
    string[] outcomes;
    mapping(address => uint256) balances;
    mapping(address => mapping(uint256 => uint256)) outcomeBalances;
    bool resolved;
}
