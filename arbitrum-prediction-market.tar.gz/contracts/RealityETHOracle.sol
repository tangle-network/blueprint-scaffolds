// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "./IOracle.sol";

contract RealityETHOracle is IOracle {
    uint256 public constant BOND_AMOUNT = 1e17;
    uint256 public constant TIMEOUT = 24 hours;

    mapping(bytes32 => ResolutionRequest) public requests;
    mapping(bytes32 => Answer[]) public answers;

    struct ResolutionRequest {
        address market;
        string question;
        string[] outcomes;
        bool resolved;
        uint256 finalAnswerIndex;
        uint256 createdAt;
    }

    struct Answer {
        int256 value;
        address answerer;
        uint256 timestamp;
        uint256 bond;
    }

    event ResolutionRequested(bytes32 indexed requestId, address indexed market);
    event AnswerSubmitted(bytes32 indexed requestId, int256 value, address answerer);
    event MarketResolved(bytes32 indexed requestId, int256 value);
    event DisputeRaised(bytes32 indexed disputeId, bytes32 indexed requestId, int256 proposedValue);

    function requestResolution(
        address market,
        string calldata question,
        string[] calldata outcomes
    ) external override returns (bytes32 requestId) {
        requestId = keccak256(abi.encodePacked(market, question, block.timestamp));
        requests[requestId] = ResolutionRequest({
            market: market,
            question: question,
            outcomes: outcomes,
            resolved: false,
            finalAnswerIndex: 0,
            createdAt: block.timestamp
        });

        emit ResolutionRequested(requestId, market);
    }

    function submitAnswer(bytes32 requestId, int256 value) external {
        answers[requestId].push(Answer({
            value: value,
            answerer: msg.sender,
            timestamp: block.timestamp,
            bond: BOND_AMOUNT
        }));

        emit AnswerSubmitted(requestId, value, msg.sender);
    }

    function finalize(bytes32 requestId) external {
        ResolutionRequest storage req = requests[requestId];
        require(!req.resolved, "Already resolved");

        Answer[] storage ans = answers[requestId];
        require(ans.length > 0, "No answers");
        require(
            block.timestamp >= ans[ans.length - 1].timestamp + TIMEOUT,
            "Timeout not reached"
        );

        req.resolved = true;
        req.finalAnswerIndex = ans.length - 1;

        emit MarketResolved(requestId, ans[ans.length - 1].value);
    }

    function resolveMarket(
        address,
        bytes32 requestId
    ) external view override returns (int256) {
        require(requests[requestId].resolved, "Not resolved");
        return answers[requestId][requests[requestId].finalAnswerIndex].value;
    }

    function disputeResolution(
        address,
        bytes32 requestId,
        int256 proposedValue
    ) external override returns (bytes32 disputeId) {
        disputeId = keccak256(abi.encodePacked(requestId, proposedValue, block.timestamp));
        emit DisputeRaised(disputeId, requestId, proposedValue);
    }
}
