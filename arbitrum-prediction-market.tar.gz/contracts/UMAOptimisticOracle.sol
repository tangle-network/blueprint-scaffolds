// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "./IOracle.sol";

contract UMAOptimisticOracle is IOracle {
    uint256 public constant BOND_AMOUNT = 1e18;
    uint256 public constant DISPUTE_PERIOD = 2 hours;

    mapping(bytes32 => ResolutionRequest) public requests;
    mapping(address => bool) public authorizedCallers;

    struct ResolutionRequest {
        address market;
        string question;
        string[] outcomes;
        int256 proposedValue;
        bool resolved;
        bool disputed;
        uint256 proposalTime;
        address proposer;
    }

    event ResolutionRequested(bytes32 indexed requestId, address indexed market);
    event ProposalMade(bytes32 indexed requestId, int256 proposedValue);
    event MarketResolved(bytes32 indexed requestId, int256 value);
    event DisputeRaised(bytes32 indexed disputeId, bytes32 indexed requestId, int256 proposedValue);

    constructor() {
        authorizedCallers[msg.sender] = true;
    }

    function requestResolution(
        address market,
        string calldata question,
        string[] calldata outcomes
    ) external override returns (bytes32 requestId) {
        requestId = keccak256(abi.encodePacked(market, question, block.timestamp));
        requests[requestId] = ResolutionRequest({
            market: market,
            question: question,
            outcomes: outcomes,
            proposedValue: 0,
            resolved: false,
            disputed: false,
            proposalTime: 0,
            proposer: address(0)
        });

        emit ResolutionRequested(requestId, market);
    }

    function proposeResolution(bytes32 requestId, int256 value) external {
        ResolutionRequest storage req = requests[requestId];
        require(!req.resolved, "Already resolved");
        require(req.proposalTime == 0, "Already proposed");

        req.proposedValue = value;
        req.proposalTime = block.timestamp;
        req.proposer = msg.sender;

        emit ProposalMade(requestId, value);
    }

    function disputeResolution(
        address,
        bytes32 requestId,
        int256 proposedValue
    ) external override returns (bytes32 disputeId) {
        ResolutionRequest storage req = requests[requestId];
        require(req.proposalTime > 0, "No proposal yet");
        require(!req.disputed, "Already disputed");
        require(block.timestamp < req.proposalTime + DISPUTE_PERIOD, "Dispute period over");

        req.disputed = true;
        disputeId = keccak256(abi.encodePacked(requestId, proposedValue, block.timestamp));

        emit DisputeRaised(disputeId, requestId, proposedValue);
    }

    function resolveMarket(
        address,
        bytes32 requestId
    ) external view override returns (int256) {
        ResolutionRequest storage req = requests[requestId];
        if (req.disputed) {
            return req.proposedValue;
        }
        require(
            req.proposalTime > 0 && block.timestamp >= req.proposalTime + DISPUTE_PERIOD,
            "Not yet resolvable"
        );
        return req.proposedValue;
    }
}
