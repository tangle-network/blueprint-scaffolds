// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "./IOracle.sol";
import "./MarketTypes.sol";

contract ChainlinkOracle is IOracle {
    mapping(bytes32 => ResolutionRequest) public requests;
    mapping(address => bool) public authorizedCallers;

    struct ResolutionRequest {
        address market;
        string question;
        string[] outcomes;
        bool resolved;
        int256 value;
        uint256 timestamp;
    }

    event ResolutionRequested(bytes32 indexed requestId, address indexed market);
    event MarketResolved(bytes32 indexed requestId, int256 value);
    event DisputeRaised(bytes32 indexed disputeId, bytes32 indexed requestId, int256 proposedValue);

    modifier onlyAuthorized() {
        require(authorizedCallers[msg.sender], "Not authorized");
        _;
    }

    constructor() {
        authorizedCallers[msg.sender] = true;
    }

    function requestResolution(
        address market,
        string calldata question,
        string[] calldata outcomes
    ) external override returns (bytes32 requestId) {
        requestId = keccak256(abi.encodePacked(market, question, block.timestamp));
        requests[requestId] = ResolutionRequest({
            market: market,
            question: question,
            outcomes: outcomes,
            resolved: false,
            value: 0,
            timestamp: block.timestamp
        });

        emit ResolutionRequested(requestId, market);
    }

    function fulfillResolution(bytes32 requestId, int256 value) external onlyAuthorized {
        ResolutionRequest storage req = requests[requestId];
        require(!req.resolved, "Already resolved");
        req.resolved = true;
        req.value = value;

        emit MarketResolved(requestId, value);
    }

    function resolveMarket(
        address,
        bytes32 requestId
    ) external view override returns (int256) {
        require(requests[requestId].resolved, "Not yet resolved");
        return requests[requestId].value;
    }

    function disputeResolution(
        address,
        bytes32 requestId,
        int256 proposedValue
    ) external override returns (bytes32 disputeId) {
        require(requests[requestId].resolved, "Not resolved yet");
        disputeId = keccak256(abi.encodePacked(requestId, proposedValue, block.timestamp));
        emit DisputeRaised(disputeId, requestId, proposedValue);
    }
}
