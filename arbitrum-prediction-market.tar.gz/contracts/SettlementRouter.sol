// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract SettlementRouter {
    enum OracleRoute {
        Chainlink,
        UMAOptimisticOracle,
        RealityEth
    }

    event ProposedOutcome(bytes32 indexed assertionId, bytes result);
    event DisputeEscalated(bytes32 indexed disputeId, OracleRoute route);
    event Finalized(bytes result);

    address public immutable oracleAdapter;
    uint64 public immutable resolveTimestamp;
    bytes public finalResult;

    constructor(address oracleAdapter_, uint64 resolveTimestamp_) {
        oracleAdapter = oracleAdapter_;
        resolveTimestamp = resolveTimestamp_;
    }

    function propose(bytes calldata result) external returns (bytes32 assertionId) {
        assertionId = keccak256(abi.encode(msg.sender, result, block.timestamp));
        emit ProposedOutcome(assertionId, result);
    }

    function escalate(bytes32 disputeId, OracleRoute route) external {
        emit DisputeEscalated(disputeId, route);
    }

    function finalize(bytes calldata result) external {
        finalResult = result;
        emit Finalized(result);
    }
}
