// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

interface IOracle {
    function requestResolution(
        address market,
        string calldata question,
        string[] calldata outcomes
    ) external returns (bytes32 requestId);

    function resolveMarket(
        address market,
        bytes32 requestId
    ) external view returns (int256 value);

    function disputeResolution(
        address market,
        bytes32 requestId,
        int256 proposedValue
    ) external returns (bytes32 disputeId);
}
