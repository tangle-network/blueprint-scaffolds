# ArbiPredict

Prediction market prototype for Arbitrum with:

- Binary, scalar, and multi-outcome markets
- AMM and order book execution concepts
- Chainlink, UMA Optimistic Oracle, and Reality.eth settlement paths
- Vite + React + TypeScript frontend
- Solidity contract stubs for factory, trading engine, and settlement router

## Scripts

- `pnpm dev`
- `pnpm build`
- `pnpm preview`
