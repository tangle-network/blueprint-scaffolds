import { TOKEN_DECIMALS, TRADE_FEE_BPS, SLIPPAGE_TOLERANCE_BPS } from "@/lib/constants";

function parseUnits(value: string, decimals: number): bigint {
  const parts = value.split(".");
  const whole = parts[0] || "0";
  const fraction = (parts[1] || "").padEnd(decimals, "0").slice(0, decimals);
  return BigInt(whole + fraction);
}

function formatUnits(value: bigint, decimals: number): string {
  const str = value.toString().padStart(decimals + 1, "0");
  const whole = str.slice(0, -decimals) || "0";
  const fraction = str.slice(-decimals).replace(/0+$/, "");
  return fraction ? `${whole}.${fraction}` : whole;
}

export class AMMEngine {
  static calculateOutcomeAmountOut(
    tokenReserve: bigint,
    outcomeReserve: bigint,
    tokenAmountIn: bigint,
    feeBps: number = TRADE_FEE_BPS
  ): bigint {
    const fee = (tokenAmountIn * BigInt(feeBps)) / BigInt(10000);
    const netInput = tokenAmountIn - fee;
    const newTokenReserve = tokenReserve + netInput;
    const invariant = tokenReserve * outcomeReserve;
    const newOutcomeReserve = invariant / newTokenReserve;
    const amountOut = outcomeReserve - newOutcomeReserve;
    if (amountOut <= 0n) throw new Error("Insufficient output amount");
    return amountOut;
  }

  static calculateTokenAmountOut(
    tokenReserve: bigint,
    outcomeReserve: bigint,
    outcomeAmountIn: bigint,
    feeBps: number = TRADE_FEE_BPS
  ): bigint {
    const newOutcomeReserve = outcomeReserve + outcomeAmountIn;
    const invariant = tokenReserve * outcomeReserve;
    const newTokenReserve = invariant / newOutcomeReserve;
    const grossOutput = tokenReserve - newTokenReserve;
    const fee = (grossOutput * BigInt(feeBps)) / BigInt(10000);
    const amountOut = grossOutput - fee;
    if (amountOut <= 0n) throw new Error("Insufficient output amount");
    return amountOut;
  }

  static calculatePriceImpact(
    tokenReserve: bigint,
    outcomeReserve: bigint,
    tokenAmountIn: bigint
  ): number {
    const spotPrice = Number(tokenReserve) / Number(outcomeReserve);
    const amountOut = Number(this.calculateOutcomeAmountOut(tokenReserve, outcomeReserve, tokenAmountIn));
    const effectivePrice = Number(tokenAmountIn) / amountOut;
    return ((effectivePrice - spotPrice) / spotPrice) * 100;
  }

  static getSpotPrice(tokenReserve: bigint, outcomeReserve: bigint): number {
    return Number(tokenReserve) / Number(outcomeReserve);
  }

  static applySlippage(amount: bigint, toleranceBps: number = SLIPPAGE_TOLERANCE_BPS): bigint {
    return amount - (amount * BigInt(toleranceBps)) / BigInt(10000);
  }

  static parseTokenAmount(humanReadable: string): bigint {
    return parseUnits(humanReadable, TOKEN_DECIMALS);
  }

  static formatTokenAmount(wei: bigint): string {
    return formatUnits(wei, TOKEN_DECIMALS);
  }

  static priceToProbability(price: number): number {
    return Math.min(Math.max(price * 100, 0), 100);
  }

  static probabilityToPrice(probability: number): number {
    return Math.min(Math.max(probability / 100, 0), 1);
  }
}
