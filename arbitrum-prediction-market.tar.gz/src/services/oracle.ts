import type { OracleProvider } from "@/types/market";
import { CONTRACT_ADDRESSES, ORACLE_BOND_AMOUNTS, DISPUTE_PERIOD_SECONDS } from "@/lib/constants";

export interface OracleResolutionRequest {
  marketId: string;
  question: string;
  outcomes: string[];
  resolutionTimestamp: number;
}

export interface OracleResolutionResult {
  provider: OracleProvider;
  outcomeId: string;
  value?: number;
  confidence: number;
  timestamp: string;
  txHash: string;
}

export interface OracleDisputeRequest {
  marketId: string;
  proposedOutcomeId: string;
  bondAmount: string;
  evidence: string;
}

class ChainlinkOracleService {
  async requestResolution(req: OracleResolutionRequest): Promise<OracleResolutionResult> {
    return {
      provider: "chainlink",
      outcomeId: "0",
      confidence: 0.95,
      timestamp: new Date().toISOString(),
      txHash: `0x${req.marketId.padStart(64, "0")}`,
    };
  }

  async getLatestAnswer(feedAddress: string): Promise<number> {
    void feedAddress;
    return 0;
  }

  getAddress(): string {
    return CONTRACT_ADDRESSES.chainlinkOracle;
  }
}

class UMAOracleService {
  async requestResolution(req: OracleResolutionRequest): Promise<OracleResolutionResult> {
    return {
      provider: "uma",
      outcomeId: "0",
      confidence: 0.85,
      timestamp: new Date().toISOString(),
      txHash: `0x${req.marketId.padStart(64, "0").slice(0, 62)}01`,
    };
  }

  async proposePrice(marketId: string, outcomeId: string, value: number): Promise<string> {
    void marketId;
    void outcomeId;
    void value;
    return "0x_proposal_tx";
  }

  async disputePrice(marketId: string): Promise<string> {
    void marketId;
    return "0x_dispute_tx";
  }

  async getBondAmount(): Promise<string> {
    return ORACLE_BOND_AMOUNTS.uma;
  }

  getAddress(): string {
    return CONTRACT_ADDRESSES.umaOracle;
  }
}

class RealityEthOracleService {
  async requestResolution(req: OracleResolutionRequest): Promise<OracleResolutionResult> {
    return {
      provider: "reality_eth",
      outcomeId: "0",
      confidence: 0.80,
      timestamp: new Date().toISOString(),
      txHash: `0x${req.marketId.padStart(64, "0").slice(0, 62)}02`,
    };
  }

  async submitAnswer(
    questionId: string,
    answer: string,
    bondAmount: string
  ): Promise<string> {
    void questionId;
    void answer;
    void bondAmount;
    return "0x_submit_tx";
  }

  async disputeAnswer(questionId: string, proposedAnswer: string): Promise<string> {
    void questionId;
    void proposedAnswer;
    return "0x_dispute_tx";
  }

  async getCurrentBond(questionId: string): Promise<string> {
    void questionId;
    return ORACLE_BOND_AMOUNTS.reality_eth;
  }

  async getDisputePeriod(): Promise<number> {
    return DISPUTE_PERIOD_SECONDS;
  }

  getAddress(): string {
    return CONTRACT_ADDRESSES.realityEthOracle;
  }
}

export const oracleProviders = {
  chainlink: new ChainlinkOracleService(),
  uma: new UMAOracleService(),
  reality_eth: new RealityEthOracleService(),
} as const;

export function getOracleService(provider: OracleProvider) {
  return oracleProviders[provider];
}

export function getProviderDisplayName(provider: OracleProvider): string {
  const names: Record<OracleProvider, string> = {
    chainlink: "Chainlink",
    uma: "UMA Optimistic Oracle",
    reality_eth: "Reality.eth",
  };
  return names[provider];
}

export function getProviderConfidence(provider: OracleProvider): number {
  const confidences: Record<OracleProvider, number> = {
    chainlink: 0.95,
    uma: 0.85,
    reality_eth: 0.80,
  };
  return confidences[provider];
}
