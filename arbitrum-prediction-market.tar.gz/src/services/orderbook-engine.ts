import type { Order, OrderSide } from "@/types/market";

export interface OrderBookEntry {
  price: number;
  amount: string;
  total: string;
}

export interface OrderBookSnapshot {
  bids: OrderBookEntry[];
  asks: OrderBookEntry[];
  spread: number;
  midPrice: number;
}

function matchOrders(existing: Order[], incoming: Order): { matched: Order[]; remaining: Order } {
  const sortedBids = (orders: Order[]) =>
    [...orders].sort((a, b) => b.price - a.price);

  const sortedAsks = (orders: Order[]) =>
    [...orders].sort((a, b) => a.price - b.price);

  const isBuy = incoming.side === "buy";
  const oppositeOrders = isBuy
    ? sortedAsks(existing.filter((o) => o.side === "sell" && o.outcomeId === incoming.outcomeId))
    : sortedBids(existing.filter((o) => o.side === "buy" && o.outcomeId === incoming.outcomeId));

  const matched: Order[] = [];
  let remainingAmount = BigInt(incoming.amount);

  for (const order of oppositeOrders) {
    if (remainingAmount <= 0n) break;

    const canMatch = isBuy ? incoming.price >= order.price : incoming.price <= order.price;
    if (!canMatch) break;

    const orderRemaining = BigInt(order.amount) - BigInt(order.filledAmount);
    const fillAmount = remainingAmount < orderRemaining ? remainingAmount : orderRemaining;

    if (fillAmount > 0n) {
      matched.push({
        ...order,
        filledAmount: (BigInt(order.filledAmount) + fillAmount).toString(),
      });
      remainingAmount -= fillAmount;
    }
  }

  const filledAmount = (BigInt(incoming.amount) - remainingAmount).toString();

  return {
    matched,
    remaining: {
      ...incoming,
      filledAmount,
    },
  };
}

function aggregateOrders(orders: Order[], side: OrderSide): OrderBookEntry[] {
  const priceMap = new Map<number, bigint>();

  const filtered = orders.filter(
    (o) => o.side === side && BigInt(o.amount) > BigInt(o.filledAmount)
  );

  for (const order of filtered) {
    const remaining = BigInt(order.amount) - BigInt(order.filledAmount);
    priceMap.set(order.price, (priceMap.get(order.price) || 0n) + remaining);
  }

  const entries: OrderBookEntry[] = [];
  let cumulative = 0n;

  const sorted = [...priceMap.entries()].sort((a, b) =>
    side === "buy" ? b[0] - a[0] : a[0] - b[0]
  );

  for (const [price, amount] of sorted) {
    cumulative += amount;
    entries.push({
      price,
      amount: amount.toString(),
      total: cumulative.toString(),
    });
  }

  return entries;
}

function buildSnapshot(bids: OrderBookEntry[], asks: OrderBookEntry[]): OrderBookSnapshot {
  const bestBid = bids.length > 0 ? bids[0].price : 0;
  const bestAsk = asks.length > 0 ? asks[0].price : 1;
  const spread = bestAsk - bestBid;
  const midPrice = (bestBid + bestAsk) / 2;

  return { bids, asks, spread, midPrice };
}

export const OrderBookEngine = {
  matchOrders,
  aggregateOrders,
  buildSnapshot,
};
