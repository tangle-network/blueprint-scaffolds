import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TRADING_FEE } from "@/lib/constants"
import type { Market, OrderSide } from "@/lib/types"
import { useTrading } from "@/hooks/useTrading"
import { Loader2 } from "lucide-react"

interface TradingPanelProps {
  market: Market
}

export function TradingPanel({ market }: TradingPanelProps) {
  const { placeOrder, isSubmitting, calculateFee } = useTrading(market.id)
  const [selectedOutcome, setSelectedOutcome] = useState(market.outcomes[0])
  const [side, setSide] = useState<OrderSide>("buy")
  const [price, setPrice] = useState(
    market.outcomePrices[market.outcomes.indexOf(market.outcomes[0])]?.toFixed(2) || "0.50"
  )
  const [amount, setAmount] = useState("")

  const numericPrice = parseFloat(price) || 0
  const numericAmount = parseFloat(amount) || 0
  const total = numericPrice * numericAmount
  const fee = calculateFee(total)
  const priceIdx = market.outcomes.indexOf(selectedOutcome)

  const handleOutcomeChange = (outcome: string) => {
    setSelectedOutcome(outcome)
    const idx = market.outcomes.indexOf(outcome)
    if (idx >= 0) {
      setPrice(market.outcomePrices[idx].toFixed(2))
    }
  }

  const handleSubmit = async () => {
    if (numericAmount <= 0 || numericPrice <= 0) return
    await placeOrder(side, selectedOutcome, numericPrice, numericAmount)
    setAmount("")
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base">Trade</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-1 rounded-lg bg-muted p-1">
          <button
            className={`rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${side === "buy" ? "bg-background shadow text-emerald-400" : "text-muted-foreground"}`}
            onClick={() => setSide("buy")}
          >
            Buy
          </button>
          <button
            className={`rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${side === "sell" ? "bg-background shadow text-red-400" : "text-muted-foreground"}`}
            onClick={() => setSide("sell")}
          >
            Sell
          </button>
        </div>

        {market.marketType !== "scalar" && (
          <div className="grid grid-cols-2 gap-1 rounded-lg bg-muted p-1">
            {market.outcomes.map((outcome) => (
              <button
                key={outcome}
                className={`rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${selectedOutcome === outcome ? "bg-background shadow" : "text-muted-foreground"}`}
                onClick={() => handleOutcomeChange(outcome)}
              >
                {outcome} <span className="text-xs text-muted-foreground">{Math.round((market.outcomePrices[market.outcomes.indexOf(outcome)] || 0) * 100)}¢</span>
              </button>
            ))}
          </div>
        )}

        {market.tradingMode === "orderbook" && (
          <div className="space-y-2">
            <Label className="text-xs">Price (¢)</Label>
            <Input
              type="number"
              min="0.01"
              max="0.99"
              step="0.01"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
            />
          </div>
        )}

        <div className="space-y-2">
          <Label className="text-xs">Amount (shares)</Label>
          <Input
            type="number"
            min="1"
            step="1"
            placeholder="Enter amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
        </div>

        {numericAmount > 0 && (
          <div className="space-y-1 text-xs text-muted-foreground">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span>${total.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Fee ({(TRADING_FEE * 100).toFixed(0)}%)</span>
              <span>${fee.toFixed(2)}</span>
            </div>
            <div className="flex justify-between font-medium text-foreground border-t pt-1">
              <span>Total</span>
              <span>${(total + fee).toFixed(2)}</span>
            </div>
          </div>
        )}

        {market.marketType === "scalar" && market.scalarRange && (
          <div className="text-xs text-muted-foreground bg-muted rounded-md p-2">
            Scalar range: [{market.scalarRange.min}, {market.scalarRange.max}]
          </div>
        )}

        <Button
          className={`w-full ${side === "buy" ? "bg-emerald-600 hover:bg-emerald-700" : "bg-red-600 hover:bg-red-700"}`}
          disabled={isSubmitting || numericAmount <= 0}
          onClick={handleSubmit}
        >
          {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {side === "buy" ? "Buy" : "Sell"} {selectedOutcome}
        </Button>
      </CardContent>
    </Card>
  )
}
