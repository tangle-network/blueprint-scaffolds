import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { formatUsd, formatPercent } from "@/lib/utils"
import type { PricePoint } from "@/lib/types"
import { TrendingUp, TrendingDown, DollarSign, BarChart3 } from "lucide-react"

interface StatsCardsProps {
  totalVolume: number
  totalLiquidity: number
  activeMarkets: number
  totalUsers: number
}

export function StatsCards({ totalVolume, totalLiquidity, activeMarkets, totalUsers }: StatsCardsProps) {
  const stats = [
    { label: "Total Volume", value: formatUsd(totalVolume), icon: DollarSign, change: "+12.5%" },
    { label: "Total Liquidity", value: formatUsd(totalLiquidity), icon: TrendingUp, change: "+8.2%" },
    { label: "Active Markets", value: activeMarkets.toString(), icon: BarChart3, change: "+3" },
    { label: "Total Users", value: totalUsers.toLocaleString(), icon: TrendingUp, change: "+156" },
  ]

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <Card key={stat.label}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
                <p className="text-xl font-bold mt-1">{stat.value}</p>
              </div>
              <div className="rounded-md bg-muted p-2">
                <stat.icon className="h-4 w-4 text-muted-foreground" />
              </div>
            </div>
            <p className="text-xs text-emerald-400 mt-2">{stat.change} from last week</p>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
