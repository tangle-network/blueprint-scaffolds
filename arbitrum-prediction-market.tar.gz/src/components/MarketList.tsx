import { MarketCard } from "@/components/MarketCard"
import type { Market } from "@/lib/types"

interface MarketListProps {
  markets: Market[]
}

export function MarketList({ markets }: MarketListProps) {
  if (markets.length === 0) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        <p className="text-lg">No markets found</p>
        <p className="text-sm mt-1">Try adjusting your filters</p>
      </div>
    )
  }

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {markets.map((market) => (
        <MarketCard key={market.id} market={market} />
      ))}
    </div>
  )
}
