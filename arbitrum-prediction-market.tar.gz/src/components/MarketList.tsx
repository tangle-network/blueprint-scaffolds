import clsx from 'clsx';
import { Market } from '../types';
import { formatCurrency, formatDate, formatProbability } from '../lib/format';

interface MarketListProps {
  markets: Market[];
  selectedMarketId: string;
  onSelect: (marketId: string) => void;
}

export function MarketList({ markets, selectedMarketId, onSelect }: MarketListProps) {
  return (
    <section className="panel">
      <div className="panel__header">
        <div>
          <div className="eyebrow">Market browser</div>
          <h2>Active markets</h2>
        </div>
      </div>
      <div className="market-list">
        {markets.map((market) => {
          const leadOutcome = market.outcomes[0];

          return (
            <button
              key={market.id}
              className={clsx('market-card', selectedMarketId === market.id && 'market-card--active')}
              onClick={() => onSelect(market.id)}
              type="button"
            >
              <div className="market-card__top">
                <span className="pill">{market.type}</span>
                <span className="pill pill--muted">{market.tradingMode}</span>
              </div>
              <h3>{market.title}</h3>
              <p>{market.description}</p>
              <div className="market-card__stats">
                <div>
                  <span>24h Vol</span>
                  <strong>{formatCurrency(market.volume24h, true)}</strong>
                </div>
                <div>
                  <span>Liquidity</span>
                  <strong>{formatCurrency(market.totalLiquidity, true)}</strong>
                </div>
                <div>
                  <span>Lead price</span>
                  <strong>{formatProbability(leadOutcome.price)}</strong>
                </div>
                <div>
                  <span>Expiry</span>
                  <strong>{formatDate(market.endDate)}</strong>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
}
