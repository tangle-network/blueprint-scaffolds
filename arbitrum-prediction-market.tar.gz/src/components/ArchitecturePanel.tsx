export function ArchitecturePanel() {
  const modules = [
    {
      title: 'MarketFactory',
      text: 'Deploys binary, scalar, and categorical markets with isolated collateral vaults and oracle routes.',
    },
    {
      title: 'TradingEngine',
      text: 'Matches limit orders or routes through an LMSR-style AMM with fee accounting and inventory controls.',
    },
    {
      title: 'SettlementRouter',
      text: 'Requests Chainlink reads, optimistic proposals through UMA, and escalates disputes into Reality.eth.',
    },
  ];

  return (
    <section className="panel">
      <div className="panel__header">
        <div>
          <div className="eyebrow">Contracts</div>
          <h2>Onchain modules</h2>
        </div>
      </div>
      <div className="architecture-grid">
        {modules.map((module) => (
          <article className="architecture-card" key={module.title}>
            <h3>{module.title}</h3>
            <p>{module.text}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
