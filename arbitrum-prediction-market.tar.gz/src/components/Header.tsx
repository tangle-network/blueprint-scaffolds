export function Header() {
  return (
    <header className="hero">
      <div className="hero__copy">
        <div className="eyebrow">Arbitrum prediction rails</div>
        <h1>Trade conviction on real-world events.</h1>
        <p>
          Binary, scalar, and multi-outcome markets with hybrid AMM and order book execution,
          backed by Chainlink, UMA optimistic settlement, and Reality.eth disputes.
        </p>
      </div>
      <div className="hero__grid">
        <div className="hero-card">
          <span>Settlement stack</span>
          <strong>Factory + engine + oracle router</strong>
        </div>
        <div className="hero-card">
          <span>Execution</span>
          <strong>AMM curves and priced limit orders</strong>
        </div>
        <div className="hero-card">
          <span>Collateral</span>
          <strong>USDC vaults on Arbitrum One</strong>
        </div>
      </div>
    </header>
  );
}
