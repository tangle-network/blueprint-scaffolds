import { Link, useLocation } from "react-router-dom"
import { Wallet, BarChart3, PlusCircle, Home, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useWallet } from "@/hooks/useWallet"

export function Header() {
  const location = useLocation()
  const { isConnected, isConnecting, displayAddress, balance, connect, disconnect } = useWallet()

  const navItems = [
    { path: "/", label: "Markets", icon: Home },
    { path: "/create", label: "Create Market", icon: PlusCircle },
    { path: "/portfolio", label: "Portfolio", icon: Wallet },
    { path: "/analytics", label: "Analytics", icon: BarChart3 },
  ]

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 max-w-screen-2xl items-center">
        <Link to="/" className="mr-6 flex items-center space-x-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-600 text-white font-bold text-sm">
            PM
          </div>
          <span className="hidden font-bold sm:inline-block">PredictArb</span>
        </Link>

        <nav className="flex items-center gap-1 text-sm font-medium">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-1.5 rounded-md px-3 py-2 transition-colors hover:bg-accent ${
                location.pathname === item.path
                  ? "bg-accent text-accent-foreground"
                  : "text-muted-foreground"
              }`}
            >
              <item.icon className="h-4 w-4" />
              <span className="hidden md:inline">{item.label}</span>
            </Link>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-2">
          {isConnected ? (
            <>
              <span className="text-xs text-muted-foreground">{balance} ETH</span>
              <span className="rounded-md border px-2 py-1 text-xs font-mono">
                {displayAddress}
              </span>
              <Button variant="ghost" size="icon" onClick={disconnect}>
                <LogOut className="h-4 w-4" />
              </Button>
            </>
          ) : (
            <Button onClick={connect} disabled={isConnecting} size="sm">
              <Wallet className="mr-2 h-4 w-4" />
              {isConnecting ? "Connecting..." : "Connect Wallet"}
            </Button>
          )}
        </div>
      </div>
    </header>
  )
}
