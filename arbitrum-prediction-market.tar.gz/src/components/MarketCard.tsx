import { Link } from "react-router-dom"
import { TrendingUp, Clock, Landmark, Bitcoin, Trophy, Microscope, Cpu, CloudSun, Clapperboard } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { formatUsd, formatDate } from "@/lib/utils"
import { ORACLE_NAMES } from "@/lib/constants"
import type { Market } from "@/lib/types"

const categoryIcons: Record<string, React.ElementType> = {
  politics: Landmark,
  crypto: Bitcoin,
  sports: Trophy,
  science: Microscope,
  tech: Cpu,
  economics: TrendingUp,
  entertainment: Clapperboard,
  weather: CloudSun,
}

const statusColors: Record<string, "success" | "secondary" | "destructive" | "warning"> = {
  active: "success",
  closed: "secondary",
  settled: "secondary",
  disputed: "warning",
}

interface MarketCardProps {
  market: Market
}

export function MarketCard({ market }: MarketCardProps) {
  const IconComp = categoryIcons[market.category] || TrendingUp

  return (
    <Link to={`/market/${market.id}`}>
      <Card className="transition-all hover:border-primary/50 hover:shadow-md cursor-pointer h-full">
        <CardContent className="p-4 flex flex-col gap-3 h-full">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2 text-muted-foreground">
              <IconComp className="h-4 w-4" />
              <span className="text-xs capitalize">{market.category}</span>
            </div>
            <Badge variant={statusColors[market.status] || "secondary"} className="capitalize text-[10px]">
              {market.status}
            </Badge>
          </div>

          <h3 className="font-semibold text-sm leading-tight line-clamp-2 flex-1">{market.title}</h3>

          {market.marketType === "binary" && (
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-emerald-400 font-medium">Yes {Math.round(market.outcomePrices[0] * 100)}¢</span>
                <span className="text-red-400 font-medium">No {Math.round(market.outcomePrices[1] * 100)}¢</span>
              </div>
              <Progress value={market.outcomePrices[0] * 100} className="h-1.5" />
            </div>
          )}

          {market.marketType === "multi_outcome" && (
            <div className="space-y-1">
              {market.outcomes.map((o, i) => (
                <div key={o} className="flex items-center gap-2">
                  <span className="text-xs w-20 truncate">{o}</span>
                  <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-500 rounded-full"
                      style={{ width: `${market.outcomePrices[i] * 100}%` }}
                    />
                  </div>
                  <span className="text-xs text-muted-foreground w-10 text-right">{Math.round(market.outcomePrices[i] * 100)}¢</span>
                </div>
              ))}
            </div>
          )}

          {market.marketType === "scalar" && market.scalarRange && (
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Min: {market.scalarRange.min}</span>
                <span>Max: {market.scalarRange.max}</span>
              </div>
              <Progress value={market.outcomePrices[0] * 100} className="h-1.5" />
            </div>
          )}

          <div className="flex items-center justify-between text-xs text-muted-foreground pt-1 border-t">
            <span>Vol: {formatUsd(market.volume)}</span>
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {formatDate(market.endDate)}
            </span>
            <span>{ORACLE_NAMES[market.oracleType]}</span>
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}
