import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CATEGORIES, ORACLE_NAMES } from "@/lib/constants"
import type { MarketType, OracleType, TradingMode } from "@/lib/types"
import { Loader2 } from "lucide-react"

export function CreateMarketForm() {
  const navigate = useNavigate()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [category, setCategory] = useState("")
  const [marketType, setMarketType] = useState<MarketType>("binary")
  const [oracleType, setOracleType] = useState<OracleType>("chainlink")
  const [tradingMode, setTradingMode] = useState<TradingMode>("amm")
  const [outcomes, setOutcomes] = useState("Yes,No")
  const [endDate, setEndDate] = useState("")
  const [resolutionSource, setResolutionSource] = useState("")
  const [scalarMin, setScalarMin] = useState("")
  const [scalarMax, setScalarMax] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    await new Promise((r) => setTimeout(r, 2000))
    setIsSubmitting(false)
    navigate("/")
  }

  return (
    <form onSubmit={handleSubmit}>
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Market Details</CardTitle>
              <CardDescription>Define your prediction market question and parameters</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Market Question</Label>
                <Input
                  id="title"
                  placeholder="e.g., Will Bitcoin reach $200,000 by 2027?"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <textarea
                  id="description"
                  className="flex min-h-[100px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                  placeholder="Detailed description of how this market will resolve..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Category</Label>
                  <Select value={category} onValueChange={setCategory} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.map((c) => (
                        <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Market Type</Label>
                  <Select value={marketType} onValueChange={(v) => setMarketType(v as MarketType)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="binary">Binary (Yes/No)</SelectItem>
                      <SelectItem value="scalar">Scalar (Range)</SelectItem>
                      <SelectItem value="multi_outcome">Multi-Outcome</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="outcomes">
                  {marketType === "scalar" ? "Outcome Label" : "Outcomes (comma-separated)"}
                </Label>
                <Input
                  id="outcomes"
                  value={outcomes}
                  onChange={(e) => setOutcomes(e.target.value)}
                  disabled={marketType === "scalar"}
                  placeholder={marketType === "scalar" ? "Scalar" : "Yes, No"}
                />
              </div>

              {marketType === "scalar" && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Range Minimum</Label>
                    <Input
                      type="number"
                      value={scalarMin}
                      onChange={(e) => setScalarMin(e.target.value)}
                      placeholder="0"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Range Maximum</Label>
                    <Input
                      type="number"
                      value={scalarMax}
                      onChange={(e) => setScalarMax(e.target.value)}
                      placeholder="100"
                    />
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="endDate">End Date</Label>
                  <Input
                    id="endDate"
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="resolution">Resolution Source</Label>
                  <Input
                    id="resolution"
                    placeholder="e.g., Chainlink Price Feed"
                    value={resolutionSource}
                    onChange={(e) => setResolutionSource(e.target.value)}
                    required
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Oracle</Label>
                <Select value={oracleType} onValueChange={(v) => setOracleType(v as OracleType)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {(Object.keys(ORACLE_NAMES) as OracleType[]).map((key) => (
                      <SelectItem key={key} value={key}>{ORACLE_NAMES[key]}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  {oracleType === "chainlink" && "Uses Chainlink price feeds for automated resolution."}
                  {oracleType === "uma" && "Uses UMA's optimistic oracle with 2-hour dispute window."}
                  {oracleType === "reality_eth" && "Community-driven resolution with bonded answers."}
                </p>
              </div>

              <div className="space-y-2">
                <Label>Trading Mode</Label>
                <Select value={tradingMode} onValueChange={(v) => setTradingMode(v as TradingMode)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="amm">AMM (Automated Market Maker)</SelectItem>
                    <SelectItem value="orderbook">Order Book</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  {tradingMode === "amm" && "Instant trades against a liquidity pool."}
                  {tradingMode === "orderbook" && "Place limit orders with price discovery."}
                </p>
              </div>

              <div className="space-y-2 pt-4 border-t">
                <div className="text-xs text-muted-foreground">
                  <p>Network: Arbitrum One</p>
                  <p>Trading Fee: 2%</p>
                  <p>Creation Fee: ~0.001 ETH</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Button type="submit" className="w-full" disabled={isSubmitting || !title || !description}>
            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Create Market
          </Button>
        </div>
      </div>
    </form>
  )
}
