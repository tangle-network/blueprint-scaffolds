import { Market } from '../types';
import { formatCurrency } from '../lib/format';

interface AnalyticsPanelProps {
  market: Market;
}

function buildSeries(market: Market) {
  return [
    { label: '00:00', volume: market.volume24h * 0.13, liquidity: market.totalLiquidity * 0.72 },
    { label: '04:00', volume: market.volume24h * 0.25, liquidity: market.totalLiquidity * 0.8 },
    { label: '08:00', volume: market.volume24h * 0.39, liquidity: market.totalLiquidity * 0.78 },
    { label: '12:00', volume: market.volume24h * 0.58, liquidity: market.totalLiquidity * 0.86 },
    { label: '16:00', volume: market.volume24h * 0.76, liquidity: market.totalLiquidity * 0.92 },
    { label: '20:00', volume: market.volume24h, liquidity: market.totalLiquidity },
  ];
}

export function AnalyticsPanel({ market }: AnalyticsPanelProps) {
  const series = buildSeries(market);
  const width = 640;
  const height = 280;
  const padding = 24;
  const maxValue = Math.max(...series.map((point) => Math.max(point.volume, point.liquidity)));
  const xStep = (width - padding * 2) / (series.length - 1);
  const plotY = (value: number) => height - padding - (value / maxValue) * (height - padding * 2);
  const volumePath = series
    .map((point, index) => `${index === 0 ? 'M' : 'L'} ${padding + index * xStep} ${plotY(point.volume)}`)
    .join(' ');
  const liquidityPath = series
    .map((point, index) => `${index === 0 ? 'M' : 'L'} ${padding + index * xStep} ${plotY(point.liquidity)}`)
    .join(' ');

  return (
    <section className="panel">
      <div className="panel__header">
        <div>
          <div className="eyebrow">Analytics</div>
          <h2>Volume and liquidity</h2>
        </div>
      </div>
      <div className="chart-wrap">
        <svg viewBox={`0 0 ${width} ${height}`} aria-label="Volume and liquidity chart" role="img">
          <rect width={width} height={height} rx="20" fill="rgba(23, 32, 48, 0.03)" />
          {[0.25, 0.5, 0.75].map((tick) => (
            <line
              key={tick}
              x1={padding}
              x2={width - padding}
              y1={padding + tick * (height - padding * 2)}
              y2={padding + tick * (height - padding * 2)}
              stroke="rgba(23, 32, 48, 0.09)"
              strokeDasharray="4 6"
            />
          ))}
          <path d={liquidityPath} fill="none" stroke="#2a9d8f" strokeWidth="4" strokeLinecap="round" />
          <path d={volumePath} fill="none" stroke="#e76f51" strokeWidth="4" strokeLinecap="round" />
          {series.map((point, index) => (
            <g key={point.label}>
              <circle cx={padding + index * xStep} cy={plotY(point.volume)} r="4.5" fill="#e76f51" />
              <circle cx={padding + index * xStep} cy={plotY(point.liquidity)} r="4.5" fill="#2a9d8f" />
              <text
                x={padding + index * xStep}
                y={height - 6}
                textAnchor="middle"
                fontSize="11"
                fill="rgba(23, 32, 48, 0.65)"
              >
                {point.label}
              </text>
            </g>
          ))}
        </svg>
        <div className="chart-legend">
          <div>
            <span className="legend-dot legend-dot--volume" />
            Volume {formatCurrency(market.volume24h, true)}
          </div>
          <div>
            <span className="legend-dot legend-dot--liquidity" />
            Liquidity {formatCurrency(market.totalLiquidity, true)}
          </div>
        </div>
      </div>
    </section>
  );
}
