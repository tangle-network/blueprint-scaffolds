import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CATEGORIES } from "@/lib/constants"
import type { MarketStatus, MarketType } from "@/lib/types"

interface MarketFiltersProps {
  searchQuery: string
  onSearchChange: (q: string) => void
  filterStatus: MarketStatus | "all"
  onStatusChange: (s: MarketStatus | "all") => void
  filterCategory: string
  onCategoryChange: (c: string) => void
  filterType: MarketType | "all"
  onTypeChange: (t: MarketType | "all") => void
}

export function MarketFilters({
  searchQuery,
  onSearchChange,
  filterStatus,
  onStatusChange,
  filterCategory,
  onCategoryChange,
  filterType,
  onTypeChange,
}: MarketFiltersProps) {
  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
      <div className="relative flex-1">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search markets..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-8"
        />
      </div>
      <div className="flex gap-2 flex-wrap">
        <Select value={filterStatus} onValueChange={(v) => onStatusChange(v as MarketStatus | "all")}>
          <SelectTrigger className="w-[130px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="closed">Closed</SelectItem>
            <SelectItem value="settled">Settled</SelectItem>
            <SelectItem value="disputed">Disputed</SelectItem>
          </SelectContent>
        </Select>

        <Select value={filterCategory} onValueChange={onCategoryChange}>
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {CATEGORIES.map((c) => (
              <SelectItem key={c.id} value={c.id}>
                {c.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={filterType} onValueChange={(v) => onTypeChange(v as MarketType | "all")}>
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder="Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="binary">Binary</SelectItem>
            <SelectItem value="scalar">Scalar</SelectItem>
            <SelectItem value="multi_outcome">Multi-Outcome</SelectItem>
          </SelectContent>
        </Select>

        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            onSearchChange("")
            onStatusChange("all")
            onCategoryChange("all")
            onTypeChange("all")
          }}
        >
          Reset
        </Button>
      </div>
    </div>
  )
}
