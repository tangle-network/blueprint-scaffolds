import { Market } from '../types';
import { formatProbability } from '../lib/format';

interface OrderBookProps {
  market: Market;
}

export function OrderBook({ market }: OrderBookProps) {
  const outcome = market.outcomes[0];

  return (
    <section className="panel">
      <div className="panel__header">
        <div>
          <div className="eyebrow">Liquidity view</div>
          <h2>Top of book</h2>
        </div>
      </div>
      <div className="book-grid">
        <div>
          <h3>Bids for {outcome.label}</h3>
          <div className="book-table">
            {outcome.bidDepth.map((level) => (
              <div className="book-row" key={`bid-${level.price}`}>
                <span>{formatProbability(level.price)}</span>
                <strong>{level.size.toLocaleString()}</strong>
              </div>
            ))}
          </div>
        </div>
        <div>
          <h3>Asks for {outcome.label}</h3>
          <div className="book-table">
            {outcome.askDepth.map((level) => (
              <div className="book-row" key={`ask-${level.price}`}>
                <span>{formatProbability(level.price)}</span>
                <strong>{level.size.toLocaleString()}</strong>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
