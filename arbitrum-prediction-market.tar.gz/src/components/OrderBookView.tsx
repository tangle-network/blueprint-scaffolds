import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { timeAgo } from "@/lib/utils"
import type { Order } from "@/lib/types"

interface OrderBookViewProps {
  orders: Order[]
}

export function OrderBookView({ orders }: OrderBookViewProps) {
  const buys = orders.filter((o) => o.side === "buy").sort((a, b) => b.price - a.price)
  const sells = orders.filter((o) => o.side === "sell").sort((a, b) => a.price - b.price)

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base">Order Book</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="text-xs font-medium text-emerald-400 mb-2">Bids</div>
            <table className="w-full text-xs">
              <thead>
                <tr className="text-muted-foreground">
                  <th className="text-left pb-1">Price</th>
                  <th className="text-right pb-1">Size</th>
                  <th className="text-right pb-1">Filled</th>
                </tr>
              </thead>
              <tbody>
                {buys.map((o) => (
                  <tr key={o.id} className="border-t border-border/50">
                    <td className="py-1 text-emerald-400">${o.price.toFixed(2)}</td>
                    <td className="py-1 text-right">{o.amount}</td>
                    <td className="py-1 text-right">{o.filled}/{o.amount}</td>
                  </tr>
                ))}
                {buys.length === 0 && (
                  <tr><td colSpan={3} className="py-2 text-center text-muted-foreground">No bids</td></tr>
                )}
              </tbody>
            </table>
          </div>
          <div>
            <div className="text-xs font-medium text-red-400 mb-2">Asks</div>
            <table className="w-full text-xs">
              <thead>
                <tr className="text-muted-foreground">
                  <th className="text-left pb-1">Price</th>
                  <th className="text-right pb-1">Size</th>
                  <th className="text-right pb-1">Filled</th>
                </tr>
              </thead>
              <tbody>
                {sells.map((o) => (
                  <tr key={o.id} className="border-t border-border/50">
                    <td className="py-1 text-red-400">${o.price.toFixed(2)}</td>
                    <td className="py-1 text-right">{o.amount}</td>
                    <td className="py-1 text-right">{o.filled}/{o.amount}</td>
                  </tr>
                ))}
                {sells.length === 0 && (
                  <tr><td colSpan={3} className="py-2 text-center text-muted-foreground">No asks</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="mt-4 border-t pt-3">
          <div className="text-xs font-medium mb-2">Recent Orders</div>
          <div className="space-y-1">
            {orders.slice(0, 5).map((o) => (
              <div key={o.id} className="flex justify-between text-xs text-muted-foreground">
                <span className={o.side === "buy" ? "text-emerald-400" : "text-red-400"}>
                  {o.side.toUpperCase()} {o.outcome}
                </span>
                <span>${o.price.toFixed(2)} x {o.amount}</span>
                <span>{timeAgo(o.timestamp)}</span>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
