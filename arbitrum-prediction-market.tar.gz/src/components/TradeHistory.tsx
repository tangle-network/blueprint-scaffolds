import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { timeAgo } from "@/lib/utils"
import type { Trade } from "@/lib/types"

interface TradeHistoryProps {
  trades: Trade[]
}

export function TradeHistory({ trades }: TradeHistoryProps) {
  if (trades.length === 0) {
    return (
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Trade History</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground text-center py-4">No trades yet</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base">Trade History</CardTitle>
      </CardHeader>
      <CardContent>
        <table className="w-full text-xs">
          <thead>
            <tr className="text-muted-foreground border-b">
              <th className="text-left pb-2">Side</th>
              <th className="text-left pb-2">Outcome</th>
              <th className="text-right pb-2">Price</th>
              <th className="text-right pb-2">Amount</th>
              <th className="text-right pb-2">Time</th>
            </tr>
          </thead>
          <tbody>
            {trades.map((t) => (
              <tr key={t.id} className="border-t border-border/50">
                <td className={`py-1.5 ${t.side === "buy" ? "text-emerald-400" : "text-red-400"}`}>
                  {t.side.toUpperCase()}
                </td>
                <td className="py-1.5">{t.outcome}</td>
                <td className="py-1.5 text-right">${t.price.toFixed(2)}</td>
                <td className="py-1.5 text-right">{t.amount}</td>
                <td className="py-1.5 text-right text-muted-foreground">{timeAgo(t.timestamp)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </CardContent>
    </Card>
  )
}
