import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import type { PricePoint } from "@/lib/types"

interface VolumeChartProps {
  data: PricePoint[]
}

export function VolumeChart({ data }: VolumeChartProps) {
  if (data.length === 0) return null

  const maxVol = Math.max(...data.map((d) => d.volume))
  const chartHeight = 120
  const chartWidth = 700
  const barWidth = chartWidth / data.length

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base">Volume</CardTitle>
      </CardHeader>
      <CardContent>
        <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-auto">
          {data.map((d, i) => {
            const barHeight = (d.volume / maxVol) * (chartHeight - 10)
            return (
              <rect
                key={i}
                x={i * barWidth}
                y={chartHeight - barHeight}
                width={Math.max(barWidth - 1, 1)}
                height={barHeight}
                fill="rgb(59,130,246)"
                opacity="0.5"
                rx="1"
              />
            )
          })}
        </svg>
      </CardContent>
    </Card>
  )
}
