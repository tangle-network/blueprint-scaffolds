import { Market } from '../types';
import { formatCurrency, formatDate, formatProbability } from '../lib/format';

interface MarketOverviewProps {
  market: Market;
}

export function MarketOverview({ market }: MarketOverviewProps) {
  return (
    <section className="panel">
      <div className="panel__header">
        <div>
          <div className="eyebrow">Selected market</div>
          <h2>{market.title}</h2>
        </div>
        <div className="stacked-pills">
          <span className="pill">{market.oracle}</span>
          <span className="pill pill--muted">{market.chain}</span>
        </div>
      </div>

      <p className="panel__lead">{market.description}</p>

      <div className="stats-grid">
        <div className="stat">
          <span>Open interest</span>
          <strong>{formatCurrency(market.openInterest, true)}</strong>
        </div>
        <div className="stat">
          <span>Total liquidity</span>
          <strong>{formatCurrency(market.totalLiquidity, true)}</strong>
        </div>
        <div className="stat">
          <span>Fees</span>
          <strong>{(market.feeBps / 100).toFixed(2)}%</strong>
        </div>
        <div className="stat">
          <span>Settlement</span>
          <strong>{formatDate(market.endDate)}</strong>
        </div>
      </div>

      {market.range ? (
        <div className="range-bar">
          <div
            className="range-bar__fill"
            style={{
              width: `${((market.range.current - market.range.min) / (market.range.max - market.range.min)) * 100}%`,
            }}
          />
          <div className="range-bar__labels">
            <span>
              {market.range.min} {market.range.unit}
            </span>
            <strong>
              Implied {market.range.current} {market.range.unit}
            </strong>
            <span>
              {market.range.max} {market.range.unit}
            </span>
          </div>
        </div>
      ) : null}

      <div className="outcomes">
        {market.outcomes.map((outcome) => (
          <article className="outcome-card" key={outcome.id}>
            <div className="outcome-card__top">
              <h3>{outcome.label}</h3>
              <span className={outcome.change24h >= 0 ? 'positive' : 'negative'}>
                {outcome.change24h >= 0 ? '+' : ''}
                {outcome.change24h.toFixed(1)}%
              </span>
            </div>
            <div className="outcome-card__metrics">
              <div>
                <span>Price</span>
                <strong>{formatProbability(outcome.price)}</strong>
              </div>
              <div>
                <span>Prob.</span>
                <strong>{formatProbability(outcome.probability)}</strong>
              </div>
              <div>
                <span>Depth</span>
                <strong>{formatCurrency(outcome.liquidity, true)}</strong>
              </div>
            </div>
          </article>
        ))}
      </div>

      <div className="resolution-box">
        <span>Resolution source</span>
        <strong>{market.resolutionSource}</strong>
      </div>
    </section>
  );
}
