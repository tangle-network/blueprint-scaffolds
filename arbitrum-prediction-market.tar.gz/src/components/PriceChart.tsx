import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { formatUsd } from "@/lib/utils"
import type { PricePoint } from "@/lib/types"

interface PriceChartProps {
  data: PricePoint[]
  outcome: string
}

export function PriceChart({ data, outcome }: PriceChartProps) {
  if (data.length === 0) {
    return (
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Price Chart — {outcome}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground text-center py-8">No price data available</p>
        </CardContent>
      </Card>
    )
  }

  const maxPrice = Math.max(...data.map((d) => d.price))
  const minPrice = Math.min(...data.map((d) => d.price))
  const priceRange = maxPrice - minPrice || 0.01
  const chartHeight = 200
  const chartWidth = 700

  const points = data.map((d, i) => {
    const x = (i / (data.length - 1)) * chartWidth
    const y = chartHeight - ((d.price - minPrice) / priceRange) * (chartHeight - 20) - 10
    return { x, y, ...d }
  })

  const pathD = points.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x} ${p.y}`).join(" ")
  const areaD = `${pathD} L ${points[points.length - 1].x} ${chartHeight} L ${points[0].x} ${chartHeight} Z`

  const latestPrice = data[data.length - 1].price
  const prevPrice = data.length > 1 ? data[data.length - 2].price : latestPrice
  const priceChange = latestPrice - prevPrice

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base">Price Chart — {outcome}</CardTitle>
          <div className="flex items-center gap-2">
            <span className="text-lg font-bold">{formatUsd(latestPrice)}</span>
            <span className={`text-xs ${priceChange >= 0 ? "text-emerald-400" : "text-red-400"}`}>
              {priceChange >= 0 ? "+" : ""}{(priceChange * 100).toFixed(1)}¢
            </span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-auto">
          <defs>
            <linearGradient id="priceGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="rgb(59,130,246)" stopOpacity="0.3" />
              <stop offset="100%" stopColor="rgb(59,130,246)" stopOpacity="0" />
            </linearGradient>
          </defs>
          {[0, 0.25, 0.5, 0.75, 1].map((pct) => {
            const y = 10 + pct * (chartHeight - 20)
            const priceVal = maxPrice - pct * priceRange
            return (
              <g key={pct}>
                <line x1="0" y1={y} x2={chartWidth} y2={y} stroke="currentColor" strokeOpacity="0.1" />
                <text x="2" y={y - 2} className="text-[8px] fill-muted-foreground">
                  {priceVal.toFixed(2)}
                </text>
              </g>
            )
          })}
          <path d={areaD} fill="url(#priceGrad)" />
          <path d={pathD} fill="none" stroke="rgb(59,130,246)" strokeWidth="2" />
          {points.length > 0 && (
            <circle cx={points[points.length - 1].x} cy={points[points.length - 1].y} r="3" fill="rgb(59,130,246)" />
          )}
        </svg>
      </CardContent>
    </Card>
  )
}
