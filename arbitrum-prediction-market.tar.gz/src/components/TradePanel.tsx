import { useMemo, useState } from 'react';
import { Market, TradeTicket } from '../types';
import { formatCurrency, formatProbability } from '../lib/format';

interface TradePanelProps {
  market: Market;
}

export function TradePanel({ market }: TradePanelProps) {
  const [ticket, setTicket] = useState<TradeTicket>({
    outcomeId: market.outcomes[0]?.id ?? '',
    side: 'buy',
    stake: 250,
  });

  const outcome = useMemo(
    () => market.outcomes.find((item) => item.id === ticket.outcomeId) ?? market.outcomes[0],
    [market.outcomes, ticket.outcomeId],
  );

  const averagePrice = outcome?.price ?? 0;
  const shares = ticket.stake / Math.max(averagePrice, 0.01);
  const fee = (ticket.stake * market.feeBps) / 10000;
  const maxPayout = ticket.side === 'buy' ? shares - fee : ticket.stake - fee;

  return (
    <section className="panel">
      <div className="panel__header">
        <div>
          <div className="eyebrow">Trading interface</div>
          <h2>Build position</h2>
        </div>
      </div>

      <div className="trade-toggle">
        <button
          className={ticket.side === 'buy' ? 'toggle active' : 'toggle'}
          onClick={() => setTicket((current) => ({ ...current, side: 'buy' }))}
          type="button"
        >
          Buy
        </button>
        <button
          className={ticket.side === 'sell' ? 'toggle active' : 'toggle'}
          onClick={() => setTicket((current) => ({ ...current, side: 'sell' }))}
          type="button"
        >
          Sell
        </button>
      </div>

      <label className="field">
        <span>Outcome</span>
        <select
          value={ticket.outcomeId}
          onChange={(event) => setTicket((current) => ({ ...current, outcomeId: event.target.value }))}
        >
          {market.outcomes.map((item) => (
            <option key={item.id} value={item.id}>
              {item.label}
            </option>
          ))}
        </select>
      </label>

      <label className="field">
        <span>Stake ({market.collateralSymbol})</span>
        <input
          min={1}
          step={25}
          type="number"
          value={ticket.stake}
          onChange={(event) =>
            setTicket((current) => ({ ...current, stake: Number(event.target.value) || 0 }))
          }
        />
      </label>

      <div className="trade-summary">
        <div>
          <span>Execution venue</span>
          <strong>{market.tradingMode}</strong>
        </div>
        <div>
          <span>Mark price</span>
          <strong>{formatProbability(averagePrice)}</strong>
        </div>
        <div>
          <span>Estimated fee</span>
          <strong>{formatCurrency(fee)}</strong>
        </div>
        <div>
          <span>{ticket.side === 'buy' ? 'Potential shares' : 'Estimated proceeds'}</span>
          <strong>{ticket.side === 'buy' ? shares.toFixed(2) : formatCurrency(maxPayout)}</strong>
        </div>
      </div>

      <button className="action-button" type="button">
        {ticket.side === 'buy' ? 'Submit buy order' : 'Submit sell order'}
      </button>
    </section>
  );
}
