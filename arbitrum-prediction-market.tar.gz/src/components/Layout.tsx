import { Outlet } from "react-router-dom"
import { Header } from "@/components/Header"
import { TooltipProvider } from "@/components/ui/tooltip"

export function Layout() {
  return (
    <TooltipProvider>
      <div className="relative min-h-screen bg-background">
        <Header />
        <main className="container max-w-screen-2xl py-6">
          <Outlet />
        </main>
        <footer className="border-t py-6 text-center text-sm text-muted-foreground">
          <div className="container max-w-screen-2xl">
            PredictArb — Prediction Markets on Arbitrum
          </div>
        </footer>
      </div>
    </TooltipProvider>
  )
}
