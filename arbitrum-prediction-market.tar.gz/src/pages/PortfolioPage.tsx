import { Link } from "react-router-dom"
import { usePortfolio } from "@/hooks/usePortfolio"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { formatUsd } from "@/lib/utils"
import { TrendingUp, TrendingDown, Wallet } from "lucide-react"

export default function PortfolioPage() {
  const { positions, totalPnl, totalValue } = usePortfolio()

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Portfolio</h1>
        <p className="text-muted-foreground">Your active positions and PnL</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <Card>
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Total Value</p>
            <p className="text-2xl font-bold">{formatUsd(totalValue)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Total PnL</p>
            <p className={`text-2xl font-bold ${totalPnl >= 0 ? "text-emerald-400" : "text-red-400"}`}>
              {totalPnl >= 0 ? "+" : ""}{formatUsd(totalPnl)}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Active Positions</p>
            <p className="text-2xl font-bold">{positions.length}</p>
          </CardContent>
        </Card>
      </div>

      {positions.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <Wallet className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-lg font-medium">No positions yet</p>
            <p className="text-sm text-muted-foreground mb-4">Start trading to see your positions here</p>
            <Link to="/">
              <Button>Browse Markets</Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Positions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {positions.map((pos, idx) => (
                <Link key={idx} to={`/market/${pos.marketId}`}>
                  <div className="flex items-center justify-between p-3 rounded-lg border hover:bg-accent/50 transition-colors">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{pos.marketTitle}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline" className="text-xs">{pos.outcome}</Badge>
                        <span className="text-xs text-muted-foreground">
                          {pos.shares} shares @ avg {formatUsd(pos.avgPrice)}
                        </span>
                      </div>
                    </div>
                    <div className="text-right ml-4">
                      <p className="text-sm font-medium">{formatUsd(pos.shares * pos.currentPrice)}</p>
                      <p className={`text-xs flex items-center justify-end gap-1 ${pos.pnl >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                        {pos.pnl >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                        {pos.pnl >= 0 ? "+" : ""}{formatUsd(pos.pnl)}
                      </p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
