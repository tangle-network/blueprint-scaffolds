import { CreateMarketForm } from "@/components/CreateMarketForm"

export default function CreatePage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Create Market</h1>
        <p className="text-muted-foreground">Deploy a new prediction market on Arbitrum</p>
      </div>
      <CreateMarketForm />
    </div>
  )
}
