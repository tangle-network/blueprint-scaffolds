import { useParams, Link } from "react-router-dom"
import { useMarkets } from "@/hooks/useMarkets"
import { useTrading } from "@/hooks/useTrading"
import { TradingPanel } from "@/components/TradingPanel"
import { OrderBookView } from "@/components/OrderBookView"
import { TradeHistory } from "@/components/TradeHistory"
import { PriceChart } from "@/components/PriceChart"
import { VolumeChart } from "@/components/VolumeChart"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { formatUsd, formatDate, formatAddress } from "@/lib/utils"
import { ORACLE_NAMES } from "@/lib/constants"
import { ArrowLeft, ExternalLink, Clock, TrendingUp, Droplets } from "lucide-react"

export default function MarketPage() {
  const { id } = useParams<{ id: string }>()
  const { getMarket, getPriceHistory } = useMarkets()

  const market = getMarket(id || "")
  if (!market) {
    return (
      <div className="text-center py-12">
        <p className="text-lg">Market not found</p>
        <Link to="/" className="text-sm text-blue-500 hover:underline mt-2 inline-block">Back to markets</Link>
      </div>
    )
  }

  const { orders, trades } = useTrading(market.id)
  const primaryOutcome = market.outcomes[0]
  const priceHistory = getPriceHistory(market.id, primaryOutcome)

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Link to="/">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <Badge variant="secondary" className="capitalize text-xs">{market.category}</Badge>
            <Badge variant="secondary" className="text-xs">{market.marketType === "multi_outcome" ? "Multi-Outcome" : market.marketType === "scalar" ? "Scalar" : "Binary"}</Badge>
            <Badge variant="secondary" className="text-xs">{market.tradingMode === "amm" ? "AMM" : "Order Book"}</Badge>
            <Badge variant={market.status === "active" ? "success" : "secondary"} className="capitalize text-xs">{market.status}</Badge>
          </div>
          <h1 className="text-xl font-bold">{market.title}</h1>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">{market.description}</p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4 pt-4 border-t">
                <div>
                  <p className="text-xs text-muted-foreground flex items-center gap-1"><TrendingUp className="h-3 w-3" /> Volume</p>
                  <p className="font-semibold">{formatUsd(market.volume)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground flex items-center gap-1"><Droplets className="h-3 w-3" /> Liquidity</p>
                  <p className="font-semibold">{formatUsd(market.liquidity)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground flex items-center gap-1"><Clock className="h-3 w-3" /> Ends</p>
                  <p className="font-semibold">{formatDate(market.endDate)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Oracle</p>
                  <p className="font-semibold">{ORACLE_NAMES[market.oracleType]}</p>
                </div>
              </div>
              <div className="flex items-center justify-between mt-3 pt-3 border-t text-xs text-muted-foreground">
                <span>Creator: {formatAddress(market.creator)}</span>
                <span>Resolution: {market.resolutionSource}</span>
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="chart">
            <TabsList>
              <TabsTrigger value="chart">Chart</TabsTrigger>
              <TabsTrigger value="orderbook">Order Book</TabsTrigger>
              <TabsTrigger value="trades">Trades</TabsTrigger>
            </TabsList>
            <TabsContent value="chart" className="space-y-4">
              <PriceChart data={priceHistory} outcome={primaryOutcome} />
              <VolumeChart data={priceHistory} />
            </TabsContent>
            <TabsContent value="orderbook">
              <OrderBookView orders={orders} />
            </TabsContent>
            <TabsContent value="trades">
              <TradeHistory trades={trades} />
            </TabsContent>
          </Tabs>
        </div>

        <div>
          <TradingPanel market={market} />
        </div>
      </div>
    </div>
  )
}
