import { useMarkets } from "@/hooks/useMarkets"
import { StatsCards } from "@/components/StatsCards"
import { PriceChart } from "@/components/PriceChart"
import { VolumeChart } from "@/components/VolumeChart"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { formatUsd } from "@/lib/utils"
import { ORACLE_NAMES, CATEGORIES } from "@/lib/constants"

export default function AnalyticsPage() {
  const { markets, getPriceHistory } = useMarkets()

  const totalVolume = markets.reduce((s, m) => s + m.volume, 0)
  const totalLiquidity = markets.reduce((s, m) => s + m.liquidity, 0)
  const activeCount = markets.filter((m) => m.status === "active").length

  const topMarkets = [...markets].sort((a, b) => b.volume - a.volume).slice(0, 5)

  const categoryVolumes = CATEGORIES.map((cat) => {
    const catMarkets = markets.filter((m) => m.category === cat.id)
    return { name: cat.name, volume: catMarkets.reduce((s, m) => s + m.volume, 0), count: catMarkets.length }
  }).filter((c) => c.count > 0).sort((a, b) => b.volume - a.volume)

  const btcMarket = markets.find((m) => m.id === "1")
  const btcHistory = btcMarket ? getPriceHistory("1", "Yes") : []

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Analytics</h1>
        <p className="text-muted-foreground">Platform-wide statistics and trends</p>
      </div>

      <StatsCards
        totalVolume={totalVolume}
        totalLiquidity={totalLiquidity}
        activeMarkets={activeCount}
        totalUsers={3847}
      />

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <PriceChart data={btcHistory} outcome="Yes" />
          <VolumeChart data={btcHistory} />
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Top Markets by Volume</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {topMarkets.map((m, i) => (
                <div key={m.id} className="flex items-center justify-between">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-xs text-muted-foreground w-5">{i + 1}</span>
                    <span className="text-sm truncate">{m.title}</span>
                  </div>
                  <span className="text-sm font-medium ml-2 whitespace-nowrap">{formatUsd(m.volume)}</span>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Volume by Category</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {categoryVolumes.map((cat) => {
                const pct = totalVolume > 0 ? (cat.volume / totalVolume) * 100 : 0
                return (
                  <div key={cat.name} className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>{cat.name}</span>
                      <span className="text-muted-foreground">{formatUsd(cat.volume)}</span>
                    </div>
                    <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-blue-500 rounded-full" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                )
              })}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
