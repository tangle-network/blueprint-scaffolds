import { useMarkets } from "@/hooks/useMarkets"
import { MarketList } from "@/components/MarketList"
import { MarketFilters } from "@/components/MarketFilters"
import { StatsCards } from "@/components/StatsCards"

export default function HomePage() {
  const {
    filteredMarkets,
    filterStatus,
    setFilterStatus,
    filterCategory,
    setFilterCategory,
    filterType,
    setFilterType,
    searchQuery,
    setSearchQuery,
  } = useMarkets()

  const totalVolume = filteredMarkets.reduce((s, m) => s + m.volume, 0)
  const totalLiquidity = filteredMarkets.reduce((s, m) => s + m.liquidity, 0)
  const activeCount = filteredMarkets.filter((m) => m.status === "active").length

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Prediction Markets</h1>
        <p className="text-muted-foreground">Trade on real-world events on Arbitrum</p>
      </div>

      <StatsCards
        totalVolume={totalVolume}
        totalLiquidity={totalLiquidity}
        activeMarkets={activeCount}
        totalUsers={3847}
      />

      <MarketFilters
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        filterStatus={filterStatus}
        onStatusChange={setFilterStatus}
        filterCategory={filterCategory}
        onCategoryChange={setFilterCategory}
        filterType={filterType}
        onTypeChange={setFilterType}
      />

      <MarketList markets={filteredMarkets} />
    </div>
  )
}
