import { mockPositions } from "@/lib/mock-data"
import type { PortfolioPosition } from "@/lib/types"

export function usePortfolio() {
  const positions: PortfolioPosition[] = mockPositions
  const totalPnl = positions.reduce((sum, p) => sum + p.pnl, 0)
  const totalValue = positions.reduce((sum, p) => sum + p.shares * p.currentPrice, 0)
  return { positions, totalPnl, totalValue }
}
