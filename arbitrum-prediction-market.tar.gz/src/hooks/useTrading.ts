import { useState, useCallback } from "react"
import { mockOrders, mockTrades } from "@/lib/mock-data"
import { TRADING_FEE } from "@/lib/constants"
import type { Order, Trade, OrderSide } from "@/lib/types"

export function useTrading(marketId: string) {
  const [orders] = useState<Order[]>(mockOrders.filter((o) => o.marketId === marketId))
  const [trades] = useState<Trade[]>(mockTrades.filter((t) => t.marketId === marketId))
  const [isSubmitting, setIsSubmitting] = useState(false)

  const calculateFee = useCallback((amount: number) => amount * TRADING_FEE, [])

  const placeOrder = useCallback(
    async (side: OrderSide, outcome: string, price: number, amount: number) => {
      setIsSubmitting(true)
      await new Promise((r) => setTimeout(r, 1500))
      setIsSubmitting(false)
      return { success: true, orderId: `order-${Date.now()}`, side, outcome, price, amount, fee: calculateFee(amount) }
    },
    [calculateFee]
  )

  const cancelOrder = useCallback(async (_orderId: string) => {
    await new Promise((r) => setTimeout(r, 800))
    return { success: true }
  }, [])

  return {
    orders,
    trades,
    isSubmitting,
    placeOrder,
    cancelOrder,
    calculateFee,
  }
}
