import { useState, useCallback } from "react"
import { mockMarkets, generatePriceHistory } from "@/lib/mock-data"
import type { Market, MarketStatus, MarketType, PricePoint } from "@/lib/types"

export function useMarkets() {
  const [markets] = useState<Market[]>(mockMarkets)
  const [filterStatus, setFilterStatus] = useState<MarketStatus | "all">("all")
  const [filterCategory, setFilterCategory] = useState<string>("all")
  const [filterType, setFilterType] = useState<MarketType | "all">("all")
  const [searchQuery, setSearchQuery] = useState("")

  const filteredMarkets = markets.filter((m) => {
    if (filterStatus !== "all" && m.status !== filterStatus) return false
    if (filterCategory !== "all" && m.category !== filterCategory) return false
    if (filterType !== "all" && m.marketType !== filterType) return false
    if (searchQuery && !m.title.toLowerCase().includes(searchQuery.toLowerCase())) return false
    return true
  })

  const getMarket = useCallback(
    (id: string) => markets.find((m) => m.id === id),
    [markets]
  )

  const getPriceHistory = useCallback((_marketId: string, outcome: string): PricePoint[] => {
    const market = markets.find((m) => m.id === _marketId)
    if (!market) return []
    const basePrice = market.outcomePrices[market.outcomes.indexOf(outcome)] || 0.5
    return generatePriceHistory(basePrice, 0.02, 168)
  }, [markets])

  return {
    markets,
    filteredMarkets,
    getMarket,
    getPriceHistory,
    filterStatus,
    setFilterStatus,
    filterCategory,
    setFilterCategory,
    filterType,
    setFilterType,
    searchQuery,
    setSearchQuery,
  }
}
