import { useState, useCallback } from "react"
import { ARBITRUM_CHAIN_ID } from "@/lib/constants"
import { formatAddress } from "@/lib/utils"

interface WalletState {
  address: string | null
  chainId: number | null
  balance: string
  isConnected: boolean
}

export function useWallet() {
  const [wallet, setWallet] = useState<WalletState>({
    address: null,
    chainId: null,
    balance: "0.00",
    isConnected: false,
  })
  const [isConnecting, setIsConnecting] = useState(false)

  const connect = useCallback(async () => {
    setIsConnecting(true)
    await new Promise((r) => setTimeout(r, 1000))
    setWallet({
      address: "0x1234567890abcdef1234567890abcdef12345678",
      chainId: ARBITRUM_CHAIN_ID,
      balance: "4.2847",
      isConnected: true,
    })
    setIsConnecting(false)
  }, [])

  const disconnect = useCallback(() => {
    setWallet({ address: null, chainId: null, balance: "0.00", isConnected: false })
  }, [])

  return {
    ...wallet,
    isConnecting,
    connect,
    disconnect,
    displayAddress: wallet.address ? formatAddress(wallet.address) : null,
  }
}
