export type MarketType = 'binary' | 'scalar' | 'multi-outcome';
export type TradingMode = 'AMM' | 'Order Book';
export type OracleType = 'Chainlink' | 'UMA Optimistic Oracle' | 'Reality.eth';

export interface OutcomeBookLevel {
  price: number;
  size: number;
}

export interface Outcome {
  id: string;
  label: string;
  probability: number;
  price: number;
  liquidity: number;
  change24h: number;
  bidDepth: OutcomeBookLevel[];
  askDepth: OutcomeBookLevel[];
}

export interface Market {
  id: string;
  title: string;
  description: string;
  category: string;
  chain: 'Arbitrum One';
  type: MarketType;
  tradingMode: TradingMode;
  oracle: OracleType;
  collateralSymbol: string;
  endDate: string;
  volume24h: number;
  openInterest: number;
  totalLiquidity: number;
  feeBps: number;
  resolutionSource: string;
  range?: {
    min: number;
    max: number;
    current: number;
    unit: string;
  };
  outcomes: Outcome[];
}

export interface TradeTicket {
  outcomeId: string;
  side: 'buy' | 'sell';
  stake: number;
}
