export const MARKET_FACTORY_ABI = [
  {
    type: "function",
    name: "createMarket",
    inputs: [
      { name: "title", type: "string" },
      { name: "description", type: "string" },
      { name: "marketType", type: "uint8" },
      { name: "tradingMechanism", type: "uint8" },
      { name: "oracleProvider", type: "uint8" },
      { name: "outcomes", type: "string[]" },
      { name: "endDate", type: "uint256" },
      { name: "feeBps", type: "uint256" },
      { name: "initialLiquidity", type: "uint256" },
    ],
    outputs: [{ name: "marketId", type: "uint256" }],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "getMarket",
    inputs: [{ name: "marketId", type: "uint256" }],
    outputs: [
      { name: "title", type: "string" },
      { name: "description", type: "string" },
      { name: "marketType", type: "uint8" },
      { name: "status", type: "uint8" },
      { name: "outcomeCount", type: "uint256" },
    ],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "getMarketCount",
    inputs: [],
    outputs: [{ name: "count", type: "uint256" }],
    stateMutability: "view",
  },
  {
    type: "event",
    name: "MarketCreated",
    inputs: [
      { name: "marketId", type: "uint256", indexed: true },
      { name: "creator", type: "address", indexed: true },
      { name: "marketType", type: "uint8", indexed: false },
    ],
  },
] as const;

export const TRADING_ENGINE_ABI = [
  {
    type: "function",
    name: "placeOrder",
    inputs: [
      { name: "marketId", type: "uint256" },
      { name: "outcomeId", type: "uint256" },
      { name: "side", type: "uint8" },
      { name: "price", type: "uint256" },
      { name: "amount", type: "uint256" },
    ],
    outputs: [{ name: "orderId", type: "uint256" }],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "swapExactTokensForOutcomes",
    inputs: [
      { name: "marketId", type: "uint256" },
      { name: "outcomeId", type: "uint256" },
      { name: "tokenAmountIn", type: "uint256" },
      { name: "minOutcomeAmountOut", type: "uint256" },
    ],
    outputs: [{ name: "outcomeAmountOut", type: "uint256" }],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "swapExactOutcomesForTokens",
    inputs: [
      { name: "marketId", type: "uint256" },
      { name: "outcomeId", type: "uint256" },
      { name: "outcomeAmountIn", type: "uint256" },
      { name: "minTokenAmountOut", type: "uint256" },
    ],
    outputs: [{ name: "tokenAmountOut", type: "uint256" }],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "cancelOrder",
    inputs: [{ name: "orderId", type: "uint256" }],
    outputs: [],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "getOrderBook",
    inputs: [
      { name: "marketId", type: "uint256" },
      { name: "outcomeId", type: "uint256" },
    ],
    outputs: [
      { name: "bids", type: "tuple[]", components: [
        { name: "price", type: "uint256" },
        { name: "amount", type: "uint256" },
      ]},
      { name: "asks", type: "tuple[]", components: [
        { name: "price", type: "uint256" },
        { name: "amount", type: "uint256" },
      ]},
    ],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "getPoolState",
    inputs: [
      { name: "marketId", type: "uint256" },
      { name: "outcomeId", type: "uint256" },
    ],
    outputs: [
      { name: "tokenReserve", type: "uint256" },
      { name: "outcomeReserve", type: "uint256" },
    ],
    stateMutability: "view",
  },
  {
    type: "event",
    name: "OrderPlaced",
    inputs: [
      { name: "orderId", type: "uint256", indexed: true },
      { name: "marketId", type: "uint256", indexed: true },
      { name: "trader", type: "address", indexed: true },
    ],
  },
  {
    type: "event",
    name: "SwapExecuted",
    inputs: [
      { name: "marketId", type: "uint256", indexed: true },
      { name: "outcomeId", type: "uint256", indexed: true },
      { name: "trader", type: "address", indexed: true },
      { name: "tokenAmount", type: "uint256", indexed: false },
      { name: "outcomeAmount", type: "uint256", indexed: false },
    ],
  },
] as const;

export const SETTLEMENT_ABI = [
  {
    type: "function",
    name: "requestResolution",
    inputs: [{ name: "marketId", type: "uint256" }],
    outputs: [],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "resolveMarket",
    inputs: [
      { name: "marketId", type: "uint256" },
      { name: "winningOutcomeId", type: "uint256" },
    ],
    outputs: [],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "disputeResolution",
    inputs: [
      { name: "marketId", type: "uint256" },
      { name: "proposedOutcomeId", type: "uint256" },
    ],
    outputs: [],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "claimWinnings",
    inputs: [{ name: "marketId", type: "uint256" }],
    outputs: [{ name: "payout", type: "uint256" }],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "getSettlementState",
    inputs: [{ name: "marketId", type: "uint256" }],
    outputs: [
      { name: "isSettled", type: "bool" },
      { name: "winningOutcomeId", type: "uint256" },
      { name: "settlementValue", type: "int256" },
      { name: "disputeRound", type: "uint256" },
      { name: "disputePeriodEnd", type: "uint256" },
    ],
    stateMutability: "view",
  },
  {
    type: "event",
    name: "MarketResolved",
    inputs: [
      { name: "marketId", type: "uint256", indexed: true },
      { name: "winningOutcomeId", type: "uint256", indexed: false },
    ],
  },
  {
    type: "event",
    name: "DisputeRaised",
    inputs: [
      { name: "marketId", type: "uint256", indexed: true },
      { name: "disputer", type: "address", indexed: true },
      { name: "proposedOutcomeId", type: "uint256", indexed: false },
    ],
  },
  {
    type: "event",
    name: "WinningsClaimed",
    inputs: [
      { name: "marketId", type: "uint256", indexed: true },
      { name: "claimer", type: "address", indexed: true },
      { name: "payout", type: "uint256", indexed: false },
    ],
  },
] as const;
