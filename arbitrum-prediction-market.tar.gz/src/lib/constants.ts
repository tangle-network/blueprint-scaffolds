export const ARBITRUM_CHAIN_ID = 42161;

export const ARBITRUM_RPC_URL = "https://arb1.arbitrum.io/rpc";

export const CONTRACT_ADDRESSES = {
  marketFactory: "0x0000000000000000000000000000000000000001" as const,
  tradingEngine: "0x0000000000000000000000000000000000000002" as const,
  settlementManager: "0x0000000000000000000000000000000000000003" as const,
  chainlinkOracle: "0x0000000000000000000000000000000000000004" as const,
  umaOracle: "0x0000000000000000000000000000000000000005" as const,
  realityEthOracle: "0x0000000000000000000000000000000000000006" as const,
  usdcToken: "0x0000000000000000000000000000000000000007" as const,
  conditionalTokenFramework: "0x0000000000000000000000000000000000000008" as const,
} as const;

export const MARKET_CATEGORIES = [
  "politics",
  "crypto",
  "sports",
  "science",
  "entertainment",
  "economics",
  "weather",
  "technology",
] as const;

export const ORACLE_BOND_AMOUNTS = {
  chainlink: "0",
  uma: "1000000000000000000",
  reality_eth: "500000000000000000",
} as const;

export const DEFAULT_FEE_BPS = 100;
export const MIN_LIQUIDITY = "1000000000";
export const MAX_DISPUTE_ROUNDS = 3;
export const DISPUTE_PERIOD_SECONDS = 86400;

export const TOKEN_DECIMALS = 6;

export const TRADE_FEE_BPS = 100;
export const SLIPPAGE_TOLERANCE_BPS = 50;
