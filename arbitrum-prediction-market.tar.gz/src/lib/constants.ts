import type { MarketCategory, OracleType } from "./types"

export const ARBITRUM_CHAIN_ID = 42161
export const ARBITRUM_RPC = "https://arb1.arbitrum.io/rpc"

export const CONTRACTS = {
  marketFactory: "0x0000000000000000000000000000000000000001",
  tradingEngine: "0x0000000000000000000000000000000000000002",
  orderBook: "0x0000000000000000000000000000000000000003",
  amm: "0x0000000000000000000000000000000000000004",
} as const

export const ORACLE_NAMES: Record<OracleType, string> = {
  chainlink: "Chainlink",
  uma: "UMA Optimistic Oracle",
  reality_eth: "Reality.eth",
}

export const CATEGORIES: MarketCategory[] = [
  { id: "politics", name: "Politics", icon: "Landmark" },
  { id: "crypto", name: "Crypto", icon: "Bitcoin" },
  { id: "sports", name: "Sports", icon: "Trophy" },
  { id: "science", name: "Science", icon: "Microscope" },
  { id: "tech", name: "Technology", icon: "Cpu" },
  { id: "economics", name: "Economics", icon: "TrendingUp" },
  { id: "entertainment", name: "Entertainment", icon: "Clapperboard" },
  { id: "weather", name: "Weather", icon: "CloudSun" },
]

export const TRADING_FEE = 0.02
export const MIN_ORDER_SIZE = 1
export const MAX_PRICE = 1
export const MIN_PRICE = 0.01
