export type MarketType = "binary" | "scalar" | "multi_outcome"
export type OracleType = "chainlink" | "uma" | "reality_eth"
export type MarketStatus = "active" | "closed" | "settled" | "disputed"
export type TradingMode = "orderbook" | "amm"
export type OrderSide = "buy" | "sell"

export interface Market {
  id: string
  title: string
  description: string
  category: string
  marketType: MarketType
  oracleType: OracleType
  status: MarketStatus
  tradingMode: TradingMode
  outcomes: string[]
  outcomePrices: number[]
  volume: number
  liquidity: number
  endDate: number
  createdAt: number
  creator: string
  resolutionSource: string
  scalarRange?: { min: number; max: number }
}

export interface Order {
  id: string
  marketId: string
  side: OrderSide
  outcome: string
  price: number
  amount: number
  filled: number
  timestamp: number
  user: string
}

export interface Trade {
  id: string
  marketId: string
  side: OrderSide
  outcome: string
  price: number
  amount: number
  timestamp: number
  buyer: string
  seller: string
}

export interface PortfolioPosition {
  marketId: string
  marketTitle: string
  outcome: string
  shares: number
  avgPrice: number
  currentPrice: number
  pnl: number
}

export interface PricePoint {
  timestamp: number
  price: number
  volume: number
}

export interface MarketCategory {
  id: string
  name: string
  icon: string
}
