import type { Market, Order, Trade, PortfolioPosition, PricePoint } from "./types"

const now = Math.floor(Date.now() / 1000)

export const mockMarkets: Market[] = [
  {
    id: "1",
    title: "Will Bitcoin reach $150,000 by end of 2026?",
    description:
      "This market resolves to YES if the price of Bitcoin (BTC) reaches or exceeds $150,000 USD on any major exchange before December 31, 2026 23:59 UTC.",
    category: "crypto",
    marketType: "binary",
    oracleType: "chainlink",
    status: "active",
    tradingMode: "amm",
    outcomes: ["Yes", "No"],
    outcomePrices: [0.42, 0.58],
    volume: 1_250_000,
    liquidity: 450_000,
    endDate: now + 180 * 86400,
    createdAt: now - 30 * 86400,
    creator: "0x1234567890abcdef1234567890abcdef12345678",
    resolutionSource: "Chainlink BTC/USD Feed",
  },
  {
    id: "2",
    title: "2026 US Midterm Senate Control",
    description:
      "Which party will control the US Senate after the 2026 midterm elections?",
    category: "politics",
    marketType: "multi_outcome",
    oracleType: "uma",
    status: "active",
    tradingMode: "amm",
    outcomes: ["Democrats", "Republicans", "Split"],
    outcomePrices: [0.35, 0.50, 0.15],
    volume: 3_200_000,
    liquidity: 890_000,
    endDate: now + 240 * 86400,
    createdAt: now - 45 * 86400,
    creator: "0xabcdef1234567890abcdef1234567890abcdef12",
    resolutionSource: "Associated Press",
  },
  {
    id: "3",
    title: "Ethereum gas price on Jan 1, 2027 (Gwei)",
    description:
      "What will be the average Ethereum gas price in Gwei on January 1, 2027? Resolution based on Etherscan daily average.",
    category: "crypto",
    marketType: "scalar",
    oracleType: "reality_eth",
    status: "active",
    tradingMode: "orderbook",
    outcomes: ["Scalar"],
    outcomePrices: [0.5],
    volume: 780_000,
    liquidity: 210_000,
    endDate: now + 300 * 86400,
    createdAt: now - 60 * 86400,
    creator: "0x9876543210fedcba9876543210fedcba98765432",
    resolutionSource: "Etherscan",
    scalarRange: { min: 0, max: 500 },
  },
  {
    id: "4",
    title: "Will SpaceX land on Mars by 2028?",
    description:
      "Resolves YES if SpaceX successfully lands a spacecraft on the surface of Mars before January 1, 2029.",
    category: "science",
    marketType: "binary",
    oracleType: "uma",
    status: "active",
    tradingMode: "amm",
    outcomes: ["Yes", "No"],
    outcomePrices: [0.28, 0.72],
    volume: 560_000,
    liquidity: 180_000,
    endDate: now + 365 * 2 * 86400,
    createdAt: now - 90 * 86400,
    creator: "0xfedcba9876543210fedcba9876543210fedcba98",
    resolutionSource: "SpaceX official communications",
  },
  {
    id: "5",
    title: "Super Bowl LXI Winner (2027)",
    description: "Which team will win Super Bowl LXI?",
    category: "sports",
    marketType: "multi_outcome",
    oracleType: "reality_eth",
    status: "active",
    tradingMode: "amm",
    outcomes: ["49ers", "Chiefs", "Lions", "Other"],
    outcomePrices: [0.25, 0.22, 0.18, 0.35],
    volume: 4_500_000,
    liquidity: 1_200_000,
    endDate: now + 200 * 86400,
    createdAt: now - 15 * 86400,
    creator: "0x1111222233334444111122223333444411112222",
    resolutionSource: "NFL Official",
  },
  {
    id: "6",
    title: "Will the Fed cut rates in Q2 2026?",
    description:
      "Resolves YES if the Federal Reserve announces a rate cut during Q2 2026 (April-June).",
    category: "economics",
    marketType: "binary",
    oracleType: "chainlink",
    status: "active",
    tradingMode: "orderbook",
    outcomes: ["Yes", "No"],
    outcomePrices: [0.61, 0.39],
    volume: 2_100_000,
    liquidity: 670_000,
    endDate: now + 90 * 86400,
    createdAt: now - 20 * 86400,
    creator: "0xaaaabbbbccccddddaaaabbbbccccddddaaaabbbb",
    resolutionSource: "Federal Reserve",
  },
  {
    id: "7",
    title: "Global avg temperature anomaly 2026 (°C)",
    description:
      "What will be the global average temperature anomaly for 2026 relative to 1951-1980 baseline? Scalar market in °C.",
    category: "weather",
    marketType: "scalar",
    oracleType: "chainlink",
    status: "active",
    tradingMode: "amm",
    outcomes: ["Scalar"],
    outcomePrices: [0.55],
    volume: 320_000,
    liquidity: 95_000,
    endDate: now + 365 * 86400,
    createdAt: now - 120 * 86400,
    creator: "0xddddeeee00001111ddddeeee00001111ddddeeee",
    resolutionSource: "NASA GISS",
    scalarRange: { min: 0.5, max: 2.0 },
  },
  {
    id: "8",
    title: "Will GPT-5 be released before July 2026?",
    description:
      "Resolves YES if OpenAI releases GPT-5 (or a successor model with that branding) before July 1, 2026.",
    category: "tech",
    marketType: "binary",
    oracleType: "uma",
    status: "settled",
    tradingMode: "amm",
    outcomes: ["Yes", "No"],
    outcomePrices: [1.0, 0.0],
    volume: 890_000,
    liquidity: 340_000,
    endDate: now - 5 * 86400,
    createdAt: now - 180 * 86400,
    creator: "0x4444555566667777444455556666777744445555",
    resolutionSource: "OpenAI official announcement",
  },
]

export const mockOrders: Order[] = [
  { id: "o1", marketId: "1", side: "buy", outcome: "Yes", price: 0.40, amount: 500, filled: 200, timestamp: now - 3600, user: "0x1234567890abcdef1234567890abcdef12345678" },
  { id: "o2", marketId: "1", side: "sell", outcome: "Yes", price: 0.45, amount: 300, filled: 0, timestamp: now - 1800, user: "0xabcdef1234567890abcdef1234567890abcdef12" },
  { id: "o3", marketId: "6", side: "buy", outcome: "Yes", price: 0.59, amount: 1000, filled: 750, timestamp: now - 7200, user: "0x9876543210fedcba9876543210fedcba98765432" },
  { id: "o4", marketId: "6", side: "buy", outcome: "No", price: 0.38, amount: 800, filled: 0, timestamp: now - 600, user: "0xfedcba9876543210fedcba9876543210fedcba98" },
  { id: "o5", marketId: "3", side: "buy", outcome: "Scalar", price: 0.48, amount: 250, filled: 50, timestamp: now - 5400, user: "0x1111222233334444111122223333444411112222" },
]

export const mockTrades: Trade[] = [
  { id: "t1", marketId: "1", side: "buy", outcome: "Yes", price: 0.41, amount: 100, timestamp: now - 300, buyer: "0x1234...", seller: "0xabcd..." },
  { id: "t2", marketId: "1", side: "sell", outcome: "Yes", price: 0.43, amount: 250, timestamp: now - 600, buyer: "0x5678...", seller: "0xef01..." },
  { id: "t3", marketId: "2", side: "buy", outcome: "Democrats", price: 0.36, amount: 500, timestamp: now - 900, buyer: "0x9abc...", seller: "0x2345..." },
  { id: "t4", marketId: "6", side: "buy", outcome: "Yes", price: 0.60, amount: 750, timestamp: now - 1200, buyer: "0xdef0...", seller: "0x6789..." },
]

export const mockPositions: PortfolioPosition[] = [
  { marketId: "1", marketTitle: "Will Bitcoin reach $150,000 by end of 2026?", outcome: "Yes", shares: 500, avgPrice: 0.38, currentPrice: 0.42, pnl: 20.0 },
  { marketId: "2", marketTitle: "2026 US Midterm Senate Control", outcome: "Democrats", shares: 300, avgPrice: 0.32, currentPrice: 0.35, pnl: 9.0 },
  { marketId: "6", marketTitle: "Will the Fed cut rates in Q2 2026?", outcome: "Yes", shares: 1000, avgPrice: 0.58, currentPrice: 0.61, pnl: 30.0 },
  { marketId: "4", marketTitle: "Will SpaceX land on Mars by 2028?", outcome: "Yes", shares: 200, avgPrice: 0.30, currentPrice: 0.28, pnl: -4.0 },
]

export function generatePriceHistory(basePrice: number, volatility: number, points: number): PricePoint[] {
  const result: PricePoint[] = []
  let price = basePrice
  for (let i = 0; i < points; i++) {
    const change = (Math.random() - 0.5) * 2 * volatility
    price = Math.max(0.01, Math.min(0.99, price + change))
    result.push({
      timestamp: now - (points - i) * 3600,
      price: Math.round(price * 1000) / 1000,
      volume: Math.floor(Math.random() * 50000) + 1000,
    })
  }
  return result
}
