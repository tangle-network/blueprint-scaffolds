import { useMemo, useState } from 'react';
import { Header } from './components/Header';
import { MarketList } from './components/MarketList';
import { MarketOverview } from './components/MarketOverview';
import { TradePanel } from './components/TradePanel';
import { OrderBook } from './components/OrderBook';
import { AnalyticsPanel } from './components/AnalyticsPanel';
import { ArchitecturePanel } from './components/ArchitecturePanel';
import { markets } from './data/markets';

export default function App() {
  const [selectedMarketId, setSelectedMarketId] = useState(markets[0].id);
  const market = useMemo(
    () => markets.find((item) => item.id === selectedMarketId) ?? markets[0],
    [selectedMarketId],
  );

  return (
    <div className="app-shell">
      <Header />
      <main className="layout">
        <div className="layout__primary">
          <MarketList
            markets={markets}
            selectedMarketId={selectedMarketId}
            onSelect={setSelectedMarketId}
          />
          <MarketOverview market={market} />
          <AnalyticsPanel market={market} />
        </div>
        <aside className="layout__secondary">
          <TradePanel market={market} />
          <OrderBook market={market} />
          <ArchitecturePanel />
        </aside>
      </main>
    </div>
  );
}
