export type MarketType = "binary" | "scalar" | "multi_outcome";

export type MarketStatus = "active" | "paused" | "closed" | "settled" | "disputed";

export type TradingMechanism = "amm" | "orderbook";

export type OracleProvider = "chainlink" | "uma" | "reality_eth";

export type OrderSide = "buy" | "sell";

export type OrderType = "limit" | "market";

export interface MarketOutcome {
  id: string;
  label: string;
  currentPrice: number;
  volume: string;
}

export interface ScalarRange {
  min: number;
  max: number;
  unit: string;
}

export interface Market {
  id: string;
  title: string;
  description: string;
  category: MarketCategory;
  marketType: MarketType;
  tradingMechanism: TradingMechanism;
  oracle: OracleConfig;
  outcomes: MarketOutcome[];
  scalarRange?: ScalarRange;
  status: MarketStatus;
  resolutionSource: string;
  endDate: string;
  createdAt: string;
  totalVolume: string;
  totalLiquidity: string;
  liquidityProvider?: string;
  creator: string;
  feeBps: number;
  imageUri?: string;
  winningOutcomeId?: string;
  settlementValue?: number;
  disputePeriodEnd?: string;
}

export type MarketCategory =
  | "politics"
  | "crypto"
  | "sports"
  | "science"
  | "entertainment"
  | "economics"
  | "weather"
  | "technology";

export interface OracleConfig {
  provider: OracleProvider;
  oracleAddress: string;
  resolutionTimestamp: number;
  disputePeriodSeconds: number;
  bondAmount: string;
}

export interface Order {
  id: string;
  marketId: string;
  outcomeId: string;
  side: OrderSide;
  orderType: OrderType;
  price: number;
  amount: string;
  filledAmount: string;
  creator: string;
  createdAt: string;
  expiresAt?: string;
}

export interface Trade {
  id: string;
  marketId: string;
  outcomeId: string;
  price: number;
  amount: string;
  buyer: string;
  seller: string;
  timestamp: string;
  txHash: string;
}

export interface AMMPool {
  marketId: string;
  outcomeId: string;
  tokenReserve: string;
  outcomeReserve: string;
  invariant: string;
  feeBps: number;
}

export interface PortfolioPosition {
  marketId: string;
  marketTitle: string;
  outcomeId: string;
  outcomeLabel: string;
  shares: string;
  avgPrice: number;
  currentPrice: number;
  pnl: number;
  pnlPercent: number;
}

export interface MarketFilters {
  category?: MarketCategory;
  marketType?: MarketType;
  tradingMechanism?: TradingMechanism;
  status?: MarketStatus;
  search?: string;
}

export interface CreateMarketParams {
  title: string;
  description: string;
  category: MarketCategory;
  marketType: MarketType;
  tradingMechanism: TradingMechanism;
  oracleProvider: OracleProvider;
  outcomes: string[];
  scalarRange?: ScalarRange;
  endDate: string;
  resolutionSource: string;
  initialLiquidity: string;
  feeBps: number;
}

export interface PriceHistoryPoint {
  timestamp: string;
  price: number;
  volume: string;
}
