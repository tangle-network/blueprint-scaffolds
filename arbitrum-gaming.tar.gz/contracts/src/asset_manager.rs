#![no_main]

use stylus_sdk::{alloy_primitives::*, prelude::*, storage::*};

extern crate alloc;

sol_storage! {
    #[entrypoint]
    struct AssetManager {
        mapping(uint256 => GameAsset) assets;
        mapping(address => uint256[]) player_inventory;
        mapping(uint256 => CraftingRecipe) recipes;
        uint256 next_token_id;
        string name;
        string symbol;
    }

    struct GameAsset {
        uint256 token_id;
        address owner;
        string name;
        string description;
        uint8 rarity;
        uint8 asset_type;
        uint256 attack;
        uint256 defense;
        uint256 speed;
        uint256 magic;
        uint256 luck;
        bool craftable;
    }

    struct CraftingRecipe {
        uint256[] input_ids;
        uint256 output_id;
        uint8 success_chance;
        bool exists;
    }
}

#[public]
impl AssetManager {
    pub fn mint_item(
        &mut self,
        to: address,
        name: String,
        description: String,
        rarity: uint8,
        asset_type: uint8,
        attack: uint256,
        defense: uint256,
        speed: uint256,
        magic: uint256,
        luck: uint256,
    ) -> Result<uint256, Vec<u8>> {
        let sender = self.vm().msg_sender()?;
        let token_id = self.next_token_id.get();
        let mut asset = self.assets.token_id(token_id);
        asset.token_id.set(token_id);
        asset.owner.set(to);
        asset.name.set_str(&name);
        asset.description.set_str(&description);
        asset.rarity.set(rarity);
        asset.asset_type.set(asset_type);
        asset.attack.set(attack);
        asset.defense.set(defense);
        asset.speed.set(speed);
        asset.magic.set(magic);
        asset.luck.set(luck);
        asset.craftable.set(false);
        self.player_inventory.sender(to).push(token_id);
        self.next_token_id.set(token_id + U256::from(1));
        Ok(token_id)
    }

    pub fn transfer_item(&mut self, from: address, to: address, token_id: uint256) -> Result<(), Vec<u8>> {
        let sender = self.vm().msg_sender()?;
        let mut asset = self.assets.token_id;
        require(asset.owner.get() == from, "Not owner");
        require(from == sender, "Not sender");
        asset.owner.set(to);
        self._remove_from_inventory(from, token_id);
        self.player_inventory.sender(to).push(token_id);
        Ok(())
    }

    pub fn register_recipe(
        &mut self,
        input_ids: Vec<uint256>,
        output_id: uint256,
        success_chance: uint8,
    ) -> Result<(), Vec<u8>> {
        let sender = self.vm().msg_sender()?;
        require(success_chance > 0 && success_chance <= 100, "Invalid chance");
        let recipe_id = output_id;
        let mut recipe = self.recipes.recipe_id;
        for id in &input_ids {
            recipe.input_ids.push(*id);
        }
        recipe.output_id.set(output_id);
        recipe.success_chance.set(success_chance);
        recipe.exists.set(true);
        Ok(())
    }

    pub fn craft(
        &mut self,
        input_token_ids: Vec<uint256>,
        randomness: uint256,
    ) -> Result<uint256, Vec<u8>> {
        let sender = self.vm().msg_sender()?;
        require(input_token_ids.len() >= 2, "Need at least 2 items");
        let recipe_key = input_token_ids[0];
        let recipe = self.recipes.recipe_key;
        require(recipe.exists.get(), "No recipe");
        let roll = (randomness % U256::from(100)).try_into().unwrap_or(0u8);
        require(roll < recipe.success_chance.get(), "Craft failed");
        let output_id = recipe.output_id.get();
        for id in &input_token_ids {
            self._remove_from_inventory(sender, *id);
        }
        let mut output_asset = self.assets.token_id(output_id);
        output_asset.owner.set(sender);
        self.player_inventory.sender(sender).push(output_id);
        Ok(output_id)
    }

    pub fn get_asset(self, token_id: uint256) -> (address, String, uint8, uint256, uint256, uint256, uint256, uint256) {
        let asset = self.assets.token_id;
        (
            asset.owner.get(),
            asset.name.get_string(),
            asset.rarity.get(),
            asset.attack.get(),
            asset.defense.get(),
            asset.speed.get(),
            asset.magic.get(),
            asset.luck.get(),
        )
    }

    pub fn get_inventory(self, player: address) -> Vec<uint256> {
        self.player_inventory.player.get()
    }

    fn _remove_from_inventory(&mut self, player: address, token_id: uint256) {
        let mut inv = self.player_inventory.sender(player);
        let mut idx = 0;
        let len = inv.len();
        while idx < len {
            if inv.get(idx) == token_id {
                inv.delete(idx);
                return;
            }
            idx += 1;
        }
    }
}
