#![no_main]

use stylus_sdk::{alloy_primitives::*, prelude::*, storage::*};

extern crate alloc;

sol_storage! {
    #[entrypoint]
    struct GameEngine {
        mapping(address => Player) players;
        mapping(uint256 => GameSession) sessions;
        uint256 session_count;
        address admin;
        bool paused;
    }

    struct Player {
        address addr;
        String username;
        uint256 elo;
        uint256 wins;
        uint256 losses;
        uint256 last_active;
        bool registered;
    }

    struct GameSession {
        uint256 id;
        address player1;
        address player2;
        uint8 status;
        uint256 board_seed;
        address current_turn;
        address winner;
        uint256 created_at;
        uint256 move_count;
    }
}

#[public]
impl GameEngine {
    pub fn register_player(&mut self, username: String) -> Result<(), Vec<u8>> {
        let sender = self.vm().msg_sender()?;
        require(!self.paused.get(), "Game paused");
        let mut player = self.players.sender(sender);
        require(!player.registered.get(), "Already registered");
        player.addr.set(sender);
        player.username.set_str(&username);
        player.elo.set(U256::from(1000));
        player.wins.set(U256::from(0));
        player.losses.set(U256::from(0));
        player.registered.set(true);
        Ok(())
    }

    pub fn create_session(&mut self) -> Result<uint256, Vec<u8>> {
        let sender = self.vm().msg_sender()?;
        let player = self.players.sender(sender);
        require(player.registered.get(), "Not registered");
        let session_id = self.session_count.get();
        let mut session = self.sessions.session_id(session_id);
        session.id.set(session_id);
        session.player1.set(sender);
        session.status.set(U256::from(0));
        session.created_at.set(U256::from(self.vm().block_timestamp()));
        self.session_count.set(session_id + U256::from(1));
        Ok(session_id)
    }

    pub fn join_session(&mut self, session_id: uint256) -> Result<(), Vec<u8>> {
        let sender = self.vm().msg_sender()?;
        let player = self.players.sender(sender);
        require(player.registered.get(), "Not registered");
        let mut session = self.sessions.session_id(session_id);
        require(session.status.get() == U256::from(0), "Session not open");
        require(session.player1.get() != sender, "Cannot join own session");
        session.player2.set(sender);
        session.status.set(U256::from(1));
        session.current_turn.set(session.player1.get());
        Ok(())
    }

    pub fn make_move(
        &mut self,
        session_id: uint256,
        row: uint8,
        col: uint8,
        element: uint8,
    ) -> Result<(), Vec<u8>> {
        let sender = self.vm().msg_sender()?;
        let mut session = self.sessions.session_id(session_id);
        require(session.status.get() == U256::from(1), "Session not active");
        require(session.current_turn.get() == sender, "Not your turn");
        require(row < 8 && col < 8, "Out of bounds");
        require(element < 4, "Invalid element");
        session.move_count.set(session.move_count.get() + U256::from(1));
        let next = if sender == session.player1.get() {
            session.player2.get()
        } else {
            session.player1.get()
        };
        session.current_turn.set(next);
        Ok(())
    }

    pub fn end_session(&mut self, session_id: uint256, winner: address) -> Result<(), Vec<u8>> {
        let sender = self.vm().msg_sender()?;
        let mut session = self.sessions.session_id(session_id);
        require(session.status.get() == U256::from(1), "Session not active");
        require(
            sender == session.player1.get() || sender == session.player2.get(),
            "Not a player",
        );
        session.winner.set(winner);
        session.status.set(U256::from(2));
        let mut winner_player = self.players.sender(winner);
        winner_player.wins.set(winner_player.wins.get() + U256::from(1));
        let loser = if winner == session.player1.get() {
            session.player2.get()
        } else {
            session.player1.get()
        };
        let mut loser_player = self.players.sender(loser);
        loser_player.losses.set(loser_player.losses.get() + U256::from(1));
        Ok(())
    }

    pub fn get_player(self, addr: address) -> (String, uint256, uint256, uint256, bool) {
        let player = self.players.addr;
        (
            player.username.get_string(),
            player.elo.get(),
            player.wins.get(),
            player.losses.get(),
            player.registered.get(),
        )
    }

    pub fn get_session(self, session_id: uint256) -> (address, address, uint8, address, uint256) {
        let session = self.sessions.session_id;
        (
            session.player1.get(),
            session.player2.get(),
            session.status.get().try_into().unwrap_or(0),
            session.winner.get(),
            session.move_count.get(),
        )
    }
}
