#![no_main]

use stylus_sdk::{alloy_primitives::*, prelude::*, storage::*};

extern crate alloc;

sol_storage! {
    #[entrypoint]
    struct RandomnessOracle {
        mapping(uint256 => RandomRequest) requests;
        uint256 request_count;
        address admin;
        uint256 commitment;
    }

    struct RandomRequest {
        uint256 id;
        address requester;
        bytes32 seed;
        uint256 result;
        bool fulfilled;
        uint256 block_number;
    }
}

#[public]
impl RandomnessOracle {
    pub fn request_randomness(&mut self, seed: bytes32) -> Result<uint256, Vec<u8>> {
        let sender = self.vm().msg_sender()?;
        let request_id = self.request_count.get();
        let mut req = self.requests.request_id;
        req.id.set(request_id);
        req.requester.set(sender);
        req.seed.set(seed);
        req.fulfilled.set(false);
        req.block_number.set(U256::from(self.vm().block_number()));
        self.request_count.set(request_id + U256::from(1));
        Ok(request_id)
    }

    pub fn fulfill_randomness(&mut self, request_id: uint256, result: uint256) -> Result<(), Vec<u8>> {
        let sender = self.vm().msg_sender()?;
        require(sender == self.admin.get(), "Not admin");
        let mut req = self.requests.request_id;
        require(!req.fulfilled.get(), "Already fulfilled");
        req.result.set(result);
        req.fulfilled.set(true);
        Ok(())
    }

    pub fn get_randomness(self, request_id: uint256) -> (uint256, bool, address) {
        let req = self.requests.request_id;
        (req.result.get(), req.fulfilled.get(), req.requester.get())
    }

    pub fn verify_randomness(self, request_id: uint256, claimed_result: uint256) -> bool {
        let req = self.requests.request_id;
        req.fulfilled.get() && req.result.get() == claimed_result
    }
}
