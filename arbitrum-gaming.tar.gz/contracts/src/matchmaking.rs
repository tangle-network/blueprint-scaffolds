#![no_main]

use stylus_sdk::{alloy_primitives::*, prelude::*, storage::*};

extern crate alloc;

sol_storage! {
    #[entrypoint]
    struct Matchmaking {
        mapping(address => QueueEntry) queue;
        address[] queued_players;
        uint256 max_elo_diff;
        uint256 queue_timeout;
        address game_engine;
    }

    struct QueueEntry {
        address player;
        uint256 elo;
        uint256 enqueued_at;
        bool in_queue;
        string preferred_mode;
    }
}

#[public]
impl Matchmaking {
    pub fn enqueue(&mut self, preferred_mode: String) -> Result<(), Vec<u8>> {
        let sender = self.vm().msg_sender()?;
        let mut entry = self.queue.sender(sender);
        require(!entry.in_queue.get(), "Already in queue");
        let engine = stylus_sdk::call::Method::new(self.game_engine.get());
        let (_, elo, _, _, registered): (String, uint256, uint256, uint256, bool) =
            engine.call(self.vm(), (&sender,))?;
        require(registered, "Not registered");
        entry.player.set(sender);
        entry.elo.set(elo);
        entry.enqueued_at.set(U256::from(self.vm().block_timestamp()));
        entry.in_queue.set(true);
        entry.preferred_mode.set_str(&preferred_mode);
        self.queued_players.push(sender);
        Ok(())
    }

    pub fn dequeue(&mut self) -> Result<(), Vec<u8>> {
        let sender = self.vm().msg_sender()?;
        let mut entry = self.queue.sender(sender);
        require(entry.in_queue.get(), "Not in queue");
        entry.in_queue.set(false);
        self._remove_from_queue(sender);
        Ok(())
    }

    pub fn find_match(&mut self) -> Result<(address, address), Vec<u8>> {
        let now = U256::from(self.vm().block_timestamp());
        let max_diff = self.max_elo_diff.get();
        let len = self.queued_players.len();
        for i in 0..len {
            let p1 = self.queued_players.get(i);
            let entry1 = self.queue.p1;
            if !entry1.in_queue.get() {
                continue;
            }
            for j in (i + 1)..len {
                let p2 = self.queued_players.get(j);
                let entry2 = self.queue.p2;
                if !entry2.in_queue.get() {
                    continue;
                }
                let elo_diff = if entry1.elo.get() > entry2.elo.get() {
                    entry1.elo.get() - entry2.elo.get()
                } else {
                    entry2.elo.get() - entry1.elo.get()
                };
                let wait1 = now - entry1.enqueued_at.get();
                let wait2 = now - entry2.enqueued_at.get();
                let effective_max = max_diff + (wait1 + wait2) / U256::from(10);
                if elo_diff <= effective_max {
                    self.queue.p1.in_queue.set(false);
                    self.queue.p2.in_queue.set(false);
                    self._remove_from_queue(p1);
                    self._remove_from_queue(p2);
                    return Ok((p1, p2));
                }
            }
        }
        Err("No match found".into())
    }

    pub fn get_queue_size(self) -> uint256 {
        let mut count = U256::from(0);
        let len = self.queued_players.len();
        for i in 0..len {
            let p = self.queued_players.get(i);
            if self.queue.p.in_queue.get() {
                count = count + U256::from(1);
            }
        }
        count
    }

    fn _remove_from_queue(&mut self, player: address) {
        let len = self.queued_players.len();
        for i in 0..len {
            if self.queued_players.get(i) == player {
                self.queued_players.delete(i);
                return;
            }
        }
    }
}
