use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use thiserror::Error;

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
pub enum ItemClass {
    Weapon,
    Catalyst,
    Relic,
    Material,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
pub enum ItemRarity {
    Common,
    Rare,
    Epic,
    Mythic,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ItemDefinition {
    pub template_id: u64,
    pub name: String,
    pub class: ItemClass,
    pub base_power: u32,
    pub rarity: ItemRarity,
    pub metadata_uri: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct InventoryAsset {
    pub token_id: u64,
    pub owner: String,
    pub template_id: u64,
    pub level: u8,
    pub power: u32,
    pub forged_with_entropy: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct CraftRecipe {
    pub recipe_id: u64,
    pub name: String,
    pub inputs: Vec<u64>,
    pub output_template_id: u64,
    pub minimum_entropy: u64,
}

#[derive(Debug)]
pub struct AssetManagement {
    definitions: BTreeMap<u64, ItemDefinition>,
    inventory: BTreeMap<u64, InventoryAsset>,
    recipes: BTreeMap<u64, CraftRecipe>,
    next_token_id: u64,
}

#[derive(Debug, Error, PartialEq, Eq)]
pub enum AssetError {
    #[error("item template does not exist")]
    MissingDefinition,
    #[error("craft recipe does not exist")]
    MissingRecipe,
    #[error("wallet does not own all input tokens")]
    InvalidOwnership,
    #[error("recipe inputs do not match provided assets")]
    InvalidRecipeInputs,
    #[error("not enough entropy for forged output")]
    EntropyTooLow,
}

impl Default for AssetManagement {
    fn default() -> Self {
        let mut management = Self {
            definitions: BTreeMap::new(),
            inventory: BTreeMap::new(),
            recipes: BTreeMap::new(),
            next_token_id: 1,
        };
        management.bootstrap_catalog();
        management
    }
}

impl AssetManagement {
    pub fn bootstrap_catalog(&mut self) {
        let definitions = [
            ItemDefinition {
                template_id: 1101,
                name: "Photon Saber".into(),
                class: ItemClass::Weapon,
                base_power: 34,
                rarity: ItemRarity::Rare,
                metadata_uri: "ipfs://photon-saber".into(),
            },
            ItemDefinition {
                template_id: 1201,
                name: "Void Sigil".into(),
                class: ItemClass::Catalyst,
                base_power: 22,
                rarity: ItemRarity::Rare,
                metadata_uri: "ipfs://void-sigil".into(),
            },
            ItemDefinition {
                template_id: 1301,
                name: "Aegis Frame".into(),
                class: ItemClass::Relic,
                base_power: 40,
                rarity: ItemRarity::Epic,
                metadata_uri: "ipfs://aegis-frame".into(),
            },
            ItemDefinition {
                template_id: 2101,
                name: "Runic Core".into(),
                class: ItemClass::Material,
                base_power: 8,
                rarity: ItemRarity::Common,
                metadata_uri: "ipfs://runic-core".into(),
            },
            ItemDefinition {
                template_id: 2201,
                name: "Prism Dust".into(),
                class: ItemClass::Material,
                base_power: 12,
                rarity: ItemRarity::Common,
                metadata_uri: "ipfs://prism-dust".into(),
            },
            ItemDefinition {
                template_id: 3101,
                name: "Nova Lance".into(),
                class: ItemClass::Weapon,
                base_power: 58,
                rarity: ItemRarity::Mythic,
                metadata_uri: "ipfs://nova-lance".into(),
            },
        ];

        for definition in definitions {
            self.definitions.insert(definition.template_id, definition);
        }

        let recipes = [
            CraftRecipe {
                recipe_id: 1,
                name: "Forge Nova Lance".into(),
                inputs: vec![1101, 1201, 2201],
                output_template_id: 3101,
                minimum_entropy: 120,
            },
            CraftRecipe {
                recipe_id: 2,
                name: "Reinforce Aegis Frame".into(),
                inputs: vec![1301, 2101, 2201],
                output_template_id: 1301,
                minimum_entropy: 80,
            },
        ];

        for recipe in recipes {
            self.recipes.insert(recipe.recipe_id, recipe);
        }
    }

    pub fn mint(
        &mut self,
        owner: impl Into<String>,
        template_id: u64,
        entropy: u64,
    ) -> Result<InventoryAsset, AssetError> {
        let definition = self
            .definitions
            .get(&template_id)
            .ok_or(AssetError::MissingDefinition)?;
        let owner = owner.into();
        let token_id = self.next_token_id;
        self.next_token_id += 1;

        let asset = InventoryAsset {
            token_id,
            owner,
            template_id,
            level: 1 + (entropy % 3) as u8,
            power: definition.base_power + (entropy % 17) as u32,
            forged_with_entropy: entropy,
        };

        self.inventory.insert(token_id, asset.clone());
        Ok(asset)
    }

    pub fn combine(
        &mut self,
        owner: &str,
        token_ids: &[u64],
        recipe_id: u64,
        entropy: u64,
    ) -> Result<InventoryAsset, AssetError> {
        let recipe = self
            .recipes
            .get(&recipe_id)
            .cloned()
            .ok_or(AssetError::MissingRecipe)?;

        if entropy < recipe.minimum_entropy {
            return Err(AssetError::EntropyTooLow);
        }

        let mut provided_templates = Vec::with_capacity(token_ids.len());
        let mut max_level = 1_u8;

        for token_id in token_ids {
            let asset = self
                .inventory
                .get(token_id)
                .ok_or(AssetError::InvalidOwnership)?;
            if asset.owner != owner {
                return Err(AssetError::InvalidOwnership);
            }
            provided_templates.push(asset.template_id);
            max_level = max_level.max(asset.level);
        }

        provided_templates.sort_unstable();
        let mut required_templates = recipe.inputs.clone();
        required_templates.sort_unstable();

        if provided_templates != required_templates {
            return Err(AssetError::InvalidRecipeInputs);
        }

        for token_id in token_ids {
            self.inventory.remove(token_id);
        }

        let mut forged = self.mint(owner.to_owned(), recipe.output_template_id, entropy + 77)?;
        forged.level = max_level.saturating_add(1);
        forged.power += (entropy % 23) as u32;
        self.inventory.insert(forged.token_id, forged.clone());

        Ok(forged)
    }

    pub fn airdrop_from_match(
        &mut self,
        owner: &str,
        placement: u8,
        entropy: u64,
    ) -> Result<InventoryAsset, AssetError> {
        let template_id = match placement {
            1 => 1301,
            2..=3 => 1201,
            _ => {
                if entropy.is_multiple_of(2) {
                    2101
                } else {
                    2201
                }
            }
        };
        self.mint(owner.to_owned(), template_id, entropy)
    }

    pub fn owner_inventory(&self, owner: &str) -> Vec<InventoryAsset> {
        let mut assets: Vec<_> = self
            .inventory
            .values()
            .filter(|asset| asset.owner == owner)
            .cloned()
            .collect();
        assets.sort_by(|left, right| right.power.cmp(&left.power));
        assets
    }

    pub fn recipe(&self, recipe_id: u64) -> Option<&CraftRecipe> {
        self.recipes.get(&recipe_id)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn crafting_consumes_inputs() {
        let mut assets = AssetManagement::default();
        let a = assets.mint("alice", 1101, 44).expect("item a");
        let b = assets.mint("alice", 1201, 45).expect("item b");
        let c = assets.mint("alice", 2201, 46).expect("item c");

        let forged = assets
            .combine("alice", &[a.token_id, b.token_id, c.token_id], 1, 200)
            .expect("forged");

        assert_eq!(forged.template_id, 3101);
        assert_eq!(assets.owner_inventory("alice").len(), 1);
    }
}
