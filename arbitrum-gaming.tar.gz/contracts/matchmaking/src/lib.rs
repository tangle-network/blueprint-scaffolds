use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, VecDeque};
use thiserror::Error;

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, PartialOrd, Ord)]
pub enum QueueMode {
    Duel,
    Squad,
    Raid,
}

impl QueueMode {
    pub fn required_players(self) -> usize {
        match self {
            Self::Duel => 2,
            Self::Squad => 4,
            Self::Raid => 6,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct SessionKey {
    pub signer: String,
    pub scope: String,
    pub expires_at_block: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct QueueTicket {
    pub ticket_id: u64,
    pub wallet: String,
    pub rating: u16,
    pub mode: QueueMode,
    pub session_key: Option<SessionKey>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum MatchStatus {
    Pending,
    InProgress,
    Completed,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct MatchRecord {
    pub match_id: u64,
    pub mode: QueueMode,
    pub players: Vec<String>,
    pub average_rating: u16,
    pub session_key_signers: Vec<String>,
    pub status: MatchStatus,
    pub placements: Vec<(String, u16)>,
    pub server_nonce: u64,
}

#[derive(Debug)]
pub struct Matchmaking {
    queues: BTreeMap<QueueMode, VecDeque<QueueTicket>>,
    matches: BTreeMap<u64, MatchRecord>,
    next_ticket_id: u64,
    next_match_id: u64,
}

#[derive(Debug, Error, PartialEq, Eq)]
pub enum MatchmakingError {
    #[error("match not found")]
    MatchNotFound,
    #[error("not enough queued players")]
    NotEnoughPlayers,
}

impl Default for Matchmaking {
    fn default() -> Self {
        let queues = BTreeMap::from([
            (QueueMode::Duel, VecDeque::new()),
            (QueueMode::Squad, VecDeque::new()),
            (QueueMode::Raid, VecDeque::new()),
        ]);

        Self {
            queues,
            matches: BTreeMap::new(),
            next_ticket_id: 1,
            next_match_id: 1,
        }
    }
}

impl Matchmaking {
    pub fn enqueue(
        &mut self,
        wallet: impl Into<String>,
        mode: QueueMode,
        rating: u16,
        session_key: Option<SessionKey>,
    ) -> u64 {
        let ticket_id = self.next_ticket_id;
        self.next_ticket_id += 1;

        let ticket = QueueTicket {
            ticket_id,
            wallet: wallet.into(),
            rating,
            mode,
            session_key,
        };

        self.queues.entry(mode).or_default().push_back(ticket);
        ticket_id
    }

    pub fn try_match(
        &mut self,
        mode: QueueMode,
        server_nonce: u64,
    ) -> Result<MatchRecord, MatchmakingError> {
        let required = mode.required_players();
        let queue = self.queues.entry(mode).or_default();

        if queue.len() < required {
            return Err(MatchmakingError::NotEnoughPlayers);
        }

        let mut tickets = Vec::with_capacity(required);
        for _ in 0..required {
            if let Some(ticket) = queue.pop_front() {
                tickets.push(ticket);
            }
        }

        let average_rating = tickets
            .iter()
            .map(|ticket| u32::from(ticket.rating))
            .sum::<u32>()
            / tickets.len() as u32;
        let match_id = self.next_match_id;
        self.next_match_id += 1;

        let record = MatchRecord {
            match_id,
            mode,
            players: tickets.iter().map(|ticket| ticket.wallet.clone()).collect(),
            average_rating: average_rating as u16,
            session_key_signers: tickets
                .iter()
                .filter_map(|ticket| ticket.session_key.as_ref().map(|key| key.signer.clone()))
                .collect(),
            status: MatchStatus::InProgress,
            placements: Vec::new(),
            server_nonce,
        };

        self.matches.insert(match_id, record.clone());
        Ok(record)
    }

    pub fn report_results(
        &mut self,
        match_id: u64,
        placements: Vec<(String, u16)>,
    ) -> Result<MatchRecord, MatchmakingError> {
        let record = self
            .matches
            .get_mut(&match_id)
            .ok_or(MatchmakingError::MatchNotFound)?;

        record.placements = placements;
        record.status = MatchStatus::Completed;

        Ok(record.clone())
    }

    pub fn active_queue(&self, mode: QueueMode) -> Vec<QueueTicket> {
        self.queues
            .get(&mode)
            .map(|queue| queue.iter().cloned().collect())
            .unwrap_or_default()
    }

    pub fn recent_matches(&self) -> Vec<MatchRecord> {
        let mut matches: Vec<_> = self.matches.values().cloned().collect();
        matches.sort_by(|left, right| right.match_id.cmp(&left.match_id));
        matches
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn tickets_promote_into_match() {
        let mut service = Matchmaking::default();
        service.enqueue("alice", QueueMode::Duel, 1400, None);
        service.enqueue("bob", QueueMode::Duel, 1415, None);

        let record = service.try_match(QueueMode::Duel, 9).expect("match record");
        assert_eq!(record.players.len(), 2);
        assert_eq!(service.active_queue(QueueMode::Duel).len(), 0);
    }
}
