use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::collections::BTreeMap;
use thiserror::Error;

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
pub enum GameMode {
    Duel,
    Squad,
    Raid,
}

impl GameMode {
    pub fn min_players(self) -> usize {
        match self {
            Self::Duel => 2,
            Self::Squad => 4,
            Self::Raid => 6,
        }
    }
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
pub enum SessionStatus {
    WaitingForPlayers,
    AwaitingRandomness,
    Active,
    Finished,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct PlayerState {
    pub wallet: String,
    pub health: u32,
    pub mana: u32,
    pub stamina: u32,
    pub loadout: Vec<u64>,
    pub rating: i32,
    pub score: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct GameSession {
    pub session_id: u64,
    pub mode: GameMode,
    pub turn: u32,
    pub status: SessionStatus,
    pub players: Vec<PlayerState>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct RandomnessRequest {
    pub request_id: u64,
    pub session_id: u64,
    pub turn: u32,
    pub commitment: [u8; 32],
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ResolvedRandomness {
    pub request_id: u64,
    pub drand_round: u64,
    pub entropy: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct LeaderboardEntry {
    pub wallet: String,
    pub wins: u32,
    pub losses: u32,
    pub rating: i32,
    pub score: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct MatchResult {
    pub session_id: u64,
    pub winner: String,
    pub completed_turns: u32,
    pub reward_points: Vec<(String, u32)>,
}

#[derive(Debug, Default)]
pub struct EngineCore {
    sessions: BTreeMap<u64, GameSession>,
    pending_randomness: BTreeMap<u64, RandomnessRequest>,
    leaderboard: BTreeMap<String, LeaderboardEntry>,
    next_session_id: u64,
    next_request_id: u64,
}

#[derive(Debug, Error, PartialEq, Eq)]
pub enum EngineError {
    #[error("not enough players for mode")]
    NotEnoughPlayers,
    #[error("session not found")]
    SessionNotFound,
    #[error("player not found in session")]
    PlayerNotFound,
    #[error("session is not ready for randomness")]
    RandomnessUnavailable,
    #[error("session is already finished")]
    SessionFinished,
    #[error("actor has no stamina remaining")]
    ExhaustedActor,
}

impl EngineCore {
    pub fn create_session(
        &mut self,
        mode: GameMode,
        wallets: Vec<String>,
    ) -> Result<u64, EngineError> {
        if wallets.len() < mode.min_players() {
            return Err(EngineError::NotEnoughPlayers);
        }

        let session_id = self.next_session_id;
        self.next_session_id += 1;

        let players = wallets
            .into_iter()
            .map(|wallet| PlayerState {
                wallet,
                health: match mode {
                    GameMode::Duel => 100,
                    GameMode::Squad => 125,
                    GameMode::Raid => 150,
                },
                mana: 30,
                stamina: 5,
                loadout: vec![1101, 2101],
                rating: 1200,
                score: 0,
            })
            .collect();

        self.sessions.insert(
            session_id,
            GameSession {
                session_id,
                mode,
                turn: 0,
                status: SessionStatus::AwaitingRandomness,
                players,
            },
        );

        Ok(session_id)
    }

    pub fn request_randomness(
        &mut self,
        session_id: u64,
        arb_block_hash: [u8; 32],
    ) -> Result<RandomnessRequest, EngineError> {
        let session = self
            .sessions
            .get(&session_id)
            .ok_or(EngineError::SessionNotFound)?;

        if session.status == SessionStatus::Finished {
            return Err(EngineError::SessionFinished);
        }

        let request_id = self.next_request_id;
        self.next_request_id += 1;

        let mut hasher = Sha256::new();
        hasher.update(session_id.to_le_bytes());
        hasher.update(session.turn.to_le_bytes());
        hasher.update(arb_block_hash);
        for player in &session.players {
            hasher.update(player.wallet.as_bytes());
        }

        let commitment = hasher.finalize().into();
        let request = RandomnessRequest {
            request_id,
            session_id,
            turn: session.turn,
            commitment,
        };

        self.pending_randomness.insert(request_id, request.clone());
        if let Some(session) = self.sessions.get_mut(&session_id) {
            session.status = SessionStatus::AwaitingRandomness;
        }

        Ok(request)
    }

    pub fn fulfill_randomness(
        &mut self,
        request_id: u64,
        drand_round: u64,
        drand_signature: &[u8],
    ) -> Result<ResolvedRandomness, EngineError> {
        let request = self
            .pending_randomness
            .remove(&request_id)
            .ok_or(EngineError::RandomnessUnavailable)?;

        let mut hasher = Sha256::new();
        hasher.update(request.commitment);
        hasher.update(drand_round.to_le_bytes());
        hasher.update(drand_signature);

        let digest = hasher.finalize();
        let mut entropy_bytes = [0_u8; 8];
        entropy_bytes.copy_from_slice(&digest[..8]);
        let entropy = u64::from_le_bytes(entropy_bytes);

        if let Some(session) = self.sessions.get_mut(&request.session_id) {
            session.status = SessionStatus::Active;
        }

        Ok(ResolvedRandomness {
            request_id,
            drand_round,
            entropy,
        })
    }

    pub fn execute_turn(
        &mut self,
        session_id: u64,
        actor_wallet: &str,
        randomness: &ResolvedRandomness,
        action_power: u32,
    ) -> Result<(), EngineError> {
        let session = self
            .sessions
            .get_mut(&session_id)
            .ok_or(EngineError::SessionNotFound)?;

        if session.status == SessionStatus::Finished {
            return Err(EngineError::SessionFinished);
        }

        let actor_index = session
            .players
            .iter()
            .position(|player| player.wallet == actor_wallet)
            .ok_or(EngineError::PlayerNotFound)?;

        if session.players[actor_index].stamina == 0 {
            return Err(EngineError::ExhaustedActor);
        }

        let alive_targets: Vec<usize> = session
            .players
            .iter()
            .enumerate()
            .filter_map(|(index, player)| {
                if index != actor_index && player.health > 0 {
                    Some(index)
                } else {
                    None
                }
            })
            .collect();

        if alive_targets.is_empty() {
            session.status = SessionStatus::Finished;
            return Ok(());
        }

        let target_index = alive_targets[(randomness.entropy as usize) % alive_targets.len()];
        let damage = 10 + action_power + (randomness.entropy % 15) as u32;

        apply_damage(&mut session.players, actor_index, target_index, damage);

        session.turn += 1;
        session.status = if session
            .players
            .iter()
            .filter(|player| player.health > 0)
            .count()
            <= 1
        {
            SessionStatus::Finished
        } else {
            SessionStatus::AwaitingRandomness
        };

        Ok(())
    }

    pub fn settle_session(&mut self, session_id: u64) -> Result<MatchResult, EngineError> {
        let session = self
            .sessions
            .get(&session_id)
            .cloned()
            .ok_or(EngineError::SessionNotFound)?;

        let winner = session
            .players
            .iter()
            .max_by_key(|player| (player.health, player.score, player.stamina))
            .ok_or(EngineError::PlayerNotFound)?
            .wallet
            .clone();

        let reward_points: Vec<(String, u32)> = session
            .players
            .iter()
            .map(|player| {
                let bonus = if player.wallet == winner { 150 } else { 50 };
                (player.wallet.clone(), player.score + bonus)
            })
            .collect();

        for player in &session.players {
            let entry = self
                .leaderboard
                .entry(player.wallet.clone())
                .or_insert(LeaderboardEntry {
                    wallet: player.wallet.clone(),
                    wins: 0,
                    losses: 0,
                    rating: 1200,
                    score: 0,
                });

            let points = reward_points
                .iter()
                .find(|(wallet, _)| wallet == &player.wallet)
                .map(|(_, points)| *points)
                .unwrap_or_default();

            entry.score += points;
            if player.wallet == winner {
                entry.wins += 1;
                entry.rating += 24;
            } else {
                entry.losses += 1;
                entry.rating -= 8;
            }
        }

        if let Some(session) = self.sessions.get_mut(&session_id) {
            session.status = SessionStatus::Finished;
        }

        Ok(MatchResult {
            session_id,
            winner,
            completed_turns: session.turn,
            reward_points,
        })
    }

    pub fn leaderboard(&self) -> Vec<LeaderboardEntry> {
        let mut entries: Vec<_> = self.leaderboard.values().cloned().collect();
        entries.sort_by(|left, right| {
            right
                .rating
                .cmp(&left.rating)
                .then(right.score.cmp(&left.score))
        });
        entries
    }

    pub fn session(&self, session_id: u64) -> Option<&GameSession> {
        self.sessions.get(&session_id)
    }
}

fn apply_damage(players: &mut [PlayerState], actor_index: usize, target_index: usize, damage: u32) {
    if actor_index < target_index {
        let (before, after) = players.split_at_mut(target_index);
        let actor = &mut before[actor_index];
        let target = &mut after[0];
        actor.stamina = actor.stamina.saturating_sub(1);
        actor.score += damage;
        target.health = target.health.saturating_sub(damage);
    } else {
        let (before, after) = players.split_at_mut(actor_index);
        let target = &mut before[target_index];
        let actor = &mut after[0];
        actor.stamina = actor.stamina.saturating_sub(1);
        actor.score += damage;
        target.health = target.health.saturating_sub(damage);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn duel_session_progresses() {
        let mut engine = EngineCore::default();
        let session_id = engine
            .create_session(GameMode::Duel, vec!["alice".into(), "bob".into()])
            .expect("session");
        let request = engine
            .request_randomness(session_id, [7_u8; 32])
            .expect("request");
        let resolved = engine
            .fulfill_randomness(request.request_id, 42, b"beacon")
            .expect("resolved");
        engine
            .execute_turn(session_id, "alice", &resolved, 9)
            .expect("turn");

        let session = engine.session(session_id).expect("session state");
        assert_eq!(session.turn, 1);
    }
}
