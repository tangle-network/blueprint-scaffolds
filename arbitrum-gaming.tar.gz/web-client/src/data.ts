export type ArenaMode = 'Duel' | 'Squad' | 'Raid';

export interface GameModeCard {
  name: ArenaMode;
  teamSize: string;
  avgDuration: string;
  focus: string;
  reward: string;
}

export interface ContractSurface {
  title: string;
  contract: string;
  bullets: string[];
}

export interface RandomnessStep {
  title: string;
  detail: string;
}

export interface InventoryItem {
  id: number;
  name: string;
  className: string;
  rarity: 'Common' | 'Rare' | 'Epic' | 'Mythic';
  power: number;
  equipped: boolean;
}

export interface CraftingRecipe {
  id: number;
  name: string;
  inputs: string[];
  output: string;
  successBand: string;
}

export interface QueueTicket {
  player: string;
  mode: ArenaMode;
  rating: number;
  sessionKey: boolean;
}

export interface LeaderboardEntry {
  rank: number;
  guild: string;
  wallet: string;
  rating: number;
  wins: number;
  crafted: number;
}

export const networkStats = [
  { label: 'Stylus contracts', value: '3 core modules' },
  { label: 'Session key fee relays', value: 'ERC-4337 ready' },
  { label: 'Randomness proofs', value: 'drand + block hash' },
  { label: 'Game asset classes', value: 'Weapons, relics, catalysts' },
];

export const gameModes: GameModeCard[] = [
  {
    name: 'Duel',
    teamSize: '1v1',
    avgDuration: '2 minutes',
    focus: 'Tight turn loops and rapid loot drops.',
    reward: 'Ranked shard packs',
  },
  {
    name: 'Squad',
    teamSize: '2v2',
    avgDuration: '6 minutes',
    focus: 'Coordinated abilities, crafted loadouts, tactical swaps.',
    reward: 'Guild points + catalysts',
  },
  {
    name: 'Raid',
    teamSize: '6 players',
    avgDuration: '12 minutes',
    focus: 'Asynchronous boss phases settled fully on-chain.',
    reward: 'Mythic forge components',
  },
];

export const contractSurfaces: ContractSurface[] = [
  {
    title: 'Engine Core',
    contract: 'contracts/engine-core',
    bullets: [
      'Turn settlement, damage rolls, and leaderboard scoring',
      'Commit-reveal friendly randomness request lifecycle',
      'Portable Rust structures aligned with Stylus contract boundaries',
    ],
  },
  {
    title: 'Asset Management',
    contract: 'contracts/asset-management',
    bullets: [
      'NFT-like inventory items with deterministic forged power',
      'Crafting recipes that consume on-chain material tokens',
      'Loot drop hooks ready for post-match rewards',
    ],
  },
  {
    title: 'Matchmaking',
    contract: 'contracts/matchmaking',
    bullets: [
      'Queue tickets, session key scopes, and match creation',
      'Team-size aware lobbies for duel, squad, and raid modes',
      'Result reporting surfaces for ranking pipelines',
    ],
  },
];

export const randomnessSteps: RandomnessStep[] = [
  {
    title: '1. Commit',
    detail: 'Game engine binds session id, turn number, and Arbitrum block hash into a request commitment.',
  },
  {
    title: '2. Beacon',
    detail: 'A drand-style signature or oracle payload resolves the commitment into reproducible entropy.',
  },
  {
    title: '3. Settle',
    detail: 'Combat rolls, drop tables, and crafting boosts use the same resolved entropy source.',
  },
];

export const inventoryItems: InventoryItem[] = [
  { id: 1101, name: 'Photon Saber', className: 'Weapon', rarity: 'Rare', power: 52, equipped: true },
  { id: 1201, name: 'Void Sigil', className: 'Catalyst', rarity: 'Rare', power: 38, equipped: true },
  { id: 1301, name: 'Aegis Frame', className: 'Relic', rarity: 'Epic', power: 67, equipped: false },
  { id: 2101, name: 'Runic Core', className: 'Material', rarity: 'Common', power: 14, equipped: false },
  { id: 2201, name: 'Prism Dust', className: 'Material', rarity: 'Common', power: 19, equipped: false },
  { id: 3101, name: 'Nova Lance', className: 'Weapon', rarity: 'Mythic', power: 91, equipped: false },
];

export const craftingRecipes: CraftingRecipe[] = [
  {
    id: 1,
    name: 'Forge Nova Lance',
    inputs: ['Photon Saber', 'Void Sigil', 'Prism Dust'],
    output: 'Nova Lance',
    successBand: 'Entropy >= 120',
  },
  {
    id: 2,
    name: 'Reinforce Aegis Frame',
    inputs: ['Aegis Frame', 'Runic Core', 'Prism Dust'],
    output: 'Aegis Frame+',
    successBand: 'Entropy >= 80',
  },
];

export const queueTickets: QueueTicket[] = [
  { player: '0xA91C...7De2', mode: 'Duel', rating: 1488, sessionKey: true },
  { player: '0xB347...fA10', mode: 'Squad', rating: 1720, sessionKey: true },
  { player: '0xCC88...9bA1', mode: 'Squad', rating: 1693, sessionKey: false },
  { player: '0xD712...1c44', mode: 'Raid', rating: 1811, sessionKey: true },
];

export const leaderboard: LeaderboardEntry[] = [
  { rank: 1, guild: 'Nightglass', wallet: '0xF0rge...091', rating: 2148, wins: 128, crafted: 47 },
  { rank: 2, guild: 'Iron Pulse', wallet: '0xShard...4CE', rating: 2081, wins: 119, crafted: 39 },
  { rank: 3, guild: 'Zero Vector', wallet: '0xRune...7d4', rating: 2010, wins: 113, crafted: 62 },
  { rank: 4, guild: 'Solar Keep', wallet: '0xMesh...D77', rating: 1988, wins: 101, crafted: 28 },
];

export const sessionKeyRules = [
  'Wallet signs a scoped ephemeral key for queue + inventory actions.',
  'Relayer covers gas while respecting action budgets and block expiry.',
  'Critical operations such as asset withdrawal still require the primary signer.',
];
