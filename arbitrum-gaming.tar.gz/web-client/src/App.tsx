import { useMemo, useState } from 'react';
import {
  contractSurfaces,
  craftingRecipes,
  gameModes,
  inventoryItems,
  leaderboard,
  networkStats,
  queueTickets,
  randomnessSteps,
  sessionKeyRules,
  type ArenaMode,
} from './data';

const rarityTone: Record<string, string> = {
  Common: 'tone-common',
  Rare: 'tone-rare',
  Epic: 'tone-epic',
  Mythic: 'tone-mythic',
};

function App() {
  const [selectedMode, setSelectedMode] = useState<ArenaMode>('Squad');
  const [sessionKeysEnabled, setSessionKeysEnabled] = useState(true);
  const [queuedMode, setQueuedMode] = useState<ArenaMode | null>('Squad');
  const [selectedRecipeId, setSelectedRecipeId] = useState(1);

  const activeMode = useMemo(
    () => gameModes.find((mode) => mode.name === selectedMode) ?? gameModes[0],
    [selectedMode],
  );

  const selectedRecipe = useMemo(
    () => craftingRecipes.find((recipe) => recipe.id === selectedRecipeId) ?? craftingRecipes[0],
    [selectedRecipeId],
  );

  const equippedPower = inventoryItems
    .filter((item) => item.equipped)
    .reduce((total, item) => total + item.power, 0);

  const queueCount = queueTickets.filter((ticket) => ticket.mode === selectedMode).length;

  return (
    <div className="app-shell">
      <div className="background-orbit orbit-a" />
      <div className="background-orbit orbit-b" />
      <main className="page-frame">
        <section className="hero-panel">
          <div className="hero-copy">
            <p className="eyebrow">Arbitrum Gaming Infrastructure</p>
            <h1>Arcadia Chainforge</h1>
            <p className="hero-text">
              A fully on-chain stack for tactical battles, verifiable randomness, NFT gear,
              gasless session keys, and ranked matchmaking powered by Arbitrum.
            </p>
            <div className="hero-actions">
              <button className="primary-button" onClick={() => setQueuedMode(selectedMode)}>
                Launch {selectedMode} Queue
              </button>
              <button
                className="secondary-button"
                onClick={() => setSessionKeysEnabled((current) => !current)}
              >
                {sessionKeysEnabled ? 'Session Keys Enabled' : 'Enable Session Keys'}
              </button>
            </div>
          </div>

          <div className="hero-metrics">
            {networkStats.map((stat) => (
              <article className="metric-card" key={stat.label}>
                <span>{stat.label}</span>
                <strong>{stat.value}</strong>
              </article>
            ))}
          </div>
        </section>

        <section className="section-grid two-up">
          <article className="panel panel-large">
            <div className="panel-header">
              <div>
                <p className="eyebrow">Lobby System</p>
                <h2>Matchmaking Modes</h2>
              </div>
              <span className="status-pill">{queueCount} queued now</span>
            </div>

            <div className="mode-grid">
              {gameModes.map((mode) => (
                <button
                  key={mode.name}
                  className={`mode-card ${selectedMode === mode.name ? 'mode-card-active' : ''}`}
                  onClick={() => setSelectedMode(mode.name)}
                >
                  <div className="mode-title-row">
                    <h3>{mode.name}</h3>
                    <span>{mode.teamSize}</span>
                  </div>
                  <p>{mode.focus}</p>
                  <dl>
                    <div>
                      <dt>Avg</dt>
                      <dd>{mode.avgDuration}</dd>
                    </div>
                    <div>
                      <dt>Reward</dt>
                      <dd>{mode.reward}</dd>
                    </div>
                  </dl>
                </button>
              ))}
            </div>

            <div className="mode-spotlight">
              <div>
                <p className="eyebrow">Selected Queue</p>
                <h3>{activeMode.name}</h3>
                <p>{activeMode.focus}</p>
              </div>
              <div className="mode-spotlight-stats">
                <div>
                  <span>State</span>
                  <strong>{queuedMode === activeMode.name ? 'Queued' : 'Ready'}</strong>
                </div>
                <div>
                  <span>Gasless</span>
                  <strong>{sessionKeysEnabled ? 'Scoped session signer' : 'Primary wallet only'}</strong>
                </div>
              </div>
            </div>
          </article>

          <article className="panel">
            <div className="panel-header">
              <div>
                <p className="eyebrow">Wallet UX</p>
                <h2>Session Keys</h2>
              </div>
              <span className={`status-pill ${sessionKeysEnabled ? 'status-live' : ''}`}>
                {sessionKeysEnabled ? 'Relayer active' : 'Manual signing'}
              </span>
            </div>
            <div className="stack-list">
              {sessionKeyRules.map((rule) => (
                <div className="list-card" key={rule}>
                  <span className="list-index">+</span>
                  <p>{rule}</p>
                </div>
              ))}
            </div>
          </article>
        </section>

        <section className="section-grid two-up">
          <article className="panel">
            <div className="panel-header">
              <div>
                <p className="eyebrow">Randomness</p>
                <h2>Verifiable Flow</h2>
              </div>
            </div>
            <div className="stack-list">
              {randomnessSteps.map((step) => (
                <div className="list-card" key={step.title}>
                  <h3>{step.title}</h3>
                  <p>{step.detail}</p>
                </div>
              ))}
            </div>
          </article>

          <article className="panel">
            <div className="panel-header">
              <div>
                <p className="eyebrow">Contract Topology</p>
                <h2>Stylus Modules</h2>
              </div>
            </div>
            <div className="stack-list">
              {contractSurfaces.map((surface) => (
                <div className="list-card" key={surface.title}>
                  <div className="card-inline-title">
                    <h3>{surface.title}</h3>
                    <code>{surface.contract}</code>
                  </div>
                  <ul>
                    {surface.bullets.map((bullet) => (
                      <li key={bullet}>{bullet}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </article>
        </section>

        <section className="section-grid two-up">
          <article className="panel panel-large">
            <div className="panel-header">
              <div>
                <p className="eyebrow">Inventory Management</p>
                <h2>NFT Loadout</h2>
              </div>
              <span className="status-pill">Equipped power {equippedPower}</span>
            </div>

            <div className="inventory-grid">
              {inventoryItems.map((item) => (
                <article className="inventory-card" key={item.id}>
                  <div className="inventory-top-row">
                    <span className={`rarity-chip ${rarityTone[item.rarity]}`}>{item.rarity}</span>
                    <span className="item-id">#{item.id}</span>
                  </div>
                  <h3>{item.name}</h3>
                  <p>{item.className}</p>
                  <div className="inventory-bottom-row">
                    <strong>{item.power} power</strong>
                    <span>{item.equipped ? 'Equipped' : 'Stored'}</span>
                  </div>
                </article>
              ))}
            </div>
          </article>

          <article className="panel">
            <div className="panel-header">
              <div>
                <p className="eyebrow">Crafting</p>
                <h2>Forge Recipes</h2>
              </div>
            </div>
            <div className="recipe-tabs">
              {craftingRecipes.map((recipe) => (
                <button
                  key={recipe.id}
                  className={`recipe-tab ${selectedRecipeId === recipe.id ? 'recipe-tab-active' : ''}`}
                  onClick={() => setSelectedRecipeId(recipe.id)}
                >
                  {recipe.name}
                </button>
              ))}
            </div>
            <div className="forge-preview">
              <div>
                <p className="eyebrow">Inputs</p>
                <div className="pill-row">
                  {selectedRecipe.inputs.map((input) => (
                    <span className="mini-pill" key={input}>
                      {input}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <p className="eyebrow">Output</p>
                <strong>{selectedRecipe.output}</strong>
                <p>{selectedRecipe.successBand}</p>
              </div>
            </div>
          </article>
        </section>

        <section className="section-grid two-up">
          <article className="panel">
            <div className="panel-header">
              <div>
                <p className="eyebrow">Active Queue</p>
                <h2>Lobby Presence</h2>
              </div>
            </div>
            <div className="ticket-list">
              {queueTickets.map((ticket) => (
                <div className="ticket-row" key={ticket.player}>
                  <div>
                    <strong>{ticket.player}</strong>
                    <p>{ticket.mode} ladder</p>
                  </div>
                  <div className="ticket-meta">
                    <span>{ticket.rating} MMR</span>
                    <span>{ticket.sessionKey ? 'Gasless' : 'Signed'}</span>
                  </div>
                </div>
              ))}
            </div>
          </article>

          <article className="panel">
            <div className="panel-header">
              <div>
                <p className="eyebrow">Leaderboards</p>
                <h2>Top Guild Operators</h2>
              </div>
            </div>
            <div className="leaderboard-table">
              {leaderboard.map((entry) => (
                <div className="leaderboard-row" key={entry.wallet}>
                  <span>#{entry.rank}</span>
                  <div>
                    <strong>{entry.guild}</strong>
                    <p>{entry.wallet}</p>
                  </div>
                  <div>
                    <strong>{entry.rating}</strong>
                    <p>{entry.wins} wins / {entry.crafted} crafted</p>
                  </div>
                </div>
              ))}
            </div>
          </article>
        </section>
      </main>
    </div>
  );
}

export default App;
