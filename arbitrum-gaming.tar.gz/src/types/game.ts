export type Rarity = 'common' | 'rare' | 'epic' | 'legendary'

export interface GameItem {
  id: string
  name: string
  description: string
  rarity: Rarity
  icon: string
  tokenId?: number
  stats: ItemStats
  craftable: boolean
  recipe?: CraftingRecipe
}

export interface ItemStats {
  attack: number
  defense: number
  speed: number
  magic: number
  luck: number
}

export interface CraftingRecipe {
  inputItemIds: string[]
  outputItemId: string
  successChance: number
  requiredMatches: number
}

export interface GameSession {
  id: string
  player1: Player
  player2: Player | null
  status: 'waiting' | 'matched' | 'in_progress' | 'completed'
  board: GameBoardState
  currentTurn: string
  winner: string | null
  randomnessSeed: string
  createdAt: number
  moves: GameMove[]
}

export interface Player {
  address: string
  username: string
  elo: number
  wins: number
  losses: number
  items: string[]
  equippedItems: string[]
  health: number
  maxHealth: number
}

export interface GameBoardState {
  grid: CellState[][]
  rows: number
  cols: number
}

export interface CellState {
  row: number
  col: number
  owner: string | null
  element: 'fire' | 'water' | 'earth' | 'air' | null
  power: number
}

export interface GameMove {
  player: string
  row: number
  col: number
  element: 'fire' | 'water' | 'earth' | 'air'
  timestamp: number
  damage: number
}

export interface LeaderboardEntry {
  rank: number
  address: string
  username: string
  elo: number
  wins: number
  losses: number
  winRate: number
  matchesPlayed: number
}

export interface SessionKey {
  key: string
  owner: string
  expiresAt: number
  spendingLimit: string
  permissions: SessionKeyPermission[]
  isActive: boolean
}

export interface SessionKeyPermission {
  contract: string
  functionSelector: string
  maxCalls: number
  callsMade: number
}

export interface MatchmakingQueue {
  players: QueuedPlayer[]
  avgWaitTime: number
  totalInQueue: number
}

export interface QueuedPlayer {
  address: string
  elo: number
  enqueuedAt: number
  preferredGameMode: string
}

export interface RandomnessRequest {
  id: string
  requester: string
  seed: string
  result: string | null
  fulfilled: boolean
  blockNumber: number
}

export interface CraftResult {
  success: boolean
  inputItems: string[]
  outputItem: GameItem | null
  randomnessUsed: string
}
