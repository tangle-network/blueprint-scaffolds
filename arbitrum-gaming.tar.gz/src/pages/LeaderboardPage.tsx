import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { MOCK_LEADERBOARD } from "@/lib/utils"
import { Trophy, Medal, TrendingUp } from "lucide-react"

export function LeaderboardPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Trophy className="w-6 h-6 text-yellow-400" />
          Leaderboard
        </h1>
        <p className="text-sm text-muted-foreground">
          Top players ranked by ELO rating
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {MOCK_LEADERBOARD.slice(0, 3).map((entry, i) => {
          const medals = ["text-yellow-400", "text-gray-300", "text-amber-600"]
          const glows = ["glow-yellow", "glow-blue", "glow-purple"]
          return (
            <Card key={entry.rank} className={`${i === 0 ? "border-yellow-500/30" : ""}`}>
              <CardContent className="py-6 text-center">
                <Medal className={`w-10 h-10 mx-auto mb-2 ${medals[i]}`} />
                <p className="text-2xl font-bold">{entry.username}</p>
                <p className="text-sm text-muted-foreground font-mono">{entry.player}</p>
                <div className="mt-3 space-y-1">
                  <p className="text-lg font-bold text-blue-400">{entry.elo} ELO</p>
                  <p className="text-xs text-muted-foreground">
                    {entry.wins}W / {entry.losses}L
                  </p>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-blue-400" />
            Full Rankings
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border text-sm text-muted-foreground">
                  <th className="text-left py-3 px-2 w-16">Rank</th>
                  <th className="text-left py-3 px-2">Player</th>
                  <th className="text-right py-3 px-2">ELO</th>
                  <th className="text-right py-3 px-2">Wins</th>
                  <th className="text-right py-3 px-2">Losses</th>
                  <th className="text-right py-3 px-2">Win Rate</th>
                </tr>
              </thead>
              <tbody>
                {MOCK_LEADERBOARD.map((entry) => {
                  const winRate = ((entry.wins / (entry.wins + entry.losses)) * 100).toFixed(1)
                  return (
                    <tr
                      key={entry.rank}
                      className="border-b border-border/50 hover:bg-accent/50 transition-colors"
                    >
                      <td className="py-3 px-2">
                        <span className={`font-bold ${entry.rank <= 3 ? "text-yellow-400" : ""}`}>
                          #{entry.rank}
                        </span>
                      </td>
                      <td className="py-3 px-2">
                        <div>
                          <p className="font-medium text-sm">{entry.username}</p>
                          <p className="text-xs text-muted-foreground font-mono">{entry.player}</p>
                        </div>
                      </td>
                      <td className="py-3 px-2 text-right font-mono font-bold text-blue-400">
                        {entry.elo}
                      </td>
                      <td className="py-3 px-2 text-right text-green-400">{entry.wins}</td>
                      <td className="py-3 px-2 text-right text-red-400">{entry.losses}</td>
                      <td className="py-3 px-2 text-right">
                        <span className={`text-sm ${Number(winRate) >= 60 ? "text-green-400" : "text-muted-foreground"}`}>
                          {winRate}%
                        </span>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
