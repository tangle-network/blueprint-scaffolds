import { GameGrid } from "@/components/game/GameGrid"
import { GameControls } from "@/components/game/GameControls"
import { BattleLog } from "@/components/game/BattleLog"
import { GameStats } from "@/components/game/GameStats"
import { useGame } from "@/hooks/useGame"
import { useWallet } from "@/hooks/useWallet"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Swords, RotateCcw } from "lucide-react"

export function GamePage() {
  const { state, movePlayer, resetGame } = useGame()
  const { isConnected } = useWallet()

  if (!isConnected) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <Swords className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
        <h2 className="text-2xl font-bold mb-2">Connect Wallet to Play</h2>
        <p className="text-muted-foreground">
          You need to connect your wallet to enter the arena.
        </p>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Swords className="w-6 h-6 text-blue-400" />
            Battle Arena
          </h1>
          <p className="text-sm text-muted-foreground">
            Turn {state.turn} — {state.isPlayerTurn ? "Your turn" : "Enemy turn"}
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={resetGame}>
          <RotateCcw className="w-4 h-4 mr-1.5" />
          Reset
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3 space-y-4">
          <Card>
            <CardContent className="p-4">
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="flex items-center gap-1">
                      <span>🧙</span> Player
                    </span>
                    <span>{state.playerHp}/{state.playerMaxHp}</span>
                  </div>
                  <Progress value={(state.playerHp / state.playerMaxHp) * 100} className="h-2" />
                </div>
                <div>
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="flex items-center gap-1">
                      <span>👹</span> Enemy
                    </span>
                    <span>{state.enemyHp}/{state.enemyMaxHp}</span>
                  </div>
                  <Progress value={(state.enemyHp / state.enemyMaxHp) * 100} className="h-2" />
                </div>
              </div>
              <GameGrid grid={state.grid} />
            </CardContent>
          </Card>

          {state.gameOver && (
            <Card className={state.winner === "player" ? "border-green-500/50 glow-green" : "border-red-500/50"}>
              <CardContent className="py-6 text-center">
                <h2 className="text-2xl font-bold mb-2">
                  {state.winner === "player" ? "Victory!" : "Defeat!"}
                </h2>
                <p className="text-muted-foreground mb-4">
                  {state.winner === "player"
                    ? "You defeated the enemy!"
                    : "The enemy got the better of you."}
                </p>
                <Button onClick={resetGame}>
                  <RotateCcw className="w-4 h-4 mr-1.5" />
                  Play Again
                </Button>
              </CardContent>
            </Card>
          )}

          <GameControls
            onMove={movePlayer}
            disabled={!state.isPlayerTurn || state.gameOver}
          />
        </div>

        <div className="space-y-4">
          <GameStats state={state} />
          <BattleLog log={state.log} />
        </div>
      </div>
    </div>
  )
}
