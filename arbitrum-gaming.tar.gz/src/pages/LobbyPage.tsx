import { useEffect } from "react"
import { useNavigate } from "react-router-dom"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { useMatchmaking } from "@/hooks/useMatchmaking"
import { useWallet } from "@/hooks/useWallet"
import { Users, Search, Clock, Swords, Loader2 } from "lucide-react"

export function LobbyPage() {
  const { isInQueue, queueSize, estimatedWait, matchFound, opponent, gameId, joinQueue, leaveQueue } = useMatchmaking()
  const { isConnected, connect } = useWallet()
  const navigate = useNavigate()

  useEffect(() => {
    if (matchFound && gameId) {
      const timer = setTimeout(() => {
        navigate("/game")
      }, 3000)
      return () => clearTimeout(timer)
    }
  }, [matchFound, gameId, navigate])

  if (!isConnected) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <Users className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
        <h2 className="text-2xl font-bold mb-2">Connect Wallet</h2>
        <p className="text-muted-foreground mb-4">Connect your wallet to enter the lobby.</p>
        <Button onClick={connect} className="gradient-arb text-white border-0">
          Connect Wallet
        </Button>
      </div>
    )
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Users className="w-6 h-6 text-blue-400" />
          Matchmaking Lobby
        </h1>
        <p className="text-sm text-muted-foreground">
          Find an opponent and battle on-chain
        </p>
      </div>

      {matchFound ? (
        <Card className="border-green-500/50 glow-green">
          <CardContent className="py-8 text-center">
            <Swords className="w-12 h-12 mx-auto mb-4 text-green-400" />
            <h2 className="text-2xl font-bold mb-2">Match Found!</h2>
            <p className="text-muted-foreground mb-1">
              Opponent: <span className="text-foreground font-mono">{opponent}</span>
            </p>
            <p className="text-sm text-muted-foreground mb-4">
              Game ID: <span className="font-mono">{gameId}</span>
            </p>
            <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="w-4 h-4 animate-spin" />
              Entering arena...
            </div>
          </CardContent>
        </Card>
      ) : isInQueue ? (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Search className="w-5 h-5 text-blue-400 animate-pulse" />
              Searching for Opponent
            </CardTitle>
            <CardDescription>Finding a worthy challenger...</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-muted-foreground">Estimated Wait</span>
                <span>{estimatedWait}s</span>
              </div>
              <Progress value={Math.max(0, (1 - estimatedWait / 30) * 100)} className="h-2" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 rounded-lg bg-secondary">
                <p className="text-2xl font-bold">{queueSize}</p>
                <p className="text-xs text-muted-foreground">Players in Queue</p>
              </div>
              <div className="text-center p-3 rounded-lg bg-secondary">
                <p className="text-2xl font-bold">{estimatedWait}s</p>
                <p className="text-xs text-muted-foreground">Est. Wait Time</p>
              </div>
            </div>
            <Button variant="destructive" className="w-full" onClick={leaveQueue}>
              Leave Queue
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          <Card>
            <CardContent className="py-8 text-center">
              <Swords className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
              <h2 className="text-xl font-bold mb-2">Ready to Battle?</h2>
              <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                Join the matchmaking queue to find an opponent. Battles are fully on-chain
                with verifiable randomness for fair outcomes.
              </p>
              <Button
                size="lg"
                className="gradient-arb text-white border-0"
                onClick={joinQueue}
              >
                <Search className="w-5 h-5 mr-2" />
                Find Match
              </Button>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-card/50">
              <CardContent className="py-4 text-center">
                <Clock className="w-8 h-8 mx-auto mb-2 text-blue-400" />
                <p className="text-sm font-medium">Session Keys</p>
                <p className="text-xs text-muted-foreground">Gasless gameplay with session keys</p>
              </CardContent>
            </Card>
            <Card className="bg-card/50">
              <CardContent className="py-4 text-center">
                <Swords className="w-8 h-8 mx-auto mb-2 text-blue-400" />
                <p className="text-sm font-medium">Fair Combat</p>
                <p className="text-xs text-muted-foreground">Verifiable randomness for outcomes</p>
              </CardContent>
            </Card>
            <Card className="bg-card/50">
              <CardContent className="py-4 text-center">
                <Users className="w-8 h-8 mx-auto mb-2 text-blue-400" />
                <p className="text-sm font-medium">ELO Ranking</p>
                <p className="text-xs text-muted-foreground">Skill-based matchmaking</p>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  )
}
