import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useInventory } from "@/hooks/useInventory"
import { useWallet } from "@/hooks/useWallet"
import { RARITY_COLORS, RARITY_BG, MOCK_RECIPES } from "@/lib/utils"
import type { GameItem } from "@/lib/utils"
import { Backpack, Hammer, Swords, CheckCircle2, XCircle } from "lucide-react"

function ItemCard({ item, selected, onClick }: { item: GameItem; selected: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`w-full text-left p-3 rounded-lg border transition-all ${
        selected
          ? "border-primary glow-blue bg-primary/5"
          : "border-border hover:border-primary/50"
      }`}
    >
      <div className="flex items-start gap-3">
        <span className="text-2xl">{item.icon}</span>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className={`font-medium text-sm ${RARITY_COLORS[item.rarity]}`}>
              {item.name}
            </span>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">{item.description}</p>
          <div className="flex gap-3 mt-1.5 text-xs text-muted-foreground">
            {item.attack && <span>ATK {item.attack}</span>}
            {item.defense && <span>DEF {item.defense}</span>}
            {item.magic && <span>MAG {item.magic}</span>}
          </div>
        </div>
        <span className={`text-xs px-2 py-0.5 rounded ${RARITY_BG[item.rarity]} ${RARITY_COLORS[item.rarity]}`}>
          {item.rarity}
        </span>
      </div>
    </button>
  )
}

export function InventoryPage() {
  const { items, selectedItems, toggleItem, craft, craftingResult, craftSuccess, clearResult } = useInventory()
  const { isConnected } = useWallet()

  if (!isConnected) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <Backpack className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
        <h2 className="text-2xl font-bold mb-2">Connect Wallet</h2>
        <p className="text-muted-foreground">Connect your wallet to view your inventory.</p>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Backpack className="w-6 h-6 text-blue-400" />
          Inventory & Crafting
        </h1>
        <p className="text-sm text-muted-foreground">
          Manage your items and craft new gear
        </p>
      </div>

      <Tabs defaultValue="inventory" className="space-y-4">
        <TabsList>
          <TabsTrigger value="inventory">
            <Backpack className="w-4 h-4 mr-1.5" />
            Inventory ({items.length})
          </TabsTrigger>
          <TabsTrigger value="crafting">
            <Hammer className="w-4 h-4 mr-1.5" />
            Crafting
          </TabsTrigger>
        </TabsList>

        <TabsContent value="inventory">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {items.map((item) => (
              <ItemCard
                key={item.id}
                item={item}
                selected={selectedItems.includes(item.id)}
                onClick={() => toggleItem(item.id)}
              />
            ))}
          </div>
          {items.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <Backpack className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>Your inventory is empty. Win battles to earn items!</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="crafting">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Select Items</CardTitle>
                  <CardDescription>Select 2 items to combine</CardDescription>
                </CardHeader>
                <CardContent className="space-y-2">
                  {selectedItems.length > 0 && (
                    <div className="flex gap-2 mb-3">
                      {selectedItems.map((id) => {
                        const item = items.find((i) => i.id === id)
                        if (!item) return null
                        return (
                          <div key={id} className="flex items-center gap-1.5 px-2 py-1 rounded bg-secondary text-sm">
                            <span>{item.icon}</span>
                            <span>{item.name}</span>
                          </div>
                        )
                      })}
                    </div>
                  )}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {items.map((item) => (
                      <ItemCard
                        key={item.id}
                        item={item}
                        selected={selectedItems.includes(item.id)}
                        onClick={() => toggleItem(item.id)}
                      />
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Recipes</CardTitle>
                  <CardDescription>Available crafting combinations</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {MOCK_RECIPES.map((recipe) => (
                    <div key={recipe.id} className="p-3 rounded-lg border border-border">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm">{recipe.name}</span>
                        <span className="text-xs text-muted-foreground">
                          {Math.round(recipe.successRate * 100)}% success
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <span className="text-muted-foreground">Input:</span>
                        {recipe.inputs.map((id) => {
                          const inputItem = items.find((i) => i.id === id)
                          return (
                            <span key={id} className="px-1.5 py-0.5 rounded bg-secondary text-xs">
                              {inputItem ? inputItem.name : `Item #${id}`}
                            </span>
                          )
                        })}
                        <span className="text-muted-foreground">→</span>
                        <span className={`px-1.5 py-0.5 rounded text-xs ${RARITY_BG[recipe.output.rarity]} ${RARITY_COLORS[recipe.output.rarity]}`}>
                          {recipe.output.name}
                        </span>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Button
                className="w-full gradient-arb text-white border-0"
                disabled={selectedItems.length !== 2}
                onClick={() => {
                  craft()
                  setTimeout(clearResult, 3000)
                }}
              >
                <Hammer className="w-4 h-4 mr-1.5" />
                Craft Items
              </Button>

              {craftSuccess !== null && (
                <Card className={craftSuccess ? "border-green-500/50" : "border-red-500/50"}>
                  <CardContent className="py-4 flex items-center gap-3">
                    {craftSuccess ? (
                      <>
                        <CheckCircle2 className="w-5 h-5 text-green-500" />
                        <div>
                          <p className="font-medium text-sm">Crafting Successful!</p>
                          {craftingResult && (
                            <p className="text-xs text-muted-foreground">
                              Created: {craftingResult.name}
                            </p>
                          )}
                        </div>
                      </>
                    ) : (
                      <>
                        <XCircle className="w-5 h-5 text-red-500" />
                        <div>
                          <p className="font-medium text-sm">Crafting Failed</p>
                          <p className="text-xs text-muted-foreground">
                            Items were not consumed. Try again!
                          </p>
                        </div>
                      </>
                    )}
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
