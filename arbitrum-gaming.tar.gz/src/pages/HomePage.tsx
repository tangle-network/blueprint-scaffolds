import { Link } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useWallet } from "@/hooks/useWallet"
import { Swords, Shield, Zap, Trophy, Users, Backpack } from "lucide-react"

export function HomePage() {
  const { isConnected, connect } = useWallet()

  const features = [
    {
      icon: Swords,
      title: "On-Chain Battles",
      description: "Turn-based combat with all moves verified on Arbitrum Stylus",
    },
    {
      icon: Shield,
      title: "NFT Items",
      description: "Collect, trade, and equip items as fully on-chain NFTs",
    },
    {
      icon: Zap,
      title: "Verifiable Randomness",
      description: "Fair combat outcomes powered by on-chain randomness",
    },
    {
      icon: Trophy,
      title: "Leaderboards",
      description: "ELO-ranked competitive play with on-chain records",
    },
    {
      icon: Users,
      title: "Matchmaking",
      description: "Skill-based matchmaking with session keys for gasless UX",
    },
    {
      icon: Backpack,
      title: "Crafting System",
      description: "Combine items to forge powerful new equipment",
    },
  ]

  return (
    <div className="max-w-7xl mx-auto px-4">
      <section className="py-20 text-center">
        <div className="animate-float mb-8">
          <div className="gradient-arb w-24 h-24 rounded-2xl flex items-center justify-center mx-auto glow-blue">
            <Swords className="w-14 h-14 text-white" />
          </div>
        </div>
        <h1 className="text-5xl font-bold mb-4">
          <span className="bg-gradient-to-r from-blue-400 via-blue-500 to-blue-600 bg-clip-text text-transparent">
            ChainArena
          </span>
        </h1>
        <p className="text-xl text-muted-foreground mb-2">
          Fully On-Chain Gaming on Arbitrum
        </p>
        <p className="text-muted-foreground max-w-2xl mx-auto mb-8">
          Battle opponents in turn-based combat where every move is verified on-chain.
          Collect rare NFT items, craft legendary gear, and climb the leaderboard — all
          powered by Arbitrum Stylus with gasless session keys.
        </p>
        <div className="flex gap-4 justify-center">
          {isConnected ? (
            <>
              <Link to="/lobby">
                <Button size="lg" className="gradient-arb text-white border-0">
                  <Swords className="w-5 h-5 mr-2" />
                  Find Match
                </Button>
              </Link>
              <Link to="/inventory">
                <Button size="lg" variant="outline">
                  <Backpack className="w-5 h-5 mr-2" />
                  View Inventory
                </Button>
              </Link>
            </>
          ) : (
            <Button size="lg" className="gradient-arb text-white border-0" onClick={connect}>
              <Zap className="w-5 h-5 mr-2" />
              Connect to Start
            </Button>
          )}
        </div>
      </section>

      <section className="py-12">
        <h2 className="text-2xl font-bold text-center mb-8">Core Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {features.map(({ icon: Icon, title, description }) => (
            <Card key={title} className="bg-card/50 hover:bg-card/80 transition-colors">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Icon className="w-5 h-5 text-blue-400" />
                  {title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="py-12 text-center">
        <Card className="bg-card/30 border-blue-500/20">
          <CardContent className="py-8">
            <h3 className="text-xl font-bold mb-2">Built on Arbitrum Stylus</h3>
            <p className="text-muted-foreground max-w-xl mx-auto">
              All game logic runs in Rust smart contracts on Arbitrum Stylus, giving you
              the performance of native code with the security of Ethereum. Session keys
              enable gasless transactions so you can focus on playing.
            </p>
          </CardContent>
        </Card>
      </section>
    </div>
  )
}
