export const GAME_ENGINE_ABI = [
  'function registerPlayer(string username) external',
  'function createSession() external returns (uint256)',
  'function joinSession(uint256 sessionId) external',
  'function makeMove(uint256 sessionId, uint8 row, uint8 col, uint8 element) external',
  'function endSession(uint256 sessionId, address winner) external',
  'function getPlayer(address addr) external view returns (string username, uint256 elo, uint256 wins, uint256 losses, bool registered)',
  'function getSession(uint256 sessionId) external view returns (address player1, address player2, uint8 status, address winner, uint256 moveCount)',
  'function sessionCount() external view returns (uint256)',
  'event PlayerRegistered(address indexed player, string username)',
  'event SessionCreated(uint256 indexed sessionId, address indexed player1)',
  'event PlayerJoined(uint256 indexed sessionId, address indexed player2)',
  'event MoveMade(uint256 indexed sessionId, address indexed player, uint8 row, uint8 col, uint8 element)',
  'event SessionEnded(uint256 indexed sessionId, address indexed winner)',
] as const

export const ASSET_MANAGER_ABI = [
  'function mintItem(address to, string name, string description, uint8 rarity, uint8 assetType, uint256 attack, uint256 defense, uint256 speed, uint256 magic, uint256 luck) external returns (uint256)',
  'function transferItem(address from, address to, uint256 tokenId) external',
  'function registerRecipe(uint256[] inputIds, uint256 outputId, uint8 successChance) external',
  'function craft(uint256[] inputTokenIds, uint256 randomness) external returns (uint256)',
  'function getAsset(uint256 tokenId) external view returns (address owner, string name, uint8 rarity, uint256 attack, uint256 defense, uint256 speed, uint256 magic, uint256 luck)',
  'function getInventory(address player) external view returns (uint256[])',
  'function nextTokenId() external view returns (uint256)',
  'event ItemMinted(uint256 indexed tokenId, address indexed owner, string name, uint8 rarity)',
  'event ItemTransferred(uint256 indexed tokenId, address indexed from, address indexed to)',
  'event CraftAttempt(address indexed player, uint256[] inputIds, uint256 outputId, bool success)',
] as const

export const MATCHMAKING_ABI = [
  'function enqueue(string preferredMode) external',
  'function dequeue() external',
  'function findMatch() external returns (address player1, address player2)',
  'function getQueueSize() external view returns (uint256)',
  'event PlayerEnqueued(address indexed player, uint256 elo)',
  'event PlayerDequeued(address indexed player)',
  'event MatchFound(address indexed player1, address indexed player2)',
] as const

export const RANDOMNESS_ORACLE_ABI = [
  'function requestRandomness(bytes32 seed) external returns (uint256)',
  'function fulfillRandomness(uint256 requestId, uint256 result) external',
  'function getRandomness(uint256 requestId) external view returns (uint256 result, bool fulfilled, address requester)',
  'function verifyRandomness(uint256 requestId, uint256 claimedResult) external view returns (bool)',
  'event RandomnessRequested(uint256 indexed requestId, address indexed requester, bytes32 seed)',
  'event RandomnessFulfilled(uint256 indexed requestId, uint256 result)',
] as const
