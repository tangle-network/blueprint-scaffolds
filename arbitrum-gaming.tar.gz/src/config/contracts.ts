export const ARBITRUM_SEPOLIA = 421614
export const ARBITRUM_ONE = 42161

export const CHAIN_CONFIG = {
  [ARBITRUM_SEPOLIA]: {
    name: 'Arbitrum Sepolia',
    rpcUrl: 'https://sepolia-rollup.arbitrum.io/rpc',
    explorerUrl: 'https://sepolia.arbiscan.io',
  },
  [ARBITRUM_ONE]: {
    name: 'Arbitrum One',
    rpcUrl: 'https://arb1.arbitrum.io/rpc',
    explorerUrl: 'https://arbiscan.io',
  },
} as const

export const CONTRACT_ADDRESSES = {
  [ARBITRUM_SEPOLIA]: {
    gameEngine: '0x0000000000000000000000000000000000000000',
    assetManager: '0x0000000000000000000000000000000000000000',
    matchmaking: '0x0000000000000000000000000000000000000000',
    randomnessOracle: '0x0000000000000000000000000000000000000000',
  },
  [ARBITRUM_ONE]: {
    gameEngine: '0x0000000000000000000000000000000000000000',
    assetManager: '0x0000000000000000000000000000000000000000',
    matchmaking: '0x0000000000000000000000000000000000000000',
    randomnessOracle: '0x0000000000000000000000000000000000000000',
  },
} as const

export function getContractAddresses(chainId: number) {
  return CONTRACT_ADDRESSES[chainId as keyof typeof CONTRACT_ADDRESSES] ?? CONTRACT_ADDRESSES[ARBITRUM_SEPOLIA]
}
