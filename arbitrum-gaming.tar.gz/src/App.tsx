import React from "react"
import { BrowserRouter, Routes, Route } from "react-router-dom"
import { TooltipProvider } from "@/components/ui/tooltip"
import { Layout } from "@/components/Layout"
import { HomePage } from "@/pages/HomePage"
import { GamePage } from "@/pages/GamePage"
import { InventoryPage } from "@/pages/InventoryPage"
import { LobbyPage } from "@/pages/LobbyPage"
import { LeaderboardPage } from "@/pages/LeaderboardPage"

export default function App() {
  return (
    <React.StrictMode>
      <BrowserRouter>
        <TooltipProvider>
          <Routes>
            <Route element={<Layout />}>
              <Route path="/" element={<HomePage />} />
              <Route path="/game" element={<GamePage />} />
              <Route path="/inventory" element={<InventoryPage />} />
              <Route path="/lobby" element={<LobbyPage />} />
              <Route path="/leaderboard" element={<LeaderboardPage />} />
            </Route>
          </Routes>
        </TooltipProvider>
      </BrowserRouter>
    </React.StrictMode>
  )
}
