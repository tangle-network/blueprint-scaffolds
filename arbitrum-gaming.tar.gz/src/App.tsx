export default function App() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="container mx-auto p-8">
        <h1 className="text-3xl font-bold">Loading...</h1>
      </div>
    </div>
  )
}
