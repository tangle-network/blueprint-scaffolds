import { useState, useCallback } from "react"
import type { GameItem, CraftingRecipe } from "@/lib/utils"
import { MOCK_ITEMS, MOCK_RECIPES } from "@/lib/utils"

interface InventoryState {
  items: GameItem[]
  selectedItems: number[]
  craftingResult: GameItem | null
  isCrafting: boolean
  craftSuccess: boolean | null
}

export function useInventory() {
  const [state, setState] = useState<InventoryState>({
    items: [...MOCK_ITEMS.slice(0, 4)],
    selectedItems: [],
    craftingResult: null,
    isCrafting: false,
    craftSuccess: null,
  })

  const toggleItem = useCallback((itemId: number) => {
    setState((prev) => ({
      ...prev,
      selectedItems: prev.selectedItems.includes(itemId)
        ? prev.selectedItems.filter((id) => id !== itemId)
        : prev.selectedItems.length < 2
          ? [...prev.selectedItems, itemId]
          : prev.selectedItems,
    }))
  }, [])

  const craft = useCallback(() => {
    setState((prev) => {
      if (prev.selectedItems.length !== 2) return prev

      const recipe = MOCK_RECIPES.find((r) => {
        const sorted1 = [...r.inputs].sort()
        const sorted2 = [...prev.selectedItems].sort()
        return sorted1.length === sorted2.length && sorted1.every((v, i) => v === sorted2[i])
      })

      if (!recipe) return { ...prev, craftSuccess: false, craftingResult: null }

      const roll = Math.random()
      const success = roll <= recipe.successRate

      const newItems = success
        ? [
            ...prev.items.filter((i) => !prev.selectedItems.includes(i.id)),
            recipe.output,
          ]
        : prev.items

      return {
        items: newItems,
        selectedItems: [],
        craftingResult: success ? recipe.output : null,
        isCrafting: false,
        craftSuccess: success,
      }
    })
  }, [])

  const clearResult = useCallback(() => {
    setState((prev) => ({ ...prev, craftingResult: null, craftSuccess: null }))
  }, [])

  return { ...state, toggleItem, craft, clearResult }
}
