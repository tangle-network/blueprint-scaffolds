import { useState, useCallback } from "react"
import { ARBITRUM_SEPOLIA } from "@/contracts/config"

interface WalletState {
  address: string | null
  isConnected: boolean
  chainId: string | null
  isConnecting: boolean
}

export function useWallet() {
  const [wallet, setWallet] = useState<WalletState>({
    address: null,
    isConnected: false,
    chainId: null,
    isConnecting: false,
  })

  const connect = useCallback(async () => {
    if (typeof window === "undefined" || !window.ethereum) {
      console.error("No wallet provider found")
      return
    }

    setWallet((prev) => ({ ...prev, isConnecting: true }))
    try {
      const accounts = await window.ethereum.request({
        method: "eth_requestAccounts",
      })
      const chainId = await window.ethereum.request({ method: "eth_chainId" })

      if (chainId !== ARBITRUM_SEPOLIA.chainId) {
        try {
          await window.ethereum.request({
            method: "wallet_switchEthereumChain",
            params: [{ chainId: ARBITRUM_SEPOLIA.chainId }],
          })
        } catch {
          await window.ethereum.request({
            method: "wallet_addEthereumChain",
            params: [ARBITRUM_SEPOLIA],
          })
        }
      }

      setWallet({
        address: accounts[0],
        isConnected: true,
        chainId: ARBITRUM_SEPOLIA.chainId,
        isConnecting: false,
      })
    } catch {
      setWallet((prev) => ({ ...prev, isConnecting: false }))
    }
  }, [])

  const disconnect = useCallback(() => {
    setWallet({
      address: null,
      isConnected: false,
      chainId: null,
      isConnecting: false,
    })
  }, [])

  return { ...wallet, connect, disconnect }
}
