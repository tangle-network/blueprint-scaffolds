import { useState, useCallback } from "react"
import type { GameItem, GameSession, GameState } from "@/lib/utils"

const EMPTY_GRID = Array(8)
  .fill(null)
  .map(() => Array(8).fill(null))

interface CellData {
  type: "player" | "enemy" | "item" | "wall" | null
  icon: string
}

interface GameEngineState {
  grid: (CellData | null)[][]
  playerPos: { x: number; y: number }
  enemyPos: { x: number; y: number }
  playerHp: number
  enemyHp: number
  playerMaxHp: number
  enemyMaxHp: number
  turn: number
  isPlayerTurn: boolean
  gameOver: boolean
  winner: string | null
  log: string[]
  sessionId: string | null
  isSearching: boolean
}

export function useGame() {
  const [state, setState] = useState<GameEngineState>({
    grid: EMPTY_GRID.map((row, y) =>
      row.map((_, x) => {
        if (x === 1 && y === 1) return { type: "player" as const, icon: "🧙" }
        if (x === 6 && y === 6) return { type: "enemy" as const, icon: "👹" }
        if (x === 3 && y === 3) return { type: "item" as const, icon: "💎" }
        if (x === 5 && y === 2) return { type: "item" as const, icon: "🗡️" }
        if ((x === 4 && y === 1) || (x === 2 && y === 5))
          return { type: "wall" as const, icon: "🧱" }
        return null
      })
    ),
    playerPos: { x: 1, y: 1 },
    enemyPos: { x: 6, y: 6 },
    playerHp: 100,
    enemyHp: 100,
    playerMaxHp: 100,
    enemyMaxHp: 100,
    turn: 0,
    isPlayerTurn: true,
    gameOver: false,
    winner: null,
    log: ["Game initialized. Your turn!"],
    sessionId: null,
    isSearching: false,
  })

  const movePlayer = useCallback(
    (dx: number, dy: number) => {
      setState((prev) => {
        if (!prev.isPlayerTurn || prev.gameOver) return prev

        const nx = prev.playerPos.x + dx
        const ny = prev.playerPos.y + dy
        if (nx < 0 || nx >= 8 || ny < 0 || ny >= 8) return prev

        const target = prev.grid[ny][nx]
        const newGrid = prev.grid.map((r) => r.map((c) => (c ? { ...c } : null)))
        const newLog = [...prev.log]
        let playerHp = prev.playerHp
        let enemyHp = prev.enemyHp
        let gameOver = false
        let winner: string | null = null

        if (target?.type === "wall") return prev

        newGrid[prev.playerPos.y][prev.playerPos.x] = null

        if (target?.type === "enemy") {
          const dmg = 15 + Math.floor(Math.random() * 20)
          enemyHp = Math.max(0, prev.enemyHp - dmg)
          newLog.push(`You attack for ${dmg} damage!`)
          newGrid[prev.playerPos.y][prev.playerPos.x] = { type: "player", icon: "🧙" }

          if (enemyHp <= 0) {
            gameOver = true
            winner = "player"
            newLog.push("Victory! Enemy defeated!")
            newGrid[prev.enemyPos.y][prev.enemyPos.x] = null
          }
        } else if (target?.type === "item") {
          newLog.push(`Picked up ${target.icon}!`)
          newGrid[ny][nx] = { type: "player", icon: "🧙" }
        } else {
          newGrid[ny][nx] = { type: "player", icon: "🧙" }
        }

        return {
          ...prev,
          grid: newGrid,
          playerPos: target?.type === "enemy" ? prev.playerPos : { x: nx, y: ny },
          playerHp,
          enemyHp,
          turn: prev.turn + 1,
          isPlayerTurn: gameOver ? false : false,
          gameOver,
          winner,
          log: newLog,
        }
      })

      setTimeout(() => {
        setState((prev) => {
          if (prev.gameOver) return prev
          const newLog = [...prev.log]
          const moves = [
            { dx: 0, dy: -1 },
            { dx: 0, dy: 1 },
            { dx: -1, dy: 0 },
            { dx: 1, dy: 0 },
          ]
          const move = moves[Math.floor(Math.random() * moves.length)]
          let ex = prev.enemyPos.x + move.dx
          let ey = prev.enemyPos.y + move.dy
          ex = Math.max(0, Math.min(7, ex))
          ey = Math.max(0, Math.min(7, ey))

          const newGrid = prev.grid.map((r) => r.map((c) => (c ? { ...c } : null)))
          let playerHp = prev.playerHp

          const dist = Math.abs(ex - prev.playerPos.x) + Math.abs(ey - prev.playerPos.y)
          if (dist <= 1) {
            const dmg = 10 + Math.floor(Math.random() * 15)
            playerHp = Math.max(0, prev.playerHp - dmg)
            newLog.push(`Enemy attacks for ${dmg} damage!`)
            if (playerHp <= 0) {
              newLog.push("Defeated! You lost this round.")
              newGrid[prev.enemyPos.y][prev.enemyPos.x] = null
              newGrid[ey][ex] = { type: "enemy", icon: "👹" }
              return {
                ...prev,
                grid: newGrid,
                playerHp,
                enemyPos: { x: ex, y: ey },
                turn: prev.turn + 1,
                isPlayerTurn: false,
                gameOver: true,
                winner: "enemy",
                log: newLog,
              }
            }
          } else {
            newGrid[prev.enemyPos.y][prev.enemyPos.x] = null
            newGrid[ey][ex] = { type: "enemy", icon: "👹" }
          }

          return {
            ...prev,
            grid: newGrid,
            playerHp,
            enemyPos: { x: ex, y: ey },
            turn: prev.turn + 1,
            isPlayerTurn: true,
            log: newLog,
          }
        })
      }, 800)
    },
    []
  )

  const startSession = useCallback((sessionId: string) => {
    setState((prev) => ({ ...prev, sessionId, gameOver: false, winner: null, turn: 0, log: ["Match started! Your turn."] }))
  }, [])

  const resetGame = useCallback(() => {
    setState((prev) => ({
      ...prev,
      grid: EMPTY_GRID.map((row, y) =>
        row.map((_, x) => {
          if (x === 1 && y === 1) return { type: "player" as const, icon: "🧙" }
          if (x === 6 && y === 6) return { type: "enemy" as const, icon: "👹" }
          if (x === 3 && y === 3) return { type: "item" as const, icon: "💎" }
          if (x === 5 && y === 2) return { type: "item" as const, icon: "🗡️" }
          if ((x === 4 && y === 1) || (x === 2 && y === 5))
            return { type: "wall" as const, icon: "🧱" }
          return null
        })
      ),
      playerPos: { x: 1, y: 1 },
      enemyPos: { x: 6, y: 6 },
      playerHp: 100,
      enemyHp: 100,
      turn: 0,
      isPlayerTurn: true,
      gameOver: false,
      winner: null,
      log: ["Game reset. Your turn!"],
    }))
  }, [])

  return { state, movePlayer, startSession, resetGame }
}
