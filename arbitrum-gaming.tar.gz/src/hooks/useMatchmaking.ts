import { useState, useCallback, useEffect, useRef } from "react"

interface MatchmakingState {
  isInQueue: boolean
  queueSize: number
  estimatedWait: number
  opponent: string | null
  gameId: string | null
  matchFound: boolean
}

export function useMatchmaking() {
  const [state, setState] = useState<MatchmakingState>({
    isInQueue: false,
    queueSize: 0,
    estimatedWait: 0,
    opponent: null,
    gameId: null,
    matchFound: false,
  })

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const joinQueue = useCallback(() => {
    setState((prev) => ({
      ...prev,
      isInQueue: true,
      queueSize: Math.floor(Math.random() * 20) + 5,
      estimatedWait: Math.floor(Math.random() * 30) + 10,
    }))
  }, [])

  const leaveQueue = useCallback(() => {
    setState((prev) => ({
      ...prev,
      isInQueue: false,
      queueSize: 0,
      estimatedWait: 0,
      opponent: null,
      gameId: null,
      matchFound: false,
    }))
    if (timerRef.current) {
      clearInterval(timerRef.current)
      timerRef.current = null
    }
  }, [])

  useEffect(() => {
    if (state.isInQueue && !state.matchFound) {
      timerRef.current = setInterval(() => {
        setState((prev) => {
          if (prev.matchFound) return prev
          const waitReduction = Math.max(0, prev.estimatedWait - 1)
          if (waitReduction <= 0 && Math.random() > 0.5) {
            return {
              ...prev,
              matchFound: true,
              opponent: "0x" + Array.from({ length: 8 }, () => Math.floor(Math.random() * 16).toString(16)).join("") + "...",
              gameId: "game-" + Math.random().toString(36).slice(2, 10),
              isInQueue: false,
            }
          }
          return { ...prev, estimatedWait: waitReduction }
        })
      }, 1000)

      return () => {
        if (timerRef.current) clearInterval(timerRef.current)
      }
    }
  }, [state.isInQueue, state.matchFound])

  return { ...state, joinQueue, leaveQueue }
}
