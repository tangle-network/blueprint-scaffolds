import { NavLink, Outlet } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { useWallet } from "@/hooks/useWallet"
import { formatAddress } from "@/lib/utils"
import { Gamepad2, Swords, Backpack, Users, Trophy, Wallet } from "lucide-react"

const navItems = [
  { to: "/", label: "Home", icon: Gamepad2 },
  { to: "/game", label: "Arena", icon: Swords },
  { to: "/inventory", label: "Inventory", icon: Backpack },
  { to: "/lobby", label: "Lobby", icon: Users },
  { to: "/leaderboard", label: "Ranks", icon: Trophy },
]

export function Layout() {
  const { address, isConnected, connect, disconnect } = useWallet()

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="border-b border-border/50 bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="gradient-arb w-8 h-8 rounded-lg flex items-center justify-center">
              <Swords className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
              ChainArena
            </span>
            <span className="text-xs text-muted-foreground ml-1 hidden sm:inline">on Arbitrum</span>
          </div>

          <nav className="flex items-center gap-1">
            {navItems.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                end={to === "/"}
                className={({ isActive }) =>
                  `flex items-center gap-1.5 px-3 py-2 rounded-md text-sm transition-colors ${
                    isActive
                      ? "bg-primary/10 text-primary"
                      : "text-muted-foreground hover:text-foreground hover:bg-accent"
                  }`
                }
              >
                <Icon className="w-4 h-4" />
                <span className="hidden md:inline">{label}</span>
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            {isConnected ? (
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-secondary text-sm">
                  <div className="w-2 h-2 rounded-full bg-green-500" />
                  <span>{formatAddress(address!)}</span>
                </div>
                <Button variant="ghost" size="sm" onClick={disconnect}>
                  Disconnect
                </Button>
              </div>
            ) : (
              <Button onClick={connect} size="sm" className="gradient-arb text-white border-0">
                <Wallet className="w-4 h-4 mr-1.5" />
                Connect Wallet
              </Button>
            )}
          </div>
        </div>
      </header>

      <main className="flex-1">
        <Outlet />
      </main>

      <footer className="border-t border-border/50 py-4 text-center text-sm text-muted-foreground">
        <p>ChainArena — Fully On-Chain Gaming on Arbitrum Stylus</p>
      </footer>
    </div>
  )
}
