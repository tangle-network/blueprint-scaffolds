import { Button } from "@/components/ui/button"
import { ArrowUp, ArrowDown, ArrowLeft, ArrowRight } from "lucide-react"

interface GameControlsProps {
  onMove: (dx: number, dy: number) => void
  disabled: boolean
}

export function GameControls({ onMove, disabled }: GameControlsProps) {
  return (
    <div className="flex flex-col items-center gap-1">
      <p className="text-sm text-muted-foreground mb-2">
        {disabled ? "Wait for enemy..." : "Use arrow keys or buttons to move"}
      </p>
      <div className="grid grid-cols-3 gap-1 w-36">
        <div />
        <Button
          variant="outline"
          size="icon"
          disabled={disabled}
          onClick={() => onMove(0, -1)}
        >
          <ArrowUp className="w-4 h-4" />
        </Button>
        <div />
        <Button
          variant="outline"
          size="icon"
          disabled={disabled}
          onClick={() => onMove(-1, 0)}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <Button
          variant="outline"
          size="icon"
          disabled={disabled}
          onClick={() => onMove(0, 1)}
        >
          <ArrowDown className="w-4 h-4" />
        </Button>
        <Button
          variant="outline"
          size="icon"
          disabled={disabled}
          onClick={() => onMove(1, 0)}
        >
          <ArrowRight className="w-4 h-4" />
        </Button>
      </div>
    </div>
  )
}
