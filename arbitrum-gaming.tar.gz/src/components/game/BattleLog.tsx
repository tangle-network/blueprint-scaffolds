import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollText } from "lucide-react"

interface BattleLogProps {
  log: string[]
}

export function BattleLog({ log }: BattleLogProps) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm flex items-center gap-2">
          <ScrollText className="w-4 h-4 text-blue-400" />
          Battle Log
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-1 max-h-48 overflow-y-auto">
          {log.map((entry, i) => (
            <p
              key={i}
              className={`text-xs ${
                i === log.length - 1 ? "text-foreground font-medium" : "text-muted-foreground"
              }`}
            >
              <span className="text-muted-foreground mr-1">[{i + 1}]</span>
              {entry}
            </p>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
