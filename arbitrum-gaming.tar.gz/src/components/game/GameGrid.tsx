interface CellData {
  type: "player" | "enemy" | "item" | "wall" | null
  icon: string
}

interface GameGridProps {
  grid: (CellData | null)[][]
}

export function GameGrid({ grid }: GameGridProps) {
  return (
    <div className="game-grid max-w-md mx-auto border border-border rounded-lg overflow-hidden bg-card">
      {grid.map((row, y) =>
        row.map((cell, x) => (
          <div
            key={`${x}-${y}`}
            className={`w-full aspect-square flex items-center justify-center text-lg ${
              cell?.type === "wall"
                ? "bg-muted"
                : cell?.type === "player"
                  ? "bg-blue-500/10"
                  : cell?.type === "enemy"
                    ? "bg-red-500/10"
                    : cell?.type === "item"
                      ? "bg-yellow-500/10"
                      : "bg-background"
            } border border-border/30`}
          >
            {cell?.icon || ""}
          </div>
        ))
      )}
    </div>
  )
}
