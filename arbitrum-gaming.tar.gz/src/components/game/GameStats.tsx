import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart3 } from "lucide-react"

interface GameEngineState {
  turn: number
  playerHp: number
  enemyHp: number
  playerMaxHp: number
  enemyMaxHp: number
  isPlayerTurn: boolean
  gameOver: boolean
  winner: string | null
}

interface GameStatsProps {
  state: GameEngineState
}

export function GameStats({ state }: GameStatsProps) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm flex items-center gap-2">
          <BarChart3 className="w-4 h-4 text-blue-400" />
          Stats
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div className="p-2 rounded bg-secondary">
            <p className="text-xs text-muted-foreground">Turn</p>
            <p className="font-bold">{state.turn}</p>
          </div>
          <div className="p-2 rounded bg-secondary">
            <p className="text-xs text-muted-foreground">Status</p>
            <p className="font-bold">
              {state.gameOver
                ? state.winner === "player"
                  ? "Victory"
                  : "Defeat"
                : state.isPlayerTurn
                  ? "Your Turn"
                  : "Enemy Turn"}
            </p>
          </div>
          <div className="p-2 rounded bg-secondary">
            <p className="text-xs text-muted-foreground">Player HP</p>
            <p className="font-bold text-blue-400">
              {state.playerHp}/{state.playerMaxHp}
            </p>
          </div>
          <div className="p-2 rounded bg-secondary">
            <p className="text-xs text-muted-foreground">Enemy HP</p>
            <p className="font-bold text-red-400">
              {state.enemyHp}/{state.enemyMaxHp}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
