import * as React from "react"
import { cn } from "@/lib/utils"

const Badge = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement> & {
  variant?: "default" | "secondary" | "destructive" | "outline" | "legendary" | "epic" | "rare" | "common"
}>(({ className, variant = "default", ...props }, ref) => {
  const variants: Record<string, string> = {
    default: "border-transparent bg-primary text-primary-foreground shadow",
    secondary: "border-transparent bg-secondary text-secondary-foreground",
    destructive: "border-transparent bg-destructive text-destructive-foreground shadow",
    outline: "text-foreground",
    legendary: "border-game-gold/50 bg-game-gold/20 text-game-gold",
    epic: "border-arb-purple/50 bg-arb-purple/20 text-arb-purple",
    rare: "border-arb-blue/50 bg-arb-blue/20 text-arb-blue",
    common: "border-game-green/50 bg-game-green/20 text-game-green",
  }
  return (
    <div
      ref={ref}
      className={cn(
        "inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors",
        variants[variant],
        className
      )}
      {...props}
    />
  )
})
Badge.displayName = "Badge"

export { Badge }
