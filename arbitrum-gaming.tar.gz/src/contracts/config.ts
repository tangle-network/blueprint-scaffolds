export const ARBITRUM_SEPOLIA = {
  chainId: "0x66eee",
  chainName: "Arbitrum Sepolia",
  rpcUrls: ["https://sepolia-rollup.arbitrum.io/rpc"],
  blockExplorerUrls: ["https://sepolia-explorer.arbitrum.io"],
  nativeCurrency: { name: "Ethereum", symbol: "ETH", decimals: 18 },
} as const

export const CONTRACTS = {
  gameEngine: "0x0000000000000000000000000000000000000000",
  assetManager: "0x0000000000000000000000000000000000000000",
  matchmaking: "0x0000000000000000000000000000000000000000",
  randomness: "0x0000000000000000000000000000000000000000",
} as const

export const GAME_ENGINE_ABI = [
  "function createGame(address opponent) external returns (uint256)",
  "function submitMove(uint256 gameId, uint8 moveType, bytes calldata data) external",
  "function resolveGame(uint256 gameId) external",
  "function getGameState(uint256 gameId) external view returns (uint8 state, address player1, address player2, address winner)",
  "function getPlayerStats(address player) external view returns (uint256 wins, uint256 losses, uint256 elo)",
  "function requestRandomness(uint256 gameId) external returns (uint256 requestId)",
  "event GameCreated(uint256 indexed gameId, address indexed player1, address indexed player2)",
  "event MoveSubmitted(uint256 indexed gameId, address indexed player, uint8 moveType)",
  "event GameResolved(uint256 indexed gameId, address indexed winner)",
  "event RandomnessFulfilled(uint256 indexed requestId, uint256 randomness)",
] as const

export const ASSET_MANAGER_ABI = [
  "function mintItem(address to, uint256 itemTemplateId) external",
  "function transferItem(address from, address to, uint256 tokenId) external",
  "function craftItems(uint256[] calldata inputTokenIds, uint256 recipeId) external returns (uint256 outputTokenId)",
  "function getInventory(address player) external view returns (uint256[] memory tokenIds)",
  "function getItemMetadata(uint256 tokenId) external view returns (string name, string description, uint8 rarity, uint256 attack, uint256 defense, uint256 magic)",
  "function getCraftingRecipes() external view returns (uint256[] memory recipeIds)",
  "event ItemMinted(address indexed to, uint256 indexed tokenId, uint256 templateId)",
  "event ItemsCrafted(address indexed crafter, uint256 outputTokenId, uint256 recipeId)",
  "event ItemTransferred(address indexed from, address indexed to, uint256 tokenId)",
] as const

export const MATCHMAKING_ABI = [
  "function joinQueue() external",
  "function leaveQueue() external",
  "function findMatch(address player) external view returns (address opponent, bool found)",
  "function getQueueSize() external view returns (uint256)",
  "function createSessionKey(address sessionKey, uint256 expiry, uint256[] calldata allowedMethods) external",
  "function revokeSessionKey(address sessionKey) external",
  "function isSessionKeyValid(address sessionKey) external view returns (bool valid, uint256 expiry)",
  "event PlayerJoinedQueue(address indexed player, uint256 elo)",
  "event PlayerLeftQueue(address indexed player)",
  "event MatchFound(address indexed player1, address indexed player2, uint256 gameId)",
  "event SessionKeyCreated(address indexed owner, address indexed sessionKey, uint256 expiry)",
] as const
