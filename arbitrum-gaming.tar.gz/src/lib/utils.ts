import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatAddress(address: string): string {
  return `${address.slice(0, 6)}...${address.slice(-4)}`
}

export function formatEther(wei: bigint): string {
  const eth = Number(wei) / 1e18
  return eth.toFixed(4)
}

export type ItemRarity = "common" | "uncommon" | "rare" | "epic" | "legendary"

export const RARITY_COLORS: Record<ItemRarity, string> = {
  common: "text-gray-400 border-gray-400",
  uncommon: "text-green-400 border-green-400",
  rare: "text-blue-400 border-blue-400",
  epic: "text-purple-400 border-purple-400",
  legendary: "text-yellow-400 border-yellow-400",
}

export const RARITY_BG: Record<ItemRarity, string> = {
  common: "bg-gray-400/10",
  uncommon: "bg-green-400/10",
  rare: "bg-blue-400/10",
  epic: "bg-purple-400/10",
  legendary: "bg-yellow-400/10",
}

export interface GameItem {
  id: number
  name: string
  description: string
  rarity: ItemRarity
  attack?: number
  defense?: number
  magic?: number
  icon: string
}

export interface Player {
  address: string
  username: string
  level: number
  xp: number
  wins: number
  losses: number
  elo: number
}

export interface GameSession {
  id: string
  players: [string, string]
  state: GameState
  winner?: string
  createdAt: number
}

export type GameState = "waiting" | "active" | "completed"

export interface MatchEntry {
  id: string
  player1: string
  player2: string
  result: "win" | "loss" | "draw"
  eloChange: number
  timestamp: number
}

export interface LeaderboardEntry {
  rank: number
  player: string
  username: string
  elo: number
  wins: number
  losses: number
}

export interface CraftingRecipe {
  id: number
  name: string
  inputs: number[]
  output: GameItem
  successRate: number
}

export const MOCK_ITEMS: GameItem[] = [
  { id: 1, name: "Iron Sword", description: "A sturdy iron blade", rarity: "common", attack: 5, icon: "⚔️" },
  { id: 2, name: "Wooden Shield", description: "Basic wooden protection", rarity: "common", defense: 3, icon: "🛡️" },
  { id: 3, name: "Fire Staff", description: "Channels fire magic", rarity: "uncommon", magic: 8, icon: "🪄" },
  { id: 4, name: "Steel Helm", description: "Forged steel helmet", rarity: "uncommon", defense: 7, icon: "⛑️" },
  { id: 5, name: "Dragon Blade", description: "Forged from dragon scales", rarity: "rare", attack: 15, defense: 5, icon: "🗡️" },
  { id: 6, name: "Crystal Orb", description: "Contains arcane power", rarity: "rare", magic: 12, icon: "🔮" },
  { id: 7, name: "Void Armor", description: "Absorbs all damage types", rarity: "epic", defense: 20, icon: "🛡️" },
  { id: 8, name: "Phoenix Staff", description: "Resurrects its wielder", rarity: "legendary", magic: 25, attack: 10, icon: "✨" },
]

export const MOCK_RECIPES: CraftingRecipe[] = [
  { id: 1, name: "Forge Steel Sword", inputs: [1, 2], output: { id: 5, name: "Dragon Blade", description: "Forged from dragon scales", rarity: "rare", attack: 15, defense: 5, icon: "🗡️" }, successRate: 0.7 },
  { id: 2, name: "Enchant Crystal", inputs: [3, 6], output: { id: 8, name: "Phoenix Staff", description: "Resurrects its wielder", rarity: "legendary", magic: 25, attack: 10, icon: "✨" }, successRate: 0.3 },
  { id: 3, name: "Reinforce Armor", inputs: [2, 4], output: { id: 7, name: "Void Armor", description: "Absorbs all damage types", rarity: "epic", defense: 20, icon: "🛡️" }, successRate: 0.5 },
]

export const MOCK_LEADERBOARD: LeaderboardEntry[] = [
  { rank: 1, player: "0x1234...5678", username: "DragonSlayer", elo: 2400, wins: 150, losses: 20 },
  { rank: 2, player: "0xabcd...ef01", username: "ArcaneMage", elo: 2350, wins: 130, losses: 30 },
  { rank: 3, player: "0x9876...5432", username: "ShadowKnight", elo: 2200, wins: 110, losses: 45 },
  { rank: 4, player: "0xdef0...1234", username: "PhoenixRider", elo: 2100, wins: 95, losses: 55 },
  { rank: 5, player: "0x4567...89ab", username: "IronGuard", elo: 2050, wins: 90, losses: 60 },
  { rank: 6, player: "0xcdef...0123", username: "StormCaller", elo: 1980, wins: 80, losses: 70 },
  { rank: 7, player: "0x2468...ace0", username: "VoidWalker", elo: 1920, wins: 75, losses: 75 },
  { rank: 8, player: "0x1357...bdf9", username: "CrystalSage", elo: 1850, wins: 65, losses: 80 },
  { rank: 9, player: "0x9753...eca1", username: "BladeMaster", elo: 1800, wins: 60, losses: 85 },
  { rank: 10, player: "0xfedc...ba98", username: "FireWielder", elo: 1750, wins: 55, losses: 90 },
]
