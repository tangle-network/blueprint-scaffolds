import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatAddress(address: string): string {
  return `${address.slice(0, 6)}...${address.slice(-4)}`
}

export function formatEther(wei: bigint): string {
  const eth = Number(wei) / 1e18
  return eth.toFixed(4)
}

export type {
  ItemRarity,
  GameItem,
  Player,
  GameSession,
  GameState,
  MatchEntry,
  LeaderboardEntry,
  CraftingRecipe,
  CellData,
  GameEngineState,
  WalletState,
  InventoryState,
  MatchmakingState,
} from "./types"

export {
  RARITY_COLORS,
  RARITY_BG,
  MOCK_ITEMS,
  MOCK_RECIPES,
  MOCK_LEADERBOARD,
} from "./types"
