# Arbitrum On-Chain Gaming Infrastructure

Monorepo for a fully on-chain gaming stack on Arbitrum with Stylus-oriented Rust contracts and a Vite + React control surface.

## Packages

- `contracts/engine-core`: turn resolution, leaderboard state, verifiable randomness flow.
- `contracts/asset-management`: NFT-style items, loot drops, crafting and combining recipes.
- `contracts/matchmaking`: queue state, session keys, and match creation logic.
- `web-client`: lobby, inventory, crafting, matchmaking, and leaderboard UI.

## Build

```bash
pnpm install
pnpm build
```
