"use client";

import type { StateGraph } from "@/types";
import { cn } from "@/lib/utils";

interface StateGraphViewProps {
  graph: StateGraph;
  currentNode?: string;
}

const NODE_COLORS: Record<string, string> = {
  router: "fill-blue-100 stroke-blue-500 dark:fill-blue-900 dark:stroke-blue-400",
  agent: "fill-green-100 stroke-green-500 dark:fill-green-900 dark:stroke-green-400",
  tool: "fill-orange-100 stroke-orange-500 dark:fill-orange-900 dark:stroke-orange-400",
  evaluator: "fill-purple-100 stroke-purple-500 dark:fill-purple-900 dark:stroke-purple-400",
};

const NODE_TEXT: Record<string, string> = {
  router: "fill-blue-700 dark:fill-blue-200",
  agent: "fill-green-700 dark:fill-green-200",
  tool: "fill-orange-700 dark:fill-orange-200",
  evaluator: "fill-purple-700 dark:fill-purple-200",
};

const NODE_W = 140;
const NODE_H = 50;
const H_GAP = 80;
const V_GAP = 80;

function layoutNodes(graph: StateGraph) {
  const positions = new Map<string, { x: number; y: number }>();
  const visited = new Set<string>();
  const queue = [graph.entryNode];
  const levels = new Map<string, number>();
  levels.set(graph.entryNode, 0);
  let maxLevel = 0;

  while (queue.length > 0) {
    const id = queue.shift()!;
    if (visited.has(id)) continue;
    visited.add(id);
    const level = levels.get(id) ?? 0;
    const edges = graph.edges.filter((e) => e.source === id);
    for (const edge of edges) {
      if (!levels.has(edge.target) || levels.get(edge.target)! < level + 1) {
        levels.set(edge.target, level + 1);
      }
      queue.push(edge.target);
      maxLevel = Math.max(maxLevel, level + 1);
    }
  }

  const byLevel = new Map<number, string[]>();
  const levelEntries = Array.from(levels.entries());
  for (const [nodeId, lvl] of levelEntries) {
    if (!byLevel.has(lvl)) byLevel.set(lvl, []);
    byLevel.get(lvl)!.push(nodeId);
  }

  const byLevelEntries = Array.from(byLevel.entries());
  for (const [lvl, nodeIds] of byLevelEntries) {
    const totalWidth = nodeIds.length * NODE_W + (nodeIds.length - 1) * H_GAP;
    const startX = (maxLevel * (NODE_W + H_GAP)) / 2 - totalWidth / 2 + NODE_W / 2;
    nodeIds.forEach((nid: string, i: number) => {
      positions.set(nid, {
        x: startX + i * (NODE_W + H_GAP),
        y: lvl * (NODE_H + V_GAP) + NODE_H / 2 + 40,
      });
    });
  }

  return { positions, width: Math.max(600, (maxLevel + 1) * (NODE_W + H_GAP)), height: (maxLevel + 1) * (NODE_H + V_GAP) + 80 };
}

export function StateGraphView({ graph, currentNode }: StateGraphViewProps) {
  const { positions, width, height } = layoutNodes(graph);

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full min-h-[300px]" style={{ maxHeight: 500 }}>
      <defs>
        <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="10" refY="3.5" orient="auto">
          <polygon points="0 0, 10 3.5, 0 7" className="fill-muted-foreground" />
        </marker>
        <filter id="glow">
          <feGaussianBlur stdDeviation="3" result="coloredBlur" />
          <feMerge>
            <feMergeNode in="coloredBlur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {graph.edges.map((edge, i) => {
        const from = positions.get(edge.source);
        const to = positions.get(edge.target);
        if (!from || !to) return null;
        const sx = from.x;
        const sy = from.y + NODE_H / 2;
        const ex = to.x;
        const ey = to.y - NODE_H / 2;
        const mx = (sx + ex) / 2;
        return (
          <g key={`edge-${i}`}>
            <path
              d={`M ${sx} ${sy} C ${sx} ${sy + V_GAP / 2}, ${ex} ${ey - V_GAP / 2}, ${ex} ${ey}`}
              stroke="currentColor"
              strokeWidth={1.5}
              fill="none"
              className="text-muted-foreground/40"
              markerEnd="url(#arrowhead)"
            />
            {edge.label && (
              <text x={mx} y={(sy + ey) / 2 + 4} textAnchor="middle" className="fill-muted-foreground text-[10px]">
                {edge.label}
              </text>
            )}
          </g>
        );
      })}

      {graph.nodes.map((node) => {
        const pos = positions.get(node.id);
        if (!pos) return null;
        const isActive = node.id === currentNode;
        return (
          <g key={node.id}>
            <rect
              x={pos.x - NODE_W / 2}
              y={pos.y - NODE_H / 2}
              width={NODE_W}
              height={NODE_H}
              rx={8}
              className={cn(
                NODE_COLORS[node.type],
                isActive && "stroke-[3px]",
                isActive && "animate-pulse"
              )}
              filter={isActive ? "url(#glow)" : undefined}
            />
            <text x={pos.x} y={pos.y + 5} textAnchor="middle" className={cn("text-xs font-medium", NODE_TEXT[node.type])}>
              {node.label}
            </text>
          </g>
        );
      })}
    </svg>
  );
}
