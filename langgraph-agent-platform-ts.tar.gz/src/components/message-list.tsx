"use client";

import { ScrollArea } from "@/components/ui/scroll-area";
import type { AgentMessage } from "@/types";
import { cn } from "@/lib/utils";
import { Bot, User, Wrench, FileText } from "lucide-react";

interface MessageListProps {
  messages: AgentMessage[];
}

const ROLE_STYLES: Record<string, string> = {
  system: "bg-muted border-border",
  user: "bg-blue-50 border-blue-200 dark:bg-blue-950 dark:border-blue-800",
  assistant: "bg-green-50 border-green-200 dark:bg-green-950 dark:border-green-800",
  tool: "bg-orange-50 border-orange-200 dark:bg-orange-950 dark:border-orange-800",
};

const ROLE_ICONS: Record<string, React.ReactNode> = {
  system: <FileText className="h-4 w-4" />,
  user: <User className="h-4 w-4" />,
  assistant: <Bot className="h-4 w-4" />,
  tool: <Wrench className="h-4 w-4" />,
};

export function MessageList({ messages }: MessageListProps) {
  if (messages.length === 0) {
    return <div className="flex items-center justify-center h-40 text-muted-foreground text-sm">No messages yet</div>;
  }

  return (
    <ScrollArea className="h-[400px]">
      <div className="space-y-3 p-2">
        {messages.map((msg) => (
          <div key={msg.id} className={cn("rounded-lg border p-3", ROLE_STYLES[msg.role])}>
            <div className="flex items-center gap-2 mb-1">
              {ROLE_ICONS[msg.role]}
              <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{msg.role}</span>
              <span className="text-xs text-muted-foreground ml-auto">{new Date(msg.timestamp).toLocaleTimeString()}</span>
            </div>
            <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
            {msg.toolCalls && msg.toolCalls.length > 0 && (
              <div className="mt-2 space-y-1">
                {msg.toolCalls.map((tc) => (
                  <div key={tc.id} className="bg-background/50 rounded p-2 text-xs font-mono">
                    <span className="font-bold">{tc.name}</span>
                    <span className="text-muted-foreground ml-2">{JSON.stringify(tc.arguments)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </ScrollArea>
  );
}
