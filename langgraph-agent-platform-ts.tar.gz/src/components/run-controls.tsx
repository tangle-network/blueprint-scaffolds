"use client";

import { Button } from "@/components/ui/button";
import type { Run } from "@/types";
import { Play, Pause, X, RotateCcw } from "lucide-react";

interface RunControlsProps {
  run: Run;
  onAction: (action: string) => void;
}

export function RunControls({ run, onAction }: RunControlsProps) {
  const status = run.status;

  return (
    <div className="flex items-center gap-2">
      {(status === "idle" || status === "paused") && (
        <Button size="sm" onClick={() => onAction("resume")}>
          <Play className="h-4 w-4 mr-1" />
          {status === "paused" ? "Resume" : "Start"}
        </Button>
      )}
      {status === "running" && (
        <Button size="sm" variant="outline" onClick={() => onAction("pause")}>
          <Pause className="h-4 w-4 mr-1" />
          Pause
        </Button>
      )}
      {(status === "running" || status === "paused") && (
        <Button size="sm" variant="destructive" onClick={() => onAction("cancel")}>
          <X className="h-4 w-4 mr-1" />
          Cancel
        </Button>
      )}
      {(status === "completed" || status === "failed" || status === "cancelled") && (
        <Button size="sm" variant="outline" onClick={() => onAction("retry")}>
          <RotateCcw className="h-4 w-4 mr-1" />
          Retry
        </Button>
      )}
    </div>
  );
}
