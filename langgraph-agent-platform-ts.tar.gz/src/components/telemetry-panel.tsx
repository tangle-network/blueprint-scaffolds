"use client";

import { ScrollArea } from "@/components/ui/scroll-area";
import type { TelemetryEvent } from "@/types";
import { cn } from "@/lib/utils";

interface TelemetryPanelProps {
  events: TelemetryEvent[];
}

const TYPE_COLORS: Record<string, string> = {
  node_enter: "text-blue-600 dark:text-blue-400",
  node_exit: "text-blue-600 dark:text-blue-400",
  tool_call: "text-orange-600 dark:text-orange-400",
  tool_result: "text-orange-600 dark:text-orange-400",
  evaluator: "text-purple-600 dark:text-purple-400",
  error: "text-red-600 dark:text-red-400",
  state_update: "text-green-600 dark:text-green-400",
};

export function TelemetryPanel({ events }: TelemetryPanelProps) {
  if (events.length === 0) {
    return <div className="flex items-center justify-center h-40 text-muted-foreground text-sm">No telemetry events</div>;
  }

  return (
    <ScrollArea className="h-[400px]">
      <div className="space-y-1 p-2 font-mono text-xs">
        {events.map((event) => (
          <div key={event.id} className="flex gap-2 py-1 border-b border-border/50">
            <span className="text-muted-foreground shrink-0">{new Date(event.timestamp).toLocaleTimeString()}</span>
            <span className={cn("font-bold shrink-0 w-28", TYPE_COLORS[event.type] ?? "text-foreground")}>{event.type}</span>
            <span className="text-muted-foreground truncate">{JSON.stringify(event.data)}</span>
          </div>
        ))}
      </div>
    </ScrollArea>
  );
}
