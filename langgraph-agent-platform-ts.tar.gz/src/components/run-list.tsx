"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { Run } from "@/types";
import { cn } from "@/lib/utils";

interface RunListProps {
  runs: Run[];
  onSelectRun: (runId: string) => void;
}

const STATUS_VARIANT: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
  idle: "secondary",
  running: "default",
  paused: "outline",
  completed: "secondary",
  failed: "destructive",
  cancelled: "outline",
};

const STATUS_CLASS: Record<string, string> = {
  running: "border-l-4 border-l-blue-500",
  completed: "border-l-4 border-l-green-500",
  failed: "border-l-4 border-l-red-500",
  paused: "border-l-4 border-l-yellow-500",
};

function getAgentName(agentId: string): string {
  const names: Record<string, string> = {
    "agent-research": "Research Agent",
    "agent-coder": "Code Assistant",
    "agent-support": "Support Agent",
  };
  return names[agentId] ?? agentId;
}

export function RunList({ runs, onSelectRun }: RunListProps) {
  if (runs.length === 0) {
    return (
      <div className="flex items-center justify-center h-40 text-muted-foreground text-sm">
        No runs yet. Select an agent to start.
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {runs.map((run) => (
        <Card
          key={run.id}
          className={cn("cursor-pointer hover:shadow-sm transition-shadow", STATUS_CLASS[run.status])}
          onClick={() => onSelectRun(run.id)}
        >
          <CardHeader className="p-3 pb-1">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-mono">{run.id.slice(0, 8)}</CardTitle>
              <Badge variant={STATUS_VARIANT[run.status]}>{run.status}</Badge>
            </div>
          </CardHeader>
          <CardContent className="p-3 pt-1">
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>{getAgentName(run.agentId)}</span>
              <span>{run.messages.length} messages</span>
              <span>{new Date(run.createdAt).toLocaleTimeString()}</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
