"use client";

import { ScrollArea } from "@/components/ui/scroll-area";
import type { EvaluatorResult } from "@/types";
import { CheckCircle, XCircle } from "lucide-react";

interface EvaluatorResultsProps {
  results: EvaluatorResult[];
}

export function EvaluatorResults({ results }: EvaluatorResultsProps) {
  if (results.length === 0) {
    return <div className="flex items-center justify-center h-40 text-muted-foreground text-sm">No evaluator results</div>;
  }

  return (
    <ScrollArea className="h-[400px]">
      <div className="space-y-3 p-2">
        {results.map((result, i) => (
          <div key={i} className="rounded-lg border p-3 flex items-start gap-3">
            {result.passed ? (
              <CheckCircle className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
            ) : (
              <XCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
            )}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-sm font-medium">{result.evaluatorId}</span>
                <span className="text-xs bg-muted px-2 py-0.5 rounded-full">Score: {(result.score * 100).toFixed(0)}%</span>
              </div>
              <p className="text-sm text-muted-foreground">{result.feedback}</p>
              <p className="text-xs text-muted-foreground mt-1">{new Date(result.timestamp).toLocaleTimeString()}</p>
            </div>
          </div>
        ))}
      </div>
    </ScrollArea>
  );
}
