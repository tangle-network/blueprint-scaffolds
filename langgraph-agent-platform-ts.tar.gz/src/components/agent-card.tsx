"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { AgentDefinition } from "@/types";
import { Bot, Wrench } from "lucide-react";

interface AgentCardProps {
  agent: AgentDefinition;
  onStartRun: (agentId: string) => void;
}

export function AgentCard({ agent, onStartRun }: AgentCardProps) {
  return (
    <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => onStartRun(agent.id)}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Bot className="h-5 w-5" />
            {agent.name}
          </CardTitle>
          <Badge variant="secondary">{agent.tools.length} tools</Badge>
        </div>
        <CardDescription>{agent.description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-2 flex-wrap">
          <Wrench className="h-3 w-3 text-muted-foreground" />
          {agent.tools.map((t) => (
            <Badge key={t.name} variant="outline" className="text-xs">
              {t.name}
            </Badge>
          ))}
        </div>
        <p className="text-xs text-muted-foreground mt-3 line-clamp-2">{agent.systemPrompt}</p>
      </CardContent>
    </Card>
  );
}
