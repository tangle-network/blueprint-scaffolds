import type { StreamEvent } from '../shared/index.js';

type Listener = (event: StreamEvent) => void;

class EventBus {
  private listeners = new Map<string, Set<Listener>>();
  private globalListeners = new Set<Listener>();

  subscribe(runId: string, listener: Listener): () => void {
    if (!this.listeners.has(runId)) {
      this.listeners.set(runId, new Set());
    }
    this.listeners.get(runId)!.add(listener);
    return () => {
      this.listeners.get(runId)?.delete(listener);
    };
  }

  subscribeAll(listener: Listener): () => void {
    this.globalListeners.add(listener);
    return () => {
      this.globalListeners.delete(listener);
    };
  }

  emit(event: StreamEvent): void {
    const runListeners = this.listeners.get(event.runId);
    if (runListeners) {
      for (const listener of runListeners) {
        try {
          listener(event);
        } catch {
          // swallow listener errors
        }
      }
    }
    for (const listener of this.globalListeners) {
      try {
        listener(event);
      } catch {
        // swallow listener errors
      }
    }
  }

  clearRun(runId: string): void {
    this.listeners.delete(runId);
  }
}

let bus: EventBus | null = null;

export function getEventBus(): EventBus {
  if (!bus) {
    bus = new EventBus();
  }
  return bus;
}
