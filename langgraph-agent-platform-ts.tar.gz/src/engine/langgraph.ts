import { v4 as uuid } from "uuid";
import type { Run, AgentMessage, TelemetryEvent } from "@/types";
import * as storage from "@/lib/storage";

const NODE_PROCESSING_TIME = 800;
const TOOL_EXECUTION_TIME = 600;
const EVALUATION_TIME = 500;

type EventCallback = (event: { type: string; data: Record<string, unknown> }) => void;

const activeListeners = new Map<string, Set<EventCallback>>();

export function addListener(runId: string, cb: EventCallback) {
  if (!activeListeners.has(runId)) activeListeners.set(runId, new Set());
  activeListeners.get(runId)!.add(cb);
  return () => { activeListeners.get(runId)?.delete(cb); };
}

export function removeListener(runId: string, cb: EventCallback) {
  activeListeners.get(runId)?.delete(cb);
}

function emit(runId: string, type: string, data: Record<string, unknown>) {
  activeListeners.get(runId)?.forEach((cb) => {
    try { cb({ type, data }); } catch {}
  });
}

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

const RESPONSES: Record<string, string[]> = {
  agent_research: [
    "Based on my research, I found several relevant sources. Let me compile the findings.",
    "I've analyzed multiple sources and here's a comprehensive summary of the topic.",
    "The research indicates several key findings that I'll outline below.",
  ],
  agent_coder: [
    "I've implemented the solution following best practices. Let me run the tests.",
    "The code has been written with proper error handling and type safety.",
    "Here's my implementation with inline documentation and test coverage.",
  ],
  agent_support: [
    "Thank you for reaching out. Let me look into this for you.",
    "I've found a solution for your issue. Here are the steps to resolve it.",
    "Your concern has been addressed. Is there anything else I can help with?",
  ],
};

const TOOL_RESULTS: Record<string, string[]> = {
  web_search: ["Found 15 relevant results for your query.", "Search returned 8 high-quality sources."],
  summarize: ["Summary: The key points are organized into 3 main categories.", "Condensed overview generated successfully."],
  run_tests: ["All 12 tests passed.", "8/10 tests passed. 2 failures in edge cases."],
  deploy: ["Deployment to staging successful.", "Deployed to production at v2.4.1."],
  search_knowledge_base: ["Found 3 matching articles in the knowledge base.", "Knowledge base returned relevant troubleshooting steps."],
};

function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export async function executeRun(runId: string): Promise<void> {
  const run = storage.getRun(runId);
  if (!run) throw new Error(`Run ${runId} not found`);

  const agent = storage.getAgent(run.agentId);
  if (!agent) throw new Error(`Agent ${run.agentId} not found`);

  storage.updateRun(runId, { status: "running" });
  emit(runId, "run_started", { runId, agentId: run.agentId });
  storage.addTelemetryEvent(runId, "state_update", { status: "running" });

  try {
    const graph = agent.graph;
    const nodeMap = new Map(graph.nodes.map((n) => [n.id, n]));
    let currentNodeId: string | undefined = graph.entryNode;
    let stepCount = 0;
    const maxSteps = 20;

    while (currentNodeId && stepCount < maxSteps) {
      const node = nodeMap.get(currentNodeId);
      if (!node) break;

      stepCount++;
      storage.updateRun(runId, { currentNode: currentNodeId });
      storage.addTelemetryEvent(runId, "node_enter", { nodeId: currentNodeId, nodeType: node.type });
      emit(runId, "node_enter", { nodeId: currentNodeId, label: node.label, nodeType: node.type });

      if (run.status === "paused") {
        emit(runId, "run_paused", { nodeId: currentNodeId });
        return;
      }

      await delay(NODE_PROCESSING_TIME);

      switch (node.type) {
        case "router": {
          const edges = graph.edges.filter((e) => e.source === currentNodeId);
          const chosen = edges[Math.floor(Math.random() * edges.length)];
          if (chosen) {
            storage.addTelemetryEvent(runId, "state_update", { routed_to: chosen.target, condition: chosen.condition });
            emit(runId, "router_decision", { from: currentNodeId, to: chosen.target, condition: chosen.condition });

            const assistantMsg: Omit<AgentMessage, "id" | "timestamp"> = {
              role: "assistant",
              content: `[Router] Routing to ${chosen.target} via condition: ${chosen.condition ?? "default"}`,
            };
            storage.addMessage(runId, assistantMsg);
            currentNodeId = chosen.target;
          } else {
            currentNodeId = undefined;
          }
          break;
        }

        case "agent": {
          const responses = RESPONSES[`agent_${run.agentId.split("-")[1]}`] ?? RESPONSES.agent_research;
          const content = pickRandom(responses);

          const toolCallId = uuid();
          const toolName = agent.tools[Math.floor(Math.random() * agent.tools.length)]?.name ?? "unknown";
          const toolArgs: Record<string, unknown> = { query: "generated query" };

          const assistantMsg: Omit<AgentMessage, "id" | "timestamp"> = {
            role: "assistant",
            content,
            toolCalls: [{ id: toolCallId, name: toolName, arguments: toolArgs }],
          };
          storage.addMessage(runId, assistantMsg);
          emit(runId, "agent_message", { content, toolCalls: [{ id: toolCallId, name: toolName }] });

          await delay(TOOL_EXECUTION_TIME);
          const toolResult = pickRandom(TOOL_RESULTS[toolName] ?? ["Tool executed successfully."]);

          const toolMsg: Omit<AgentMessage, "id" | "timestamp"> = {
            role: "tool",
            content: toolResult,
            toolCallId,
          };
          storage.addMessage(runId, toolMsg);
          storage.addTelemetryEvent(runId, "tool_call", { toolName, toolCallId, arguments: toolArgs });
          storage.addTelemetryEvent(runId, "tool_result", { toolName, toolCallId, result: toolResult });
          emit(runId, "tool_result", { toolName, result: toolResult });

          const nextEdge = graph.edges.find((e) => e.source === currentNodeId);
          currentNodeId = nextEdge?.target;
          break;
        }

        case "tool": {
          const toolName = node.label.toLowerCase().replace(/\s+/g, "_");
          const toolResult = pickRandom(TOOL_RESULTS[toolName] ?? ["Tool executed successfully."]);

          await delay(TOOL_EXECUTION_TIME);

          const toolMsg: Omit<AgentMessage, "id" | "timestamp"> = {
            role: "tool",
            content: toolResult,
            toolCallId: uuid(),
          };
          storage.addMessage(runId, toolMsg);
          storage.addTelemetryEvent(runId, "tool_call", { toolName, result: toolResult });
          emit(runId, "tool_result", { toolName, result: toolResult });

          const nextEdge = graph.edges.find((e) => e.source === currentNodeId);
          currentNodeId = nextEdge?.target;
          break;
        }

        case "evaluator": {
          await delay(EVALUATION_TIME);
          const passed = Math.random() > 0.3;
          const score = passed ? 0.7 + Math.random() * 0.3 : Math.random() * 0.5;
          const feedback = passed
            ? "Quality check passed. Response meets standards."
            : "Quality check failed. Response needs improvement.";

          storage.addEvaluatorResult(runId, {
            evaluatorId: node.id,
            passed,
            score,
            feedback,
          });
          storage.addTelemetryEvent(runId, "evaluator", { evaluatorId: node.id, passed, score });
          emit(runId, "evaluator_result", { evaluatorId: node.id, passed, score, feedback });

          const evalEdges = graph.edges.filter((e) => e.source === currentNodeId);
          const nextEdge = passed
            ? evalEdges.find((e) => e.condition !== "retry" && e.condition !== "needs_changes") ?? evalEdges[0]
            : evalEdges.find((e) => e.condition === "retry" || e.condition === "needs_changes") ?? evalEdges[0];

          currentNodeId = nextEdge?.target;
          break;
        }
      }

      storage.addTelemetryEvent(runId, "node_exit", { nodeId: currentNodeId ?? "end", stepCount });
      emit(runId, "node_exit", { nodeId: currentNodeId ?? "end" });
    }

    const finalMsg: Omit<AgentMessage, "id" | "timestamp"> = {
      role: "assistant",
      content: "Task completed successfully. All nodes have been processed.",
    };
    storage.addMessage(runId, finalMsg);

    storage.updateRun(runId, { status: "completed", currentNode: "end" });
    storage.addTelemetryEvent(runId, "state_update", { status: "completed" });
    emit(runId, "run_completed", { runId });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    storage.updateRun(runId, { status: "failed" });
    storage.addTelemetryEvent(runId, "error", { error: errorMessage });
    emit(runId, "run_failed", { error: errorMessage });
  }
}

export async function retryRun(runId: string): Promise<void> {
  const run = storage.getRun(runId);
  if (!run) throw new Error(`Run ${runId} not found`);

  const agent = storage.getAgent(run.agentId);
  if (!agent) throw new Error(`Agent ${run.agentId} not found`);

  const userMessages = run.messages.filter((m) => m.role === "user");
  const newRun = storage.createRun(run.agentId, userMessages, run.metadata);
  emit(newRun.id, "run_created", { runId: newRun.id, fromRunId: runId });
  await executeRun(newRun.id);
  return;
}

export function pauseRun(runId: string): void {
  const run = storage.getRun(runId);
  if (!run) throw new Error(`Run ${runId} not found`);
  storage.updateRun(runId, { status: "paused" });
  emit(runId, "run_paused", { runId });
}

export function cancelRun(runId: string): void {
  const run = storage.getRun(runId);
  if (!run) throw new Error(`Run ${runId} not found`);
  storage.updateRun(runId, { status: "cancelled" });
  emit(runId, "run_cancelled", { runId });
}
