import { v4 as uuid } from 'uuid';
import type {
  GraphDefinition,
  NodeDefinition,
  EdgeDefinition,
  RunState,
  RunStatus,
  StateCheckpoint,
  StreamEvent,
  RunContext,
} from '../shared/index.js';

export interface CompiledGraph {
  definition: GraphDefinition;
  nodeMap: Map<string, NodeDefinition>;
  adjacency: Map<string, EdgeDefinition[]>;
  validate(): string[];
}

export function compileGraph(def: GraphDefinition): CompiledGraph {
  const nodeMap = new Map<string, NodeDefinition>();
  for (const node of def.nodes) {
    nodeMap.set(node.id, node);
  }

  const adjacency = new Map<string, EdgeDefinition[]>();
  for (const edge of def.edges) {
    const existing = adjacency.get(edge.from) || [];
    existing.push(edge);
    adjacency.set(edge.from, existing);
  }

  return {
    definition: def,
    nodeMap,
    adjacency,
    validate(): string[] {
      const errors: string[] = [];
      if (!nodeMap.has(def.entryNode)) {
        errors.push(`Entry node "${def.entryNode}" not found in nodes`);
      }
      for (const edge of def.edges) {
        if (!nodeMap.has(edge.from)) errors.push(`Edge from unknown node "${edge.from}"`);
        if (!nodeMap.has(edge.to)) errors.push(`Edge to unknown node "${edge.to}"`);
      }
      for (const node of def.nodes) {
        if (node.type === 'router') {
          const edges = adjacency.get(node.id) || [];
          const conditionalEdges = edges.filter((e) => e.condition);
          if (conditionalEdges.length < 2) {
            errors.push(`Router node "${node.id}" needs at least 2 conditional edges`);
          }
        }
      }
      return errors;
    },
  };
}

export function resolveNextNode(
  graph: CompiledGraph,
  currentNodeId: string,
  state: Record<string, unknown>
): string | null {
  const edges = graph.adjacency.get(currentNodeId);
  if (!edges || edges.length === 0) return null;

  if (edges.length === 1 && !edges[0].condition) {
    return edges[0].to;
  }

  const conditionKey = state._route as string | undefined;
  for (const edge of edges) {
    if (edge.condition && edge.condition === conditionKey) {
      return edge.to;
    }
  }

  const defaultEdge = edges.find((e) => !e.condition);
  return defaultEdge ? defaultEdge.to : null;
}

export function createRunState(
  runId: string,
  graphId: string,
  input: Record<string, unknown>,
  context?: Record<string, unknown>
): RunState {
  const now = Date.now();
  return {
    runId,
    graphId,
    currentNode: null,
    status: 'pending',
    input,
    output: null,
    context: context || {},
    history: [],
    error: null,
    createdAt: now,
    updatedAt: now,
    completedAt: null,
  };
}

export function checkpointFromNode(
  nodeId: string,
  state: Record<string, unknown>,
  output?: unknown,
  error?: string
): StateCheckpoint {
  return {
    nodeId,
    timestamp: Date.now(),
    state: { ...state },
    output,
    error,
  };
}

export function makeEmit(runId: string, sink: (event: StreamEvent) => void) {
  return (type: StreamEvent['type'], data: Record<string, unknown>, nodeId?: string) => {
    sink({
      type,
      runId,
      nodeId,
      timestamp: Date.now(),
      data,
    });
  };
}

export function makeRunContext(
  runId: string,
  state: Record<string, unknown>,
  sink: (event: StreamEvent) => void,
  toolExecutor: (name: string, args: Record<string, unknown>) => Promise<unknown>
): RunContext {
  return {
    runId,
    state,
    emit: (event: StreamEvent) => sink(event),
    callTool: toolExecutor,
  };
}
