import type { RunState, StateCheckpoint } from '../shared/index.js';

export interface PersistenceStore {
  saveRun(run: RunState): Promise<void>;
  loadRun(runId: string): Promise<RunState | null>;
  listRuns(offset: number, limit: number): Promise<{ runs: RunState[]; total: number }>;
  deleteRun(runId: string): Promise<boolean>;
  saveCheckpoint(checkpoint: StateCheckpoint & { runId: string }): Promise<void>;
  loadCheckpoints(runId: string): Promise<StateCheckpoint[]>;
}

class InMemoryStore implements PersistenceStore {
  private runs = new Map<string, RunState>();
  private checkpoints = new Map<string, StateCheckpoint[]>();

  async saveRun(run: RunState): Promise<void> {
    this.runs.set(run.runId, { ...run });
  }

  async loadRun(runId: string): Promise<RunState | null> {
    const run = this.runs.get(runId);
    return run ? { ...run } : null;
  }

  async listRuns(offset: number, limit: number): Promise<{ runs: RunState[]; total: number }> {
    const all = Array.from(this.runs.values()).sort(
      (a, b) => b.createdAt - a.createdAt
    );
    return {
      runs: all.slice(offset, offset + limit),
      total: all.length,
    };
  }

  async deleteRun(runId: string): Promise<boolean> {
    const existed = this.runs.has(runId);
    this.runs.delete(runId);
    this.checkpoints.delete(runId);
    return existed;
  }

  async saveCheckpoint(checkpoint: StateCheckpoint & { runId: string }): Promise<void> {
    const { runId, ...cp } = checkpoint;
    const existing = this.checkpoints.get(runId) || [];
    existing.push(cp);
    this.checkpoints.set(runId, existing);
  }

  async loadCheckpoints(runId: string): Promise<StateCheckpoint[]> {
    return [...(this.checkpoints.get(runId) || [])];
  }
}

let store: PersistenceStore | null = null;

export function getPersistenceStore(): PersistenceStore {
  if (!store) {
    store = new InMemoryStore();
  }
  return store;
}
