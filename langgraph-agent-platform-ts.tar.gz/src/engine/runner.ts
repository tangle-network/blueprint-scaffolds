import { v4 as uuid } from 'uuid';
import type {
  GraphDefinition,
  NodeDefinition,
  RunState,
  StreamEvent,
  RunContext,
} from '../shared/index.js';
import { compileGraph, resolveNextNode, createRunState, checkpointFromNode, type CompiledGraph } from './graph.js';
import { getPersistenceStore } from './persistence.js';
import { getEventBus } from './events.js';

export interface NodeExecutor {
  execute(
    node: NodeDefinition,
    context: RunContext,
    state: Record<string, unknown>
  ): Promise<Record<string, unknown>>;
}

class DefaultNodeExecutor implements NodeExecutor {
  async execute(
    node: NodeDefinition,
    context: RunContext,
    state: Record<string, unknown>
  ): Promise<Record<string, unknown>> {
    switch (node.type) {
      case 'agent':
        return this.executeAgent(node, context, state);
      case 'tool':
        return this.executeTool(node, context, state);
      case 'router':
        return this.executeRouter(node, context, state);
      case 'evaluator':
        return this.executeEvaluator(node, context, state);
      case 'input':
        return { ...state, _input: state };
      case 'output':
        return { ...state, _output: state._result || state };
      default:
        return state;
    }
  }

  private async executeAgent(
    node: NodeDefinition,
    context: RunContext,
    state: Record<string, unknown>
  ): Promise<Record<string, unknown>> {
    const prompt = node.config.prompt as string || 'Process the input';
    const model = node.config.model as string || 'default';
    context.emit({
      type: 'node:start',
      runId: context.runId,
      nodeId: node.id,
      timestamp: Date.now(),
      data: { prompt, model, nodeType: 'agent' },
    });

    const result = {
      ...state,
      _agentOutput: `Agent [${node.id}] processed with model ${model}`,
      _lastNode: node.id,
    };

    context.emit({
      type: 'node:complete',
      runId: context.runId,
      nodeId: node.id,
      timestamp: Date.now(),
      data: { result: result._agentOutput },
    });

    return result;
  }

  private async executeTool(
    node: NodeDefinition,
    context: RunContext,
    state: Record<string, unknown>
  ): Promise<Record<string, unknown>> {
    const toolName = node.config.toolName as string;
    const toolArgs = (node.config.toolArgs as Record<string, string>) || {};

    context.emit({
      type: 'tool:call',
      runId: context.runId,
      nodeId: node.id,
      timestamp: Date.now(),
      data: { toolName, args: toolArgs },
    });

    const resolvedArgs: Record<string, unknown> = {};
    for (const [key, ref] of Object.entries(toolArgs)) {
      resolvedArgs[key] = typeof ref === 'string' && ref.startsWith('$')
        ? state[ref.slice(1)]
        : ref;
    }

    let toolResult: unknown;
    try {
      toolResult = await context.callTool(toolName, resolvedArgs);
    } catch (err) {
      toolResult = { error: err instanceof Error ? err.message : String(err) };
    }

    context.emit({
      type: 'tool:result',
      runId: context.runId,
      nodeId: node.id,
      timestamp: Date.now(),
      data: { toolName, result: toolResult },
    });

    return {
      ...state,
      _toolResults: { ...(state._toolResults as Record<string, unknown> || {}), [node.id]: toolResult },
      _lastNode: node.id,
    };
  }

  private async executeRouter(
    node: NodeDefinition,
    context: RunContext,
    state: Record<string, unknown>
  ): Promise<Record<string, unknown>> {
    const rules = node.config.rules as Array<{ field: string; match: unknown; route: string }> || [];
    let route = node.config.defaultRoute as string || 'default';

    for (const rule of rules) {
      const value = state[rule.field];
      if (value === rule.match) {
        route = rule.route;
        break;
      }
    }

    context.emit({
      type: 'node:start',
      runId: context.runId,
      nodeId: node.id,
      timestamp: Date.now(),
      data: { route, nodeType: 'router' },
    });

    return { ...state, _route: route, _lastNode: node.id };
  }

  private async executeEvaluator(
    node: NodeDefinition,
    context: RunContext,
    state: Record<string, unknown>
  ): Promise<Record<string, unknown>> {
    context.emit({
      type: 'hook:eval',
      runId: context.runId,
      nodeId: node.id,
      timestamp: Date.now(),
      data: { nodeType: 'evaluator', state },
    });

    return { ...state, _lastNode: node.id, _evaluated: true };
  }
}

const registry = new Map<string, CompiledGraph>();
const executor = new DefaultNodeExecutor();

export function registerGraph(def: GraphDefinition): void {
  const compiled = compileGraph(def);
  const errors = compiled.validate();
  if (errors.length > 0) {
    throw new Error(`Graph validation failed: ${errors.join(', ')}`);
  }
  registry.set(def.id, compiled);
}

export function getGraph(graphId: string): CompiledGraph | undefined {
  return registry.get(graphId);
}

export function listGraphs(): GraphDefinition[] {
  return Array.from(registry.values()).map((g) => g.definition);
}

export async function startRun(
  graphId: string,
  input: Record<string, unknown>,
  context?: Record<string, unknown>
): Promise<RunState> {
  const graph = registry.get(graphId);
  if (!graph) throw new Error(`Graph "${graphId}" not found`);

  const runId = uuid();
  const state = createRunState(runId, graphId, input, context);
  state.status = 'running';
  state.currentNode = graph.definition.entryNode;

  const store = getPersistenceStore();
  const bus = getEventBus();

  await store.saveRun(state);

  bus.emit({
    type: 'run:start',
    runId,
    timestamp: Date.now(),
    data: { graphId, input },
  });

  executeGraph(runId, graph, state).catch((err) => {
    console.error(`Run ${runId} failed:`, err);
  });

  return state;
}

async function executeGraph(
  runId: string,
  graph: CompiledGraph,
  initialState: RunState
): Promise<void> {
  const store = getPersistenceStore();
  const bus = getEventBus();

  let state: Record<string, unknown> = { ...initialState.input, ...initialState.context };
  let currentNodeId: string | null = initialState.currentNode || graph.definition.entryNode;
  const runState = { ...initialState };

  while (currentNodeId) {
    const node = graph.nodeMap.get(currentNodeId);
    if (!node) {
      runState.status = 'failed';
      runState.error = `Node "${currentNodeId}" not found`;
      runState.updatedAt = Date.now();
      await store.saveRun(runState);
      bus.emit({
        type: 'run:error',
        runId,
        nodeId: currentNodeId,
        timestamp: Date.now(),
        data: { error: runState.error },
      });
      return;
    }

    runState.currentNode = currentNodeId;

    const ctx: RunContext = {
      runId,
      state: { ...state },
      emit: (event: StreamEvent) => bus.emit(event),
      callTool: async (name: string, args: Record<string, unknown>) => {
        return { tool: name, args, result: `Simulated result for ${name}` };
      },
    };

    try {
      const cp = checkpointFromNode(currentNodeId, state);
      runState.history.push(cp);
      await store.saveCheckpoint({ runId, ...cp });

      bus.emit({
        type: 'state:checkpoint',
        runId,
        nodeId: currentNodeId,
        timestamp: Date.now(),
        data: { state },
      });

      state = await executor.execute(node, ctx, state);

      if (runState.status === 'paused') {
        runState.updatedAt = Date.now();
        await store.saveRun(runState);
        return;
      }
    } catch (err) {
      runState.status = 'failed';
      runState.error = err instanceof Error ? err.message : String(err);
      runState.updatedAt = Date.now();
      runState.completedAt = Date.now();
      await store.saveRun(runState);

      bus.emit({
        type: 'run:error',
        runId,
        nodeId: currentNodeId,
        timestamp: Date.now(),
        data: { error: runState.error },
      });
      return;
    }

    const nextNodeId = resolveNextNode(graph, currentNodeId, state);
    currentNodeId = nextNodeId;
  }

  runState.status = 'completed';
  runState.output = state;
  runState.currentNode = null;
  runState.updatedAt = Date.now();
  runState.completedAt = Date.now();
  await store.saveRun(runState);

  bus.emit({
    type: 'run:complete',
    runId,
    timestamp: Date.now(),
    data: { output: state },
  });
}

export async function resumeRun(runId: string): Promise<RunState> {
  const store = getPersistenceStore();
  const bus = getEventBus();
  const runState = await store.loadRun(runId);
  if (!runState) throw new Error(`Run "${runId}" not found`);
  if (runState.status !== 'paused' && runState.status !== 'failed') {
    throw new Error(`Cannot resume run in status "${runState.status}"`);
  }

  const graph = registry.get(runState.graphId);
  if (!graph) throw new Error(`Graph "${runState.graphId}" not found`);

  runState.status = 'running';
  runState.error = null;
  runState.updatedAt = Date.now();
  await store.saveRun(runState);

  bus.emit({
    type: 'run:resumed',
    runId,
    timestamp: Date.now(),
    data: {},
  });

  executeGraph(runId, graph, runState).catch((err) => {
    console.error(`Run ${runId} resume failed:`, err);
  });

  return runState;
}

export async function cancelRun(runId: string): Promise<RunState> {
  const store = getPersistenceStore();
  const runState = await store.loadRun(runId);
  if (!runState) throw new Error(`Run "${runId}" not found`);
  runState.status = 'cancelled';
  runState.updatedAt = Date.now();
  runState.completedAt = Date.now();
  await store.saveRun(runState);
  return runState;
}
