import type { TelemetrySpan, TelemetryEvent } from "@/types";

const spans = new Map<string, TelemetrySpan>();
const events: TelemetryEvent[] = [];

function makeId(): string {
  return Math.random().toString(36).slice(2, 14);
}

export function startSpan(name: string, attributes: Record<string, unknown> = {}, parentSpanId?: string): TelemetrySpan {
  const span: TelemetrySpan = {
    traceId: makeId(),
    spanId: makeId(),
    parentSpanId,
    name,
    kind: "internal",
    startTime: Date.now(),
    attributes,
    status: "ok",
  };
  spans.set(span.spanId, span);
  return span;
}

export function endSpan(spanId: string, status: "ok" | "error" = "ok", extraAttrs?: Record<string, unknown>): TelemetrySpan | undefined {
  const span = spans.get(spanId);
  if (!span) return undefined;
  span.endTime = Date.now();
  span.status = status;
  if (extraAttrs) span.attributes = { ...span.attributes, ...extraAttrs };
  return span;
}

export function getSpan(spanId: string): TelemetrySpan | undefined {
  return spans.get(spanId);
}

export function recordEvent(name: string, attributes: Record<string, unknown> = {}): TelemetryEvent {
  const evt: TelemetryEvent = { id: makeId(), name, timestamp: Date.now(), attributes };
  events.push(evt);
  return evt;
}

export function getEventsByName(name: string): TelemetryEvent[] {
  return events.filter((e) => e.name === name);
}

export function getAllSpans(): TelemetrySpan[] {
  return Array.from(spans.values());
}

export function getAllEvents(): TelemetryEvent[] {
  return [...events];
}

export function getSpanTree(traceId: string): TelemetrySpan[] {
  return Array.from(spans.values()).filter((s) => s.traceId === traceId);
}

export function getMetrics(): {
  totalSpans: number;
  totalEvents: number;
  avgSpanDurationMs: number;
  errorRate: number;
} {
  const allSpans = Array.from(spans.values());
  const completed = allSpans.filter((s) => s.endTime !== undefined);
  const errors = allSpans.filter((s) => s.status === "error");
  const durations = completed.map((s) => (s.endTime! - s.startTime));

  return {
    totalSpans: allSpans.length,
    totalEvents: events.length,
    avgSpanDurationMs: durations.length > 0 ? durations.reduce((a, b) => a + b, 0) / durations.length : 0,
    errorRate: allSpans.length > 0 ? errors.length / allSpans.length : 0,
  };
}

export function clearTelemetry(): void {
  spans.clear();
  events.length = 0;
}
