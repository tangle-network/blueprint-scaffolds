import type { ToolDefinition, ToolCall } from "@/types";

export interface ToolExecutor {
  definition: ToolDefinition;
  execute(args: Record<string, unknown>): Promise<unknown>;
}

function makeId(): string {
  return Math.random().toString(36).slice(2, 10);
}

export class ToolRegistry {
  private tools = new Map<string, ToolExecutor>();

  register(executor: ToolExecutor): void {
    this.tools.set(executor.definition.name, executor);
  }

  get(name: string): ToolExecutor | undefined {
    return this.tools.get(name);
  }

  list(): ToolDefinition[] {
    return Array.from(this.tools.values()).map((t) => t.definition);
  }

  async call(name: string, args: Record<string, unknown>): Promise<ToolCall> {
    const tool = this.tools.get(name);
    const startedAt = Date.now();
    const tc: ToolCall = { id: makeId(), name, arguments: args, startedAt };

    if (!tool) {
      tc.error = `Tool "${name}" not found`;
      tc.completedAt = Date.now();
      return tc;
    }

    try {
      tc.result = await tool.execute(args);
    } catch (err: unknown) {
      tc.error = err instanceof Error ? err.message : String(err);
    }
    tc.completedAt = Date.now();
    return tc;
  }
}

const searchTool: ToolExecutor = {
  definition: {
    name: "web_search",
    description: "Search the web for information. Returns relevant results.",
    parameters: {
      type: "object",
      properties: { query: { type: "string", description: "Search query" } },
      required: ["query"],
    },
  },
  async execute(args) {
    const q = String(args.query ?? "");
    return {
      query: q,
      results: [
        { title: `Result for "${q}"`, url: `https://example.com/search?q=${encodeURIComponent(q)}`, snippet: `This is a simulated search result for "${q}".` },
        { title: `${q} - Wikipedia`, url: `https://en.wikipedia.org/wiki/${encodeURIComponent(q)}`, snippet: `Article about ${q} with detailed information.` },
      ],
    };
  },
};

const calculatorTool: ToolExecutor = {
  definition: {
    name: "calculator",
    description: "Evaluate a mathematical expression safely.",
    parameters: {
      type: "object",
      properties: { expression: { type: "string", description: "Math expression to evaluate" } },
      required: ["expression"],
    },
  },
  async execute(args) {
    const expr = String(args.expression ?? "");
    const sanitized = expr.replace(/[^0-9+\-*/().%\s]/g, "");
    if (!sanitized.trim()) throw new Error("Invalid expression");
    const result = new Function(`"use strict"; return (${sanitized})`)();
    if (typeof result !== "number" || !isFinite(result)) throw new Error("Expression did not evaluate to a finite number");
    return { expression: expr, result };
  },
};

const weatherTool: ToolExecutor = {
  definition: {
    name: "get_weather",
    description: "Get current weather for a location.",
    parameters: {
      type: "object",
      properties: { location: { type: "string", description: "City name" }, units: { type: "string", enum: ["celsius", "fahrenheit"] } },
      required: ["location"],
    },
  },
  async execute(args) {
    const loc = String(args.location ?? "");
    const temp = 15 + Math.floor(Math.random() * 20);
    return {
      location: loc,
      temperature: args.units === "fahrenheit" ? temp * 1.8 + 32 : temp,
      units: args.units === "fahrenheit" ? "fahrenheit" : "celsius",
      conditions: ["sunny", "cloudy", "partly cloudy", "rainy"][Math.floor(Math.random() * 4)],
      humidity: 40 + Math.floor(Math.random() * 40),
    };
  },
};

const knowledgeTool: ToolExecutor = {
  definition: {
    name: "query_knowledge_base",
    description: "Query the internal knowledge base for documentation and facts.",
    parameters: {
      type: "object",
      properties: { topic: { type: "string", description: "Topic to look up" } },
      required: ["topic"],
    },
  },
  async execute(args) {
    const topic = String(args.topic ?? "");
    return {
      topic,
      documents: [
        { title: `${topic} Overview`, content: `Comprehensive guide about ${topic}. This document covers fundamentals and advanced concepts.` },
        { title: `${topic} Best Practices`, content: `Recommended patterns and anti-patterns for ${topic}.` },
      ],
      totalResults: 2,
    };
  },
};

export function createDefaultRegistry(): ToolRegistry {
  const reg = new ToolRegistry();
  reg.register(searchTool);
  reg.register(calculatorTool);
  reg.register(weatherTool);
  reg.register(knowledgeTool);
  return reg;
}

export const defaultRegistry = createDefaultRegistry();
