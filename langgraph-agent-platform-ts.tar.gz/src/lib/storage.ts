import { v4 as uuid } from "uuid";
import type { Run, AgentDefinition, TelemetryEvent, AgentMessage, EvaluatorResult } from "@/types";

const agents: Map<string, AgentDefinition> = new Map();
const runs: Map<string, Run> = new Map();

function seedData() {
  const agent1: AgentDefinition = {
    id: "agent-research",
    name: "Research Agent",
    description: "Performs web research and summarizes findings",
    systemPrompt: "You are a research assistant. Analyze queries, search for information, and provide comprehensive summaries.",
    graph: {
      nodes: [
        { id: "router", label: "Router", type: "router" },
        { id: "researcher", label: "Researcher", type: "agent" },
        { id: "search_tool", label: "Web Search", type: "tool" },
        { id: "summarizer", label: "Summarizer", type: "agent" },
        { id: "evaluator", label: "Quality Check", type: "evaluator" },
      ],
      edges: [
        { source: "router", target: "researcher", condition: "needs_research", label: "Research Needed" },
        { source: "researcher", target: "search_tool", label: "Search" },
        { source: "search_tool", target: "summarizer", label: "Summarize" },
        { source: "summarizer", target: "evaluator", label: "Evaluate" },
        { source: "router", target: "evaluator", condition: "direct_answer", label: "Direct Answer" },
        { source: "evaluator", target: "router", condition: "retry", label: "Retry" },
      ],
      entryNode: "router",
    },
    tools: [
      { name: "web_search", description: "Search the web for information", parameters: { query: { type: "string", description: "Search query" } } },
      { name: "summarize", description: "Summarize text content", parameters: { text: { type: "string", description: "Text to summarize" } } },
    ],
  };

  const agent2: AgentDefinition = {
    id: "agent-coder",
    name: "Code Assistant",
    description: "Writes and reviews code with automated testing",
    systemPrompt: "You are a code assistant. Write clean code, run tests, and review for quality.",
    graph: {
      nodes: [
        { id: "planner", label: "Planner", type: "router" },
        { id: "coder", label: "Coder", type: "agent" },
        { id: "test_runner", label: "Test Runner", type: "tool" },
        { id: "reviewer", label: "Reviewer", type: "evaluator" },
        { id: "deployer", label: "Deployer", type: "tool" },
      ],
      edges: [
        { source: "planner", target: "coder", condition: "implement", label: "Implement" },
        { source: "coder", target: "test_runner", label: "Run Tests" },
        { source: "test_runner", target: "reviewer", condition: "tests_pass", label: "Tests Pass" },
        { source: "test_runner", target: "coder", condition: "tests_fail", label: "Tests Fail" },
        { source: "reviewer", target: "deployer", condition: "approved", label: "Approved" },
        { source: "reviewer", target: "coder", condition: "needs_changes", label: "Needs Changes" },
      ],
      entryNode: "planner",
    },
    tools: [
      { name: "run_tests", description: "Run test suite", parameters: { path: { type: "string", description: "Test file path" } } },
      { name: "deploy", description: "Deploy code", parameters: { target: { type: "string", description: "Deployment target" } } },
    ],
  };

  const agent3: AgentDefinition = {
    id: "agent-support",
    name: "Support Agent",
    description: "Handles customer support with escalation routing",
    systemPrompt: "You are a customer support agent. Classify issues and resolve or escalate them.",
    graph: {
      nodes: [
        { id: "classifier", label: "Classifier", type: "router" },
        { id: "responder", label: "Responder", type: "agent" },
        { id: "kb_search", label: "Knowledge Base", type: "tool" },
        { id: "escalator", label: "Escalator", type: "agent" },
        { id: "satisfaction", label: "Satisfaction Check", type: "evaluator" },
      ],
      edges: [
        { source: "classifier", target: "responder", condition: "simple", label: "Simple" },
        { source: "responder", target: "kb_search", label: "Search KB" },
        { source: "kb_search", target: "satisfaction", label: "Check" },
        { source: "classifier", target: "escalator", condition: "complex", label: "Complex" },
        { source: "escalator", target: "satisfaction", label: "Evaluate" },
      ],
      entryNode: "classifier",
    },
    tools: [
      { name: "search_knowledge_base", description: "Search knowledge base", parameters: { query: { type: "string", description: "Search query" } } },
    ],
  };

  agents.set(agent1.id, agent1);
  agents.set(agent2.id, agent2);
  agents.set(agent3.id, agent3);
}

seedData();

export function getAgents(): AgentDefinition[] {
  return Array.from(agents.values());
}

export function getAgent(id: string): AgentDefinition | undefined {
  return agents.get(id);
}

export function getRuns(): Run[] {
  return Array.from(runs.values()).sort((a, b) => b.createdAt - a.createdAt);
}

export function getRun(id: string): Run | undefined {
  return runs.get(id);
}

export function createRun(agentId: string, messages: AgentMessage[], metadata?: Record<string, unknown>): Run {
  const agent = agents.get(agentId);
  if (!agent) throw new Error(`Agent ${agentId} not found`);

  const run: Run = {
    id: uuid(),
    agentId,
    status: "idle",
    messages: [...messages],
    stateGraph: { ...agent.graph, nodes: [...agent.graph.nodes], edges: [...agent.graph.edges] },
    currentNode: agent.graph.entryNode,
    evaluatorResults: [],
    telemetry: [],
    createdAt: Date.now(),
    updatedAt: Date.now(),
    metadata: metadata ?? {},
  };

  runs.set(run.id, run);
  return run;
}

export function updateRun(id: string, updates: Partial<Run>): Run {
  const run = runs.get(id);
  if (!run) throw new Error(`Run ${id} not found`);
  Object.assign(run, updates, { updatedAt: Date.now() });
  return run;
}

export function addTelemetryEvent(runId: string, type: TelemetryEvent["type"], data: Record<string, unknown>): TelemetryEvent {
  const run = runs.get(runId);
  if (!run) throw new Error(`Run ${runId} not found`);

  const event: TelemetryEvent = {
    id: uuid(),
    runId,
    type,
    data,
    timestamp: Date.now(),
  };
  run.telemetry.push(event);
  run.updatedAt = Date.now();
  return event;
}

export function addMessage(runId: string, message: Omit<AgentMessage, "id" | "timestamp">): AgentMessage {
  const run = runs.get(runId);
  if (!run) throw new Error(`Run ${runId} not found`);

  const msg: AgentMessage = {
    id: uuid(),
    ...message,
    timestamp: Date.now(),
  };
  run.messages.push(msg);
  run.updatedAt = Date.now();
  return msg;
}

export function addEvaluatorResult(runId: string, result: Omit<EvaluatorResult, "timestamp">): EvaluatorResult {
  const run = runs.get(runId);
  if (!run) throw new Error(`Run ${runId} not found`);

  const res: EvaluatorResult = { ...result, timestamp: Date.now() };
  run.evaluatorResults.push(res);
  run.updatedAt = Date.now();
  return res;
}
