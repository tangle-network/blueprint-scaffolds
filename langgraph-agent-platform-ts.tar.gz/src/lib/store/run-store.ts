import { AgentRun, RunEvent } from "@/types";

type EventListener = (runId: string, event: RunEvent) => void;

const runs = new Map<string, AgentRun>();
const listeners: EventListener[] = [];
const eventLogs = new Map<string, RunEvent[]>();

export function createRun(run: AgentRun): AgentRun {
  runs.set(run.id, { ...run });
  eventLogs.set(run.id, []);
  return run;
}

export function getRun(id: string): AgentRun | undefined {
  const r = runs.get(id);
  return r ? { ...r } : undefined;
}

export function updateRun(id: string, patch: Partial<AgentRun>): AgentRun | undefined {
  const existing = runs.get(id);
  if (!existing) return undefined;
  const updated = { ...existing, ...patch, updatedAt: Date.now() };
  runs.set(id, updated);
  return { ...updated };
}

export function listRuns(graphId?: string): AgentRun[] {
  const all = Array.from(runs.values());
  if (graphId) return all.filter((r) => r.graphId === graphId);
  return all.sort((a, b) => b.createdAt - a.createdAt).map((r) => ({ ...r }));
}

export function deleteRun(id: string): boolean {
  eventLogs.delete(id);
  return runs.delete(id);
}

export function appendEvent(runId: string, event: RunEvent): void {
  const logs = eventLogs.get(runId);
  if (logs) logs.push(event);
  for (const fn of listeners) {
    try {
      fn(runId, event);
    } catch {}
  }
}

export function getEvents(runId: string): RunEvent[] {
  return eventLogs.get(runId) ?? [];
}

export function subscribe(fn: EventListener): () => void {
  listeners.push(fn);
  return () => {
    const idx = listeners.indexOf(fn);
    if (idx >= 0) listeners.splice(idx, 1);
  };
}

export function clearAll(): void {
  runs.clear();
  eventLogs.clear();
  listeners.length = 0;
}
