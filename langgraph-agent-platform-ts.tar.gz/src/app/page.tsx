"use client";

import { useEffect, useState, useCallback } from "react";
import { useAppStore } from "@/store/app-store";
import { AgentCard } from "@/components/agent-card";
import { RunList } from "@/components/run-list";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { AgentDefinition, Run } from "@/types";
import { Activity, Bot, Zap, BarChart3 } from "lucide-react";

export default function DashboardPage() {
  const { agents, runs, setAgents, setRuns, addRun } = useAppStore();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch("/api/agents").then((r) => r.json()),
      fetch("/api/runs").then((r) => r.json()),
    ]).then(([agentsData, runsData]) => {
      setAgents(agentsData as AgentDefinition[]);
      setRuns(runsData as Run[]);
      setLoading(false);
    });
  }, [setAgents, setRuns]);

  const handleStartRun = useCallback(
    async (agentId: string) => {
      const res = await fetch("/api/runs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          agentId,
          messages: [{ id: crypto.randomUUID(), role: "user", content: "Help me with my task", timestamp: Date.now() }],
        }),
      });
      const run = (await res.json()) as Run;
      addRun(run);
      window.location.href = `/runs/${run.id}`;
    },
    [addRun]
  );

  const runningCount = runs.filter((r) => r.status === "running").length;
  const completedCount = runs.filter((r) => r.status === "completed").length;
  const failedCount = runs.filter((r) => r.status === "failed").length;

  if (loading) {
    return (
      <div className="container px-6 py-8">
        <div className="flex items-center justify-center h-64 text-muted-foreground">Loading...</div>
      </div>
    );
  }

  return (
    <div className="container px-6 py-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground mt-1">LangGraph agent platform with durable workflows and event streaming</p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Agents</CardTitle>
            <Bot className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{agents.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Runs</CardTitle>
            <Activity className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{runningCount}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed</CardTitle>
            <Zap className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{completedCount}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Failed</CardTitle>
            <BarChart3 className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{failedCount}</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-8 lg:grid-cols-2">
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-semibold">Agents</h2>
            <Badge variant="secondary">{agents.length}</Badge>
          </div>
          <div className="space-y-4">
            {agents.map((agent) => (
              <AgentCard key={agent.id} agent={agent} onStartRun={handleStartRun} />
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-semibold">Recent Runs</h2>
            <Badge variant="secondary">{runs.length}</Badge>
          </div>
          <RunList runs={runs} onSelectRun={(id) => { window.location.href = `/runs/${id}`; }} />
        </div>
      </div>
    </div>
  );
}
