import { NextResponse } from "next/server";
import { getAgents } from "@/lib/storage";

export async function GET() {
  return NextResponse.json(getAgents());
}
