import { NextResponse } from "next/server";
import { retryRun } from "@/engine/langgraph";

export async function POST(_request: Request, { params }: { params: { id: string } }) {
  try {
    await retryRun(params.id);
    const { getRun } = await import("@/lib/storage");
    const runs = getRun(params.id);
    const newRun = runs ? getRun(runs.id) : null;
    return NextResponse.json(newRun ?? { success: true });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 404 });
  }
}
