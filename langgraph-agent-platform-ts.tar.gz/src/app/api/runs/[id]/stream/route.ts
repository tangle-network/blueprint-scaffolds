import { addListener, removeListener } from "@/engine/langgraph";
import { getRun } from "@/lib/storage";

export async function GET(request: Request, { params }: { params: { id: string } }) {
  const run = getRun(params.id);
  if (!run) return new Response("Run not found", { status: 404 });

  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    start(controller) {
      const send = (data: unknown) => {
        try {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(data)}\n\n`));
        } catch {}
      };

      send({ type: "init", data: run });

      const cb = (event: { type: string; data: Record<string, unknown> }) => {
        send(event);
      };

      const unsubscribe = addListener(params.id, cb);

      const interval = setInterval(() => {
        const current = getRun(params.id);
        if (current && (current.status === "completed" || current.status === "failed" || current.status === "cancelled")) {
          send({ type: "run_ended", data: { status: current.status } });
          clearInterval(interval);
          unsubscribe();
          try { controller.close(); } catch {}
        }
      }, 2000);

      request.signal.addEventListener("abort", () => {
        clearInterval(interval);
        removeListener(params.id, cb);
        unsubscribe();
        try { controller.close(); } catch {}
      });
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
}
