import { NextResponse } from "next/server";
import { cancelRun } from "@/engine/langgraph";

export async function POST(_request: Request, { params }: { params: { id: string } }) {
  try {
    cancelRun(params.id);
    return NextResponse.json({ success: true });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 404 });
  }
}
