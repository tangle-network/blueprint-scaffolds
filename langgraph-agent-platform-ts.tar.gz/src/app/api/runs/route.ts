import { NextResponse } from "next/server";
import { getRuns, createRun } from "@/lib/storage";
import { executeRun } from "@/engine/langgraph";
import type { CreateRunRequest } from "@/types";

export async function GET() {
  return NextResponse.json(getRuns());
}

export async function POST(request: Request) {
  const body: CreateRunRequest = await request.json();
  const run = createRun(body.agentId, body.messages, body.metadata);
  executeRun(run.id).catch(() => {});
  return NextResponse.json(run, { status: 201 });
}
