"use client";

import { useEffect, useState, useCallback } from "react";
import { useAppStore } from "@/store/app-store";
import { StateGraphView } from "@/components/state-graph-view";
import { MessageList } from "@/components/message-list";
import { TelemetryPanel } from "@/components/telemetry-panel";
import { EvaluatorResults } from "@/components/evaluator-results";
import { RunControls } from "@/components/run-controls";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import type { Run } from "@/types";

const STATUS_VARIANT: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
  idle: "secondary",
  running: "default",
  paused: "outline",
  completed: "secondary",
  failed: "destructive",
  cancelled: "outline",
};

function getAgentName(agentId: string): string {
  const names: Record<string, string> = {
    "agent-research": "Research Agent",
    "agent-coder": "Code Assistant",
    "agent-support": "Support Agent",
  };
  return names[agentId] ?? agentId;
}

export default function RunDetailPage({ params }: { params: { id: string } }) {
  const { currentRun, setCurrentRun, updateRun } = useAppStore();
  const [loading, setLoading] = useState(true);

  const fetchRun = useCallback(async () => {
    const res = await fetch(`/api/runs/${params.id}`);
    if (res.ok) {
      const run = (await res.json()) as Run;
      setCurrentRun(run);
    }
    setLoading(false);
  }, [params.id, setCurrentRun]);

  useEffect(() => {
    fetchRun();
  }, [fetchRun]);

  useEffect(() => {
    if (!currentRun || (currentRun.status !== "running" && currentRun.status !== "idle")) return;

    const interval = setInterval(fetchRun, 2000);
    return () => clearInterval(interval);
  }, [currentRun?.status, fetchRun]);

  const handleAction = async (action: string) => {
    const res = await fetch(`/api/runs/${params.id}/${action}`, { method: "POST" });
    if (res.ok) {
      setTimeout(fetchRun, 500);
    }
  };

  if (loading) {
    return (
      <div className="container px-6 py-8">
        <div className="flex items-center justify-center h-64 text-muted-foreground">Loading run...</div>
      </div>
    );
  }

  if (!currentRun) {
    return (
      <div className="container px-6 py-8">
        <div className="flex items-center justify-center h-64 text-muted-foreground">Run not found</div>
      </div>
    );
  }

  return (
    <div className="container px-6 py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold tracking-tight font-mono">{currentRun.id.slice(0, 8)}</h1>
            <Badge variant={STATUS_VARIANT[currentRun.status]}>{currentRun.status}</Badge>
          </div>
          <p className="text-sm text-muted-foreground">
            Agent: {getAgentName(currentRun.agentId)} &middot; Created: {new Date(currentRun.createdAt).toLocaleString()}
          </p>
        </div>
        <RunControls run={currentRun} onAction={handleAction} />
      </div>

      <Separator />

      <div className="grid gap-6 lg:grid-cols-5">
        <div className="lg:col-span-3 space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">State Graph</CardTitle>
            </CardHeader>
            <CardContent>
              <StateGraphView graph={currentRun.stateGraph} currentNode={currentRun.currentNode} />
            </CardContent>
          </Card>

          <Tabs defaultValue="messages">
            <TabsList>
              <TabsTrigger value="messages">Messages ({currentRun.messages.length})</TabsTrigger>
              <TabsTrigger value="telemetry">Telemetry ({currentRun.telemetry.length})</TabsTrigger>
              <TabsTrigger value="evaluators">Evaluators ({currentRun.evaluatorResults.length})</TabsTrigger>
            </TabsList>
            <TabsContent value="messages">
              <Card>
                <CardContent className="pt-4">
                  <MessageList messages={currentRun.messages} />
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="telemetry">
              <Card>
                <CardContent className="pt-4">
                  <TelemetryPanel events={currentRun.telemetry} />
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="evaluators">
              <Card>
                <CardContent className="pt-4">
                  <EvaluatorResults results={currentRun.evaluatorResults} />
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Run Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Status</span>
                <Badge variant={STATUS_VARIANT[currentRun.status]}>{currentRun.status}</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Current Node</span>
                <span className="font-mono text-xs">{currentRun.currentNode}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Messages</span>
                <span>{currentRun.messages.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Telemetry Events</span>
                <span>{currentRun.telemetry.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Evaluations</span>
                <span>{currentRun.evaluatorResults.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Created</span>
                <span>{new Date(currentRun.createdAt).toLocaleTimeString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Updated</span>
                <span>{new Date(currentRun.updatedAt).toLocaleTimeString()}</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Metadata</CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="text-xs font-mono bg-muted p-2 rounded overflow-auto max-h-40">
                {JSON.stringify(currentRun.metadata, null, 2)}
              </pre>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
