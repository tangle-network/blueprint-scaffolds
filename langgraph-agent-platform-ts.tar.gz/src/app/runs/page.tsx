"use client";

import { useEffect, useState } from "react";
import { useAppStore } from "@/store/app-store";
import { RunList } from "@/components/run-list";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { AgentDefinition, Run } from "@/types";

export default function RunsPage() {
  const { runs, setRuns, setAgents, agents } = useAppStore();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch("/api/runs").then((r) => r.json()),
      fetch("/api/agents").then((r) => r.json()),
    ]).then(([runsData, agentsData]) => {
      setRuns(runsData as Run[]);
      setAgents(agentsData as AgentDefinition[]);
      setLoading(false);
    });
  }, [setRuns, setAgents]);

  const handleStartRun = async (agentId: string) => {
    const res = await fetch("/api/runs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        agentId,
        messages: [{ id: crypto.randomUUID(), role: "user", content: "Help me with my task", timestamp: Date.now() }],
      }),
    });
    const run = (await res.json()) as Run;
    window.location.href = `/runs/${run.id}`;
  };

  if (loading) {
    return (
      <div className="container px-6 py-8">
        <div className="flex items-center justify-center h-64 text-muted-foreground">Loading...</div>
      </div>
    );
  }

  return (
    <div className="container px-6 py-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Runs</h1>
          <p className="text-muted-foreground mt-1">All agent run executions</p>
        </div>
        <div className="flex gap-2">
          {agents.map((a) => (
            <Button key={a.id} size="sm" variant="outline" onClick={() => handleStartRun(a.id)}>
              Run {a.name}
            </Button>
          ))}
        </div>
      </div>

      <RunList runs={runs} onSelectRun={(id) => { window.location.href = `/runs/${id}`; }} />
    </div>
  );
}
