import { create } from "zustand";
import type { Run, AgentDefinition, AgentMessage, TelemetryEvent, EvaluatorResult } from "@/types";

interface AppState {
  agents: AgentDefinition[];
  runs: Run[];
  currentRun: Run | null;
  isLoading: boolean;

  setAgents: (agents: AgentDefinition[]) => void;
  setRuns: (runs: Run[]) => void;
  setCurrentRun: (run: Run | null) => void;
  addRun: (run: Run) => void;
  updateRun: (id: string, updates: Partial<Run>) => void;
  addMessageToRun: (runId: string, message: AgentMessage) => void;
  addTelemetryToRun: (runId: string, event: TelemetryEvent) => void;
  addEvaluatorToRun: (runId: string, result: EvaluatorResult) => void;
  setLoading: (loading: boolean) => void;
}

export const useAppStore = create<AppState>((set) => ({
  agents: [],
  runs: [],
  currentRun: null,
  isLoading: false,

  setAgents: (agents) => set({ agents }),
  setRuns: (runs) => set({ runs }),
  setCurrentRun: (run) => set({ currentRun: run }),
  addRun: (run) => set((state) => ({ runs: [run, ...state.runs] })),
  updateRun: (id, updates) =>
    set((state) => ({
      runs: state.runs.map((r) => (r.id === id ? { ...r, ...updates, updatedAt: Date.now() } : r)),
      currentRun: state.currentRun?.id === id ? { ...state.currentRun, ...updates, updatedAt: Date.now() } : state.currentRun,
    })),
  addMessageToRun: (runId, message) =>
    set((state) => {
      const updateRun = (run: Run) => ({
        ...run,
        messages: [...run.messages, { ...message, timestamp: Date.now() }],
        updatedAt: Date.now(),
      });
      return {
        runs: state.runs.map((r) => (r.id === runId ? updateRun(r) : r)),
        currentRun: state.currentRun?.id === runId && state.currentRun ? updateRun(state.currentRun) : state.currentRun,
      };
    }),
  addTelemetryToRun: (runId, event) =>
    set((state) => {
      const updateRun = (run: Run) => ({
        ...run,
        telemetry: [...run.telemetry, { ...event, timestamp: Date.now() }],
        updatedAt: Date.now(),
      });
      return {
        runs: state.runs.map((r) => (r.id === runId ? updateRun(r) : r)),
        currentRun: state.currentRun?.id === runId && state.currentRun ? updateRun(state.currentRun) : state.currentRun,
      };
    }),
  addEvaluatorToRun: (runId, result) =>
    set((state) => {
      const updateRun = (run: Run) => ({
        ...run,
        evaluatorResults: [...run.evaluatorResults, { ...result, timestamp: Date.now() }],
        updatedAt: Date.now(),
      });
      return {
        runs: state.runs.map((r) => (r.id === runId ? updateRun(r) : r)),
        currentRun: state.currentRun?.id === runId && state.currentRun ? updateRun(state.currentRun) : state.currentRun,
      };
    }),
  setLoading: (isLoading) => set({ isLoading }),
}));
