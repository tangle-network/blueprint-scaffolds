export interface RunState {
  runId: string;
  graphId: string;
  currentNode: string | null;
  status: RunStatus;
  input: Record<string, unknown>;
  output: Record<string, unknown> | null;
  context: Record<string, unknown>;
  history: StateCheckpoint[];
  error: string | null;
  createdAt: number;
  updatedAt: number;
  completedAt: number | null;
}

export type RunStatus =
  | 'pending'
  | 'running'
  | 'paused'
  | 'completed'
  | 'failed'
  | 'cancelled';

export interface StateCheckpoint {
  nodeId: string;
  timestamp: number;
  state: Record<string, unknown>;
  output?: unknown;
  error?: string;
}

export interface GraphDefinition {
  id: string;
  name: string;
  nodes: NodeDefinition[];
  edges: EdgeDefinition[];
  entryNode: string;
}

export interface NodeDefinition {
  id: string;
  label: string;
  type: NodeType;
  config: Record<string, unknown>;
}

export type NodeType = 'agent' | 'tool' | 'router' | 'evaluator' | 'input' | 'output';

export interface EdgeDefinition {
  id: string;
  from: string;
  to: string;
  condition?: string;
  label?: string;
}

export interface ToolDefinition {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
  execute: (args: Record<string, unknown>, context: RunContext) => Promise<unknown>;
}

export interface RunContext {
  runId: string;
  state: Record<string, unknown>;
  emit: (event: StreamEvent) => void;
  callTool: (name: string, args: Record<string, unknown>) => Promise<unknown>;
}

export interface StreamEvent {
  type: EventType;
  runId: string;
  nodeId?: string;
  timestamp: number;
  data: Record<string, unknown>;
}

export type EventType =
  | 'node:start'
  | 'node:complete'
  | 'node:error'
  | 'tool:call'
  | 'tool:result'
  | 'hook:eval'
  | 'run:start'
  | 'run:complete'
  | 'run:error'
  | 'run:paused'
  | 'run:resumed'
  | 'state:checkpoint'
  | 'background:started'
  | 'background:complete';

export interface EvaluatorHook {
  name: string;
  nodeId?: string;
  evaluate: (state: Record<string, unknown>, output: unknown) => Promise<EvalResult>;
}

export interface EvalResult {
  passed: boolean;
  score: number;
  message: string;
  metadata?: Record<string, unknown>;
}

export interface BackgroundTask {
  id: string;
  name: string;
  runId: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  result: unknown;
  createdAt: number;
  completedAt: number | null;
}

export interface TelemetrySpan {
  traceId: string;
  spanId: string;
  parentSpanId?: string;
  runId: string;
  nodeId?: string;
  operation: string;
  startTime: number;
  endTime: number | null;
  attributes: Record<string, unknown>;
  events: TelemetryEvent[];
}

export interface TelemetryEvent {
  name: string;
  timestamp: number;
  attributes: Record<string, unknown>;
}

export interface RunListResponse {
  runs: RunState[];
  total: number;
  offset: number;
  limit: number;
}

export interface CreateRunRequest {
  graphId: string;
  input: Record<string, unknown>;
  context?: Record<string, unknown>;
}

export interface APIError {
  code: string;
  message: string;
  details?: Record<string, unknown>;
}
