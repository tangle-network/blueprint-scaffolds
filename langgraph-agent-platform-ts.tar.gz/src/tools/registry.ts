import type { ToolDefinition, RunContext } from '../shared/index.js';

const toolRegistry = new Map<string, ToolDefinition>();

export function registerTool(tool: ToolDefinition): void {
  toolRegistry.set(tool.name, tool);
}

export function getTool(name: string): ToolDefinition | undefined {
  return toolRegistry.get(name);
}

export function listTools(): ToolDefinition[] {
  return Array.from(toolRegistry.values()).map((t) => ({
    name: t.name,
    description: t.description,
    parameters: t.parameters,
    execute: t.execute,
  }));
}

export async function executeTool(
  name: string,
  args: Record<string, unknown>,
  context: RunContext
): Promise<unknown> {
  const tool = toolRegistry.get(name);
  if (!tool) throw new Error(`Tool "${name}" not found`);
  return tool.execute(args, context);
}

registerTool({
  name: 'search',
  description: 'Search for information',
  parameters: {
    type: 'object',
    properties: {
      query: { type: 'string', description: 'Search query' },
    },
    required: ['query'],
  },
  execute: async (args) => {
    return { results: [`Result for "${args.query}"`], count: 1 };
  },
});

registerTool({
  name: 'calculate',
  description: 'Perform a calculation',
  parameters: {
    type: 'object',
    properties: {
      expression: { type: 'string', description: 'Math expression' },
    },
    required: ['expression'],
  },
  execute: async (args) => {
    const expr = args.expression as string;
    try {
      const safeExpr = expr.replace(/[^0-9+\-*/().%\s]/g, '');
      const result = Function(`"use strict"; return (${safeExpr})`)();
      return { expression: expr, result };
    } catch {
      return { expression: expr, error: 'Invalid expression' };
    }
  },
});

registerTool({
  name: 'http_request',
  description: 'Make an HTTP request',
  parameters: {
    type: 'object',
    properties: {
      url: { type: 'string' },
      method: { type: 'string' },
    },
    required: ['url'],
  },
  execute: async (args) => {
    return {
      url: args.url,
      method: args.method || 'GET',
      status: 200,
      body: `Simulated response from ${args.url}`,
    };
  },
});
