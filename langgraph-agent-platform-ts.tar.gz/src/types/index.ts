export type RunStatus = "idle" | "running" | "paused" | "completed" | "failed" | "cancelled";

export interface AgentMessage {
  id: string;
  role: "system" | "user" | "assistant" | "tool";
  content: string;
  toolCalls?: ToolCall[];
  toolCallId?: string;
  timestamp: number;
}

export interface ToolCall {
  id: string;
  name: string;
  arguments: Record<string, unknown>;
  result?: unknown;
  error?: string;
}

export interface ToolDefinition {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
}

export interface GraphNode {
  id: string;
  label: string;
  type: "agent" | "tool" | "router" | "evaluator";
}

export interface GraphEdge {
  source: string;
  target: string;
  condition?: string;
  label?: string;
}

export interface StateGraph {
  nodes: GraphNode[];
  edges: GraphEdge[];
  entryNode: string;
}

export interface EvaluatorResult {
  evaluatorId: string;
  passed: boolean;
  score: number;
  feedback: string;
  timestamp: number;
}

export interface Run {
  id: string;
  agentId: string;
  status: RunStatus;
  messages: AgentMessage[];
  stateGraph: StateGraph;
  currentNode: string;
  evaluatorResults: EvaluatorResult[];
  telemetry: TelemetryEvent[];
  createdAt: number;
  updatedAt: number;
  metadata: Record<string, unknown>;
}

export interface TelemetryEvent {
  id: string;
  runId: string;
  type: "node_enter" | "node_exit" | "tool_call" | "tool_result" | "evaluator" | "error" | "state_update";
  data: Record<string, unknown>;
  timestamp: number;
}

export interface CreateRunRequest {
  agentId: string;
  messages: AgentMessage[];
  metadata?: Record<string, unknown>;
}

export interface AgentDefinition {
  id: string;
  name: string;
  description: string;
  graph: StateGraph;
  tools: ToolDefinition[];
  systemPrompt: string;
}
