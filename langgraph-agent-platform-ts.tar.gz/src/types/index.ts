export type RunStatus = "pending" | "running" | "paused" | "completed" | "failed" | "cancelled";

export interface AgentMessage {
  id: string;
  role: "user" | "assistant" | "system" | "tool";
  content: string;
  toolCallId?: string;
  toolName?: string;
  timestamp: number;
}

export interface ToolCall {
  id: string;
  name: string;
  arguments: Record<string, unknown>;
  result?: unknown;
  error?: string;
  startedAt: number;
  completedAt?: number;
}

export interface GraphNode {
  id: string;
  label: string;
  type: "agent" | "tool" | "router" | "evaluator";
  status: "idle" | "active" | "completed" | "error";
}

export interface GraphEdge {
  from: string;
  to: string;
  condition?: string;
  label?: string;
}

export interface StateSnapshot {
  nodeId: string;
  state: Record<string, unknown>;
  timestamp: number;
  label: string;
}

export interface EvaluatorResult {
  evaluatorId: string;
  passed: boolean;
  score: number;
  feedback: string;
  timestamp: number;
}

export interface RunEvent {
  type: "state_update" | "tool_call" | "tool_result" | "message" | "evaluator" | "error" | "complete" | "node_transition";
  timestamp: number;
  data: Record<string, unknown>;
}

export interface AgentRun {
  id: string;
  graphId: string;
  status: RunStatus;
  messages: AgentMessage[];
  toolCalls: ToolCall[];
  stateHistory: StateSnapshot[];
  evaluatorResults: EvaluatorResult[];
  graphNodes: GraphNode[];
  graphEdges: GraphEdge[];
  currentNodeId: string | null;
  state: Record<string, unknown>;
  input: string;
  output?: string;
  error?: string;
  createdAt: number;
  updatedAt: number;
  completedAt?: number;
  metadata: Record<string, unknown>;
  parentRunId?: string;
  retryCount: number;
  checkpoint?: Record<string, unknown>;
}

export interface GraphDefinition {
  id: string;
  name: string;
  description: string;
  nodes: GraphNode[];
  edges: GraphEdge[];
  entryNodeId: string;
}

export interface ToolDefinition {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
}

export interface TelemetrySpan {
  traceId: string;
  spanId: string;
  parentSpanId?: string;
  name: string;
  kind: "internal" | "client" | "server";
  startTime: number;
  endTime?: number;
  attributes: Record<string, unknown>;
  status: "ok" | "error";
}

export interface TelemetryEvent {
  id: string;
  name: string;
  timestamp: number;
  attributes: Record<string, unknown>;
}

export interface CreateRunRequest {
  graphId: string;
  input: string;
  metadata?: Record<string, unknown>;
  parentRunId?: string;
}

export interface ResumeRunRequest {
  input: string;
  nodeId?: string;
}
