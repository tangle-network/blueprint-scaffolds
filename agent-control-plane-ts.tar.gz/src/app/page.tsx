export default function Home() {
  return (
    <main className="min-h-screen p-8">
      <h1 className="text-3xl font-bold mb-4">Welcome</h1>
      <p className="text-gray-600">Get started by editing this page.</p>
    </main>
  )
}
