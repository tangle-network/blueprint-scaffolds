import { z } from "zod";

export type AgentStatus = "idle" | "running" | "paused" | "error" | "completed";
export type RunStatus = "queued" | "running" | "completed" | "failed" | "cancelled";
export type SessionStatus = "active" | "expired" | "terminated";
export type ToolType = "function" | "http" | "browser" | "structured";

export const ToolParameterSchema = z.object({
  name: z.string(),
  type: z.enum(["string", "number", "boolean", "object", "array"]),
  required: z.boolean().default(false),
  description: z.string().optional(),
});

export type ToolParameter = z.infer<typeof ToolParameterSchema>;

export const ToolDefinitionSchema = z.object({
  name: z.string(),
  description: z.string(),
  type: z.enum(["function", "http", "browser", "structured"]),
  parameters: z.array(ToolParameterSchema),
  handler: z.string().optional(),
});

export type ToolDefinition = z.infer<typeof ToolDefinitionSchema>;

export const ToolExecutionSchema = z.object({
  toolName: z.string(),
  args: z.record(z.unknown()),
  result: z.unknown().optional(),
  error: z.string().optional(),
  durationMs: z.number().optional(),
  startedAt: z.string(),
  completedAt: z.string().optional(),
});

export type ToolExecution = z.infer<typeof ToolExecutionSchema>;

export const TraceSpanSchema = z.object({
  id: z.string(),
  runId: z.string(),
  parentSpanId: z.string().optional(),
  name: z.string(),
  kind: z.enum(["agent", "tool", "llm", "retrieval", "custom"]),
  status: z.enum(["ok", "error"]),
  startTime: z.string(),
  endTime: z.string().optional(),
  attributes: z.record(z.unknown()).optional(),
  events: z.array(z.object({ name: z.string(), timestamp: z.string(), attributes: z.record(z.unknown()).optional() })).optional(),
});

export type TraceSpan = z.infer<typeof TraceSpanSchema>;

export const TraceSchema = z.object({
  id: z.string(),
  runId: z.string(),
  sessionId: z.string().optional(),
  spans: z.array(TraceSpanSchema),
  createdAt: z.string(),
});

export type Trace = z.infer<typeof TraceSchema>;

export const MemoryEntrySchema = z.object({
  id: z.string(),
  sessionId: z.string(),
  role: z.enum(["system", "user", "assistant", "tool"]),
  content: z.string(),
  metadata: z.record(z.unknown()).optional(),
  createdAt: z.string(),
});

export type MemoryEntry = z.infer<typeof MemoryEntrySchema>;

export const RunSchema = z.object({
  id: z.string(),
  agentId: z.string(),
  sessionId: z.string(),
  prompt: z.string(),
  status: z.enum(["queued", "running", "completed", "failed", "cancelled"]),
  result: z.string().optional(),
  error: z.string().optional(),
  toolCalls: z.array(ToolExecutionSchema).optional(),
  retryCount: z.number().default(0),
  maxRetries: z.number().default(3),
  traceId: z.string().optional(),
  tokensUsed: z.number().default(0),
  durationMs: z.number().optional(),
  createdAt: z.string(),
  updatedAt: z.string(),
  completedAt: z.string().optional(),
});

export type Run = z.infer<typeof RunSchema>;

export const AgentConfigSchema = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string(),
  model: z.string().default("gpt-4"),
  provider: z.string().default("openai"),
  systemPrompt: z.string().optional(),
  tools: z.array(z.string()).default([]),
  maxRetries: z.number().default(3),
  temperature: z.number().min(0).max(2).default(0.7),
  maxTokens: z.number().default(4096),
  status: z.enum(["idle", "running", "paused", "error", "completed"]).default("idle"),
  createdAt: z.string(),
  updatedAt: z.string(),
});

export type AgentConfig = z.infer<typeof AgentConfigSchema>;

export const SessionSchema = z.object({
  id: z.string(),
  agentId: z.string(),
  status: z.enum(["active", "expired", "terminated"]).default("active"),
  metadata: z.record(z.string()).optional(),
  createdAt: z.string(),
  expiresAt: z.string().optional(),
});

export type Session = z.infer<typeof SessionSchema>;

export const WebhookConfigSchema = z.object({
  id: z.string(),
  url: z.string().url(),
  events: z.array(z.enum(["run.started", "run.completed", "run.failed", "tool.called", "tool.completed", "agent.error"])),
  secret: z.string().optional(),
  active: z.boolean().default(true),
  createdAt: z.string(),
});

export type WebhookConfig = z.infer<typeof WebhookConfigSchema>;

export const WebhookDeliverySchema = z.object({
  id: z.string(),
  webhookId: z.string(),
  event: z.string(),
  payload: z.record(z.unknown()),
  statusCode: z.number().optional(),
  success: z.boolean(),
  attempts: z.number().default(0),
  createdAt: z.string(),
});

export type WebhookDelivery = z.infer<typeof WebhookDeliverySchema>;

export const EvaluationResultSchema = z.object({
  id: z.string(),
  runId: z.string(),
  score: z.number().min(0).max(1),
  criteria: z.string(),
  feedback: z.string().optional(),
  passed: z.boolean(),
  evaluatedAt: z.string(),
});

export type EvaluationResult = z.infer<typeof EvaluationResultSchema>;

export const PromptTemplateSchema = z.object({
  id: z.string(),
  name: z.string(),
  template: z.string(),
  variables: z.array(z.string()),
  description: z.string().optional(),
  createdAt: z.string(),
  updatedAt: z.string(),
});

export type PromptTemplate = z.infer<typeof PromptTemplateSchema>;
