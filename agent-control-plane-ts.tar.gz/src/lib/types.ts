export interface Agent {
  id: string;
  name: string;
  description: string;
  model: string;
  provider: string;
  systemPrompt: string;
  tools: string[];
  maxRetries: number;
  temperature: number;
  createdAt: string;
  updatedAt: string;
}

export interface Session {
  id: string;
  agentId: string;
  status: "active" | "paused" | "completed" | "failed";
  messages: Message[];
  metadata: Record<string, unknown>;
  createdAt: string;
  updatedAt: string;
}

export interface Message {
  id: string;
  role: "system" | "user" | "assistant" | "tool";
  content: string;
  toolCallId?: string;
  toolName?: string;
  timestamp: string;
}

export interface Run {
  id: string;
  sessionId: string;
  agentId: string;
  status: "pending" | "running" | "completed" | "failed" | "retrying";
  input: string;
  output?: string;
  trace: TraceStep[];
  retryCount: number;
  maxRetries: number;
  error?: string;
  startedAt: string;
  completedAt?: string;
  duration?: number;
}

export interface TraceStep {
  id: string;
  runId: string;
  type: "llm_call" | "tool_call" | "tool_result" | "memory_read" | "memory_write" | "retry" | "webhook";
  name: string;
  input: unknown;
  output?: unknown;
  duration?: number;
  timestamp: string;
  metadata?: Record<string, unknown>;
}

export interface ToolDefinition {
  name: string;
  description: string;
  parameters: ToolParameter[];
  handler?: string;
}

export interface ToolParameter {
  name: string;
  type: "string" | "number" | "boolean" | "object" | "array";
  description: string;
  required: boolean;
  enum?: string[];
}

export interface Prompt {
  id: string;
  name: string;
  template: string;
  variables: string[];
  version: number;
  createdAt: string;
  updatedAt: string;
}

export interface WebhookConfig {
  id: string;
  name: string;
  url: string;
  events: string[];
  secret: string;
  active: boolean;
  createdAt: string;
}

export interface MemoryEntry {
  id: string;
  sessionId: string;
  key: string;
  value: unknown;
  embedding?: number[];
  timestamp: string;
}

export interface ProviderConfig {
  name: string;
  type: "openai" | "anthropic" | "local";
  apiKey?: string;
  baseUrl?: string;
  models: string[];
}

export interface EvaluationResult {
  runId: string;
  score: number;
  passed: boolean;
  criteria: string;
  feedback: string;
  timestamp: string;
}

export interface TaskQueueItem {
  id: string;
  type: "run" | "evaluation" | "webhook";
  payload: unknown;
  status: "queued" | "processing" | "completed" | "failed";
  priority: number;
  createdAt: string;
  processedAt?: string;
  error?: string;
}
