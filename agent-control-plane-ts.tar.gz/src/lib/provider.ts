import type { AgentConfig, ToolDefinition, Run, TraceSpan, ToolExecution } from "./types";
import { db, genId, now } from "./store";
import { toolRegistry } from "./tool-registry";
import { memoryStore } from "./memory";
import { taskQueue } from "./task-queue";
import { traceCollector } from "./traces";
import { webhookDispatcher } from "./webhooks";
import { evaluator } from "./evaluator";

export interface ProviderResponse {
  text: string;
  toolCalls?: { name: string; args: Record<string, unknown> }[];
  tokensUsed: number;
}

export interface LLMProvider {
  name: string;
  complete(config: AgentConfig, messages: { role: string; content: string }[]): Promise<ProviderResponse>;
}

class MockProvider implements LLMProvider {
  name = "mock";

  async complete(config: AgentConfig, messages: { role: string; content: string }[]): Promise<ProviderResponse> {
    const lastMessage = messages[messages.length - 1]?.content ?? "";
    const toolDefs = config.tools.map((t) => toolRegistry.get(t)).filter(Boolean) as ToolDefinition[];

    if (lastMessage.toLowerCase().includes("browse") || lastMessage.toLowerCase().includes("search")) {
      return {
        text: "I'll browse the web for you.",
        toolCalls: [{ name: "web_browse", args: { query: lastMessage } }],
        tokensUsed: 150,
      };
    }

    if (lastMessage.toLowerCase().includes("summarize") || lastMessage.toLowerCase().includes("summary")) {
      return {
        text: "I'll summarize that for you.",
        toolCalls: [{ name: "summarize", args: { text: lastMessage, maxLength: 200 } }],
        tokensUsed: 120,
      };
    }

    if (lastMessage.toLowerCase().includes("calculate") || lastMessage.toLowerCase().includes("compute")) {
      return {
        text: "I'll calculate that.",
        toolCalls: [{ name: "structured_tool", args: { operation: "calculate", expression: lastMessage } }],
        tokensUsed: 80,
      };
    }

    if (toolDefs.length > 0 && Math.random() > 0.6) {
      const tool = toolDefs[0];
      return {
        text: `Using tool: ${tool.name}`,
        toolCalls: [{ name: tool.name, args: {} }],
        tokensUsed: 100,
      };
    }

    return {
      text: `Agent "${config.name}" processed: ${lastMessage.substring(0, 100)}${lastMessage.length > 100 ? "..." : ""}`,
      tokensUsed: lastMessage.length + 50,
    };
  }
}

class OpenAIProvider implements LLMProvider {
  name = "openai";

  async complete(config: AgentConfig, messages: { role: string; content: string }[]): Promise<ProviderResponse> {
    return new MockProvider().complete(config, messages);
  }
}

class AnthropicProvider implements LLMProvider {
  name = "anthropic";

  async complete(config: AgentConfig, messages: { role: string; content: string }[]): Promise<ProviderResponse> {
    return new MockProvider().complete(config, messages);
  }
}

const providers: Map<string, LLMProvider> = new Map([
  ["mock", new MockProvider()],
  ["openai", new OpenAIProvider()],
  ["anthropic", new AnthropicProvider()],
]);

export function getProvider(name: string): LLMProvider {
  return providers.get(name) ?? providers.get("mock")!;
}

export async function executeRun(runId: string): Promise<Run> {
  const run = db.runs.get(runId);
  if (!run) throw new Error(`Run ${runId} not found`);

  const agent = db.agents.get(run.agentId);
  if (!agent) throw new Error(`Agent ${run.agentId} not found`);

  db.runs.update(runId, { status: "running" });
  db.agents.update(run.agentId, { status: "running" });

  const trace = db.traces.create({ runId, sessionId: run.sessionId, spans: [] });
  db.runs.update(runId, { traceId: trace.id });

  const rootSpan: TraceSpan = {
    id: genId(),
    runId,
    name: `run:${runId}`,
    kind: "agent",
    status: "ok",
    startTime: now(),
    attributes: { agentId: run.agentId, prompt: run.prompt },
  };

  await webhookDispatcher.dispatch("run.started", { runId, agentId: run.agentId });

  try {
    memoryStore.add(run.sessionId, { role: "user", content: run.prompt });

    if (agent.systemPrompt) {
      memoryStore.add(run.sessionId, { role: "system", content: agent.systemPrompt });
    }

    const messages = memoryStore.get(run.sessionId).map((m) => ({ role: m.role, content: m.content }));
    const provider = getProvider(agent.provider);

    const llmSpan: TraceSpan = {
      id: genId(),
      runId,
      parentSpanId: rootSpan.id,
      name: "llm.completion",
      kind: "llm",
      status: "ok",
      startTime: now(),
      attributes: { model: agent.model, provider: agent.provider, messageCount: messages.length },
    };

    const response = await provider.complete(agent, messages);

    llmSpan.endTime = now();
    llmSpan.attributes = { ...llmSpan.attributes, tokensUsed: response.tokensUsed };
    db.traces.addSpan(trace.id, llmSpan);

    const toolCalls: ToolExecution[] = [];

    if (response.toolCalls && response.toolCalls.length > 0) {
      for (const tc of response.toolCalls) {
        const toolSpan: TraceSpan = {
          id: genId(),
          runId,
          parentSpanId: rootSpan.id,
          name: `tool:${tc.name}`,
          kind: "tool",
          status: "ok",
          startTime: now(),
          attributes: { toolName: tc.name, args: tc.args },
        };

        const exec = await toolRegistry.execute(tc.name, tc.args);
        toolCalls.push(exec);

        if (exec.error) {
          toolSpan.status = "error";
          toolSpan.attributes = { ...toolSpan.attributes, error: exec.error };
        }

        toolSpan.endTime = now();
        db.traces.addSpan(trace.id, toolSpan);

        await webhookDispatcher.dispatch("tool.called", {
          runId,
          toolName: tc.name,
          args: tc.args,
        });

        memoryStore.add(run.sessionId, {
          role: "tool",
          content: JSON.stringify(exec.result ?? exec.error),
          metadata: { toolName: tc.name },
        });
      }
    }

    memoryStore.add(run.sessionId, { role: "assistant", content: response.text });

    const completedRun = db.runs.update(runId, {
      status: "completed",
      result: response.text,
      toolCalls,
      tokensUsed: response.tokensUsed,
      completedAt: now(),
    });

    rootSpan.endTime = now();
    rootSpan.status = "ok";
    db.traces.addSpan(trace.id, rootSpan);

    db.agents.update(run.agentId, { status: "idle" });

    await webhookDispatcher.dispatch("run.completed", {
      runId,
      agentId: run.agentId,
      status: "completed",
      tokensUsed: response.tokensUsed,
      toolCallCount: toolCalls.length,
    });

    await evaluator.evaluateRun(runId);

    return completedRun!;
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : "Unknown error";

    rootSpan.endTime = now();
    rootSpan.status = "error";
    rootSpan.attributes = { ...rootSpan.attributes, error: errorMessage };
    db.traces.addSpan(trace.id, rootSpan);

    db.agents.update(run.agentId, { status: "error" });

    const failedRun = db.runs.update(runId, {
      status: "failed",
      error: errorMessage,
      completedAt: now(),
    });

    await webhookDispatcher.dispatch("run.failed", { runId, agentId: run.agentId, error: errorMessage });

    if (run.retryCount < run.maxRetries) {
      db.runs.update(runId, { retryCount: run.retryCount + 1 });
      taskQueue.enqueue(run.agentId, run.sessionId, run.prompt, run.maxRetries);
    }

    return failedRun!;
  }
}
