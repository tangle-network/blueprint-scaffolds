import type { MemoryEntry } from "./types";
import { db } from "./store";

class MemoryStore {
  add(sessionId: string, entry: { role: MemoryEntry["role"]; content: string; metadata?: Record<string, unknown> }): MemoryEntry {
    return db.memory.add({ sessionId, ...entry });
  }

  get(sessionId: string): MemoryEntry[] {
    return db.memory.getBySession(sessionId).sort(
      (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
    );
  }

  clear(sessionId: string): void {
    db.memory.clear(sessionId);
  }

  getContextWindow(sessionId: string, maxEntries: number = 50): MemoryEntry[] {
    const entries = this.get(sessionId);
    return entries.slice(-maxEntries);
  }

  getFormattedContext(sessionId: string): string {
    const entries = this.get(sessionId);
    return entries.map((e) => `[${e.role}]: ${e.content}`).join("\n");
  }
}

export const memoryStore = new MemoryStore();
