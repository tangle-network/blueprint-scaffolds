import { db, genId, now } from "./store";
import type { Trace, TraceSpan } from "./types";

class TraceCollector {
  createTrace(runId: string, sessionId?: string): Trace {
    return db.traces.create({ runId, sessionId, spans: [] });
  }

  addSpan(traceId: string, span: Omit<TraceSpan, "id">): TraceSpan {
    const fullSpan: TraceSpan = { ...span, id: genId() };
    db.traces.addSpan(traceId, fullSpan);
    return fullSpan;
  }

  getTrace(traceId: string): Trace | undefined {
    return db.traces.get(traceId);
  }

  getTracesForRun(runId: string): Trace[] {
    return db.traces.getByRun(runId);
  }

  getTraceStats(traceId: string): { spanCount: number; totalDurationMs: number; errorCount: number } {
    const trace = db.traces.get(traceId);
    if (!trace) return { spanCount: 0, totalDurationMs: 0, errorCount: 0 };

    let totalDurationMs = 0;
    let errorCount = 0;

    for (const span of trace.spans) {
      if (span.endTime && span.startTime) {
        totalDurationMs += new Date(span.endTime).getTime() - new Date(span.startTime).getTime();
      }
      if (span.status === "error") errorCount++;
    }

    return { spanCount: trace.spans.length, totalDurationMs, errorCount };
  }

  startSpan(runId: string, name: string, kind: TraceSpan["kind"], parentSpanId?: string): TraceSpan {
    return {
      id: genId(),
      runId,
      parentSpanId,
      name,
      kind,
      status: "ok",
      startTime: now(),
    };
  }

  endSpan(span: TraceSpan, status: TraceSpan["status"] = "ok", attributes?: Record<string, unknown>): TraceSpan {
    span.endTime = now();
    span.status = status;
    if (attributes) span.attributes = { ...span.attributes, ...attributes };
    return span;
  }
}

export const traceCollector = new TraceCollector();
