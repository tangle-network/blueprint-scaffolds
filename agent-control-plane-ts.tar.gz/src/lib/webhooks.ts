import { db } from "./store";

type WebhookEvent = "run.started" | "run.completed" | "run.failed" | "tool.called" | "tool.completed" | "agent.error";

class WebhookDispatcher {
  async dispatch(event: WebhookEvent, payload: Record<string, unknown>): Promise<void> {
    const webhooks = db.webhooks.list().filter((w) => w.active && w.events.includes(event));

    for (const webhook of webhooks) {
      const delivery = db.webhooks.deliveries.create({
        webhookId: webhook.id,
        event,
        payload,
        success: false,
        attempts: 0,
      });

      try {
        const maxAttempts = 3;
        let lastError: string | undefined;

        for (let attempt = 1; attempt <= maxAttempts; attempt++) {
          try {
            const response = await fetch(webhook.url, {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                "X-Webhook-Signature": webhook.secret ?? "",
                "X-Webhook-Event": event,
                "X-Webhook-Delivery": delivery.id,
              },
              body: JSON.stringify({ event, timestamp: new Date().toISOString(), data: payload }),
            });

            db.webhooks.deliveries.create({
              webhookId: webhook.id,
              event,
              payload: { ...payload, attempt, statusCode: response.status },
              statusCode: response.status,
              success: response.ok,
              attempts: attempt,
            });

            if (response.ok) break;
            lastError = `HTTP ${response.status}`;
          } catch (err) {
            lastError = err instanceof Error ? err.message : "Fetch error";
          }
        }

        if (lastError) {
          db.webhooks.deliveries.create({
            webhookId: webhook.id,
            event,
            payload,
            error: lastError,
            success: false,
            attempts: maxAttempts,
          });
        }
      } catch {
        // Webhook delivery completely failed
      }
    }
  }
}

export const webhookDispatcher = new WebhookDispatcher();
