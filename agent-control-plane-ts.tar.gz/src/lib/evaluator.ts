import { db } from "./store";
import type { Run } from "./types";

interface EvaluationCriteria {
  name: string;
  evaluate: (run: Run) => { score: number; passed: boolean; feedback: string };
}

const criteria: EvaluationCriteria[] = [
  {
    name: "completeness",
    evaluate: (run: Run) => {
      const hasResult = !!run.result && run.result.length > 0;
      const hasToolCalls = (run.toolCalls?.length ?? 0) > 0;
      const score = (hasResult ? 0.6 : 0) + (hasToolCalls ? 0.4 : 0);
      return {
        score,
        passed: score >= 0.5,
        feedback: hasResult ? "Run produced output" : "Run produced no output",
      };
    },
  },
  {
    name: "efficiency",
    evaluate: (run: Run) => {
      const toolCount = run.toolCalls?.length ?? 0;
      const duration = run.durationMs ?? 0;
      const score = toolCount <= 5 && duration < 30000 ? 0.9 : 0.5;
      return {
        score,
        passed: score >= 0.6,
        feedback: `Used ${toolCount} tool calls in ${duration}ms`,
      };
    },
  },
  {
    name: "reliability",
    evaluate: (run: Run) => {
      const hasError = !!run.error;
      const score = hasError ? 0.2 : 0.9;
      return {
        score,
        passed: !hasError,
        feedback: hasError ? `Error: ${run.error}` : "No errors detected",
      };
    },
  },
];

class Evaluator {
  async evaluateRun(runId: string): Promise<void> {
    const run = db.runs.get(runId);
    if (!run || run.status !== "completed") return;

    for (const c of criteria) {
      const result = c.evaluate(run);
      db.evaluations.create({
        runId,
        criteria: c.name,
        score: result.score,
        passed: result.passed,
        feedback: result.feedback,
      });
    }
  }

  getEvaluations(runId: string) {
    return db.evaluations.getByRun(runId);
  }
}

export const evaluator = new Evaluator();
