import { z, ZodError } from "zod";
import { genId, now } from "./store";
import type { ToolDefinition, ToolExecution } from "./types";

interface RegisteredTool {
  definition: ToolDefinition;
  handler: (args: Record<string, unknown>) => Promise<unknown>;
}

class ToolRegistry {
  private tools: Map<string, RegisteredTool> = new Map();

  register(definition: ToolDefinition, handler: (args: Record<string, unknown>) => Promise<unknown>): void {
    this.tools.set(definition.name, { definition, handler });
  }

  list(): ToolDefinition[] {
    return Array.from(this.tools.values()).map((t) => t.definition);
  }

  get(name: string): ToolDefinition | undefined {
    return this.tools.get(name)?.definition;
  }

  async execute(name: string, args: Record<string, unknown>): Promise<ToolExecution> {
    const registered = this.tools.get(name);
    const startedAt = now();

    if (!registered) {
      return {
        toolName: name,
        args,
        error: `Tool "${name}" not found`,
        startedAt,
        completedAt: now(),
        durationMs: 0,
      };
    }

    try {
      const paramsSchema = z.object(
        Object.fromEntries(
          registered.definition.parameters.map((p) => [
            p.name,
            p.required ? this.typeToZod(p.type) : this.typeToZod(p.type).optional(),
          ])
        )
      );

      const validated = paramsSchema.parse(args);
      const startTime = Date.now();
      const result = await registered.handler(validated);
      const durationMs = Date.now() - startTime;

      return {
        toolName: name,
        args,
        result,
        durationMs,
        startedAt,
        completedAt: now(),
      };
    } catch (err) {
      const durationMs = Date.now() - new Date(startedAt).getTime();
      if (err instanceof ZodError) {
        return {
          toolName: name,
          args,
          error: `Validation error: ${err.errors.map((e) => `${e.path.join(".")}: ${e.message}`).join(", ")}`,
          durationMs,
          startedAt,
          completedAt: now(),
        };
      }
      return {
        toolName: name,
        args,
        error: err instanceof Error ? err.message : "Unknown tool error",
        durationMs,
        startedAt,
        completedAt: now(),
      };
    }
  }

  private typeToZod(type: string) {
    switch (type) {
      case "string":
        return z.string();
      case "number":
        return z.number();
      case "boolean":
        return z.boolean();
      case "object":
        return z.record(z.unknown());
      case "array":
        return z.array(z.unknown());
      default:
        return z.unknown();
    }
  }
}

export const toolRegistry = new ToolRegistry();

toolRegistry.register(
  {
    name: "web_browse",
    description: "Browse the web and retrieve content from a URL or search query",
    type: "browser",
    parameters: [
      { name: "query", type: "string", required: true, description: "Search query or URL to browse" },
      { name: "maxLength", type: "number", required: false, description: "Max response length" },
    ],
  },
  async (args) => {
    const query = String(args.query ?? "");
    return {
      title: `Search results for: ${query}`,
      url: `https://search.example.com/?q=${encodeURIComponent(query)}`,
      snippet: `Here are the top results for "${query}". This is a simulated browse response from the agent control plane.`,
      content: `Simulated web content for query: "${query}". In production, this would fetch real web content.`,
    };
  }
);

toolRegistry.register(
  {
    name: "summarize",
    description: "Summarize text content to a specified maximum length",
    type: "function",
    parameters: [
      { name: "text", type: "string", required: true, description: "Text to summarize" },
      { name: "maxLength", type: "number", required: false, description: "Maximum length of summary" },
    ],
  },
  async (args) => {
    const text = String(args.text ?? "");
    const maxLen = Number(args.maxLength ?? 200);
    const summary = text.length > maxLen ? text.substring(0, maxLen) + "..." : text;
    return { summary, originalLength: text.length, summaryLength: summary.length };
  }
);

toolRegistry.register(
  {
    name: "structured_tool",
    description: "Execute a structured operation with validated input/output schemas",
    type: "structured",
    parameters: [
      { name: "operation", type: "string", required: true, description: "Operation to perform" },
      { name: "expression", type: "string", required: false, description: "Expression or data for the operation" },
    ],
  },
  async (args) => {
    const op = String(args.operation ?? "unknown");
    const expr = String(args.expression ?? "");
    return {
      operation: op,
      input: expr,
      result: `Executed structured operation "${op}" with input: "${expr}"`,
      schema: { input: "string", output: "string" },
    };
  }
);

toolRegistry.register(
  {
    name: "http_request",
    description: "Make an HTTP request to an external API",
    type: "http",
    parameters: [
      { name: "url", type: "string", required: true, description: "URL to request" },
      { name: "method", type: "string", required: false, description: "HTTP method" },
      { name: "body", type: "object", required: false, description: "Request body" },
    ],
  },
  async (args) => {
    return {
      status: 200,
      url: String(args.url),
      method: String(args.method ?? "GET"),
      body: { message: "Simulated HTTP response from agent control plane" },
    };
  }
);
