import { v4 as uuid } from "uuid";
import type {
  AgentConfig,
  Session,
  Run,
  ToolDefinition,
  Trace,
  TraceSpan,
  MemoryEntry,
  WebhookConfig,
  WebhookDelivery,
  EvaluationResult,
  PromptTemplate,
} from "./types";

type StoreCollections = {
  agents: Map<string, AgentConfig>;
  sessions: Map<string, Session>;
  runs: Map<string, Run>;
  tools: Map<string, ToolDefinition>;
  traces: Map<string, Trace>;
  memory: Map<string, MemoryEntry>;
  webhooks: Map<string, WebhookConfig>;
  webhookDeliveries: Map<string, WebhookDelivery>;
  evaluations: Map<string, EvaluationResult>;
  prompts: Map<string, PromptTemplate>;
};

const store: StoreCollections = {
  agents: new Map(),
  sessions: new Map(),
  runs: new Map(),
  tools: new Map(),
  traces: new Map(),
  memory: new Map(),
  webhooks: new Map(),
  webhookDeliveries: new Map(),
  evaluations: new Map(),
  prompts: new Map(),
};

export function genId(): string {
  return uuid();
}

export function now(): string {
  return new Date().toISOString();
}

export const db = {
  agents: {
    list: () => Array.from(store.agents.values()),
    get: (id: string) => store.agents.get(id),
    create: (data: Omit<AgentConfig, "id" | "createdAt" | "updatedAt">): AgentConfig => {
      const agent: AgentConfig = { ...data, id: genId(), createdAt: now(), updatedAt: now() };
      store.agents.set(agent.id, agent);
      return agent;
    },
    update: (id: string, data: Partial<AgentConfig>): AgentConfig | undefined => {
      const existing = store.agents.get(id);
      if (!existing) return undefined;
      const updated = { ...existing, ...data, updatedAt: now() };
      store.agents.set(id, updated);
      return updated;
    },
    delete: (id: string) => store.agents.delete(id),
  },
  sessions: {
    list: () => Array.from(store.sessions.values()),
    get: (id: string) => store.sessions.get(id),
    getByAgent: (agentId: string) => Array.from(store.sessions.values()).filter((s) => s.agentId === agentId),
    create: (data: Omit<Session, "id" | "createdAt">): Session => {
      const session: Session = { ...data, id: genId(), createdAt: now() };
      store.sessions.set(session.id, session);
      return session;
    },
    update: (id: string, data: Partial<Session>): Session | undefined => {
      const existing = store.sessions.get(id);
      if (!existing) return undefined;
      const updated = { ...existing, ...data };
      store.sessions.set(id, updated);
      return updated;
    },
    delete: (id: string) => store.sessions.delete(id),
  },
  runs: {
    list: () => Array.from(store.runs.values()),
    get: (id: string) => store.runs.get(id),
    getBySession: (sessionId: string) => Array.from(store.runs.values()).filter((r) => r.sessionId === sessionId),
    getByAgent: (agentId: string) => Array.from(store.runs.values()).filter((r) => r.agentId === agentId),
    create: (data: Omit<Run, "id" | "createdAt" | "updatedAt">): Run => {
      const run: Run = { ...data, id: genId(), createdAt: now(), updatedAt: now() };
      store.runs.set(run.id, run);
      return run;
    },
    update: (id: string, data: Partial<Run>): Run | undefined => {
      const existing = store.runs.get(id);
      if (!existing) return undefined;
      const updated = { ...existing, ...data, updatedAt: now() };
      store.runs.set(id, updated);
      return updated;
    },
  },
  tools: {
    list: () => Array.from(store.tools.values()),
    get: (id: string) => store.tools.get(id),
    getByName: (name: string) => Array.from(store.tools.values()).find((t) => t.name === name),
    create: (data: ToolDefinition & { id?: string }): ToolDefinition => {
      const tool: ToolDefinition = { ...data };
      store.tools.set(tool.name, tool);
      return tool;
    },
    delete: (name: string) => store.tools.delete(name),
  },
  traces: {
    list: () => Array.from(store.traces.values()),
    get: (id: string) => store.traces.get(id),
    getByRun: (runId: string) => Array.from(store.traces.values()).filter((t) => t.runId === runId),
    create: (data: Omit<Trace, "id" | "createdAt">): Trace => {
      const trace: Trace = { ...data, id: genId(), createdAt: now() };
      store.traces.set(trace.id, trace);
      return trace;
    },
    addSpan: (traceId: string, span: TraceSpan): Trace | undefined => {
      const trace = store.traces.get(traceId);
      if (!trace) return undefined;
      trace.spans.push(span);
      return trace;
    },
  },
  memory: {
    getBySession: (sessionId: string) => Array.from(store.memory.values()).filter((m) => m.sessionId === sessionId),
    add: (data: Omit<MemoryEntry, "id" | "createdAt">): MemoryEntry => {
      const entry: MemoryEntry = { ...data, id: genId(), createdAt: now() };
      store.memory.set(entry.id, entry);
      return entry;
    },
    clear: (sessionId: string) => {
      for (const [id, entry] of store.memory) {
        if (entry.sessionId === sessionId) store.memory.delete(id);
      }
    },
  },
  webhooks: {
    list: () => Array.from(store.webhooks.values()),
    get: (id: string) => store.webhooks.get(id),
    create: (data: Omit<WebhookConfig, "id" | "createdAt">): WebhookConfig => {
      const webhook: WebhookConfig = { ...data, id: genId(), createdAt: now() };
      store.webhooks.set(webhook.id, webhook);
      return webhook;
    },
    update: (id: string, data: Partial<WebhookConfig>): WebhookConfig | undefined => {
      const existing = store.webhooks.get(id);
      if (!existing) return undefined;
      const updated = { ...existing, ...data };
      store.webhooks.set(id, updated);
      return updated;
    },
    delete: (id: string) => store.webhooks.delete(id),
    deliveries: {
      list: () => Array.from(store.webhookDeliveries.values()),
      getByWebhook: (webhookId: string) =>
        Array.from(store.webhookDeliveries.values()).filter((d) => d.webhookId === webhookId),
      create: (data: Omit<WebhookDelivery, "id" | "createdAt">): WebhookDelivery => {
        const delivery: WebhookDelivery = { ...data, id: genId(), createdAt: now() };
        store.webhookDeliveries.set(delivery.id, delivery);
        return delivery;
      },
    },
  },
  evaluations: {
    list: () => Array.from(store.evaluations.values()),
    getByRun: (runId: string) => Array.from(store.evaluations.values()).filter((e) => e.runId === runId),
    create: (data: Omit<EvaluationResult, "id" | "evaluatedAt">): EvaluationResult => {
      const evaluation: EvaluationResult = { ...data, id: genId(), evaluatedAt: now() };
      store.evaluations.set(evaluation.id, evaluation);
      return evaluation;
    },
  },
  prompts: {
    list: () => Array.from(store.prompts.values()),
    get: (id: string) => store.prompts.get(id),
    create: (data: Omit<PromptTemplate, "id" | "createdAt" | "updatedAt">): PromptTemplate => {
      const prompt: PromptTemplate = { ...data, id: genId(), createdAt: now(), updatedAt: now() };
      store.prompts.set(prompt.id, prompt);
      return prompt;
    },
    update: (id: string, data: Partial<PromptTemplate>): PromptTemplate | undefined => {
      const existing = store.prompts.get(id);
      if (!existing) return undefined;
      const updated = { ...existing, ...data, updatedAt: now() };
      store.prompts.set(id, updated);
      return updated;
    },
    delete: (id: string) => store.prompts.delete(id),
  },
};
