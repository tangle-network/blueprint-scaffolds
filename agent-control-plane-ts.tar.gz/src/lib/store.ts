import { Agent, Session, Run, Prompt, EvaluationResult } from "@/lib/types";
import { v4 as uuid } from "uuid";

class Store {
  agents: Map<string, Agent> = new Map();
  sessions: Map<string, Session> = new Map();
  runs: Map<string, Run> = new Map();
  prompts: Map<string, Prompt> = new Map();
  evaluations: Map<string, EvaluationResult> = new Map();

  createAgent(data: Omit<Agent, "id" | "createdAt" | "updatedAt">): Agent {
    const agent: Agent = {
      id: uuid(),
      ...data,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.agents.set(agent.id, agent);
    return agent;
  }

  updateAgent(id: string, data: Partial<Agent>): Agent | null {
    const agent = this.agents.get(id);
    if (!agent) return null;
    Object.assign(agent, data, { updatedAt: new Date().toISOString() });
    return agent;
  }

  createSession(data: Omit<Session, "id" | "createdAt" | "updatedAt" | "messages" | "metadata">): Session {
    const session: Session = {
      id: uuid(),
      messages: [],
      metadata: {},
      ...data,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.sessions.set(session.id, session);
    return session;
  }

  updateSession(id: string, data: Partial<Session>): Session | null {
    const session = this.sessions.get(id);
    if (!session) return null;
    Object.assign(session, data, { updatedAt: new Date().toISOString() });
    return session;
  }

  createRun(data: Omit<Run, "id" | "trace" | "retryCount" | "startedAt">): Run {
    const run: Run = {
      id: uuid(),
      trace: [],
      retryCount: 0,
      startedAt: new Date().toISOString(),
      ...data,
    };
    this.runs.set(run.id, run);
    return run;
  }

  updateRun(id: string, data: Partial<Run>): Run | null {
    const run = this.runs.get(id);
    if (!run) return null;
    Object.assign(run, data);
    return run;
  }

  createPrompt(data: Omit<Prompt, "id" | "version" | "createdAt" | "updatedAt">): Prompt {
    const prompt: Prompt = {
      id: uuid(),
      version: 1,
      ...data,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.prompts.set(prompt.id, prompt);
    return prompt;
  }

  updatePrompt(id: string, data: Partial<Prompt>): Prompt | null {
    const prompt = this.prompts.get(id);
    if (!prompt) return null;
    Object.assign(prompt, data, { updatedAt: new Date().toISOString() });
    return prompt;
  }

  addEvaluation(result: EvaluationResult): void {
    this.evaluations.set(result.runId + "-" + result.criteria, result);
  }

  getEvaluationsForRun(runId: string): EvaluationResult[] {
    return Array.from(this.evaluations.values()).filter((e) => e.runId === runId);
  }

  getAllEvaluations(): EvaluationResult[] {
    return Array.from(this.evaluations.values());
  }

  getAllTraces(): { runId: string; trace: Run["trace"] }[] {
    return Array.from(this.runs.values())
      .filter((r) => r.trace.length > 0)
      .map((r) => ({ runId: r.id, trace: r.trace }));
  }
}

export const store = new Store();
