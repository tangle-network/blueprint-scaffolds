import { db, genId, now } from "./store";
import { executeRun } from "./provider";

interface QueueItem {
  id: string;
  agentId: string;
  sessionId: string;
  prompt: string;
  maxRetries: number;
  runId: string;
  enqueuedAt: string;
  priority: number;
}

class TaskQueue {
  private queue: QueueItem[] = [];
  private processing: Map<string, NodeJS.Timeout> = new Map();

  enqueue(agentId: string, sessionId: string, prompt: string, maxRetries: number = 3, priority: number = 0): string {
    const run = db.runs.create({
      agentId,
      sessionId,
      prompt,
      status: "queued",
      maxRetries,
      retryCount: 0,
      tokensUsed: 0,
    });

    const item: QueueItem = {
      id: genId(),
      agentId,
      sessionId,
      prompt,
      maxRetries,
      runId: run.id,
      enqueuedAt: now(),
      priority,
    };

    this.queue.push(item);
    this.queue.sort((a, b) => b.priority - a.priority);
    this.scheduleNext();

    return run.id;
  }

  private scheduleNext(): void {
    if (this.processing.size >= 5) return;
    const item = this.queue.shift();
    if (!item) return;

    const timer = setTimeout(async () => {
      try {
        await executeRun(item.runId);
      } finally {
        this.processing.delete(item.id);
        this.scheduleNext();
      }
    }, 0);

    this.processing.set(item.id, timer);
  }

  getStatus(): { queued: number; processing: number } {
    return { queued: this.queue.length, processing: this.processing.size };
  }

  cancel(runId: string): boolean {
    const idx = this.queue.findIndex((item) => item.runId === runId);
    if (idx >= 0) {
      this.queue.splice(idx, 1);
      db.runs.update(runId, { status: "cancelled", completedAt: now() });
      return true;
    }
    return false;
  }
}

export const taskQueue = new TaskQueue();
