import { createTool, stringParam } from "../core/tool-registry.js";

export const browseTool = createTool(
  "browse",
  "Fetch content from a URL and return the text content",
  {
    url: stringParam("The URL to fetch", true),
  },
  async (args) => {
    const url = args.url as string;
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 10000);
      const resp = await fetch(url, { signal: controller.signal });
      clearTimeout(timeout);
      if (!resp.ok) return `HTTP ${resp.status}: ${resp.statusText}`;
      const text = await resp.text();
      return text.slice(0, 5000);
    } catch (err) {
      return `Failed to fetch ${url}: ${err instanceof Error ? err.message : String(err)}`;
    }
  },
);

export const summarizeTool = createTool(
  "summarize",
  "Summarize the given text content",
  {
    text: stringParam("The text to summarize", true),
    maxLength: stringParam("Maximum length of summary in words", false),
  },
  async (args) => {
    const text = args.text as string;
    const maxLen = args.maxLength ? parseInt(args.maxLength as string, 10) : 100;
    const sentences = text.split(/[.!?]+/).filter((s) => s.trim().length > 0);
    const summary = sentences.slice(0, Math.max(1, Math.ceil(sentences.length / 3))).join(". ").trim();
    const words = summary.split(/\s+/);
    if (words.length > maxLen) {
      return words.slice(0, maxLen).join(" ") + "...";
    }
    return summary || text.slice(0, 500);
  },
);

export const calculatorTool = createTool(
  "calculator",
  "Evaluate a simple mathematical expression",
  {
    expression: stringParam("The math expression to evaluate", true),
  },
  async (args) => {
    const expr = args.expression as string;
    const safe = expr.replace(/[^0-9+\-*/().%\s]/g, "");
    if (safe.length === 0) return "Invalid expression";
    try {
      const result = Function(`"use strict"; return (${safe})`)();
      return `Result: ${result}`;
    } catch {
      return `Error evaluating: ${expr}`;
    }
  },
);

export const jsonExtractorTool = createTool(
  "json_extract",
  "Extract a value from JSON text using a dot-path notation",
  {
    json: stringParam("JSON string to parse", true),
    path: stringParam("Dot-notation path (e.g. data.items.0.name)", true),
  },
  async (args) => {
    try {
      const data = JSON.parse(args.json as string);
      const parts = (args.path as string).split(".");
      let current: unknown = data;
      for (const part of parts) {
        if (current === null || current === undefined) return `Path not found: ${args.path}`;
        current = (current as Record<string, unknown>)[part];
      }
      return JSON.stringify(current, null, 2);
    } catch (err) {
      return `Error: ${err instanceof Error ? err.message : String(err)}`;
    }
  },
);

export const allTools = [browseTool, summarizeTool, calculatorTool, jsonExtractorTool];
