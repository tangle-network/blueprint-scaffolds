export interface RunTrace {
  id: string;
  sessionId: string;
  agentId: string;
  parentRunId?: string;
  status: "pending" | "running" | "completed" | "failed" | "retrying";
  input: string;
  output?: string;
  toolCalls: ToolCallRecord[];
  tokenUsage: TokenUsage;
  startedAt: number;
  finishedAt?: number;
  error?: string;
  retryCount: number;
  metadata: Record<string, unknown>;
}

export interface ToolCallRecord {
  id: string;
  toolName: string;
  args: Record<string, unknown>;
  result?: unknown;
  status: "pending" | "completed" | "failed";
  startedAt: number;
  finishedAt?: number;
  error?: string;
}

export interface TokenUsage {
  prompt: number;
  completion: number;
  total: number;
}

export interface Session {
  id: string;
  agentId: string;
  status: "active" | "paused" | "closed";
  memory: MemoryEntry[];
  createdAt: number;
  updatedAt: number;
  metadata: Record<string, unknown>;
}

export interface MemoryEntry {
  id: string;
  role: "system" | "user" | "assistant" | "tool";
  content: string;
  timestamp: number;
  metadata?: Record<string, unknown>;
}

export interface ToolDefinition {
  name: string;
  description: string;
  parameters: Record<string, ToolParameter>;
  handler: ToolHandler;
}

export interface ToolParameter {
  type: "string" | "number" | "boolean" | "object" | "array";
  description?: string;
  required?: boolean;
  enum?: string[];
}

export type ToolHandler = (args: Record<string, unknown>) => Promise<unknown>;

export interface AgentConfig {
  id: string;
  name: string;
  description: string;
  systemPrompt: string;
  tools: string[];
  provider: string;
  maxRetries: number;
  retryDelayMs: number;
  maxTokens: number;
  temperature: number;
}

export interface ProviderMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface ProviderResponse {
  content: string;
  toolCalls?: PendingToolCall[];
  tokenUsage: TokenUsage;
}

export interface PendingToolCall {
  id: string;
  name: string;
  args: Record<string, unknown>;
}

export interface TaskQueueItem {
  id: string;
  sessionId: string;
  agentId: string;
  input: string;
  status: "queued" | "processing" | "completed" | "failed";
  priority: number;
  createdAt: number;
  startedAt?: number;
  completedAt?: number;
  error?: string;
  maxRetries: number;
  retryCount: number;
}

export interface WebhookConfig {
  id: string;
  url: string;
  events: WebhookEvent[];
  headers: Record<string, string>;
  active: boolean;
}

export type WebhookEvent =
  | "run.started"
  | "run.completed"
  | "run.failed"
  | "tool.called"
  | "tool.completed"
  | "tool.failed"
  | "session.created"
  | "session.closed";

export interface WebhookPayload {
  event: WebhookEvent;
  timestamp: number;
  data: Record<string, unknown>;
}

export interface EvalHook {
  id: string;
  name: string;
  description: string;
  evaluate: (input: string, output: string, trace: RunTrace) => EvalResult;
}

export interface EvalResult {
  score: number;
  passed: boolean;
  reasoning: string;
}
