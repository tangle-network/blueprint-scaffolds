import { Agent, Message, Run, TraceStep, ProviderConfig } from "@/lib/types";
import { v4 as uuid } from "uuid";

export interface LLMResponse {
  content: string;
  toolCalls?: { id: string; name: string; arguments: Record<string, unknown> }[];
  usage?: { promptTokens: number; completionTokens: number; totalTokens: number };
}

export abstract class BaseProvider {
  abstract name: string;
  abstract call(
    messages: Message[],
    config: { model: string; temperature: number; tools?: unknown[] }
  ): Promise<LLMResponse>;
}

export class OpenAIProvider extends BaseProvider {
  name = "openai";
  private config: ProviderConfig;

  constructor(config: ProviderConfig) {
    super();
    this.config = config;
  }

  async call(
    messages: Message[],
    config: { model: string; temperature: number; tools?: unknown[] }
  ): Promise<LLMResponse> {
    const formatted = messages.map((m) => ({ role: m.role, content: m.content }));

    if (this.config.baseUrl) {
      try {
        const res = await fetch(`${this.config.baseUrl}/chat/completions`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(this.config.apiKey ? { Authorization: `Bearer ${this.config.apiKey}` } : {}),
          },
          body: JSON.stringify({ model: config.model, messages: formatted, temperature: config.temperature }),
        });
        const data = await res.json();
        return {
          content: data.choices?.[0]?.message?.content ?? "",
          usage: data.usage
            ? {
                promptTokens: data.usage.prompt_tokens,
                completionTokens: data.usage.completion_tokens,
                totalTokens: data.usage.total_tokens,
              }
            : undefined,
        };
      } catch {
        return { content: `[${this.name}] Error calling model ${config.model}` };
      }
    }

    return {
      content: `[${this.name}] Simulated response for: "${formatted[formatted.length - 1]?.content?.slice(0, 100)}"`,
      usage: { promptTokens: 50, completionTokens: 120, totalTokens: 170 },
    };
  }
}

export class AnthropicProvider extends BaseProvider {
  name = "anthropic";
  private config: ProviderConfig;

  constructor(config: ProviderConfig) {
    super();
    this.config = config;
  }

  async call(
    messages: Message[],
    config: { model: string; temperature: number; tools?: unknown[] }
  ): Promise<LLMResponse> {
    return {
      content: `[${this.name}] Simulated response for model ${config.model}: "${messages[messages.length - 1]?.content?.slice(0, 100)}"`,
      usage: { promptTokens: 40, completionTokens: 100, totalTokens: 140 },
    };
  }
}

export class ProviderFactory {
  private static providers: Map<string, BaseProvider> = new Map();

  static register(name: string, provider: BaseProvider) {
    this.providers.set(name, provider);
  }

  static get(name: string): BaseProvider | undefined {
    return this.providers.get(name);
  }

  static create(config: ProviderConfig): BaseProvider {
    switch (config.type) {
      case "openai":
        return new OpenAIProvider(config);
      case "anthropic":
        return new AnthropicProvider(config);
      default:
        return new OpenAIProvider(config);
    }
  }
}

export async function executeWithTracing(
  run: Run,
  stepType: TraceStep["type"],
  stepName: string,
  input: unknown,
  fn: () => Promise<unknown>
): Promise<{ output: unknown; step: TraceStep }> {
  const start = Date.now();
  try {
    const output = await fn();
    const step: TraceStep = {
      id: uuid(),
      runId: run.id,
      type: stepType,
      name: stepName,
      input,
      output,
      duration: Date.now() - start,
      timestamp: new Date().toISOString(),
    };
    return { output, step };
  } catch (error) {
    const step: TraceStep = {
      id: uuid(),
      runId: run.id,
      type: stepType,
      name: stepName,
      input,
      output: { error: error instanceof Error ? error.message : String(error) },
      duration: Date.now() - start,
      timestamp: new Date().toISOString(),
    };
    return { output: null, step };
  }
}
