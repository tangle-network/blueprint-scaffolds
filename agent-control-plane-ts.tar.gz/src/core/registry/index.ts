import { ToolDefinition } from "@/lib/types";

export interface ToolExecutionContext {
  sessionId: string;
  agentId: string;
  runId: string;
}

export interface ToolExecutionResult {
  success: boolean;
  output: unknown;
  error?: string;
}

type ToolHandler = (params: Record<string, unknown>, ctx: ToolExecutionContext) => Promise<ToolExecutionResult>;

interface RegisteredTool extends ToolDefinition {
  handler?: ToolHandler;
}

class ToolRegistryClass {
  private tools: Map<string, RegisteredTool> = new Map();

  register(definition: ToolDefinition, handler?: ToolHandler) {
    this.tools.set(definition.name, { ...definition, handler });
  }

  get(name: string): RegisteredTool | undefined {
    return this.tools.get(name);
  }

  list(): RegisteredTool[] {
    return Array.from(this.tools.values());
  }

  async execute(
    toolName: string,
    params: Record<string, unknown>,
    ctx: ToolExecutionContext
  ): Promise<ToolExecutionResult> {
    const tool = this.tools.get(toolName);
    if (!tool) return { success: false, output: null, error: `Tool "${toolName}" not found` };

    if (tool.handler) {
      try {
        return await tool.handler(params, ctx);
      } catch (error) {
        return { success: false, output: null, error: error instanceof Error ? error.message : String(error) };
      }
    }

    return { success: true, output: { message: `Tool "${toolName}" executed (no handler)`, params } };
  }

  unregister(name: string) {
    this.tools.delete(name);
  }
}

export const ToolRegistry = new ToolRegistryClass();

ToolRegistry.register({
  name: "browse",
  description: "Browse a URL and extract its text content",
  parameters: [
    { name: "url", type: "string", description: "The URL to browse", required: true },
    { name: "maxLength", type: "number", description: "Max content length to return", required: false },
  ],
}, async (params) => {
  const url = params.url as string;
  try {
    const res = await fetch(url);
    const text = await res.text();
    const cleaned = text.replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim().slice(0, (params.maxLength as number) ?? 5000);
    return { success: true, output: { content: cleaned, url } };
  } catch (error) {
    return { success: false, output: null, error: error instanceof Error ? error.message : String(error) };
  }
});

ToolRegistry.register({
  name: "summarize",
  description: "Summarize the provided text content",
  parameters: [
    { name: "text", type: "string", description: "The text to summarize", required: true },
    { name: "maxLength", type: "number", description: "Max summary length in words", required: false },
  ],
}, async (params) => {
  const text = params.text as string;
  const words = text.split(" ");
  const maxLen = (params.maxLength as number) ?? 100;
  const summary = words.length > maxLen ? words.slice(0, maxLen).join(" ") + "..." : text;
  return { success: true, output: { summary, originalLength: words.length } };
});

ToolRegistry.register({
  name: "structured_query",
  description: "Execute a structured data query against a knowledge base",
  parameters: [
    { name: "query", type: "string", description: "The query to execute", required: true },
    { name: "format", type: "string", description: "Response format", required: false, enum: ["json", "text", "table"] },
    { name: "limit", type: "number", description: "Max results to return", required: false },
  ],
}, async (params) => {
  return {
    success: true,
    output: {
      query: params.query,
      format: params.format ?? "json",
      results: [
        { id: 1, title: "Sample result", relevance: 0.95 },
        { id: 2, title: "Another result", relevance: 0.87 },
      ],
      total: 2,
    },
  };
});

ToolRegistry.register({
  name: "http_request",
  description: "Make an HTTP request to an external API",
  parameters: [
    { name: "url", type: "string", description: "The URL to request", required: true },
    { name: "method", type: "string", description: "HTTP method", required: false, enum: ["GET", "POST", "PUT", "DELETE"] },
    { name: "headers", type: "object", description: "Request headers", required: false },
    { name: "body", type: "object", description: "Request body", required: false },
  ],
}, async (params) => {
  try {
    const res = await fetch(params.url as string, {
      method: (params.method as string) ?? "GET",
      headers: (params.headers as Record<string, string>) ?? {},
      body: params.body ? JSON.stringify(params.body) : undefined,
    });
    const data = await res.text();
    return { success: true, output: { status: res.status, body: data.slice(0, 5000) } };
  } catch (error) {
    return { success: false, output: null, error: error instanceof Error ? error.message : String(error) };
  }
});
