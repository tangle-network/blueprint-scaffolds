import { EvaluationResult, Run } from "@/lib/types";
import { v4 as uuid } from "uuid";

type EvaluationFn = (run: Run) => Promise<Omit<EvaluationResult, "timestamp">>;

class EvaluationEngine {
  private evaluators: Map<string, EvaluationFn> = new Map();

  register(name: string, fn: EvaluationFn) {
    this.evaluators.set(name, fn);
  }

  async evaluate(name: string, run: Run): Promise<EvaluationResult | null> {
    const fn = this.evaluators.get(name);
    if (!fn) return null;

    const result = await fn(run);
    return { ...result, runId: run.id, timestamp: new Date().toISOString() };
  }

  listEvaluators(): string[] {
    return Array.from(this.evaluators.keys());
  }
}

export const evaluationEngine = new EvaluationEngine();

evaluationEngine.register("output_length", async (run) => {
  const output = run.output ?? "";
  const score = Math.min(output.length / 500, 1);
  return {
    runId: run.id,
    score,
    passed: score > 0.2,
    criteria: "Output length should be at least 100 characters",
    feedback: output.length < 100 ? "Output is too short" : "Output length is adequate",
  };
});

evaluationEngine.register("has_trace", async (run) => {
  const hasSteps = run.trace.length > 0;
  return {
    runId: run.id,
    score: hasSteps ? 1 : 0,
    passed: hasSteps,
    criteria: "Run should have at least one trace step",
    feedback: hasSteps ? "Trace present" : "No trace steps recorded",
  };
});

evaluationEngine.register("no_errors", async (run) => {
  const hasError = !!run.error;
  return {
    runId: run.id,
    score: hasError ? 0 : 1,
    passed: !hasError,
    criteria: "Run should complete without errors",
    feedback: hasError ? `Error: ${run.error}` : "No errors detected",
  };
});
