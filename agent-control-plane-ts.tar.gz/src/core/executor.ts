import type { AgentConfig, MemoryEntry, ProviderMessage, RunTrace, TokenUsage, ToolCallRecord } from "../types/index.js";
import { generateToolCallId } from "./tool-registry.js";
import type { LLMProvider, ProviderOptions } from "./providers.js";
import type { MemoryStore } from "./memory.js";
import type { ToolRegistry } from "./tool-registry.js";
import type { TraceStore } from "./trace-store.js";
import type { WebhookManager } from "./webhooks.js";
import type { EvalRunner } from "./eval.js";

export interface AgentRunOptions {
  sessionId: string;
  input: string;
  maxIterations?: number;
  parentRunId?: string;
}

export interface AgentRunResult {
  trace: RunTrace;
  output: string;
  evalResults?: Array<{ hookName: string; score: number; passed: boolean; reasoning: string }>;
}

export class AgentExecutor {
  constructor(
    private config: AgentConfig,
    private provider: LLMProvider,
    private memory: MemoryStore,
    private tools: ToolRegistry,
    private traces: TraceStore,
    private webhooks?: WebhookManager,
    private evalRunner?: EvalRunner,
  ) {}

  async run(options: AgentRunOptions): Promise<AgentRunResult> {
    const { sessionId, input, maxIterations = 10, parentRunId } = options;

    const trace = this.traces.create({
      sessionId,
      agentId: this.config.id,
      input,
      parentRunId,
    });

    await this.webhooks?.fire("run.started", { traceId: trace.id, sessionId, agentId: this.config.id });

    this.traces.start(trace.id);
    this.memory.addMemory(sessionId, "user", input);

    let output = "";
    let retryCount = 0;

    for (let iteration = 0; iteration < maxIterations; iteration++) {
      try {
        output = await this.runIteration(sessionId, trace.id);
        retryCount = 0;
        break;
      } catch (err) {
        retryCount++;
        const errorMsg = err instanceof Error ? err.message : String(err);

        if (retryCount >= this.config.maxRetries) {
          this.traces.fail(trace.id, errorMsg);
          this.memory.addMemory(sessionId, "system", `Error after ${retryCount} retries: ${errorMsg}`);
          await this.webhooks?.fire("run.failed", { traceId: trace.id, error: errorMsg });
          return { trace: this.traces.get(trace.id)!, output: errorMsg };
        }

        this.traces.setRetrying(trace.id);
        await this.delay(this.config.retryDelayMs * retryCount);
      }
    }

    this.traces.complete(trace.id, output);
    this.memory.addMemory(sessionId, "assistant", output);

    let evalResults: AgentRunResult["evalResults"];
    if (this.evalRunner) {
      const completedTrace = this.traces.get(trace.id)!;
      const evals = this.evalRunner.evaluate(input, output, completedTrace);
      evalResults = evals.map((e) => ({
        hookName: e.hook.name,
        score: e.result.score,
        passed: e.result.passed,
        reasoning: e.result.reasoning,
      }));
    }

    await this.webhooks?.fire("run.completed", { traceId: trace.id, output });

    return { trace: this.traces.get(trace.id)!, output, evalResults };
  }

  private async runIteration(sessionId: string, traceId: string): Promise<string> {
    const history = this.memory.getMemory(sessionId);
    const messages: ProviderMessage[] = [
      { role: "system", content: this.config.systemPrompt },
      ...history.map((m: MemoryEntry) => ({ role: m.role as ProviderMessage["role"], content: m.content })),
    ];

    const providerOptions: ProviderOptions = {
      maxTokens: this.config.maxTokens,
      temperature: this.config.temperature,
      tools: this.config.tools
        .filter((t) => this.tools.has(t))
        .map((t) => {
          const def = this.tools.get(t)!;
          return { name: def.name, description: def.description, parameters: def.parameters };
        }),
    };

    const response = await this.provider.complete(messages, providerOptions);
    this.traces.addTokenUsage(traceId, response.tokenUsage);

    if (response.toolCalls && response.toolCalls.length > 0) {
      let toolOutput = "";
      for (const tc of response.toolCalls) {
        const toolRecord: ToolCallRecord = {
          id: generateToolCallId(),
          toolName: tc.name,
          args: tc.args,
          status: "pending",
          startedAt: Date.now(),
        };
        this.traces.addToolCall(traceId, toolRecord);
        await this.webhooks?.fire("tool.called", { traceId, toolCallId: toolRecord.id, toolName: tc.name });

        try {
          const result = await this.tools.execute(tc.name, tc.args);
          this.traces.updateToolCall(traceId, toolRecord.id, {
            status: "completed",
            result,
            finishedAt: Date.now(),
          });
          await this.webhooks?.fire("tool.completed", {
            traceId,
            toolCallId: toolRecord.id,
            toolName: tc.name,
            result,
          });
          toolOutput += typeof result === "string" ? result : JSON.stringify(result);
        } catch (err) {
          const errorMsg = err instanceof Error ? err.message : String(err);
          this.traces.updateToolCall(traceId, toolRecord.id, {
            status: "failed",
            error: errorMsg,
            finishedAt: Date.now(),
          });
          await this.webhooks?.fire("tool.failed", {
            traceId,
            toolCallId: toolRecord.id,
            toolName: tc.name,
            error: errorMsg,
          });
          toolOutput += `Tool error (${tc.name}): ${errorMsg}`;
        }
      }

      this.memory.addMemory(sessionId, "assistant", `Used tools: ${response.toolCalls.map((t) => t.name).join(", ")}`);
      this.memory.addMemory(sessionId, "tool", toolOutput);

      const followUp = await this.provider.complete(
        [
          { role: "system", content: this.config.systemPrompt },
          ...this.memory.getMemory(sessionId).map((m: MemoryEntry) => ({
            role: m.role as ProviderMessage["role"],
            content: m.content,
          })),
        ],
        { maxTokens: this.config.maxTokens, temperature: this.config.temperature },
      );
      this.traces.addTokenUsage(traceId, followUp.tokenUsage);
      return followUp.content;
    }

    return response.content;
  }

  private delay(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}
