import type { WebhookConfig, WebhookEvent, WebhookPayload } from "../types/index.js";
import { v4 as uuid } from "uuid";

export class WebhookManager {
  private webhooks = new Map<string, WebhookConfig>();

  register(config: Omit<WebhookConfig, "id">): WebhookConfig {
    const webhook: WebhookConfig = { id: uuid(), ...config };
    this.webhooks.set(webhook.id, webhook);
    return webhook;
  }

  unregister(id: string): boolean {
    return this.webhooks.delete(id);
  }

  list(): WebhookConfig[] {
    return Array.from(this.webhooks.values());
  }

  async fire(event: WebhookEvent, data: Record<string, unknown>): Promise<void> {
    const payload: WebhookPayload = {
      event,
      timestamp: Date.now(),
      data,
    };

    const matching = Array.from(this.webhooks.values()).filter(
      (w) => w.active && w.events.includes(event),
    );

    await Promise.allSettled(
      matching.map(async (w) => {
        try {
          const headers: Record<string, string> = {
            "Content-Type": "application/json",
            ...w.headers,
          };
          const controller = new AbortController();
          const timeout = setTimeout(() => controller.abort(), 5000);
          await fetch(w.url, {
            method: "POST",
            headers,
            body: JSON.stringify(payload),
            signal: controller.signal,
          });
          clearTimeout(timeout);
        } catch {
          // Webhook delivery failed silently
        }
      }),
    );
  }
}
