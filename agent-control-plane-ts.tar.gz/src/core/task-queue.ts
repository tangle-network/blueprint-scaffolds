import type { TaskQueueItem } from "../types/index.js";
import { v4 as uuid } from "uuid";

export class TaskQueue {
  private queue: TaskQueueItem[] = [];
  private processing = false;
  private handler?: (item: TaskQueueItem) => Promise<void>;

  setHandler(handler: (item: TaskQueueItem) => Promise<void>): void {
    this.handler = handler;
  }

  enqueue(params: {
    sessionId: string;
    agentId: string;
    input: string;
    priority?: number;
    maxRetries?: number;
  }): TaskQueueItem {
    const item: TaskQueueItem = {
      id: uuid(),
      sessionId: params.sessionId,
      agentId: params.agentId,
      input: params.input,
      status: "queued",
      priority: params.priority ?? 0,
      createdAt: Date.now(),
      maxRetries: params.maxRetries ?? 3,
      retryCount: 0,
    };
    this.queue.push(item);
    this.queue.sort((a, b) => b.priority - a.priority);
    this.processNext();
    return item;
  }

  get(itemId: string): TaskQueueItem | undefined {
    return this.queue.find((i) => i.id === itemId);
  }

  list(status?: TaskQueueItem["status"]): TaskQueueItem[] {
    if (status) return this.queue.filter((i) => i.status === status);
    return [...this.queue];
  }

  private async processNext(): Promise<void> {
    if (this.processing || !this.handler) return;
    const next = this.queue.find((i) => i.status === "queued");
    if (!next) return;

    this.processing = true;
    next.status = "processing";
    next.startedAt = Date.now();

    try {
      await this.handler(next);
      next.status = "completed";
      next.completedAt = Date.now();
    } catch (err) {
      next.error = err instanceof Error ? err.message : String(err);
      if (next.retryCount < next.maxRetries) {
        next.retryCount++;
        next.status = "queued";
      } else {
        next.status = "failed";
        next.completedAt = Date.now();
      }
    } finally {
      this.processing = false;
    }

    this.processNext();
  }

  clear(): void {
    this.queue = [];
  }

  get size(): number {
    return this.queue.filter((i) => i.status === "queued").length;
  }
}
