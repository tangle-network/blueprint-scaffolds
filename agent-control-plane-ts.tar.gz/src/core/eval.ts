import type { EvalHook, EvalResult, RunTrace } from "../types/index.js";
import { v4 as uuid } from "uuid";

export class EvalRunner {
  private hooks = new Map<string, EvalHook>();

  register(hook: Omit<EvalHook, "id">): EvalHook {
    const evalHook: EvalHook = { id: uuid(), ...hook };
    this.hooks.set(evalHook.id, evalHook);
    return evalHook;
  }

  unregister(id: string): boolean {
    return this.hooks.delete(id);
  }

  list(): EvalHook[] {
    return Array.from(this.hooks.values());
  }

  evaluate(input: string, output: string, trace: RunTrace): Array<{ hook: EvalHook; result: EvalResult }> {
    const results: Array<{ hook: EvalHook; result: EvalResult }> = [];
    for (const hook of this.hooks.values()) {
      try {
        const result = hook.evaluate(input, output, trace);
        results.push({ hook, result });
      } catch {
        results.push({
          hook,
          result: { score: 0, passed: false, reasoning: "Evaluation threw an error" },
        });
      }
    }
    return results;
  }
}
