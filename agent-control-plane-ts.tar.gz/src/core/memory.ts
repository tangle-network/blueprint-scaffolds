import { v4 as uuid } from "uuid";
import type { MemoryEntry, Session } from "../types/index.js";

export class MemoryStore {
  private sessions = new Map<string, Session>();

  createSession(agentId: string, metadata?: Record<string, unknown>): Session {
    const session: Session = {
      id: uuid(),
      agentId,
      status: "active",
      memory: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
      metadata: metadata ?? {},
    };
    this.sessions.set(session.id, session);
    return session;
  }

  getSession(sessionId: string): Session | undefined {
    return this.sessions.get(sessionId);
  }

  listSessions(agentId?: string): Session[] {
    const all = Array.from(this.sessions.values());
    if (agentId) return all.filter((s) => s.agentId === agentId);
    return all;
  }

  addMemory(sessionId: string, role: MemoryEntry["role"], content: string, metadata?: Record<string, unknown>): MemoryEntry {
    const session = this.sessions.get(sessionId);
    if (!session) throw new Error(`Session ${sessionId} not found`);
    const entry: MemoryEntry = {
      id: uuid(),
      role,
      content,
      timestamp: Date.now(),
      metadata,
    };
    session.memory.push(entry);
    session.updatedAt = Date.now();
    return entry;
  }

  getMemory(sessionId: string, limit?: number): MemoryEntry[] {
    const session = this.sessions.get(sessionId);
    if (!session) throw new Error(`Session ${sessionId} not found`);
    if (limit) return session.memory.slice(-limit);
    return [...session.memory];
  }

  closeSession(sessionId: string): void {
    const session = this.sessions.get(sessionId);
    if (!session) throw new Error(`Session ${sessionId} not found`);
    session.status = "closed";
    session.updatedAt = Date.now();
  }

  clearSession(sessionId: string): void {
    const session = this.sessions.get(sessionId);
    if (!session) throw new Error(`Session ${sessionId} not found`);
    session.memory = [];
    session.updatedAt = Date.now();
  }
}
