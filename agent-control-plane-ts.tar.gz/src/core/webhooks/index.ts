import { WebhookConfig } from "@/lib/types";
import { v4 as uuid } from "uuid";

class WebhookManager {
  private webhooks: Map<string, WebhookConfig> = new Map();

  register(config: Omit<WebhookConfig, "id" | "createdAt">): WebhookConfig {
    const webhook: WebhookConfig = {
      id: uuid(),
      ...config,
      createdAt: new Date().toISOString(),
    };
    this.webhooks.set(webhook.id, webhook);
    return webhook;
  }

  get(id: string): WebhookConfig | undefined {
    return this.webhooks.get(id);
  }

  list(): WebhookConfig[] {
    return Array.from(this.webhooks.values());
  }

  update(id: string, updates: Partial<WebhookConfig>): WebhookConfig | undefined {
    const webhook = this.webhooks.get(id);
    if (!webhook) return undefined;
    Object.assign(webhook, updates);
    return webhook;
  }

  delete(id: string): boolean {
    return this.webhooks.delete(id);
  }

  async fire(event: string, payload: unknown): Promise<{ sent: number; errors: string[] }> {
    const matching = Array.from(this.webhooks.values()).filter(
      (w) => w.active && w.events.includes(event)
    );

    let sent = 0;
    const errors: string[] = [];

    for (const webhook of matching) {
      try {
        const res = await fetch(webhook.url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-Webhook-Secret": webhook.secret,
            "X-Webhook-Event": event,
          },
          body: JSON.stringify({ event, timestamp: new Date().toISOString(), data: payload }),
        });
        if (res.ok) sent++;
        else errors.push(`Webhook ${webhook.id}: HTTP ${res.status}`);
      } catch (error) {
        errors.push(`Webhook ${webhook.id}: ${error instanceof Error ? error.message : String(error)}`);
      }
    }

    return { sent, errors };
  }
}

export const webhookManager = new WebhookManager();
