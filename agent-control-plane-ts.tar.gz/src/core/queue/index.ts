import { TaskQueueItem } from "@/lib/types";
import { v4 as uuid } from "uuid";

type TaskHandler = (payload: unknown) => Promise<unknown>;

class TaskQueue {
  private queue: TaskQueueItem[] = [];
  private handlers: Map<string, TaskHandler> = new Map();
  private processing = false;

  registerHandler(type: string, handler: TaskHandler) {
    this.handlers.set(type, handler);
  }

  enqueue(type: TaskQueueItem["type"], payload: unknown, priority = 0): TaskQueueItem {
    const item: TaskQueueItem = {
      id: uuid(),
      type,
      payload,
      status: "queued",
      priority,
      createdAt: new Date().toISOString(),
    };
    this.queue.push(item);
    this.queue.sort((a, b) => b.priority - a.priority);
    this.process();
    return item;
  }

  get(id: string): TaskQueueItem | undefined {
    return this.queue.find((item) => item.id === id);
  }

  list(): TaskQueueItem[] {
    return [...this.queue].sort((a, b) => b.priority - a.priority);
  }

  private async process() {
    if (this.processing) return;
    this.processing = true;

    while (true) {
      const item = this.queue.find((i) => i.status === "queued");
      if (!item) break;

      item.status = "processing";
      const handler = this.handlers.get(item.type);

      if (handler) {
        try {
          await handler(item.payload);
          item.status = "completed";
        } catch (error) {
          item.status = "failed";
          item.error = error instanceof Error ? error.message : String(error);
        }
      } else {
        item.status = "completed";
      }
      item.processedAt = new Date().toISOString();
    }

    this.processing = false;
  }
}

export const taskQueue = new TaskQueue();
