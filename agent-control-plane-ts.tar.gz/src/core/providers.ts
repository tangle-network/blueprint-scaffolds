import type { ProviderMessage, ProviderResponse, TokenUsage } from "../types/index.js";

export interface LLMProvider {
  readonly name: string;
  complete(messages: ProviderMessage[], options: ProviderOptions): Promise<ProviderResponse>;
}

export interface ProviderOptions {
  maxTokens?: number;
  temperature?: number;
  tools?: Array<{
    name: string;
    description: string;
    parameters: Record<string, unknown>;
  }>;
}

export class MockProvider implements LLMProvider {
  readonly name = "mock";
  private callCount = 0;

  async complete(messages: ProviderMessage[], options: ProviderOptions): Promise<ProviderResponse> {
    this.callCount++;
    const lastMsg = messages[messages.length - 1];
    const input = lastMsg?.content ?? "";

    let content = `Mock response for: "${input.slice(0, 80)}..."`;
    let toolCalls: ProviderResponse["toolCalls"];

    if (input.toLowerCase().includes("browse") || input.toLowerCase().includes("visit")) {
      toolCalls = [
        {
          id: `call_${this.callCount}`,
          name: "browse",
          args: { url: "https://example.com" },
        },
      ];
      content = "";
    } else if (input.toLowerCase().includes("summarize") || input.toLowerCase().includes("summary")) {
      toolCalls = [
        {
          id: `call_${this.callCount}`,
          name: "summarize",
          args: { text: input },
        },
      ];
      content = "";
    } else if (input.toLowerCase().includes("calculate") || input.toLowerCase().includes("math")) {
      toolCalls = [
        {
          id: `call_${this.callCount}`,
          name: "calculator",
          args: { expression: "2 + 2" },
        },
      ];
      content = "";
    }

    const usage: TokenUsage = {
      prompt: messages.reduce((acc, m) => acc + Math.ceil(m.content.length / 4), 0),
      completion: Math.ceil((content?.length ?? 50) / 4),
      total: 0,
    };
    usage.total = usage.prompt + usage.completion;

    return { content, toolCalls, tokenUsage: usage };
  }
}

export class ProviderFactory {
  private providers = new Map<string, LLMProvider>();

  register(provider: LLMProvider): void {
    this.providers.set(provider.name, provider);
  }

  get(name: string): LLMProvider {
    const provider = this.providers.get(name);
    if (!provider) throw new Error(`Provider not found: ${name}`);
    return provider;
  }

  list(): string[] {
    return Array.from(this.providers.keys());
  }
}
