import { MemoryEntry } from "@/lib/types";
import { v4 as uuid } from "uuid";

class MemoryStore {
  private entries: Map<string, MemoryEntry> = new Map();
  private sessionIndex: Map<string, Set<string>> = new Map();

  store(sessionId: string, key: string, value: unknown): MemoryEntry {
    const existing = this.findByKey(sessionId, key);
    if (existing) {
      existing.value = value;
      existing.timestamp = new Date().toISOString();
      return existing;
    }

    const entry: MemoryEntry = {
      id: uuid(),
      sessionId,
      key,
      value,
      timestamp: new Date().toISOString(),
    };
    this.entries.set(entry.id, entry);
    if (!this.sessionIndex.has(sessionId)) this.sessionIndex.set(sessionId, new Set());
    this.sessionIndex.get(sessionId)!.add(entry.id);
    return entry;
  }

  retrieve(sessionId: string, key: string): MemoryEntry | undefined {
    return this.findByKey(sessionId, key);
  }

  listSession(sessionId: string): MemoryEntry[] {
    const ids = this.sessionIndex.get(sessionId);
    if (!ids) return [];
    return Array.from(ids)
      .map((id) => this.entries.get(id))
      .filter((e): e is MemoryEntry => !!e);
  }

  delete(id: string): boolean {
    const entry = this.entries.get(id);
    if (!entry) return false;
    this.entries.delete(id);
    this.sessionIndex.get(entry.sessionId)?.delete(id);
    return true;
  }

  private findByKey(sessionId: string, key: string): MemoryEntry | undefined {
    const ids = this.sessionIndex.get(sessionId);
    if (!ids) return undefined;
    for (const id of ids) {
      const entry = this.entries.get(id);
      if (entry && entry.key === key) return entry;
    }
    return undefined;
  }
}

export const memoryStore = new MemoryStore();
