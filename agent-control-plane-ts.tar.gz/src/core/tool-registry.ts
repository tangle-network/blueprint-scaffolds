import { v4 as uuid } from "uuid";
import type { ToolDefinition, ToolParameter } from "../types/index.js";

export class ToolRegistry {
  private tools = new Map<string, ToolDefinition>();

  register(definition: ToolDefinition): void {
    this.tools.set(definition.name, definition);
  }

  get(name: string): ToolDefinition | undefined {
    return this.tools.get(name);
  }

  list(): ToolDefinition[] {
    return Array.from(this.tools.values());
  }

  listSchemas(): Array<{ name: string; description: string; parameters: Record<string, ToolParameter> }> {
    return this.list().map((t) => ({
      name: t.name,
      description: t.description,
      parameters: t.parameters,
    }));
  }

  async execute(name: string, args: Record<string, unknown>): Promise<unknown> {
    const tool = this.tools.get(name);
    if (!tool) throw new Error(`Tool not found: ${name}`);
    return tool.handler(args);
  }

  has(name: string): boolean {
    return this.tools.has(name);
  }

  unregister(name: string): boolean {
    return this.tools.delete(name);
  }
}

export function createTool(
  name: string,
  description: string,
  parameters: Record<string, ToolParameter>,
  handler: ToolDefinition["handler"],
): ToolDefinition {
  return { name, description, parameters, handler };
}

export function stringParam(description?: string, required = true): ToolParameter {
  return { type: "string", description, required };
}

export function numberParam(description?: string, required = true): ToolParameter {
  return { type: "number", description, required };
}

export function booleanParam(description?: string, required = true): ToolParameter {
  return { type: "boolean", description, required };
}

export function generateToolCallId(): string {
  return `tc_${uuid().replace(/-/g, "").slice(0, 12)}`;
}
