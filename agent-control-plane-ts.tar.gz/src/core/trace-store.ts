import { v4 as uuid } from "uuid";
import type { RunTrace, ToolCallRecord, TokenUsage } from "../types/index.js";

export class TraceStore {
  private traces = new Map<string, RunTrace>();

  create(params: {
    sessionId: string;
    agentId: string;
    input: string;
    parentRunId?: string;
    metadata?: Record<string, unknown>;
  }): RunTrace {
    const trace: RunTrace = {
      id: uuid(),
      sessionId: params.sessionId,
      agentId: params.agentId,
      parentRunId: params.parentRunId,
      status: "pending",
      input: params.input,
      toolCalls: [],
      tokenUsage: { prompt: 0, completion: 0, total: 0 },
      startedAt: Date.now(),
      retryCount: 0,
      metadata: params.metadata ?? {},
    };
    this.traces.set(trace.id, trace);
    return trace;
  }

  get(traceId: string): RunTrace | undefined {
    return this.traces.get(traceId);
  }

  list(sessionId?: string, agentId?: string): RunTrace[] {
    let results = Array.from(this.traces.values());
    if (sessionId) results = results.filter((t) => t.sessionId === sessionId);
    if (agentId) results = results.filter((t) => t.agentId === agentId);
    return results.sort((a, b) => b.startedAt - a.startedAt);
  }

  start(traceId: string): void {
    const trace = this.traces.get(traceId);
    if (!trace) throw new Error(`Trace ${traceId} not found`);
    trace.status = "running";
  }

  complete(traceId: string, output: string): void {
    const trace = this.traces.get(traceId);
    if (!trace) throw new Error(`Trace ${traceId} not found`);
    trace.status = "completed";
    trace.output = output;
    trace.finishedAt = Date.now();
  }

  fail(traceId: string, error: string): void {
    const trace = this.traces.get(traceId);
    if (!trace) throw new Error(`Trace ${traceId} not found`);
    trace.status = "failed";
    trace.error = error;
    trace.finishedAt = Date.now();
  }

  setRetrying(traceId: string): void {
    const trace = this.traces.get(traceId);
    if (!trace) throw new Error(`Trace ${traceId} not found`);
    trace.status = "retrying";
    trace.retryCount++;
  }

  addToolCall(traceId: string, record: ToolCallRecord): void {
    const trace = this.traces.get(traceId);
    if (!trace) throw new Error(`Trace ${traceId} not found`);
    trace.toolCalls.push(record);
  }

  updateToolCall(traceId: string, toolCallId: string, update: Partial<ToolCallRecord>): void {
    const trace = this.traces.get(traceId);
    if (!trace) throw new Error(`Trace ${traceId} not found`);
    const tc = trace.toolCalls.find((t) => t.id === toolCallId);
    if (tc) Object.assign(tc, update);
  }

  addTokenUsage(traceId: string, usage: TokenUsage): void {
    const trace = this.traces.get(traceId);
    if (!trace) throw new Error(`Trace ${traceId} not found`);
    trace.tokenUsage.prompt += usage.prompt;
    trace.tokenUsage.completion += usage.completion;
    trace.tokenUsage.total += usage.total;
  }

  getStats(): { total: number; completed: number; failed: number; avgDurationMs: number } {
    const all = Array.from(this.traces.values());
    const completed = all.filter((t) => t.status === "completed" && t.finishedAt);
    const failed = all.filter((t) => t.status === "failed");
    const durations = completed.map((t) => (t.finishedAt! - t.startedAt));
    const avgDurationMs = durations.length > 0 ? durations.reduce((a, b) => a + b, 0) / durations.length : 0;
    return { total: all.length, completed: completed.length, failed: failed.length, avgDurationMs };
  }
}
