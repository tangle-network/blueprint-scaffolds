# AGENTS.md

Build a TypeScript agent control plane with tool execution, memory, retries, webhooks, and traceable runs.

## What's here

This project was scaffolded by starter-foundry. The user's prompt drove the choices below — read their prompt first, it takes priority over everything in this file.

- **Family:** `agent-service-ts`
- **Layers:** `framework:agent-service-ts`, `capability:agent-ai-sdk`, `database:sqlite`, `sdk:none`, `auth:none`, `payments:none`, `queue:none`

### Architecture notes
- Agent control loop: plan → act → reflect
- Tool registration
- Memory/state management
- HTTP health endpoint
- Use streamText() for streaming responses in API routes.
- Define tools with zod schemas for type-safe function calling.
- Multi-provider: swap providers without changing application code.
- Use useChat() hook on the client for streaming UI integration.

## Getting started

```bash
node agent.mjs
```

Key files: `agent.mjs`, `agent.config.json`

## Suggested build plan

These are starting points — adapt them to the user's actual needs.

- **API routes:** /api/chat
- **Components:** ChatStream, ToolCallRenderer
- **Data models:** Message, ToolDefinition, StreamChunk
- **Integrations:** Vercel AI SDK, Anthropic provider, OpenAI provider

## How to use this scaffold

This is a starting point, not a contract. You own every file.

- **Customize freely.** Replace components, change the layout, swap the color scheme — whatever fits the user's product.
- **The scaffold saves you setup time** — Tailwind, shadcn/ui, path aliases, and framework config are ready. Don't redo them.
- **Check `.starter-foundry/compose-report.json`** if you want to see which layer wrote which file.
- **Update this file** as the project evolves. Delete sections that no longer apply.
