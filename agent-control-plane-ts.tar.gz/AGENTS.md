# AGENTS.md

## Goal

Build a TypeScript agent control plane with tool execution, memory, retries, webhooks, and traceable runs.

## Stack

- Family: `agent-service-ts`
- Layers: `capability:agent-ai-sdk`, `database:sqlite`, `sdk:none`, `auth:none`, `payments:none`, `queue:none`

## Architecture

- Agent control loop: plan → act → reflect
- Tool registration
- Memory/state management
- HTTP health endpoint
- Use streamText() for streaming responses in API routes.
- Define tools with zod schemas for type-safe function calling.
- Multi-provider: swap providers without changing application code.
- Use useChat() hook on the client for streaming UI integration.

## Entry Points

- `agent.mjs`
- `agent.config.json`

## Commands

- `node agent.mjs`

## Build Plan

API routes: /api/chat
Components: ChatStream, ToolCallRenderer
Data models: Message, ToolDefinition, StreamChunk
Integrations: Vercel AI SDK, Anthropic provider, OpenAI provider

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
