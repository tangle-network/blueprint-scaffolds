from typing import Any, Callable, Dict, List, Optional
from dataclasses import dataclass, field
import json
import traceback
import subprocess
import sqlite3
import os
import re
import signal


@dataclass
class Tool:
    name: str
    description: str
    parameters: Dict[str, str]
    func: Callable[..., Any]
    dangerous: bool = False


class ToolRegistry:
    def __init__(self):
        self._tools: Dict[str, Tool] = {}

    def register(self, name: str, description: str, parameters: Dict[str, str], dangerous: bool = False):
        def decorator(func: Callable[..., Any]):
            self._tools[name] = Tool(
                name=name,
                description=description,
                parameters=parameters,
                func=func,
                dangerous=dangerous,
            )
            return func
        return decorator

    def get(self, name: str) -> Optional[Tool]:
        return self._tools.get(name)

    def list_tools(self) -> List[Dict[str, Any]]:
        return [
            {
                "name": t.name,
                "description": t.description,
                "parameters": t.parameters,
            }
            for t in self._tools.values()
        ]

    def execute(self, name: str, **kwargs) -> str:
        tool = self.get(name)
        if not tool:
            return f"Error: Unknown tool '{name}'"
        try:
            result = tool.func(**kwargs)
            if isinstance(result, dict) or isinstance(result, list):
                return json.dumps(result, indent=2)
            return str(result)
        except Exception as e:
            return f"Error executing {name}: {e}"


registry = ToolRegistry()
SANDBOX_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "storage")
os.makedirs(SANDBOX_DIR, exist_ok=True)


@registry.register(
    name="web_search",
    description="Search the web for information. Returns search results with titles and snippets.",
    parameters={"query": "Search query string"},
)
def web_search(query: str) -> str:
    mock_results = [
        {"title": f"Result for '{query}'", "snippet": f"Relevant information about {query}. This is a simulated search result demonstrating the agent's web search capability.", "url": f"https://example.com/search?q={query}"},
        {"title": f"More about {query}", "snippet": f"Additional context and details regarding {query}. In production, this would return real search results.", "url": f"https://example.com/info/{query}"},
        {"title": f"Expert analysis: {query}", "snippet": f"Expert perspective on {query} with supporting evidence and references.", "url": f"https://example.com/analysis/{query}"},
    ]
    output = []
    for r in mock_results:
        output.append(f"- {r['title']}\n  {r['snippet']}\n  {r['url']}")
    return "\n\n".join(output)


@registry.register(
    name="code_execute",
    description="Execute Python code in a sandboxed environment. Returns stdout and stderr.",
    parameters={"code": "Python code to execute"},
    dangerous=True,
)
def code_execute(code: str) -> str:
    tmpfile = os.path.join(SANDBOX_DIR, "_sandbox_exec.py")
    with open(tmpfile, "w") as f:
        f.write(code)
    try:
        proc = subprocess.run(
            ["/nix/store/cq6pj1rzqvbnhvnd5lnyh261g69rwd1s-python3-3.12.8-env/bin/python3", tmpfile],
            capture_output=True,
            text=True,
            timeout=10,
            cwd=SANDBOX_DIR,
        )
        output = ""
        if proc.stdout:
            output += proc.stdout
        if proc.stderr:
            output += f"\nSTDERR:\n{proc.stderr}"
        if proc.returncode != 0:
            output += f"\nExit code: {proc.returncode}"
        return output.strip() or "(no output)"
    except subprocess.TimeoutExpired:
        return "Error: Code execution timed out (10s limit)"
    except Exception as e:
        return f"Error: {e}"
    finally:
        try:
            os.remove(tmpfile)
        except OSError:
            pass


@registry.register(
    name="database_query",
    description="Query the local SQLite database. Supports SELECT, INSERT, UPDATE, DELETE operations.",
    parameters={
        "sql": "SQL query to execute",
        "params": "Optional JSON string of query parameters",
    },
)
def database_query(sql: str, params: str = "[]") -> str:
    db_path = os.path.join(SANDBOX_DIR, "agent.db")
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        cursor = conn.cursor()
        parsed_params = json.loads(params) if isinstance(params, str) else params
        cursor.execute(sql, parsed_params)

        if sql.strip().upper().startswith("SELECT"):
            rows = cursor.fetchall()
            if not rows:
                return "No results found."
            columns = [desc[0] for desc in cursor.description]
            result = [dict(zip(columns, row)) for row in rows]
            return json.dumps(result, indent=2, default=str)
        else:
            conn.commit()
            return f"Query executed successfully. Rows affected: {cursor.rowcount}"
    except Exception as e:
        return f"Database error: {e}"
    finally:
        conn.close()


@registry.register(
    name="api_call",
    description="Make an HTTP API call. Supports GET, POST, PUT, DELETE methods.",
    parameters={
        "url": "The URL to call",
        "method": "HTTP method (GET, POST, PUT, DELETE)",
        "body": "Optional JSON body for POST/PUT requests",
        "headers": "Optional JSON string of headers",
    },
)
def api_call(url: str, method: str = "GET", body: str = "", headers: str = "{}") -> str:
    try:
        import urllib.request
        import urllib.error

        parsed_headers = json.loads(headers) if isinstance(headers, str) else headers
        data = body.encode("utf-8") if body else None

        req = urllib.request.Request(url, data=data, method=method.upper())
        for k, v in parsed_headers.items():
            req.add_header(k, v)
        if data and "content-type" not in {k.lower() for k in parsed_headers}:
            req.add_header("Content-Type", "application/json")

        with urllib.request.urlopen(req, timeout=10) as resp:
            result = resp.read().decode("utf-8")
            return result[:5000]

    except urllib.error.HTTPError as e:
        return f"HTTP Error {e.code}: {e.reason}"
    except urllib.error.URLError as e:
        return f"URL Error: {e.reason}"
    except Exception as e:
        return f"API call error: {e}"


@registry.register(
    name="calculator",
    description="Evaluate a mathematical expression safely.",
    parameters={"expression": "Mathematical expression to evaluate"},
)
def calculator(expression: str) -> str:
    allowed = set("0123456789+-*/.()^% ")
    if not all(c in allowed for c in expression):
        return "Error: Expression contains disallowed characters"
    try:
        expr = expression.replace("^", "**")
        result = eval(expr, {"__builtins__": {}}, {})
        return str(result)
    except Exception as e:
        return f"Calculation error: {e}"


def _init_db():
    db_path = os.path.join(SANDBOX_DIR, "agent.db")
    conn = sqlite3.connect(db_path)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            category TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS conversation_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    count = conn.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
    if count == 0:
        sample_docs = [
            ("Getting Started with DSPy", "DSPy is a framework for algorithmically optimizing language model prompts and weights.", "tutorial"),
            ("ReAct Pattern Guide", "The ReAct pattern combines reasoning and acting in an interleaved manner for improved task performance.", "guide"),
            ("Tool-Use Best Practices", "When building AI agents with tool access, always validate inputs, handle errors gracefully, and set appropriate timeouts.", "best-practices"),
            ("Context Window Management", "Effective context management involves summarizing history, prioritizing recent information, and trimming low-relevance content.", "guide"),
            ("Multi-Step Planning", "Complex tasks benefit from decomposition into sub-tasks with clear dependencies and verification at each step.", "tutorial"),
        ]
        conn.executemany("INSERT INTO documents (title, content, category) VALUES (?, ?, ?)", sample_docs)
    conn.commit()
    conn.close()


_init_db()
