import time
import json
import traceback
import uuid
import subprocess
import tempfile
import os
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ToolResult:
    success: bool
    output: str
    error: str | None = None
    duration_ms: int = 0
    metadata: dict = field(default_factory=dict)


class BaseTool(ABC):
    name: str = ""
    description: str = ""
    category: str = "general"

    @abstractmethod
    def execute(self, **kwargs) -> ToolResult:
        ...

    @abstractmethod
    def get_schema(self) -> dict:
        ...


class WebSearchTool(BaseTool):
    name = "web_search"
    description = "Search the web for information on any topic"
    category = "search"

    def execute(self, query: str = "", **kwargs) -> ToolResult:
        start = time.time()
        try:
            results = [
                {
                    "title": f"Search result for '{query}' - Source {i+1}",
                    "url": f"https://example.com/result/{i+1}",
                    "snippet": f"This is a simulated search result for the query '{query}'. "
                    f"In production, this would connect to a real search API like Google, Bing, or Tavily. "
                    f"Result {i+1} contains relevant information about {query}.",
                }
                for i in range(3)
            ]
            output = json.dumps(results, indent=2)
            return ToolResult(
                success=True,
                output=output,
                duration_ms=int((time.time() - start) * 1000),
                metadata={"result_count": len(results)},
            )
        except Exception as e:
            return ToolResult(
                success=False,
                output="",
                error=str(e),
                duration_ms=int((time.time() - start) * 1000),
            )

    def get_schema(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "The search query string",
                    }
                },
                "required": ["query"],
            },
        }


class CodeExecuteTool(BaseTool):
    name = "code_execute"
    description = "Execute Python code in a sandboxed environment and return the output"
    category = "code"

    def execute(self, code: str = "", language: str = "python", **kwargs) -> ToolResult:
        start = time.time()
        if language != "python":
            return ToolResult(
                success=False,
                output="",
                error=f"Unsupported language: {language}. Only python is supported.",
                duration_ms=int((time.time() - start) * 1000),
            )

        try:
            with tempfile.NamedTemporaryFile(
                mode="w", suffix=".py", delete=False
            ) as f:
                safe_code = (
                    "import sys\nimport json\nimport math\nimport os\n"
                    "import datetime\nimport collections\nimport itertools\n"
                    "import functools\nimport re\nimport statistics\n\n"
                    + code
                )
                f.write(safe_code)
                tmp_path = f.name

            try:
                result = subprocess.run(
                    ["python3", tmp_path],
                    capture_output=True,
                    text=True,
                    timeout=10,
                    env={**os.environ, "PYTHONPATH": ""},
                )
                output = result.stdout
                if result.returncode != 0:
                    return ToolResult(
                        success=False,
                        output=result.stderr,
                        error=f"Exit code {result.returncode}",
                        duration_ms=int((time.time() - start) * 1000),
                    )
                return ToolResult(
                    success=True,
                    output=output[:5000],
                    duration_ms=int((time.time() - start) * 1000),
                )
            finally:
                os.unlink(tmp_path)
        except subprocess.TimeoutExpired:
            return ToolResult(
                success=False,
                output="",
                error="Execution timed out (10s limit)",
                duration_ms=int((time.time() - start) * 1000),
            )
        except Exception as e:
            return ToolResult(
                success=False,
                output="",
                error=str(e),
                duration_ms=int((time.time() - start) * 1000),
            )

    def get_schema(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "parameters": {
                "type": "object",
                "properties": {
                    "code": {
                        "type": "string",
                        "description": "The Python code to execute",
                    },
                    "language": {
                        "type": "string",
                        "description": "Programming language (default: python)",
                        "default": "python",
                    },
                },
                "required": ["code"],
            },
        }


class DatabaseQueryTool(BaseTool):
    name = "db_query"
    description = "Execute SQL-like queries against an in-memory database"
    category = "db"

    def __init__(self):
        self._data = {
            "users": [
                {"id": 1, "name": "Alice", "email": "alice@example.com", "role": "admin"},
                {"id": 2, "name": "Bob", "email": "bob@example.com", "role": "user"},
                {"id": 3, "name": "Carol", "email": "carol@example.com", "role": "user"},
                {"id": 4, "name": "Dave", "email": "dave@example.com", "role": "moderator"},
                {"id": 5, "name": "Eve", "email": "eve@example.com", "role": "user"},
            ],
            "products": [
                {"id": 1, "name": "Widget", "price": 29.99, "stock": 100},
                {"id": 2, "name": "Gadget", "price": 49.99, "stock": 50},
                {"id": 3, "name": "Doohickey", "price": 19.99, "stock": 200},
                {"id": 4, "name": "Thingamajig", "price": 99.99, "stock": 25},
            ],
            "orders": [
                {"id": 1, "user_id": 1, "product_id": 1, "quantity": 2, "total": 59.98},
                {"id": 2, "user_id": 2, "product_id": 2, "quantity": 1, "total": 49.99},
                {"id": 3, "user_id": 3, "product_id": 3, "quantity": 5, "total": 99.95},
                {"id": 4, "user_id": 1, "product_id": 4, "quantity": 1, "total": 99.99},
                {"id": 5, "user_id": 4, "product_id": 1, "quantity": 3, "total": 89.97},
            ],
        }

    def execute(self, query: str = "", table: str = "", **kwargs) -> ToolResult:
        start = time.time()
        try:
            if table and table in self._data:
                rows = self._data[table]
                return ToolResult(
                    success=True,
                    output=json.dumps(rows, indent=2),
                    duration_ms=int((time.time() - start) * 1000),
                    metadata={"table": table, "row_count": len(rows)},
                )

            q_lower = query.lower().strip()

            for table_name, rows in self._data.items():
                if table_name in q_lower:
                    filtered = rows
                    if "where" in q_lower:
                        parts = q_lower.split("where")
                        if len(parts) > 1:
                            condition = parts[1].strip()
                            for row in rows:
                                for key, val in row.items():
                                    if isinstance(val, str) and str(val).lower() in condition:
                                        filtered = [row]
                                        break

                    limit = None
                    if "limit" in q_lower:
                        try:
                            limit = int(q_lower.split("limit")[-1].strip().split()[0])
                        except (ValueError, IndexError):
                            pass

                    if limit:
                        filtered = filtered[:limit]

                    return ToolResult(
                        success=True,
                        output=json.dumps(filtered, indent=2),
                        duration_ms=int((time.time() - start) * 1000),
                        metadata={"table": table_name, "row_count": len(filtered)},
                    )

            all_tables = {k: len(v) for k, v in self._data.items()}
            return ToolResult(
                success=True,
                output=f"Available tables: {json.dumps(all_tables)}\nSpecify a table name or use 'SELECT * FROM <table>' syntax.",
                duration_ms=int((time.time() - start) * 1000),
            )
        except Exception as e:
            return ToolResult(
                success=False,
                output="",
                error=str(e),
                duration_ms=int((time.time() - start) * 1000),
            )

    def get_schema(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "SQL-like query or table name",
                    },
                    "table": {
                        "type": "string",
                        "description": "Direct table name (users, products, orders)",
                    },
                },
                "required": ["query"],
            },
        }


class APICallTool(BaseTool):
    name = "api_call"
    description = "Make HTTP API calls to external services"
    category = "api"

    def execute(
        self,
        url: str = "",
        method: str = "GET",
        headers: dict | None = None,
        body: dict | None = None,
        **kwargs,
    ) -> ToolResult:
        start = time.time()
        try:
            response_data = {
                "status": 200,
                "url": url or "https://api.example.com/placeholder",
                "method": method.upper(),
                "headers": headers or {},
                "body": body or {},
                "simulated_response": {
                    "message": f"Simulated {method.upper()} response for {url}. "
                    "In production, this would make a real HTTP request.",
                    "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                    "request_id": str(uuid.uuid4()),
                },
            }

            return ToolResult(
                success=True,
                output=json.dumps(response_data, indent=2),
                duration_ms=int((time.time() - start) * 1000),
                metadata={"status_code": 200, "method": method.upper()},
            )
        except Exception as e:
            return ToolResult(
                success=False,
                output="",
                error=str(e),
                duration_ms=int((time.time() - start) * 1000),
            )

    def get_schema(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "parameters": {
                "type": "object",
                "properties": {
                    "url": {"type": "string", "description": "The URL to call"},
                    "method": {
                        "type": "string",
                        "description": "HTTP method",
                        "default": "GET",
                        "enum": ["GET", "POST", "PUT", "DELETE", "PATCH"],
                    },
                    "headers": {
                        "type": "object",
                        "description": "Request headers",
                    },
                    "body": {
                        "type": "object",
                        "description": "Request body (for POST/PUT)",
                    },
                },
                "required": ["url"],
            },
        }


class ToolRegistry:
    def __init__(self):
        self._tools: dict[str, BaseTool] = {}
        self.register(WebSearchTool())
        self.register(CodeExecuteTool())
        self.register(DatabaseQueryTool())
        self.register(APICallTool())

    def register(self, tool: BaseTool):
        self._tools[tool.name] = tool

    def get(self, name: str) -> BaseTool | None:
        return self._tools.get(name)

    def list_tools(self) -> list[dict]:
        return [tool.get_schema() for tool in self._tools.values()]

    def execute(self, name: str, **kwargs) -> ToolResult:
        tool = self._tools.get(name)
        if not tool:
            return ToolResult(
                success=False,
                output="",
                error=f"Unknown tool: {name}. Available: {list(self._tools.keys())}",
            )
        return tool.execute(**kwargs)
