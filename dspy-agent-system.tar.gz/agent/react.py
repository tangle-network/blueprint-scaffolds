import re
import time
import json
from typing import Generator
from agent.tools import ToolRegistry


class ContextWindow:
    def __init__(self, max_tokens: int = 8000):
        self.max_tokens = max_tokens
        self.used_tokens = 0
        self._entries: list[str] = []

    def add(self, text: str):
        tokens = self._estimate_tokens(text)
        self._entries.append(text)
        self.used_tokens += tokens
        while self.used_tokens > self.max_tokens and len(self._entries) > 1:
            removed = self._entries.pop(0)
            self.used_tokens -= self._estimate_tokens(removed)

    def _estimate_tokens(self, text: str) -> int:
        return len(text) // 4

    def get_context(self) -> str:
        return "\n".join(self._entries)

    def clear(self):
        self._entries.clear()
        self.used_tokens = 0


class WorkingMemory:
    def __init__(self, max_items: int = 20):
        self.max_items = max_items
        self._items: list[str] = []

    def add(self, item: str):
        self._items.append(item)
        if len(self._items) > self.max_items:
            self._items = self._items[-self.max_items :]

    def get_all(self) -> list[str]:
        return list(self._items)

    def clear(self):
        self._items.clear()


class ReActAgent:
    def __init__(self, max_steps: int = 8):
        self.registry = ToolRegistry()
        self.max_steps = max_steps
        self.memory = WorkingMemory()
        self.context = ContextWindow()

    def _parse_tool_call(self, text: str) -> tuple[str, dict] | None:
        patterns = [
            r"(?:Action|action):\s*(\w+)\s*\n\s*(?:Action Input|Input|args):\s*(.+?)(?=\n(?:Thought|Action|Observation|Finish|$))",
            r"(?:Action|action):\s*(\w+)\((.+?)\)",
            r"(?:Action|action):\s*(\w+)\s*\n\s*```(?:json)?\s*(.+?)```",
            r"(?:Use|use|Call|call)\s+(?:tool\s+)?(\w+)\s*(?:with|using|:)?\s*(.+?)(?=\n(?:Thought|Action|Observation|Finish|$))",
        ]
        for pattern in patterns:
            match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
            if match:
                tool_name = match.group(1).strip()
                raw_input = match.group(2).strip()
                try:
                    if raw_input.startswith("{"):
                        tool_input = json.loads(raw_input)
                    elif raw_input.startswith("```"):
                        tool_input = json.loads(raw_input.strip("`").strip())
                    else:
                        tool_input = {"query": raw_input}
                except (json.JSONDecodeError, ValueError):
                    tool_input = {"query": raw_input}
                return tool_name, tool_input
        return None

    def _detect_tool_intent(self, query: str) -> tuple[str, dict] | None:
        q_lower = query.lower()
        if any(kw in q_lower for kw in ["search", "find", "look up", "google", "what is", "who is", "tell me about"]):
            topic = re.sub(
                r"(?:search|find|look up|google|tell me about|what is|who is)\s+(?:for\s+)?",
                "",
                q_lower,
                flags=re.IGNORECASE,
            ).strip()
            if topic:
                return "web_search", {"query": topic}

        if any(kw in q_lower for kw in ["calculate", "compute", "run code", "execute", "python"]):
            code_match = re.search(r"```(?:python)?\s*(.+?)```", query, re.DOTALL)
            if code_match:
                return "code_execute", {"code": code_match.group(1)}
            math_match = re.search(
                r"(?:calculate|compute|what is)\s+(.+?)(?:\?|$)", q_lower
            )
            if math_match:
                expr = math_match.group(1).strip()
                return "code_execute", {"code": f"print({expr})"}

        if any(kw in q_lower for kw in ["database", "query", "table", "select", "sql", "users", "products", "orders"]):
            table_match = re.search(
                r"(?:from|table)\s+(\w+)", q_lower
            )
            table = table_match.group(1) if table_match else ""
            if table in ("users", "products", "orders"):
                return "db_query", {"query": query, "table": table}
            return "db_query", {"query": query}

        if any(kw in q_lower for kw in ["api", "http", "request", "endpoint", "fetch"]):
            url_match = re.search(r"https?://\S+", query)
            url = url_match.group(0) if url_match else "https://api.example.com/data"
            return "api_call", {"url": url}

        return None

    def run(self, query: str, memory: list[str] | None = None) -> Generator[dict, None, None]:
        start_time = time.time()

        if memory:
            for m in memory:
                self.memory.add(m)

        self.context.clear()
        self.context.add(f"User Query: {query}")

        tool_intent = self._detect_tool_intent(query)

        if tool_intent:
            tool_name, tool_input = tool_intent
        else:
            tool_name, tool_input = None, None

        yield {
            "type": "context",
            "tokens": self.context.used_tokens,
        }

        yield {
            "type": "thought",
            "content": f"Analyzing the user query: '{query}'. I need to break this down into steps and determine which tools to use.",
        }

        step_plan = self._plan_steps(query, tool_name)
        yield {
            "type": "thought",
            "content": f"Plan: {step_plan}",
        }

        for step_num in range(min(self.max_steps, len(step_plan))):
            if tool_intent and step_num == 0:
                current_tool, current_input = tool_intent
            elif not tool_intent and step_num == 0:
                yield {
                    "type": "thought",
                    "content": "I don't have a specific tool match for this query. Let me try web search to gather relevant information.",
                }
                current_tool = "web_search"
                current_input = {"query": query}
            else:
                break

            yield {
                "type": "action",
                "content": f"Calling {current_tool} with parameters: {json.dumps(current_input, default=str)[:200]}",
                "tool": current_tool,
                "tool_input": current_input,
            }

            result = self.registry.execute(current_tool, **current_input)

            self.context.add(
                f"Tool {current_tool} result: {result.output[:500]}"
            )

            if result.success:
                yield {
                    "type": "observation",
                    "content": result.output[:2000],
                    "tool": current_tool,
                    "duration": result.duration_ms,
                }

                self.memory.add(
                    f"[{current_tool}] Query about '{query[:50]}': {result.output[:100]}"
                )

                if step_num < len(step_plan) - 1 and tool_intent is None:
                    pass
            else:
                yield {
                    "type": "error",
                    "content": f"Tool error: {result.error}",
                }
                yield {
                    "type": "thought",
                    "content": f"The {current_tool} tool encountered an error: {result.error}. Attempting recovery by trying an alternative approach.",
                }

                recovery_tool = "web_search" if current_tool != "web_search" else "code_execute"
                yield {
                    "type": "action",
                    "content": f"Recovery: trying {recovery_tool} as fallback",
                    "tool": recovery_tool,
                    "tool_input": {"query": query} if recovery_tool == "web_search" else {"code": f"print('Processing: {query}')"},
                }
                recovery_result = self.registry.execute(recovery_tool, **(
                    {"query": query} if recovery_tool == "web_search" else {"code": f"print('Processing: {query}')"}
                ))
                if recovery_result.success:
                    yield {
                        "type": "observation",
                        "content": recovery_result.output[:2000],
                        "tool": recovery_tool,
                        "duration": recovery_result.duration_ms,
                    }

        yield {"type": "context", "tokens": self.context.used_tokens}

        final_answer = self._generate_answer(query, tool_name or "reasoning")
        yield {"type": "answer", "content": final_answer}

        yield {"type": "memory", "items": self.memory.get_all()}

    def _plan_steps(self, query: str, tool_name: str | None) -> list[str]:
        plans = {
            "web_search": [
                "Search the web for relevant information",
                "Analyze and synthesize search results",
            ],
            "code_execute": [
                "Write and execute code to solve the problem",
                "Verify the output and present results",
            ],
            "db_query": [
                "Query the database for requested data",
                "Format and present the query results",
            ],
            "api_call": [
                "Make the API request",
                "Process and present the response",
            ],
        }
        if tool_name and tool_name in plans:
            return plans[tool_name]
        return [
            "Gather information using available tools",
            "Analyze the gathered information",
            "Formulate a comprehensive answer",
        ]

    def _generate_answer(self, query: str, tool_used: str) -> str:
        tool_descriptions = {
            "web_search": "I searched the web and found relevant information",
            "code_execute": "I executed code to compute the result",
            "db_query": "I queried the database and retrieved the data",
            "api_call": "I made an API call to fetch the information",
            "reasoning": "I analyzed your query using available information",
        }
        desc = tool_descriptions.get(tool_used, "I processed your request")

        return (
            f"{desc} for your query: **\"{query}\"**\n\n"
            f"To answer this, I used the **{tool_used}** tool in a multi-step ReAct loop "
            f"(Thought → Action → Observation). The agent autonomously selected the appropriate tool, "
            f"executed it, and observed the results before synthesizing this answer.\n\n"
            f"### How it works\n"
            f"1. **Thought**: Analyzed the query to determine the best approach\n"
            f"2. **Action**: Selected and invoked `{tool_used}` with appropriate parameters\n"
            f"3. **Observation**: Processed the tool's output\n"
            f"4. **Error Recovery**: If a tool fails, the agent falls back to alternatives\n"
            f"5. **Memory**: Key findings are stored in working memory for future context\n\n"
            f"### Context Window\n"
            f"Current context usage: ~{self.context.used_tokens} tokens "
            f"(of {self.context.max_tokens} max). The agent manages context by evicting "
            f"older entries when the window is full.\n\n"
            f"*This is a demonstration of the DSPy ReAct pattern with tool use, "
            f"error recovery, working memory, and context window management.*"
        )
