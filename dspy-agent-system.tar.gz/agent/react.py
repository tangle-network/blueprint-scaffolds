import json
import re
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".pip-packages"))

from typing import Any, Dict, Generator, List, Optional
from dataclasses import dataclass, field

from agent.tools import registry


@dataclass
class WorkingMemory:
    scratchpad: List[str] = field(default_factory=list)
    tool_results: List[Dict[str, Any]] = field(default_factory=list)
    plan: List[str] = field(default_factory=list)
    error_count: int = 0
    max_context_tokens: int = 4000

    def add_thought(self, thought: str):
        self.scratchpad.append(f"Thought: {thought}")

    def add_action(self, tool: str, inp: str):
        self.scratchpad.append(f"Action: {tool}({inp})")

    def add_observation(self, obs: str):
        self.scratchpad.append(f"Observation: {obs}")
        self.tool_results.append({"tool": "current", "result": obs})

    def add_error(self, error: str):
        self.scratchpad.append(f"Error: {error}")
        self.error_count += 1

    def get_context(self) -> str:
        context = "\n".join(self.scratchpad)
        while len(context) > self.max_context_tokens * 4:
            if len(self.scratchpad) > 4:
                self.scratchpad = self.scratchpad[:2] + ["[... earlier steps summarized ...]"] + self.scratchpad[-2:]
                context = "\n".join(self.scratchpad)
            else:
                break
        return context

    def to_dict(self) -> Dict[str, Any]:
        return {
            "scratchpad": self.scratchpad,
            "tool_results": self.tool_results,
            "plan": self.plan,
            "error_count": self.error_count,
        }


THOUGHT_ACTION_RE = re.compile(
    r"(?:Thought:\s*(.+?))?\s*Action:\s*(\w+)\s*\[([^\]]*)\]",
    re.DOTALL,
)

PLAN_RE = re.compile(r"Plan:\s*\n((?:-\s+.+\n?)+)", re.MULTILINE)

TOOL_DESCRIPTIONS = """Available tools:
- web_search[query]: Search the web for information
- code_execute[code]: Execute Python code in a sandbox
- database_query[sql]: Query a local SQLite database (params optional: sql, params)
- api_call[url]: Make an HTTP request (method, body, headers optional)
- calculator[expression]: Evaluate a math expression
"""


def _build_prompt(query: str, memory: WorkingMemory, history: List[Dict]) -> str:
    context = memory.get_context()
    history_text = ""
    if history:
        recent = history[-3:]
        history_text = "Previous conversation:\n"
        for msg in recent:
            role = msg.get("role", "unknown")
            content = msg.get("content", "")
            history_text += f"{role}: {content[:200]}\n"
        history_text += "\n"

    return f"""You are an AI agent that uses the ReAct (Reasoning + Acting) pattern to solve tasks.

You must respond in the following format:
Thought: <your reasoning about what to do>
Action: <tool_name>[<input>]

{TOOL_DESCRIPTIONS}

Rules:
- Always think before acting
- If a tool fails, try a different approach
- After gathering enough information, respond with: Thought: I now know the final answer.\\nAction: finish[<your answer>]
- You can use at most 8 iterations
- Use the scratchpad to track your reasoning

{history_text}Current task: {query}

{context}
Thought:"""


def _parse_response(response: str) -> tuple:
    thought = ""
    action = ""
    action_input = ""

    lines = response.strip().split("\n")
    for line in lines:
        line = line.strip()
        if line.startswith("Thought:"):
            thought = line[len("Thought:"):].strip()
        elif line.startswith("Action:"):
            action_part = line[len("Action:"):].strip()
            match = re.match(r"(\w+)\[(.+)\]", action_part, re.DOTALL)
            if match:
                action = match.group(1)
                action_input = match.group(2).strip()

    if not action:
        match = THOUGHT_ACTION_RE.search(response)
        if match:
            thought = match.group(1) or thought
            action = match.group(2)
            action_input = match.group(3)

    if not action:
        finish_match = re.search(r"Action:\s*finish\[(.+?)\]", response, re.DOTALL)
        if finish_match:
            return finish_match.group(1).strip(), "finish", finish_match.group(1).strip()

    return thought, action, action_input


def run_agent(
    query: str,
    history: Optional[List[Dict]] = None,
    max_iterations: int = 8,
    simulate_llm: bool = True,
) -> Generator[Dict[str, Any], None, None]:
    memory = WorkingMemory()
    history = history or []

    plan_steps = [
        "Understand the user's question",
        "Determine what tools are needed",
        "Execute tools and gather information",
        "Synthesize results into an answer",
    ]
    memory.plan = plan_steps

    for iteration in range(max_iterations):
        if memory.error_count >= 3:
            yield {"type": "error", "content": "Too many errors encountered. Stopping."}
            break

        prompt = _build_prompt(query, memory, history)
        thought, action, action_input = _simulate_thought(query, memory, iteration, max_iterations)

        yield {"type": "thought", "content": thought}
        memory.add_thought(thought)

        if action == "finish":
            yield {"type": "answer", "content": action_input}
            break

        if not action:
            yield {"type": "error", "content": f"Could not parse action from response"}
            memory.add_error("Parse failure")
            continue

        yield {"type": "action", "tool": action, "input": action_input}
        memory.add_action(action, action_input)

        tool = registry.get(action)
        if not tool:
            obs = f"Unknown tool: {action}. Available tools: {', '.join(t.name for t in registry._tools.values())}"
            yield {"type": "observation", "content": obs}
            memory.add_error(obs)
            continue

        try:
            if action == "database_query":
                obs = registry.execute(action, sql=action_input)
            elif action == "api_call":
                parts = action_input.split("|")
                url = parts[0].strip()
                method = parts[1].strip() if len(parts) > 1 else "GET"
                body = parts[2].strip() if len(parts) > 2 else ""
                headers = parts[3].strip() if len(parts) > 3 else "{}"
                obs = registry.execute(action, url=url, method=method, body=body, headers=headers)
            else:
                kwargs = {}
                if action == "code_execute":
                    kwargs["code"] = action_input
                elif action == "web_search":
                    kwargs["query"] = action_input
                elif action == "calculator":
                    kwargs["expression"] = action_input
                else:
                    kwargs = {"input": action_input}
                obs = registry.execute(action, **kwargs)
        except Exception as e:
            obs = f"Tool execution error: {e}"
            memory.add_error(obs)

        obs_display = obs[:1000] if len(obs) > 1000 else obs
        yield {"type": "observation", "content": obs_display}
        memory.add_observation(obs)

    else:
        final_context = memory.get_context()
        yield {"type": "answer", "content": f"I've gathered information through {max_iterations} steps but couldn't reach a final conclusion. Based on my research: {final_context[-500:]}"}

    yield {"type": "done"}


def _simulate_thought(query: str, memory: WorkingMemory, iteration: int, max_iter: int) -> tuple:
    q = query.lower()
    scratchpad = memory.scratchpad

    if iteration == 0:
        if any(kw in q for kw in ["search", "find", "look up", "what is", "who is", "when was", "where is"]):
            return (
                "I need to search for information about this topic. Let me start with a web search.",
                "web_search",
                query,
            )
        elif any(kw in q for kw in ["calculate", "compute", "math", "what is "]):
            expr_match = re.search(r"[\d+\-*/().^ ]+", query)
            expr = expr_match.group(0).strip() if expr_match else query
            return (
                "I need to perform a calculation. Let me use the calculator tool.",
                "calculator",
                expr,
            )
        elif any(kw in q for kw in ["code", "python", "run", "execute", "program"]):
            return (
                "I need to execute some code. Let me first understand what computation is needed.",
                "code_execute",
                f"# Analyzing: {query}\nprint('Hello from the code sandbox!')\nresult = 2 + 2\nprint(f'Result: {{result}}')",
            )
        elif any(kw in q for kw in ["database", "sql", "query", "table", "record"]):
            return (
                "I should query the database to find relevant information.",
                "database_query",
                "SELECT * FROM documents",
            )
        elif any(kw in q for kw in ["api", "fetch", "http", "request", "call"]):
            return (
                "I need to make an API call to retrieve data.",
                "api_call",
                "https://httpbin.org/get",
            )
        else:
            return (
                "Let me start by searching for relevant information about this topic.",
                "web_search",
                query,
            )

    elif iteration == 1:
        if len(scratchpad) > 0:
            obs = memory.tool_results[-1]["result"] if memory.tool_results else ""
            if "error" in obs.lower():
                return (
                    "The previous attempt had an error. Let me try a different approach.",
                    "web_search",
                    query,
                )
            return (
                "I've gathered some initial information. Let me dig deeper to provide a comprehensive answer.",
                "web_search",
                f"{query} detailed explanation",
            )
        return ("Let me try a different approach.", "web_search", query)

    else:
        all_observations = "\n".join(
            r.get("result", "")[:200] for r in memory.tool_results
        )
        return (
            f"I now have enough information to provide a final answer based on my research through {iteration + 1} steps.",
            "finish",
            f"Based on my analysis through {iteration + 1} steps of research, here is what I found about your question: {all_observations[:500]}\n\nI used the ReAct (Reasoning + Acting) pattern to gather this information, planning my approach and adapting based on the results at each step.",
        )
