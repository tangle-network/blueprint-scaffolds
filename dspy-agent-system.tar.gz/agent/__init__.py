"""
ReAct Agent - Multi-step AI agent using DSPy's ReAct pattern.
"""

__version__ = "1.0.0"
