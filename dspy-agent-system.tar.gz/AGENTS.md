# AGENTS.md

Build a multi-step AI agent using DSPy's ReAct pattern. Tool registration, reasoning chain, action execution.

## What's here

This project was scaffolded by starter-foundry. The user's prompt drove the choices below — read their prompt first, it takes priority over everything in this file.

- **Family:** `dspy-pipeline-py`
- **Layers:** `framework:dspy-pipeline-py`, `database:sqlite`, `sdk:none`, `auth:none`, `payments:none`, `queue:none`

## Getting started

```bash
python3 main.py
```

Key files: `main.py`, `pipeline.json`

## How to use this scaffold

This is a starting point, not a contract. You own every file.

- **Customize freely.** Replace components, change the layout, swap the color scheme — whatever fits the user's product.
- **The scaffold saves you setup time** — Tailwind, shadcn/ui, path aliases, and framework config are ready. Don't redo them.
- **Check `.starter-foundry/compose-report.json`** if you want to see which layer wrote which file.
- **Update this file** as the project evolves. Delete sections that no longer apply.
