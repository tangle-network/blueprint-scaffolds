import { useState, useRef, useEffect, useCallback } from 'react';
import { Message, AgentTrace, AgentStep, AVAILABLE_TOOLS } from './types';
import ReactMarkdown from 'react-markdown';

function useMessages() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [contextTokens, setContextTokens] = useState(0);
  const [memory, setMemory] = useState<string[]>([]);

  const sendMessage = useCallback(async (content: string) => {
    const userMsg: Message = {
      id: crypto.randomUUID(),
      role: 'user',
      content,
      timestamp: Date.now(),
    };
    setMessages(prev => [...prev, userMsg]);
    setIsLoading(true);

    try {
      const res = await fetch('/api/agent/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: content, memory }),
      });

      if (!res.ok) throw new Error(`HTTP ${res.status}`);

      const reader = res.body?.getReader();
      if (!reader) throw new Error('No reader');

      const decoder = new TextDecoder();
      let assistantContent = '';
      const steps: AgentStep[] = [];
      let finalAnswer = '';
      let totalSteps = 0;
      let totalDuration = 0;
      let newMemory: string[] = [];
      let buffer = '';

      const assistantId = crypto.randomUUID();
      const assistantMsg: Message = {
        id: assistantId,
        role: 'assistant',
        content: '',
        timestamp: Date.now(),
      };
      setMessages(prev => [...prev, assistantMsg]);

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          const data = line.slice(6);
          if (data === '[DONE]') break;

          try {
            const event = JSON.parse(data);

            if (event.type === 'thought') {
              steps.push({
                type: 'thought',
                content: event.content,
                timestamp: Date.now(),
              });
            } else if (event.type === 'action') {
              steps.push({
                type: 'action',
                content: event.content,
                tool: event.tool,
                toolInput: event.tool_input,
                timestamp: Date.now(),
              });
            } else if (event.type === 'observation') {
              steps.push({
                type: 'observation',
                content: event.content,
                tool: event.tool,
                duration: event.duration,
                timestamp: Date.now(),
              });
              totalSteps++;
              totalDuration += event.duration || 0;
            } else if (event.type === 'error') {
              steps.push({
                type: 'error',
                content: event.content,
                timestamp: Date.now(),
              });
            } else if (event.type === 'answer') {
              finalAnswer = event.content;
              assistantContent = event.content;
            } else if (event.type === 'memory') {
              newMemory = event.items || [];
            } else if (event.type === 'context') {
              setContextTokens(event.tokens || 0);
            }

            const trace: AgentTrace = {
              steps: [...steps],
              finalAnswer,
              totalSteps,
              totalDuration,
              memory: newMemory,
            };

            setMessages(prev =>
              prev.map(m =>
                m.id === assistantId
                  ? { ...m, content: assistantContent || 'Thinking...', trace }
                  : m
              )
            );
          } catch {
            // skip malformed JSON
          }
        }
      }

      setMemory(newMemory);
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : 'Unknown error';
      setMessages(prev => [
        ...prev,
        {
          id: crypto.randomUUID(),
          role: 'system',
          content: `Error: ${errMsg}. Make sure the backend is running on port 8000.`,
          timestamp: Date.now(),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  }, [memory]);

  return { messages, isLoading, contextTokens, memory, sendMessage };
}

function StepTrace({ trace }: { trace: AgentTrace }) {
  return (
    <div className="step-trace">
      <div className="step-trace-header">
        <span>Agent Trace</span>
        <span style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--text-secondary)' }}>
          {trace.totalSteps} tool calls · {(trace.totalDuration / 1000).toFixed(1)}s
        </span>
      </div>
      {trace.steps.map((step, i) => (
        <div key={i} className={`step ${step.type}`}>
          <div className="step-label">
            {step.type === 'thought' && '💭 Thought'}
            {step.type === 'action' && `⚡ Action: ${step.tool || 'unknown'}`}
            {step.type === 'observation' && '👁️ Observation'}
            {step.type === 'error' && '❌ Error'}
          </div>
          <div className="step-content">{step.content}</div>
          {step.tool && step.type === 'observation' && (
            <div className="tool-call">
              <div className="tool-call-header">
                <span className="tool-call-name">{step.tool}</span>
                {step.duration != null && (
                  <span className="tool-call-duration">{step.duration}ms</span>
                )}
              </div>
              <div className="tool-call-result">{step.content}</div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function MessageBubble({ message }: { message: Message }) {
  return (
    <div className={`message ${message.role}`}>
      <div className="message-header">
        <span className={`message-role ${message.role}`}>{message.role}</span>
        <span className="message-timestamp">
          {new Date(message.timestamp).toLocaleTimeString()}
        </span>
      </div>
      <div className="message-content">
        <ReactMarkdown>{message.content}</ReactMarkdown>
        {message.trace && message.trace.steps.length > 0 && (
          <StepTrace trace={message.trace} />
        )}
      </div>
    </div>
  );
}

function Sidebar({ memory, contextTokens }: { memory: string[]; contextTokens: number }) {
  return (
    <div className="sidebar">
      <div className="sidebar-header">
        <h1>ReAct Agent</h1>
        <p>DSPy-powered multi-step reasoning</p>
      </div>
      <div className="tool-list">
        {AVAILABLE_TOOLS.map(tool => (
          <div key={tool.name} className="tool-item">
            <div className={`tool-icon ${tool.category}`}>{tool.icon}</div>
            <div className="tool-info">
              <h4>{tool.name}</h4>
              <p>{tool.description}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="memory-section">
        <h3>Working Memory</h3>
        {memory.length === 0 ? (
          <div className="memory-item">No memories yet</div>
        ) : (
          memory.slice(-5).map((m, i) => <div key={i} className="memory-item">{m}</div>)
        )}
      </div>
    </div>
  );
}

export default function App() {
  const { messages, isLoading, contextTokens, memory, sendMessage } = useMessages();
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSubmit = () => {
    const trimmed = input.trim();
    if (!trimmed || isLoading) return;
    sendMessage(trimmed);
    setInput('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="app">
      <Sidebar memory={memory} contextTokens={contextTokens} />
      <div className="main">
        <div className="context-bar">
          <div className="context-bar-item">
            Context: <span className="context-bar-value">{contextTokens} tokens</span>
          </div>
          <div className="context-bar-item">
            Memory: <span className="context-bar-value">{memory.length} items</span>
          </div>
          <div className="context-bar-item">
            Messages: <span className="context-bar-value">{messages.length}</span>
          </div>
        </div>
        <div className="messages">
          {messages.length === 0 && (
            <div className="empty-state">
              <h2>ReAct Agent</h2>
              <p>
                A multi-step AI agent using DSPy's ReAct pattern. Ask a question and watch
                the agent reason through thought-action-observation loops, selecting and
                executing tools autonomously.
              </p>
            </div>
          )}
          {messages.map(msg => (
            <MessageBubble key={msg.id} message={msg} />
          ))}
          {isLoading && messages[messages.length - 1]?.role !== 'assistant' && (
            <div className="typing-indicator">
              <div className="typing-dot" />
              <div className="typing-dot" />
              <div className="typing-dot" />
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
        <div className="input-area">
          <div className="input-wrapper">
            <textarea
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask the agent anything..."
              rows={1}
              disabled={isLoading}
            />
            <button className="send-btn" onClick={handleSubmit} disabled={isLoading || !input.trim()}>
              Send
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
