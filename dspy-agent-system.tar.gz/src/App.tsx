import { useState, useRef, useEffect } from "react";
import { useChat } from "@/hooks/useChat";
import { MessageBubble } from "@/components/MessageBubble";
import { StreamSteps } from "@/components/StepVisualization";
import { StreamIndicator } from "@/components/StreamIndicator";
import { ToolPanel } from "@/components/ToolPanel";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PanelLeftClose, PanelLeft, Cpu } from "lucide-react";

export default function App() {
  const { messages, isLoading, streamEvents, sendMessage, stop } = useChat();
  const [input, setInput] = useState("");
  const [showTools, setShowTools] = useState(true);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, streamEvents]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;
    sendMessage(input.trim());
    setInput("");
  };

  return (
    <div className="flex h-screen">
      {showTools && (
        <aside className="w-72 border-r bg-card overflow-y-auto p-4 shrink-0">
          <ToolPanel />
        </aside>
      )}

      <div className="flex flex-col flex-1 min-w-0 max-w-3xl mx-auto">
        <header className="border-b px-6 py-3 flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => setShowTools(!showTools)}>
            {showTools ? <PanelLeftClose className="h-4 w-4" /> : <PanelLeft className="h-4 w-4" />}
          </Button>
          <Cpu className="h-5 w-5" />
          <div>
            <h1 className="text-lg font-bold">AI ReAct Agent</h1>
            <p className="text-xs text-muted-foreground">
              Multi-step reasoning with tool use
            </p>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 && (
            <div className="flex items-center justify-center h-full text-muted-foreground">
              <div className="text-center">
                <Cpu className="h-12 w-12 mx-auto mb-4 opacity-20" />
                <p className="text-lg font-medium">Start a conversation</p>
                <p className="text-sm mt-1">Ask anything — the agent will reason, plan, and use tools</p>
              </div>
            </div>
          )}
          {messages.map((msg) => (
            <MessageBubble key={msg.id} message={msg} />
          ))}
          {isLoading && streamEvents.length > 0 && (
            <>
              <StreamSteps events={streamEvents} />
              <StreamIndicator events={streamEvents} />
            </>
          )}
          <div ref={bottomRef} />
        </div>

        <form onSubmit={handleSubmit} className="border-t p-4 flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask the agent..."
            disabled={isLoading}
            className="flex-1"
          />
          {isLoading ? (
            <Button type="button" variant="destructive" onClick={stop}>
              Stop
            </Button>
          ) : (
            <Button type="submit" disabled={!input.trim()}>
              Send
            </Button>
          )}
        </form>
      </div>
    </div>
  );
}
