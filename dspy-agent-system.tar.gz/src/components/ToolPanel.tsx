import { useEffect, useState } from "react";
import { ToolInfo } from "@/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Wrench, Search, Code, Database, Globe, Calculator } from "lucide-react";

const toolIcons: Record<string, React.ReactNode> = {
  web_search: <Search className="h-4 w-4" />,
  code_execute: <Code className="h-4 w-4" />,
  database_query: <Database className="h-4 w-4" />,
  api_call: <Globe className="h-4 w-4" />,
  calculator: <Calculator className="h-4 w-4" />,
};

export function ToolPanel() {
  const [tools, setTools] = useState<ToolInfo[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/tools")
      .then((r) => r.json())
      .then((data) => setTools(data.tools || []))
      .catch(() => {
        const fallback: ToolInfo[] = [
          { name: "web_search", description: "Search the web for information", parameters: { query: "Search query string" } },
          { name: "code_execute", description: "Execute Python code in a sandbox", parameters: { code: "Python code to execute" } },
          { name: "database_query", description: "Query a local SQLite database", parameters: { sql: "SQL query" } },
          { name: "api_call", description: "Make an HTTP API call", parameters: { url: "URL to call" } },
          { name: "calculator", description: "Evaluate a math expression", parameters: { expression: "Math expression" } },
        ];
        setTools(fallback);
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="p-4 text-sm text-muted-foreground animate-pulse">Loading tools...</div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 px-1">
        <Wrench className="h-4 w-4" />
        <h2 className="text-sm font-semibold">Available Tools</h2>
        <Badge variant="secondary" className="text-xs">{tools.length}</Badge>
      </div>
      {tools.map((tool) => (
        <Card key={tool.name} className="bg-muted/30">
          <CardHeader className="py-2 px-3">
            <CardTitle className="text-xs flex items-center gap-2">
              {toolIcons[tool.name] || <Wrench className="h-3 w-3" />}
              <span>{tool.name}</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="py-1 px-3">
            <p className="text-xs text-muted-foreground mb-1">{tool.description}</p>
            <div className="flex flex-wrap gap-1">
              {Object.keys(tool.parameters).map((param) => (
                <Badge key={param} variant="outline" className="text-[10px] px-1 py-0">
                  {param}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
