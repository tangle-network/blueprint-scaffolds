import { AgentStep } from "@/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface StepVisualizationProps {
  steps: AgentStep[];
  isStreaming?: boolean;
}

export function StepVisualization({ steps, isStreaming }: StepVisualizationProps) {
  if (steps.length === 0) return null;

  return (
    <div className="space-y-2 mt-2">
      {steps.map((step, i) => (
        <Card key={i} className="bg-muted/50">
          <CardHeader className="py-2 px-3">
            <CardTitle className="text-xs flex items-center gap-2">
              <Badge variant="secondary">Step {i + 1}</Badge>
              {step.action && <Badge>{step.action}</Badge>}
              {isStreaming && i === steps.length - 1 && (
                <span className="animate-pulse text-muted-foreground">thinking...</span>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="py-2 px-3 text-xs space-y-1">
            {step.thought && (
              <div className="text-muted-foreground">
                <span className="font-medium">Thought:</span> {step.thought}
              </div>
            )}
            {step.action && (
              <div>
                <span className="font-medium">Action:</span>{" "}
                <code className="bg-background px-1 rounded">{step.action}</code>
                {step.action_input && (
                  <span>
                    {" "}
                    → <code className="bg-background px-1 rounded">{step.action_input}</code>
                  </span>
                )}
              </div>
            )}
            {step.observation && (
              <div className="text-muted-foreground">
                <span className="font-medium">Observation:</span> {step.observation}
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

interface StreamStepsProps {
  events: import("@/types").StreamEvent[];
}

export function StreamSteps({ events }: StreamStepsProps) {
  const steps: AgentStep[] = [];
  let currentStep: AgentStep | null = null;

  for (const ev of events) {
    if (ev.type === "thought") {
      currentStep = { thought: ev.content, action: "", action_input: "", observation: "" };
      steps.push(currentStep);
    } else if (ev.type === "action" && currentStep) {
      currentStep.action = ev.tool;
      currentStep.action_input = ev.input;
    } else if (ev.type === "observation" && currentStep) {
      currentStep.observation = ev.content;
    }
  }

  return <StepVisualization steps={steps} isStreaming />;
}
