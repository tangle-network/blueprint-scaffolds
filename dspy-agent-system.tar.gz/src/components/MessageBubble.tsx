import { AgentMessage } from "@/types";
import { StepVisualization } from "./StepVisualization";

interface MessageBubbleProps {
  message: AgentMessage;
}

export function MessageBubble({ message }: MessageBubbleProps) {
  const isUser = message.role === "user";

  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div className={`max-w-[80%] rounded-lg px-4 py-2 ${isUser ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
        {!isUser && message.steps && message.steps.length > 0 && (
          <StepVisualization steps={message.steps} />
        )}
        <div className="text-sm whitespace-pre-wrap">
          {message.error ? (
            <span className="text-destructive">{message.content}</span>
          ) : (
            message.content
          )}
        </div>
      </div>
    </div>
  );
}
