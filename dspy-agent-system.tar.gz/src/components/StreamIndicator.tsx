import { StreamEvent } from "@/types";
import { Badge } from "@/components/ui/badge";

interface StreamIndicatorProps {
  events: StreamEvent[];
}

export function StreamIndicator({ events }: StreamIndicatorProps) {
  if (events.length === 0) return null;

  const last = events[events.length - 1];
  const labels: Record<string, string> = {
    thought: "Thinking",
    action: "Executing",
    observation: "Observing",
    answer: "Answering",
    error: "Error",
  };

  return (
    <div className="flex items-center gap-2 px-4 py-2">
      <Badge variant={last.type === "error" ? "destructive" : "secondary"}>
        {labels[last.type] || last.type}
      </Badge>
      <span className="text-xs text-muted-foreground animate-pulse">Agent is working...</span>
    </div>
  );
}
