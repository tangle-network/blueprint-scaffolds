export interface AgentStep {
  thought: string;
  action: string;
  action_input: string;
  observation: string;
}

export interface AgentMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  steps?: AgentStep[];
  final_answer?: string;
  error?: string;
  timestamp: number;
}

export interface ToolInfo {
  name: string;
  description: string;
  parameters: Record<string, string>;
}

export interface AgentConfig {
  max_iterations: number;
  temperature: number;
  model: string;
}

export type StreamEvent =
  | { type: "thought"; content: string }
  | { type: "action"; tool: string; input: string }
  | { type: "observation"; content: string }
  | { type: "answer"; content: string }
  | { type: "error"; content: string }
  | { type: "done" };
