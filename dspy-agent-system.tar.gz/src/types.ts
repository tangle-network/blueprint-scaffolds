export interface AgentStep {
  type: 'thought' | 'action' | 'observation' | 'error';
  content: string;
  tool?: string;
  toolInput?: Record<string, unknown>;
  duration?: number;
  timestamp: number;
}

export interface AgentTrace {
  steps: AgentStep[];
  finalAnswer: string;
  totalSteps: number;
  totalDuration: number;
  memory: string[];
}

export interface ToolInfo {
  name: string;
  description: string;
  category: 'search' | 'code' | 'db' | 'api';
  icon: string;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  trace?: AgentTrace;
  timestamp: number;
}

export const AVAILABLE_TOOLS: ToolInfo[] = [
  { name: 'web_search', description: 'Search the web for information', category: 'search', icon: '🔍' },
  { name: 'code_execute', description: 'Execute Python code in sandbox', category: 'code', icon: '⚡' },
  { name: 'db_query', description: 'Query the database', category: 'db', icon: '🗄️' },
  { name: 'api_call', description: 'Make external API calls', category: 'api', icon: '🌐' },
];
