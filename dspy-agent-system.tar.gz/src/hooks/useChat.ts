import React from "react";

export function useChat() {
  const [messages, setMessages] = React.useState<import("@/types").AgentMessage[]>([]);
  const [isLoading, setIsLoading] = React.useState(false);
  const [streamEvents, setStreamEvents] = React.useState<import("@/types").StreamEvent[]>([]);
  const abortRef = React.useRef<AbortController | null>(null);

  const sendMessage = React.useCallback(
    async (content: string) => {
      const userMsg: import("@/types").AgentMessage = {
        id: crypto.randomUUID(),
        role: "user",
        content,
        timestamp: Date.now(),
      };

      setMessages((prev) => [...prev, userMsg]);
      setIsLoading(true);
      setStreamEvents([]);

      const abort = new AbortController();
      abortRef.current = abort;

      try {
        const res = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ message: content, history: messages }),
          signal: abort.signal,
        });

        const reader = res.body?.getReader();
        if (!reader) throw new Error("No reader");

        const decoder = new TextDecoder();
        let buffer = "";
        const events: import("@/types").StreamEvent[] = [];
        let steps: import("@/types").AgentStep[] = [];
        let finalAnswer = "";
        let errorMsg = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() || "";

          for (const line of lines) {
            if (!line.startsWith("data: ")) continue;
            const data = line.slice(6);
            if (data === "[DONE]") continue;

            try {
              const event: import("@/types").StreamEvent = JSON.parse(data);
              events.push(event);
              setStreamEvents([...events]);

              if (event.type === "thought") {
                steps.push({
                  thought: event.content,
                  action: "",
                  action_input: "",
                  observation: "",
                });
              } else if (event.type === "action" && steps.length > 0) {
                const s = steps[steps.length - 1];
                s.action = event.tool;
                s.action_input = event.input;
              } else if (event.type === "observation" && steps.length > 0) {
                const s = steps[steps.length - 1];
                s.observation = event.content;
              } else if (event.type === "answer") {
                finalAnswer = event.content;
              } else if (event.type === "error") {
                errorMsg = event.content;
              }
            } catch {}
          }
        }

        const assistantMsg: import("@/types").AgentMessage = {
          id: crypto.randomUUID(),
          role: "assistant",
          content: finalAnswer || errorMsg || "No response",
          steps: steps.filter((s) => s.thought),
          final_answer: finalAnswer,
          error: errorMsg || undefined,
          timestamp: Date.now(),
        };

        setMessages((prev) => [...prev, assistantMsg]);
      } catch (err: unknown) {
        if (err instanceof Error && err.name !== "AbortError") {
          const errMsg: import("@/types").AgentMessage = {
            id: crypto.randomUUID(),
            role: "assistant",
            content: `Error: ${err.message}`,
            error: err.message,
            timestamp: Date.now(),
          };
          setMessages((prev) => [...prev, errMsg]);
        }
      } finally {
        setIsLoading(false);
        setStreamEvents([]);
        abortRef.current = null;
      }
    },
    [messages]
  );

  const stop = React.useCallback(() => {
    abortRef.current?.abort();
  }, []);

  return { messages, isLoading, streamEvents, sendMessage, stop };
}
