"""FastAPI backend for the DSPy ReAct agent."""

from __future__ import annotations

import asyncio
import json
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from .agent import ReActAgent, AgentResult, AgentStep
from .tools import registry as default_registry
from .memory import WorkingMemory


app = FastAPI(title="DSPy ReAct Agent", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

_sessions: Dict[str, ReActAgent] = {}


class QueryRequest(BaseModel):
    query: str
    session_id: Optional[str] = None


class QueryResponse(BaseModel):
    answer: str
    session_id: str
    steps: List[Dict[str, Any]]
    total_steps: int
    execution_time: float
    memory_usage: int
    plan: Optional[Dict[str, Any]] = None


def _get_agent(session_id: Optional[str]) -> ReActAgent:
    if session_id and session_id in _sessions:
        return _sessions[session_id]
    agent = ReActAgent()
    if session_id:
        _sessions[session_id] = agent
    return agent


def _step_to_dict(step: AgentStep) -> Dict[str, Any]:
    return {
        "stepNumber": step.step_number,
        "thought": step.thought,
        "action": step.action,
        "actionInput": step.action_input,
        "observation": step.observation,
        "error": step.error,
        "timestamp": step.timestamp,
    }


def _result_to_response(result: AgentResult) -> QueryResponse:
    return QueryResponse(
        answer=result.answer,
        session_id=result.session_id,
        steps=[_step_to_dict(s) for s in result.steps],
        total_steps=result.total_steps,
        execution_time=result.execution_time,
        memory_usage=result.memory_usage,
        plan={"goal": result.plan.goal, "steps": result.plan.steps, "currentStep": result.plan.current_step} if result.plan else None,
    )


@app.get("/api/tools")
async def list_tools() -> List[Dict[str, Any]]:
    return default_registry.list_tools()


@app.post("/api/query", response_model=QueryResponse)
async def query_agent(request: QueryRequest) -> QueryResponse:
    agent = _get_agent(request.session_id)
    result = await agent.run(request.query, session_id=request.session_id)
    return _result_to_response(result)


@app.websocket("/ws/agent")
async def websocket_agent(websocket: WebSocket) -> None:
    await websocket.accept()
    agent: Optional[ReActAgent] = None
    try:
        while True:
            data = await websocket.receive_text()
            msg = json.loads(data)
            if msg.get("type") == "query":
                session_id = msg.get("session_id")
                if session_id:
                    if session_id not in _sessions:
                        _sessions[session_id] = ReActAgent()
                    agent = _sessions[session_id]
                else:
                    agent = ReActAgent()

                await websocket.send_json({"type": "status", "status": "processing"})

                result = await agent.run(msg["query"], session_id=session_id)

                for step in result.steps:
                    await websocket.send_json({
                        "type": "step",
                        **_step_to_dict(step),
                    })

                await websocket.send_json({
                    "type": "result",
                    "answer": result.answer,
                    "sessionId": result.session_id,
                    "totalSteps": result.total_steps,
                    "executionTime": result.execution_time,
                    "memoryUsage": result.memory_usage,
                })
            elif msg.get("type") == "clear":
                if agent:
                    agent.memory.clear()
                await websocket.send_json({"type": "cleared"})
    except WebSocketDisconnect:
        pass


@app.get("/api/health")
async def health() -> Dict[str, str]:
    return {"status": "ok"}
