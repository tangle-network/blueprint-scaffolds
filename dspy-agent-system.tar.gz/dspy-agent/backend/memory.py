"""Working memory and context window management for the agent."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class MemoryEntry:
    role: str
    content: str
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def token_estimate(self) -> int:
        return max(1, len(self.content) // 4)


class WorkingMemory:
    def __init__(self, max_tokens: int = 8000) -> None:
        self._entries: List[MemoryEntry] = []
        self._max_tokens = max_tokens
        self._current_tokens = 0
        self._scratchpad: Dict[str, Any] = {}

    def add(self, role: str, content: str, **metadata: Any) -> None:
        entry = MemoryEntry(role=role, content=content, metadata=metadata)
        self._entries.append(entry)
        self._current_tokens += entry.token_estimate()
        self._enforce_limit()

    def get_context(self, max_tokens: Optional[int] = None) -> List[Dict[str, str]]:
        limit = max_tokens or self._max_tokens
        total = 0
        result: List[Dict[str, str]] = []
        for entry in reversed(self._entries):
            est = entry.token_estimate()
            if total + est > limit:
                break
            total += est
            result.append({"role": entry.role, "content": entry.content})
        result.reverse()
        return result

    def _enforce_limit(self) -> None:
        while self._current_tokens > self._max_tokens and len(self._entries) > 1:
            removed = self._entries.pop(0)
            self._current_tokens -= removed.token_estimate()

    def set_scratch(self, key: str, value: Any) -> None:
        self._scratchpad[key] = value

    def get_scratch(self, key: str, default: Any = None) -> Any:
        return self._scratchpad.get(key, default)

    def get_summary(self) -> str:
        if not self._entries:
            return "No memory entries."
        lines = [f"[{e.role}] {e.content[:120]}" for e in self._entries[-10:]]
        return "\n".join(lines)

    def clear(self) -> None:
        self._entries.clear()
        self._current_tokens = 0
        self._scratchpad.clear()

    @property
    def token_usage(self) -> int:
        return self._current_tokens

    @property
    def entry_count(self) -> int:
        return len(self._entries)
