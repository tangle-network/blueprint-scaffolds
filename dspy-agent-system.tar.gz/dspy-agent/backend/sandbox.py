"""Sandboxed code execution runner."""

from __future__ import annotations

import json
import subprocess
import tempfile
import resource
import signal
import os
from typing import Any, Dict, Optional


SANDBOX_DEFAULTS = {
    "max_memory_mb": 128,
    "max_timeout_s": 30,
    "max_output_bytes": 65536,
}


class SandboxResult:
    def __init__(
        self,
        stdout: str,
        stderr: str,
        returncode: int,
        timed_out: bool = False,
        memory_exceeded: bool = False,
    ) -> None:
        self.stdout = stdout
        self.stderr = stderr
        self.returncode = returncode
        self.timed_out = timed_out
        self.memory_exceeded = memory_exceeded

    def to_dict(self) -> Dict[str, Any]:
        return {
            "stdout": self.stdout[:SANDBOX_DEFAULTS["max_output_bytes"]],
            "stderr": self.stderr[:SANDBOX_DEFAULTS["max_output_bytes"]],
            "returncode": self.returncode,
            "timed_out": self.timed_out,
            "memory_exceeded": self.memory_exceeded,
        }


def run_sandboxed(
    code: str,
    language: str = "python",
    timeout: int = SANDBOX_DEFAULTS["max_timeout_s"],
    max_memory_mb: int = SANDBOX_DEFAULTS["max_memory_mb"],
) -> SandboxResult:
    if language != "python":
        return SandboxResult("", f"Unsupported language: {language}", -1)

    wrapper = f"""
import sys
import resource
resource.setrlimit(resource.RLIMIT_AS, ({max_memory_mb * 1024 * 1024}, {max_memory_mb * 1024 * 1024}))
resource.setrlimit(resource.RLIMIT_CPU, ({timeout}, {timeout}))
{code}
"""
    path = ""
    try:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write(wrapper)
            f.flush()
            path = f.name

        proc = subprocess.run(
            ["python3", path],
            capture_output=True,
            text=True,
            timeout=timeout + 5,
        )
        os.unlink(path)
        return SandboxResult(stdout=proc.stdout, stderr=proc.stderr, returncode=proc.returncode)
    except subprocess.TimeoutExpired:
        if path and os.path.exists(path):
            os.unlink(path)
        return SandboxResult("", f"Execution timed out after {timeout}s", -1, timed_out=True)
    except Exception as exc:
        if path and os.path.exists(path):
            os.unlink(path)
        return SandboxResult("", str(exc), -1)
