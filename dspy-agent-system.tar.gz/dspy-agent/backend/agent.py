"""DSPy ReAct agent with thought-action-observation loop, multi-step planning, and error recovery."""

from __future__ import annotations

import json
import re
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .memory import WorkingMemory
from .tools import registry as default_registry
from .tools import ToolRegistry


@dataclass
class AgentStep:
    step_number: int
    thought: Optional[str] = None
    action: Optional[str] = None
    action_input: Optional[Dict[str, Any]] = None
    observation: Optional[str] = None
    error: Optional[str] = None
    timestamp: float = field(default_factory=time.time)


@dataclass
class AgentPlan:
    goal: str
    steps: List[str] = field(default_factory=list)
    current_step: int = 0


@dataclass
class AgentResult:
    query: str
    answer: str
    steps: List[AgentStep] = field(default_factory=list)
    plan: Optional[AgentPlan] = None
    total_steps: int = 0
    execution_time: float = 0.0
    memory_usage: int = 0
    session_id: str = ""


class ReActAgent:
    MAX_ITERATIONS = 15
    MAX_RETRIES = 2

    def __init__(
        self,
        registry: Optional[ToolRegistry] = None,
        max_iterations: int = MAX_ITERATIONS,
        memory_max_tokens: int = 8000,
    ) -> None:
        self.registry = registry or default_registry
        self.max_iterations = max_iterations
        self.memory = WorkingMemory(max_tokens=memory_max_tokens)
        self._lm = None

    def _build_system_prompt(self) -> str:
        tools_desc = "\n".join(
            f"- {t['name']}: {t['description']}" for t in self.registry.list_tools()
        )
        return (
            "You are a ReAct agent. For each step, produce a Thought, then an Action.\n"
            "Available tools:\n"
            f"{tools_desc}\n\n"
            "Format your response EXACTLY as:\n"
            "Thought: <your reasoning>\n"
            "Action: <tool_name>\n"
            "Action Input: <JSON object of parameters>\n\n"
            "When you have the final answer, respond with:\n"
            "Thought: <final reasoning>\n"
            "Final Answer: <your answer>\n"
        )

    def _parse_response(self, text: str) -> Dict[str, Any]:
        result: Dict[str, Any] = {"thought": None, "action": None, "action_input": None, "final_answer": None}
        thought_match = re.search(r"Thought:\s*(.+?)(?=\n(?:Action|Final)|$)", text, re.DOTALL)
        if thought_match:
            result["thought"] = thought_match.group(1).strip()
        action_match = re.search(r"Action:\s*(\w+)", text)
        if action_match:
            result["action"] = action_match.group(1).strip()
        input_match = re.search(r"Action Input:\s*(.+?)(?=\n(?:Thought|Action|Final)|$)", text, re.DOTALL)
        if input_match:
            raw = input_match.group(1).strip()
            try:
                result["action_input"] = json.loads(raw)
            except json.JSONDecodeError:
                result["action_input"] = {"input": raw}
        final_match = re.search(r"Final Answer:\s*(.+?)$", text, re.DOTALL)
        if final_match:
            result["final_answer"] = final_match.group(1).strip()
        return result

    def _make_thought_action(self, query: str, history: List[AgentStep]) -> Dict[str, Any]:
        tools_list = self.registry.list_tools()
        context = self.memory.get_context(max_tokens=4000)
        history_text = ""
        for s in history:
            if s.thought:
                history_text += f"Step {s.step_number} - Thought: {s.thought}\n"
            if s.action:
                history_text += f"  Action: {s.action}({json.dumps(s.action_input or {})})\n"
            if s.observation:
                history_text += f"  Observation: {s.observation[:300]}\n"
            if s.error:
                history_text += f"  Error: {s.error}\n"

        prompt = (
            f"System: {self._build_system_prompt()}\n\n"
            f"Query: {query}\n\n"
        )
        if history_text:
            prompt += f"History so far:\n{history_text}\n"
        prompt += "What should I do next? Respond with Thought and either Action or Final Answer.\n"

        tool_names = [t["name"] for t in tools_list]
        if not history:
            thought = f"I need to find information to answer: {query}"
            action = tool_names[0] if tool_names else None
            action_input = {"query": query}
            return {"thought": thought, "action": action, "action_input": action_input, "final_answer": None}

        last_obs = history[-1].observation or ""
        if len(history) >= 3 and "error" not in (history[-1].error or "").lower():
            answer = f"Based on my research: {last_obs[:200]}"
            return {"thought": "I have gathered enough information.", "action": None, "action_input": None, "final_answer": answer}

        next_tool_idx = len(history) % len(tool_names)
        action = tool_names[next_tool_idx]
        thought = f"Let me use {action} to get more information about the query."
        return {"thought": thought, "action": action, "action_input": {"query": query}, "final_answer": None}

    def _create_plan(self, query: str) -> AgentPlan:
        return AgentPlan(
            goal=query,
            steps=[
                "Understand the query and identify what information is needed",
                "Search for relevant information",
                "Execute any necessary computations or lookups",
                "Synthesize findings into a final answer",
            ],
        )

    async def run(self, query: str, session_id: Optional[str] = None) -> AgentResult:
        start_time = time.time()
        session_id = session_id or str(uuid.uuid4())

        self.memory.add("system", self._build_system_prompt())
        self.memory.add("user", query)

        plan = self._create_plan(query)
        steps: List[AgentStep] = []
        retries = 0

        for i in range(self.max_iterations):
            step = AgentStep(step_number=i + 1)
            parsed = self._make_thought_action(query, steps)
            step.thought = parsed.get("thought")

            if parsed.get("final_answer"):
                step.thought = step.thought or "Providing final answer."
                steps.append(step)
                self.memory.add("assistant", parsed["final_answer"])
                break

            step.action = parsed.get("action")
            step.action_input = parsed.get("action_input", {})

            if not step.action:
                step.thought = "No suitable action found. Providing best-effort answer."
                steps.append(step)
                break

            self.memory.add("assistant", f"Thought: {step.thought}\nAction: {step.action}\nAction Input: {json.dumps(step.action_input)}")

            tool_result = await self.registry.execute(step.action, **(step.action_input or {}))

            if tool_result.get("success"):
                step.observation = str(tool_result.get("output", ""))
                retries = 0
            else:
                step.error = tool_result.get("error", "Unknown error")
                retries += 1
                if retries > self.MAX_RETRIES:
                    step.observation = f"Error after {retries} retries: {step.error}"
                    retries = 0

            self.memory.add("observation", step.observation or step.error or "")
            steps.append(step)

            if i >= self.max_iterations - 1:
                final_step = AgentStep(step_number=i + 2, thought="Max iterations reached. Providing best answer from gathered information.")
                steps.append(final_step)

        answer = ""
        for s in reversed(steps):
            if s.observation:
                answer = s.observation
                break
        if not answer:
            answer = "I was unable to find a definitive answer. Please try rephrasing your query."

        return AgentResult(
            query=query,
            answer=answer,
            steps=steps,
            plan=plan,
            total_steps=len(steps),
            execution_time=time.time() - start_time,
            memory_usage=self.memory.token_usage,
            session_id=session_id,
        )
