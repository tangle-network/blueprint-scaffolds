"""Tool registry for the DSPy ReAct agent."""

from __future__ import annotations

import json
import re
import subprocess
import tempfile
import traceback
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional


@dataclass
class Tool:
    name: str
    description: str
    parameters: Dict[str, Any]
    handler: Callable[..., Any]


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: Dict[str, Tool] = {}

    def register(self, name: str, description: str, parameters: Dict[str, Any]) -> Callable:
        def decorator(fn: Callable) -> Callable:
            self._tools[name] = Tool(
                name=name,
                description=description,
                parameters=parameters,
                handler=fn,
            )
            return fn
        return decorator

    def get(self, name: str) -> Optional[Tool]:
        return self._tools.get(name)

    def list_tools(self) -> List[Dict[str, Any]]:
        return [
            {
                "name": t.name,
                "description": t.description,
                "parameters": t.parameters,
            }
            for t in self._tools.values()
        ]

    async def execute(self, name: str, **kwargs: Any) -> Dict[str, Any]:
        tool = self.get(name)
        if tool is None:
            return {"error": f"Unknown tool: {name}", "success": False}
        try:
            result = tool.handler(**kwargs)
            if asyncio.iscoroutine(result):
                result = await result
            return {"output": result, "success": True}
        except Exception as exc:
            return {
                "error": f"{type(exc).__name__}: {exc}",
                "traceback": traceback.format_exc(),
                "success": False,
            }


import asyncio

registry = ToolRegistry()


@registry.register(
    name="web_search",
    description="Search the web for information. Returns top results with titles and snippets.",
    parameters={
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "The search query"},
            "max_results": {
                "type": "integer",
                "description": "Maximum number of results to return",
                "default": 5,
            },
        },
        "required": ["query"],
    },
)
def web_search(query: str, max_results: int = 5) -> str:
    results = [
        {
            "title": f"Search result for '{query}' - Article {i+1}",
            "url": f"https://example.com/result/{i+1}",
            "snippet": f"This is a simulated search result snippet for query '{query}'. Result {i+1} contains relevant information about the topic.",
        }
        for i in range(max_results)
    ]
    return json.dumps(results, indent=2)


@registry.register(
    name="code_execute",
    description="Execute Python code in a sandboxed environment. Returns stdout, stderr, and any errors.",
    parameters={
        "type": "object",
        "properties": {
            "code": {"type": "string", "description": "Python code to execute"},
            "timeout": {
                "type": "integer",
                "description": "Execution timeout in seconds",
                "default": 30,
            },
        },
        "required": ["code"],
    },
)
def code_execute(code: str, timeout: int = 30) -> str:
    try:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write(code)
            f.flush()
            result = subprocess.run(
                ["python3", f.name],
                capture_output=True,
                text=True,
                timeout=timeout,
            )
        output = {"stdout": result.stdout, "stderr": result.stderr, "returncode": result.returncode}
        return json.dumps(output, indent=2)
    except subprocess.TimeoutExpired:
        return json.dumps({"error": f"Execution timed out after {timeout}s", "returncode": -1})
    except Exception as exc:
        return json.dumps({"error": str(exc), "returncode": -1})


@registry.register(
    name="database_query",
    description="Execute a SQL-like query against the in-memory database. Supports SELECT, INSERT, UPDATE, DELETE.",
    parameters={
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "SQL query to execute"},
            "database": {
                "type": "string",
                "description": "Database name (default: 'main')",
                "default": "main",
            },
        },
        "required": ["query"],
    },
)
def database_query(query: str, database: str = "main") -> str:
    _SIMULATED_TABLES: Dict[str, List[Dict[str, Any]]] = {
        "users": [
            {"id": 1, "name": "Alice", "email": "alice@example.com", "role": "admin"},
            {"id": 2, "name": "Bob", "email": "bob@example.com", "role": "user"},
            {"id": 3, "name": "Charlie", "email": "charlie@example.com", "role": "user"},
        ],
        "products": [
            {"id": 1, "name": "Widget A", "price": 29.99, "stock": 150},
            {"id": 2, "name": "Gadget B", "price": 49.99, "stock": 75},
            {"id": 3, "name": "Tool C", "price": 19.99, "stock": 200},
        ],
        "orders": [
            {"id": 1, "user_id": 1, "product_id": 2, "quantity": 3, "total": 149.97},
            {"id": 2, "user_id": 2, "product_id": 1, "quantity": 1, "total": 29.99},
            {"id": 3, "user_id": 1, "product_id": 3, "quantity": 5, "total": 99.95},
        ],
    }
    query_lower = query.strip().lower()
    if query_lower.startswith("select"):
        match = re.search(r"from\s+(\w+)", query_lower)
        if match:
            table = match.group(1)
            if table in _SIMULATED_TABLES:
                rows = _SIMULATED_TABLES[table]
                if "where" not in query_lower:
                    return json.dumps({"rows": rows, "count": len(rows)}, indent=2)
                return json.dumps(
                    {"rows": rows[:1], "count": len(rows[:1]), "note": "Filtered (simulated)"},
                    indent=2,
                )
            return json.dumps({"error": f"Table '{table}' not found", "tables": list(_SIMULATED_TABLES.keys())})
        return json.dumps({"rows": [], "tables": list(_SIMULATED_TABLES.keys())})
    if query_lower.startswith(("insert", "update", "delete")):
        return json.dumps({"status": "ok", "rows_affected": 1, "note": "Simulated write operation"})
    return json.dumps({"error": f"Unsupported query type: {query[:50]}"})


@registry.register(
    name="api_call",
    description="Make an HTTP API call. Supports GET, POST, PUT, DELETE methods.",
    parameters={
        "type": "object",
        "properties": {
            "url": {"type": "string", "description": "The URL to call"},
            "method": {
                "type": "string",
                "enum": ["GET", "POST", "PUT", "DELETE"],
                "default": "GET",
            },
            "headers": {"type": "object", "description": "Request headers"},
            "body": {"type": "object", "description": "Request body (for POST/PUT)"},
        },
        "required": ["url"],
    },
)
def api_call(url: str, method: str = "GET", headers: Optional[Dict] = None, body: Optional[Dict] = None) -> str:
    return json.dumps(
        {
            "status_code": 200,
            "url": url,
            "method": method,
            "response": {
                "message": f"Simulated {method} response for {url}",
                "data": {"key": "value"},
            },
            "headers": {"content-type": "application/json"},
        },
        indent=2,
    )
