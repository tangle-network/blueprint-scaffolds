export interface AgentStep {
  stepNumber: number;
  thought: string | null;
  action: string | null;
  actionInput: Record<string, unknown> | null;
  observation: string | null;
  error: string | null;
  timestamp: number;
}

export interface AgentPlan {
  goal: string;
  steps: string[];
  currentStep: number;
}

export interface AgentResult {
  answer: string;
  sessionId: string;
  steps: AgentStep[];
  totalSteps: number;
  executionTime: number;
  memoryUsage: number;
  plan: AgentPlan | null;
}

export interface ToolInfo {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  steps?: AgentStep[];
  result?: AgentResult;
  isStreaming?: boolean;
}

export type WSMessage =
  | { type: "query"; query: string; session_id?: string }
  | { type: "clear" };

export type WSEvent =
  | { type: "status"; status: string }
  | { type: "step"; stepNumber: number; thought: string | null; action: string | null; actionInput: Record<string, unknown> | null; observation: string | null; error: string | null; timestamp: number }
  | { type: "result"; answer: string; sessionId: string; totalSteps: number; executionTime: number; memoryUsage: number }
  | { type: "cleared" };
