import { useRef, useState, useCallback, useEffect } from "react";
import type { AgentResult, AgentStep, WSEvent, WSMessage } from "../types";

interface UseAgentReturn {
  result: AgentResult | null;
  steps: AgentStep[];
  isProcessing: boolean;
  error: string | null;
  sendQuery: (query: string, sessionId?: string) => void;
  clear: () => void;
  connected: boolean;
}

export function useAgent(wsUrl: string): UseAgentReturn {
  const wsRef = useRef<WebSocket | null>(null);
  const [steps, setSteps] = useState<AgentStep[]>([]);
  const [result, setResult] = useState<AgentResult | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [connected, setConnected] = useState(false);

  const connect = useCallback(() => {
    const ws = new WebSocket(wsUrl);
    ws.onopen = () => setConnected(true);
    ws.onclose = () => {
      setConnected(false);
      setTimeout(connect, 3000);
    };
    ws.onerror = () => setError("WebSocket connection error");
    ws.onmessage = (ev) => {
      const msg: WSEvent = JSON.parse(ev.data);
      switch (msg.type) {
        case "status":
          if (msg.status === "processing") {
            setIsProcessing(true);
            setSteps([]);
            setResult(null);
            setError(null);
          }
          break;
        case "step":
          setSteps((prev) => [
            ...prev,
            {
              stepNumber: msg.stepNumber,
              thought: msg.thought,
              action: msg.action,
              actionInput: msg.actionInput,
              observation: msg.observation,
              error: msg.error,
              timestamp: msg.timestamp,
            },
          ]);
          break;
        case "result":
          setResult({
            answer: msg.answer,
            sessionId: msg.sessionId,
            steps: [],
            totalSteps: msg.totalSteps,
            executionTime: msg.executionTime,
            memoryUsage: msg.memoryUsage,
            plan: null,
          });
          setIsProcessing(false);
          break;
        case "cleared":
          setSteps([]);
          setResult(null);
          break;
      }
    };
    wsRef.current = ws;
  }, [wsUrl]);

  useEffect(() => {
    connect();
    return () => {
      wsRef.current?.close();
    };
  }, [connect]);

  const send = useCallback((msg: WSMessage) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(msg));
    }
  }, []);

  const sendQuery = useCallback(
    (query: string, sessionId?: string) => {
      setIsProcessing(true);
      setSteps([]);
      setResult(null);
      setError(null);
      send({ type: "query", query, session_id: sessionId });
    },
    [send]
  );

  const clear = useCallback(() => {
    send({ type: "clear" });
  }, [send]);

  return { result, steps, isProcessing, error, sendQuery, clear, connected };
}
