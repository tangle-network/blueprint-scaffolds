let counter = 0;
export function uid(): string {
  return `${Date.now()}-${++counter}`;
}
