import { type FC, useState, useRef, useEffect, type FormEvent } from "react";
import type { ChatMessage } from "../types";
import { StepVisualization } from "./StepVisualization";
import { uid } from "../lib";

interface ChatProps {
  messages: ChatMessage[];
  onSend: (query: string) => void;
  disabled: boolean;
}

export const Chat: FC<ChatProps> = ({ messages, onSend, disabled }) => {
  const [input, setInput] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const q = input.trim();
    if (!q || disabled) return;
    onSend(q);
    setInput("");
  };

  return (
    <div className="chat-container">
      <div className="messages">
        {messages.length === 0 && (
          <div className="empty-state">
            <h2>DSPy ReAct Agent</h2>
            <p>Ask a question to start the thought-action-observation loop.</p>
          </div>
        )}
        {messages.map((msg) => (
          <div key={msg.id} className={`message message-${msg.role}`}>
            <div className="message-avatar">
              {msg.role === "user" ? "U" : "A"}
            </div>
            <div className="message-body">
              {msg.role === "user" ? (
                <p className="message-text">{msg.content}</p>
              ) : (
                <>
                  {msg.isStreaming && msg.steps && msg.steps.length > 0 && (
                    <div className="steps-container">
                      {msg.steps.map((step) => (
                        <StepVisualization key={step.stepNumber} step={step} />
                      ))}
                      <div className="streaming-indicator">
                        <span className="dot" />
                        <span className="dot" />
                        <span className="dot" />
                      </div>
                    </div>
                  )}
                  {msg.result && (
                    <div className="final-answer">
                      <div className="answer-header">Final Answer</div>
                      <p className="answer-text">{msg.result.answer}</p>
                      <div className="answer-meta">
                        <span>{msg.result.totalSteps} steps</span>
                        <span>{msg.result.executionTime.toFixed(2)}s</span>
                        <span>{msg.result.memoryUsage} tokens</span>
                      </div>
                    </div>
                  )}
                  {msg.steps && !msg.isStreaming && msg.steps.length > 0 && (
                    <details className="steps-details">
                      <summary>Show {msg.steps.length} steps</summary>
                      <div className="steps-container">
                        {msg.steps.map((step) => (
                          <StepVisualization
                            key={step.stepNumber}
                            step={step}
                          />
                        ))}
                      </div>
                    </details>
                  )}
                </>
              )}
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      <form className="input-form" onSubmit={handleSubmit}>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={
            disabled ? "Processing..." : "Ask the agent something..."
          }
          disabled={disabled}
          className="chat-input"
        />
        <button type="submit" disabled={disabled || !input.trim()} className="send-btn">
          Send
        </button>
      </form>
    </div>
  );
};
