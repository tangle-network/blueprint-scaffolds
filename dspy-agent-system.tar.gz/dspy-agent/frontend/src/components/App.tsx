import { type FC, useState, useCallback, useRef } from "react";
import type { AgentResult, AgentStep, ChatMessage } from "../types";
import { uid } from "../lib";
import { Chat } from "./Chat";
import { useAgent } from "../hooks/useAgent";

const WS_URL = `ws://${window.location.hostname}:8000/ws/agent`;

export const App: FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [sessionId, setSessionId] = useState<string | undefined>();
  const pendingIdRef = useRef<string | null>(null);

  const { steps, result, isProcessing, sendQuery, clear, connected } =
    useAgent(WS_URL);

  const handleSend = useCallback(
    (query: string) => {
      const userMsg: ChatMessage = {
        id: uid(),
        role: "user",
        content: query,
      };
      const assistantId = uid();
      pendingIdRef.current = assistantId;
      const assistantMsg: ChatMessage = {
        id: assistantId,
        role: "assistant",
        content: "",
        steps: [],
        isStreaming: true,
      };
      setMessages((prev) => [...prev, userMsg, assistantMsg]);
      sendQuery(query, sessionId);
    },
    [sendQuery, sessionId]
  );

  const streamingMsg: ChatMessage | undefined = messages.find(
    (m) => m.isStreaming && m.id === pendingIdRef.current
  );

  const mergedMessages = messages.map((msg) => {
    if (msg.isStreaming && msg.id === pendingIdRef.current) {
      return {
        ...msg,
        steps: steps.length > 0 ? steps : msg.steps,
        result: result ?? msg.result,
        isStreaming: isProcessing,
      } as ChatMessage;
    }
    return msg;
  });

  return (
    <div className="app">
      <header className="app-header">
        <h1>DSPy ReAct Agent</h1>
        <div className="header-controls">
          <span className={`status-dot ${connected ? "connected" : "disconnected"}`} />
          <button onClick={clear} className="clear-btn" disabled={isProcessing}>
            Clear
          </button>
        </div>
      </header>
      <Chat
        messages={mergedMessages}
        onSend={handleSend}
        disabled={isProcessing}
      />
    </div>
  );
};
