import type { FC } from "react";
import type { AgentStep } from "../types";

const TOOL_COLORS: Record<string, string> = {
  web_search: "#3b82f6",
  code_execute: "#f59e0b",
  database_query: "#10b981",
  api_call: "#8b5cf6",
};

function getToolColor(action: string | null): string {
  if (!action) return "#6b7280";
  for (const [key, color] of Object.entries(TOOL_COLORS)) {
    if (action.includes(key)) return color;
  }
  return "#6b7280";
}

export const StepVisualization: FC<{ step: AgentStep }> = ({ step }) => {
  const color = getToolColor(step.action);

  return (
    <div className="step-card">
      <div className="step-header">
        <span className="step-badge" style={{ backgroundColor: color }}>
          Step {step.stepNumber}
        </span>
        {step.action && (
          <span className="tool-badge" style={{ borderColor: color, color }}>
            {step.action}
          </span>
        )}
      </div>

      {step.thought && (
        <div className="step-section">
          <div className="section-label thought-label">Thought</div>
          <p className="step-thought">{step.thought}</p>
        </div>
      )}

      {step.action && step.actionInput && (
        <div className="step-section">
          <div className="section-label action-label">Action Input</div>
          <pre className="step-code">
            {JSON.stringify(step.actionInput, null, 2)}
          </pre>
        </div>
      )}

      {step.observation && (
        <div className="step-section">
          <div className="section-label observation-label">Observation</div>
          <pre className="step-observation">{step.observation}</pre>
        </div>
      )}

      {step.error && (
        <div className="step-section">
          <div className="section-label error-label">Error</div>
          <pre className="step-error">{step.error}</pre>
        </div>
      )}
    </div>
  );
};
