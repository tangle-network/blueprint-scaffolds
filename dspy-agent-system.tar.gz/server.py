from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
import json
from agent.tools import ToolRegistry
from agent.react import ReActAgent

app = FastAPI(title="ReAct Agent API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

registry = ToolRegistry()
agent = ReActAgent(max_steps=8)


class AgentRequest(BaseModel):
    query: str
    memory: list[str] = []


class AgentResponse(BaseModel):
    answer: str
    steps: int
    duration_ms: int


@app.get("/api/health")
def health():
    return {"status": "ok", "version": "1.0.0"}


@app.get("/api/tools")
def list_tools():
    return {"tools": registry.list_tools()}


@app.post("/api/agent/run")
def run_agent(request: AgentRequest):
    def event_stream():
        for event in agent.run(request.query, request.memory):
            yield f"data: {json.dumps(event)}\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
