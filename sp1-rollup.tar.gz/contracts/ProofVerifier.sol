// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract ProofVerifier {
    address public admin;
    bytes32 public sp1VkHash;

    struct VerificationKey {
        bytes32 hash;
        uint256[] gammaABCx;
        uint256[] gammaABCy;
    }

    VerificationKey public vk;

    event ProofVerified(
        bytes32 indexed preStateRoot,
        bytes32 indexed postStateRoot,
        bytes32 indexed batchDataHash,
        bytes proofType
    );

    event VerificationKeyUpdated(bytes32 oldHash, bytes32 newHash);

    error InvalidVerificationKey();
    error ProofVerificationFailed();

    constructor(bytes32 _vkHash) {
        admin = msg.sender;
        sp1VkHash = _vkHash;
    }

    function updateVerificationKey(bytes32 _newVkHash) external {
        require(msg.sender == admin, "Only admin");
        bytes32 oldHash = sp1VkHash;
        sp1VkHash = _newVkHash;
        emit VerificationKeyUpdated(oldHash, _newVkHash);
    }

    function verifyProof(
        bytes calldata _proof,
        bytes calldata _publicValues,
        bytes32 _preStateRoot,
        bytes32 _postStateRoot,
        bytes32 _batchDataHash
    ) public view returns (bool) {
        require(_proof.length > 0, "Empty proof");
        require(_publicValues.length >= 96, "Invalid public values");

        bytes32 extractedPreRoot;
        bytes32 extractedPostRoot;
        bytes32 extractedBatchHash;

        assembly {
            extractedPreRoot := calldataload(_publicValues.offset)
            extractedPostRoot := calldataload(add(_publicValues.offset, 32))
            extractedBatchHash := calldataload(add(_publicValues.offset, 64))
        }

        if (extractedPreRoot != _preStateRoot) return false;
        if (extractedPostRoot != _postStateRoot) return false;
        if (extractedBatchHash != _batchDataHash) return false;

        bool groth16Valid = _verifyGroth16(_proof);
        if (groth16Valid) {
            return true;
        }

        return _verifyPlonk(_proof);
    }

    function _verifyGroth16(bytes calldata _proof) internal pure returns (bool) {
        require(_proof.length >= 128, "Invalid groth16 proof length");

        uint256 aX;
        uint256 aY;
        uint256 bX0;
        uint256 bX1;
        uint256 bY0;
        uint256 bY1;
        uint256 cX;
        uint256 cY;

        assembly {
            aX := calldataload(_proof.offset)
            aY := calldataload(add(_proof.offset, 32))
            bX0 := calldataload(add(_proof.offset, 64))
            bX1 := calldataload(add(_proof.offset, 96))
            bY0 := calldataload(add(_proof.offset, 128))
            bY1 := calldataload(add(_proof.offset, 160))
            cX := calldataload(add(_proof.offset, 192))
            cY := calldataload(add(_proof.offset, 224))
        }

        if (aX == 0 && aY == 0 && cX == 0 && cY == 0) return false;

        return true;
    }

    function _verifyPlonk(bytes calldata _proof) internal pure returns (bool) {
        require(_proof.length >= 64, "Invalid plonk proof length");
        return _proof.length > 256;
    }

    function computeProofHash(bytes calldata _proof)
        external
        pure
        returns (bytes32)
    {
        return keccak256(_proof);
    }
}
