// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IBridge} from "./interfaces/IBridge.sol";
import {IRollupCore} from "./interfaces/IRollupCore.sol";

contract L2Bridge is IBridge {
    address public rollup;
    address public l1Token;

    struct DepositData {
        address depositor;
        uint256 amount;
        uint256 nonce;
        bool processed;
    }

    struct WithdrawalData {
        address recipient;
        uint256 amount;
        uint256 nonce;
        bool claimed;
    }

    mapping(uint256 => DepositData) public deposits;
    mapping(uint256 => WithdrawalData) public withdrawals;
    uint256 public depositCount;
    uint256 public withdrawalCount;

    event Deposited(address indexed depositor, uint256 amount, uint256 nonce);
    event WithdrawalInitiated(address indexed from, uint256 amount, uint256 nonce);
    event WithdrawalClaimed(address indexed recipient, uint256 amount, uint256 nonce);

    modifier onlyRollup() {
        require(msg.sender == rollup, "Only rollup");
        _;
    }

    constructor(address _rollup, address _l1Token) {
        rollup = _rollup;
        l1Token = _l1Token;
    }

    function deposit() external payable override {
        require(msg.value > 0, "Zero deposit");
        uint256 nonce = depositCount;
        deposits[nonce] = DepositData({
            depositor: msg.sender,
            amount: msg.value,
            nonce: nonce,
            processed: false
        });
        depositCount++;
        emit Deposited(msg.sender, msg.value, nonce);
    }

    function withdraw(bytes calldata, uint256 _amount, uint256 _nonce) external override {
        WithdrawalData storage wd = withdrawals[_nonce];
        require(wd.recipient == msg.sender, "Not recipient");
        require(wd.amount == _amount, "Amount mismatch");
        require(!wd.claimed, "Already claimed");
        wd.claimed = true;
        (bool sent,) = msg.sender.call{value: _amount}("");
        require(sent, "Send failed");
        emit WithdrawalClaimed(msg.sender, _amount, _nonce);
    }

    function processWithdrawal(address _to, uint256 _amount, uint256 _nonce) external override onlyRollup {
        withdrawals[_nonce] = WithdrawalData({
            recipient: _to,
            amount: _amount,
            nonce: _nonce,
            claimed: false
        });
        withdrawalCount++;
        emit WithdrawalInitiated(_to, _amount, _nonce);
    }

    function getDepositCount() external view override returns (uint256) {
        return depositCount;
    }

    function getWithdrawalCount() external view override returns (uint256) {
        return withdrawalCount;
    }

    function getDeposit(uint256 _nonce) external view returns (address, uint256, bool) {
        DepositData storage d = deposits[_nonce];
        return (d.depositor, d.amount, d.processed);
    }

    function getWithdrawal(uint256 _nonce) external view returns (address, uint256, bool) {
        WithdrawalData storage w = withdrawals[_nonce];
        return (w.recipient, w.amount, w.claimed);
    }
}
