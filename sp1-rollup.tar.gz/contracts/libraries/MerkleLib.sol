// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

library MerkleLib {
    function verify(bytes32 _root, bytes32 _leaf, bytes32[] calldata _proof) internal pure returns (bool) {
        bytes32 computedHash = _leaf;
        for (uint256 i = 0; i < _proof.length; i++) {
            bytes32 proofElement = _proof[i];
            if (computedHash < proofElement) {
                computedHash = keccak256(abi.encodePacked(computedHash, proofElement));
            } else {
                computedHash = keccak256(abi.encodePacked(proofElement, computedHash));
            }
        }
        return computedHash == _root;
    }

    function computeRoot(bytes32[] calldata _leaves) internal pure returns (bytes32) {
        require(_leaves.length > 0, "Empty leaves");
        if (_leaves.length == 1) return _leaves[0];

        bytes32[] memory nodes = new bytes32[](_leaves.length);
        for (uint256 i = 0; i < _leaves.length; i++) {
            nodes[i] = _leaves[i];
        }

        uint256 len = _leaves.length;
        while (len > 1) {
            uint256 newLen = (len + 1) / 2;
            for (uint256 i = 0; i < newLen; i++) {
                bytes32 left = nodes[i * 2];
                bytes32 right = (i * 2 + 1 < len) ? nodes[i * 2 + 1] : bytes32(0);
                nodes[i] = keccak256(abi.encodePacked(left, right));
            }
            len = newLen;
        }
        return nodes[0];
    }
}
