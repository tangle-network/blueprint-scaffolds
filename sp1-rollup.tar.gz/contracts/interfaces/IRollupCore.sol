// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IRollupCore {
    function submitBatch(bytes32 _newStateRoot, bytes32 _dataHash, bytes calldata _compressedTxs, uint256 _txCount, uint256[] calldata _depositIndices) external;
    function verifyBatch(uint256 _batchIndex, bytes calldata _proof, bytes32[] calldata _publicInputs) external;
    function verifyAggregated(uint256 _startBatch, uint256 _endBatch, bytes calldata _aggregatedProof, bytes32[] calldata _publicInputs) external;
    function getBatch(uint256 _index) external view returns (bytes32 stateRoot, bytes32 dataHash, uint256 timestamp, uint256 txCount);
    function getLatestStateRoot() external view returns (bytes32);
    function stateRoot() external view returns (bytes32);
    function currentBatchIndex() external view returns (uint256);
    function lastVerifiedBatch() external view returns (uint256);
}
