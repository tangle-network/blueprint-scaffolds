// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IBridge {
    function deposit() external payable;
    function withdraw(bytes calldata _withdrawalProof, uint256 _amount, uint256 _nonce) external;
    function processWithdrawal(address _to, uint256 _amount, uint256 _nonce) external;
    function getDepositCount() external view returns (uint256);
    function getWithdrawalCount() external view returns (uint256);
}
