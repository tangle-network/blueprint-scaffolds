// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IProofVerifier {
    function verifyProof(bytes calldata proof, bytes32[] calldata publicInputs) external view returns (bool);
    function verifyAggregatedProof(bytes calldata proof, bytes32[] calldata publicInputs) external view returns (bool);
}
