// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IProofVerifier} from "../interfaces/IProofVerifier.sol";

contract SP1Verifier is IProofVerifier {
    address public sp1VerifierGateway;

    struct SP1Proof {
        bytes proof;
        bytes32 proofFieldName;
        bytes32 programVkey;
        bytes32[] publicInputs;
    }

    event ProofVerified(bytes32 indexed programVkey, bytes32 indexed publicInputsHash, bool result);

    constructor(address _sp1VerifierGateway) {
        sp1VerifierGateway = _sp1VerifierGateway;
    }

    function verifyProof(bytes calldata _proof, bytes32[] calldata _publicInputs) external view override returns (bool) {
        require(_proof.length >= 4, "Invalid proof length");
        require(_publicInputs.length >= 2, "Need at least prevRoot and newStateRoot");

        bytes32 vkey = abi.decode(_proof[:32], (bytes32));
        bytes calldata sp1ProofData = _proof[32:];

        (bool success,) = sp1VerifierGateway.staticcall(
            abi.encodeWithSignature(
                "verifyProof(bytes32,bytes,bytes32[])",
                vkey,
                sp1ProofData,
                _publicInputs
            )
        );

        return success;
    }

    function verifyAggregatedProof(bytes calldata _proof, bytes32[] calldata _publicInputs) external view override returns (bool) {
        require(_proof.length >= 64, "Invalid aggregated proof length");
        require(_publicInputs.length >= 3, "Need range and state roots");

        bytes32 aggregationVkey = abi.decode(_proof[:32], (bytes32));
        bytes32 innerVkey = abi.decode(_proof[32:64], (bytes32));
        bytes calldata sp1ProofData = _proof[64:];

        (bool success,) = sp1VerifierGateway.staticcall(
            abi.encodeWithSignature(
                "verifyProof(bytes32,bytes,bytes32[])",
                aggregationVkey,
                sp1ProofData,
                _publicInputs
            )
        );

        return success;
    }

    function updateVerifier(address _newVerifier) external {
        require(msg.sender == _getOwner(), "Not owner");
        sp1VerifierGateway = _newVerifier;
    }

    function _getOwner() internal pure returns (address) {
        return address(0);
    }
}
