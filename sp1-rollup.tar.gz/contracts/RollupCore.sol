// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IRollupCore} from "./interfaces/IRollupCore.sol";
import {IProofVerifier} from "./interfaces/IProofVerifier.sol";
import {IBridge} from "./interfaces/IBridge.sol";
import {MerkleLib} from "./libraries/MerkleLib.sol";

contract RollupCore is IRollupCore {
    address public operator;
    IProofVerifier public verifier;
    IBridge public bridge;

    bytes32 public stateRoot;
    bytes32 public pendingStateRoot;
    uint256 public currentBatchIndex;
    uint256 public lastVerifiedBatch;
    uint256 public batchSubmissionInterval;
    uint256 public maxTxPerBatch;

    struct Batch {
        bytes32 stateRoot;
        bytes32 dataHash;
        uint256 timestamp;
        bytes calldataProof;
        uint256 txCount;
    }

    mapping(uint256 => Batch) public batches;

    struct Deposit {
        address depositor;
        uint256 amount;
        uint256 nonce;
        bool processed;
    }

    mapping(uint256 => Deposit) public pendingDeposits;
    uint256 public depositCount;

    uint256 public challengePeriod;
    uint256 public minBondAmount;

    event BatchSubmitted(uint256 indexed batchIndex, bytes32 stateRoot, bytes32 dataHash, uint256 txCount);
    event BatchVerified(uint256 indexed batchIndex, bytes32 stateRoot);
    event StateRootUpdated(bytes32 oldRoot, bytes32 newRoot);
    event DepositsProcessed(uint256 indexed batchIndex, uint256 count);

    modifier onlyOperator() {
        require(msg.sender == operator, "Only operator");
        _;
    }

    constructor(
        address _verifier,
        address _bridge,
        bytes32 _genesisStateRoot,
        uint256 _batchInterval,
        uint256 _maxTxPerBatch
    ) {
        operator = msg.sender;
        verifier = IProofVerifier(_verifier);
        bridge = IBridge(_bridge);
        stateRoot = _genesisStateRoot;
        batchSubmissionInterval = _batchInterval;
        maxTxPerBatch = _maxTxPerBatch;
        challengePeriod = 7 days;
        minBondAmount = 1 ether;
    }

    function submitBatch(
        bytes32 _newStateRoot,
        bytes32 _dataHash,
        bytes calldata _compressedTxs,
        uint256 _txCount,
        uint256[] calldata _depositIndices
    ) external onlyOperator {
        require(_txCount <= maxTxPerBatch, "Too many txs");
        require(_depositIndices.length == 0 || _depositIndices.length <= maxTxPerBatch, "Too many deposits");

        bytes32 computedDataHash = keccak256(_compressedTxs);
        require(computedDataHash == _dataHash, "Data hash mismatch");

        uint256 batchIndex = currentBatchIndex;
        batches[batchIndex] = Batch({
            stateRoot: _newStateRoot,
            dataHash: _dataHash,
            timestamp: block.timestamp,
            calldataProof: _compressedTxs,
            txCount: _txCount
        });

        for (uint256 i = 0; i < _depositIndices.length; i++) {
            uint256 depIdx = _depositIndices[i];
            require(pendingDeposits[depIdx].processed == false, "Already processed");
            require(pendingDeposits[depIdx].depositor != address(0), "Invalid deposit");
            pendingDeposits[depIdx].processed = true;
        }

        emit BatchSubmitted(batchIndex, _newStateRoot, _dataHash, _txCount);
        emit DepositsProcessed(batchIndex, _depositIndices.length);

        pendingStateRoot = _newStateRoot;
        currentBatchIndex++;
    }

    function verifyBatch(
        uint256 _batchIndex,
        bytes calldata _proof,
        bytes32[] calldata _publicInputs
    ) external {
        require(_batchIndex <= currentBatchIndex, "Invalid batch");
        require(_batchIndex == lastVerifiedBatch + 1, "Batch out of order");

        Batch storage batch = batches[_batchIndex];
        require(batch.stateRoot != bytes32(0), "Batch not found");

        bytes32 prevStateRoot = _batchIndex == 0 ? stateRoot : batches[_batchIndex - 1].stateRoot;
        bytes32 expectedPublicInput = keccak256(
            abi.encodePacked(prevStateRoot, batch.stateRoot, batch.dataHash)
        );

        bool isValid = verifier.verifyProof(_proof, _publicInputs);
        require(isValid, "Invalid proof");

        bytes32 oldRoot = stateRoot;
        stateRoot = batch.stateRoot;
        lastVerifiedBatch = _batchIndex;

        emit StateRootUpdated(oldRoot, stateRoot);
        emit BatchVerified(_batchIndex, stateRoot);
    }

    function verifyAggregated(
        uint256 _startBatch,
        uint256 _endBatch,
        bytes calldata _aggregatedProof,
        bytes32[] calldata _publicInputs
    ) external {
        require(_endBatch <= currentBatchIndex, "Invalid batch range");
        require(_startBatch == lastVerifiedBatch + 1, "Start batch out of order");

        bool isValid = verifier.verifyProof(_aggregatedProof, _publicInputs);
        require(isValid, "Invalid aggregated proof");

        for (uint256 i = _startBatch; i <= _endBatch; i++) {
            emit BatchVerified(i, batches[i].stateRoot);
        }

        bytes32 oldRoot = stateRoot;
        stateRoot = batches[_endBatch].stateRoot;
        lastVerifiedBatch = _endBatch;

        emit StateRootUpdated(oldRoot, stateRoot);
    }

    function getBatch(uint256 _index) external view returns (Batch memory) {
        return batches[_index];
    }

    function getLatestStateRoot() external view returns (bytes32) {
        return stateRoot;
    }

    function isIncludedInBatch(uint256 _batchIndex, bytes32 _leaf, bytes32[] calldata _proof) external view returns (bool) {
        return MerkleLib.verify(batches[_batchIndex].dataHash, _leaf, _proof);
    }

    function updateOperator(address _newOperator) external onlyOperator {
        require(_newOperator != address(0), "Zero address");
        operator = _newOperator;
    }
}
