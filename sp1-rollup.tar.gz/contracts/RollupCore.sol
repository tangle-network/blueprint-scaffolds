// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {ProofVerifier} from "./ProofVerifier.sol";
import {Bridge} from "./Bridge.sol";

contract RollupCore {
    ProofVerifier public verifier;
    Bridge public bridge;

    bytes32 public latestStateRoot;
    bytes32 public latestBatchDataHash;
    uint256 public latestBlockNumber;
    uint256 public blockInterval;
    uint256 public maxBatchSize;
    uint256 public proofWindow;
    uint256 public challengePeriod;

    struct BatchCommit {
        bytes32 stateRoot;
        bytes32 batchDataHash;
        uint256 blockNumber;
        uint256 timestamp;
        bool proven;
        uint256 proofDeadline;
    }

    mapping(uint256 => BatchCommit) public batches;
    mapping(bytes32 => bool) public stateRootHistory;

    event BatchCommitted(
        uint256 indexed blockNumber,
        bytes32 indexed stateRoot,
        bytes32 batchDataHash,
        uint256 timestamp
    );

    event BatchProven(
        uint256 indexed blockNumber,
        bytes32 indexed stateRoot,
        bytes proofType
    );

    event StateRootUpdated(
        bytes32 indexed oldRoot,
        bytes32 indexed newRoot,
        uint256 blockNumber
    );

    error InvalidProof();
    error BatchNotFound();
    error BatchAlreadyProven();
    error ProofWindowExpired();
    error InvalidStateRoot();

    constructor(
        address _verifier,
        address _bridge,
        bytes32 _genesisStateRoot,
        uint256 _blockInterval,
        uint256 _maxBatchSize,
        uint256 _proofWindow,
        uint256 _challengePeriod
    ) {
        verifier = ProofVerifier(_verifier);
        bridge = Bridge(_bridge);
        latestStateRoot = _genesisStateRoot;
        latestBlockNumber = 0;
        blockInterval = _blockInterval;
        maxBatchSize = _maxBatchSize;
        proofWindow = _proofWindow;
        challengePeriod = _challengePeriod;
        stateRootHistory[_genesisStateRoot] = true;

        batches[0] = BatchCommit({
            stateRoot: _genesisStateRoot,
            batchDataHash: bytes32(0),
            blockNumber: 0,
            timestamp: block.timestamp,
            proven: true,
            proofDeadline: 0
        });
    }

    function commitBatch(
        bytes32 _stateRoot,
        bytes32 _batchDataHash,
        uint256 _blockNumber
    ) external {
        require(_blockNumber == latestBlockNumber + 1, "Invalid block number");
        require(_stateRoot != bytes32(0), "Invalid state root");
        require(!stateRootHistory[_stateRoot], "State root already used");

        batches[_blockNumber] = BatchCommit({
            stateRoot: _stateRoot,
            batchDataHash: _batchDataHash,
            blockNumber: _blockNumber,
            timestamp: block.timestamp,
            proven: false,
            proofDeadline: block.timestamp + proofWindow
        });

        bytes32 oldRoot = latestStateRoot;
        latestStateRoot = _stateRoot;
        latestBatchDataHash = _batchDataHash;
        latestBlockNumber = _blockNumber;
        stateRootHistory[_stateRoot] = true;

        emit BatchCommitted(_blockNumber, _stateRoot, _batchDataHash, block.timestamp);
        emit StateRootUpdated(oldRoot, _stateRoot, _blockNumber);
    }

    function verifyBatchProof(
        uint256 _blockNumber,
        bytes calldata _proof,
        bytes calldata _publicValues
    ) external {
        BatchCommit storage batch = batches[_blockNumber];
        if (batch.blockNumber != _blockNumber) revert BatchNotFound();
        if (batch.proven) revert BatchAlreadyProven();

        bytes32 preStateRoot = batches[_blockNumber - 1].stateRoot;

        bool valid = verifier.verifyProof(
            _proof,
            _publicValues,
            preStateRoot,
            batch.stateRoot,
            batch.batchDataHash
        );

        if (!valid) revert InvalidProof();

        batch.proven = true;

        emit BatchProven(_blockNumber, batch.stateRoot, "groth16");
    }

    function getBatch(uint256 _blockNumber)
        external
        view
        returns (BatchCommit memory)
    {
        return batches[_blockNumber];
    }

    function isBatchProven(uint256 _blockNumber) external view returns (bool) {
        return batches[_blockNumber].proven;
    }

    function getStateRoot(uint256 _blockNumber) external view returns (bytes32) {
        return batches[_blockNumber].stateRoot;
    }
}
