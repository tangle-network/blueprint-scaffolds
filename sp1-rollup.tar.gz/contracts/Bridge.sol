// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IRollupCore {
    function latestStateRoot() external view returns (bytes32);
    function latestBlockNumber() external view returns (uint256);
    function commitBatch(
        bytes32 _stateRoot,
        bytes32 _batchDataHash,
        uint256 _blockNumber
    ) external;
}

contract Bridge {
    address public admin;
    address public rollup;
    uint256 public depositCount;
    uint256 public withdrawalCount;

    struct Deposit {
        address depositor;
        address recipient;
        uint256 amount;
        address token;
        uint256 l2BlockNumber;
        bool claimed;
        bytes32 l1TxHash;
    }

    struct Withdrawal {
        address withdrawer;
        address recipient;
        uint256 amount;
        address token;
        uint256 l2BlockNumber;
        bool finalized;
        bytes32 l2TxHash;
        uint256 claimableAfter;
    }

    mapping(uint256 => Deposit) public deposits;
    mapping(uint256 => Withdrawal) public withdrawals;
    mapping(address => uint256) public pendingWithdrawals;

    mapping(address => bool) public supportedTokens;
    mapping(bytes32 => bool) public processedL1Txs;
    mapping(bytes32 => bool) public processedL2Txs;

    event DepositInitiated(
        uint256 indexed depositId,
        address indexed depositor,
        address indexed recipient,
        uint256 amount,
        address token
    );

    event DepositClaimed(
        uint256 indexed depositId,
        address indexed recipient,
        uint256 l2BlockNumber
    );

    event WithdrawalInitiated(
        uint256 indexed withdrawalId,
        address indexed withdrawer,
        address indexed recipient,
        uint256 amount,
        address token
    );

    event WithdrawalFinalized(
        uint256 indexed withdrawalId,
        address indexed recipient,
        uint256 amount
    );

    error TokenNotSupported();
    error InsufficientBalance();
    error AlreadyProcessed();
    error NotClaimable();
    error ChallengePeriodNotOver();

    constructor(address _rollup) {
        admin = msg.sender;
        rollup = _rollup;
        supportedTokens[address(0)] = true;
    }

    function addSupportedToken(address _token) external {
        require(msg.sender == admin, "Only admin");
        supportedTokens[_token] = true;
    }

    function depositETH(address _recipient) external payable {
        require(msg.value > 0, "Must send ETH");
        require(supportedTokens[address(0)], "ETH not supported");

        uint256 depositId = depositCount++;
        deposits[depositId] = Deposit({
            depositor: msg.sender,
            recipient: _recipient,
            amount: msg.value,
            token: address(0),
            l2BlockNumber: 0,
            claimed: false,
            l1TxHash: bytes32(0)
        });

        emit DepositInitiated(depositId, msg.sender, _recipient, msg.value, address(0));
    }

    function depositERC20(
        address _token,
        uint256 _amount,
        address _recipient
    ) external {
        require(_amount > 0, "Must deposit positive amount");
        require(supportedTokens[_token], "Token not supported");

        uint256 depositId = depositCount++;
        deposits[depositId] = Deposit({
            depositor: msg.sender,
            recipient: _recipient,
            amount: _amount,
            token: _token,
            l2BlockNumber: 0,
            claimed: false,
            l1TxHash: bytes32(0)
        });

        emit DepositInitiated(depositId, msg.sender, _recipient, _amount, _token);
    }

    function claimDeposit(uint256 _depositId, uint256 _l2BlockNumber) external {
        Deposit storage dep = deposits[_depositId];
        require(!dep.claimed, "Already claimed");
        require(msg.sender == rollup, "Only rollup");

        dep.claimed = true;
        dep.l2BlockNumber = _l2BlockNumber;

        emit DepositClaimed(_depositId, dep.recipient, _l2BlockNumber);
    }

    function initiateWithdrawal(
        address _recipient,
        uint256 _amount,
        address _token,
        bytes32 _l2TxHash
    ) external {
        require(_amount > 0, "Must withdraw positive amount");
        require(supportedTokens[_token], "Token not supported");
        require(!processedL2Txs[_l2TxHash], "Already processed");

        processedL2Txs[_l2TxHash] = true;
        uint256 withdrawalId = withdrawalCount++;
        uint256 challengePeriod = 7 days;

        withdrawals[withdrawalId] = Withdrawal({
            withdrawer: msg.sender,
            recipient: _recipient,
            amount: _amount,
            token: _token,
            l2BlockNumber: IRollupCore(rollup).latestBlockNumber(),
            finalized: false,
            l2TxHash: _l2TxHash,
            claimableAfter: block.timestamp + challengePeriod
        });

        pendingWithdrawals[_token] += _amount;

        emit WithdrawalInitiated(withdrawalId, msg.sender, _recipient, _amount, _token);
    }

    function finalizeWithdrawal(uint256 _withdrawalId) external {
        Withdrawal storage wd = withdrawals[_withdrawalId];
        require(!wd.finalized, "Already finalized");
        require(
            block.timestamp >= wd.claimableAfter,
            "Challenge period not over"
        );

        wd.finalized = true;
        pendingWithdrawals[wd.token] -= wd.amount;

        if (wd.token == address(0)) {
            (bool success, ) = wd.recipient.call{value: wd.amount}("");
            require(success, "Transfer failed");
        }

        emit WithdrawalFinalized(_withdrawalId, wd.recipient, wd.amount);
    }

    function getDeposit(uint256 _depositId) external view returns (Deposit memory) {
        return deposits[_depositId];
    }

    function getWithdrawal(uint256 _withdrawalId) external view returns (Withdrawal memory) {
        return withdrawals[_withdrawalId];
    }
}
