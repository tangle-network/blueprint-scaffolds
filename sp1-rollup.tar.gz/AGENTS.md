# ZK Rollup on SP1 - Build Plan

## Project Structure
```
/home/agent/
├── contracts/           # Solidity contracts
│   ├── RollupCore.sol   # Core rollup logic (commit blocks, verify proofs)
│   ├── Bridge.sol       # L1<->L2 bridge for deposits/withdrawals
│   └── ProofVerifier.sol# SP1 proof verification via groth16/plonk
├── sequencer/           # Rust sequencer implementation
│   └── src/
│       ├── main.rs      # Sequencer entry point
│       ├── lib.rs        # Sequencer library
│       ├── mempool.rs   # Transaction mempool
│       ├── state.rs     # Merkle Patricia trie state
│       ├── prover.rs    # SP1 proof pipeline
│       ├── da.rs        # Calldata/blob DA layer
│       └── batch.rs     # Transaction batching
├── src/
│   ├── lib/
│   │   ├── types.ts     # Shared types
│   │   ├── merkle.ts    # Merkle Patricia trie (JS impl)
│   │   └── utils.ts     # Utilities
│   ├── components/ui/   # shadcn/ui components
│   │   ├── button.tsx
│   │   ├── card.tsx
│   │   ├── input.tsx
│   │   ├── tabs.tsx
│   │   ├── badge.tsx
│   │   ├── progress.tsx
│   │   ├── separator.tsx
│   │   ├── table.tsx
│   │   ├── dialog.tsx
│   │   ├── select.tsx
│   │   ├── label.tsx
│   │   ├── tooltip.tsx
│   │   └── scroll-area.tsx
│   ├── components/
│   │   ├── Navbar.tsx
│   │   ├── BlockExplorer.tsx
│   │   ├── BridgeUI.tsx
│   │   ├── ProofStatus.tsx
│   │   ├── StateRootDisplay.tsx
│   │   └── TransactionTable.tsx
│   └── app/
│       ├── layout.tsx
│       ├── page.tsx         # Home / dashboard
│       ├── globals.css
│       ├── explorer/
│       │   └── page.tsx     # Block explorer
│       ├── bridge/
│       │   └── page.tsx     # Bridge UI
│       └── api/
│           ├── blocks/
│           │   └── route.ts
│           ├── transactions/
│           │   └── route.ts
│           ├── proof/
│           │   └── route.ts
│           └── bridge/
│               └── route.ts
├── package.json
├── tsconfig.json
├── tailwind.config.ts
├── postcss.config.js
└── next.config.js
```

## Pages
- `/` - Dashboard with latest blocks, state root, proof status
- `/explorer` - Full block explorer with block/tx details
- `/bridge` - Deposit/withdrawal bridge UI

## API Routes
- `GET /api/blocks` - List blocks, with optional `?limit=N`
- `GET /api/transactions?block=N` - Transactions for a block
- `GET /api/proof?block=N` - Proof status for a block
- `POST /api/bridge` - Initiate bridge deposit/withdrawal

## Components
- Navbar: navigation between pages
- BlockExplorer: block list with search
- BridgeUI: deposit/withdrawal form
- ProofStatus: SP1 proof generation progress
- StateRootDisplay: current state root with history
- TransactionTable: sortable tx table
