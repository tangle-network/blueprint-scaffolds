/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        zk: {
          bg: "#0a0b0f",
          card: "#12141c",
          border: "#1e2230",
          accent: "#6366f1",
          "accent-light": "#818cf8",
          success: "#22c55e",
          warning: "#f59e0b",
          danger: "#ef4444",
          muted: "#6b7280",
        },
      },
    },
  },
  plugins: [],
};
