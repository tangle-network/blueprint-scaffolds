import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ZK Rollup Explorer — SP1",
  description: "Block explorer and bridge UI for SP1-powered ZK rollup",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-zk-bg antialiased">
        <nav className="border-b border-zk-border bg-zk-card/80 backdrop-blur-sm sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center space-x-8">
                <a href="/" className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-zk-accent rounded-lg flex items-center justify-center">
                    <span className="text-white font-bold text-sm">ZK</span>
                  </div>
                  <span className="text-white font-semibold text-lg">
                    ZK Rollup
                  </span>
                </a>
                <div className="hidden md:flex items-center space-x-1">
                  <a
                    href="/"
                    className="text-zk-muted hover:text-white px-3 py-2 rounded-md text-sm transition-colors"
                  >
                    Explorer
                  </a>
                  <a
                    href="/bridge"
                    className="text-zk-muted hover:text-white px-3 py-2 rounded-md text-sm transition-colors"
                  >
                    Bridge
                  </a>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="hidden sm:flex items-center space-x-2 text-xs text-zk-muted">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  <span>Sequencer Online</span>
                </div>
              </div>
            </div>
          </div>
        </nav>
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {children}
        </main>
      </body>
    </html>
  );
}
