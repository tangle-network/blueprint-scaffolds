import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ZK Rollup SP1",
  description: "ZK Rollup with SP1 proof system",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
