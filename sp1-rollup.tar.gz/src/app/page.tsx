import Link from "next/link";

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-8">
      <h1 className="text-4xl font-bold text-rollup-accent mb-4">
        ZK Rollup SP1
      </h1>
      <p className="text-rollup-muted mb-8 text-center max-w-md">
        A zero-knowledge rollup powered by the SP1 proof system. Bridge assets,
        explore transactions, and verify proofs on-chain.
      </p>
      <div className="flex gap-4">
        <Link
          href="/bridge"
          className="px-6 py-3 bg-rollup-accent text-white rounded-lg hover:opacity-90 transition"
        >
          Bridge
        </Link>
        <Link
          href="/explorer"
          className="px-6 py-3 border border-rollup-border text-white rounded-lg hover:bg-rollup-card transition"
        >
          Explorer
        </Link>
      </div>
    </main>
  );
}
