export default function BridgePage() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-8">
      <h1 className="text-3xl font-bold text-rollup-accent mb-4">
        Asset Bridge
      </h1>
      <p className="text-rollup-muted mb-6">
        Bridge assets between L1 and L2.
      </p>
      <div className="w-full max-w-md bg-rollup-card border border-rollup-border rounded-xl p-6">
        <div className="mb-4">
          <label className="block text-sm text-rollup-muted mb-1">From</label>
          <div className="bg-rollup-dark border border-rollup-border rounded-lg p-3 text-sm">
            Ethereum L1
          </div>
        </div>
        <div className="flex justify-center my-2">
          <span className="text-rollup-muted">&#8595;</span>
        </div>
        <div className="mb-4">
          <label className="block text-sm text-rollup-muted mb-1">To</label>
          <div className="bg-rollup-dark border border-rollup-border rounded-lg p-3 text-sm">
            ZK Rollup L2
          </div>
        </div>
        <div className="mb-4">
          <label className="block text-sm text-rollup-muted mb-1">Amount</label>
          <input
            type="number"
            placeholder="0.0"
            className="w-full bg-rollup-dark border border-rollup-border rounded-lg p-3 text-sm focus:outline-none focus:border-rollup-accent"
          />
        </div>
        <button className="w-full py-3 bg-rollup-accent text-white rounded-lg hover:opacity-90 transition font-medium">
          Connect Wallet
        </button>
      </div>
    </main>
  );
}
