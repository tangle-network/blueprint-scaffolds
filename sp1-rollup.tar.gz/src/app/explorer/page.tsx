export default function ExplorerPage() {
  return (
    <main className="min-h-screen p-8">
      <h1 className="text-3xl font-bold text-rollup-accent mb-6">
        Block Explorer
      </h1>
      <div className="overflow-x-auto">
        <table className="w-full max-w-4xl border-collapse">
          <thead>
            <tr className="border-b border-rollup-border text-left text-sm text-rollup-muted">
              <th className="pb-3 pr-4">Batch</th>
              <th className="pb-3 pr-4">Transactions</th>
              <th className="pb-3 pr-4">Status</th>
              <th className="pb-3">Proof</th>
            </tr>
          </thead>
          <tbody className="text-sm">
            <tr className="border-b border-rollup-border">
              <td className="py-3 pr-4 font-mono text-rollup-accent">#1</td>
              <td className="py-3 pr-4">0</td>
              <td className="py-3 pr-4">
                <span className="px-2 py-1 bg-rollup-success/20 text-rollup-success rounded text-xs">
                  Finalized
                </span>
              </td>
              <td className="py-3 font-mono text-xs">—</td>
            </tr>
          </tbody>
        </table>
      </div>
    </main>
  );
}
