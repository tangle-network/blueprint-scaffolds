import Link from "next/link";

export default function Navbar() {
  return (
    <nav className="flex items-center justify-between px-6 py-4 border-b border-rollup-border bg-rollup-dark">
      <Link href="/" className="text-lg font-bold text-rollup-accent">
        ZK Rollup SP1
      </Link>
      <div className="flex gap-4 text-sm">
        <Link href="/bridge" className="hover:text-rollup-accent transition">
          Bridge
        </Link>
        <Link href="/explorer" className="hover:text-rollup-accent transition">
          Explorer
        </Link>
      </div>
    </nav>
  );
}
