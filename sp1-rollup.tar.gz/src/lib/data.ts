import type {
  Block,
  Transaction,
  Batch,
  NetworkStats,
  BridgeDeposit,
} from "./types";

function hex(n: number, len = 8): string {
  return (
    "0x" +
    n.toString(16).padStart(len, "0") +
    "a".repeat(56 - 0)
  );
}

function randHex(len = 64): string {
  const chars = "0123456789abcdef";
  let s = "0x";
  for (let i = 0; i < len; i++) s += chars[Math.floor(Math.random() * 16)];
  return s;
}

function randAddr(): string {
  return randHex(40);
}

const STATUSES = ["pending", "submitted", "verified"] as const;
const TX_STATUSES = ["success", "failed", "pending"] as const;
const TX_TYPES = ["transfer", "deposit", "withdrawal"] as const;

export function generateBlocks(count: number): Block[] {
  const blocks: Block[] = [];
  for (let i = 0; i < count; i++) {
    const num = 1000 - i;
    blocks.push({
      number: num,
      hash: randHex(),
      parentHash: randHex(),
      stateRoot: randHex(),
      transactionCount: Math.floor(Math.random() * 50) + 5,
      timestamp: Date.now() / 1000 - i * 2,
      gasUsed: (
        BigInt(Math.floor(Math.random() * 8000000) + 100000)
      ).toString(),
      batchHash: i % 10 === 0 ? randHex() : undefined,
      proofStatus: STATUSES[Math.floor(Math.random() * 3)],
    });
  }
  return blocks;
}

export function generateTransactions(count: number): Transaction[] {
  const txs: Transaction[] = [];
  for (let i = 0; i < count; i++) {
    txs.push({
      hash: randHex(),
      blockNumber: 1000 - Math.floor(i / 3),
      from: randAddr(),
      to: randAddr(),
      value: (BigInt(Math.floor(Math.random() * 1e18)).toString()),
      gasPrice: (BigInt(Math.floor(Math.random() * 1e10)).toString()),
      status: TX_STATUSES[Math.floor(Math.random() * 3)],
      timestamp: Date.now() / 1000 - i * 5,
      type: TX_TYPES[Math.floor(Math.random() * 3)],
    });
  }
  return txs;
}

export function generateBatches(count: number): Batch[] {
  const batches: Batch[] = [];
  for (let i = 0; i < count; i++) {
    const start = 1000 - i * 10;
    const status = STATUSES[Math.min(i, 2)];
    batches.push({
      id: 100 - i,
      batchHash: randHex(),
      stateRoot: randHex(),
      prevStateRoot: randHex(),
      blockRange: [start - 9, start],
      txCount: Math.floor(Math.random() * 300) + 20,
      proofTxHash: status !== "pending" ? randHex() : undefined,
      status,
      submittedAt: status !== "pending" ? Date.now() / 1000 - i * 100 : undefined,
      verifiedAt: status === "verified" ? Date.now() / 1000 - i * 80 : undefined,
    });
  }
  return batches;
}

export function generateDeposits(count: number): BridgeDeposit[] {
  const deposits: BridgeDeposit[] = [];
  for (let i = 0; i < count; i++) {
    const status = i < count - 2 ? "claimed" : i < count - 1 ? "pending" : "pending";
    deposits.push({
      id: count - i,
      l1TxHash: randHex(),
      l2TxHash: status === "claimed" ? randHex() : undefined,
      recipient: randAddr(),
      amount: (BigInt(Math.floor(Math.random() * 1e18)).toString()),
      token: "ETH",
      status,
      blockNumber: status === "claimed" ? 990 - i : undefined,
    });
  }
  return deposits;
}

export function getNetworkStats(): NetworkStats {
  return {
    latestBlock: 1000,
    totalTransactions: 45283,
    totalBatches: 104,
    avgBlockTime: "2.1s",
    pendingProofs: 3,
    stateRoot: randHex(),
    l1FinalizedBlock: 997,
  };
}

export function formatEth(wei: string): string {
  const val = BigInt(wei);
  const eth = val / BigInt(1e14);
  return (Number(eth) / 1e4).toFixed(4) + " ETH";
}

export function formatGas(gas: string): string {
  return Number(gas).toLocaleString();
}

export function truncateHash(hash: string, chars = 6): string {
  if (!hash || hash.length < chars * 2 + 2) return hash;
  return `${hash.slice(0, chars + 2)}...${hash.slice(-chars)}`;
}

export function timeAgo(timestamp: number): string {
  const diff = Math.floor(Date.now() / 1000 - timestamp);
  if (diff < 60) return `${diff}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}
