export const ROLLUP_CONFIG = {
  chainId: 901,
  chainName: "ZK Rollup SP1",
  l1ChainId: 1,
  blockTime: 2000,
  maxTxsPerBlock: 100,
  maxBlocksPerBatch: 10,
  proofTimeout: 3600,
  challengePeriod: 604800,
  sequencerAddress: "0x" + "a".repeat(40),
  rollupContract: "0x" + "b".repeat(40),
  bridgeContract: "0x" + "c".repeat(40),
  verifierContract: "0x" + "d".repeat(40),
  rpcUrl: "http://localhost:8545",
  l1RpcUrl: "http://localhost:8546",
  explorerUrl: "http://localhost:3000",
  nativeToken: "ETH",
};

export const SP1_VERIFIER_PROGRAM = {
  name: "zk-rollup-state-transition",
  programId:
    "0x" + "deadbeef".repeat(8),
  version: "1.0.0",
};

export const DA_CONFIG = {
  mode: "calldata" as const,
  maxBlobDataSize: 131072,
  maxCalldataSize: 65536,
  blobVersionedHash: undefined as string | undefined,
};
