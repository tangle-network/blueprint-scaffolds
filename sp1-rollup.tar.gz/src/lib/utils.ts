export function shortenHash(hash: string, chars = 6): string {
  if (hash.length <= chars * 2 + 2) return hash
  return `${hash.slice(0, chars + 2)}...${hash.slice(-chars)}`
}

export function formatEther(wei: string): string {
  const num = BigInt(wei)
  const whole = num / BigInt(10 ** 18)
  const frac = num % BigInt(10 ** 18)
  if (frac === 0n) return whole.toString()
  return `${whole}.${frac.toString().padStart(18, "0").replace(/0+$/, "")}`
}

export function timestampToAge(timestamp: number): string {
  const now = Date.now() / 1000
  const diff = Math.floor(now - timestamp)
  if (diff < 60) return `${diff}s ago`
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`
  return `${Math.floor(diff / 86400)}d ago`
}

export function timestampToDate(timestamp: number): string {
  return new Date(timestamp * 1000).toLocaleString()
}

export function randomHex(length: number): string {
  const chars = "0123456789abcdef"
  let result = "0x"
  for (let i = 0; i < length; i++) {
    result += chars[Math.floor(Math.random() * 16)]
  }
  return result
}

export function classNames(...classes: (string | boolean | undefined | null)[]): string {
  return classes.filter(Boolean).join(" ")
}

export const ROLLUP_CONFIG = {
  chainId: 42069,
  chainName: "ZK Rollup SP1",
  blockInterval: 2,
  maxBatchSize: 1000,
  proofWindow: 600,
  challengePeriod: 604800,
  daMode: "blob" as const,
  l1ChainId: 1,
  verifierAddress: "0x0000000000000000000000000000000000000001",
  bridgeAddress: "0x0000000000000000000000000000000000000002",
}

export const MOCK_ADDRESSES = [
  "0x742d35Cc6634C0532925a3b844Bc9e7595f2bD28",
  "0x8Ba1f109551bD432803012645Ac136ddd64DBA72",
  "0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045",
  "0x5aAeb6053F3E94C9b9A09f33669435E7Ef1BeAed",
  "0xfB6916095ca1df60bB79Ce92cE3Ea74c37c5d359",
  "0xAb5801a7D398351b8bE11C439e05C5B3259aeC9B",
]
