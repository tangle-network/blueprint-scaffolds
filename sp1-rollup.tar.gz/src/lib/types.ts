export interface Block {
  number: number;
  hash: string;
  parentHash: string;
  stateRoot: string;
  transactionCount: number;
  timestamp: number;
  gasUsed: string;
  batchHash?: string;
  proofStatus: "pending" | "submitted" | "verified";
}

export interface Transaction {
  hash: string;
  blockNumber: number;
  from: string;
  to: string;
  value: string;
  gasPrice: string;
  status: "success" | "failed" | "pending";
  timestamp: number;
  type: "transfer" | "deposit" | "withdrawal";
}

export interface Batch {
  id: number;
  batchHash: string;
  stateRoot: string;
  prevStateRoot: string;
  blockRange: [number, number];
  txCount: number;
  proofTxHash?: string;
  status: "proving" | "submitted" | "verified";
  submittedAt?: number;
  verifiedAt?: number;
}

export interface BridgeDeposit {
  id: number;
  l1TxHash: string;
  l2TxHash?: string;
  recipient: string;
  amount: string;
  token: string;
  status: "pending" | "claimed" | "failed";
  blockNumber?: number;
}

export interface NetworkStats {
  latestBlock: number;
  totalTransactions: number;
  totalBatches: number;
  avgBlockTime: string;
  pendingProofs: number;
  stateRoot: string;
  l1FinalizedBlock: number;
}

export interface Account {
  address: string;
  balance: string;
  nonce: number;
  codeHash: string;
  storageRoot: string;
}
