export interface Block {
  number: number
  hash: string
  parentHash: string
  stateRoot: string
  transactionCount: number
  timestamp: number
  gasUsed: string
  batchDataHash: string
}

export interface Transaction {
  hash: string
  blockNumber: number
  from: string
  to: string | null
  value: string
  gasPrice: string
  gasUsed: string
  status: "success" | "failed"
  type: "transfer" | "deposit" | "withdrawal" | "contract_call"
  data: string
  nonce: number
}

export interface Proof {
  blockNumber: number
  proofType: "groth16" | "plonk"
  status: "pending" | "generating" | "submitted" | "verified" | "failed"
  proofBytes: string
  publicValues: string
  sp1VkHash: string
  submittedAt: number | null
  verifiedAt: number | null
}

export interface StateRoot {
  root: string
  blockNumber: number
  timestamp: number
}

export interface BridgeDeposit {
  id: string
  l1TxHash: string
  l2TxHash: string | null
  amount: string
  token: string
  from: string
  to: string
  status: "pending" | "deposited" | "claimed" | "failed"
}

export interface BridgeWithdrawal {
  id: string
  l2TxHash: string
  l1TxHash: string | null
  amount: string
  token: string
  from: string
  to: string
  status: "pending" | "submitted" | "finalized" | "failed"
}

export interface SequencerStatus {
  currentBlock: number
  pendingTransactions: number
  stateRoot: string
  lastProofBlock: number
  proofQueueDepth: number
  isRunning: boolean
  daMode: "calldata" | "blob"
}

export interface MerkleProof {
  key: string
  value: string
  proof: string[]
  root: string
}

export interface RollupConfig {
  chainId: number
  blockInterval: number
  maxBatchSize: number
  proofWindow: number
  challengePeriod: number
  daMode: "calldata" | "blob"
  verifierAddress: string
  bridgeAddress: string
}
