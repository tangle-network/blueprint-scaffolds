export class MerklePatriciaNode {
  type: "leaf" | "extension" | "branch"
  key: string
  value?: string
  children: Map<string, MerklePatriciaNode>
  hash: string

  constructor(type: "leaf" | "extension" | "branch", key: string = "") {
    this.type = type
    this.key = key
    this.children = new Map()
    this.hash = ""
  }
}

function nibblesToHex(nibbles: string[]): string {
  let hex = ""
  for (let i = 0; i < nibbles.length; i += 2) {
    const high = parseInt(nibbles[i], 16)
    const low = i + 1 < nibbles.length ? parseInt(nibbles[i + 1], 16) : 0
    hex += ((high << 4) | low).toString(16).padStart(2, "0")
  }
  return hex
}

function hexToNibbles(hex: string): string[] {
  const nibbles: string[] = []
  for (const ch of hex) {
    nibbles.push(ch.toLowerCase())
  }
  return nibbles
}

function sharedPrefixLength(a: string[], b: string[]): number {
  const len = Math.min(a.length, b.length)
  for (let i = 0; i < len; i++) {
    if (a[i] !== b[i]) return i
  }
  return len
}

function hashNode(node: MerklePatriciaNode): string {
  const encoder = new TextEncoder()
  let data = node.type + ":"

  if (node.type === "leaf") {
    data += node.key + ":" + (node.value || "")
  } else if (node.type === "extension") {
    data += node.key + ":" + node.hash
  } else {
    const parts: string[] = []
    for (const [k, child] of node.children) {
      parts.push(k + ":" + child.hash)
    }
    data += parts.join(",")
  }

  const bytes = encoder.encode(data)
  let h = 0x811c9dc5
  for (let i = 0; i < bytes.length; i++) {
    h ^= bytes[i]
    h = Math.imul(h, 0x01000193)
  }
  return ("0000000" + (h >>> 0).toString(16)).slice(-8)
}

export class MerklePatriciaTrie {
  root: MerklePatriciaNode

  constructor() {
    this.root = new MerklePatriciaNode("branch")
    this.root.hash = hashNode(this.root)
  }

  getRootHash(): string {
    return this.root.hash
  }

  insert(keyHex: string, value: string): void {
    const nibbles = hexToNibbles(keyHex)
    this.root = this._insert(this.root, nibbles, value)
    this.root.hash = hashNode(this.root)
  }

  private _insert(
    node: MerklePatriciaNode,
    nibbles: string[],
    value: string
  ): MerklePatriciaNode {
    if (node.type === "branch") {
      if (nibbles.length === 0) {
        const leaf = new MerklePatriciaNode("leaf")
        leaf.key = ""
        leaf.value = value
        leaf.hash = hashNode(leaf)
        return leaf
      }
      const first = nibbles[0]
      const rest = nibbles.slice(1)
      if (node.children.has(first)) {
        const child = node.children.get(first)!
        node.children.set(first, this._insert(child, rest, value))
      } else {
        const leaf = new MerklePatriciaNode("leaf")
        leaf.key = rest.join("")
        leaf.value = value
        leaf.hash = hashNode(leaf)
        node.children.set(first, leaf)
      }
      node.hash = hashNode(node)
      return node
    }

    if (node.type === "leaf") {
      const existingNibbles = hexToNibbles(node.key)
      const shared = sharedPrefixLength(nibbles, existingNibbles)

      if (shared === nibbles.length && shared === existingNibbles.length) {
        node.value = value
        node.hash = hashNode(node)
        return node
      }

      const branch = new MerklePatriciaNode("branch")

      if (shared > 0) {
        const ext = new MerklePatriciaNode("extension")
        ext.key = nibbles.slice(0, shared).join("")

        const newLeaf = new MerklePatriciaNode("leaf")
        newLeaf.key = nibbles.slice(shared + 1).join("")
        newLeaf.value = value
        newLeaf.hash = hashNode(newLeaf)

        const oldLeaf = new MerklePatriciaNode("leaf")
        oldLeaf.key = existingNibbles.slice(shared + 1).join("")
        oldLeaf.value = node.value || ""
        oldLeaf.hash = hashNode(oldLeaf)

        branch.children.set(nibbles[shared], newLeaf)
        branch.children.set(existingNibbles[shared], oldLeaf)
        branch.hash = hashNode(branch)

        ext.children.set("", branch)
        ext.hash = hashNode(ext)
        return ext
      }

      const newLeaf = new MerklePatriciaNode("leaf")
      newLeaf.key = nibbles.slice(1).join("")
      newLeaf.value = value
      newLeaf.hash = hashNode(newLeaf)

      const oldLeaf = new MerklePatriciaNode("leaf")
      oldLeaf.key = existingNibbles.slice(1).join("")
      oldLeaf.value = node.value || ""
      oldLeaf.hash = hashNode(oldLeaf)

      branch.children.set(nibbles[0], newLeaf)
      branch.children.set(existingNibbles[0], oldLeaf)
      branch.hash = hashNode(branch)
      return branch
    }

    if (node.type === "extension") {
      const extNibbles = hexToNibbles(node.key)
      const shared = sharedPrefixLength(nibbles, extNibbles)

      if (shared === extNibbles.length) {
        const childNode = node.children.get("")!
        node.children.set("", this._insert(childNode, nibbles.slice(shared), value))
        node.hash = hashNode(node)
        return node
      }

      const branch = new MerklePatriciaNode("branch")

      if (shared > 0) {
        const lowerExt = new MerklePatriciaNode("extension")
        lowerExt.key = extNibbles.slice(shared + 1).join("")
        lowerExt.children.set("", node.children.get("")!)
        lowerExt.hash = hashNode(lowerExt)

        branch.children.set(extNibbles[shared], lowerExt)
        branch.children.set(
          nibbles[shared],
          (() => {
            const leaf = new MerklePatriciaNode("leaf")
            leaf.key = nibbles.slice(shared + 1).join("")
            leaf.value = value
            leaf.hash = hashNode(leaf)
            return leaf
          })()
        )

        const upperExt = new MerklePatriciaNode("extension")
        upperExt.key = extNibbles.slice(0, shared).join("")
        upperExt.children.set("", branch)
        upperExt.hash = hashNode(upperExt)
        return upperExt
      }

      const lowerExt = new MerklePatriciaNode("extension")
      lowerExt.key = extNibbles.slice(1).join("")
      lowerExt.children.set("", node.children.get("")!)
      lowerExt.hash = hashNode(lowerExt)

      branch.children.set(extNibbles[0], lowerExt)
      branch.children.set(
        nibbles[0],
        (() => {
          const leaf = new MerklePatriciaNode("leaf")
          leaf.key = nibbles.slice(1).join("")
          leaf.value = value
          leaf.hash = hashNode(leaf)
          return leaf
        })()
      )
      branch.hash = hashNode(branch)
      return branch
    }

    return node
  }

  get(keyHex: string): string | null {
    const nibbles = hexToNibbles(keyHex)
    return this._get(this.root, nibbles)
  }

  private _get(node: MerklePatriciaNode, nibbles: string[]): string | null {
    if (node.type === "branch") {
      if (nibbles.length === 0) {
        if (node.children.has("")) {
          const child = node.children.get("")!
          if (child.type === "leaf" && child.key === "") return child.value || null
        }
        return null
      }
      const child = node.children.get(nibbles[0])
      if (!child) return null
      return this._get(child, nibbles.slice(1))
    }

    if (node.type === "leaf") {
      const existing = hexToNibbles(node.key)
      if (existing.length !== nibbles.length) return null
      return existing.every((n, i) => n === nibbles[i]) ? node.value || null : null
    }

    if (node.type === "extension") {
      const extNibbles = hexToNibbles(node.key)
      if (nibbles.length < extNibbles.length) return null
      for (let i = 0; i < extNibbles.length; i++) {
        if (nibbles[i] !== extNibbles[i]) return null
      }
      const child = node.children.get("")!
      return this._get(child, nibbles.slice(extNibbles.length))
    }

    return null
  }

  getProof(keyHex: string): { key: string; value: string | null; proof: string[] } {
    const nibbles = hexToNibbles(keyHex)
    const proof: string[] = []
    const value = this._getProof(this.root, nibbles, proof)
    return { key: keyHex, value, proof }
  }

  private _getProof(
    node: MerklePatriciaNode,
    nibbles: string[],
    proof: string[]
  ): string | null {
    proof.push(node.hash)

    if (node.type === "branch") {
      if (nibbles.length === 0) return null
      const child = node.children.get(nibbles[0])
      if (!child) return null
      return this._getProof(child, nibbles.slice(1), proof)
    }

    if (node.type === "leaf") {
      const existing = hexToNibbles(node.key)
      if (existing.length !== nibbles.length) return null
      return existing.every((n, i) => n === nibbles[i]) ? node.value || null : null
    }

    if (node.type === "extension") {
      const extNibbles = hexToNibbles(node.key)
      for (let i = 0; i < extNibbles.length; i++) {
        if (nibbles[i] !== extNibbles[i]) return null
      }
      const child = node.children.get("")!
      return this._getProof(child, nibbles.slice(extNibbles.length), proof)
    }

    return null
  }
}
