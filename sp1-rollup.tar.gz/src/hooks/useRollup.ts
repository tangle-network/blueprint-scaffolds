"use client";

import { useState, useCallback } from "react";

export function useRollup() {
  const [loading, setLoading] = useState(false);

  const bridge = useCallback(async (_amount: string) => {
    setLoading(true);
    try {
      return { success: true };
    } finally {
      setLoading(false);
    }
  }, []);

  return { loading, bridge };
}
