use crate::batch::BatchBuilder;
use crate::da::{DAMode, DataAvailabilityLayer};
use crate::mempool::Mempool;
use crate::proof::ProofPipeline;
use crate::state::StateManager;

pub struct Sequencer {
    pub state: StateManager,
    pub mempool: Mempool,
    pub batch_builder: BatchBuilder,
    pub proof_pipeline: ProofPipeline,
    pub da_layer: DataAvailabilityLayer,
    pub current_batch_index: u64,
    pub max_txs_per_batch: usize,
}

impl Sequencer {
    pub fn new(
        max_mempool_size: usize,
        max_txs_per_batch: usize,
        max_batch_bytes: usize,
        aggregation_threshold: usize,
        da_mode: DAMode,
    ) -> Self {
        Self {
            state: StateManager::new(),
            mempool: Mempool::new(max_mempool_size, max_batch_bytes),
            batch_builder: BatchBuilder::new(max_txs_per_batch, max_batch_bytes),
            proof_pipeline: ProofPipeline::new(aggregation_threshold),
            da_layer: DataAvailabilityLayer::new(da_mode),
            current_batch_index: 0,
            max_txs_per_batch,
        }
    }

    pub fn submit_transaction(
        &self,
        tx: crate::state::Transaction,
    ) -> Result<[u8; 32], String> {
        self.mempool.add_transaction(tx)
    }

    pub fn produce_batch(&mut self) -> Result<Option<crate::batch::Batch>, String> {
        let txs = self.mempool.collect_batch(self.max_txs_per_batch, 1024 * 1024);
        if txs.is_empty() {
            return Ok(None);
        }

        let prev_root = self.state.state_root();
        let (results, new_root) = self.state.apply_batch(&txs);

        let failed: Vec<_> = results.iter().filter(|r| r.is_err()).collect();
        if !failed.is_empty() {
            return Err(format!("{} transactions failed in batch", failed.len()));
        }

        let batch = self.batch_builder.build_batch(
            self.current_batch_index,
            txs,
            prev_root,
            new_root,
        )?;

        self.current_batch_index += 1;
        Ok(Some(batch))
    }

    pub fn process_full_cycle(&mut self) -> Result<Option<CycleResult>, String> {
        let batch = self.produce_batch()?;

        match batch {
            Some(b) => {
                let da_commitment = self.da_layer.publish_batch(&b)?;
                self.proof_pipeline.submit_batch(b.clone());

                let proofs = self.proof_pipeline.process_pending();

                let aggregated = self.proof_pipeline.try_aggregate();

                Ok(Some(CycleResult {
                    batch: b,
                    da_commitment,
                    proofs,
                    aggregated,
                }))
            }
            None => Ok(None),
        }
    }
}

pub struct CycleResult {
    pub batch: crate::batch::Batch,
    pub da_commitment: crate::da::DACommitment,
    pub proofs: Vec<crate::proof::SP1Proof>,
    pub aggregated: Option<crate::proof::AggregatedProof>,
}
