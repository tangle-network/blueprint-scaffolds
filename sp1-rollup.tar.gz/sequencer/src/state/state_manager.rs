use crate::state::transaction::{AccountState, Transaction};
use crate::state::MerklePatriciaTrie;
use sha3::{Digest, Keccak256};
use std::collections::HashMap;

pub struct StateManager {
    trie: MerklePatriciaTrie,
    account_cache: HashMap<[u8; 20], AccountState>,
}

impl StateManager {
    pub fn new() -> Self {
        Self {
            trie: MerklePatriciaTrie::new(),
            account_cache: HashMap::new(),
        }
    }

    pub fn state_root(&self) -> [u8; 32] {
        self.trie.root_hash()
    }

    pub fn get_account(&mut self, address: &[u8; 20]) -> AccountState {
        if let Some(acc) = self.account_cache.get(address) {
            return acc.clone();
        }
        match self.trie.get(address) {
            Some(data) => AccountState::decode(&data).unwrap_or(AccountState {
                nonce: 0,
                balance: 0,
                code_hash: [0; 32],
                storage_root: [0; 32],
            }),
            None => AccountState {
                nonce: 0,
                balance: 0,
                code_hash: [0; 32],
                storage_root: [0; 32],
            },
        }
    }

    pub fn set_account(&mut self, address: &[u8; 20], account: AccountState) {
        self.account_cache.insert(*address, account.clone());
        self.trie.insert(address, account.encode());
    }

    pub fn apply_transaction(&mut self, tx: &Transaction) -> Result<(), String> {
        let mut from_account = self.get_account(&tx.from);
        let mut to_account = self.get_account(&tx.to);

        if from_account.nonce != tx.nonce {
            return Err(format!(
                "Nonce mismatch: expected {}, got {}",
                from_account.nonce, tx.nonce
            ));
        }

        let gas_cost = tx.gas_limit * tx.gas_price;
        let total_cost = tx.amount + gas_cost;

        if from_account.balance < total_cost {
            return Err(format!(
                "Insufficient balance: {} < {}",
                from_account.balance, total_cost
            ));
        }

        from_account.balance -= total_cost;
        from_account.nonce += 1;
        to_account.balance += tx.amount;

        self.set_account(&tx.from, from_account);
        self.set_account(&tx.to, to_account);

        Ok(())
    }

    pub fn apply_batch(&mut self, txs: &[Transaction]) -> (Vec<Result<(), String>>, [u8; 32]) {
        let mut results = Vec::with_capacity(txs.len());
        for tx in txs {
            results.push(self.apply_transaction(tx));
        }
        (results, self.state_root())
    }

    pub fn compute_tx_root(txs: &[Transaction]) -> [u8; 32] {
        let mut hasher = Keccak256::new();
        for tx in txs {
            hasher.update(&tx.hash());
        }
        let result = hasher.finalize();
        let mut out = [0u8; 32];
        out.copy_from_slice(&result);
        out
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_apply_transaction() {
        let mut state = StateManager::new();
        let from = [1u8; 20];
        let to = [2u8; 20];

        let from_acc = AccountState {
            nonce: 0,
            balance: 1000,
            code_hash: [0; 32],
            storage_root: [0; 32],
        };
        state.set_account(&from, from_acc);

        let tx = Transaction {
            nonce: 0,
            from,
            to,
            amount: 100,
            gas_limit: 1,
            gas_price: 1,
            data: vec![],
            signature: vec![],
        };

        let result = state.apply_transaction(&tx);
        assert!(result.is_ok());

        let new_from = state.get_account(&from);
        assert_eq!(new_from.balance, 899);
        assert_eq!(new_from.nonce, 1);

        let new_to = state.get_account(&to);
        assert_eq!(new_to.balance, 100);
    }
}
