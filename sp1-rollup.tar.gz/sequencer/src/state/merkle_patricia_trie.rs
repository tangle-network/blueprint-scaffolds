use sha3::{Digest, Keccak256};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NibblePath {
    pub nibbles: Vec<u8>,
}

impl NibblePath {
    pub fn new(data: &[u8]) -> Self {
        let mut nibbles = Vec::with_capacity(data.len() * 2);
        for byte in data {
            nibbles.push(byte >> 4);
            nibbles.push(byte & 0x0F);
        }
        Self { nibbles }
    }

    pub fn from_nibbles(nibbles: Vec<u8>) -> Self {
        Self { nibbles }
    }

    pub fn len(&self) -> usize {
        self.nibbles.len()
    }

    pub fn is_empty(&self) -> bool {
        self.nibbles.is_empty()
    }

    pub fn common_prefix_len(&self, other: &NibblePath) -> usize {
        self.nibbles
            .iter()
            .zip(other.nibbles.iter())
            .take_while(|(a, b)| a == b)
            .count()
    }

    pub fn slice(&self, start: usize) -> NibblePath {
        NibblePath::from_nibbles(self.nibbles[start..].to_vec())
    }

    pub fn slice_range(&self, start: usize, end: usize) -> NibblePath {
        NibblePath::from_nibbles(self.nibbles[start..end].to_vec())
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TrieNode {
    Empty,
    Leaf {
        path: NibblePath,
        value: Vec<u8>,
    },
    Extension {
        path: NibblePath,
        child: Box<TrieNode>,
    },
    Branch {
        children: [Box<TrieNode>; 16],
        value: Option<Vec<u8>>,
    },
}

fn hash_node(node: &TrieNode) -> Vec<u8> {
    let encoded = encode_node(node);
    if encoded.len() < 32 {
        return encoded;
    }
    let mut hasher = Keccak256::new();
    hasher.update(&encoded);
    hasher.finalize().to_vec()
}

fn encode_node(node: &TrieNode) -> Vec<u8> {
    match node {
        TrieNode::Empty => vec![0x80],
        TrieNode::Leaf { path, value } => {
            let mut out = Vec::new();
            out.push(0x20);
            out.extend_from_slice(&compact_encode(path));
            out.extend_from_slice(value);
            out
        }
        TrieNode::Extension { path, child } => {
            let mut out = Vec::new();
            out.push(0x3e);
            out.extend_from_slice(&compact_encode(path));
            out.extend_from_slice(&hash_node(child));
            out
        }
        TrieNode::Branch { children, value } => {
            let mut out = Vec::new();
            out.push(0x40);
            for child in children {
                out.extend_from_slice(&hash_node(child));
            }
            if let Some(v) = value {
                out.extend_from_slice(v);
            } else {
                out.push(0x80);
            }
            out
        }
    }
}

fn compact_encode(path: &NibblePath) -> Vec<u8> {
    let mut result = Vec::new();
    let is_even = path.nibbles.len() % 2 == 0;
    let prefix = if is_even { 0x00 } else { 0x10 };
    result.push(prefix | 0x20);

    let mut nibbles = path.nibbles.clone();
    if is_even {
        nibbles.insert(0, 0);
    }

    for chunk in nibbles.chunks(2) {
        let byte = if chunk.len() == 2 {
            (chunk[0] << 4) | chunk[1]
        } else {
            chunk[0] << 4
        };
        result.push(byte);
    }
    result
}

#[derive(Debug, Clone)]
pub struct MerklePatriciaTrie {
    root: TrieNode,
}

impl Default for MerklePatriciaTrie {
    fn default() -> Self {
        Self::new()
    }
}

impl MerklePatriciaTrie {
    pub fn new() -> Self {
        Self {
            root: TrieNode::Empty,
        }
    }

    pub fn root_hash(&self) -> [u8; 32] {
        let hash = hash_node(&self.root);
        let mut out = [0u8; 32];
        out.copy_from_slice(&hash[..32]);
        out
    }

    pub fn root_hash_vec(&self) -> Vec<u8> {
        hash_node(&self.root)
    }

    pub fn insert(&mut self, key: &[u8], value: Vec<u8>) {
        let path = NibblePath::new(key);
        self.root = Self::insert_recursive(self.root.clone(), &path, value);
    }

    fn insert_recursive(node: TrieNode, path: &NibblePath, value: Vec<u8>) -> TrieNode {
        match node {
            TrieNode::Empty => TrieNode::Leaf {
                path: path.clone(),
                value,
            },
            TrieNode::Leaf {
                path: existing_path,
                value: _,
            } => {
                if existing_path.nibbles == path.nibbles {
                    return TrieNode::Leaf {
                        path: path.clone(),
                        value,
                    };
                }
                let common_len = existing_path.common_prefix_len(path);
                let mut children: Vec<Box<TrieNode>> = (0..16)
                    .map(|_| Box::new(TrieNode::Empty))
                    .collect();

                let existing_nibble = existing_path.nibbles[common_len];
                let new_nibble = path.nibbles[common_len];

                if existing_path.nibbles.len() > common_len + 1 {
                    children[existing_nibble as usize] = Box::new(TrieNode::Leaf {
                        path: existing_path.slice(common_len + 1),
                        value: vec![],
                    });
                } else {
                    children[existing_nibble as usize] = Box::new(TrieNode::Leaf {
                        path: NibblePath::from_nibbles(vec![]),
                        value: vec![],
                    });
                }

                if path.nibbles.len() > common_len + 1 {
                    children[new_nibble as usize] = Box::new(TrieNode::Leaf {
                        path: path.slice(common_len + 1),
                        value,
                    });
                } else {
                    children[new_nibble as usize] = Box::new(TrieNode::Leaf {
                        path: NibblePath::from_nibbles(vec![]),
                        value,
                    });
                }

                let child_array: [Box<TrieNode>; 16] = children.try_into().unwrap();

                if common_len > 0 {
                    TrieNode::Extension {
                        path: path.slice_range(0, common_len),
                        child: Box::new(TrieNode::Branch {
                            children: child_array,
                            value: None,
                        }),
                    }
                } else {
                    TrieNode::Branch {
                        children: child_array,
                        value: None,
                    }
                }
            }
            TrieNode::Branch {
                children,
                value: branch_val,
            } => {
                if path.is_empty() {
                    return TrieNode::Branch {
                        children,
                        value: Some(value),
                    };
                }
                let nibble = path.nibbles[0] as usize;
                let mut new_children = children;
                new_children[nibble] = Box::new(Self::insert_recursive(
                    (*children[nibble]).clone(),
                    &path.slice(1),
                    value,
                ));
                TrieNode::Branch {
                    children: new_children,
                    value: branch_val,
                }
            }
            TrieNode::Extension {
                path: ext_path,
                child,
            } => {
                let common_len = ext_path.common_prefix_len(path);
                if common_len == ext_path.len() {
                    let sub_path = path.slice(common_len);
                    TrieNode::Extension {
                        path: ext_path,
                        child: Box::new(Self::insert_recursive(*child, &sub_path, value)),
                    }
                } else {
                    let mut children: Vec<Box<TrieNode>> = (0..16)
                        .map(|_| Box::new(TrieNode::Empty))
                        .collect();
                    let split_nibble = ext_path.nibbles[common_len];
                    let remaining_ext = ext_path.slice(common_len + 1);

                    if remaining_ext.is_empty() {
                        children[split_nibble as usize] = child;
                    } else {
                        children[split_nibble as usize] = Box::new(TrieNode::Extension {
                            path: remaining_ext,
                            child,
                        });
                    }

                    if common_len < path.len() {
                        let new_nibble = path.nibbles[common_len];
                        let remaining = path.slice(common_len + 1);
                        children[new_nibble as usize] = Box::new(TrieNode::Leaf {
                            path: remaining,
                            value,
                        });
                    }

                    let child_array: [Box<TrieNode>; 16] = children.try_into().unwrap();

                    if common_len > 0 {
                        TrieNode::Extension {
                            path: path.slice_range(0, common_len),
                            child: Box::new(TrieNode::Branch {
                                children: child_array,
                                value: None,
                            }),
                        }
                    } else {
                        TrieNode::Branch {
                            children: child_array,
                            value: None,
                        }
                    }
                }
            }
        }
    }

    pub fn get(&self, key: &[u8]) -> Option<Vec<u8>> {
        let path = NibblePath::new(key);
        Self::get_recursive(&self.root, &path)
    }

    fn get_recursive(node: &TrieNode, path: &NibblePath) -> Option<Vec<u8>> {
        match node {
            TrieNode::Empty => None,
            TrieNode::Leaf {
                path: leaf_path,
                value,
            } => {
                if leaf_path.nibbles == path.nibbles {
                    Some(value.clone())
                } else {
                    None
                }
            }
            TrieNode::Branch { children, value } => {
                if path.is_empty() {
                    return value.clone();
                }
                let nibble = path.nibbles[0] as usize;
                Self::get_recursive(&children[nibble], &path.slice(1))
            }
            TrieNode::Extension {
                path: ext_path,
                child,
            } => {
                if path.nibbles.len() < ext_path.len() {
                    return None;
                }
                for i in 0..ext_path.len() {
                    if path.nibbles[i] != ext_path.nibbles[i] {
                        return None;
                    }
                }
                Self::get_recursive(child, &path.slice(ext_path.len()))
            }
        }
    }

    pub fn delete(&mut self, key: &[u8]) {
        let path = NibblePath::new(key);
        self.root = Self::delete_recursive(self.root.clone(), &path);
    }

    fn delete_recursive(node: TrieNode, path: &NibblePath) -> TrieNode {
        match node {
            TrieNode::Empty => TrieNode::Empty,
            TrieNode::Leaf {
                path: leaf_path, ..
            } => {
                if leaf_path.nibbles == path.nibbles {
                    TrieNode::Empty
                } else {
                    node
                }
            }
            TrieNode::Branch { children, value } => {
                if path.is_empty() {
                    return if children.iter().all(|c| **c == TrieNode::Empty) {
                        TrieNode::Empty
                    } else {
                        TrieNode::Branch {
                            children,
                            value: None,
                        }
                    };
                }
                let nibble = path.nibbles[0] as usize;
                let mut new_children = children;
                new_children[nibble] = Box::new(Self::delete_recursive(
                    (*children[nibble]).clone(),
                    &path.slice(1),
                ));
                let non_empty = new_children
                    .iter()
                    .filter(|c| **c != TrieNode::Empty)
                    .count();
                if non_empty == 0 {
                    if let Some(v) = value {
                        TrieNode::Leaf {
                            path: NibblePath::from_nibbles(vec![]),
                            value: v,
                        }
                    } else {
                        TrieNode::Empty
                    }
                } else {
                    TrieNode::Branch {
                        children: new_children,
                        value,
                    }
                }
            }
            TrieNode::Extension {
                path: ext_path,
                child,
            } => {
                if path.nibbles.len() < ext_path.len() {
                    return node;
                }
                for i in 0..ext_path.len() {
                    if path.nibbles[i] != ext_path.nibbles[i] {
                        return node;
                    }
                }
                let new_child = Self::delete_recursive(*child, &path.slice(ext_path.len()));
                match new_child {
                    TrieNode::Empty => TrieNode::Empty,
                    _ => TrieNode::Extension {
                        path: ext_path,
                        child: Box::new(new_child),
                    },
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_insert_and_get() {
        let mut trie = MerklePatriciaTrie::new();
        trie.insert(b"key1", b"value1".to_vec());
        assert_eq!(trie.get(b"key1"), Some(b"value1".to_vec()));
    }

    #[test]
    fn test_multiple_inserts() {
        let mut trie = MerklePatriciaTrie::new();
        trie.insert(b"doe", b"reindeer".to_vec());
        trie.insert(b"dog", b"puppy".to_vec());
        trie.insert(b"dogglesworth", b"cat".to_vec());
        assert_eq!(trie.get(b"doe"), Some(b"reindeer".to_vec()));
        assert_eq!(trie.get(b"dog"), Some(b"puppy".to_vec()));
        assert_eq!(trie.get(b"dogglesworth"), Some(b"cat".to_vec()));
    }

    #[test]
    fn test_root_hash_changes() {
        let mut trie = MerklePatriciaTrie::new();
        let h1 = trie.root_hash();
        trie.insert(b"key1", b"value1".to_vec());
        let h2 = trie.root_hash();
        assert_ne!(h1, h2);
    }

    #[test]
    fn test_delete() {
        let mut trie = MerklePatriciaTrie::new();
        trie.insert(b"key1", b"value1".to_vec());
        trie.delete(b"key1");
        assert_eq!(trie.get(b"key1"), None);
    }
}
