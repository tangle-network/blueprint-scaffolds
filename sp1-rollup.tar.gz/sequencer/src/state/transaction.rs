use sha3::{Digest, Keccak256};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Transaction {
    pub nonce: u64,
    pub from: [u8; 20],
    pub to: [u8; 20],
    pub amount: u64,
    pub gas_limit: u64,
    pub gas_price: u64,
    pub data: Vec<u8>,
    pub signature: Vec<u8>,
}

impl Transaction {
    pub fn hash(&self) -> [u8; 32] {
        let mut hasher = Keccak256::new();
        hasher.update(&self.nonce.to_le_bytes());
        hasher.update(&self.from);
        hasher.update(&self.to);
        hasher.update(&self.amount.to_le_bytes());
        hasher.update(&self.gas_limit.to_le_bytes());
        hasher.update(&self.gas_price.to_le_bytes());
        hasher.update(&self.data);
        let sig_hash = {
            let mut h = Keccak256::new();
            h.update(&self.signature);
            h.finalize()
        };
        hasher.update(sig_hash);
        let result = hasher.finalize();
        let mut out = [0u8; 32];
        out.copy_from_slice(&result);
        out
    }

    pub fn encode(&self) -> Vec<u8> {
        let mut buf = Vec::new();
        buf.extend_from_slice(&self.nonce.to_le_bytes());
        buf.extend_from_slice(&self.from);
        buf.extend_from_slice(&self.to);
        buf.extend_from_slice(&self.amount.to_le_bytes());
        buf.extend_from_slice(&self.gas_limit.to_le_bytes());
        buf.extend_from_slice(&self.gas_price.to_le_bytes());
        let data_len = self.data.len() as u64;
        buf.extend_from_slice(&data_len.to_le_bytes());
        buf.extend_from_slice(&self.data);
        let sig_len = self.signature.len() as u64;
        buf.extend_from_slice(&sig_len.to_le_bytes());
        buf.extend_from_slice(&self.signature);
        buf
    }

    pub fn decode(data: &[u8]) -> Option<Self> {
        if data.len() < 84 {
            return None;
        }
        let nonce = u64::from_le_bytes(data[0..8].try_into().ok()?);
        let from: [u8; 20] = data[8..28].try_into().ok()?;
        let to: [u8; 20] = data[28..48].try_into().ok()?;
        let amount = u64::from_le_bytes(data[48..56].try_into().ok()?);
        let gas_limit = u64::from_le_bytes(data[56..64].try_into().ok()?);
        let gas_price = u64::from_le_bytes(data[64..72].try_into().ok()?);
        let data_len = u64::from_le_bytes(data[72..80].try_into().ok()?) as usize;
        if data.len() < 80 + data_len + 8 {
            return None;
        }
        let tx_data = data[80..80 + data_len].to_vec();
        let sig_offset = 80 + data_len;
        let sig_len = u64::from_le_bytes(data[sig_offset..sig_offset + 8].try_into().ok()?) as usize;
        if data.len() < sig_offset + 8 + sig_len {
            return None;
        }
        let signature = data[sig_offset + 8..sig_offset + 8 + sig_len].to_vec();
        Some(Transaction {
            nonce,
            from,
            to,
            amount,
            gas_limit,
            gas_price,
            data: tx_data,
            signature,
        })
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AccountState {
    pub nonce: u64,
    pub balance: u64,
    pub code_hash: [u8; 32],
    pub storage_root: [u8; 32],
}

impl AccountState {
    pub fn encode(&self) -> Vec<u8> {
        let mut buf = Vec::with_capacity(80);
        buf.extend_from_slice(&self.nonce.to_le_bytes());
        buf.extend_from_slice(&self.balance.to_le_bytes());
        buf.extend_from_slice(&self.code_hash);
        buf.extend_from_slice(&self.storage_root);
        buf
    }

    pub fn decode(data: &[u8]) -> Option<Self> {
        if data.len() < 80 {
            return None;
        }
        Some(AccountState {
            nonce: u64::from_le_bytes(data[0..8].try_into().ok()?),
            balance: u64::from_le_bytes(data[8..16].try_into().ok()?),
            code_hash: data[16..48].try_into().ok()?,
            storage_root: data[48..80].try_into().ok()?,
        })
    }
}
