use crate::state::Transaction;
use sha3::{Digest, Keccak256};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Batch {
    pub batch_index: u64,
    pub transactions: Vec<Transaction>,
    pub prev_state_root: [u8; 32],
    pub new_state_root: [u8; 32],
    pub data_hash: [u8; 32],
    pub timestamp: u64,
}

impl Batch {
    pub fn new(
        batch_index: u64,
        transactions: Vec<Transaction>,
        prev_state_root: [u8; 32],
        new_state_root: [u8; 32],
    ) -> Self {
        let data_hash = Self::compute_data_hash(&transactions);
        Self {
            batch_index,
            transactions,
            prev_state_root,
            new_state_root,
            data_hash,
            timestamp: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs(),
        }
    }

    fn compute_data_hash(txs: &[Transaction]) -> [u8; 32] {
        let mut hasher = Keccak256::new();
        for tx in txs {
            hasher.update(&tx.hash());
        }
        let result = hasher.finalize();
        let mut out = [0u8; 32];
        out.copy_from_slice(&result);
        out
    }

    pub fn encode_transactions(&self) -> Vec<u8> {
        let mut buf = Vec::new();
        let count = self.transactions.len() as u64;
        buf.extend_from_slice(&count.to_le_bytes());
        for tx in &self.transactions {
            let encoded = tx.encode();
            let len = encoded.len() as u64;
            buf.extend_from_slice(&len.to_le_bytes());
            buf.extend_from_slice(&encoded);
        }
        buf
    }

    pub fn header_hash(&self) -> [u8; 32] {
        let mut hasher = Keccak256::new();
        hasher.update(&self.batch_index.to_le_bytes());
        hasher.update(&self.prev_state_root);
        hasher.update(&self.new_state_root);
        hasher.update(&self.data_hash);
        hasher.update(&self.timestamp.to_le_bytes());
        let result = hasher.finalize();
        let mut out = [0u8; 32];
        out.copy_from_slice(&result);
        out
    }
}

pub struct BatchBuilder {
    max_txs_per_batch: usize,
    max_batch_size_bytes: usize,
}

impl BatchBuilder {
    pub fn new(max_txs: usize, max_bytes: usize) -> Self {
        Self {
            max_txs_per_batch: max_txs,
            max_batch_size_bytes: max_bytes,
        }
    }

    pub fn build_batch(
        &self,
        batch_index: u64,
        txs: Vec<Transaction>,
        prev_state_root: [u8; 32],
        new_state_root: [u8; 32],
    ) -> Result<Batch, String> {
        if txs.len() > self.max_txs_per_batch {
            return Err(format!(
                "Too many transactions: {} > {}",
                txs.len(),
                self.max_txs_per_batch
            ));
        }

        let total_size: usize = txs.iter().map(|tx| tx.encode().len()).sum();
        if total_size > self.max_batch_size_bytes {
            return Err(format!(
                "Batch too large: {} > {}",
                total_size, self.max_batch_size_bytes
            ));
        }

        Ok(Batch::new(batch_index, txs, prev_state_root, new_state_root))
    }
}
