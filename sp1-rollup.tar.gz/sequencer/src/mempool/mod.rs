use crate::state::Transaction;
use dashmap::DashMap;
use sha3::{Digest, Keccak256};
use std::collections::VecDeque;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use std::time::Instant;

pub struct MempoolEntry {
    pub tx: Transaction,
    pub hash: [u8; 32],
    pub received_at: Instant,
    pub gas_price: u64,
    pub size_bytes: usize,
}

pub struct Mempool {
    entries: Arc<DashMap<[u8; 32], MempoolEntry>>,
    priority_queue: Arc<std::sync::Mutex<VecDeque<[u8; 32]>>>,
    tx_count: AtomicU64,
    max_size: usize,
    max_tx_size: usize,
}

impl Mempool {
    pub fn new(max_size: usize, max_tx_size: usize) -> Self {
        Self {
            entries: Arc::new(DashMap::new()),
            priority_queue: Arc::new(std::sync::Mutex::new(VecDeque::new())),
            tx_count: AtomicU64::new(0),
            max_size,
            max_tx_size,
        }
    }

    pub fn add_transaction(&self, tx: Transaction) -> Result<[u8; 32], String> {
        let hash = tx.hash();
        let size_bytes = tx.encode().len();

        if size_bytes > self.max_tx_size {
            return Err(format!("Transaction too large: {} > {}", size_bytes, self.max_tx_size));
        }

        if self.entries.len() >= self.max_size {
            return Err("Mempool full".to_string());
        }

        if self.entries.contains_key(&hash) {
            return Err("Duplicate transaction".to_string());
        }

        let entry = MempoolEntry {
            tx,
            hash,
            received_at: Instant::now(),
            gas_price: 0,
            size_bytes,
        };

        self.entries.insert(hash, entry);
        self.priority_queue.lock().unwrap().push_back(hash);
        self.tx_count.fetch_add(1, Ordering::Relaxed);

        Ok(hash)
    }

    pub fn collect_batch(&self, max_txs: usize, max_bytes: usize) -> Vec<Transaction> {
        let mut batch = Vec::new();
        let mut total_bytes = 0usize;
        let mut keys_to_remove = Vec::new();

        let mut queue = self.priority_queue.lock().unwrap();

        while batch.len() < max_txs {
            let key = match queue.pop_front() {
                Some(k) => k,
                None => break,
            };

            if let Some((_, entry)) = self.entries.remove(&key) {
                if total_bytes + entry.size_bytes <= max_bytes {
                    total_bytes += entry.size_bytes;
                    batch.push(entry.tx.clone());
                } else {
                    self.entries.insert(key, entry);
                    keys_to_remove.push(key);
                    break;
                }
            }
        }

        for key in keys_to_remove {
            queue.push_back(key);
        }

        batch
    }

    pub fn remove_transactions(&self, hashes: &[[u8; 32]]) {
        for hash in hashes {
            self.entries.remove(hash);
        }
    }

    pub fn size(&self) -> usize {
        self.entries.len()
    }

    pub fn total_tx_count(&self) -> u64 {
        self.tx_count.load(Ordering::Relaxed)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_tx(nonce: u64) -> Transaction {
        Transaction {
            nonce,
            from: [nonce as u8; 20],
            to: [2u8; 20],
            amount: 100,
            gas_limit: 1,
            gas_price: 1,
            data: vec![],
            signature: vec![],
        }
    }

    #[test]
    fn test_add_and_collect() {
        let pool = Mempool::new(1000, 1024 * 1024);
        pool.add_transaction(make_tx(0)).unwrap();
        pool.add_transaction(make_tx(1)).unwrap();
        pool.add_transaction(make_tx(2)).unwrap();

        assert_eq!(pool.size(), 3);

        let batch = pool.collect_batch(2, 1024 * 1024);
        assert_eq!(batch.len(), 2);
    }
}
