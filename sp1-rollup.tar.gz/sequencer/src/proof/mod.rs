use crate::batch::Batch;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SP1Proof {
    pub proof_bytes: Vec<u8>,
    pub public_inputs: Vec<[u8; 32]>,
    pub program_vkey: [u8; 32],
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AggregatedProof {
    pub inner_proofs: Vec<SP1Proof>,
    pub aggregated_proof_bytes: Vec<u8>,
    pub public_inputs: Vec<[u8; 32]>,
    pub batch_range: (u64, u64),
}

pub struct ProofPipeline {
    pending_batches: Vec<Batch>,
    completed_proofs: Vec<SP1Proof>,
    aggregation_threshold: usize,
}

impl ProofPipeline {
    pub fn new(aggregation_threshold: usize) -> Self {
        Self {
            pending_batches: Vec::new(),
            completed_proofs: Vec::new(),
            aggregation_threshold,
        }
    }

    pub fn submit_batch(&mut self, batch: Batch) {
        self.pending_batches.push(batch);
    }

    pub fn generate_proof(&mut self, batch: &Batch) -> SP1Proof {
        let mut public_inputs = Vec::new();
        public_inputs.push(batch.prev_state_root);
        public_inputs.push(batch.new_state_root);
        public_inputs.push(batch.data_hash);
        public_inputs.push(batch.batch_index.to_le_bytes());

        let proof_bytes = Self::simulate_sp1_prove(
            &batch.prev_state_root,
            &batch.new_state_root,
            &batch.data_hash,
        );

        SP1Proof {
            proof_bytes,
            public_inputs,
            program_vkey: [0u8; 32],
        }
    }

    fn simulate_sp1_prove(
        prev_root: &[u8; 32],
        new_root: &[u8; 32],
        data_hash: &[u8; 32],
    ) -> Vec<u8> {
        use sha3::{Digest, Keccak256};
        let mut hasher = Keccak256::new();
        hasher.update(b"sp1_proof_prefix");
        hasher.update(prev_root);
        hasher.update(new_root);
        hasher.update(data_hash);
        hasher.update(b"sp1_proof_suffix");
        let hash = hasher.finalize();
        let mut proof = Vec::with_capacity(256);
        proof.extend_from_slice(&hash);
        proof.extend_from_slice(&[0u8; 224]);
        proof
    }

    pub fn process_pending(&mut self) -> Vec<SP1Proof> {
        let mut new_proofs = Vec::new();
        for batch in self.pending_batches.drain(..) {
            let proof = self.generate_proof(&batch);
            new_proofs.push(proof.clone());
            self.completed_proofs.push(proof);
        }
        new_proofs
    }

    pub fn try_aggregate(&mut self) -> Option<AggregatedProof> {
        if self.completed_proofs.len() < self.aggregation_threshold {
            return None;
        }

        let proofs_to_agg: Vec<SP1Proof> = self.completed_proofs.drain(..self.aggregation_threshold).collect();

        let mut all_inputs = Vec::new();
        for proof in &proofs_to_agg {
            all_inputs.extend_from_slice(&proof.public_inputs);
        }

        let batch_start = 0u64;
        let batch_end = (proofs_to_agg.len() as u64) - 1;

        let mut agg_bytes = Vec::new();
        agg_bytes.extend_from_slice(b"agg_proof_header");
        for p in &proofs_to_agg {
            agg_bytes.extend_from_slice(&p.proof_bytes[..32.min(p.proof_bytes.len())]);
        }
        agg_bytes.extend_from_slice(b"agg_proof_footer");

        Some(AggregatedProof {
            inner_proofs: proofs_to_agg,
            aggregated_proof_bytes: agg_bytes,
            public_inputs: all_inputs,
            batch_range: (batch_start, batch_end),
        })
    }

    pub fn pending_count(&self) -> usize {
        self.pending_batches.len()
    }

    pub fn completed_count(&self) -> usize {
        self.completed_proofs.len()
    }
}
