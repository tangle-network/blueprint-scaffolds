use crate::batch::Batch;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum DAMode {
    Calldata,
    Blob4844,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DACommitment {
    pub mode: DAMode,
    pub tx_hash: [u8; 32],
    pub data_hash: [u8; 32],
    pub size_bytes: u64,
    pub batch_indices: Vec<u64>,
}

pub struct DataAvailabilityLayer {
    mode: DAMode,
    max_calldata_size: usize,
    max_blob_size: usize,
    commitments: Vec<DACommitment>,
}

impl DataAvailabilityLayer {
    pub fn new(mode: DAMode) -> Self {
        Self {
            mode,
            max_calldata_size: 128 * 1024,
            max_blob_size: 128 * 1024 * 4,
            commitments: Vec::new(),
        }
    }

    pub fn publish_batch(&mut self, batch: &Batch) -> Result<DACommitment, String> {
        let encoded = batch.encode_transactions();
        let data_hash = batch.data_hash;

        match self.mode {
            DAMode::Calldata => {
                if encoded.len() > self.max_calldata_size {
                    return Err(format!(
                        "Calldata too large: {} > {}",
                        encoded.len(),
                        self.max_calldata_size
                    ));
                }
            }
            DAMode::Blob4844 => {
                if encoded.len() > self.max_blob_size {
                    return Err(format!(
                        "Blob too large: {} > {}",
                        encoded.len(),
                        self.max_blob_size
                    ));
                }
            }
        }

        let commitment = DACommitment {
            mode: self.mode,
            tx_hash: Self::compute_da_tx_hash(&encoded),
            data_hash,
            size_bytes: encoded.len() as u64,
            batch_indices: vec![batch.batch_index],
        };

        self.commitments.push(commitment.clone());
        Ok(commitment)
    }

    pub fn publish_batches(&mut self, batches: &[Batch]) -> Result<Vec<DACommitment>, String> {
        let mut commitments = Vec::new();
        for batch in batches {
            commitments.push(self.publish_batch(batch)?);
        }
        Ok(commitments)
    }

    fn compute_da_tx_hash(data: &[u8]) -> [u8; 32] {
        use sha3::{Digest, Keccak256};
        let mut hasher = Keccak256::new();
        hasher.update(b"da_commitment");
        hasher.update(data);
        let result = hasher.finalize();
        let mut out = [0u8; 32];
        out.copy_from_slice(&result);
        out
    }

    pub fn set_mode(&mut self, mode: DAMode) {
        self.mode = mode;
    }

    pub fn get_commitments(&self) -> &[DACommitment] {
        &self.commitments
    }

    pub fn max_batch_size(&self) -> usize {
        match self.mode {
            DAMode::Calldata => self.max_calldata_size,
            DAMode::Blob4844 => self.max_blob_size,
        }
    }
}
