import { ethers } from "hardhat";
import "dotenv/config";

async function main() {
    const [deployer] = await ethers.getSigners();
    console.log("Deploying contracts with account:", deployer.address);
    console.log("Account balance:", ethers.formatEther(await ethers.provider.getBalance(deployer.address)));

    const lzEndpoint = "0xD461ea0B4a51e946dB4D23670Aa2a8C0A2B4ae02";

    const XLayerOFT = await ethers.getContractFactory("XLayerOFT");
    const oft = await XLayerOFT.deploy(
        "XLayer Token",
        "XLT",
        lzEndpoint,
        deployer.address
    );

    await oft.waitForDeployment();
    const oftAddress = await oft.getAddress();

    console.log("XLayerOFT deployed to:", oftAddress);
}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
