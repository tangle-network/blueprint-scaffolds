import { ethers } from "hardhat";

async function main() {
    const [deployer] = await ethers.getSigners();
    console.log("Deploying contracts with account:", deployer.address);

    const balance = await ethers.provider.getBalance(deployer.address);
    console.log("Account balance:", ethers.formatEther(balance), "XDC");

    // X Layer mainnet LayerZero V2 Endpoint
    const LZ_ENDPOINT_XLAYER = "0xb9c7C351e216FE2591FFBCC2e1b0E6F943651A54";

    const MyOFT = await ethers.getContractFactory("MyOFT");
    const oft = await MyOFT.deploy(
        "MyOFT Token",
        "MOFT",
        LZ_ENDPOINT_XLAYER,
        deployer.address
    );

    await oft.waitForDeployment();

    const oftAddress = await oft.getAddress();
    console.log("MyOFT deployed to:", oftAddress);

    // Mint initial supply to deployer (1 million tokens with 18 decimals)
    const initialSupply = ethers.parseUnits("1000000", 18);
    const mintTx = await oft.mint(deployer.address, initialSupply);
    await mintTx.wait();
    console.log("Minted", ethers.formatUnits(initialSupply, 18), "MOFT to deployer");

    console.log("\n--- Deployment Summary ---");
    console.log("Contract:", oftAddress);
    console.log("Network: X Layer (chainId 196)");
    console.log("Owner:", deployer.address);
    console.log("LayerZero Endpoint:", LZ_ENDPOINT_XLAYER);
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });
