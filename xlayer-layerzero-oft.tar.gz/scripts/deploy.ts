import { ethers } from "hardhat";
import * as dotenv from "dotenv";

dotenv.config();

async function main() {
    const [deployer] = await ethers.getSigners();
    console.log("Deploying contracts with:", deployer.address);

    const balance = await deployer.getBalance();
    console.log("Account balance:", ethers.utils.formatEther(balance));

    const MyOFT = await ethers.getContractFactory("MyOFT");

    const XLAYER_ENDPOINT = "0x09c9B2e8555b85976534a1981711D93a112D3a30";
    const tokenName = "MyOFT";
    const tokenSymbol = "MOFT";

    const oft = await MyOFT.deploy(
        tokenName,
        tokenSymbol,
        XLAYER_ENDPOINT,
        deployer.address
    );

    await oft.deployed();
    console.log("MyOFT deployed to:", oft.address);

    const MINT_AMOUNT = ethers.utils.parseUnits("1000000", 18);
    const mintTx = await oft.mint(deployer.address, MINT_AMOUNT);
    await mintTx.wait();
    console.log("Minted 1,000,000 MOFT to deployer");
}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
