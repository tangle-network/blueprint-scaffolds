import { ethers } from "hardhat";
import { Options } from "@layerzerolabs/lz-v2-utilities";
import "dotenv/config";

const OFT_ADDRESS = "YOUR_OFT_ADDRESS_HERE";

const XLAYER_EID = 30266;
const SEPOLIA_EID = 40161;

async function main() {
    const [signer] = await ethers.getSigners();
    console.log("Sending from account:", signer.address);

    const oft = await ethers.getContractAt("XLayerOFT", OFT_ADDRESS);

    const sendParam = {
        dstEid: SEPOLIA_EID,
        to: ethers.zeroPadValue(signer.address, 32),
        amountLD: ethers.parseEther("1"),
        minAmountLD: ethers.parseEther("0.99"),
        extraOptions: Options.newOptions().addExecutorLzReceiveOption(200000, 0).toHex(),
        composeMsg: "0x",
        onftCmd: "0x",
    };

    const [nativeFee, lzTokenFee] = await oft.quoteSend(sendParam, false);
    console.log("Native fee:", ethers.formatEther(nativeFee));
    console.log("LZ token fee:", ethers.formatEther(lzTokenFee));

    const tx = await oft.send(sendParam, { nativeFee, lzTokenFee }, signer.address, {
        value: nativeFee,
    });

    console.log("Transaction hash:", tx.hash);
    const receipt = await tx.wait();
    console.log("Bridged tokens successfully! Block:", receipt.blockNumber);
}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
