import { ethers } from "hardhat";

async function main() {
    const [signer] = await ethers.getSigners();
    console.log("Sending tokens from account:", signer.address);

    const oftAddress = process.env.OFT_CONTRACT_ADDRESS;
    if (!oftAddress) {
        console.error("Error: OFT_CONTRACT_ADDRESS not set in .env");
        process.exit(1);
    }

    const destEid = parseInt(process.env.DEST_EID || "30101");
    const destAddress = process.env.DEST_ADDRESS || signer.address;
    const amountToSend = ethers.parseUnits("100", 18);

    console.log("OFT Contract:", oftAddress);
    console.log("Destination EID:", destEid);
    console.log("Destination Address:", destAddress);
    console.log("Amount to send:", ethers.formatUnits(amountToSend, 18), "MOFT");

    const MyOFT = await ethers.getContractFactory("MyOFT");
    const oft = MyOFT.attach(oftAddress);

    const balance = await oft.balanceOf(signer.address);
    console.log("Current MOFT balance:", ethers.formatUnits(balance, 18));

    if (balance < amountToSend) {
        console.error("Error: Insufficient MOFT balance");
        process.exit(1);
    }

    const sendParam = {
        dstEid: destEid,
        to: ethers.zeroPadValue(destAddress, 32),
        amountLD: amountToSend,
        minAmountLD: amountToSend,
        extraOptions: "0x",
        composeMsg: "0x",
        oftCmd: "0x",
    };

    console.log("\nQuoting send fee...");
    const quote = await oft.quoteSend(sendParam, false);
    console.log("Native fee:", ethers.formatEther(quote.nativeFee), "XDC");
    console.log("LZ token fee:", ethers.formatEther(quote.lzTokenFee));

    console.log("\nSending tokens cross-chain...");
    const sendTx = await oft.send(
        sendParam,
        { nativeFee: quote.nativeFee, lzTokenFee: 0 },
        signer.address,
        { value: quote.nativeFee }
    );

    console.log("Transaction hash:", sendTx.hash);
    console.log("Waiting for confirmation...");

    const receipt = await sendTx.wait();
    console.log("Transaction confirmed in block:", receipt.blockNumber);
    console.log("Gas used:", receipt.gasUsed.toString());
    console.log("\n--- Bridge Summary ---");
    console.log("Sent:", ethers.formatUnits(amountToSend, 18), "MOFT");
    console.log("From: X Layer -> Destination EID:", destEid);
    console.log("To:", destAddress);
    console.log("TX:", sendTx.hash);
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });
