import { ethers } from "hardhat";
import * as dotenv from "dotenv";

dotenv.config();

const DST_EID = 30101;
const DST_ADDRESS = process.env.DST_OFT_ADDRESS || "0x0000000000000000000000000000000000000000";

async function main() {
    const [signer] = await ethers.getSigners();
    console.log("Sending from:", signer.address);

    const oftAddress = process.env.OFT_ADDRESS;
    if (!oftAddress) {
        console.error("Set OFT_ADDRESS in .env");
        process.exit(1);
    }

    const oft = await ethers.getContractAt("MyOFT", oftAddress);

    const sendAmount = ethers.utils.parseUnits("100", 18);
    const toAddressBytes32 = ethers.utils.hexZeroPad(signer.address, 32);

    const sendParam = {
        dstEid: DST_EID,
        to: toAddressBytes32,
        amountLD: sendAmount,
        minAmountLD: sendAmount.mul(95).div(100),
        extraOptions: "0x",
        composeMsg: "0x",
        oftCmd: "0x",
    };

    const quote = await oft.quoteSend(sendParam, false);
    console.log("Fee quote:", ethers.utils.formatEther(quote.nativeFee), "X Layer native");

    const tx = await oft.send(sendParam, quote, signer.address, {
        value: quote.nativeFee,
        gasLimit: 500000,
    });

    console.log("Bridge tx hash:", tx.hash);
    const receipt = await tx.wait();
    console.log("Bridge complete, block:", receipt.blockNumber);
}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
