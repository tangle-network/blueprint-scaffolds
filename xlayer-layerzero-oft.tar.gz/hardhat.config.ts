import { HardhatUserConfig } from "hardhat/config";
import "@nomicfoundation/hardhat-toolbox";
import * as dotenv from "dotenv";

dotenv.config();

const privateKey = process.env.PRIVATE_KEY;
const isValidKey = privateKey && /^0x[0-9a-fA-F]{64}$/.test(privateKey);

const config: HardhatUserConfig = {
  solidity: {
    version: "0.8.22",
    settings: {
      evmVersion: "paris",
      viaIR: true,
      optimizer: {
        enabled: true,
        runs: 200,
      },
    },
  },
  networks: {
    xlayer: {
      url: process.env.XLAYER_RPC_URL || "https://rpc.xlayer.tech",
      accounts: isValidKey ? [privateKey!] : [],
    },
    ethereum: {
      url: process.env.ETHEREUM_RPC_URL || "https://rpc.ankr.com/eth",
      accounts: isValidKey ? [privateKey!] : [],
    },
  },
};

export default config;
