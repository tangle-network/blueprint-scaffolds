# AGENTS.md

Deploy a LayerZero OFT (Omnichain Fungible Token) on X Layer for cross-chain token transfers.

## What's here

This project was scaffolded by starter-foundry. The user's prompt drove the choices below — read their prompt first, it takes priority over everything in this file.

- **Family:** `forge-contracts`
- **Layers:** `framework:forge-foundation`, `capability:evm-layerzero-oft`
- **Partner:** `xlayer`

### Architecture notes
- Foundry project
- Solidity contracts in src/
- Tests in test/
- Deploy scripts in script/

## Getting started

```bash
forge build
forge test
```

Key files: `src/StarterCounter.sol`, `test/StarterCounter.t.sol`, `script/Deploy.s.sol`

## How to use this scaffold

This is a starting point, not a contract. You own every file.

- **Customize freely.** Replace components, change the layout, swap the color scheme — whatever fits the user's product.
- **The scaffold saves you setup time** — Tailwind, shadcn/ui, path aliases, and framework config are ready. Don't redo them.
- **Check `.starter-foundry/compose-report.json`** if you want to see which layer wrote which file.
- **Update this file** as the project evolves. Delete sections that no longer apply.
