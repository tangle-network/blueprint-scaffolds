// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import { StarterCounter } from "../src/StarterCounter.sol";

contract DeployScript {
    function run() external returns (StarterCounter deployed) {
        deployed = new StarterCounter();
    }
}
