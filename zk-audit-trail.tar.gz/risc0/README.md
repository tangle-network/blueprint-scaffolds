# RISC Zero Components

This directory contains a reference guest/host layout for generating receipts over:

- a Merkle root for committed logs
- policy evaluation summaries
- time-range inclusion statements
- selective disclosure claims

The frontend currently models the receipt shape in TypeScript so the Vite build remains lightweight. To turn this into a production prover, compile the Rust guest under `methods/guest` and wire the host under `host` to the dashboard or a backend service.
