use anyhow::Result;
use risc0_zkvm::{default_prover, ExecutorEnv};
use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize)]
struct AuditStatement {
    merkle_root: String,
    range_start: String,
    range_end: String,
    disclosed_fields: Vec<String>,
    passed_rules: Vec<String>,
}

fn main() -> Result<()> {
    let statement = AuditStatement {
        merkle_root: "replace-with-real-root".to_owned(),
        range_start: "2025-02-18T09:00:00Z".to_owned(),
        range_end: "2025-02-18T12:00:00Z".to_owned(),
        disclosed_fields: vec!["approvalRef".to_owned(), "control".to_owned()],
        passed_rules: vec!["retention-window".to_owned(), "restricted-review".to_owned()],
    };

    let env = ExecutorEnv::builder().write(&statement)?.build()?;
    let _prover = default_prover();

    // The actual prove call depends on the built guest ELF/image ID.
    println!("Prepared host env for statement: {:?}", env.input_digest());
    Ok(())
}
