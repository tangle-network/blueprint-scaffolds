# ZK Audit Trail

Vite + React dashboard for privacy-preserving audit logging with:

- Merkle-based tamper evidence
- policy compliance verification
- selective disclosure views
- time-range inclusion proofs
- RISC Zero receipt modeling
- Solidity contracts for registry, attestations, and multi-party coordination

## Commands

```bash
pnpm install
pnpm build
pnpm dev
```

## Structure

- `src/`: React dashboard and proof assembly logic
- `contracts/`: Solidity contracts for anchor publication and attestations
- `risc0/`: reference Rust guest and host for integrating real receipts
