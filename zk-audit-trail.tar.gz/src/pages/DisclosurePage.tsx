import { useState } from 'react';
import { Eye, Lock, Unlock, Clock, UserX } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { defaultDisclosureRequests, defaultLogs } from '@/lib/data';
import { formatDate, statusColor } from '@/lib/utils';
import type { SelectiveDisclosureRequest } from '@/lib/types';

export default function DisclosurePage() {
  const [selected, setSelected] = useState<SelectiveDisclosureRequest | null>(null);

  const approved = defaultDisclosureRequests.filter(r => r.status === 'approved').length;
  const pending = defaultDisclosureRequests.filter(r => r.status === 'pending').length;
  const denied = defaultDisclosureRequests.filter(r => r.status === 'denied').length;

  const statusIcons: Record<string, React.ReactNode> = {
    approved: <Unlock className="h-5 w-5 text-emerald-400" />,
    pending: <Clock className="h-5 w-5 text-amber-400" />,
    denied: <UserX className="h-5 w-5 text-red-400" />,
    expired: <Clock className="h-5 w-5 text-gray-400" />,
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Selective Disclosure</h1>
          <p className="text-muted-foreground mt-1">ZK-proof-backed data sharing with field-level control</p>
        </div>
        <Button size="sm">
          <Eye className="h-4 w-4 mr-2" />
          New Request
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Requests</p>
              <p className="text-3xl font-bold mt-1">{defaultDisclosureRequests.length}</p>
            </div>
            <div className="rounded-full p-3 bg-blue-500/20 text-blue-400">
              <Eye className="h-6 w-6" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Approved</p>
              <p className="text-3xl font-bold mt-1 text-emerald-400">{approved}</p>
            </div>
            <div className="rounded-full p-3 bg-emerald-500/20 text-emerald-400">
              <Unlock className="h-6 w-6" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Pending</p>
              <p className="text-3xl font-bold mt-1 text-amber-400">{pending}</p>
            </div>
            <div className="rounded-full p-3 bg-amber-500/20 text-amber-400">
              <Clock className="h-6 w-6" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Denied</p>
              <p className="text-3xl font-bold mt-1 text-red-400">{denied}</p>
            </div>
            <div className="rounded-full p-3 bg-red-500/20 text-red-400">
              <UserX className="h-6 w-6" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Disclosure Requests</CardTitle>
          <CardDescription>Manage selective data access with zero-knowledge proofs</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {defaultDisclosureRequests.map((req) => {
              const log = defaultLogs.find(l => l.id === req.logEntryId);
              return (
                <div
                  key={req.id}
                  onClick={() => setSelected(req)}
                  className="flex items-center justify-between p-4 rounded-md bg-muted/30 hover:bg-muted/50 cursor-pointer transition-colors border border-transparent hover:border-border"
                >
                  <div className="flex items-center gap-4">
                    <div className={`rounded-full p-2 ${
                      req.status === 'approved' ? 'bg-emerald-500/20' :
                      req.status === 'pending' ? 'bg-amber-500/20' :
                      req.status === 'denied' ? 'bg-red-500/20' : 'bg-gray-500/20'
                    }`}>
                      {statusIcons[req.status]}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium">{req.requester}</p>
                        <Badge className={statusColor(req.status)}>{req.status}</Badge>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        Requesting fields: {req.fields.join(', ')} from {req.logEntryId}
                        {log && ` (${log.eventType})`}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">Created {formatDate(req.createdAt)}</p>
                    <p className="text-xs text-muted-foreground">
                      {req.expiresAt > Date.now()
                        ? `Expires ${formatDate(req.expiresAt)}`
                        : 'Expired'
                      }
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {selected && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center" onClick={() => setSelected(null)}>
          <div className="bg-background border rounded-lg p-6 max-w-lg w-full mx-4" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Lock className="h-5 w-5 text-primary" />
                Disclosure Request
              </h2>
              <Badge className={statusColor(selected.status)}>{selected.status}</Badge>
            </div>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <label className="text-xs text-muted-foreground">Requester</label>
                  <p className="font-medium">{selected.requester}</p>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">Log Entry</label>
                  <p className="font-mono text-sm">{selected.logEntryId}</p>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">Created</label>
                  <p>{formatDate(selected.createdAt)}</p>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">Expires</label>
                  <p>{formatDate(selected.expiresAt)}</p>
                </div>
              </div>
              <div>
                <label className="text-xs text-muted-foreground">Requested Fields</label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {selected.fields.map((f) => (
                    <Badge key={f} variant="outline">{f}</Badge>
                  ))}
                </div>
              </div>
              {selected.proof && (
                <div>
                  <label className="text-xs text-muted-foreground">ZK Proof</label>
                  <div className="bg-muted p-2 rounded mt-1 text-xs">
                    <Badge className="proof-badge-verified">Verified</Badge>
                    <p className="mt-1 font-mono">ID: {selected.proof.id}</p>
                  </div>
                </div>
              )}
              {selected.status === 'pending' && (
                <div className="flex gap-2 pt-2">
                  <Button size="sm" className="flex-1">Approve</Button>
                  <Button size="sm" variant="destructive" className="flex-1">Deny</Button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
