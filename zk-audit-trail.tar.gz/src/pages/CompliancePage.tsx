import { useState } from 'react';
import { Shield, Eye, CheckCircle2, XCircle, Clock, FileText } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { defaultPolicies, defaultAttestations } from '@/lib/data';
import { formatDate, statusColor } from '@/lib/utils';
import type { CompliancePolicy, ComplianceAttestation } from '@/lib/types';

export default function CompliancePage() {
  const [selectedPolicy, setSelectedPolicy] = useState<CompliancePolicy | null>(null);
  const [selectedAtt, setSelectedAtt] = useState<ComplianceAttestation | null>(null);

  const compliant = defaultAttestations.filter((a) => a.status === 'compliant').length;
  const pending = defaultAttestations.filter((a) => a.status === 'pending').length;
  const nonCompliant = defaultAttestations.filter((a) => a.status === 'non-compliant').length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Compliance</h1>
          <p className="text-muted-foreground mt-1">Policy management and compliance attestations</p>
        </div>
        <Button>
          <Shield className="h-4 w-4 mr-2" />
          Create Policy
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="rounded-full p-3 bg-emerald-500/20">
              <CheckCircle2 className="h-6 w-6 text-emerald-400" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Compliant</p>
              <p className="text-2xl font-bold text-emerald-400">{compliant}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="rounded-full p-3 bg-amber-500/20">
              <Clock className="h-6 w-6 text-amber-400" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Pending</p>
              <p className="text-2xl font-bold text-amber-400">{pending}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="rounded-full p-3 bg-red-500/20">
              <XCircle className="h-6 w-6 text-red-400" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Non-Compliant</p>
              <p className="text-2xl font-bold text-red-400">{nonCompliant}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="rounded-full p-3 bg-blue-500/20">
              <FileText className="h-6 w-6 text-blue-400" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Active Policies</p>
              <p className="text-2xl font-bold">{defaultPolicies.filter((p) => p.active).length}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="policies">
        <TabsList>
          <TabsTrigger value="policies">Policies</TabsTrigger>
          <TabsTrigger value="attestations">Attestations</TabsTrigger>
        </TabsList>

        <TabsContent value="policies" className="space-y-4">
          {defaultPolicies.map((policy) => (
            <Card
              key={policy.id}
              className="cursor-pointer hover:bg-muted/30 transition-colors"
              onClick={() => setSelectedPolicy(policy)}
            >
              <CardContent className="p-5">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4">
                    <div className="rounded-full p-2 bg-primary/10 mt-0.5">
                      <Shield className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold">{policy.name}</h3>
                        <Badge variant="outline">{policy.category}</Badge>
                        {policy.active && (
                          <Badge className="proof-badge-verified">Active</Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{policy.description}</p>
                      <div className="flex gap-4 mt-2 text-xs text-muted-foreground">
                        <span>{policy.rules.length} rule(s)</span>
                        <span>Created {formatDate(policy.createdAt)}</span>
                      </div>
                    </div>
                  </div>
                  <Badge variant="outline">{policy.id}</Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="attestations" className="space-y-4">
          {defaultAttestations.map((att) => (
            <Card
              key={att.id}
              className="cursor-pointer hover:bg-muted/30 transition-colors"
              onClick={() => setSelectedAtt(att)}
            >
              <CardContent className="p-5">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4">
                    <div className={`rounded-full p-2 mt-0.5 ${
                      att.status === 'compliant' ? 'bg-emerald-500/20' :
                      att.status === 'pending' ? 'bg-amber-500/20' : 'bg-red-500/20'
                    }`}>
                      {att.status === 'compliant' ? (
                        <CheckCircle2 className="h-5 w-5 text-emerald-400" />
                      ) : att.status === 'pending' ? (
                        <Clock className="h-5 w-5 text-amber-400" />
                      ) : (
                        <XCircle className="h-5 w-5 text-red-400" />
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold">{att.policyId}</h3>
                        <Badge className={statusColor(att.status)}>{att.status}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{att.notes}</p>
                      <div className="flex gap-4 mt-2 text-xs text-muted-foreground">
                        <span>Attester: {att.attester}</span>
                        <span>{att.logEntryIds.length} log(s)</span>
                        <span>{formatDate(att.attestedAt)}</span>
                      </div>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon">
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>

      <Dialog open={!!selectedPolicy} onOpenChange={() => setSelectedPolicy(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              {selectedPolicy?.name}
            </DialogTitle>
            <DialogDescription>{selectedPolicy?.description}</DialogDescription>
          </DialogHeader>
          {selectedPolicy && (
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="text-xs text-muted-foreground">Category</span>
                  <p><Badge variant="outline">{selectedPolicy.category}</Badge></p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground">Status</span>
                  <p>{selectedPolicy.active ? <Badge className="proof-badge-verified">Active</Badge> : <Badge variant="secondary">Inactive</Badge>}</p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground">Created</span>
                  <p>{formatDate(selectedPolicy.createdAt)}</p>
                </div>
              </div>
              <div>
                <h4 className="text-sm font-medium mb-2">Policy Rules ({selectedPolicy.rules.length})</h4>
                <div className="space-y-2">
                  {selectedPolicy.rules.map((rule) => (
                    <div key={rule.id} className="flex items-center justify-between p-3 rounded-md bg-muted/50 text-sm">
                      <div className="flex items-center gap-3">
                        <Badge className={statusColor(rule.severity)}>{rule.severity}</Badge>
                        <span>
                          <code className="text-xs">{rule.field}</code> {rule.operator}{' '}
                          <code className="text-xs">{rule.value}</code>
                        </span>
                      </div>
                      <code className="text-xs text-muted-foreground">{rule.id}</code>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="text-sm font-medium mb-2">Related Attestations</h4>
                <div className="space-y-2">
                  {defaultAttestations
                    .filter((a) => a.policyId === selectedPolicy.id)
                    .map((att) => (
                      <div key={att.id} className="flex items-center justify-between p-2 rounded-md bg-muted/30 text-sm">
                        <div className="flex items-center gap-2">
                          <Badge className={statusColor(att.status)}>{att.status}</Badge>
                          <span className="text-muted-foreground">{att.attester}</span>
                        </div>
                        <span className="text-xs text-muted-foreground">{formatDate(att.attestedAt)}</span>
                      </div>
                    ))}
                  {defaultAttestations.filter((a) => a.policyId === selectedPolicy.id).length === 0 && (
                    <p className="text-sm text-muted-foreground">No attestations for this policy.</p>
                  )}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={!!selectedAtt} onOpenChange={() => setSelectedAtt(null)}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>Attestation — {selectedAtt?.id}</DialogTitle>
            <DialogDescription>Compliance attestation details with ZK proof</DialogDescription>
          </DialogHeader>
          {selectedAtt && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-xs text-muted-foreground">Policy</span>
                  <p className="font-mono">{selectedAtt.policyId}</p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground">Status</span>
                  <p><Badge className={statusColor(selectedAtt.status)}>{selectedAtt.status}</Badge></p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground">Attester</span>
                  <p>{selectedAtt.attester}</p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground">Attested At</span>
                  <p>{formatDate(selectedAtt.attestedAt)}</p>
                </div>
              </div>
              <div>
                <span className="text-xs text-muted-foreground">Log Entries</span>
                <div className="flex gap-2 mt-1">
                  {selectedAtt.logEntryIds.map((id) => (
                    <Badge key={id} variant="outline">{id}</Badge>
                  ))}
                </div>
              </div>
              <div>
                <span className="text-xs text-muted-foreground">Notes</span>
                <p className="text-sm mt-1">{selectedAtt.notes}</p>
              </div>
              <div>
                <span className="text-xs text-muted-foreground">Associated Proof</span>
                <div className="bg-muted p-2 rounded mt-1 text-xs font-mono">
                  {selectedAtt.proof.id} — {selectedAtt.proof.proofType}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
