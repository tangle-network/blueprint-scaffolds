import { useState } from 'react';
import { FileText, Search, Download, RefreshCw } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { defaultLogs } from '@/lib/data';
import { formatDate, formatAddress, severityColor } from '@/lib/utils';
import type { AuditLogEntry } from '@/lib/types';

export default function LogsPage() {
  const [search, setSearch] = useState('');
  const [severityFilter, setSeverityFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [selectedLog, setSelectedLog] = useState<AuditLogEntry | null>(null);

  const filtered = defaultLogs.filter((log) => {
    const matchSearch =
      search === '' ||
      log.actor.toLowerCase().includes(search.toLowerCase()) ||
      log.resource.toLowerCase().includes(search.toLowerCase()) ||
      log.eventType.toLowerCase().includes(search.toLowerCase()) ||
      log.action.toLowerCase().includes(search.toLowerCase());
    const matchSeverity = severityFilter === 'all' || log.severity === severityFilter;
    const matchType = typeFilter === 'all' || log.eventType === typeFilter;
    return matchSearch && matchSeverity && matchType;
  });

  const eventTypes = [...new Set(defaultLogs.map((l) => l.eventType))];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Audit Logs</h1>
          <p className="text-muted-foreground mt-1">{defaultLogs.length} entries ingested and hash-anchored</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by actor, resource, event type..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={severityFilter} onValueChange={setSeverityFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Severity" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Severities</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="low">Low</SelectItem>
              </SelectContent>
            </Select>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Event Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                {eventTypes.map((t) => (
                  <SelectItem key={t} value={t}>{t}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <div className="grid grid-cols-12 gap-2 p-3 text-xs font-medium text-muted-foreground border-b">
              <div className="col-span-1">Severity</div>
              <div className="col-span-2">Event</div>
              <div className="col-span-2">Actor</div>
              <div className="col-span-3">Resource</div>
              <div className="col-span-1">Action</div>
              <div className="col-span-1">Timestamp</div>
              <div className="col-span-2">Data Hash</div>
            </div>
            {filtered.length === 0 && (
              <div className="p-8 text-center text-muted-foreground">No logs match the current filters.</div>
            )}
            {filtered.map((log) => (
              <div
                key={log.id}
                onClick={() => setSelectedLog(log)}
                className="grid grid-cols-12 gap-2 p-3 text-sm items-center hover:bg-muted/50 cursor-pointer transition-colors border-b last:border-0"
              >
                <div className="col-span-1">
                  <Badge className={severityColor(log.severity)}>{log.severity}</Badge>
                </div>
                <div className="col-span-2 font-medium">{log.eventType}</div>
                <div className="col-span-2 text-muted-foreground truncate">{log.actor}</div>
                <div className="col-span-3 font-mono text-xs truncate">{log.resource}</div>
                <div className="col-span-1">{log.action}</div>
                <div className="col-span-1 text-xs text-muted-foreground whitespace-nowrap">
                  {new Date(log.timestamp).toLocaleTimeString()}
                </div>
                <div className="col-span-2 font-mono text-xs text-muted-foreground">
                  {formatAddress(log.dataHash)}
                </div>
              </div>
            ))}
          </div>
          <div className="mt-3 text-sm text-muted-foreground">
            Showing {filtered.length} of {defaultLogs.length} entries
          </div>
        </CardContent>
      </Card>

      <Dialog open={!!selectedLog} onOpenChange={() => setSelectedLog(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              Audit Log Detail — {selectedLog?.id}
            </DialogTitle>
            <DialogDescription>Full entry with metadata and integrity hash</DialogDescription>
          </DialogHeader>
          {selectedLog && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-muted-foreground">Timestamp</label>
                  <p className="text-sm">{formatDate(selectedLog.timestamp)}</p>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">Severity</label>
                  <p><Badge className={severityColor(selectedLog.severity)}>{selectedLog.severity}</Badge></p>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">Event Type</label>
                  <p className="text-sm">{selectedLog.eventType}</p>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">Actor</label>
                  <p className="text-sm">{selectedLog.actor}</p>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">Resource</label>
                  <p className="text-sm font-mono">{selectedLog.resource}</p>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">Action</label>
                  <p className="text-sm">{selectedLog.action}</p>
                </div>
              </div>
              <div>
                <label className="text-xs text-muted-foreground">Data Hash (SHA-256)</label>
                <code className="block text-xs bg-muted p-2 rounded mt-1 break-all">{selectedLog.dataHash}</code>
              </div>
              <div>
                <label className="text-xs text-muted-foreground">Metadata</label>
                <div className="bg-muted p-2 rounded mt-1">
                  {Object.entries(selectedLog.metadata).map(([k, v]) => (
                    <div key={k} className="flex justify-between text-xs py-0.5">
                      <span className="text-muted-foreground">{k}</span>
                      <span className="font-mono">{v}</span>
                    </div>
                  ))}
                </div>
              </div>
              {selectedLog.merkleProof && (
                <div>
                  <label className="text-xs text-muted-foreground">Merkle Proof Path</label>
                  <div className="space-y-1 mt-1">
                    {selectedLog.merkleProof.map((h, i) => (
                      <code key={i} className="block text-xs bg-muted p-1 rounded">{formatAddress(h, 16)}</code>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
