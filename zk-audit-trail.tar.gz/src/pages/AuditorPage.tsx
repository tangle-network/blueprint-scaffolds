import { useState } from 'react';
import { CheckCircle2, Clock, Users, AlertTriangle, Play, FileText } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { defaultSessions, defaultLogs, defaultProofs } from '@/lib/data';
import { formatDate, formatAddress, severityColor, proofTypeLabel, statusColor } from '@/lib/utils';
import type { AuditSession } from '@/lib/types';

export default function AuditorPage() {
  const [selectedSession, setSelectedSession] = useState<AuditSession | null>(null);

  const activeSessions = defaultSessions.filter((s) => s.status === 'active');
  const completedSessions = defaultSessions.filter((s) => s.status === 'completed');
  const disputedSessions = defaultSessions.filter((s) => s.status === 'disputed');
  const totalEntriesReviewed = defaultSessions.reduce((acc, s) => acc + s.entriesReviewed, 0);
  const totalProofsGenerated = defaultSessions.reduce((acc, s) => acc + s.proofsGenerated, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Auditor Verification</h1>
          <p className="text-muted-foreground mt-1">Audit session management and proof verification workflow</p>
        </div>
        <Button>
          <Play className="h-4 w-4 mr-2" />
          Start Session
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="rounded-full p-3 bg-emerald-500/20">
              <CheckCircle2 className="h-6 w-6 text-emerald-400" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Completed</p>
              <p className="text-2xl font-bold text-emerald-400">{completedSessions.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="rounded-full p-3 bg-amber-500/20">
              <Clock className="h-6 w-6 text-amber-400" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Active</p>
              <p className="text-2xl font-bold text-amber-400">{activeSessions.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="rounded-full p-3 bg-blue-500/20">
              <FileText className="h-6 w-6 text-blue-400" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Entries Reviewed</p>
              <p className="text-2xl font-bold">{totalEntriesReviewed}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="rounded-full p-3 bg-purple-500/20">
              <Users className="h-6 w-6 text-purple-400" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Proofs Generated</p>
              <p className="text-2xl font-bold">{totalProofsGenerated}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All Sessions</TabsTrigger>
          <TabsTrigger value="active">Active</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          <SessionList sessions={defaultSessions} onSelect={setSelectedSession} />
        </TabsContent>
        <TabsContent value="active">
          <SessionList sessions={activeSessions} onSelect={setSelectedSession} />
        </TabsContent>
        <TabsContent value="completed">
          <SessionList sessions={completedSessions} onSelect={setSelectedSession} />
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Verification Queue</CardTitle>
          <CardDescription>Proofs awaiting auditor verification</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {defaultProofs
              .filter((p) => !p.verified)
              .map((proof) => (
                <div key={proof.id} className="flex items-center justify-between p-3 rounded-md bg-muted/30">
                  <div className="flex items-center gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-400" />
                    <div>
                      <p className="text-sm font-medium">{proofTypeLabel(proof.proofType)}</p>
                      <p className="text-xs text-muted-foreground">Entry: {proof.logEntryId}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">{formatDate(proof.createdAt)}</span>
                    <Button size="sm" variant="outline">Verify</Button>
                  </div>
                </div>
              ))}
            {defaultProofs.filter((p) => !p.verified).length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-4">All proofs have been verified.</p>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Recent Audit Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {defaultLogs.slice(-5).reverse().map((log) => (
              <div key={log.id} className="flex items-center justify-between p-3 rounded-md bg-muted/30">
                <div className="flex items-center gap-3">
                  <Badge className={severityColor(log.severity)}>{log.severity}</Badge>
                  <div>
                    <p className="text-sm">{log.eventType} — {log.action}</p>
                    <p className="text-xs text-muted-foreground">{log.actor}</p>
                  </div>
                </div>
                <span className="text-xs text-muted-foreground">{formatDate(log.timestamp)}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Dialog open={!!selectedSession} onOpenChange={() => setSelectedSession(null)}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Users className="h-5 w-5 text-primary" />
              Session — {selectedSession?.id}
            </DialogTitle>
            <DialogDescription>Audit session details</DialogDescription>
          </DialogHeader>
          {selectedSession && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-xs text-muted-foreground">Auditor</span>
                  <p>{selectedSession.auditor}</p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground">Status</span>
                  <p><Badge className={statusColor(selectedSession.status)}>{selectedSession.status}</Badge></p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground">Started</span>
                  <p>{formatDate(selectedSession.startedAt)}</p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground">Ended</span>
                  <p>{selectedSession.endedAt ? formatDate(selectedSession.endedAt) : '—'}</p>
                </div>
              </div>
              <div>
                <span className="text-xs text-muted-foreground">Progress</span>
                <div className="mt-2 space-y-2">
                  <div className="flex justify-between text-xs">
                    <span>Entries Reviewed</span>
                    <span>{selectedSession.entriesReviewed}</span>
                  </div>
                  <Progress value={Math.min(selectedSession.entriesReviewed, 100)} />
                  <div className="flex justify-between text-xs">
                    <span>Proofs Generated</span>
                    <span>{selectedSession.proofsGenerated}</span>
                  </div>
                  <Progress value={Math.min(selectedSession.proofsGenerated * 5, 100)} />
                  <div className="flex justify-between text-xs">
                    <span>Attestations</span>
                    <span>{selectedSession.attestations}</span>
                  </div>
                  <Progress value={Math.min(selectedSession.attestations * 10, 100)} />
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function SessionList({ sessions, onSelect }: { sessions: AuditSession[]; onSelect: (s: AuditSession) => void }) {
  if (sessions.length === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center text-muted-foreground">No sessions found.</CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      {sessions.map((session) => {
        const duration = session.endedAt
          ? Math.round((session.endedAt - session.startedAt) / 60000)
          : Math.round((Date.now() - session.startedAt) / 60000);

        return (
          <Card
            key={session.id}
            className="cursor-pointer hover:bg-muted/30 transition-colors"
            onClick={() => onSelect(session)}
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={`rounded-full p-2 ${
                    session.status === 'active' ? 'bg-amber-500/20' :
                    session.status === 'completed' ? 'bg-emerald-500/20' : 'bg-red-500/20'
                  }`}>
                    {session.status === 'active' ? (
                      <Clock className="h-5 w-5 text-amber-400" />
                    ) : (
                      <CheckCircle2 className="h-5 w-5 text-emerald-400" />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-medium">{session.auditor}</p>
                      <Badge className={statusColor(session.status)}>{session.status}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mt-0.5">
                      {session.entriesReviewed} entries &middot; {session.proofsGenerated} proofs &middot; {session.attestations} attestations &middot; {duration}min
                    </p>
                  </div>
                </div>
                <code className="text-xs text-muted-foreground">{formatAddress(session.id, 6)}</code>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
