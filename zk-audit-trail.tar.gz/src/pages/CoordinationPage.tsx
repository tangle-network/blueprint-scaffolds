import { useState } from 'react';
import { Users, CheckCircle2, Clock, XCircle, ArrowRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { defaultCoordination } from '@/lib/data';
import { formatDate, formatAddress, statusColor } from '@/lib/utils';
import type { MultiPartyCoordination } from '@/lib/types';

export default function CoordinationPage() {
  const [selected, setSelected] = useState<MultiPartyCoordination | null>(null);

  const approved = defaultCoordination.filter(c => c.status === 'approved').length;
  const pending = defaultCoordination.filter(c => c.status === 'pending').length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Multi-Party Coordination</h1>
          <p className="text-muted-foreground mt-1">Threshold approval workflows for sensitive operations</p>
        </div>
        <Button size="sm">
          <Users className="h-4 w-4 mr-2" />
          New Request
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Requests</p>
              <p className="text-3xl font-bold mt-1">{defaultCoordination.length}</p>
            </div>
            <div className="rounded-full p-3 bg-blue-500/20 text-blue-400">
              <Users className="h-6 w-6" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Approved</p>
              <p className="text-3xl font-bold mt-1 text-emerald-400">{approved}</p>
            </div>
            <div className="rounded-full p-3 bg-emerald-500/20 text-emerald-400">
              <CheckCircle2 className="h-6 w-6" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Pending</p>
              <p className="text-3xl font-bold mt-1 text-amber-400">{pending}</p>
            </div>
            <div className="rounded-full p-3 bg-amber-500/20 text-amber-400">
              <Clock className="h-6 w-6" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-4">
        {defaultCoordination.map((coord) => (
          <Card
            key={coord.id}
            className="cursor-pointer hover:border-primary/50 transition-colors"
            onClick={() => setSelected(coord)}
          >
            <CardContent className="p-5">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <Badge className={statusColor(coord.status)}>{coord.status}</Badge>
                    <span className="text-sm font-medium">{coord.action}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Created {formatDate(coord.createdAt)} — Requires {coord.requiredApprovals} of {coord.parties.length} approvals
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium">{coord.approvals.length} / {coord.requiredApprovals}</p>
                  <Progress
                    value={(coord.approvals.length / coord.requiredApprovals) * 100}
                    className="w-24 mt-1"
                  />
                </div>
              </div>

              <div className="mt-4 flex items-center gap-2">
                {coord.parties.map((party, idx) => {
                  const approval = coord.approvals.find(a => a.partyId === party.id);
                  const hasApproved = approval?.approved;
                  return (
                    <div key={party.id} className="flex items-center gap-1">
                      {idx > 0 && <ArrowRight className="h-3 w-3 text-muted-foreground" />}
                      <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs ${
                        hasApproved
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : 'bg-muted text-muted-foreground'
                      }`}>
                        {hasApproved
                          ? <CheckCircle2 className="h-3 w-3" />
                          : <Clock className="h-3 w-3" />
                        }
                        {party.name}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {selected && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center" onClick={() => setSelected(null)}>
          <div className="bg-background border rounded-lg p-6 max-w-lg w-full mx-4" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Multi-Party Request</h2>
              <Badge className={statusColor(selected.status)}>{selected.status}</Badge>
            </div>
            <div className="space-y-4 text-sm">
              <div>
                <label className="text-xs text-muted-foreground">Action</label>
                <p className="font-medium">{selected.action}</p>
              </div>
              <div>
                <label className="text-xs text-muted-foreground">Approval Progress</label>
                <div className="mt-1">
                  <div className="flex justify-between text-xs mb-1">
                    <span>{selected.approvals.length} approved</span>
                    <span>{selected.requiredApprovals} required</span>
                  </div>
                  <Progress value={(selected.approvals.length / selected.requiredApprovals) * 100} />
                </div>
              </div>
              <div>
                <label className="text-xs text-muted-foreground">Parties & Approvals</label>
                <div className="space-y-2 mt-2">
                  {selected.parties.map((party) => {
                    const approval = selected.approvals.find(a => a.partyId === party.id);
                    return (
                      <div key={party.id} className="flex items-center justify-between p-3 bg-muted rounded">
                        <div>
                          <p className="font-medium">{party.name}</p>
                          <p className="text-xs text-muted-foreground">{party.role}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          {approval ? (
                            <>
                              <Badge className={approval.approved ? 'proof-badge-verified' : 'proof-badge-failed'}>
                                {approval.approved ? 'Approved' : 'Rejected'}
                              </Badge>
                              <span className="text-xs text-muted-foreground">{formatDate(approval.timestamp)}</span>
                            </>
                          ) : (
                            <Badge variant="outline">Pending</Badge>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
              <div>
                <label className="text-xs text-muted-foreground">Created</label>
                <p>{formatDate(selected.createdAt)}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
