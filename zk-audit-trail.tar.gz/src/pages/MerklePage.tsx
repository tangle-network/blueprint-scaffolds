import { TreePine, CheckCircle2, Layers } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { defaultLogs } from '@/lib/data';
import { formatAddress } from '@/lib/utils';
import { MerkleTree } from '@/lib/merkle';

export default function MerklePage() {
  const tree = new MerkleTree(defaultLogs.map(l => l.dataHash));
  const root = tree.getRoot();
  const leaves = tree.getLeaves();
  const levels = tree.getLevels();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Merkle Evidence</h1>
          <p className="text-muted-foreground mt-1">Audit log Merkle tree visualization and inclusion proofs</p>
        </div>
        <Button size="sm">
          <TreePine className="h-4 w-4 mr-2" />
          Rebuild Tree
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Leaves</p>
              <p className="text-3xl font-bold mt-1">{tree.getSize()}</p>
            </div>
            <div className="rounded-full p-3 bg-blue-500/20 text-blue-400">
              <Layers className="h-6 w-6" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Height</p>
              <p className="text-3xl font-bold mt-1">{tree.getHeight()}</p>
            </div>
            <div className="rounded-full p-3 bg-purple-500/20 text-purple-400">
              <TreePine className="h-6 w-6" />
            </div>
          </CardContent>
        </Card>
        <Card className="md:col-span-2">
          <CardContent className="p-6">
            <p className="text-sm text-muted-foreground mb-1">Root Hash</p>
            <code className="text-xs bg-muted p-2 rounded block break-all">{root}</code>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Tree Structure</CardTitle>
          <CardDescription>Merkle tree levels from leaves to root</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {levels.map((level, levelIdx) => (
              <div key={levelIdx}>
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="outline" className="text-xs">
                    Level {levelIdx === levels.length - 1 ? '(Root)' : levelIdx}
                  </Badge>
                  <span className="text-xs text-muted-foreground">{level.length} node(s)</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {level.map((hash, nodeIdx) => (
                    <div
                      key={nodeIdx}
                      className={`px-3 py-2 rounded text-xs font-mono bg-muted/50 border ${
                        levelIdx === levels.length - 1
                          ? 'border-primary/50 bg-primary/10'
                          : 'border-border'
                      }`}
                    >
                      {formatAddress(hash, 8)}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Leaf Entries & Inclusion Proofs</CardTitle>
          <CardDescription>Merkle proof for each audit log entry</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {defaultLogs.map((log, idx) => {
              const proof = tree.getProof(idx);
              const verified = tree.verify(log.dataHash, proof, root);
              return (
                <div key={log.id} className="p-4 rounded-md bg-muted/30">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">{log.id}</Badge>
                      <span className="text-sm">{log.eventType}</span>
                    </div>
                    <Badge className={verified ? 'proof-badge-verified' : 'proof-badge-failed'}>
                      {verified ? 'Verified' : 'Invalid'}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span>Leaf:</span>
                    <code className="bg-muted px-1 rounded">{formatAddress(leaves[idx], 12)}</code>
                    <span className="mx-1">→</span>
                    <span>Proof ({proof.length} siblings):</span>
                    {proof.map((h, i) => (
                      <code key={i} className="bg-muted px-1 rounded">{formatAddress(h, 6)}</code>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
