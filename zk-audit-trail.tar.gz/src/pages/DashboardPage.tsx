import { useState } from 'react';
import {
  FileText, Shield, CheckCircle2, Activity, Lock, TrendingUp, Users, TreePine,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { defaultStats, defaultLogs, defaultProofs, defaultSessions, defaultAttestations } from '@/lib/data';
import { formatDate, formatAddress, severityColor, statusColor, proofTypeLabel } from '@/lib/utils';

function StatCard({ icon: Icon, label, value, sub, color }: {
  icon: React.ElementType; label: string; value: string | number; sub?: string; color: string;
}) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">{label}</p>
            <p className="text-3xl font-bold mt-1">{value}</p>
            {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
          </div>
          <div className={`rounded-full p-3 ${color}`}>
            <Icon className="h-6 w-6" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function DashboardPage() {
  const [tab, setTab] = useState('overview');
  const recentLogs = defaultLogs.slice(-5).reverse();
  const recentProofs = defaultProofs.slice(-3).reverse();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground mt-1">ZK Audit Trail — RISC Zero Verified Logging</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge className="proof-badge-verified">RISC Zero Active</Badge>
          <Badge variant="outline">Image: a3f7...c2d1</Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={FileText} label="Total Audit Logs" value={defaultStats.totalLogs} sub="+3 today" color="bg-blue-500/20 text-blue-400" />
        <StatCard icon={Shield} label="Verified Proofs" value={defaultStats.verifiedProofs} sub={`${defaultStats.pendingProofs} pending`} color="bg-emerald-500/20 text-emerald-400" />
        <StatCard icon={TrendingUp} label="Compliance Rate" value={`${(defaultStats.complianceRate * 100).toFixed(0)}%`} sub="4 active policies" color="bg-purple-500/20 text-purple-400" />
        <StatCard icon={Users} label="Active Sessions" value={defaultStats.activeSessions} sub={`${defaultSessions.length} total`} color="bg-amber-500/20 text-amber-400" />
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="logs">Recent Logs</TabsTrigger>
          <TabsTrigger value="proofs">Latest Proofs</TabsTrigger>
          <TabsTrigger value="attestations">Attestations</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  System Health
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Proof Verification</span>
                    <span className="text-emerald-400">{((defaultStats.verifiedProofs / Math.max(defaultProofs.length, 1)) * 100).toFixed(0)}%</span>
                  </div>
                  <Progress value={(defaultStats.verifiedProofs / Math.max(defaultProofs.length, 1)) * 100} />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Compliance Rate</span>
                    <span className="text-purple-400">{(defaultStats.complianceRate * 100).toFixed(0)}%</span>
                  </div>
                  <Progress value={defaultStats.complianceRate * 100} />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Log Integrity</span>
                    <span className="text-blue-400">100%</span>
                  </div>
                  <Progress value={100} />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <TreePine className="h-5 w-5 text-primary" />
                  Merkle Tree
                </CardTitle>
                <CardDescription>Current audit log tree state</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Root Hash</span>
                  <code className="text-xs bg-muted px-2 py-1 rounded">{defaultStats.merkleRoot}</code>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Total Leaves</span>
                  <span>{defaultStats.totalLogs}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Tree Height</span>
                  <span>{Math.ceil(Math.log2(Math.max(defaultStats.totalLogs, 1))) + 1}</span>
                </div>
                <div className="mt-4 p-3 rounded-md bg-muted/50 text-xs font-mono">
                  <div className="text-center text-muted-foreground mb-2">Merkle Root</div>
                  <div className="flex justify-center gap-2">
                    <div className="merkle-node" />
                    <div className="merkle-node" />
                  </div>
                  <div className="merkle-line w-32 mx-auto my-1" />
                  <div className="flex justify-center gap-2">
                    <div className="merkle-node" />
                    <div className="merkle-node" />
                    <div className="merkle-node" />
                    <div className="merkle-node" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Lock className="h-5 w-5 text-primary" />
                RISC Zero Guest Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Image ID</span>
                  <p className="font-mono text-xs mt-1">a3f7...c2d1</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Method</span>
                  <p className="mt-1">poseidon2</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Cycle Count</span>
                  <p className="mt-1">~2.4M</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Status</span>
                  <p className="mt-1"><Badge className="proof-badge-verified">Active</Badge></p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="logs">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Recent Audit Logs</CardTitle>
                <Button variant="outline" size="sm" asChild>
                  <a href="/logs">View All</a>
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentLogs.map((log) => (
                  <div key={log.id} className="flex items-center justify-between p-3 rounded-md bg-muted/30 hover:bg-muted/50 transition-colors">
                    <div className="flex items-center gap-3">
                      <Badge className={severityColor(log.severity)}>{log.severity}</Badge>
                      <div>
                        <p className="text-sm font-medium">{log.eventType} — {log.action}</p>
                        <p className="text-xs text-muted-foreground">{log.actor} → {log.resource}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground">{formatDate(log.timestamp)}</p>
                      <code className="text-xs text-muted-foreground">{formatAddress(log.dataHash)}</code>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="proofs">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Latest ZK Proofs</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentProofs.map((proof) => (
                  <div key={proof.id} className="flex items-center justify-between p-3 rounded-md bg-muted/30">
                    <div className="flex items-center gap-3">
                      <Badge className={proof.verified ? 'proof-badge-verified' : 'proof-badge-pending'}>
                        {proof.verified ? 'Verified' : 'Pending'}
                      </Badge>
                      <div>
                        <p className="text-sm font-medium">{proofTypeLabel(proof.proofType)}</p>
                        <p className="text-xs text-muted-foreground">Entry: {proof.logEntryId}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground">{formatDate(proof.createdAt)}</p>
                      {proof.riscZeroReceipt && (
                        <code className="text-xs text-muted-foreground">Seal: {formatAddress(proof.riscZeroReceipt.seal)}</code>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="attestations">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Compliance Attestations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {defaultAttestations.map((att) => (
                  <div key={att.id} className="flex items-center justify-between p-3 rounded-md bg-muted/30">
                    <div className="flex items-center gap-3">
                      <Badge className={statusColor(att.status)}>{att.status}</Badge>
                      <div>
                        <p className="text-sm font-medium">{att.policyId}</p>
                        <p className="text-xs text-muted-foreground">{att.attester}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground">{formatDate(att.attestedAt)}</p>
                      <p className="text-xs text-muted-foreground">{att.logEntryIds.length} log(s)</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
