import { useState } from 'react';
import { Clock, Calendar, CheckCircle2, AlertTriangle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { defaultProofs, defaultLogs } from '@/lib/data';
import { formatDate, formatAddress, proofTypeLabel } from '@/lib/utils';

export default function TimeRangePage() {
  const timeProofs = defaultProofs.filter(p => p.proofType === 'time_range');

  const now = Date.now();
  const HOUR = 3600000;
  const ranges = [
    { label: 'Last Hour', start: now - HOUR, end: now },
    { label: 'Last 6 Hours', start: now - 6 * HOUR, end: now },
    { label: 'Last 24 Hours', start: now - 24 * HOUR, end: now },
    { label: 'Last 7 Days', start: now - 7 * 24 * HOUR, end: now },
  ];

  const rangeCounts = ranges.map(r => ({
    ...r,
    count: defaultLogs.filter(l => l.timestamp >= r.start && l.timestamp <= r.end).length,
    criticalCount: defaultLogs.filter(l => l.timestamp >= r.start && l.timestamp <= r.end && l.severity === 'critical').length,
  }));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Time Range Proofs</h1>
          <p className="text-muted-foreground mt-1">Zero-knowledge proofs of event timing without revealing exact timestamps</p>
        </div>
        <Button size="sm">
          <Clock className="h-4 w-4 mr-2" />
          Generate Time Proof
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Time Range Proofs</p>
              <p className="text-3xl font-bold mt-1">{timeProofs.length}</p>
            </div>
            <div className="rounded-full p-3 bg-blue-500/20 text-blue-400">
              <Clock className="h-6 w-6" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Verified</p>
              <p className="text-3xl font-bold mt-1 text-emerald-400">{timeProofs.filter(p => p.verified).length}</p>
            </div>
            <div className="rounded-full p-3 bg-emerald-500/20 text-emerald-400">
              <CheckCircle2 className="h-6 w-6" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Coverage</p>
              <p className="text-3xl font-bold mt-1">100%</p>
            </div>
            <div className="rounded-full p-3 bg-purple-500/20 text-purple-400">
              <Calendar className="h-6 w-6" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Time Range Analysis</CardTitle>
          <CardDescription>Event distribution across time ranges</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {rangeCounts.map((range) => (
              <div key={range.label} className="p-4 rounded-md bg-muted/30">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">{range.label}</span>
                    {range.criticalCount > 0 && (
                      <Badge className="text-red-400 bg-red-500/20 border-red-500/30">{range.criticalCount} critical</Badge>
                    )}
                  </div>
                  <span className="text-sm text-muted-foreground">{range.count} events</span>
                </div>
                <Progress value={range.count > 0 ? (range.count / defaultLogs.length) * 100 : 0} />
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>{formatDate(range.start)}</span>
                  <span>{formatDate(range.end)}</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Time Range Proof Details</CardTitle>
        </CardHeader>
        <CardContent>
          {timeProofs.length === 0 ? (
            <p className="text-muted-foreground text-sm">No time range proofs generated yet.</p>
          ) : (
            <div className="space-y-3">
              {timeProofs.map((proof) => {
                const log = defaultLogs.find(l => l.id === proof.logEntryId);
                return (
                  <div key={proof.id} className="flex items-center justify-between p-4 rounded-md bg-muted/30">
                    <div className="flex items-center gap-3">
                      <div className={`rounded-full p-2 ${proof.verified ? 'bg-emerald-500/20' : 'bg-amber-500/20'}`}>
                        {proof.verified
                          ? <CheckCircle2 className="h-5 w-5 text-emerald-400" />
                          : <AlertTriangle className="h-5 w-5 text-amber-400" />
                        }
                      </div>
                      <div>
                        <p className="text-sm font-medium">{proof.logEntryId}</p>
                        <p className="text-xs text-muted-foreground">
                          {log ? `${log.eventType} — ${log.actor}` : 'Unknown entry'}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge className={proof.verified ? 'proof-badge-verified' : 'proof-badge-pending'}>
                        {proof.verified ? 'Within Range' : 'Out of Range'}
                      </Badge>
                      <p className="text-xs text-muted-foreground mt-1">{formatDate(proof.createdAt)}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
