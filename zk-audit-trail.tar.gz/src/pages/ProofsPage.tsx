import { useState } from 'react';
import { Shield, CheckCircle2, Clock, AlertTriangle, Eye } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { defaultProofs } from '@/lib/data';
import { formatDate, formatAddress, proofTypeLabel } from '@/lib/utils';
import type { ZKProof } from '@/lib/types';

export default function ProofsPage() {
  const [typeFilter, setTypeFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedProof, setSelectedProof] = useState<ZKProof | null>(null);

  const filtered = defaultProofs.filter((p) => {
    const matchType = typeFilter === 'all' || p.proofType === typeFilter;
    const matchStatus =
      statusFilter === 'all' ||
      (statusFilter === 'verified' && p.verified) ||
      (statusFilter === 'pending' && !p.verified);
    return matchType && matchStatus;
  });

  const verified = defaultProofs.filter((p) => p.verified).length;
  const pending = defaultProofs.filter((p) => !p.verified).length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Proof Generation</h1>
          <p className="text-muted-foreground mt-1">Zero-knowledge proofs generated via RISC Zero guest program</p>
        </div>
        <Button>
          <Shield className="h-4 w-4 mr-2" />
          Generate Proof
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="rounded-full p-3 bg-emerald-500/20">
              <CheckCircle2 className="h-6 w-6 text-emerald-400" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Verified</p>
              <p className="text-2xl font-bold text-emerald-400">{verified}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="rounded-full p-3 bg-amber-500/20">
              <Clock className="h-6 w-6 text-amber-400" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Pending</p>
              <p className="text-2xl font-bold text-amber-400">{pending}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="rounded-full p-3 bg-blue-500/20">
              <Shield className="h-6 w-6 text-blue-400" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total</p>
              <p className="text-2xl font-bold">{defaultProofs.length}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all">
        <div className="flex items-center justify-between mb-4">
          <TabsList>
            <TabsTrigger value="all">All Proofs</TabsTrigger>
            <TabsTrigger value="verified">Verified</TabsTrigger>
            <TabsTrigger value="pending">Pending</TabsTrigger>
          </TabsList>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-52">
              <SelectValue placeholder="Proof Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="log_integrity">Log Integrity</SelectItem>
              <SelectItem value="policy_compliance">Policy Compliance</SelectItem>
              <SelectItem value="selective_disclosure">Selective Disclosure</SelectItem>
              <SelectItem value="time_range">Time Range</SelectItem>
              <SelectItem value="merkle_inclusion">Merkle Inclusion</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <TabsContent value="all">
          <ProofList proofs={filtered} onSelect={setSelectedProof} />
        </TabsContent>
        <TabsContent value="verified">
          <ProofList proofs={filtered.filter((p) => p.verified)} onSelect={setSelectedProof} />
        </TabsContent>
        <TabsContent value="pending">
          <ProofList proofs={filtered.filter((p) => !p.verified)} onSelect={setSelectedProof} />
        </TabsContent>
      </Tabs>

      <Dialog open={!!selectedProof} onOpenChange={() => setSelectedProof(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              Proof Detail — {selectedProof?.id}
            </DialogTitle>
            <DialogDescription>RISC Zero receipt and verification details</DialogDescription>
          </DialogHeader>
          {selectedProof && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-muted-foreground">Proof Type</label>
                  <p className="text-sm font-medium">{proofTypeLabel(selectedProof.proofType)}</p>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">Status</label>
                  <p>
                    <Badge className={selectedProof.verified ? 'proof-badge-verified' : 'proof-badge-pending'}>
                      {selectedProof.verified ? 'Verified' : 'Pending'}
                    </Badge>
                  </p>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">Log Entry</label>
                  <p className="text-sm font-mono">{selectedProof.logEntryId}</p>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">Created</label>
                  <p className="text-sm">{formatDate(selectedProof.createdAt)}</p>
                </div>
                {selectedProof.verifiedAt && (
                  <div>
                    <label className="text-xs text-muted-foreground">Verified At</label>
                    <p className="text-sm">{formatDate(selectedProof.verifiedAt)}</p>
                  </div>
                )}
                {selectedProof.verifier && (
                  <div>
                    <label className="text-xs text-muted-foreground">Verifier</label>
                    <p className="text-sm font-mono">{selectedProof.verifier}</p>
                  </div>
                )}
              </div>

              <div>
                <label className="text-xs text-muted-foreground">Proof Data (Seal)</label>
                <code className="block text-xs bg-muted p-2 rounded mt-1 break-all">{selectedProof.proofData}</code>
              </div>

              <div>
                <label className="text-xs text-muted-foreground">Public Inputs</label>
                <div className="space-y-1 mt-1">
                  {selectedProof.publicInputs.map((inp, i) => (
                    <code key={i} className="block text-xs bg-muted p-1.5 rounded break-all">
                      [{i}] {inp}
                    </code>
                  ))}
                </div>
              </div>

              {selectedProof.riscZeroReceipt && (
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                      RISC Zero Receipt
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div>
                        <span className="text-muted-foreground">Journal</span>
                        <code className="block bg-muted p-1.5 rounded mt-0.5 break-all">
                          {formatAddress(selectedProof.riscZeroReceipt.journal, 16)}
                        </code>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Seal</span>
                        <code className="block bg-muted p-1.5 rounded mt-0.5 break-all">
                          {formatAddress(selectedProof.riscZeroReceipt.seal, 16)}
                        </code>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Image ID</span>
                        <code className="block bg-muted p-1.5 rounded mt-0.5 break-all">
                          {formatAddress(selectedProof.riscZeroReceipt.imageId, 16)}
                        </code>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Receipt Timestamp</span>
                        <p className="mt-0.5">{formatDate(selectedProof.riscZeroReceipt.timestamp)}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ProofList({ proofs, onSelect }: { proofs: ZKProof[]; onSelect: (p: ZKProof) => void }) {
  if (proofs.length === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center text-muted-foreground">No proofs match the current filters.</CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      {proofs.map((proof) => (
        <Card
          key={proof.id}
          className="cursor-pointer hover:bg-muted/30 transition-colors"
          onClick={() => onSelect(proof)}
        >
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className={`rounded-full p-2 ${proof.verified ? 'bg-emerald-500/20' : 'bg-amber-500/20'}`}>
                  {proof.verified ? (
                    <CheckCircle2 className="h-5 w-5 text-emerald-400" />
                  ) : (
                    <AlertTriangle className="h-5 w-5 text-amber-400" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-medium">{proofTypeLabel(proof.proofType)}</p>
                    <Badge className={proof.verified ? 'proof-badge-verified' : 'proof-badge-pending'}>
                      {proof.verified ? 'Verified' : 'Pending'}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mt-0.5">
                    Entry: {proof.logEntryId} &middot; {proof.publicInputs.length} public input(s)
                  </p>
                </div>
              </div>
              <div className="text-right flex items-center gap-3">
                <div>
                  <p className="text-xs text-muted-foreground">{formatDate(proof.createdAt)}</p>
                  {proof.riscZeroReceipt && (
                    <code className="text-xs text-muted-foreground">
                      Seal: {formatAddress(proof.riscZeroReceipt.seal)}
                    </code>
                  )}
                </div>
                <Button variant="ghost" size="icon">
                  <Eye className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
