import { createContext, useContext, useReducer, type ReactNode } from 'react'

export interface AuditLog {
  id: string
  timestamp: number
  eventType: string
  actor: string
  resource: string
  action: string
  severity: 'info' | 'warn' | 'critical'
  commitment: string
  merkleRoot: string
  proofGenerated: boolean
}

export interface CompliancePolicy {
  id: string
  name: string
  description: string
  rules: PolicyRule[]
  status: 'active' | 'inactive'
}

export interface PolicyRule {
  field: string
  operator: 'eq' | 'neq' | 'gt' | 'lt' | 'contains'
  value: string
}

export interface ZKProof {
  id: string
  logId: string
  proofType: 'integrity' | 'compliance' | 'disclosure' | 'timerange'
  proofData: string
  verified: boolean
  timestamp: number
  publicInputs: string[]
}

export interface Attestation {
  id: string
  logId: string
  auditor: string
  claim: string
  timestamp: number
  signature: string
  status: 'pending' | 'verified' | 'rejected'
}

export interface MerkleTree {
  root: string
  leaves: string[]
  layers: string[][]
}

export type Tab = 'logs' | 'proofs' | 'compliance' | 'attestations' | 'coordination'

interface State {
  logs: AuditLog[]
  proofs: ZKProof[]
  policies: CompliancePolicy[]
  attestations: Attestation[]
  merkleTree: MerkleTree | null
  activeTab: Tab
  isGenerating: boolean
}

type Action =
  | { type: 'ADD_LOG'; payload: AuditLog }
  | { type: 'ADD_PROOF'; payload: ZKProof }
  | { type: 'ADD_POLICY'; payload: CompliancePolicy }
  | { type: 'ADD_ATTESTATION'; payload: Attestation }
  | { type: 'UPDATE_ATTESTATION'; payload: { id: string; status: 'verified' | 'rejected' } }
  | { type: 'SET_MERKLE_TREE'; payload: MerkleTree }
  | { type: 'SET_TAB'; payload: Tab }
  | { type: 'SET_GENERATING'; payload: boolean }
  | { type: 'MARK_LOG_PROOF'; payload: string }
  | { type: 'TOGGLE_POLICY'; payload: string }

const initialState: State = {
  logs: [],
  proofs: [],
  policies: [
    {
      id: 'pol-1',
      name: 'SOC 2 Type II',
      description: 'Access control and audit logging compliance',
      rules: [
        { field: 'eventType', operator: 'eq', value: 'access' },
        { field: 'severity', operator: 'neq', value: 'info' },
      ],
      status: 'active',
    },
    {
      id: 'pol-2',
      name: 'GDPR Data Access',
      description: 'Personal data access event tracking',
      rules: [
        { field: 'resource', operator: 'contains', value: 'pii' },
        { field: 'action', operator: 'eq', value: 'read' },
      ],
      status: 'active',
    },
    {
      id: 'pol-3',
      name: 'Financial Audit Trail',
      description: 'Transaction integrity verification',
      rules: [
        { field: 'eventType', operator: 'eq', value: 'transaction' },
        { field: 'severity', operator: 'gt', value: 'warn' },
      ],
      status: 'inactive',
    },
  ],
  attestations: [],
  merkleTree: null,
  activeTab: 'logs',
  isGenerating: false,
}

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case 'ADD_LOG':
      return { ...state, logs: [action.payload, ...state.logs] }
    case 'ADD_PROOF':
      return { ...state, proofs: [action.payload, ...state.proofs] }
    case 'ADD_POLICY':
      return { ...state, policies: [...state.policies, action.payload] }
    case 'ADD_ATTESTATION':
      return { ...state, attestations: [action.payload, ...state.attestations] }
    case 'UPDATE_ATTESTATION':
      return {
        ...state,
        attestations: state.attestations.map(a =>
          a.id === action.payload.id ? { ...a, status: action.payload.status } : a
        ),
      }
    case 'SET_MERKLE_TREE':
      return { ...state, merkleTree: action.payload }
    case 'SET_TAB':
      return { ...state, activeTab: action.payload }
    case 'SET_GENERATING':
      return { ...state, isGenerating: action.payload }
    case 'MARK_LOG_PROOF':
      return {
        ...state,
        logs: state.logs.map(l => (l.id === action.payload ? { ...l, proofGenerated: true } : l)),
      }
    case 'TOGGLE_POLICY':
      return {
        ...state,
        policies: state.policies.map(p =>
          p.id === action.payload
            ? { ...p, status: p.status === 'active' ? 'inactive' : 'active' }
            : p
        ),
      }
    default:
      return state
  }
}

const StoreCtx = createContext<{
  state: State
  dispatch: React.Dispatch<Action>
} | null>(null)

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState)
  return <StoreCtx.Provider value={{ state, dispatch }}>{children}</StoreCtx.Provider>
}

export function useStore() {
  const ctx = useContext(StoreCtx)
  if (!ctx) throw new Error('useStore must be used within StoreProvider')
  return ctx
}
