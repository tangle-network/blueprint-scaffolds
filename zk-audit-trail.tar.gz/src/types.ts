export type Actor = "ops" | "finance" | "security" | "auditor";

export type LogVisibility = "internal" | "confidential" | "restricted";

export interface AuditLog {
  id: string;
  timestamp: string;
  actor: Actor;
  action: string;
  resource: string;
  region: string;
  visibility: LogVisibility;
  tags: string[];
  fields: Record<string, string>;
}

export interface MerkleProofNode {
  position: "left" | "right";
  hash: string;
}

export interface MerkleCommitment {
  root: string;
  leaf: string;
  proof: MerkleProofNode[];
  leafIndex: number;
}

export interface ComplianceRule {
  id: string;
  label: string;
  predicate: (log: AuditLog) => boolean;
}

export interface PolicyEvaluation {
  ruleId: string;
  label: string;
  passed: boolean;
  reason: string;
}

export interface DisclosureView {
  audience: string;
  visibleFields: Record<string, string>;
  hiddenFieldCount: number;
}

export interface TimeRangeProof {
  rangeStart: string;
  rangeEnd: string;
  includedLogIds: string[];
  omittedLogIds: string[];
  root: string;
}

export interface RiscZeroReceipt {
  journal: string;
  seal: string;
  imageId: string;
}

export interface ProofBundle {
  log: AuditLog;
  commitment: MerkleCommitment;
  evaluations: PolicyEvaluation[];
  disclosure: DisclosureView;
  timeRangeProof: TimeRangeProof;
  receipt: RiscZeroReceipt;
}
