import { useStore } from '../store'
import { truncateHash, formatTimestamp } from '../crypto'
import { Users, Network, ArrowRight } from 'lucide-react'

interface Party {
  id: string
  name: string
  role: string
}

const PARTIES: Party[] = [
  { id: 'p1', name: 'Data Controller', role: 'controller' },
  { id: 'p2', name: 'ZK Prover (RISC Zero)', role: 'prover' },
  { id: 'p3', name: 'Audit Registry', role: 'registry' },
  { id: 'p4', name: 'Compliance Auditor', role: 'auditor' },
  { id: 'p5', name: 'Verifier Contract', role: 'verifier' },
]

export default function Coordination() {
  const { state } = useStore()

  const completedSteps = [
    state.logs.length > 0,
    state.merkleTree !== null,
    state.proofs.length > 0,
    state.attestations.some(a => a.status === 'verified'),
    state.proofs.some(p => p.verified),
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Users className="w-6 h-6 text-amber-400" />
        <h2 className="text-2xl font-bold">Multi-Party Coordination</h2>
      </div>

      <div className="glass p-6 glow">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Network className="w-5 h-5 text-zk-500" /> Coordination Flow
        </h3>
        <div className="flex flex-wrap items-center justify-center gap-2 py-6">
          {PARTIES.map((party, i) => (
            <div key={party.id} className="flex items-center gap-2">
              <div className={`flex flex-col items-center p-4 rounded-xl border transition-all ${
                completedSteps[i]
                  ? 'bg-zk-600/20 border-zk-500/50'
                  : 'bg-gray-800/50 border-gray-700'
              }`}>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold mb-2 ${
                  completedSteps[i] ? 'bg-zk-600 text-white' : 'bg-gray-700 text-gray-400'
                }`}>
                  {i + 1}
                </div>
                <div className="text-sm font-medium text-center">{party.name}</div>
                <div className="text-xs text-gray-500 capitalize">{party.role}</div>
                {completedSteps[i] && (
                  <div className="text-xs text-green-400 mt-1">Complete</div>
                )}
              </div>
              {i < PARTIES.length - 1 && (
                <ArrowRight className="w-5 h-5 text-gray-600 flex-shrink-0" />
              )}
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="glass p-6">
          <h3 className="text-lg font-semibold mb-4">Audit Registry Contract</h3>
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Contract Address</span>
              <span className="font-mono text-zk-100 text-xs">0x7a3b...f92d</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Network</span>
              <span className="text-gray-200">RISC Zero zkVM (Guest)</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Total Entries</span>
              <span className="text-accent-400 font-bold">{state.logs.length}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Merkle Root</span>
              <span className="font-mono text-accent-400 text-xs">
                {state.merkleTree ? truncateHash(state.merkleTree.root) : 'Not built'}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Proofs Submitted</span>
              <span className="text-green-400 font-bold">{state.proofs.length}</span>
            </div>
          </div>
        </div>

        <div className="glass p-6">
          <h3 className="text-lg font-semibold mb-4">Verification Status</h3>
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Verified Proofs</span>
              <span className="text-green-400 font-bold">{state.proofs.filter(p => p.verified).length}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Pending Proofs</span>
              <span className="text-yellow-400 font-bold">{state.proofs.filter(p => !p.verified).length}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Verified Attestations</span>
              <span className="text-green-400 font-bold">{state.attestations.filter(a => a.status === 'verified').length}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Active Policies</span>
              <span className="text-zk-100 font-bold">{state.policies.filter(p => p.status === 'active').length}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Last Activity</span>
              <span className="text-gray-300 text-xs">
                {state.logs.length > 0 ? formatTimestamp(state.logs[0].timestamp) : 'N/A'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {state.merkleTree && state.merkleTree.layers.length > 0 && (
        <div className="glass p-6">
          <h3 className="text-lg font-semibold mb-4">Merkle Tree Visualization</h3>
          <div className="space-y-2 overflow-x-auto">
            {state.merkleTree.layers.map((layer, li) => (
              <div key={li} className="flex gap-2 items-center flex-wrap">
                <span className="text-xs text-gray-500 w-16">Layer {li}:</span>
                {layer.slice(0, 16).map((node, ni) => (
                  <span key={ni} className={`text-xs font-mono px-2 py-1 rounded ${
                    li === state.merkleTree!.layers.length - 1
                      ? 'bg-accent-400/10 text-accent-400 border border-accent-400/30'
                      : 'bg-gray-800 text-gray-400'
                  }`}>
                    {truncateHash(node, 3)}
                  </span>
                ))}
                {layer.length > 16 && (
                  <span className="text-xs text-gray-500">+{layer.length - 16} more</span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
