import { useState } from 'react'
import { useStore, type Attestation } from '../store'
import { generateId, formatTimestamp, truncateHash, sha256 } from '../crypto'
import { Stamp, UserCheck, UserX, Clock, CheckCircle2, XCircle } from 'lucide-react'

export default function Attestations() {
  const { state, dispatch } = useStore()
  const [selectedLog, setSelectedLog] = useState('')
  const [auditor, setAuditor] = useState('')
  const [claim, setClaim] = useState('')

  const createAttestation = () => {
    if (!selectedLog || !auditor || !claim) return
    const log = state.logs.find(l => l.id === selectedLog)
    if (!log) return
    const att: Attestation = {
      id: generateId(),
      logId: selectedLog,
      auditor,
      claim,
      timestamp: Date.now(),
      signature: sha256(auditor + claim + log.commitment),
      status: 'pending',
    }
    dispatch({ type: 'ADD_ATTESTATION', payload: att })
    setSelectedLog('')
    setAuditor('')
    setClaim('')
  }

  const statusIcon = (s: string) => {
    if (s === 'verified') return <CheckCircle2 className="w-4 h-4 text-green-400" />
    if (s === 'rejected') return <XCircle className="w-4 h-4 text-red-400" />
    return <Clock className="w-4 h-4 text-yellow-400" />
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Stamp className="w-6 h-6 text-purple-400" />
        <h2 className="text-2xl font-bold">Compliance Attestations</h2>
      </div>

      <div className="glass p-6 glow">
        <h3 className="text-lg font-semibold mb-4">Issue Attestation</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm text-gray-400 mb-1">Audit Log</label>
            <select
              value={selectedLog}
              onChange={e => setSelectedLog(e.target.value)}
              className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-gray-200 focus:border-zk-500 focus:outline-none"
            >
              <option value="">Select log...</option>
              {state.logs.map(l => (
                <option key={l.id} value={l.id}>
                  {l.eventType} / {l.actor} / {truncateHash(l.commitment, 4)}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">Auditor</label>
            <input
              value={auditor}
              onChange={e => setAuditor(e.target.value)}
              placeholder="auditor@firm.com"
              className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-gray-200 focus:border-zk-500 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">Claim</label>
            <input
              value={claim}
              onChange={e => setClaim(e.target.value)}
              placeholder="e.g., Compliant with SOC 2"
              className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-gray-200 focus:border-zk-500 focus:outline-none"
            />
          </div>
          <div className="flex items-end">
            <button onClick={createAttestation} className="btn-primary w-full flex items-center justify-center gap-2">
              <Stamp className="w-4 h-4" /> Attest
            </button>
          </div>
        </div>
      </div>

      <div className="glass p-6">
        <h3 className="text-lg font-semibold mb-4">Attestation Registry ({state.attestations.length})</h3>
        {state.attestations.length === 0 ? (
          <div className="text-center py-8 text-gray-500">No attestations issued yet.</div>
        ) : (
          <div className="space-y-3">
            {state.attestations.map(att => (
              <div key={att.id} className="flex items-center gap-4 p-4 rounded-lg bg-gray-800/50">
                <div>{statusIcon(att.status)}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{att.claim}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      att.status === 'verified' ? 'bg-green-400/10 text-green-400' :
                      att.status === 'rejected' ? 'bg-red-400/10 text-red-400' :
                      'bg-yellow-400/10 text-yellow-400'
                    }`}>
                      {att.status}
                    </span>
                  </div>
                  <div className="text-xs text-gray-400 mt-1">
                    Auditor: <span className="text-zk-100">{att.auditor}</span> · Log: {truncateHash(att.logId, 4)} · Sig: <span className="font-mono text-accent-400">{truncateHash(att.signature, 6)}</span>
                  </div>
                </div>
                <div className="text-xs text-gray-500">{formatTimestamp(att.timestamp)}</div>
                {att.status === 'pending' && (
                  <div className="flex gap-1">
                    <button
                      onClick={() => dispatch({ type: 'UPDATE_ATTESTATION', payload: { id: att.id, status: 'verified' } })}
                      className="p-1.5 rounded-lg bg-green-400/10 text-green-400 hover:bg-green-400/20"
                      title="Verify"
                    >
                      <UserCheck className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => dispatch({ type: 'UPDATE_ATTESTATION', payload: { id: att.id, status: 'rejected' } })}
                      className="p-1.5 rounded-lg bg-red-400/10 text-red-400 hover:bg-red-400/20"
                      title="Reject"
                    >
                      <UserX className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
