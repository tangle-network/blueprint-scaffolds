import { useState } from 'react'
import { useStore, type AuditLog } from '../store'
import { sha256, generateId, formatTimestamp, truncateHash } from '../crypto'
import { Shield, Plus, FileCheck, AlertTriangle, Info } from 'lucide-react'

export default function LogIngestion() {
  const { state, dispatch } = useStore()
  const [eventType, setEventType] = useState('access')
  const [actor, setActor] = useState('')
  const [resource, setResource] = useState('')
  const [action, setAction] = useState('read')
  const [severity, setSeverity] = useState<'info' | 'warn' | 'critical'>('info')

  const addLog = () => {
    if (!actor || !resource) return
    const id = generateId()
    const timestamp = Date.now()
    const data = `${id}:${timestamp}:${eventType}:${actor}:${resource}:${action}:${severity}`
    const commitment = sha256(data)
    const log: AuditLog = {
      id,
      timestamp,
      eventType,
      actor,
      resource,
      action,
      severity,
      commitment,
      merkleRoot: '',
      proofGenerated: false,
    }
    dispatch({ type: 'ADD_LOG', payload: log })
    setActor('')
    setResource('')
  }

  const sevIcon = (s: string) => {
    if (s === 'critical') return <AlertTriangle className="w-4 h-4 text-red-400" />
    if (s === 'warn') return <AlertTriangle className="w-4 h-4 text-yellow-400" />
    return <Info className="w-4 h-4 text-blue-400" />
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Shield className="w-6 h-6 text-zk-500" />
        <h2 className="text-2xl font-bold">Audit Log Ingestion</h2>
      </div>

      <div className="glass p-6 glow">
        <h3 className="text-lg font-semibold mb-4 text-gray-200">Submit New Audit Entry</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm text-gray-400 mb-1">Event Type</label>
            <select
              value={eventType}
              onChange={e => setEventType(e.target.value)}
              className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-gray-200 focus:border-zk-500 focus:outline-none"
            >
              <option value="access">Access</option>
              <option value="transaction">Transaction</option>
              <option value="modification">Modification</option>
              <option value="deletion">Deletion</option>
              <option value="authentication">Authentication</option>
            </select>
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">Actor</label>
            <input
              value={actor}
              onChange={e => setActor(e.target.value)}
              placeholder="user@org.com"
              className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-gray-200 focus:border-zk-500 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">Resource</label>
            <input
              value={resource}
              onChange={e => setResource(e.target.value)}
              placeholder="/api/records/123"
              className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-gray-200 focus:border-zk-500 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">Action</label>
            <select
              value={action}
              onChange={e => setAction(e.target.value)}
              className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-gray-200 focus:border-zk-500 focus:outline-none"
            >
              <option value="read">Read</option>
              <option value="write">Write</option>
              <option value="delete">Delete</option>
              <option value="execute">Execute</option>
              <option value="grant">Grant</option>
            </select>
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">Severity</label>
            <select
              value={severity}
              onChange={e => setSeverity(e.target.value as 'info' | 'warn' | 'critical')}
              className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-gray-200 focus:border-zk-500 focus:outline-none"
            >
              <option value="info">Info</option>
              <option value="warn">Warning</option>
              <option value="critical">Critical</option>
            </select>
          </div>
          <div className="flex items-end">
            <button onClick={addLog} className="btn-primary flex items-center gap-2 w-full justify-center">
              <Plus className="w-4 h-4" /> Add Entry
            </button>
          </div>
        </div>
      </div>

      <div className="glass p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-200">
            Audit Entries ({state.logs.length})
          </h3>
          {state.merkleTree && (
            <div className="text-xs text-gray-400">
              Merkle Root: <span className="text-accent-400 font-mono">{truncateHash(state.merkleTree.root)}</span>
            </div>
          )}
        </div>

        {state.logs.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <FileCheck className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>No audit entries yet. Submit one above.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-800 text-gray-400">
                  <th className="text-left py-2 px-3">Time</th>
                  <th className="text-left py-2 px-3">Type</th>
                  <th className="text-left py-2 px-3">Actor</th>
                  <th className="text-left py-2 px-3">Resource</th>
                  <th className="text-left py-2 px-3">Action</th>
                  <th className="text-left py-2 px-3">Sev</th>
                  <th className="text-left py-2 px-3">Commitment</th>
                  <th className="text-left py-2 px-3">Proof</th>
                </tr>
              </thead>
              <tbody>
                {state.logs.map(log => (
                  <tr key={log.id} className="border-b border-gray-800/50 hover:bg-gray-800/30">
                    <td className="py-2 px-3 text-gray-400 text-xs">{formatTimestamp(log.timestamp)}</td>
                    <td className="py-2 px-3">{log.eventType}</td>
                    <td className="py-2 px-3 text-zk-100 font-mono text-xs">{log.actor}</td>
                    <td className="py-2 px-3 font-mono text-xs">{log.resource}</td>
                    <td className="py-2 px-3">{log.action}</td>
                    <td className="py-2 px-3">{sevIcon(log.severity)}</td>
                    <td className="py-2 px-3 font-mono text-xs text-accent-400">
                      {truncateHash(log.commitment)}
                    </td>
                    <td className="py-2 px-3">
                      {log.proofGenerated ? (
                        <span className="text-green-400 text-xs">✓ Proven</span>
                      ) : (
                        <span className="text-gray-600 text-xs">Pending</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
