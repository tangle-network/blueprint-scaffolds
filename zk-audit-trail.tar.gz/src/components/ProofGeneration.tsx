import { useStore, type ZKProof } from '../store'
import { generateZKProof, generateId, formatTimestamp, truncateHash, buildMerkleTree, sha256 } from '../crypto'
import { KeyRound, Play, CheckCircle2, Clock, Eye, EyeOff, Timer } from 'lucide-react'

const PROOF_TYPES = [
  { key: 'integrity', label: 'Integrity Proof', desc: 'Prove log entry exists and is unmodified', icon: KeyRound },
  { key: 'compliance', label: 'Compliance Proof', desc: 'Prove compliance with a specific policy', icon: CheckCircle2 },
  { key: 'disclosure', label: 'Selective Disclosure', desc: 'Reveal specific fields without exposing others', icon: EyeOff },
  { key: 'timerange', label: 'Time-Range Proof', desc: 'Prove event occurred within a time window', icon: Timer },
] as const

export default function ProofGeneration() {
  const { state, dispatch } = useStore()

  const generateProof = (logId: string, proofType: ZKProof['proofType']) => {
    const log = state.logs.find(l => l.id === logId)
    if (!log) return
    dispatch({ type: 'SET_GENERATING', payload: true })

    setTimeout(() => {
      const proofData = generateZKProof(log.commitment, proofType)
      const publicInputs: string[] = [log.commitment]
      if (proofType === 'timerange') {
        publicInputs.push(`t>=${log.timestamp - 3600000}`, `t<=${log.timestamp + 3600000}`)
      }
      if (proofType === 'disclosure') {
        publicInputs.push(`field:eventType:${log.eventType}`)
      }
      if (proofType === 'compliance') {
        publicInputs.push('policy:compliant:true')
      }

      const proof: ZKProof = {
        id: generateId(),
        logId,
        proofType,
        proofData,
        verified: false,
        timestamp: Date.now(),
        publicInputs,
      }
      dispatch({ type: 'ADD_PROOF', payload: proof })
      dispatch({ type: 'MARK_LOG_PROOF', payload: logId })
      dispatch({ type: 'SET_GENERATING', payload: false })

      const allCommitments = [...state.logs.map(l => l.commitment), log.commitment]
      const tree = buildMerkleTree(allCommitments)
      dispatch({ type: 'SET_MERKLE_TREE', payload: tree })
    }, 800)
  }

  const generateAllProofs = () => {
    dispatch({ type: 'SET_GENERATING', payload: true })
    const unproven = state.logs.filter(l => !l.proofGenerated)
    if (unproven.length === 0) {
      dispatch({ type: 'SET_GENERATING', payload: false })
      return
    }

    let delay = 0
    unproven.forEach(log => {
      setTimeout(() => {
        generateProof(log.id, 'integrity')
      }, delay)
      delay += 400
    })
  }

  const typeIcon = (t: string) => {
    const found = PROOF_TYPES.find(p => p.key === t)
    return found ? <found.icon className="w-4 h-4" /> : <KeyRound className="w-4 h-4" />
  }

  const typeColor = (t: string) => {
    switch (t) {
      case 'integrity': return 'text-blue-400 bg-blue-400/10'
      case 'compliance': return 'text-green-400 bg-green-400/10'
      case 'disclosure': return 'text-purple-400 bg-purple-400/10'
      case 'timerange': return 'text-amber-400 bg-amber-400/10'
      default: return 'text-gray-400'
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <KeyRound className="w-6 h-6 text-zk-500" />
          <h2 className="text-2xl font-bold">ZK Proof Generation</h2>
        </div>
        <button onClick={generateAllProofs} disabled={state.isGenerating || state.logs.length === 0} className="btn-primary flex items-center gap-2">
          <Play className="w-4 h-4" />
          {state.isGenerating ? 'Generating...' : 'Generate All Integrity Proofs'}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {PROOF_TYPES.map(pt => (
          <div key={pt.key} className="glass p-4">
            <div className="flex items-center gap-2 mb-2">
              <pt.icon className="w-5 h-5 text-zk-500" />
              <h4 className="font-semibold">{pt.label}</h4>
            </div>
            <p className="text-sm text-gray-400">{pt.desc}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {state.logs.slice(0, 5).map(log => (
                <button
                  key={log.id}
                  onClick={() => generateProof(log.id, pt.key as ZKProof['proofType'])}
                  disabled={state.isGenerating}
                  className="text-xs btn-secondary px-2 py-1"
                >
                  {truncateHash(log.commitment, 4)}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="glass p-6">
        <h3 className="text-lg font-semibold mb-4">Generated Proofs ({state.proofs.length})</h3>
        {state.proofs.length === 0 ? (
          <div className="text-center py-8 text-gray-500">No proofs generated yet.</div>
        ) : (
          <div className="space-y-2">
            {state.proofs.map(proof => (
              <div key={proof.id} className="flex items-center gap-4 p-3 rounded-lg bg-gray-800/50 hover:bg-gray-800/80">
                <div className={`p-2 rounded-lg ${typeColor(proof.proofType)}`}>
                  {typeIcon(proof.proofType)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium capitalize">{proof.proofType}</span>
                    {proof.verified ? (
                      <span className="text-xs text-green-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Verified
                      </span>
                    ) : (
                      <span className="text-xs text-yellow-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" /> Unverified
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-gray-400 font-mono truncate">
                    {truncateHash(proof.proofData, 12)}
                  </p>
                </div>
                <div className="text-xs text-gray-500">{formatTimestamp(proof.timestamp)}</div>
                <button
                  onClick={() => {
                    dispatch({
                      type: 'ADD_PROOF',
                      payload: { ...proof, verified: true },
                    })
                    dispatch({
                      type: 'UPDATE_ATTESTATION',
                      payload: { id: proof.id, status: 'verified' },
                    })
                  }}
                  className="btn-secondary text-xs px-2 py-1 flex items-center gap-1"
                >
                  <Eye className="w-3 h-3" /> Verify
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
