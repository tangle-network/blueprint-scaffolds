import { Link, useLocation } from 'react-router-dom'
import {
  LayoutDashboard, FileText, Shield, Eye, Clock, Users, CheckCircle2, TreePine,
} from 'lucide-react'
import { cn } from '@/lib/utils'

const navItems = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/logs', label: 'Log Ingestion', icon: FileText },
  { to: '/proofs', label: 'Proof Generation', icon: Shield },
  { to: '/auditor', label: 'Auditor Verification', icon: CheckCircle2 },
  { to: '/compliance', label: 'Compliance', icon: Eye },
  { to: '/disclosure', label: 'Selective Disclosure', icon: Eye },
  { to: '/time-range', label: 'Time Range Proofs', icon: Clock },
  { to: '/merkle', label: 'Merkle Evidence', icon: TreePine },
  { to: '/coordination', label: 'Multi-Party', icon: Users },
]

export default function Sidebar() {
  const location = useLocation()

  return (
    <aside className="fixed left-0 top-0 z-40 h-screen w-64 border-r border-border bg-card/80 backdrop-blur-sm">
      <div className="flex h-16 items-center border-b border-border px-6">
        <Shield className="h-6 w-6 text-primary mr-2" />
        <div>
          <h1 className="text-sm font-bold text-foreground">ZK Audit Trail</h1>
          <p className="text-xs text-muted-foreground">RISC Zero Verified</p>
        </div>
      </div>
      <nav className="space-y-1 p-3">
        {navItems.map(({ to, label, icon: Icon }) => {
          const active = location.pathname === to
          return (
            <Link
              key={to}
              to={to}
              className={cn(
                'flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors',
                active
                  ? 'bg-primary/10 text-primary font-medium'
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground'
              )}
            >
              <Icon className="h-4 w-4" />
              {label}
            </Link>
          )
        })}
      </nav>
      <div className="absolute bottom-4 left-4 right-4">
        <div className="rounded-md bg-muted/50 p-3 text-xs text-muted-foreground">
          <p className="font-medium text-foreground mb-1">RISC Zero Guest</p>
          <p>Image ID: a3f7...c2d1</p>
          <p>Status: Active</p>
        </div>
      </div>
    </aside>
  )
}
