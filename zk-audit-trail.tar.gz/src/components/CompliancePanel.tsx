import { useState } from 'react'
import { useStore, type CompliancePolicy, type PolicyRule } from '../store'
import { generateId } from '../crypto'
import { ShieldCheck, Plus, ToggleLeft, ToggleRight, Trash2 } from 'lucide-react'

export default function CompliancePanel() {
  const { state, dispatch } = useStore()
  const [showNew, setShowNew] = useState(false)
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [rules, setRules] = useState<PolicyRule[]>([{ field: '', operator: 'eq', value: '' }])

  const addPolicy = () => {
    if (!name) return
    const policy: CompliancePolicy = {
      id: generateId(),
      name,
      description,
      rules: rules.filter(r => r.field),
      status: 'active',
    }
    dispatch({ type: 'ADD_POLICY', payload: policy })
    setName('')
    setDescription('')
    setRules([{ field: '', operator: 'eq', value: '' }])
    setShowNew(false)
  }

  const addRule = () => setRules([...rules, { field: '', operator: 'eq', value: '' }])

  const updateRule = (i: number, key: keyof PolicyRule, val: string) => {
    const updated = [...rules]
    updated[i] = { ...updated[i], [key]: val }
    setRules(updated)
  }

  const activeCount = state.policies.filter(p => p.status === 'active').length
  const complianceRate = state.policies.length > 0
    ? Math.round((activeCount / state.policies.length) * 100)
    : 0

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <ShieldCheck className="w-6 h-6 text-green-400" />
          <h2 className="text-2xl font-bold">Compliance Policies</h2>
        </div>
        <button onClick={() => setShowNew(!showNew)} className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" /> New Policy
        </button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="glass p-4 text-center">
          <div className="text-3xl font-bold text-zk-500">{state.policies.length}</div>
          <div className="text-sm text-gray-400">Total Policies</div>
        </div>
        <div className="glass p-4 text-center">
          <div className="text-3xl font-bold text-green-400">{activeCount}</div>
          <div className="text-sm text-gray-400">Active</div>
        </div>
        <div className="glass p-4 text-center">
          <div className="text-3xl font-bold text-accent-400">{complianceRate}%</div>
          <div className="text-sm text-gray-400">Compliance Rate</div>
        </div>
      </div>

      {showNew && (
        <div className="glass p-6 glow">
          <h3 className="text-lg font-semibold mb-4">Create Policy</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-sm text-gray-400 mb-1">Policy Name</label>
              <input
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g., SOC 2 Access Control"
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-gray-200 focus:border-zk-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-1">Description</label>
              <input
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder="Policy description"
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-gray-200 focus:border-zk-500 focus:outline-none"
              />
            </div>
          </div>
          <div className="mb-4">
            <label className="block text-sm text-gray-400 mb-2">Rules</label>
            {rules.map((rule, i) => (
              <div key={i} className="flex gap-2 mb-2">
                <input
                  value={rule.field}
                  onChange={e => updateRule(i, 'field', e.target.value)}
                  placeholder="field"
                  className="flex-1 bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-gray-200 text-sm focus:border-zk-500 focus:outline-none"
                />
                <select
                  value={rule.operator}
                  onChange={e => updateRule(i, 'operator', e.target.value)}
                  className="bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-gray-200 text-sm focus:border-zk-500 focus:outline-none"
                >
                  <option value="eq">=</option>
                  <option value="neq">!=</option>
                  <option value="gt">&gt;</option>
                  <option value="lt">&lt;</option>
                  <option value="contains">contains</option>
                </select>
                <input
                  value={rule.value}
                  onChange={e => updateRule(i, 'value', e.target.value)}
                  placeholder="value"
                  className="flex-1 bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-gray-200 text-sm focus:border-zk-500 focus:outline-none"
                />
              </div>
            ))}
            <button onClick={addRule} className="text-sm text-zk-500 hover:text-zk-400">+ Add Rule</button>
          </div>
          <div className="flex gap-2">
            <button onClick={addPolicy} className="btn-primary">Create Policy</button>
            <button onClick={() => setShowNew(false)} className="btn-secondary">Cancel</button>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {state.policies.map(policy => (
          <div key={policy.id} className="glass p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-3 h-3 rounded-full ${policy.status === 'active' ? 'bg-green-400' : 'bg-gray-600'}`} />
                <div>
                  <h4 className="font-semibold">{policy.name}</h4>
                  <p className="text-sm text-gray-400">{policy.description}</p>
                </div>
              </div>
              <button
                onClick={() => dispatch({ type: 'TOGGLE_POLICY', payload: policy.id })}
                className="flex items-center gap-2 text-sm"
              >
                {policy.status === 'active' ? (
                  <ToggleRight className="w-6 h-6 text-green-400" />
                ) : (
                  <ToggleLeft className="w-6 h-6 text-gray-500" />
                )}
              </button>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {policy.rules.map((rule, i) => (
                <span key={i} className="text-xs bg-gray-800 text-gray-300 px-2 py-1 rounded">
                  {rule.field} {rule.operator} {rule.value}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
