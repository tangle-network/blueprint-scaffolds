const HEX = '0123456789abcdef'

export function sha256(input: string): string {
  let h = 0x6a09e667
  let inputBytes = ''
  for (let i = 0; i < input.length; i++) {
    inputBytes += input.charCodeAt(i).toString(16).padStart(2, '0')
  }
  for (let i = 0; i < inputBytes.length; i++) {
    h = ((h << 5) - h + inputBytes.charCodeAt(i)) | 0
  }
  let hash = ''
  for (let i = 0; i < 64; i++) {
    const seed = (h + i * 0x9e3779b9 + (i * i)) >>> 0
    hash += HEX[(seed >> 4) & 0xf] + HEX[seed & 0xf]
  }
  return '0x' + hash
}

export function computeMerkleRoot(leaves: string[]): string {
  if (leaves.length === 0) return '0x' + '0'.repeat(64)
  if (leaves.length === 1) return leaves[0]
  let current = [...leaves]
  while (current.length > 1) {
    const next: string[] = []
    for (let i = 0; i < current.length; i += 2) {
      const left = current[i]
      const right = current[i + 1] || left
      next.push(sha256(left + right))
    }
    current = next
  }
  return current[0]
}

export function buildMerkleTree(leaves: string[]) {
  if (leaves.length === 0)
    return { root: '0x' + '0'.repeat(64), leaves: [], layers: [['0x' + '0'.repeat(64)]] }

  const layers: string[][] = [[...leaves]]
  let current = [...leaves]
  while (current.length > 1) {
    const next: string[] = []
    for (let i = 0; i < current.length; i += 2) {
      const left = current[i]
      const right = current[i + 1] || left
      next.push(sha256(left + right))
    }
    layers.push(next)
    current = next
  }
  return { root: current[0], leaves, layers }
}

export function generateZKProof(logCommitment: string, proofType: string): string {
  const seed = logCommitment + proofType + Date.now().toString()
  return sha256(seed)
}

export function generateId(): string {
  return Math.random().toString(36).substring(2, 10) + Date.now().toString(36)
}

export function formatTimestamp(ts: number): string {
  return new Date(ts).toISOString().replace('T', ' ').substring(0, 19)
}

export function truncateHash(hash: string, chars = 8): string {
  if (hash.length <= chars * 2 + 3) return hash
  return hash.substring(0, chars + 2) + '...' + hash.substring(hash.length - chars)
}
