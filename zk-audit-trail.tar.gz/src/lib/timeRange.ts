import type { AuditLog, TimeRangeProof } from "../types";

export function buildTimeRangeProof(
  logs: AuditLog[],
  root: string,
  rangeStart: string,
  rangeEnd: string,
): TimeRangeProof {
  const start = new Date(rangeStart).getTime();
  const end = new Date(rangeEnd).getTime();
  const includedLogIds: string[] = [];
  const omittedLogIds: string[] = [];

  logs.forEach((log) => {
    const timestamp = new Date(log.timestamp).getTime();
    if (timestamp >= start && timestamp <= end) {
      includedLogIds.push(log.id);
      return;
    }
    omittedLogIds.push(log.id);
  });

  return {
    rangeStart,
    rangeEnd,
    includedLogIds,
    omittedLogIds,
    root,
  };
}
