import { hashPair, sha256 } from "./hash";
import type { AuditLog, MerkleCommitment, MerkleProofNode } from "../types";

function serializeLog(log: AuditLog): string {
  return JSON.stringify({
    ...log,
    fields: Object.entries(log.fields).sort(([left], [right]) =>
      left.localeCompare(right),
    ),
    tags: [...log.tags].sort(),
  });
}

export async function hashLog(log: AuditLog): Promise<string> {
  return sha256(serializeLog(log));
}

export async function buildMerkleCommitments(
  logs: AuditLog[],
): Promise<MerkleCommitment[]> {
  const leaves = await Promise.all(logs.map(hashLog));
  const levels: string[][] = [leaves];
  let currentLevel = leaves;

  while (currentLevel.length > 1) {
    const nextLevel: string[] = [];
    for (let index = 0; index < currentLevel.length; index += 2) {
      const left = currentLevel[index];
      const right = currentLevel[index + 1] ?? currentLevel[index];
      nextLevel.push(await hashPair(left, right));
    }
    levels.push(nextLevel);
    currentLevel = nextLevel;
  }

  const root = currentLevel[0];

  return leaves.map((leaf, leafIndex) => {
    const proof: MerkleProofNode[] = [];
    let index = leafIndex;

    for (let levelIndex = 0; levelIndex < levels.length - 1; levelIndex += 1) {
      const level = levels[levelIndex];
      const siblingIndex = index % 2 === 0 ? index + 1 : index - 1;
      const sibling = level[siblingIndex] ?? level[index];
      proof.push({
        position: index % 2 === 0 ? "right" : "left",
        hash: sibling,
      });
      index = Math.floor(index / 2);
    }

    return { root, leaf, proof, leafIndex };
  });
}
