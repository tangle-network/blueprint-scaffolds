import CryptoJS from 'crypto-js';

export class MerkleTree {
  private leaves: string[];
  private levels: string[][];

  constructor(data: string[]) {
    this.leaves = data.map(d => CryptoJS.SHA256(d).toString());
    this.levels = [this.leaves];
    this.build();
  }

  private build(): void {
    let currentLevel = this.leaves;
    while (currentLevel.length > 1) {
      const nextLevel: string[] = [];
      for (let i = 0; i < currentLevel.length; i += 2) {
        const left = currentLevel[i];
        const right = i + 1 < currentLevel.length ? currentLevel[i + 1] : left;
        nextLevel.push(CryptoJS.SHA256(left + right).toString());
      }
      this.levels.push(nextLevel);
      currentLevel = nextLevel;
    }
  }

  getRoot(): string {
    return this.levels[this.levels.length - 1][0];
  }

  getLeaves(): string[] {
    return [...this.leaves];
  }

  getLevels(): string[][] {
    return this.levels.map(l => [...l]);
  }

  getProof(index: number): string[] {
    const proof: string[] = [];
    let idx = index;
    for (let level = 0; level < this.levels.length - 1; level++) {
      const levelData = this.levels[level];
      const siblingIdx = idx % 2 === 0 ? idx + 1 : idx - 1;
      if (siblingIdx < levelData.length) {
        proof.push(levelData[siblingIdx]);
      } else {
        proof.push(levelData[idx]);
      }
      idx = Math.floor(idx / 2);
    }
    return proof;
  }

  verify(data: string, proof: string[], root: string): boolean {
    let hash = CryptoJS.SHA256(data).toString();
    for (const sibling of proof) {
      hash = CryptoJS.SHA256(
        hash < sibling ? hash + sibling : sibling + hash
      ).toString();
    }
    return hash === root;
  }

  getSize(): number {
    return this.leaves.length;
  }

  getHeight(): number {
    return this.levels.length;
  }
}

export function computeHash(data: string): string {
  return CryptoJS.SHA256(data).toString();
}

export function computeHMAC(data: string, key: string): string {
  return CryptoJS.HmacSHA256(data, key).toString();
}
