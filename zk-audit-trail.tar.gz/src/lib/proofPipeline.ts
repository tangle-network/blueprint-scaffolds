import { discloseLog } from "./disclosure";
import { buildMerkleCommitments } from "./merkle";
import { evaluatePolicies } from "./policy";
import { createReceipt } from "./risc0";
import { buildTimeRangeProof } from "./timeRange";
import type { AuditLog, ProofBundle } from "../types";

export async function assembleProofs(
  logs: AuditLog[],
  audience: "regulator" | "counterparty" | "internal",
  rangeStart: string,
  rangeEnd: string,
): Promise<ProofBundle[]> {
  const commitments = await buildMerkleCommitments(logs);

  return Promise.all(
    logs.map(async (log, index) => {
      const commitment = commitments[index];
      const evaluations = evaluatePolicies(log);
      const disclosure = discloseLog(log, audience);
      const timeRangeProof = buildTimeRangeProof(logs, commitment.root, rangeStart, rangeEnd);
      const receipt = await createReceipt({
        log,
        commitment,
        evaluations,
        disclosure,
        timeRangeProof,
      });

      return {
        log,
        commitment,
        evaluations,
        disclosure,
        timeRangeProof,
        receipt,
      };
    }),
  );
}
