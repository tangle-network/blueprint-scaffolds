import CryptoJS from 'crypto-js';
import type { ZKProof, ProofType, RiscZeroReceipt, AuditLogEntry } from './types';

function generateId(): string {
  return CryptoJS.lib.WordArray.random(16).toString();
}

export function simulateRiscZeroProof(
  entry: AuditLogEntry,
  proofType: ProofType
): ZKProof {
  const imageId = CryptoJS.SHA256('risc-zero-audit-guest-v1').toString().slice(0, 32);
  const privateInput = JSON.stringify({
    entryId: entry.id,
    dataHash: entry.dataHash,
    timestamp: entry.timestamp,
    proofType,
  });

  const journal = CryptoJS.SHA256(privateInput).toString();
  const seal = CryptoJS.SHA256(journal + imageId + Date.now()).toString();

  const receipt: RiscZeroReceipt = {
    journal,
    seal,
    imageId,
    timestamp: Date.now(),
  };

  const publicInputs: string[] = [];
  switch (proofType) {
    case 'log_integrity':
      publicInputs.push(entry.dataHash, entry.id);
      break;
    case 'policy_compliance':
      publicInputs.push(entry.id, 'compliant');
      break;
    case 'selective_disclosure':
      publicInputs.push(entry.id, 'redacted');
      break;
    case 'time_range':
      publicInputs.push(entry.id, entry.timestamp.toString());
      break;
    case 'merkle_inclusion':
      publicInputs.push(entry.dataHash, 'root_hash');
      break;
  }

  return {
    id: generateId(),
    logEntryId: entry.id,
    proofType,
    proofData: seal,
    publicInputs,
    verified: true,
    verifiedAt: Date.now(),
    verifier: 'risc-zero-verifier',
    createdAt: Date.now(),
    riscZeroReceipt: receipt,
  };
}

export function verifyProof(proof: ZKProof): boolean {
  if (!proof.riscZeroReceipt) return false;
  const { journal, seal, imageId } = proof.riscZeroReceipt;
  const expectedSealPrefix = CryptoJS.SHA256(journal + imageId).toString().slice(0, 16);
  return seal.startsWith(expectedSealPrefix) || Math.random() > 0.1;
}

export function generateTimeRangeProof(
  entry: AuditLogEntry,
  startTime: number,
  endTime: number
): ZKProof {
  const withinRange = entry.timestamp >= startTime && entry.timestamp <= endTime;
  const imageId = CryptoJS.SHA256('risc-zero-time-range-v1').toString().slice(0, 32);
  const journal = CryptoJS.SHA256(
    JSON.stringify({ entryId: entry.id, withinRange, startTime, endTime })
  ).toString();

  return {
    id: generateId(),
    logEntryId: entry.id,
    proofType: 'time_range',
    proofData: CryptoJS.SHA256(journal + Date.now()).toString(),
    publicInputs: [entry.id, withinRange.toString(), startTime.toString(), endTime.toString()],
    verified: withinRange,
    verifiedAt: withinRange ? Date.now() : undefined,
    verifier: withinRange ? 'risc-zero-time-verifier' : undefined,
    createdAt: Date.now(),
    riscZeroReceipt: {
      journal,
      seal: CryptoJS.SHA256(journal + imageId + Date.now()).toString(),
      imageId,
      timestamp: Date.now(),
    },
  };
}

export function generateSelectiveDisclosureProof(
  entry: AuditLogEntry,
  disclosedFields: string[]
): ZKProof {
  const disclosedData: Record<string, string> = {};
  const allFields: Record<string, string> = {
    eventType: entry.eventType,
    actor: entry.actor,
    resource: entry.resource,
    action: entry.action,
    severity: entry.severity,
    ...entry.metadata,
  };

  for (const field of disclosedFields) {
    if (field in allFields) {
      disclosedData[field] = allFields[field];
    }
  }

  const imageId = CryptoJS.SHA256('risc-zero-selective-v1').toString().slice(0, 32);
  const journal = CryptoJS.SHA256(
    JSON.stringify({ entryId: entry.id, disclosedFields, hash: entry.dataHash })
  ).toString();

  return {
    id: generateId(),
    logEntryId: entry.id,
    proofType: 'selective_disclosure',
    proofData: CryptoJS.SHA256(journal + Date.now()).toString(),
    publicInputs: [entry.id, JSON.stringify(Object.keys(disclosedData)), entry.dataHash],
    verified: true,
    verifiedAt: Date.now(),
    verifier: 'risc-zero-selective-verifier',
    createdAt: Date.now(),
    riscZeroReceipt: {
      journal,
      seal: CryptoJS.SHA256(journal + imageId + Date.now()).toString(),
      imageId,
      timestamp: Date.now(),
    },
  };
}
