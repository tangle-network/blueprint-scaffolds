import { sha256 } from "./hash";
import type { ProofBundle, RiscZeroReceipt } from "../types";

const IMAGE_ID = "risc0-audit-guest-v1";

export async function createReceipt(bundle: Omit<ProofBundle, "receipt">): Promise<RiscZeroReceipt> {
  const journal = await sha256(
    JSON.stringify({
      id: bundle.log.id,
      root: bundle.commitment.root,
      disclosedFields: bundle.disclosure.visibleFields,
      policySummary: bundle.evaluations.map((evaluation) => ({
        ruleId: evaluation.ruleId,
        passed: evaluation.passed,
      })),
      includedLogIds: bundle.timeRangeProof.includedLogIds,
    }),
  );

  const seal = await sha256(`${IMAGE_ID}:${journal}`);
  return { journal, seal, imageId: IMAGE_ID };
}
