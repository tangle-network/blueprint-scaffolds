import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDate(timestamp: number): string {
  return new Date(timestamp).toLocaleString();
}

export function formatAddress(hash: string, chars = 8): string {
  if (hash.length <= chars * 2) return hash;
  return `${hash.slice(0, chars)}...${hash.slice(-chars)}`;
}

export function severityColor(severity: string): string {
  switch (severity) {
    case 'critical': return 'text-red-400 bg-red-500/20 border-red-500/30';
    case 'high': return 'text-orange-400 bg-orange-500/20 border-orange-500/30';
    case 'medium': return 'text-amber-400 bg-amber-500/20 border-amber-500/30';
    case 'low': return 'text-emerald-400 bg-emerald-500/20 border-emerald-500/30';
    default: return 'text-gray-400 bg-gray-500/20 border-gray-500/30';
  }
}

export function statusColor(status: string): string {
  switch (status) {
    case 'compliant':
    case 'approved':
    case 'verified':
    case 'active':
    case 'completed':
      return 'text-emerald-400 bg-emerald-500/20 border-emerald-500/30';
    case 'pending':
      return 'text-amber-400 bg-amber-500/20 border-amber-500/30';
    case 'non-compliant':
    case 'denied':
    case 'failed':
    case 'rejected':
    case 'disputed':
      return 'text-red-400 bg-red-500/20 border-red-500/30';
    case 'expired':
      return 'text-gray-400 bg-gray-500/20 border-gray-500/30';
    default:
      return 'text-gray-400 bg-gray-500/20 border-gray-500/30';
  }
}

export function proofTypeLabel(type: string): string {
  switch (type) {
    case 'log_integrity': return 'Log Integrity';
    case 'policy_compliance': return 'Policy Compliance';
    case 'selective_disclosure': return 'Selective Disclosure';
    case 'time_range': return 'Time Range';
    case 'merkle_inclusion': return 'Merkle Inclusion';
    default: return type;
  }
}
