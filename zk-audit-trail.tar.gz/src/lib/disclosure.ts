import type { AuditLog, DisclosureView } from "../types";

const audiences: Record<string, string[]> = {
  regulator: ["ticket", "approvalRef", "quorum", "evidenceRef", "control", "outcome"],
  counterparty: ["checksum", "dataset", "rotationId", "vendor"],
  internal: [],
};

export function discloseLog(log: AuditLog, audience: keyof typeof audiences): DisclosureView {
  const allowList = audiences[audience];
  const visibleFields = Object.fromEntries(
    Object.entries(log.fields).filter(([field]) => {
      if (audience === "internal") {
        return true;
      }
      return allowList.includes(field);
    }),
  );

  return {
    audience,
    visibleFields,
    hiddenFieldCount: Object.keys(log.fields).length - Object.keys(visibleFields).length,
  };
}
