import CryptoJS from 'crypto-js';
import type {
  AuditLogEntry,
  CompliancePolicy,
  ComplianceAttestation,
  PolicyRule,
  DashboardStats,
  AuditSession,
} from './types';

function generateId(): string {
  return CryptoJS.lib.WordArray.random(16).toString();
}

export function createAuditLogEntry(
  eventType: string,
  actor: string,
  resource: string,
  action: string,
  severity: AuditLogEntry['severity'],
  metadata: Record<string, string> = {}
): AuditLogEntry {
  const data = JSON.stringify({ eventType, actor, resource, action, metadata });
  return {
    id: generateId(),
    timestamp: Date.now(),
    eventType,
    actor,
    resource,
    action,
    severity,
    metadata,
    dataHash: CryptoJS.SHA256(data).toString(),
  };
}

export function evaluatePolicyRule(rule: PolicyRule, entry: AuditLogEntry): boolean {
  const fieldValue = getFieldValue(rule.field, entry);
  if (fieldValue === undefined) return false;

  switch (rule.operator) {
    case 'eq': return fieldValue === rule.value;
    case 'neq': return fieldValue !== rule.value;
    case 'gt': return fieldValue > rule.value;
    case 'lt': return fieldValue < rule.value;
    case 'contains': return fieldValue.includes(rule.value);
    case 'matches': return new RegExp(rule.value).test(fieldValue);
    default: return false;
  }
}

function getFieldValue(field: string, entry: AuditLogEntry): string {
  const fieldMap: Record<string, string> = {
    eventType: entry.eventType,
    actor: entry.actor,
    resource: entry.resource,
    action: entry.action,
    severity: entry.severity,
  };
  return fieldMap[field] || entry.metadata[field] || '';
}

export function evaluatePolicy(policy: CompliancePolicy, entries: AuditLogEntry[]): {
  compliant: boolean;
  violations: { rule: PolicyRule; entry: AuditLogEntry }[];
} {
  const violations: { rule: PolicyRule; entry: AuditLogEntry }[] = [];

  for (const entry of entries) {
    for (const rule of policy.rules) {
      if (!evaluatePolicyRule(rule, entry)) {
        violations.push({ rule, entry });
      }
    }
  }

  return { compliant: violations.length === 0, violations };
}

export function createComplianceAttestation(
  policyId: string,
  logEntryIds: string[],
  proof: ComplianceAttestation['proof'],
  attester: string,
  status: ComplianceAttestation['status'],
  notes?: string
): ComplianceAttestation {
  return {
    id: generateId(),
    policyId,
    logEntryIds,
    proof,
    status,
    attestedAt: Date.now(),
    attester,
    notes,
  };
}

export function createAuditSession(auditor: string): AuditSession {
  return {
    id: generateId(),
    auditor,
    startedAt: Date.now(),
    entriesReviewed: 0,
    proofsGenerated: 0,
    attestations: 0,
    status: 'active',
  };
}

export function computeDashboardStats(
  logs: AuditLogEntry[],
  proofs: { verified: boolean }[],
  sessions: AuditSession[],
  complianceRate: number,
  merkleRoot?: string
): DashboardStats {
  return {
    totalLogs: logs.length,
    verifiedProofs: proofs.filter(p => p.verified).length,
    pendingProofs: proofs.filter(p => !p.verified).length,
    failedProofs: proofs.filter(p => !p.verified).length,
    complianceRate,
    activeSessions: sessions.filter(s => s.status === 'active').length,
    merkleRoot,
  };
}

export function generateSampleLogs(count: number): AuditLogEntry[] {
  const eventTypes = ['authentication', 'data_access', 'configuration', 'api_call', 'file_operation'];
  const actors = ['admin@company.com', 'user1@company.com', 'service-account@company.com', 'auditor@company.com', 'api-gateway@company.com'];
  const resources = ['database://users', 'api://customers', 's3://reports', 'vault://secrets', 'k8s://pods'];
  const actions = ['read', 'write', 'delete', 'update', 'create', 'login', 'logout'];
  const severities: AuditLogEntry['severity'][] = ['low', 'medium', 'high', 'critical'];

  const logs: AuditLogEntry[] = [];
  for (let i = 0; i < count; i++) {
    logs.push(
      createAuditLogEntry(
        eventTypes[Math.floor(Math.random() * eventTypes.length)],
        actors[Math.floor(Math.random() * actors.length)],
        resources[Math.floor(Math.random() * resources.length)],
        actions[Math.floor(Math.random() * actions.length)],
        severities[Math.floor(Math.random() * severities.length)],
        { source: 'production', version: '1.0.0', region: 'us-east-1' }
      )
    );
  }
  return logs.sort((a, b) => a.timestamp - b.timestamp);
}

export function generateSamplePolicies(): CompliancePolicy[] {
  return [
    {
      id: generateId(),
      name: 'GDPR Data Access Control',
      description: 'Ensure all data access events comply with GDPR requirements',
      category: 'GDPR',
      active: true,
      createdAt: Date.now(),
      rules: [
        { id: generateId(), field: 'resource', operator: 'contains', value: 'personal', severity: 'high' },
        { id: generateId(), field: 'action', operator: 'neq', value: 'delete', severity: 'critical' },
      ],
    },
    {
      id: generateId(),
      name: 'HIPAA Audit Trail',
      description: 'Maintain complete audit trail for PHI access',
      category: 'HIPAA',
      active: true,
      createdAt: Date.now(),
      rules: [
        { id: generateId(), field: 'eventType', operator: 'eq', value: 'data_access', severity: 'high' },
        { id: generateId(), field: 'actor', operator: 'contains', value: '@company.com', severity: 'medium' },
      ],
    },
    {
      id: generateId(),
      name: 'SOC 2 Change Management',
      description: 'Track all configuration changes for SOC 2 compliance',
      category: 'SOC2',
      active: true,
      createdAt: Date.now(),
      rules: [
        { id: generateId(), field: 'eventType', operator: 'eq', value: 'configuration', severity: 'high' },
        { id: generateId(), field: 'action', operator: 'neq', value: 'read', severity: 'medium' },
      ],
    },
    {
      id: generateId(),
      name: 'PCI-DSS Access Monitoring',
      description: 'Monitor access to cardholder data environments',
      category: 'PCI-DSS',
      active: true,
      createdAt: Date.now(),
      rules: [
        { id: generateId(), field: 'resource', operator: 'contains', value: 'payment', severity: 'critical' },
        { id: generateId(), field: 'severity', operator: 'eq', value: 'critical', severity: 'critical' },
      ],
    },
  ];
}
