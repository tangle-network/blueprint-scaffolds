const encoder = new TextEncoder();

async function digestBytes(input: string): Promise<ArrayBuffer> {
  return crypto.subtle.digest("SHA-256", encoder.encode(input));
}

function toHex(buffer: ArrayBuffer): string {
  return [...new Uint8Array(buffer)]
    .map((value) => value.toString(16).padStart(2, "0"))
    .join("");
}

export async function sha256(input: string): Promise<string> {
  return toHex(await digestBytes(input));
}

export async function hashPair(left: string, right: string): Promise<string> {
  return sha256(`${left}:${right}`);
}
