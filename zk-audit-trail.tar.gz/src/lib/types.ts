export interface AuditLogEntry {
  id: string;
  timestamp: number;
  eventType: string;
  actor: string;
  resource: string;
  action: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  metadata: Record<string, string>;
  dataHash: string;
  merkleProof?: string[];
}

export interface ZKProof {
  id: string;
  logEntryId: string;
  proofType: ProofType;
  proofData: string;
  publicInputs: string[];
  verified: boolean;
  verifiedAt?: number;
  verifier?: string;
  createdAt: number;
  riscZeroReceipt?: RiscZeroReceipt;
}

export type ProofType =
  | 'log_integrity'
  | 'policy_compliance'
  | 'selective_disclosure'
  | 'time_range'
  | 'merkle_inclusion';

export interface RiscZeroReceipt {
  journal: string;
  seal: string;
  imageId: string;
  timestamp: number;
}

export interface CompliancePolicy {
  id: string;
  name: string;
  description: string;
  rules: PolicyRule[];
  category: 'GDPR' | 'HIPAA' | 'SOC2' | 'PCI-DSS' | 'Custom';
  active: boolean;
  createdAt: number;
}

export interface PolicyRule {
  id: string;
  field: string;
  operator: 'eq' | 'neq' | 'gt' | 'lt' | 'contains' | 'matches';
  value: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
}

export interface ComplianceAttestation {
  id: string;
  policyId: string;
  logEntryIds: string[];
  proof: ZKProof;
  status: 'compliant' | 'non-compliant' | 'pending';
  attestedAt: number;
  attester: string;
  notes?: string;
}

export interface SelectiveDisclosureRequest {
  id: string;
  requester: string;
  fields: string[];
  logEntryId: string;
  proof?: ZKProof;
  status: 'pending' | 'approved' | 'denied' | 'expired';
  createdAt: number;
  expiresAt: number;
}

export interface MerkleTree {
  root: string;
  leaves: string[];
  levels: string[][];
}

export interface AuditSession {
  id: string;
  auditor: string;
  startedAt: number;
  endedAt?: number;
  entriesReviewed: number;
  proofsGenerated: number;
  attestations: number;
  status: 'active' | 'completed' | 'disputed';
}

export interface TimeRangeProof {
  id: string;
  logEntryId: string;
  startTime: number;
  endTime: number;
  proof: ZKProof;
  actualTime?: number;
  verified: boolean;
}

export interface MultiPartyCoordination {
  id: string;
  parties: Party[];
  requiredApprovals: number;
  approvals: Approval[];
  status: 'pending' | 'approved' | 'rejected';
  action: string;
  createdAt: number;
}

export interface Party {
  id: string;
  name: string;
  role: string;
  publicKey: string;
}

export interface Approval {
  partyId: string;
  approved: boolean;
  signature: string;
  timestamp: number;
  comments?: string;
}

export interface DashboardStats {
  totalLogs: number;
  verifiedProofs: number;
  pendingProofs: number;
  failedProofs: number;
  complianceRate: number;
  activeSessions: number;
  merkleRoot?: string;
}
