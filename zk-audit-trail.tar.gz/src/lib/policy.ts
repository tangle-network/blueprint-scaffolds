import type { AuditLog, ComplianceRule, PolicyEvaluation } from "../types";

const complianceRules: ComplianceRule[] = [
  {
    id: "retention-window",
    label: "Retention metadata is attached",
    predicate: (log) => Object.keys(log.fields).some((field) => field.includes("Ref") || field.includes("ticket")),
  },
  {
    id: "restricted-review",
    label: "Restricted exports require approval reference",
    predicate: (log) =>
      log.visibility !== "restricted" || typeof log.fields.approvalRef === "string",
  },
  {
    id: "key-rotation-quorum",
    label: "Key operations record a quorum",
    predicate: (log) =>
      !log.action.includes("keys") || typeof log.fields.quorum === "string",
  },
];

export function evaluatePolicies(log: AuditLog): PolicyEvaluation[] {
  return complianceRules.map((rule) => {
    const passed = rule.predicate(log);
    return {
      ruleId: rule.id,
      label: rule.label,
      passed,
      reason: passed
        ? "Control satisfied"
        : "Required evidence is missing for this event class",
    };
  });
}
