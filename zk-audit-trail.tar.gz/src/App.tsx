import { useEffect, useMemo, useState } from "react";
import {
  BadgeCheck,
  Blocks,
  Eye,
  FileLock2,
  Fingerprint,
  ShieldCheck,
} from "lucide-react";
import { sampleLogs } from "./lib/sampleData";
import { assembleProofs } from "./lib/proofPipeline";
import type { ProofBundle } from "./types";

const defaultRange = {
  start: "2025-02-18T09:00",
  end: "2025-02-18T12:00",
};

type Audience = "regulator" | "counterparty" | "internal";

const statCards = [
  {
    title: "Merkle Anchors",
    icon: Blocks,
    description: "Every audit event is committed into a shared append-only tree.",
  },
  {
    title: "Selective Disclosure",
    icon: Eye,
    description: "Proof bundles reveal only audience-approved fields.",
  },
  {
    title: "Compliance Checks",
    icon: ShieldCheck,
    description: "Policies are attested without exposing full source logs.",
  },
  {
    title: "RISC Zero Receipts",
    icon: Fingerprint,
    description: "Receipts summarize proof statements for external verifiers.",
  },
];

function App() {
  const [audience, setAudience] = useState<Audience>("regulator");
  const [rangeStart, setRangeStart] = useState(defaultRange.start);
  const [rangeEnd, setRangeEnd] = useState(defaultRange.end);
  const [proofs, setProofs] = useState<ProofBundle[]>([]);

  useEffect(() => {
    assembleProofs(sampleLogs, audience, rangeStart, rangeEnd).then(setProofs);
  }, [audience, rangeEnd, rangeStart]);

  const failedCount = useMemo(
    () =>
      proofs.reduce(
        (count, proof) =>
          count +
          proof.evaluations.filter((evaluation) => !evaluation.passed).length,
        0,
      ),
    [proofs],
  );

  const activeRoot = proofs[0]?.commitment.root ?? "building";

  return (
    <div className="app-shell">
      <header className="hero">
        <div className="hero-copy">
          <p className="eyebrow">RISC Zero Verifiable Logging</p>
          <h1>ZK audit trail for sensitive operational evidence.</h1>
          <p className="lede">
            Produce tamper-evident log commitments, prove compliance over time
            ranges, and disclose only the fields an auditor is entitled to see.
          </p>
        </div>
        <div className="hero-panel">
          <div className="hero-row">
            <span>Global root</span>
            <strong>{activeRoot.slice(0, 18)}...</strong>
          </div>
          <div className="hero-row">
            <span>Events committed</span>
            <strong>{sampleLogs.length}</strong>
          </div>
          <div className="hero-row">
            <span>Policy failures</span>
            <strong>{failedCount}</strong>
          </div>
          <div className="hero-row">
            <span>Disclosure mode</span>
            <strong>{audience}</strong>
          </div>
        </div>
      </header>

      <section className="stats-grid">
        {statCards.map(({ title, icon: Icon, description }) => (
          <article key={title} className="stat-card">
            <Icon size={20} />
            <h2>{title}</h2>
            <p>{description}</p>
          </article>
        ))}
      </section>

      <section className="controls-panel">
        <div>
          <p className="section-label">Proof controls</p>
          <h2>Generate auditor-ready bundles</h2>
        </div>
        <label>
          Audience
          <select
            value={audience}
            onChange={(event) => setAudience(event.target.value as Audience)}
          >
            <option value="regulator">Regulator</option>
            <option value="counterparty">Counterparty</option>
            <option value="internal">Internal</option>
          </select>
        </label>
        <label>
          Range start
          <input
            type="datetime-local"
            value={rangeStart}
            onChange={(event) => setRangeStart(event.target.value)}
          />
        </label>
        <label>
          Range end
          <input
            type="datetime-local"
            value={rangeEnd}
            onChange={(event) => setRangeEnd(event.target.value)}
          />
        </label>
      </section>

      <section className="proof-list">
        {proofs.map((proof) => (
          <article key={proof.log.id} className="proof-card">
            <div className="proof-header">
              <div>
                <p className="section-label">{proof.log.actor}</p>
                <h3>{proof.log.action}</h3>
              </div>
              <span className={`pill ${proof.log.visibility}`}>
                <FileLock2 size={14} />
                {proof.log.visibility}
              </span>
            </div>

            <dl className="meta-grid">
              <div>
                <dt>Resource</dt>
                <dd>{proof.log.resource}</dd>
              </div>
              <div>
                <dt>Region</dt>
                <dd>{proof.log.region}</dd>
              </div>
              <div>
                <dt>Timestamp</dt>
                <dd>{proof.log.timestamp}</dd>
              </div>
              <div>
                <dt>Leaf index</dt>
                <dd>{proof.commitment.leafIndex}</dd>
              </div>
            </dl>

            <div className="proof-sections">
              <section>
                <h4>
                  <Blocks size={16} />
                  Merkle evidence
                </h4>
                <p>Leaf {proof.commitment.leaf.slice(0, 22)}...</p>
                <p>Root {proof.commitment.root.slice(0, 22)}...</p>
                <p>Path length {proof.commitment.proof.length}</p>
              </section>

              <section>
                <h4>
                  <BadgeCheck size={16} />
                  Compliance
                </h4>
                {proof.evaluations.map((evaluation) => (
                  <p
                    key={evaluation.ruleId}
                    className={evaluation.passed ? "pass" : "fail"}
                  >
                    {evaluation.label}: {evaluation.reason}
                  </p>
                ))}
              </section>

              <section>
                <h4>
                  <Eye size={16} />
                  Selective disclosure
                </h4>
                <p>Audience {proof.disclosure.audience}</p>
                <p>Visible fields {Object.keys(proof.disclosure.visibleFields).length}</p>
                <p>Hidden fields {proof.disclosure.hiddenFieldCount}</p>
              </section>

              <section>
                <h4>
                  <Fingerprint size={16} />
                  RISC Zero receipt
                </h4>
                <p>Image {proof.receipt.imageId}</p>
                <p>Journal {proof.receipt.journal.slice(0, 22)}...</p>
                <p>Seal {proof.receipt.seal.slice(0, 22)}...</p>
              </section>
            </div>

            <footer className="time-range">
              <span>
                Included in time proof: {proof.timeRangeProof.includedLogIds.join(", ")}
              </span>
              <span>
                Omitted:{" "}
                {proof.timeRangeProof.omittedLogIds.length > 0
                  ? proof.timeRangeProof.omittedLogIds.join(", ")
                  : "none"}
              </span>
            </footer>
          </article>
        ))}
      </section>
    </div>
  );
}

export default App;
