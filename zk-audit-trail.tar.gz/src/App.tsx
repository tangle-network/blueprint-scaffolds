import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import DashboardPage from './pages/DashboardPage'
import LogsPage from './pages/LogsPage'
import ProofsPage from './pages/ProofsPage'
import CompliancePage from './pages/CompliancePage'
import DisclosurePage from './pages/DisclosurePage'
import AuditorPage from './pages/AuditorPage'
import TimeRangePage from './pages/TimeRangePage'
import MerklePage from './pages/MerklePage'
import CoordinationPage from './pages/CoordinationPage'

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<DashboardPage />} />
        <Route path="/logs" element={<LogsPage />} />
        <Route path="/proofs" element={<ProofsPage />} />
        <Route path="/compliance" element={<CompliancePage />} />
        <Route path="/disclosure" element={<DisclosurePage />} />
        <Route path="/auditor" element={<AuditorPage />} />
        <Route path="/time-range" element={<TimeRangePage />} />
        <Route path="/merkle" element={<MerklePage />} />
        <Route path="/coordination" element={<CoordinationPage />} />
      </Route>
    </Routes>
  )
}
