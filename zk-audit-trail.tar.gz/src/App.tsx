import { StoreProvider, useStore, type Tab } from './store'
import LogIngestion from './components/LogIngestion'
import ProofGeneration from './components/ProofGeneration'
import CompliancePanel from './components/CompliancePanel'
import Attestations from './components/Attestations'
import Coordination from './components/Coordination'
import { Shield, KeyRound, ShieldCheck, Stamp, Users } from 'lucide-react'

const TABS: { key: Tab; label: string; icon: typeof Shield }[] = [
  { key: 'logs', label: 'Audit Logs', icon: Shield },
  { key: 'proofs', label: 'ZK Proofs', icon: KeyRound },
  { key: 'compliance', label: 'Compliance', icon: ShieldCheck },
  { key: 'attestations', label: 'Attestations', icon: Stamp },
  { key: 'coordination', label: 'Coordination', icon: Users },
]

function Dashboard() {
  const { state, dispatch } = useStore()

  const renderTab = () => {
    switch (state.activeTab) {
      case 'logs': return <LogIngestion />
      case 'proofs': return <ProofGeneration />
      case 'compliance': return <CompliancePanel />
      case 'attestations': return <Attestations />
      case 'coordination': return <Coordination />
    }
  }

  return (
    <div className="min-h-screen bg-gray-950">
      <header className="border-b border-gray-800 bg-gray-950/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-zk-600 flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold">ZK Audit Trail</h1>
              <p className="text-xs text-gray-500">RISC Zero Verifiable Logging</p>
            </div>
          </div>
          <div className="flex items-center gap-4 text-xs text-gray-400">
            <span>{state.logs.length} logs</span>
            <span>{state.proofs.length} proofs</span>
            <span className="text-green-400 flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" /> Online
            </span>
          </div>
        </div>
      </header>

      <nav className="border-b border-gray-800 bg-gray-900/50">
        <div className="max-w-7xl mx-auto px-4 flex gap-1 overflow-x-auto">
          {TABS.map(tab => {
            const Icon = tab.icon
            return (
              <button
                key={tab.key}
                onClick={() => dispatch({ type: 'SET_TAB', payload: tab.key })}
                className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-all whitespace-nowrap ${
                  state.activeTab === tab.key
                    ? 'border-zk-500 text-zk-100'
                    : 'border-transparent text-gray-400 hover:text-gray-200 hover:border-gray-700'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            )
          })}
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 py-6">
        {renderTab()}
      </main>

      <footer className="border-t border-gray-800 mt-12 py-4 text-center text-xs text-gray-600">
        ZK Audit Trail System — Powered by RISC Zero zkVM — Verifiable Logging Without Exposure
      </footer>
    </div>
  )
}

export default function App() {
  return (
    <StoreProvider>
      <Dashboard />
    </StoreProvider>
  )
}
