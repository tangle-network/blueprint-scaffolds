/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        zk: { 50: '#f0f4ff', 100: '#dbe4ff', 500: '#4c6ef5', 600: '#3b5bdb', 700: '#364fc7', 900: '#1a1a2e' },
        accent: { 400: '#63e6be', 500: '#38d9a9', 600: '#20c997' },
      },
    },
  },
  plugins: [],
}
