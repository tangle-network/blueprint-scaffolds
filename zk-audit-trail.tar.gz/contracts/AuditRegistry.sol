// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract AuditRegistry {
    struct RootCommitment {
        bytes32 root;
        uint64 timestamp;
        string scope;
        address submitter;
    }

    RootCommitment[] public commitments;

    event RootCommitted(uint256 indexed index, bytes32 indexed root, string scope, address indexed submitter);

    function commitRoot(bytes32 root, string calldata scope) external returns (uint256 index) {
        commitments.push(
            RootCommitment({
                root: root,
                timestamp: uint64(block.timestamp),
                scope: scope,
                submitter: msg.sender
            })
        );

        index = commitments.length - 1;
        emit RootCommitted(index, root, scope, msg.sender);
    }

    function latestCommitment() external view returns (RootCommitment memory) {
        require(commitments.length > 0, "no commitments");
        return commitments[commitments.length - 1];
    }
}
