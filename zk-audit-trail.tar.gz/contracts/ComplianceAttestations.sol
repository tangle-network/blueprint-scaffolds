// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract ComplianceAttestations {
    struct Attestation {
        bytes32 root;
        bytes32 policySetHash;
        bytes32 receiptSeal;
        address attestor;
        uint64 timestamp;
    }

    mapping(bytes32 => Attestation) public attestations;

    event ComplianceAttested(bytes32 indexed root, bytes32 indexed policySetHash, bytes32 receiptSeal, address attestor);

    function attestCompliance(bytes32 root, bytes32 policySetHash, bytes32 receiptSeal) external {
        attestations[root] = Attestation({
            root: root,
            policySetHash: policySetHash,
            receiptSeal: receiptSeal,
            attestor: msg.sender,
            timestamp: uint64(block.timestamp)
        });

        emit ComplianceAttested(root, policySetHash, receiptSeal, msg.sender);
    }
}
