// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract MultiPartyCoordinator {
    struct Session {
        bytes32 sessionId;
        bytes32 root;
        uint8 approvalsRequired;
        uint8 approvalsReceived;
        bool finalized;
    }

    mapping(bytes32 => Session) public sessions;
    mapping(bytes32 => mapping(address => bool)) public hasApproved;

    event SessionOpened(bytes32 indexed sessionId, bytes32 indexed root, uint8 approvalsRequired);
    event SessionApproved(bytes32 indexed sessionId, address indexed approver, uint8 approvalsReceived);
    event SessionFinalized(bytes32 indexed sessionId);

    function openSession(bytes32 sessionId, bytes32 root, uint8 approvalsRequired) external {
        require(sessions[sessionId].sessionId == bytes32(0), "session exists");
        require(approvalsRequired > 0, "invalid quorum");

        sessions[sessionId] = Session({
            sessionId: sessionId,
            root: root,
            approvalsRequired: approvalsRequired,
            approvalsReceived: 0,
            finalized: false
        });

        emit SessionOpened(sessionId, root, approvalsRequired);
    }

    function approve(bytes32 sessionId) external {
        Session storage session = sessions[sessionId];
        require(session.sessionId != bytes32(0), "unknown session");
        require(!session.finalized, "session finalized");
        require(!hasApproved[sessionId][msg.sender], "already approved");

        hasApproved[sessionId][msg.sender] = true;
        session.approvalsReceived += 1;

        emit SessionApproved(sessionId, msg.sender, session.approvalsReceived);

        if (session.approvalsReceived >= session.approvalsRequired) {
            session.finalized = true;
            emit SessionFinalized(sessionId);
        }
    }
}
