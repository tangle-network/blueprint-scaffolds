import React, { useState, useCallback, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Folder,
  File,
  ChevronRight,
  ChevronDown,
  Plus,
  Trash2,
  RefreshCw,
  FolderPlus,
} from "lucide-react";
import { executeTool, getChildren, getStats } from "@/lib/mcp/executor";
import { addAuditEntry } from "@/lib/safety/audit";

interface FileEntry {
  name: string;
  path: string;
  type: "file" | "directory";
  size: number;
  modified: string;
}

interface FileBrowserProps {
  onFileSelect: (path: string) => void;
  currentPath: string;
}

export function FileBrowser({ onFileSelect, currentPath }: FileBrowserProps) {
  const [expandedDirs, setExpandedDirs] = useState<Set<string>>(new Set([""]));
  const [selectedPath, setSelectedPath] = useState<string>("");
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [newItemName, setNewItemName] = useState("");
  const [showNewInput, setShowNewInput] = useState<string | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);

  const toggleDir = useCallback((dirPath: string) => {
    setExpandedDirs((prev) => {
      const next = new Set(prev);
      if (next.has(dirPath)) next.delete(dirPath);
      else next.add(dirPath);
      return next;
    });
  }, []);

  const refresh = useCallback(() => setRefreshKey((k) => k + 1), []);

  const handleDelete = useCallback(() => {
    if (!deleteTarget) return;
    executeTool("delete_path", { path: deleteTarget, recursive: true });
    setDeleteTarget(null);
    refresh();
  }, [deleteTarget, refresh]);

  const handleCreate = useCallback(
    (parentPath: string, name: string, isDir: boolean) => {
      const fullPath = parentPath ? `${parentPath}/${name}` : name;
      if (isDir) {
        executeTool("create_directory", { path: fullPath });
      } else {
        executeTool("write_file", { path: fullPath, content: "" });
        onFileSelect(fullPath);
      }
      setShowNewInput(null);
      setNewItemName("");
      refresh();
    },
    [refresh, onFileSelect]
  );

  const renderTree = (dirPath: string, depth: number): React.ReactNode => {
    const children = getChildren(dirPath);
    if (children.length === 0 && depth > 0) return null;

    return children.map((name) => {
      const stat = getStats(name, dirPath);
      const isExpanded = expandedDirs.has(stat.path);
      const isSelected = selectedPath === stat.path || currentPath === stat.path;
      const paddingLeft = depth * 16 + 8;

      return (
        <React.Fragment key={stat.path}>
          <div
            className={`flex items-center py-1 px-2 cursor-pointer hover:bg-accent group ${
              isSelected ? "bg-accent" : ""
            }`}
            style={{ paddingLeft }}
            onClick={() => {
              if (stat.type === "directory") {
                toggleDir(stat.path);
              } else {
                setSelectedPath(stat.path);
                onFileSelect(stat.path);
              }
            }}
          >
            {stat.type === "directory" ? (
              <>
                {isExpanded ? (
                  <ChevronDown className="h-4 w-4 shrink-0 mr-1" />
                ) : (
                  <ChevronRight className="h-4 w-4 shrink-0 mr-1" />
                )}
                <Folder className="h-4 w-4 shrink-0 mr-2 text-blue-500" />
              </>
            ) : (
              <>
                <span className="w-5 shrink-0 mr-1" />
                <File className="h-4 w-4 shrink-0 mr-2 text-gray-500" />
              </>
            )}
            <span className="truncate text-sm flex-1">{stat.name}</span>
            <span className="text-xs text-muted-foreground ml-2">
              {stat.type === "file" ? formatSize(stat.size) : ""}
            </span>
            <div className="opacity-0 group-hover:opacity-100 flex gap-1 ml-2">
              <button
                className="p-0.5 hover:bg-destructive/20 rounded"
                onClick={(e) => {
                  e.stopPropagation();
                  setDeleteTarget(stat.path);
                }}
              >
                <Trash2 className="h-3 w-3 text-destructive" />
              </button>
            </div>
          </div>
          {stat.type === "directory" && isExpanded && renderTree(stat.path, depth + 1)}
          {showNewInput === stat.path && (
            <div className="flex items-center gap-1 py-1 px-2" style={{ paddingLeft: (depth + 1) * 16 + 8 }}>
              <Input
                value={newItemName}
                onChange={(e) => setNewItemName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && newItemName) {
                    handleCreate(stat.path, newItemName, false);
                  }
                  if (e.key === "Escape") setShowNewInput(null);
                }}
                placeholder="filename..."
                className="h-7 text-xs"
                autoFocus
              />
              <Button
                size="sm"
                variant="ghost"
                className="h-7 px-2"
                onClick={() => newItemName && handleCreate(stat.path, newItemName, false)}
              >
                <Plus className="h-3 w-3" />
              </Button>
            </div>
          )}
        </React.Fragment>
      );
    });
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between p-2 border-b">
        <h2 className="text-sm font-semibold">Files</h2>
        <div className="flex gap-1">
          <Button
            size="icon"
            variant="ghost"
            className="h-7 w-7"
            onClick={() => {
              setShowNewInput("");
              setNewItemName("");
            }}
            title="New file"
          >
            <Plus className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="h-7 w-7"
            onClick={() => {
              setShowNewInput("");
              setNewItemName("");
            }}
            title="New folder"
          >
            <FolderPlus className="h-4 w-4" />
          </Button>
          <Button size="icon" variant="ghost" className="h-7 w-7" onClick={refresh} title="Refresh">
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </div>
      <ScrollArea className="flex-1">
        <div className="py-1">
          {showNewInput === "" && (
            <div className="flex items-center gap-1 px-2 py-1">
              <Input
                value={newItemName}
                onChange={(e) => setNewItemName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && newItemName) {
                    handleCreate("", newItemName, false);
                  }
                  if (e.key === "Escape") setShowNewInput(null);
                }}
                placeholder="new file..."
                className="h-7 text-xs"
                autoFocus
              />
              <Button size="sm" variant="ghost" className="h-7 px-2" onClick={() => newItemName && handleCreate("", newItemName, false)}>
                <Plus className="h-3 w-3" />
              </Button>
            </div>
          )}
          {renderTree("", 0)}
        </div>
      </ScrollArea>

      <AlertDialog open={!!deleteTarget} onOpenChange={() => setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Delete</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{deleteTarget}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes}B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)}KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)}MB`;
}
