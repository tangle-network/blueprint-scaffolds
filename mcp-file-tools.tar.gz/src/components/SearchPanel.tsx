import React, { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Search, FileSearch, Clock, HardDrive } from "lucide-react";
import { executeTool } from "@/lib/mcp/executor";

interface SearchResult {
  path: string;
  line?: number;
  content?: string;
  size?: number;
  type?: string;
  modified?: string;
}

export function SearchPanel() {
  const [globPattern, setGlobPattern] = useState("**/*.ts");
  const [grepPattern, setGrepPattern] = useState("");
  const [basePath, setBasePath] = useState("");
  const [timeAfter, setTimeAfter] = useState("");
  const [timeBefore, setTimeBefore] = useState("");
  const [sizeMin, setSizeMin] = useState("");
  const [sizeMax, setSizeMax] = useState("");
  const [results, setResults] = useState<SearchResult[]>([]);
  const [count, setCount] = useState<number>(0);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("glob");

  const handleGlobSearch = useCallback(() => {
    setLoading(true);
    const result = executeTool("search_glob", {
      pattern: globPattern,
      basePath: basePath || undefined,
    });
    if (result.success && result.data) {
      const d = result.data as { matches: string[]; count: number };
      setResults(d.matches.map((m) => ({ path: m })));
      setCount(d.count);
    } else {
      setResults([]);
      setCount(0);
    }
    setLoading(false);
  }, [globPattern, basePath]);

  const handleGrepSearch = useCallback(() => {
    if (!grepPattern) return;
    setLoading(true);
    const result = executeTool("search_grep", {
      pattern: grepPattern,
      basePath: basePath || undefined,
    });
    if (result.success && result.data) {
      const d = result.data as { results: SearchResult[]; count: number };
      setResults(d.results);
      setCount(d.count);
    } else {
      setResults([]);
      setCount(0);
    }
    setLoading(false);
  }, [grepPattern, basePath]);

  const handleTimeSearch = useCallback(() => {
    if (!basePath) return;
    setLoading(true);
    const result = executeTool("search_by_time", {
      basePath,
      after: timeAfter || undefined,
      before: timeBefore || undefined,
    });
    if (result.success && result.data) {
      const d = result.data as { matches: SearchResult[]; count: number };
      setResults(d.matches);
      setCount(d.count);
    } else {
      setResults([]);
      setCount(0);
    }
    setLoading(false);
  }, [basePath, timeAfter, timeBefore]);

  const handleSizeSearch = useCallback(() => {
    if (!basePath) return;
    setLoading(true);
    const result = executeTool("search_by_size", {
      basePath,
      minSize: sizeMin ? parseInt(sizeMin) : undefined,
      maxSize: sizeMax ? parseInt(sizeMax) : undefined,
    });
    if (result.success && result.data) {
      const d = result.data as { matches: SearchResult[]; count: number };
      setResults(d.matches);
      setCount(d.count);
    } else {
      setResults([]);
      setCount(0);
    }
    setLoading(false);
  }, [basePath, sizeMin, sizeMax]);

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-2 px-3 py-2 border-b">
        <Search className="h-4 w-4" />
        <h2 className="text-sm font-semibold">Search</h2>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <div className="px-2 pt-2">
          <TabsList className="w-full">
            <TabsTrigger value="glob" className="flex-1 text-xs">
              <FileSearch className="h-3 w-3 mr-1" />
              Glob
            </TabsTrigger>
            <TabsTrigger value="grep" className="flex-1 text-xs">
              <Search className="h-3 w-3 mr-1" />
              Grep
            </TabsTrigger>
            <TabsTrigger value="time" className="flex-1 text-xs">
              <Clock className="h-3 w-3 mr-1" />
              Time
            </TabsTrigger>
            <TabsTrigger value="size" className="flex-1 text-xs">
              <HardDrive className="h-3 w-3 mr-1" />
              Size
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="glob" className="px-3 pt-2 space-y-2">
          <Input
            value={globPattern}
            onChange={(e) => setGlobPattern(e.target.value)}
            placeholder="**/*.ts"
            className="h-8 text-sm"
          />
          <Input
            value={basePath}
            onChange={(e) => setBasePath(e.target.value)}
            placeholder="Base path (optional)"
            className="h-8 text-sm"
          />
          <Button size="sm" onClick={handleGlobSearch} disabled={loading} className="w-full">
            Search Files
          </Button>
        </TabsContent>

        <TabsContent value="grep" className="px-3 pt-2 space-y-2">
          <Input
            value={grepPattern}
            onChange={(e) => setGrepPattern(e.target.value)}
            placeholder="regex pattern"
            className="h-8 text-sm"
          />
          <Input
            value={basePath}
            onChange={(e) => setBasePath(e.target.value)}
            placeholder="Base path (optional)"
            className="h-8 text-sm"
          />
          <Button size="sm" onClick={handleGrepSearch} disabled={loading || !grepPattern} className="w-full">
            Search Content
          </Button>
        </TabsContent>

        <TabsContent value="time" className="px-3 pt-2 space-y-2">
          <Input
            value={basePath}
            onChange={(e) => setBasePath(e.target.value)}
            placeholder="Base path (required)"
            className="h-8 text-sm"
          />
          <Input
            value={timeAfter}
            onChange={(e) => setTimeAfter(e.target.value)}
            placeholder="After (ISO date)"
            className="h-8 text-sm"
          />
          <Input
            value={timeBefore}
            onChange={(e) => setTimeBefore(e.target.value)}
            placeholder="Before (ISO date)"
            className="h-8 text-sm"
          />
          <Button size="sm" onClick={handleTimeSearch} disabled={loading || !basePath} className="w-full">
            Search by Time
          </Button>
        </TabsContent>

        <TabsContent value="size" className="px-3 pt-2 space-y-2">
          <Input
            value={basePath}
            onChange={(e) => setBasePath(e.target.value)}
            placeholder="Base path (required)"
            className="h-8 text-sm"
          />
          <Input
            value={sizeMin}
            onChange={(e) => setSizeMin(e.target.value)}
            placeholder="Min size (bytes)"
            type="number"
            className="h-8 text-sm"
          />
          <Input
            value={sizeMax}
            onChange={(e) => setSizeMax(e.target.value)}
            placeholder="Max size (bytes)"
            type="number"
            className="h-8 text-sm"
          />
          <Button size="sm" onClick={handleSizeSearch} disabled={loading || !basePath} className="w-full">
            Search by Size
          </Button>
        </TabsContent>
      </Tabs>

      <div className="border-t px-3 py-1">
        <Badge variant="secondary" className="text-xs">
          {count} result{count !== 1 ? "s" : ""}
        </Badge>
      </div>

      <ScrollArea className="flex-1">
        <div className="px-2 pb-2">
          {results.map((r, i) => (
            <div
              key={i}
              className="px-2 py-1.5 text-xs hover:bg-accent rounded cursor-pointer border-b border-border/50"
            >
              <div className="font-medium truncate">{r.path}</div>
              {r.line !== undefined && (
                <div className="text-muted-foreground truncate">
                  :{r.line} {r.content}
                </div>
              )}
              {r.size !== undefined && (
                <div className="text-muted-foreground">
                  {r.size} bytes
                </div>
              )}
              {r.modified && (
                <div className="text-muted-foreground">
                  {new Date(r.modified).toLocaleDateString()}
                </div>
              )}
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
