import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { ClipboardList, Trash2, RefreshCw } from "lucide-react";
import { getAuditLog, clearAuditLog } from "@/lib/mcp/executor";
import type { AuditLogEntry } from "@/lib/safety/audit";

export function AuditLogViewer() {
  const [entries, setEntries] = useState<AuditLogEntry[]>([]);
  const [filter, setFilter] = useState<string>("");

  const refresh = () => {
    setEntries(getAuditLog());
  };

  useEffect(() => {
    refresh();
    const interval = setInterval(refresh, 2000);
    return () => clearInterval(interval);
  }, []);

  const filtered = filter
    ? entries.filter(
        (e) =>
          e.tool.includes(filter) ||
          e.action.includes(filter) ||
          e.path?.includes(filter) ||
          e.status.includes(filter)
      )
    : entries;

  const statusColor = (status: string) => {
    switch (status) {
      case "success":
        return "bg-green-500/10 text-green-700 border-green-200";
      case "denied":
        return "bg-red-500/10 text-red-700 border-red-200";
      case "error":
        return "bg-yellow-500/10 text-yellow-700 border-yellow-200";
      default:
        return "";
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-3 py-2 border-b">
        <div className="flex items-center gap-2">
          <ClipboardList className="h-4 w-4" />
          <h2 className="text-sm font-semibold">Audit Log</h2>
          <Badge variant="secondary" className="text-xs">
            {entries.length}
          </Badge>
        </div>
        <div className="flex gap-1">
          <Button size="icon" variant="ghost" className="h-7 w-7" onClick={refresh}>
            <RefreshCw className="h-3.5 w-3.5" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="h-7 w-7"
            onClick={() => {
              clearAuditLog();
              refresh();
            }}
          >
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>

      <div className="px-3 py-1.5 border-b">
        <input
          type="text"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          placeholder="Filter logs..."
          className="w-full text-xs bg-transparent outline-none placeholder:text-muted-foreground"
        />
      </div>

      <ScrollArea className="flex-1">
        <div className="px-2 py-1">
          {filtered.length === 0 && (
            <div className="text-center text-xs text-muted-foreground py-4">
              No audit entries
            </div>
          )}
          {filtered.map((entry, i) => (
            <div
              key={i}
              className="flex items-start gap-2 px-2 py-1.5 text-xs border-b border-border/30 hover:bg-accent/50"
            >
              <Badge
                variant="outline"
                className={`text-[10px] px-1.5 py-0 shrink-0 ${statusColor(entry.status)}`}
              >
                {entry.status}
              </Badge>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-medium">{entry.tool}</span>
                  <span className="text-muted-foreground">{entry.action}</span>
                </div>
                {entry.path && (
                  <div className="text-muted-foreground truncate">
                    {entry.path}
                  </div>
                )}
                {entry.details && (
                  <div className="text-muted-foreground truncate">
                    {entry.details}
                  </div>
                )}
              </div>
              <span className="text-muted-foreground whitespace-nowrap text-[10px]">
                {new Date(entry.timestamp).toLocaleTimeString()}
              </span>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
