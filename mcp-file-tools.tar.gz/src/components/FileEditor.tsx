import { executeTool } from "@/lib/mcp/executor";
import { virtualFS } from "@/lib/mcp/executor";
import React, { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Save,
  FileText,
  GitCompare,
  Copy,
  RotateCcw,
} from "lucide-react";
import type { MCPToolResult } from "@/lib/mcp/types";

interface FileEditorProps {
  filePath: string;
  onSave: (path: string, content: string) => void;
}

export function FileEditor({ filePath, onSave }: FileEditorProps) {
  const [content, setContent] = useState("");
  const [originalContent, setOriginalContent] = useState("");
  const [savedContent, setSavedContent] = useState<string | null>(null);
  const [diffResult, setDiffResult] = useState<{
    unified: string;
    added: number;
    removed: number;
  } | null>(null);
  const [isDirty, setIsDirty] = useState(false);
  const [tab, setTab] = useState("edit");

  useEffect(() => {
    if (!filePath) return;
    const result: MCPToolResult = executeTool("read_file", { path: filePath });
    if (result.success && result.data) {
      const d = result.data as { content: string };
      setContent(d.content);
      setOriginalContent(d.content);
      setIsDirty(false);
      setDiffResult(null);
      setSavedContent(null);
    }
  }, [filePath]);

  const handleChange = useCallback(
    (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      const newContent = e.target.value;
      setContent(newContent);
      setIsDirty(newContent !== originalContent);
    },
    [originalContent]
  );

  const handleSave = useCallback(() => {
    const result = executeTool("write_file", {
      path: filePath,
      content,
      atomic: true,
    });
    if (result.success) {
      setOriginalContent(content);
      setIsDirty(false);
      onSave(filePath, content);
    }
  }, [filePath, content, onSave]);

  const handleDiff = useCallback(() => {
    const result = executeTool("diff_string", {
      oldContent: originalContent,
      newContent: content,
      fileName: filePath,
    });
    if (result.success && result.data) {
      setDiffResult(result.data as { unified: string; added: number; removed: number });
      setTab("diff");
    }
  }, [originalContent, content, filePath]);

  const handleReset = useCallback(() => {
    setContent(originalContent);
    setIsDirty(false);
  }, [originalContent]);

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(content);
  }, [content]);

  if (!filePath) {
    return (
      <div className="flex items-center justify-center h-full text-muted-foreground">
        <div className="text-center">
          <FileText className="h-12 w-12 mx-auto mb-3 opacity-30" />
          <p className="text-sm">Select a file to edit</p>
        </div>
      </div>
    );
  }

  const lineCount = content.split("\n").length;

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-3 py-2 border-b bg-muted/30">
        <div className="flex items-center gap-2">
          <FileText className="h-4 w-4" />
          <span className="text-sm font-medium truncate max-w-xs">{filePath}</span>
          {isDirty && (
            <Badge variant="secondary" className="text-xs">
              Modified
            </Badge>
          )}
          <span className="text-xs text-muted-foreground">
            {lineCount} lines
          </span>
        </div>
        <div className="flex gap-1">
          <Button size="sm" variant="ghost" onClick={handleCopy} title="Copy">
            <Copy className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={handleReset}
            disabled={!isDirty}
            title="Reset"
          >
            <RotateCcw className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={handleDiff}
            disabled={!isDirty}
            title="View diff"
          >
            <GitCompare className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            onClick={handleSave}
            disabled={!isDirty}
            title="Save"
          >
            <Save className="h-4 w-4 mr-1" />
            Save
          </Button>
        </div>
      </div>

      <Tabs value={tab} onValueChange={setTab} className="flex-1 flex flex-col">
        <TabsContent value="edit" className="flex-1 m-0">
          <div className="flex h-full">
            <div className="bg-muted/50 text-right pr-2 pt-2 text-xs text-muted-foreground select-none border-r font-mono leading-6 min-w-[3rem]">
              {Array.from({ length: lineCount }, (_, i) => (
                <div key={i}>{i + 1}</div>
              ))}
            </div>
            <textarea
              value={content}
              onChange={handleChange}
              className="flex-1 p-2 font-mono text-sm resize-none focus:outline-none bg-background leading-6"
              spellCheck={false}
            />
          </div>
        </TabsContent>
        <TabsContent value="diff" className="flex-1 m-0">
          <ScrollArea className="h-full">
            {diffResult ? (
              <div className="p-3">
                <div className="flex gap-2 mb-3">
                  <Badge variant="secondary">
                    +{diffResult.added} added
                  </Badge>
                  <Badge variant="destructive">
                    -{diffResult.removed} removed
                  </Badge>
                </div>
                <pre className="text-xs font-mono leading-5 whitespace-pre-wrap">
                  {diffResult.unified.split("\n").map((line, i) => (
                    <div
                      key={i}
                      className={
                        line.startsWith("+")
                          ? "bg-green-500/10 text-green-700"
                          : line.startsWith("-")
                          ? "bg-red-500/10 text-red-700"
                          : ""
                      }
                    >
                      {line}
                    </div>
                  ))}
                </pre>
              </div>
            ) : (
              <div className="p-3 text-sm text-muted-foreground">
                No diff to display
              </div>
            )}
          </ScrollArea>
        </TabsContent>
      </Tabs>
    </div>
  );
}
