import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import {
  Wrench,
  Play,
  ChevronDown,
  ChevronRight,
  FolderOpen,
  FileText,
  FolderPlus,
  PenLine,
  Trash2,
  ArrowRightLeft,
  Search,
  GitCompare,
  Eye,
} from "lucide-react";
import { MCP_TOOLS } from "@/lib/mcp/types";
import { executeTool } from "@/lib/mcp/executor";
import type { MCPToolResult, MCPToolDefinition } from "@/lib/mcp/types";

const categoryIcons: Record<string, React.ReactNode> = {
  read: <Eye className="h-3.5 w-3.5" />,
  write: <PenLine className="h-3.5 w-3.5" />,
  directory: <FolderOpen className="h-3.5 w-3.5" />,
  search: <Search className="h-3.5 w-3.5" />,
  diff: <GitCompare className="h-3.5 w-3.5" />,
};

export function ToolPanel() {
  const [selectedTool, setSelectedTool] = useState<MCPToolDefinition | null>(null);
  const [paramValues, setParamValues] = useState<Record<string, string>>({});
  const [result, setResult] = useState<MCPToolResult | null>(null);
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(
    new Set(["read", "write", "directory", "search", "diff"])
  );

  const categories = ["read", "write", "directory", "search", "diff"] as const;

  const toggleCategory = (cat: string) => {
    setExpandedCategories((prev) => {
      const next = new Set(prev);
      if (next.has(cat)) next.delete(cat);
      else next.add(cat);
      return next;
    });
  };

  const selectTool = (tool: MCPToolDefinition) => {
    setSelectedTool(tool);
    const defaults: Record<string, string> = {};
    tool.parameters.forEach((p) => {
      if (p.default !== undefined) defaults[p.name] = String(p.default);
      else defaults[p.name] = "";
    });
    setParamValues(defaults);
    setResult(null);
  };

  const execute = () => {
    if (!selectedTool) return;
    const params: Record<string, unknown> = {};
    selectedTool.parameters.forEach((p) => {
      const val = paramValues[p.name];
      if (val === "" || val === undefined) return;
      if (p.type === "number") params[p.name] = Number(val);
      else if (p.type === "boolean") params[p.name] = val === "true";
      else params[p.name] = val;
    });
    setResult(executeTool(selectedTool.name, params));
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-2 px-3 py-2 border-b">
        <Wrench className="h-4 w-4" />
        <h2 className="text-sm font-semibold">MCP Tools</h2>
      </div>

      <div className="flex-1 flex flex-col overflow-hidden">
        <ScrollArea className="flex-1">
          <div className="px-2 py-1">
            {categories.map((cat) => {
              const tools = MCP_TOOLS.filter((t) => t.category === cat);
              const isExpanded = expandedCategories.has(cat);
              return (
                <div key={cat}>
                  <button
                    className="flex items-center gap-1.5 w-full px-2 py-1.5 text-xs font-medium capitalize hover:bg-accent rounded"
                    onClick={() => toggleCategory(cat)}
                  >
                    {isExpanded ? (
                      <ChevronDown className="h-3 w-3" />
                    ) : (
                      <ChevronRight className="h-3 w-3" />
                    )}
                    {categoryIcons[cat]}
                    {cat}
                    <Badge variant="secondary" className="text-[10px] ml-auto px-1.5 py-0">
                      {tools.length}
                    </Badge>
                  </button>
                  {isExpanded &&
                    tools.map((tool) => (
                      <button
                        key={tool.name}
                        className={`flex items-center gap-2 w-full px-3 py-1.5 text-xs ml-2 rounded hover:bg-accent ${
                          selectedTool?.name === tool.name ? "bg-accent" : ""
                        }`}
                        onClick={() => selectTool(tool)}
                      >
                        <span className="truncate">{tool.name}</span>
                        {tool.destructive && (
                          <Badge variant="destructive" className="text-[10px] px-1 py-0 ml-auto">
                            !
                          </Badge>
                        )}
                      </button>
                    ))}
                </div>
              );
            })}
          </div>
        </ScrollArea>

        {selectedTool && (
          <div className="border-t flex flex-col max-h-[50%]">
            <div className="px-3 py-2 border-b bg-muted/30">
              <div className="text-xs font-medium">{selectedTool.name}</div>
              <div className="text-xs text-muted-foreground">
                {selectedTool.description}
              </div>
            </div>
            <ScrollArea className="flex-1">
              <div className="px-3 py-2 space-y-2">
                {selectedTool.parameters.map((p) => (
                  <div key={p.name}>
                    <label className="text-xs font-medium">
                      {p.name}
                      {p.required && <span className="text-destructive">*</span>}
                      {!p.required && (
                        <span className="text-muted-foreground ml-1">(opt)</span>
                      )}
                    </label>
                    {p.type === "string" && p.name === "content" ? (
                      <Textarea
                        value={paramValues[p.name] || ""}
                        onChange={(e) =>
                          setParamValues((prev) => ({
                            ...prev,
                            [p.name]: e.target.value,
                          }))
                        }
                        placeholder={p.description}
                        className="mt-0.5 text-xs h-20"
                      />
                    ) : (
                      <Input
                        value={paramValues[p.name] || ""}
                        onChange={(e) =>
                          setParamValues((prev) => ({
                            ...prev,
                            [p.name]: e.target.value,
                          }))
                        }
                        placeholder={p.description}
                        type={p.type === "number" ? "number" : "text"}
                        className="mt-0.5 h-7 text-xs"
                      />
                    )}
                  </div>
                ))}
                <Button size="sm" onClick={execute} className="w-full">
                  <Play className="h-3 w-3 mr-1" />
                  Execute
                </Button>
              </div>
            </ScrollArea>

            {result && (
              <div className="border-t">
                <div className="px-3 py-1 text-xs font-medium bg-muted/30">
                  Result:{" "}
                  <Badge
                    variant={result.success ? "secondary" : "destructive"}
                    className="text-[10px]"
                  >
                    {result.success ? "Success" : "Error"}
                  </Badge>
                </div>
                <ScrollArea className="max-h-32">
                  <pre className="px-3 py-1.5 text-xs font-mono whitespace-pre-wrap break-all">
                    {result.error
                      ? result.error
                      : JSON.stringify(result.data, null, 2)}
                  </pre>
                </ScrollArea>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
