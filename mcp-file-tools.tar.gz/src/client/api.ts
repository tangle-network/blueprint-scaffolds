import type { FileMetadata, AuditEntry, SearchResult, DiffResult, ToolResponse } from "../shared/types";

const API_BASE = "/api";

async function apiCall<T>(endpoint: string, body?: unknown): Promise<ToolResponse<T>> {
  const res = await fetch(`${API_BASE}${endpoint}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  return res.json();
}

export const api = {
  listDirectory: (path: string, recursive = false) =>
    apiCall<FileMetadata[]>("/directory/list", { path, recursive }),

  createDirectory: (path: string, recursive = true) =>
    apiCall("/directory/create", { path, recursive }),

  movePath: (source: string, destination: string) =>
    apiCall("/directory/move", { source, destination }),

  deletePath: (path: string, recursive = false) =>
    apiCall("/directory/delete", { path, recursive }),

  readFile: (path: string, mode: "text" | "binary" | "atomic" = "text") =>
    apiCall<{ content: string; size: number }>("/file/read", { path, mode }),

  writeFile: (path: string, content: string, mode: "text" | "binary" | "atomic" = "text", overwrite = true) =>
    apiCall("/file/write", { path, content, mode, overwrite, createDirs: true }),

  getMetadata: (path: string) =>
    apiCall<FileMetadata>("/file/metadata", { path }),

  searchGlob: (pattern: string, cwd: string) =>
    apiCall<string[]>("/search/glob", { pattern, cwd }),

  searchGrep: (pattern: string, path: string, include?: string[]) =>
    apiCall<SearchResult[]>("/search/grep", { pattern, path, include }),

  generateDiff: (oldPath: string, newPath: string) =>
    apiCall<DiffResult>("/diff", { oldPath, newPath }),

  getAuditLog: (limit = 100) =>
    apiCall<AuditEntry[]>("/audit/log", { limit }),

  getPendingConfirmations: () =>
    apiCall("/confirmations", {}),

  confirmAction: (id: string, approved: boolean) =>
    apiCall(`/confirmations/${id}`, { approved }),
};
