import type {
  ApiErrorShape,
  CreateDirectoryRequest,
  DeletePathRequest,
  DiffRequest,
  DiffResponse,
  ListDirectoryRequest,
  ListDirectoryResponse,
  MovePathRequest,
  ReadFileRequest,
  ReadFileResponse,
  SearchGlobRequest,
  SearchGrepRequest,
  SearchMetadataRequest,
  SearchResponse,
  WriteFileRequest,
  WriteFileResponse
} from "../shared/contracts";

const apiBase = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:4321";

async function request<T>(endpoint: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${apiBase}${endpoint}`, {
    headers: { "content-type": "application/json" },
    ...init
  });

  if (!response.ok) {
    const error = (await response.json()) as ApiErrorShape;
    throw error;
  }

  return (await response.json()) as T;
}

export const api = {
  roots: () => request<{ roots: string[] }>("/api/roots"),
  list: (payload: ListDirectoryRequest) =>
    request<ListDirectoryResponse>("/api/list", { method: "POST", body: JSON.stringify(payload) }),
  read: (payload: ReadFileRequest) =>
    request<ReadFileResponse>("/api/read", { method: "POST", body: JSON.stringify(payload) }),
  write: (payload: WriteFileRequest) =>
    request<WriteFileResponse>("/api/write", { method: "POST", body: JSON.stringify(payload) }),
  createDirectory: (payload: CreateDirectoryRequest) =>
    request<{ path: string }>("/api/directory", { method: "POST", body: JSON.stringify(payload) }),
  move: (payload: MovePathRequest) =>
    request<{ source: string; destination: string }>("/api/move", {
      method: "POST",
      body: JSON.stringify(payload)
    }),
  delete: (payload: DeletePathRequest) =>
    request<{ path: string; deleted: true }>("/api/delete", {
      method: "POST",
      body: JSON.stringify(payload)
    }),
  searchGlob: (payload: SearchGlobRequest) =>
    request<SearchResponse>("/api/search/glob", { method: "POST", body: JSON.stringify(payload) }),
  searchGrep: (payload: SearchGrepRequest) =>
    request<SearchResponse>("/api/search/grep", { method: "POST", body: JSON.stringify(payload) }),
  searchMetadata: (payload: SearchMetadataRequest) =>
    request<SearchResponse>("/api/search/metadata", {
      method: "POST",
      body: JSON.stringify(payload)
    }),
  diff: (payload: DiffRequest) =>
    request<DiffResponse>("/api/diff", { method: "POST", body: JSON.stringify(payload) })
};
