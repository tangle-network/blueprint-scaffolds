export type EntryType = "file" | "directory" | "symlink" | "other";
export type EncodingMode = "utf8" | "base64";

export interface FileEntry {
  name: string;
  path: string;
  type: EntryType;
  size: number;
  modifiedAt: string;
}

export interface ListDirectoryRequest {
  path: string;
  includeHidden?: boolean;
  recursive?: boolean;
  maxEntries?: number;
}

export interface ListDirectoryResponse {
  cwd: string;
  entries: FileEntry[];
  truncated: boolean;
}

export interface ReadFileRequest {
  path: string;
  encoding?: EncodingMode;
  offset?: number;
  length?: number;
}

export interface ReadFileResponse {
  path: string;
  encoding: EncodingMode;
  content: string;
  size: number;
  truncated: boolean;
}

export interface WriteFileRequest {
  path: string;
  content: string;
  encoding?: EncodingMode;
  atomic?: boolean;
  createDirectories?: boolean;
}

export interface WriteFileResponse {
  path: string;
  bytesWritten: number;
  atomic: boolean;
}

export interface CreateDirectoryRequest {
  path: string;
  recursive?: boolean;
}

export interface MovePathRequest {
  source: string;
  destination: string;
  overwrite?: boolean;
  confirmationToken?: string;
}

export interface DeletePathRequest {
  path: string;
  recursive?: boolean;
  confirmationToken?: string;
}

export interface SearchGlobRequest {
  root: string;
  pattern: string;
  includeHidden?: boolean;
  maxResults?: number;
}

export interface SearchGrepRequest {
  root: string;
  query: string;
  caseSensitive?: boolean;
  includeHidden?: boolean;
  maxResults?: number;
}

export interface SearchMetadataRequest {
  root: string;
  minSize?: number;
  maxSize?: number;
  modifiedAfter?: string;
  modifiedBefore?: string;
  includeHidden?: boolean;
  maxResults?: number;
}

export interface SearchMatch {
  path: string;
  preview?: string;
  size: number;
  modifiedAt: string;
}

export interface SearchResponse {
  matches: SearchMatch[];
  truncated: boolean;
}

export interface DiffRequest {
  path: string;
  nextContent: string;
}

export interface DiffResponse {
  path: string;
  diff: string;
}

export interface ApiErrorShape {
  error: string;
  confirmationToken?: string;
}

export interface ConfirmationRequired extends ApiErrorShape {
  error: "confirmation_required";
  confirmationToken: string;
}

export interface AuditRecord {
  at: string;
  action: string;
  path?: string;
  detail?: Record<string, unknown>;
  status: "ok" | "error" | "blocked";
  message?: string;
}
