export const generateId = {} as any
