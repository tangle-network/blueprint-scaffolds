export interface AuditEntry {
  timestamp: string;
  tool: string;
  operation: string;
  path: string;
  success: boolean;
  details?: string;
  error?: string;
}

export interface SandboxedPath {
  resolved: string;
  relative: string;
  allowed: boolean;
}

export interface FileMetadata {
  name: string;
  path: string;
  size: number;
  isDirectory: boolean;
  isFile: boolean;
  modified: string;
  created: string;
  permissions: string;
}

export interface SearchResult {
  path: string;
  line?: number;
  column?: number;
  match?: string;
  context?: string;
}

export interface DiffResult {
  oldPath: string;
  newPath: string;
  hunks: number;
  patch: string;
}

export interface ConfirmationRequest {
  id: string;
  operation: string;
  path: string;
  details?: string;
}

export interface ToolResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  auditId?: string;
}

export type ReadMode = "text" | "binary" | "atomic";

export interface ReadOptions {
  path: string;
  mode: ReadMode;
  encoding?: string;
  offset?: number;
  limit?: number;
}

export interface WriteOptions {
  path: string;
  content: string;
  mode: "text" | "binary" | "atomic";
  encoding?: string;
  createDirs?: boolean;
  overwrite?: boolean;
}

export interface SearchGlobOptions {
  pattern: string;
  cwd: string;
  ignore?: string[];
  dot?: boolean;
  absolute?: boolean;
}

export interface SearchGrepOptions {
  pattern: string;
  path: string;
  include?: string[];
  maxResults?: number;
  contextLines?: number;
}

export interface SearchTimeOptions {
  path: string;
  modifiedAfter?: string;
  modifiedBefore?: string;
  createdAfter?: string;
  createdBefore?: string;
}

export interface SearchSizeOptions {
  path: string;
  minSize?: number;
  maxSize?: number;
  recursive?: boolean;
}
