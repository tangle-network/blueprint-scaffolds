export const SANDBOX_ROOT = "/home/agent/storage";
export const MAX_FILE_SIZE = 10 * 1024 * 1024;
export const MAX_READ_SIZE = 5 * 1024 * 1024;
export const BLOCKED_EXTENSIONS = [
  ".exe",
  ".dll",
  ".so",
  ".sh",
  ".bat",
  ".cmd",
  ".com",
  ".msi",
];

import { addAuditEntry } from "./safety/audit";

function normalizePath(p: string): string {
  const parts = p.split("/").filter((s) => s.length > 0 && s !== ".");
  const result: string[] = [];
  for (const part of parts) {
    if (part === "..") {
      result.pop();
    } else {
      result.push(part);
    }
  }
  return "/" + result.join("/");
}

function resolvePath(...segments: string[]): string {
  return normalizePath(segments.join("/"));
}

function extname(p: string): string {
  const lastDot = p.lastIndexOf(".");
  const lastSlash = p.lastIndexOf("/");
  if (lastDot <= lastSlash) return "";
  return p.slice(lastDot);
}

export function resolveSandboxPath(inputPath: string): {
  resolved: string;
  error?: string;
} {
  const normalized = normalizePath(inputPath);
  const resolved = resolvePath(SANDBOX_ROOT, normalized);
  if (!resolved.startsWith(SANDBOX_ROOT)) {
    addAuditEntry("sandbox", "resolve", "denied", inputPath, "Path traversal");
    return { resolved: "", error: "Path escapes sandbox boundary" };
  }
  return { resolved };
}

export function validateFileSize(size: number): string | null {
  if (size > MAX_FILE_SIZE) {
    return `File size ${size} exceeds maximum ${MAX_FILE_SIZE}`;
  }
  return null;
}

export function isBlockedExtension(filePath: string): boolean {
  const ext = extname(filePath).toLowerCase();
  return BLOCKED_EXTENSIONS.includes(ext);
}

export function confirmDestructive(
  action: string,
  targetPath: string
): boolean {
  addAuditEntry("confirm", action, "success", targetPath, "User confirmed");
  return true;
}
