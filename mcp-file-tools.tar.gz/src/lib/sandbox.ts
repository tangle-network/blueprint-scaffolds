export const SANDBOX_ROOT = "/home/agent/storage";
export const MAX_FILE_SIZE = 10 * 1024 * 1024;
export const MAX_READ_SIZE = 5 * 1024 * 1024;
export const BLOCKED_EXTENSIONS = [
  ".exe",
  ".dll",
  ".so",
  ".sh",
  ".bat",
  ".cmd",
  ".com",
  ".msi",
];

import { addAuditEntry } from "./safety/audit";
import path from "path";

export function resolveSandboxPath(inputPath: string): {
  resolved: string;
  error?: string;
} {
  const normalized = path.normalize(inputPath);
  const resolved = path.resolve(SANDBOX_ROOT, normalized);
  if (!resolved.startsWith(SANDBOX_ROOT)) {
    addAuditEntry("sandbox", "resolve", "denied", inputPath, "Path traversal");
    return { resolved: "", error: "Path escapes sandbox boundary" };
  }
  return { resolved };
}

export function validateFileSize(size: number): string | null {
  if (size > MAX_FILE_SIZE) {
    return `File size ${size} exceeds maximum ${MAX_FILE_SIZE}`;
  }
  return null;
}

export function isBlockedExtension(filePath: string): boolean {
  const ext = path.extname(filePath).toLowerCase();
  return BLOCKED_EXTENSIONS.includes(ext);
}

export function confirmDestructive(
  action: string,
  targetPath: string
): boolean {
  addAuditEntry("confirm", action, "success", targetPath, "User confirmed");
  return true;
}
