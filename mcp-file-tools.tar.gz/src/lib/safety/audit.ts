export interface AuditLogEntry {
  timestamp: string;
  tool: string;
  action: string;
  path?: string;
  details?: string;
  status: "success" | "denied" | "error";
}

const logEntries: AuditLogEntry[] = [];

export function addAuditEntry(
  tool: string,
  action: string,
  status: AuditLogEntry["status"],
  path?: string,
  details?: string
): void {
  logEntries.push({
    timestamp: new Date().toISOString(),
    tool,
    action,
    path,
    details,
    status,
  });
  if (logEntries.length > 1000) logEntries.shift();
}

export function getAuditLog(): AuditLogEntry[] {
  return [...logEntries];
}

export function clearAuditLog(): void {
  logEntries.length = 0;
}
