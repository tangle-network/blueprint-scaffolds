export interface MCPToolParameter {
  name: string;
  type: "string" | "number" | "boolean" | "object" | "array";
  description: string;
  required?: boolean;
  default?: unknown;
}

export interface MCPToolDefinition {
  name: string;
  description: string;
  category: "read" | "write" | "directory" | "search" | "diff";
  parameters: MCPToolParameter[];
  destructive?: boolean;
}

export interface MCPToolResult {
  success: boolean;
  data?: unknown;
  error?: string;
  auditId?: string;
}

export const MCP_TOOLS: MCPToolDefinition[] = [
  {
    name: "read_file",
    description: "Read text file content from sandbox",
    category: "read",
    parameters: [
      { name: "path", type: "string", description: "File path relative to sandbox", required: true },
      { name: "encoding", type: "string", description: "Text encoding (default: utf-8)", default: "utf-8" },
      { name: "offset", type: "number", description: "Start line (0-based)" },
      { name: "limit", type: "number", description: "Max lines to read" },
    ],
  },
  {
    name: "read_file_binary",
    description: "Read file as binary (base64 encoded)",
    category: "read",
    parameters: [
      { name: "path", type: "string", description: "File path relative to sandbox", required: true },
      { name: "offset", type: "number", description: "Start byte offset" },
      { name: "limit", type: "number", description: "Max bytes to read" },
    ],
  },
  {
    name: "write_file",
    description: "Write text content to a file (atomic)",
    category: "write",
    destructive: true,
    parameters: [
      { name: "path", type: "string", description: "File path relative to sandbox", required: true },
      { name: "content", type: "string", description: "Text content to write", required: true },
      { name: "atomic", type: "boolean", description: "Use atomic write (write to temp then rename)", default: true },
    ],
  },
  {
    name: "write_file_binary",
    description: "Write binary data (base64 encoded) to a file",
    category: "write",
    destructive: true,
    parameters: [
      { name: "path", type: "string", description: "File path relative to sandbox", required: true },
      { name: "content", type: "string", description: "Base64 encoded content", required: true },
    ],
  },
  {
    name: "list_directory",
    description: "List directory contents",
    category: "directory",
    parameters: [
      { name: "path", type: "string", description: "Directory path relative to sandbox", required: true },
      { name: "recursive", type: "boolean", description: "List recursively", default: false },
    ],
  },
  {
    name: "create_directory",
    description: "Create a directory (and parents)",
    category: "directory",
    parameters: [
      { name: "path", type: "string", description: "Directory path relative to sandbox", required: true },
    ],
  },
  {
    name: "move_path",
    description: "Move or rename a file/directory",
    category: "directory",
    destructive: true,
    parameters: [
      { name: "source", type: "string", description: "Source path relative to sandbox", required: true },
      { name: "destination", type: "string", description: "Destination path relative to sandbox", required: true },
    ],
  },
  {
    name: "delete_path",
    description: "Delete a file or directory",
    category: "directory",
    destructive: true,
    parameters: [
      { name: "path", type: "string", description: "Path to delete relative to sandbox", required: true },
      { name: "recursive", type: "boolean", description: "Delete recursively for directories", default: false },
    ],
  },
  {
    name: "search_glob",
    description: "Search files by glob pattern",
    category: "search",
    parameters: [
      { name: "pattern", type: "string", description: "Glob pattern (e.g. **/*.ts)", required: true },
      { name: "basePath", type: "string", description: "Base directory for search" },
    ],
  },
  {
    name: "search_grep",
    description: "Search file contents by regex pattern",
    category: "search",
    parameters: [
      { name: "pattern", type: "string", description: "Regex pattern to search", required: true },
      { name: "basePath", type: "string", description: "Base directory for search" },
      { name: "filePattern", type: "string", description: "File glob filter (e.g. *.ts)", default: "*" },
    ],
  },
  {
    name: "search_by_time",
    description: "Search files by modification time",
    category: "search",
    parameters: [
      { name: "basePath", type: "string", description: "Base directory", required: true },
      { name: "after", type: "string", description: "ISO date string - modified after" },
      { name: "before", type: "string", description: "ISO date string - modified before" },
    ],
  },
  {
    name: "search_by_size",
    description: "Search files by size range",
    category: "search",
    parameters: [
      { name: "basePath", type: "string", description: "Base directory", required: true },
      { name: "minSize", type: "number", description: "Minimum size in bytes" },
      { name: "maxSize", type: "number", description: "Maximum size in bytes" },
    ],
  },
  {
    name: "diff_files",
    description: "Generate diff between two files",
    category: "diff",
    parameters: [
      { name: "pathA", type: "string", description: "First file path", required: true },
      { name: "pathB", type: "string", description: "Second file path", required: true },
    ],
  },
  {
    name: "diff_string",
    description: "Generate diff between two strings",
    category: "diff",
    parameters: [
      { name: "oldContent", type: "string", description: "Original content", required: true },
      { name: "newContent", type: "string", description: "New content", required: true },
      { name: "fileName", type: "string", description: "Label for diff output" },
    ],
  },
];
