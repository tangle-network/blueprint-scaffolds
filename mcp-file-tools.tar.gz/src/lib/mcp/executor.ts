import { MCPToolResult, MCP_TOOLS } from "./types";
import {
  resolveSandboxPath,
  validateFileSize,
  isBlockedExtension,
  confirmDestructive,
} from "../sandbox";
import { addAuditEntry, getAuditLog, clearAuditLog } from "../safety/audit";

interface VirtualFS {
  [key: string]: string | null;
}

let virtualFS: VirtualFS = {
  "README.md": "# MCP File System Tools\n\nA sandboxed file system tool suite for safe file operations.",
  "src/index.ts": 'export { read_file, write_file } from "./tools";\n',
  "src/tools.ts": "export function read_file(path: string): string {\n  return 'content of ' + path;\n}\n\nexport function write_file(path: string, content: string): void {\n  console.log('writing to', path);\n}\n",
  "src/utils.ts": "export function formatDate(d: Date): string {\n  return d.toISOString();\n}\n",
  "package.json": '{\n  "name": "example-project",\n  "version": "1.0.0"\n}\n',
  "docs/guide.md": "# User Guide\n\nThis is a sample project demonstrating MCP tools.\n",
  "config/settings.json": '{\n  "theme": "dark",\n  "fontSize": 14\n}\n',
  "data/sample.csv": "name,age,city\nAlice,30,NYC\nBob,25,LA\nCharlie,35,SF\n",
};

function ensureDir(filePath: string): void {
  const parts = filePath.split("/");
  for (let i = 1; i < parts.length; i++) {
    const dir = parts.slice(0, i).join("/");
    if (!virtualFS[dir]) {
      virtualFS[dir] = null;
    }
  }
}

function isDir(key: string): boolean {
  return virtualFS[key] === null || Object.keys(virtualFS).some((k) => k.startsWith(key + "/"));
}

function getChildren(dirPath: string): string[] {
  const prefix = dirPath === "" ? "" : dirPath + "/";
  const entries = new Set<string>();
  for (const key of Object.keys(virtualFS)) {
    if (prefix === "" || key.startsWith(prefix)) {
      const relative = prefix === "" ? key : key.slice(prefix.length);
      const firstPart = relative.split("/")[0];
      if (firstPart) entries.add(firstPart);
    }
  }
  return Array.from(entries).sort();
}

function getStats(name: string, parentPath: string) {
  const fullPath = parentPath ? `${parentPath}/${name}` : name;
  const entry = virtualFS[fullPath];
  const isDirectory = entry === null || isDir(fullPath);
  return {
    name,
    path: fullPath,
    type: isDirectory ? ("directory" as const) : ("file" as const),
    size: isDirectory ? 0 : (entry?.length ?? 0),
    modified: new Date(Date.now() - Math.random() * 86400000 * 30).toISOString(),
  };
}

export function executeTool(
  toolName: string,
  params: Record<string, unknown>
): MCPToolResult {
  const tool = MCP_TOOLS.find((t) => t.name === toolName);
  if (!tool) {
    addAuditEntry(toolName, "unknown", "error", undefined, "Tool not found");
    return { success: false, error: `Unknown tool: ${toolName}` };
  }

  const pathParam = (params.path as string) || "";
  const sourceParam = (params.source as string) || "";
  const destParam = (params.destination as string) || "";

  if (tool.category !== "diff" || toolName === "diff_files") {
    const checkPath = pathParam || sourceParam;
    if (checkPath) {
      const { resolved, error } = resolveSandboxPath(checkPath);
      if (error) {
        return { success: false, error };
      }
    }
  }

  if (tool.destructive && !confirmDestructive(toolName, pathParam || sourceParam)) {
    return { success: false, error: "Operation cancelled by user" };
  }

  try {
    let result: unknown;

    switch (toolName) {
      case "read_file": {
        const content = virtualFS[pathParam];
        if (content === undefined) {
          addAuditEntry(toolName, "read", "error", pathParam, "File not found");
          return { success: false, error: `File not found: ${pathParam}` };
        }
        if (content === null) {
          addAuditEntry(toolName, "read", "error", pathParam, "Is a directory");
          return { success: false, error: `Is a directory: ${pathParam}` };
        }
        let output = content;
        const offset = (params.offset as number) || 0;
        const limit = params.limit as number | undefined;
        const lines = output.split("\n");
        const sliced = lines.slice(offset, limit ? offset + limit : undefined);
        addAuditEntry(toolName, "read", "success", pathParam);
        result = {
          content: sliced.join("\n"),
          totalLines: lines.length,
          returnedLines: sliced.length,
          encoding: params.encoding || "utf-8",
        };
        break;
      }

      case "read_file_binary": {
        const content = virtualFS[pathParam];
        if (content === undefined) {
          return { success: false, error: `File not found: ${pathParam}` };
        }
        if (content === null) {
          return { success: false, error: `Is a directory: ${pathParam}` };
        }
        const bytes = new TextEncoder().encode(content);
        addAuditEntry(toolName, "read", "success", pathParam);
        result = {
          content: btoa(String.fromCharCode(...bytes)),
          size: bytes.length,
          encoding: "base64",
        };
        break;
      }

      case "write_file": {
        const content = params.content as string;
        if (isBlockedExtension(pathParam)) {
          addAuditEntry(toolName, "write", "denied", pathParam, "Blocked extension");
          return { success: false, error: `Blocked file extension: ${pathParam}` };
        }
        const sizeError = validateFileSize(content.length);
        if (sizeError) {
          return { success: false, error: sizeError };
        }
        ensureDir(pathParam);
        virtualFS[pathParam] = content;
        addAuditEntry(toolName, "write", "success", pathParam, `${content.length} bytes`);
        result = { path: pathParam, size: content.length, atomic: params.atomic !== false };
        break;
      }

      case "write_file_binary": {
        const b64content = params.content as string;
        try {
          atob(b64content);
        } catch {
          return { success: false, error: "Invalid base64 content" };
        }
        ensureDir(pathParam);
        virtualFS[pathParam] = atob(b64content);
        addAuditEntry(toolName, "write", "success", pathParam, "binary");
        result = { path: pathParam, size: b64content.length };
        break;
      }

      case "list_directory": {
        const dirPath = pathParam || "";
        const recursive = params.recursive as boolean;
        const children = getChildren(dirPath);
        const entries = children.map((name) => getStats(name, dirPath));
        addAuditEntry(toolName, "list", "success", dirPath, `${entries.length} entries`);

        if (recursive) {
          const allEntries: ReturnType<typeof getStats>[] = [];
          function walk(p: string) {
            const kids = getChildren(p);
            for (const name of kids) {
              const stat = getStats(name, p);
              allEntries.push(stat);
              if (stat.type === "directory") {
                walk(stat.path);
              }
            }
          }
          walk(dirPath);
          result = { entries: allEntries, path: dirPath, count: allEntries.length };
        } else {
          result = { entries, path: dirPath, count: entries.length };
        }
        break;
      }

      case "create_directory": {
        virtualFS[pathParam] = null;
        ensureDir(pathParam);
        addAuditEntry(toolName, "create", "success", pathParam);
        result = { path: pathParam, created: true };
        break;
      }

      case "move_path": {
        if (virtualFS[sourceParam] === undefined) {
          return { success: false, error: `Source not found: ${sourceParam}` };
        }
        virtualFS[destParam] = virtualFS[sourceParam];
        delete virtualFS[sourceParam];
        addAuditEntry(toolName, "move", "success", `${sourceParam} -> ${destParam}`);
        result = { source: sourceParam, destination: destParam };
        break;
      }

      case "delete_path": {
        const recursive = params.recursive as boolean;
        if (virtualFS[pathParam] === undefined) {
          return { success: false, error: `Path not found: ${pathParam}` };
        }
        if (isDir(pathParam) && !recursive) {
          const children = getChildren(pathParam);
          if (children.length > 0) {
            return { success: false, error: "Directory not empty. Use recursive=true." };
          }
        }
        const keysToDelete = Object.keys(virtualFS).filter(
          (k) => k === pathParam || k.startsWith(pathParam + "/")
        );
        for (const k of keysToDelete) delete virtualFS[k];
        addAuditEntry(toolName, "delete", "success", pathParam);
        result = { path: pathParam, deleted: true };
        break;
      }

      case "search_glob": {
        const pattern = params.pattern as string;
        const basePath = (params.basePath as string) || "";
        const regexStr = pattern
          .replace(/\*\*/g, ".*")
          .replace(/\*/g, "[^/]*")
          .replace(/\?/g, "[^/]")
          .replace(/\./g, "\\.");
        const regex = new RegExp(regexStr);
        const matches = Object.keys(virtualFS).filter((k) => {
          const rel = basePath ? k.slice(basePath.length + 1) : k;
          return regex.test(rel) && virtualFS[k] !== null;
        });
        addAuditEntry(toolName, "search", "success", basePath, `${matches.length} matches`);
        result = { matches, pattern, count: matches.length };
        break;
      }

      case "search_grep": {
        const pattern = params.pattern as string;
        const basePath = (params.basePath as string) || "";
        const filePattern = (params.filePattern as string) || "*";
        const regex = new RegExp(pattern, "g");
        const results: { file: string; line: number; content: string }[] = [];
        for (const [key, value] of Object.entries(virtualFS)) {
          if (value === null) continue;
          if (basePath && !key.startsWith(basePath)) continue;
          if (filePattern !== "*") {
            const fpRegex = new RegExp(
              filePattern.replace(/\*/g, ".*").replace(/\?/g, ".")
            );
            if (!fpRegex.test(key)) continue;
          }
          const lines = value.split("\n");
          lines.forEach((line, i) => {
            if (regex.test(line)) {
              results.push({ file: key, line: i + 1, content: line.trim() });
            }
            regex.lastIndex = 0;
          });
        }
        addAuditEntry(toolName, "search", "success", basePath, `${results.length} matches`);
        result = { results, count: results.length };
        break;
      }

      case "search_by_time": {
        const basePath = (params.basePath as string) || "";
        const after = params.after ? new Date(params.after as string) : null;
        const before = params.before ? new Date(params.before as string) : null;
        const matches = Object.entries(virtualFS)
          .filter(([k, v]) => {
            if (v === null) return false;
            if (basePath && !k.startsWith(basePath)) return false;
            return true;
          })
          .map(([k]) => getStats(k.split("/").pop()!, k.includes("/") ? k.substring(0, k.lastIndexOf("/")) : ""))
          .filter((s) => {
            const mod = new Date(s.modified);
            if (after && mod <= after) return false;
            if (before && mod >= before) return false;
            return true;
          });
        addAuditEntry(toolName, "search", "success", basePath, `${matches.length} matches`);
        result = { matches, count: matches.length };
        break;
      }

      case "search_by_size": {
        const basePath = (params.basePath as string) || "";
        const minSize = (params.minSize as number) || 0;
        const maxSize = (params.maxSize as number) || Infinity;
        const matches = Object.entries(virtualFS)
          .filter(([k, v]) => {
            if (v === null) return false;
            if (basePath && !k.startsWith(basePath)) return false;
            const size = v.length;
            return size >= minSize && size <= maxSize;
          })
          .map(([k, v]) => ({
            path: k,
            size: (v as string).length,
            type: "file" as const,
          }));
        addAuditEntry(toolName, "search", "success", basePath, `${matches.length} matches`);
        result = { matches, count: matches.length };
        break;
      }

      case "diff_files": {
        const contentA = virtualFS[params.pathA as string];
        const contentB = virtualFS[params.pathB as string];
        if (contentA === undefined) return { success: false, error: `File not found: ${params.pathA}` };
        if (contentB === undefined) return { success: false, error: `File not found: ${params.pathB}` };
        addAuditEntry(toolName, "diff", "success", `${params.pathA} vs ${params.pathB}`);
        result = generateDiff(contentA || "", contentB || "", params.pathA as string, params.pathB as string);
        break;
      }

      case "diff_string": {
        const oldC = params.oldContent as string;
        const newC = params.newContent as string;
        const label = (params.fileName as string) || "string";
        addAuditEntry(toolName, "diff", "success", undefined, label);
        result = generateDiff(oldC, newC, `${label} (old)`, `${label} (new)`);
        break;
      }

      default:
        return { success: false, error: `Unhandled tool: ${toolName}` };
    }

    return { success: true, data: result };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    addAuditEntry(toolName, "error", "error", pathParam, msg);
    return { success: false, error: msg };
  }
}

function generateDiff(
  oldStr: string,
  newStr: string,
  oldLabel: string,
  newLabel: string
): { unified: string; added: number; removed: number } {
  const oldLines = oldStr.split("\n");
  const newLines = newStr.split("\n");
  const unified: string[] = [];
  unified.push(`--- ${oldLabel}`);
  unified.push(`+++ ${newLabel}`);
  unified.push("@@ differences @@");

  let added = 0;
  let removed = 0;
  const maxLen = Math.max(oldLines.length, newLines.length);
  for (let i = 0; i < maxLen; i++) {
    const oldLine = oldLines[i];
    const newLine = newLines[i];
    if (oldLine === newLine) {
      unified.push(` ${oldLine ?? ""}`);
    } else {
      if (oldLine !== undefined) {
        unified.push(`-${oldLine}`);
        removed++;
      }
      if (newLine !== undefined) {
        unified.push(`+${newLine}`);
        added++;
      }
    }
  }

  return { unified: unified.join("\n"), added, removed };
}

const path = { extname: (p: string) => "." + p.split(".").pop() };

export { virtualFS, getAuditLog, clearAuditLog, getChildren, getStats };
