import fs from "node:fs/promises";
import type { AuditEntry } from "../shared/types.js";
import { AUDIT_LOG_PATH } from "./constants.js";

const auditLog: AuditEntry[] = [];
const subscribers: Array<(entry: AuditEntry) => void> = [];

export function subscribeToAudit(fn: (entry: AuditEntry) => void): () => void {
  subscribers.push(fn);
  return () => {
    const idx = subscribers.indexOf(fn);
    if (idx >= 0) subscribers.splice(idx, 1);
  };
}

export async function audit<T>(
  tool: string,
  operation: string,
  targetPath: string,
  fn: () => Promise<T>,
  details?: string
): Promise<{ success: boolean; data?: T; error?: string }> {
  const entry: AuditEntry = {
    timestamp: new Date().toISOString(),
    tool,
    operation,
    path: targetPath,
    success: false,
    details,
  };

  try {
    const result = await fn();
    entry.success = true;
    auditLog.push(entry);
    notify(entry);
    return { success: true, data: result };
  } catch (err) {
    entry.success = false;
    entry.error = err instanceof Error ? err.message : String(err);
    auditLog.push(entry);
    notify(entry);
    return { success: false, error: entry.error };
  }
}

function notify(entry: AuditEntry) {
  for (const sub of subscribers) {
    try { sub(entry); } catch {}
  }
  if (AUDIT_LOG_PATH) {
    fs.appendFile(AUDIT_LOG_PATH, JSON.stringify(entry) + "\n").catch(() => {});
  }
}

export function getAuditLog(limit = 100, offset = 0): AuditEntry[] {
  return auditLog.slice(-(limit + offset)).slice(offset);
}

export function clearAuditLog(): void {
  auditLog.length = 0;
}
