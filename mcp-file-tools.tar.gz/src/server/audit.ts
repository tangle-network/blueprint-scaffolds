import { mkdir, appendFile } from "node:fs/promises";
import path from "node:path";
import type { AuditRecord } from "../shared/contracts.js";

export class AuditLogger {
  constructor(private readonly auditPath: string) {}

  async log(record: AuditRecord): Promise<void> {
    await mkdir(path.dirname(this.auditPath), { recursive: true });
    await appendFile(this.auditPath, `${JSON.stringify(record)}\n`, "utf8");
  }
}
