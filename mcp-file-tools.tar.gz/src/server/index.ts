import { AuditLogger } from "./audit.js";
import { getConfig } from "./config.js";
import { FilesystemService } from "./filesystemService.js";
import { startHttpApi } from "./httpApi.js";
import { startMcpServer } from "./mcp.js";

const config = getConfig();
const audit = new AuditLogger(config.auditLogPath);
const service = new FilesystemService(config, audit);

startHttpApi(service, config);
await startMcpServer(service);
