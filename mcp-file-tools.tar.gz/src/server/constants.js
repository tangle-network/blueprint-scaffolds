import React from 'react'

export function AUDIT_LOG_PATH(props: Record<string, any>) { return <div>{props.children}</div> }
