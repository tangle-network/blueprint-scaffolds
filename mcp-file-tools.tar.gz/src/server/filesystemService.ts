import {
  copyFile,
  mkdir,
  mkdtemp,
  readFile,
  readdir,
  rename,
  rm,
  stat,
  writeFile
} from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import fg from "fast-glob";
import { createPatch } from "diff";
import type {
  CreateDirectoryRequest,
  DeletePathRequest,
  DiffRequest,
  DiffResponse,
  FileEntry,
  ListDirectoryRequest,
  ListDirectoryResponse,
  MovePathRequest,
  ReadFileRequest,
  ReadFileResponse,
  SearchGlobRequest,
  SearchGrepRequest,
  SearchMatch,
  SearchMetadataRequest,
  SearchResponse,
  WriteFileRequest,
  WriteFileResponse
} from "../shared/contracts.js";
import { AuditLogger } from "./audit.js";
import { FsSafetyError, assertConfirmation, resolveSandboxPath } from "./pathSafety.js";
import type { ServerConfig } from "./config.js";

export class FilesystemService {
  constructor(
    private readonly config: ServerConfig,
    private readonly audit: AuditLogger
  ) {}

  getRoots(): string[] {
    return [...this.config.roots];
  }

  async listDirectory(request: ListDirectoryRequest): Promise<ListDirectoryResponse> {
    const dirPath = await resolveSandboxPath(request.path, this.config.roots);
    const maxEntries = Math.min(request.maxEntries ?? this.config.maxEntries, this.config.maxEntries);
    const entries: FileEntry[] = [];

    const visit = async (currentPath: string): Promise<void> => {
      const dirents = await readdir(currentPath, { withFileTypes: true });
      for (const dirent of dirents) {
        if (!request.includeHidden && dirent.name.startsWith(".")) {
          continue;
        }
        const fullPath = path.join(currentPath, dirent.name);
        const info = await stat(fullPath);
        entries.push({
          name: dirent.name,
          path: fullPath,
          type: dirent.isDirectory()
            ? "directory"
            : dirent.isFile()
              ? "file"
              : dirent.isSymbolicLink()
                ? "symlink"
                : "other",
          size: info.size,
          modifiedAt: info.mtime.toISOString()
        });
        if (entries.length >= maxEntries) {
          return;
        }
        if (request.recursive && dirent.isDirectory()) {
          await visit(fullPath);
          if (entries.length >= maxEntries) {
            return;
          }
        }
      }
    };

    await visit(dirPath);
    await this.audit.log({
      at: new Date().toISOString(),
      action: "list_directory",
      path: dirPath,
      detail: { recursive: Boolean(request.recursive) },
      status: "ok"
    });

    return {
      cwd: dirPath,
      entries,
      truncated: entries.length >= maxEntries
    };
  }

  async readFile(request: ReadFileRequest): Promise<ReadFileResponse> {
    const filePath = await resolveSandboxPath(request.path, this.config.roots);
    const info = await stat(filePath);
    const content = await readFile(filePath);
    const offset = request.offset ?? 0;
    const requestedLength = request.length ?? this.config.maxReadBytes;
    const maxLength = Math.min(requestedLength, this.config.maxReadBytes);
    const chunk = content.subarray(offset, offset + maxLength);
    const encoding = request.encoding ?? "utf8";

    await this.audit.log({
      at: new Date().toISOString(),
      action: "read_file",
      path: filePath,
      detail: { encoding, offset, length: maxLength },
      status: "ok"
    });

    return {
      path: filePath,
      encoding,
      content: encoding === "base64" ? chunk.toString("base64") : chunk.toString("utf8"),
      size: info.size,
      truncated: offset + maxLength < info.size
    };
  }

  async writeFile(request: WriteFileRequest): Promise<WriteFileResponse> {
    const targetPath = await resolveSandboxPath(request.path, this.config.roots);
    const encoding = request.encoding ?? "utf8";
    const payload = encoding === "base64" ? Buffer.from(request.content, "base64") : Buffer.from(request.content, "utf8");
    if (payload.byteLength > this.config.maxWriteBytes) {
      throw new FsSafetyError(`Write exceeds size limit of ${this.config.maxWriteBytes} bytes`);
    }

    if (request.createDirectories) {
      await mkdir(path.dirname(targetPath), { recursive: true });
    }

    if (request.atomic ?? true) {
      const tempDir = await mkdtemp(path.join(os.tmpdir(), "mcp-fs-"));
      const tempPath = path.join(tempDir, path.basename(targetPath));
      await writeFile(tempPath, payload);
      await rename(tempPath, targetPath);
    } else {
      await writeFile(targetPath, payload);
    }

    await this.audit.log({
      at: new Date().toISOString(),
      action: "write_file",
      path: targetPath,
      detail: { encoding, atomic: request.atomic ?? true, bytes: payload.byteLength },
      status: "ok"
    });

    return {
      path: targetPath,
      bytesWritten: payload.byteLength,
      atomic: request.atomic ?? true
    };
  }

  async createDirectory(request: CreateDirectoryRequest): Promise<{ path: string }> {
    const dirPath = await resolveSandboxPath(request.path, this.config.roots);
    await mkdir(dirPath, { recursive: request.recursive ?? true });
    await this.audit.log({
      at: new Date().toISOString(),
      action: "create_directory",
      path: dirPath,
      detail: { recursive: request.recursive ?? true },
      status: "ok"
    });
    return { path: dirPath };
  }

  async movePath(request: MovePathRequest): Promise<{ source: string; destination: string }> {
    const sourcePath = await resolveSandboxPath(request.source, this.config.roots);
    const destinationPath = await resolveSandboxPath(request.destination, this.config.roots);

    if (request.overwrite) {
      assertConfirmation(request.confirmationToken, "overwrite_move", destinationPath);
      await rm(destinationPath, { recursive: true, force: true });
    }

    await mkdir(path.dirname(destinationPath), { recursive: true });
    await rename(sourcePath, destinationPath);
    await this.audit.log({
      at: new Date().toISOString(),
      action: "move_path",
      path: sourcePath,
      detail: { destination: destinationPath, overwrite: Boolean(request.overwrite) },
      status: "ok"
    });
    return { source: sourcePath, destination: destinationPath };
  }

  async deletePath(request: DeletePathRequest): Promise<{ path: string; deleted: true }> {
    const targetPath = await resolveSandboxPath(request.path, this.config.roots);
    assertConfirmation(request.confirmationToken, request.recursive ? "recursive_delete" : "delete", targetPath);
    await rm(targetPath, { recursive: request.recursive ?? false, force: false });
    await this.audit.log({
      at: new Date().toISOString(),
      action: "delete_path",
      path: targetPath,
      detail: { recursive: Boolean(request.recursive) },
      status: "ok"
    });
    return { path: targetPath, deleted: true };
  }

  async searchGlob(request: SearchGlobRequest): Promise<SearchResponse> {
    const root = await resolveSandboxPath(request.root, this.config.roots);
    const maxResults = Math.min(request.maxResults ?? this.config.maxSearchResults, this.config.maxSearchResults);
    const matches = await fg(request.pattern, {
      cwd: root,
      absolute: true,
      dot: request.includeHidden ?? false,
      onlyFiles: false
    });
    const limited = matches.slice(0, maxResults);
    return {
      matches: await Promise.all(limited.map((match) => this.toSearchMatch(match))),
      truncated: matches.length > limited.length
    };
  }

  async searchGrep(request: SearchGrepRequest): Promise<SearchResponse> {
    const root = await resolveSandboxPath(request.root, this.config.roots);
    const maxResults = Math.min(request.maxResults ?? this.config.maxSearchResults, this.config.maxSearchResults);
    const files = await fg("**/*", {
      cwd: root,
      absolute: true,
      dot: request.includeHidden ?? false,
      onlyFiles: true
    });
    const query = request.caseSensitive ? request.query : request.query.toLowerCase();
    const matches: SearchMatch[] = [];

    for (const file of files) {
      if (matches.length >= maxResults) {
        break;
      }
      const buffer = await readFile(file);
      const text = buffer.toString("utf8");
      const haystack = request.caseSensitive ? text : text.toLowerCase();
      const index = haystack.indexOf(query);
      if (index >= 0) {
        const lineStart = text.lastIndexOf("\n", index) + 1;
        const lineEnd = text.indexOf("\n", index);
        const info = await stat(file);
        matches.push({
          path: file,
          preview: text.slice(lineStart, lineEnd >= 0 ? lineEnd : undefined).trim(),
          size: info.size,
          modifiedAt: info.mtime.toISOString()
        });
      }
    }

    return {
      matches,
      truncated: files.length > matches.length && matches.length >= maxResults
    };
  }

  async searchMetadata(request: SearchMetadataRequest): Promise<SearchResponse> {
    const root = await resolveSandboxPath(request.root, this.config.roots);
    const maxResults = Math.min(request.maxResults ?? this.config.maxSearchResults, this.config.maxSearchResults);
    const after = request.modifiedAfter ? new Date(request.modifiedAfter).getTime() : undefined;
    const before = request.modifiedBefore ? new Date(request.modifiedBefore).getTime() : undefined;
    const files = await fg("**/*", {
      cwd: root,
      absolute: true,
      dot: request.includeHidden ?? false,
      onlyFiles: false
    });
    const matches: SearchMatch[] = [];

    for (const file of files) {
      const info = await stat(file);
      const modified = info.mtime.getTime();
      if (request.minSize !== undefined && info.size < request.minSize) {
        continue;
      }
      if (request.maxSize !== undefined && info.size > request.maxSize) {
        continue;
      }
      if (after !== undefined && modified < after) {
        continue;
      }
      if (before !== undefined && modified > before) {
        continue;
      }
      matches.push({
        path: file,
        size: info.size,
        modifiedAt: info.mtime.toISOString()
      });
      if (matches.length >= maxResults) {
        break;
      }
    }

    return {
      matches,
      truncated: files.length > matches.length && matches.length >= maxResults
    };
  }

  async generateDiff(request: DiffRequest): Promise<DiffResponse> {
    const current = await this.readFile({ path: request.path, encoding: "utf8" });
    return {
      path: current.path,
      diff: createPatch(current.path, current.content, request.nextContent, "current", "next")
    };
  }

  async copyBinary(source: string, destination: string): Promise<{ source: string; destination: string }> {
    const sourcePath = await resolveSandboxPath(source, this.config.roots);
    const destinationPath = await resolveSandboxPath(destination, this.config.roots);
    await mkdir(path.dirname(destinationPath), { recursive: true });
    await copyFile(sourcePath, destinationPath);
    return { source: sourcePath, destination: destinationPath };
  }

  private async toSearchMatch(filePath: string): Promise<SearchMatch> {
    const info = await stat(filePath);
    return {
      path: filePath,
      size: info.size,
      modifiedAt: info.mtime.toISOString()
    };
  }
}
