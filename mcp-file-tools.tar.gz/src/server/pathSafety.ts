import path from "node:path";
import { realpath } from "node:fs/promises";

export class FsSafetyError extends Error {
  confirmationToken?: string;

  constructor(message: string, confirmationToken?: string) {
    super(message);
    this.name = "FsSafetyError";
    this.confirmationToken = confirmationToken;
  }
}

export async function resolveSandboxPath(inputPath: string, roots: string[]): Promise<string> {
  const absolute = path.resolve(inputPath);
  const parent = path.dirname(absolute);

  let resolvedParent: string;
  try {
    resolvedParent = await realpath(parent);
  } catch {
    resolvedParent = path.resolve(parent);
  }

  const resolved = path.join(resolvedParent, path.basename(absolute));
  const allowed = roots.some((root) => isWithinRoot(resolved, root));
  if (!allowed) {
    throw new FsSafetyError(`Path is outside sandbox roots: ${inputPath}`);
  }

  return resolved;
}

export function isWithinRoot(target: string, root: string): boolean {
  const relative = path.relative(root, target);
  return relative === "" || (!relative.startsWith("..") && !path.isAbsolute(relative));
}

export function buildConfirmationToken(action: string, target: string): string {
  return `${action}:${target}`;
}

export function assertConfirmation(
  provided: string | undefined,
  expectedAction: string,
  target: string
): void {
  const token = buildConfirmationToken(expectedAction, target);
  if (provided !== token) {
    throw new FsSafetyError("confirmation_required", token);
  }
}
