import path from "node:path";
import type { SandboxedPath } from "../shared/types.js";
import { SANDBOX_ROOT } from "./constants.js";

export function resolveSandboxed(inputPath: string, sandboxRoot?: string): SandboxedPath {
  const root = sandboxRoot ?? SANDBOX_ROOT;
  const resolved = path.resolve(root, inputPath);
  const normalizedRoot = path.resolve(root);
  const relative = path.relative(normalizedRoot, resolved);
  const allowed = !relative.startsWith("..") && !path.isAbsolute(relative);
  return { resolved, relative: relative || ".", allowed };
}

export function assertSandboxed(inputPath: string, sandboxRoot?: string): string {
  const result = resolveSandboxed(inputPath, sandboxRoot);
  if (!result.allowed) {
    throw new Error(`Path escapes sandbox: ${inputPath}`);
  }
  return result.resolved;
}

export function isPathSandboxed(inputPath: string, sandboxRoot?: string): boolean {
  return resolveSandboxed(inputPath, sandboxRoot).allowed;
}
