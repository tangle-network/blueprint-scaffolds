import fs from "node:fs/promises";
import path from "node:path";
import fg from "fast-glob";
import type { SearchResult, SearchGlobOptions, SearchGrepOptions, SearchTimeOptions, SearchSizeOptions, ToolResponse } from "../../shared/types.js";
import { assertSandboxed } from "../sandbox.js";
import { audit } from "../audit.js";

export async function searchGlob(options: SearchGlobOptions): Promise<ToolResponse<string[]>> {
  const resolved = assertSandboxed(options.cwd);
  return audit("search", "glob", resolved, async () => {
    const results = await fg(options.pattern, {
      cwd: resolved,
      ignore: options.ignore,
      dot: options.dot ?? false,
      absolute: options.absolute ?? false,
      onlyFiles: true,
    });
    return results as string[];
  });
}

export async function searchGrep(options: SearchGrepOptions): Promise<ToolResponse<SearchResult[]>> {
  const resolved = assertSandboxed(options.path);
  return audit("search", "grep", resolved, async () => {
    const regex = new RegExp(options.pattern, "g");
    const results: SearchResult[] = [];
    const maxResults = options.maxResults ?? 100;
    const contextLines = options.contextLines ?? 0;

    await walkAndGrep(resolved, regex, results, maxResults, contextLines, options.include);
    return results;
  });
}

async function walkAndGrep(
  dirPath: string,
  regex: RegExp,
  results: SearchResult[],
  maxResults: number,
  contextLines: number,
  include?: string[]
): Promise<void> {
  if (results.length >= maxResults) return;

  const entries = await fs.readdir(dirPath, { withFileTypes: true });
  for (const entry of entries) {
    if (results.length >= maxResults) return;
    const fullPath = path.join(dirPath, entry.name);

    if (entry.isDirectory()) {
      await walkAndGrep(fullPath, regex, results, maxResults, contextLines, include);
    } else if (entry.isFile()) {
      if (include && !include.some((ext) => fullPath.endsWith(ext))) continue;
      try {
        const content = await fs.readFile(fullPath, "utf-8");
        const lines = content.split("\n");
        for (let i = 0; i < lines.length && results.length < maxResults; i++) {
          const re = new RegExp(regex.source, regex.flags);
          if (re.test(lines[i])) {
            const contextStart = Math.max(0, i - contextLines);
            const contextEnd = Math.min(lines.length, i + contextLines + 1);
            results.push({
              path: fullPath,
              line: i + 1,
              match: lines[i].trim(),
              context: lines.slice(contextStart, contextEnd).join("\n"),
            });
          }
        }
      } catch {}
    }
  }
}

export async function searchByTime(options: SearchTimeOptions): Promise<ToolResponse<SearchResult[]>> {
  const resolved = assertSandboxed(options.path);
  return audit("search", "time", resolved, async () => {
    const results: SearchResult[] = [];
    await walkByTime(resolved, options, results);
    return results;
  });
}

async function walkByTime(
  dirPath: string,
  options: SearchTimeOptions,
  results: SearchResult[]
): Promise<void> {
  const entries = await fs.readdir(dirPath, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dirPath, entry.name);
    const stat = await fs.stat(fullPath);

    if (options.modifiedAfter && new Date(stat.mtime) <= new Date(options.modifiedAfter)) continue;
    if (options.modifiedBefore && new Date(stat.mtime) >= new Date(options.modifiedBefore)) continue;
    if (options.createdAfter && new Date(stat.birthtime) <= new Date(options.createdAfter)) continue;
    if (options.createdBefore && new Date(stat.birthtime) >= new Date(options.createdBefore)) continue;

    results.push({ path: fullPath });

    if (entry.isDirectory()) {
      await walkByTime(fullPath, options, results);
    }
  }
}

export async function searchBySize(options: SearchSizeOptions): Promise<ToolResponse<SearchResult[]>> {
  const resolved = assertSandboxed(options.path);
  return audit("search", "size", resolved, async () => {
    const results: SearchResult[] = [];
    await walkBySize(resolved, options, results);
    return results;
  });
}

async function walkBySize(
  dirPath: string,
  options: SearchSizeOptions,
  results: SearchResult[]
): Promise<void> {
  const entries = await fs.readdir(dirPath, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dirPath, entry.name);
    const stat = await fs.stat(fullPath);

    if (entry.isFile()) {
      if (options.minSize !== undefined && stat.size < options.minSize) continue;
      if (options.maxSize !== undefined && stat.size > options.maxSize) continue;
      results.push({ path: fullPath, match: `${stat.size} bytes` });
    }

    if (entry.isDirectory() && options.recursive) {
      await walkBySize(fullPath, options, results);
    }
  }
}
