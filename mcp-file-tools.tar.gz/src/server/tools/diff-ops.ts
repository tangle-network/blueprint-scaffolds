import fs from "node:fs/promises";
import { diffLines, diffWords } from "diff";
import type { DiffResult, ToolResponse } from "../../shared/types.js";
import { assertSandboxed } from "../sandbox.js";
import { audit } from "../audit.js";

export async function generateDiff(
  oldPath: string,
  newPath: string,
  mode: "lines" | "words" = "lines"
): Promise<ToolResponse<DiffResult>> {
  const resolvedOld = assertSandboxed(oldPath);
  const resolvedNew = assertSandboxed(newPath);

  return audit("diff", mode, `${oldPath} vs ${newPath}`, async () => {
    const [oldContent, newContent] = await Promise.all([
      fs.readFile(resolvedOld, "utf-8"),
      fs.readFile(resolvedNew, "utf-8"),
    ]);

    const changes = mode === "lines"
      ? diffLines(oldContent, newContent)
      : diffWords(oldContent, newContent);

    const hunks = changes.filter((c) => c.added || c.removed).length;
    const patch = changes.map((c) => {
      const prefix = c.added ? "+" : c.removed ? "-" : " ";
      return c.value.split("\n").map((line) => `${prefix}${line}`).join("\n");
    }).join("");

    return { oldPath, newPath, hunks, patch } satisfies DiffResult;
  });
}

export async function generateDiffFromContent(
  oldContent: string,
  newContent: string,
  oldLabel = "original",
  newLabel = "modified"
): Promise<ToolResponse<DiffResult>> {
  return audit("diff", "content", `${oldLabel} vs ${newLabel}`, async () => {
    const changes = diffLines(oldContent, newContent);
    const hunks = changes.filter((c) => c.added || c.removed).length;
    const patch = changes.map((c) => {
      const prefix = c.added ? "+" : c.removed ? "-" : " ";
      return c.value.split("\n").map((line) => `${prefix}${line}`).join("\n");
    }).join("");

    return { oldPath: oldLabel, newPath: newLabel, hunks, patch } satisfies DiffResult;
  });
}
