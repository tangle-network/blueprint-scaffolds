export const assertSandboxed = {} as any
