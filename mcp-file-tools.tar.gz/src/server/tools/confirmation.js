export const requestConfirmation = {} as any
