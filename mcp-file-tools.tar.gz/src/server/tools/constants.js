import React from 'react'

export function MAX_READ_SIZE(props: Record<string, any>) { return <div>{props.children}</div> }

export function MAX_WRITE_SIZE(props: Record<string, any>) { return <div>{props.children}</div> }
