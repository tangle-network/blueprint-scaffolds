import fs from "node:fs/promises";
import path from "node:path";
import type { FileMetadata, ToolResponse } from "../../shared/types.js";
import { assertSandboxed } from "../sandbox.js";
import { audit } from "../audit.js";
import { requestConfirmation } from "../confirmation.js";
import { MAX_DIRECTORY_ENTRIES } from "../constants.js";

export async function listDirectory(
  dirPath: string,
  recursive = false
): Promise<ToolResponse<FileMetadata[]>> {
  const resolved = assertSandboxed(dirPath);
  return audit("directory", "list", resolved, async () => {
    const entries: FileMetadata[] = [];
    await walkDir(resolved, dirPath, entries, recursive, 0);
    return entries.slice(0, MAX_DIRECTORY_ENTRIES);
  });
}

async function walkDir(
  resolved: string,
  displayPath: string,
  entries: FileMetadata[],
  recursive: boolean,
  depth: number
): Promise<void> {
  const items = await fs.readdir(resolved, { withFileTypes: true });
  for (const item of items) {
    if (entries.length >= MAX_DIRECTORY_ENTRIES) return;
    const itemPath = path.join(displayPath, item.name);
    const itemResolved = path.join(resolved, item.name);
    const stat = await fs.stat(itemResolved);
    entries.push({
      name: item.name,
      path: itemPath,
      size: stat.size,
      isDirectory: item.isDirectory(),
      isFile: item.isFile(),
      modified: stat.mtime.toISOString(),
      created: stat.birthtime.toISOString(),
      permissions: stat.mode.toString(8).slice(-3),
    });
    if (recursive && item.isDirectory() && depth < 10) {
      await walkDir(itemResolved, itemPath, entries, recursive, depth + 1);
    }
  }
}

export async function createDirectory(
  dirPath: string,
  recursive = true
): Promise<ToolResponse> {
  const resolved = assertSandboxed(dirPath);
  return audit("directory", "create", resolved, async () => {
    await fs.mkdir(resolved, { recursive });
    return { created: true, path: dirPath };
  });
}

export async function movePath(
  source: string,
  destination: string
): Promise<ToolResponse> {
  const resolvedSrc = assertSandboxed(source);
  const resolvedDst = assertSandboxed(destination);

  const approved = await requestConfirmation("move", `${source} -> ${destination}`);
  if (!approved) throw new Error("Operation cancelled by user");

  return audit("directory", "move", `${source} -> ${destination}`, async () => {
    await fs.mkdir(path.dirname(resolvedDst), { recursive: true });
    await fs.rename(resolvedSrc, resolvedDst);
    return { moved: true, from: source, to: destination };
  });
}

export async function deletePath(
  targetPath: string,
  recursive = false
): Promise<ToolResponse> {
  const resolved = assertSandboxed(targetPath);

  const approved = await requestConfirmation("delete", resolved);
  if (!approved) throw new Error("Operation cancelled by user");

  return audit("directory", "delete", resolved, async () => {
    const stat = await fs.stat(resolved);
    if (stat.isDirectory()) {
      if (recursive) {
        await fs.rm(resolved, { recursive: true, force: true });
      } else {
        await fs.rmdir(resolved);
      }
    } else {
      await fs.unlink(resolved);
    }
    return { deleted: true, path: targetPath };
  });
}
