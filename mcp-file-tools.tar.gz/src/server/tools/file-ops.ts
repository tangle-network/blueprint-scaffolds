import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import type { ReadOptions, WriteOptions, FileMetadata, ToolResponse } from "../shared/types.js";
import { assertSandboxed } from "./sandbox.js";
import { audit } from "./audit.js";
import { requestConfirmation } from "./confirmation.js";
import { MAX_READ_SIZE, MAX_WRITE_SIZE } from "./constants.js";

export async function readFile(options: ReadOptions): Promise<ToolResponse> {
  const resolved = assertSandboxed(options.path);
  return audit("read", "read", resolved, async () => {
    const stat = await fs.stat(resolved);
    if (stat.size > MAX_READ_SIZE) {
      throw new Error(`File too large: ${stat.size} bytes (max ${MAX_READ_SIZE})`);
    }

    if (options.mode === "binary") {
      const buffer = await fs.readFile(resolved);
      return { content: buffer.toString("base64"), encoding: "base64", size: buffer.length };
    }

    if (options.mode === "atomic") {
      const tmpPath = resolved + `.tmp-${crypto.randomUUID()}`;
      try {
        await fs.copyFile(resolved, tmpPath);
        const content = await fs.readFile(tmpPath, { encoding: options.encoding ?? "utf-8" });
        return { content, size: content.length };
      } finally {
        await fs.unlink(tmpPath).catch(() => {});
      }
    }

    let content = await fs.readFile(resolved, { encoding: options.encoding ?? "utf-8" });
    if (options.offset !== undefined || options.limit !== undefined) {
      const lines = content.split("\n");
      const start = options.offset ?? 0;
      const end = options.limit !== undefined ? start + options.limit : lines.length;
      content = lines.slice(start, end).join("\n");
    }

    return { content, size: content.length, mode: options.mode };
  });
}

export async function writeFile(options: WriteOptions): Promise<ToolResponse> {
  const resolved = assertSandboxed(options.path);
  const size = typeof options.content === "string" ? options.content.length : 0;
  if (size > MAX_WRITE_SIZE) {
    throw new Error(`Content too large: ${size} bytes (max ${MAX_WRITE_SIZE})`);
  }

  const exists = await fs.access(resolved).then(() => true).catch(() => false);
  if (exists && !options.overwrite) {
    throw new Error(`File already exists: ${options.path}. Set overwrite to true.`);
  }
  if (exists) {
    const approved = await requestConfirmation("overwrite", resolved);
    if (!approved) throw new Error("Operation cancelled by user");
  }

  return audit("write", "write", resolved, async () => {
    if (options.createDirs) {
      await fs.mkdir(path.dirname(resolved), { recursive: true });
    }

    if (options.mode === "atomic") {
      const tmpPath = resolved + `.tmp-${crypto.randomUUID()}`;
      try {
        await fs.writeFile(tmpPath, options.content, options.encoding ?? "utf-8");
        await fs.rename(tmpPath, resolved);
      } catch (err) {
        await fs.unlink(tmpPath).catch(() => {});
        throw err;
      }
    } else if (options.mode === "binary") {
      const buf = Buffer.from(options.content, "base64");
      await fs.writeFile(resolved, buf);
    } else {
      await fs.writeFile(resolved, options.content, options.encoding ?? "utf-8");
    }

    return { written: true, path: options.path, size };
  });
}

export async function getMetadata(filePath: string): Promise<ToolResponse<FileMetadata>> {
  const resolved = assertSandboxed(filePath);
  return audit("metadata", "stat", resolved, async () => {
    const stat = await fs.stat(resolved);
    return {
      name: path.basename(resolved),
      path: filePath,
      size: stat.size,
      isDirectory: stat.isDirectory(),
      isFile: stat.isFile(),
      modified: stat.mtime.toISOString(),
      created: stat.birthtime.toISOString(),
      permissions: stat.mode.toString(8).slice(-3),
    };
  });
}
