import type { ConfirmationRequest } from "../shared/types.js";
import { generateId } from "../shared/utils.js";
import { DESTRUCTIVE_OPS, type DestructiveOp } from "./constants.js";

const pendingConfirmations = new Map<string, ConfirmationRequest>();
const confirmationHandlers = new Map<string, (approved: boolean) => void>();

export function isDestructive(operation: string): operation is DestructiveOp {
  return (DESTRUCTIVE_OPS as readonly string[]).includes(operation);
}

export function requestConfirmation(
  operation: string,
  targetPath: string,
  details?: string
): Promise<boolean> {
  const id = generateId();
  const req: ConfirmationRequest = { id, operation, path: targetPath, details };
  pendingConfirmations.set(id, req);

  return new Promise<boolean>((resolve) => {
    confirmationHandlers.set(id, resolve);
  });
}

export function confirmAction(id: string, approved: boolean): boolean {
  const handler = confirmationHandlers.get(id);
  if (!handler) return false;
  handler(approved);
  confirmationHandlers.delete(id);
  pendingConfirmations.delete(id);
  return true;
}

export function getPendingConfirmations(): ConfirmationRequest[] {
  return Array.from(pendingConfirmations.values());
}

export function cancelConfirmation(id: string): boolean {
  const handler = confirmationHandlers.get(id);
  if (!handler) return false;
  handler(false);
  confirmationHandlers.delete(id);
  pendingConfirmations.delete(id);
  return true;
}
