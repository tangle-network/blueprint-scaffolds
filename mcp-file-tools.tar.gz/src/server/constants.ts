export const MAX_READ_SIZE = 10 * 1024 * 1024;
export const MAX_WRITE_SIZE = 50 * 1024 * 1024;
export const MAX_DIRECTORY_ENTRIES = 10000;
export const DEFAULT_ENCODING = "utf-8";
export const SANDBOX_ROOT = process.env.SANDBOX_ROOT || process.cwd();
export const AUDIT_LOG_PATH = process.env.AUDIT_LOG_PATH || "";
export const DESTRUCTIVE_OPS = ["delete", "move", "overwrite", "rmtree"] as const;
export type DestructiveOp = (typeof DESTRUCTIVE_OPS)[number];
