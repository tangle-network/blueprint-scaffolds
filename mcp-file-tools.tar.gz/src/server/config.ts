import path from "node:path";

const cwd = process.cwd();
const defaultRoot = process.env.SANDBOX_ROOTS ?? path.join(cwd, "..");

export interface ServerConfig {
  roots: string[];
  maxReadBytes: number;
  maxWriteBytes: number;
  maxEntries: number;
  maxSearchResults: number;
  auditLogPath: string;
  apiPort: number;
}

export function getConfig(): ServerConfig {
  return {
    roots: defaultRoot
      .split(path.delimiter)
      .map((value) => path.resolve(value.trim()))
      .filter(Boolean),
    maxReadBytes: Number(process.env.MAX_READ_BYTES ?? 1024 * 1024),
    maxWriteBytes: Number(process.env.MAX_WRITE_BYTES ?? 1024 * 1024),
    maxEntries: Number(process.env.MAX_ENTRIES ?? 500),
    maxSearchResults: Number(process.env.MAX_SEARCH_RESULTS ?? 200),
    auditLogPath: path.resolve(process.env.AUDIT_LOG_PATH ?? path.join(cwd, ".audit", "fs-tools.log")),
    apiPort: Number(process.env.API_PORT ?? 4321)
  };
}
