import * as z from "zod/v4";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { FilesystemService } from "./filesystemService.js";

export async function startMcpServer(service: FilesystemService): Promise<void> {
  const server = new McpServer(
    {
      name: "safe-filesystem-tools",
      version: "0.1.0"
    },
    {
      capabilities: {
        logging: {}
      }
    }
  );

  server.registerTool(
    "list_directory",
    {
      description: "List directory contents within sandboxed roots.",
      inputSchema: {
        path: z.string(),
        includeHidden: z.boolean().optional(),
        recursive: z.boolean().optional(),
        maxEntries: z.number().int().positive().optional()
      }
    },
    async (input) => textResult(await service.listDirectory(input))
  );

  server.registerTool(
    "read_file",
    {
      description: "Read a text or binary file with size limits.",
      inputSchema: {
        path: z.string(),
        encoding: z.enum(["utf8", "base64"]).optional(),
        offset: z.number().int().nonnegative().optional(),
        length: z.number().int().positive().optional()
      }
    },
    async (input) => textResult(await service.readFile(input))
  );

  server.registerTool(
    "write_file",
    {
      description: "Write text or binary file content, atomically by default.",
      inputSchema: {
        path: z.string(),
        content: z.string(),
        encoding: z.enum(["utf8", "base64"]).optional(),
        atomic: z.boolean().optional(),
        createDirectories: z.boolean().optional()
      }
    },
    async (input) => textResult(await service.writeFile(input))
  );

  server.registerTool(
    "create_directory",
    {
      description: "Create a directory inside sandbox roots.",
      inputSchema: {
        path: z.string(),
        recursive: z.boolean().optional()
      }
    },
    async (input) => textResult(await service.createDirectory(input))
  );

  server.registerTool(
    "move_path",
    {
      description: "Move or rename a path. Overwrites require a confirmation token.",
      inputSchema: {
        source: z.string(),
        destination: z.string(),
        overwrite: z.boolean().optional(),
        confirmationToken: z.string().optional()
      }
    },
    async (input) => textResult(await service.movePath(input))
  );

  server.registerTool(
    "delete_path",
    {
      description: "Delete a path. Every delete requires a confirmation token.",
      inputSchema: {
        path: z.string(),
        recursive: z.boolean().optional(),
        confirmationToken: z.string().optional()
      }
    },
    async (input) => textResult(await service.deletePath(input))
  );

  server.registerTool(
    "search_glob",
    {
      description: "Search by glob pattern inside a sandbox root.",
      inputSchema: {
        root: z.string(),
        pattern: z.string(),
        includeHidden: z.boolean().optional(),
        maxResults: z.number().int().positive().optional()
      }
    },
    async (input) => textResult(await service.searchGlob(input))
  );

  server.registerTool(
    "search_grep",
    {
      description: "Search file contents with plain-text grep semantics.",
      inputSchema: {
        root: z.string(),
        query: z.string(),
        caseSensitive: z.boolean().optional(),
        includeHidden: z.boolean().optional(),
        maxResults: z.number().int().positive().optional()
      }
    },
    async (input) => textResult(await service.searchGrep(input))
  );

  server.registerTool(
    "search_metadata",
    {
      description: "Search by file modified time and size metadata.",
      inputSchema: {
        root: z.string(),
        minSize: z.number().int().nonnegative().optional(),
        maxSize: z.number().int().nonnegative().optional(),
        modifiedAfter: z.string().optional(),
        modifiedBefore: z.string().optional(),
        includeHidden: z.boolean().optional(),
        maxResults: z.number().int().positive().optional()
      }
    },
    async (input) => textResult(await service.searchMetadata(input))
  );

  server.registerTool(
    "generate_diff",
    {
      description: "Generate a unified diff between current file content and proposed content.",
      inputSchema: {
        path: z.string(),
        nextContent: z.string()
      }
    },
    async (input) => textResult(await service.generateDiff(input))
  );

  const transport = new StdioServerTransport();
  await server.connect(transport);
}

function textResult(payload: unknown) {
  return {
    content: [
      {
        type: "text" as const,
        text: JSON.stringify(payload, null, 2)
      }
    ]
  };
}
