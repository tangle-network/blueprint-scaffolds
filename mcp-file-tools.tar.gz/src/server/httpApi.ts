import { createServer, type IncomingMessage, type ServerResponse } from "node:http";
import type { ApiErrorShape } from "../shared/contracts.js";
import { FsSafetyError } from "./pathSafety.js";
import { FilesystemService } from "./filesystemService.js";
import type { ServerConfig } from "./config.js";

type Handler = (body: unknown) => Promise<unknown>;

export function startHttpApi(service: FilesystemService, config: ServerConfig): void {
  const routes = new Map<string, Handler>([
    ["GET /api/roots", async () => ({ roots: service.getRoots() })],
    ["POST /api/list", async (body) => service.listDirectory(body as never)],
    ["POST /api/read", async (body) => service.readFile(body as never)],
    ["POST /api/write", async (body) => service.writeFile(body as never)],
    ["POST /api/directory", async (body) => service.createDirectory(body as never)],
    ["POST /api/move", async (body) => service.movePath(body as never)],
    ["POST /api/delete", async (body) => service.deletePath(body as never)],
    ["POST /api/search/glob", async (body) => service.searchGlob(body as never)],
    ["POST /api/search/grep", async (body) => service.searchGrep(body as never)],
    ["POST /api/search/metadata", async (body) => service.searchMetadata(body as never)],
    ["POST /api/diff", async (body) => service.generateDiff(body as never)]
  ]);

  const server = createServer(async (req, res) => {
    try {
      setCors(res);
      if (req.method === "OPTIONS") {
        res.writeHead(204).end();
        return;
      }

      const routeKey = `${req.method ?? "GET"} ${req.url ?? "/"}`;
      const handler = routes.get(routeKey);
      if (!handler) {
        sendJson(res, 404, { error: "not_found" });
        return;
      }

      const body = req.method === "GET" ? undefined : await readJson(req);
      const data = await handler(body);
      sendJson(res, 200, data);
    } catch (error) {
      const payload = normalizeError(error);
      const status = payload.error === "confirmation_required" ? 409 : 400;
      sendJson(res, status, payload);
    }
  });

  server.listen(config.apiPort, () => {
    console.log(`HTTP API listening on http://localhost:${config.apiPort}`);
  });
}

async function readJson(req: IncomingMessage): Promise<unknown> {
  const chunks: Buffer[] = [];
  for await (const chunk of req) {
    chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  }
  const text = Buffer.concat(chunks).toString("utf8");
  return text ? (JSON.parse(text) as unknown) : {};
}

function normalizeError(error: unknown): ApiErrorShape {
  if (error instanceof FsSafetyError) {
    return {
      error: error.message,
      confirmationToken: error.confirmationToken
    };
  }
  if (error instanceof Error) {
    return { error: error.message };
  }
  return { error: "Unknown error" };
}

function sendJson(res: ServerResponse, status: number, payload: unknown): void {
  res.writeHead(status, { "content-type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(payload));
}

function setCors(res: ServerResponse): void {
  res.setHeader("access-control-allow-origin", "*");
  res.setHeader("access-control-allow-methods", "GET,POST,OPTIONS");
  res.setHeader("access-control-allow-headers", "content-type");
}
