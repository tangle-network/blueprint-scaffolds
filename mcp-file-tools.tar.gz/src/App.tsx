import { useEffect, useState } from "react";
import { api } from "./client/api";
import type { ApiErrorShape, FileEntry, SearchMatch } from "./shared/contracts";
import "./styles.css";

export default function App() {
  const [roots, setRoots] = useState<string[]>([]);
  const [currentRoot, setCurrentRoot] = useState("");
  const [entries, setEntries] = useState<FileEntry[]>([]);
  const [selectedPath, setSelectedPath] = useState("");
  const [content, setContent] = useState("");
  const [diff, setDiff] = useState("");
  const [searchQuery, setSearchQuery] = useState("README");
  const [searchResults, setSearchResults] = useState<SearchMatch[]>([]);
  const [status, setStatus] = useState("Loading roots...");

  useEffect(() => {
    void loadRoots();
  }, []);

  async function loadRoots() {
    try {
      const result = await api.roots();
      setRoots(result.roots);
      const firstRoot = result.roots[0] ?? "";
      setCurrentRoot(firstRoot);
      if (firstRoot) {
        await loadDirectory(firstRoot);
      }
      setStatus("Ready");
    } catch (error) {
      setStatus(formatError(error));
    }
  }

  async function loadDirectory(dirPath: string) {
    try {
      const result = await api.list({ path: dirPath, maxEntries: 200 });
      setEntries(result.entries);
      setStatus(result.truncated ? "Directory truncated to 200 entries" : "Directory loaded");
    } catch (error) {
      setStatus(formatError(error));
    }
  }

  async function openFile(filePath: string) {
    try {
      const result = await api.read({ path: filePath, encoding: "utf8" });
      setSelectedPath(result.path);
      setContent(result.content);
      setDiff("");
      setStatus(result.truncated ? "File preview truncated by safety limit" : "File loaded");
    } catch (error) {
      setStatus(formatError(error));
    }
  }

  async function saveFile() {
    if (!selectedPath) {
      setStatus("Choose a file first");
      return;
    }

    try {
      await api.write({
        path: selectedPath,
        content,
        encoding: "utf8",
        atomic: true,
        createDirectories: true
      });
      setStatus("File saved atomically");
      await refreshDiff();
    } catch (error) {
      setStatus(formatError(error));
    }
  }

  async function refreshDiff() {
    if (!selectedPath) {
      return;
    }

    try {
      const result = await api.diff({ path: selectedPath, nextContent: content });
      setDiff(result.diff);
    } catch (error) {
      setStatus(formatError(error));
    }
  }

  async function runSearch() {
    if (!currentRoot) {
      return;
    }

    try {
      const result = await api.searchGrep({
        root: currentRoot,
        query: searchQuery,
        includeHidden: false,
        maxResults: 25
      });
      setSearchResults(result.matches);
      setStatus(result.truncated ? "Search truncated at 25 matches" : `Search found ${result.matches.length} matches`);
    } catch (error) {
      setStatus(formatError(error));
    }
  }

  return (
    <div className="app-shell">
      <section className="hero">
        <div>
          <p className="eyebrow">MCP Filesystem Tools</p>
          <h1>Sandboxed read, write, search, diff, and audited destructive operations.</h1>
        </div>
        <div className="status-card">{status}</div>
      </section>

      <section className="workspace">
        <aside className="panel">
          <div className="panel-header">
            <h2>Roots</h2>
            <select
              value={currentRoot}
              onChange={(event) => {
                const nextRoot = event.target.value;
                setCurrentRoot(nextRoot);
                void loadDirectory(nextRoot);
              }}
            >
              {roots.map((root) => (
                <option key={root} value={root}>
                  {root}
                </option>
              ))}
            </select>
          </div>

          <div className="list">
            {entries.map((entry) => (
              <button
                key={entry.path}
                className={`list-item ${entry.path === selectedPath ? "active" : ""}`}
                onClick={() => {
                  if (entry.type === "file") {
                    void openFile(entry.path);
                  } else if (entry.type === "directory") {
                    setCurrentRoot(entry.path);
                    void loadDirectory(entry.path);
                  }
                }}
              >
                <span>{entry.type === "directory" ? "DIR" : "FILE"}</span>
                <strong>{entry.name}</strong>
              </button>
            ))}
          </div>
        </aside>

        <main className="panel editor-panel">
          <div className="panel-header">
            <h2>Editor</h2>
            <div className="actions">
              <button onClick={() => void refreshDiff()}>Diff</button>
              <button onClick={() => void saveFile()}>Save</button>
            </div>
          </div>

          <div className="path-label">{selectedPath || "No file selected"}</div>
          <textarea
            className="editor"
            value={content}
            onChange={(event) => setContent(event.target.value)}
            placeholder="Select a file to inspect and edit"
          />

          <div className="diff-block">
            <h3>Unified Diff</h3>
            <pre>{diff || "Generate a diff to preview changes before saving."}</pre>
          </div>
        </main>

        <aside className="panel">
          <div className="panel-header">
            <h2>Search</h2>
            <button onClick={() => void runSearch()}>Run</button>
          </div>
          <input value={searchQuery} onChange={(event) => setSearchQuery(event.target.value)} />
          <div className="list">
            {searchResults.map((match) => (
              <button key={match.path} className="list-item" onClick={() => void openFile(match.path)}>
                <strong>{match.path}</strong>
                <span>{match.preview ?? `${match.size} bytes`}</span>
              </button>
            ))}
          </div>
        </aside>
      </section>
    </div>
  );
}

function formatError(error: unknown): string {
  if (typeof error === "object" && error && "error" in error) {
    const apiError = error as ApiErrorShape;
    return apiError.confirmationToken
      ? `${apiError.error}: retry with ${apiError.confirmationToken}`
      : apiError.error;
  }
  return error instanceof Error ? error.message : "Unknown error";
}
