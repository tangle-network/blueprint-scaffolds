import React, { useState, useCallback } from "react";
import { FileBrowser } from "@/components/FileBrowser";
import { FileEditor } from "@/components/FileEditor";
import { SearchPanel } from "@/components/SearchPanel";
import { AuditLogViewer } from "@/components/AuditLogViewer";
import { ToolPanel } from "@/components/ToolPanel";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Wrench,
  Search,
  ClipboardList,
  FileText,
  PanelLeftClose,
  PanelLeft,
} from "lucide-react";
import { Button } from "@/components/ui/button";

export default function App() {
  const [currentFile, setCurrentFile] = useState<string>("");
  const [sidebarVisible, setSidebarVisible] = useState(true);
  const [rightPanel, setRightPanel] = useState("tools");

  const handleFileSelect = useCallback((path: string) => {
    setCurrentFile(path);
  }, []);

  const handleSave = useCallback((_path: string, _content: string) => {}, []);

  return (
    <div className="h-screen flex flex-col bg-background">
      <header className="flex items-center justify-between px-4 py-2 border-b">
        <div className="flex items-center gap-3">
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8"
            onClick={() => setSidebarVisible(!sidebarVisible)}
          >
            {sidebarVisible ? (
              <PanelLeftClose className="h-4 w-4" />
            ) : (
              <PanelLeft className="h-4 w-4" />
            )}
          </Button>
          <div>
            <h1 className="text-sm font-bold">MCP File System Tools</h1>
            <p className="text-xs text-muted-foreground">
              Sandboxed file operations with audit logging
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded">
            Sandbox: /home/agent/storage
          </span>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {sidebarVisible && (
          <div className="w-64 border-r flex flex-col bg-background">
            <FileBrowser
              onFileSelect={handleFileSelect}
              currentPath={currentFile}
            />
          </div>
        )}

        <div className="flex-1 flex flex-col min-w-0">
          <div className="flex-1 min-h-0">
            <FileEditor filePath={currentFile} onSave={handleSave} />
          </div>
        </div>

        <div className="w-80 border-l flex flex-col bg-background">
          <Tabs
            value={rightPanel}
            onValueChange={setRightPanel}
            className="flex-1 flex flex-col"
          >
            <TabsList className="w-full rounded-none border-b h-auto p-0 bg-transparent">
              <TabsTrigger
                value="tools"
                className="flex-1 rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent py-2"
              >
                <Wrench className="h-3.5 w-3.5 mr-1" />
                <span className="text-xs">Tools</span>
              </TabsTrigger>
              <TabsTrigger
                value="search"
                className="flex-1 rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent py-2"
              >
                <Search className="h-3.5 w-3.5 mr-1" />
                <span className="text-xs">Search</span>
              </TabsTrigger>
              <TabsTrigger
                value="audit"
                className="flex-1 rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent py-2"
              >
                <ClipboardList className="h-3.5 w-3.5 mr-1" />
                <span className="text-xs">Audit</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="tools" className="flex-1 m-0 overflow-hidden">
              <ToolPanel />
            </TabsContent>
            <TabsContent value="search" className="flex-1 m-0 overflow-hidden">
              <SearchPanel />
            </TabsContent>
            <TabsContent value="audit" className="flex-1 m-0 overflow-hidden">
              <AuditLogViewer />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
