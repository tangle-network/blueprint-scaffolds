/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        vrf: {
          dark: '#0a0e1a',
          panel: '#111827',
          accent: '#6366f1',
          success: '#10b981',
          warn: '#f59e0b',
          danger: '#ef4444',
        },
      },
    },
  },
  plugins: [],
};
