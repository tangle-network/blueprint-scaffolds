// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "./IVRFConsumer.sol";

interface IRiscZeroVerifier {
    function verify(bytes calldata seal, bytes32 imageId, bytes32 journalDigest) external view;
}

contract RiscZeroVRFCoordinator {
    enum Status {
        None,
        Committed,
        Fulfilled
    }

    struct Request {
        address consumer;
        bytes32 commitment;
        uint64 createdAtBlock;
        uint32 callbackGasLimit;
        uint16 minConfirmations;
        Status status;
    }

    event RandomnessRequested(
        bytes32 indexed requestId,
        address indexed consumer,
        bytes32 indexed commitment,
        uint16 minConfirmations
    );

    event RandomnessFulfilled(bytes32 indexed requestId, uint256 randomness);

    IRiscZeroVerifier public immutable verifier;
    bytes32 public immutable imageId;
    mapping(bytes32 => Request) public requests;
    mapping(bytes32 => bool) public nullifiers;

    uint256 private nonce;

    constructor(address verifier_, bytes32 imageId_) {
        verifier = IRiscZeroVerifier(verifier_);
        imageId = imageId_;
    }

    function requestRandomness(
        bytes32 commitment,
        uint16 minConfirmations,
        uint32 callbackGasLimit
    ) external returns (bytes32 requestId) {
        nonce += 1;
        requestId = keccak256(
            abi.encodePacked(msg.sender, commitment, block.chainid, block.number, nonce)
        );

        requests[requestId] = Request({
            consumer: msg.sender,
            commitment: commitment,
            createdAtBlock: uint64(block.number),
            callbackGasLimit: callbackGasLimit,
            minConfirmations: minConfirmations,
            status: Status.Committed
        });

        emit RandomnessRequested(requestId, msg.sender, commitment, minConfirmations);
    }

    function fulfillRandomness(
        bytes32 requestId,
        bytes32 proofNullifier,
        bytes calldata journal,
        bytes calldata seal
    ) external {
        Request storage req = requests[requestId];
        require(req.status == Status.Committed, "bad-status");
        require(block.number >= req.createdAtBlock + req.minConfirmations, "too-early");
        require(!nullifiers[proofNullifier], "proof-used");

        bytes32 digest = sha256(
            abi.encodePacked(requestId, req.consumer, req.commitment, proofNullifier, journal)
        );
        verifier.verify(seal, imageId, digest);

        nullifiers[proofNullifier] = true;
        req.status = Status.Fulfilled;

        uint256 randomness = uint256(
            keccak256(
                abi.encodePacked(
                    requestId,
                    req.consumer,
                    req.commitment,
                    blockhash(req.createdAtBlock),
                    journal
                )
            )
        );

        IVRFConsumer(req.consumer).rawFulfillRandomness{gas: req.callbackGasLimit}(
            requestId,
            randomness
        );

        emit RandomnessFulfilled(requestId, randomness);
    }
}
