// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

struct VRFRequest {
    uint256 requestId;
    address requester;
    uint256 seed;
    bytes32 commitment;
    uint256 blockNumber;
    uint256 timestamp;
    bool fulfilled;
    bytes32 randomness;
    bytes proof;
}

struct EntropySource {
    string name;
    uint256 weight;
    bool active;
}

interface IVRFCoordinator {
    event RandomnessRequested(uint256 indexed requestId, address indexed requester, bytes32 commitment, uint256 seed);
    event RandomnessFulfilled(uint256 indexed requestId, bytes32 randomness, bytes proof);
    event EntropySourceAdded(string name, uint256 weight);
    event EntropySourceRemoved(string name);

    function requestRandomness(uint256 seed) external payable returns (uint256 requestId);
    function requestRandomnessWithCommitment(bytes32 commitment) external payable returns (uint256 requestId);
    function fulfillRandomness(uint256 requestId, bytes32 randomness, bytes calldata proof) external;
    function getRandomness(uint256 requestId) external view returns (bytes32);
    function getRequest(uint256 requestId) external view returns (VRFRequest memory);
    function isFulfilled(uint256 requestId) external view returns (bool);
    function addEntropySource(string calldata name, uint256 weight) external;
    function removeEntropySource(string calldata name) external;
    function getActiveEntropySources() external view returns (EntropySource[] memory);
}
