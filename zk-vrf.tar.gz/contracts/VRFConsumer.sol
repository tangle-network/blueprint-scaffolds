// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract VRFConsumer {
    struct RandomnessResult {
        uint256 requestId;
        bytes32 randomness;
        uint256 retrievedAt;
    }

    address public vrfCoordinator;
    mapping(uint256 => RandomnessResult) public results;
    uint256[] public requestIds;

    event RandomnessConsumed(uint256 indexed requestId, bytes32 randomness, string purpose);

    constructor(address _vrfCoordinator) {
        vrfCoordinator = _vrfCoordinator;
    }

    function requestRandomWords(uint256 seed) external payable returns (uint256) {
        (bool success, bytes memory data) = vrfCoordinator.call{value: msg.value}(
            abi.encodeWithSignature("requestRandomness(uint256)", seed)
        );
        require(success, "VRF request failed");
        uint256 requestId = abi.decode(data, (uint256));
        requestIds.push(requestId);
        return requestId;
    }

    function consumeRandomness(uint256 requestId, string calldata purpose) external returns (bytes32) {
        (bool success, bytes memory data) = vrfCoordinator.staticcall(
            abi.encodeWithSignature("getRandomness(uint256)", requestId)
        );
        require(success, "VRF call failed");
        bytes32 randomness = abi.decode(data, (bytes32));

        results[requestId] = RandomnessResult({
            requestId: requestId,
            randomness: randomness,
            retrievedAt: block.timestamp
        });

        emit RandomnessConsumed(requestId, randomness, purpose);
        return randomness;
    }

    function expandToWords(bytes32 randomness, uint256 count) external pure returns (uint256[] memory) {
        uint256[] memory words = new uint256[](count);
        for (uint256 i = 0; i < count; i++) {
            words[i] = uint256(keccak256(abi.encodePacked(randomness, i)));
        }
        return words;
    }

    function getRandomnessHistory() external view returns (RandomnessResult[] memory) {
        RandomnessResult[] memory history = new RandomnessResult[](requestIds.length);
        for (uint256 i = 0; i < requestIds.length; i++) {
            history[i] = results[requestIds[i]];
        }
        return history;
    }
}
