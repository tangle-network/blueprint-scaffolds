// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./IVRFCoordinator.sol";

contract VRFCoordinator is IVRFCoordinator {
    uint256 public requestCount;
    uint256 public constant MIN_FEE = 0.001 ether;
    uint256 public constant MAX_REQUESTS_PER_BLOCK = 10;
    uint256 public constant COMMITMENT_TIMEOUT = 100 blocks;

    address public owner;
    address public verifier;

    mapping(uint256 => VRFRequest) private requests;
    mapping(uint256 => uint256) private blockRequests;
    mapping(bytes32 => bool) private usedCommitments;
    mapping(string => EntropySource) private entropySources;
    string[] private entropySourceNames;

    modifier onlyOwner() {
        require(msg.sender == owner, "Only owner");
        _;
    }

    modifier onlyVerifier() {
        require(msg.sender == verifier, "Only verifier");
        _;
    }

    constructor() {
        owner = msg.sender;
        verifier = msg.sender;
        entropySources["blockhash"] = EntropySource("blockhash", 30, true);
        entropySources["timestamp"] = EntropySource("timestamp", 20, true);
        entropySources["chainlink"] = EntropySource("chainlink", 30, true);
        entropySources["drand"] = EntropySource("drand", 20, true);
        entropySourceNames.push("blockhash");
        entropySourceNames.push("timestamp");
        entropySourceNames.push("chainlink");
        entropySourceNames.push("drand");
    }

    function requestRandomness(uint256 seed) external payable override returns (uint256 requestId) {
        require(msg.value >= MIN_FEE, "Insufficient fee");
        require(blockRequests[block.number] < MAX_REQUESTS_PER_BLOCK, "Block limit reached");

        requestId = ++requestCount;
        bytes32 commitment = keccak256(abi.encodePacked(msg.sender, seed, block.number, requestId));

        require(!usedCommitments[commitment], "Commitment already used");
        usedCommitments[commitment] = true;
        blockRequests[block.number]++;

        requests[requestId] = VRFRequest({
            requestId: requestId,
            requester: msg.sender,
            seed: seed,
            commitment: commitment,
            blockNumber: block.number,
            timestamp: block.timestamp,
            fulfilled: false,
            randomness: bytes32(0),
            proof: bytes("")
        });

        emit RandomnessRequested(requestId, msg.sender, commitment, seed);
    }

    function requestRandomnessWithCommitment(bytes32 commitment) external payable override returns (uint256 requestId) {
        require(msg.value >= MIN_FEE, "Insufficient fee");
        require(blockRequests[block.number] < MAX_REQUESTS_PER_BLOCK, "Block limit reached");
        require(!usedCommitments[commitment], "Commitment already used");

        usedCommitments[commitment] = true;
        requestId = ++requestCount;
        blockRequests[block.number]++;

        requests[requestId] = VRFRequest({
            requestId: requestId,
            requester: msg.sender,
            seed: 0,
            commitment: commitment,
            blockNumber: block.number,
            timestamp: block.timestamp,
            fulfilled: false,
            randomness: bytes32(0),
            proof: bytes("")
        });

        emit RandomnessRequested(requestId, msg.sender, commitment, 0);
    }

    function fulfillRandomness(uint256 requestId, bytes32 randomness, bytes calldata proof) external override onlyVerifier {
        VRFRequest storage req = requests[requestId];
        require(req.requestId != 0, "Request not found");
        require(!req.fulfilled, "Already fulfilled");
        require(block.number <= req.blockNumber + COMMITMENT_TIMEOUT, "Request expired");

        bytes32 combined = _combineEntropySources(req, randomness);
        req.randomness = combined;
        req.proof = proof;
        req.fulfilled = true;

        emit RandomnessFulfilled(requestId, combined, proof);
    }

    function getRandomness(uint256 requestId) external view override returns (bytes32) {
        require(requests[requestId].fulfilled, "Not fulfilled");
        return requests[requestId].randomness;
    }

    function getRequest(uint256 requestId) external view override returns (VRFRequest memory) {
        require(requests[requestId].requestId != 0, "Request not found");
        return requests[requestId];
    }

    function isFulfilled(uint256 requestId) external view override returns (bool) {
        return requests[requestId].fulfilled;
    }

    function addEntropySource(string calldata name, uint256 weight) external override onlyOwner {
        require(!entropySources[name].active, "Already exists");
        entropySources[name] = EntropySource(name, weight, true);
        entropySourceNames.push(name);
        emit EntropySourceAdded(name, weight);
    }

    function removeEntropySource(string calldata name) external override onlyOwner {
        require(entropySources[name].active, "Not active");
        entropySources[name].active = false;
        emit EntropySourceRemoved(name);
    }

    function getActiveEntropySources() external view override returns (EntropySource[] memory) {
        uint256 count;
        for (uint256 i = 0; i < entropySourceNames.length; i++) {
            if (entropySources[entropySourceNames[i]].active) count++;
        }
        EntropySource[] memory active = new EntropySource[](count);
        uint256 idx;
        for (uint256 i = 0; i < entropySourceNames.length; i++) {
            if (entropySources[entropySourceNames[i]].active) {
                active[idx++] = entropySources[entropySourceNames[i]];
            }
        }
        return active;
    }

    function _combineEntropySources(VRFRequest storage req, bytes32 providedRandomness) internal view returns (bytes32) {
        bytes32 blockHash = blockhash(req.blockNumber);
        bytes32 combined = keccak256(abi.encodePacked(
            req.commitment,
            providedRandomness,
            blockHash,
            block.timestamp,
            req.requester
        ));
        return combined;
    }

    function setVerifier(address _verifier) external onlyOwner {
        verifier = _verifier;
    }
}
