// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "./RiscZeroVRFCoordinator.sol";

contract ExampleLotteryConsumer is IVRFConsumer {
    RiscZeroVRFCoordinator public immutable coordinator;

    uint256 public winnerIndex;
    bytes32 public activeRequestId;

    constructor(address coordinator_) {
        coordinator = RiscZeroVRFCoordinator(coordinator_);
    }

    function drawWinner(bytes32 commitment) external {
        activeRequestId = coordinator.requestRandomness(commitment, 8, 200000);
    }

    function rawFulfillRandomness(bytes32 requestId, uint256 randomness) external override {
        require(msg.sender == address(coordinator), "only-coordinator");
        require(requestId == activeRequestId, "unknown-request");
        winnerIndex = randomness % 1000;
    }
}
