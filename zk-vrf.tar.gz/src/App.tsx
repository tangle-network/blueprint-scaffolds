import { useState, useEffect } from 'react';
import RequestForm from './components/RequestForm';
import RequestCard from './components/RequestCard';
import ProgressIndicator from './components/ProgressIndicator';
import HistoryPanel from './components/HistoryPanel';
import ArchitecturePanel from './components/ArchitecturePanel';
import { VRFRequest, UseCase } from './types';
import { submitVRFRequest, getStoredRequests, clearStoredRequests } from './api';

export default function App() {
  const [requests, setRequests] = useState<VRFRequest[]>([]);
  const [latestRequest, setLatestRequest] = useState<VRFRequest | null>(null);
  const [loading, setLoading] = useState(false);
  const [progressStage, setProgressStage] = useState('');
  const [showArch, setShowArch] = useState(true);

  useEffect(() => {
    setRequests(getStoredRequests());
  }, []);

  const handleSubmit = async (seed: string, numWords: number, useCase: UseCase) => {
    setLoading(true);
    setProgressStage('Initializing...');
    setLatestRequest(null);
    try {
      const req = await submitVRFRequest(seed, numWords, useCase, setProgressStage);
      setLatestRequest(req);
      setRequests(getStoredRequests());
    } finally {
      setLoading(false);
      setTimeout(() => setProgressStage(''), 3000);
    }
  };

  const handleClear = () => {
    clearStoredRequests();
    setRequests([]);
    setLatestRequest(null);
  };

  return (
    <div className="min-h-screen">
      <header className="border-b border-gray-800/50 py-6 px-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">
              RISC Zero VRF
            </h1>
            <p className="text-sm text-gray-500 mt-0.5">
              Provably fair on-chain randomness with commit-reveal & ZK proofs
            </p>
          </div>
          <button
            onClick={() => setShowArch(!showArch)}
            className="text-xs px-3 py-1.5 rounded-lg border border-gray-700 text-gray-400 hover:text-white hover:border-vrf-accent transition-all"
          >
            {showArch ? 'Hide' : 'Show'} Architecture
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <RequestForm onSubmit={handleSubmit} loading={loading} />

            {progressStage && <ProgressIndicator stage={progressStage} />}

            {latestRequest && <RequestCard request={latestRequest} />}

            {showArch && <ArchitecturePanel />}
          </div>

          <div>
            <HistoryPanel requests={requests} onClear={handleClear} />
          </div>
        </div>
      </main>

      <footer className="border-t border-gray-800/50 py-6 px-4 mt-12">
        <div className="max-w-6xl mx-auto flex items-center justify-between text-xs text-gray-600">
          <span>RISC Zero VRF Service v1.0.0</span>
          <span>Powered by RISC Zero STARK proofs</span>
        </div>
      </footer>
    </div>
  );
}
