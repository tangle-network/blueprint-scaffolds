type EntropySource = {
  name: string;
  contribution: string;
  trustModel: string;
};

type PipelineStage = {
  title: string;
  detail: string;
};

type UseCase = {
  title: string;
  description: string;
};

const entropySources: EntropySource[] = [
  {
    name: 'User Commit Salt',
    contribution: 'Hidden seed committed before request inclusion.',
    trustModel: 'Unpredictable to searchers until reveal.',
  },
  {
    name: 'Coordinator Beacon',
    contribution: 'Service-side entropy sealed into the zk guest execution.',
    trustModel: 'Verifiable by RISC Zero receipt instead of blind trust.',
  },
  {
    name: 'Chain Context',
    contribution: 'Block hash window and request metadata folded into the transcript.',
    trustModel: 'Anchors output to the execution environment without making it miner-controlled.',
  },
];

const pipeline: PipelineStage[] = [
  {
    title: '1. Commit',
    detail: 'The requester submits a commitment hash, callback target, gas limit, and application payload. The coordinator records the request and locks its nonce.',
  },
  {
    title: '2. Reveal + Prove',
    detail: 'After finality, the service reveals its witness bundle inside a RISC Zero guest. The guest verifies the commitment, mixes all entropy sources, and emits a receipt.',
  },
  {
    title: '3. Fulfill',
    detail: 'The coordinator validates the proof, checks replay protection, derives the final random word, and calls the consumer through a request/fulfill interface.',
  },
];

const useCases: UseCase[] = [
  {
    title: 'Gaming',
    description: 'Resolve loot drops, card shuffles, and battle outcomes with public auditability.',
  },
  {
    title: 'NFT Traits',
    description: 'Assign metadata traits after mint without exposing deterministic mint-order sniping.',
  },
  {
    title: 'Lotteries',
    description: 'Pick winners from finalized participant sets while resisting manipulation and front-running.',
  },
  {
    title: 'Leader Selection',
    description: 'Rotate sequencers, validators, or committees from a transparent randomness beacon.',
  },
];

const initialRequest = {
  requestId: 'REQ-19024',
  consumer: '0x2a5f...9d11',
  commitment: '0xf65e1f0f0df8...0ac9',
  callbackGasLimit: 350000,
  minConfirmations: 8,
  appNonce: 'lottery-round-42',
};

const contractSnippet = `function fulfillRandomness(
    bytes32 requestId,
    bytes calldata journal,
    bytes calldata seal
) external {
    Request storage req = requests[requestId];
    require(req.status == Status.Committed, "bad-status");
    verifier.verify(seal, imageId, sha256(journal));

    bytes32 randomWord = keccak256(
        abi.encodePacked(
            requestId,
            req.commitment,
            req.consumer,
            journal
        )
    );

    req.status = Status.Fulfilled;
    IVRFConsumer(req.consumer).rawFulfillRandomness(requestId, uint256(randomWord));
}`;

function App() {
  return (
    <div className="shell">
      <header className="hero">
        <div className="hero-copy">
          <p className="eyebrow">RISC Zero VRF Service</p>
          <h1>Provably fair randomness for contracts that cannot afford trust leaks.</h1>
          <p className="lede">
            Commit-reveal prevents pre-trade leakage, a zk receipt proves the entropy mix,
            and a coordinator contract provides a familiar request/fulfill flow for gaming,
            lotteries, NFT mints, and leader election.
          </p>
          <div className="hero-badges">
            <span>Commit-Reveal</span>
            <span>Bias-Resistant Mixing</span>
            <span>Front-Running Protection</span>
          </div>
        </div>

        <aside className="request-card">
          <div className="card-header">
            <h2>Request Interface</h2>
            <span className="status">Ready</span>
          </div>

          <form className="request-form">
            <label>
              Consumer Contract
              <input value={initialRequest.consumer} readOnly />
            </label>
            <label>
              Commitment Hash
              <input value={initialRequest.commitment} readOnly />
            </label>
            <div className="grid-two">
              <label>
                Callback Gas
                <input value={String(initialRequest.callbackGasLimit)} readOnly />
              </label>
              <label>
                Confirmations
                <input value={String(initialRequest.minConfirmations)} readOnly />
              </label>
            </div>
            <label>
              App Nonce
              <input value={initialRequest.appNonce} readOnly />
            </label>

            <div className="request-meta">
              <div>
                <span>Request ID</span>
                <strong>{initialRequest.requestId}</strong>
              </div>
              <div>
                <span>Execution Path</span>
                <strong>Coordinator → Guest → Proof → Callback</strong>
              </div>
            </div>
          </form>
        </aside>
      </header>

      <main className="content">
        <section className="panel">
          <div className="section-heading">
            <p className="eyebrow">Entropy Sources</p>
            <h2>Multiple inputs, one deterministic proof transcript.</h2>
          </div>
          <div className="cards">
            {entropySources.map((source) => (
              <article className="info-card" key={source.name}>
                <h3>{source.name}</h3>
                <p>{source.contribution}</p>
                <small>{source.trustModel}</small>
              </article>
            ))}
          </div>
        </section>

        <section className="panel split">
          <div>
            <div className="section-heading">
              <p className="eyebrow">Lifecycle</p>
              <h2>Request, prove, fulfill.</h2>
            </div>
            <div className="timeline">
              {pipeline.map((stage) => (
                <article className="timeline-item" key={stage.title}>
                  <h3>{stage.title}</h3>
                  <p>{stage.detail}</p>
                </article>
              ))}
            </div>
          </div>

          <div className="panel inset">
            <div className="section-heading">
              <p className="eyebrow">Bias Resistance</p>
              <h2>Front-running and selective aborts are constrained at the protocol layer.</h2>
            </div>
            <ul className="checklist">
              <li>Commitment hashes hide user intent until the reveal phase closes.</li>
              <li>Request nonces and proof nullifiers stop replay across rounds.</li>
              <li>Entropy contributions are domain-separated before hashing to reduce correlation risk.</li>
              <li>Final outputs bind the consumer address, request id, and receipt journal.</li>
            </ul>
          </div>
        </section>

        <section className="panel split">
          <div>
            <div className="section-heading">
              <p className="eyebrow">Coordinator Contract</p>
              <h2>Familiar VRF integration surface.</h2>
            </div>
            <p className="lede compact">
              Consumer contracts request randomness through a coordinator, then receive the final
              word in a callback after proof verification. The Solidity sources live under
              <code> contracts/</code> in this project.
            </p>
            <pre className="code-block">
              <code>{contractSnippet}</code>
            </pre>
          </div>

          <div>
            <div className="section-heading">
              <p className="eyebrow">Use Cases</p>
              <h2>High-integrity randomness anywhere selection matters.</h2>
            </div>
            <div className="cards">
              {useCases.map((useCase) => (
                <article className="info-card compact" key={useCase.title}>
                  <h3>{useCase.title}</h3>
                  <p>{useCase.description}</p>
                </article>
              ))}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;
