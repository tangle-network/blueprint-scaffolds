import { VRFRequest, UseCase } from './types';
import { simulateCommit, simulateZKProof, generateRandomWords } from './lib/vrf';

const STORAGE_KEY = 'risc0-vrf-requests';

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function submitVRFRequest(
  seed: string,
  numWords: number,
  useCase: UseCase,
  onProgress: (stage: string) => void,
): Promise<VRFRequest> {
  const id = `req_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const nonce = Date.now().toString(16) + Math.random().toString(16).slice(2);

  const request: VRFRequest = {
    id,
    requester: '0x' + 'a'.repeat(40),
    seed,
    numWords,
    status: 'pending',
    createdAt: Date.now(),
    useCase,
  };

  onProgress('Submitting request to VRF coordinator...');
  await delay(600);
  request.status = 'commit';

  onProgress('Generating commit hash (commit-reveal phase 1)...');
  await delay(400);
  const commitHash = simulateCommit(seed, nonce);
  request.commitHash = commitHash;

  onProgress('Collecting entropy sources...');
  await delay(500);
  const entropySources = collectEntropy(commitHash);
  request.entropySources = entropySources;

  const combinedEntropy = entropySources.map((e) => e.value).join('');

  onProgress('Generating ZK proof via RISC Zero guest...');
  await delay(1200);
  const { proof, journal } = simulateZKProof(commitHash, seed, nonce, combinedEntropy);
  request.proof = proof;

  onProgress('Verifying proof and fulfilling request...');
  await delay(600);

  const reveal = generateRandomWords(combinedEntropy, numWords);
  request.randomness = reveal;
  request.status = 'fulfilled';
  request.fulfilledAt = Date.now();

  persistRequest(request);
  onProgress('Complete! Randomness delivered on-chain.');

  return request;
}

function collectEntropy(commitHash: string) {
  return [
    { name: 'Block Hash', value: commitHash.slice(0, 64), weight: 30 },
    { name: 'RISC Zero DRAND', value: hashString('drand_' + Date.now()), weight: 25 },
    { name: 'Requester Nonce', value: hashString('nonce_' + commitHash), weight: 20 },
    { name: 'Timestamp Entropy', value: Date.now().toString(16).padStart(64, '0'), weight: 15 },
    { name: 'Beacon Chain RANDAO', value: hashString('randao_' + Math.random()), weight: 10 },
  ];
}

function hashString(input: string): string {
  let hash = 0n;
  for (let i = 0; i < input.length; i++) {
    const char = BigInt(input.charCodeAt(i));
    hash = ((hash << 5n) - hash + char) & BigInt('0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF');
  }
  return hash.toString(16).padStart(64, '0');
}

function persistRequest(request: VRFRequest): void {
  const existing = getStoredRequests();
  existing.unshift(request);
  if (existing.length > 50) existing.length = 50;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(existing));
  } catch {
    // storage full
  }
}

export function getStoredRequests(): VRFRequest[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function clearStoredRequests(): void {
  localStorage.removeItem(STORAGE_KEY);
}
