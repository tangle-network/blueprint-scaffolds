import { useVRF } from "@/lib/hooks"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Clock, Trash2, ExternalLink } from "lucide-react"
import { useState } from "react"
import type { VRFRequest } from "@/lib/vrf"
import ProofViewer from "@/components/vrf/ProofViewer"

export default function HistoryPage() {
  const { requests, clearHistory } = useVRF()
  const [selectedRequest, setSelectedRequest] = useState<VRFRequest | null>(null)

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
            <Clock className="h-8 w-8 text-primary" />
            Request History
          </h1>
          <p className="text-muted-foreground mt-1">
            View all past VRF randomness requests and their proofs
          </p>
        </div>
        {requests.length > 0 && (
          <Button variant="destructive" size="sm" onClick={clearHistory}>
            <Trash2 className="mr-2 h-4 w-4" />
            Clear History
          </Button>
        )}
      </div>

      {requests.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Clock className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg font-medium">No requests yet</p>
            <p className="text-sm text-muted-foreground">
              Submit a randomness request to see it appear here
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-3">
            {requests.map((req) => (
              <Card
                key={req.requestId}
                className={`cursor-pointer transition-colors hover:border-primary/50 ${
                  selectedRequest?.requestId === req.requestId ? "border-primary" : ""
                }`}
                onClick={() => setSelectedRequest(req)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-medium">#{req.requestId}</span>
                        <Badge
                          variant={
                            req.status === "fulfilled" ? "default" :
                            req.status === "pending" ? "secondary" : "destructive"
                          }
                        >
                          {req.status}
                        </Badge>
                        <Badge variant="outline">{req.useCase}</Badge>
                      </div>
                      <p className="text-xs text-muted-foreground font-mono truncate max-w-[500px]">
                        Commitment: {req.commitment}
                      </p>
                      {req.randomness && (
                        <p className="text-xs text-muted-foreground font-mono truncate max-w-[500px]">
                          Randomness: {req.randomness}
                        </p>
                      )}
                    </div>
                    <div className="text-right text-xs text-muted-foreground shrink-0 ml-4">
                      <div>Block {req.blockNumber.toLocaleString()}</div>
                      <div>{new Date(req.timestamp).toLocaleString()}</div>
                      <div className="mt-1">
                        <ExternalLink className="h-3 w-3 inline" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div>
            {selectedRequest ? (
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Request Details</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    <div>
                      <span className="text-muted-foreground">Request ID</span>
                      <p className="font-mono">{selectedRequest.requestId}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Requester</span>
                      <p className="font-mono text-xs">{selectedRequest.requester}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Seed</span>
                      <p className="font-mono text-xs">{selectedRequest.seed}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Commitment</span>
                      <p className="font-mono text-xs break-all">{selectedRequest.commitment}</p>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <span className="text-muted-foreground">Block</span>
                        <p className="font-mono">{selectedRequest.blockNumber}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Status</span>
                        <div>
                          <Badge
                            variant={
                              selectedRequest.status === "fulfilled" ? "default" :
                              selectedRequest.status === "pending" ? "secondary" : "destructive"
                            }
                          >
                            {selectedRequest.status}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    {selectedRequest.randomness && (
                      <div className="rounded-lg bg-muted p-3">
                        <span className="text-xs text-muted-foreground">Randomness</span>
                        <p className="font-mono text-xs break-all">{selectedRequest.randomness}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
                {selectedRequest.proof && (
                  <ProofViewer proof={selectedRequest.proof} />
                )}
              </div>
            ) : (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <p className="text-sm text-muted-foreground">Select a request to view details</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
