import { useVRF, useBlockNumber } from "@/lib/hooks"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { LayoutDashboard, Zap, Clock, ShieldCheck, Activity } from "lucide-react"

export default function DashboardPage() {
  const { requests, entropySources } = useVRF()
  const blockNumber = useBlockNumber()

  const totalRequests = requests.length
  const fulfilledRequests = requests.filter((r) => r.status === "fulfilled").length
  const pendingRequests = requests.filter((r) => r.status === "pending").length
  const activeSources = entropySources.filter((s) => s.active).length

  const stats = [
    { title: "Total Requests", value: totalRequests, icon: Zap, color: "text-blue-500" },
    { title: "Fulfilled", value: fulfilledRequests, icon: ShieldCheck, color: "text-green-500" },
    { title: "Pending", value: pendingRequests, icon: Clock, color: "text-yellow-500" },
    { title: "Entropy Sources", value: `${activeSources}/${entropySources.length}`, icon: Activity, color: "text-purple-500" },
  ]

  const recentRequests = requests.slice(0, 5)

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
          <LayoutDashboard className="h-8 w-8 text-primary" />
          Dashboard
        </h1>
        <p className="text-muted-foreground mt-1">
          Provably fair randomness powered by RISC Zero ZK proofs
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Network Status</CardTitle>
            <CardDescription>Current block and system health</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Block Number</span>
              <span className="font-mono">{blockNumber.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Commitment Timeout</span>
              <span className="font-mono">100 blocks</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Min Fee</span>
              <span className="font-mono">0.001 ETH</span>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Fulfillment Rate</span>
                <span className="font-mono">
                  {totalRequests > 0
                    ? ((fulfilledRequests / totalRequests) * 100).toFixed(1)
                    : 0}
                  %
                </span>
              </div>
              <Progress
                value={totalRequests > 0 ? (fulfilledRequests / totalRequests) * 100 : 0}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Entropy Sources</CardTitle>
            <CardDescription>Active randomness sources with weights</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {entropySources.map((source) => (
              <div key={source.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div
                    className={`h-2 w-2 rounded-full ${
                      source.active ? "bg-green-500" : "bg-gray-300"
                    }`}
                  />
                  <span className="text-sm font-medium">{source.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">Weight: {source.weight}</span>
                  <Badge variant={source.active ? "default" : "secondary"}>
                    {source.active ? "Active" : "Inactive"}
                  </Badge>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {recentRequests.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Recent Requests</CardTitle>
            <CardDescription>Latest VRF randomness requests</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentRequests.map((req) => (
                <div
                  key={req.requestId}
                  className="flex items-center justify-between rounded-lg border p-3"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm">#{req.requestId}</span>
                      <Badge
                        variant={
                          req.status === "fulfilled"
                            ? "default"
                            : req.status === "pending"
                            ? "secondary"
                            : "destructive"
                        }
                      >
                        {req.status}
                      </Badge>
                      <Badge variant="outline">{req.useCase}</Badge>
                    </div>
                    <p className="text-xs text-muted-foreground font-mono truncate max-w-[400px]">
                      {req.commitment}
                    </p>
                  </div>
                  <div className="text-right text-xs text-muted-foreground">
                    <div>Block {req.blockNumber.toLocaleString()}</div>
                    <div>{new Date(req.timestamp).toLocaleTimeString()}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
