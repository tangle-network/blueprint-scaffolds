import { useState } from "react"
import { useVRF } from "@/lib/hooks"
import { type VRFProof } from "@/lib/types"
import { expandRandomness, mapRandomnessToRange } from "@/lib/vrf"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ShieldCheck, CheckCircle2, XCircle, Copy } from "lucide-react"

export default function VerifyPage() {
  const { requests, verifyProof } = useVRF()
  const [proofInput, setProofInput] = useState("")
  const [verifiedResults, setVerifiedResults] = useState<
    { input: string; valid: boolean; details: string }[]
  >([])
  const [expandCount, setExpandCount] = useState(4)
  const [expandInput, setExpandInput] = useState("")
  const [expandedValues, setExpandedValues] = useState<string[]>([])
  const [copied, setCopied] = useState<string | null>(null)

  const handleVerify = async () => {
    if (!proofInput.trim()) return

    let proof: VRFProof | null = null
    const found = requests.find(
      (r) =>
        r.proof?.proofId === proofInput ||
        r.requestId === proofInput ||
        r.commitment === proofInput
    )
    if (found?.proof) {
      proof = found.proof
    }

    const result = proof ? await verifyProof(proof.proofId) : null
    const valid = result ? result.valid : false
    setVerifiedResults((prev) => [
      {
        input: proofInput,
        valid,
        details: proof && found
          ? `Proof found for request #${found.requestId}. Verified: ${proof.verified}, Seal: ${proof.seal ? "present" : "missing"}, Journal: ${proof.journal ? "present" : "missing"}`
          : "No matching proof found. Ensure the proof ID, request ID, or commitment is correct.",
      },
      ...prev,
    ])
    setProofInput("")
  }

  const handleExpand = () => {
    if (!expandInput.trim()) return
    const values = expandRandomness(expandInput, expandCount)
    setExpandedValues(values)
  }

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text)
    setCopied(id)
    setTimeout(() => setCopied(null), 2000)
  }

  const verifiedProofs = requests.filter((r) => r.proof && r.status === "fulfilled")

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
          <ShieldCheck className="h-8 w-8 text-primary" />
          Verify Proofs
        </h1>
        <p className="text-muted-foreground mt-1">
          Verify ZK proofs and expand randomness for your use cases
        </p>
      </div>

      <Tabs defaultValue="verify" className="space-y-6">
        <TabsList>
          <TabsTrigger value="verify">Verify Proof</TabsTrigger>
          <TabsTrigger value="expand">Expand Randomness</TabsTrigger>
          <TabsTrigger value="verified">Verified Proofs ({verifiedProofs.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="verify" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Verify a Proof</CardTitle>
              <CardDescription>
                Enter a proof ID, request ID, or commitment to verify the ZK proof
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="Proof ID, Request ID, or Commitment"
                  value={proofInput}
                  onChange={(e) => setProofInput(e.target.value)}
                  className="font-mono"
                  onKeyDown={(e) => e.key === "Enter" && handleVerify()}
                />
                <Button onClick={handleVerify} disabled={!proofInput.trim()}>
                  <ShieldCheck className="mr-2 h-4 w-4" />
                  Verify
                </Button>
              </div>

              {verifiedResults.length > 0 && (
                <div className="space-y-3">
                  {verifiedResults.map((result, i) => (
                    <div
                      key={i}
                      className={`rounded-lg border p-4 ${
                        result.valid
                          ? "border-green-500/50 bg-green-500/5"
                          : "border-red-500/50 bg-red-500/5"
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-2">
                        {result.valid ? (
                          <CheckCircle2 className="h-5 w-5 text-green-500" />
                        ) : (
                          <XCircle className="h-5 w-5 text-red-500" />
                        )}
                        <span className="font-medium">
                          {result.valid ? "Proof Verified" : "Verification Failed"}
                        </span>
                        <Badge variant="outline" className="font-mono text-xs">
                          {result.input.substring(0, 20)}...
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{result.details}</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="expand" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Expand Randomness</CardTitle>
              <CardDescription>
                Derive multiple random values from a single randomness output
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Randomness Value</label>
                <Input
                  placeholder="0x..."
                  value={expandInput}
                  onChange={(e) => setExpandInput(e.target.value)}
                  className="font-mono"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Number of Values</label>
                <Input
                  type="number"
                  min={1}
                  max={100}
                  value={expandCount}
                  onChange={(e) => setExpandCount(parseInt(e.target.value) || 1)}
                />
              </div>
              <Button onClick={handleExpand} disabled={!expandInput.trim()} className="w-full">
                Expand
              </Button>

              {expandedValues.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-sm font-medium">Expanded Values</h4>
                  <div className="grid gap-2">
                    {expandedValues.map((val, i) => (
                      <div
                        key={i}
                        className="flex items-center justify-between rounded-lg bg-muted p-3"
                      >
                        <div>
                          <span className="text-xs text-muted-foreground">Index {i}</span>
                          <p className="font-mono text-sm">{val}</p>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-sm text-muted-foreground">
                            Range [1, 100]: {mapRandomnessToRange(val, 1, 100)}
                          </span>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => copyToClipboard(val, `expand-${i}`)}
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="verified" className="space-y-4">
          {verifiedProofs.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <ShieldCheck className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-lg font-medium">No verified proofs</p>
                <p className="text-sm text-muted-foreground">
                  Fulfilled requests with proofs will appear here
                </p>
              </CardContent>
            </Card>
          ) : (
            verifiedProofs.map((req) => (
              <Card key={req.requestId}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="h-4 w-4 text-green-500" />
                        <span className="font-mono font-medium">#{req.requestId}</span>
                        <Badge variant="default">Verified</Badge>
                        <Badge variant="outline">{req.useCase}</Badge>
                      </div>
                      <p className="text-xs text-muted-foreground font-mono truncate max-w-[400px]">
                        Seal: {req.proof?.seal?.substring(0, 40)}...
                      </p>
                    </div>
                    <div className="text-right text-xs text-muted-foreground">
                      <div>Verified: {req.proof?.verifiedAt ? new Date(req.proof.verifiedAt).toLocaleString() : "N/A"}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
