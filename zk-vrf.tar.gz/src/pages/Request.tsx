import { useState } from "react"
import { useVRF } from "@/lib/hooks"
import { USE_CASES, type UseCaseId } from "@/lib/types"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import EntropySourcePanel from "@/components/vrf/EntropySourcePanel"
import CommitRevealPanel from "@/components/vrf/CommitRevealPanel"
import ProofViewer from "@/components/vrf/ProofViewer"
import { Zap, Dice1, ImageIcon, Trophy, Users } from "lucide-react"

const useCaseIcons: Record<string, React.ElementType> = {
  gaming: Dice1,
  "nft-traits": ImageIcon,
  lottery: Trophy,
  "leader-selection": Users,
}

export default function RequestPage() {
  const { requestRandomness, phase, currentRequest, isLoading, error, entropySources, toggleEntropySource, setEntropyWeight } = useVRF()
  const [seed, setSeed] = useState("")
  const [selectedUseCase, setSelectedUseCase] = useState<UseCaseId>("gaming")

  const handleSubmit = async () => {
    if (!seed.trim()) return
    try {
      await requestRandomness(seed, selectedUseCase)
    } catch {}
  }

  const handleRandomSeed = () => {
    const arr = new Uint8Array(32)
    crypto.getRandomValues(arr)
    setSeed(
      "0x" +
        Array.from(arr)
          .map((b) => b.toString(16).padStart(2, "0"))
          .join("")
    )
  }

  const progressValue =
    phase.phase === "idle" ? 0 :
    phase.phase === "committing" ? 20 :
    phase.phase === "committed" ? 40 :
    phase.phase === "revealing" ? 70 :
    phase.phase === "revealed" ? 100 : 0

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
          <Zap className="h-8 w-8 text-primary" />
          Request Randomness
        </h1>
        <p className="text-muted-foreground mt-1">
          Generate provably fair randomness with commit-reveal and ZK proofs
        </p>
      </div>

      <Tabs defaultValue="request" className="space-y-6">
        <TabsList>
          <TabsTrigger value="request">Request</TabsTrigger>
          <TabsTrigger value="entropy">Entropy Sources</TabsTrigger>
          <TabsTrigger value="commit-reveal">Commit-Reveal</TabsTrigger>
          {currentRequest?.proof && (
            <TabsTrigger value="proof">Proof</TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="request" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Request Configuration</CardTitle>
              <CardDescription>Configure your randomness request parameters</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium">Seed Value</label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Enter seed (hex or decimal)"
                    value={seed}
                    onChange={(e) => setSeed(e.target.value)}
                    className="font-mono"
                  />
                  <Button variant="outline" onClick={handleRandomSeed}>
                    Random
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  The seed is combined with entropy sources to produce unbiased randomness
                </p>
              </div>

              <div className="space-y-3">
                <label className="text-sm font-medium">Use Case</label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {USE_CASES.map((uc) => {
                    const Icon = useCaseIcons[uc.id]
                    return (
                      <button
                        key={uc.id}
                        onClick={() => setSelectedUseCase(uc.id)}
                        className={`flex flex-col items-center gap-2 rounded-lg border-2 p-4 transition-all ${
                          selectedUseCase === uc.id
                            ? "border-primary bg-primary/5"
                            : "border-muted hover:border-primary/50"
                        }`}
                      >
                        <Icon className={`h-6 w-6 ${selectedUseCase === uc.id ? "text-primary" : "text-muted-foreground"}`} />
                        <span className="text-sm font-medium">{uc.label}</span>
                        <span className="text-xs text-muted-foreground text-center">{uc.description}</span>
                      </button>
                    )
                  })}
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Progress</span>
                  <span className="font-medium">{phase.phase}</span>
                </div>
                <Progress value={progressValue} />
              </div>

              {error && (
                <div className="rounded-lg border border-destructive/50 bg-destructive/10 p-3 text-sm text-destructive">
                  {error}
                </div>
              )}

              <Button
                onClick={handleSubmit}
                disabled={isLoading || !seed.trim()}
                className="w-full"
                size="lg"
              >
                {isLoading ? (
                  <>
                    <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Zap className="mr-2 h-4 w-4" />
                    Request Randomness
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {currentRequest && (
            <Card>
              <CardHeader>
                <CardTitle>Request Result</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="text-muted-foreground">Request ID</span>
                    <p className="font-mono">{currentRequest.requestId}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Status</span>
                    <div>
                      <Badge
                        variant={
                          currentRequest.status === "fulfilled" ? "default" :
                          currentRequest.status === "pending" ? "secondary" : "destructive"
                        }
                      >
                        {currentRequest.status}
                      </Badge>
                    </div>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Commitment</span>
                    <p className="font-mono text-xs truncate">{currentRequest.commitment}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Use Case</span>
                    <p>{currentRequest.useCase}</p>
                  </div>
                </div>
                {currentRequest.randomness && (
                  <div className="rounded-lg bg-muted p-3">
                    <span className="text-xs text-muted-foreground">Randomness Output</span>
                    <p className="font-mono text-sm break-all">{currentRequest.randomness}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="entropy">
          <EntropySourcePanel
            sources={entropySources}
            onToggle={toggleEntropySource}
            onWeightChange={setEntropyWeight}
          />
        </TabsContent>

        <TabsContent value="commit-reveal">
          <CommitRevealPanel phase={phase} request={currentRequest} />
        </TabsContent>

        {currentRequest?.proof && (
          <TabsContent value="proof">
            <ProofViewer proof={currentRequest.proof} />
          </TabsContent>
        )}
      </Tabs>
    </div>
  )
}
