export type VRFRequestStatus = 'pending' | 'commit' | 'fulfilled' | 'failed';

export interface VRFRequest {
  id: string;
  requester: string;
  seed: string;
  numWords: number;
  status: VRFRequestStatus;
  commitHash?: string;
  proof?: string;
  randomness?: string[];
  createdAt: number;
  fulfilledAt?: number;
  entropySources?: EntropySource[];
  useCase?: UseCase;
}

export interface EntropySource {
  name: string;
  value: string;
  weight: number;
}

export type UseCase = 'gaming' | 'nft-traits' | 'lottery' | 'leader-selection' | 'custom';

export interface VRFConfig {
  coordinator: string;
  chainId: number;
  maxGasLimit: number;
  confirmationBlocks: number;
  proofTimeout: number;
}

export const DEFAULT_CONFIG: VRFConfig = {
  coordinator: '0x0000000000000000000000000000000000000000',
  chainId: 1,
  maxGasLimit: 500000,
  confirmationBlocks: 3,
  proofTimeout: 300,
};

export const USE_CASES: { value: UseCase; label: string; description: string; defaultWords: number }[] = [
  { value: 'gaming', label: 'Gaming', description: 'Dice rolls, card shuffles, critical hits', defaultWords: 1 },
  { value: 'nft-traits', label: 'NFT Traits', description: 'Trait generation for minting', defaultWords: 4 },
  { value: 'lottery', label: 'Lottery', description: 'Provably fair lottery draws', defaultWords: 1 },
  { value: 'leader-selection', label: 'Leader Selection', description: 'Validator/committee selection', defaultWords: 1 },
  { value: 'custom', label: 'Custom', description: 'Custom random number request', defaultWords: 1 },
];
