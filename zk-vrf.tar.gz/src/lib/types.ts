export interface EntropySource {
  name: string
  weight: number
  active: boolean
  value?: string
  lastUpdated?: number
}

export interface CommitRevealPhase {
  phase: "idle" | "committing" | "committed" | "revealing" | "revealed"
  commitment?: string
  revealValue?: string
  timestamp?: number
}

export interface VRFProof {
  proofId: string
  requestId: string
  journal: string
  seal: string
  imageId: string
  entropySources: EntropySource[]
  combinedRandomness: string
  verified: boolean
  verifiedAt?: number
}

export interface VRFRequest {
  requestId: string
  requester: string
  seed: string
  commitment: string
  blockNumber: number
  timestamp: number
  fulfilled: boolean
  randomness?: string
  proof?: VRFProof
  status: "pending" | "fulfilled" | "expired" | "failed"
  useCase: string
}

export type UseCaseId = "gaming" | "nft-traits" | "lottery" | "leader-selection"

export interface UseCase {
  id: UseCaseId
  label: string
  description: string
}

export const USE_CASES: UseCase[] = [
  { id: "gaming", label: "Gaming", description: "Fair dice rolls, card shuffles, game outcomes" },
  { id: "nft-traits", label: "NFT Trait Generation", description: "Provably fair NFT attribute assignment" },
  { id: "lottery", label: "Lottery", description: "Transparent lottery draws with verifiable results" },
  { id: "leader-selection", label: "Leader Selection", description: "Fair validator or committee selection" },
]

export const DEFAULT_ENTROPY_SOURCES: EntropySource[] = [
  { name: "blockhash", weight: 30, active: true },
  { name: "timestamp", weight: 20, active: true },
  { name: "chainlink", weight: 30, active: true },
  { name: "drand", weight: 20, active: true },
]

const now = Date.now()

export const DEFAULT_REQUESTS: VRFRequest[] = [
  {
    requestId: "1",
    requester: "0x742d35Cc6634C0532925a3b844Bc9e7595f2bD38",
    seed: "0xa1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2",
    commitment: "0x4f8a3c1e9d7b5a2f6c8e0d4b7a3f1e5c9d2b8a6f4e0c7d3b9a5f1e8c4d2b7a6f",
    blockNumber: 19847550,
    timestamp: now - 3600000,
    fulfilled: true,
    randomness: "0xb7e3f1a9c5d2e8b4a6f0c7d3e9b1a5f8c2d6e4b8a0f7c3d1e9b5a2f6c8d4e0b3",
    proof: {
      proofId: "proof_1_1718000000000",
      requestId: "1",
      journal: "0xe4b2a8f7c3d1e9b5a6f0c2d8e4b7a3f1c9d5e8b2a6f4c0d7e3b9a1f5c8d2e6b4a7f0c3d1e9b5a2f8c4d6",
      seal: "0xa1f3c5e7b9d1a3f5c7e9b1d3a5f7c9e1b3d5a7f9c1e3b5d7a9f1c3e5b7d9a1f3c5e7b9d1a3f5c7e9b1d3a5f7c9e1b3d5a7f9c1e3b5d7a9f1c3e5b7d9a1f3",
      imageId: "0x7e2a5c1d8f4b3a9e6d0c7f5b8a2e1d4c9b7f3a6e0d8c5b2f9a4e7d1c3b8f6a2",
      entropySources: [
        { name: "blockhash", weight: 30, active: true, value: "0xf4a2b7c3", lastUpdated: now - 3500000 },
        { name: "timestamp", weight: 20, active: true, value: "0xe1b9d3a7", lastUpdated: now - 3500000 },
        { name: "chainlink", weight: 30, active: true, value: "0xc5f8a2d6", lastUpdated: now - 3500000 },
        { name: "drand", weight: 20, active: true, value: "0xb3e7c1f9", lastUpdated: now - 3500000 },
      ],
      combinedRandomness: "0xb7e3f1a9c5d2e8b4a6f0c7d3e9b1a5f8c2d6e4b8a0f7c3d1e9b5a2f6c8d4e0b3",
      verified: true,
      verifiedAt: now - 3400000,
    },
    status: "fulfilled",
    useCase: "gaming",
  },
  {
    requestId: "2",
    requester: "0x8Ba1f955b6fA5c4b7d3E2a1F8c9B4d6E7f0A2b3C",
    seed: "0xd4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5",
    commitment: "0x7a2f9c4b8e1d5a3f7c9b2e6a4d8f0c5b7a3e1d9f5c2b8a6e4d0f7c3b9a5e1d8f",
    blockNumber: 19847555,
    timestamp: now - 1800000,
    fulfilled: true,
    randomness: "0xa3f7c1e5b9d2a6f0c8b4e7a1d5f3c9b2e6a8d0f4c7b1a5e9d3f6c2b8a4e0d7f1",
    proof: {
      proofId: "proof_2_1718005000000",
      requestId: "2",
      journal: "0xc1d3e5a7b9f2c4d6e8a0b2f4d6a8c0e2f4a6b8c0d2e4f6a8b0c2d4e6f8a0b2c4d6e8f0a2b4c6d8",
      seal: "0xf1e3d5c7b9a1f3e5d7c9b1a3d5f7e9c1b3a5d7f9e1c3b5a7d9f1e3c5b7a9d1f3e5c7b9a1d3f5e7c9b1a3d5f7e9c1b3a5d7f9e1c3b5a7d9f1e3c5b7a9d1f",
      imageId: "0x7e2a5c1d8f4b3a9e6d0c7f5b8a2e1d4c9b7f3a6e0d8c5b2f9a4e7d1c3b8f6a2",
      entropySources: [
        { name: "blockhash", weight: 30, active: true, value: "0xa7c3f1b5", lastUpdated: now - 1700000 },
        { name: "timestamp", weight: 20, active: true, value: "0xd9e2b4a6", lastUpdated: now - 1700000 },
        { name: "chainlink", weight: 30, active: true, value: "0xf0c8a2d4", lastUpdated: now - 1700000 },
        { name: "drand", weight: 20, active: true, value: "0x1b5e9c3f", lastUpdated: now - 1700000 },
      ],
      combinedRandomness: "0xa3f7c1e5b9d2a6f0c8b4e7a1d5f3c9b2e6a8d0f4c7b1a5e9d3f6c2b8a4e0d7f1",
      verified: true,
      verifiedAt: now - 1600000,
    },
    status: "fulfilled",
    useCase: "nft-traits",
  },
  {
    requestId: "3",
    requester: "0x1a2B3c4D5e6F7890AbCdEf1234567890aBcDeF12",
    seed: "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
    commitment: "0x2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3",
    blockNumber: 19847558,
    timestamp: now - 900000,
    fulfilled: true,
    randomness: "0xc4e8a2f6b0d3c7a1e5f9b3d7a1c5e9f2b6d0a4c8e1f5b9d3a7c0e4f8b2d6a1c5",
    proof: {
      proofId: "proof_3_1718008000000",
      requestId: "3",
      journal: "0x1a3b5c7d9e0f2a4b6c8d0e2f4a6b8c0d2e4f6a8b0c2d4e6f8a0b2c4d6e8f0a2b4c6d8e0f2a4b6",
      seal: "0x3a5c7e9b1d3f5a7c9e1b3d5f7a9c1e3b5d7f9a1c3e5b7d9f1a3c5e7b9d1f3a5c7e9b1d3f5a7c9e1b3d5f7a9c1e3b5d7f9a1c3e5b7d9f1a3c5e7b9d1f3a",
      imageId: "0x7e2a5c1d8f4b3a9e6d0c7f5b8a2e1d4c9b7f3a6e0d8c5b2f9a4e7d1c3b8f6a2",
      entropySources: [
        { name: "blockhash", weight: 30, active: true, value: "0xb1d4f7a2", lastUpdated: now - 800000 },
        { name: "timestamp", weight: 20, active: true, value: "0xc5e8a3d6", lastUpdated: now - 800000 },
        { name: "chainlink", weight: 30, active: true, value: "0xd7f0b4c9", lastUpdated: now - 800000 },
        { name: "drand", weight: 20, active: true, value: "0xe2a6f1b8", lastUpdated: now - 800000 },
      ],
      combinedRandomness: "0xc4e8a2f6b0d3c7a1e5f9b3d7a1c5e9f2b6d0a4c8e1f5b9d3a7c0e4f8b2d6a1c5",
      verified: true,
      verifiedAt: now - 750000,
    },
    status: "fulfilled",
    useCase: "lottery",
  },
  {
    requestId: "4",
    requester: "0xFeDcBa9876543210fEdCbA9876543210FeDcBa98",
    seed: "0xfedcba9876543210fedcba9876543210fedcba9876543210fedcba9876543210",
    commitment: "0x5e6d7c8b9a0f1e2d3c4b5a6f7e8d9c0b1a2f3e4d5c6b7a8f9e0d1c2b3a4f5e6",
    blockNumber: 19847561,
    timestamp: now - 120000,
    fulfilled: false,
    status: "pending",
    useCase: "leader-selection",
  },
  {
    requestId: "5",
    requester: "0xAb12Cd34Ef56Ab78Cd90Ef12Ab34Cd56Ef78Ab90",
    seed: "0xabcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789",
    commitment: "0x9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4d3e2f1a0b9c8d7e6f5a4b3c2d1e0f9a8",
    blockNumber: 19847540,
    timestamp: now - 7200000,
    fulfilled: false,
    status: "expired",
    useCase: "gaming",
  },
]
