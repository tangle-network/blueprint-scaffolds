import { useState, useCallback, useEffect } from "react";
import type {
  VRFRequest,
  EntropySourceConfig,
  CommitRevealPhase,
  DashboardStats,
  VRFConfig,
} from "./types";
import { DEFAULT_ENTROPY_SOURCES } from "./types";
import {
  fetchRequests,
  fetchDashboardStats,
  fetchConfig,
  submitVRFRequest,
  simulateCommitReveal,
  verifyProofOnChain,
  fetchProof,
} from "./vrf";
import type { ZKProof } from "./types";

interface VRFState {
  requests: VRFRequest[];
  currentRequest: VRFRequest | null;
  phase: CommitRevealPhase;
  entropySources: EntropySourceConfig[];
  config: VRFConfig | null;
  stats: DashboardStats | null;
  isLoading: boolean;
  error: string | null;
}

export function useVRF() {
  const [state, setState] = useState<VRFState>({
    requests: [],
    currentRequest: null,
    phase: { phase: "idle" },
    entropySources: [...DEFAULT_ENTROPY_SOURCES],
    config: null,
    stats: null,
    isLoading: false,
    error: null,
  });

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setState((prev) => ({ ...prev, isLoading: true }));
      try {
        const [requests, config, stats] = await Promise.all([
          fetchRequests(),
          fetchConfig(),
          fetchDashboardStats(),
        ]);
        if (!cancelled) {
          setState((prev) => ({
            ...prev,
            requests,
            config,
            stats,
            isLoading: false,
          }));
        }
      } catch (err) {
        if (!cancelled) {
          setState((prev) => ({
            ...prev,
            isLoading: false,
            error: err instanceof Error ? err.message : "Failed to load data",
          }));
        }
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, []);

  const setPhase = useCallback((phase: CommitRevealPhase) => {
    setState((prev) => ({ ...prev, phase }));
  }, []);

  const requestRandomness = useCallback(
    async (
      seed: string,
      requester: string = "0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045"
    ) => {
      setState((prev) => ({ ...prev, isLoading: true, error: null }));
      setPhase({ phase: "committing", timestamp: Date.now() });

      try {
        const request = await submitVRFRequest({
          seed,
          requester,
          entropySources: state.entropySources,
          gasLimit: state.config?.maxGasLimit ?? 500000,
          callbackGasLimit: state.config?.defaultCallbackGas ?? 100000,
          feeToken: "ETH",
        });

        setPhase({
          phase: "committed",
          commitHash: request.commitHash ?? undefined,
          timestamp: Date.now(),
        });

        setState((prev) => ({
          ...prev,
          requests: [request, ...prev.requests],
          currentRequest: request,
        }));

        setPhase({
          phase: "revealing",
          commitHash: request.commitHash ?? undefined,
          timestamp: Date.now(),
        });

        const fulfilled = await simulateCommitReveal(request.id);

        setPhase({
          phase: "revealed",
          commitHash: fulfilled.commitHash ?? undefined,
          revealValue: fulfilled.revealValue ?? undefined,
          timestamp: Date.now(),
        });

        setState((prev) => ({
          ...prev,
          requests: prev.requests.map((r) =>
            r.id === fulfilled.id ? fulfilled : r
          ),
          currentRequest: fulfilled,
          isLoading: false,
        }));

        return fulfilled;
      } catch (err) {
        const message = err instanceof Error ? err.message : "Unknown error";
        setState((prev) => ({ ...prev, isLoading: false, error: message }));
        setPhase({ phase: "idle" });
        throw err;
      }
    },
    [state.entropySources, state.config, setPhase]
  );

  const toggleEntropySource = useCallback((type: string) => {
    setState((prev) => ({
      ...prev,
      entropySources: prev.entropySources.map((s) =>
        s.type === type ? { ...s, enabled: !s.enabled } : s
      ),
    }));
  }, []);

  const setEntropyWeight = useCallback((type: string, weight: number) => {
    setState((prev) => ({
      ...prev,
      entropySources: prev.entropySources.map((s) =>
        s.type === type ? { ...s, weight } : s
      ),
    }));
  }, []);

  const verifyProof = useCallback(
    async (proofHash: string) => {
      const result = await verifyProofOnChain(proofHash);
      return result;
    },
    []
  );

  const getProof = useCallback(async (proofHash: string): Promise<ZKProof | null> => {
    return fetchProof(proofHash);
  }, []);

  const clearHistory = useCallback(() => {
    setState((prev) => ({
      ...prev,
      requests: prev.requests.filter(
        (r) => r.status === "pending" || r.status === "committed" || r.status === "revealing"
      ),
      currentRequest: null,
    }));
  }, []);

  return {
    ...state,
    requestRandomness,
    toggleEntropySource,
    setEntropyWeight,
    verifyProof,
    getProof,
    clearHistory,
  };
}

export function useBlockNumber() {
  const [blockNumber, setBlockNumber] = useState(19_847_562);

  useEffect(() => {
    const interval = setInterval(() => {
      setBlockNumber((prev) => prev + 1);
    }, 12000);
    return () => clearInterval(interval);
  }, []);

  return blockNumber;
}
