import { useState, useCallback, useRef, useEffect } from "react"
import {
  type VRFRequest,
  type VRFProof,
  type EntropySource,
  type CommitRevealPhase,
  DEFAULT_ENTROPY_SOURCES,
  generateCommitment,
  generateMockRandomness,
  generateMockProof,
  simulateFrontRunningProtection,
  type UseCaseId,
} from "./vrf"

interface VRFState {
  requests: VRFRequest[]
  currentRequest: VRFRequest | null
  phase: CommitRevealPhase
  entropySources: EntropySource[]
  isLoading: boolean
  error: string | null
}

const STORAGE_KEY = "vrf-requests"

function loadRequests(): VRFRequest[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY)
    return stored ? JSON.parse(stored) : []
  } catch {
    return []
  }
}

function saveRequests(requests: VRFRequest[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(requests))
}

export function useVRF() {
  const [state, setState] = useState<VRFState>({
    requests: loadRequests(),
    currentRequest: null,
    phase: { phase: "idle" },
    entropySources: DEFAULT_ENTROPY_SOURCES,
    isLoading: false,
    error: null,
  })

  const nextId = useRef(
    state.requests.length > 0
      ? Math.max(...state.requests.map((r) => parseInt(r.requestId))) + 1
      : 1
  )

  const setPhase = useCallback((phase: CommitRevealPhase) => {
    setState((prev) => ({ ...prev, phase }))
  }, [])

  const requestRandomness = useCallback(
    async (seed: string, useCase: UseCaseId, requester: string = "0x742d35Cc6634C0532925a3b844Bc9e7595f2bD38") => {
      setState((prev) => ({ ...prev, isLoading: true, error: null }))
      setPhase({ phase: "committing", timestamp: Date.now() })

      try {
        const { commitment, revealValue } = await generateCommitment(seed, requester)

        setPhase({
          phase: "committed",
          commitment,
          revealValue,
          timestamp: Date.now(),
        })

        const requestId = (nextId.current++).toString()
        const now = Date.now()

        const request: VRFRequest = {
          requestId,
          requester,
          seed,
          commitment,
          blockNumber: Math.floor(now / 12000),
          timestamp: now,
          fulfilled: false,
          status: "pending",
          useCase,
        }

        setState((prev) => {
          const updated = [request, ...prev.requests]
          saveRequests(updated)
          return { ...prev, requests: updated, currentRequest: request }
        })

        await new Promise((resolve) => setTimeout(resolve, 1500 + Math.random() * 2000))

        setPhase({ phase: "revealing", commitment, revealValue, timestamp: Date.now() })

        await new Promise((resolve) => setTimeout(resolve, 1000))

        const randomness = await generateMockRandomness(seed, commitment, state.entropySources)
        const proof = generateMockProof(requestId, randomness, state.entropySources)
        const protection = simulateFrontRunningProtection(commitment, request.blockNumber, request.blockNumber + 5)

        const fulfilledRequest: VRFRequest = {
          ...request,
          fulfilled: true,
          randomness,
          proof,
          status: protection.safe ? "fulfilled" : "failed",
        }

        setState((prev) => {
          const updated = prev.requests.map((r) =>
            r.requestId === requestId ? fulfilledRequest : r
          )
          saveRequests(updated)
          return { ...prev, requests: updated, currentRequest: fulfilledRequest, isLoading: false }
        })

        setPhase({
          phase: "revealed",
          commitment,
          revealValue,
          timestamp: Date.now(),
        })

        return fulfilledRequest
      } catch (err) {
        const message = err instanceof Error ? err.message : "Unknown error"
        setState((prev) => ({ ...prev, isLoading: false, error: message }))
        setPhase({ phase: "idle" })
        throw err
      }
    },
    [state.entropySources, setPhase]
  )

  const toggleEntropySource = useCallback((name: string) => {
    setState((prev) => ({
      ...prev,
      entropySources: prev.entropySources.map((s) =>
        s.name === name ? { ...s, active: !s.active } : s
      ),
    }))
  }, [])

  const setEntropyWeight = useCallback((name: string, weight: number) => {
    setState((prev) => ({
      ...prev,
      entropySources: prev.entropySources.map((s) =>
        s.name === name ? { ...s, weight } : s
      ),
    }))
  }, [])

  const clearHistory = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY)
    setState((prev) => ({ ...prev, requests: [], currentRequest: null }))
  }, [])

  const verifyProof = useCallback((proof: VRFProof): boolean => {
    return proof.verified && !!proof.seal && !!proof.journal && !!proof.imageId
  }, [])

  return {
    ...state,
    requestRandomness,
    toggleEntropySource,
    setEntropyWeight,
    clearHistory,
    verifyProof,
  }
}

export function useBlockNumber() {
  const [blockNumber, setBlockNumber] = useState(0)

  useEffect(() => {
    const base = Math.floor(Date.now() / 12000)
    setBlockNumber(base)
    const interval = setInterval(() => {
      setBlockNumber((prev) => prev + 1)
    }, 12000)
    return () => clearInterval(interval)
  }, [])

  return blockNumber
}
