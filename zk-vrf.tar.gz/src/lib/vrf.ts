import { EntropySource } from './types';

export function combineEntropy(sources: EntropySource[]): string {
  const totalWeight = sources.reduce((sum, s) => sum + s.weight, 0);
  const combined = sources.map((s) => {
    const scaled = BigInt('0x' + s.value) * BigInt(s.weight);
    return (scaled / BigInt(totalWeight)).toString(16).padStart(64, '0');
  });
  return combined.join('');
}

export function simulateCommit(seed: string, nonce: string): string {
  const data = seed + nonce;
  let hash = 0n;
  for (let i = 0; i < data.length; i++) {
    const char = BigInt(data.charCodeAt(i));
    hash = ((hash << 5n) - hash + char) & BigInt('0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF');
    hash = ((hash >> 3n) ^ hash) * BigInt('0x27d4eb2d');
    hash = hash & BigInt('0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF');
  }
  return hash.toString(16).padStart(64, '0');
}

export function simulateReveal(commitHash: string, combinedEntropy: string): string {
  const data = commitHash + combinedEntropy;
  let hash = 0n;
  for (let i = 0; i < data.length; i++) {
    const char = BigInt(data.charCodeAt(i));
    hash = ((hash << 7n) - hash + char) * BigInt('0x5bd1e995');
    hash = hash & BigInt('0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF');
  }
  return hash.toString(16).padStart(64, '0');
}

export function generateProofInput(commitHash: string, seed: string, nonce: string, entropy: string): string {
  return [
    'RISC0_VRF_PROOF_V1',
    `commit:${commitHash}`,
    `seed:${seed}`,
    `nonce:${nonce}`,
    `entropy:${entropy}`,
    `journal:${commitHash.substring(0, 16)}...${entropy.substring(0, 16)}`,
    'image_id:risc0-vrf-guest-v1.0.0',
  ].join('\n');
}

export function generateRandomWords(revealValue: string, numWords: number): string[] {
  const words: string[] = [];
  for (let i = 0; i < numWords; i++) {
    const segment = revealValue.slice(
      (i * 8) % revealValue.length,
      ((i * 8) % revealValue.length) + 64,
    ) || revealValue.substring(0, 64);
    let hash = BigInt('0x' + revealValue) + BigInt(i) * BigInt('0x9e3779b97f4a7c15');
    hash = ((hash ^ (hash >> 30n)) * BigInt('0xbf58476d1ce4e5b9')) & BigInt('0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF');
    hash = ((hash ^ (hash >> 27n)) * BigInt('0x94d049bb133111eb')) & BigInt('0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF');
    hash = hash ^ (hash >> 31n);
    words.push(hash.toString(16).padStart(64, '0'));
  }
  return words;
}

export function simulateZKProof(
  commitHash: string,
  seed: string,
  nonce: string,
  entropy: string,
): { proof: string; journal: string } {
  const reveal = simulateReveal(commitHash, entropy);
  const proofBody = [
    'risc0_receipt',
    `version:1.0`,
    `method:vrf_commit_reveal`,
    `seal:${commitHash.slice(0, 32)}${reveal.slice(0, 32)}`,
    `claims:{"commit":"${commitHash}","seed":"${seed}","nonce":"${nonce}"}`,
  ].join('|');

  const proofHash = Array.from(proofBody).reduce((acc, char) => {
    const h = BigInt(acc.charCodeAt(0) ^ char.charCodeAt(0));
    return h.toString(16).padStart(2, '0');
  }, '00');

  return {
    proof: `0x${proofBody}${proofHash}`,
    journal: JSON.stringify({
      commit: commitHash,
      reveal,
      seed,
      nonce,
      entropy_sources: entropy,
      timestamp: Date.now(),
    }),
  };
}
