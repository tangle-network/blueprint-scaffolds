export interface EntropySource {
  name: string
  weight: number
  active: boolean
  value?: string
  lastUpdated?: number
}

export interface CommitRevealPhase {
  phase: "idle" | "committing" | "committed" | "revealing" | "revealed"
  commitment?: string
  revealValue?: string
  timestamp?: number
}

export interface VRFProof {
  proofId: string
  requestId: string
  journal: string
  seal: string
  imageId: string
  entropySources: EntropySource[]
  combinedRandomness: string
  verified: boolean
  verifiedAt?: number
}

export interface VRFRequest {
  requestId: string
  requester: string
  seed: string
  commitment: string
  blockNumber: number
  timestamp: number
  fulfilled: boolean
  randomness?: string
  proof?: VRFProof
  status: "pending" | "fulfilled" | "expired" | "failed"
  useCase: string
}

export const DEFAULT_ENTROPY_SOURCES: EntropySource[] = [
  { name: "blockhash", weight: 30, active: true },
  { name: "timestamp", weight: 20, active: true },
  { name: "chainlink", weight: 30, active: true },
  { name: "drand", weight: 20, active: true },
]

function hexToBytes(hex: string): Uint8Array {
  const clean = hex.startsWith("0x") ? hex.slice(2) : hex
  const bytes = new Uint8Array(clean.length / 2)
  for (let i = 0; i < clean.length; i += 2) {
    bytes[i / 2] = parseInt(clean.substring(i, i + 2), 16)
  }
  return bytes
}

async function sha256(data: Uint8Array): Promise<string> {
  const hash = await crypto.subtle.digest("SHA-256", data.buffer as ArrayBuffer)
  return Array.from(new Uint8Array(hash))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("")
}

export async function generateCommitment(
  seed: string,
  requester: string,
  nonce?: string
): Promise<{ commitment: string; revealValue: string }> {
  const revealValue = nonce || Array.from(crypto.getRandomValues(new Uint8Array(32)))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("")

  const encoded = new TextEncoder().encode(
    JSON.stringify({ seed, requester, revealValue, timestamp: Date.now() })
  )
  const commitment = await sha256(encoded)
  return { commitment: `0x${commitment}`, revealValue }
}

export function combineEntropySources(
  sources: EntropySource[],
  values: Record<string, string>
): string {
  const combined = sources
    .filter((s) => s.active && values[s.name])
    .sort((a, b) => a.name.localeCompare(b.name))
    .map((s) => `${s.name}:${values[s.name]}:${s.weight}`)
    .join("|")
  return combined
}

export async function generateMockRandomness(
  seed: string,
  commitment: string,
  sources: EntropySource[]
): Promise<string> {
  const sourceValues: Record<string, string> = {}
  for (const s of sources) {
    if (s.active) {
      const raw = Array.from(crypto.getRandomValues(new Uint8Array(32)))
        .map((b) => b.toString(16).padStart(2, "0"))
        .join("")
      sourceValues[s.name] = raw
    }
  }
  const combined = combineEntropySources(sources, sourceValues)
  const encoded = new TextEncoder().encode(seed + commitment + combined)
  const hash = await sha256(encoded)
  return `0x${hash}`
}

export function generateMockProof(
  requestId: string,
  randomness: string,
  sources: EntropySource[]
): VRFProof {
  return {
    proofId: `proof_${requestId}_${Date.now()}`,
    requestId,
    journal: `0x${Array.from(crypto.getRandomValues(new Uint8Array(64)))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("")}`,
    seal: `0x${Array.from(crypto.getRandomValues(new Uint8Array(96)))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("")}`,
    imageId: "0x7e2a5c1d8f4b3a9e6d0c7f5b8a2e1d4c9b7f3a6e0d8c5b2f9a4e7d1c3b8f6a2",
    entropySources: sources.map((s) => ({
      ...s,
      value: Array.from(crypto.getRandomValues(new Uint8Array(8)))
        .map((b) => b.toString(16).padStart(2, "0"))
        .join(""),
      lastUpdated: Date.now(),
    })),
    combinedRandomness: randomness,
    verified: true,
    verifiedAt: Date.now(),
  }
}

export function expandRandomness(randomness: string, count: number): string[] {
  const results: string[] = []
  const base = randomness.startsWith("0x") ? randomness : `0x${randomness}`
  for (let i = 0; i < count; i++) {
    const input = base + i.toString(16).padStart(8, "0")
    let hash = 0
    for (let j = 0; j < input.length; j++) {
      const chr = input.charCodeAt(j)
      hash = ((hash << 5) - hash + chr) | 0
    }
    results.push(`0x${Math.abs(hash).toString(16).padStart(16, "0")}`)
  }
  return results
}

export function mapRandomnessToRange(randomness: string, min: number, max: number): number {
  const hex = randomness.startsWith("0x") ? randomness.slice(2) : randomness
  const value = parseInt(hex.substring(0, 8), 16)
  return min + (value % (max - min + 1))
}

export function simulateFrontRunningProtection(
  commitment: string,
  blockNumber: number,
  currentBlock: number
): { safe: boolean; delayBlocks: number; reason: string } {
  const delayBlocks = currentBlock - blockNumber
  if (delayBlocks < 3) {
    return { safe: false, delayBlocks, reason: "Insufficient block delay for front-running protection" }
  }
  if (delayBlocks > 100) {
    return { safe: false, delayBlocks, reason: "Commitment expired - too many blocks passed" }
  }
  return { safe: true, delayBlocks, reason: "Commitment is within safe window" }
}

export const USE_CASES = [
  { id: "gaming", label: "Gaming", description: "Fair dice rolls, card shuffles, game outcomes" },
  { id: "nft-traits", label: "NFT Trait Generation", description: "Provably fair NFT attribute assignment" },
  { id: "lottery", label: "Lottery", description: "Transparent lottery draws with verifiable results" },
  { id: "leader-selection", label: "Leader Selection", description: "Fair validator or committee selection" },
] as const

export type UseCaseId = (typeof USE_CASES)[number]["id"]
