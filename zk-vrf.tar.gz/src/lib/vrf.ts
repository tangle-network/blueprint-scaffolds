interface VRFRequest {
  id: string;
  requester: string;
  seed: string;
  entropySources: EntropySourceConfig[];
  status: "pending" | "committed" | "revealing" | "fulfilled" | "expired" | "failed";
  commitHash: string;
  revealValue: string | null;
  randomValue: string | null;
  proofHash: string | null;
  gasLimit: number;
  callbackGasLimit: number;
  fee: string;
  createdAt: string;
  fulfilledAt: string | null;
  blockNumber: number | null;
}

interface VRFConfig {
  minFee: string;
  maxFee: string;
  gasLimit: number;
  callbackGasLimit: number;
  verifierAddress: string;
  verifierName: string;
}

interface ZKProof {
  proofId: string;
  journal: string;
  seal: string;
  imageId: string;
  verified: boolean;
  verifiedAt: string;
}

interface DashboardStats {
  totalRequests: number;
  fulfilledRequests: number;
  pendingRequests: number;
  avgFulfillmentTime: string;
  totalFeesEarned: string;
  uniqueConsumers: number;
}

interface EntropySourceConfig {
  name: string;
  weight: number;
  active: boolean;
  value?: string;
  lastUpdated?: number;
}

const DEFAULT_CONFIG: VRFConfig = {
  minFee: "0.001",
  maxFee: "0.01",
  gasLimit: 300000,
  callbackGasLimit: 100000,
  verifierAddress: "0x7e2a5c1d8f4b3a9e6d0c7f5b8a2e1d4c9b7f3a6e0d8c5b2f9a4e7d1c3b8f6a2",
  verifierName: "RISC-Zero VRF Verifier",
};

const DEFAULT_ENTROPY_SOURCES: EntropySourceConfig[] = [
  { name: "blockhash", weight: 30, active: true },
  { name: "timestamp", weight: 20, active: true },
  { name: "chainlink", weight: 30, active: true },
  { name: "drand", weight: 20, active: true },
];

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function randomHex(length: number): string {
  const chars = "0123456789abcdef";
  let result = "0x";
  for (let i = 0; i < length; i++)
    result += chars[Math.floor(Math.random() * chars.length)];
  return result;
}

const mockRequests: VRFRequest[] = [
  {
    id: "0x10000001",
    requester: "0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045",
    seed: "0xdeadbeef",
    entropySources: [...DEFAULT_ENTROPY_SOURCES],
    status: "fulfilled",
    commitHash: randomHex(64),
    revealValue: randomHex(32),
    randomValue:
      "0xa1b2c3d4e5f6789012345678901234567890abcdef1234567890abcdef123456",
    proofHash: randomHex(64),
    gasLimit: 300000,
    callbackGasLimit: 100000,
    fee: "0.001",
    createdAt: "2024-12-15T10:30:00Z",
    fulfilledAt: "2024-12-15T10:30:12Z",
    blockNumber: 12345678,
  },
  {
    id: "0x10000002",
    requester: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
    seed: "0xcafebabe",
    entropySources: DEFAULT_ENTROPY_SOURCES.slice(0, 3),
    status: "pending",
    commitHash: randomHex(64),
    revealValue: null,
    randomValue: null,
    proofHash: null,
    gasLimit: 250000,
    callbackGasLimit: 80000,
    fee: "0.001",
    createdAt: "2024-12-15T11:00:00Z",
    fulfilledAt: null,
    blockNumber: null,
  },
  {
    id: "0x10000003",
    requester: "0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045",
    seed: "0x12345678",
    entropySources: DEFAULT_ENTROPY_SOURCES.slice(0, 2),
    status: "committed",
    commitHash: randomHex(64),
    revealValue: null,
    randomValue: null,
    proofHash: null,
    gasLimit: 200000,
    callbackGasLimit: 100000,
    fee: "0.002",
    createdAt: "2024-12-15T11:15:00Z",
    fulfilledAt: null,
    blockNumber: 12345690,
  },
  {
    id: "0x10000004",
    requester: "0xFeDcBa9876543210fEdCbA9876543210FeDcBa98",
    seed: "0xabcdef01",
    entropySources: DEFAULT_ENTROPY_SOURCES.slice(0, 3),
    status: "fulfilled",
    commitHash: randomHex(64),
    revealValue: randomHex(32),
    randomValue:
      "0x9876abcd5432ef019876abcd5432ef019876abcd5432ef019876abcd5432ef01",
    proofHash: randomHex(64),
    gasLimit: 350000,
    callbackGasLimit: 120000,
    fee: "0.0015",
    createdAt: "2024-12-15T09:00:00Z",
    fulfilledAt: "2024-12-15T09:00:18Z",
    blockNumber: 12345600,
  },
  {
    id: "0x10000005",
    requester: "0xAb12Cd34Ef56Ab78Cd90Ef12Ab34Cd56Ef78Ab90",
    seed: "0xfedcba98",
    entropySources: DEFAULT_ENTROPY_SOURCES,
    status: "expired",
    commitHash: randomHex(64),
    revealValue: null,
    randomValue: null,
    proofHash: null,
    gasLimit: 200000,
    callbackGasLimit: 80000,
    fee: "0.001",
    createdAt: "2024-12-14T08:00:00Z",
    fulfilledAt: null,
    blockNumber: 12340000,
  },
  {
    id: "0x10000006",
    requester: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
    seed: "0x5678abcd",
    entropySources: DEFAULT_ENTROPY_SOURCES.slice(0, 2),
    status: "failed",
    commitHash: randomHex(64),
    revealValue: null,
    randomValue: null,
    proofHash: null,
    gasLimit: 500000,
    callbackGasLimit: 100000,
    fee: "0.001",
    createdAt: "2024-12-14T14:30:00Z",
    fulfilledAt: null,
    blockNumber: 12342000,
  },
  {
    id: "0x10000007",
    requester: "0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045",
    seed: "0xaaaabbbb",
    entropySources: DEFAULT_ENTROPY_SOURCES,
    status: "revealing",
    commitHash: randomHex(64),
    revealValue: randomHex(32),
    randomValue: null,
    proofHash: null,
    gasLimit: 300000,
    callbackGasLimit: 100000,
    fee: "0.001",
    createdAt: "2024-12-15T11:45:00Z",
    fulfilledAt: null,
    blockNumber: 12345700,
  },
];

export async function fetchRequests(): Promise<VRFRequest[]> {
  await delay(400 + Math.random() * 300);
  return [...mockRequests];
}

export async function fetchRequest(id: string): Promise<VRFRequest | null> {
  await delay(200 + Math.random() * 200);
  return mockRequests.find((r) => r.id === id) ?? null;
}

export async function fetchConfig(): Promise<VRFConfig> {
  await delay(300);
  return { ...DEFAULT_CONFIG };
}

export async function fetchDashboardStats(): Promise<DashboardStats> {
  await delay(500);
  return {
    totalRequests: 1247,
    fulfilledRequests: 1189,
    pendingRequests: 23,
    avgFulfillmentTime: "2.4s",
    totalFeesEarned: "1.247 ETH",
    uniqueConsumers: 89,
  };
}

export async function fetchProof(proofHash: string): Promise<ZKProof | null> {
  await delay(600 + Math.random() * 400);
  if (!proofHash || proofHash === "null") return null;
  return {
    proofId: `proof_${Date.now()}`,
    journal: randomHex(128),
    seal: randomHex(192),
    imageId: DEFAULT_CONFIG.verifierAddress,
    verified: true,
    verifiedAt: new Date().toISOString(),
  };
}

export async function submitVRFRequest(params: {
  seed: string;
  requester: string;
  entropySources: EntropySourceConfig[];
  gasLimit: number;
  callbackGasLimit: number;
  feeToken: string;
}): Promise<VRFRequest> {
  await delay(800 + Math.random() * 600);

  const commitHash = randomHex(64);
  const id = `0x${(Date.now()).toString(16)}`;

  const request: VRFRequest = {
    id,
    requester: params.requester,
    seed: params.seed,
    entropySources: [...params.entropySources],
    status: "pending",
    commitHash,
    revealValue: null,
    randomValue: null,
    proofHash: null,
    gasLimit: params.gasLimit,
    callbackGasLimit: params.callbackGasLimit,
    fee: DEFAULT_CONFIG.minFee,
    createdAt: new Date().toISOString(),
    fulfilledAt: null,
    blockNumber: Math.floor(Date.now() / 12000),
  };

  mockRequests.unshift(request);
  return request;
}

export async function simulateCommitReveal(
  requestId: string
): Promise<VRFRequest> {
  await delay(1500 + Math.random() * 1000);

  const idx = mockRequests.findIndex((r) => r.id === requestId);
  if (idx === -1) throw new Error("Request not found");

  const revealValue = randomHex(32);
  mockRequests[idx] = {
    ...mockRequests[idx],
    status: "committed",
    revealValue,
  };

  await delay(1000 + Math.random() * 500);

  const randomValue = randomHex(64);
  const proofHash = randomHex(64);

  mockRequests[idx] = {
    ...mockRequests[idx],
    status: "fulfilled",
    randomValue,
    proofHash,
    fulfilledAt: new Date().toISOString(),
    blockNumber: (mockRequests[idx].blockNumber ?? 0) + 5,
  };

  return { ...mockRequests[idx] };
}

export async function verifyProofOnChain(
  proofHash: string
): Promise<{ valid: boolean; details: string }> {
  await delay(700 + Math.random() * 500);
  const found = mockRequests.find((r) => r.proofHash === proofHash);
  if (!found) {
    return {
      valid: false,
      details:
        "No matching proof found. Ensure the proof hash or request ID is correct.",
    };
  }
  return {
    valid: found.status === "fulfilled",
    details:
      found.status === "fulfilled"
        ? `Proof verified for request ${found.id}. Verifier: ${DEFAULT_CONFIG.verifierName}. Seal and journal validated on-chain.`
        : `Request ${found.id} has status "${found.status}" — proof not yet available or invalid.`,
  };
}

export function expandRandomness(randomness: string, count: number): string[] {
  const results: string[] = [];
  const base = randomness.startsWith("0x") ? randomness : `0x${randomness}`;
  for (let i = 0; i < count; i++) {
    const input = base + i.toString(16).padStart(8, "0");
    let hash = 0;
    for (let j = 0; j < input.length; j++) {
      const chr = input.charCodeAt(j);
      hash = ((hash << 5) - hash + chr) | 0;
    }
    results.push(`0x${Math.abs(hash).toString(16).padStart(16, "0")}`);
  }
  return results;
}

export function mapRandomnessToRange(
  randomness: string,
  min: number,
  max: number
): number {
  const hex = randomness.startsWith("0x") ? randomness.slice(2) : randomness;
  const value = parseInt(hex.substring(0, 8), 16);
  return min + (value % (max - min + 1));
}
