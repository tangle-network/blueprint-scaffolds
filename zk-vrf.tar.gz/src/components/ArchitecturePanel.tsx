export default function ArchitecturePanel() {
  return (
    <div className="glass-panel rounded-xl p-6 space-y-5">
      <h2 className="text-lg font-bold text-white">How It Works</h2>

      <div className="space-y-4">
        <Step
          num={1}
          title="Commit"
          desc="User submits a seed. Coordinator generates a commit hash and publishes it on-chain, preventing the prover from manipulating results."
        />
        <Step
          num={2}
          title="Entropy Collection"
          desc="Multiple entropy sources are gathered: block hash, DRAND beacon, RANDAO, requester nonce — weighted and combined with bias resistance."
        />
        <Step
          num={3}
          title="ZK Proof Generation"
          desc="RISC Zero guest circuit computes randomness from commit + entropy, then generates a STARK proof that the computation was correct."
        />
        <Step
          num={4}
          title="On-Chain Verification"
          desc="Groth16/STARK proof is verified on-chain. The coordinator fulfills the request with verified random words, guaranteed by math."
        />
      </div>

      <div className="border-t border-gray-700/50 pt-4 space-y-3">
        <h3 className="text-sm font-semibold text-gray-300">Security Properties</h3>
        <div className="grid grid-cols-2 gap-2">
          <Badge label="Front-Running Protection" detail="Commit before reveal" color="blue" />
          <Badge label="Bias Resistance" detail="Multiple entropy sources" color="purple" />
          <Badge label="Verifiable" detail="ZK proof on-chain" color="green" />
          <Badge label="Tamper-Proof" detail="RISC Zero STARK" color="yellow" />
        </div>
      </div>

      <div className="border-t border-gray-700/50 pt-4">
        <h3 className="text-sm font-semibold text-gray-300 mb-2">VRF Coordinator Contract</h3>
        <pre className="bg-gray-900/80 rounded-lg p-3 text-xs font-mono text-gray-400 overflow-x-auto">
{`contract VRFCoordinator {
  mapping(uint256 => Request) requests;
  uint256 nonce;

  function requestRandomness(
    bytes32 seed,
    uint32 numWords
  ) external returns (uint256 reqId) {
    reqId = ++nonce;
    bytes32 commit = keccak256(
      abi.encode(reqId, seed, block.number)
    );
    requests[reqId] = Request({
      requester: msg.sender,
      commit: commit,
      numWords: numWords,
      fulfilled: false
    });
    emit RandomnessRequested(reqId, commit);
  }

  function fulfillRandomness(
    uint256 reqId,
    bytes32[] calldata randomness,
    bytes calldata proof
  ) external {
    Request storage r = requests[reqId];
    require(!r.fulfilled);
    require(verifyProof(proof, r.commit));
    r.fulfilled = true;
    r.randomness = randomness;
    emit RandomnessFulfilled(reqId, randomness);
  }
}`}
        </pre>
      </div>
    </div>
  );
}

function Step({ num, title, desc }: { num: number; title: string; desc: string }) {
  return (
    <div className="flex gap-3">
      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-vrf-accent/20 flex items-center justify-center text-vrf-accent font-bold text-sm">
        {num}
      </div>
      <div>
        <h3 className="text-sm font-semibold text-white">{title}</h3>
        <p className="text-xs text-gray-400 mt-0.5 leading-relaxed">{desc}</p>
      </div>
    </div>
  );
}

function Badge({ label, detail, color }: { label: string; detail: string; color: string }) {
  const colors: Record<string, string> = {
    blue: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    purple: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
    green: 'bg-green-500/10 text-green-400 border-green-500/20',
    yellow: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
  };
  return (
    <div className={`rounded-lg border px-3 py-2 ${colors[color]}`}>
      <p className="text-xs font-medium">{label}</p>
      <p className="text-[10px] opacity-70">{detail}</p>
    </div>
  );
}
