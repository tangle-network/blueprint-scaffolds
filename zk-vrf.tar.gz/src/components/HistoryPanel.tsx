import { VRFRequest } from '../types';

interface Props {
  requests: VRFRequest[];
  onClear: () => void;
}

export default function HistoryPanel({ requests, onClear }: Props) {
  if (requests.length === 0) {
    return (
      <div className="glass-panel rounded-xl p-8 text-center">
        <div className="text-4xl mb-3">📋</div>
        <p className="text-gray-500 text-sm">No VRF requests yet</p>
        <p className="text-gray-600 text-xs mt-1">Submit a request to see the commit-reveal flow in action</p>
      </div>
    );
  }

  const stats = {
    total: requests.length,
    fulfilled: requests.filter((r) => r.status === 'fulfilled').length,
    pending: requests.filter((r) => r.status !== 'fulfilled' && r.status !== 'failed').length,
    avgLatency:
      requests
        .filter((r) => r.fulfilledAt)
        .reduce((sum, r) => sum + (r.fulfilledAt! - r.createdAt), 0) /
        (requests.filter((r) => r.fulfilledAt).length || 1) /
        1000,
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold text-white">Request History</h2>
        <button
          onClick={onClear}
          className="text-xs text-gray-500 hover:text-red-400 transition-colors"
        >
          Clear All
        </button>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="glass-panel rounded-lg p-3 text-center">
          <p className="text-2xl font-bold text-vrf-accent">{stats.total}</p>
          <p className="text-xs text-gray-500">Total</p>
        </div>
        <div className="glass-panel rounded-lg p-3 text-center">
          <p className="text-2xl font-bold text-green-400">{stats.fulfilled}</p>
          <p className="text-xs text-gray-500">Fulfilled</p>
        </div>
        <div className="glass-panel rounded-lg p-3 text-center">
          <p className="text-2xl font-bold text-yellow-400">{stats.avgLatency.toFixed(1)}s</p>
          <p className="text-xs text-gray-500">Avg Latency</p>
        </div>
      </div>

      <div className="space-y-3 max-h-[600px] overflow-y-auto pr-1">
        {requests.map((req) => (
          <div key={req.id} className="glass-panel rounded-lg p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs text-gray-500">{req.id.slice(0, 20)}...</span>
              <span
                className={`text-xs px-2 py-0.5 rounded-full ${
                  req.status === 'fulfilled'
                    ? 'bg-green-500/20 text-green-400'
                    : req.status === 'failed'
                    ? 'bg-red-500/20 text-red-400'
                    : 'bg-yellow-500/20 text-yellow-400'
                }`}
              >
                {req.status}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-400 capitalize">{req.useCase?.replace('-', ' ')}</span>
              <span className="text-gray-600">{new Date(req.createdAt).toLocaleTimeString()}</span>
            </div>
            {req.randomness && (
              <div className="bg-gray-900/50 rounded p-2">
                <code className="text-green-400 text-[11px] font-mono block truncate">
                  {req.randomness[0]}
                </code>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
