import { useState } from 'react';
import { VRFRequest, UseCase, USE_CASES } from '../types';

interface Props {
  onSubmit: (seed: string, numWords: number, useCase: UseCase) => void;
  loading: boolean;
}

export default function RequestForm({ onSubmit, loading }: Props) {
  const [seed, setSeed] = useState('');
  const [numWords, setNumWords] = useState(1);
  const [useCase, setUseCase] = useState<UseCase>('gaming');

  const handleUseCaseChange = (uc: UseCase) => {
    setUseCase(uc);
    const found = USE_CASES.find((u) => u.value === uc);
    if (found) setNumWords(found.defaultWords);
  };

  const generateRandomSeed = () => {
    const arr = new Uint8Array(32);
    crypto.getRandomValues(arr);
    setSeed(Array.from(arr, (b) => b.toString(16).padStart(2, '0')).join(''));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!seed || loading) return;
    onSubmit(seed, numWords, useCase);
  };

  return (
    <form onSubmit={handleSubmit} className="glass-panel rounded-xl p-6 space-y-5">
      <h2 className="text-xl font-bold text-white flex items-center gap-2">
        <span className="text-2xl">🎲</span> Request Randomness
      </h2>

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-1.5">Use Case</label>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {USE_CASES.map((uc) => (
            <button
              key={uc.value}
              type="button"
              onClick={() => handleUseCaseChange(uc.value)}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                useCase === uc.value
                  ? 'bg-vrf-accent text-white glow-accent'
                  : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
              }`}
            >
              {uc.label}
            </button>
          ))}
        </div>
        <p className="mt-1 text-xs text-gray-500">
          {USE_CASES.find((u) => u.value === useCase)?.description}
        </p>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-1.5">
          Seed
          <button
            type="button"
            onClick={generateRandomSeed}
            className="ml-2 text-vrf-accent hover:text-vrf-accent/80 text-xs"
          >
            Generate Random
          </button>
        </label>
        <input
          type="text"
          value={seed}
          onChange={(e) => setSeed(e.target.value)}
          placeholder="0x... hex seed value"
          className="w-full bg-gray-900 border border-gray-700 rounded-lg px-3 py-2.5 text-sm font-mono text-white placeholder-gray-600 focus:outline-none focus:border-vrf-accent focus:ring-1 focus:ring-vrf-accent"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-1.5">
          Random Words: <span className="text-vrf-accent">{numWords}</span>
        </label>
        <input
          type="range"
          min={1}
          max={10}
          value={numWords}
          onChange={(e) => setNumWords(Number(e.target.value))}
          className="w-full accent-vrf-accent"
        />
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          <span>1</span>
          <span>10</span>
        </div>
      </div>

      <button
        type="submit"
        disabled={loading || !seed}
        className="w-full py-3 rounded-lg font-semibold text-white transition-all disabled:opacity-50 disabled:cursor-not-allowed bg-gradient-to-r from-vrf-accent to-purple-600 hover:from-vrf-accent/90 hover:to-purple-600/90 glow-accent"
      >
        {loading ? 'Processing...' : 'Request VRF Randomness'}
      </button>
    </form>
  );
}
