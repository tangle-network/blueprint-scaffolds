interface Props {
  stage: string;
}

export default function ProgressIndicator({ stage }: Props) {
  if (!stage) return null;

  const steps = [
    { key: 'submit', label: 'Submit' },
    { key: 'commit', label: 'Commit' },
    { key: 'entropy', label: 'Entropy' },
    { key: 'proof', label: 'ZK Proof' },
    { key: 'fulfill', label: 'Fulfill' },
  ];

  const getStepIndex = () => {
    if (stage.includes('Submitting')) return 0;
    if (stage.includes('commit')) return 1;
    if (stage.includes('entropy')) return 2;
    if (stage.includes('proof') || stage.includes('ZK')) return 3;
    if (stage.includes('Verif') || stage.includes('Complete')) return 4;
    return 0;
  };

  const currentIdx = getStepIndex();

  return (
    <div className="glass-panel rounded-xl p-5 space-y-4">
      <div className="flex items-center gap-2">
        <div className="pulse-dot w-2 h-2 rounded-full bg-vrf-accent" />
        <span className="text-sm font-medium text-gray-300">{stage}</span>
      </div>

      <div className="flex items-center gap-1">
        {steps.map((step, i) => (
          <div key={step.key} className="flex-1 flex flex-col items-center gap-1">
            <div
              className={`h-1.5 w-full rounded-full transition-all ${
                i <= currentIdx ? 'bg-vrf-accent' : 'bg-gray-700'
              }`}
            />
            <span
              className={`text-[10px] ${
                i <= currentIdx ? 'text-vrf-accent' : 'text-gray-600'
              }`}
            >
              {step.label}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
