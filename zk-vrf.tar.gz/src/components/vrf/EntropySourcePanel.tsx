import type { EntropySource } from "@/lib/vrf"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Activity, ToggleLeft, ToggleRight } from "lucide-react"

interface EntropySourcePanelProps {
  sources: EntropySource[]
  onToggle: (name: string) => void
  onWeightChange: (name: string, weight: number) => void
}

export default function EntropySourcePanel({
  sources,
  onToggle,
  onWeightChange,
}: EntropySourcePanelProps) {
  const totalWeight = sources.filter((s) => s.active).reduce((sum, s) => sum + s.weight, 0)

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="h-5 w-5 text-primary" />
          Entropy Sources
        </CardTitle>
        <CardDescription>
          Configure entropy sources for bias-resistant randomness combination.
          Active sources are combined with their weights to produce the final randomness.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="rounded-lg bg-muted p-3">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Total Active Weight</span>
            <span className="font-mono font-medium">{totalWeight}</span>
          </div>
        </div>

        {sources.map((source) => (
          <div
            key={source.name}
            className={`rounded-lg border p-4 transition-all ${
              source.active ? "border-primary/30 bg-primary/5" : "border-muted opacity-60"
            }`}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => onToggle(source.name)}
                  className="text-primary hover:text-primary/80"
                >
                  {source.active ? (
                    <ToggleRight className="h-6 w-6" />
                  ) : (
                    <ToggleLeft className="h-6 w-6" />
                  )}
                </button>
                <div>
                  <h4 className="font-medium capitalize">{source.name}</h4>
                  <p className="text-xs text-muted-foreground">
                    {source.name === "blockhash" && "On-chain block hash entropy"}
                    {source.name === "timestamp" && "Block timestamp entropy"}
                    {source.name === "chainlink" && "Chainlink VRF external oracle"}
                    {source.name === "drand" && "drand distributed randomness beacon"}
                  </p>
                </div>
              </div>
              <Badge variant={source.active ? "default" : "secondary"}>
                {source.active ? "Active" : "Inactive"}
              </Badge>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Weight</span>
                <span className="font-mono">{source.weight}</span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                value={source.weight}
                onChange={(e) => onWeightChange(source.name, parseInt(e.target.value))}
                className="w-full h-2 rounded-lg appearance-none cursor-pointer accent-primary"
                disabled={!source.active}
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>0</span>
                <span>50</span>
                <span>100</span>
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
