import { useState } from "react"
import type { VRFProof } from "@/lib/vrf"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ShieldCheck, Copy, ChevronDown, ChevronUp, CheckCircle2 } from "lucide-react"

interface ProofViewerProps {
  proof: VRFProof
}

export default function ProofViewer({ proof }: ProofViewerProps) {
  const [expanded, setExpanded] = useState(false)
  const [copied, setCopied] = useState<string | null>(null)

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text)
    setCopied(id)
    setTimeout(() => setCopied(null), 2000)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ShieldCheck className="h-5 w-5 text-primary" />
          ZK Proof Details
          <Badge variant={proof.verified ? "default" : "destructive"}>
            {proof.verified ? "Verified" : "Unverified"}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="rounded-lg border border-green-500/30 bg-green-500/5 p-3 flex items-center gap-2">
          <CheckCircle2 className="h-5 w-5 text-green-500" />
          <div>
            <p className="text-sm font-medium">Proof verified successfully</p>
            <p className="text-xs text-muted-foreground">
              RISC Zero ZK proof validated on {proof.verifiedAt ? new Date(proof.verifiedAt).toLocaleString() : "N/A"}
            </p>
          </div>
        </div>

        <div className="space-y-2 text-sm">
          <div className="flex items-center justify-between rounded-lg bg-muted p-3">
            <div>
              <span className="text-xs text-muted-foreground">Proof ID</span>
              <p className="font-mono">{proof.proofId}</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => copyToClipboard(proof.proofId, "proofId")}
            >
              <Copy className="h-3 w-3" />
            </Button>
          </div>

          <div className="flex items-center justify-between rounded-lg bg-muted p-3">
            <div className="min-w-0 flex-1">
              <span className="text-xs text-muted-foreground">Seal</span>
              <p className="font-mono text-xs break-all">{proof.seal}</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 shrink-0 ml-2"
              onClick={() => copyToClipboard(proof.seal, "seal")}
            >
              <Copy className="h-3 w-3" />
            </Button>
          </div>

          <div className="flex items-center justify-between rounded-lg bg-muted p-3">
            <div>
              <span className="text-xs text-muted-foreground">Image ID</span>
              <p className="font-mono text-xs break-all">{proof.imageId}</p>
            </div>
          </div>
        </div>

        <Button
          variant="ghost"
          className="w-full"
          onClick={() => setExpanded(!expanded)}
        >
          {expanded ? (
            <>
              <ChevronUp className="mr-2 h-4 w-4" />
              Show Less
            </>
          ) : (
            <>
              <ChevronDown className="mr-2 h-4 w-4" />
              Show More Details
            </>
          )}
        </Button>

        {expanded && (
          <div className="space-y-2 text-sm">
            <div className="rounded-lg bg-muted p-3">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-muted-foreground">Journal</span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6"
                  onClick={() => copyToClipboard(proof.journal, "journal")}
                >
                  <Copy className="h-3 w-3" />
                </Button>
              </div>
              <p className="font-mono text-xs break-all">{proof.journal}</p>
            </div>

            <div className="rounded-lg bg-muted p-3">
              <span className="text-xs text-muted-foreground">Entropy Sources Used</span>
              <div className="mt-2 space-y-1">
                {proof.entropySources.map((source) => (
                  <div key={source.name} className="flex items-center justify-between">
                    <span className="font-medium capitalize">{source.name}</span>
                    <div className="flex items-center gap-2">
                      {source.value && (
                        <span className="font-mono text-xs text-muted-foreground">
                          {source.value}
                        </span>
                      )}
                      <Badge variant={source.active ? "default" : "secondary"}>
                        w: {source.weight}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-lg bg-muted p-3">
              <span className="text-xs text-muted-foreground">Combined Randomness</span>
              <div className="flex items-center gap-2 mt-1">
                <p className="font-mono text-xs break-all flex-1">{proof.combinedRandomness}</p>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 shrink-0"
                  onClick={() => copyToClipboard(proof.combinedRandomness, "combined")}
                >
                  <Copy className="h-3 w-3" />
                </Button>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
