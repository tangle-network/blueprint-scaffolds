import type { CommitRevealPhase, VRFRequest } from "@/lib/vrf"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Lock, Unlock, Clock, CheckCircle2, Loader2 } from "lucide-react"

interface CommitRevealPanelProps {
  phase: CommitRevealPhase
  request: VRFRequest | null
}

const phaseConfig: Record<
  CommitRevealPhase["phase"],
  { label: string; icon: React.ElementType; color: string; description: string }
> = {
  idle: {
    label: "Idle",
    icon: Clock,
    color: "text-muted-foreground",
    description: "No active commit-reveal cycle",
  },
  committing: {
    label: "Committing",
    icon: Loader2,
    color: "text-blue-500",
    description: "Generating commitment hash from seed and secret...",
  },
  committed: {
    label: "Committed",
    icon: Lock,
    color: "text-yellow-500",
    description: "Commitment submitted on-chain. Waiting for reveal phase.",
  },
  revealing: {
    label: "Revealing",
    icon: Unlock,
    color: "text-purple-500",
    description: "Revealing secret value and generating ZK proof...",
  },
  revealed: {
    label: "Revealed",
    icon: CheckCircle2,
    color: "text-green-500",
    description: "Randomness revealed with valid ZK proof.",
  },
}

export default function CommitRevealPanel({ phase, request }: CommitRevealPanelProps) {
  const config = phaseConfig[phase.phase]
  const Icon = config.icon

  const phases: CommitRevealPhase["phase"][] = ["idle", "committing", "committed", "revealing", "revealed"]
  const currentIdx = phases.indexOf(phase.phase)

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Lock className="h-5 w-5 text-primary" />
          Commit-Reveal Protocol
        </CardTitle>
        <CardDescription>
          Two-phase protocol ensures front-running protection and provably fair outcomes
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center gap-2 p-3 rounded-lg bg-muted">
          <Icon className={`h-5 w-5 ${config.color} ${phase.phase === "committing" || phase.phase === "revealing" ? "animate-spin" : ""}`} />
          <div>
            <div className="flex items-center gap-2">
              <span className="font-medium">{config.label}</span>
              <Badge variant="outline">{phase.phase}</Badge>
            </div>
            <p className="text-sm text-muted-foreground">{config.description}</p>
          </div>
        </div>

        <div className="flex items-center justify-between">
          {phases.map((p, i) => {
            const pConfig = phaseConfig[p]
            const PIcon = pConfig.icon
            const isActive = i === currentIdx
            const isCompleted = i < currentIdx
            return (
              <div key={p} className="flex flex-col items-center gap-1">
                <div
                  className={`h-10 w-10 rounded-full flex items-center justify-center border-2 ${
                    isCompleted
                      ? "bg-green-500 border-green-500 text-white"
                      : isActive
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-muted bg-muted text-muted-foreground"
                  }`}
                >
                  {isCompleted ? (
                    <CheckCircle2 className="h-5 w-5" />
                  ) : (
                    <PIcon className={`h-4 w-4 ${isActive && (p === "committing" || p === "revealing") ? "animate-spin" : ""}`} />
                  )}
                </div>
                <span className="text-xs font-medium">{pConfig.label}</span>
              </div>
            )
          })}
        </div>

        {phase.commitment && (
          <div className="rounded-lg border p-3 space-y-1">
            <span className="text-xs text-muted-foreground">Commitment Hash</span>
            <p className="font-mono text-sm break-all">{phase.commitment}</p>
          </div>
        )}

        {phase.revealValue && (
          <div className="rounded-lg border p-3 space-y-1">
            <span className="text-xs text-muted-foreground">Reveal Value (Secret)</span>
            <p className="font-mono text-sm break-all">{phase.revealValue}</p>
          </div>
        )}

        {phase.timestamp && (
          <div className="text-xs text-muted-foreground">
            Last updated: {new Date(phase.timestamp).toLocaleString()}
          </div>
        )}

        <div className="rounded-lg bg-muted p-4 space-y-2">
          <h4 className="font-medium text-sm">How Commit-Reveal Works</h4>
          <ol className="text-sm text-muted-foreground space-y-1 list-decimal list-inside">
            <li>Commit: Hash your seed + secret and submit on-chain</li>
            <li>Wait: Allow several blocks to pass (front-running protection)</li>
            <li>Reveal: Submit the original seed and secret</li>
            <li>Verify: RISC Zero ZK proof validates the computation</li>
          </ol>
        </div>
      </CardContent>
    </Card>
  )
}
