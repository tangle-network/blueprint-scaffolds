import { VRFRequest } from '../types';

interface Props {
  request: VRFRequest;
}

export default function RequestCard({ request }: Props) {
  const statusColors: Record<string, string> = {
    pending: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
    commit: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
    fulfilled: 'bg-green-500/20 text-green-400 border-green-500/30',
    failed: 'bg-red-500/20 text-red-400 border-red-500/30',
  };

  return (
    <div className="glass-panel rounded-xl p-5 space-y-3 animate-fade-in">
      <div className="flex items-center justify-between">
        <span className="text-xs font-mono text-gray-500">{request.id}</span>
        <span className={`text-xs px-2 py-0.5 rounded-full border ${statusColors[request.status]}`}>
          {request.status.toUpperCase()}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-3 text-sm">
        <div>
          <span className="text-gray-500 text-xs">Use Case</span>
          <p className="text-gray-300 capitalize">{request.useCase?.replace('-', ' ') || 'N/A'}</p>
        </div>
        <div>
          <span className="text-gray-500 text-xs">Words Requested</span>
          <p className="text-gray-300">{request.numWords}</p>
        </div>
        <div className="col-span-2">
          <span className="text-gray-500 text-xs">Seed</span>
          <p className="text-gray-300 font-mono text-xs truncate">{request.seed}</p>
        </div>
        {request.commitHash && (
          <div className="col-span-2">
            <span className="text-gray-500 text-xs">Commit Hash</span>
            <p className="text-blue-400 font-mono text-xs truncate">{request.commitHash}</p>
          </div>
        )}
      </div>

      {request.randomness && request.randomness.length > 0 && (
        <div className="mt-3 pt-3 border-t border-gray-700/50">
          <span className="text-gray-500 text-xs block mb-2">Random Words</span>
          <div className="space-y-1">
            {request.randomness.map((word, i) => (
              <div key={i} className="flex items-center gap-2">
                <span className="text-vrf-accent text-xs font-bold w-6">W{i}</span>
                <code className="text-green-400 text-xs font-mono flex-1 truncate">{word}</code>
              </div>
            ))}
          </div>
        </div>
      )}

      {request.proof && (
        <div className="mt-3 pt-3 border-t border-gray-700/50">
          <span className="text-gray-500 text-xs block mb-1">ZK Proof</span>
          <p className="text-purple-400 font-mono text-xs truncate">{request.proof}</p>
        </div>
      )}

      <div className="flex justify-between text-xs text-gray-600 pt-2">
        <span>{new Date(request.createdAt).toLocaleTimeString()}</span>
        {request.fulfilledAt && (
          <span className="text-green-500">
            Fulfilled in {((request.fulfilledAt - request.createdAt) / 1000).toFixed(1)}s
          </span>
        )}
      </div>
    </div>
  );
}
