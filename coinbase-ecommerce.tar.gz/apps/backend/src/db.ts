import pg from 'pg'
import type { Env } from './env.js'

const { Pool } = pg

export function createPool(env: Env) {
  const pool = new Pool({
    connectionString: env.DATABASE_URL
  })

  pool.on('error', (err) => {
    // eslint-disable-next-line no-console
    console.error('Postgres pool error', err)
  })

  return pool
}

export type Db = ReturnType<typeof createPool>
