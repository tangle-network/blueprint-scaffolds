export type ProductRow = {
  id: string
  sku: string
  name: string
  description: string
  price_usd_cents: number
  image_url: string | null
  active: boolean
}

export type OrderRow = {
  id: string
  wallet_address: string
  status: 'created' | 'pending' | 'confirmed' | 'failed' | 'canceled'
  total_usd_cents: number
  charge_id: string | null
  charge_code: string | null
  hosted_url: string | null
  created_at: string
}

export type OrderItemRow = {
  id: string
  order_id: string
  product_id: string
  sku: string
  name: string
  unit_price_usd_cents: number
  quantity: number
}
