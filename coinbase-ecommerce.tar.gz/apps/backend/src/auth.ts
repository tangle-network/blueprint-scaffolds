import jwt, { type Secret, type SignOptions } from 'jsonwebtoken'
import { verifyMessage, getAddress } from 'ethers'
import type { Request, Response, NextFunction } from 'express'
import type { Env } from './env.js'

export type AuthTokenPayload = {
  walletAddress: string
}

export function signToken(env: Env, payload: AuthTokenPayload) {
  const secret: Secret = env.JWT_SECRET as unknown as Secret
  const options: SignOptions = {
    expiresIn: env.JWT_EXPIRES_IN as unknown as SignOptions['expiresIn']
  }
  return jwt.sign(payload, secret, options)
}

export function requireAuth(env: Env) {
  return (req: Request & { auth?: AuthTokenPayload }, res: Response, next: NextFunction) => {
    const header = req.header('Authorization') || ''
    const m = header.match(/^Bearer\s+(.+)$/i)
    if (!m) return res.status(401).json({ error: 'Missing Bearer token' })
    try {
      const decoded = jwt.verify(m[1], env.JWT_SECRET) as AuthTokenPayload
      req.auth = { walletAddress: getAddress(decoded.walletAddress) }
      next()
    } catch {
      return res.status(401).json({ error: 'Invalid token' })
    }
  }
}

export function verifyWalletLogin(input: { address: string; message: string; signature: string }) {
  const recovered = verifyMessage(input.message, input.signature)
  const recoveredChecksum = getAddress(recovered)
  const claimedChecksum = getAddress(input.address)
  if (recoveredChecksum !== claimedChecksum) {
    throw new Error('Signature does not match address')
  }
  return claimedChecksum
}
