import { z } from 'zod'

const envSchema = z.object({
  NODE_ENV: z.string().default('development'),
  PORT: z.coerce.number().default(4000),
  CORS_ORIGIN: z.string().default('http://localhost:5173'),
  DATABASE_URL: z.string().min(1),
  JWT_SECRET: z.string().min(12),
  JWT_EXPIRES_IN: z.string().default('1h'),
  COINBASE_COMMERCE_API_KEY: z.string().optional().default(''),
  COINBASE_COMMERCE_WEBHOOK_SECRET: z.string().optional().default(''),
  COINBASE_COMMERCE_VERSION: z.string().default('2018-03-22'),
  PUBLIC_BASE_URL: z.string().optional().default('http://localhost:4000')
})

export type Env = z.infer<typeof envSchema>

export function loadEnv(): Env {
  const parsed = envSchema.safeParse(process.env)
  if (!parsed.success) {
    const msg = parsed.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('\n')
    throw new Error(`Invalid environment variables:\n${msg}`)
  }
  return parsed.data
}
