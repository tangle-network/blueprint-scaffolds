import type { Router } from 'express'
import type { Db } from '../db.js'

export function registerProductRoutes(router: Router, db: Db) {
  router.get('/products', async (_req, res) => {
    const { rows } = await db.query(
      `SELECT id, sku, name, description, price_usd_cents, image_url, active
       FROM products
       WHERE active = true
       ORDER BY created_at DESC`
    )
    const products = rows.map((r) => ({
      id: r.id,
      sku: r.sku,
      name: r.name,
      description: r.description,
      priceUsdCents: r.price_usd_cents,
      imageUrl: r.image_url,
      active: r.active
    }))
    res.json({ products })
  })
}
