import type { Router } from 'express'
import { z } from 'zod'
import type { Db } from '../db.js'
import type { Env } from '../env.js'
import { createCharge } from '../coinbaseCommerce.js'

export function registerOrderRoutes(router: Router, db: Db, env: Env) {
  const createSchema = z.object({
    items: z
      .array(
        z.object({
          productId: z.string().uuid(),
          quantity: z.number().int().positive()
        })
      )
      .min(1)
  })

  router.get('/orders', async (req: any, res) => {
    const walletAddress = req.auth.walletAddress as string

    const ordersRes = await db.query(
      `SELECT id, wallet_address, status, total_usd_cents, charge_id, charge_code, hosted_url, created_at
       FROM orders
       WHERE wallet_address = $1
       ORDER BY created_at DESC
       LIMIT 50`,
      [walletAddress]
    )

    const orderIds = ordersRes.rows.map((r) => r.id as string)
    const itemsByOrder = new Map<string, any[]>()
    if (orderIds.length > 0) {
      const itemsRes = await db.query(
        `SELECT id, order_id, product_id, sku, name, unit_price_usd_cents, quantity
         FROM order_items
         WHERE order_id = ANY($1::uuid[])
         ORDER BY name ASC`,
        [orderIds]
      )
      for (const it of itemsRes.rows) {
        const arr = itemsByOrder.get(it.order_id) || []
        arr.push({
          id: it.id,
          orderId: it.order_id,
          productId: it.product_id,
          sku: it.sku,
          name: it.name,
          unitPriceUsdCents: it.unit_price_usd_cents,
          quantity: it.quantity
        })
        itemsByOrder.set(it.order_id, arr)
      }
    }

    const orders = ordersRes.rows.map((o) => ({
      id: o.id,
      walletAddress: o.wallet_address,
      status: o.status,
      totalUsdCents: o.total_usd_cents,
      chargeId: o.charge_id,
      hostedUrl: o.hosted_url,
      createdAt: o.created_at,
      items: itemsByOrder.get(o.id) || []
    }))

    res.json({ orders })
  })

  router.post('/orders', async (req: any, res) => {
    const walletAddress = req.auth.walletAddress as string
    const parsed = createSchema.safeParse(req.body)
    if (!parsed.success) return res.status(400).json({ error: 'Invalid body' })

    const client = await db.connect()
    try {
      await client.query('BEGIN')

      const productIds = parsed.data.items.map((i) => i.productId)
      const productsRes = await client.query(
        `SELECT id, sku, name, description, price_usd_cents, image_url, active
         FROM products
         WHERE id = ANY($1::uuid[])`,
        [productIds]
      )

      const productById = new Map<string, any>()
      for (const p of productsRes.rows) productById.set(p.id, p)

      let total = 0
      for (const item of parsed.data.items) {
        const p = productById.get(item.productId)
        if (!p || !p.active) {
          throw new Error(`Invalid product: ${item.productId}`)
        }
        total += item.quantity * p.price_usd_cents
      }

      const orderRes = await client.query(
        `INSERT INTO orders (wallet_address, status, total_usd_cents)
         VALUES ($1, 'created', $2)
         RETURNING id, wallet_address, status, total_usd_cents, charge_id, charge_code, hosted_url, created_at`,
        [walletAddress, total]
      )
      const order = orderRes.rows[0]

      for (const item of parsed.data.items) {
        const p = productById.get(item.productId)
        await client.query(
          `INSERT INTO order_items (order_id, product_id, sku, name, unit_price_usd_cents, quantity)
           VALUES ($1, $2, $3, $4, $5, $6)`,
          [order.id, p.id, p.sku, p.name, p.price_usd_cents, item.quantity]
        )
      }

      // Create Coinbase Commerce charge
      const charge = await createCharge(env, {
        name: `Order ${String(order.id).slice(0, 8)}`,
        description: `Web3 Commerce Store purchase`,
        amountUsd: (total / 100).toFixed(2),
        metadata: {
          orderId: order.id,
          walletAddress,
          publicBaseUrl: env.PUBLIC_BASE_URL
        }
      })

      const updateRes = await client.query(
        `UPDATE orders
         SET status = 'pending', charge_id = $2, charge_code = $3, hosted_url = $4, updated_at = now()
         WHERE id = $1
         RETURNING id, wallet_address, status, total_usd_cents, charge_id, charge_code, hosted_url, created_at`,
        [order.id, charge.id, charge.code, charge.hosted_url]
      )

      const itemsRes = await client.query(
        `SELECT id, order_id, product_id, sku, name, unit_price_usd_cents, quantity
         FROM order_items
         WHERE order_id = $1
         ORDER BY name ASC`,
        [order.id]
      )

      await client.query('COMMIT')

      res.json({
        order: {
          id: updateRes.rows[0].id,
          walletAddress: updateRes.rows[0].wallet_address,
          status: updateRes.rows[0].status,
          totalUsdCents: updateRes.rows[0].total_usd_cents,
          chargeId: updateRes.rows[0].charge_id,
          hostedUrl: updateRes.rows[0].hosted_url,
          createdAt: updateRes.rows[0].created_at,
          items: itemsRes.rows.map((it) => ({
            id: it.id,
            orderId: it.order_id,
            productId: it.product_id,
            sku: it.sku,
            name: it.name,
            unitPriceUsdCents: it.unit_price_usd_cents,
            quantity: it.quantity
          }))
        }
      })
    } catch (err) {
      await client.query('ROLLBACK').catch(() => {})
      res.status(400).json({ error: (err as Error).message || 'Could not create order' })
    } finally {
      client.release()
    }
  })
}
