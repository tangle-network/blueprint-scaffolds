import type { Router } from 'express'
import { z } from 'zod'
import type { Env } from '../env.js'
import { signToken, verifyWalletLogin } from '../auth.js'

export function registerAuthRoutes(router: Router, env: Env) {
  const bodySchema = z.object({
    address: z.string().min(1),
    message: z.string().min(1),
    signature: z.string().min(1)
  })

  router.post('/auth/wallet', async (req, res) => {
    const parsed = bodySchema.safeParse(req.body)
    if (!parsed.success) return res.status(400).json({ error: 'Invalid body' })

    try {
      const walletAddress = verifyWalletLogin(parsed.data)
      const token = signToken(env, { walletAddress })
      res.json({ token })
    } catch (err) {
      res.status(401).json({ error: (err as Error).message || 'Unauthorized' })
    }
  })
}
