import type { Router } from 'express'
import type { Db } from '../db.js'
import type { Env } from '../env.js'
import { mapCommerceEventToStatus, type CommerceWebhookEvent, verifyWebhookSignature } from '../coinbaseCommerce.js'

export function registerWebhookRoutes(router: Router, db: Db, env: Env) {
  router.post('/webhooks/coinbase-commerce', async (req: any, res) => {
    const rawBody: Buffer | undefined = req.rawBody
    try {
      if (!rawBody) throw new Error('Missing raw body')
      verifyWebhookSignature(env.COINBASE_COMMERCE_WEBHOOK_SECRET, rawBody, req.header('X-CC-Webhook-Signature'))
    } catch (err) {
      return res.status(400).json({ error: (err as Error).message || 'Invalid webhook' })
    }

    let event: CommerceWebhookEvent
    try {
      event = JSON.parse(rawBody.toString('utf8')) as CommerceWebhookEvent
    } catch {
      return res.status(400).json({ error: 'Invalid JSON' })
    }

    const chargeCode = event?.data?.code
    const eventType = event?.type
    if (!chargeCode || !eventType) {
      return res.status(400).json({ error: 'Malformed event' })
    }

    // Persist event for audit/debug
    await db.query(
      `INSERT INTO commerce_webhook_events (charge_code, event_type, payload)
       VALUES ($1, $2, $3)`,
      [chargeCode, eventType, event]
    )

    const newStatus = mapCommerceEventToStatus(eventType)
    if (newStatus) {
      await db.query(
        `UPDATE orders
         SET status = $2, updated_at = now()
         WHERE charge_code = $1`,
        [chargeCode, newStatus]
      )
    }

    res.json({ ok: true })
  })
}
