import crypto from 'crypto'
import type { Env } from './env.js'

export type CreateChargeInput = {
  name: string
  description: string
  amountUsd: string
  metadata: Record<string, string>
}

export type CommerceCharge = {
  id: string
  code: string
  hosted_url: string
}

export async function createCharge(env: Env, input: CreateChargeInput): Promise<CommerceCharge> {
  if (!env.COINBASE_COMMERCE_API_KEY) {
    throw new Error('COINBASE_COMMERCE_API_KEY not set')
  }

  const res = await fetch('https://api.commerce.coinbase.com/charges', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-CC-Api-Key': env.COINBASE_COMMERCE_API_KEY,
      'X-CC-Version': env.COINBASE_COMMERCE_VERSION
    },
    body: JSON.stringify({
      name: input.name,
      description: input.description,
      pricing_type: 'fixed_price',
      local_price: { amount: input.amountUsd, currency: 'USD' },
      metadata: input.metadata
    })
  })

  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new Error(`Coinbase Commerce error ${res.status}: ${text || res.statusText}`)
  }

  const json = (await res.json()) as { data: CommerceCharge }
  return json.data
}

export function verifyWebhookSignature(secret: string, rawBody: Buffer, signatureHeader: string | undefined) {
  if (!secret) throw new Error('Webhook secret not configured')
  if (!signatureHeader) throw new Error('Missing X-CC-Webhook-Signature')
  const expected = crypto.createHmac('sha256', secret).update(rawBody).digest('hex')

  const a = Buffer.from(expected, 'utf8')
  const b = Buffer.from(signatureHeader, 'utf8')
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    throw new Error('Invalid webhook signature')
  }
}

export type CommerceWebhookEvent = {
  id: string
  type: string
  api_version: string
  created_at: string
  data: {
    id?: string
    code: string
    metadata?: Record<string, any>
    timeline?: Array<{ status: string; time: string }>
    payments?: any[]
  }
}

export function mapCommerceEventToStatus(eventType: string): 'pending' | 'confirmed' | 'failed' | 'canceled' | null {
  switch (eventType) {
    case 'charge:created':
    case 'charge:pending':
    case 'charge:delayed':
    case 'charge:resolved':
      return 'pending'
    case 'charge:confirmed':
      return 'confirmed'
    case 'charge:failed':
      return 'failed'
    case 'charge:canceled':
      return 'canceled'
    default:
      return null
  }
}
