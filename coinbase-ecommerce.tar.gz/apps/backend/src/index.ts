import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import { loadEnv } from './env.js'
import { createPool } from './db.js'
import { requireAuth } from './auth.js'
import { registerProductRoutes } from './routes/products.js'
import { registerAuthRoutes } from './routes/auth.js'
import { registerOrderRoutes } from './routes/orders.js'
import { registerWebhookRoutes } from './routes/webhooks.js'

const env = loadEnv()
const db = createPool(env)

const app = express()

// Capture raw body for Coinbase Commerce webhook signature verification.
app.use(
  '/api/webhooks/coinbase-commerce',
  express.raw({ type: 'application/json' }),
  (req: any, _res, next) => {
    req.rawBody = req.body
    next()
  }
)

app.use(express.json())

const corsOrigin = env.CORS_ORIGIN.trim()
app.use(
  cors({
    origin: corsOrigin === '*' ? true : corsOrigin.split(',').map((s) => s.trim()),
    credentials: false
  })
)

app.get('/api/health', (_req, res) => {
  res.json({ ok: true })
})

const router = express.Router()
registerProductRoutes(router, db)
registerAuthRoutes(router, env)
router.use(requireAuth(env))
registerOrderRoutes(router, db, env)
registerWebhookRoutes(router, db, env)
app.use('/api', router)

// Error handler
app.use((err: any, _req: any, res: any, _next: any) => {
  // eslint-disable-next-line no-console
  console.error(err)
  res.status(500).json({ error: 'Internal server error' })
})

app.listen(env.PORT, () => {
  // eslint-disable-next-line no-console
  console.log(`Backend listening on http://localhost:${env.PORT}`)
})
