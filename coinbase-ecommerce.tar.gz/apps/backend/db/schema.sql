-- Schema for Web3 Commerce Store

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sku text NOT NULL UNIQUE,
  name text NOT NULL,
  description text NOT NULL DEFAULT '',
  price_usd_cents integer NOT NULL CHECK (price_usd_cents >= 0),
  image_url text,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TYPE order_status AS ENUM ('created', 'pending', 'confirmed', 'failed', 'canceled');

CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_address text NOT NULL,
  status order_status NOT NULL DEFAULT 'created',
  total_usd_cents integer NOT NULL CHECK (total_usd_cents >= 0),
  charge_id text,
  charge_code text,
  hosted_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS orders_wallet_address_idx ON orders(wallet_address);
CREATE UNIQUE INDEX IF NOT EXISTS orders_charge_code_uniq ON orders(charge_code) WHERE charge_code IS NOT NULL;

CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id),
  sku text NOT NULL,
  name text NOT NULL,
  unit_price_usd_cents integer NOT NULL CHECK (unit_price_usd_cents >= 0),
  quantity integer NOT NULL CHECK (quantity > 0)
);

CREATE INDEX IF NOT EXISTS order_items_order_id_idx ON order_items(order_id);

CREATE TABLE IF NOT EXISTS commerce_webhook_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  charge_code text,
  event_type text NOT NULL,
  payload jsonb NOT NULL,
  received_at timestamptz NOT NULL DEFAULT now()
);
