INSERT INTO products (sku, name, description, price_usd_cents, image_url, active)
VALUES
  ('CBW-TEE', 'Coinbase Blue Tee', 'Soft cotton tee with a deep-blue gradient.', 2800, NULL, true),
  ('HODL-MUG', 'HODL Mug', 'Ceramic mug for long mornings and longer cycles.', 1800, NULL, true),
  ('LEDGER-PCH', 'Hardware Wallet Pouch', 'Minimal pouch to keep your essentials secure.', 2400, NULL, true)
ON CONFLICT (sku) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  price_usd_cents = EXCLUDED.price_usd_cents,
  image_url = EXCLUDED.image_url,
  active = EXCLUDED.active,
  updated_at = now();
