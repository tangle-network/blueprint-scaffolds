export type Product = {
  id: string
  sku: string
  name: string
  description: string
  priceUsdCents: number
  imageUrl: string | null
  active: boolean
}

export type OrderStatus = 'created' | 'pending' | 'confirmed' | 'failed' | 'canceled'

export type Order = {
  id: string
  walletAddress: string
  status: OrderStatus
  totalUsdCents: number
  chargeId: string | null
  hostedUrl: string | null
  createdAt: string
}

export type OrderItem = {
  id: string
  orderId: string
  productId: string
  name: string
  sku: string
  unitPriceUsdCents: number
  quantity: number
}

export type OrderWithItems = Order & { items: OrderItem[] }
