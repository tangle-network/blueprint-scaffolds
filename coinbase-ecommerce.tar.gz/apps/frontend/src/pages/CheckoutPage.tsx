import { useMutation, useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { apiFetch } from '../api/client'
import type { OrderWithItems } from '../api/types'
import { useCart } from '../cart/cart'
import { useWallet } from '../wallet/wallet'

function formatUsd(cents: number) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(cents / 100)
}

function nonce() {
  return crypto.getRandomValues(new Uint32Array(4)).join('-')
}

export default function CheckoutPage() {
  const cart = useCart()
  const wallet = useWallet()
  const meQ = useQuery({
    queryKey: ['me', wallet.account],
    enabled: !!wallet.account,
    queryFn: async () => {
      const message = `Sign in to Web3 Commerce Store\n\nAddress: ${wallet.account}\nNonce: ${nonce()}`
      const signature = await wallet.signMessage(message)
      return apiFetch<{ token: string }>(`/api/auth/wallet`, {
        method: 'POST',
        body: JSON.stringify({ address: wallet.account, message, signature })
      })
    }
  })

  const checkoutM = useMutation({
    mutationFn: async () => {
      if (!wallet.account) throw new Error('Connect wallet to checkout')
      if (!meQ.data?.token) throw new Error('Not authenticated yet')
      if (cart.items.length === 0) throw new Error('Cart is empty')
      const items = cart.items.map((it) => ({ productId: it.product.id, quantity: it.quantity }))
      return apiFetch<{ order: OrderWithItems }>(`/api/orders`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${meQ.data.token}` },
        body: JSON.stringify({ items })
      })
    },
    onSuccess: (data) => {
      cart.clear()
      if (data.order.hostedUrl) window.location.href = data.order.hostedUrl
    }
  })

  return (
    <section className="section">
      <div className="section__header">
        <h1 className="h1">Checkout</h1>
        <p className="lede">Sign in with your wallet, then pay via Coinbase Commerce hosted checkout.</p>
      </div>

      <div className="layout">
        <div className="card">
          <h2 className="h2">Cart</h2>
          {cart.items.length === 0 ? (
            <p className="muted">Your cart is empty. <Link to="/">Browse products</Link>.</p>
          ) : (
            <div className="cart">
              {cart.items.map((it) => (
                <div className="cart__row" key={it.product.id}>
                  <div className="cart__name">{it.product.name}</div>
                  <div className="cart__qty">
                    <button className="qty" onClick={() => cart.setQty(it.product.id, it.quantity - 1)}>-</button>
                    <span>{it.quantity}</span>
                    <button className="qty" onClick={() => cart.setQty(it.product.id, it.quantity + 1)}>+</button>
                  </div>
                  <div className="cart__price">{formatUsd(it.quantity * it.product.priceUsdCents)}</div>
                </div>
              ))}
              <div className="cart__total">
                <span>Total</span>
                <strong>{formatUsd(cart.totalUsdCents)}</strong>
              </div>
            </div>
          )}
        </div>

        <div className="card">
          <h2 className="h2">Wallet & Payment</h2>
          {!wallet.account ? (
            <p className="muted">Connect your Coinbase Wallet to continue.</p>
          ) : (
            <p className="muted">Connected: <span className="mono">{wallet.account}</span></p>
          )}

          {wallet.account ? (
            <div className="auth">
              <div className="auth__row">
                <span>Status</span>
                <span>
                  {meQ.isFetching ? 'Signing...' : meQ.data?.token ? 'Signed in' : meQ.isError ? 'Error' : 'Ready'}
                </span>
              </div>
              {meQ.isError ? <div className="hint hint--error">{String(meQ.error)}</div> : null}
            </div>
          ) : null}

          <button
            className="btn btn--primary"
            onClick={() => checkoutM.mutate()}
            disabled={!wallet.account || !meQ.data?.token || cart.items.length === 0 || checkoutM.isPending}
          >
            {checkoutM.isPending ? 'Creating checkout...' : 'Pay with crypto'}
          </button>
          {checkoutM.isError ? <div className="hint hint--error">{String(checkoutM.error)}</div> : null}
          <div className="hint">
            Payment methods configured by your Coinbase Commerce settings (BTC, ETH, USDC).
          </div>
        </div>
      </div>
    </section>
  )
}
