import { useQuery } from '@tanstack/react-query'
import { apiFetch } from '../api/client'
import type { Product } from '../api/types'
import { useCart } from '../cart/cart'

function formatUsd(cents: number) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(cents / 100)
}

export default function CatalogPage() {
  const { add } = useCart()
  const productsQ = useQuery({
    queryKey: ['products'],
    queryFn: () => apiFetch<{ products: Product[] }>('/api/products')
  })

  return (
    <section className="section">
      <div className="section__header">
        <h1 className="h1">Products</h1>
        <p className="lede">Curated essentials priced in USD, payable in BTC/ETH/USDC.</p>
      </div>

      {productsQ.isLoading ? <div className="card">Loading...</div> : null}
      {productsQ.isError ? <div className="card card--error">{String(productsQ.error)}</div> : null}

      <div className="grid">
        {(productsQ.data?.products || []).map((p) => (
          <article className="product" key={p.id}>
            <div className="product__imgWrap">
              {p.imageUrl ? <img className="product__img" src={p.imageUrl} alt={p.name} /> : <div className="product__placeholder" />}
            </div>
            <div className="product__body">
              <div className="product__top">
                <h3 className="h3">{p.name}</h3>
                <div className="price">{formatUsd(p.priceUsdCents)}</div>
              </div>
              <p className="muted">{p.description}</p>
              <div className="product__actions">
                <button className="btn" onClick={() => add(p, 1)}>Add to cart</button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  )
}
