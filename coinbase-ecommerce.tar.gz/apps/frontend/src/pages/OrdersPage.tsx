import { useMutation, useQuery } from '@tanstack/react-query'
import { apiFetch } from '../api/client'
import type { OrderWithItems } from '../api/types'
import { useWallet } from '../wallet/wallet'

function nonce() {
  return crypto.getRandomValues(new Uint32Array(4)).join('-')
}

function formatUsd(cents: number) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(cents / 100)
}

export default function OrdersPage() {
  const wallet = useWallet()

  const signInM = useMutation({
    mutationFn: async () => {
      if (!wallet.account) throw new Error('Connect wallet')
      const message = `Sign in to Web3 Commerce Store\n\nAddress: ${wallet.account}\nNonce: ${nonce()}`
      const signature = await wallet.signMessage(message)
      return apiFetch<{ token: string }>(`/api/auth/wallet`, {
        method: 'POST',
        body: JSON.stringify({ address: wallet.account, message, signature })
      })
    }
  })

  const ordersQ = useQuery({
    queryKey: ['orders', wallet.account, signInM.data?.token],
    enabled: !!wallet.account && !!signInM.data?.token,
    queryFn: () =>
      apiFetch<{ orders: OrderWithItems[] }>(`/api/orders`, {
        headers: { Authorization: `Bearer ${signInM.data!.token}` }
      })
  })

  return (
    <section className="section">
      <div className="section__header">
        <h1 className="h1">Orders</h1>
        <p className="lede">Track your order status (webhook updates confirmed payments).</p>
      </div>

      <div className="card">
        {!wallet.account ? (
          <p className="muted">Connect your wallet to view your orders.</p>
        ) : (
          <>
            <div className="row">
              <div>
                <div className="label">Wallet</div>
                <div className="mono">{wallet.account}</div>
              </div>
              <button className="btn" onClick={() => signInM.mutate()} disabled={signInM.isPending}>
                {signInM.data?.token ? 'Refresh session' : signInM.isPending ? 'Signing...' : 'Sign in'}
              </button>
            </div>
            {signInM.isError ? <div className="hint hint--error">{String(signInM.error)}</div> : null}
          </>
        )}
      </div>

      {ordersQ.isLoading ? <div className="card">Loading...</div> : null}
      {ordersQ.isError ? <div className="card card--error">{String(ordersQ.error)}</div> : null}

      <div className="stack">
        {(ordersQ.data?.orders || []).map((o) => (
          <div className="card" key={o.id}>
            <div className="row">
              <div>
                <div className="label">Order</div>
                <div className="mono">{o.id}</div>
              </div>
              <div className="pill">{o.status}</div>
            </div>
            <div className="row row--tight">
              <div>
                <div className="label">Total</div>
                <div className="strong">{formatUsd(o.totalUsdCents)}</div>
              </div>
              <div>
                <div className="label">Created</div>
                <div className="muted">{new Date(o.createdAt).toLocaleString()}</div>
              </div>
            </div>

            <div className="hr" />
            <div className="items">
              {o.items.map((it) => (
                <div className="items__row" key={it.id}>
                  <span>{it.name} x {it.quantity}</span>
                  <span className="muted">{formatUsd(it.unitPriceUsdCents * it.quantity)}</span>
                </div>
              ))}
            </div>

            {o.hostedUrl ? (
              <div className="hint">
                Hosted checkout: <a href={o.hostedUrl} target="_blank" rel="noreferrer">Open</a>
              </div>
            ) : null}
          </div>
        ))}
      </div>
    </section>
  )
}
