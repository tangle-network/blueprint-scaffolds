import React, { createContext, useContext, useMemo, useState } from 'react'
import CoinbaseWalletSDK from '@coinbase/wallet-sdk'
import { BrowserProvider, type Eip1193Provider } from 'ethers'

type WalletContextValue = {
  account: string | null
  isConnecting: boolean
  connect: () => Promise<void>
  disconnect: () => void
  signMessage: (message: string) => Promise<string>
}

const WalletContext = createContext<WalletContextValue | null>(null)

const APP_NAME = import.meta.env.VITE_APP_NAME || 'Web3 Commerce Store'

function getProvider(): Eip1193Provider {
  const sdk = new CoinbaseWalletSDK({
    appName: APP_NAME
  })
  return sdk.makeWeb3Provider({
    options: 'smartWalletOnly'
  }) as unknown as Eip1193Provider
}

export function WalletProvider({ children }: { children: React.ReactNode }) {
  const [account, setAccount] = useState<string | null>(null)
  const [isConnecting, setIsConnecting] = useState(false)
  const [provider, setProvider] = useState<Eip1193Provider | null>(null)

  const connect = async () => {
    setIsConnecting(true)
    try {
      const p = provider ?? getProvider()
      setProvider(p)
      const ethersProvider = new BrowserProvider(p)
      const accounts = await ethersProvider.send('eth_requestAccounts', [])
      setAccount((accounts?.[0] as string) || null)
    } finally {
      setIsConnecting(false)
    }
  }

  const disconnect = () => {
    setAccount(null)
    try {
      // Best-effort: many EIP-1193 providers do not implement disconnect.
      ;(provider as any)?.disconnect?.()
    } catch {
      // ignore
    }
  }

  const signMessage = async (message: string) => {
    if (!provider) throw new Error('Wallet not connected')
    const ethersProvider = new BrowserProvider(provider)
    const signer = await ethersProvider.getSigner()
    return await signer.signMessage(message)
  }

  const value = useMemo<WalletContextValue>(
    () => ({ account, isConnecting, connect, disconnect, signMessage }),
    [account, isConnecting, provider]
  )

  return <WalletContext.Provider value={value}>{children}</WalletContext.Provider>
}

export function useWallet() {
  const ctx = useContext(WalletContext)
  if (!ctx) throw new Error('useWallet must be used within WalletProvider')
  return ctx
}
