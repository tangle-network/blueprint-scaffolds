import React, { createContext, useContext, useMemo, useReducer } from 'react'
import type { Product } from '../api/types'

export type CartItem = {
  product: Product
  quantity: number
}

type CartState = {
  items: Record<string, CartItem>
}

type Action =
  | { type: 'add'; product: Product; quantity?: number }
  | { type: 'remove'; productId: string }
  | { type: 'setQty'; productId: string; quantity: number }
  | { type: 'clear' }

function reducer(state: CartState, action: Action): CartState {
  switch (action.type) {
    case 'add': {
      const existing = state.items[action.product.id]
      const nextQty = (existing?.quantity || 0) + (action.quantity ?? 1)
      return {
        items: {
          ...state.items,
          [action.product.id]: { product: action.product, quantity: nextQty }
        }
      }
    }
    case 'remove': {
      const next = { ...state.items }
      delete next[action.productId]
      return { items: next }
    }
    case 'setQty': {
      const existing = state.items[action.productId]
      if (!existing) return state
      if (action.quantity <= 0) {
        const next = { ...state.items }
        delete next[action.productId]
        return { items: next }
      }
      return {
        items: {
          ...state.items,
          [action.productId]: { ...existing, quantity: action.quantity }
        }
      }
    }
    case 'clear':
      return { items: {} }
    default:
      return state
  }
}

type CartContextValue = {
  items: CartItem[]
  itemsCount: number
  totalUsdCents: number
  add: (product: Product, quantity?: number) => void
  remove: (productId: string) => void
  setQty: (productId: string, quantity: number) => void
  clear: () => void
}

const CartContext = createContext<CartContextValue | null>(null)

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, { items: {} })

  const value = useMemo<CartContextValue>(() => {
    const items = Object.values(state.items)
    const itemsCount = items.reduce((acc, it) => acc + it.quantity, 0)
    const totalUsdCents = items.reduce((acc, it) => acc + it.quantity * it.product.priceUsdCents, 0)
    return {
      items,
      itemsCount,
      totalUsdCents,
      add: (product, quantity) => dispatch({ type: 'add', product, quantity }),
      remove: (productId) => dispatch({ type: 'remove', productId }),
      setQty: (productId, quantity) => dispatch({ type: 'setQty', productId, quantity }),
      clear: () => dispatch({ type: 'clear' })
    }
  }, [state.items])

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>
}

export function useCart() {
  const ctx = useContext(CartContext)
  if (!ctx) throw new Error('useCart must be used within CartProvider')
  return ctx
}
