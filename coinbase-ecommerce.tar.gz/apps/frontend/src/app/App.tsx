import { Link, Route, Routes } from 'react-router-dom'
import { CartProvider, useCart } from '../cart/cart'
import { WalletProvider, useWallet } from '../wallet/wallet'
import CatalogPage from '../pages/CatalogPage'
import OrdersPage from '../pages/OrdersPage'
import CheckoutPage from '../pages/CheckoutPage'

function TopBar() {
  const { itemsCount } = useCart()
  const { account, connect, disconnect, isConnecting } = useWallet()
  return (
    <header className="topbar">
      <div className="topbar__inner">
        <div className="brand">
          <Link to="/" className="brand__link">{import.meta.env.VITE_APP_NAME || 'Web3 Store'}</Link>
          <span className="brand__tag">Crypto payments via Coinbase Commerce</span>
        </div>
        <nav className="nav">
          <Link to="/" className="nav__link">Products</Link>
          <Link to="/orders" className="nav__link">Orders</Link>
          <Link to="/checkout" className="nav__link">Cart ({itemsCount})</Link>
        </nav>
        <div className="wallet">
          {account ? (
            <>
              <span className="wallet__addr" title={account}>{account.slice(0, 6)}...{account.slice(-4)}</span>
              <button className="btn btn--ghost" onClick={disconnect}>Disconnect</button>
            </>
          ) : (
            <button className="btn" onClick={connect} disabled={isConnecting}>
              {isConnecting ? 'Connecting...' : 'Connect Wallet'}
            </button>
          )}
        </div>
      </div>
    </header>
  )
}

export default function App() {
  return (
    <WalletProvider>
      <CartProvider>
        <div className="app">
          <TopBar />
          <main className="main">
            <Routes>
              <Route path="/" element={<CatalogPage />} />
              <Route path="/checkout" element={<CheckoutPage />} />
              <Route path="/orders" element={<OrdersPage />} />
            </Routes>
          </main>
          <footer className="footer">
            <div className="footer__inner">
              <span>Test mode friendly. Webhooks update order status automatically.</span>
            </div>
          </footer>
        </div>
      </CartProvider>
    </WalletProvider>
  )
}
