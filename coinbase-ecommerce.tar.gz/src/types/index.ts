export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  stock: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Order {
  id: string;
  walletAddress: string;
  items: OrderItem[];
  total: number;
  currency: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  chargeId?: string;
  createdAt: string;
}

export interface OrderItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
}

export interface WalletState {
  address: string | null;
  connected: boolean;
  chainId: number | null;
}

export interface CoinbaseCharge {
  id: string;
  code: string;
  status: string;
  payments: Array<{
    transaction_id: string;
    status: string;
    value: { local: { amount: string; currency: string } };
  }>;
}
