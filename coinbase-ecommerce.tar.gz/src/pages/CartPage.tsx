import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { CartItemRow } from '@/components/CartItemRow';
import { useCart } from '@/context/CartContext';
import { useWallet } from '@/context/WalletContext';
import type { Product } from '@/types';

export function CartPage() {
  const { items, total, clearCart } = useCart();
  const { connected, connect, address } = useWallet();
  const [checkoutLoading, setCheckoutLoading] = useState(false);
  const [checkoutResult, setCheckoutResult] = useState<{ orderId: string; total: number; currency: string } | null>(null);

  const handleCheckout = async () => {
    if (!connected || !address) return;
    setCheckoutLoading(true);
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          walletAddress: address,
          items: items.map((i) => ({ productId: i.product.id, quantity: i.quantity })),
          currency: 'ETH',
        }),
      });
      const data = await res.json();
      if (data.orderId) {
        const simulateRes = await fetch(`/api/orders/${data.orderId}/simulate-payment`, { method: 'POST' });
        const simData = await simulateRes.json();
        setCheckoutResult({ orderId: data.orderId, total: data.total, currency: data.currency });
        clearCart();
      }
    } catch (err) {
      console.error('Checkout failed:', err);
    } finally {
      setCheckoutLoading(false);
    }
  };

  if (checkoutResult) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <div className="mx-auto max-w-md">
          <div className="mb-4 text-6xl">🎉</div>
          <h2 className="text-3xl font-bold">Order Confirmed!</h2>
          <p className="mt-2 text-muted-foreground">
            Payment of {checkoutResult.total.toFixed(4)} {checkoutResult.currency} received.
          </p>
          <p className="mt-1 text-sm text-muted-foreground">Order ID: {checkoutResult.orderId}</p>
          <div className="mt-6 flex justify-center gap-4">
            <Link to="/">
              <Button>Continue Shopping</Button>
            </Link>
            <Link to="/orders">
              <Button variant="outline">View Orders</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <ShoppingCart className="mx-auto h-16 w-16 text-muted-foreground" />
        <h2 className="mt-4 text-2xl font-bold">Your cart is empty</h2>
        <p className="mt-2 text-muted-foreground">Browse our products and add items to your cart.</p>
        <Link to="/" className="mt-6 inline-block">
          <Button>
            Browse Products
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Shopping Cart</h1>
      <div className="grid gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>{items.length} item{items.length !== 1 ? 's' : ''}</CardTitle>
            </CardHeader>
            <CardContent>
              {items.map((item) => (
                <CartItemRow key={item.product.id} item={item} />
              ))}
            </CardContent>
          </Card>
        </div>
        <div>
          <Card className="sticky top-24">
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span>{total.toFixed(4)} ETH</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Network Fee</span>
                <span>~0.001 ETH</span>
              </div>
              <div className="border-t pt-3 flex justify-between font-semibold">
                <span>Total</span>
                <span>{(total + 0.001).toFixed(4)} ETH</span>
              </div>
              <div className="text-xs text-muted-foreground">
                ≈ ${(((total + 0.001) * 3500)).toFixed(2)} USD
              </div>
            </CardContent>
            <CardFooter className="flex-col gap-2">
              {connected ? (
                <Button className="w-full" onClick={handleCheckout} disabled={checkoutLoading}>
                  {checkoutLoading ? 'Processing...' : 'Pay with Crypto'}
                </Button>
              ) : (
                <Button className="w-full" onClick={connect}>
                  Connect Wallet to Checkout
                </Button>
              )}
              <p className="text-xs text-center text-muted-foreground">
                Accepts BTC, ETH, and USDC via Coinbase Commerce
              </p>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}
