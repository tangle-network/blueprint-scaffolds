import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { CartItemRow } from '@/components/CartItemRow';
import { useCart } from '@/context/CartContext';
import { useWallet } from '@/context/WalletContext';

export function CartPage() {
  const { items, total, clearCart } = useCart();
  const { connected, connect } = useWallet();
  const navigate = useNavigate();

  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <ShoppingCart className="mx-auto h-16 w-16 text-muted-foreground" />
        <h2 className="mt-4 text-2xl font-bold">Your cart is empty</h2>
        <p className="mt-2 text-muted-foreground">
          Browse our products and add items to your cart.
        </p>
        <Link to="/" className="mt-6 inline-block">
          <Button>
            Browse Products
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </Link>
      </div>
    );
  }

  const handleCheckout = () => {
    if (!connected) {
      connect();
      return;
    }
    navigate('/checkout');
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Shopping Cart</h1>
      <div className="grid gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>
                {items.length} item{items.length !== 1 ? 's' : ''}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {items.map((item) => (
                <CartItemRow key={item.product.id} item={item} />
              ))}
            </CardContent>
          </Card>
        </div>
        <div>
          <Card className="sticky top-24">
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span>{total.toFixed(4)} ETH</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Network Fee</span>
                <span>~0.001 ETH</span>
              </div>
              <div className="border-t pt-3 flex justify-between font-semibold">
                <span>Total</span>
                <span>{(total + 0.001).toFixed(4)} ETH</span>
              </div>
              <div className="text-xs text-muted-foreground">
                ≈ ${((total + 0.001) * 3500).toFixed(2)} USD
              </div>
            </CardContent>
            <CardFooter className="flex-col gap-2">
              <Button className="w-full" onClick={handleCheckout}>
                {connected ? 'Proceed to Checkout' : 'Connect Wallet to Checkout'}
              </Button>
              <Button
                variant="ghost"
                className="w-full text-destructive"
                onClick={clearCart}
              >
                Clear Cart
              </Button>
              <p className="text-xs text-center text-muted-foreground">
                Accepts BTC, ETH, and USDC via Coinbase Commerce
              </p>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}
