import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, CheckCircle2, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useCart } from '@/context/CartContext';
import { useWallet } from '@/context/WalletContext';
import { createOrder, completeOrder } from '@/data/orders';
import { useToast } from '@/components/ui/use-toast';

const CRYPTO_OPTIONS = [
  { id: 'ETH', name: 'Ethereum', symbol: 'ETH', icon: '⟠', rate: 1 },
  { id: 'BTC', name: 'Bitcoin', symbol: 'BTC', icon: '₿', rate: 0.000065 },
  { id: 'USDC', name: 'USD Coin', symbol: 'USDC', icon: '$', rate: 3500 },
] as const;

export function CheckoutPage() {
  const { items, total, clearCart } = useCart();
  const { address, connected, connect } = useWallet();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [currency, setCurrency] = useState<string>('ETH');
  const [paying, setPaying] = useState(false);
  const [completed, setCompleted] = useState<{
    orderId: string;
    amount: string;
    currency: string;
  } | null>(null);

  if (items.length === 0 && !completed) {
    navigate('/cart');
    return null;
  }

  if (!connected || !address) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-bold">Wallet Required</h2>
        <p className="mt-2 text-muted-foreground">
          Connect your wallet to proceed with checkout.
        </p>
        <Button className="mt-6" onClick={connect}>
          Connect Wallet
        </Button>
      </div>
    );
  }

  const selected = CRYPTO_OPTIONS.find((c) => c.id === currency)!;
  const ethTotal = total + 0.001;
  const convertedAmount = (ethTotal * selected.rate).toFixed(
    currency === 'BTC' ? 8 : currency === 'ETH' ? 4 : 2
  );

  const handlePay = () => {
    setPaying(true);
    setTimeout(() => {
      const order = createOrder(
        address,
        items.map((i) => ({
          productId: i.product.id,
          name: i.product.name,
          price: i.product.price,
          quantity: i.quantity,
        })),
        currency
      );
      completeOrder(order.id);
      clearCart();
      setCompleted({
        orderId: order.id,
        amount: convertedAmount,
        currency: selected.symbol,
      });
      setPaying(false);
      toast({
        title: 'Payment confirmed',
        description: `Order ${order.id.slice(0, 8)} paid with ${selected.symbol}`,
      });
    }, 2000);
  };

  if (completed) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <div className="mx-auto max-w-md">
          <CheckCircle2 className="mx-auto h-16 w-16 text-green-500" />
          <h2 className="mt-4 text-3xl font-bold">Payment Confirmed!</h2>
          <p className="mt-2 text-muted-foreground">
            You paid {completed.amount} {completed.currency} via Coinbase Commerce.
          </p>
          <p className="mt-1 text-sm font-mono text-muted-foreground">
            Order ID: {completed.orderId}
          </p>
          <div className="mt-6 flex justify-center gap-4">
            <Link to="/">
              <Button>Continue Shopping</Button>
            </Link>
            <Link to="/orders">
              <Button variant="outline">View Orders</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <Link to="/cart" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-6">
        <ArrowLeft className="mr-1 h-4 w-4" />
        Back to cart
      </Link>
      <h1 className="text-3xl font-bold mb-8">Checkout</h1>

      <div className="grid gap-8 lg:grid-cols-2">
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Order Items</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {items.map((item) => (
                <div key={item.product.id} className="flex justify-between text-sm">
                  <span>
                    {item.product.name} x{item.quantity}
                  </span>
                  <span>{(item.product.price * item.quantity).toFixed(4)} ETH</span>
                </div>
              ))}
              <div className="border-t pt-2 flex justify-between font-semibold">
                <span>Subtotal + Network Fee</span>
                <span>{ethTotal.toFixed(4)} ETH</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Select Payment Currency</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {CRYPTO_OPTIONS.map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => setCurrency(opt.id)}
                  className={`w-full flex items-center gap-3 rounded-lg border p-4 text-left transition-colors ${
                    currency === opt.id
                      ? 'border-primary bg-primary/5 ring-2 ring-primary'
                      : 'hover:bg-muted/50'
                  }`}
                >
                  <span className="text-2xl">{opt.icon}</span>
                  <div className="flex-1">
                    <div className="font-medium">{opt.name}</div>
                    <div className="text-sm text-muted-foreground">
                      {(ethTotal * opt.rate).toFixed(opt.id === 'BTC' ? 8 : opt.id === 'ETH' ? 4 : 2)}{' '}
                      {opt.symbol}
                    </div>
                  </div>
                  {currency === opt.id && (
                    <CheckCircle2 className="h-5 w-5 text-primary" />
                  )}
                </button>
              ))}

              <div className="pt-4">
                <Button className="w-full" onClick={handlePay} disabled={paying}>
                  {paying ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing Payment...
                    </>
                  ) : (
                    `Pay ${convertedAmount} ${selected.symbol}`
                  )}
                </Button>
                <p className="mt-2 text-xs text-center text-muted-foreground">
                  Payment processed via Coinbase Commerce API
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
