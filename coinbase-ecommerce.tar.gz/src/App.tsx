import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { WalletProvider } from '@/context/WalletContext';
import { CartProvider } from '@/context/CartContext';
import { Header } from '@/components/Header';
import { Toaster } from '@/components/ui/toaster';
import { HomePage } from '@/pages/HomePage';
import { CartPage } from '@/pages/CartPage';
import { OrdersPage } from '@/pages/OrdersPage';

function App() {
  return (
    <BrowserRouter>
      <WalletProvider>
        <CartProvider>
          <div className="min-h-screen bg-background">
            <Header />
            <main>
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/cart" element={<CartPage />} />
                <Route path="/orders" element={<OrdersPage />} />
              </Routes>
            </main>
            <footer className="border-t py-8 text-center text-sm text-muted-foreground">
              <p>CryptoStore &mdash; Web3 E-Commerce &bull; Powered by Coinbase Commerce</p>
            </footer>
            <Toaster />
          </div>
        </CartProvider>
      </WalletProvider>
    </BrowserRouter>
  );
}

export default App;
