import type { Product } from '@/types';

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Crypto Hoodie',
    description:
      'Premium cotton hoodie with embroidered crypto logo. Comfortable and stylish for any occasion.',
    price: 0.05,
    image: '/products/hoodie.svg',
    category: 'clothing',
    stock: 50,
  },
  {
    id: '2',
    name: 'Bitcoin Cap',
    description:
      'Adjustable snapback cap with Bitcoin embroidered patch. One size fits all.',
    price: 0.02,
    image: '/products/cap.svg',
    category: 'clothing',
    stock: 100,
  },
  {
    id: '3',
    name: 'Ethereum Tee',
    description:
      'Organic cotton t-shirt featuring Ethereum artwork. Available in multiple sizes.',
    price: 0.03,
    image: '/products/tee.svg',
    category: 'clothing',
    stock: 75,
  },
  {
    id: '4',
    name: 'Web3 Sticker Pack',
    description:
      'Set of 20 holographic vinyl stickers featuring popular crypto logos and memes.',
    price: 0.005,
    image: '/products/stickers.svg',
    category: 'accessories',
    stock: 200,
  },
  {
    id: '5',
    name: 'Hardware Wallet Case',
    description:
      'Premium leather case for hardware wallets. Fits all major brands with RFID protection.',
    price: 0.04,
    image: '/products/wallet-case.svg',
    category: 'accessories',
    stock: 30,
  },
  {
    id: '6',
    name: 'Blockchain Art Print',
    description:
      'Limited edition giclée print of generative blockchain art. Numbered and signed.',
    price: 0.15,
    image: '/products/art-print.svg',
    category: 'art',
    stock: 10,
  },
  {
    id: '7',
    name: 'DeFi Coffee Mug',
    description:
      'Ceramic mug with heat-reactive DeFi protocol logos that appear when hot liquid is added.',
    price: 0.015,
    image: '/products/mug.svg',
    category: 'accessories',
    stock: 60,
  },
  {
    id: '8',
    name: 'NFT Display Frame',
    description:
      'Digital frame for displaying NFTs. 10 inch HD screen with WiFi connectivity.',
    price: 0.25,
    image: '/products/frame.svg',
    category: 'tech',
    stock: 15,
  },
];
