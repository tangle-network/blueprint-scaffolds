import type { Order } from '@/types';

const orders: Order[] = [];

export function getOrders(walletAddress: string): Order[] {
  return orders.filter(
    (o) => o.walletAddress.toLowerCase() === walletAddress.toLowerCase()
  );
}

export function createOrder(
  walletAddress: string,
  items: { productId: string; name: string; price: number; quantity: number }[],
  currency: string
): Order {
  const total = items.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const order: Order = {
    id: crypto.randomUUID(),
    walletAddress,
    items,
    total,
    currency,
    status: 'pending',
    createdAt: new Date().toISOString(),
  };
  orders.push(order);
  return order;
}

export function completeOrder(orderId: string): Order | undefined {
  const order = orders.find((o) => o.id === orderId);
  if (order) order.status = 'completed';
  return order;
}
