import { ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useCart } from '@/context/CartContext';
import type { Product } from '@/types';

const productEmojis: Record<string, string> = {
  '1': '🧥',
  '2': '🧢',
  '3': '👕',
  '4': '🏷️',
  '5': '💼',
  '6': '🎨',
  '7': '☕',
  '8': '🖼️',
};

export function ProductCard({ product }: { product: Product }) {
  const { addItem } = useCart();

  return (
    <Card className="group overflow-hidden transition-shadow hover:shadow-lg">
      <div className="flex h-48 items-center justify-center bg-muted/50 text-6xl">
        {productEmojis[product.id] || '📦'}
      </div>
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between">
          <CardTitle className="text-lg">{product.name}</CardTitle>
          <span className="rounded-full bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">
            {product.category}
          </span>
        </div>
      </CardHeader>
      <CardContent className="pb-2">
        <p className="text-sm text-muted-foreground line-clamp-2">{product.description}</p>
        <div className="mt-3 flex items-baseline gap-2">
          <span className="text-2xl font-bold text-primary">{product.price} ETH</span>
          <span className="text-xs text-muted-foreground">
            (~${(product.price * 3500).toFixed(0)} USD)
          </span>
        </div>
        <p className="mt-1 text-xs text-muted-foreground">{product.stock} in stock</p>
      </CardContent>
      <CardFooter>
        <Button onClick={() => addItem(product)} className="w-full" disabled={product.stock === 0}>
          <ShoppingCart className="mr-2 h-4 w-4" />
          {product.stock === 0 ? 'Out of Stock' : 'Add to Cart'}
        </Button>
      </CardFooter>
    </Card>
  );
}
