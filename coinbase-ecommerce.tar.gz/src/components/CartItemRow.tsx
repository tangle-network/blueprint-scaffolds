import { Minus, Plus, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/context/CartContext';

export function CartItemRow({ item }: { item: import('@/types').CartItem }) {
  const { updateQuantity, removeItem } = useCart();

  return (
    <div className="flex items-center gap-4 py-4 border-b last:border-0">
      <div className="flex h-16 w-16 items-center justify-center rounded-md bg-muted text-2xl shrink-0">
        📦
      </div>
      <div className="flex-1 min-w-0">
        <h4 className="font-medium truncate">{item.product.name}</h4>
        <p className="text-sm text-muted-foreground">{item.product.price} ETH each</p>
      </div>
      <div className="flex items-center gap-2">
        <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => updateQuantity(item.product.id, item.quantity - 1)}>
          <Minus className="h-3 w-3" />
        </Button>
        <span className="w-8 text-center font-medium">{item.quantity}</span>
        <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => updateQuantity(item.product.id, item.quantity + 1)}>
          <Plus className="h-3 w-3" />
        </Button>
      </div>
      <div className="w-20 text-right">
        <span className="font-semibold">{(item.product.price * item.quantity).toFixed(4)} ETH</span>
      </div>
      <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => removeItem(item.product.id)}>
        <Trash2 className="h-4 w-4" />
      </Button>
    </div>
  );
}
