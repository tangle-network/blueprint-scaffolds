import { Link, useLocation } from 'react-router-dom';
import { ShoppingCart, Wallet, Store, ClipboardList, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useWallet } from '@/context/WalletContext';
import { useCart } from '@/context/CartContext';

export function Header() {
  const { address, connected, connect, disconnect } = useWallet();
  const { itemCount } = useCart();
  const location = useLocation();

  const shortAddr = address ? `${address.slice(0, 6)}...${address.slice(-4)}` : '';

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link to="/" className="flex items-center gap-2">
          <Store className="h-6 w-6 text-primary" />
          <span className="text-xl font-bold">CryptoStore</span>
        </Link>

        <nav className="flex items-center gap-4">
          {connected && (
            <Link to="/orders">
              <Button variant={location.pathname === '/orders' ? 'default' : 'ghost'} size="sm">
                <ClipboardList className="mr-2 h-4 w-4" />
                Orders
              </Button>
            </Link>
          )}

          <Link to="/cart" className="relative">
            <Button variant={location.pathname === '/cart' ? 'default' : 'ghost'} size="icon">
              <ShoppingCart className="h-5 w-5" />
              {itemCount > 0 && (
                <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                  {itemCount}
                </span>
              )}
            </Button>
          </Link>

          {connected ? (
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-2 rounded-md border px-3 py-1.5 text-sm">
                <Wallet className="h-4 w-4 text-green-500" />
                <span className="font-mono">{shortAddr}</span>
              </div>
              <Button variant="ghost" size="icon" onClick={disconnect} title="Disconnect wallet">
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <Button onClick={connect} size="sm">
              <Wallet className="mr-2 h-4 w-4" />
              Connect Wallet
            </Button>
          )}
        </nav>
      </div>
    </header>
  );
}
