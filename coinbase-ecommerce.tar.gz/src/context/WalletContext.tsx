import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import type { WalletState } from '@/types';

interface WalletContextType extends WalletState {
  connect: () => Promise<void>;
  disconnect: () => void;
}

const WalletContext = createContext<WalletContextType>({
  address: null,
  connected: false,
  chainId: null,
  connect: async () => {},
  disconnect: () => {},
});

export function WalletProvider({ children }: { children: ReactNode }) {
  const [wallet, setWallet] = useState<WalletState>({
    address: null,
    connected: false,
    chainId: null,
  });

  useEffect(() => {
    const saved = localStorage.getItem('walletAddress');
    if (saved) {
      setWallet({ address: saved, connected: true, chainId: 1 });
    }
  }, []);

  const connect = useCallback(async () => {
    if (typeof window !== 'undefined' && (window as unknown as Record<string, unknown>).ethereum) {
      try {
        const ethereum = (window as unknown as Record<string, unknown>).ethereum as {
          request: (args: { method: string; params?: unknown[] }) => Promise<unknown[]>;
          on?: (event: string, handler: (...args: unknown[]) => void) => void;
          getChainId?: () => Promise<string>;
        };
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' }) as string[];
        if (accounts.length > 0) {
          let chainId = 1;
          try {
            const rawChainId = await ethereum.getChainId?.();
            if (rawChainId) chainId = parseInt(rawChainId as string, 16) || 1;
          } catch {}
          const address = accounts[0] as string;
          setWallet({ address, connected: true, chainId });
          localStorage.setItem('walletAddress', address);
        }
      } catch (err) {
        console.error('Wallet connection failed:', err);
      }
    } else {
      const mockAddress = '0x' + Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
      setWallet({ address: mockAddress, connected: true, chainId: 1 });
      localStorage.setItem('walletAddress', mockAddress);
    }
  }, []);

  const disconnect = useCallback(() => {
    setWallet({ address: null, connected: false, chainId: null });
    localStorage.removeItem('walletAddress');
  }, []);

  return (
    <WalletContext.Provider value={{ ...wallet, connect, disconnect }}>
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  return useContext(WalletContext);
}
