import express from 'express';
import cors from 'cors';
import crypto from 'crypto';

const app = express();
app.use(cors());
app.use(express.json());

interface StoredProduct {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  stock: number;
}

interface StoredOrder {
  id: string;
  walletAddress: string;
  items: Array<{ productId: string; name: string; price: number; quantity: number }>;
  total: number;
  currency: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  chargeId: string;
  createdAt: string;
}

const products: StoredProduct[] = [
  { id: '1', name: 'Crypto Hoodie', description: 'Premium cotton hoodie with embroidered crypto logo. Comfortable and stylish for any occasion.', price: 0.05, image: '/products/hoodie.svg', category: 'clothing', stock: 50 },
  { id: '2', name: 'Bitcoin Cap', description: 'Adjustable snapback cap with Bitcoin embroidered patch. One size fits all.', price: 0.02, image: '/products/cap.svg', category: 'clothing', stock: 100 },
  { id: '3', name: 'Ethereum Tee', description: 'Organic cotton t-shirt featuring Ethereum artwork. Available in multiple sizes.', price: 0.03, image: '/products/tee.svg', category: 'clothing', stock: 75 },
  { id: '4', name: 'Web3 Sticker Pack', description: 'Set of 20 holographic vinyl stickers featuring popular crypto logos and memes.', price: 0.005, image: '/products/stickers.svg', category: 'accessories', stock: 200 },
  { id: '5', name: 'Hardware Wallet Case', description: 'Premium leather case for hardware wallets. Fits all major brands with RFID protection.', price: 0.04, image: '/products/wallet-case.svg', category: 'accessories', stock: 30 },
  { id: '6', name: 'Blockchain Art Print', description: 'Limited edition giclée print of generative blockchain art. Numbered and signed.', price: 0.15, image: '/products/art-print.svg', category: 'art', stock: 10 },
  { id: '7', name: 'DeFi Coffee Mug', description: 'Ceramic mug with heat-reactive DeFi protocol logos that appear when hot liquid is added.', price: 0.015, image: '/products/mug.svg', category: 'accessories', stock: 60 },
  { id: '8', name: 'NFT Display Frame', description: 'Digital frame for displaying NFTs. 10 inch HD screen with WiFi connectivity.', price: 0.25, image: '/products/frame.svg', category: 'tech', stock: 15 },
];

const orders: StoredOrder[] = [];

app.get('/api/products', (_req, res) => {
  res.json(products);
});

app.get('/api/products/:id', (req, res) => {
  const product = products.find((p) => p.id === req.params.id);
  if (!product) return res.status(404).json({ error: 'Product not found' });
  res.json(product);
});

app.post('/api/checkout', (req, res) => {
  const { walletAddress, items, currency } = req.body as {
    walletAddress: string;
    items: Array<{ productId: string; quantity: number }>;
    currency: string;
  };

  if (!walletAddress || !items?.length) {
    return res.status(400).json({ error: 'Wallet address and items required' });
  }

  const orderItems = items.map((item) => {
    const product = products.find((p) => p.id === item.productId);
    if (!product) throw new Error(`Product ${item.productId} not found`);
    return { productId: product.id, name: product.name, price: product.price, quantity: item.quantity };
  });

  const total = orderItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const orderId = crypto.randomUUID();
  const chargeId = `charge_${crypto.randomBytes(16).toString('hex')}`;

  const order: StoredOrder = {
    id: orderId,
    walletAddress,
    items: orderItems,
    total,
    currency: currency || 'ETH',
    status: 'pending',
    chargeId,
    createdAt: new Date().toISOString(),
  };

  orders.push(order);

  res.json({
    orderId: order.id,
    chargeId: order.chargeId,
    total: order.total,
    currency: order.currency,
    paymentUrl: `https://commerce.coinbase.com/charges/${chargeId}`,
    status: order.status,
  });
});

app.get('/api/orders/:walletAddress', (req, res) => {
  const walletOrders = orders.filter((o) => o.walletAddress.toLowerCase() === req.params.walletAddress.toLowerCase());
  res.json(walletOrders);
});

app.get('/api/orders/:walletAddress/:orderId', (req, res) => {
  const order = orders.find(
    (o) => o.walletAddress.toLowerCase() === req.params.walletAddress.toLowerCase() && o.id === req.params.orderId
  );
  if (!order) return res.status(404).json({ error: 'Order not found' });
  res.json(order);
});

app.post('/api/webhook/coinbase', (req, res) => {
  const signature = req.headers['x-cc-webhook-signature'] as string;
  if (!signature) {
    return res.status(400).json({ error: 'Missing signature' });
  }

  const event = req.body;
  const chargeId = event?.event?.data?.id;

  if (chargeId) {
    const order = orders.find((o) => o.chargeId === chargeId);
    if (order) {
      switch (event.event.type) {
        case 'charge:confirmed':
          order.status = 'confirmed';
          break;
        case 'charge:resolved':
          order.status = 'completed';
          break;
        case 'charge:failed':
          order.status = 'cancelled';
          break;
      }
    }
  }

  res.json({ received: true });
});

app.post('/api/orders/:orderId/simulate-payment', (req, res) => {
  const order = orders.find((o) => o.id === req.params.orderId);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  order.status = 'completed';
  res.json({ orderId: order.id, status: order.status });
});

const PORT = 3001;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

export default app;
