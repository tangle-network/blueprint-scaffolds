import { Outlet, Link, useLocation } from 'react-router-dom'
import { useState, useCallback } from 'react'
import { Wallet, Coins, Menu, X, LayoutDashboard, Users, FileText, Vote, Target } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Avatar } from '@/components/ui/avatar'
import Sidebar from '@/components/layout/Sidebar'
import { cn } from '@/lib/utils'
import { connectWallet, disconnect } from '@/lib/web3'

const MOBILE_NAV = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/creators', label: 'Creators', icon: Users },
  { to: '/tokens', label: 'Tokens', icon: Coins },
  { to: '/content', label: 'Content', icon: FileText },
  { to: '/governance', label: 'Governance', icon: Vote },
  { to: '/bounties', label: 'Bounties', icon: Target },
]

export default function MainLayout() {
  const [account, setAccount] = useState<string | null>(null)
  const [connecting, setConnecting] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const location = useLocation()

  const handleConnect = useCallback(async () => {
    if (account) {
      disconnect()
      setAccount(null)
      return
    }
    setConnecting(true)
    try {
      const addr = await connectWallet()
      setAccount(addr)
    } catch (err) {
      console.error('Wallet connection failed', err)
    } finally {
      setConnecting(false)
    }
  }, [account])

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />

      <div className="flex-1 flex flex-col min-w-0">
        <header className="sticky top-0 z-40 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="flex h-16 items-center justify-between px-4 md:px-6">
            <div className="flex items-center gap-3">
              <Link to="/dashboard" className="flex items-center gap-2 lg:hidden font-bold text-lg">
                <Coins className="h-5 w-5 text-primary" />
                <span>SocialToken</span>
              </Link>
              <button
                className="lg:hidden p-2 hover:bg-muted rounded-md"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </button>
            </div>

            <div className="flex items-center gap-3">
              {account && (
                <Avatar size="sm">{account.slice(0, 2).toUpperCase()}</Avatar>
              )}
              <Button onClick={handleConnect} disabled={connecting} variant={account ? 'outline' : 'default'} size="sm">
                <Wallet className="mr-2 h-4 w-4" />
                {connecting ? 'Connecting...' : account ? `${account.slice(0, 6)}...${account.slice(-4)}` : 'Connect Wallet'}
              </Button>
            </div>
          </div>

          {mobileMenuOpen && (
            <nav className="lg:hidden border-t bg-background p-2">
              {MOBILE_NAV.map((item) => (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={() => setMobileMenuOpen(false)}
                  className={cn(
                    'flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium',
                    location.pathname.startsWith(item.to)
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted-foreground hover:bg-muted'
                  )}
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </Link>
              ))}
            </nav>
          )}
        </header>

        <main className="flex-1 p-4 md:p-6 overflow-auto">
          <Outlet />
        </main>

        <footer className="border-t py-4 px-4 md:px-6">
          <p className="text-center text-xs text-muted-foreground">
            SocialToken Platform on Arbitrum — Powered by bonding curves & community
          </p>
        </footer>
      </div>
    </div>
  )
}
