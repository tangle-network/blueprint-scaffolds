export interface Creator {
  id: string
  name: string
  handle: string
  avatar: string
  bio: string
  tokenSymbol: string
  tokenAddress: string
  followerCount: number
  reputationScore: number
  verified: boolean
}

export interface CommunityToken {
  address: string
  name: string
  symbol: string
  creator: string
  supply: number
  marketCap: number
  price: number
  priceHistory: { timestamp: number; price: number }[]
  bondingCurveType: 'linear' | 'exponential' | 'polynomial' | 'sigmoid'
  reserveRatio: number
  createdAt: number
}

export interface BondingCurve {
  type: 'linear' | 'exponential' | 'polynomial' | 'sigmoid'
  basePrice: number
  reserveRatio: number
  maxSupply: number
  slope: number
}

export interface Content {
  id: string
  creatorId: string
  title: string
  body: string
  contentType: 'article' | 'video' | 'audio' | 'tutorial' | 'report'
  accessLevel: 'free' | 'token_gated' | 'paid'
  tokenGated: boolean
  requiredTokens: number
  createdAt: number
  likes: number
  views: number
}

export interface Proposal {
  id: string
  title: string
  description: string
  creator: string
  status: 'active' | 'passed' | 'failed' | 'executed'
  votesFor: number
  votesAgainst: number
  endDate: number
  quorum: number
}

export interface Bounty {
  id: string
  title: string
  description: string
  creator: string
  reward: number
  rewardToken: string
  status: 'open' | 'in_progress' | 'completed' | 'cancelled'
  assignee: string | null
  deadline: number
  submissions: number
}

export interface UserProfile {
  id: string
  name: string
  handle: string
  avatar: string
  walletAddress: string
  tokenHoldings: { symbol: string; amount: number; value: number }[]
  reputation: number
  contributions: number
}

export type { Creator as default }
