import { create } from 'zustand'
import type { Creator } from '@/types'

const MOCK_CREATORS: Creator[] = [
  {
    id: 'c1',
    name: 'CryptoAlina',
    handle: '@cryptoalina',
    avatar: '',
    bio: 'DeFi researcher and on-chain analyst. Breaking down complex tokenomics into actionable insights for the community.',
    tokenSymbol: 'ALINA',
    tokenAddress: '0xa1b2c3d4e5f6789012345678901234567890abcd',
    followerCount: 42300,
    reputationScore: 94,
    verified: true,
  },
  {
    id: 'c2',
    name: 'DeFi_Marcus',
    handle: '@defi_marcus',
    avatar: '',
    bio: 'Smart contract auditor and protocol architect. Building safer DeFi primitives on Arbitrum with 8 years of experience.',
    tokenSymbol: 'MARCUS',
    tokenAddress: '0xb2c3d4e5f6789012345678901234567890abcdef1',
    followerCount: 28700,
    reputationScore: 91,
    verified: true,
  },
  {
    id: 'c3',
    name: 'NFTJasmine',
    handle: '@nft_jasmine',
    avatar: '',
    bio: 'Generative artist exploring the intersection of code and canvas. Creator of the Chromatic Dreams collection.',
    tokenSymbol: 'JASMN',
    tokenAddress: '0xc3d4e5f6789012345678901234567890abcdef12',
    followerCount: 19500,
    reputationScore: 88,
    verified: true,
  },
  {
    id: 'c4',
    name: 'SolidityKai',
    handle: '@solidity_kai',
    avatar: '',
    bio: 'Core contributor to several major DeFi protocols. Passionate about gas optimization and formal verification.',
    tokenSymbol: 'KAI',
    tokenAddress: '0xd4e5f6789012345678901234567890abcdef1234',
    followerCount: 35100,
    reputationScore: 96,
    verified: true,
  },
  {
    id: 'c5',
    name: 'ChainRebecca',
    handle: '@chain_rebecca',
    avatar: '',
    bio: 'DAO strategist and governance researcher. Helping communities design token models that align incentives long-term.',
    tokenSymbol: 'REBECC',
    tokenAddress: '0xe5f6789012345678901234567890abcdef123456',
    followerCount: 15200,
    reputationScore: 82,
    verified: false,
  },
  {
    id: 'c6',
    name: 'ZKEthan',
    handle: '@zk_ethan',
    avatar: '',
    bio: 'Zero-knowledge proof researcher. Making privacy-preserving DeFi a reality through recursive SNARKs.',
    tokenSymbol: 'ZKETH',
    tokenAddress: '0xf6789012345678901234567890abcdef12345678',
    followerCount: 21400,
    reputationScore: 89,
    verified: true,
  },
  {
    id: 'c7',
    name: 'YieldMax_Olga',
    handle: '@yieldmax_olga',
    avatar: '',
    bio: 'Yield farming strategist sharing real-time DeFi opportunities. Former quantitative analyst at a top-tier hedge fund.',
    tokenSymbol: 'YOLGA',
    tokenAddress: '0x6789012345678901234567890abcdef1234567890',
    followerCount: 11800,
    reputationScore: 76,
    verified: false,
  },
  {
    id: 'c8',
    name: 'ArbDev_Priya',
    handle: '@arbdev_priya',
    avatar: '',
    bio: 'Arbitrum ecosystem builder. Maintaining open-source bridges and cross-chain messaging tools for L2 scaling.',
    tokenSymbol: 'PRIYA',
    tokenAddress: '0x789012345678901234567890abcdef12345678901',
    followerCount: 9300,
    reputationScore: 71,
    verified: false,
  },
]

interface CreatorStore {
  creators: Creator[]
  searchQuery: string
  setSearchQuery: (q: string) => void
  getFilteredCreators: () => Creator[]
}

export const useCreatorStore = create<CreatorStore>((set, get) => ({
  creators: MOCK_CREATORS,
  searchQuery: '',
  setSearchQuery: (q) => set({ searchQuery: q }),
  getFilteredCreators: () => {
    const { creators, searchQuery } = get()
    if (!searchQuery) return creators
    const q = searchQuery.toLowerCase()
    return creators.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.handle.toLowerCase().includes(q) ||
        c.tokenSymbol.toLowerCase().includes(q) ||
        c.bio.toLowerCase().includes(q)
    )
  },
}))
