import { create } from 'zustand'
import type { Proposal } from '@/types'

const MOCK_PROPOSALS: Proposal[] = [
  {
    id: 'p1',
    title: 'Allocate Treasury for Q3 Builder Grants Program',
    description: 'Distribute 150,000 KAI tokens across 10 builder grants of 15,000 KAI each to fund community-built tooling on Arbitrum. Grants are reviewed by a 5-member committee elected by token holders.',
    creator: 'c4',
    status: 'active',
    votesFor: 28400,
    votesAgainst: 6200,
    endDate: Date.now() + 86400000 * 3,
    quorum: 20000,
  },
  {
    id: 'p2',
    title: 'Migrate Liquidity Incentives to Concentated LP Positions',
    description: 'Shift 60% of farming emissions from standard Uniswap V3 LP positions to concentrated liquidity ranges. Backtest shows this increases capital efficiency by 3.2x and reduces impermanent loss by 18%.',
    creator: 'c1',
    status: 'active',
    votesFor: 15200,
    votesAgainst: 13100,
    endDate: Date.now() + 86400000 * 5,
    quorum: 15000,
  },
  {
    id: 'p3',
    title: 'Adopt ERC-7201 Namespaced Storage for All Future Upgrades',
    description: 'Require all new proxy implementations to use ERC-7201 storage slots, preventing storage collisions during upgrades. This is a breaking change for existing proxy admins and requires a migration script.',
    creator: 'c2',
    status: 'active',
    votesFor: 41000,
    votesAgainst: 3200,
    endDate: Date.now() + 86400000 * 2,
    quorum: 25000,
  },
  {
    id: 'p4',
    title: 'Fund Cross-Chain Bridge Audit with Trail of Bits',
    description: 'Approve 80,000 USDC from the treasury for a full security audit of the L2<>L1 bridge contracts by Trail of Bits. The audit scope covers 4,200 lines of Solidity and includes a 2-week fuzzing engagement.',
    creator: 'c8',
    status: 'active',
    votesFor: 19700,
    votesAgainst: 4100,
    endDate: Date.now() + 86400000 * 4,
    quorum: 18000,
  },
]

interface GovernanceStore {
  proposals: Proposal[]
  getActiveProposals: () => Proposal[]
}

export const useGovernanceStore = create<GovernanceStore>((set, get) => ({
  proposals: MOCK_PROPOSALS,
  getActiveProposals: () => get().proposals.filter((p) => p.status === 'active'),
}))
