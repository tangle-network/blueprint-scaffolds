import { create } from 'zustand'
import type { CommunityToken } from '@/types'

function generatePriceHistory(basePrice: number, days: number): { timestamp: number; price: number }[] {
  const history: { timestamp: number; price: number }[] = []
  let price = basePrice * 0.6
  for (let i = days; i >= 0; i--) {
    const drift = (Math.random() - 0.4) * basePrice * 0.08
    price = Math.max(basePrice * 0.1, Math.min(basePrice * 2.5, price + drift))
    history.push({ timestamp: Date.now() - i * 86400000, price: Number(price.toFixed(4)) })
  }
  return history
}

const MOCK_TOKENS: CommunityToken[] = [
  {
    address: '0xa1b2c3d4e5f6789012345678901234567890abcd',
    name: 'Alina Coin',
    symbol: 'ALINA',
    creator: 'c1',
    supply: 1000000,
    marketCap: 2450000,
    price: 2.45,
    priceHistory: generatePriceHistory(2.45, 30),
    bondingCurveType: 'exponential',
    reserveRatio: 0.35,
    createdAt: Date.now() - 86400000 * 90,
  },
  {
    address: '0xb2c3d4e5f6789012345678901234567890abcdef1',
    name: 'Marcus DeFi',
    symbol: 'MARCUS',
    creator: 'c2',
    supply: 5000000,
    marketCap: 412500,
    price: 0.0825,
    priceHistory: generatePriceHistory(0.0825, 30),
    bondingCurveType: 'linear',
    reserveRatio: 0.5,
    createdAt: Date.now() - 86400000 * 120,
  },
  {
    address: '0xc3d4e5f6789012345678901234567890abcdef12',
    name: 'Jasmine Art',
    symbol: 'JASMN',
    creator: 'c3',
    supply: 750000,
    marketCap: 937500,
    price: 1.25,
    priceHistory: generatePriceHistory(1.25, 30),
    bondingCurveType: 'polynomial',
    reserveRatio: 0.25,
    createdAt: Date.now() - 86400000 * 60,
  },
  {
    address: '0xd4e5f6789012345678901234567890abcdef1234',
    name: 'Kai Protocol',
    symbol: 'KAI',
    creator: 'c4',
    supply: 2000000,
    marketCap: 1890000,
    price: 0.945,
    priceHistory: generatePriceHistory(0.945, 30),
    bondingCurveType: 'exponential',
    reserveRatio: 0.4,
    createdAt: Date.now() - 86400000 * 150,
  },
  {
    address: '0xe5f6789012345678901234567890abcdef123456',
    name: 'Rebecca DAO',
    symbol: 'REBECC',
    creator: 'c5',
    supply: 3000000,
    marketCap: 150000,
    price: 0.05,
    priceHistory: generatePriceHistory(0.05, 30),
    bondingCurveType: 'linear',
    reserveRatio: 0.5,
    createdAt: Date.now() - 86400000 * 30,
  },
  {
    address: '0xf6789012345678901234567890abcdef12345678',
    name: 'ZK Ethan',
    symbol: 'ZKETH',
    creator: 'c6',
    supply: 500000,
    marketCap: 625000,
    price: 1.25,
    priceHistory: generatePriceHistory(1.25, 30),
    bondingCurveType: 'sigmoid',
    reserveRatio: 0.3,
    createdAt: Date.now() - 86400000 * 45,
  },
  {
    address: '0x6789012345678901234567890abcdef1234567890',
    name: 'Yield Olga',
    symbol: 'YOLGA',
    creator: 'c7',
    supply: 8000000,
    marketCap: 960000,
    price: 0.12,
    priceHistory: generatePriceHistory(0.12, 30),
    bondingCurveType: 'polynomial',
    reserveRatio: 0.45,
    createdAt: Date.now() - 86400000 * 75,
  },
  {
    address: '0x789012345678901234567890abcdef12345678901',
    name: 'Priya Build',
    symbol: 'PRIYA',
    creator: 'c8',
    supply: 1200000,
    marketCap: 54000,
    price: 0.045,
    priceHistory: generatePriceHistory(0.045, 30),
    bondingCurveType: 'linear',
    reserveRatio: 0.5,
    createdAt: Date.now() - 86400000 * 15,
  },
]

interface TokenStore {
  tokens: CommunityToken[]
  selectedTokenAddress: string | null
  setSelectedToken: (address: string | null) => void
  getSelectedToken: () => CommunityToken | undefined
  getTopTokens: (limit?: number) => CommunityToken[]
}

export const useTokenStore = create<TokenStore>((set, get) => ({
  tokens: MOCK_TOKENS,
  selectedTokenAddress: null,
  setSelectedToken: (address) => set({ selectedTokenAddress: address }),
  getSelectedToken: () => {
    const { tokens, selectedTokenAddress } = get()
    if (!selectedTokenAddress) return undefined
    return tokens.find((t) => t.address === selectedTokenAddress)
  },
  getTopTokens: (limit = 5) => {
    return [...get().tokens].sort((a, b) => b.marketCap - a.marketCap).slice(0, limit)
  },
}))
