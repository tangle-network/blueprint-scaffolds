import { create } from 'zustand'
import type { Content } from '@/types'

const MOCK_CONTENT: Content[] = [
  {
    id: 'ct1',
    creatorId: 'c1',
    title: 'Analyzing Arbitrum Sequencer Economics After Dencun',
    body: 'The Dencun upgrade reduced L2 data costs by over 90%, fundamentally changing the sequencer profit model. In this analysis I break down the new fee revenue streams, how sequencer batching efficiency improved, and what it means for ARB token holders going forward.',
    contentType: 'article',
    accessLevel: 'free',
    tokenGated: false,
    requiredTokens: 0,
    createdAt: Date.now() - 86400000 * 1,
    likes: 312,
    views: 8450,
  },
  {
    id: 'ct2',
    creatorId: 'c2',
    title: 'Advanced Reentrancy Patterns: Beyond the Checks-Effects-Interactions Guard',
    body: 'Most Solidity devs know the standard reentrancy defense, but cross-function and cross-contract reentrancy vectors remain underexplored. This deep-dive covers real exploits from 2025 audits and presents a formal verification approach using Halmos.',
    contentType: 'tutorial',
    accessLevel: 'token_gated',
    tokenGated: true,
    requiredTokens: 200,
    createdAt: Date.now() - 86400000 * 3,
    likes: 187,
    views: 4200,
  },
  {
    id: 'ct3',
    creatorId: 'c3',
    title: 'Chromatic Dreams Season 2: Generative Algorithm Breakdown',
    body: 'I used a custom Perlin noise implementation combined with HSL color rotation to produce the 500-piece Season 2 drop. Each token seeds its noise field from the holder wallet address, making every piece mathematically unique.',
    contentType: 'report',
    accessLevel: 'token_gated',
    tokenGated: true,
    requiredTokens: 50,
    createdAt: Date.now() - 86400000 * 5,
    likes: 256,
    views: 6100,
  },
  {
    id: 'ct4',
    creatorId: 'c4',
    title: 'Gas Golfing in Solidity 0.8.28: A Practical Benchmark Suite',
    body: 'With the new transient storage opcodes and MCOPY, gas optimization entered a new era. I benchmarked 14 common patterns including Uniswap V4 hooks, ERC-7201 namespaced storage, and batch Merkle proofs, measuring exact gas savings against 0.8.20 compiled code.',
    contentType: 'article',
    accessLevel: 'free',
    tokenGated: false,
    requiredTokens: 0,
    createdAt: Date.now() - 86400000 * 2,
    likes: 421,
    views: 12300,
  },
  {
    id: 'ct5',
    creatorId: 'c6',
    title: 'Building Privacy-Preserving AMMs with Recursive SNARKs',
    body: 'Standard DEX designs leak trader intent through the mempool. This research demonstrates a Constant Product AMM where swap amounts and token addresses are proven valid inside a zk-SNARK, while the on-chain state only reveals a commitment root.',
    contentType: 'report',
    accessLevel: 'paid',
    tokenGated: false,
    requiredTokens: 0,
    createdAt: Date.now() - 86400000 * 7,
    likes: 89,
    views: 2100,
  },
  {
    id: 'ct6',
    creatorId: 'c5',
    title: 'Token Engineering Framework for Quadratic Funding DAOs',
    body: 'Quadratic funding amplifies small donations, but sybil resistance and collusion remain hard. I present a token-weighted reputation framework that uses soul-bound tokens from Gitcoin Passport scores to gate matching pool allocations.',
    contentType: 'article',
    accessLevel: 'free',
    tokenGated: false,
    requiredTokens: 0,
    createdAt: Date.now() - 86400000 * 4,
    likes: 143,
    views: 3800,
  },
]

interface ContentStore {
  content: Content[]
  filter: 'all' | 'free' | 'token_gated' | 'paid'
  setFilter: (f: 'all' | 'free' | 'token_gated' | 'paid') => void
  getFilteredContent: () => Content[]
}

export const useContentStore = create<ContentStore>((set, get) => ({
  content: MOCK_CONTENT,
  filter: 'all',
  setFilter: (f) => set({ filter: f }),
  getFilteredContent: () => {
    const { content, filter } = get()
    if (filter === 'all') return content
    return content.filter((c) => c.accessLevel === filter)
  },
}))
