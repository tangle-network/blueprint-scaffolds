import { Routes, Route, Navigate } from 'react-router-dom'
import MainLayout from '@/components/layout/MainLayout'
import Dashboard from '@/pages/Dashboard'
import Creators from '@/pages/Creators'
import TokenTrading from '@/pages/TokenTrading'
import ContentPage from '@/pages/ContentPage'
import GovernancePage from '@/pages/GovernancePage'
import BountiesPage from '@/pages/BountiesPage'
import CreateTokenPage from '@/pages/CreateTokenPage'
import TokenDetailPage from '@/pages/TokenDetailPage'
import CreatorProfilePage from '@/pages/CreatorProfilePage'
import HomePage from '@/pages/HomePage'

export default function App() {
  return (
    <Routes>
      <Route element={<MainLayout />}>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/creators" element={<Creators />} />
        <Route path="/tokens" element={<TokenTrading />} />
        <Route path="/token/:address" element={<TokenDetailPage />} />
        <Route path="/creator/:address" element={<CreatorProfilePage />} />
        <Route path="/content" element={<ContentPage />} />
        <Route path="/governance" element={<GovernancePage />} />
        <Route path="/bounties" element={<BountiesPage />} />
        <Route path="/create" element={<CreateTokenPage />} />
        <Route path="/home" element={<HomePage />} />
      </Route>
    </Routes>
  )
}
