// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

library MathUtils {
    uint256 internal constant PRECISION = 1e18;

    function mulDown(uint256 a, uint256 b) internal pure returns (uint256) {
        return (a * b) / PRECISION;
    }

    function divDown(uint256 a, uint256 b) internal pure returns (uint256) {
        return (a * PRECISION) / b;
    }

    function sqrt(uint256 x) internal pure returns (uint256 z) {
        if (x == 0) return 0;
        z = x;
        uint256 y = (x + 1) / 2;
        while (y < z) {
            z = y;
            y = (x / y + y) / 2;
        }
    }
}
