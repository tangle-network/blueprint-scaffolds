// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract ReputationSystem {
    struct UserProfile {
        uint256 reputationScore;
        uint256 totalTipsSent;
        uint256 totalTipsReceived;
        uint256 bountiesCompleted;
        uint256 bountiesCreated;
        uint256 contentCreated;
        bool exists;
    }

    mapping(address => UserProfile) public profiles;
    address[] public users;

    mapping(address => mapping(address => bool)) public hasEndorsed;
    mapping(address => uint256) public endorsementCount;

    address public owner;

    event ReputationUpdated(address indexed user, uint256 newScore, string reason);
    event UserRegistered(address indexed user);
    event Endorsed(address indexed from, address indexed to);

    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }

    constructor() {
        owner = msg.sender;
    }

    function registerUser() external {
        require(!profiles[msg.sender].exists, "Already registered");
        profiles[msg.sender].exists = true;
        profiles[msg.sender].reputationScore = 100;
        users.push(msg.sender);
        emit UserRegistered(msg.sender);
    }

    function addReputation(address user, uint256 amount, string calldata reason) external onlyOwner {
        require(profiles[user].exists, "User not registered");
        profiles[user].reputationScore += amount;
        emit ReputationUpdated(user, profiles[user].reputationScore, reason);
    }

    function removeReputation(address user, uint256 amount, string calldata reason) external onlyOwner {
        require(profiles[user].exists, "User not registered");
        if (profiles[user].reputationScore > amount) {
            profiles[user].reputationScore -= amount;
        } else {
            profiles[user].reputationScore = 0;
        }
        emit ReputationUpdated(user, profiles[user].reputationScore, reason);
    }

    function recordTipSent(address sender) external onlyOwner {
        profiles[sender].totalTipsSent++;
    }

    function recordTipReceived(address receiver) external onlyOwner {
        profiles[receiver].totalTipsReceived++;
    }

    function recordBountyCompleted(address hunter) external onlyOwner {
        profiles[hunter].bountiesCompleted++;
        profiles[hunter].reputationScore += 50;
        emit ReputationUpdated(hunter, profiles[hunter].reputationScore, "Bounty completed");
    }

    function recordBountyCreated(address creator) external onlyOwner {
        profiles[creator].bountiesCreated++;
    }

    function recordContentCreated(address creator) external onlyOwner {
        profiles[creator].contentCreated++;
        profiles[creator].reputationScore += 10;
        emit ReputationUpdated(creator, profiles[creator].reputationScore, "Content created");
    }

    function endorse(address user) external {
        require(profiles[msg.sender].exists, "Not registered");
        require(profiles[user].exists, "Target not registered");
        require(msg.sender != user, "Cannot self-endorse");
        require(!hasEndorsed[msg.sender][user], "Already endorsed");

        hasEndorsed[msg.sender][user] = true;
        endorsementCount[user]++;
        profiles[user].reputationScore += 5;

        emit Endorsed(msg.sender, user);
        emit ReputationUpdated(user, profiles[user].reputationScore, "Endorsed");
    }

    function getProfile(address user) external view returns (
        uint256 reputationScore,
        uint256 totalTipsSent,
        uint256 totalTipsReceived,
        uint256 bountiesCompleted,
        uint256 bountiesCreated,
        uint256 contentCreated,
        bool exists
    ) {
        UserProfile storage p = profiles[user];
        return (p.reputationScore, p.totalTipsSent, p.totalTipsReceived, p.bountiesCompleted, p.bountiesCreated, p.contentCreated, p.exists);
    }

    function getUserCount() external view returns (uint256) {
        return users.length;
    }

    function getLeaderboard(uint256 limit) external view returns (address[] memory, uint256[] memory) {
        uint256 count = users.length;
        if (limit < count) count = limit;

        address[] memory topUsers = new address[](count);
        uint256[] memory scores = new uint256[](count);

        for (uint256 i = 0; i < count; i++) {
            topUsers[i] = users[i];
            scores[i] = profiles[users[i]].reputationScore;
        }

        for (uint256 i = 0; i < count; i++) {
            for (uint256 j = i + 1; j < count; j++) {
                if (scores[j] > scores[i]) {
                    (scores[i], scores[j]) = (scores[j], scores[i]);
                    (topUsers[i], topUsers[j]) = (topUsers[j], topUsers[i]);
                }
            }
        }

        return (topUsers, scores);
    }
}
