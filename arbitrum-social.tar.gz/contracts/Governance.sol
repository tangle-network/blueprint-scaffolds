// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/access/Ownable.sol";

contract Governance is Ownable {
    struct Proposal {
        uint256 id;
        address proposer;
        string description;
        uint256 forVotes;
        uint256 againstVotes;
        uint256 deadline;
        bool executed;
        bool cancelled;
        ProposalState state;
    }

    enum ProposalState { Active, Defeated, Succeeded, Executed, Cancelled }

    mapping(uint256 => Proposal) public proposals;
    mapping(uint256 => mapping(address => bool)) public hasVoted;
    mapping(uint256 => mapping(address => bool)) public voteChoice;
    mapping(address => uint256) public votingPower;

    address public token;
    uint256 public proposalCount;
    uint256 public votingPeriod;
    uint256 public quorumBps;

    event ProposalCreated(uint256 indexed proposalId, address indexed proposer, string description, uint256 deadline);
    event Voted(uint256 indexed proposalId, address indexed voter, bool support, uint256 weight);
    event ProposalExecuted(uint256 indexed proposalId);
    event ProposalCancelled(uint256 indexed proposalId);
    event VotingPowerUpdated(address indexed voter, uint256 power);

    constructor(address _token, uint256 _votingPeriod, uint256 _quorumBps) Ownable(msg.sender) {
        token = _token;
        votingPeriod = _votingPeriod;
        quorumBps = _quorumBps;
    }

    function createProposal(string calldata description) external returns (uint256) {
        require(votingPower[msg.sender] > 0, "No voting power");
        require(bytes(description).length > 0, "Description required");

        uint256 proposalId = proposalCount++;
        uint256 deadline = block.timestamp + votingPeriod;

        proposals[proposalId] = Proposal({
            id: proposalId,
            proposer: msg.sender,
            description: description,
            forVotes: 0,
            againstVotes: 0,
            deadline: deadline,
            executed: false,
            cancelled: false,
            state: ProposalState.Active
        });

        emit ProposalCreated(proposalId, msg.sender, description, deadline);
        return proposalId;
    }

    function vote(uint256 proposalId, bool support) external {
        Proposal storage proposal = proposals[proposalId];
        require(proposal.state == ProposalState.Active, "Not active");
        require(block.timestamp < proposal.deadline, "Voting ended");
        require(!hasVoted[proposalId][msg.sender], "Already voted");
        require(votingPower[msg.sender] > 0, "No voting power");

        uint256 weight = votingPower[msg.sender];
        hasVoted[proposalId][msg.sender] = true;
        voteChoice[proposalId][msg.sender] = support;

        if (support) {
            proposal.forVotes += weight;
        } else {
            proposal.againstVotes += weight;
        }

        emit Voted(proposalId, msg.sender, support, weight);
    }

    function executeProposal(uint256 proposalId) external {
        Proposal storage proposal = proposals[proposalId];
        require(proposal.state == ProposalState.Active, "Not active");
        require(block.timestamp >= proposal.deadline, "Voting not ended");

        uint256 totalVotes = proposal.forVotes + proposal.againstVotes;
        require(totalVotes > 0, "No votes");

        uint256 quorum = (quorumBps * totalVotes) / 10000;

        if (proposal.forVotes > proposal.againstVotes && proposal.forVotes >= quorum) {
            proposal.state = ProposalState.Succeeded;
        } else {
            proposal.state = ProposalState.Defeated;
        }

        proposal.executed = true;
        emit ProposalExecuted(proposalId);
    }

    function cancelProposal(uint256 proposalId) external {
        Proposal storage proposal = proposals[proposalId];
        require(proposal.proposer == msg.sender || msg.sender == owner(), "Not authorized");
        require(proposal.state == ProposalState.Active, "Not active");

        proposal.state = ProposalState.Cancelled;
        proposal.cancelled = true;
        emit ProposalCancelled(proposalId);
    }

    function updateVotingPower(address voter, uint256 power) external {
        votingPower[voter] = power;
        emit VotingPowerUpdated(voter, power);
    }

    function getProposalState(uint256 proposalId) external view returns (ProposalState) {
        Proposal storage proposal = proposals[proposalId];
        if (proposal.cancelled) return ProposalState.Cancelled;
        if (proposal.executed) return proposal.state;
        if (block.timestamp >= proposal.deadline) {
            uint256 totalVotes = proposal.forVotes + proposal.againstVotes;
            if (proposal.forVotes > proposal.againstVotes) {
                return ProposalState.Succeeded;
            }
            return ProposalState.Defeated;
        }
        return ProposalState.Active;
    }
}
