// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract Tipping {
    struct Tip {
        uint256 id;
        address from;
        address to;
        uint256 amount;
        string message;
        uint256 timestamp;
        address token;
    }

    Tip[] public tips;
    mapping(address => uint256) public totalTipsSent;
    mapping(address => uint256) public totalTipsReceived;
    mapping(address => uint256[]) public userTips;

    address public owner;
    uint256 public platformFeeBps;
    address public platformTreasury;

    event TipSent(uint256 indexed tipId, address indexed from, address indexed to, uint256 amount, address token);
    event PlatformFeeCollected(uint256 amount);

    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }

    constructor(uint256 _feeBps, address _treasury) {
        owner = msg.sender;
        platformFeeBps = _feeBps;
        platformTreasury = _treasury;
    }

    function tip(address to, string calldata message) external payable returns (uint256) {
        require(msg.value > 0, "No value sent");
        require(to != address(0), "Invalid recipient");
        require(to != msg.sender, "Cannot tip self");

        uint256 fee = (msg.value * platformFeeBps) / 10000;
        uint256 netAmount = msg.value - fee;

        if (fee > 0) {
            (bool feeSuccess, ) = platformTreasury.call{value: fee}("");
            require(feeSuccess, "Fee transfer failed");
            emit PlatformFeeCollected(fee);
        }

        (bool success, ) = to.call{value: netAmount}("");
        require(success, "Tip transfer failed");

        uint256 tipId = tips.length;
        tips.push(Tip({
            id: tipId,
            from: msg.sender,
            to: to,
            amount: netAmount,
            message: message,
            timestamp: block.timestamp,
            token: address(0)
        }));

        totalTipsSent[msg.sender]++;
        totalTipsReceived[to]++;
        userTips[msg.sender].push(tipId);
        userTips[to].push(tipId);

        emit TipSent(tipId, msg.sender, to, netAmount, address(0));
        return tipId;
    }

    function getTip(uint256 tipId) external view returns (
        address from,
        address to,
        uint256 amount,
        string memory message,
        uint256 timestamp,
        address token
    ) {
        Tip storage t = tips[tipId];
        return (t.from, t.to, t.amount, t.message, t.timestamp, t.token);
    }

    function getUserTips(address user) external view returns (uint256[] memory) {
        return userTips[user];
    }

    function getRecentTips(uint256 limit) external view returns (Tip[] memory) {
        uint256 total = tips.length;
        if (limit > total) limit = total;

        Tip[] memory result = new Tip[](limit);
        for (uint256 i = 0; i < limit; i++) {
            result[i] = tips[total - 1 - i];
        }
        return result;
    }

    function setPlatformFee(uint256 _bps) external onlyOwner {
        require(_bps <= 500, "Max 5%");
        platformFeeBps = _bps;
    }

    function setTreasury(address _treasury) external onlyOwner {
        require(_treasury != address(0), "Zero address");
        platformTreasury = _treasury;
    }

    receive() external payable {}
}
