// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IBondingCurve {
    function getPurchasePrice(uint256 supply, uint256 amount) external pure returns (uint256);
    function getSalePrice(uint256 supply, uint256 amount) external pure returns (uint256);
    function getCurvePrice(uint256 supply) external pure returns (uint256);
}
