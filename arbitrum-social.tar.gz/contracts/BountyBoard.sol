// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract BountyBoard {
    struct Bounty {
        uint256 id;
        address creator;
        string title;
        string description;
        uint256 reward;
        address assignee;
        BountyStatus status;
        uint256 createdAt;
        uint256 deadline;
        string[] submissions;
    }

    enum BountyStatus { Open, Assigned, InProgress, UnderReview, Completed, Cancelled }

    mapping(uint256 => Bounty) public bounties;
    uint256 public nextBountyId;
    address public owner;
    address public reputationSystem;

    event BountyCreated(uint256 indexed bountyId, address indexed creator, uint256 reward, uint256 deadline);
    event BountyAssigned(uint256 indexed bountyId, address indexed assignee);
    event BountySubmitted(uint256 indexed bountyId, address indexed submitter, string submission);
    event BountyCompleted(uint256 indexed bountyId, address indexed hunter, uint256 reward);
    event BountyCancelled(uint256 indexed bountyId);
    event BountyReviewed(uint256 indexed bountyId, bool approved);

    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }

    constructor(address _reputationSystem) {
        owner = msg.sender;
        reputationSystem = _reputationSystem;
    }

    function createBounty(
        string calldata title,
        string calldata description,
        uint256 deadline
    ) external payable returns (uint256) {
        require(msg.value > 0, "Reward required");
        require(bytes(title).length > 0, "Title required");
        require(deadline > block.timestamp, "Invalid deadline");

        uint256 bountyId = nextBountyId++;
        bounties[bountyId] = Bounty({
            id: bountyId,
            creator: msg.sender,
            title: title,
            description: description,
            reward: msg.value,
            assignee: address(0),
            status: BountyStatus.Open,
            createdAt: block.timestamp,
            deadline: deadline,
            submissions: new string[](0)
        });

        emit BountyCreated(bountyId, msg.sender, msg.value, deadline);
        return bountyId;
    }

    function assignBounty(uint256 bountyId, address hunter) external {
        Bounty storage bounty = bounties[bountyId];
        require(bounty.status == BountyStatus.Open, "Not open");
        require(bounty.creator == msg.sender || msg.sender == owner, "Not authorized");
        require(hunter != address(0), "Invalid hunter");

        bounty.assignee = hunter;
        bounty.status = BountyStatus.Assigned;
        emit BountyAssigned(bountyId, hunter);
    }

    function startWork(uint256 bountyId) external {
        Bounty storage bounty = bounties[bountyId];
        require(bounty.assignee == msg.sender, "Not assigned");
        require(bounty.status == BountyStatus.Assigned, "Not assigned state");
        bounty.status = BountyStatus.InProgress;
    }

    function submitWork(uint256 bountyId, string calldata submission) external {
        Bounty storage bounty = bounties[bountyId];
        require(bounty.assignee == msg.sender, "Not assigned");
        require(
            bounty.status == BountyStatus.InProgress || bounty.status == BountyStatus.UnderReview,
            "Invalid state"
        );
        require(bytes(submission).length > 0, "Submission required");

        bounty.submissions.push(submission);
        bounty.status = BountyStatus.UnderReview;
        emit BountySubmitted(bountyId, msg.sender, submission);
    }

    function reviewSubmission(uint256 bountyId, bool approved) external {
        Bounty storage bounty = bounties[bountyId];
        require(bounty.creator == msg.sender || msg.sender == owner, "Not authorized");
        require(bounty.status == BountyStatus.UnderReview, "Not under review");

        if (approved) {
            bounty.status = BountyStatus.Completed;
            (bool success, ) = bounty.assignee.call{value: bounty.reward}("");
            require(success, "Payment failed");
            emit BountyCompleted(bountyId, bounty.assignee, bounty.reward);
        } else {
            bounty.status = BountyStatus.InProgress;
            emit BountyReviewed(bountyId, false);
        }
    }

    function cancelBounty(uint256 bountyId) external {
        Bounty storage bounty = bounties[bountyId];
        require(bounty.creator == msg.sender, "Not creator");
        require(bounty.status == BountyStatus.Open || bounty.status == BountyStatus.Assigned, "Cannot cancel");

        bounty.status = BountyStatus.Cancelled;
        (bool success, ) = bounty.creator.call{value: bounty.reward}("");
        require(success, "Refund failed");

        emit BountyCancelled(bountyId);
    }

    function getBountySubmissions(uint256 bountyId) external view returns (string[] memory) {
        return bounties[bountyId].submissions;
    }

    function getOpenBounties(uint256 limit) external view returns (uint256[] memory) {
        uint256 count = 0;
        for (uint256 i = 0; i < nextBountyId && count < limit; i++) {
            if (bounties[i].status == BountyStatus.Open) count++;
        }

        uint256[] memory result = new uint256[](count);
        uint256 idx = 0;
        for (uint256 i = 0; i < nextBountyId && idx < count; i++) {
            if (bounties[i].status == BountyStatus.Open) {
                result[idx++] = i;
            }
        }
        return result;
    }
}
