// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "./IBondingCurve.sol";

contract SocialToken is ERC20, Ownable {
    IBondingCurve public bondingCurve;
    address public factory;
    address public creator;
    uint256 public creatorBasisPoints;
    bool public transferLocked;

    event TokensPurchased(address indexed buyer, uint256 amount, uint256 cost);
    event TokensSold(address indexed seller, uint256 amount, uint256 refund);
    event CreatorBasisPointsUpdated(uint256 newBasisPoints);

    modifier onlyFactoryOrCreator() {
        require(msg.sender == factory || msg.sender == creator, "Not authorized");
        _;
    }

    constructor(
        string memory name_,
        string memory symbol_,
        address creator_,
        address bondingCurve_,
        uint256 creatorBasisPoints_
    ) ERC20(name_, symbol_) Ownable(creator_) {
        creator = creator_;
        factory = msg.sender;
        bondingCurve = IBondingCurve(bondingCurve_);
        creatorBasisPoints = creatorBasisPoints_;
    }

    function buy(uint256 amount) external payable {
        require(amount > 0, "Amount must be > 0");
        uint256 cost = bondingCurve.getPurchasePrice(totalSupply(), amount);
        require(msg.value >= cost, "Insufficient payment");

        _mint(msg.sender, amount);

        if (creatorBasisPoints > 0) {
            uint256 creatorFee = (cost * creatorBasisPoints) / 10000;
            (bool success, ) = creator.call{value: creatorFee}("");
            require(success, "Creator fee transfer failed");
        }

        uint256 refund = msg.value - cost;
        if (refund > 0) {
            (bool success, ) = msg.sender.call{value: refund}("");
            require(success, "Refund failed");
        }

        emit TokensPurchased(msg.sender, amount, cost);
    }

    function sell(uint256 amount) external {
        require(amount > 0, "Amount must be > 0");
        require(balanceOf(msg.sender) >= amount, "Insufficient balance");

        uint256 salePrice = bondingCurve.getSalePrice(totalSupply(), amount);

        _burn(msg.sender, amount);

        (bool success, ) = msg.sender.call{value: salePrice}("");
        require(success, "Sale transfer failed");

        emit TokensSold(msg.sender, amount, salePrice);
    }

    function setCreatorBasisPoints(uint256 _basisPoints) external onlyFactoryOrCreator {
        require(_basisPoints <= 1000, "Max 10%");
        creatorBasisPoints = _basisPoints;
        emit CreatorBasisPointsUpdated(_basisPoints);
    }

    function setBondingCurve(address _bondingCurve) external onlyFactoryOrCreator {
        bondingCurve = IBondingCurve(_bondingCurve);
    }

    receive() external payable {}
}
