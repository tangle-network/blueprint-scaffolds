// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/access/Ownable.sol";

contract AccessControl is Ownable {
    struct Content {
        address creator;
        string contentHash;
        uint256 minTokensRequired;
        bool isActive;
        uint256 createdAt;
        ContentType contentType;
    }

    enum ContentType { Article, Video, Audio, Image, File, Stream }

    mapping(uint256 => Content) public contents;
    mapping(address => mapping(uint256 => bool)) public hasAccess;
    mapping(address => uint256[]) public creatorContentIds;
    uint256 public nextContentId;

    event ContentCreated(uint256 indexed contentId, address indexed creator, ContentType contentType, uint256 minTokens);
    event AccessGranted(address indexed user, uint256 indexed contentId);
    event AccessRevoked(address indexed user, uint256 indexed contentId);
    event ContentDeactivated(uint256 indexed contentId);

    mapping(address => address) public tokenRegistry;

    constructor() Ownable(msg.sender) {}

    function registerToken(address token) external {
        tokenRegistry[msg.sender] = token;
    }

    function createContent(
        string calldata contentHash,
        uint256 minTokensRequired,
        ContentType contentType
    ) external returns (uint256) {
        require(bytes(contentHash).length > 0, "Hash required");

        uint256 contentId = nextContentId++;
        contents[contentId] = Content({
            creator: msg.sender,
            contentHash: contentHash,
            minTokensRequired: minTokensRequired,
            isActive: true,
            createdAt: block.timestamp,
            contentType: contentType
        });
        creatorContentIds[msg.sender].push(contentId);

        emit ContentCreated(contentId, msg.sender, contentType, minTokensRequired);
        return contentId;
    }

    function grantAccess(uint256 contentId) external {
        require(contents[contentId].isActive, "Content not active");
        hasAccess[msg.sender][contentId] = true;
        emit AccessGranted(msg.sender, contentId);
    }

    function revokeAccess(uint256 contentId) external {
        hasAccess[msg.sender][contentId] = false;
        emit AccessRevoked(msg.sender, contentId);
    }

    function checkAccess(address user, uint256 contentId) external view returns (bool) {
        return hasAccess[user][contentId];
    }

    function getContent(uint256 contentId) external view returns (
        address creator,
        string memory contentHash,
        uint256 minTokensRequired,
        bool isActive,
        uint256 createdAt,
        ContentType contentType
    ) {
        Content storage c = contents[contentId];
        return (c.creator, c.contentHash, c.minTokensRequired, c.isActive, c.createdAt, c.contentType);
    }

    function getCreatorContent(address creator) external view returns (uint256[] memory) {
        return creatorContentIds[creator];
    }

    function deactivateContent(uint256 contentId) external {
        require(contents[contentId].creator == msg.sender, "Not creator");
        contents[contentId].isActive = false;
        emit ContentDeactivated(contentId);
    }
}
