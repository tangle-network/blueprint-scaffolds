// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract RevenueDistributor {
    struct RevenuePool {
        address token;
        uint256 totalRevenue;
        uint256 claimedRevenue;
        mapping(address => uint256) shares;
        mapping(address => uint256) claimed;
        address[] recipients;
    }

    address public owner;
    mapping(address => RevenuePool) public pools;
    address[] public poolTokens;

    event RevenueDeposited(address indexed token, uint256 amount);
    event RevenueClaimed(address indexed token, address indexed recipient, uint256 amount);
    event SharesUpdated(address indexed token, address[] recipients, uint256[] shares);

    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }

    constructor() {
        owner = msg.sender;
    }

    function createPool(address token, address[] calldata recipients, uint256[] calldata shares) external onlyOwner {
        require(recipients.length == shares.length, "Length mismatch");
        require(recipients.length > 0, "No recipients");

        RevenuePool storage pool = pools[token];
        pool.token = token;
        pool.recipients = recipients;
        poolTokens.push(token);

        for (uint256 i = 0; i < recipients.length; i++) {
            pool.shares[recipients[i]] = shares[i];
        }

        emit SharesUpdated(token, recipients, shares);
    }

    function depositRevenue(address token) external payable {
        require(msg.value > 0, "No value sent");
        RevenuePool storage pool = pools[token];
        require(pool.recipients.length > 0, "Pool not found");
        pool.totalRevenue += msg.value;
        emit RevenueDeposited(token, msg.value);
    }

    function claimRevenue(address token) external {
        RevenuePool storage pool = pools[token];
        uint256 pending = getPendingRevenue(token, msg.sender);
        require(pending > 0, "No pending revenue");

        pool.claimed[msg.sender] += pending;
        pool.claimedRevenue += pending;

        (bool success, ) = msg.sender.call{value: pending}("");
        require(success, "Transfer failed");

        emit RevenueClaimed(token, msg.sender, pending);
    }

    function getPendingRevenue(address token, address recipient) public view returns (uint256) {
        RevenuePool storage pool = pools[token];
        if (pool.shares[recipient] == 0) return 0;
        uint256 totalShares = _totalShares(token);
        uint256 unclaimed = pool.totalRevenue - pool.claimedRevenue;
        uint256 recipientShare = (unclaimed * pool.shares[recipient]) / totalShares;
        uint256 alreadyClaimed = pool.claimed[recipient];
        if (recipientShare > alreadyClaimed) {
            return recipientShare - alreadyClaimed;
        }
        return 0;
    }

    function updateShares(address token, address[] calldata recipients, uint256[] calldata shares) external onlyOwner {
        require(recipients.length == shares.length, "Length mismatch");
        RevenuePool storage pool = pools[token];
        pool.recipients = recipients;
        for (uint256 i = 0; i < recipients.length; i++) {
            pool.shares[recipients[i]] = shares[i];
        }
        emit SharesUpdated(token, recipients, shares);
    }

    function _totalShares(address token) internal view returns (uint256 total) {
        RevenuePool storage pool = pools[token];
        for (uint256 i = 0; i < pool.recipients.length; i++) {
            total += pool.shares[pool.recipients[i]];
        }
    }

    receive() external payable {}
}
