// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./IBondingCurve.sol";
import "./MathUtils.sol";

contract LinearBondingCurve is IBondingCurve {
    uint256 public immutable slope;
    uint256 public immutable basePrice;

    constructor(uint256 _slope, uint256 _basePrice) {
        slope = _slope;
        basePrice = _basePrice;
    }

    function getCurvePrice(uint256 supply) public view override returns (uint256) {
        return basePrice + MathUtils.mulDown(slope, supply * MathUtils.PRECISION);
    }

    function getPurchasePrice(uint256 supply, uint256 amount) external pure override returns (uint256) {
        uint256 startPrice = supply * MathUtils.PRECISION;
        uint256 endPrice = (supply + amount) * MathUtils.PRECISION;
        uint256 avgPrice = (startPrice + endPrice) / 2;
        return MathUtils.mulDown(avgPrice, amount * MathUtils.PRECISION);
    }

    function getSalePrice(uint256 supply, uint256 amount) external pure override returns (uint256) {
        require(supply >= amount, "Insufficient supply");
        uint256 startPrice = supply * MathUtils.PRECISION;
        uint256 endPrice = (supply - amount) * MathUtils.PRECISION;
        uint256 avgPrice = (startPrice + endPrice) / 2;
        return MathUtils.mulDown(avgPrice, amount * MathUtils.PRECISION);
    }
}
