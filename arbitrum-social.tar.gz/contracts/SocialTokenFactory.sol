// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./SocialToken.sol";
import "./LinearBondingCurve.sol";

contract SocialTokenFactory {
    address[] public allTokens;
    mapping(address => address[]) public creatorTokens;
    mapping(address => bool) public isTokenCreated;
    address[] public bondingCurves;

    uint256 public defaultSlope;
    uint256 public defaultBasePrice;
    uint256 public protocolFeeBps;
    address public protocolTreasury;

    event TokenCreated(
        address indexed token,
        address indexed creator,
        string name,
        string symbol,
        address bondingCurve,
        uint256 creatorBps
    );
    event BondingCurveCreated(address indexed curve, uint256 slope, uint256 basePrice);
    event ProtocolFeeUpdated(uint256 newFee);
    event TreasuryUpdated(address newTreasury);

    constructor(uint256 _slope, uint256 _basePrice, uint256 _protocolFeeBps, address _treasury) {
        defaultSlope = _slope;
        defaultBasePrice = _basePrice;
        protocolFeeBps = _protocolFeeBps;
        protocolTreasury = _treasury;
    }

    function createToken(
        string calldata name,
        string calldata symbol,
        uint256 creatorBps
    ) external returns (address) {
        require(creatorBps <= 1000, "Max 10% creator fee");
        require(bytes(name).length > 0, "Name required");
        require(bytes(symbol).length > 0, "Symbol required");

        LinearBondingCurve curve = new LinearBondingCurve(defaultSlope, defaultBasePrice);
        bondingCurves.push(address(curve));

        SocialToken token = new SocialToken(
            name,
            symbol,
            msg.sender,
            address(curve),
            creatorBps
        );

        allTokens.push(address(token));
        creatorTokens[msg.sender].push(address(token));
        isTokenCreated[address(token)] = true;

        emit TokenCreated(address(token), msg.sender, name, symbol, address(curve), creatorBps);
        emit BondingCurveCreated(address(curve), defaultSlope, defaultBasePrice);

        return address(token);
    }

    function createTokenWithCustomCurve(
        string calldata name,
        string calldata symbol,
        uint256 creatorBps,
        uint256 slope,
        uint256 basePrice
    ) external returns (address) {
        require(creatorBps <= 1000, "Max 10% creator fee");

        LinearBondingCurve curve = new LinearBondingCurve(slope, basePrice);
        bondingCurves.push(address(curve));

        SocialToken token = new SocialToken(
            name,
            symbol,
            msg.sender,
            address(curve),
            creatorBps
        );

        allTokens.push(address(token));
        creatorTokens[msg.sender].push(address(token));
        isTokenCreated[address(token)] = true;

        emit TokenCreated(address(token), msg.sender, name, symbol, address(curve), creatorBps);
        emit BondingCurveCreated(address(curve), slope, basePrice);

        return address(token);
    }

    function getTokenCount() external view returns (uint256) {
        return allTokens.length;
    }

    function getCreatorTokens(address creator) external view returns (address[] memory) {
        return creatorTokens[creator];
    }

    function getAllTokens(uint256 offset, uint256 limit) external view returns (address[] memory) {
        uint256 total = allTokens.length;
        if (offset >= total) return new address[](0);

        uint256 end = offset + limit;
        if (end > total) end = total;

        address[] memory result = new address[](end - offset);
        for (uint256 i = offset; i < end; i++) {
            result[i - offset] = allTokens[i];
        }
        return result;
    }

    function setProtocolFee(uint256 _bps) external {
        require(msg.sender == protocolTreasury, "Only treasury");
        require(_bps <= 500, "Max 5%");
        protocolFeeBps = _bps;
        emit ProtocolFeeUpdated(_bps);
    }

    function setTreasury(address _treasury) external {
        require(msg.sender == protocolTreasury, "Only treasury");
        require(_treasury != address(0), "Zero address");
        protocolTreasury = _treasury;
        emit TreasuryUpdated(_treasury);
    }
}
