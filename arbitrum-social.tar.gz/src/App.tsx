import React from 'react'
import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom'
import Home from './pages/Home'
import TokenDetail from './pages/TokenDetail'
import CreateToken from './pages/CreateToken'
import Portfolio from './pages/Portfolio'

const App: React.FC = () => {
  return (
    <BrowserRouter>
      <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
        <nav style={{
          display: 'flex',
          gap: '1rem',
          padding: '1rem 2rem',
          borderBottom: '1px solid #e0e0e0',
          alignItems: 'center',
        }}>
          <h1 style={{ fontSize: '1.25rem', fontWeight: 'bold', marginRight: '2rem' }}>
            Social Token Platform
          </h1>
          {[
            { to: '/', label: 'Explore' },
            { to: '/create', label: 'Create Token' },
            { to: '/portfolio', label: 'Portfolio' },
          ].map(({ to, label }) => (
            <NavLink
              key={to}
              to={to}
              end={to === '/'}
              style={({ isActive }) => ({
                padding: '0.5rem 1rem',
                borderRadius: '6px',
                background: isActive ? '#0077cc' : 'transparent',
                color: isActive ? '#fff' : '#213547',
                fontWeight: isActive ? 600 : 400,
              })}
            >
              {label}
            </NavLink>
          ))}
        </nav>
        <main style={{ flex: 1, padding: '2rem', maxWidth: '1200px', width: '100%', margin: '0 auto' }}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/token/:address" element={<TokenDetail />} />
            <Route path="/create" element={<CreateToken />} />
            <Route path="/portfolio" element={<Portfolio />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  )
}

export default App
