import { useState, useCallback } from 'react'
import { Routes, Route, Link, useLocation } from 'react-router-dom'
import { Wallet, Home, Coins, FileText, Vote, Target, PlusCircle, User } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Avatar } from '@/components/ui/avatar'
import { formatAddress } from '@/lib/utils'
import { connectWallet, disconnect } from '@/lib/web3'
import HomePage from '@/pages/HomePage'
import TokenDetailPage from '@/pages/TokenDetailPage'
import CreatorProfilePage from '@/pages/CreatorProfilePage'
import ContentPage from '@/pages/ContentPage'
import GovernancePage from '@/pages/GovernancePage'
import BountiesPage from '@/pages/BountiesPage'
import CreateTokenPage from '@/pages/CreateTokenPage'

export default function App() {
  const [account, setAccount] = useState<string | null>(null)
  const [connecting, setConnecting] = useState(false)
  const location = useLocation()

  const handleConnect = useCallback(async () => {
    if (account) {
      disconnect()
      setAccount(null)
      return
    }
    setConnecting(true)
    try {
      const addr = await connectWallet()
      setAccount(addr)
    } catch (err) {
      console.error('Wallet connection failed', err)
    } finally {
      setConnecting(false)
    }
  }, [account])

  const navItems = [
    { to: '/', label: 'Home', icon: Home },
    { to: '/content', label: 'Content', icon: FileText },
    { to: '/governance', label: 'Governance', icon: Vote },
    { to: '/bounties', label: 'Bounties', icon: Target },
    { to: '/create', label: 'Create Token', icon: PlusCircle },
  ]

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <Link to="/" className="flex items-center gap-2 font-bold text-xl">
            <Coins className="h-6 w-6 text-primary" />
            <span>SocialToken</span>
          </Link>

          <nav className="hidden md:flex items-center gap-6">
            {navItems.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className={`flex items-center gap-1.5 text-sm font-medium transition-colors hover:text-primary ${
                  location.pathname === item.to ? 'text-primary' : 'text-muted-foreground'
                }`}
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            {account && (
              <Link to={`/creator/${account}`}>
                <Avatar size="sm">{account.slice(0, 2).toUpperCase()}</Avatar>
              </Link>
            )}
            <Button onClick={handleConnect} disabled={connecting} variant={account ? 'outline' : 'default'} size="sm">
              <Wallet className="mr-2 h-4 w-4" />
              {connecting ? 'Connecting...' : account ? formatAddress(account) : 'Connect Wallet'}
            </Button>
          </div>
        </div>
      </header>

      <nav className="md:hidden border-b bg-background">
        <div className="container mx-auto flex items-center gap-1 px-2 py-2 overflow-x-auto">
          {navItems.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={`flex items-center gap-1 rounded-md px-3 py-1.5 text-xs font-medium whitespace-nowrap ${
                location.pathname === item.to
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:bg-muted'
              }`}
            >
              <item.icon className="h-3 w-3" />
              {item.label}
            </Link>
          ))}
        </div>
      </nav>

      <main className="container mx-auto px-4 py-6">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/token/:address" element={<TokenDetailPage />} />
          <Route path="/creator/:address" element={<CreatorProfilePage />} />
          <Route path="/content" element={<ContentPage />} />
          <Route path="/governance" element={<GovernancePage />} />
          <Route path="/bounties" element={<BountiesPage />} />
          <Route path="/create" element={<CreateTokenPage />} />
        </Routes>
      </main>

      <footer className="border-t py-8 mt-12">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>SocialToken Platform on Arbitrum</p>
          <p className="mt-1">Powered by bonding curves & community</p>
        </div>
      </footer>
    </div>
  )
}
