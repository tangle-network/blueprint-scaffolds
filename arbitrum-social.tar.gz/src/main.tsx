import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App";
import { WalletProvider } from "./contexts/WalletContext";
import { TokenProvider } from "./contexts/TokenContext";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <BrowserRouter>
      <WalletProvider>
        <TokenProvider>
          <App />
        </TokenProvider>
      </WalletProvider>
    </BrowserRouter>
  </React.StrictMode>
);
