import React from 'react'
import { SocialTokenData } from '../types'

interface TokenCardProps {
  token: SocialTokenData
}

const TokenCard: React.FC<TokenCardProps> = ({ token }) => {
  return (
    <div
      style={{
        border: '1px solid #e0e0e0',
        borderRadius: '12px',
        padding: '1.5rem',
        transition: 'box-shadow 0.2s',
      }}
      onMouseEnter={(e) => (e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.1)')}
      onMouseLeave={(e) => (e.currentTarget.style.boxShadow = 'none')}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
        <div
          style={{
            width: '48px',
            height: '48px',
            borderRadius: '50%',
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#fff',
            fontWeight: 'bold',
            fontSize: '1.1rem',
          }}
        >
          {token.symbol.slice(0, 2)}
        </div>
        <div>
          <h3 style={{ margin: 0 }}>{token.name}</h3>
          <span style={{ color: '#666', fontSize: '0.875rem' }}>${token.symbol}</span>
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem', fontSize: '0.875rem' }}>
        <div>
          <span style={{ color: '#888' }}>Price</span>
          <div style={{ fontWeight: 600 }}>{token.price} ETH</div>
        </div>
        <div>
          <span style={{ color: '#888' }}>Market Cap</span>
          <div style={{ fontWeight: 600 }}>{token.marketCap} ETH</div>
        </div>
        <div>
          <span style={{ color: '#888' }}>Holders</span>
          <div style={{ fontWeight: 600 }}>{token.holders}</div>
        </div>
        <div>
          <span style={{ color: '#888' }}>Supply</span>
          <div style={{ fontWeight: 600 }}>{Number(token.totalSupply).toLocaleString()}</div>
        </div>
      </div>
    </div>
  )
}

export default TokenCard
