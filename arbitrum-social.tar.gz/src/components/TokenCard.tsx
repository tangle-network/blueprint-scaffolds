import { Link } from 'react-router-dom'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { TrendingUp, Users } from 'lucide-react'
import type { TokenInfo } from '@/lib/types'

interface TokenCardProps {
  token: TokenInfo
}

export default function TokenCard({ token }: TokenCardProps) {
  return (
    <Link to={`/token/${token.address}`}>
      <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
        <CardContent className="p-5">
          <div className="flex items-start justify-between mb-3">
            <div>
              <h3 className="font-semibold text-lg">{token.name}</h3>
              <p className="text-sm text-muted-foreground">{token.symbol}</p>
            </div>
            <Badge variant={token.type === 'personal' ? 'outline' : 'default'}>{token.type}</Badge>
          </div>
          <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{token.description}</p>
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-1">
              <TrendingUp className="h-4 w-4 text-green-500" />
              <span className="font-medium">${token.price}</span>
            </div>
            <div className="flex items-center gap-1 text-muted-foreground">
              <Users className="h-4 w-4" />
              <span>{token.holders}</span>
            </div>
            <span className="text-muted-foreground">MC: ${Number(token.marketCap).toLocaleString()}</span>
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}
