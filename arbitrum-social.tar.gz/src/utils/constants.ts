export const ARBITRUM_CHAIN_ID = 42161

export const FACTORY_ADDRESS = '0x0000000000000000000000000000000000000000' as const

export const ERC20_ABI = [
  'function name() view returns (string)',
  'function symbol() view returns (string)',
  'function totalSupply() view returns (uint256)',
  'function balanceOf(address) view returns (uint256)',
  'function decimals() view returns (uint8)',
] as const

export const FACTORY_ABI = [
  'function createToken(string name, string symbol, uint256 creatorBps) returns (address)',
  'function createTokenWithCustomCurve(string name, string symbol, uint256 creatorBps, uint256 slope, uint256 basePrice) returns (address)',
  'function allTokens(uint256) view returns (address)',
  'function getTokenCount() view returns (uint256)',
  'function getCreatorTokens(address) view returns (address[])',
  'function getAllTokens(uint256 offset, uint256 limit) view returns (address[])',
  'event TokenCreated(address indexed token, address indexed creator, string name, string symbol, address bondingCurve, uint256 creatorBps)',
] as const

export const SOCIAL_TOKEN_ABI = [
  'function buy(uint256 amount) payable',
  'function sell(uint256 amount)',
  'function bondingCurve() view returns (address)',
  'function creator() view returns (address)',
  'function creatorBasisPoints() view returns (uint256)',
  'function name() view returns (string)',
  'function symbol() view returns (string)',
  'function totalSupply() view returns (uint256)',
  'function balanceOf(address) view returns (uint256)',
  'event TokensPurchased(address indexed buyer, uint256 amount, uint256 cost)',
  'event TokensSold(address indexed seller, uint256 amount, uint256 refund)',
] as const

export const BONDING_CURVE_ABI = [
  'function getPurchasePrice(uint256 supply, uint256 amount) view returns (uint256)',
  'function getSalePrice(uint256 supply, uint256 amount) view returns (uint256)',
  'function getCurvePrice(uint256 supply) view returns (uint256)',
  'function slope() view returns (uint256)',
  'function basePrice() view returns (uint256)',
] as const
