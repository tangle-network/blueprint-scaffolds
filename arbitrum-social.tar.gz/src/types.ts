export interface SocialTokenData {
  address: string
  name: string
  symbol: string
  creator: string
  totalSupply: string
  marketCap: string
  price: string
  holders: number
  image?: string
}

export interface BondingCurveState {
  currentPrice: string
  tokensSold: string
  reserveBalance: string
  curveType: 'linear' | 'exponential'
}

export interface PortfolioEntry {
  token: SocialTokenData
  balance: string
  value: string
}
