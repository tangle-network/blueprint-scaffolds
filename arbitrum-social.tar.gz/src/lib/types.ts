export interface CreatorProfile {
  address: string;
  name: string;
  bio: string;
  avatar: string;
  bannerImage: string;
  tokenAddress: string;
  tokenSymbol: string;
  tokenName: string;
  holdersCount: number;
  marketCap: number;
  totalSupply: number;
  reputationScore: number;
  contentCount: number;
  followersCount: number;
  verified: boolean;
  createdAt: number;
  curveType: CurveType;
}

export type CurveType = "linear" | "exponential" | "logarithmic" | "s_curve";

export interface SocialToken {
  address: string;
  name: string;
  symbol: string;
  creator: string;
  creatorAddress: string;
  totalSupply: number;
  circulatingSupply: number;
  reserveBalance: number;
  marketCap: number;
  price: number;
  priceChange24h: number;
  holdersCount: number;
  volume24h: number;
  curveType: CurveType;
  curveParams: CurveParams;
  createdAt: number;
  isCommunity: boolean;
}

export interface CurveParams {
  basePrice: number;
  slope: number;
  exponent?: number;
  inflectionPoint?: number;
}

export interface ContentItem {
  id: string;
  creatorAddress: string;
  creatorName: string;
  creatorAvatar: string;
  title: string;
  description: string;
  content: string;
  contentType: "article" | "video" | "audio" | "image" | "exclusive";
  isGated: boolean;
  tokenThreshold: number;
  tokenAddress: string;
  tokenSymbol: string;
  likes: number;
  comments: number;
  tips: number;
  tipAmount: number;
  createdAt: number;
  tags: string[];
}

export interface GovernanceProposal {
  id: string;
  tokenAddress: string;
  tokenName: string;
  title: string;
  description: string;
  proposer: string;
  proposerName: string;
  status: "active" | "passed" | "failed" | "executed";
  votesFor: number;
  votesAgainst: number;
  votesAbstain: number;
  totalVotes: number;
  quorum: number;
  startDate: number;
  endDate: number;
  executionData: string;
}

export interface Bounty {
  id: string;
  tokenAddress: string;
  tokenName: string;
  tokenSymbol: string;
  creatorAddress: string;
  creatorName: string;
  creatorAvatar: string;
  title: string;
  description: string;
  reward: number;
  rewardToken: string;
  rewardTokenSymbol: string;
  status: "open" | "in_progress" | "completed" | "cancelled";
  assignee?: string;
  assigneeName?: string;
  submissions: BountySubmission[];
  deadline: number;
  tags: string[];
  createdAt: number;
}

export interface BountySubmission {
  id: string;
  bountyId: string;
  submitter: string;
  submitterName: string;
  description: string;
  evidence: string;
  submittedAt: number;
  accepted: boolean;
}

export interface ReputationEntry {
  address: string;
  score: number;
  rank: string;
  tokensHeld: number;
  proposalsCreated: number;
  proposalsVoted: number;
  bountiesCompleted: number;
  contentCreated: number;
  tipsReceived: number;
  tipsGiven: number;
  badges: Badge[];
  history: ReputationEvent[];
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  earnedAt: number;
}

export interface ReputationEvent {
  type: "token_bought" | "content_published" | "bounty_completed" | "proposal_voted" | "tip_received";
  points: number;
  timestamp: number;
  description: string;
}

export interface RevenueShare {
  recipient: string;
  recipientName: string;
  percentage: number;
  amount: number;
  lastClaimed: number;
}

export interface TradeOrder {
  type: "buy" | "sell";
  tokenAddress: string;
  tokenSymbol: string;
  amount: number;
  price: number;
  total: number;
  timestamp: number;
  txHash: string;
}
