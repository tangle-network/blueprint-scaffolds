export interface TokenInfo {
  address: string
  name: string
  symbol: string
  type: 'personal' | 'community'
  creator: string
  totalSupply: string
  price: string
  marketCap: string
  holders: number
  curveType: string
  createdAt: number
  logoURI?: string
  description?: string
}

export interface CreatorProfile {
  address: string
  name: string
  bio: string
  avatar: string
  tokenAddress?: string
  tokenSymbol?: string
  followers: number
  reputation: number
  contentCount: number
  joinedAt: number
}

export interface ContentItem {
  id: string
  creator: string
  creatorName: string
  title: string
  description: string
  contentHash: string
  accessType: 'free' | 'token_gated' | 'paid'
  requiredTokens: number
  price: string
  createdAt: number
  likes: number
  category: string
}

export interface Proposal {
  id: string
  tokenAddress: string
  title: string
  description: string
  proposer: string
  forVotes: number
  againstVotes: number
  status: 'active' | 'passed' | 'failed' | 'executed'
  startDate: number
  endDate: number
}

export interface Bounty {
  id: string
  creator: string
  title: string
  description: string
  reward: string
  tokenSymbol: string
  tokenAddress: string
  status: 'open' | 'in_progress' | 'completed' | 'cancelled'
  assignee?: string
  deadline: number
  createdAt: number
  submissions: number
}

export interface RevenueShare {
  recipient: string
  share: number
  totalEarned: string
  pendingClaim: string
}

export interface TradeHistory {
  timestamp: number
  price: number
  volume: number
  type: 'buy' | 'sell'
}
