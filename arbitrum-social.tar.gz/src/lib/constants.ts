export const ARBITRUM_CHAIN_ID = 42161;
export const ARBITRUM_RPC_URL = "https://arb1.arbitrum.io/rpc";
export const ARBITRUM_EXPLORER = "https://arbiscan.io";

export const CURVE_TYPES = {
  linear: { label: "Linear", description: "Price increases at a constant rate per token" },
  exponential: { label: "Exponential", description: "Price increases exponentially with supply" },
  logarithmic: { label: "Logarithmic", description: "Price increases quickly at first, then levels off" },
  s_curve: { label: "S-Curve", description: "Slow start, rapid middle growth, then stabilization" },
} as const;

export const TOKEN_THRESHOLD_TIERS = [
  { label: "Bronze", min: 1, icon: "🥉" },
  { label: "Silver", min: 10, icon: "🥈" },
  { label: "Gold", min: 50, icon: "🥇" },
  { label: "Diamond", min: 100, icon: "💎" },
  { label: "Whale", min: 500, icon: "🐋" },
] as const;

export const REPUTATION_RANKS = [
  { name: "Newcomer", minScore: 0 },
  { name: "Member", minScore: 100 },
  { name: "Contributor", minScore: 500 },
  { name: "Veteran", minScore: 1000 },
  { name: "Champion", minScore: 5000 },
  { name: "Legend", minScore: 10000 },
] as const;

export const DEFAULT_CURVE_PARAMS = {
  linear: { basePrice: 0.001, slope: 0.0001 },
  exponential: { basePrice: 0.001, slope: 0.0001, exponent: 1.5 },
  logarithmic: { basePrice: 0.001, slope: 0.01 },
  s_curve: { basePrice: 0.001, slope: 0.001, inflectionPoint: 500000 },
};
