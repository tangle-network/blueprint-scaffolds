import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatAddress(address: string): string {
  return `${address.slice(0, 6)}...${address.slice(-4)}`
}

export function formatEther(value: bigint): string {
  const str = value.toString()
  if (str.length <= 18) return `0.${str.padStart(18, '0').replace(/0+$/, '')}`
  const int = str.slice(0, -18)
  const dec = str.slice(-18).replace(/0+$/, '')
  return dec ? `${int}.${dec}` : int
}

export function parseEther(value: string): bigint {
  const [int, dec = ''] = value.split('.')
  const paddedDec = dec.padEnd(18, '0').slice(0, 18)
  return BigInt(int + paddedDec)
}
