import { ethers } from "ethers";
import { ARBITRUM_CHAIN_ID, ARBITRUM_RPC_URL } from "./constants";

export async function connectWallet(): Promise<string | null> {
  if (!(window as Record<string, unknown>).ethereum) return null;
  try {
    const accounts = await (window as Record<string, unknown>).ethereum.request?.({
      method: "eth_requestAccounts",
    }) as string[];
    return accounts?.[0] ?? null;
  } catch {
    return null;
  }
}

export function getProvider(): ethers.JsonRpcProvider {
  return new ethers.JsonRpcProvider(ARBITRUM_RPC_URL);
}

export function getSigner(): ethers.JsonRpcSigner | null {
  const ethereum = (window as Record<string, unknown>).ethereum;
  if (!ethereum) return null;
  const provider = new ethers.BrowserProvider(ethereum as ethers.Eip1193Provider);
  return provider.getSigner();
}

export async function switchToArbitrum(): Promise<boolean> {
  const ethereum = (window as Record<string, unknown>).ethereum;
  if (!ethereum) return false;
  try {
    await ethereum.request?.({
      method: "wallet_switchEthereumChain",
      params: [{ chainId: `0x${ARBITRUM_CHAIN_ID.toString(16)}` }],
    });
    return true;
  } catch {
    return false;
  }
}

export function getExplorerUrl(hash: string, type: "tx" | "address" | "token" = "tx"): string {
  return `https://arbiscan.io/${type}/${hash}`;
}
