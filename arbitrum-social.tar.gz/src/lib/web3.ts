import { ethers } from 'ethers'
import { ARBITRUM_CHAIN_ID, ARBITRUM_RPC } from './constants'

let provider: ethers.BrowserProvider | null = null
let signer: ethers.JsonRpcSigner | null = null

export async function getProvider(): Promise<ethers.BrowserProvider> {
  if (provider) return provider
  if (typeof window === 'undefined' || !window.ethereum) {
    throw new Error('No wallet detected')
  }
  provider = new ethers.BrowserProvider(window.ethereum)
  return provider
}

export async function getSigner(): Promise<ethers.JsonRpcSigner> {
  if (signer) return signer
  const p = await getProvider()
  signer = await p.getSigner()
  return signer
}

export async function connectWallet(): Promise<string> {
  const p = await getProvider()
  const accounts = await p.send('eth_requestAccounts', [])
  signer = await p.getSigner()
  return accounts[0]
}

export async function getChainId(): Promise<number> {
  const p = await getProvider()
  const network = await p.getNetwork()
  return Number(network.chainId)
}

export async function switchToArbitrum(): Promise<void> {
  if (!window.ethereum) throw new Error('No wallet detected')
  await window.ethereum.request({
    method: 'wallet_switchEthereumChain',
    params: [{ chainId: `0x${ARBITRUM_CHAIN_ID.toString(16)}` }],
  })
}

export function getReadOnlyProvider(): ethers.JsonRpcProvider {
  return new ethers.JsonRpcProvider(ARBITRUM_RPC)
}

export function disconnect(): void {
  provider = null
  signer = null
}
