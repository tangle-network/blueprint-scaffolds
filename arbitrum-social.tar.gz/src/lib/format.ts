export function shortenAddress(address: string, chars: number = 4): string {
  return `${address.slice(0, chars + 2)}...${address.slice(-chars)}`;
}

export function formatEth(value: number, decimals: number = 4): string {
  if (value === 0) return "0";
  if (value < 0.0001) return "<0.0001";
  return value.toFixed(decimals);
}

export function formatUsd(value: number): string {
  if (value === 0) return "$0";
  if (value < 0.01) return "<$0.01";
  if (value >= 1_000_000) return `$${(value / 1_000_000).toFixed(2)}M`;
  if (value >= 1_000) return `$${(value / 1_000).toFixed(2)}K`;
  return `$${value.toFixed(2)}`;
}

export function formatNumber(value: number): string {
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}M`;
  if (value >= 1_000) return `${(value / 1_000).toFixed(1)}K`;
  return value.toFixed(0);
}

export function timeAgo(timestamp: number): string {
  const seconds = Math.floor(Date.now() / 1000 - timestamp);
  if (seconds < 60) return "just now";
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  if (seconds < 2592000) return `${Math.floor(seconds / 86400)}d ago`;
  return new Date(timestamp * 1000).toLocaleDateString();
}

export function getTokenTier(held: number): { label: string; icon: string } {
  if (held >= 500) return { label: "Whale", icon: "🐋" };
  if (held >= 100) return { label: "Diamond", icon: "💎" };
  if (held >= 50) return { label: "Gold", icon: "🥇" };
  if (held >= 10) return { label: "Silver", icon: "🥈" };
  if (held >= 1) return { label: "Bronze", icon: "🥉" };
  return { label: "None", icon: "·" };
}

export function getReputationRank(score: number): string {
  if (score >= 10000) return "Legend";
  if (score >= 5000) return "Champion";
  if (score >= 1000) return "Veteran";
  if (score >= 500) return "Contributor";
  if (score >= 100) return "Member";
  return "Newcomer";
}
