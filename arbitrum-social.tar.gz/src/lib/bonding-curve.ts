import type { CurveType, CurveParams } from "./types";

export function calculateBuyPrice(
  curveType: CurveType,
  params: CurveParams,
  currentSupply: number,
  amount: number
): number {
  const startSupply = currentSupply;
  const endSupply = currentSupply + amount;
  return curveIntegral(curveType, params, endSupply) - curveIntegral(curveType, params, startSupply);
}

export function calculateSellPrice(
  curveType: CurveType,
  params: CurveParams,
  currentSupply: number,
  amount: number
): number {
  const endSupply = Math.max(0, currentSupply - amount);
  return curveIntegral(curveType, params, currentSupply) - curveIntegral(curveType, params, endSupply);
}

export function calculateSpotPrice(
  curveType: CurveType,
  params: CurveParams,
  currentSupply: number
): number {
  switch (curveType) {
    case "linear":
      return params.basePrice + params.slope * currentSupply;
    case "exponential":
      return params.basePrice + params.slope * Math.pow(currentSupply, params.exponent ?? 1.5);
    case "logarithmic":
      return params.basePrice + params.slope * Math.log(currentSupply + 1);
    case "s_curve": {
      const k = params.inflectionPoint ?? 500000;
      return params.basePrice + params.slope * k / (1 + Math.exp(-0.00001 * (currentSupply - k)));
    }
    default:
      return params.basePrice;
  }
}

function curveIntegral(curveType: CurveType, params: CurveParams, supply: number): number {
  switch (curveType) {
    case "linear":
      return params.basePrice * supply + (params.slope * supply * supply) / 2;
    case "exponential": {
      const e = params.exponent ?? 1.5;
      return params.basePrice * supply + (params.slope * Math.pow(supply, e + 1)) / (e + 1);
    }
    case "logarithmic": {
      const s1 = supply + 1;
      return params.basePrice * supply + params.slope * (s1 * Math.log(s1) - s1 + 1);
    }
    case "s_curve": {
      return params.basePrice * supply + params.slope * supply;
    }
    default:
      return params.basePrice * supply;
  }
}

export function generateCurvePoints(
  curveType: CurveType,
  params: CurveParams,
  maxSupply: number,
  steps: number = 100
): { supply: number; price: number }[] {
  const points: { supply: number; price: number }[] = [];
  const step = maxSupply / steps;
  for (let i = 0; i <= steps; i++) {
    const supply = i * step;
    points.push({ supply, price: calculateSpotPrice(curveType, params, supply) });
  }
  return points;
}

export function calculateSlippage(
  curveType: CurveType,
  params: CurveParams,
  currentSupply: number,
  amount: number,
  isBuy: boolean
): number {
  const spotPrice = calculateSpotPrice(curveType, params, currentSupply);
  const avgPrice = isBuy
    ? calculateBuyPrice(curveType, params, currentSupply, amount) / amount
    : calculateSellPrice(curveType, params, currentSupply, amount) / amount;
  if (spotPrice === 0) return 0;
  return Math.abs(((avgPrice - spotPrice) / spotPrice) * 100);
}

export function calculateMarketCap(
  curveType: CurveType,
  params: CurveParams,
  supply: number
): number {
  return calculateSpotPrice(curveType, params, supply) * supply;
}
