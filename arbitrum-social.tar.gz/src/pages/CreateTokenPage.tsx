import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Select } from '@/components/ui/select'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { Coins, TrendingUp, Zap, Info } from 'lucide-react'
import { BONDING_CURVE_PARAMS } from '@/lib/constants'

export default function CreateTokenPage() {
  const [tokenType, setTokenType] = useState<'personal' | 'community'>('personal')
  const [name, setName] = useState('')
  const [symbol, setSymbol] = useState('')
  const [description, setDescription] = useState('')
  const [curveType, setCurveType] = useState('linear')
  const [created, setCreated] = useState(false)

  const handleCreate = () => {
    if (!name || !symbol) return
    setCreated(true)
  }

  if (created) {
    return (
      <div className="max-w-lg mx-auto text-center py-20">
        <div className="inline-flex items-center justify-center h-20 w-20 rounded-full bg-green-100 mb-6">
          <Coins className="h-10 w-10 text-green-600" />
        </div>
        <h1 className="text-3xl font-bold">Token Created!</h1>
        <p className="text-muted-foreground mt-2">
          Your {tokenType} token <strong>{name} ({symbol})</strong> has been deployed to Arbitrum.
        </p>
        <div className="mt-6">
          <Button onClick={() => { setCreated(false); setName(''); setSymbol(''); setDescription('') }}>
            Create Another Token
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold">Create a Social Token</h1>
        <p className="text-muted-foreground mt-2">
          Launch your personal or community token on Arbitrum with bonding curve pricing
        </p>
      </div>

      <Tabs value={tokenType} onValueChange={(v) => setTokenType(v as 'personal' | 'community')}>
        <TabsList className="w-full">
          <TabsTrigger value="personal" className="flex-1">Personal Token</TabsTrigger>
          <TabsTrigger value="community" className="flex-1">Community Token</TabsTrigger>
        </TabsList>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Token Details</CardTitle>
          <CardDescription>
            {tokenType === 'personal'
              ? 'A personal token represents your individual brand and content'
              : 'A community token powers governance and shared ownership'}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium">Token Name</label>
              <Input
                placeholder="e.g. AliceCoin"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Symbol</label>
              <Input
                placeholder="e.g. ALICE"
                value={symbol}
                onChange={(e) => setSymbol(e.target.value.toUpperCase())}
                className="mt-1"
                maxLength={8}
              />
            </div>
          </div>
          <div>
            <label className="text-sm font-medium">Description</label>
            <Textarea
              placeholder="Describe what your token represents..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="mt-1"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Zap className="h-5 w-5" /> Bonding Curve
          </CardTitle>
          <CardDescription>
            The bonding curve determines how token price changes with supply
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium">Curve Type</label>
            <Select
              value={curveType}
              onChange={(e) => setCurveType(e.target.value)}
              options={[
                { value: 'linear', label: 'Linear — price grows steadily' },
                { value: 'exponential', label: 'Exponential — price grows faster over time' },
              ]}
              className="mt-1"
            />
          </div>

          <div className="bg-muted/50 rounded-lg p-4 space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Base Price</span>
              <span>{BONDING_CURVE_PARAMS.BASE_PRICE} ETH</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Curve Factor</span>
              <span>{BONDING_CURVE_PARAMS.CURVE_FACTOR}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Max Supply</span>
              <span>{BONDING_CURVE_PARAMS.MAX_SUPPLY.toLocaleString()}</span>
            </div>
          </div>

          <div className="flex items-start gap-2 text-sm text-muted-foreground bg-blue-50 rounded-lg p-3">
            <Info className="h-4 w-4 mt-0.5 text-blue-500 shrink-0" />
            <p>
              {curveType === 'linear'
                ? 'Linear curves provide steady, predictable price increases. Great for personal tokens.'
                : 'Exponential curves reward early adopters more. Great for community tokens that need bootstrapping.'}
            </p>
          </div>
        </CardContent>
      </Card>

      {tokenType === 'community' && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <TrendingUp className="h-5 w-5" /> Revenue Sharing
            </CardTitle>
            <CardDescription>Configure how revenue is distributed among community members</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-muted/50 rounded-lg p-4 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Creator Share</span>
                <span>40%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Community Treasury</span>
                <span>30%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Token Holders</span>
                <span>20%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Platform Fee</span>
                <span>10%</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Button
        className="w-full"
        size="lg"
        onClick={handleCreate}
        disabled={!name || !symbol}
      >
        <Coins className="mr-2 h-5 w-5" />
        Deploy {tokenType === 'personal' ? 'Personal' : 'Community'} Token on Arbitrum
      </Button>
    </div>
  )
}
