import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { TrendingUp, Users, Vote, Target, ArrowUpRight, ArrowDownRight, Clock } from 'lucide-react'
import { useCreatorStore } from '@/stores/useCreatorStore'
import { useTokenStore } from '@/stores/useTokenStore'
import { useGovernanceStore } from '@/stores/useGovernanceStore'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'

const ACTIVITY_FEED = [
  { id: 'a1', text: 'CryptoAlina published a new analysis on sequencer economics', time: '2 hours ago', type: 'content' },
  { id: 'a2', text: 'SolidityKai proposal reached quorum with 41K votes in favor', time: '5 hours ago', type: 'governance' },
  { id: 'a3', text: 'ZKEthon token price surged 12% after privacy AMM paper release', time: '8 hours ago', type: 'trading' },
  { id: 'a4', text: 'DeFi_Marcus opened a bounty for gas optimization benchmarks', time: '12 hours ago', type: 'bounty' },
  { id: 'a5', text: 'NFTJasmine Season 2 collection sold 80% in first hour', time: '1 day ago', type: 'trading' },
  { id: 'a6', text: 'ChainRebecca published token engineering framework for DAOs', time: '1 day ago', type: 'content' },
]

export default function Dashboard() {
  const creators = useCreatorStore((s) => s.creators)
  const tokens = useTokenStore((s) => s.tokens)
  const proposals = useGovernanceStore((s) => s.proposals)

  const totalTvl = tokens.reduce((sum, t) => sum + t.marketCap, 0)
  const activeCreators = creators.length
  const activeProposals = proposals.filter((p) => p.status === 'active').length
  const openBounties = 4

  const stats = [
    { icon: TrendingUp, label: 'Total Value Locked', value: `$${(totalTvl / 1e6).toFixed(2)}M`, change: '+8.3%', up: true },
    { icon: Users, label: 'Active Creators', value: activeCreators.toString(), change: '+2 this week', up: true },
    { icon: Vote, label: 'Active Proposals', value: activeProposals.toString(), change: '2 closing soon', up: true },
    { icon: Target, label: 'Open Bounties', value: openBounties.toString(), change: '2 new', up: true },
  ]

  const topTokens = [...tokens].sort((a, b) => b.marketCap - a.marketCap).slice(0, 5)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground mt-1">Overview of the SocialToken ecosystem on Arbitrum</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <stat.icon className="h-8 w-8 text-primary" />
                <div className="flex items-center gap-1 text-xs">
                  {stat.up ? (
                    <ArrowUpRight className="h-3 w-3 text-green-500" />
                  ) : (
                    <ArrowDownRight className="h-3 w-3 text-red-500" />
                  )}
                  <span className={stat.up ? 'text-green-500' : 'text-red-500'}>{stat.change}</span>
                </div>
              </div>
              <p className="text-2xl font-bold mt-3">{stat.value}</p>
              <p className="text-xs text-muted-foreground">{stat.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg">Top Tokens by Market Cap</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <LineChart
                data={topTokens.map((t) => ({
                  name: t.symbol,
                  price: t.price,
                  marketCap: t.marketCap,
                }))}
              >
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => `$${(v / 1e6).toFixed(1)}M`} />
                <Tooltip formatter={(value: number, name: string) => [name === 'marketCap' ? `$${(value / 1e6).toFixed(2)}M` : `$${value}`, name === 'marketCap' ? 'Market Cap' : 'Price']} />
                <Line type="monotone" dataKey="marketCap" stroke="hsl(221.2, 83.2%, 53.3%)" strokeWidth={2} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Token Price Comparison</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {topTokens.map((token) => (
              <div key={token.address} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-xs font-bold text-primary">
                    {token.symbol.slice(0, 2)}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{token.symbol}</p>
                    <p className="text-xs text-muted-foreground">{token.name}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold">${token.price}</p>
                  <p className="text-xs text-muted-foreground">{(token.marketCap / 1e3).toFixed(0)}K mcap</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {ACTIVITY_FEED.map((item) => (
              <div key={item.id} className="flex items-start gap-3">
                <div className="mt-0.5">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                </div>
                <div className="flex-1">
                  <p className="text-sm">{item.text}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-xs text-muted-foreground">{item.time}</span>
                    <Badge variant="outline" className="text-xs">
                      {item.type}
                    </Badge>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
