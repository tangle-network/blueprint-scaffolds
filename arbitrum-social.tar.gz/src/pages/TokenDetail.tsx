import React, { useState } from 'react'
import { useParams } from 'react-router-dom'
import { SocialTokenData, BondingCurveState } from '../types'

const SAMPLE_TOKEN: SocialTokenData = {
  address: '0x1234...abcd',
  name: 'CreatorCoin',
  symbol: 'CCOIN',
  creator: '0xaaaa...1111',
  totalSupply: '1000000',
  marketCap: '50000',
  price: '0.05',
  holders: 142,
}

const SAMPLE_CURVE: BondingCurveState = {
  currentPrice: '0.05',
  tokensSold: '250000',
  reserveBalance: '12500',
  curveType: 'linear',
}

const TokenDetail: React.FC = () => {
  const { address } = useParams<{ address: string }>()
  const [token] = useState<SocialTokenData>(SAMPLE_TOKEN)
  const [curve] = useState<BondingCurveState>(SAMPLE_CURVE)
  const [amount, setAmount] = useState('')
  const [action, setAction] = useState<'buy' | 'sell'>('buy')

  const estimatedCost =
    amount && curve
      ? (parseFloat(amount) * parseFloat(curve.currentPrice)).toFixed(6)
      : '0'

  return (
    <div>
      <div style={{ marginBottom: '2rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <div
            style={{
              width: '64px',
              height: '64px',
              borderRadius: '50%',
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#fff',
              fontWeight: 'bold',
              fontSize: '1.5rem',
            }}
          >
            {token.symbol.slice(0, 2)}
          </div>
          <div>
            <h2 style={{ margin: 0 }}>{token.name} (${token.symbol})</h2>
            <p style={{ color: '#666', fontSize: '0.875rem', margin: '0.25rem 0 0' }}>
              Created by {token.creator} | Token Address: {address}
            </p>
          </div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>
        <div>
          <h3 style={{ marginBottom: '1rem' }}>Token Info</h3>
          <div style={{ border: '1px solid #e0e0e0', borderRadius: '12px', padding: '1.5rem' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div>
                <span style={{ color: '#888', fontSize: '0.875rem' }}>Price</span>
                <div style={{ fontWeight: 600 }}>{token.price} ETH</div>
              </div>
              <div>
                <span style={{ color: '#888', fontSize: '0.875rem' }}>Market Cap</span>
                <div style={{ fontWeight: 600 }}>{token.marketCap} ETH</div>
              </div>
              <div>
                <span style={{ color: '#888', fontSize: '0.875rem' }}>Total Supply</span>
                <div style={{ fontWeight: 600 }}>{Number(token.totalSupply).toLocaleString()}</div>
              </div>
              <div>
                <span style={{ color: '#888', fontSize: '0.875rem' }}>Holders</span>
                <div style={{ fontWeight: 600 }}>{token.holders}</div>
              </div>
            </div>
          </div>

          <h3 style={{ margin: '1.5rem 0 1rem' }}>Bonding Curve</h3>
          <div style={{ border: '1px solid #e0e0e0', borderRadius: '12px', padding: '1.5rem' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1rem' }}>
              <div>
                <span style={{ color: '#888', fontSize: '0.875rem' }}>Tokens Sold</span>
                <div style={{ fontWeight: 600 }}>{Number(curve.tokensSold).toLocaleString()}</div>
              </div>
              <div>
                <span style={{ color: '#888', fontSize: '0.875rem' }}>Reserve</span>
                <div style={{ fontWeight: 600 }}>{curve.reserveBalance} ETH</div>
              </div>
              <div>
                <span style={{ color: '#888', fontSize: '0.875rem' }}>Curve Type</span>
                <div style={{ fontWeight: 600, textTransform: 'capitalize' }}>{curve.curveType}</div>
              </div>
            </div>
            <div
              style={{
                marginTop: '1rem',
                height: '8px',
                borderRadius: '4px',
                background: '#e0e0e0',
                overflow: 'hidden',
              }}
            >
              <div
                style={{
                  height: '100%',
                  width: `${(Number(curve.tokensSold) / Number(token.totalSupply)) * 100}%`,
                  background: 'linear-gradient(90deg, #667eea, #764ba2)',
                  borderRadius: '4px',
                }}
              />
            </div>
          </div>
        </div>

        <div>
          <h3 style={{ marginBottom: '1rem' }}>Trade</h3>
          <div style={{ border: '1px solid #e0e0e0', borderRadius: '12px', padding: '1.5rem' }}>
            <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1rem' }}>
              <button
                onClick={() => setAction('buy')}
                style={{
                  flex: 1,
                  padding: '0.75rem',
                  border: 'none',
                  borderRadius: '8px',
                  background: action === 'buy' ? '#0077cc' : '#e0e0e0',
                  color: action === 'buy' ? '#fff' : '#333',
                  fontWeight: 600,
                }}
              >
                Buy
              </button>
              <button
                onClick={() => setAction('sell')}
                style={{
                  flex: 1,
                  padding: '0.75rem',
                  border: 'none',
                  borderRadius: '8px',
                  background: action === 'sell' ? '#e74c3c' : '#e0e0e0',
                  color: action === 'sell' ? '#fff' : '#333',
                  fontWeight: 600,
                }}
              >
                Sell
              </button>
            </div>
            <div style={{ marginBottom: '1rem' }}>
              <label style={{ fontSize: '0.875rem', color: '#666', display: 'block', marginBottom: '0.5rem' }}>
                Amount ({token.symbol})
              </label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.0"
                style={{
                  width: '100%',
                  padding: '0.75rem',
                  borderRadius: '8px',
                  border: '1px solid #ccc',
                  fontSize: '1rem',
                }}
              />
            </div>
            <div
              style={{
                background: '#f5f5f5',
                padding: '0.75rem',
                borderRadius: '8px',
                marginBottom: '1rem',
                fontSize: '0.875rem',
              }}
            >
              <span style={{ color: '#888' }}>Estimated cost: </span>
              <strong>{estimatedCost} ETH</strong>
            </div>
            <button
              style={{
                width: '100%',
                padding: '0.75rem',
                border: 'none',
                borderRadius: '8px',
                background: action === 'buy' ? '#0077cc' : '#e74c3c',
                color: '#fff',
                fontWeight: 600,
                fontSize: '1rem',
              }}
            >
              {action === 'buy' ? 'Buy' : 'Sell'} {token.symbol}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default TokenDetail
