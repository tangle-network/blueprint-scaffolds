import React, { useState } from 'react'

const CreateToken: React.FC = () => {
  const [form, setForm] = useState({
    name: '',
    symbol: '',
    initialSupply: '',
    curveType: 'linear' as 'linear' | 'exponential',
    slope: '',
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    alert('Token creation would be submitted to the blockchain.')
  }

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto' }}>
      <h2 style={{ marginBottom: '1.5rem' }}>Create a Social Token</h2>
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: '1rem' }}>
          <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500 }}>Token Name</label>
          <input
            name="name"
            value={form.name}
            onChange={handleChange}
            required
            style={{ width: '100%', padding: '0.75rem', borderRadius: '8px', border: '1px solid #ccc' }}
          />
        </div>
        <div style={{ marginBottom: '1rem' }}>
          <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500 }}>Symbol</label>
          <input
            name="symbol"
            value={form.symbol}
            onChange={handleChange}
            required
            maxLength={8}
            style={{ width: '100%', padding: '0.75rem', borderRadius: '8px', border: '1px solid #ccc' }}
          />
        </div>
        <div style={{ marginBottom: '1rem' }}>
          <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500 }}>Initial Supply</label>
          <input
            name="initialSupply"
            type="number"
            value={form.initialSupply}
            onChange={handleChange}
            required
            min="1"
            style={{ width: '100%', padding: '0.75rem', borderRadius: '8px', border: '1px solid #ccc' }}
          />
        </div>
        <div style={{ marginBottom: '1rem' }}>
          <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500 }}>Bonding Curve Type</label>
          <select
            name="curveType"
            value={form.curveType}
            onChange={handleChange}
            style={{ width: '100%', padding: '0.75rem', borderRadius: '8px', border: '1px solid #ccc' }}
          >
            <option value="linear">Linear</option>
            <option value="exponential">Exponential</option>
          </select>
        </div>
        <div style={{ marginBottom: '1.5rem' }}>
          <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500 }}>Curve Slope</label>
          <input
            name="slope"
            type="number"
            value={form.slope}
            onChange={handleChange}
            required
            min="0"
            step="0.001"
            placeholder="e.g. 0.001"
            style={{ width: '100%', padding: '0.75rem', borderRadius: '8px', border: '1px solid #ccc' }}
          />
        </div>
        <button
          type="submit"
          style={{
            width: '100%',
            padding: '0.75rem',
            border: 'none',
            borderRadius: '8px',
            background: '#0077cc',
            color: '#fff',
            fontWeight: 600,
            fontSize: '1rem',
          }}
        >
          Create Token
        </button>
      </form>
    </div>
  )
}

export default CreateToken
