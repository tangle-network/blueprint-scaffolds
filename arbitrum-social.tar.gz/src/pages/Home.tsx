import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import TokenCard from '../components/TokenCard'
import { SocialTokenData } from '../types'

const SAMPLE_TOKENS: SocialTokenData[] = [
  {
    address: '0x1234...abcd',
    name: 'CreatorCoin',
    symbol: 'CCOIN',
    creator: '0xaaaa...1111',
    totalSupply: '1000000',
    marketCap: '50000',
    price: '0.05',
    holders: 142,
  },
  {
    address: '0x5678...efgh',
    name: 'InfluencerToken',
    symbol: 'ILT',
    creator: '0xbbbb...2222',
    totalSupply: '500000',
    marketCap: '25000',
    price: '0.05',
    holders: 89,
  },
  {
    address: '0x9abc...ijkl',
    name: 'CommunityDAO',
    symbol: 'CDAO',
    creator: '0xcccc...3333',
    totalSupply: '2000000',
    marketCap: '120000',
    price: '0.06',
    holders: 310,
  },
]

const Home: React.FC = () => {
  const [tokens, setTokens] = useState<SocialTokenData[]>([])
  const [search, setSearch] = useState('')

  useEffect(() => {
    setTokens(SAMPLE_TOKENS)
  }, [])

  const filtered = tokens.filter(
    (t) =>
      t.name.toLowerCase().includes(search.toLowerCase()) ||
      t.symbol.toLowerCase().includes(search.toLowerCase()),
  )

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
        <h2>Explore Social Tokens</h2>
        <input
          type="text"
          placeholder="Search tokens..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ padding: '0.5rem 1rem', borderRadius: '6px', border: '1px solid #ccc', width: '300px' }}
        />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '1.5rem' }}>
        {filtered.map((token) => (
          <Link key={token.address} to={`/token/${token.address}`} style={{ textDecoration: 'none', color: 'inherit' }}>
            <TokenCard token={token} />
          </Link>
        ))}
      </div>
      {filtered.length === 0 && <p>No tokens found.</p>}
    </div>
  )
}

export default Home
