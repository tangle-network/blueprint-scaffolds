import { Link } from 'react-router-dom'
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar } from '@/components/ui/avatar'
import { ArrowUpRight, TrendingUp, Users, FileText, Vote, Target } from 'lucide-react'
import { MOCK_TOKENS, MOCK_CREATORS, MOCK_CONTENT, MOCK_PROPOSALS, MOCK_BOUNTIES } from '@/lib/mockData'
import TokenCard from '@/components/TokenCard'

export default function HomePage() {
  return (
    <div className="space-y-10">
      <section className="text-center py-10">
        <h1 className="text-4xl font-bold tracking-tight">Social Tokens on Arbitrum</h1>
        <p className="mt-3 text-lg text-muted-foreground max-w-2xl mx-auto">
          Create, trade, and earn with personal and community tokens. Bonding curves power fair price discovery while gated content, governance, and bounties build thriving communities.
        </p>
        <div className="flex gap-3 justify-center mt-6">
          <Link to="/create">
            <Button size="lg">
              <ArrowUpRight className="mr-2 h-4 w-4" /> Create Token
            </Button>
          </Link>
          <Link to="/content">
            <Button variant="outline" size="lg">Explore Content</Button>
          </Link>
        </div>
      </section>

      <section>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { icon: TrendingUp, label: 'Total Market Cap', value: '$805K' },
            { icon: Users, label: 'Total Holders', value: '2,114' },
            { icon: FileText, label: 'Content Items', value: MOCK_CONTENT.length.toString() },
            { icon: Vote, label: 'Active Proposals', value: MOCK_PROPOSALS.filter(p => p.status === 'active').length.toString() },
          ].map((stat) => (
            <Card key={stat.label}>
              <CardContent className="p-4 flex items-center gap-3">
                <stat.icon className="h-8 w-8 text-primary" />
                <div>
                  <p className="text-2xl font-bold">{stat.value}</p>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold">Trending Tokens</h2>
          <Link to="/create">
            <Button variant="ghost" size="sm">View All <ArrowUpRight className="ml-1 h-3 w-3" /></Button>
          </Link>
        </div>
        <div className="grid md:grid-cols-3 gap-4">
          {MOCK_TOKENS.map((token) => (
            <TokenCard key={token.address} token={token} />
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-bold mb-4">Top Creators</h2>
        <div className="grid md:grid-cols-3 gap-4">
          {MOCK_CREATORS.map((creator) => (
            <Link key={creator.address} to={`/creator/${creator.address}`}>
              <Card className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-4 flex items-center gap-4">
                  <Avatar size="lg">{creator.name.slice(0, 2).toUpperCase()}</Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold truncate">{creator.name}</p>
                    <p className="text-sm text-muted-foreground">{creator.followers.toLocaleString()} followers</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="secondary">{creator.tokenSymbol}</Badge>
                      <Badge variant="outline">Rep: {creator.reputation}</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-bold mb-4">Latest Content</h2>
        <div className="grid md:grid-cols-2 gap-4">
          {MOCK_CONTENT.slice(0, 4).map((item) => (
            <Card key={item.id}>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <Badge variant={item.accessType === 'free' ? 'success' : item.accessType === 'token_gated' ? 'default' : 'secondary'}>
                    {item.accessType === 'token_gated' ? 'Token Gated' : item.accessType === 'paid' ? `Paid: ${item.price} ETH` : 'Free'}
                  </Badge>
                  <Badge variant="outline">{item.category}</Badge>
                </div>
                <CardTitle className="text-lg">{item.title}</CardTitle>
                <CardDescription>{item.creatorName}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground line-clamp-2">{item.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-bold mb-4">Active Bounties</h2>
        <div className="grid md:grid-cols-2 gap-4">
          {MOCK_BOUNTIES.filter(b => b.status === 'open').map((bounty) => (
            <Link key={bounty.id} to="/bounties">
              <Card className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="default">{bounty.status}</Badge>
                    <span className="text-lg font-bold">{bounty.reward} {bounty.tokenSymbol}</span>
                  </div>
                  <h3 className="font-semibold">{bounty.title}</h3>
                  <p className="text-sm text-muted-foreground mt-1">{bounty.submissions} submissions</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>
    </div>
  )
}
