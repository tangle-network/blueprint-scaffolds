import { useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar } from '@/components/ui/avatar'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { ArrowLeft, Users, FileText, Star, Send, DollarSign } from 'lucide-react'
import { MOCK_CREATORS, MOCK_CONTENT, MOCK_TOKENS, MOCK_BOUNTIES, MOCK_REVENUE_SHARES } from '@/lib/mockData'
import { formatAddress } from '@/lib/utils'
import { Input } from '@/components/ui/input'

export default function CreatorProfilePage() {
  const { address } = useParams<{ address: string }>()
  const creator = MOCK_CREATORS.find(c => c.address === address) || MOCK_CREATORS[0]
  const token = MOCK_TOKENS.find(t => t.address === creator.tokenAddress)
  const content = MOCK_CONTENT.filter(c => c.creator === creator.address)
  const bounties = MOCK_BOUNTIES.filter(b => b.creator === creator.address)
  const revenueShares = MOCK_REVENUE_SHARES.filter(r => r.recipient === creator.address)
  const [tipAmount, setTipAmount] = useState('')

  const reputationPercent = creator.reputation

  return (
    <div className="space-y-6">
      <Link to="/" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="mr-1 h-4 w-4" /> Back to Home
      </Link>

      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row items-start gap-6">
            <Avatar size="xl">{creator.name.slice(0, 2).toUpperCase()}</Avatar>
            <div className="flex-1">
              <div className="flex items-center gap-3">
                <h1 className="text-2xl font-bold">{creator.name}</h1>
                {creator.tokenSymbol && <Badge>{creator.tokenSymbol}</Badge>}
              </div>
              <p className="text-sm text-muted-foreground mt-1">{formatAddress(creator.address)}</p>
              <p className="mt-2 text-muted-foreground">{creator.bio}</p>
              <div className="flex items-center gap-6 mt-4">
                <div className="flex items-center gap-1 text-sm">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <span>{creator.followers.toLocaleString()} followers</span>
                </div>
                <div className="flex items-center gap-1 text-sm">
                  <FileText className="h-4 w-4 text-muted-foreground" />
                  <span>{creator.contentCount} posts</span>
                </div>
                <div className="flex items-center gap-1 text-sm">
                  <Star className="h-4 w-4 text-muted-foreground" />
                  <span>Rep: {creator.reputation}/100</span>
                </div>
              </div>
              <div className="mt-3 max-w-xs">
                <Progress value={reputationPercent} />
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <Input
                  type="number"
                  placeholder="ETH"
                  value={tipAmount}
                  onChange={(e) => setTipAmount(e.target.value)}
                  className="w-24"
                />
                <Button size="sm">
                  <Send className="mr-1 h-3 w-3" /> Tip
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">Send a tip to {creator.name}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="content">
        <TabsList>
          <TabsTrigger value="content">Content ({content.length})</TabsTrigger>
          <TabsTrigger value="token">Token</TabsTrigger>
          <TabsTrigger value="bounties">Bounties ({bounties.length})</TabsTrigger>
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
        </TabsList>

        <TabsContent value="content" className="mt-4">
          <div className="grid md:grid-cols-2 gap-4">
            {content.length > 0 ? content.map((item) => (
              <Card key={item.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <Badge variant={item.accessType === 'free' ? 'success' : item.accessType === 'token_gated' ? 'default' : 'secondary'}>
                      {item.accessType === 'token_gated' ? 'Token Gated' : item.accessType === 'paid' ? `Paid: ${item.price} ETH` : 'Free'}
                    </Badge>
                    <Badge variant="outline">{item.category}</Badge>
                  </div>
                  <CardTitle className="text-lg">{item.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{item.description}</p>
                  <div className="flex items-center justify-between mt-3 text-sm text-muted-foreground">
                    <span>{item.likes} likes</span>
                    <span>{new Date(item.createdAt).toLocaleDateString()}</span>
                  </div>
                </CardContent>
              </Card>
            )) : (
              <p className="text-muted-foreground">No content yet.</p>
            )}
          </div>
        </TabsContent>

        <TabsContent value="token" className="mt-4">
          {token ? (
            <Link to={`/token/${token.address}`}>
              <Card className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-bold">{token.name} ({token.symbol})</h3>
                      <p className="text-sm text-muted-foreground mt-1">{token.description}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold">${token.price}</p>
                      <p className="text-sm text-muted-foreground">{token.holders} holders</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ) : (
            <p className="text-muted-foreground">No token created yet.</p>
          )}
        </TabsContent>

        <TabsContent value="bounties" className="mt-4">
          <div className="space-y-4">
            {bounties.length > 0 ? bounties.map((bounty) => (
              <Card key={bounty.id}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold">{bounty.title}</h3>
                      <p className="text-sm text-muted-foreground mt-1">{bounty.description}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold">{bounty.reward} {bounty.tokenSymbol}</p>
                      <Badge variant={bounty.status === 'open' ? 'default' : bounty.status === 'completed' ? 'success' : 'secondary'}>
                        {bounty.status}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )) : (
              <p className="text-muted-foreground">No bounties yet.</p>
            )}
          </div>
        </TabsContent>

        <TabsContent value="revenue" className="mt-4">
          <div className="grid md:grid-cols-2 gap-4">
            {revenueShares.length > 0 ? revenueShares.map((share, i) => (
              <Card key={i}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{share.share}% share</p>
                      <p className="text-sm text-muted-foreground">Total earned: {share.totalEarned} ETH</p>
                    </div>
                    <div className="text-right">
                      <p className="text-green-600 font-semibold">{share.pendingClaim} ETH</p>
                      <p className="text-xs text-muted-foreground">pending claim</p>
                    </div>
                  </div>
                  <Button size="sm" className="mt-3 w-full">
                    <DollarSign className="mr-1 h-3 w-3" /> Claim Revenue
                  </Button>
                </CardContent>
              </Card>
            )) : (
              <p className="text-muted-foreground">No revenue data yet.</p>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
