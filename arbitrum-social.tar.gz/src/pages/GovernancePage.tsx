import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { Progress } from '@/components/ui/progress'
import { Vote, ThumbsUp, ThumbsDown, PlusCircle, Clock } from 'lucide-react'
import { MOCK_PROPOSALS, MOCK_TOKENS } from '@/lib/mockData'
import { formatAddress } from '@/lib/utils'
import { Dialog, DialogOverlay, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'

export default function GovernancePage() {
  const [showCreate, setShowCreate] = useState(false)
  const [selectedProposal, setSelectedProposal] = useState<string | null>(null)

  const getTokenSymbol = (addr: string) => MOCK_TOKENS.find(t => t.address === addr)?.symbol || '???'

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Governance</h1>
          <p className="text-muted-foreground mt-1">Vote on proposals and shape the future of communities</p>
        </div>
        <Button onClick={() => setShowCreate(true)}>
          <PlusCircle className="mr-2 h-4 w-4" /> New Proposal
        </Button>
      </div>

      <div className="grid gap-4">
        {MOCK_PROPOSALS.map((proposal) => {
          const totalVotes = proposal.forVotes + proposal.againstVotes
          const forPercent = totalVotes > 0 ? (proposal.forVotes / totalVotes) * 100 : 0

          return (
            <Card key={proposal.id}>
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant={
                        proposal.status === 'active' ? 'default' :
                        proposal.status === 'passed' ? 'success' :
                        proposal.status === 'failed' ? 'destructive' : 'secondary'
                      }>
                        {proposal.status}
                      </Badge>
                      <Badge variant="outline">{getTokenSymbol(proposal.tokenAddress)}</Badge>
                    </div>
                    <h3 className="text-lg font-semibold">{proposal.title}</h3>
                    <p className="text-sm text-muted-foreground mt-1">{proposal.description}</p>
                    <p className="text-xs text-muted-foreground mt-2">
                      Proposed by {formatAddress(proposal.proposer)}
                    </p>
                  </div>
                  <div className="text-right ml-6">
                    <div className="flex items-center gap-1 text-sm text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {proposal.status === 'active' ? 'Ends' : 'Ended'} {new Date(proposal.endDate).toLocaleDateString()}
                    </div>
                  </div>
                </div>

                <div className="mt-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-green-600">For: {proposal.forVotes.toLocaleString()}</span>
                    <span className="text-red-600">Against: {proposal.againstVotes.toLocaleString()}</span>
                  </div>
                  <Progress value={forPercent} />
                </div>

                {proposal.status === 'active' && (
                  <div className="flex gap-2 mt-4">
                    <Button size="sm" variant="outline" className="flex-1">
                      <ThumbsUp className="mr-1 h-4 w-4 text-green-600" /> Vote For
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1">
                      <ThumbsDown className="mr-1 h-4 w-4 text-red-600" /> Vote Against
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          )
        })}
      </div>

      {showCreate && (
        <Dialog>
          <DialogOverlay onClick={() => setShowCreate(false)} />
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Proposal</DialogTitle>
              <DialogDescription>Submit a new governance proposal for your community</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <Input placeholder="Proposal title" />
              <Textarea placeholder="Describe your proposal..." />
              <Button className="w-full">Submit Proposal</Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}
