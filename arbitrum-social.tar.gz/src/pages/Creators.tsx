import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Avatar } from '@/components/ui/avatar'
import { Search, Users, Star, CheckCircle2 } from 'lucide-react'
import { useCreatorStore } from '@/stores/useCreatorStore'
import { useTokenStore } from '@/stores/useTokenStore'

export default function Creators() {
  const { searchQuery, setSearchQuery, getFilteredCreators } = useCreatorStore()
  const tokens = useTokenStore((s) => s.tokens)
  const [sortBy, setSortBy] = useState<'followers' | 'reputation'>('followers')
  const creators = getFilteredCreators()

  const sorted = [...creators].sort((a, b) =>
    sortBy === 'followers' ? b.followerCount - a.followerCount : b.reputationScore - a.reputationScore
  )

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Creators</h1>
        <p className="text-muted-foreground mt-1">Discover creators building with social tokens on Arbitrum</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by name, handle, or token..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <div className="flex gap-2">
          <Badge
            variant={sortBy === 'followers' ? 'default' : 'outline'}
            className="cursor-pointer px-3 py-1.5"
            onClick={() => setSortBy('followers')}
          >
            <Users className="mr-1 h-3 w-3" /> By Followers
          </Badge>
          <Badge
            variant={sortBy === 'reputation' ? 'default' : 'outline'}
            className="cursor-pointer px-3 py-1.5"
            onClick={() => setSortBy('reputation')}
          >
            <Star className="mr-1 h-3 w-3" /> By Reputation
          </Badge>
        </div>
      </div>

      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
        {sorted.map((creator) => {
          const token = tokens.find((t) => t.creator === creator.id)
          return (
            <Link key={creator.id} to={`/token/${creator.tokenAddress}`}>
              <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
                <CardContent className="p-5">
                  <div className="flex items-start gap-4">
                    <Avatar size="lg">{creator.name.slice(0, 2).toUpperCase()}</Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold truncate">{creator.name}</h3>
                        {creator.verified && (
                          <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{creator.handle}</p>
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{creator.bio}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 mt-4 flex-wrap">
                    <Badge variant="secondary">{creator.tokenSymbol}</Badge>
                    {token && (
                      <Badge variant="outline">${token.price}</Badge>
                    )}
                    <Badge variant="outline">
                      <Star className="mr-1 h-3 w-3" /> {creator.reputationScore}
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between mt-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Users className="h-3 w-3" />
                      <span>{(creator.followerCount / 1000).toFixed(1)}K followers</span>
                    </div>
                    {token && (
                      <span>MC: ${(token.marketCap / 1e3).toFixed(0)}K</span>
                    )}
                  </div>
                </CardContent>
              </Card>
            </Link>
          )
        })}
      </div>

      {sorted.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          <p>No creators found matching "{searchQuery}"</p>
        </div>
      )}
    </div>
  )
}
