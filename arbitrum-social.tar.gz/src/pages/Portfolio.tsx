import React from 'react'
import { Link } from 'react-router-dom'
import { PortfolioEntry } from '../types'

const SAMPLE_PORTFOLIO: PortfolioEntry[] = [
  {
    token: {
      address: '0x1234...abcd',
      name: 'CreatorCoin',
      symbol: 'CCOIN',
      creator: '0xaaaa...1111',
      totalSupply: '1000000',
      marketCap: '50000',
      price: '0.05',
      holders: 142,
    },
    balance: '5000',
    value: '250',
  },
  {
    token: {
      address: '0x9abc...ijkl',
      name: 'CommunityDAO',
      symbol: 'CDAO',
      creator: '0xcccc...3333',
      totalSupply: '2000000',
      marketCap: '120000',
      price: '0.06',
      holders: 310,
    },
    balance: '10000',
    value: '600',
  },
]

const Portfolio: React.FC = () => {
  const portfolio = SAMPLE_PORTFOLIO
  const totalValue = portfolio.reduce((sum, e) => sum + parseFloat(e.value), 0)

  return (
    <div>
      <h2 style={{ marginBottom: '1.5rem' }}>My Portfolio</h2>
      <div
        style={{
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          borderRadius: '12px',
          padding: '2rem',
          color: '#fff',
          marginBottom: '2rem',
        }}
      >
        <div style={{ fontSize: '0.875rem', opacity: 0.8 }}>Total Value</div>
        <div style={{ fontSize: '2rem', fontWeight: 'bold' }}>{totalValue.toFixed(2)} ETH</div>
      </div>
      {portfolio.length === 0 ? (
        <p>No tokens in portfolio. <Link to="/">Explore tokens</Link></p>
      ) : (
        <div style={{ border: '1px solid #e0e0e0', borderRadius: '12px', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: '#f5f5f5' }}>
                <th style={{ padding: '1rem', textAlign: 'left' }}>Token</th>
                <th style={{ padding: '1rem', textAlign: 'right' }}>Balance</th>
                <th style={{ padding: '1rem', textAlign: 'right' }}>Value (ETH)</th>
                <th style={{ padding: '1rem', textAlign: 'right' }}>Price (ETH)</th>
              </tr>
            </thead>
            <tbody>
              {portfolio.map((entry) => (
                <tr key={entry.token.address} style={{ borderTop: '1px solid #e0e0e0' }}>
                  <td style={{ padding: '1rem' }}>
                    <Link to={`/token/${entry.token.address}`} style={{ fontWeight: 600 }}>
                      {entry.token.name}
                    </Link>
                    <div style={{ color: '#888', fontSize: '0.875rem' }}>${entry.token.symbol}</div>
                  </td>
                  <td style={{ padding: '1rem', textAlign: 'right' }}>
                    {Number(entry.balance).toLocaleString()}
                  </td>
                  <td style={{ padding: '1rem', textAlign: 'right', fontWeight: 600 }}>
                    {entry.value}
                  </td>
                  <td style={{ padding: '1rem', textAlign: 'right' }}>
                    {entry.token.price}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

export default Portfolio
