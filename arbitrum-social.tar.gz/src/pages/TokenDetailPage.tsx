import { useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { ArrowLeft, TrendingUp, Users, DollarSign, BarChart3 } from 'lucide-react'
import { MOCK_TOKENS, MOCK_CREATORS, generateTradeHistory } from '@/lib/mockData'
import { MOCK_REVENUE_SHARES } from '@/lib/mockData'
import { formatAddress } from '@/lib/utils'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts'

export default function TokenDetailPage() {
  const { address } = useParams<{ address: string }>()
  const token = MOCK_TOKENS.find(t => t.address === address) || MOCK_TOKENS[0]
  const creator = MOCK_CREATORS.find(c => c.tokenAddress === token.address)
  const tradeHistory = generateTradeHistory()
  const [tradeAmount, setTradeAmount] = useState('')
  const [tradeTab, setTradeTab] = useState<'buy' | 'sell'>('buy')

  const estimatedCost = tradeAmount
    ? (parseFloat(tradeAmount) * parseFloat(token.price)).toFixed(4)
    : '0.0000'

  return (
    <div className="space-y-6">
      <Link to="/" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="mr-1 h-4 w-4" /> Back to Home
      </Link>

      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-bold">{token.name}</h1>
            <Badge variant="secondary">{token.symbol}</Badge>
            <Badge variant={token.type === 'personal' ? 'outline' : 'default'}>{token.type}</Badge>
          </div>
          <p className="text-sm text-muted-foreground mt-1">{formatAddress(token.address)}</p>
          <p className="text-sm text-muted-foreground mt-1">{token.description}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { icon: DollarSign, label: 'Price', value: `$${token.price}` },
          { icon: TrendingUp, label: 'Market Cap', value: `$${Number(token.marketCap).toLocaleString()}` },
          { icon: Users, label: 'Holders', value: token.holders.toString() },
          { icon: BarChart3, label: 'Supply', value: Number(token.totalSupply).toLocaleString() },
        ].map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-4 flex items-center gap-3">
              <stat.icon className="h-6 w-6 text-primary" />
              <div>
                <p className="text-lg font-bold">{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Price Chart (30d)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={tradeHistory}>
                  <defs>
                    <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(221.2, 83.2%, 53.3%)" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="hsl(221.2, 83.2%, 53.3%)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis
                    dataKey="timestamp"
                    tickFormatter={(v) => new Date(v).toLocaleDateString('en', { month: 'short', day: 'numeric' })}
                    tick={{ fontSize: 12 }}
                  />
                  <YAxis tick={{ fontSize: 12 }} domain={['auto', 'auto']} />
                  <Tooltip
                    labelFormatter={(v) => new Date(v as number).toLocaleDateString()}
                    formatter={(value: number) => [`$${value.toFixed(4)}`, 'Price']}
                  />
                  <Area type="monotone" dataKey="price" stroke="hsl(221.2, 83.2%, 53.3%)" fill="url(#colorPrice)" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Bonding Curve</CardTitle>
              <CardDescription>
                {token.curveType} curve — price increases as supply grows
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart
                  data={Array.from({ length: 20 }, (_, i) => ({
                    supply: i * 500000,
                    price: parseFloat(token.price) * (1 + i * 0.15),
                  }))}
                >
                  <XAxis dataKey="supply" tick={{ fontSize: 12 }} tickFormatter={(v) => `${(v / 1000000).toFixed(1)}M`} />
                  <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => `$${v.toFixed(2)}`} />
                  <Tooltip formatter={(value: number) => [`$${value.toFixed(4)}`, 'Price']} />
                  <Line type="monotone" dataKey="price" stroke="hsl(221.2, 83.2%, 53.3%)" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Revenue Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {MOCK_REVENUE_SHARES.map((share, i) => (
                  <div key={i} className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">{formatAddress(share.recipient)}</span>
                    <span className="font-medium">{share.share}%</span>
                    <span className="text-muted-foreground">{share.totalEarned} ETH earned</span>
                    <span className="text-green-600">{share.pendingClaim} ETH pending</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Trade {token.symbol}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Tabs value={tradeTab} onValueChange={(v) => setTradeTab(v as 'buy' | 'sell')}>
                <TabsList className="w-full">
                  <TabsTrigger value="buy" className="flex-1">Buy</TabsTrigger>
                  <TabsTrigger value="sell" className="flex-1">Sell</TabsTrigger>
                </TabsList>
              </Tabs>
              <div>
                <label className="text-sm font-medium">Amount ({token.symbol})</label>
                <Input
                  type="number"
                  placeholder="0"
                  value={tradeAmount}
                  onChange={(e) => setTradeAmount(e.target.value)}
                  className="mt-1"
                />
              </div>
              <div className="text-sm text-muted-foreground">
                Estimated {tradeTab === 'buy' ? 'cost' : 'return'}: {estimatedCost} ETH
              </div>
              <Button className="w-full" variant={tradeTab === 'buy' ? 'default' : 'destructive'}>
                {tradeTab === 'buy' ? 'Buy' : 'Sell'} {token.symbol}
              </Button>
            </CardContent>
          </Card>

          {creator && (
            <Link to={`/creator/${creator.address}`}>
              <Card className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-4">
                  <p className="text-sm text-muted-foreground mb-2">Creator</p>
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center font-semibold text-primary">
                      {creator.name.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <p className="font-semibold">{creator.name}</p>
                      <p className="text-sm text-muted-foreground">{creator.followers.toLocaleString()} followers</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Token Info</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Curve Type</span>
                <span className="font-medium capitalize">{token.curveType}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Token Type</span>
                <span className="font-medium capitalize">{token.type}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Created</span>
                <span className="font-medium">{new Date(token.createdAt).toLocaleDateString()}</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
