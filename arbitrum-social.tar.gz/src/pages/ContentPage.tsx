import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { Search, Lock, Unlock, CreditCard } from 'lucide-react'
import { MOCK_CONTENT } from '@/lib/mockData'

export default function ContentPage() {
  const [search, setSearch] = useState('')
  const [tab, setTab] = useState('all')

  const filtered = MOCK_CONTENT.filter((item) => {
    const matchSearch =
      item.title.toLowerCase().includes(search.toLowerCase()) ||
      item.description.toLowerCase().includes(search.toLowerCase())
    const matchTab =
      tab === 'all' ||
      (tab === 'free' && item.accessType === 'free') ||
      (tab === 'gated' && item.accessType === 'token_gated') ||
      (tab === 'paid' && item.accessType === 'paid')
    return matchSearch && matchTab
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Content Platform</h1>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search content..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList>
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="free">Free</TabsTrigger>
            <TabsTrigger value="gated">Token Gated</TabsTrigger>
            <TabsTrigger value="paid">Paid</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((item) => (
          <Card key={item.id} className="flex flex-col">
            <CardHeader>
              <div className="flex items-center justify-between">
                <Badge variant={item.accessType === 'free' ? 'success' : item.accessType === 'token_gated' ? 'default' : 'secondary'}>
                  {item.accessType === 'free' ? (
                    <><Unlock className="mr-1 h-3 w-3" /> Free</>
                  ) : item.accessType === 'token_gated' ? (
                    <><Lock className="mr-1 h-3 w-3" /> {item.requiredTokens} tokens</>
                  ) : (
                    <><CreditCard className="mr-1 h-3 w-3" /> {item.price} ETH</>
                  )}
                </Badge>
                <Badge variant="outline">{item.category}</Badge>
              </div>
              <CardTitle className="text-lg">{item.title}</CardTitle>
              <CardDescription>by {item.creatorName}</CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
              <p className="text-sm text-muted-foreground line-clamp-3">{item.description}</p>
              <div className="flex items-center justify-between mt-4">
                <span className="text-sm text-muted-foreground">{item.likes} likes</span>
                <Button size="sm" variant={item.accessType === 'free' ? 'default' : 'outline'}>
                  {item.accessType === 'free' ? 'Read' : item.accessType === 'token_gated' ? 'Unlock' : 'Purchase'}
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-10 text-muted-foreground">
          <p>No content found matching your criteria.</p>
        </div>
      )}
    </div>
  )
}
