import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { Search, PlusCircle, Clock, Users, DollarSign, CheckCircle2 } from 'lucide-react'
import { MOCK_BOUNTIES, MOCK_CREATORS } from '@/lib/mockData'
import { Dialog, DialogOverlay, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import { Select } from '@/components/ui/select'

export default function BountiesPage() {
  const [search, setSearch] = useState('')
  const [tab, setTab] = useState('all')
  const [showCreate, setShowCreate] = useState(false)

  const filtered = MOCK_BOUNTIES.filter((b) => {
    const matchSearch =
      b.title.toLowerCase().includes(search.toLowerCase()) ||
      b.description.toLowerCase().includes(search.toLowerCase())
    const matchTab =
      tab === 'all' ||
      (tab === 'open' && b.status === 'open') ||
      (tab === 'in_progress' && b.status === 'in_progress') ||
      (tab === 'completed' && b.status === 'completed')
    return matchSearch && matchTab
  })

  const getCreatorName = (addr: string) => MOCK_CREATORS.find(c => c.address === addr)?.name || formatAddress(addr)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Bounties</h1>
          <p className="text-muted-foreground mt-1">Complete tasks and earn token rewards</p>
        </div>
        <Button onClick={() => setShowCreate(true)}>
          <PlusCircle className="mr-2 h-4 w-4" /> Create Bounty
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search bounties..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList>
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="open">Open</TabsTrigger>
            <TabsTrigger value="in_progress">In Progress</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="grid gap-4">
        {filtered.map((bounty) => (
          <Card key={bounty.id}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant={
                      bounty.status === 'open' ? 'default' :
                      bounty.status === 'in_progress' ? 'secondary' :
                      bounty.status === 'completed' ? 'success' : 'destructive'
                    }>
                      {bounty.status.replace('_', ' ')}
                    </Badge>
                    <Badge variant="outline">{bounty.tokenSymbol}</Badge>
                  </div>
                  <h3 className="text-lg font-semibold">{bounty.title}</h3>
                  <p className="text-sm text-muted-foreground mt-1">{bounty.description}</p>
                  <div className="flex items-center gap-4 mt-3 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Users className="h-3 w-3" /> {getCreatorName(bounty.creator)}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" /> Due {new Date(bounty.deadline).toLocaleDateString()}
                    </span>
                    <span>{bounty.submissions} submissions</span>
                  </div>
                </div>
                <div className="text-right ml-6">
                  <p className="text-2xl font-bold">{bounty.reward}</p>
                  <p className="text-sm text-muted-foreground">{bounty.tokenSymbol}</p>
                  {bounty.status === 'open' && (
                    <Button size="sm" className="mt-2">
                      Submit Work
                    </Button>
                  )}
                  {bounty.status === 'completed' && (
                    <div className="flex items-center gap-1 text-green-600 mt-2 text-sm">
                      <CheckCircle2 className="h-4 w-4" /> Completed
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-10 text-muted-foreground">
          <p>No bounties found matching your criteria.</p>
        </div>
      )}

      {showCreate && (
        <Dialog>
          <DialogOverlay onClick={() => setShowCreate(false)} />
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Bounty</DialogTitle>
              <DialogDescription>Post a new bounty for the community</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <Input placeholder="Bounty title" />
              <Textarea placeholder="Describe the task..." />
              <Input type="number" placeholder="Reward amount" />
              <Select
                placeholder="Select token"
                options={[
                  { value: 'BUILD', label: 'BUILD' },
                  { value: 'ALICE', label: 'ALICE' },
                  { value: 'ART', label: 'ART' },
                ]}
              />
              <Input type="date" placeholder="Deadline" />
              <Button className="w-full">Create Bounty</Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

function formatAddress(addr: string): string {
  return `${addr.slice(0, 6)}...${addr.slice(-4)}`
}
