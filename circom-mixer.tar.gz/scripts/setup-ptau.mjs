import { mkdir, access } from "node:fs/promises";
import { constants } from "node:fs";
import { resolve } from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);
const artifactsDir = resolve("artifacts");
const ptauPath = resolve(artifactsDir, "powersOfTau28_hez_final_12.ptau");

async function main() {
  await mkdir(artifactsDir, { recursive: true });

  try {
    await access(ptauPath, constants.R_OK);
    console.log(`Powers of Tau already present at ${ptauPath}`);
    return;
  } catch {
    console.log("Preparing a local Powers of Tau ceremony with snarkjs...");
  }

  await execFileAsync("pnpm", ["exec", "snarkjs", "powersoftau", "new", "bn128", "12", resolve(artifactsDir, "pot12_0000.ptau"), "-v"]);
  await execFileAsync("pnpm", ["exec", "snarkjs", "powersoftau", "contribute", resolve(artifactsDir, "pot12_0000.ptau"), resolve(artifactsDir, "pot12_0001.ptau"), "--name=First contribution", "-v", "-e=random entropy"]);
  await execFileAsync("pnpm", ["exec", "snarkjs", "powersoftau", "prepare", "phase2", resolve(artifactsDir, "pot12_0001.ptau"), ptauPath, "-v"]);
  console.log(`Prepared ${ptauPath}`);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
