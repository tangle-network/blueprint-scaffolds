import { mkdir } from "node:fs/promises";
import { resolve } from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);

async function run(command, args) {
  const { stdout, stderr } = await execFileAsync(command, args, { cwd: resolve(".") });
  if (stdout) {
    process.stdout.write(stdout);
  }
  if (stderr) {
    process.stderr.write(stderr);
  }
}

async function main() {
  const artifactsDir = resolve("artifacts");
  await mkdir(artifactsDir, { recursive: true });

  const circuits = ["deposit", "withdraw"];
  for (const circuit of circuits) {
    await run("circom", [
      resolve("circuits", `${circuit}.circom`),
      "--r1cs",
      "--wasm",
      "--sym",
      "-o",
      artifactsDir
    ]);
  }

  console.log("Circuits compiled into artifacts/. Run `pnpm setup:ptau` before Groth16 setup.");
}

main().catch((error) => {
  console.error(error.message);
  process.exitCode = 1;
});
