import { randomBytes } from "node:crypto";
import { buildPoseidon } from "circomlibjs";

function randomHex() {
  return `0x${randomBytes(31).toString("hex")}`;
}

async function main() {
  const poseidon = await buildPoseidon();
  const secret = randomHex();
  const nullifier = randomHex();
  const secretBigInt = BigInt(secret);
  const nullifierBigInt = BigInt(nullifier);
  const commitment = `0x${BigInt(poseidon.F.toString(poseidon([secretBigInt, nullifierBigInt]))).toString(16)}`;
  const nullifierHash = `0x${BigInt(poseidon.F.toString(poseidon([nullifierBigInt]))).toString(16)}`;

  console.log(
    JSON.stringify(
      {
        secret,
        nullifier,
        commitment,
        nullifierHash,
        note: `mixer:${secret}:${nullifier}`
      },
      null,
      2
    )
  );
}

main();
