# Privacy Mixer

Circom-based anonymous transfer demo with fixed denomination pools, Merkle commitments, nullifier-based withdrawals, and a relayer-focused frontend.

## Stack

- Circom circuits in [`circuits/`](./circuits)
- Trusted setup helpers in [`scripts/`](./scripts)
- React + Vite frontend in [`src/`](./src)

## Commands

```bash
pnpm install
pnpm dev
pnpm build
pnpm build:circuits
pnpm setup:ptau
```

## Circuit flow

1. `deposit.circom` computes a commitment and nullifier hash from `(secret, nullifier)`.
2. `withdraw.circom` proves the commitment exists in an 8-level Merkle tree and binds the nullifier hash to prevent double spends.
3. Public signals expose the tree root, relayer routing fields, and fee/refund values while keeping `(secret, nullifier)` private.
