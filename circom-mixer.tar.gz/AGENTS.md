# Privacy Mixer — Build Plan

## Architecture
- **Circom circuits** in `/circuits/`: `deposit.circom`, `withdraw.circom`, `merkle_tree.circom`
- **Solidity contracts** in `/contracts/`: `PrivacyMixer.sol`, `RelayerRegistry.sol`
- **Frontend** in `/src/`: Vite + React + TypeScript + Tailwind + shadcn/ui

## Pages
- **DepositPage** — select denomination, generate note, submit deposit commitment
- **WithdrawPage** — paste note, build Merkle proof, select relayer, submit withdrawal
- **NotesPage** — list stored deposit notes, copy/delete, show status

## Components (`src/components/`)
- `Header.tsx` — nav bar with links to Deposit / Withdraw / Notes
- `DepositForm.tsx` — denomination selector + deposit button
- `WithdrawForm.tsx` — note input, proof gen, relayer selector, withdraw button
- `NoteManager.tsx` — list notes with copy/delete
- `RelayerSelector.tsx` — pick a relayer from network

## shadcn/ui components (`src/components/ui/`)
- button, card, input, label, select, tabs, dialog, toast, separator, badge, tooltip

## Hooks (`src/hooks/`)
- `useMixer.ts` — deposit/withdraw logic, tree state
- `useNote.ts` — CRUD for deposit notes in localStorage

## Lib (`src/lib/`)
- `utils.ts` — cn() helper
- `crypto.ts` — Poseidon hash, commitment, nullifier generation
- `merkle.ts` — Merkle tree construction, proof generation
- `note.ts` — deposit note encoding/decoding
- `types.ts` — shared types

## Entry
- `src/main.tsx` — React root
- `src/App.tsx` — Router with Deposit/Withdraw/Notes pages
- `src/index.css` — Tailwind + CSS variables
