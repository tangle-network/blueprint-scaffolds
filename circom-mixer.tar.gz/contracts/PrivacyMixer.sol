// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract IVerifier {
    function verifyProof(
        uint[2] calldata _pA,
        uint[2][2] calldata _pB,
        uint[2] calldata _pC,
        uint[5] calldata _pubSignals
    ) external view returns (bool) {
        return true;
    }
}

contract PrivacyMixer {
    uint256 public constant LEVELS = 20;
    uint256 public constant FIELD_SIZE = 21888242871839275222246405745257275088548364400416034343698204186575808495617;

    struct Denomination {
        uint256 amount;
        bool active;
        uint256 depositCount;
    }

    mapping(uint256 => Denomination) public denominations;
    mapping(uint256 => bool) public nullifierHashes;
    mapping(uint256 => bool) public commitments;
    uint256[] public commitmentList;

    IVerifier public verifier;

    uint256 public immutable MERKLE_TREE_HEIGHT = 20;
    bytes32[] public filledSubtrees;
    bytes32 public currentRoot;
    uint32 public nextIndex;

    event Deposit(bytes32 indexed commitment, uint256 leafIndex, uint256 denomination);
    event Withdrawal(address to, uint256 nullifierHash, uint256 fee);
    event NewCommitment(bytes32 commitment, uint256 index);

    constructor(address _verifier) {
        verifier = IVerifier(_verifier);

        for (uint256 i = 0; i < MERKLE_TREE_HEIGHT; i++) {
            filledSubtrees.push(zeros(i));
        }
        currentRoot = zeros(MERKLE_TREE_HEIGHT);

        denominations[0] = Denomination(0.1 ether, true, 0);
        denominations[1] = Denomination(1 ether, true, 0);
        denominations[2] = Denomination(10 ether, true, 0);
        denominations[3] = Denomination(100 ether, true, 0);
    }

    function deposit(uint256 _commitment, uint256 _denominationId) external payable {
        Denomination storage denom = denominations[_denominationId];
        require(denom.active, "Denomination not active");
        require(msg.value == denom.amount, "Incorrect deposit amount");
        require(!commitments[_commitment], "Commitment already exists");

        commitments[_commitment] = true;
        commitmentList.push(_commitment);
        denom.depositCount++;

        bytes32 leaf = bytes32(_commitment);
        _insert(leaf);

        emit Deposit(leaf, nextIndex - 1, _denominationId);
    }

    function withdraw(
        uint[2] calldata _proofA,
        uint[2][2] calldata _proofB,
        uint[2] calldata _proofC,
        uint256 _root,
        uint256 _nullifierHash,
        address payable _recipient,
        address payable _relayer,
        uint256 _fee,
        uint256 _refund
    ) external {
        require(_fee <= 1 ether, "Fee exceeds limit");
        require(!nullifierHashes[_nullifierHash], "Already withdrawn");

        nullifierHashes[_nullifierHash] = true;

        require(verifier.verifyProof(_proofA, _proofB, _proofC, [_root, _nullifierHash, uint256(uint160(_recipient)), uint256(uint160(_relayer)), _fee]), "Invalid proof");

        _recipient.transfer(msg.value - _fee);
        if (_fee > 0) {
            _relayer.transfer(_fee);
        }

        emit Withdrawal(_recipient, _nullifierHash, _fee);
    }

    function isSpent(uint256 _nullifierHash) external view returns (bool) {
        return nullifierHashes[_nullifierHash];
    }

    function _insert(bytes32 _leaf) internal {
        require(nextIndex < uint32(2) ** uint32(MERKLE_TREE_HEIGHT), "Tree is full");

        bytes32 current = _leaf;
        uint32 currentIndex = nextIndex;

        for (uint256 i = 0; i < MERKLE_TREE_HEIGHT; i++) {
            if (currentIndex % 2 == 0) {
                filledSubtrees[i] = current;
                current = hashLeftRight(current, zeros(i));
            } else {
                current = hashLeftRight(filledSubtrees[i], current);
            }
            currentIndex /= 2;
        }

        currentRoot = current;
        nextIndex++;

        emit NewCommitment(_leaf, nextIndex - 1);
    }

    function hashLeftRight(bytes32 _left, bytes32 _right) internal pure returns (bytes32) {
        return keccak256(abi.encodePacked(_left, _right));
    }

    function zeros(uint256 i) internal pure returns (bytes32) {
        bytes32[] memory zerosArr = new bytes32[](33);
        zerosArr[0] = bytes32(0);
        for (uint256 j = 1; j <= 32; j++) {
            zerosArr[j] = keccak256(abi.encodePacked(zerosArr[j - 1], zerosArr[j - 1]));
        }
        return zerosArr[i];
    }
}
