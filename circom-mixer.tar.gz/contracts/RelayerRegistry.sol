// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract RelayerRegistry {
    struct Relayer {
        address operator;
        uint256 fee;
        bool active;
        uint256 totalRewards;
    }

    mapping(address => Relayer) public relayers;
    address[] public relayerList;

    event RelayerRegistered(address indexed relayer, uint256 fee);
    event RelayerUpdated(address indexed relayer, uint256 newFee);
    event RelayerDeactivated(address indexed relayer);

    function registerRelayer(uint256 _fee) external {
        require(_fee > 0 && _fee <= 1 ether, "Invalid fee");
        require(relayers[msg.sender].operator == address(0), "Already registered");

        relayers[msg.sender] = Relayer({
            operator: msg.sender,
            fee: _fee,
            active: true,
            totalRewards: 0
        });
        relayerList.push(msg.sender);

        emit RelayerRegistered(msg.sender, _fee);
    }

    function updateFee(uint256 _newFee) external {
        require(relayers[msg.sender].active, "Not active");
        require(_newFee > 0 && _newFee <= 1 ether, "Invalid fee");
        relayers[msg.sender].fee = _newFee;
        emit RelayerUpdated(msg.sender, _newFee);
    }

    function deactivate() external {
        relayers[msg.sender].active = false;
        emit RelayerDeactivated(msg.sender);
    }

    function getActiveRelayers() external view returns (address[] memory) {
        uint256 count = 0;
        for (uint256 i = 0; i < relayerList.length; i++) {
            if (relayers[relayerList[i]].active) count++;
        }

        address[] memory active = new address[](count);
        uint256 idx = 0;
        for (uint256 i = 0; i < relayerList.length; i++) {
            if (relayers[relayerList[i]].active) {
                active[idx] = relayerList[i];
                idx++;
            }
        }
        return active;
    }
}
