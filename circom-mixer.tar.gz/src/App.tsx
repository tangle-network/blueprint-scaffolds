import { useEffect, useMemo, useState } from "react";
import {
  createDepositNote,
  createWithdrawalBundle,
  makePoolKey,
  poolLabel,
  pools,
  relayers,
  type DepositNote
} from "./lib/mixer";
import { shortHex } from "./lib/crypto";

const STORAGE_KEY = "privacy-mixer-notes";

function loadStoredNotes(): DepositNote[] {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) {
    return [];
  }

  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as DepositNote[]) : [];
  } catch {
    return [];
  }
}

export default function App() {
  const [selectedPool, setSelectedPool] = useState(makePoolKey(pools[0]));
  const [notes, setNotes] = useState<DepositNote[]>([]);
  const [activeNoteId, setActiveNoteId] = useState<string>("");
  const [recipient, setRecipient] = useState("0x9f8F72aA9304c8B593d555F12ef6589cC3A579A2");
  const [selectedRelayer, setSelectedRelayer] = useState<string>(relayers[0].id);
  const [status, setStatus] = useState("Ready");
  const [withdrawPayload, setWithdrawPayload] = useState("");

  useEffect(() => {
    const restored = loadStoredNotes();
    setNotes(restored);
    if (restored[0]) {
      setActiveNoteId(restored[0].id);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
  }, [notes]);

  const activeNote = notes.find((note) => note.id === activeNoteId) ?? null;
  const relayer = relayers.find((candidate) => candidate.id === selectedRelayer) ?? relayers[0];

  const poolSummaries = useMemo(
    () =>
      pools.map((pool) => {
        const poolKey = makePoolKey(pool);
        const poolNotes = notes.filter((note) => note.poolKey === poolKey);
        return {
          ...pool,
          poolKey,
          commitments: poolNotes.length
        };
      }),
    [notes]
  );

  async function handleDeposit() {
    setStatus("Creating commitment and note...");
    const note = await createDepositNote(selectedPool);
    setNotes((current) => [note, ...current]);
    setActiveNoteId(note.id);
    setStatus(`Deposited into ${poolLabel(note.poolKey)} pool. Store the note before withdrawing.`);
  }

  async function handleWithdraw() {
    if (!activeNote) {
      setStatus("Select a note before preparing a withdrawal.");
      return;
    }

    setStatus("Building Merkle proof and relayer payload...");

    try {
      const payload = await createWithdrawalBundle({
        note: activeNote,
        notes,
        recipient,
        relayer
      });

      setWithdrawPayload(JSON.stringify(payload, null, 2));
      setStatus("Withdrawal bundle prepared. Send it to the relayer endpoint.");
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Withdrawal bundle failed.");
    }
  }

  function clearNotes() {
    setNotes([]);
    setActiveNoteId("");
    setWithdrawPayload("");
    setStatus("Local note vault cleared.");
  }

  return (
    <div className="shell">
      <header className="hero">
        <div>
          <p className="eyebrow">Circom + Groth16 + Meta-Privacy</p>
          <h1>Privacy Mixer</h1>
          <p className="lede">
            Fixed denomination pools with commitment deposits, nullifier-based withdrawals, Merkle proofs,
            and a relayer handoff that breaks the wallet-to-recipient link.
          </p>
        </div>
        <div className="hero-card">
          <h2>Workflow</h2>
          <ol>
            <li>Deposit into a fixed pool and store the generated note.</li>
            <li>Wait for more commitments to accumulate in the Merkle tree.</li>
            <li>Generate a withdrawal bundle and submit it through a relayer.</li>
          </ol>
        </div>
      </header>

      <main className="grid">
        <section className="panel">
          <div className="panel-header">
            <div>
              <p className="kicker">1. Deposit</p>
              <h2>Commitment mint</h2>
            </div>
            <button onClick={handleDeposit}>Create deposit note</button>
          </div>

          <label>
            Pool
            <select value={selectedPool} onChange={(event) => setSelectedPool(event.target.value)}>
              {pools.map((pool) => (
                <option key={makePoolKey(pool)} value={makePoolKey(pool)}>
                  {pool.symbol} {pool.denomination}
                </option>
              ))}
            </select>
          </label>

          <div className="pool-list">
            {poolSummaries.map((pool) => (
              <article key={pool.poolKey} className="pool-card">
                <p>{pool.symbol}</p>
                <strong>{pool.denomination}</strong>
                <span>{pool.commitments} commitments</span>
              </article>
            ))}
          </div>
        </section>

        <section className="panel">
          <div className="panel-header">
            <div>
              <p className="kicker">2. Notes</p>
              <h2>Local vault</h2>
            </div>
            <button className="ghost" onClick={clearNotes}>
              Clear
            </button>
          </div>

          <div className="notes">
            {notes.length === 0 ? (
              <p className="empty">No notes yet. Create a deposit to seed the Merkle tree.</p>
            ) : (
              notes.map((note) => (
                <button
                  className={`note-card ${note.id === activeNoteId ? "active" : ""}`}
                  key={note.id}
                  onClick={() => setActiveNoteId(note.id)}
                >
                  <strong>{poolLabel(note.poolKey)}</strong>
                  <span>Commitment {shortHex(note.commitment)}</span>
                  <span>Nullifier {shortHex(note.nullifierHash)}</span>
                </button>
              ))
            )}
          </div>

          {activeNote ? (
            <pre className="note-preview">{JSON.stringify(activeNote, null, 2)}</pre>
          ) : null}
        </section>

        <section className="panel">
          <div className="panel-header">
            <div>
              <p className="kicker">3. Withdraw</p>
              <h2>Relayer handoff</h2>
            </div>
            <button onClick={handleWithdraw}>Prepare withdrawal</button>
          </div>

          <label>
            Recipient
            <input value={recipient} onChange={(event) => setRecipient(event.target.value)} />
          </label>

          <label>
            Relayer
            <select value={selectedRelayer} onChange={(event) => setSelectedRelayer(event.target.value)}>
              {relayers.map((candidate) => (
                <option key={candidate.id} value={candidate.id}>
                  {candidate.name}
                </option>
              ))}
            </select>
          </label>

          <div className="relayer-meta">
            <span>Endpoint: {relayer.endpoint}</span>
            <span>Fee: {relayer.feeBps / 100}%</span>
          </div>

          <textarea
            className="payload"
            readOnly
            value={withdrawPayload}
            placeholder="Prepared proof input and public signals will appear here."
          />
        </section>
      </main>

      <footer className="status-bar">
        <strong>Status</strong>
        <span>{status}</span>
      </footer>
    </div>
  );
}
