import type { DepositNote } from "./types";
import {
  generateNullifier,
  generateSecret,
  computeCommitment,
  computeNullifierHash,
} from "./crypto";

export function createDepositNote(
  denomination: string,
  amount: string,
  currency: string = "ETH",
  network: string = "mainnet"
): DepositNote {
  const nullifier = generateNullifier();
  const secret = generateSecret();
  const commitment = computeCommitment(nullifier, secret);

  return {
    id: crypto.randomUUID(),
    denomination,
    amount,
    currency,
    nullifier: nullifier.toString(),
    secret: secret.toString(),
    commitment: commitment.toString(),
    network,
    createdAt: Date.now(),
    spent: false,
  };
}

export function encodeNote(note: DepositNote): string {
  const payload = JSON.stringify({
    n: note.nullifier,
    s: note.secret,
    d: note.denomination,
    a: note.amount,
    c: note.currency,
    net: note.network,
  });
  return `privacy-mixer-${btoa(payload)}`;
}

export function decodeNote(encoded: string): DepositNote | null {
  try {
    if (!encoded.startsWith("privacy-mixer-")) return null;
    const payload = atob(encoded.replace("privacy-mixer-", ""));
    const data = JSON.parse(payload);
    const nullifier = BigInt(data.n);
    const secret = BigInt(data.s);
    const commitment = computeCommitment(nullifier, secret);
    const nullifierHash = computeNullifierHash(nullifier);

    return {
      id: crypto.randomUUID(),
      denomination: data.d,
      amount: data.a,
      currency: data.c,
      nullifier: nullifier.toString(),
      secret: secret.toString(),
      commitment: commitment.toString(),
      network: data.net,
      createdAt: Date.now(),
      spent: false,
      nullifierHash: nullifierHash.toString(),
    };
  } catch {
    return null;
  }
}
