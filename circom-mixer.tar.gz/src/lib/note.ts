import type { DepositNote } from "@/types";
import {
  generateNullifier,
  generateSecret,
  computeCommitment,
  computeNullifierHash,
} from "./crypto";

export function createDepositNote(
  denomination: string,
  token: string,
  chainId: number
): DepositNote {
  const nullifier = generateNullifier();
  const secret = generateSecret();
  const commitment = computeCommitment(nullifier, secret);

  return {
    id: crypto.randomUUID(),
    denomination,
    token,
    chainId,
    nullifier: nullifier.toString(),
    secret: secret.toString(),
    commitment: commitment.toString(),
    createdAt: Date.now(),
    status: "deposited",
  };
}

export function encodeNote(note: DepositNote): string {
  const payload = JSON.stringify({
    n: note.nullifier,
    s: note.secret,
    d: note.denomination,
    t: note.token,
    c: note.chainId,
  });
  return `privacy-mixer-${btoa(payload)}`;
}

export function decodeNote(encoded: string): DepositNote | null {
  try {
    if (!encoded.startsWith("privacy-mixer-")) return null;
    const payload = atob(encoded.replace("privacy-mixer-", ""));
    const data = JSON.parse(payload);
    const nullifier = BigInt(data.n);
    const secret = BigInt(data.s);
    const commitment = computeCommitment(nullifier, secret);

    return {
      id: crypto.randomUUID(),
      denomination: data.d,
      token: data.t,
      chainId: data.c,
      nullifier: nullifier.toString(),
      secret: secret.toString(),
      commitment: commitment.toString(),
      createdAt: Date.now(),
      status: "deposited",
    };
  } catch {
    return null;
  }
}
