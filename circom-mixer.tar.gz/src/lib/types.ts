export const MERKLE_TREE_HEIGHT = 20;
export const FIELD_SIZE = BigInt(
  "21888242871839275222246405745257275088548364400416034343698204186575808495617"
);

export interface DepositNote {
  id: string;
  denomination: string;
  amount: string;
  currency: string;
  nullifier: string;
  secret: string;
  commitment: string;
  network: string;
  createdAt: number;
  spent: boolean;
  nullifierHash?: string;
}

export interface RelayerInfo {
  address: string;
  fee: string;
  url: string;
  active: boolean;
}

export interface MerkleProof {
  root: string;
  pathElements: string[];
  pathIndices: number[];
  leaf: string;
}

export interface WithdrawProof {
  proofA: [string, string];
  proofB: [[string, string], [string, string]];
  proofC: [string, string];
  root: string;
  nullifierHash: string;
  recipient: string;
  relayer: string;
  fee: string;
  refund: string;
}

export type DenominationOption = {
  id: number;
  label: string;
  amount: string;
};
