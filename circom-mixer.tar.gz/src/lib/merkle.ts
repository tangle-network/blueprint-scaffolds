import { MERKLE_TREE_HEIGHT } from "./types";
import { poseidonHash } from "./crypto";
import type { MerkleProof } from "./types";

const ZERO_VALUE =
  BigInt(
    "21663839004416932945382355908790599225266501822907911457504978515578255421292"
  );

function getZeroes(levels: number): bigint[] {
  const zeros: bigint[] = [ZERO_VALUE];
  for (let i = 1; i <= levels; i++) {
    zeros.push(poseidonHash([zeros[i - 1], zeros[i - 1]]));
  }
  return zeros;
}

export class MerkleTree {
  levels: number;
  capacity: number;
  leaves: bigint[];
  layers: bigint[][];
  zeros: bigint[];

  constructor(levels: number = MERKLE_TREE_HEIGHT) {
    this.levels = levels;
    this.capacity = 2 ** levels;
    this.leaves = [];
    this.zeros = getZeroes(levels);
    this.layers = [];
    this._buildLayers();
  }

  _buildLayers() {
    this.layers = [this.leaves.length > 0 ? [...this.leaves] : []];
    for (let i = 0; i < this.levels; i++) {
      const prev = this.layers[i];
      const layer: bigint[] = [];
      for (let j = 0; j < Math.ceil(prev.length / 2); j++) {
        const left = prev[2 * j] ?? this.zeros[i];
        const right = prev[2 * j + 1] ?? this.zeros[i];
        layer.push(poseidonHash([left, right]));
      }
      this.layers.push(layer);
    }
  }

  insert(leaf: bigint) {
    if (this.leaves.length >= this.capacity) {
      throw new Error("Tree is full");
    }
    this.leaves.push(leaf);
    this._buildLayers();
  }

  getRoot(): bigint {
    if (this.layers[this.levels].length === 0) return this.zeros[this.levels];
    return this.layers[this.levels][0];
  }

  getProof(index: number): MerkleProof {
    if (index < 0 || index >= this.leaves.length) {
      throw new Error("Index out of bounds");
    }

    const pathElements: string[] = [];
    const pathIndices: number[] = [];

    for (let i = 0; i < this.levels; i++) {
      const layerIndex = Math.floor(index / 2 ** i);
      const siblingIndex = layerIndex ^ 1;
      const layer = this.layers[i];

      pathIndices.push(layerIndex % 2);
      if (siblingIndex < layer.length) {
        pathElements.push(layer[siblingIndex].toString());
      } else {
        pathElements.push(this.zeros[i].toString());
      }
    }

    return {
      root: this.getRoot().toString(),
      pathElements,
      pathIndices,
      leaf: this.leaves[index].toString(),
    };
  }

  getIndex(leaf: bigint): number {
    return this.leaves.findIndex((l) => l === leaf);
  }

  getLeaves(): bigint[] {
    return [...this.leaves];
  }
}

export function createProof(
  leaf: bigint,
  leaves: string[],
  index: number
): MerkleProof {
  const tree = new MerkleTree(MERKLE_TREE_HEIGHT);
  for (const l of leaves) {
    tree.insert(BigInt(l));
  }
  return tree.getProof(index);
}
