import { poseidonHash } from "./crypto";

export type MerkleProof = {
  root: bigint;
  pathElements: bigint[];
  pathIndices: number[];
};

export async function computeZeroes(depth: number) {
  const zeroes: bigint[] = [0n];
  for (let level = 0; level < depth; level += 1) {
    zeroes.push(await poseidonHash([zeroes[level], zeroes[level]]));
  }
  return zeroes;
}

export async function buildMerkleTree(leaves: bigint[], depth: number) {
  const zeroes = await computeZeroes(depth);
  const capacity = 2 ** depth;
  const paddedLeaves = Array.from({ length: capacity }, (_, index) => leaves[index] ?? zeroes[0]);
  const layers: bigint[][] = [paddedLeaves];

  for (let level = 0; level < depth; level += 1) {
    const current = layers[level];
    const next: bigint[] = [];
    for (let i = 0; i < current.length; i += 2) {
      next.push(await poseidonHash([current[i], current[i + 1]]));
    }
    layers.push(next);
  }

  return { zeroes, layers, root: layers[layers.length - 1][0] };
}

export async function createProof(leaves: bigint[], leafIndex: number, depth: number): Promise<MerkleProof> {
  const tree = await buildMerkleTree(leaves, depth);
  const pathElements: bigint[] = [];
  const pathIndices: number[] = [];
  let index = leafIndex;

  for (let level = 0; level < depth; level += 1) {
    const siblingIndex = index ^ 1;
    pathElements.push(tree.layers[level][siblingIndex]);
    pathIndices.push(index & 1);
    index = Math.floor(index / 2);
  }

  return {
    root: tree.root,
    pathElements,
    pathIndices
  };
}
