import { addressToField, poseidonHash, randomFieldElement, toHex } from "./crypto";
import { createProof } from "./merkle";

export const TREE_DEPTH = 8;

export const pools = [
  { symbol: "ETH", denomination: "0.10", amountWei: 100000000000000000n },
  { symbol: "ETH", denomination: "1.00", amountWei: 1000000000000000000n },
  { symbol: "DAI", denomination: "100", amountWei: 100000000000000000000n }
] as const;

export const relayers = [
  {
    id: "owl",
    name: "Owl Relay",
    feeBps: 20,
    endpoint: "https://owl-relay.example/api/v1/withdraw",
    address: "0x1111111111111111111111111111111111111111"
  },
  {
    id: "mesh",
    name: "Mesh Private RPC",
    feeBps: 35,
    endpoint: "https://mesh-private.example/api/v1/withdraw",
    address: "0x2222222222222222222222222222222222222222"
  },
  {
    id: "shadow",
    name: "Shadow Router",
    feeBps: 50,
    endpoint: "https://shadow-router.example/api/v1/withdraw",
    address: "0x3333333333333333333333333333333333333333"
  }
] as const;

export type Pool = (typeof pools)[number];
export type Relayer = (typeof relayers)[number];

export type DepositNote = {
  id: string;
  createdAt: string;
  poolKey: string;
  secret: string;
  nullifier: string;
  commitment: string;
  nullifierHash: string;
};

export async function createDepositNote(poolKey: string): Promise<DepositNote> {
  const secret = randomFieldElement();
  const nullifier = randomFieldElement();
  const commitment = await poseidonHash([secret, nullifier]);
  const nullifierHash = await poseidonHash([nullifier]);

  return {
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
    poolKey,
    secret: toHex(secret),
    nullifier: toHex(nullifier),
    commitment: toHex(commitment),
    nullifierHash: toHex(nullifierHash)
  };
}

export function poolLabel(poolKey: string) {
  return poolKey.replace("-", " ");
}

export function getPool(poolKey: string) {
  return pools.find((pool) => makePoolKey(pool) === poolKey);
}

export function makePoolKey(pool: Pool) {
  return `${pool.symbol}-${pool.denomination}`;
}

export async function createWithdrawalBundle({
  note,
  notes,
  recipient,
  relayer,
  refund = "0"
}: {
  note: DepositNote;
  notes: DepositNote[];
  recipient: string;
  relayer: Relayer;
  refund?: string;
}) {
  const leaves = notes
    .filter((candidate) => candidate.poolKey === note.poolKey)
    .map((candidate) => BigInt(candidate.commitment));
  const leafIndex = notes
    .filter((candidate) => candidate.poolKey === note.poolKey)
    .findIndex((candidate) => candidate.id === note.id);

  if (leafIndex < 0) {
    throw new Error("Note was not found in the selected pool");
  }

  const proof = await createProof(leaves, leafIndex, TREE_DEPTH);
  const pool = getPool(note.poolKey);

  if (!pool) {
    throw new Error("Pool configuration missing");
  }

  const fee = (pool.amountWei * BigInt(relayer.feeBps)) / 10000n;
  const recipientField = addressToField(recipient);
  const relayerField = addressToField(relayer.address);

  return {
    publicSignals: {
      root: toHex(proof.root),
      nullifierHash: note.nullifierHash,
      recipient,
      relayer: relayer.address,
      relayerEndpoint: relayer.endpoint,
      fee: fee.toString(),
      refund
    },
    witnessInput: {
      root: proof.root.toString(),
      nullifierHash: BigInt(note.nullifierHash).toString(),
      recipient: recipientField.toString(),
      relayer: relayerField.toString(),
      fee: fee.toString(),
      refund,
      secret: BigInt(note.secret).toString(),
      nullifier: BigInt(note.nullifier).toString(),
      pathElements: proof.pathElements.map((value) => value.toString()),
      pathIndices: proof.pathIndices
    }
  };
}
