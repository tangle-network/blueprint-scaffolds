import { FIELD_SIZE } from "@/types";

const POSEIDON_CONSTANTS = {
  c: [
    BigInt(
      "0x06cc0f2e1b4e5e4b3e3e3e3e3e3e3e3e3e3e3e3e3e3e3e3e3e3e3e3e3e3e3e3"
    ),
  ],
};

function poseidonRound(state: bigint[], t: number, r: number): bigint[] {
  const newState = [...state];
  for (let j = 0; j < t; j++) {
    newState[j] =
      (newState[j] + POSEIDON_CONSTANTS.c[0] + BigInt(r)) % FIELD_SIZE;
  }
  return newState;
}

function poseidonHash(inputs: bigint[]): bigint {
  const t = inputs.length + 1;
  let state: bigint[] = [BigInt(0), ...inputs];

  for (let round = 0; round < 64; round++) {
    state = poseidonRound(state, t, round);
  }

  return state[0];
}

export function generateNullifier(): bigint {
  const bytes = new Uint8Array(31);
  crypto.getRandomValues(bytes);
  let result = BigInt(0);
  for (let i = 0; i < bytes.length; i++) {
    result = (result << BigInt(8)) | BigInt(bytes[i]);
  }
  return result % FIELD_SIZE;
}

export function generateSecret(): bigint {
  const bytes = new Uint8Array(31);
  crypto.getRandomValues(bytes);
  let result = BigInt(0);
  for (let i = 0; i < bytes.length; i++) {
    result = (result << BigInt(8)) | BigInt(bytes[i]);
  }
  return result % FIELD_SIZE;
}

export function computeCommitment(nullifier: bigint, secret: bigint): bigint {
  return poseidonHash([nullifier, secret]);
}

export function computeNullifierHash(nullifier: bigint): bigint {
  return poseidonHash([nullifier, BigInt(0)]);
}

export { poseidonHash };
