type PoseidonFn = ((inputs: bigint[]) => bigint[]) & {
  F: {
    toString(value: bigint): string;
  };
};

let poseidonPromise: Promise<PoseidonFn> | null = null;

function getPoseidon() {
  if (!poseidonPromise) {
    poseidonPromise = import("circomlibjs").then((module) => module.buildPoseidon() as Promise<PoseidonFn>);
  }

  return poseidonPromise;
}

export async function poseidonHash(inputs: bigint[]) {
  const poseidon = await getPoseidon();
  return BigInt(poseidon.F.toString(poseidon(inputs as bigint[]) as unknown as bigint));
}

export function randomFieldElement() {
  const bytes = new Uint8Array(31);
  crypto.getRandomValues(bytes);
  const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
  return BigInt(`0x${hex}`);
}

export function toHex(value: bigint) {
  return `0x${value.toString(16)}`;
}

export function shortHex(value: bigint | string) {
  const normalized = typeof value === "bigint" ? toHex(value) : value;
  return `${normalized.slice(0, 10)}...${normalized.slice(-6)}`;
}

export function addressToField(address: string) {
  if (!/^0x[a-fA-F0-9]{40}$/.test(address)) {
    throw new Error("Recipient must be a 20-byte hex address.");
  }

  return BigInt(address);
}
