import { useMixerStore } from "@/store/useMixerStore";
import { createDepositNote } from "@/lib/note";
import { encodeNote } from "@/lib/note";
import type { DepositPool, Relayer } from "@/types";

export function useMixer() {
  const store = useMixerStore();

  const deposit = (pool: DepositPool) => {
    store.setDepositing(true);
    const note = createDepositNote(pool.denomination, pool.token, pool.chainId);
    store.addNote(note);
    const encoded = encodeNote(note);
    setTimeout(() => {
      store.updateNoteStatus(note.id, "deposited");
      store.setDepositing(false);
    }, 2000);
    return { note, encoded };
  };

  const withdraw = (
    noteId: string,
    recipient: string,
    relayer: Relayer | null
  ) => {
    store.setWithdrawing(true);
    setTimeout(() => {
      store.updateNoteStatus(noteId, "withdrawn");
      store.setWithdrawing(false);
    }, 3000);
  };

  return {
    ...store,
    deposit,
    withdraw,
  };
}
