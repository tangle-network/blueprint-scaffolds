import { useState, useEffect, useCallback } from "react";
import type { DepositNote } from "@/types";

const STORAGE_KEY = "privacy-mixer-notes";

function loadNotes(): DepositNote[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveNotes(notes: DepositNote[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
}

export function useNote() {
  const [notes, setNotes] = useState<DepositNote[]>(loadNotes);

  useEffect(() => {
    saveNotes(notes);
  }, [notes]);

  const addNote = useCallback((note: DepositNote) => {
    setNotes((prev) => [...prev, note]);
  }, []);

  const removeNote = useCallback((id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
  }, []);

  const updateNote = useCallback((id: string, updates: Partial<DepositNote>) => {
    setNotes((prev) =>
      prev.map((n) => (n.id === id ? { ...n, ...updates } : n))
    );
  }, []);

  return { notes, addNote, removeNote, updateNote };
}
