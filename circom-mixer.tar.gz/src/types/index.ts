export interface DepositNote {
  id: string;
  commitment: string;
  nullifier: string;
  nullifierHash?: string;
  secret: string;
  denomination: string;
  token: string;
  chainId: number;
  createdAt: number;
  status: "deposited" | "withdrawn" | "expired";
  txHash?: string;
  withdrawalTxHash?: string;
  relayerUsed?: string;
  amount?: string;
  currency?: string;
  network?: string;
  spent?: boolean;
}

export interface DepositPool {
  denomination: string;
  token: string;
  tokenAddress: string;
  chainId: number;
  balance: string;
  totalDeposits: number;
  treeDepth: number;
  merkleRoot: string;
  apy?: string;
}

export interface Relayer {
  id: string;
  url: string;
  address: string;
  fee: string;
  feeToken: string;
  reputation: number;
  status: "online" | "offline" | "busy";
  supportedChains: number[];
  totalRelayed: number;
  responseTime: number;
  active?: boolean;
}

export interface WithdrawalRequest {
  id: string;
  nullifierHash: string;
  recipient: string;
  relayer?: string;
  fee: string;
  proof: string;
  root: string;
  status: "pending" | "submitting" | "confirmed" | "failed";
}

export interface MerkleProofData {
  root: string;
  pathElements: string[];
  pathIndices: number[];
  leaf: string;
}

export interface WithdrawProof {
  proofA: [string, string];
  proofB: [[string, string], [string, string]];
  proofC: [string, string];
  root: string;
  nullifierHash: string;
  recipient: string;
  relayer: string;
  fee: string;
  refund: string;
}

export interface CircuitArtifact {
  name: string;
  version: string;
  numConstraints: number;
  provingKeySize: string;
  verificationKey: string;
}

export type TabValue = "deposit" | "withdraw" | "notes" | "relayers" | "circuits";

export const MERKLE_TREE_HEIGHT = 20;
export const FIELD_SIZE = BigInt(
  "21888242871839275222246405745257275088548364400416034343698204186575808495617"
);

export type DenominationOption = {
  id: number;
  label: string;
  amount: string;
};
