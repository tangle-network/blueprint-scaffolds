import { create } from "zustand";
import type { DepositNote, DepositPool, Relayer, WithdrawalRequest } from "@/types";

interface MixerState {
  pools: DepositPool[];
  notes: DepositNote[];
  relayers: Relayer[];
  selectedPool: DepositPool | null;
  selectedRelayer: Relayer | null;
  withdrawalRequests: WithdrawalRequest[];
  isDepositing: boolean;
  isWithdrawing: boolean;
  isConnected: boolean;
  account: string | null;

  setSelectedPool: (pool: DepositPool | null) => void;
  setSelectedRelayer: (relayer: Relayer | null) => void;
  addNote: (note: DepositNote) => void;
  removeNote: (id: string) => void;
  updateNoteStatus: (id: string, status: DepositNote["status"]) => void;
  setDepositing: (v: boolean) => void;
  setWithdrawing: (v: boolean) => void;
  setConnected: (v: boolean, account?: string | null) => void;
  addWithdrawalRequest: (req: WithdrawalRequest) => void;
  updateWithdrawalStatus: (id: string, status: WithdrawalRequest["status"]) => void;
}

export const useMixerStore = create<MixerState>((set) => ({
  pools: [
    {
      denomination: "0.1",
      token: "ETH",
      tokenAddress: "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE",
      chainId: 1,
      balance: "45.7",
      totalDeposits: 457,
      treeDepth: 20,
      merkleRoot: "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
    },
    {
      denomination: "1",
      token: "ETH",
      tokenAddress: "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE",
      chainId: 1,
      balance: "128.0",
      totalDeposits: 128,
      treeDepth: 20,
      merkleRoot: "0xabcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890",
    },
    {
      denomination: "10",
      token: "ETH",
      tokenAddress: "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE",
      chainId: 1,
      balance: "320.0",
      totalDeposits: 32,
      treeDepth: 20,
      merkleRoot: "0x567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234",
      apy: "2.4",
    },
    {
      denomination: "100",
      token: "ETH",
      tokenAddress: "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE",
      chainId: 1,
      balance: "500.0",
      totalDeposits: 5,
      treeDepth: 20,
      merkleRoot: "0x90abcdef1234567890abcdef1234567890abcdef1234567890abcdef12345678",
      apy: "3.1",
    },
    {
      denomination: "100",
      token: "USDC",
      tokenAddress: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
      chainId: 1,
      balance: "45000",
      totalDeposits: 450,
      treeDepth: 20,
      merkleRoot: "0x4567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef12",
    },
    {
      denomination: "1000",
      token: "USDC",
      tokenAddress: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
      chainId: 1,
      balance: "18000",
      totalDeposits: 18,
      treeDepth: 20,
      merkleRoot: "0x7890abcdef1234567890abcdef1234567890abcdef1234567890abcdef123456",
      apy: "1.8",
    },
    {
      denomination: "10000",
      token: "DAI",
      tokenAddress: "0x6B175474E89094C44Da98b954EedeAC495271d0F",
      chainId: 1,
      balance: "120000",
      totalDeposits: 12,
      treeDepth: 20,
      merkleRoot: "0xcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890ab",
      apy: "2.1",
    },
  ],

  notes: [
    {
      id: "note-001",
      commitment: "0xaaa1112223334445556667778889990001112223334445556667778889990001",
      nullifier: "987654321098765432109876543210",
      secret: "123456789012345678901234567890",
      denomination: "1",
      token: "ETH",
      chainId: 1,
      createdAt: Date.now() - 86400000 * 3,
      status: "deposited",
      txHash: "0xfedcba0987654321fedcba0987654321fedcba0987654321fedcba0987654321",
    },
    {
      id: "note-002",
      commitment: "0xbbb2223334445556667778889990001112223334445556667778889990001112",
      nullifier: "111222333444555666777888999000",
      secret: "999888777666555444333222111000",
      denomination: "10",
      token: "ETH",
      chainId: 1,
      createdAt: Date.now() - 86400000 * 7,
      status: "withdrawn",
      txHash: "0xabc123def456abc123def456abc123def456abc123def456abc123def456abc1",
      withdrawalTxHash: "0x111222333444555666777888999aaabbbcccdddeeefff0001112223334445556",
      relayerUsed: "0xRelayer2Addr",
    },
    {
      id: "note-003",
      commitment: "0xccc3334445556667778889990001112223334445556667778889990001112223",
      nullifier: "555666777888999000111222333444",
      secret: "444555666777888999000111222333",
      denomination: "0.1",
      token: "ETH",
      chainId: 1,
      createdAt: Date.now() - 86400000 * 1,
      status: "deposited",
      txHash: "0xddd4445556667778889990001112223334445556667778889990001112223334",
    },
  ],

  relayers: [
    {
      id: "relayer-1",
      url: "https://relayer1.privacymixer.eth",
      address: "0x1234567890abcdef1234567890abcdef12345678",
      fee: "0.1",
      feeToken: "ETH",
      reputation: 99,
      status: "online",
      supportedChains: [1, 10, 42161],
      totalRelayed: 4521,
      responseTime: 120,
    },
    {
      id: "relayer-2",
      url: "https://relayer2.privacymixer.eth",
      address: "0xabcdef1234567890abcdef1234567890abcdef12",
      fee: "0.3",
      feeToken: "ETH",
      reputation: 95,
      status: "online",
      supportedChains: [1, 137],
      totalRelayed: 2834,
      responseTime: 250,
    },
    {
      id: "relayer-3",
      url: "https://relayer3.privacymixer.eth",
      address: "0x9876543210fedcba9876543210fedcba98765432",
      fee: "0.15",
      feeToken: "ETH",
      reputation: 92,
      status: "busy",
      supportedChains: [1],
      totalRelayed: 1567,
      responseTime: 450,
    },
    {
      id: "relayer-4",
      url: "https://relayer4.privacymixer.eth",
      address: "0xfedcba9876543210fedcba9876543210fedcba98",
      fee: "0.5",
      feeToken: "ETH",
      reputation: 85,
      status: "offline",
      supportedChains: [1, 10, 42161, 137],
      totalRelayed: 892,
      responseTime: 800,
    },
    {
      id: "relayer-5",
      url: "https://relayer5.privacymixer.eth",
      address: "0x1111222233334444555566667777888899990000",
      fee: "0.2",
      feeToken: "ETH",
      reputation: 97,
      status: "online",
      supportedChains: [1, 10],
      totalRelayed: 3210,
      responseTime: 180,
    },
  ],

  selectedPool: null,
  selectedRelayer: null,
  withdrawalRequests: [],
  isDepositing: false,
  isWithdrawing: false,
  isConnected: false,
  account: null,

  setSelectedPool: (pool) => set({ selectedPool: pool }),
  setSelectedRelayer: (relayer) => set({ selectedRelayer: relayer }),
  addNote: (note) => set((s) => ({ notes: [...s.notes, note] })),
  removeNote: (id) => set((s) => ({ notes: s.notes.filter((n) => n.id !== id) })),
  updateNoteStatus: (id, status) =>
    set((s) => ({
      notes: s.notes.map((n) => (n.id === id ? { ...n, status } : n)),
    })),
  setDepositing: (v) => set({ isDepositing: v }),
  setWithdrawing: (v) => set({ isWithdrawing: v }),
  setConnected: (v, account) => set({ isConnected: v, account: account ?? null }),
  addWithdrawalRequest: (req) =>
    set((s) => ({ withdrawalRequests: [...s.withdrawalRequests, req] })),
  updateWithdrawalStatus: (id, status) =>
    set((s) => ({
      withdrawalRequests: s.withdrawalRequests.map((r) =>
        r.id === id ? { ...r, status } : r
      ),
    })),
}));
