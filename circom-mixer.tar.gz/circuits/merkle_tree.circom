pragma circom 2.1.0;

include "../node_modules/circomlib/circuits/poseidon.circom";

template MerkleTree(levels) {
    signal input leaves[2 ** levels];
    signal output root;
    signal layers[levels + 1][2 ** levels];

    for (var i = 0; i < 2 ** levels; i++) {
        layers[0][i] <== leaves[i];
    }

    for (var level = 0; level < levels; level++) {
        for (var i = 0; i < 2 ** (levels - level - 1); i++) {
            layers[level + 1][i] <== Poseidon(2)([layers[level][2 * i], layers[level][2 * i + 1]]);
        }
    }

    root <== layers[levels][0];
}

template MerkleInclusionProof(levels) {
    signal input leaf;
    signal input root;
    signal input pathElements[levels];
    signal input pathIndices[levels];

    signal computedRoot;

    component hashers[levels];
    computedRoot <== leaf;

    for (var i = 0; i < levels; i++) {
        hashers[i] = Poseidon(2);

        hashers[i].inputs[0] <== pathIndices[i] === 0 ? computedRoot : pathElements[i];
        hashers[i].inputs[1] <== pathIndices[i] === 0 ? pathElements[i] : computedRoot;
        computedRoot <== hashers[i].out;
    }

    computedRoot === root;
}

component main = MerkleTree(20);
