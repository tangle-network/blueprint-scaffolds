pragma circom 2.1.6;

include "../node_modules/circomlib/circuits/poseidon.circom";

template MerkleTreeChecker(levels) {
    signal input leaf;
    signal input root;
    signal input pathElements[levels];
    signal input pathIndices[levels];

    signal current[levels + 1];
    current[0] <== leaf;

    component hashers[levels];

    for (var i = 0; i < levels; i++) {
        pathIndices[i] * (pathIndices[i] - 1) === 0;

        hashers[i] = Poseidon(2);
        hashers[i].inputs[0] <== current[i] * (1 - pathIndices[i]) + pathElements[i] * pathIndices[i];
        hashers[i].inputs[1] <== current[i] * pathIndices[i] + pathElements[i] * (1 - pathIndices[i]);
        current[i + 1] <== hashers[i].out;
    }

    root === current[levels];
}

template Withdraw(levels) {
    signal input root;
    signal input nullifierHash;
    signal input recipient;
    signal input relayer;
    signal input fee;
    signal input refund;

    signal input secret;
    signal input nullifier;
    signal input pathElements[levels];
    signal input pathIndices[levels];

    signal commitment;
    signal computedNullifierHash;
    signal metadataDigest;

    component commitmentHasher = Poseidon(2);
    commitmentHasher.inputs[0] <== secret;
    commitmentHasher.inputs[1] <== nullifier;
    commitment <== commitmentHasher.out;

    component nullifierHasher = Poseidon(1);
    nullifierHasher.inputs[0] <== nullifier;
    computedNullifierHash <== nullifierHasher.out;

    nullifierHash === computedNullifierHash;

    component treeChecker = MerkleTreeChecker(levels);
    treeChecker.leaf <== commitment;
    treeChecker.root <== root;

    for (var i = 0; i < levels; i++) {
        treeChecker.pathElements[i] <== pathElements[i];
        treeChecker.pathIndices[i] <== pathIndices[i];
    }

    component metadataHasher = Poseidon(4);
    metadataHasher.inputs[0] <== recipient;
    metadataHasher.inputs[1] <== relayer;
    metadataHasher.inputs[2] <== fee;
    metadataHasher.inputs[3] <== refund;
    metadataDigest <== metadataHasher.out;
}

component main {public [root, nullifierHash, recipient, relayer, fee, refund]} = Withdraw(8);
