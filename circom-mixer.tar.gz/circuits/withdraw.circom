pragma circom 2.1.0;

include "../node_modules/circomlib/circuits/poseidon.circom";
include "./merkle_tree.circom";

template Withdraw(levels) {
    signal input nullifier;
    signal input secret;
    signal input root;
    signal input pathElements[levels];
    signal input pathIndices[levels];
    signal input recipient;
    signal input relayer;
    signal input fee;
    signal input refund;

    signal commitment;
    commitment <== Poseidon(2)([nullifier, secret]);

    component proof = MerkleInclusionProof(levels);
    proof.leaf <== commitment;
    proof.root <== root;
    for (var i = 0; i < levels; i++) {
        proof.pathElements[i] <== pathElements[i];
        proof.pathIndices[i] <== pathIndices[i];
    }

    signal nullifierHash;
    nullifierHash <== Poseidon(2)([nullifier, 0]);
}

component main {public [root, recipient, relayer, fee, refund]} = Withdraw(20);
