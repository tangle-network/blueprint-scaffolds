pragma circom 2.1.0;

include "../node_modules/circomlib/circuits/poseidon.circom";

template Deposit() {
    signal input nullifier;
    signal input secret;
    signal output commitment;

    commitment <== Poseidon(2)([nullifier, secret]);
}

component main {public [nullifier]} = Deposit();
