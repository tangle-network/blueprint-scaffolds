export interface ResearchJob {
  id: string;
  query: string;
  status: "pending" | "retrieving" | "ranking" | "reasoning" | "writing" | "evaluating" | "complete" | "failed";
  created_at: string;
  completed_at?: string;
  progress: number;
}

export interface Source {
  id: string;
  title: string;
  url: string;
  snippet: string;
  relevance_score: number;
  credibility_score: number;
  composite_score: number;
  retrieved_at: string;
}

export interface AgentStep {
  id: string;
  job_id: string;
  step_type: "tool_call" | "retrieval" | "ranking" | "reasoning" | "evaluation";
  description: string;
  input: Record<string, unknown>;
  output: Record<string, unknown>;
  timestamp: string;
  duration_ms: number;
}

export interface Citation {
  id: string;
  source_id: string;
  source: Source;
  context: string;
  claim: string;
  confidence: number;
}

export interface ResearchReport {
  job_id: string;
  query: string;
  summary: string;
  sections: ReportSection[];
  citations: Citation[];
  evaluation: EvaluationResult;
  created_at: string;
}

export interface ReportSection {
  title: string;
  content: string;
  citation_ids: string[];
}

export interface EvaluationResult {
  overall_score: number;
  source_diversity: number;
  citation_coverage: number;
  factual_grounding: number;
  coherence: number;
  notes: string;
}
