export type JobStatus = "pending" | "running" | "completed" | "failed";

export interface Source {
  id: string;
  title: string;
  url: string;
  snippet: string;
  relevance_score: number;
  retrieved_at: string;
}

export interface ResearchStep {
  step_number: number;
  step_type: string;
  description: string;
  output: string | null;
  sources_used: string[];
  started_at: string;
  completed_at: string | null;
}

export interface Citation {
  citation_id: string;
  source_id: string;
  quote: string;
  relevance: number;
}

export interface ResearchReport {
  question: string;
  summary: string;
  detailed_answer: string;
  citations: Citation[];
  confidence_score: number;
  steps: ResearchStep[];
  sources: Source[];
  created_at: string;
}

export interface ResearchRequest {
  question: string;
  max_sources: number;
  depth: "quick" | "standard" | "deep";
}

export interface ResearchJob {
  job_id: string;
  question: string;
  status: JobStatus;
  progress: number;
  current_step: string | null;
  report: ResearchReport | null;
  created_at: string;
  updated_at: string;
}
