import { ResearchJob, ResearchRequest } from "./types";

export async function startResearch(
  request: ResearchRequest
): Promise<ResearchJob> {
  const res = await fetch("/api/research", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(request),
  });
  if (!res.ok) throw new Error(`Research request failed: ${res.statusText}`);
  return res.json();
}

export async function getJob(jobId: string): Promise<ResearchJob> {
  const res = await fetch(`/api/research/${jobId}`);
  if (!res.ok) throw new Error(`Failed to fetch job: ${res.statusText}`);
  return res.json();
}

export async function listJobs(): Promise<ResearchJob[]> {
  const res = await fetch("/api/research");
  if (!res.ok) throw new Error(`Failed to list jobs: ${res.statusText}`);
  return res.json();
}
