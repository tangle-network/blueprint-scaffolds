import type { Metadata } from 'next'


export const metadata: Metadata = {
  title: 'research-agent',
  description: 'research-agent',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
