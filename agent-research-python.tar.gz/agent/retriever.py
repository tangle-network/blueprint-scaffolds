from agent.models import Source
from agent.utils import gen_id, now_iso, deterministic_score

KNOWLEDGE_BASE: list[dict] = [
    {
        "title": "Transformer Architecture Explained",
        "url": "https://arxiv.org/abs/1706.03762",
        "content": "The Transformer architecture introduced self-attention mechanisms that revolutionized NLP. It processes tokens in parallel rather than sequentially, enabling significantly faster training. Multi-head attention allows the model to attend to information from different representation subspaces.",
    },
    {
        "title": "BERT: Pre-training of Deep Bidirectional Transformers",
        "url": "https://arxiv.org/abs/1810.04805",
        "content": "BERT introduced masked language modeling for bidirectional pre-training. It achieved state-of-the-art results on 11 NLP tasks. Fine-tuning BERT requires minimal task-specific architecture changes.",
    },
    {
        "title": "GPT-4 Technical Report",
        "url": "https://arxiv.org/abs/2303.08774",
        "content": "GPT-4 is a large multimodal model accepting image and text inputs. It exhibits human-level performance on professional and academic benchmarks. The model uses reinforcement learning from human feedback during alignment.",
    },
    {
        "title": "Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks",
        "url": "https://arxiv.org/abs/2005.11401",
        "content": "RAG combines pre-trained parametric memory with non-parametric memory for generation. It retrieves relevant documents from a knowledge store and conditions generation on them. RAG achieves strong results on open-domain question answering.",
    },
    {
        "title": "Chain-of-Thought Prompting Elicits Reasoning",
        "url": "https://arxiv.org/abs/2201.11903",
        "content": "Chain-of-thought prompting improves reasoning in large language models by generating intermediate steps. This approach dramatically improves performance on math, commonsense, and symbolic reasoning tasks. The technique works by adding step-by-step reasoning exemplars to prompts.",
    },
    {
        "title": "Attention Is All You Need - Implementation Guide",
        "url": "https://nlp.seas.harvard.edu/2018/04/03/attention.html",
        "content": "A practical guide to implementing the Transformer model. Covers encoder-decoder stacks, positional encoding, and training optimization. Includes PyTorch code for each component.",
    },
    {
        "title": "Scaling Laws for Neural Language Models",
        "url": "https://arxiv.org/abs/2001.08361",
        "content": "Model performance scales as a power law with model size, dataset size, and compute budget. Larger models are significantly more sample-efficient than smaller models. These scaling laws enable predicting model performance before training.",
    },
    {
        "title": "ReAct: Synergizing Reasoning and Acting in Language Models",
        "url": "https://arxiv.org/abs/2210.03629",
        "content": "ReAct combines reasoning traces with task-specific actions. The model generates thoughts and actions interleaved, improving interpretability and trustworthiness. This approach outperforms reasoning-only and acting-only baselines.",
    },
    {
        "title": "Constitutional AI: Harmlessness from AI Feedback",
        "url": "https://arxiv.org/abs/2212.08073",
        "content": "Constitutional AI trains models to be helpful and harmless using AI-generated feedback. The process involves critique and revision steps guided by a constitution of principles. This reduces the need for human-labeled harmfulness data.",
    },
    {
        "title": "Toolformer: Language Models Can Teach Themselves to Use Tools",
        "url": "https://arxiv.org/abs/2302.04761",
        "content": "Toolformer enables language models to teach themselves to use external tools via simple APIs. Models learn when and how to use calculators, search engines, and calendars. This is achieved through self-supervised learning without human demonstrations.",
    },
    {
        "title": "Vector Search and Embedding Indexes",
        "url": "https://www.pinecone.io/learn/vector-search/",
        "content": "Vector search converts text into dense embeddings and finds nearest neighbors in vector space. HNSW and IVF indexes enable approximate nearest neighbor search at scale. Embedding models like sentence-transformers provide high-quality semantic representations.",
    },
    {
        "title": "Evaluation Metrics for Text Generation",
        "url": "https://aclanthology.org/D18-1009/",
        "content": "Modern evaluation of text generation goes beyond BLEU and ROUGE. BERTScore uses contextual embeddings for semantic similarity. Human evaluation remains the gold standard for fluency and coherence assessment.",
    },
]


def retrieve_sources(query: str, top_k: int = 6) -> list[Source]:
    query_lower = query.lower()
    scored: list[tuple[float, dict]] = []
    for doc in KNOWLEDGE_BASE:
        relevance = 0.0
        for word in query_lower.split():
            if len(word) < 3:
                continue
            if word in doc["title"].lower() or word in doc["content"].lower():
                relevance += 0.3
            if word in doc["title"].lower():
                relevance += 0.2
        relevance += deterministic_score(doc["url"], query) * 0.3
        scored.append((relevance, doc))
    scored.sort(key=lambda x: x[0], reverse=True)
    results: list[Source] = []
    for i, (rel, doc) in enumerate(scored[:top_k]):
        credibility = deterministic_score(doc["url"], "cred")
        results.append(
            Source(
                id=gen_id("src"),
                title=doc["title"],
                url=doc["url"],
                snippet=doc["content"][:200] + "...",
                relevance_score=round(rel, 3),
                credibility_score=round(credibility, 3),
                composite_score=round(rel * 0.6 + credibility * 0.4, 3),
                retrieved_at=now_iso(),
            )
        )
    return results
