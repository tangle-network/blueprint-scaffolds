from pydantic import BaseModel
from typing import Optional
from enum import Enum


class JobStatus(str, Enum):
    PENDING = "pending"
    RETRIEVING = "retrieving"
    RANKING = "ranking"
    REASONING = "reasoning"
    WRITING = "writing"
    EVALUATING = "evaluating"
    COMPLETE = "complete"
    FAILED = "failed"


class ResearchRequest(BaseModel):
    query: str


class Source(BaseModel):
    id: str
    title: str
    url: str
    snippet: str
    relevance_score: float
    credibility_score: float
    composite_score: float
    retrieved_at: str


class AgentStep(BaseModel):
    id: str
    job_id: str
    step_type: str
    description: str
    input: dict
    output: dict
    timestamp: str
    duration_ms: int


class Citation(BaseModel):
    id: str
    source_id: str
    source: Source
    context: str
    claim: str
    confidence: float


class ReportSection(BaseModel):
    title: str
    content: str
    citation_ids: list[str]


class EvaluationResult(BaseModel):
    overall_score: float
    source_diversity: float
    citation_coverage: float
    factual_grounding: float
    coherence: float
    notes: str


class ResearchReport(BaseModel):
    job_id: str
    query: str
    summary: str
    sections: list[ReportSection]
    citations: list[Citation]
    evaluation: EvaluationResult
    created_at: str


class ResearchJob(BaseModel):
    id: str
    query: str
    status: JobStatus
    created_at: str
    completed_at: Optional[str] = None
    progress: float
