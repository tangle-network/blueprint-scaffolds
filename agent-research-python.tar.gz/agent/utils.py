import random
import string
import hashlib
from datetime import datetime, timezone


def gen_id(prefix: str = "") -> str:
    chars = string.ascii_lowercase + string.digits
    body = "".join(random.choices(chars, k=12))
    return f"{prefix}_{body}" if prefix else body


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def deterministic_score(text: str, salt: str = "") -> float:
    h = hashlib.md5((text + salt).encode()).hexdigest()
    return (int(h[:8], 16) % 1000) / 1000.0
