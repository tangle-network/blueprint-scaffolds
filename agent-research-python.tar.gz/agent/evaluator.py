from agent.models import ResearchReport, EvaluationResult
from agent.utils import deterministic_score


def evaluate_report(report: ResearchReport) -> EvaluationResult:
    citations = report.citations
    sections = report.sections
    n_unique_sources = len(set(c.source.url for c in citations))
    source_diversity = min(1.0, n_unique_sources / max(len(citations), 1))
    cited_sections = sum(1 for s in sections if s.citation_ids)
    citation_coverage = cited_sections / max(len(sections), 1)
    avg_confidence = sum(c.confidence for c in citations) / max(len(citations), 1)
    factual_grounding = min(1.0, avg_confidence * 1.1)
    coherence = min(1.0, len(sections) / 5.0 * 0.85 + 0.15)
    overall = round(
        source_diversity * 0.2
        + citation_coverage * 0.25
        + factual_grounding * 0.3
        + coherence * 0.25,
        3,
    )
    return EvaluationResult(
        overall_score=overall,
        source_diversity=round(source_diversity, 3),
        citation_coverage=round(citation_coverage, 3),
        factual_grounding=round(factual_grounding, 3),
        coherence=round(coherence, 3),
        notes=f"Evaluated {len(sections)} sections with {len(citations)} citations from {n_unique_sources} unique sources. Overall quality score: {overall:.1%}.",
    )
