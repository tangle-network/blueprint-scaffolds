from agent.models import Source


def rank_sources(sources: list[Source]) -> list[Source]:
    ranked = sorted(sources, key=lambda s: s.composite_score, reverse=True)
    for i, s in enumerate(ranked):
        boosted = s.composite_score + (len(ranked) - i) * 0.02
        ranked[i] = s.model_copy(update={"composite_score": round(boosted, 3)})
    return ranked
