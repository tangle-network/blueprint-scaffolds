import asyncio
import time
from datetime import datetime, timezone
from typing import Optional

from agent.models import (
    ResearchJob,
    JobStatus,
    ResearchReport,
    AgentStep,
    Source,
)
from agent.utils import gen_id, now_iso
from agent.retriever import retrieve_sources
from agent.ranker import rank_sources
from agent.reasoner import reason_over_sources, generate_report
from agent.evaluator import evaluate_report

_jobs: dict[str, ResearchJob] = {}
_reports: dict[str, ResearchReport] = {}
_steps: dict[str, list[AgentStep]] = {}


def _ts() -> str:
    return datetime.now(timezone.utc).isoformat()


def _step(
    job_id: str, step_type: str, desc: str, inp: dict, out: dict, dur_ms: int
) -> AgentStep:
    return AgentStep(
        id=gen_id("step"),
        job_id=job_id,
        step_type=step_type,
        description=desc,
        input=inp,
        output=out,
        timestamp=_ts(),
        duration_ms=dur_ms,
    )


def create_job(query: str) -> ResearchJob:
    job = ResearchJob(
        id=gen_id("job"),
        query=query,
        status=JobStatus.PENDING,
        created_at=_ts(),
        progress=0.0,
    )
    _jobs[job.id] = job
    _steps[job.id] = []
    asyncio.ensure_future(_run_pipeline(job))
    return job


def get_job(job_id: str) -> Optional[ResearchJob]:
    return _jobs.get(job_id)


def list_jobs() -> list[ResearchJob]:
    return sorted(_jobs.values(), key=lambda j: j.created_at, reverse=True)


def get_report(job_id: str) -> Optional[ResearchReport]:
    return _reports.get(job_id)


def get_steps(job_id: str) -> list[AgentStep]:
    return _steps.get(job_id, [])


async def _run_pipeline(job: ResearchJob) -> None:
    try:
        t0 = time.time()

        job.status = JobStatus.RETRIEVING
        job.progress = 0.1
        await asyncio.sleep(0.4)
        sources = retrieve_sources(job.query, top_k=8)
        _steps[job.id].append(
            _step(
                job.id,
                "tool_call",
                "Called retrieve_sources tool",
                {"query": job.query, "top_k": 8},
                {"sources_found": len(sources)},
                int((time.time() - t0) * 1000),
            )
        )
        _steps[job.id].append(
            _step(
                job.id,
                "retrieval",
                f"Retrieved {len(sources)} candidate sources",
                {"query": job.query},
                {"source_ids": [s.id for s in sources]},
                int((time.time() - t0) * 1000),
            )
        )

        job.status = JobStatus.RANKING
        job.progress = 0.3
        await asyncio.sleep(0.3)
        ranked = rank_sources(sources)
        _steps[job.id].append(
            _step(
                job.id,
                "ranking",
                f"Ranked {len(ranked)} sources by composite score",
                {"source_count": len(sources)},
                {"top_score": ranked[0].composite_score if ranked else 0},
                int((time.time() - t0) * 1000),
            )
        )

        job.status = JobStatus.REASONING
        job.progress = 0.5
        await asyncio.sleep(0.5)
        citations = reason_over_sources(job.query, ranked)
        _steps[job.id].append(
            _step(
                job.id,
                "reasoning",
                f"Generated {len(citations)} citations from reasoning over sources",
                {"source_count": len(ranked)},
                {"citation_count": len(citations)},
                int((time.time() - t0) * 1000),
            )
        )

        job.status = JobStatus.WRITING
        job.progress = 0.75
        await asyncio.sleep(0.4)
        report = generate_report(job.query, citations, job.id)
        _steps[job.id].append(
            _step(
                job.id,
                "tool_call",
                "Called generate_report tool",
                {"query": job.query, "citation_count": len(citations)},
                {"sections": len(report.sections), "total_words": sum(len(s.content.split()) for s in report.sections)},
                int((time.time() - t0) * 1000),
            )
        )

        job.status = JobStatus.EVALUATING
        job.progress = 0.9
        await asyncio.sleep(0.3)
        evaluation = evaluate_report(report)
        report.evaluation = evaluation
        _steps[job.id].append(
            _step(
                job.id,
                "evaluation",
                f"Evaluation complete: overall={evaluation.overall_score:.1%}",
                {"report_id": report.job_id},
                {"overall_score": evaluation.overall_score, "notes": evaluation.notes},
                int((time.time() - t0) * 1000),
            )
        )

        _reports[job.id] = report
        job.status = JobStatus.COMPLETE
        job.progress = 1.0
        job.completed_at = _ts()

    except Exception as e:
        job.status = JobStatus.FAILED
        _steps[job.id].append(
            _step(
                job.id,
                "evaluation",
                f"Pipeline failed: {str(e)}",
                {},
                {"error": str(e)},
                0,
            )
        )
