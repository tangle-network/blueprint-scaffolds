import asyncio
import uuid
from datetime import datetime
from typing import Optional

from api.models import ResearchRequest, ResearchJob, JobStatus, ResearchReport
from api.retrieval import retrieve_sources
from api.reasoning import generate_report


_jobs: dict[str, ResearchJob] = {}


def create_job(request: ResearchRequest) -> ResearchJob:
    job = ResearchJob(
        job_id=str(uuid.uuid4())[:8],
        question=request.question,
    )
    _jobs[job.job_id] = job
    return job


def get_job(job_id: str) -> Optional[ResearchJob]:
    return _jobs.get(job_id)


def list_jobs() -> list[ResearchJob]:
    return sorted(_jobs.values(), key=lambda j: j.created_at, reverse=True)


async def run_job(job_id: str, request: ResearchRequest) -> None:
    job = _jobs.get(job_id)
    if not job:
        return

    try:
        job.status = JobStatus.RUNNING
        job.updated_at = datetime.utcnow()
        await asyncio.sleep(0.05)

        job.current_step = "Retrieving sources..."
        job.progress = 0.2
        job.updated_at = datetime.utcnow()
        sources = retrieve_sources(request.question, request.max_sources)
        await asyncio.sleep(0.05)

        job.current_step = "Analyzing and reasoning..."
        job.progress = 0.5
        job.updated_at = datetime.utcnow()
        await asyncio.sleep(0.05)

        job.current_step = "Generating report..."
        job.progress = 0.75
        job.updated_at = datetime.utcnow()

        def evaluator_hook(report: ResearchReport) -> None:
            pass

        report = generate_report(request, sources, evaluator=evaluator_hook)
        await asyncio.sleep(0.05)

        job.progress = 1.0
        job.status = JobStatus.COMPLETED
        job.current_step = "Complete"
        job.report = report
        job.updated_at = datetime.utcnow()

    except Exception as e:
        job.status = JobStatus.FAILED
        job.current_step = f"Failed: {str(e)}"
        job.updated_at = datetime.utcnow()
