import re
import hashlib
from datetime import datetime
from typing import Optional
from api.models import Source


def _mock_search(query: str) -> list[dict]:
    mock_db = [
        {
            "title": "Wikipedia: " + query.title(),
            "url": f"https://en.wikipedia.org/wiki/{query.replace(' ', '_')}",
            "snippet": f"Comprehensive overview of {query} covering history, key concepts, and current understanding.",
        },
        {
            "title": f"Research Paper: {query.title()} — A Review",
            "url": f"https://arxiv.org/abs/2024.{hashlib.md5(query.encode()).hexdigest()[:6]}",
            "snippet": f"Peer-reviewed analysis of {query} with empirical evidence and theoretical frameworks.",
        },
        {
            "title": f"Expert Analysis: Understanding {query.title()}",
            "url": f"https://example.com/expert/{hashlib.md5(query.encode()).hexdigest()[:8]}",
            "snippet": f"In-depth expert commentary on {query}, covering practical implications and recent developments.",
        },
        {
            "title": f"Technical Documentation — {query.title()}",
            "url": f"https://docs.example.org/guides/{query.replace(' ', '-')}",
            "snippet": f"Official technical documentation explaining {query} with examples and best practices.",
        },
        {
            "title": f"News: Latest Developments in {query.title()}",
            "url": f"https://news.example.com/{query.replace(' ', '-')}-2024",
            "snippet": f"Breaking coverage of recent developments related to {query}.",
        },
        {
            "title": f"Educational Resource: {query.title()} Explained",
            "url": f"https://edu.example.org/topics/{query.replace(' ', '-')}",
            "snippet": f"Beginner-friendly explanation of {query} with diagrams, examples, and quiz questions.",
        },
    ]
    return mock_db


def rank_sources(sources: list[dict], query: str) -> list[dict]:
    query_terms = set(re.findall(r"\w+", query.lower()))
    for s in sources:
        snippet_terms = set(re.findall(r"\w+", s["snippet"].lower()))
        title_terms = set(re.findall(r"\w+", s["title"].lower()))
        overlap = len(query_terms & (snippet_terms | title_terms))
        base_score = overlap / max(len(query_terms), 1)
        import random

        s["relevance_score"] = round(min(base_score + random.uniform(0.1, 0.35), 1.0), 3)
    return sorted(sources, key=lambda x: x["relevance_score"], reverse=True)


def retrieve_sources(query: str, max_sources: int = 5) -> list[Source]:
    raw = _mock_search(query)
    ranked = rank_sources(raw, query)
    results = []
    for i, s in enumerate(ranked[:max_sources]):
        results.append(
            Source(
                id=f"src_{hashlib.md5((query + str(i)).encode()).hexdigest()[:8]}",
                title=s["title"],
                url=s["url"],
                snippet=s["snippet"],
                relevance_score=s["relevance_score"],
            )
        )
    return results


def evaluate_source_relevance(source: Source, query: str) -> float:
    query_terms = set(re.findall(r"\w+", query.lower()))
    snippet_terms = set(re.findall(r"\w+", source.snippet.lower()))
    title_terms = set(re.findall(r"\w+", source.title.lower()))
    overlap = len(query_terms & (snippet_terms | title_terms))
    base = overlap / max(len(query_terms), 1)
    import random

    return round(min(base + random.uniform(0.05, 0.2), 1.0), 3)
