from pydantic import BaseModel, Field
from typing import Optional
from enum import Enum
from datetime import datetime


class JobStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class Source(BaseModel):
    id: str
    title: str
    url: str
    snippet: str
    relevance_score: float = Field(ge=0.0, le=1.0)
    retrieved_at: datetime = Field(default_factory=datetime.utcnow)


class ResearchStep(BaseModel):
    step_number: int
    step_type: str
    description: str
    output: Optional[str] = None
    sources_used: list[str] = Field(default_factory=list)
    started_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None


class Citation(BaseModel):
    citation_id: str
    source_id: str
    quote: str
    relevance: float = Field(ge=0.0, le=1.0)


class ResearchReport(BaseModel):
    question: str
    summary: str
    detailed_answer: str
    citations: list[Citation] = Field(default_factory=list)
    confidence_score: float = Field(ge=0.0, le=1.0)
    steps: list[ResearchStep] = Field(default_factory=list)
    sources: list[Source] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.utcnow)


class ResearchRequest(BaseModel):
    question: str
    max_sources: int = Field(default=5, ge=1, le=20)
    depth: str = Field(default="standard", pattern="^(quick|standard|deep)$")


class ResearchJob(BaseModel):
    job_id: str
    question: str
    status: JobStatus = JobStatus.PENDING
    progress: float = Field(default=0.0, ge=0.0, le=1.0)
    current_step: Optional[str] = None
    report: Optional[ResearchReport] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
