import asyncio
from fastapi import FastAPI, HTTPException, BackgroundTasks
from api.models import ResearchRequest, ResearchJob
from api.jobs import create_job, get_job, list_jobs, run_job

app = FastAPI(title="Research Agent API", version="0.1.0")


@app.get("/api/health")
async def health():
    return {"status": "ok"}


@app.post("/api/research", response_model=ResearchJob)
async def start_research(
    request: ResearchRequest, background_tasks: BackgroundTasks
):
    job = create_job(request)
    background_tasks.add_task(run_job, job.job_id, request)
    return job


@app.get("/api/research/{job_id}", response_model=ResearchJob)
async def get_research(job_id: str):
    job = get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@app.get("/api/research", response_model=list[ResearchJob])
async def list_research():
    return list_jobs()
