# AGENTS.md

Build a Python research agent service that can retrieve sources, reason over them, and produce cited reports.

## What's here

This project was scaffolded by starter-foundry. The user's prompt drove the choices below — read their prompt first, it takes priority over everything in this file.

- **Family:** `agent-service-py`
- **Layers:** `framework:agent-service-py`, `capability:agent-rag`, `database:sqlite`, `sdk:none`, `auth:none`, `payments:none`, `queue:none`

### Architecture notes
- Agent control loop: plan → act → reflect
- Tool registration
- Memory/state management
- HTTP health endpoint

## Getting started

```bash
python3 app.py
```

Key files: `app.py`, `agent.config.json`

## Suggested build plan

These are starting points — adapt them to the user's actual needs.

- **API routes:** /api/ingest, /api/query
- **Components:** DocumentUploader, SearchResults, SourceCitation
- **Data models:** Document, Chunk, Embedding, SearchResult
- **Integrations:** Vector database, Embedding API, Document parser

## How to use this scaffold

This is a starting point, not a contract. You own every file.

- **Customize freely.** Replace components, change the layout, swap the color scheme — whatever fits the user's product.
- **The scaffold saves you setup time** — Tailwind, shadcn/ui, path aliases, and framework config are ready. Don't redo them.
- **Check `.starter-foundry/compose-report.json`** if you want to see which layer wrote which file.
- **Update this file** as the project evolves. Delete sections that no longer apply.
