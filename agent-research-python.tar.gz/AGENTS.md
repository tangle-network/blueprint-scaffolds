# AGENTS.md

## Goal

Build a Python research agent service that can retrieve sources, reason over them, and produce cited reports.

## Stack

- Family: `agent-service-py`
- Layers: `capability:agent-rag`, `database:sqlite`, `sdk:none`, `auth:none`, `payments:none`, `queue:none`

## Architecture

- Agent control loop: plan → act → reflect
- Tool registration
- Memory/state management
- HTTP health endpoint

## Entry Points

- `app.py`
- `agent.config.json`

## Commands

- `python3 app.py`

## Build Plan

API routes: /api/ingest, /api/query
Components: DocumentUploader, SearchResults, SourceCitation
Data models: Document, Chunk, Embedding, SearchResult
Integrations: Vector database, Embedding API, Document parser

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
