from __future__ import annotations
from datetime import datetime
from models import (
    ResearchReport,
    Source,
    Citation,
    StepResult,
    ToolCall,
)
from retrieval import retrieve_sources
from evaluators import run_evaluators
from tools import call_tool


async def run_research(question: str, max_sources: int = 10, depth: str = "standard") -> ResearchReport:
    steps: list[StepResult] = []
    all_tool_calls: list[ToolCall] = []

    # Step 1: Plan
    steps.append(StepResult(
        step="planning",
        description="Analyzing the research question and creating a search plan",
        output=f"Research plan created for: '{question}'. Depth: {depth}. Max sources: {max_sources}.",
    ))

    # Step 2: Retrieve sources
    tc = ToolCall(tool_name="web_search", arguments={"query": question, "max_results": max_sources})
    sources = await retrieve_sources(question, max_sources)
    tc.result_preview = f"Retrieved {len(sources)} sources"
    all_tool_calls.append(tc)

    steps.append(StepResult(
        step="retrieval",
        description="Searching and retrieving relevant sources",
        output=f"Found {len(sources)} sources. Top source: {sources[0].title if sources else 'N/A'} (score: {sources[0].combined_score:.2f})" if sources else "No sources found.",
        tool_calls=[tc],
    ))

    # Step 3: Reason over sources
    facts: list[dict] = []
    for src in sources[:5]:
        tc2 = ToolCall(tool_name="extract_facts", arguments={"text": src.snippet, "question": question})
        extracted = await call_tool("extract_facts", text=src.snippet, question=question)
        tc2.result_preview = f"Extracted {len(extracted)} facts"
        all_tool_calls.append(tc2)
        facts.extend(extracted)

    steps.append(StepResult(
        step="reasoning",
        description="Extracting and synthesizing key facts from sources",
        output=f"Extracted {len(facts)} key facts across {min(len(sources), 5)} sources.",
        tool_calls=[tc2],
    ))

    # Step 4: Build report
    citations = [
        Citation(
            source_id=src.id,
            source_title=src.title,
            source_url=src.url,
            quote=src.snippet[:150],
            relevance=src.relevance_score,
        )
        for src in sources[:5]
    ]

    avg_confidence = sum(f["confidence"] for f in facts) / max(len(facts), 1) if facts else 0.0

    report = ResearchReport(
        question=question,
        summary=f"Research findings for: {question}. Based on {len(sources)} sources with {len(facts)} extracted facts, the evidence suggests multiple perspectives on this topic.",
        detailed_findings="\n\n".join(
            f"**Finding {i+1}:** {f['fact']} (confidence: {f['confidence']:.0%})"
            for i, f in enumerate(facts)
        ) or "No specific findings were extracted from the available sources.",
        citations=citations,
        sources=sources,
        steps=steps,
        confidence_score=round(avg_confidence, 2),
    )

    # Step 5: Evaluate
    evaluations = await run_evaluators(report)
    report.evaluations = evaluations

    steps.append(StepResult(
        step="evaluation",
        description="Running quality evaluators on the report",
        output=f"Ran {len(evaluations)} evaluators. "
               f"Passed: {sum(1 for e in evaluations if e.passed)}/{len(evaluations)}.",
    ))

    report.steps = steps
    return report
