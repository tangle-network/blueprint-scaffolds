from __future__ import annotations
import asyncio
import uuid
from datetime import datetime
from typing import Dict
from models import JobResponse, JobStatus, ResearchRequest, ResearchReport
from agent import run_research


_jobs: Dict[str, JobResponse] = {}


async def create_job(request: ResearchRequest) -> JobResponse:
    job_id = str(uuid.uuid4())
    job = JobResponse(job_id=job_id, status=JobStatus.PENDING, question=request.question)
    _jobs[job_id] = job
    asyncio.create_task(_execute_job(job_id, request))
    return job


async def get_job(job_id: str) -> JobResponse | None:
    return _jobs.get(job_id)


async def list_jobs() -> list[JobResponse]:
    return list(_jobs.values())


async def _execute_job(job_id: str, request: ResearchRequest):
    job = _jobs[job_id]
    job.status = JobStatus.RUNNING
    try:
        report: ResearchReport = await run_research(
            question=request.question,
            max_sources=request.max_sources,
            depth=request.depth,
        )
        job.status = JobStatus.COMPLETED
        job.completed_at = datetime.utcnow()
        job.report = report
    except Exception as exc:
        job.status = JobStatus.FAILED
        job.error = str(exc)
