from __future__ import annotations
from models import Source
from tools import call_tool


async def retrieve_sources(question: str, max_sources: int = 10) -> list[Source]:
    raw = await call_tool("web_search", query=question, max_results=max_sources)
    sources = []
    for item in raw:
        sources.append(
            Source(
                id=item["id"],
                title=item["title"],
                url=item["url"],
                snippet=item["snippet"],
                relevance_score=0.5,
                credibility_score=0.5,
                combined_score=0.5,
            )
        )
    sources = await _enrich_sources(sources, question)
    sources = rank_sources(sources)
    return sources


async def _enrich_sources(sources: list[Source], question: str) -> list[Source]:
    enriched = []
    for src in sources:
        try:
            page = await call_tool("fetch_page", url=src.url)
            facts = await call_tool("extract_facts", text=page["text"], question=question)
            relevance = sum(f["confidence"] for f in facts) / max(len(facts), 1)
            enriched.append(
                src.model_copy(
                    update={
                        "snippet": page["text"][:300],
                        "relevance_score": min(relevance, 1.0),
                    }
                )
            )
        except Exception:
            enriched.append(src)
    return enriched


def rank_sources(sources: list[Source]) -> list[Source]:
    for src in sources:
        src.combined_score = 0.6 * src.relevance_score + 0.4 * src.credibility_score
    return sorted(sources, key=lambda s: s.combined_score, reverse=True)
