from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from models import ResearchRequest, JobResponse
from jobs import create_job, get_job, list_jobs

app = FastAPI(title="Research Agent", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post("/api/jobs", response_model=JobResponse)
async def start_research(req: ResearchRequest):
    return await create_job(req)


@app.get("/api/jobs", response_model=list[JobResponse])
async def get_jobs():
    return await list_jobs()


@app.get("/api/jobs/{job_id}", response_model=JobResponse)
async def get_job_status(job_id: str):
    job = await get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@app.get("/api/health")
async def health():
    return {"status": "ok"}
