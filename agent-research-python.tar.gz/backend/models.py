from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime
from enum import Enum


class JobStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class ResearchRequest(BaseModel):
    question: str = Field(..., min_length=1, description="The research question to investigate")
    max_sources: int = Field(default=10, ge=1, le=50)
    depth: str = Field(default="standard", pattern="^(quick|standard|deep)$")


class Source(BaseModel):
    id: str
    title: str
    url: str
    snippet: str
    relevance_score: float = Field(default=0.0, ge=0.0, le=1.0)
    credibility_score: float = Field(default=0.0, ge=0.0, le=1.0)
    combined_score: float = Field(default=0.0, ge=0.0, le=1.0)
    retrieved_at: datetime = Field(default_factory=datetime.utcnow)


class ToolCall(BaseModel):
    tool_name: str
    arguments: dict
    result_preview: str = Field(default="")
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class StepResult(BaseModel):
    step: str
    description: str
    output: str
    tool_calls: list[ToolCall] = Field(default_factory=list)
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class Citation(BaseModel):
    source_id: str
    source_title: str
    source_url: str
    quote: str
    relevance: float = Field(default=0.0, ge=0.0, le=1.0)


class EvaluationResult(BaseModel):
    evaluator_name: str
    score: float = Field(ge=0.0, le=1.0)
    passed: bool
    feedback: str = Field(default="")


class ResearchReport(BaseModel):
    question: str
    summary: str
    detailed_findings: str
    citations: list[Citation] = Field(default_factory=list)
    sources: list[Source] = Field(default_factory=list)
    steps: list[StepResult] = Field(default_factory=list)
    evaluations: list[EvaluationResult] = Field(default_factory=list)
    confidence_score: float = Field(default=0.0, ge=0.0, le=1.0)


class JobResponse(BaseModel):
    job_id: str
    status: JobStatus
    question: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    report: Optional[ResearchReport] = None
    error: Optional[str] = None
