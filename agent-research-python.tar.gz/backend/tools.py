from __future__ import annotations
import asyncio
import json
from typing import Callable, Any


TOOL_REGISTRY: dict[str, Callable] = {}


def register_tool(name: str):
    def decorator(fn: Callable):
        TOOL_REGISTRY[name] = fn
        return fn
    return decorator


@register_tool("web_search")
async def web_search(query: str, max_results: int = 10) -> list[dict]:
    await asyncio.sleep(0.1)
    return [
        {
            "id": f"src-{i+1}",
            "title": f"Search result {i+1} for: {query}",
            "url": f"https://example.com/result/{i+1}",
            "snippet": f"This is a simulated search result for the query '{query}'. "
                       f"It contains relevant information about the topic.",
        }
        for i in range(min(max_results, 5))
    ]


@register_tool("fetch_page")
async def fetch_page(url: str) -> dict:
    await asyncio.sleep(0.1)
    return {
        "url": url,
        "title": f"Content from {url}",
        "text": f"Simulated page content from {url}. "
                "This would contain the full text of the retrieved page for analysis.",
        "headings": ["Introduction", "Key Findings", "Conclusion"],
    }


@register_tool("extract_facts")
async def extract_facts(text: str, question: str) -> list[dict]:
    await asyncio.sleep(0.05)
    return [
        {
            "fact": f"Key finding related to: {question}",
            "confidence": 0.85,
            "source_text": text[:200],
        }
    ]


async def call_tool(name: str, **kwargs) -> Any:
    if name not in TOOL_REGISTRY:
        raise ValueError(f"Unknown tool: {name}")
    return await TOOL_REGISTRY[name](**kwargs)


def get_tool_descriptions() -> list[dict]:
    return [
        {"name": name, "doc": fn.__doc__ or ""}
        for name, fn in TOOL_REGISTRY.items()
    ]
