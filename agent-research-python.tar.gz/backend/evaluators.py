from __future__ import annotations
from typing import Protocol
from models import ResearchReport, EvaluationResult


class Evaluator(Protocol):
    name: str

    async def evaluate(self, report: ResearchReport) -> EvaluationResult: ...


class CitationCoverageEvaluator:
    name = "citation_coverage"

    async def evaluate(self, report: ResearchReport) -> EvaluationResult:
        if not report.detailed_findings:
            score = 0.0
        else:
            score = min(len(report.citations) / 5.0, 1.0)
        return EvaluationResult(
            evaluator_name=self.name,
            score=score,
            passed=score >= 0.4,
            feedback=f"Found {len(report.citations)} citations. {'Sufficient coverage.' if score >= 0.4 else 'Needs more citations.'}",
        )


class SourceDiversityEvaluator:
    name = "source_diversity"

    async def evaluate(self, report: ResearchReport) -> EvaluationResult:
        unique_domains = len({s.url.split("/")[2] if "/" in s.url else s.url for s in report.sources})
        score = min(unique_domains / 3.0, 1.0)
        return EvaluationResult(
            evaluator_name=self.name,
            score=score,
            passed=score >= 0.5,
            feedback=f"{unique_domains} unique source domains. {'Good diversity.' if score >= 0.5 else 'Consider more diverse sources.'}",
        )


class ConfidenceEvaluator:
    name = "confidence"

    async def evaluate(self, report: ResearchReport) -> EvaluationResult:
        score = report.confidence_score
        return EvaluationResult(
            evaluator_name=self.name,
            score=score,
            passed=score >= 0.6,
            feedback=f"Report confidence: {score:.0%}. {'Acceptable.' if score >= 0.6 else 'Low confidence.'}",
        )


DEFAULT_EVALUATORS: list[Evaluator] = [
    CitationCoverageEvaluator(),
    SourceDiversityEvaluator(),
    ConfidenceEvaluator(),
]


async def run_evaluators(report: ResearchReport, evaluators: list[Evaluator] | None = None) -> list[EvaluationResult]:
    evaluators = evaluators or DEFAULT_EVALUATORS
    results = []
    for ev in evaluators:
        result = await ev.evaluate(report)
        results.append(result)
    return results
