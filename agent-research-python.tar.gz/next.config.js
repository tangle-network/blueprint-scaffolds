/** @type {import('next').NextConfig} */
const nextConfig = {
  rewrites: [
    {
      source: "/api/:path*",
      destination: "http://localhost:8000/api/:path*",
    },
  ],
};

module.exports = nextConfig;
