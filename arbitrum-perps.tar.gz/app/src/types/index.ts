export interface Market {
  id: string;
  pair: string;
  baseToken: string;
  quoteToken: string;
  markPrice: number;
  indexPrice: number;
  fundingRate: number;
  fundingCountdown: number;
  volume24h: number;
  openInterest: number;
  maxLeverage: number;
  minMargin: number;
  maintenanceMargin: number;
}

export type OrderSide = "long" | "short";
export type OrderType = "market" | "limit" | "stop_market" | "stop_limit" | "take_profit" | "take_profit_limit";
export type MarginMode = "cross" | "isolated";
export type PositionStatus = "open" | "closed" | "liquidated";
export type OrderStatus = "pending" | "open" | "filled" | "cancelled" | "triggered";

export interface Position {
  id: string;
  marketId: string;
  pair: string;
  side: OrderSide;
  sizeUsd: number;
  sizeToken: number;
  leverage: number;
  marginMode: MarginMode;
  entryPrice: number;
  markPrice: number;
  liquidationPrice: number;
  unrealizedPnl: number;
  marginUsed: number;
  marginRatio: number;
  status: PositionStatus;
  openedAt: string;
}

export interface Order {
  id: string;
  marketId: string;
  pair: string;
  side: OrderSide;
  type: OrderType;
  price?: number;
  triggerPrice?: number;
  sizeUsd: number;
  sizeToken: number;
  leverage: number;
  marginMode: MarginMode;
  status: OrderStatus;
  createdAt: string;
  reduceOnly: boolean;
}

export interface CollateralAsset {
  id: string;
  symbol: string;
  name: string;
  balance: number;
  usdValue: number;
  availableBalance: number;
  canDeposit: boolean;
  isYieldBearing: boolean;
}

export interface AccountSummary {
  totalEquity: number;
  totalMargin: number;
  availableMargin: number;
  unrealizedPnl: number;
  marginRatio: number;
  totalPositions: number;
  totalOrders: number;
}

export interface LeaderboardEntry {
  rank: number;
  address: string;
  displayName: string;
  totalPnl: number;
  totalPnlPercent: number;
  totalVolume: number;
  winRate: number;
  positionsCount: number;
  isTopTrader: boolean;
}

export interface Trade {
  id: string;
  marketId: string;
  pair: string;
  side: OrderSide;
  price: number;
  sizeUsd: number;
  sizeToken: number;
  timestamp: string;
  isBuyerMaker: boolean;
}

export interface CandlestickData {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}
