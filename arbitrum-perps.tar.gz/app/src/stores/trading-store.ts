import { create } from 'zustand'
import type { Market, Position, Order, CollateralAsset, AccountSummary, Trade, CandlestickData } from '@/types'

const DEFAULT_MARKETS: Market[] = [
  {
    id: 'btc-usd',
    pair: 'BTC-USD',
    baseToken: 'BTC',
    quoteToken: 'USD',
    markPrice: 67234.50,
    indexPrice: 67230.25,
    fundingRate: 0.0123,
    fundingCountdown: 2847,
    volume24h: 1_245_000_000,
    openInterest: 892_000_000,
    maxLeverage: 50,
    minMargin: 0.5,
    maintenanceMargin: 0.5,
  },
  {
    id: 'eth-usd',
    pair: 'ETH-USD',
    baseToken: 'ETH',
    quoteToken: 'USD',
    markPrice: 3456.78,
    indexPrice: 3455.90,
    fundingRate: -0.0045,
    fundingCountdown: 2847,
    volume24h: 678_000_000,
    openInterest: 412_000_000,
    maxLeverage: 50,
    minMargin: 0.5,
    maintenanceMargin: 0.5,
  },
  {
    id: 'arb-usd',
    pair: 'ARB-USD',
    baseToken: 'ARB',
    quoteToken: 'USD',
    markPrice: 0.8921,
    indexPrice: 0.8918,
    fundingRate: 0.0089,
    fundingCountdown: 2847,
    volume24h: 156_000_000,
    openInterest: 89_000_000,
    maxLeverage: 25,
    minMargin: 1.0,
    maintenanceMargin: 0.5,
  },
  {
    id: 'sol-usd',
    pair: 'SOL-USD',
    baseToken: 'SOL',
    quoteToken: 'USD',
    markPrice: 178.45,
    indexPrice: 178.40,
    fundingRate: 0.0067,
    fundingCountdown: 2847,
    volume24h: 432_000_000,
    openInterest: 198_000_000,
    maxLeverage: 25,
    minMargin: 1.0,
    maintenanceMargin: 0.5,
  },
  {
    id: 'gmx-usd',
    pair: 'GMX-USD',
    baseToken: 'GMX',
    quoteToken: 'USD',
    markPrice: 34.56,
    indexPrice: 34.52,
    fundingRate: -0.0023,
    fundingCountdown: 2847,
    volume24h: 45_000_000,
    openInterest: 32_000_000,
    maxLeverage: 20,
    minMargin: 1.0,
    maintenanceMargin: 0.5,
  },
]

const DEFAULT_POSITIONS: Position[] = [
  {
    id: 'pos-1',
    marketId: 'btc-usd',
    pair: 'BTC-USD',
    side: 'long',
    sizeUsd: 50000,
    sizeToken: 0.7438,
    leverage: 10,
    marginMode: 'cross',
    entryPrice: 65432.10,
    markPrice: 67234.50,
    liquidationPrice: 59483.72,
    unrealizedPnl: 1340.52,
    marginUsed: 5000,
    marginRatio: 26.81,
    status: 'open',
    openedAt: '2025-03-15T10:30:00Z',
  },
  {
    id: 'pos-2',
    marketId: 'eth-usd',
    pair: 'ETH-USD',
    side: 'short',
    sizeUsd: 25000,
    sizeToken: 7.2342,
    leverage: 5,
    marginMode: 'isolated',
    entryPrice: 3512.45,
    markPrice: 3456.78,
    liquidationPrice: 3793.45,
    unrealizedPnl: 403.72,
    marginUsed: 5000,
    marginRatio: 58.07,
    status: 'open',
    openedAt: '2025-03-18T14:15:00Z',
  },
  {
    id: 'pos-3',
    marketId: 'sol-usd',
    pair: 'SOL-USD',
    side: 'long',
    sizeUsd: 10000,
    sizeToken: 56.04,
    leverage: 3,
    marginMode: 'cross',
    entryPrice: 172.30,
    markPrice: 178.45,
    liquidationPrice: 142.80,
    unrealizedPnl: 344.34,
    marginUsed: 3333.33,
    marginRatio: 40.32,
    status: 'open',
    openedAt: '2025-03-20T08:45:00Z',
  },
  {
    id: 'pos-4',
    marketId: 'arb-usd',
    pair: 'ARB-USD',
    side: 'long',
    sizeUsd: 5000,
    sizeToken: 5604.96,
    leverage: 5,
    marginMode: 'isolated',
    entryPrice: 0.8623,
    markPrice: 0.8921,
    liquidationPrice: 0.7415,
    unrealizedPnl: 167.06,
    marginUsed: 1000,
    marginRatio: 116.71,
    status: 'open',
    openedAt: '2025-03-22T16:00:00Z',
  },
]

const DEFAULT_ORDERS: Order[] = [
  {
    id: 'ord-1',
    marketId: 'btc-usd',
    pair: 'BTC-USD',
    side: 'long',
    type: 'limit',
    price: 65000,
    sizeUsd: 20000,
    sizeToken: 0.3077,
    leverage: 10,
    marginMode: 'cross',
    status: 'open',
    createdAt: '2025-03-25T09:00:00Z',
    reduceOnly: false,
  },
  {
    id: 'ord-2',
    marketId: 'eth-usd',
    pair: 'ETH-USD',
    side: 'short',
    type: 'stop_market',
    triggerPrice: 3200,
    sizeUsd: 15000,
    sizeToken: 4.6875,
    leverage: 5,
    marginMode: 'isolated',
    status: 'open',
    createdAt: '2025-03-24T12:30:00Z',
    reduceOnly: false,
  },
  {
    id: 'ord-3',
    marketId: 'sol-usd',
    pair: 'SOL-USD',
    side: 'long',
    type: 'take_profit',
    triggerPrice: 200,
    sizeUsd: 10000,
    sizeToken: 50,
    leverage: 3,
    marginMode: 'cross',
    status: 'open',
    createdAt: '2025-03-20T08:50:00Z',
    reduceOnly: true,
  },
]

const DEFAULT_COLLATERAL: CollateralAsset[] = [
  { id: 'usdc', symbol: 'USDC', name: 'USD Coin', balance: 12500, usdValue: 12500, availableBalance: 9516.67, canDeposit: true, isYieldBearing: true },
  { id: 'weth', symbol: 'WETH', name: 'Wrapped Ether', balance: 2.5, usdValue: 8641.95, availableBalance: 2.5, canDeposit: true, isYieldBearing: false },
  { id: 'wbtc', symbol: 'WBTC', name: 'Wrapped Bitcoin', balance: 0.15, usdValue: 10085.18, availableBalance: 0.15, canDeposit: true, isYieldBearing: false },
  { id: 'arb', symbol: 'ARB', name: 'Arbitrum', balance: 5000, usdValue: 4460.50, availableBalance: 5000, canDeposit: true, isYieldBearing: false },
]

interface MarketState {
  markets: Market[]
  selectedMarketId: string
  setSelectedMarket: (id: string) => void
  updateMarkPrice: (id: string, price: number) => void
}

interface PositionState {
  positions: Position[]
  orders: Order[]
  addPosition: (position: Position) => void
  closePosition: (id: string) => void
  addOrder: (order: Order) => void
  cancelOrder: (id: string) => void
}

interface AccountState {
  collateral: CollateralAsset[]
  accountSummary: AccountSummary
}

export const useMarketStore = create<MarketState>((set) => ({
  markets: DEFAULT_MARKETS,
  selectedMarketId: 'btc-usd',
  setSelectedMarket: (id) => set({ selectedMarketId: id }),
  updateMarkPrice: (id, price) =>
    set((state) => ({
      markets: state.markets.map((m) =>
        m.id === id ? { ...m, markPrice: price } : m
      ),
    })),
}))

export const usePositionStore = create<PositionState>((set) => ({
  positions: DEFAULT_POSITIONS,
  orders: DEFAULT_ORDERS,
  addPosition: (position) => set((state) => ({ positions: [...state.positions, position] })),
  closePosition: (id) => set((state) => ({ positions: state.positions.filter((p) => p.id !== id) })),
  addOrder: (order) => set((state) => ({ orders: [...state.orders, order] })),
  cancelOrder: (id) => set((state) => ({ orders: state.orders.filter((o) => o.id !== id) })),
}))

export const useAccountStore = create<AccountState>(() => {
  const totalCollateral = DEFAULT_COLLATERAL.reduce((sum, c) => sum + c.usdValue, 0)
  const unrealizedPnl = DEFAULT_POSITIONS.reduce((sum, p) => sum + p.unrealizedPnl, 0)
  const marginUsed = DEFAULT_POSITIONS.reduce((sum, p) => sum + p.marginUsed, 0)

  return {
    collateral: DEFAULT_COLLATERAL,
    accountSummary: {
      totalEquity: totalCollateral + unrealizedPnl,
      totalMargin: marginUsed,
      availableMargin: totalCollateral - marginUsed,
      unrealizedPnl,
      marginRatio: ((totalCollateral + unrealizedPnl) / marginUsed) * 100,
      totalPositions: DEFAULT_POSITIONS.length,
      totalOrders: DEFAULT_ORDERS.length,
    },
  }
})

export function generateRecentTrades(marketId: string, basePrice: number): Trade[] {
  const trades: Trade[] = []
  const now = Date.now()
  for (let i = 0; i < 20; i++) {
    const offset = (Math.random() - 0.5) * basePrice * 0.001
    const price = basePrice + offset
    const isBuy = Math.random() > 0.5
    trades.push({
      id: `trade-${marketId}-${i}`,
      marketId,
      pair: marketId.toUpperCase().replace('-', '-'),
      side: isBuy ? 'long' : 'short',
      price,
      sizeUsd: Math.round(Math.random() * 50000 + 100),
      sizeToken: Math.round((Math.random() * 50000 + 100) / price * 10000) / 10000,
      timestamp: new Date(now - i * Math.random() * 60000).toISOString(),
      isBuyerMaker: !isBuy,
    })
  }
  return trades
}

export function generateCandlestickData(basePrice: number, count: number = 100): CandlestickData[] {
  const data: CandlestickData[] = []
  let price = basePrice * 0.95
  const now = Math.floor(Date.now() / 1000)
  const interval = 300

  for (let i = 0; i < count; i++) {
    const change = (Math.random() - 0.48) * basePrice * 0.005
    const open = price
    const close = price + change
    const high = Math.max(open, close) + Math.random() * basePrice * 0.002
    const low = Math.min(open, close) - Math.random() * basePrice * 0.002
    const volume = Math.random() * 1_000_000 + 100_000

    data.push({
      time: now - (count - i) * interval,
      open,
      high,
      low,
      close,
      volume,
    })

    price = close
  }

  return data
}
