import { Routes, Route, Navigate, NavLink, useLocation } from 'react-router-dom'
import { BarChart3, Briefcase, Trophy, Activity, Settings } from 'lucide-react'
import TradePage from './pages/TradePage'
import PortfolioPage from './pages/PortfolioPage'
import LeaderboardPage from './pages/LeaderboardPage'
import AccountHeader from './components/trading/account-header'
import { cn } from './lib/utils'

const NAV_ITEMS = [
  { to: '/trade/BTC', label: 'Trade', icon: BarChart3 },
  { to: '/portfolio', label: 'Portfolio', icon: Briefcase },
  { to: '/leaderboard', label: 'Leaderboard', icon: Trophy },
]

function TopNav() {
  const location = useLocation()

  return (
    <header className="fixed top-0 left-0 right-0 z-50 flex h-14 items-center border-b border-border bg-card">
      <div className="flex items-center gap-2 px-4 w-48">
        <Activity className="h-5 w-5 text-blue-500" />
        <div>
          <h1 className="text-sm font-bold text-foreground leading-none">Perp Terminal</h1>
          <p className="text-[10px] text-muted-foreground">Arbitrum</p>
        </div>
      </div>

      <nav className="flex items-center gap-1 px-2">
        {NAV_ITEMS.map(({ to, label, icon: Icon }) => {
          const isActive = location.pathname.startsWith(to === '/trade/BTC' ? '/trade' : to) || (to === '/trade/BTC' && location.pathname === '/')
          return (
            <NavLink
              key={to}
              to={to}
              className={() =>
                cn(
                  'flex items-center gap-2 rounded-md px-3 py-1.5 text-sm font-medium transition-colors',
                  isActive
                    ? 'bg-accent text-foreground'
                    : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                )
              }
            >
              <Icon className="h-4 w-4" />
              {label}
            </NavLink>
          )
        })}
      </nav>

      <div className="flex-1" />

      <div className="flex items-center gap-3 px-4">
        <button className="text-muted-foreground hover:text-foreground transition-colors">
          <Settings className="h-4 w-4" />
        </button>
      </div>
    </header>
  )
}

export default function App() {
  return (
    <div className="min-h-screen bg-background">
      <TopNav />
      <div className="pt-14">
        <AccountHeader />
        <Routes>
          <Route path="/" element={<Navigate to="/trade/BTC" replace />} />
          <Route path="/trade/:pair" element={<TradePage />} />
          <Route path="/portfolio" element={<PortfolioPage />} />
          <Route path="/leaderboard" element={<LeaderboardPage />} />
        </Routes>
      </div>
    </div>
  )
}
