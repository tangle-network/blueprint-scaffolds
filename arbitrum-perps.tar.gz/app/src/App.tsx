import { Routes, Route, NavLink, useLocation } from 'react-router-dom'
import { LayoutDashboard, ListTodo, Users, Shield, Fuel, Settings, Activity } from 'lucide-react'
import Dashboard from './pages/Dashboard'
import TaskExplorer from './pages/TaskExplorer'
import Operators from './pages/Operators'
import SLAMonitoring from './pages/SLAMonitoring'
import GasCoverage from './pages/GasCoverage'
import RustEngine from './pages/RustEngine'
import { cn } from './lib/utils'

const NAV_ITEMS = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/tasks', label: 'Task Explorer', icon: ListTodo },
  { to: '/operators', label: 'Operators', icon: Users },
  { to: '/sla', label: 'SLA Monitoring', icon: Shield },
  { to: '/gas', label: 'Gas Coverage', icon: Fuel },
  { to: '/engine', label: 'Rust Engine', icon: Settings },
]

function Sidebar() {
  const location = useLocation()

  return (
    <aside className="fixed inset-y-0 left-0 z-50 flex w-64 flex-col border-r bg-card">
      <div className="flex h-16 items-center gap-2 border-b px-6">
        <Activity className="h-6 w-6 text-primary" />
        <div>
          <h1 className="text-sm font-bold text-foreground">Keeper Network</h1>
          <p className="text-xs text-muted-foreground">EigenLayer AVS</p>
        </div>
      </div>
      <nav className="flex-1 space-y-1 p-4">
        {NAV_ITEMS.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            end={to === '/'}
            className={({ isActive }) =>
              cn(
                'flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors',
                isActive
                  ? 'bg-primary/10 text-primary'
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground'
              )
            }
          >
            <Icon className="h-4 w-4" />
            {label}
          </NavLink>
        ))}
      </nav>
      <div className="border-t p-4">
        <div className="rounded-md bg-muted/50 p-3">
          <p className="text-xs font-medium text-foreground">Network Status</p>
          <div className="mt-1 flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-xs text-muted-foreground">15 operators active</span>
          </div>
        </div>
      </div>
    </aside>
  )
}

export default function App() {
  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main className="pl-64">
        <div className="mx-auto max-w-7xl p-6">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/tasks" element={<TaskExplorer />} />
            <Route path="/operators" element={<Operators />} />
            <Route path="/sla" element={<SLAMonitoring />} />
            <Route path="/gas" element={<GasCoverage />} />
            <Route path="/engine" element={<RustEngine />} />
          </Routes>
        </div>
      </main>
    </div>
  )
}
