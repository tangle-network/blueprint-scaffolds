import { useMemo } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { cn, formatUsdFull, formatPercent, formatAddress } from '@/lib/utils'
import { Trophy, TrendingUp, BarChart3, Users } from 'lucide-react'
import type { LeaderboardEntry } from '@/types'

function generateLeaderboard(): LeaderboardEntry[] {
  const names = [
    'WhaleHunter', 'DegenSpartan', 'ArbMaxi', 'LiquidationKing', 'PerpWizard',
    'FundingFarmer', 'DeltaNeutral', 'LeverageLord', 'GMXWhale', 'ArbitrumAce',
    'ShortSeller', 'BullRunRider', 'CryptoSage', 'MarginMaster', 'YieldChaser',
    'FlashTrader', 'BlockBuilder', 'GasOptimizor', 'ProtocolPilot', 'StackedETH',
  ]

  return names.map((name, i) => ({
    rank: i + 1,
    address: `0x${(Math.random().toString(16) + '0'.repeat(40)).slice(2, 42)}`,
    displayName: name,
    totalPnl: Math.round((Math.random() - 0.3) * 500000 * 100) / 100,
    totalPnlPercent: Math.round((Math.random() - 0.3) * 200 * 100) / 100,
    totalVolume: Math.round(Math.random() * 50000000 * 100) / 100,
    winRate: Math.round((40 + Math.random() * 40) * 100) / 100,
    positionsCount: Math.floor(Math.random() * 500 + 50),
    isTopTrader: i < 3,
  })).sort((a, b) => b.totalPnl - a.totalPnl).map((entry, i) => ({ ...entry, rank: i + 1 }))
}

function LeaderboardRow({ entry }: { entry: LeaderboardEntry }) {
  const isPositive = entry.totalPnl >= 0

  return (
    <div className={cn(
      'flex items-center gap-4 px-4 py-3 border-b border-border transition-colors hover:bg-muted/30',
      entry.rank <= 3 && 'bg-muted/10'
    )}>
      <div className="w-10 flex items-center justify-center">
        {entry.rank === 1 && <Trophy className="h-5 w-5 text-yellow-500" />}
        {entry.rank === 2 && <Trophy className="h-5 w-5 text-gray-400" />}
        {entry.rank === 3 && <Trophy className="h-5 w-5 text-amber-700" />}
        {entry.rank > 3 && <span className="text-sm text-muted-foreground font-medium">#{entry.rank}</span>}
      </div>

      <div className="w-36">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-foreground">{entry.displayName}</span>
          {entry.isTopTrader && (
            <Badge variant="secondary" className="text-xs px-1.5 py-0 bg-yellow-500/10 text-yellow-500 border-yellow-500/20">
              Top
            </Badge>
          )}
        </div>
        <span className="text-xs text-muted-foreground font-mono">{formatAddress(entry.address)}</span>
      </div>

      <div className="w-32 text-right">
        <span className={cn('text-sm font-semibold', isPositive ? 'text-emerald-500' : 'text-red-500')}>
          {isPositive ? '+' : ''}{formatUsdFull(entry.totalPnl)}
        </span>
        <p className={cn('text-xs', isPositive ? 'text-emerald-500/70' : 'text-red-500/70')}>
          {formatPercent(entry.totalPnlPercent)}
        </p>
      </div>

      <div className="w-28 text-right">
        <span className="text-sm text-foreground">{formatUsdFull(entry.totalVolume)}</span>
        <p className="text-xs text-muted-foreground">volume</p>
      </div>

      <div className="w-20 text-right">
        <span className="text-sm text-foreground">{entry.winRate.toFixed(1)}%</span>
        <p className="text-xs text-muted-foreground">win rate</p>
      </div>

      <div className="w-20 text-right">
        <span className="text-sm text-muted-foreground">{entry.positionsCount}</span>
        <p className="text-xs text-muted-foreground">trades</p>
      </div>
    </div>
  )
}

export default function LeaderboardPage() {
  const entries = useMemo(() => generateLeaderboard(), [])
  const totalPnl = entries.reduce((sum, e) => sum + e.totalPnl, 0)
  const totalVolume = entries.reduce((sum, e) => sum + e.totalVolume, 0)
  const avgWinRate = entries.reduce((sum, e) => sum + e.winRate, 0) / entries.length

  return (
    <div className="space-y-6 p-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Leaderboard</h1>
        <p className="text-sm text-muted-foreground mt-1">Top traders ranked by PnL on Arbitrum perps</p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Trader PnL</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className={cn('text-2xl font-bold', totalPnl >= 0 ? 'text-emerald-500' : 'text-red-500')}>
              {formatUsdFull(totalPnl)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Volume</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatUsdFull(totalVolume)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">Avg. Win Rate</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{avgWinRate.toFixed(1)}%</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-0">
          <div className="flex items-center gap-4 px-4 text-xs font-medium text-muted-foreground pb-2">
            <div className="w-10">Rank</div>
            <div className="w-36">Trader</div>
            <div className="w-32 text-right">PnL</div>
            <div className="w-28 text-right">Volume</div>
            <div className="w-20 text-right">Win Rate</div>
            <div className="w-20 text-right">Trades</div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {entries.map((entry) => (
            <LeaderboardRow key={entry.rank} entry={entry} />
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
