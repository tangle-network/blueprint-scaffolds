import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import {
  MOCK_NETWORK_STATS,
  MOCK_TASKS,
  MOCK_OPERATORS,
  TASK_TYPE_LABELS,
  TASK_TYPE_COLORS,
  STATUS_COLORS,
} from '@/lib/mock-data'
import { formatEth, formatPercent, timeAgo, formatUsd } from '@/lib/utils'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
} from 'recharts'
import { Activity, Users, Zap, DollarSign, Shield, TrendingUp } from 'lucide-react'
import type { Task } from '@/lib/types'

const PIE_COLORS = ['#8b5cf6', '#3b82f6', '#10b981', '#f59e0b']

export default function Dashboard() {
  const stats = MOCK_NETWORK_STATS

  const tasksByTypeData = Object.entries(stats.tasksByType).map(([type, count]) => ({
    name: TASK_TYPE_LABELS[type] || type,
    value: count,
  }))

  const tasksByProtocolData = [
    { name: 'Aave', tasks: stats.tasksByProtocol.aave },
    { name: 'Compound', tasks: stats.tasksByProtocol.compound },
    { name: 'Vault', tasks: stats.tasksByProtocol.vault },
  ]

  const recentTasks = [...MOCK_TASKS]
    .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
    .slice(0, 8)

  const topOperators = [...MOCK_OPERATORS]
    .sort((a, b) => b.stake - a.stake)
    .slice(0, 5)

  const hourlyData = Array.from({ length: 24 }, (_, i) => ({
    hour: `${i}:00`,
    tasks: Math.floor(Math.random() * 20) + 5,
    gas: Math.floor(Math.random() * 150000) + 50000,
  }))

  const statCards = [
    {
      title: 'Total Stake',
      value: formatEth(stats.totalStake),
      icon: Zap,
      sub: `${stats.activeOperators} active operators`,
    },
    {
      title: 'Tasks Completed',
      value: stats.totalTasksCompleted.toLocaleString(),
      icon: Activity,
      sub: `${stats.tasksLast24h} in last 24h`,
    },
    {
      title: 'SLA Compliance',
      value: formatPercent(stats.slaComplianceRate),
      icon: Shield,
      sub: 'Network average',
    },
    {
      title: 'Rewards Distributed',
      value: formatEth(stats.totalRewardsDistributed),
      icon: DollarSign,
      sub: 'Total to operators',
    },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Network Dashboard</h1>
        <p className="text-sm text-muted-foreground">Keeper Network AVS overview on EigenLayer</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {statCards.map(({ title, value, icon: Icon, sub }) => (
          <Card key={title}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
              <Icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{value}</div>
              <p className="text-xs text-muted-foreground mt-1">{sub}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Task Volume (24h)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <AreaChart data={hourlyData}>
                <defs>
                  <linearGradient id="taskGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="hour" tick={{ fontSize: 10 }} stroke="#666" interval={3} />
                <YAxis tick={{ fontSize: 10 }} stroke="#666" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #333', borderRadius: 8 }}
                />
                <Area type="monotone" dataKey="tasks" stroke="#8b5cf6" fill="url(#taskGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Tasks by Type</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={tasksByTypeData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {tasksByTypeData.map((_, i) => (
                    <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #333', borderRadius: 8 }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex justify-center gap-4 mt-2">
              {tasksByTypeData.map((d, i) => (
                <div key={d.name} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <span className="h-2 w-2 rounded-full" style={{ backgroundColor: PIE_COLORS[i] }} />
                  {d.name}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Tasks by Protocol</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={tasksByProtocolData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} stroke="#666" />
                <YAxis tick={{ fontSize: 10 }} stroke="#666" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #333', borderRadius: 8 }}
                />
                <Bar dataKey="tasks" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Top Operators by Stake</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {topOperators.map((op) => (
                <div key={op.id} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="h-2 w-2 rounded-full bg-green-500" />
                    <span className="text-sm font-mono">{op.address.slice(0, 10)}...</span>
                  </div>
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-muted-foreground">{op.tasksCompleted} tasks</span>
                    <span className="font-medium">{formatEth(op.stake)}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Recent Tasks</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {recentTasks.map((task) => (
              <div key={task.id} className="flex items-center justify-between rounded-md border p-3">
                <div className="flex items-center gap-3">
                  <Badge className={TASK_TYPE_COLORS[task.type]}>
                    {TASK_TYPE_LABELS[task.type]}
                  </Badge>
                  <span className="text-sm">{task.description.slice(0, 50)}...</span>
                </div>
                <div className="flex items-center gap-3">
                  <Badge className={STATUS_COLORS[task.status]} variant="outline">
                    {task.status}
                  </Badge>
                  <span className="text-xs text-muted-foreground">{timeAgo(task.createdAt)}</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
