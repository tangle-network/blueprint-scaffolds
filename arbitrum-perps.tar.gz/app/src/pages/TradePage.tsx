import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import MarketSelector from '@/components/trading/market-selector'
import PriceChart from '@/components/trading/price-chart'
import OrderForm from '@/components/trading/order-form'
import PositionsTable from '@/components/trading/positions-table'
import OrdersTable from '@/components/trading/orders-table'
import RecentTrades from '@/components/trading/recent-trades'
import MarketInfo from '@/components/trading/market-info'
import { useMarketStore } from '@/stores/trading-store'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { cn } from '@/lib/utils'

export default function TradePage() {
  const { pair } = useParams<{ pair: string }>()
  const { markets, setSelectedMarket } = useMarketStore()
  const [rightTab, setRightTab] = useState('order')
  const [bottomTab, setBottomTab] = useState('positions')

  useEffect(() => {
    if (pair) {
      const marketId = pair.toLowerCase() + '-usd'
      const exists = markets.find((m) => m.id === marketId)
      if (exists) setSelectedMarket(marketId)
    }
  }, [pair, markets, setSelectedMarket])

  return (
    <div className="flex flex-col h-[calc(100vh-3.5rem)]">
      <MarketSelector />

      <div className="flex-1 grid grid-cols-[1fr_320px] grid-rows-[1fr_280px] gap-px bg-border min-h-0">
        <div className="bg-card flex flex-col min-h-0 overflow-hidden">
          <PriceChart />
        </div>

        <div className="bg-card flex flex-col min-h-0 overflow-hidden">
          <div className="border-b border-border">
            <Tabs value={rightTab} onValueChange={setRightTab}>
              <TabsList className="w-full rounded-none bg-transparent p-0 h-9">
                <TabsTrigger value="order" className="flex-1 rounded-none border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none">
                  Order
                </TabsTrigger>
                <TabsTrigger value="info" className="flex-1 rounded-none border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none">
                  Info
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          <div className="flex-1 overflow-y-auto">
            {rightTab === 'order' && <OrderForm />}
            {rightTab === 'info' && <MarketInfo />}
          </div>
        </div>

        <div className="bg-card col-span-2 flex flex-col min-h-0 overflow-hidden">
          <div className="border-b border-border">
            <Tabs value={bottomTab} onValueChange={setBottomTab}>
              <TabsList className="w-full rounded-none bg-transparent p-0 h-9">
                <TabsTrigger value="positions" className="flex-1 rounded-none border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none">
                  Positions
                </TabsTrigger>
                <TabsTrigger value="orders" className="flex-1 rounded-none border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none">
                  Orders
                </TabsTrigger>
                <TabsTrigger value="trades" className="flex-1 rounded-none border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none">
                  Trades
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          <div className="flex-1 overflow-y-auto">
            {bottomTab === 'positions' && <PositionsTable />}
            {bottomTab === 'orders' && <OrdersTable />}
            {bottomTab === 'trades' && <RecentTrades />}
          </div>
        </div>
      </div>
    </div>
  )
}
