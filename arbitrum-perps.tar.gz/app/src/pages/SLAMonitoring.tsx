import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { MOCK_SLA_COMMITMENTS, MOCK_OPERATORS, MOCK_NETWORK_STATS } from '@/lib/mock-data'
import { formatPercent, formatEth } from '@/lib/utils'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts'
import { Shield, CheckCircle, XCircle, Clock, AlertTriangle } from 'lucide-react'

export default function SLAMonitoring() {
  const commitments = MOCK_SLA_COMMITMENTS
  const onTime = commitments.filter((c) => c.completed && c.onTime).length
  const late = commitments.filter((c) => c.completed && !c.onTime).length
  const pending = commitments.filter((c) => !c.completed).length
  const total = commitments.length

  const complianceRate = total > 0 ? ((onTime / (onTime + late)) * 100) : 100

  const penaltyData = commitments
    .filter((c) => c.completed && !c.onTime)
    .map((c) => ({
      taskId: c.taskId.slice(0, 12),
      penalty: c.penaltyRate,
    }))

  const operatorSLA = MOCK_OPERATORS.map((op) => ({
    name: op.address.slice(0, 8) + '...',
    score: op.slaScore,
  })).sort((a, b) => a.score - b.score)

  const PIE_COLORS = ['#10b981', '#ef4444', '#f59e0b']

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">SLA Monitoring</h1>
        <p className="text-sm text-muted-foreground">
          Service Level Agreement commitments and compliance tracking
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm text-muted-foreground">Compliance Rate</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-400">{formatPercent(complianceRate)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm text-muted-foreground">On-Time</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-400" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{onTime}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm text-muted-foreground">Late / Failed</CardTitle>
            <XCircle className="h-4 w-4 text-red-400" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-red-400">{late}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm text-muted-foreground">Pending</CardTitle>
            <Clock className="h-4 w-4 text-yellow-400" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-yellow-400">{pending}</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">SLA Outcome Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={[
                    { name: 'On Time', value: onTime },
                    { name: 'Late', value: late },
                    { name: 'Pending', value: pending },
                  ]}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {[0, 1, 2].map((i) => (
                    <Cell key={i} fill={PIE_COLORS[i]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #333', borderRadius: 8 }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex justify-center gap-4 mt-2">
              {['On Time', 'Late', 'Pending'].map((label, i) => (
                <div key={label} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <span className="h-2 w-2 rounded-full" style={{ backgroundColor: PIE_COLORS[i] }} />
                  {label}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Operator SLA Scores</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={operatorSLA} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis type="number" domain={[80, 100]} tick={{ fontSize: 10 }} stroke="#666" />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 9 }} width={80} stroke="#666" />
                <Tooltip contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #333', borderRadius: 8 }} />
                <Bar dataKey="score" fill="#8b5cf6" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">SLA Commitments</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/30">
                  <th className="text-left p-3 text-xs font-medium text-muted-foreground">Task ID</th>
                  <th className="text-left p-3 text-xs font-medium text-muted-foreground">Operator</th>
                  <th className="text-left p-3 text-xs font-medium text-muted-foreground">Deadline</th>
                  <th className="text-left p-3 text-xs font-medium text-muted-foreground">Status</th>
                  <th className="text-left p-3 text-xs font-medium text-muted-foreground">Penalty Rate</th>
                  <th className="text-left p-3 text-xs font-medium text-muted-foreground">Result</th>
                </tr>
              </thead>
              <tbody>
                {commitments.map((c, i) => {
                  const isExpired = !c.completed && c.deadline < new Date()
                  return (
                    <tr key={i} className="border-b hover:bg-muted/20">
                      <td className="p-3 font-mono text-xs">{c.taskId.slice(0, 16)}</td>
                      <td className="p-3 font-mono text-xs">{c.operatorId.slice(0, 12)}</td>
                      <td className="p-3 text-xs">{c.deadline.toLocaleString()}</td>
                      <td className="p-3">
                        {c.completed ? (
                          <Badge className="bg-green-500/20 text-green-400">Completed</Badge>
                        ) : isExpired ? (
                          <Badge className="bg-red-500/20 text-red-400">
                            <AlertTriangle className="h-3 w-3 mr-1" />
                            Expired
                          </Badge>
                        ) : (
                          <Badge className="bg-yellow-500/20 text-yellow-400">In Progress</Badge>
                        )}
                      </td>
                      <td className="p-3 text-xs">{c.penaltyRate.toFixed(2)}x</td>
                      <td className="p-3">
                        {c.completed ? (
                          c.onTime ? (
                            <span className="text-green-400 text-xs flex items-center gap-1">
                              <CheckCircle className="h-3 w-3" /> On Time
                            </span>
                          ) : (
                            <span className="text-red-400 text-xs flex items-center gap-1">
                              <XCircle className="h-3 w-3" /> Late
                            </span>
                          )
                        ) : (
                          <span className="text-muted-foreground text-xs">—</span>
                        )}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">SLA Enforcement Rules</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-md border p-4">
              <h4 className="text-sm font-medium mb-2">Penalty Structure</h4>
              <ul className="space-y-1 text-xs text-muted-foreground">
                <li>• Late execution: 0.5x penalty on staked amount</li>
                <li>• Failed execution: 1.0x penalty on staked amount</li>
                <li>• Missed deadline (no execution): 2.0x penalty</li>
                <li>• Repeated failures trigger progressive slashing</li>
              </ul>
            </div>
            <div className="rounded-md border p-4">
              <h4 className="text-sm font-medium mb-2">Fallback Mechanism</h4>
              <ul className="space-y-1 text-xs text-muted-foreground">
                <li>• Max 3 fallback attempts per task</li>
                <li>• Fallback operators selected by stake weight</li>
                <li>• Penalty applies to all failed operators in chain</li>
                <li>• Final fallback: any registered operator may claim</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
