import { useAccountStore, usePositionStore } from '@/stores/trading-store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { cn, formatUsdFull, formatPercent, formatPrice } from '@/lib/utils'
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  AreaChart,
  Area,
  XAxis,
  YAxis,
} from 'recharts'
import { Wallet, TrendingUp, Shield, DollarSign } from 'lucide-react'

const COLORS = ['#3b82f6', '#8b5cf6', '#f59e0b', '#10b981']

function generateEquityHistory() {
  const data = []
  let equity = 30000
  const now = Date.now()
  for (let i = 0; i < 30; i++) {
    equity += (Math.random() - 0.45) * 500
    data.push({
      day: new Date(now - (30 - i) * 86400000).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      equity: Math.round(equity * 100) / 100,
    })
  }
  return data
}

export default function PortfolioPage() {
  const { collateral, accountSummary } = useAccountStore()
  const { positions } = usePositionStore()
  const equityHistory = generateEquityHistory()

  const totalUnrealizedPnl = positions.reduce((sum, p) => sum + p.unrealizedPnl, 0)
  const isPnlPositive = totalUnrealizedPnl >= 0

  return (
    <div className="space-y-6 p-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Portfolio</h1>
        <p className="text-sm text-muted-foreground mt-1">Account overview and collateral management</p>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Equity</CardTitle>
            <Wallet className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatUsdFull(accountSummary.totalEquity)}</div>
            <p className={cn('text-xs mt-1', isPnlPositive ? 'text-emerald-500' : 'text-red-500')}>
              {isPnlPositive ? '+' : ''}{formatUsdFull(totalUnrealizedPnl)} unrealized PnL
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">Available Margin</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatUsdFull(accountSummary.availableMargin)}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {formatUsdFull(accountSummary.totalMargin)} used
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">Margin Ratio</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{accountSummary.marginRatio.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground mt-1">
              {accountSummary.totalPositions} positions open
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">Open Orders</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{accountSummary.totalOrders}</div>
            <p className="text-xs text-muted-foreground mt-1">
              pending execution
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-[1fr_1fr] gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Equity History (30D)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={equityHistory}>
                  <defs>
                    <linearGradient id="equityGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="day" tick={{ fontSize: 10, fill: 'hsl(215 20% 55%)' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 10, fill: 'hsl(215 20% 55%)' }} axisLine={false} tickLine={false} tickFormatter={(v: number) => `$${(v / 1000).toFixed(0)}K`} width={50} />
                  <Tooltip
                    contentStyle={{ backgroundColor: 'hsl(222 47% 8%)', border: '1px solid hsl(222 47% 14%)', borderRadius: '8px', fontSize: '12px' }}
                    labelStyle={{ color: 'hsl(215 20% 55%)' }}
                    itemStyle={{ color: 'hsl(210 40% 98%)' }}
                    formatter={(value: number) => [formatUsdFull(value), 'Equity']}
                  />
                  <Area type="monotone" dataKey="equity" stroke="#3b82f6" fill="url(#equityGrad)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Collateral Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <div className="w-1/2 h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={collateral} cx="50%" cy="50%" innerRadius={60} outerRadius={90} dataKey="usdValue" nameKey="symbol" paddingAngle={2}>
                      {collateral.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{ backgroundColor: 'hsl(222 47% 8%)', border: '1px solid hsl(222 47% 14%)', borderRadius: '8px', fontSize: '12px' }}
                      formatter={(value: number) => [formatUsdFull(value), '']}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="w-1/2 flex flex-col justify-center space-y-3">
                {collateral.map((asset, i) => (
                  <div key={asset.id} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                      <span className="text-sm font-medium">{asset.symbol}</span>
                      {asset.isYieldBearing && (
                        <Badge variant="secondary" className="text-xs px-1 py-0">Yield</Badge>
                      )}
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">{formatUsdFull(asset.usdValue)}</p>
                      <p className="text-xs text-muted-foreground">{asset.balance} {asset.symbol}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
