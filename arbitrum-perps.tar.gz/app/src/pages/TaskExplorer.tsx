import { useState, useMemo } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select } from '@/components/ui/select'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { MOCK_TASKS, TASK_TYPE_LABELS, PROTOCOL_LABELS, STATUS_COLORS, TASK_TYPE_COLORS } from '@/lib/mock-data'
import { formatEth, formatAddress, timeAgo } from '@/lib/utils'
import { Search, Filter, ChevronDown, ChevronUp, Clock, AlertTriangle } from 'lucide-react'
import type { Task, TaskType, TaskStatus, Protocol } from '@/lib/types'

function TaskDetail({ task, onClose }: { task: Task; onClose: () => void }) {
  return (
    <Card className="border-primary/30">
      <CardHeader className="flex flex-row items-start justify-between">
        <div>
          <CardTitle className="text-base">{task.description}</CardTitle>
          <p className="text-xs text-muted-foreground mt-1 font-mono">{task.id}</p>
        </div>
        <Button variant="ghost" size="sm" onClick={onClose}>
          Close
        </Button>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <div>
            <p className="text-xs text-muted-foreground">Type</p>
            <Badge className={TASK_TYPE_COLORS[task.type]}>{TASK_TYPE_LABELS[task.type]}</Badge>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Status</p>
            <Badge className={STATUS_COLORS[task.status]} variant="outline">{task.status}</Badge>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Protocol</p>
            <p className="text-sm font-medium">{PROTOCOL_LABELS[task.protocol]}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Target</p>
            <p className="text-sm font-mono">{formatAddress(task.targetAddress)}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Reward</p>
            <p className="text-sm font-medium text-green-400">{formatEth(task.reward)}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Gas Estimate</p>
            <p className="text-sm">{task.gasEstimate.toLocaleString()} gas</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Priority</p>
            <p className="text-sm">{task.priority}/100</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Assigned Operator</p>
            <p className="text-sm font-mono">{task.assignedOperator || 'Unassigned'}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Fallbacks</p>
            <p className="text-sm">
              {task.fallbackCount}/{task.maxFallbacks}
            </p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">SLA Deadline</p>
            <p className="text-sm">{task.slaDeadline.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Created</p>
            <p className="text-sm">{timeAgo(task.createdAt)}</p>
          </div>
          {task.executedAt && (
            <div>
              <p className="text-xs text-muted-foreground">Executed</p>
              <p className="text-sm">{timeAgo(task.executedAt)}</p>
            </div>
          )}
        </div>

        <div className="mt-4 rounded-md bg-muted/50 p-3">
          <p className="text-xs font-medium text-muted-foreground mb-2">Execution Pipeline</p>
          <div className="flex items-center gap-2">
            <span className="flex h-6 items-center rounded bg-yellow-500/20 px-2 text-xs text-yellow-400">Created</span>
            <span className="text-muted-foreground">→</span>
            <span className="flex h-6 items-center rounded bg-blue-500/20 px-2 text-xs text-blue-400">Assigned</span>
            <span className="text-muted-foreground">→</span>
            <span className="flex h-6 items-center rounded bg-purple-500/20 px-2 text-xs text-purple-400">Executing</span>
            <span className="text-muted-foreground">→</span>
            <span className={`flex h-6 items-center rounded px-2 text-xs ${task.status === 'completed' ? 'bg-green-500/20 text-green-400' : task.status === 'failed' ? 'bg-red-500/20 text-red-400' : 'bg-gray-500/20 text-gray-400'}`}>
              {task.status === 'completed' ? 'Verified' : task.status === 'failed' ? 'Failed' : 'Pending'}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default function TaskExplorer() {
  const [search, setSearch] = useState('')
  const [typeFilter, setTypeFilter] = useState<string>('all')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [protocolFilter, setProtocolFilter] = useState<string>('all')
  const [selectedTask, setSelectedTask] = useState<Task | null>(null)
  const [sortBy, setSortBy] = useState<'priority' | 'reward' | 'created'>('priority')
  const [sortAsc, setSortAsc] = useState(false)

  const filtered = useMemo(() => {
    let tasks = [...MOCK_TASKS]
    if (search) {
      const q = search.toLowerCase()
      tasks = tasks.filter(
        (t) =>
          t.description.toLowerCase().includes(q) ||
          t.id.toLowerCase().includes(q) ||
          t.targetAddress.toLowerCase().includes(q)
      )
    }
    if (typeFilter !== 'all') tasks = tasks.filter((t) => t.type === typeFilter)
    if (statusFilter !== 'all') tasks = tasks.filter((t) => t.status === statusFilter)
    if (protocolFilter !== 'all') tasks = tasks.filter((t) => t.protocol === protocolFilter)

    tasks.sort((a, b) => {
      const dir = sortAsc ? 1 : -1
      if (sortBy === 'priority') return (a.priority - b.priority) * dir
      if (sortBy === 'reward') return (a.reward - b.reward) * dir
      return (a.createdAt.getTime() - b.createdAt.getTime()) * dir
    })
    return tasks
  }, [search, typeFilter, statusFilter, protocolFilter, sortBy, sortAsc])

  const counts = useMemo(() => {
    const byType = Object.fromEntries(Object.keys(TASK_TYPE_LABELS).map((k) => [k, MOCK_TASKS.filter((t) => t.type === k).length]))
    const byStatus = Object.fromEntries(['pending', 'active', 'completed', 'failed', 'cancelled'].map((s) => [s, MOCK_TASKS.filter((t) => t.status === s).length]))
    return { byType, byStatus }
  }, [])

  function toggleSort(field: 'priority' | 'reward' | 'created') {
    if (sortBy === field) setSortAsc(!sortAsc)
    else { setSortBy(field); setSortAsc(false) }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Task Explorer</h1>
        <p className="text-sm text-muted-foreground">Browse, filter, and inspect keeper tasks</p>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search tasks..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)}>
          <option value="all">All Types</option>
          {Object.entries(TASK_TYPE_LABELS).map(([k, v]) => (
            <option key={k} value={k}>{v}</option>
          ))}
        </Select>
        <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="all">All Statuses</option>
          {['pending', 'active', 'completed', 'failed', 'cancelled'].map((s) => (
            <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>
          ))}
        </Select>
        <Select value={protocolFilter} onChange={(e) => setProtocolFilter(e.target.value)}>
          <option value="all">All Protocols</option>
          {Object.entries(PROTOCOL_LABELS).map(([k, v]) => (
            <option key={k} value={k}>{v}</option>
          ))}
        </Select>
      </div>

      <div className="flex gap-2 flex-wrap">
        <Badge variant="outline">{filtered.length} tasks</Badge>
        {typeFilter !== 'all' && <Badge className={TASK_TYPE_COLORS[typeFilter]}>{TASK_TYPE_LABELS[typeFilter]}</Badge>}
        {statusFilter !== 'all' && <Badge className={STATUS_COLORS[statusFilter]}>{statusFilter}</Badge>}
      </div>

      {selectedTask && (
        <TaskDetail task={selectedTask} onClose={() => setSelectedTask(null)} />
      )}

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/30">
                  <th className="text-left p-3 text-xs font-medium text-muted-foreground">Type</th>
                  <th className="text-left p-3 text-xs font-medium text-muted-foreground">Description</th>
                  <th className="text-left p-3 text-xs font-medium text-muted-foreground">Protocol</th>
                  <th className="text-left p-3 text-xs font-medium text-muted-foreground">Status</th>
                  <th className="text-left p-3 text-xs font-medium text-muted-foreground cursor-pointer" onClick={() => toggleSort('reward')}>
                    Reward {sortBy === 'reward' && (sortAsc ? '↑' : '↓')}
                  </th>
                  <th className="text-left p-3 text-xs font-medium text-muted-foreground cursor-pointer" onClick={() => toggleSort('priority')}>
                    Priority {sortBy === 'priority' && (sortAsc ? '↑' : '↓')}
                  </th>
                  <th className="text-left p-3 text-xs font-medium text-muted-foreground">Gas</th>
                  <th className="text-left p-3 text-xs font-medium text-muted-foreground">Operator</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((task) => (
                  <tr
                    key={task.id}
                    className="border-b hover:bg-muted/20 cursor-pointer transition-colors"
                    onClick={() => setSelectedTask(selectedTask?.id === task.id ? null : task)}
                  >
                    <td className="p-3">
                      <Badge className={TASK_TYPE_COLORS[task.type]}>{TASK_TYPE_LABELS[task.type]}</Badge>
                    </td>
                    <td className="p-3 max-w-[300px] truncate">{task.description}</td>
                    <td className="p-3">{PROTOCOL_LABELS[task.protocol]}</td>
                    <td className="p-3">
                      <Badge className={STATUS_COLORS[task.status]} variant="outline">{task.status}</Badge>
                    </td>
                    <td className="p-3 text-green-400">{formatEth(task.reward)}</td>
                    <td className="p-3">
                      <div className="flex items-center gap-2">
                        <div className="h-1.5 w-12 rounded-full bg-muted">
                          <div className="h-full rounded-full bg-primary" style={{ width: `${task.priority}%` }} />
                        </div>
                        <span className="text-xs">{task.priority}</span>
                      </div>
                    </td>
                    <td className="p-3 text-xs text-muted-foreground">{(task.gasEstimate / 1000).toFixed(0)}k</td>
                    <td className="p-3 font-mono text-xs">
                      {task.assignedOperator ? task.assignedOperator.slice(0, 10) + '...' : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
