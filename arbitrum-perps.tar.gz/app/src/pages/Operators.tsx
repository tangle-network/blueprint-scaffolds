import { useState, useMemo } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Select } from '@/components/ui/select'
import { Progress } from '@/components/ui/progress'
import {
  MOCK_OPERATORS,
  MOCK_NETWORK_STATS,
  TASK_TYPE_LABELS,
  PROTOCOL_LABELS,
} from '@/lib/mock-data'
import { formatEth, formatAddress, formatPercent, timeAgo } from '@/lib/utils'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from 'recharts'
import { Search, TrendingUp, TrendingDown, Award } from 'lucide-react'
import type { Operator, OperatorStatus } from '@/lib/types'

const STATUS_LABELS: Record<OperatorStatus, string> = {
  active: 'Active',
  inactive: 'Inactive',
  slashed: 'Slashed',
  deregistered: 'Deregistered',
}

const STATUS_COLORS: Record<OperatorStatus, string> = {
  active: 'bg-green-500/20 text-green-400',
  inactive: 'bg-gray-500/20 text-gray-400',
  slashed: 'bg-red-500/20 text-red-400',
  deregistered: 'bg-yellow-500/20 text-yellow-400',
}

export default function Operators() {
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [selectedOp, setSelectedOp] = useState<Operator | null>(null)

  const filtered = useMemo(() => {
    let ops = [...MOCK_OPERATORS]
    if (search) {
      const q = search.toLowerCase()
      ops = ops.filter(
        (o) => o.address.toLowerCase().includes(q) || o.id.toLowerCase().includes(q)
      )
    }
    if (statusFilter !== 'all') ops = ops.filter((o) => o.status === statusFilter)
    return ops.sort((a, b) => b.stake - a.stake)
  }, [search, statusFilter])

  const stakeDistribution = useMemo(() => {
    const buckets = [
      { range: '0-50', count: 0 },
      { range: '50-100', count: 0 },
      { range: '100-200', count: 0 },
      { range: '200-300', count: 0 },
      { range: '300+', count: 0 },
    ]
    for (const op of MOCK_OPERATORS) {
      if (op.stake < 50) buckets[0].count++
      else if (op.stake < 100) buckets[1].count++
      else if (op.stake < 200) buckets[2].count++
      else if (op.stake < 300) buckets[3].count++
      else buckets[4].count++
    }
    return buckets
  }, [])

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Operators</h1>
        <p className="text-sm text-muted-foreground">
          EigenLayer restaked operators in the Keeper Network AVS
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground">Total Operators</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{MOCK_NETWORK_STATS.totalOperators}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground">Active</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-400">{MOCK_NETWORK_STATS.activeOperators}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground">Total Stake</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{formatEth(MOCK_NETWORK_STATS.totalStake)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground">Avg SLA Score</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{formatPercent(MOCK_OPERATORS.reduce((s, o) => s + o.slaScore, 0) / MOCK_OPERATORS.length)}</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Operator Registry</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-3 mb-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search by address..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9"
                />
              </div>
              <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
                <option value="all">All Status</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
                <option value="slashed">Slashed</option>
              </Select>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/30">
                    <th className="text-left p-3 text-xs font-medium text-muted-foreground">Operator</th>
                    <th className="text-left p-3 text-xs font-medium text-muted-foreground">Status</th>
                    <th className="text-left p-3 text-xs font-medium text-muted-foreground">Stake</th>
                    <th className="text-left p-3 text-xs font-medium text-muted-foreground">Success Rate</th>
                    <th className="text-left p-3 text-xs font-medium text-muted-foreground">Tasks</th>
                    <th className="text-left p-3 text-xs font-medium text-muted-foreground">SLA</th>
                    <th className="text-left p-3 text-xs font-medium text-muted-foreground">Rewards</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((op) => (
                    <tr
                      key={op.id}
                      className={`border-b hover:bg-muted/20 cursor-pointer transition-colors ${selectedOp?.id === op.id ? 'bg-primary/5' : ''}`}
                      onClick={() => setSelectedOp(selectedOp?.id === op.id ? null : op)}
                    >
                      <td className="p-3">
                        <div>
                          <p className="font-mono text-xs">{formatAddress(op.address)}</p>
                          <p className="text-xs text-muted-foreground">{op.delegatorCount} delegators</p>
                        </div>
                      </td>
                      <td className="p-3">
                        <Badge className={STATUS_COLORS[op.status]}>{STATUS_LABELS[op.status]}</Badge>
                      </td>
                      <td className="p-3 font-medium">{formatEth(op.stake)}</td>
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          <Progress value={op.successRate} className="h-1.5 w-16" />
                          <span className="text-xs">{formatPercent(op.successRate)}</span>
                        </div>
                      </td>
                      <td className="p-3">{op.tasksCompleted.toLocaleString()}</td>
                      <td className="p-3">
                        <span className={op.slaScore >= 95 ? 'text-green-400' : op.slaScore >= 90 ? 'text-yellow-400' : 'text-red-400'}>
                          {formatPercent(op.slaScore)}
                        </span>
                      </td>
                      <td className="p-3 text-green-400">{formatEth(op.totalRewardsEarned)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Stake Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={stakeDistribution}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                  <XAxis dataKey="range" tick={{ fontSize: 10 }} stroke="#666" />
                  <YAxis tick={{ fontSize: 10 }} stroke="#666" />
                  <Tooltip contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #333', borderRadius: 8 }} />
                  <Bar dataKey="count" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {selectedOp && (
            <Card className="border-primary/30">
              <CardHeader>
                <CardTitle className="text-base">Operator Detail</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2">
                  <Badge className={STATUS_COLORS[selectedOp.status]}>{STATUS_LABELS[selectedOp.status]}</Badge>
                  <span className="font-mono text-xs">{formatAddress(selectedOp.address)}</span>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Stake</span>
                    <span className="font-medium">{formatEth(selectedOp.stake)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Tasks Completed</span>
                    <span>{selectedOp.tasksCompleted.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Tasks Failed</span>
                    <span className="text-red-400">{selectedOp.tasksFailed}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Avg Execution</span>
                    <span>{selectedOp.avgExecutionTime.toFixed(1)}s</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">SLA Score</span>
                    <span>{formatPercent(selectedOp.slaScore)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Rewards</span>
                    <span className="text-green-400">{formatEth(selectedOp.totalRewardsEarned)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Last Active</span>
                    <span>{timeAgo(selectedOp.lastActiveAt)}</span>
                  </div>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Supported Protocols</p>
                  <div className="flex gap-1">
                    {selectedOp.supportedProtocols.map((p) => (
                      <Badge key={p} variant="outline" className="text-xs">{PROTOCOL_LABELS[p]}</Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Task Types</p>
                  <div className="flex gap-1 flex-wrap">
                    {selectedOp.supportedTaskTypes.map((t) => (
                      <Badge key={t} variant="outline" className="text-xs">{TASK_TYPE_LABELS[t]}</Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
