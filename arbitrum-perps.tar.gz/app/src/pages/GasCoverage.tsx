import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { MOCK_GAS_COVERAGE, MOCK_TASKS, MOCK_NETWORK_STATS } from '@/lib/mock-data'
import { formatPercent, formatEth } from '@/lib/utils'
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts'
import { Fuel, TrendingUp, Shield, Zap } from 'lucide-react'

const gasHistory = Array.from({ length: 30 }, (_, i) => ({
  block: 19000000 + i * 100,
  baseFee: 10 + Math.random() * 40,
  priorityFee: 1 + Math.random() * 4,
  coverage: 80 + Math.random() * 19,
}))

const taskGasData = MOCK_TASKS.slice(0, 20).map((t) => ({
  task: t.id.slice(0, 10),
  gas: t.gasEstimate,
  reward: t.reward * 1e6,
}))

export default function GasCoverage() {
  const gc = MOCK_GAS_COVERAGE
  const coveragePercent = (gc.operatorCoverage / gc.maxCoverage) * 100

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Gas Coverage</h1>
        <p className="text-sm text-muted-foreground">
          Gas estimation, coverage policies, and reimbursement tracking
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm text-muted-foreground">Base Gas</CardTitle>
            <Fuel className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{gc.baseGas.toLocaleString()}</p>
            <p className="text-xs text-muted-foreground">gas units</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm text-muted-foreground">Priority Fee</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{gc.priorityFee} Gwei</p>
            <p className="text-xs text-muted-foreground">tip per gas unit</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm text-muted-foreground">Max Coverage</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{gc.maxCoverage.toLocaleString()}</p>
            <p className="text-xs text-muted-foreground">gas units covered</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm text-muted-foreground">Avg Coverage</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-400">
              {formatPercent(MOCK_NETWORK_STATS.avgGasCoverage)}
            </p>
            <p className="text-xs text-muted-foreground">network average</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Gas Fee History</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <AreaChart data={gasHistory}>
                <defs>
                  <linearGradient id="baseGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="block" tick={{ fontSize: 9 }} stroke="#666" interval={4} />
                <YAxis tick={{ fontSize: 10 }} stroke="#666" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1a1a2e',
                    border: '1px solid #333',
                    borderRadius: 8,
                  }}
                />
                <Area type="monotone" dataKey="baseFee" stroke="#8b5cf6" fill="url(#baseGrad)" name="Base Fee (Gwei)" />
                <Area type="monotone" dataKey="priorityFee" stroke="#f59e0b" fill="none" name="Priority Fee (Gwei)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Task Gas Usage vs Reward</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={taskGasData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="task" tick={{ fontSize: 8 }} stroke="#666" angle={-45} textAnchor="end" height={60} />
                <YAxis tick={{ fontSize: 10 }} stroke="#666" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1a1a2e',
                    border: '1px solid #333',
                    borderRadius: 8,
                  }}
                />
                <Bar dataKey="gas" fill="#8b5cf6" name="Gas (units)" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Coverage Policy</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="rounded-md border p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-sm font-medium">Current Coverage Level</h4>
                <Badge className="bg-green-500/20 text-green-400">
                  {formatPercent(coveragePercent)}
                </Badge>
              </div>
              <Progress value={coveragePercent} className="h-2" />
              <div className="flex justify-between mt-2 text-xs text-muted-foreground">
                <span>Operator: {gc.operatorCoverage.toLocaleString()} gas</span>
                <span>Max: {gc.maxCoverage.toLocaleString()} gas</span>
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-3">
              <div className="rounded-md border p-4">
                <h4 className="text-sm font-medium mb-2">Liquidation Tasks</h4>
                <p className="text-xs text-muted-foreground">
                  Gas fully covered up to 350k units. Priority fee capped at 5 Gwei. Excess borne by task creator.
                </p>
              </div>
              <div className="rounded-md border p-4">
                <h4 className="text-sm font-medium mb-2">Rebalancing</h4>
                <p className="text-xs text-muted-foreground">
                  90% gas coverage up to 250k units. Operators stake-weighted subsidy applies for remaining 10%.
                </p>
              </div>
              <div className="rounded-md border p-4">
                <h4 className="text-sm font-medium mb-2">Yield Harvest</h4>
                <p className="text-xs text-muted-foreground">
                  Coverage from harvested yield. Min harvest must exceed gas cost by 1.5x. Auto-pause if unprofitable.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
