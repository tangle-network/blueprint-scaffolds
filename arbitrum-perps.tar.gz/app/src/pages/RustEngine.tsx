import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { MOCK_TASKS, TASK_TYPE_LABELS, PROTOCOL_LABELS } from '@/lib/mock-data'
import {
  Settings,
  Terminal,
  Cpu,
  Database,
  Network,
  Shield,
  Zap,
  FileCode,
  Activity,
} from 'lucide-react'

function CodeBlock({ code, language }: { code: string; language: string }) {
  return (
    <div className="relative">
      <div className="absolute right-2 top-2">
        <Badge variant="outline" className="text-xs">
          {language}
        </Badge>
      </div>
      <pre className="overflow-x-auto rounded-md bg-black/50 p-4 text-xs leading-relaxed">
        <code>{code}</code>
      </pre>
    </div>
  )
}

export default function RustEngine() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Rust Execution Engine</h1>
        <p className="text-sm text-muted-foreground">
          Operator software architecture and task execution pipeline
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm text-muted-foreground">Engine</CardTitle>
            <Cpu className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">v0.8.2</p>
            <p className="text-xs text-muted-foreground">Rust 1.75+</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm text-muted-foreground">Latency</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-400">~120ms</p>
            <p className="text-xs text-muted-foreground">avg execution</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm text-muted-foreground">Protocols</CardTitle>
            <Network className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">3</p>
            <p className="text-xs text-muted-foreground">Aave, Compound, Vault</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm text-muted-foreground">SLA</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">99.2%</p>
            <p className="text-xs text-muted-foreground">uptime guarantee</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="architecture">
        <TabsList>
          <TabsTrigger value="architecture">Architecture</TabsTrigger>
          <TabsTrigger value="executor">Task Executor</TabsTrigger>
          <TabsTrigger value="staking">Stake Selection</TabsTrigger>
          <TabsTrigger value="fallback">Fallback System</TabsTrigger>
        </TabsList>

        <TabsContent value="architecture">
          <div className="grid gap-4 lg:grid-cols-2 mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Terminal className="h-4 w-4" /> System Architecture
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="rounded-md border p-3">
                  <p className="text-xs font-medium mb-1">Task Listener</p>
                  <p className="text-xs text-muted-foreground">
                    Subscribes to EigenLayer task manager events via WebSocket. Validates incoming tasks against operator capabilities.
                  </p>
                </div>
                <div className="flex justify-center text-muted-foreground">↓</div>
                <div className="rounded-md border p-3">
                  <p className="text-xs font-medium mb-1">Task Dispatcher</p>
                  <p className="text-xs text-muted-foreground">
                    Stake-weighted task selection. Checks SLA commitments, gas coverage, and protocol support before accepting.
                  </p>
                </div>
                <div className="flex justify-center text-muted-foreground">↓</div>
                <div className="rounded-md border p-3">
                  <p className="text-xs font-medium mb-1">Execution Engine</p>
                  <p className="text-xs text-muted-foreground">
                    Builds and signs transactions for target protocols. Handles gas estimation, nonce management, and retry logic.
                  </p>
                </div>
                <div className="flex justify-center text-muted-foreground">↓</div>
                <div className="rounded-md border p-3">
                  <p className="text-xs font-medium mb-1">Result Aggregator</p>
                  <p className="text-xs text-muted-foreground">
                    Confirms on-chain execution, reports to AVS registry, tracks SLA compliance and gas usage.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <FileCode className="h-4 w-4" /> Cargo.toml
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CodeBlock
                  language="toml"
                  code={`[package]
name = "keeper-network-engine"
version = "0.8.2"
edition = "2021"

[dependencies]
alloy = { version = "0.1", features = ["full"] }
tokio = { version = "1", features = ["full"] }
serde = { version = "1", features = ["derive"] }
serde_json = "1"
eigensdk = "0.3"
tracing = "0.1"
tracing-subscriber = "0.3"
thiserror = "1"
async-trait = "0.1"

[dependencies.keeper-types]
path = "../keeper-types"

[profile.release]
opt-level = 3
lto = true
strip = true`}
                />
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="executor">
          <Card className="mt-4">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <FileCode className="h-4 w-4" /> Task Executor Module
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CodeBlock
                language="rust"
                code={`use alloy::providers::Provider;
use keeper_types::{Task, TaskType, Protocol, TaskResult};
use std::sync::Arc;

pub struct TaskExecutor<P: Provider> {
    provider: Arc<P>,
    gas_estimator: GasEstimator,
    protocol_handlers: HashMap<Protocol, Box<dyn ProtocolHandler>>,
}

impl<P: Provider> TaskExecutor<P> {
    pub async fn execute(&self, task: &Task) -> Result<TaskResult, ExecutorError> {
        let handler = self.protocol_handlers
            .get(&task.protocol)
            .ok_or(ExecutorError::UnsupportedProtocol)?;

        let gas_estimate = self.gas_estimator
            .estimate(task, handler).await?;

        if gas_estimate > task.gas_estimate * 3 / 2 {
            return Err(ExecutorError::GasExceeded);
        }

        let tx = handler.build_transaction(task, &gas_estimate).await?;
        let pending = self.provider.send_transaction(tx).await?;
        let receipt = pending.get_receipt().await?;

        if receipt.status() {
            Ok(TaskResult::Success {
                tx_hash: receipt.transaction_hash,
                gas_used: receipt.gas_used,
                block_number: receipt.block_number,
            })
        } else {
            Err(ExecutorError::ExecutionReverted(receipt))
        }
    }
}

#[async_trait]
pub trait ProtocolHandler: Send + Sync {
    async fn build_transaction(
        &self, task: &Task, gas: &GasEstimate
    ) -> Result<TransactionRequest, HandlerError>;
}

pub struct AaveHandler { pool_address: Address }
pub struct CompoundHandler { comet_address: Address }
pub struct VaultHandler { vault_address: Address }`}
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="staking">
          <Card className="mt-4">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Activity className="h-4 w-4" /> Stake-Weighted Selection
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CodeBlock
                language="rust"
                code={`use keeper_types::Operator;

pub struct StakeWeightedSelector {
    operators: Vec<Operator>,
    rng: SmallRng,
}

impl StakeWeightedSelector {
    pub fn select_operator(
        &mut self,
        protocol: Protocol,
        task_type: TaskType,
    ) -> Option<&Operator> {
        let eligible: Vec<&Operator> = self.operators.iter()
            .filter(|op| op.status == OperatorStatus::Active)
            .filter(|op| op.supported_protocols.contains(&protocol))
            .filter(|op| op.supported_task_types.contains(&task_type))
            .filter(|op| op.sla_score >= 85.0)
            .collect();

        if eligible.is_empty() {
            return None;
        }

        let total_stake: f64 = eligible.iter()
            .map(|op| op.stake).sum();
        let mut threshold = self.rng.gen::<f64>() * total_stake;

        for operator in eligible {
            threshold -= operator.stake;
            if threshold <= 0.0 {
                return Some(operator);
            }
        }
        eligible.last()
    }
}`}
              />

              <div className="mt-4 rounded-md bg-muted/50 p-4">
                <h4 className="text-sm font-medium mb-2">Selection Algorithm</h4>
                <ul className="space-y-1 text-xs text-muted-foreground">
                  <li>• Operators filtered by: status, protocol support, task type, min SLA</li>
                  <li>• Weighted random selection proportional to restaked ETH</li>
                  <li>• Higher stake = higher probability of task assignment</li>
                  <li>• SLA score acts as a multiplier (min 85% required)</li>
                  <li>• Selection is deterministic given same RNG seed for auditability</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="fallback">
          <Card className="mt-4">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Shield className="h-4 w-4" /> Redundant Execution & Fallback
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CodeBlock
                language="rust"
                code={`pub struct FallbackManager {
    max_fallbacks: u32,
    timeout: Duration,
}

impl FallbackManager {
    pub async fn execute_with_fallback(
        &self,
        task: &Task,
        selector: &mut StakeWeightedSelector,
        executor: &TaskExecutor<impl Provider>,
    ) -> Result<TaskResult, FallbackError> {
        let mut attempts = 0;

        loop {
            let operator = selector.select_operator(
                task.protocol, task.type
            ).ok_or(FallbackError::NoEligibleOperators)?;

            match tokio::time::timeout(
                self.timeout,
                executor.execute(task)
            ).await {
                Ok(Ok(result)) => return Ok(result),
                Ok(Err(e)) => {
                    attempts += 1;
                    self.report_failure(
                        &operator.id, task, &e
                    ).await;
                    if attempts >= self.max_fallbacks {
                        return Err(FallbackError::MaxRetriesExceeded);
                    }
                }
                Err(_) => {
                    attempts += 1;
                    self.report_timeout(
                        &operator.id, task
                    ).await;
                    if attempts >= self.max_fallbacks {
                        return Err(FallbackError::MaxRetriesExceeded);
                    }
                }
            }
        }
    }
}`}
              />

              <div className="mt-4 grid gap-4 md:grid-cols-2">
                <div className="rounded-md border p-4">
                  <h4 className="text-sm font-medium mb-2">Redundancy Model</h4>
                  <ul className="space-y-1 text-xs text-muted-foreground">
                    <li>• Primary operator selected via stake-weighted algorithm</li>
                    <li>• On failure/timeout, next operator selected from pool</li>
                    <li>• Max 3 fallback attempts per task</li>
                    <li>• Each failed operator receives SLA penalty</li>
                  </ul>
                </div>
                <div className="rounded-md border p-4">
                  <h4 className="text-sm font-medium mb-2">Timeout Thresholds</h4>
                  <ul className="space-y-1 text-xs text-muted-foreground">
                    <li>• Liquidation: 30 seconds (time-critical)</li>
                    <li>• Rebalancing: 5 minutes</li>
                    <li>• Yield harvest: 10 minutes</li>
                    <li>• Order execution: per-order deadline</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
