import { useMemo } from 'react'
import {
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
} from 'recharts'
import { useMarketStore, generateCandlestickData } from '@/stores/trading-store'
import { formatPrice } from '@/lib/utils'
import { cn } from '@/lib/utils'

const TIMEFRAMES = ['1m', '5m', '15m', '1h', '4h', '1D']

function CustomTooltip({ active, payload }: { active?: boolean; payload?: Array<{ payload: { open: number; high: number; low: number; close: number; volume: number; time: number } }> }) {
  if (!active || !payload?.length) return null
  const d = payload[0].payload
  return (
    <div className="rounded-md border border-border bg-card p-2 text-xs shadow-lg">
      <div className="flex justify-between gap-4">
        <span className="text-muted-foreground">O</span>
        <span>{formatPrice(d.open)}</span>
      </div>
      <div className="flex justify-between gap-4">
        <span className="text-muted-foreground">H</span>
        <span>{formatPrice(d.high)}</span>
      </div>
      <div className="flex justify-between gap-4">
        <span className="text-muted-foreground">L</span>
        <span>{formatPrice(d.low)}</span>
      </div>
      <div className="flex justify-between gap-4">
        <span className="text-muted-foreground">C</span>
        <span className={d.close >= d.open ? 'text-emerald-500' : 'text-red-500'}>{formatPrice(d.close)}</span>
      </div>
    </div>
  )
}

export default function PriceChart() {
  const { markets, selectedMarketId } = useMarketStore()
  const market = markets.find((m) => m.id === selectedMarketId) ?? markets[0]

  const chartData = useMemo(() => {
    const candles = generateCandlestickData(market.markPrice, 120)
    return candles.map((c) => ({
      ...c,
      timeLabel: new Date(c.time * 1000).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      isUp: c.close >= c.open,
      barColor: c.close >= c.open ? 'rgba(16, 185, 129, 0.3)' : 'rgba(239, 68, 68, 0.3)',
    }))
  }, [market.markPrice])

  const minPrice = Math.min(...chartData.map((d) => d.low))
  const maxPrice = Math.max(...chartData.map((d) => d.high))
  const padding = (maxPrice - minPrice) * 0.1

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-3 py-2 border-b border-border">
        <div className="flex items-center gap-3">
          <span className="text-sm font-medium text-foreground">{market.pair}</span>
          <span className="text-lg font-bold text-foreground">{formatPrice(market.markPrice)}</span>
        </div>
        <div className="flex gap-1">
          {TIMEFRAMES.map((tf) => (
            <button
              key={tf}
              className={cn(
                'px-2 py-0.5 text-xs rounded transition-colors',
                tf === '5m'
                  ? 'bg-accent text-foreground'
                  : 'text-muted-foreground hover:text-foreground'
              )}
            >
              {tf}
            </button>
          ))}
        </div>
      </div>
      <div className="flex-1 min-h-0">
        <ResponsiveContainer width="100%" height="70%">
          <ComposedChart data={chartData} margin={{ top: 8, right: 8, bottom: 0, left: 8 }}>
            <XAxis dataKey="timeLabel" tick={{ fontSize: 10, fill: 'hsl(215 20% 55%)' }} axisLine={false} tickLine={false} interval={19} />
            <YAxis domain={[minPrice - padding, maxPrice + padding]} tick={{ fontSize: 10, fill: 'hsl(215 20% 55%)' }} axisLine={false} tickLine={false} orientation="right" tickFormatter={(v: number) => formatPrice(v)} width={80} />
            <Tooltip content={<CustomTooltip />} />
            <ReferenceLine y={market.markPrice} stroke="hsl(215 20% 55%)" strokeDasharray="3 3" />
            <Bar dataKey="volume" fill="rgba(100, 116, 139, 0.2)" yAxisId="volume" />
            <Line type="monotone" dataKey="close" stroke="hsl(210 40% 98%)" strokeWidth={1.5} dot={false} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
