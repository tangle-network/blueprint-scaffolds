import { useAccountStore, usePositionStore } from '@/stores/trading-store'
import { cn, formatUsdFull, formatPercent } from '@/lib/utils'
import { Wallet } from 'lucide-react'

export default function AccountHeader() {
  const { accountSummary } = useAccountStore()
  const { positions } = usePositionStore()
  const totalPnl = positions.reduce((sum, p) => sum + p.unrealizedPnl, 0)
  const isPositive = totalPnl >= 0

  return (
    <div className="flex items-center justify-between h-14 px-4 border-b border-border bg-card">
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2">
          <Wallet className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-medium text-foreground">
            {formatUsdFull(accountSummary.totalEquity)}
          </span>
          <span className="text-xs text-muted-foreground">Equity</span>
        </div>
        <div className="h-4 w-px bg-border" />
        <div>
          <span className={cn('text-sm font-medium', isPositive ? 'text-emerald-500' : 'text-red-500')}>
            {isPositive ? '+' : ''}{formatUsdFull(totalPnl)}
          </span>
          <span className="text-xs text-muted-foreground ml-1">Unrealized PnL</span>
        </div>
        <div className="h-4 w-px bg-border" />
        <div>
          <span className="text-sm font-medium text-foreground">
            {formatUsdFull(accountSummary.availableMargin)}
          </span>
          <span className="text-xs text-muted-foreground ml-1">Available</span>
        </div>
        <div className="h-4 w-px bg-border" />
        <div>
          <span className="text-sm font-medium text-foreground">
            {accountSummary.marginRatio.toFixed(1)}%
          </span>
          <span className="text-xs text-muted-foreground ml-1">Margin Ratio</span>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1.5">
          <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-xs text-muted-foreground">Arbitrum</span>
        </div>
        <div className="h-4 w-px bg-border" />
        <span className="text-xs text-muted-foreground font-mono">0x7a3f...b2c4</span>
      </div>
    </div>
  )
}
