import React, { useState, useMemo } from 'react'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select } from '@/components/ui/select'
import { cn, formatPrice, generateId } from '@/lib/utils'
import { useMarketStore, usePositionStore } from '@/stores/trading-store'
import type { OrderSide, OrderType, MarginMode, Order } from '@/types'

const ORDER_TYPES: { value: OrderType; label: string }[] = [
  { value: 'market', label: 'Market' },
  { value: 'limit', label: 'Limit' },
  { value: 'stop_market', label: 'Stop Market' },
  { value: 'stop_limit', label: 'Stop Limit' },
  { value: 'take_profit', label: 'Take Profit' },
  { value: 'take_profit_limit', label: 'TP Limit' },
]

const LEVERAGE_MARKS = [1, 2, 3, 5, 10, 15, 20, 25, 50]

export default function OrderForm() {
  const { markets, selectedMarketId } = useMarketStore()
  const addOrder = usePositionStore((s) => s.addOrder)
  const market = markets.find((m) => m.id === selectedMarketId) ?? markets[0]

  const [side, setSide] = useState<OrderSide>('long')
  const [orderType, setOrderType] = useState<OrderType>('market')
  const [price, setPrice] = useState('')
  const [triggerPrice, setTriggerPrice] = useState('')
  const [sizeUsd, setSizeUsd] = useState('')
  const [leverage, setLeverage] = useState(10)
  const [marginMode, setMarginMode] = useState<MarginMode>('cross')

  const sizeToken = useMemo(() => {
    const usd = parseFloat(sizeUsd) || 0
    const p = orderType === 'market' ? market.markPrice : parseFloat(price) || market.markPrice
    return p > 0 ? usd / p : 0
  }, [sizeUsd, price, orderType, market.markPrice])

  const marginRequired = useMemo(() => {
    return (parseFloat(sizeUsd) || 0) / leverage
  }, [sizeUsd, leverage])

  const needsPrice = orderType !== 'market' && orderType !== 'stop_market'
  const needsTrigger = orderType.startsWith('stop') || orderType.startsWith('take_profit')

  const handleSubmit = () => {
    if (!sizeUsd || parseFloat(sizeUsd) <= 0) return

    const order: Order = {
      id: generateId(),
      marketId: market.id,
      pair: market.pair,
      side,
      type: orderType,
      price: needsPrice ? parseFloat(price) : undefined,
      triggerPrice: needsTrigger ? parseFloat(triggerPrice) : undefined,
      sizeUsd: parseFloat(sizeUsd),
      sizeToken,
      leverage,
      marginMode,
      status: 'open',
      createdAt: new Date().toISOString(),
      reduceOnly: false,
    }
    addOrder(order)
    setSizeUsd('')
    setPrice('')
    setTriggerPrice('')
  }

  return (
    <div className="flex flex-col gap-3 p-4">
      <Tabs defaultValue="long" onValueChange={(v) => setSide(v as OrderSide)}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger
            value="long"
            className={cn(
              'font-semibold data-[state=active]:bg-emerald-600 data-[state=active]:text-white'
            )}
          >
            Long
          </TabsTrigger>
          <TabsTrigger
            value="short"
            className={cn(
              'font-semibold data-[state=active]:bg-red-600 data-[state=active]:text-white'
            )}
          >
            Short
          </TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="space-y-3">
        <div className="flex gap-2">
          <Select
            value={orderType}
            onChange={(e) => setOrderType(e.target.value as OrderType)}
            className="text-xs"
          >
            {ORDER_TYPES.map((t) => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </Select>
        </div>

        {needsPrice && (
          <div className="space-y-1">
            <label className="text-xs text-muted-foreground">Price (USD)</label>
            <Input
              type="number"
              placeholder={formatPrice(market.markPrice)}
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              className="h-9 text-sm"
            />
          </div>
        )}

        {needsTrigger && (
          <div className="space-y-1">
            <label className="text-xs text-muted-foreground">Trigger Price (USD)</label>
            <Input
              type="number"
              placeholder={formatPrice(market.markPrice)}
              value={triggerPrice}
              onChange={(e) => setTriggerPrice(e.target.value)}
              className="h-9 text-sm"
            />
          </div>
        )}

        <div className="space-y-1">
          <label className="text-xs text-muted-foreground">Size (USD)</label>
          <Input
            type="number"
            placeholder="0.00"
            value={sizeUsd}
            onChange={(e) => setSizeUsd(e.target.value)}
            className="h-9 text-sm"
          />
          <p className="text-xs text-muted-foreground">
            ≈ {sizeToken.toFixed(4)} {market.baseToken}
          </p>
        </div>

        <div className="space-y-1">
          <div className="flex items-center justify-between">
            <label className="text-xs text-muted-foreground">Leverage</label>
            <span className="text-xs font-medium text-foreground">{leverage}x</span>
          </div>
          <input
            type="range"
            min={1}
            max={market.maxLeverage}
            value={leverage}
            onChange={(e) => setLeverage(parseInt(e.target.value))}
            className="w-full h-1.5 rounded-full appearance-none cursor-pointer bg-secondary accent-primary"
          />
          <div className="flex justify-between">
            {LEVERAGE_MARKS.filter((m) => m <= market.maxLeverage).map((mark) => (
              <button
                key={mark}
                onClick={() => setLeverage(mark)}
                className={cn(
                  'text-xs px-1.5 py-0.5 rounded transition-colors',
                  leverage === mark
                    ? 'bg-primary/20 text-foreground font-medium'
                    : 'text-muted-foreground hover:text-foreground'
                )}
              >
                {mark}x
              </button>
            ))}
          </div>
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => setMarginMode('cross')}
            className={cn(
              'flex-1 text-xs py-1.5 rounded border transition-colors',
              marginMode === 'cross'
                ? 'border-primary bg-primary/10 text-foreground'
                : 'border-border text-muted-foreground hover:text-foreground'
            )}
          >
            Cross
          </button>
          <button
            onClick={() => setMarginMode('isolated')}
            className={cn(
              'flex-1 text-xs py-1.5 rounded border transition-colors',
              marginMode === 'isolated'
                ? 'border-primary bg-primary/10 text-foreground'
                : 'border-border text-muted-foreground hover:text-foreground'
            )}
          >
            Isolated
          </button>
        </div>

        <div className="space-y-1 rounded-md bg-muted/50 p-3 text-xs">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Margin Required</span>
            <span>{formatPrice(marginRequired)} USD</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Est. Liq. Price</span>
            <span>
              {side === 'long'
                ? formatPrice(market.markPrice * (1 - 1 / leverage + market.maintenanceMargin / 100))
                : formatPrice(market.markPrice * (1 + 1 / leverage - market.maintenanceMargin / 100))}
            </span>
          </div>
        </div>

        <Button
          onClick={handleSubmit}
          className={cn(
            'w-full h-10 font-semibold',
            side === 'long'
              ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
              : 'bg-red-600 hover:bg-red-700 text-white'
          )}
        >
          {side === 'long' ? 'Buy/Long' : 'Sell/Short'} {market.baseToken}
        </Button>
      </div>
    </div>
  )
}
