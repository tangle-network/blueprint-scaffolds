import { useMarketStore } from '@/stores/trading-store'
import { formatPrice, formatUsd, formatFundingRate, formatCountdown } from '@/lib/utils'
import { Info } from 'lucide-react'

export default function MarketInfo() {
  const { markets, selectedMarketId } = useMarketStore()
  const market = markets.find((m) => m.id === selectedMarketId) ?? markets[0]
  const spread = Math.abs(market.markPrice - market.indexPrice)
  const spreadBps = (spread / market.indexPrice) * 10000
  const fundingPositive = market.fundingRate >= 0

  return (
    <div className="space-y-3 p-3">
      <div className="flex items-center gap-2">
        <Info className="h-4 w-4 text-muted-foreground" />
        <span className="text-sm font-medium text-foreground">{market.pair} Market Info</span>
      </div>

      <div className="grid grid-cols-2 gap-2 text-xs">
        <div className="space-y-0.5">
          <span className="text-muted-foreground">Mark Price</span>
          <p className="font-medium text-foreground">{formatPrice(market.markPrice)}</p>
        </div>
        <div className="space-y-0.5">
          <span className="text-muted-foreground">Index Price</span>
          <p className="font-medium text-foreground">{formatPrice(market.indexPrice)}</p>
        </div>
        <div className="space-y-0.5">
          <span className="text-muted-foreground">Spread</span>
          <p className="font-medium text-foreground">{spreadBps.toFixed(2)} bps</p>
        </div>
        <div className="space-y-0.5">
          <span className="text-muted-foreground">24h Volume</span>
          <p className="font-medium text-foreground">{formatUsd(market.volume24h)}</p>
        </div>
        <div className="space-y-0.5">
          <span className="text-muted-foreground">Open Interest</span>
          <p className="font-medium text-foreground">{formatUsd(market.openInterest)}</p>
        </div>
        <div className="space-y-0.5">
          <span className="text-muted-foreground">Max Leverage</span>
          <p className="font-medium text-foreground">{market.maxLeverage}x</p>
        </div>
        <div className="space-y-0.5">
          <span className="text-muted-foreground">Funding Rate</span>
          <p className={`font-medium ${fundingPositive ? 'text-emerald-500' : 'text-red-500'}`}>
            {formatFundingRate(market.fundingRate)}
          </p>
        </div>
        <div className="space-y-0.5">
          <span className="text-muted-foreground">Next Funding</span>
          <p className="font-medium text-foreground">{formatCountdown(market.fundingCountdown)}</p>
        </div>
        <div className="space-y-0.5">
          <span className="text-muted-foreground">Min Margin</span>
          <p className="font-medium text-foreground">{market.minMargin}%</p>
        </div>
        <div className="space-y-0.5">
          <span className="text-muted-foreground">Maintenance</span>
          <p className="font-medium text-foreground">{market.maintenanceMargin}%</p>
        </div>
      </div>
    </div>
  )
}
