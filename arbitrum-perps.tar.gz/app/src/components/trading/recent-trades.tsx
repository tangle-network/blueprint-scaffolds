import { useMemo } from 'react'
import { useMarketStore, usePositionStore, generateRecentTrades } from '@/stores/trading-store'
import { cn, formatPrice, formatUsd, timeAgo } from '@/lib/utils'

export default function RecentTrades() {
  const { markets, selectedMarketId } = useMarketStore()
  const market = markets.find((m) => m.id === selectedMarketId) ?? markets[0]
  const trades = useMemo(() => generateRecentTrades(market.id, market.markPrice), [market.id, market.markPrice])

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-3 px-3 py-1.5 text-xs font-medium text-muted-foreground border-b border-border bg-muted/20">
        <div className="w-16">Price</div>
        <div className="w-16 text-right">Size</div>
        <div className="w-16 text-right">Time</div>
      </div>
      <div className="flex-1 overflow-y-auto">
        {trades.map((trade) => (
          <div
            key={trade.id}
            className="flex items-center gap-3 px-3 py-1 text-xs border-b border-border/50 hover:bg-muted/20 transition-colors"
          >
            <div className={cn('w-16 font-mono', trade.side === 'long' ? 'text-emerald-500' : 'text-red-500')}>
              {formatPrice(trade.price)}
            </div>
            <div className="w-16 text-right text-muted-foreground">
              {formatUsd(trade.sizeUsd)}
            </div>
            <div className="w-16 text-right text-muted-foreground">
              {timeAgo(trade.timestamp)}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
