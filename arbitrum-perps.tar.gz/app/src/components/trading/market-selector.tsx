import { useMarketStore } from '@/stores/trading-store'
import { cn, formatPrice, formatUsd, formatPercent } from '@/lib/utils'
import { TrendingUp, TrendingDown } from 'lucide-react'
import { useNavigate } from 'react-router-dom'

export default function MarketSelector() {
  const { markets, selectedMarketId, setSelectedMarket } = useMarketStore()
  const navigate = useNavigate()

  const handleSelect = (marketId: string) => {
    setSelectedMarket(marketId)
    const market = markets.find((m) => m.id === marketId)
    if (market) {
      navigate(`/trade/${market.baseToken}`)
    }
  }

  return (
    <div className="border-b border-border">
      <div className="flex items-center gap-1 px-2 py-1 overflow-x-auto scrollbar-hide">
        {markets.map((market) => {
          const isSelected = market.id === selectedMarketId
          const priceChange = ((market.markPrice - market.indexPrice) / market.indexPrice) * 100
          const isPositive = priceChange >= 0

          return (
            <button
              key={market.id}
              onClick={() => handleSelect(market.id)}
              className={cn(
                'flex items-center gap-2 px-3 py-2 rounded-md text-xs whitespace-nowrap transition-colors',
                isSelected
                  ? 'bg-accent text-foreground'
                  : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
              )}
            >
              <span className="font-medium">{market.pair}</span>
              <span className="text-foreground">{formatPrice(market.markPrice)}</span>
              <span className={cn('flex items-center gap-0.5', isPositive ? 'text-emerald-500' : 'text-red-500')}>
                {isPositive ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                {formatPercent(priceChange)}
              </span>
            </button>
          )
        })}
      </div>
    </div>
  )
}
