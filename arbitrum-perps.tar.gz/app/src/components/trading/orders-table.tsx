import { usePositionStore } from '@/stores/trading-store'
import { cn, formatPrice, formatUsd, timeAgo } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { X } from 'lucide-react'
import type { Order } from '@/types'

function OrderRow({ order, onCancel }: { order: Order; onCancel: (id: string) => void }) {
  return (
    <div className="flex items-center gap-3 px-3 py-2 text-xs border-b border-border hover:bg-muted/30 transition-colors">
      <div className="w-20">
        <span className="font-medium text-foreground">{order.pair}</span>
      </div>
      <Badge
        variant="outline"
        className={cn(
          'text-xs px-1.5 py-0',
          order.side === 'long'
            ? 'border-emerald-600 text-emerald-500'
            : 'border-red-600 text-red-500'
        )}
      >
        {order.side.toUpperCase()}
      </Badge>
      <div className="w-24">
        <Badge variant="secondary" className="text-xs px-1.5 py-0">
          {order.type.replace('_', ' ').toUpperCase()}
        </Badge>
      </div>
      <div className="w-24 text-right">
        <span className="text-foreground">
          {order.price ? formatPrice(order.price) : order.triggerPrice ? formatPrice(order.triggerPrice) : '—'}
        </span>
      </div>
      <div className="w-24 text-right">
        <span className="text-muted-foreground">{formatUsd(order.sizeUsd)}</span>
      </div>
      <div className="w-16 text-right">
        <span className="text-muted-foreground">{order.leverage}x</span>
      </div>
      <div className="w-20 text-right">
        <span className="text-muted-foreground">{timeAgo(order.createdAt)}</span>
      </div>
      {order.reduceOnly && (
        <Badge variant="outline" className="text-xs px-1.5 py-0 border-yellow-600 text-yellow-500">
          RO
        </Badge>
      )}
      <div className="w-12 text-right">
        <Button
          variant="ghost"
          size="icon"
          className="h-6 w-6 text-muted-foreground hover:text-red-500"
          onClick={() => onCancel(order.id)}
        >
          <X className="h-3 w-3" />
        </Button>
      </div>
    </div>
  )
}

export default function OrdersTable() {
  const { orders, cancelOrder } = usePositionStore()

  if (orders.length === 0) {
    return (
      <div className="flex items-center justify-center py-8 text-sm text-muted-foreground">
        No open orders
      </div>
    )
  }

  return (
    <div>
      <div className="flex items-center gap-3 px-3 py-1.5 text-xs font-medium text-muted-foreground border-b border-border bg-muted/20">
        <div className="w-20">Market</div>
        <div className="w-14">Side</div>
        <div className="w-24">Type</div>
        <div className="w-24 text-right">Price</div>
        <div className="w-24 text-right">Size</div>
        <div className="w-16 text-right">Lev.</div>
        <div className="w-20 text-right">Created</div>
        <div className="w-10" />
        <div className="w-12" />
      </div>
      {orders.map((order) => (
        <OrderRow key={order.id} order={order} onCancel={cancelOrder} />
      ))}
    </div>
  )
}
