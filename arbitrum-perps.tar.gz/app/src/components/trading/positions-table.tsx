import { usePositionStore } from '@/stores/trading-store'
import { cn, formatPrice, formatUsd, formatPercent, timeAgo } from '@/lib/utils'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { X } from 'lucide-react'
import type { Position } from '@/types'

function PositionRow({ position, onClose }: { position: Position; onClose: (id: string) => void }) {
  const isPositive = position.unrealizedPnl >= 0
  const pnlPercent = ((position.unrealizedPnl / position.marginUsed) * 100)

  return (
    <div className="flex items-center gap-3 px-3 py-2 text-xs border-b border-border hover:bg-muted/30 transition-colors">
      <div className="w-20">
        <span className="font-medium text-foreground">{position.pair}</span>
      </div>
      <Badge
        variant="outline"
        className={cn(
          'text-xs px-1.5 py-0',
          position.side === 'long'
            ? 'border-emerald-600 text-emerald-500'
            : 'border-red-600 text-red-500'
        )}
      >
        {position.side.toUpperCase()} {position.leverage}x
      </Badge>
      <div className="w-24 text-right">
        <span className="text-muted-foreground">{formatUsd(position.sizeUsd)}</span>
      </div>
      <div className="w-24 text-right">
        <span className="text-foreground">{formatPrice(position.entryPrice)}</span>
      </div>
      <div className="w-24 text-right">
        <span className="text-foreground">{formatPrice(position.markPrice)}</span>
      </div>
      <div className="w-24 text-right">
        <span className="text-muted-foreground">{formatPrice(position.liquidationPrice)}</span>
      </div>
      <div className="w-24 text-right">
        <span className={cn('font-medium', isPositive ? 'text-emerald-500' : 'text-red-500')}>
          {isPositive ? '+' : ''}{formatUsd(position.unrealizedPnl)}
        </span>
        <span className={cn('ml-1', isPositive ? 'text-emerald-500/70' : 'text-red-500/70')}>
          ({formatPercent(pnlPercent)})
        </span>
      </div>
      <div className="w-16 text-right">
        <Badge variant="outline" className="text-xs px-1.5 py-0">
          {position.marginMode}
        </Badge>
      </div>
      <div className="w-12 text-right">
        <Button
          variant="ghost"
          size="icon"
          className="h-6 w-6 text-muted-foreground hover:text-red-500"
          onClick={() => onClose(position.id)}
        >
          <X className="h-3 w-3" />
        </Button>
      </div>
    </div>
  )
}

export default function PositionsTable() {
  const { positions, closePosition } = usePositionStore()

  if (positions.length === 0) {
    return (
      <div className="flex items-center justify-center py-8 text-sm text-muted-foreground">
        No open positions
      </div>
    )
  }

  return (
    <div>
      <div className="flex items-center gap-3 px-3 py-1.5 text-xs font-medium text-muted-foreground border-b border-border bg-muted/20">
        <div className="w-20">Market</div>
        <div className="w-14">Side</div>
        <div className="w-24 text-right">Size</div>
        <div className="w-24 text-right">Entry</div>
        <div className="w-24 text-right">Mark</div>
        <div className="w-24 text-right">Liq. Price</div>
        <div className="w-24 text-right">PnL</div>
        <div className="w-16 text-right">Margin</div>
        <div className="w-12" />
      </div>
      {positions.map((pos) => (
        <PositionRow key={pos.id} position={pos} onClose={closePosition} />
      ))}
    </div>
  )
}
