import type { Task, Operator, NetworkStats, GasCoverage, SLACommitment } from './types'
import { generateId } from './utils'

const PROTOCOLS = ['aave', 'compound', 'vault'] as const
const TASK_TYPES = ['liquidation', 'rebalancing', 'yield_harvest', 'order_execution'] as const
const STATUSES = ['pending', 'active', 'completed', 'failed', 'cancelled'] as const

function randomFrom<T>(arr: readonly T[]): T {
  return arr[Math.floor(Math.random() * arr.length)]
}

function randomAddress(): string {
  return '0x' + Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join('')
}

function randomDate(daysBack: number): Date {
  const d = new Date()
  d.setMinutes(d.getMinutes() - Math.floor(Math.random() * daysBack * 24 * 60))
  return d
}

const TASK_DESCRIPTIONS: Record<string, string[]> = {
  liquidation: [
    'Liquidate undercollateralized position on Aave V3',
    'Liquidate unhealthy borrow on Compound V3',
    'Cascade liquidation for vault position below threshold',
  ],
  rebalancing: [
    'Rebalance ETH/USDC pool to target 60/40 ratio',
    'Adjust leverage on Gearbox vault to optimal level',
    'Rebalance yield strategy allocation across protocols',
  ],
  yield_harvest: [
    'Harvest accrued rewards from Aave lending pool',
    'Claim COMP rewards and reinvest into strategy',
    'Harvest yield from auto-compounding vault',
  ],
  order_execution: [
    'Execute limit order: Swap 5 ETH for USDC at $3,200',
    'Execute TWAP order: Sell 10,000 DAI over 4 hours',
    'Execute DCA order: Buy 0.5 ETH weekly',
  ],
}

export function generateTasks(count: number): Task[] {
  return Array.from({ length: count }, () => {
    const type = randomFrom(TASK_TYPES)
    const protocol = randomFrom(PROTOCOLS)
    const status = randomFrom(STATUSES)
    const slaDeadline = new Date()
    slaDeadline.setHours(slaDeadline.getHours() + Math.floor(Math.random() * 24) + 1)
    return {
      id: `task-${generateId()}`,
      type,
      status,
      protocol,
      description: randomFrom(TASK_DESCRIPTIONS[type]),
      targetAddress: randomAddress(),
      reward: 0.001 + Math.random() * 0.05,
      gasEstimate: 50000 + Math.floor(Math.random() * 300000),
      priority: Math.floor(Math.random() * 100),
      slaDeadline,
      createdAt: randomDate(7),
      executedAt: status === 'completed' || status === 'failed' ? randomDate(2) : undefined,
      assignedOperator: status !== 'pending' ? `op-${generateId()}` : undefined,
      fallbackCount: Math.floor(Math.random() * 3),
      maxFallbacks: 3,
      params: {},
    }
  })
}

export function generateOperators(count: number): Operator[] {
  return Array.from({ length: count }, () => {
    const stake = 10 + Math.random() * 500
    const completed = 100 + Math.floor(Math.random() * 5000)
    const failed = Math.floor(Math.random() * completed * 0.05)
    return {
      id: `op-${generateId()}`,
      address: randomAddress(),
      stake,
      status: Math.random() > 0.1 ? 'active' : randomFrom(['inactive', 'slashed'] as const),
      tasksCompleted: completed,
      tasksFailed: failed,
      successRate: (completed / (completed + failed)) * 100,
      avgExecutionTime: 2 + Math.random() * 30,
      totalRewardsEarned: completed * 0.005 + Math.random() * 5,
      registeredAt: randomDate(90),
      lastActiveAt: randomDate(1),
      delegatorCount: Math.floor(Math.random() * 50),
      supportedProtocols: PROTOCOLS.slice(0, 1 + Math.floor(Math.random() * PROTOCOLS.length)),
      supportedTaskTypes: TASK_TYPES.slice(0, 1 + Math.floor(Math.random() * TASK_TYPES.length)),
      slaScore: 85 + Math.random() * 15,
    }
  })
}

export function generateNetworkStats(tasks: Task[], operators: Operator[]): NetworkStats {
  const activeOps = operators.filter(o => o.status === 'active')
  const completed = tasks.filter(t => t.status === 'completed')
  const tasksByType = {} as Record<string, number>
  const tasksByProtocol = {} as Record<string, number>
  for (const t of TASK_TYPES) tasksByType[t] = tasks.filter(ta => ta.type === t).length
  for (const p of PROTOCOLS) tasksByProtocol[p] = tasks.filter(ta => ta.protocol === p).length

  return {
    totalOperators: operators.length,
    activeOperators: activeOps.length,
    totalStake: operators.reduce((s, o) => s + o.stake, 0),
    totalTasksCompleted: completed.length,
    tasksLast24h: Math.floor(completed.length * 0.3),
    avgGasCoverage: 85 + Math.random() * 14,
    slaComplianceRate: 94 + Math.random() * 5.5,
    totalRewardsDistributed: completed.reduce((s, t) => s + t.reward, 0),
    tasksByType: tasksByType as NetworkStats['tasksByType'],
    tasksByProtocol: tasksByProtocol as NetworkStats['tasksByProtocol'],
  }
}

export function generateGasCoverage(): GasCoverage {
  const base = 20000 + Math.floor(Math.random() * 80000)
  const priority = 1 + Math.floor(Math.random() * 5)
  return {
    baseGas: base,
    priorityFee: priority,
    maxCoverage: base * 1.5,
    operatorCoverage: base * (0.7 + Math.random() * 0.3),
  }
}

export function generateSLACommitments(tasks: Task[], operators: Operator[]): SLACommitment[] {
  return tasks.slice(0, 20).map(t => ({
    taskId: t.id,
    operatorId: t.assignedOperator || operators[Math.floor(Math.random() * operators.length)].id,
    deadline: t.slaDeadline,
    penaltyRate: 0.5 + Math.random() * 2,
    completed: t.status === 'completed',
    onTime: t.status === 'completed' ? Math.random() > 0.05 : false,
  }))
}

export const MOCK_TASKS = generateTasks(50)
export const MOCK_OPERATORS = generateOperators(15)
export const MOCK_NETWORK_STATS = generateNetworkStats(MOCK_TASKS, MOCK_OPERATORS)
export const MOCK_GAS_COVERAGE = generateGasCoverage()
export const MOCK_SLA_COMMITMENTS = generateSLACommitments(MOCK_TASKS, MOCK_OPERATORS)

export const TASK_TYPE_LABELS: Record<string, string> = {
  liquidation: 'Liquidation',
  rebalancing: 'Rebalancing',
  yield_harvest: 'Yield Harvest',
  order_execution: 'Order Execution',
}

export const PROTOCOL_LABELS: Record<string, string> = {
  aave: 'Aave',
  compound: 'Compound',
  vault: 'Vault',
}

export const STATUS_COLORS: Record<string, string> = {
  pending: 'bg-yellow-500/20 text-yellow-400',
  active: 'bg-blue-500/20 text-blue-400',
  completed: 'bg-green-500/20 text-green-400',
  failed: 'bg-red-500/20 text-red-400',
  cancelled: 'bg-gray-500/20 text-gray-400',
}

export const TASK_TYPE_COLORS: Record<string, string> = {
  liquidation: 'bg-red-500/20 text-red-400',
  rebalancing: 'bg-blue-500/20 text-blue-400',
  yield_harvest: 'bg-green-500/20 text-green-400',
  order_execution: 'bg-purple-500/20 text-purple-400',
}
