export type TaskType = 'liquidation' | 'rebalancing' | 'yield_harvest' | 'order_execution'
export type TaskStatus = 'pending' | 'active' | 'completed' | 'failed' | 'cancelled'
export type OperatorStatus = 'active' | 'inactive' | 'slashed' | 'deregistered'
export type Protocol = 'aave' | 'compound' | 'vault'

export interface Task {
  id: string
  type: TaskType
  status: TaskStatus
  protocol: Protocol
  description: string
  targetAddress: string
  reward: number
  gasEstimate: number
  priority: number
  slaDeadline: Date
  createdAt: Date
  executedAt?: Date
  assignedOperator?: string
  fallbackCount: number
  maxFallbacks: number
  params: Record<string, unknown>
}

export interface Operator {
  id: string
  address: string
  stake: number
  status: OperatorStatus
  tasksCompleted: number
  tasksFailed: number
  successRate: number
  avgExecutionTime: number
  totalRewardsEarned: number
  registeredAt: Date
  lastActiveAt: Date
  delegatorCount: number
  supportedProtocols: Protocol[]
  supportedTaskTypes: TaskType[]
  slaScore: number
}

export interface NetworkStats {
  totalOperators: number
  activeOperators: number
  totalStake: number
  totalTasksCompleted: number
  tasksLast24h: number
  avgGasCoverage: number
  slaComplianceRate: number
  totalRewardsDistributed: number
  tasksByType: Record<TaskType, number>
  tasksByProtocol: Record<Protocol, number>
}

export interface GasCoverage {
  baseGas: number
  priorityFee: number
  maxCoverage: number
  operatorCoverage: number
}

export interface SLACommitment {
  taskId: string
  operatorId: string
  deadline: Date
  penaltyRate: number
  completed: boolean
  onTime: boolean
}
