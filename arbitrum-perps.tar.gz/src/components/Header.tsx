import React from 'react'
import { useTradingStore } from '../store/tradingStore'
import { useWallet } from '../hooks'
import { formatAddress, formatUsd } from '../utils'
import { MARKETS } from '../types'

export const Header: React.FC = () => {
  const activeMarket = useTradingStore((s) => s.activeMarket)
  const markPrice = useTradingStore((s) => s.markPrice)
  const fundingRates = useTradingStore((s) => s.fundingRates)
  const setActiveMarket = useTradingStore((s) => s.setActiveMarket)
  const accountSummary = useTradingStore((s) => s.accountSummary)
  const { isConnected, account, connect, disconnect } = useWallet()

  const fundingInfo = fundingRates.find((f) => f.market === activeMarket.symbol)
  const prevPriceRef = React.useRef(markPrice)
  const [priceDirection, setPriceDirection] = React.useState<'up' | 'down' | null>(null)

  React.useEffect(() => {
    if (markPrice > prevPriceRef.current) setPriceDirection('up')
    else if (markPrice < prevPriceRef.current) setPriceDirection('down')
    prevPriceRef.current = markPrice
    const t = setTimeout(() => setPriceDirection(null), 500)
    return () => clearTimeout(t)
  }, [markPrice])

  const priceColor = priceDirection === 'up'
    ? 'text-accent-green'
    : priceDirection === 'down'
    ? 'text-accent-red'
    : 'text-text-primary'

  const change24h = ((markPrice - 3250) / 3250 * 100).toFixed(2)
  const isPositiveChange = Number(change24h) >= 0

  return (
    <header className="flex items-center justify-between px-4 py-2 bg-bg-secondary border-b border-border-primary">
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2">
          <span className="text-accent-blue font-bold text-lg tracking-tight">PerpX</span>
          <span className="text-[10px] text-text-muted bg-bg-tertiary px-1.5 py-0.5 rounded">ARBITRUM</span>
        </div>

        <div className="flex items-center gap-1">
          {MARKETS.map((m) => (
            <button
              key={m.id}
              onClick={() => setActiveMarket(m)}
              className={`px-3 py-1 text-xs rounded-sm transition-colors ${
                activeMarket.id === m.id
                  ? 'bg-bg-tertiary text-accent-blue'
                  : 'text-text-muted hover:text-text-primary hover:bg-bg-hover'
              }`}
            >
              {m.symbol}
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-6">
        <div className="flex items-center gap-4">
          <div className="text-right">
            <div className={`text-base font-semibold ${priceColor} transition-colors`}>
              {markPrice.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>
          <div className="text-right">
            <div className="text-[10px] text-text-muted">24h Change</div>
            <div className={`text-xs font-medium ${isPositiveChange ? 'text-accent-green' : 'text-accent-red'}`}>
              {isPositiveChange ? '+' : ''}{change24h}%
            </div>
          </div>
          <div className="text-right">
            <div className="text-[10px] text-text-muted">Funding Rate</div>
            <div className={`text-xs font-medium ${Number(fundingInfo?.rate ?? 0) >= 0 ? 'text-accent-green' : 'text-accent-red'}`}>
              {fundingInfo ? (Number(fundingInfo.rate) >= 0 ? '+' : '') + (Number(fundingInfo.rate) * 100).toFixed(4) + '%' : '0.0000%'}
            </div>
          </div>
          {isConnected && accountSummary && (
            <div className="text-right">
              <div className="text-[10px] text-text-muted">Equity</div>
              <div className="text-xs font-medium text-text-primary">{formatUsd(accountSummary.totalEquity)}</div>
            </div>
          )}
        </div>

        <button
          onClick={isConnected ? disconnect : connect}
          className={`px-4 py-1.5 text-xs rounded-sm font-medium transition-colors ${
            isConnected
              ? 'bg-bg-tertiary text-text-primary border border-border-secondary hover:bg-bg-hover'
              : 'bg-accent-blue text-white hover:bg-accent-blue/80'
          }`}
        >
          {isConnected ? formatAddress(account!) : 'Connect Wallet'}
        </button>
      </div>
    </header>
  )
}
