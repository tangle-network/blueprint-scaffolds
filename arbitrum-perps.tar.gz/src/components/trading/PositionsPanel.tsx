import { useTradingStore } from '@/store/trading-store'
import { Button } from '@/components/ui/button'
import { formatUSD, cn } from '@/lib/utils'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'

export function PositionsPanel() {
  const { positions, closePosition, selectedMarket } = useTradingStore()
  const openPositions = positions.filter((p) => p.status === 'open')

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-3 py-2 border-b">
        <span className="text-xs font-medium">Positions ({openPositions.length})</span>
      </div>
      <div className="flex-1 overflow-auto">
        {openPositions.length === 0 ? (
          <div className="flex items-center justify-center h-24 text-xs text-muted-foreground">
            No open positions
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Market</TableHead>
                <TableHead>Side</TableHead>
                <TableHead>Size</TableHead>
                <TableHead>Leverage</TableHead>
                <TableHead>Entry</TableHead>
                <TableHead>Mark</TableHead>
                <TableHead>Liq.</TableHead>
                <TableHead>Margin</TableHead>
                <TableHead>PNL</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {openPositions.map((pos) => (
                <TableRow key={pos.id}>
                  <TableCell className="font-medium">{pos.marketSymbol}</TableCell>
                  <TableCell>
                    <span className={cn('font-medium', pos.side === 'long' ? 'text-profit' : 'text-loss')}>
                      {pos.side.toUpperCase()}
                    </span>
                  </TableCell>
                  <TableCell>{pos.size}</TableCell>
                  <TableCell>{pos.leverage}x</TableCell>
                  <TableCell>{formatUSD(pos.entryPrice)}</TableCell>
                  <TableCell>{formatUSD(pos.markPrice)}</TableCell>
                  <TableCell className="text-loss">{formatUSD(pos.liquidationPrice)}</TableCell>
                  <TableCell>
                    <div className="flex flex-col">
                      <span>{formatUSD(pos.margin)}</span>
                      <span className="text-muted-foreground">{pos.marginMode}</span>
                    </div>
                  </TableCell>
                  <TableCell className={cn('font-medium', pos.unrealizedPnl >= 0 ? 'text-profit' : 'text-loss')}>
                    {formatUSD(pos.unrealizedPnl)}
                  </TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm" className="h-6 text-xs" onClick={() => closePosition(pos.id)}>
                      Close
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>
    </div>
  )
}
