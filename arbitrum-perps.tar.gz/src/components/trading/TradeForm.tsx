import { useState } from 'react'
import { useTradingStore } from '@/store/trading-store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select'
import { cn, formatUSD, calculateLiquidationPrice } from '@/lib/utils'
import type { Side, OrderType, MarginMode } from '@/lib/types'

const LEVERAGE_OPTIONS = [1, 2, 3, 5, 10, 15, 20, 25, 50]

export function TradeForm() {
  const { selectedMarket, addOrder, account } = useTradingStore()
  const [side, setSide] = useState<Side>('long')
  const [orderType, setOrderType] = useState<OrderType>('market')
  const [marginMode, setMarginMode] = useState<MarginMode>('cross')
  const [leverage, setLeverage] = useState(10)
  const [size, setSize] = useState('')
  const [price, setPrice] = useState('')
  const [triggerPrice, setTriggerPrice] = useState('')
  const [trailPercent, setTrailPercent] = useState('')

  const notionalValue = parseFloat(size || '0') * selectedMarket.price
  const marginRequired = notionalValue / leverage
  const liqPrice = parseFloat(size || '0') > 0
    ? calculateLiquidationPrice(selectedMarket.price, leverage, side)
    : 0
  const fee = notionalValue * 0.0005

  const handleSubmit = () => {
    if (!account || !parseFloat(size)) return
    const order = {
      id: `o-${Date.now()}`,
      marketId: selectedMarket.id,
      marketSymbol: selectedMarket.symbol,
      type: orderType,
      side,
      size: parseFloat(size),
      price: price ? parseFloat(price) : undefined,
      triggerPrice: triggerPrice ? parseFloat(triggerPrice) : undefined,
      trailPercent: trailPercent ? parseFloat(trailPercent) : undefined,
      leverage,
      marginMode,
      status: 'pending' as const,
      createdAt: Date.now(),
    }
    addOrder(order)
    setSize('')
    setPrice('')
    setTriggerPrice('')
    setTrailPercent('')
  }

  const showPrice = orderType === 'limit' || orderType === 'stop-limit'
  const showTrigger = orderType === 'stop' || orderType === 'stop-limit' || orderType === 'take-profit'
  const showTrail = orderType === 'trailing-stop'

  return (
    <div className="flex flex-col h-full">
      <div className="p-3 border-b">
        <Tabs value={side} onValueChange={(v) => setSide(v as Side)}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="long" className="data-[state=active]:bg-profit data-[state=active]:text-white">
              Long
            </TabsTrigger>
            <TabsTrigger value="short" className="data-[state=active]:bg-loss data-[state=active]:text-white">
              Short
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="p-3 space-y-3 flex-1 overflow-y-auto">
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Order Type</label>
          <Select value={orderType} onValueChange={(v) => setOrderType(v as OrderType)}>
            <SelectTrigger className="h-8 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="market">Market</SelectItem>
              <SelectItem value="limit">Limit</SelectItem>
              <SelectItem value="stop">Stop</SelectItem>
              <SelectItem value="stop-limit">Stop Limit</SelectItem>
              <SelectItem value="take-profit">Take Profit</SelectItem>
              <SelectItem value="trailing-stop">Trailing Stop</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Margin Mode</label>
          <Tabs value={marginMode} onValueChange={(v) => setMarginMode(v as MarginMode)}>
            <TabsList className="grid w-full grid-cols-2 h-8">
              <TabsTrigger value="cross" className="text-xs">Cross</TabsTrigger>
              <TabsTrigger value="isolated" className="text-xs">Isolated</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        <div>
          <label className="text-xs text-muted-foreground mb-1 block">
            Leverage: <span className="text-foreground font-medium">{leverage}x</span>
          </label>
          <div className="flex items-center gap-2">
            <input
              type="range"
              min={1}
              max={selectedMarket.maxLeverage}
              value={leverage}
              onChange={(e) => setLeverage(parseInt(e.target.value))}
              className="flex-1 h-1.5 accent-primary"
            />
          </div>
          <div className="flex gap-1 mt-1.5 flex-wrap">
            {LEVERAGE_OPTIONS.filter((l) => l <= selectedMarket.maxLeverage).map((l) => (
              <Button
                key={l}
                variant={leverage === l ? 'default' : 'outline'}
                size="sm"
                className="h-6 px-2 text-xs"
                onClick={() => setLeverage(l)}
              >
                {l}x
              </Button>
            ))}
          </div>
        </div>

        {showPrice && (
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">Price (USD)</label>
            <Input
              type="number"
              placeholder={formatUSD(selectedMarket.price)}
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              className="h-8 text-xs"
            />
          </div>
        )}

        {showTrigger && (
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">Trigger Price (USD)</label>
            <Input
              type="number"
              placeholder={formatUSD(selectedMarket.price)}
              value={triggerPrice}
              onChange={(e) => setTriggerPrice(e.target.value)}
              className="h-8 text-xs"
            />
          </div>
        )}

        {showTrail && (
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">Trail Distance (%)</label>
            <Input
              type="number"
              placeholder="1.5"
              value={trailPercent}
              onChange={(e) => setTrailPercent(e.target.value)}
              className="h-8 text-xs"
            />
          </div>
        )}

        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Size ({selectedMarket.baseAsset})</label>
          <Input
            type="number"
            placeholder="0.00"
            value={size}
            onChange={(e) => setSize(e.target.value)}
            className="h-8 text-xs"
          />
        </div>

        <div className="space-y-1.5 text-xs text-muted-foreground pt-2 border-t">
          <div className="flex justify-between">
            <span>Notional Value</span>
            <span className="text-foreground">{formatUSD(notionalValue)}</span>
          </div>
          <div className="flex justify-between">
            <span>Margin Required</span>
            <span className="text-foreground">{formatUSD(marginRequired)}</span>
          </div>
          <div className="flex justify-between">
            <span>Est. Fee (0.05%)</span>
            <span className="text-foreground">{formatUSD(fee)}</span>
          </div>
          {liqPrice > 0 && (
            <div className="flex justify-between">
              <span>Est. Liq. Price</span>
              <span className="text-loss">{formatUSD(liqPrice)}</span>
            </div>
          )}
        </div>
      </div>

      <div className="p-3 border-t">
        {!account ? (
          <Button className="w-full" disabled>Connect Wallet to Trade</Button>
        ) : (
          <Button
            className={cn('w-full', side === 'long' ? 'bg-profit hover:bg-profit/90' : 'bg-loss hover:bg-loss/90')}
            onClick={handleSubmit}
            disabled={!parseFloat(size)}
          >
            {side === 'long' ? 'Buy/Long' : 'Sell/Short'} {selectedMarket.symbol}
          </Button>
        )}
      </div>
    </div>
  )
}
