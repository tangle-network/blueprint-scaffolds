import { useTradingStore } from '@/store/trading-store'
import { formatUSD, cn } from '@/lib/utils'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Plus } from 'lucide-react'

export function CollateralPanel() {
  const { collateral, account } = useTradingStore()
  const totalBalance = collateral.reduce((s, c) => s + c.usdValue, 0)

  return (
    <Card className="border-0 rounded-none">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle>Collateral</CardTitle>
          {account && (
            <Button variant="outline" size="sm" className="h-6 text-xs gap-1">
              <Plus className="h-3 w-3" />
              Deposit
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-sm font-medium mb-2">
          Total: {formatUSD(totalBalance)}
        </div>
        <div className="space-y-2">
          {collateral.map((asset) => (
            <div key={asset.symbol} className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center text-[10px] font-bold text-primary">
                  {asset.symbol.charAt(0)}
                </div>
                <span>{asset.symbol}</span>
              </div>
              <div className="text-right">
                <div>{asset.balance.toLocaleString()}</div>
                <div className="text-muted-foreground">{formatUSD(asset.usdValue)}</div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
