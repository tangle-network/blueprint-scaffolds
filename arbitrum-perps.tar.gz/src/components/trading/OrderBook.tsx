import { useEffect, useState } from 'react'
import { useTradingStore } from '@/store/trading-store'
import { generateOrderBook } from '@/lib/mock-data'
import { formatUSD, cn } from '@/lib/utils'
import type { OrderBookLevel } from '@/lib/types'

export function OrderBook() {
  const { selectedMarket } = useTradingStore()
  const [bids, setBids] = useState<OrderBookLevel[]>([])
  const [asks, setAsks] = useState<OrderBookLevel[]>([])

  useEffect(() => {
    const update = () => {
      const book = generateOrderBook(selectedMarket.price)
      setBids(book.bids)
      setAsks(book.asks)
    }
    update()
    const interval = setInterval(update, 2000)
    return () => clearInterval(interval)
  }, [selectedMarket.id, selectedMarket.price])

  const maxTotal = Math.max(
    ...asks.map((a) => a.total),
    ...bids.map((b) => b.total)
  )

  const spread = asks.length && bids.length
    ? ((asks[0].price - bids[0].price) / bids[0].price * 100).toFixed(3)
    : '0.000'

  return (
    <div className="flex flex-col h-full text-xs">
      <div className="flex items-center justify-between px-3 py-2 border-b">
        <span className="text-xs font-medium">Order Book</span>
        <span className="text-muted-foreground">Spread: {spread}%</span>
      </div>
      <div className="grid grid-cols-3 gap-0 px-3 py-1 text-muted-foreground border-b">
        <span>Price</span>
        <span className="text-right">Size</span>
        <span className="text-right">Total</span>
      </div>
      <div className="flex-1 overflow-y-auto flex flex-col-reverse">
        {asks.slice().reverse().map((level, i) => (
          <div key={`a-${i}`} className="relative grid grid-cols-3 px-3 py-0.5">
            <div
              className="absolute inset-y-0 right-0 bg-loss/10"
              style={{ width: `${(level.total / maxTotal) * 100}%` }}
            />
            <span className="text-loss relative z-10">
              {formatUSD(level.price, selectedMarket.price < 10 ? 4 : 2)}
            </span>
            <span className="text-right relative z-10">{level.size.toFixed(4)}</span>
            <span className="text-right relative z-10">{level.total.toFixed(4)}</span>
          </div>
        ))}
      </div>
      <div className="px-3 py-1.5 border-y text-center">
        <span className={cn(
          'text-base font-bold',
          selectedMarket.change24h >= 0 ? 'text-profit' : 'text-loss'
        )}>
          {formatUSD(selectedMarket.price, selectedMarket.price < 10 ? 4 : 2)}
        </span>
      </div>
      <div className="flex-1 overflow-y-auto">
        {bids.map((level, i) => (
          <div key={`b-${i}`} className="relative grid grid-cols-3 px-3 py-0.5">
            <div
              className="absolute inset-y-0 right-0 bg-profit/10"
              style={{ width: `${(level.total / maxTotal) * 100}%` }}
            />
            <span className="text-profit relative z-10">
              {formatUSD(level.price, selectedMarket.price < 10 ? 4 : 2)}
            </span>
            <span className="text-right relative z-10">{level.size.toFixed(4)}</span>
            <span className="text-right relative z-10">{level.total.toFixed(4)}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
