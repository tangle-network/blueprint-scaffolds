import { useTradingStore } from '@/store/trading-store'
import { Button } from '@/components/ui/button'
import { formatUSD, cn } from '@/lib/utils'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'

export function OrdersPanel() {
  const { orders, cancelOrder } = useTradingStore()
  const pendingOrders = orders.filter((o) => o.status === 'pending')

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-3 py-2 border-b">
        <span className="text-xs font-medium">Open Orders ({pendingOrders.length})</span>
      </div>
      <div className="flex-1 overflow-auto">
        {pendingOrders.length === 0 ? (
          <div className="flex items-center justify-center h-24 text-xs text-muted-foreground">
            No open orders
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Market</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Side</TableHead>
                <TableHead>Size</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Trigger</TableHead>
                <TableHead>Leverage</TableHead>
                <TableHead>Margin</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pendingOrders.map((order) => (
                <TableRow key={order.id}>
                  <TableCell className="font-medium">{order.marketSymbol}</TableCell>
                  <TableCell className="capitalize">{order.type.replace('-', ' ')}</TableCell>
                  <TableCell>
                    <span className={cn('font-medium', order.side === 'long' ? 'text-profit' : 'text-loss')}>
                      {order.side.toUpperCase()}
                    </span>
                  </TableCell>
                  <TableCell>{order.size}</TableCell>
                  <TableCell>{order.price ? formatUSD(order.price) : 'Market'}</TableCell>
                  <TableCell>{order.triggerPrice ? formatUSD(order.triggerPrice) : '-'}</TableCell>
                  <TableCell>{order.leverage}x</TableCell>
                  <TableCell className="capitalize">{order.marginMode}</TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm" className="h-6 text-xs" onClick={() => cancelOrder(order.id)}>
                      Cancel
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>
    </div>
  )
}
