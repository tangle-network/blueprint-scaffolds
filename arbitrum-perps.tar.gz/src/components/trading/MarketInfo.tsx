import { useTradingStore } from '@/store/trading-store'
import { formatUSD, formatCompact, cn } from '@/lib/utils'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { TrendingUp, TrendingDown, DollarSign, BarChart3 } from 'lucide-react'

export function MarketInfo() {
  const { selectedMarket } = useTradingStore()

  return (
    <Card className="border-0 rounded-none">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <span>{selectedMarket.symbol}</span>
            <span className={cn(
              'text-xs px-1.5 py-0.5 rounded',
              selectedMarket.change24h >= 0 ? 'bg-profit/10 text-profit' : 'bg-loss/10 text-loss'
            )}>
              {selectedMarket.change24h >= 0 ? '+' : ''}{selectedMarket.change24h.toFixed(2)}%
            </span>
          </CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">
          {formatUSD(selectedMarket.price, selectedMarket.price < 10 ? 4 : 2)}
        </div>
        <Separator className="my-2" />
        <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-xs">
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <BarChart3 className="h-3 w-3" />
            <span>24h Vol</span>
          </div>
          <span className="text-right">${formatCompact(selectedMarket.volume24h)}</span>

          <div className="flex items-center gap-1.5 text-muted-foreground">
            <DollarSign className="h-3 w-3" />
            <span>OI</span>
          </div>
          <span className="text-right">${formatCompact(selectedMarket.openInterest)}</span>

          <div className="flex items-center gap-1.5 text-muted-foreground">
            {selectedMarket.fundingRate >= 0 ? (
              <TrendingUp className="h-3 w-3 text-profit" />
            ) : (
              <TrendingDown className="h-3 w-3 text-loss" />
            )}
            <span>Funding</span>
          </div>
          <span className={cn('text-right', selectedMarket.fundingRate >= 0 ? 'text-profit' : 'text-loss')}>
            {(selectedMarket.fundingRate * 100).toFixed(4)}%
          </span>

          <div className="text-muted-foreground">Max Lev</div>
          <span className="text-right">{selectedMarket.maxLeverage}x</span>

          <div className="text-muted-foreground">Maint. Margin</div>
          <span className="text-right">{(selectedMarket.maintenanceMargin * 100).toFixed(1)}%</span>

          <div className="text-muted-foreground">Oracle</div>
          <span className="text-right text-primary">Chainlink + Pyth</span>
        </div>
      </CardContent>
    </Card>
  )
}
