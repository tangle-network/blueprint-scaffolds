import { useEffect, useState } from 'react'
import { useTradingStore } from '@/store/trading-store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { generateFundingHistory } from '@/lib/mock-data'
import type { FundingRateHistory } from '@/lib/types'

function formatUSD(value: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 4,
    maximumFractionDigits: 4,
  }).format(value)
}

export function FundingRatePanel() {
  const { selectedMarket } = useTradingStore()
  const [history, setHistory] = useState<FundingRateHistory[]>([])

  useEffect(() => {
    setHistory(generateFundingHistory(selectedMarket.fundingRate))
  }, [selectedMarket.id, selectedMarket.fundingRate])

  const avgRate = history.length > 0
    ? history.reduce((s, h) => s + h.rate, 0) / history.length
    : 0

  const annualRate = avgRate * 3 * 365 * 100

  return (
    <Card className="border-0 rounded-none">
      <CardHeader className="pb-2">
        <CardTitle>Funding Rate</CardTitle>
      </CardHeader>
      <CardContent className="text-xs space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-muted-foreground">Current</span>
          <span className={selectedMarket.fundingRate >= 0 ? 'text-profit' : 'text-loss'}>
            {(selectedMarket.fundingRate * 100).toFixed(4)}%
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-muted-foreground">8h Est.</span>
          <span>{formatUSD(selectedMarket.price * selectedMarket.fundingRate)}</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-muted-foreground">Annual Est.</span>
          <span className={annualRate >= 0 ? 'text-profit' : 'text-loss'}>
            {annualRate.toFixed(2)}%
          </span>
        </div>
        <div className="pt-1">
          <div className="text-muted-foreground mb-1">24h History</div>
          <div className="flex items-end gap-px h-8">
            {history.map((h, i) => (
              <div
                key={i}
                className={`flex-1 rounded-t-sm ${h.rate >= 0 ? 'bg-profit/40' : 'bg-loss/40'}`}
                style={{
                  height: `${Math.max(2, Math.abs(h.rate) / Math.max(...history.map(x => Math.abs(x.rate))) * 100)}%`,
                }}
              />
            ))}
          </div>
        </div>
        <div className="text-muted-foreground pt-1">
          Next funding: {new Date(Date.now() + 3600000 * (8 - (new Date().getHours() % 8))).toLocaleTimeString()}
        </div>
      </CardContent>
    </Card>
  )
}
