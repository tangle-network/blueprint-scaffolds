import { useEffect, useRef } from 'react'
import { createChart, type IChartApi, type ISeriesApi, ColorType, type Time } from 'lightweight-charts'
import { useTradingStore } from '@/store/trading-store'
import { generateCandlestickData } from '@/lib/mock-data'

export function TradingChart() {
  const chartContainerRef = useRef<HTMLDivElement>(null)
  const chartRef = useRef<IChartApi | null>(null)
  const seriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null)
  const { selectedMarket } = useTradingStore()

  useEffect(() => {
    if (!chartContainerRef.current) return

    const chart = createChart(chartContainerRef.current, {
      layout: {
        background: { type: ColorType.Solid, color: 'hsl(0, 0%, 3.9%)' },
        textColor: 'hsl(0, 0%, 63.9%)',
      },
      grid: {
        vertLines: { color: 'hsl(0, 0%, 10%)' },
        horzLines: { color: 'hsl(0, 0%, 10%)' },
      },
      crosshair: { mode: 0 },
      rightPriceScale: { borderColor: 'hsl(0, 0%, 14.9%)' },
      timeScale: { borderColor: 'hsl(0, 0%, 14.9%)', timeVisible: true },
      width: chartContainerRef.current.clientWidth,
      height: chartContainerRef.current.clientHeight,
    })

    const series = chart.addCandlestickSeries({
      upColor: '#22c55e',
      downColor: '#ef4444',
      borderUpColor: '#22c55e',
      borderDownColor: '#ef4444',
      wickUpColor: '#22c55e',
      wickDownColor: '#ef4444',
    })

    chartRef.current = chart
    seriesRef.current = series

    const handleResize = () => {
      if (chartContainerRef.current) {
        chart.applyOptions({
          width: chartContainerRef.current.clientWidth,
          height: chartContainerRef.current.clientHeight,
        })
      }
    }
    window.addEventListener('resize', handleResize)

    return () => {
      window.removeEventListener('resize', handleResize)
      chart.remove()
    }
  }, [])

  useEffect(() => {
    if (!seriesRef.current) return
    const data = generateCandlestickData(selectedMarket.price)
    seriesRef.current.setData(data as any)
  }, [selectedMarket.id, selectedMarket.price])

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-3 px-3 py-2 border-b">
        <span className="text-sm font-medium">{selectedMarket.symbol}</span>
        <span className="text-sm text-muted-foreground">
          OI: ${(selectedMarket.openInterest / 1e6).toFixed(1)}M
        </span>
        <span className="text-sm text-muted-foreground">
          24h Vol: ${(selectedMarket.volume24h / 1e6).toFixed(1)}M
        </span>
      </div>
      <div ref={chartContainerRef} className="flex-1" />
    </div>
  )
}
