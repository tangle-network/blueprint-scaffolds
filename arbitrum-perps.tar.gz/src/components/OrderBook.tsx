import React from 'react'
import { useTradingStore } from '../store/tradingStore'
import { formatPrice } from '../utils'

export const OrderBook: React.FC = () => {
  const orderBook = useTradingStore((s) => s.orderBook)
  const markPrice = useTradingStore((s) => s.markPrice)
  const activeMarket = useTradingStore((s) => s.activeMarket)

  const maxTotal = Math.max(
    ...orderBook.bids.map((b) => Number(b.total)),
    ...orderBook.asks.map((a) => Number(a.total)),
    1
  )

  return (
    <div className="flex flex-col h-full">
      <div className="panel-header">{activeMarket.symbol} Order Book</div>

      <div className="flex-1 overflow-hidden flex flex-col text-[11px]">
        <div className="grid grid-cols-3 px-2 py-1 text-text-muted text-[10px] border-b border-border-primary">
          <span>Price</span>
          <span className="text-right">Size</span>
          <span className="text-right">Total</span>
        </div>

        <div className="flex-1 overflow-y-auto flex flex-col-reverse">
          {orderBook.bids.map((bid, i) => {
            const depthPercent = (Number(bid.total) / maxTotal) * 100
            return (
              <div
                key={`bid-${i}`}
                className="grid grid-cols-3 px-2 py-0.5 row-hover relative"
              >
                <div
                  className="absolute inset-0 bg-accent-green/5"
                  style={{ width: `${depthPercent}%`, right: 0, left: 'auto' }}
                />
                <span className="relative text-accent-green">
                  {formatPrice(bid.price, activeMarket.priceDecimals)}
                </span>
                <span className="relative text-right text-text-secondary">
                  {Number(bid.size).toFixed(activeMarket.sizeDecimals)}
                </span>
                <span className="relative text-right text-text-muted">
                  {Number(bid.total).toFixed(2)}
                </span>
              </div>
            )
          })}
        </div>

        <div className="px-2 py-1.5 border-y border-border-primary bg-bg-tertiary">
          <span className={`text-sm font-bold ${true ? 'text-accent-green' : 'text-accent-red'}`}>
            {formatPrice(markPrice, activeMarket.priceDecimals)}
          </span>
          <span className="text-[10px] text-text-muted ml-2">USD</span>
        </div>

        <div className="flex-1 overflow-y-auto">
          {orderBook.asks.map((ask, i) => {
            const depthPercent = (Number(ask.total) / maxTotal) * 100
            return (
              <div
                key={`ask-${i}`}
                className="grid grid-cols-3 px-2 py-0.5 row-hover relative"
              >
                <div
                  className="absolute inset-0 bg-accent-red/5"
                  style={{ width: `${depthPercent}%` }}
                />
                <span className="relative text-accent-red">
                  {formatPrice(ask.price, activeMarket.priceDecimals)}
                </span>
                <span className="relative text-right text-text-secondary">
                  {Number(ask.size).toFixed(activeMarket.sizeDecimals)}
                </span>
                <span className="relative text-right text-text-muted">
                  {Number(ask.total).toFixed(2)}
                </span>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
