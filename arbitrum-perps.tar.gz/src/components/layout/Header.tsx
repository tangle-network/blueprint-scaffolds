import { Link, useLocation } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { useTradingStore } from '@/store/trading-store'
import { formatUSD } from '@/lib/utils'
import { Wallet, Shield, Trophy, BarChart3 } from 'lucide-react'

export function Header() {
  const { account, setAccount, collateral } = useTradingStore()
  const location = useLocation()
  const totalBalance = collateral.reduce((s, c) => s + c.usdValue, 0)

  const connectWallet = () => {
    setAccount('0x742d35Cc6634C0532925a3b844Bc9e7595f2bD18')
  }

  const navItems = [
    { path: '/', label: 'Trade', icon: BarChart3 },
    { path: '/leaderboard', label: 'Leaderboard', icon: Trophy },
    { path: '/insurance', label: 'Insurance', icon: Shield },
  ]

  return (
    <header className="h-12 border-b bg-card flex items-center px-4 gap-4 shrink-0">
      <Link to="/" className="flex items-center gap-2 font-bold text-primary">
        <BarChart3 className="h-5 w-5" />
        <span>ArbPerp</span>
      </Link>

      <nav className="flex items-center gap-1 ml-4">
        {navItems.map(({ path, label, icon: Icon }) => (
          <Link key={path} to={path}>
            <Button
              variant={location.pathname === path ? 'secondary' : 'ghost'}
              size="sm"
              className="gap-1.5"
            >
              <Icon className="h-3.5 w-3.5" />
              {label}
            </Button>
          </Link>
        ))}
      </nav>

      <div className="ml-auto flex items-center gap-3">
        {account && (
          <div className="text-xs text-muted-foreground">
            Balance: <span className="text-foreground font-medium">{formatUSD(totalBalance)}</span>
          </div>
        )}
        {account ? (
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-muted-foreground">
              {account.slice(0, 6)}...{account.slice(-4)}
            </span>
            <div className="h-2 w-2 rounded-full bg-profit" />
          </div>
        ) : (
          <Button size="sm" onClick={connectWallet} className="gap-1.5">
            <Wallet className="h-3.5 w-3.5" />
            Connect Wallet
          </Button>
        )}
      </div>
    </header>
  )
}
