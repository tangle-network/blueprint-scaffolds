import { useTradingStore } from '@/store/trading-store'
import { formatUSD, formatPercent, formatCompact } from '@/lib/utils'
import { cn } from '@/lib/utils'
import { ScrollArea } from '@/components/ui/scroll-area'

export function Sidebar() {
  const { markets, selectedMarket, selectMarket } = useTradingStore()

  return (
    <div className="w-56 border-r bg-card flex flex-col shrink-0">
      <div className="p-3 border-b">
        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Markets</h3>
      </div>
      <div className="flex-1 overflow-y-auto">
        {markets.map((market) => (
          <button
            key={market.id}
            onClick={() => selectMarket(market)}
            className={cn(
              'w-full px-3 py-2.5 flex flex-col gap-0.5 border-b border-border/50 hover:bg-accent/50 transition-colors text-left',
              selectedMarket.id === market.id && 'bg-accent'
            )}
          >
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">{market.symbol}</span>
              <span className={cn(
                'text-xs',
                market.change24h >= 0 ? 'text-profit' : 'text-loss'
              )}>
                {formatPercent(market.change24h)}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">{formatUSD(market.price, market.price < 10 ? 4 : 2)}</span>
              <span className="text-xs text-muted-foreground">Vol {formatCompact(market.volume24h)}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">
                FR: <span className={market.fundingRate >= 0 ? 'text-profit' : 'text-loss'}>
                  {(market.fundingRate * 100).toFixed(4)}%
                </span>
              </span>
              <span className="text-xs text-muted-foreground">
                {market.maxLeverage}x
              </span>
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}
