import { useState } from 'react'
import { useTradingStore } from '@/store/trading-store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { formatUSD, formatCompact, formatPercent, cn } from '@/lib/utils'
import { MARKET_STATS_24H, MOCK_SYSTEM_HEALTH } from '@/lib/mock-data'
import { Search, TrendingUp, TrendingDown, BarChart3, Activity, Users, DollarSign, Zap, Clock, Server } from 'lucide-react'
import type { Market } from '@/lib/types'

function MarketRow({ market, onSelect }: { market: Market; onSelect: (m: Market) => void }) {
  return (
    <button
      onClick={() => onSelect(market)}
      className="w-full grid grid-cols-12 gap-2 items-center px-4 py-3 border-b hover:bg-accent/50 transition-colors text-left"
    >
      <div className="col-span-2">
        <div className="text-sm font-medium">{market.symbol}</div>
        <div className="text-xs text-muted-foreground">{market.baseAsset}/{market.quoteAsset}</div>
      </div>
      <div className="col-span-2 text-sm">
        {formatUSD(market.price, market.price < 10 ? 4 : 2)}
      </div>
      <div className={cn('col-span-1 text-sm font-medium', market.change24h >= 0 ? 'text-profit' : 'text-loss')}>
        {market.change24h >= 0 ? '+' : ''}{market.change24h.toFixed(2)}%
      </div>
      <div className="col-span-2 text-sm text-right">
        ${formatCompact(market.volume24h)}
      </div>
      <div className="col-span-2 text-sm text-right">
        ${formatCompact(market.openInterestUsd)}
      </div>
      <div className={cn('col-span-1 text-xs text-right', market.fundingRate >= 0 ? 'text-profit' : 'text-loss')}>
        {(market.fundingRate * 100).toFixed(4)}%
      </div>
      <div className="col-span-2 text-xs text-muted-foreground text-right">
        {market.maxLeverage}x · {market.oracleSources.join('+')}
      </div>
    </button>
  )
}

export function MarketsPage() {
  const { markets, selectMarket } = useTradingStore()
  const [search, setSearch] = useState('')
  const [sortBy, setSortBy] = useState<'volume' | 'change' | 'oi'>('volume')
  const stats = MARKET_STATS_24H
  const health = MOCK_SYSTEM_HEALTH

  const filtered = markets
    .filter((m) => {
      if (!search) return true
      const q = search.toLowerCase()
      return m.symbol.toLowerCase().includes(q) || m.baseAsset.toLowerCase().includes(q) || m.name.toLowerCase().includes(q)
    })
    .sort((a, b) => {
      if (sortBy === 'volume') return b.volume24h - a.volume24h
      if (sortBy === 'change') return b.change24h - a.change24h
      return b.openInterestUsd - a.openInterestUsd
    })

  const handleSelect = (market: Market) => {
    selectMarket(market)
    window.location.hash = '#/'
  }

  return (
    <div className="h-full overflow-auto p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-center gap-3">
          <BarChart3 className="h-6 w-6 text-primary" />
          <h1 className="text-2xl font-bold">Markets Overview</h1>
        </div>

        <div className="grid grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs text-muted-foreground flex items-center gap-1.5">
                <DollarSign className="h-3.5 w-3.5" />
                24h Volume
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold">${formatCompact(stats.totalVolume)}</div>
              <div className="text-xs text-muted-foreground mt-1">{stats.totalTrades.toLocaleString()} trades</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs text-muted-foreground flex items-center gap-1.5">
                <Activity className="h-3.5 w-3.5" />
                Total OI
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold">${formatCompact(stats.totalOpenInterest)}</div>
              <div className="text-xs text-muted-foreground mt-1">Across {markets.length} markets</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs text-muted-foreground flex items-center gap-1.5">
                <Users className="h-3.5 w-3.5" />
                Active Traders
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold">{stats.activeTraders.toLocaleString()}</div>
              <div className="text-xs text-profit mt-1">+{stats.newAccounts} new today</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs text-muted-foreground flex items-center gap-1.5">
                <Server className="h-3.5 w-3.5" />
                System Health
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <div className={cn('h-2 w-2 rounded-full', health.status === 'online' ? 'bg-profit' : 'bg-yellow-500')} />
                <span className="text-xl font-bold capitalize">{health.status}</span>
              </div>
              <div className="text-xs text-muted-foreground mt-1">{health.blockLatency}ms latency</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-4 w-4" />
                Platform Fees Collected (24h)
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="text-2xl font-bold text-profit">{formatUSD(stats.totalFees)}</div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-muted-foreground">Avg Trade Size</span>
                  <div>{formatUSD(stats.avgTradeSize)}</div>
                </div>
                <div>
                  <span className="text-muted-foreground">Liq. Volume</span>
                  <div className="text-loss">${formatCompact(stats.liquidationVolume)}</div>
                </div>
                <div>
                  <span className="text-muted-foreground">Funding Collected</span>
                  <div>${formatCompact(stats.fundingCollected)}</div>
                </div>
                <div>
                  <span className="text-muted-foreground">Sequencer Uptime</span>
                  <div className="text-profit">{health.sequencerHealth}%</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Network Status
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Block Height</span>
                <span className="font-mono">{health.blockHeight.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Block Latency</span>
                <span>{health.blockLatency}ms</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Indexer Lag</span>
                <span className="text-profit">{health.indexerLag} blocks</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Oracle Freshness</span>
                <span>{health.oracleFreshness}s</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Mempool Size</span>
                <span>{health.mempoolSize} txs</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Gas Price</span>
                <span>{health.gasPrice} Gwei</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>All Perpetual Markets</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="flex items-center gap-2 px-4 py-3 border-b">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search markets..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9 h-8"
                />
              </div>
              <Tabs value={sortBy} onValueChange={(v) => setSortBy(v as typeof sortBy)}>
                <TabsList className="h-8">
                  <TabsTrigger value="volume" className="text-xs h-6 px-2">Volume</TabsTrigger>
                  <TabsTrigger value="change" className="text-xs h-6 px-2">Change</TabsTrigger>
                  <TabsTrigger value="oi" className="text-xs h-6 px-2">Open Interest</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
            <div className="grid grid-cols-12 gap-2 px-4 py-2 text-xs font-medium text-muted-foreground border-b bg-muted/30">
              <div className="col-span-2">Market</div>
              <div className="col-span-2">Price</div>
              <div className="col-span-1">24h</div>
              <div className="col-span-2 text-right">Volume</div>
              <div className="col-span-2 text-right">Open Interest</div>
              <div className="col-span-1 text-right">Funding</div>
              <div className="col-span-2 text-right">Leverage / Oracle</div>
            </div>
            {filtered.map((market) => (
              <MarketRow key={market.id} market={market} onSelect={handleSelect} />
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
