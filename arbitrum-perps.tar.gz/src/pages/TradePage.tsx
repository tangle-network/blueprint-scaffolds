import { TradingChart } from '@/components/trading/TradingChart'
import { OrderBook } from '@/components/trading/OrderBook'
import { TradeForm } from '@/components/trading/TradeForm'
import { PositionsPanel } from '@/components/trading/PositionsPanel'
import { OrdersPanel } from '@/components/trading/OrdersPanel'
import { MarketInfo } from '@/components/trading/MarketInfo'
import { CollateralPanel } from '@/components/trading/CollateralPanel'
import { FundingRatePanel } from '@/components/trading/FundingRatePanel'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'

export function TradePage() {
  return (
    <div className="flex flex-col h-full">
      <div className="flex flex-1 overflow-hidden">
        <div className="flex-1 flex flex-col border-r min-w-0">
          <TradingChart />
        </div>

        <div className="w-72 border-r flex flex-col shrink-0">
          <OrderBook />
        </div>

        <div className="w-72 shrink-0">
          <TradeForm />
        </div>
      </div>

      <div className="h-64 border-t flex flex-col shrink-0">
        <Tabs defaultValue="positions" className="flex flex-col h-full">
          <TabsList className="w-fit mx-2 mt-1 mb-0">
            <TabsTrigger value="positions">Positions</TabsTrigger>
            <TabsTrigger value="orders">Orders</TabsTrigger>
            <TabsTrigger value="info">Market Info</TabsTrigger>
            <TabsTrigger value="collateral">Collateral</TabsTrigger>
            <TabsTrigger value="funding">Funding</TabsTrigger>
          </TabsList>
          <TabsContent value="positions" className="flex-1 overflow-hidden mt-0">
            <PositionsPanel />
          </TabsContent>
          <TabsContent value="orders" className="flex-1 overflow-hidden mt-0">
            <OrdersPanel />
          </TabsContent>
          <TabsContent value="info" className="flex-1 overflow-auto mt-0 p-2">
            <MarketInfo />
          </TabsContent>
          <TabsContent value="collateral" className="flex-1 overflow-auto mt-0 p-2">
            <CollateralPanel />
          </TabsContent>
          <TabsContent value="funding" className="flex-1 overflow-auto mt-0 p-2">
            <FundingRatePanel />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
