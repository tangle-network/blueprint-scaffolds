import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { cn, formatUSD } from '@/lib/utils'
import { Shield, AlertTriangle, TrendingUp, DollarSign, BarChart3, Activity } from 'lucide-react'

export function InsuranceFundPage() {
  const fundBalance = 12_345_678.90
  const totalLiquidations = 234_567_890.12
  const totalDistributed = 8_765_432.10
  const pendingClaims = 123_456.78

  const recentEvents = [
    { type: 'liquidation', market: 'BTC-PERP', amount: 45678.90, time: '2 min ago', side: 'short' },
    { type: 'liquidation', market: 'ETH-PERP', amount: 23456.78, time: '15 min ago', side: 'long' },
    { type: 'distribution', market: 'SOL-PERP', amount: 12345.67, time: '1 hr ago', side: '-' },
    { type: 'liquidation', market: 'ARB-PERP', amount: 8901.23, time: '2 hr ago', side: 'long' },
    { type: 'distribution', market: 'BTC-PERP', amount: 5678.90, time: '3 hr ago', side: '-' },
    { type: 'liquidation', market: 'LINK-PERP', amount: 3456.78, time: '4 hr ago', side: 'short' },
    { type: 'liquidation', market: 'GMX-PERP', amount: 2345.67, time: '5 hr ago', side: 'long' },
    { type: 'distribution', market: 'ETH-PERP', amount: 1234.56, time: '6 hr ago', side: '-' },
  ]

  return (
    <div className="h-full overflow-auto p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex items-center gap-3">
          <Shield className="h-6 w-6 text-primary" />
          <h1 className="text-2xl font-bold">Insurance Fund</h1>
        </div>

        <p className="text-sm text-muted-foreground max-w-2xl">
          The insurance fund protects against auto-deleveraging by covering losses from forced liquidations.
          Funded by liquidation fees and exchange revenue. On-chain transparency via Arbitrum Stylus contracts.
        </p>

        <div className="grid grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs text-muted-foreground flex items-center gap-1.5">
                <Shield className="h-3.5 w-3.5" />
                Fund Balance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold text-profit">{formatUSD(fundBalance)}</div>
              <div className="text-xs text-profit mt-1">+2.3% this week</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs text-muted-foreground flex items-center gap-1.5">
                <AlertTriangle className="h-3.5 w-3.5" />
                Total Liquidations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold">{formatUSD(totalLiquidations)}</div>
              <div className="text-xs text-muted-foreground mt-1">Last 30 days</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs text-muted-foreground flex items-center gap-1.5">
                <DollarSign className="h-3.5 w-3.5" />
                Distributed
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold">{formatUSD(totalDistributed)}</div>
              <div className="text-xs text-muted-foreground mt-1">Total payouts</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs text-muted-foreground flex items-center gap-1.5">
                <Activity className="h-3.5 w-3.5" />
                Pending Claims
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold text-yellow-500">{formatUSD(pendingClaims)}</div>
              <div className="text-xs text-muted-foreground mt-1">Processing</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                Fund Utilization
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-muted-foreground">Utilization Rate</span>
                  <span>71.0%</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary rounded-full" style={{ width: '71%' }} />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-muted-foreground">Liquidation Coverage</span>
                  <span>5.3x</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-profit rounded-full" style={{ width: '85%' }} />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-muted-foreground">Auto-Deleveraging Risk</span>
                  <span className="text-profit">Low</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-profit rounded-full" style={{ width: '15%' }} />
                </div>
              </div>
              <Separator />
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <div className="text-muted-foreground">Liquidation Fee</div>
                  <div>0.5%</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Partial Liquidation</div>
                  <div>Enabled</div>
                </div>
                <div>
                  <div className="text-muted-foreground">ADL Threshold</div>
                  <div>95% utilization</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Max Drawdown</div>
                  <div>{formatUSD(1_234_567)}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                Recent Events
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y">
                {recentEvents.map((event, i) => (
                  <div key={i} className="flex items-center justify-between px-4 py-2.5 text-xs">
                    <div className="flex items-center gap-2">
                      <div className={cn(
                        'h-1.5 w-1.5 rounded-full',
                        event.type === 'liquidation' ? 'bg-loss' : 'bg-profit'
                      )} />
                      <span className="font-medium">{event.market}</span>
                      <span className={cn(
                        'px-1.5 py-0.5 rounded text-[10px]',
                        event.type === 'liquidation' ? 'bg-loss/10 text-loss' : 'bg-profit/10 text-profit'
                      )}>
                        {event.type === 'liquidation' ? 'Liq.' : 'Dist.'}
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className={event.type === 'liquidation' ? 'text-loss' : 'text-profit'}>
                        {event.type === 'liquidation' ? '-' : '+'}{formatUSD(event.amount)}
                      </span>
                      <span className="text-muted-foreground w-16 text-right">{event.time}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Contract Details (Arbitrum Stylus)</CardTitle>
          </CardHeader>
          <CardContent className="text-xs space-y-2">
            <div className="grid grid-cols-2 gap-x-8 gap-y-2">
              <div>
                <span className="text-muted-foreground">Position Manager: </span>
                <span className="font-mono">0xStylus... Posi7i0n</span>
              </div>
              <div>
                <span className="text-muted-foreground">Order Engine: </span>
                <span className="font-mono">0xStylus... 0rd3r5</span>
              </div>
              <div>
                <span className="text-muted-foreground">Oracle Aggregator: </span>
                <span className="font-mono">0xStylus... Pr4c13</span>
              </div>
              <div>
                <span className="text-muted-foreground">Insurance Vault: </span>
                <span className="font-mono">0xStylus... V4u17</span>
              </div>
            </div>
            <Separator className="my-2" />
            <div className="text-muted-foreground">
              Oracles: Chainlink Price Feeds + Pyth Network (dual-oracle with median aggregation and circuit breaker)
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}


