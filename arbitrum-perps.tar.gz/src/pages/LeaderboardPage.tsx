import { MOCK_LEADERBOARD } from '@/lib/mock-data'
import { formatUSD, formatCompact, formatAddress } from '@/lib/utils'
import { cn } from '@/lib/utils'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Trophy, Medal } from 'lucide-react'

export function LeaderboardPage() {
  return (
    <div className="h-full overflow-auto p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex items-center gap-3">
          <Trophy className="h-6 w-6 text-yellow-500" />
          <h1 className="text-2xl font-bold">Leaderboard</h1>
        </div>

        <div className="grid grid-cols-3 gap-4">
          {MOCK_LEADERBOARD.slice(0, 3).map((entry) => (
            <Card key={entry.rank} className={cn(
              'relative overflow-hidden',
              entry.rank === 1 && 'border-yellow-500/50',
              entry.rank === 2 && 'border-gray-400/50',
              entry.rank === 3 && 'border-amber-600/50',
            )}>
              <CardHeader className="pb-2">
                <div className="flex items-center gap-2">
                  <Medal className={cn(
                    'h-5 w-5',
                    entry.rank === 1 && 'text-yellow-500',
                    entry.rank === 2 && 'text-gray-400',
                    entry.rank === 3 && 'text-amber-600',
                  )} />
                  <CardTitle>#{entry.rank}</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="text-xs space-y-2">
                <div className="font-mono">{formatAddress(entry.address)}</div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Total PnL</span>
                  <span className="text-profit">{formatUSD(entry.totalPnl)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">ROI</span>
                  <span className="text-profit">+{entry.roi.toFixed(2)}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Win Rate</span>
                  <span>{entry.winRate}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Volume</span>
                  <span>${formatCompact(entry.volume)}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Rank</TableHead>
                  <TableHead>Trader</TableHead>
                  <TableHead>Total PnL</TableHead>
                  <TableHead>ROI</TableHead>
                  <TableHead>Win Rate</TableHead>
                  <TableHead>Trades</TableHead>
                  <TableHead>Volume</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {MOCK_LEADERBOARD.map((entry) => (
                  <TableRow key={entry.rank}>
                    <TableCell className="font-medium">
                      {entry.rank <= 3 ? (
                        <span className={cn(
                          entry.rank === 1 && 'text-yellow-500',
                          entry.rank === 2 && 'text-gray-400',
                          entry.rank === 3 && 'text-amber-600',
                        )}>
                          #{entry.rank}
                        </span>
                      ) : (
                        <span>#{entry.rank}</span>
                      )}
                    </TableCell>
                    <TableCell className="font-mono text-xs">{formatAddress(entry.address)}</TableCell>
                    <TableCell className={cn('font-medium', entry.totalPnl >= 0 ? 'text-profit' : 'text-loss')}>
                      {formatUSD(entry.totalPnl)}
                    </TableCell>
                    <TableCell className={cn('font-medium', entry.roi >= 0 ? 'text-profit' : 'text-loss')}>
                      +{entry.roi.toFixed(2)}%
                    </TableCell>
                    <TableCell>{entry.winRate}%</TableCell>
                    <TableCell>{entry.totalTrades.toLocaleString()}</TableCell>
                    <TableCell>${formatCompact(entry.volume)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
