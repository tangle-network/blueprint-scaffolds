export type Side = 'long' | 'short'
export type OrderType = 'market' | 'limit' | 'stop' | 'stop_limit' | 'take_profit'
export type MarginMode = 'cross' | 'isolated'
export type PositionStatus = 'open' | 'closed' | 'liquidated'
export type OrderStatus = 'pending' | 'filled' | 'cancelled' | 'expired'
export type CollateralAsset = 'USDC' | 'USDT' | 'DAI' | 'WETH' | 'WBTC' | 'ARB'

export interface Market {
  id: string
  symbol: string
  name: string
  baseAsset: string
  quoteAsset: string
  priceDecimals: number
  sizeDecimals: number
  maxLeverage: number
  maintenanceMarginRate: number
  fundingRateInterval: number
  oracleAddress: string
  isActive: boolean
}

export interface Position {
  id: string
  market: string
  side: Side
  size: string
  entryPrice: string
  markPrice: string
  leverage: number
  margin: string
  marginMode: MarginMode
  collateralAsset: CollateralAsset
  unrealizedPnl: string
  realizedPnl: string
  liquidationPrice: string
  status: PositionStatus
  createdAt: number
  updatedAt: number
  fundingFeeAccrued: string
}

export interface Order {
  id: string
  market: string
  side: Side
  type: OrderType
  price: string
  triggerPrice?: string
  size: string
  leverage: number
  margin: string
  marginMode: MarginMode
  collateralAsset: CollateralAsset
  status: OrderStatus
  createdAt: number
  updatedAt: number
  reduceOnly: boolean
}

export interface OrderBookEntry {
  price: string
  size: string
  total: string
}

export interface OrderBookSnapshot {
  market: string
  bids: OrderBookEntry[]
  asks: OrderBookEntry[]
  timestamp: number
}

export interface FundingRateInfo {
  market: string
  rate: string
  annualizedRate: string
  nextFundingTime: number
  periodHours: number
}

export interface AccountSummary {
  address: string
  totalEquity: string
  totalMargin: string
  availableMargin: string
  unrealizedPnl: string
  totalPnl: string
  positions: Position[]
  openOrders: Order[]
  collateralBalances: Record<CollateralAsset, string>
}

export interface LeaderboardEntry {
  rank: number
  address: string
  pnl: string
  pnlPercent: string
  totalVolume: string
  winRate: string
  positions: number
}

export interface TradeHistoryEntry {
  id: string
  market: string
  side: Side
  size: string
  price: string
  pnl: string
  fee: string
  timestamp: number
}

export interface InsuranceFundSummary {
  totalBalance: string
  totalDebt: string
  totalPremiumPaid: string
  recentLiquidations: LiquidationEvent[]
}

export interface LiquidationEvent {
  id: string
  market: string
  side: Side
  size: string
  liquidationPrice: string
  loss: string
  insuranceFundCovered: string
  timestamp: number
}

export interface CandleData {
  time: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

export const MARKETS: Market[] = [
  {
    id: 'eth-usdc',
    symbol: 'ETH-PERP',
    name: 'Ether Perpetual',
    baseAsset: 'ETH',
    quoteAsset: 'USDC',
    priceDecimals: 2,
    sizeDecimals: 4,
    maxLeverage: 50,
    maintenanceMarginRate: 0.005,
    fundingRateInterval: 28800,
    oracleAddress: '0x0000000000000000000000000000000000000001',
    isActive: true,
  },
  {
    id: 'btc-usdc',
    symbol: 'BTC-PERP',
    name: 'Bitcoin Perpetual',
    baseAsset: 'BTC',
    quoteAsset: 'USDC',
    priceDecimals: 1,
    sizeDecimals: 6,
    maxLeverage: 50,
    maintenanceMarginRate: 0.005,
    fundingRateInterval: 28800,
    oracleAddress: '0x0000000000000000000000000000000000000002',
    isActive: true,
  },
  {
    id: 'arb-usdc',
    symbol: 'ARB-PERP',
    name: 'Arbitrum Perpetual',
    baseAsset: 'ARB',
    quoteAsset: 'USDC',
    priceDecimals: 4,
    sizeDecimals: 2,
    maxLeverage: 25,
    maintenanceMarginRate: 0.01,
    fundingRateInterval: 28800,
    oracleAddress: '0x0000000000000000000000000000000000000003',
    isActive: true,
  },
  {
    id: 'sol-usdc',
    symbol: 'SOL-PERP',
    name: 'Solana Perpetual',
    baseAsset: 'SOL',
    quoteAsset: 'USDC',
    priceDecimals: 3,
    sizeDecimals: 2,
    maxLeverage: 25,
    maintenanceMarginRate: 0.01,
    fundingRateInterval: 28800,
    oracleAddress: '0x0000000000000000000000000000000000000004',
    isActive: true,
  },
]

export const COLLATERAL_ASSETS: { symbol: CollateralAsset; decimals: number; address: string }[] = [
  { symbol: 'USDC', decimals: 6, address: '0xaf88d065e77c8cC2239327C5EDb3A432268e5831' },
  { symbol: 'USDT', decimals: 6, address: '0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9' },
  { symbol: 'DAI', decimals: 18, address: '0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1' },
  { symbol: 'WETH', decimals: 18, address: '0x82aF49447D8a07e3bd95BD0d56f35241523fBab1' },
  { symbol: 'WBTC', decimals: 8, address: '0x2f2a2543B76A4166549F7aaB2e75Bef0aefC5B0f' },
  { symbol: 'ARB', decimals: 18, address: '0x912CE59144191C1204E64559FE8253a0e49E6548' },
]

export const LEVERAGE_OPTIONS = [1, 2, 3, 5, 10, 15, 20, 25, 30, 40, 50]
