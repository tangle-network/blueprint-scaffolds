import { create } from 'zustand'
import type { Position, Order, Market, CollateralAsset } from '@/lib/types'
import { MARKETS, MOCK_POSITIONS, MOCK_ORDERS, MOCK_COLLATERAL } from '@/lib/mock-data'

interface TradingStore {
  markets: Market[]
  selectedMarket: Market
  positions: Position[]
  orders: Order[]
  collateral: CollateralAsset[]
  account: string | null

  selectMarket: (market: Market) => void
  setAccount: (account: string | null) => void
  closePosition: (id: string) => void
  cancelOrder: (id: string) => void
  addOrder: (order: Order) => void
  addPosition: (position: Position) => void
}

export const useTradingStore = create<TradingStore>((set) => ({
  markets: MARKETS,
  selectedMarket: MARKETS[0],
  positions: MOCK_POSITIONS,
  orders: MOCK_ORDERS,
  collateral: MOCK_COLLATERAL,
  account: null,

  selectMarket: (market) => set({ selectedMarket: market }),
  setAccount: (account) => set({ account }),
  closePosition: (id) =>
    set((state) => ({
      positions: state.positions.map((p) =>
        p.id === id ? { ...p, status: 'closed' as const } : p
      ),
    })),
  cancelOrder: (id) =>
    set((state) => ({
      orders: state.orders.map((o) =>
        o.id === id ? { ...o, status: 'cancelled' as const } : o
      ),
    })),
  addOrder: (order) =>
    set((state) => ({ orders: [...state.orders, order] })),
  addPosition: (position) =>
    set((state) => ({ positions: [...state.positions, position] })),
}))
