import { create } from 'zustand'
import type {
  Market,
  Position,
  Order,
  OrderBookSnapshot,
  FundingRateInfo,
  AccountSummary,
  Side,
  MarginMode,
  OrderType,
  CollateralAsset,
} from '../types'
import { MARKETS } from '../types'
import {
  generateMockOrderBook,
  generateMockCandles,
  calculateUnrealizedPnl,
  calculateLiquidationPrice,
} from '../utils'
import type { CandleData } from '../types'

interface TradingState {
  activeMarket: Market
  setActiveMarket: (market: Market) => void

  markPrice: number
  setMarkPrice: (price: number) => void

  orderBook: OrderBookSnapshot
  updateOrderBook: () => void

  candles: CandleData[]
  updateCandles: () => void

  positions: Position[]
  addPosition: (position: Position) => void
  removePosition: (id: string) => void
  updatePosition: (id: string, updates: Partial<Position>) => void
  closePosition: (id: string) => void

  orders: Order[]
  addOrder: (order: Order) => void
  cancelOrder: (id: string) => void

  accountSummary: AccountSummary | null
  setAccountSummary: (summary: AccountSummary) => void

  fundingRates: FundingRateInfo[]
  updateFundingRates: () => void

  leverage: number
  setLeverage: (leverage: number) => void

  marginMode: MarginMode
  setMarginMode: (mode: MarginMode) => void

  collateralAsset: CollateralAsset
  setCollateralAsset: (asset: CollateralAsset) => void

  isConnected: boolean
  setIsConnected: (connected: boolean) => void

  account: string | null
  setAccount: (account: string | null) => void
}

const mockPositions: Position[] = [
  {
    id: 'pos-1',
    market: 'ETH-PERP',
    side: 'long',
    size: '10.5',
    entryPrice: '3245.50',
    markPrice: '3280.00',
    leverage: 10,
    margin: '3407.78',
    marginMode: 'cross',
    collateralAsset: 'USDC',
    unrealizedPnl: '362.25',
    realizedPnl: '0',
    liquidationPrice: '2957.41',
    status: 'open',
    createdAt: Date.now() - 86400000,
    updatedAt: Date.now(),
    fundingFeeAccrued: '-12.50',
  },
  {
    id: 'pos-2',
    market: 'BTC-PERP',
    side: 'short',
    size: '0.5',
    entryPrice: '97500.00',
    markPrice: '97200.00',
    leverage: 25,
    margin: '1950.00',
    marginMode: 'isolated',
    collateralAsset: 'USDT',
    unrealizedPnl: '150.00',
    realizedPnl: '0',
    liquidationPrice: '99456.25',
    status: 'open',
    createdAt: Date.now() - 43200000,
    updatedAt: Date.now(),
    fundingFeeAccrued: '-5.20',
  },
  {
    id: 'pos-3',
    market: 'SOL-PERP',
    side: 'long',
    size: '200',
    entryPrice: '185.50',
    markPrice: '183.20',
    leverage: 15,
    margin: '2473.33',
    marginMode: 'cross',
    collateralAsset: 'WETH',
    unrealizedPnl: '-460.00',
    realizedPnl: '0',
    liquidationPrice: '173.87',
    status: 'open',
    createdAt: Date.now() - 21600000,
    updatedAt: Date.now(),
    fundingFeeAccrued: '-8.30',
  },
]

const mockOrders: Order[] = [
  {
    id: 'ord-1',
    market: 'ETH-PERP',
    side: 'long',
    type: 'limit',
    price: '3200.00',
    size: '5.0',
    leverage: 10,
    margin: '1600.00',
    marginMode: 'isolated',
    collateralAsset: 'USDC',
    status: 'pending',
    createdAt: Date.now() - 3600000,
    updatedAt: Date.now(),
    reduceOnly: false,
  },
  {
    id: 'ord-2',
    market: 'BTC-PERP',
    side: 'short',
    type: 'stop',
    triggerPrice: '96000.00',
    price: '95800.00',
    size: '0.3',
    leverage: 20,
    margin: '1437.00',
    marginMode: 'cross',
    collateralAsset: 'USDC',
    status: 'pending',
    createdAt: Date.now() - 1800000,
    updatedAt: Date.now(),
    reduceOnly: true,
  },
]

const mockAccount: AccountSummary = {
  address: '0x742d35Cc6634C0532925a3b844Bc9e7595f2bD38',
  totalEquity: '52467.55',
  totalMargin: '7831.11',
  availableMargin: '3898.86',
  unrealizedPnl: '52.05',
  totalPnl: '12450.80',
  positions: mockPositions,
  openOrders: mockOrders,
  collateralBalances: {
    USDC: '25000.00',
    USDT: '15000.00',
    DAI: '5000.00',
    WETH: '2.5',
    WBTC: '0.1',
    ARB: '5000.00',
  },
}

export const useTradingStore = create<TradingState>((set, get) => ({
  activeMarket: MARKETS[0],
  setActiveMarket: (market) => {
    set({ activeMarket: market })
    get().updateOrderBook()
    get().updateCandles()
  },

  markPrice: 3280.45,
  setMarkPrice: (price) => set({ markPrice: price }),

  orderBook: {
    market: 'ETH-PERP',
    bids: [],
    asks: [],
    timestamp: Date.now(),
  },
  updateOrderBook: () => {
    const state = get()
    const { bids, asks } = generateMockOrderBook(state.markPrice)
    set({
      orderBook: {
        market: state.activeMarket.symbol,
        bids,
        asks,
        timestamp: Date.now(),
      },
    })
  },

  candles: [],
  updateCandles: () => {
    const state = get()
    const basePrice = state.markPrice
    set({ candles: generateMockCandles(200, basePrice) })
  },

  positions: mockPositions,
  addPosition: (position) =>
    set((s) => ({ positions: [...s.positions, position] })),
  removePosition: (id) =>
    set((s) => ({ positions: s.positions.filter((p) => p.id !== id) })),
  updatePosition: (id, updates) =>
    set((s) => ({
      positions: s.positions.map((p) =>
        p.id === id ? { ...p, ...updates } : p
      ),
    })),
  closePosition: (id) =>
    set((s) => ({
      positions: s.positions.map((p) =>
        p.id === id ? { ...p, status: 'closed' as const } : p
      ),
    })),

  orders: mockOrders,
  addOrder: (order) =>
    set((s) => ({ orders: [...s.orders, order] })),
  cancelOrder: (id) =>
    set((s) => ({
      orders: s.orders.map((o) =>
        o.id === id ? { ...o, status: 'cancelled' as const } : o
      ),
    })),

  accountSummary: mockAccount,
  setAccountSummary: (summary) => set({ accountSummary: summary }),

  fundingRates: [
    { market: 'ETH-PERP', rate: '0.0001', annualizedRate: '0.0876', nextFundingTime: Date.now() + 28800000, periodHours: 8 },
    { market: 'BTC-PERP', rate: '-0.00005', annualizedRate: '-0.0438', nextFundingTime: Date.now() + 28800000, periodHours: 8 },
    { market: 'ARB-PERP', rate: '0.0003', annualizedRate: '0.2628', nextFundingTime: Date.now() + 28800000, periodHours: 8 },
    { market: 'SOL-PERP', rate: '0.0002', annualizedRate: '0.1752', nextFundingTime: Date.now() + 28800000, periodHours: 8 },
  ],
  updateFundingRates: () =>
    set((s) => ({
      fundingRates: s.fundingRates.map((fr) => ({
        ...fr,
        rate: (Number(fr.rate) + (Math.random() - 0.5) * 0.00005).toFixed(6),
      })),
    })),

  leverage: 10,
  setLeverage: (leverage) => set({ leverage }),

  marginMode: 'cross',
  setMarginMode: (mode) => set({ marginMode: mode }),

  collateralAsset: 'USDC',
  setCollateralAsset: (asset) => set({ collateralAsset: asset }),

  isConnected: false,
  setIsConnected: (connected) => set({ isConnected: connected }),

  account: null,
  setAccount: (account) => set({ account }),
}))
