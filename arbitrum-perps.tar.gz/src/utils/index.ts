import type { Side } from '../types'
import type { CandleData } from '../types'

export function formatPrice(price: string | number, decimals = 2): string {
  return Number(price).toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })
}

export function formatSize(size: string | number, decimals = 4): string {
  return Number(size).toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })
}

export function formatUsd(value: string | number): string {
  const num = Number(value)
  if (Math.abs(num) >= 1e9) return `$${(num / 1e9).toFixed(2)}B`
  if (Math.abs(num) >= 1e6) return `$${(num / 1e6).toFixed(2)}M`
  if (Math.abs(num) >= 1e3) return `$${(num / 1e3).toFixed(2)}K`
  return `$${num.toFixed(2)}`
}

export function formatPnl(pnl: string | number): { text: string; className: string } {
  const num = Number(pnl)
  const sign = num >= 0 ? '+' : ''
  return {
    text: `${sign}$${Math.abs(num).toFixed(2)}`,
    className: num >= 0 ? 'text-accent-green' : 'text-accent-red',
  }
}

export function formatAddress(address: string): string {
  if (!address) return ''
  return `${address.slice(0, 6)}...${address.slice(-4)}`
}

export function formatPercent(value: string | number, decimals = 4): string {
  return `${(Number(value) * 100).toFixed(decimals)}%`
}

export function calculateLiquidationPrice(
  entryPrice: number,
  leverage: number,
  side: Side,
  maintenanceMarginRate: number = 0.005
): number {
  const marginRate = 1 / leverage
  if (side === 'long') {
    return entryPrice * (1 - marginRate + maintenanceMarginRate)
  } else {
    return entryPrice * (1 + marginRate - maintenanceMarginRate)
  }
}

export function calculateUnrealizedPnl(
  entryPrice: number,
  markPrice: number,
  size: number,
  side: Side
): number {
  if (side === 'long') {
    return (markPrice - entryPrice) * size
  } else {
    return (entryPrice - markPrice) * size
  }
}

export function calculateMargin(cost: number, leverage: number): number {
  return cost / leverage
}

export function calculateFundingFee(
  positionSize: number,
  entryPrice: number,
  fundingRate: number
): number {
  return positionSize * entryPrice * fundingRate
}

export function getMarginRequirement(
  size: number,
  price: number,
  leverage: number
): number {
  return (size * price) / leverage
}

export function sideColor(side: Side): string {
  return side === 'long' ? 'text-accent-green' : 'text-accent-red'
}

export function sideBg(side: Side): string {
  return side === 'long' ? 'bg-accent-green/10' : 'bg-accent-red/10'
}

export function generateMockCandles(count: number, basePrice: number): CandleData[] {
  const candles: CandleData[] = []
  let price = basePrice
  const now = Math.floor(Date.now() / 1000)

  for (let i = count; i > 0; i--) {
    const change = (Math.random() - 0.48) * (basePrice * 0.015)
    const open = price
    price += change
    const close = price
    const high = Math.max(open, close) + Math.random() * Math.abs(change) * 0.5
    const low = Math.min(open, close) - Math.random() * Math.abs(change) * 0.5
    const volume = Math.random() * 1000 + 100

    candles.push({
      time: now - i * 300,
      open: Number(open.toFixed(2)),
      high: Number(high.toFixed(2)),
      low: Number(low.toFixed(2)),
      close: Number(close.toFixed(2)),
      volume: Number(volume.toFixed(2)),
    })
  }

  return candles
}

export function generateMockOrderBook(midPrice: number, levels: number = 15) {
  const spread = midPrice * 0.0002
  const bids: { price: string; size: string; total: string }[] = []
  const asks: { price: string; size: string; total: string }[] = []
  let bidTotal = 0
  let askTotal = 0

  for (let i = 0; i < levels; i++) {
    const bidPrice = midPrice - spread - i * midPrice * 0.0003
    const askPrice = midPrice + spread + i * midPrice * 0.0003
    const bidSize = Math.random() * 50 + 5
    const askSize = Math.random() * 50 + 5

    bidTotal += bidSize
    askTotal += askSize

    bids.push({
      price: bidPrice.toFixed(2),
      size: bidSize.toFixed(4),
      total: bidTotal.toFixed(4),
    })
    asks.push({
      price: askPrice.toFixed(2),
      size: askSize.toFixed(4),
      total: askTotal.toFixed(4),
    })
  }

  return { bids, asks }
}

export const CONTRACTS = {
  positionManager: '0x0000000000000000000000000000000000001001',
  orderBook: '0x0000000000000000000000000000000000001002',
  oracleAggregator: '0x0000000000000000000000000000000000001003',
  insuranceFund: '0x0000000000000000000000000000000000001004',
  fundingRate: '0x0000000000000000000000000000000000001005',
  multicall: '0x0000000000000000000000000000000000001006',
} as const

export const ARBITRUM_CHAIN_ID = 42161
