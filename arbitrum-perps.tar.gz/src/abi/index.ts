export const POSITION_MANAGER_ABI = [
  'function openPosition(address market, uint8 side, uint256 size, uint256 leverage, uint8 marginMode, address collateralAsset) external returns (uint256 positionId)',
  'function closePosition(uint256 positionId, uint256 closeSize) external',
  'function addMargin(uint256 positionId, uint256 amount, address collateralAsset) external',
  'function removeMargin(uint256 positionId, uint256 amount) external',
  'function updateLeverage(uint256 positionId, uint256 newLeverage) external',
  'function liquidatePosition(uint256 positionId) external',
  'function partialLiquidate(uint256 positionId, uint256 closeRatio) external',
  'function getPosition(uint256 positionId) external view returns (tuple(uint256 id, address market, uint8 side, uint256 size, uint256 entryPrice, uint256 leverage, uint256 margin, uint8 marginMode, address collateralAsset, int256 unrealizedPnl, int256 fundingFee, uint256 liquidationPrice, uint8 status, uint256 createdAt))',
  'function getPositionsByTrader(address trader) external view returns (uint256[] memory)',
  'function getAccountSummary(address trader) external view returns (tuple(uint256 totalEquity, uint256 totalMargin, uint256 availableMargin, int256 unrealizedPnl, int256 totalPnl))',
  'event PositionOpened(uint256 indexed positionId, address indexed trader, address market, uint8 side, uint256 size, uint256 entryPrice, uint256 leverage)',
  'event PositionClosed(uint256 indexed positionId, address indexed trader, int256 pnl)',
  'event PositionLiquidated(uint256 indexed positionId, address indexed liquidator, uint256 lossToInsurance)',
  'event MarginUpdated(uint256 indexed positionId, uint256 newMargin)',
  'event LeverageUpdated(uint256 indexed positionId, uint256 newLeverage)',
] as const

export const ORDER_BOOK_ABI = [
  'function placeOrder(address market, uint8 side, uint8 orderType, uint256 price, uint256 triggerPrice, uint256 size, uint256 leverage, uint8 marginMode, address collateralAsset, bool reduceOnly) external returns (uint256 orderId)',
  'function cancelOrder(uint256 orderId) external',
  'function cancelAllOrders(address market) external',
  'function getOrderBook(address market, uint256 depth) external view returns (uint256[] memory bidPrices, uint256[] memory bidSizes, uint256[] memory askPrices, uint256[] memory askSizes)',
  'function getOrderByTrader(address trader, uint256 orderId) external view returns (tuple(uint256 id, address market, uint8 side, uint8 orderType, uint256 price, uint256 triggerPrice, uint256 size, uint256 leverage, uint8 marginMode, address collateralAsset, uint8 status, bool reduceOnly, uint256 createdAt))',
  'function getOrdersByTrader(address trader) external view returns (uint256[] memory)',
  'function getMidPrice(address market) external view returns (uint256)',
  'function getSpread(address market) external view returns (uint256)',
  'event OrderPlaced(uint256 indexed orderId, address indexed trader, address market, uint8 side, uint8 orderType, uint256 price, uint256 size)',
  'event OrderFilled(uint256 indexed orderId, uint256 fillSize, uint256 fillPrice)',
  'event OrderCancelled(uint256 indexed orderId)',
] as const

export const ORACLE_AGGREGATOR_ABI = [
  'function getPrice(address asset) external view returns (uint256 price, uint256 timestamp, uint8 source)',
  'function getPrices(address[] calldata assets) external view returns (uint256[] memory prices, uint256[] memory timestamps, uint8[] memory sources)',
  'function updateChainlinkPrice(address asset) external',
  'function updatePythPrice(address asset, bytes calldata pythData) external',
  'function setOracleSource(address asset, address chainlinkFeed, bytes32 pythFeedId) external',
  'function getPriceConfidence(address asset) external view returns (uint256 price, uint256 confidence)',
  'event PriceUpdated(address indexed asset, uint256 price, uint256 timestamp, uint8 source)',
] as const

export const INSURANCE_FUND_ABI = [
  'function deposit(address token, uint256 amount) external',
  'function withdraw(address token, uint256 amount) external',
  'function coverLoss(uint256 positionId, uint256 lossAmount) external',
  'function getTotalBalance() external view returns (uint256)',
  'function getBalanceByToken(address token) external view returns (uint256)',
  'function getRecentLiquidations(uint256 count) external view returns (tuple(uint256 positionId, address market, uint256 loss, uint256 covered, uint256 timestamp)[] memory)',
  'event Deposit(address indexed depositor, address token, uint256 amount)',
  'event LossCovered(uint256 indexed positionId, uint256 lossAmount, uint256 coveredAmount)',
] as const

export const FUNDING_RATE_ABI = [
  'function getFundingRate(address market) external view returns (int256 rate, uint256 nextTime, uint256 period)',
  'function getAccruedFunding(uint256 positionId) external view returns (int256 accrued)',
  'function getAnnualizedRate(address market) external view returns (int256)',
  'function setFundingPeriod(address market, uint256 period) external',
  'event FundingRateUpdated(address indexed market, int256 rate, uint256 timestamp)',
  'event FundingSettled(address indexed market, address indexed trader, int256 amount)',
] as const
