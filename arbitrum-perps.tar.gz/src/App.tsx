
export default function App() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto py-8 px-4">
        <h1 className="text-3xl font-bold mb-8">Welcome</h1>
        <p className="text-muted-foreground">Get started by editing src/App.tsx</p>
      </div>
    </div>
  )
}
