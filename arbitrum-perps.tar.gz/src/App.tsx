import { Routes, Route } from 'react-router-dom'
import { Header } from '@/components/layout/Header'
import { Sidebar } from '@/components/layout/Sidebar'
import { TradePage } from '@/pages/TradePage'
import { LeaderboardPage } from '@/pages/LeaderboardPage'
import { InsuranceFundPage } from '@/pages/InsuranceFundPage'

export default function App() {
  return (
    <div className="flex flex-col h-screen overflow-hidden">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        <main className="flex-1 overflow-hidden">
          <Routes>
            <Route path="/" element={<TradePage />} />
            <Route path="/leaderboard" element={<LeaderboardPage />} />
            <Route path="/insurance" element={<InsuranceFundPage />} />
          </Routes>
        </main>
      </div>
    </div>
  )
}
