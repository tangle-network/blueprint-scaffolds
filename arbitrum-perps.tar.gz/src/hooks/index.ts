import { useEffect, useRef, useCallback } from 'react'
import { useTradingStore } from '../store/tradingStore'

export function usePriceFeed() {
  const setMarkPrice = useTradingStore((s) => s.setMarkPrice)
  const updateOrderBook = useTradingStore((s) => s.updateOrderBook)
  const updateCandles = useTradingStore((s) => s.updateCandles)
  const markPrice = useTradingStore((s) => s.markPrice)
  const updateFundingRates = useTradingStore((s) => s.updateFundingRates)
  const updatePosition = useTradingStore((s) => s.updatePosition)
  const positions = useTradingStore((s) => s.positions)
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  useEffect(() => {
    updateOrderBook()
    updateCandles()

    intervalRef.current = setInterval(() => {
      const change = (Math.random() - 0.48) * markPrice * 0.001
      const newPrice = Number((markPrice + change).toFixed(2))
      setMarkPrice(newPrice)
      updateOrderBook()

      positions.forEach((p) => {
        if (p.status === 'open') {
          const pnl = Number(p.unrealizedPnl) + (Math.random() - 0.5) * 10
          updatePosition(p.id, {
            markPrice: newPrice.toString(),
            unrealizedPnl: pnl.toFixed(2),
          })
        }
      })
    }, 2000)

    const fundingInterval = setInterval(() => {
      updateFundingRates()
    }, 30000)

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current)
      clearInterval(fundingInterval)
    }
  }, [markPrice])

  return { markPrice }
}

export function useWallet() {
  const isConnected = useTradingStore((s) => s.isConnected)
  const account = useTradingStore((s) => s.account)
  const setIsConnected = useTradingStore((s) => s.setIsConnected)
  const setAccount = useTradingStore((s) => s.setAccount)

  const connect = useCallback(async () => {
    if (typeof window !== 'undefined' && (window as any).ethereum) {
      try {
        const accounts = await (window as any).ethereum.request({
          method: 'eth_requestAccounts',
        })
        setAccount(accounts[0])
        setIsConnected(true)
      } catch {
        console.error('Wallet connection failed')
      }
    } else {
      setAccount('0x742d35Cc6634C0532925a3b844Bc9e7595f2bD38')
      setIsConnected(true)
    }
  }, [setAccount, setIsConnected])

  const disconnect = useCallback(() => {
    setAccount(null)
    setIsConnected(false)
  }, [setAccount, setIsConnected])

  return { isConnected, account, connect, disconnect }
}

export function useAutoResize(el: HTMLElement | null, direction: 'height' | 'width') {
  useEffect(() => {
    if (!el) return
    const observer = new ResizeObserver(() => {})
    observer.observe(el)
    return () => observer.disconnect()
  }, [el, direction])
}
