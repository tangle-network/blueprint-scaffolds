export type Side = 'long' | 'short'
export type OrderType = 'market' | 'limit' | 'stop' | 'stop-limit' | 'take-profit' | 'trailing-stop'
export type MarginMode = 'cross' | 'isolated'
export type PositionStatus = 'open' | 'closed' | 'liquidated'
export type OrderStatus = 'pending' | 'filled' | 'cancelled' | 'triggered'

export interface Market {
  id: string
  symbol: string
  name: string
  baseAsset: string
  quoteAsset: string
  price: number
  change24h: number
  volume24h: number
  fundingRate: number
  openInterest: number
  maxLeverage: number
  maintenanceMargin: number
}

export interface Position {
  id: string
  marketId: string
  marketSymbol: string
  side: Side
  size: number
  notionalValue: number
  entryPrice: number
  markPrice: number
  leverage: number
  margin: number
  marginMode: MarginMode
  unrealizedPnl: number
  liquidationPrice: number
  createdAt: number
  status: PositionStatus
}

export interface Order {
  id: string
  marketId: string
  marketSymbol: string
  type: OrderType
  side: Side
  size: number
  price?: number
  triggerPrice?: number
  trailPercent?: number
  leverage: number
  marginMode: MarginMode
  status: OrderStatus
  createdAt: number
  filledAt?: number
}

export interface CollateralAsset {
  symbol: string
  address: string
  decimals: number
  balance: number
  usdValue: number
}

export interface LeaderboardEntry {
  rank: number
  address: string
  totalPnl: number
  totalPnlPercent: number
  winRate: number
  totalTrades: number
  volume: number
  roi: number
}

export interface OrderBookLevel {
  price: number
  size: number
  total: number
}

export interface FundingRateHistory {
  timestamp: number
  rate: number
}

export interface PortfolioSummary {
  totalEquity: number
  totalMargin: number
  availableMargin: number
  unrealizedPnl: number
  totalPnl: number
  positions: Position[]
  orders: Order[]
  collateral: CollateralAsset[]
}
