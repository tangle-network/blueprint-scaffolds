export type Side = 'long' | 'short'
export type MarginMode = 'cross' | 'isolated'
export type OrderType = 'market' | 'limit' | 'stop' | 'stop_limit' | 'take_profit' | 'take_profit_limit'
export type PositionStatus = 'open' | 'closed' | 'liquidated'
export type OrderStatus = 'pending' | 'filled' | 'cancelled' | 'triggered'
export type CollateralAsset = 'USDC' | 'USDT' | 'DAI' | 'WETH' | 'WBTC' | 'ARB'

export interface MarketConfig {
  symbol: string
  baseAsset: string
  quoteAsset: string
  priceDecimals: number
  sizeDecimals: number
  maxLeverage: number
  maintenanceMarginRate: number
  initialMarginRate: number
  takerFee: number
  makerFee: number
  fundingIntervalSec: number
  oracleAddress: string
  chainlinkFeed: string
  pythFeedId: string
}

export interface Position {
  id: string
  market: string
  side: Side
  size: number
  entryPrice: number
  markPrice: number
  leverage: number
  margin: number
  marginMode: MarginMode
  unrealizedPnl: number
  liquidationPrice: number
  collateral: CollateralAsset[]
  openedAt: number
  status: PositionStatus
}

export interface Order {
  id: string
  market: string
  side: Side
  type: OrderType
  size: number
  price: number
  triggerPrice?: number
  leverage: number
  marginMode: MarginMode
  status: OrderStatus
  filledSize: number
  createdAt: number
  collateral: CollateralAsset
}

export interface OrderBookLevel {
  price: number
  size: number
  total: number
}

export interface OrderBookData {
  bids: OrderBookLevel[]
  asks: OrderBookLevel[]
  spread: number
  spreadPercent: number
}

export interface FundingRateInfo {
  market: string
  rate: number
  annualized: number
  nextFundingTime: number
  indexPrice: number
  markPrice: number
  twap: number
}

export interface CollateralBalance {
  asset: CollateralAsset
  balance: number
  usdValue: number
  address: string
  decimals: number
}

export interface LeaderboardEntry {
  rank: number
  address: string
  totalPnl: number
  totalPnlPercent: number
  realizedPnl: number
  unrealizedPnl: number
  totalVolume: number
  winRate: number
  tradesCount: number
  bestTrade: number
  worstTrade: number
  avgLeverage: number
  activePositions: number
}

export interface InsuranceFundInfo {
  totalBalance: number
  totalClaims: number
  totalPremiums: number
  utilizationRate: number
  lastLiquidationRecovery: number
  collateralBreakdown: { asset: string; amount: number; usdValue: number }[]
}

export interface RecentTrade {
  id: string
  market: string
  side: Side
  size: number
  price: number
  time: number
  leverage: number
}

export interface CandleData {
  time: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

export interface MarketTicker {
  market: string
  lastPrice: number
  markPrice: number
  indexPrice: number
  volume24h: number
  change24h: number
  change24hPercent: number
  high24h: number
  low24h: number
  openInterest: number
  openInterestUsd: number
  fundingRate: number
}
