export type Side = 'long' | 'short'
export type OrderType = 'market' | 'limit' | 'stop' | 'stop-limit' | 'take-profit' | 'trailing-stop'
export type MarginMode = 'cross' | 'isolated'
export type PositionStatus = 'open' | 'closed' | 'liquidated'
export type OrderStatus = 'pending' | 'filled' | 'cancelled' | 'triggered'
export type LiquidationStatus = 'active' | 'partial' | 'full' | 'adl'
export type OracleSource = 'chainlink' | 'pyth' | 'redstone' | 'api3'
export type NetworkStatus = 'online' | 'degraded' | 'maintenance'
export type AssetCategory = 'perp' | 'spot' | 'option'

export interface Market {
  id: string
  symbol: string
  name: string
  baseAsset: string
  quoteAsset: string
  category: AssetCategory
  price: number
  indexPrice: number
  markPrice: number
  change24h: number
  high24h: number
  low24h: number
  volume24h: number
  turnover24h: number
  fundingRate: number
  fundingCountdown: number
  openInterest: number
  openInterestUsd: number
  maxLeverage: number
  maintenanceMargin: number
  initialMargin: number
  baseFeeRate: number
  oracleSources: OracleSource[]
  listedAt: number
  isDelistable: boolean
}

export interface Position {
  id: string
  marketId: string
  marketSymbol: string
  side: Side
  size: number
  notionalValue: number
  entryPrice: number
  markPrice: number
  leverage: number
  margin: number
  marginMode: MarginMode
  marginRatio: number
  unrealizedPnl: number
  realizedPnl: number
  liquidationPrice: number
  bankruptcyPrice: number
  createdAt: number
  updatedAt: number
  status: PositionStatus
  stopLoss?: number
  takeProfit?: number
}

export interface Order {
  id: string
  marketId: string
  marketSymbol: string
  type: OrderType
  side: Side
  size: number
  price?: number
  triggerPrice?: number
  trailPercent?: number
  leverage: number
  marginMode: MarginMode
  status: OrderStatus
  createdAt: number
  filledAt?: number
  filledPrice?: number
  reduceOnly: boolean
  postOnly: boolean
}

export interface Trade {
  id: string
  marketId: string
  marketSymbol: string
  side: Side
  price: number
  size: number
  notionalValue: number
  fee: number
  feeAsset: string
  timestamp: number
  txHash: string
  maker: boolean
}

export interface CollateralAsset {
  symbol: string
  address: string
  decimals: number
  balance: number
  availableBalance: number
  usdValue: number
  usdPrice: number
  isYieldBearing: boolean
  apr: number
}

export interface PortfolioSummary {
  totalEquity: number
  totalMargin: number
  availableMargin: number
  unrealizedPnl: number
  totalPnl: number
  totalPnlPercent: number
  marginRatio: number
  marginHealth: 'safe' | 'warning' | 'danger'
  positions: Position[]
  orders: Order[]
  collateral: CollateralAsset[]
}

export interface LeaderboardEntry {
  rank: number
  address: string
  displayName?: string
  totalPnl: number
  totalPnlPercent: number
  winRate: number
  totalTrades: number
  volume: number
  roi: number
  bestTrade: number
  worstTrade: number
  avgHoldingTime: number
  currentStreak: number
  isTopTrader: boolean
}

export interface OrderBookLevel {
  price: number
  size: number
  total: number
  depth: number
}

export interface FundingRateHistory {
  timestamp: number
  rate: number
  annualized: number
}

export interface LiquidationEvent {
  id: string
  marketSymbol: string
  side: Side
  size: number
  price: number
  value: number
  fee: number
  timestamp: number
  status: LiquidationStatus
}

export interface InsuranceFundSummary {
  totalBalance: number
  totalLiquidations30d: number
  totalDistributed: number
  pendingClaims: number
  utilizationRate: number
  coverageRatio: number
  adlRisk: 'low' | 'medium' | 'high'
  liquidationFee: number
  partialLiquidationEnabled: boolean
  adlThreshold: number
  maxDrawdown: number
  recentEvents: LiquidationEvent[]
}

export interface SystemHealth {
  status: NetworkStatus
  blockHeight: number
  blockLatency: number
  indexerLag: number
  oracleFreshness: number
  mempoolSize: number
  gasPrice: number
  sequencerHealth: number
  lastChecked: number
}

export interface MarketStat24h {
  totalVolume: number
  totalTrades: number
  totalFees: number
  avgTradeSize: number
  activeTraders: number
  newAccounts: number
  totalOpenInterest: number
  liquidationVolume: number
  fundingCollected: number
}

export interface CandlestickPoint {
  time: number
  open: number
  high: number
  low: number
  close: number
  volume?: number
}

export interface AccountEvent {
  id: string
  type: 'deposit' | 'withdraw' | 'trade' | 'funding' | 'liquidation' | 'transfer'
  market?: string
  amount: number
  asset: string
  balanceAfter: number
  timestamp: number
  txHash: string
}
