import type { MarketConfig, Side, Position } from './types'

export function calculateLiquidationPrice(
  entryPrice: number,
  side: Side,
  leverage: number,
  maintenanceMarginRate: number,
  marginMode: 'cross' | 'isolated',
  extraMargin = 0
): number {
  const effectiveMargin = extraMargin > 0 ? extraMargin : entryPrice / leverage
  if (side === 'long') {
    return entryPrice - effectiveMargin * (1 - maintenanceMarginRate)
  }
  return entryPrice + effectiveMargin * (1 - maintenanceMarginRate)
}

export function calculateUnrealizedPnl(
  entryPrice: number,
  markPrice: number,
  size: number,
  side: Side
): number {
  if (side === 'long') {
    return (markPrice - entryPrice) * size
  }
  return (entryPrice - markPrice) * size
}

export function calculateMarginRequired(
  size: number,
  price: number,
  leverage: number
): number {
  return (size * price) / leverage
}

export function calculateFundingPayment(
  size: number,
  price: number,
  fundingRate: number,
  side: Side
): number {
  const notional = size * price
  if (side === 'long') {
    return -notional * fundingRate
  }
  return notional * fundingRate
}

export function calculateFee(
  size: number,
  price: number,
  feeRate: number
): number {
  return size * price * feeRate
}

export function calculateBankruptcyPrice(
  entryPrice: number,
  side: Side,
  leverage: number
): number {
  if (side === 'long') {
    return entryPrice * (1 - 1 / leverage)
  }
  return entryPrice * (1 + 1 / leverage)
}

export function calculateMaxPositionSize(
  balance: number,
  price: number,
  leverage: number,
  feeRate: number
): number {
  const effectiveBalance = balance / (1 + feeRate)
  return (effectiveBalance * leverage) / price
}

export function calculateLeverageFromMargin(
  notionalValue: number,
  margin: number
): number {
  if (margin <= 0) return 0
  return Math.min(notionalValue / margin, 50)
}

export function calculateMaintenanceMargin(
  size: number,
  price: number,
  maintenanceMarginRate: number
): number {
  return size * price * maintenanceMarginRate
}

export function isLiquidatable(position: Position, maintenanceMarginRate: number): boolean {
  const notional = position.size * position.markPrice
  const marginRatio = position.margin / notional
  return marginRatio <= maintenanceMarginRate
}

export function calculatePartialLiquidationSize(
  position: Position,
  maintenanceMarginRate: number,
  partialLiquidationRatio = 0.5
): number {
  const notional = position.size * position.markPrice
  const deficit = position.margin - notional * maintenanceMarginRate
  if (deficit >= 0) return 0
  return position.size * partialLiquidationRatio
}

export function generateMockCandles(basePrice: number, count: number) {
  const candles = []
  let price = basePrice
  const now = Math.floor(Date.now() / 1000)
  for (let i = count; i > 0; i--) {
    const change = (Math.random() - 0.48) * basePrice * 0.005
    const open = price
    price += change
    const high = Math.max(open, price) + Math.random() * basePrice * 0.002
    const low = Math.min(open, price) - Math.random() * basePrice * 0.002
    candles.push({
      time: now - i * 300,
      open: Number(open.toFixed(2)),
      high: Number(high.toFixed(2)),
      low: Number(low.toFixed(2)),
      close: Number(price.toFixed(2)),
      volume: Math.random() * 1000 + 100,
    })
  }
  return candles
}

export function generateMockOrderBook(midPrice: number, market: MarketConfig, levels = 15) {
  const step = midPrice * 0.0001
  const bids = []
  const asks = []
  let bidTotal = 0
  let askTotal = 0
  for (let i = 0; i < levels; i++) {
    const bidSize = Math.random() * 50 + 1
    const askSize = Math.random() * 50 + 1
    bidTotal += bidSize
    askTotal += askSize
    bids.push({
      price: Number((midPrice - step * (i + 1)).toFixed(market.priceDecimals)),
      size: Number(bidSize.toFixed(market.sizeDecimals)),
      total: Number(bidTotal.toFixed(market.sizeDecimals)),
    })
    asks.push({
      price: Number((midPrice + step * (i + 1)).toFixed(market.priceDecimals)),
      size: Number(askSize.toFixed(market.sizeDecimals)),
      total: Number(askTotal.toFixed(market.sizeDecimals)),
    })
  }
  return {
    bids: bids.reverse(),
    asks,
    spread: Number((asks[0].price - bids[bids.length - 1].price).toFixed(market.priceDecimals)),
    spreadPercent: Number(((asks[0].price - bids[bids.length - 1].price) / midPrice * 100).toFixed(4)),
  }
}
