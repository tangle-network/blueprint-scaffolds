import type { Market, Position, Order, CollateralAsset, LeaderboardEntry, OrderBookLevel } from './types'

export const MARKETS: Market[] = [
  { id: 'btc-usdc', symbol: 'BTC-PERP', name: 'Bitcoin Perpetual', baseAsset: 'BTC', quoteAsset: 'USDC', price: 67542.30, change24h: 2.34, volume24h: 1_234_567_890, fundingRate: 0.0001, openInterest: 543_210_000, maxLeverage: 50, maintenanceMargin: 0.005 },
  { id: 'eth-usdc', symbol: 'ETH-PERP', name: 'Ethereum Perpetual', baseAsset: 'ETH', quoteAsset: 'USDC', price: 3456.78, change24h: -1.23, volume24h: 567_890_123, fundingRate: -0.00005, openInterest: 234_567_000, maxLeverage: 50, maintenanceMargin: 0.005 },
  { id: 'arb-usdc', symbol: 'ARB-PERP', name: 'Arbitrum Perpetual', baseAsset: 'ARB', quoteAsset: 'USDC', price: 1.2345, change24h: 5.67, volume24h: 89_012_345, fundingRate: 0.0002, openInterest: 12_345_000, maxLeverage: 25, maintenanceMargin: 0.01 },
  { id: 'sol-usdc', symbol: 'SOL-PERP', name: 'Solana Perpetual', baseAsset: 'SOL', quoteAsset: 'USDC', price: 178.90, change24h: 3.45, volume24h: 345_678_901, fundingRate: 0.00015, openInterest: 98_765_000, maxLeverage: 25, maintenanceMargin: 0.01 },
  { id: 'link-usdc', symbol: 'LINK-PERP', name: 'Chainlink Perpetual', baseAsset: 'LINK', quoteAsset: 'USDC', price: 18.56, change24h: -0.89, volume24h: 45_678_901, fundingRate: -0.0001, openInterest: 8_765_000, maxLeverage: 25, maintenanceMargin: 0.01 },
  { id: 'gmx-usdc', symbol: 'GMX-PERP', name: 'GMX Perpetual', baseAsset: 'GMX', quoteAsset: 'USDC', price: 34.21, change24h: 1.12, volume24h: 12_345_678, fundingRate: 0.00005, openInterest: 5_432_000, maxLeverage: 20, maintenanceMargin: 0.01 },
]

export const MOCK_POSITIONS: Position[] = [
  { id: 'p1', marketId: 'btc-usdc', marketSymbol: 'BTC-PERP', side: 'long', size: 0.5, notionalValue: 33771.15, entryPrice: 65432.10, markPrice: 67542.30, leverage: 10, margin: 3377.12, marginMode: 'cross', unrealizedPnl: 1055.10, liquidationPrice: 59789.32, createdAt: Date.now() - 86400000, status: 'open' },
  { id: 'p2', marketId: 'eth-usdc', marketSymbol: 'ETH-PERP', side: 'short', size: 5, notionalValue: 17283.90, entryPrice: 3567.89, markPrice: 3456.78, leverage: 5, margin: 3456.78, marginMode: 'isolated', unrealizedPnl: 555.55, liquidationPrice: 3889.12, createdAt: Date.now() - 43200000, status: 'open' },
  { id: 'p3', marketId: 'sol-usdc', marketSymbol: 'SOL-PERP', side: 'long', size: 100, notionalValue: 17890.00, entryPrice: 175.23, markPrice: 178.90, leverage: 20, margin: 894.50, marginMode: 'cross', unrealizedPnl: 367.00, liquidationPrice: 170.12, createdAt: Date.now() - 21600000, status: 'open' },
]

export const MOCK_ORDERS: Order[] = [
  { id: 'o1', marketId: 'btc-usdc', marketSymbol: 'BTC-PERP', type: 'limit', side: 'long', size: 0.1, price: 65000, leverage: 10, marginMode: 'isolated', status: 'pending', createdAt: Date.now() - 3600000 },
  { id: 'o2', marketId: 'eth-usdc', marketSymbol: 'ETH-PERP', type: 'stop', side: 'short', size: 10, triggerPrice: 3200, leverage: 5, marginMode: 'cross', status: 'pending', createdAt: Date.now() - 7200000 },
  { id: 'o3', marketId: 'arb-usdc', marketSymbol: 'ARB-PERP', type: 'take-profit', side: 'long', size: 5000, triggerPrice: 1.50, leverage: 15, marginMode: 'isolated', status: 'pending', createdAt: Date.now() - 1800000 },
]

export const MOCK_COLLATERAL: CollateralAsset[] = [
  { symbol: 'USDC', address: '0xaf88d065e77c8cC2239327C5EDb3A432268e5831', decimals: 6, balance: 25430.50, usdValue: 25430.50 },
  { symbol: 'ETH', address: '0xEe01c0CD76354C383B8c7B4e65EA88D6B7A6D6dE', decimals: 18, balance: 2.5, usdValue: 8641.95 },
  { symbol: 'BTC', address: '0x6aEf3bBBa4b207C92A1E0Fe0a7A37e256A89E3b4', decimals: 8, balance: 0.15, usdValue: 10131.35 },
  { symbol: 'ARB', address: '0x912CE59144191C1204E64559FE8253a0e49E6548', decimals: 18, balance: 5000, usdValue: 6172.50 },
]

export const MOCK_LEADERBOARD: LeaderboardEntry[] = [
  { rank: 1, address: '0x742d35Cc6634C0532925a3b844Bc9e7595f2bD18', totalPnl: 2345678.90, totalPnlPercent: 234.56, winRate: 78.5, totalTrades: 1234, volume: 89_000_000, roi: 234.56 },
  { rank: 2, address: '0x8ba1f109551bD432803012645Ac136ddd64DBA72', totalPnl: 1890123.45, totalPnlPercent: 189.01, winRate: 72.3, totalTrades: 987, volume: 67_000_000, roi: 189.01 },
  { rank: 3, address: '0xdD870fA1b7C4700F2BD7f44238821C26f7392148', totalPnl: 1567890.12, totalPnlPercent: 156.79, winRate: 69.8, totalTrades: 876, volume: 54_000_000, roi: 156.79 },
  { rank: 4, address: '0x583031D1113aD414F02576BD6afaBfb302140225', totalPnl: 1234567.89, totalPnlPercent: 123.46, winRate: 65.4, totalTrades: 765, volume: 43_000_000, roi: 123.46 },
  { rank: 5, address: '0x4B0897b0513fdC7C541B6d9D7E929C4e5364D2dB', totalPnl: 987654.32, totalPnlPercent: 98.77, winRate: 61.2, totalTrades: 654, volume: 32_000_000, roi: 98.77 },
  { rank: 6, address: '0x14723A09ACff6D2A60DcdF7aA4AFf308F36C2810', totalPnl: 876543.21, totalPnlPercent: 87.65, winRate: 58.9, totalTrades: 543, volume: 28_000_000, roi: 87.65 },
  { rank: 7, address: '0xCA35b7d915458EF540aDe6068dFe2F44E8fa733c', totalPnl: 765432.10, totalPnlPercent: 76.54, winRate: 55.7, totalTrades: 432, volume: 21_000_000, roi: 76.54 },
  { rank: 8, address: '0x1aE0EA34a72D944a8C7603FfB3eC30a6669E454C', totalPnl: 654321.00, totalPnlPercent: 65.43, winRate: 53.4, totalTrades: 321, volume: 15_000_000, roi: 65.43 },
  { rank: 9, address: '0x0A098Eda01Ce92ff4A4CCb7A4fFFb5A43EBC70DC', totalPnl: 543210.98, totalPnlPercent: 54.32, winRate: 51.1, totalTrades: 210, volume: 9_000_000, roi: 54.32 },
  { rank: 10, address: '0x5B38Da6a701c568545dCfcB03FcB875f56beddC4', totalPnl: 432109.87, totalPnlPercent: 43.21, winRate: 48.8, totalTrades: 198, volume: 7_500_000, roi: 43.21 },
]

export function generateOrderBook(midPrice: number, spread = 0.001): { bids: OrderBookLevel[]; asks: OrderBookLevel[] } {
  const bids: OrderBookLevel[] = []
  const asks: OrderBookLevel[] = []
  let bidTotal = 0
  let askTotal = 0
  for (let i = 0; i < 20; i++) {
    const bidPrice = midPrice * (1 - spread * (i + 1))
    const askPrice = midPrice * (1 + spread * (i + 1))
    const bidSize = Math.random() * 10 + 0.5
    const askSize = Math.random() * 10 + 0.5
    bidTotal += bidSize
    askTotal += askSize
    bids.push({ price: bidPrice, size: bidSize, total: bidTotal })
    asks.push({ price: askPrice, size: askSize, total: askTotal })
  }
  return { bids, asks }
}

export function generateCandlestickData(basePrice: number, count = 200) {
  const data = []
  let price = basePrice * 0.8
  const now = Math.floor(Date.now() / 1000)
  for (let i = 0; i < count; i++) {
    const open = price
    const change = (Math.random() - 0.48) * price * 0.02
    const close = open + change
    const high = Math.max(open, close) * (1 + Math.random() * 0.005)
    const low = Math.min(open, close) * (1 - Math.random() * 0.005)
    data.push({
      time: now - (count - i) * 3600,
      open: +open.toFixed(2),
      high: +high.toFixed(2),
      low: +low.toFixed(2),
      close: +close.toFixed(2),
    })
    price = close
  }
  return data
}
