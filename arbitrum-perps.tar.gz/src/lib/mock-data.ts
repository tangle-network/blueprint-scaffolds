import type { Market, Position, Order, CollateralAsset, LeaderboardEntry, OrderBookLevel, AccountEvent, SystemHealth, MarketStat24h, LiquidationEvent, FundingRateHistory } from './types'

const now = Date.now()

export const MARKETS: Market[] = [
  { id: 'btc-usdc', symbol: 'BTC-PERP', name: 'Bitcoin Perpetual', baseAsset: 'BTC', quoteAsset: 'USDC', category: 'perp', price: 67542.30, indexPrice: 67538.10, markPrice: 67541.80, change24h: 2.34, high24h: 68234.00, low24h: 65890.50, volume24h: 1_234_567_890, turnover24h: 4_567_890_123, fundingRate: 0.0001, fundingCountdown: 2847, openInterest: 543_210, openInterestUsd: 36_700_000_000, maxLeverage: 50, maintenanceMargin: 0.005, initialMargin: 0.01, baseFeeRate: 0.0005, oracleSources: ['chainlink', 'pyth'], listedAt: now - 365 * 86400000, isDelistable: false },
  { id: 'eth-usdc', symbol: 'ETH-PERP', name: 'Ethereum Perpetual', baseAsset: 'ETH', quoteAsset: 'USDC', category: 'perp', price: 3456.78, indexPrice: 3455.90, markPrice: 3456.40, change24h: -1.23, high24h: 3512.00, low24h: 3410.20, volume24h: 567_890_123, turnover24h: 1_987_654_321, fundingRate: -0.00005, fundingCountdown: 2847, openInterest: 234_567, openInterestUsd: 810_000_000, maxLeverage: 50, maintenanceMargin: 0.005, initialMargin: 0.01, baseFeeRate: 0.0005, oracleSources: ['chainlink', 'pyth'], listedAt: now - 365 * 86400000, isDelistable: false },
  { id: 'arb-usdc', symbol: 'ARB-PERP', name: 'Arbitrum Perpetual', baseAsset: 'ARB', quoteAsset: 'USDC', category: 'perp', price: 1.2345, indexPrice: 1.2338, markPrice: 1.2342, change24h: 5.67, high24h: 1.2890, low24h: 1.1680, volume24h: 89_012_345, turnover24h: 234_567_890, fundingRate: 0.0002, fundingCountdown: 2847, openInterest: 12_345_000, openInterestUsd: 15_234_567, maxLeverage: 25, maintenanceMargin: 0.01, initialMargin: 0.02, baseFeeRate: 0.0006, oracleSources: ['chainlink', 'redstone'], listedAt: now - 180 * 86400000, isDelistable: false },
  { id: 'sol-usdc', symbol: 'SOL-PERP', name: 'Solana Perpetual', baseAsset: 'SOL', quoteAsset: 'USDC', category: 'perp', price: 178.90, indexPrice: 178.85, markPrice: 178.88, change24h: 3.45, high24h: 183.40, low24h: 172.10, volume24h: 345_678_901, turnover24h: 987_654_321, fundingRate: 0.00015, fundingCountdown: 2847, openInterest: 98_765, openInterestUsd: 176_543_210, maxLeverage: 25, maintenanceMargin: 0.01, initialMargin: 0.02, baseFeeRate: 0.0006, oracleSources: ['chainlink', 'pyth'], listedAt: now - 300 * 86400000, isDelistable: false },
  { id: 'link-usdc', symbol: 'LINK-PERP', name: 'Chainlink Perpetual', baseAsset: 'LINK', quoteAsset: 'USDC', category: 'perp', price: 18.56, indexPrice: 18.54, markPrice: 18.55, change24h: -0.89, high24h: 19.12, low24h: 18.20, volume24h: 45_678_901, turnover24h: 123_456_789, fundingRate: -0.0001, fundingCountdown: 2847, openInterest: 8_765_000, openInterestUsd: 162_678_900, maxLeverage: 25, maintenanceMargin: 0.01, initialMargin: 0.02, baseFeeRate: 0.0006, oracleSources: ['chainlink'], listedAt: now - 240 * 86400000, isDelistable: false },
  { id: 'gmx-usdc', symbol: 'GMX-PERP', name: 'GMX Perpetual', baseAsset: 'GMX', quoteAsset: 'USDC', category: 'perp', price: 34.21, indexPrice: 34.18, markPrice: 34.20, change24h: 1.12, high24h: 35.40, low24h: 33.50, volume24h: 12_345_678, turnover24h: 45_678_901, fundingRate: 0.00005, fundingCountdown: 2847, openInterest: 5_432_000, openInterestUsd: 185_812_320, maxLeverage: 20, maintenanceMargin: 0.01, initialMargin: 0.02, baseFeeRate: 0.0007, oracleSources: ['chainlink'], listedAt: now - 200 * 86400000, isDelistable: true },
]

export const MOCK_POSITIONS: Position[] = [
  { id: 'p1', marketId: 'btc-usdc', marketSymbol: 'BTC-PERP', side: 'long', size: 0.5, notionalValue: 33771.15, entryPrice: 65432.10, markPrice: 67542.30, leverage: 10, margin: 3377.12, marginMode: 'cross', marginRatio: 26.81, unrealizedPnl: 1055.10, realizedPnl: 0, liquidationPrice: 59789.32, bankruptcyPrice: 58989.81, createdAt: now - 86400000, updatedAt: now, status: 'open' },
  { id: 'p2', marketId: 'eth-usdc', marketSymbol: 'ETH-PERP', side: 'short', size: 5, notionalValue: 17283.90, entryPrice: 3567.89, markPrice: 3456.78, leverage: 5, margin: 3456.78, marginMode: 'isolated', marginRatio: 58.07, unrealizedPnl: 555.55, realizedPnl: 0, liquidationPrice: 3889.12, bankruptcyPrice: 3929.01, createdAt: now - 43200000, updatedAt: now, status: 'open' },
  { id: 'p3', marketId: 'sol-usdc', marketSymbol: 'SOL-PERP', side: 'long', size: 100, notionalValue: 17890.00, entryPrice: 175.23, markPrice: 178.90, leverage: 20, margin: 894.50, marginMode: 'cross', marginRatio: 40.32, unrealizedPnl: 367.00, realizedPnl: 0, liquidationPrice: 170.12, bankruptcyPrice: 168.90, createdAt: now - 21600000, updatedAt: now, status: 'open' },
]

export const MOCK_ORDERS: Order[] = [
  { id: 'o1', marketId: 'btc-usdc', marketSymbol: 'BTC-PERP', type: 'limit', side: 'long', size: 0.1, price: 65000, leverage: 10, marginMode: 'isolated', status: 'pending', createdAt: now - 3600000, reduceOnly: false, postOnly: false },
  { id: 'o2', marketId: 'eth-usdc', marketSymbol: 'ETH-PERP', type: 'stop', side: 'short', size: 10, triggerPrice: 3200, leverage: 5, marginMode: 'cross', status: 'pending', createdAt: now - 7200000, reduceOnly: false, postOnly: false },
  { id: 'o3', marketId: 'arb-usdc', marketSymbol: 'ARB-PERP', type: 'take-profit', side: 'long', size: 5000, triggerPrice: 1.50, leverage: 15, marginMode: 'isolated', status: 'pending', createdAt: now - 1800000, reduceOnly: true, postOnly: false },
]

export const MOCK_COLLATERAL: CollateralAsset[] = [
  { symbol: 'USDC', address: '0xaf88d065e77c8cC2239327C5EDb3A432268e5831', decimals: 6, balance: 25430.50, availableBalance: 18530.50, usdValue: 25430.50, usdPrice: 1.0, isYieldBearing: true, apr: 3.2 },
  { symbol: 'ETH', address: '0xEe01c0CD76354C383B8c7B4e65EA88D6B7A6D6dE', decimals: 18, balance: 2.5, availableBalance: 2.5, usdValue: 8641.95, usdPrice: 3456.78, isYieldBearing: false, apr: 0 },
  { symbol: 'BTC', address: '0x6aEf3bBBa4b207C92A1E0Fe0a7A37e256A89E3b4', decimals: 8, balance: 0.15, availableBalance: 0.15, usdValue: 10131.35, usdPrice: 67542.30, isYieldBearing: false, apr: 0 },
  { symbol: 'ARB', address: '0x912CE59144191C1204E64559FE8253a0e49E6548', decimals: 18, balance: 5000, availableBalance: 5000, usdValue: 6172.50, usdPrice: 1.2345, isYieldBearing: false, apr: 0 },
]

export const MOCK_LEADERBOARD: LeaderboardEntry[] = [
  { rank: 1, address: '0x742d35Cc6634C0532925a3b844Bc9e7595f2bD18', displayName: 'WhaleAlpha', totalPnl: 2345678.90, totalPnlPercent: 234.56, winRate: 78.5, totalTrades: 1234, volume: 89_000_000, roi: 234.56, bestTrade: 234567.00, worstTrade: -34567.00, avgHoldingTime: 43200, currentStreak: 8, isTopTrader: true },
  { rank: 2, address: '0x8ba1f109551bD432803012645Ac136ddd64DBA72', displayName: 'DegenMaster', totalPnl: 1890123.45, totalPnlPercent: 189.01, winRate: 72.3, totalTrades: 987, volume: 67_000_000, roi: 189.01, bestTrade: 178900.00, worstTrade: -45678.00, avgHoldingTime: 28800, currentStreak: 3, isTopTrader: true },
  { rank: 3, address: '0xdD870fA1b7C4700F2BD7f44238821C26f7392148', displayName: 'ArbKing', totalPnl: 1567890.12, totalPnlPercent: 156.79, winRate: 69.8, totalTrades: 876, volume: 54_000_000, roi: 156.79, bestTrade: 145678.00, worstTrade: -56789.00, avgHoldingTime: 57600, currentStreak: -2, isTopTrader: true },
  { rank: 4, address: '0x583031D1113aD414F02576BD6afaBfb302140225', totalPnl: 1234567.89, totalPnlPercent: 123.46, winRate: 65.4, totalTrades: 765, volume: 43_000_000, roi: 123.46, bestTrade: 98765.00, worstTrade: -23456.00, avgHoldingTime: 36000, currentStreak: 5, isTopTrader: false },
  { rank: 5, address: '0x4B0897b0513fdC7C541B6d9D7E929C4e5364D2dB', totalPnl: 987654.32, totalPnlPercent: 98.77, winRate: 61.2, totalTrades: 654, volume: 32_000_000, roi: 98.77, bestTrade: 87654.00, worstTrade: -34567.00, avgHoldingTime: 50400, currentStreak: -1, isTopTrader: false },
  { rank: 6, address: '0x14723A09ACff6D2A60DcdF7aA4AFf308F36C2810', totalPnl: 876543.21, totalPnlPercent: 87.65, winRate: 58.9, totalTrades: 543, volume: 28_000_000, roi: 87.65, bestTrade: 76543.00, worstTrade: -45678.00, avgHoldingTime: 43200, currentStreak: 2, isTopTrader: false },
  { rank: 7, address: '0xCA35b7d915458EF540aDe6068dFe2F44E8fa733c', totalPnl: 765432.10, totalPnlPercent: 76.54, winRate: 55.7, totalTrades: 432, volume: 21_000_000, roi: 76.54, bestTrade: 65432.00, worstTrade: -56789.00, avgHoldingTime: 64800, currentStreak: -3, isTopTrader: false },
  { rank: 8, address: '0x1aE0EA34a72D944a8C7603FfB3eC30a6669E454C', totalPnl: 654321.00, totalPnlPercent: 65.43, winRate: 53.4, totalTrades: 321, volume: 15_000_000, roi: 65.43, bestTrade: 54321.00, worstTrade: -67890.00, avgHoldingTime: 72000, currentStreak: 1, isTopTrader: false },
  { rank: 9, address: '0x0A098Eda01Ce92ff4A4CCb7A4fFFb5A43EBC70DC', totalPnl: 543210.98, totalPnlPercent: 54.32, winRate: 51.1, totalTrades: 210, volume: 9_000_000, roi: 54.32, bestTrade: 43210.00, worstTrade: -23456.00, avgHoldingTime: 86400, currentStreak: 0, isTopTrader: false },
  { rank: 10, address: '0x5B38Da6a701c568545dCfcB03FcB875f56beddC4', totalPnl: 432109.87, totalPnlPercent: 43.21, winRate: 48.8, totalTrades: 198, volume: 7_500_000, roi: 43.21, bestTrade: 32109.00, worstTrade: -12345.00, avgHoldingTime: 100800, currentStreak: -4, isTopTrader: false },
]

export const MOCK_ACCOUNT_EVENTS: AccountEvent[] = [
  { id: 'evt-1', type: 'deposit', asset: 'USDC', amount: 25000, balanceAfter: 25430.50, timestamp: now - 86400000 * 3, txHash: '0xabc123...def456' },
  { id: 'evt-2', type: 'trade', market: 'BTC-PERP', asset: 'USDC', amount: -156.78, balanceAfter: 25273.72, timestamp: now - 86400000 * 2, txHash: '0xdef456...ghi789' },
  { id: 'evt-3', type: 'trade', market: 'ETH-PERP', asset: 'USDC', amount: 555.55, balanceAfter: 25829.27, timestamp: now - 86400000, txHash: '0xghi789...jkl012' },
  { id: 'evt-4', type: 'funding', asset: 'USDC', amount: -12.34, balanceAfter: 25816.93, timestamp: now - 43200000, txHash: '0xjkl012...mno345' },
  { id: 'evt-5', type: 'trade', market: 'SOL-PERP', asset: 'USDC', amount: 367.00, balanceAfter: 26183.93, timestamp: now - 21600000, txHash: '0xmno345...pqr678' },
  { id: 'evt-6', type: 'deposit', asset: 'ETH', amount: 2.5, balanceAfter: 2.5, timestamp: now - 172800000, txHash: '0xpqr678...stu901' },
]

export const MOCK_SYSTEM_HEALTH: SystemHealth = {
  status: 'online',
  blockHeight: 234567890,
  blockLatency: 120,
  indexerLag: 2,
  oracleFreshness: 5,
  mempoolSize: 234,
  gasPrice: 0.12,
  sequencerHealth: 99.98,
  lastChecked: now,
}

export const MARKET_STATS_24H: MarketStat24h = {
  totalVolume: 2_301_234_567,
  totalTrades: 156_789,
  totalFees: 1_150_617,
  avgTradeSize: 14_678,
  activeTraders: 12_345,
  newAccounts: 234,
  totalOpenInterest: 1_890_000_000,
  liquidationVolume: 45_678_900,
  fundingCollected: 890_123,
}

export const MOCK_LIQUIDATION_EVENTS: LiquidationEvent[] = [
  { id: 'liq-1', marketSymbol: 'BTC-PERP', side: 'short', size: 0.8, price: 68100.00, value: 54480.00, fee: 272.40, timestamp: now - 120000, status: 'full' },
  { id: 'liq-2', marketSymbol: 'ETH-PERP', side: 'long', size: 25, price: 3420.50, value: 85512.50, fee: 427.56, timestamp: now - 900000, status: 'full' },
  { id: 'liq-3', marketSymbol: 'SOL-PERP', side: 'long', size: 500, price: 176.40, value: 88200.00, fee: 441.00, timestamp: now - 3600000, status: 'partial' },
  { id: 'liq-4', marketSymbol: 'ARB-PERP', side: 'long', size: 150000, price: 1.19, value: 178500.00, fee: 892.50, timestamp: now - 7200000, status: 'full' },
  { id: 'liq-5', marketSymbol: 'LINK-PERP', side: 'short', size: 8000, price: 18.90, value: 151200.00, fee: 756.00, timestamp: now - 14400000, status: 'full' },
  { id: 'liq-6', marketSymbol: 'GMX-PERP', side: 'long', size: 200, price: 33.80, value: 6760.00, fee: 33.80, timestamp: now - 21600000, status: 'full' },
  { id: 'liq-7', marketSymbol: 'BTC-PERP', side: 'long', size: 0.3, price: 66200.00, value: 19860.00, fee: 99.30, timestamp: now - 28800000, status: 'full' },
  { id: 'liq-8', marketSymbol: 'ETH-PERP', side: 'short', size: 100, price: 3490.00, value: 349000.00, fee: 1745.00, timestamp: now - 43200000, status: 'adl' },
]

export function generateOrderBook(midPrice: number, spread = 0.001): { bids: OrderBookLevel[]; asks: OrderBookLevel[] } {
  const bids: OrderBookLevel[] = []
  const asks: OrderBookLevel[] = []
  let bidTotal = 0
  let askTotal = 0
  for (let i = 0; i < 20; i++) {
    const bidPrice = midPrice * (1 - spread * (i + 1))
    const askPrice = midPrice * (1 + spread * (i + 1))
    const bidSize = Math.random() * 10 + 0.5
    const askSize = Math.random() * 10 + 0.5
    bidTotal += bidSize
    askTotal += askSize
    bids.push({ price: bidPrice, size: bidSize, total: bidTotal, depth: bidTotal * midPrice })
    asks.push({ price: askPrice, size: askSize, total: askTotal, depth: askTotal * midPrice })
  }
  return { bids, asks }
}

export function generateCandlestickData(basePrice: number, count = 200) {
  const data = []
  let price = basePrice * 0.8
  const nowSec = Math.floor(now / 1000)
  for (let i = 0; i < count; i++) {
    const open = price
    const change = (Math.random() - 0.48) * price * 0.02
    const close = open + change
    const high = Math.max(open, close) * (1 + Math.random() * 0.005)
    const low = Math.min(open, close) * (1 - Math.random() * 0.005)
    data.push({
      time: nowSec - (count - i) * 3600,
      open: +open.toFixed(2),
      high: +high.toFixed(2),
      low: +low.toFixed(2),
      close: +close.toFixed(2),
    })
    price = close
  }
  return data
}

export function generateFundingHistory(baseRate: number): FundingRateHistory[] {
  const history: FundingRateHistory[] = []
  for (let i = 24; i >= 0; i--) {
    const rate = baseRate * (0.5 + Math.random())
    history.push({
      timestamp: now - i * 3600000,
      rate,
      annualized: rate * 3 * 365,
    })
  }
  return history
}
