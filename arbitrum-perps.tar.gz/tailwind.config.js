/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: {
          primary: '#0a0e17',
          secondary: '#111827',
          tertiary: '#1a2035',
          hover: '#1e293b',
        },
        accent: {
          green: '#00e676',
          red: '#ff1744',
          blue: '#2979ff',
          yellow: '#ffd600',
          purple: '#7c4dff',
        },
        text: {
          primary: '#e2e8f0',
          secondary: '#94a3b8',
          muted: '#64748b',
        },
        border: {
          primary: '#1e293b',
          secondary: '#334155',
        },
      },
      fontFamily: {
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
    },
  },
  plugins: [],
}
