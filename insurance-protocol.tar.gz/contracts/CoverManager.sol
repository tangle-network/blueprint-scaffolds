// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface ICapitalPool {
    function reserveLiquidity(bytes32 riskPoolId, uint256 amount) external;
    function releaseLiquidity(bytes32 riskPoolId, uint256 amount) external;
}

contract CoverManager {
    struct ProductRisk {
        bytes32 id;
        string protocolName;
        string riskType;
        uint64 utilizationBps;
        uint64 historicalLossBps;
        uint64 oracleStrengthBps;
        uint64 auditScoreBps;
        uint128 maxCapacity;
        bool active;
    }

    struct Policy {
        uint256 id;
        address holder;
        bytes32 productId;
        uint128 coverageAmount;
        uint64 premiumBps;
        uint64 durationDays;
        uint64 startTimestamp;
        bool claimed;
        bool active;
    }

    event ProductConfigured(bytes32 indexed productId, string protocolName, string riskType);
    event PolicyPurchased(uint256 indexed policyId, address indexed holder, bytes32 indexed productId, uint256 coverageAmount, uint256 premium);
    event PolicyCancelled(uint256 indexed policyId, address indexed holder);

    address public owner;
    ICapitalPool public immutable capitalPool;
    uint256 public nextPolicyId = 1;

    mapping(bytes32 => ProductRisk) public products;
    mapping(uint256 => Policy) public policies;

    modifier onlyOwner() {
        require(msg.sender == owner, "not owner");
        _;
    }

    constructor(address capitalPool_) {
        owner = msg.sender;
        capitalPool = ICapitalPool(capitalPool_);
    }

    function configureProduct(ProductRisk calldata config) external onlyOwner {
        require(config.id != bytes32(0), "invalid id");
        require(config.maxCapacity > 0, "invalid capacity");
        products[config.id] = config;
        emit ProductConfigured(config.id, config.protocolName, config.riskType);
    }

    function quotePremium(bytes32 productId, uint256 coverageAmount, uint256 durationDays) public view returns (uint256 premium, uint256 premiumBps) {
        ProductRisk memory product = products[productId];
        require(product.active, "inactive product");
        require(coverageAmount <= product.maxCapacity, "coverage too high");

        uint256 baseRateBps = 320;
        uint256 utilizationLoad = 10_000 + (uint256(product.utilizationBps) * 65 / 100);
        uint256 lossLoad = 10_000 + uint256(product.historicalLossBps) * 12;
        uint256 controlsDiscount = 10_000 - ((uint256(product.auditScoreBps) * 18 / 100) + (uint256(product.oracleStrengthBps) * 8 / 100));
        if (controlsDiscount < 6_200) {
            controlsDiscount = 6_200;
        }

        premiumBps = baseRateBps * utilizationLoad / 10_000;
        premiumBps = premiumBps * lossLoad / 10_000;
        premiumBps = premiumBps * controlsDiscount / 10_000;
        premium = coverageAmount * premiumBps * durationDays / 365 / 10_000;
    }

    function purchasePolicy(bytes32 productId, uint128 coverageAmount, uint64 durationDays) external payable returns (uint256 policyId) {
        (uint256 premium, uint256 premiumBps) = quotePremium(productId, coverageAmount, durationDays);
        require(msg.value >= premium, "insufficient premium");

        ProductRisk memory product = products[productId];
        capitalPool.reserveLiquidity(productId, coverageAmount);

        policyId = nextPolicyId++;
        policies[policyId] = Policy({
            id: policyId,
            holder: msg.sender,
            productId: productId,
            coverageAmount: coverageAmount,
            premiumBps: uint64(premiumBps),
            durationDays: durationDays,
            startTimestamp: uint64(block.timestamp),
            claimed: false,
            active: true
        });

        emit PolicyPurchased(policyId, msg.sender, productId, coverageAmount, premium);
    }

    function cancelExpiredPolicy(uint256 policyId) external {
        Policy storage policy = policies[policyId];
        require(policy.active, "inactive policy");
        require(block.timestamp > policy.startTimestamp + uint256(policy.durationDays) * 1 days, "not expired");
        policy.active = false;
        capitalPool.releaseLiquidity(policy.productId, policy.coverageAmount);
        emit PolicyCancelled(policyId, policy.holder);
    }
}
