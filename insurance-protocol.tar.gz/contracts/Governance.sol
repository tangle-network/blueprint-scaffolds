// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IClaimsProcessorAdmin {
    function setVotingPower(address voter, uint256 power) external;
}

contract Governance {
    struct Proposal {
        uint256 id;
        string description;
        address target;
        bytes data;
        uint64 deadline;
        uint128 yesVotes;
        uint128 noVotes;
        bool executed;
    }

    event ProposalCreated(uint256 indexed proposalId, string description);
    event ProposalVoted(uint256 indexed proposalId, address indexed voter, bool support, uint256 weight);
    event ProposalExecuted(uint256 indexed proposalId);

    uint256 public nextProposalId = 1;
    mapping(uint256 => Proposal) public proposals;
    mapping(uint256 => mapping(address => bool)) public voted;
    mapping(address => uint256) public governancePower;

    function seedVotingPower(address voter, uint256 power) external {
        governancePower[voter] = power;
    }

    function createProposal(string calldata description, address target, bytes calldata data) external returns (uint256 proposalId) {
        require(governancePower[msg.sender] > 0, "no power");
        proposalId = nextProposalId++;
        proposals[proposalId] = Proposal({
            id: proposalId,
            description: description,
            target: target,
            data: data,
            deadline: uint64(block.timestamp + 5 days),
            yesVotes: 0,
            noVotes: 0,
            executed: false
        });

        emit ProposalCreated(proposalId, description);
    }

    function vote(uint256 proposalId, bool support) external {
        Proposal storage proposal = proposals[proposalId];
        require(proposal.id != 0, "proposal missing");
        require(block.timestamp < proposal.deadline, "proposal closed");
        require(!voted[proposalId][msg.sender], "already voted");

        uint256 weight = governancePower[msg.sender];
        require(weight > 0, "no power");
        voted[proposalId][msg.sender] = true;

        if (support) {
            proposal.yesVotes += uint128(weight);
        } else {
            proposal.noVotes += uint128(weight);
        }

        emit ProposalVoted(proposalId, msg.sender, support, weight);
    }

    function execute(uint256 proposalId) external {
        Proposal storage proposal = proposals[proposalId];
        require(proposal.id != 0, "proposal missing");
        require(block.timestamp >= proposal.deadline, "proposal active");
        require(!proposal.executed, "already executed");
        require(proposal.yesVotes > proposal.noVotes, "proposal rejected");

        proposal.executed = true;
        (bool success, ) = proposal.target.call(proposal.data);
        require(success, "execution failed");
        emit ProposalExecuted(proposalId);
    }

    function grantClaimsAssessorPower(address claimsProcessor, address assessor, uint256 power) external {
        require(governancePower[msg.sender] > 0, "no power");
        IClaimsProcessorAdmin(claimsProcessor).setVotingPower(assessor, power);
    }
}
