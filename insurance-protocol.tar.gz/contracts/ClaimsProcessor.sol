// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface ICoverRegistry {
    function policies(uint256 policyId) external view returns (
        uint256 id,
        address holder,
        bytes32 productId,
        uint128 coverageAmount,
        uint64 premiumBps,
        uint64 durationDays,
        uint64 startTimestamp,
        bool claimed,
        bool active
    );
}

interface IClaimPool {
    function payClaim(bytes32 riskPoolId, address payable claimant, uint256 amount) external;
}

contract ClaimsProcessor {
    struct Claim {
        uint256 id;
        uint256 policyId;
        address claimant;
        uint128 requestedAmount;
        uint128 yesVotes;
        uint128 noVotes;
        uint64 openedAt;
        bool resolved;
        bool approved;
    }

    event ClaimSubmitted(uint256 indexed claimId, uint256 indexed policyId, address indexed claimant, uint256 amount);
    event VoteCast(uint256 indexed claimId, address indexed voter, bool support, uint256 weight);
    event ClaimResolved(uint256 indexed claimId, bool approved);

    address public governance;
    ICoverRegistry public immutable coverManager;
    IClaimPool public immutable capitalPool;
    uint256 public nextClaimId = 1;

    mapping(uint256 => Claim) public claims;
    mapping(uint256 => mapping(address => bool)) public hasVoted;
    mapping(address => uint256) public votingPower;

    modifier onlyGovernance() {
        require(msg.sender == governance, "not governance");
        _;
    }

    constructor(address coverManager_, address capitalPool_) {
        governance = msg.sender;
        coverManager = ICoverRegistry(coverManager_);
        capitalPool = IClaimPool(capitalPool_);
    }

    function setVotingPower(address voter, uint256 power) external onlyGovernance {
        votingPower[voter] = power;
    }

    function submitClaim(uint256 policyId, uint128 requestedAmount) external returns (uint256 claimId) {
        (, address holder, bytes32 productId, uint128 coverageAmount, , , , bool claimed, bool active) = coverManager.policies(policyId);
        require(active, "policy inactive");
        require(holder == msg.sender, "not policy holder");
        require(!claimed, "policy already claimed");
        require(requestedAmount <= coverageAmount, "amount exceeds cover");
        require(productId != bytes32(0), "invalid product");

        claimId = nextClaimId++;
        claims[claimId] = Claim({
            id: claimId,
            policyId: policyId,
            claimant: msg.sender,
            requestedAmount: requestedAmount,
            yesVotes: 0,
            noVotes: 0,
            openedAt: uint64(block.timestamp),
            resolved: false,
            approved: false
        });

        emit ClaimSubmitted(claimId, policyId, msg.sender, requestedAmount);
    }

    function vote(uint256 claimId, bool support) external {
        Claim storage claim = claims[claimId];
        require(claim.id != 0, "claim missing");
        require(!claim.resolved, "claim resolved");
        require(!hasVoted[claimId][msg.sender], "already voted");

        uint256 weight = votingPower[msg.sender];
        require(weight > 0, "no voting power");
        hasVoted[claimId][msg.sender] = true;

        if (support) {
            claim.yesVotes += uint128(weight);
        } else {
            claim.noVotes += uint128(weight);
        }

        emit VoteCast(claimId, msg.sender, support, weight);
    }

    function resolveClaim(uint256 claimId) external {
        Claim storage claim = claims[claimId];
        require(claim.id != 0, "claim missing");
        require(!claim.resolved, "already resolved");
        require(block.timestamp >= claim.openedAt + 3 days, "voting active");

        claim.resolved = true;
        claim.approved = claim.yesVotes > claim.noVotes;
        emit ClaimResolved(claimId, claim.approved);

        if (claim.approved) {
            (, , bytes32 productId, , , , , , ) = coverManager.policies(claim.policyId);
            capitalPool.payClaim(productId, payable(claim.claimant), claim.requestedAmount);
        }
    }
}
