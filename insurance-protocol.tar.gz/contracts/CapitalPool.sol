// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract CapitalPool {
    struct PoolConfig {
        bytes32 riskPoolId;
        uint128 totalCapital;
        uint128 reservedCapital;
        uint64 utilizationBps;
        bool active;
    }

    event Deposited(bytes32 indexed riskPoolId, address indexed provider, uint256 amount);
    event LiquidityReserved(bytes32 indexed riskPoolId, uint256 amount);
    event LiquidityReleased(bytes32 indexed riskPoolId, uint256 amount);
    event ClaimPaid(bytes32 indexed riskPoolId, address indexed claimant, uint256 amount);

    address public coverManager;
    address public claimsProcessor;
    mapping(bytes32 => PoolConfig) public pools;
    mapping(bytes32 => mapping(address => uint256)) public lpBalance;

    modifier onlyAuthorized() {
        require(msg.sender == coverManager || msg.sender == claimsProcessor, "not authorized");
        _;
    }

    constructor(address coverManager_, address claimsProcessor_) {
        coverManager = coverManager_;
        claimsProcessor = claimsProcessor_;
    }

    function configurePool(bytes32 riskPoolId, uint128 seedCapital) external {
        PoolConfig storage pool = pools[riskPoolId];
        pool.riskPoolId = riskPoolId;
        pool.totalCapital = seedCapital;
        pool.active = true;
    }

    function deposit(bytes32 riskPoolId) external payable {
        PoolConfig storage pool = pools[riskPoolId];
        require(pool.active, "pool inactive");
        pool.totalCapital += uint128(msg.value);
        lpBalance[riskPoolId][msg.sender] += msg.value;
        emit Deposited(riskPoolId, msg.sender, msg.value);
    }

    function reserveLiquidity(bytes32 riskPoolId, uint256 amount) external onlyAuthorized {
        PoolConfig storage pool = pools[riskPoolId];
        require(pool.active, "pool inactive");
        require(pool.totalCapital >= pool.reservedCapital + amount, "insufficient capital");
        pool.reservedCapital += uint128(amount);
        pool.utilizationBps = uint64(uint256(pool.reservedCapital) * 10_000 / pool.totalCapital);
        emit LiquidityReserved(riskPoolId, amount);
    }

    function releaseLiquidity(bytes32 riskPoolId, uint256 amount) external onlyAuthorized {
        PoolConfig storage pool = pools[riskPoolId];
        require(pool.reservedCapital >= amount, "reserve underflow");
        pool.reservedCapital -= uint128(amount);
        pool.utilizationBps = pool.totalCapital == 0 ? 0 : uint64(uint256(pool.reservedCapital) * 10_000 / pool.totalCapital);
        emit LiquidityReleased(riskPoolId, amount);
    }

    function payClaim(bytes32 riskPoolId, address payable claimant, uint256 amount) external onlyAuthorized {
        PoolConfig storage pool = pools[riskPoolId];
        require(pool.reservedCapital >= amount, "insufficient reserve");
        pool.reservedCapital -= uint128(amount);
        pool.totalCapital -= uint128(amount);
        pool.utilizationBps = pool.totalCapital == 0 ? 0 : uint64(uint256(pool.reservedCapital) * 10_000 / pool.totalCapital);
        (bool sent, ) = claimant.call{value: amount}("");
        require(sent, "transfer failed");
        emit ClaimPaid(riskPoolId, claimant, amount);
    }
}
