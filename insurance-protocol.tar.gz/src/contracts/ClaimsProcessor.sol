// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IERC20 {
    function transfer(address, uint256) external returns (bool);
}

interface ICoverManager {
    function getPolicy(uint256 policyId) external view returns (
        uint256 id,
        address policyholder,
        address protocol,
        uint8 category,
        uint256 coverageAmount,
        uint256 premium,
        uint256 premiumRateBps,
        uint256 startTime,
        uint256 endTime,
        uint8 status,
        uint8 claimCount
    );
    function markClaimed(uint256 policyId) external;
    function isPolicyActive(uint256 policyId) external view returns (bool);
}

interface ICapitalPool {
    function payClaim(address recipient, uint256 amount) external;
}

enum ClaimStatus {
    SUBMITTED,
    VOTING,
    APPROVED,
    REJECTED,
    PAID
}

struct Claim {
    uint256 id;
    uint256 policyId;
    address claimant;
    uint256 amount;
    bytes32 evidenceHash;
    ClaimStatus status;
    uint256 submittedAt;
    uint256 votingEndTime;
    uint256 votesFor;
    uint256 votesAgainst;
    uint256 voterCount;
    string description;
}

contract ClaimsProcessor {
    ICoverManager public coverManager;
    ICapitalPool public capitalPool;
    IERC20 public immutable usdc;

    address public owner;

    uint256 public nextClaimId = 1;
    uint256 public constant VOTING_PERIOD = 7 days;
    uint256 public constant QUORUM_BPS = 1000; // 10% of governance token supply
    uint256 public constant PASS_THRESHOLD_BPS = 6000; // 60% must vote yes
    uint256 public constant MAX_CLAIM_RATIO = 100; // 100% of coverage amount

    mapping(uint256 => Claim) public claims;
    mapping(uint256 => mapping(address => bool)) public hasVoted;
    mapping(address => uint256[]) public claimantClaims;

    mapping(address => uint256) public votingPower;

    event ClaimSubmitted(uint256 indexed claimId, uint256 indexed policyId, address claimant, uint256 amount);
    event VoteCast(uint256 indexed claimId, address voter, bool support, uint256 weight);
    event ClaimApproved(uint256 indexed claimId, uint256 amount);
    event ClaimRejected(uint256 indexed claimId);
    event ClaimPaid(uint256 indexed claimId, address recipient, uint256 amount);

    modifier onlyGovernance() {
        require(msg.sender == owner, "Only governance");
        _;
    }

    constructor(address _coverManager, address _capitalPool, address _usdc) {
        coverManager = ICoverManager(_coverManager);
        capitalPool = ICapitalPool(_capitalPool);
        usdc = IERC20(_usdc);
        owner = msg.sender;
    }

    function submitClaim(
        uint256 policyId,
        uint256 amount,
        bytes32 evidenceHash,
        string calldata description
    ) external returns (uint256 claimId) {
        require(coverManager.isPolicyActive(policyId), "Policy not active");

        (
            ,,address protocol,,,,,uint256 startTime, uint256 endTime,, uint8 claimCount
        ) = coverManager.getPolicy(policyId);

        require(amount > 0, "Zero amount");
        require(bytes(description).length > 0, "Description required");
        require(evidenceHash != bytes32(0), "Evidence required");
        require(claimCount < 3, "Max claims reached");

        claimId = nextClaimId++;

        Claim storage c = claims[claimId];
        c.id = claimId;
        c.policyId = policyId;
        c.claimant = msg.sender;
        c.amount = amount;
        c.evidenceHash = evidenceHash;
        c.status = ClaimStatus.VOTING;
        c.submittedAt = block.timestamp;
        c.votingEndTime = block.timestamp + VOTING_PERIOD;
        c.votesFor = 0;
        c.votesAgainst = 0;
        c.voterCount = 0;
        c.description = description;

        claimantClaims[msg.sender].push(claimId);

        emit ClaimSubmitted(claimId, policyId, msg.sender, amount);
    }

    function castVote(uint256 claimId, bool support) external {
        Claim storage c = claims[claimId];
        require(c.status == ClaimStatus.VOTING, "Not in voting");
        require(block.timestamp < c.votingEndTime, "Voting ended");
        require(!hasVoted[claimId][msg.sender], "Already voted");

        uint256 weight = votingPower[msg.sender];
        require(weight > 0, "No voting power");

        hasVoted[claimId][msg.sender] = true;
        c.voterCount++;

        if (support) {
            c.votesFor += weight;
        } else {
            c.votesAgainst += weight;
        }

        emit VoteCast(claimId, msg.sender, support, weight);
    }

    function resolveClaim(uint256 claimId) external {
        Claim storage c = claims[claimId];
        require(c.status == ClaimStatus.VOTING, "Not in voting");
        require(block.timestamp >= c.votingEndTime, "Voting not ended");

        uint256 totalVotes = c.votesFor + c.votesAgainst;
        require(totalVotes > 0, "No votes");

        bool approved = (c.votesFor * 10_000) / totalVotes >= PASS_THRESHOLD_BPS;

        if (approved) {
            c.status = ClaimStatus.APPROVED;
            emit ClaimApproved(claimId, c.amount);
        } else {
            c.status = ClaimStatus.REJECTED;
            emit ClaimRejected(claimId);
        }
    }

    function executePayout(uint256 claimId) external onlyGovernance {
        Claim storage c = claims[claimId];
        require(c.status == ClaimStatus.APPROVED, "Not approved");

        c.status = ClaimStatus.PAID;
        coverManager.markClaimed(c.policyId);
        capitalPool.payClaim(c.claimant, c.amount);

        emit ClaimPaid(claimId, c.claimant, c.amount);
    }

    function setVotingPower(address voter, uint256 power) external onlyGovernance {
        votingPower[voter] = power;
    }

    function getClaim(uint256 claimId) external view returns (Claim memory) {
        return claims[claimId];
    }

    function getClaimsByClaimant(address claimant) external view returns (uint256[] memory) {
        return claimantClaims[claimant];
    }
}
