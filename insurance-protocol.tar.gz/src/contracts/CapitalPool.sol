// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IERC20 {
    function transfer(address, uint256) external returns (bool);
    function transferFrom(address, address, uint256) external returns (bool);
    function balanceOf(address) external view returns (uint256);
}

contract CapitalPool {
    IERC20 public immutable usdc;

    address public owner;
    address public coverManager;
    address public claimsProcessor;

    uint256 public totalCapacity;
    uint256 public lockedCapacity;
    uint256 public totalPremiumsCollected;
    uint256 public totalClaimsPaid;

    mapping(address => uint256) public depositorShares;
    mapping(address => uint256) public depositorDeposit;
    uint256 public totalShares;
    uint256 public totalDeposits;

    uint256 public constant TARGET_RESERVE_RATIO = 2; // 200% reserve
    uint256 public constant MAX_UTILIZATION_BPS = 8000; // 80% max
    uint256 public constant PROTOCOL_FEE_BPS = 1000; // 10% of premiums

    event Deposited(address indexed depositor, uint256 amount, uint256 shares);
    event Withdrawn(address indexed depositor, uint256 amount, uint256 shares);
    event CapacityLocked(uint256 amount);
    event CapacityReleased(uint256 amount);
    event ClaimPaid(address indexed recipient, uint256 amount);
    event PremiumCollected(uint256 amount);

    modifier onlyCoverManager() {
        require(msg.sender == coverManager, "Only CoverManager");
        _;
    }

    modifier onlyClaimsProcessor() {
        require(msg.sender == claimsProcessor, "Only ClaimsProcessor");
        _;
    }

    modifier onlyGovernance() {
        require(msg.sender == owner, "Only governance");
        _;
    }

    constructor(address _usdc) {
        usdc = IERC20(_usdc);
        owner = msg.sender;
    }

    function setCoverManager(address _coverManager) external onlyGovernance {
        coverManager = _coverManager;
    }

    function setClaimsProcessor(address _claimsProcessor) external onlyGovernance {
        claimsProcessor = _claimsProcessor;
    }

    function deposit(uint256 amount) external returns (uint256 shares) {
        require(amount > 0, "Zero deposit");
        require(usdc.transferFrom(msg.sender, address(this), amount), "Transfer failed");

        if (totalShares == 0) {
            shares = amount;
        } else {
            shares = (amount * totalShares) / totalDeposits;
        }

        depositorShares[msg.sender] += shares;
        depositorDeposit[msg.sender] += amount;
        totalShares += shares;
        totalDeposits += amount;
        totalCapacity += amount;

        emit Deposited(msg.sender, amount, shares);
    }

    function withdraw(uint256 shareAmount) external returns (uint256 amount) {
        require(depositorShares[msg.sender] >= shareAmount, "Insufficient shares");
        require(getAvailableCapacity() >= amount, "Insufficient available capacity");

        amount = (shareAmount * totalDeposits) / totalShares;

        depositorShares[msg.sender] -= shareAmount;
        depositorDeposit[msg.sender] -= amount;
        totalShares -= shareAmount;
        totalDeposits -= amount;
        totalCapacity -= amount;

        require(usdc.transfer(msg.sender, amount), "Transfer failed");

        emit Withdrawn(msg.sender, amount, shareAmount);
    }

    function lockCapacity(uint256 amount) external onlyCoverManager {
        require(getAvailableCapacity() >= amount, "Insufficient capacity");
        lockedCapacity += amount;
        emit CapacityLocked(amount);
    }

    function releaseCapacity(uint256 amount) external onlyCoverManager {
        require(lockedCapacity >= amount, "Underflow");
        lockedCapacity -= amount;
        emit CapacityReleased(amount);
    }

    function collectPremium(uint256 amount) external onlyCoverManager {
        require(usdc.transferFrom(msg.sender, address(this), amount), "Transfer failed");
        totalPremiumsCollected += amount;

        uint256 fee = (amount * PROTOCOL_FEE_BPS) / 10_000;
        totalDeposits += (amount - fee);

        emit PremiumCollected(amount);
    }

    function payClaim(address recipient, uint256 amount) external onlyClaimsProcessor {
        require(lockedCapacity >= amount, "Exceeds locked");
        require(usdc.transfer(recipient, amount), "Transfer failed");

        lockedCapacity -= amount;
        totalDeposits -= amount;
        totalClaimsPaid += amount;

        emit ClaimPaid(recipient, amount);
    }

    function getAvailableCapacity() public view returns (uint256) {
        return totalCapacity - lockedCapacity;
    }

    function getUtilizationRate() external view returns (uint256) {
        if (totalCapacity == 0) return 0;
        return (lockedCapacity * 10_000) / totalCapacity;
    }

    function getReserveRatio() external view returns (uint256) {
        if (lockedCapacity == 0) return type(uint256).max;
        return ((totalCapacity - lockedCapacity) * 100) / lockedCapacity;
    }

    function getDepositorValue(address depositor) external view returns (uint256) {
        if (totalShares == 0) return 0;
        return (depositorShares[depositor] * totalDeposits) / totalShares;
    }

    function getStakingAPR() external view returns (uint256) {
        if (totalDeposits == 0) return 0;
        uint256 yearlyPremiumsEstimate = totalPremiumsCollected * 12;
        uint256 depositorShare = (yearlyPremiumsEstimate * (10_000 - PROTOCOL_FEE_BPS)) / 10_000;
        return (depositorShare * 10_000) / totalDeposits;
    }
}
