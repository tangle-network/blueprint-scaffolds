// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IERC20 {
    function transfer(address, uint256) external returns (bool);
    function transferFrom(address, address, uint256) external returns (bool);
    function balanceOf(address) external view returns (uint256);
    function approve(address, uint256) external returns (bool);
}

interface ICapitalPool {
    function lockCapacity(uint256 amount) external;
    function releaseCapacity(uint256 amount) external;
    function payClaim(address recipient, uint256 amount) external;
    function getAvailableCapacity() external view returns (uint256);
    function getTotalCapacity() external view returns (uint256);
}

interface IClaimsProcessor {
    function submitClaim(
        uint256 policyId,
        uint256 amount,
        bytes32 evidenceHash
    ) external returns (uint256 claimId);
}

enum RiskCategory {
    SMART_CONTRACT_BUG,
    ORACLE_FAILURE,
    STABLECOIN_DEPEG,
    SLASHING_EVENT
}

enum PolicyStatus {
    ACTIVE,
    EXPIRED,
    CLAIMED,
    CANCELLED
}

struct Policy {
    uint256 id;
    address policyholder;
    address protocol;
    RiskCategory category;
    uint256 coverageAmount;
    uint256 premium;
    uint256 premiumRateBps;
    uint256 startTime;
    uint256 endTime;
    PolicyStatus status;
    uint8 claimCount;
}

contract CoverManager {
    IERC20 public immutable usdc;
    ICapitalPool public capitalPool;
    IClaimsProcessor public claimsProcessor;

    uint256 public nextPolicyId = 1;
    uint256 public constant MIN_COVERAGE = 1_000e6;
    uint256 public constant MAX_COVERAGE = 50_000_000e6;
    uint256 public constant MIN_DURATION = 30 days;
    uint256 public constant MAX_DURATION = 365 days;
    uint256 public constant MAX_CLAIMS_PER_POLICY = 3;

    mapping(uint256 => Policy) public policies;
    mapping(address => uint256[]) public policyholderPolicies;
    mapping(address => bool) public whitelistedProtocols;
    mapping(address => mapping(RiskCategory => uint256)) public protocolPremiumRates;

    event PolicyCreated(uint256 indexed policyId, address indexed policyholder, uint256 coverageAmount, uint256 premium);
    PolicyExpired event PolicyExpired(uint256 indexed policyId);
    event PolicyCancelled(uint256 indexed policyId, uint256 refund);
    event ProtocolWhitelisted(address indexed protocol, bool status);

    modifier onlyGovernance() {
        require(msg.sender == owner, "Only governance");
        _;
    }

    address public owner;

    constructor(address _usdc, address _capitalPool, address _claimsProcessor) {
        usdc = IERC20(_usdc);
        capitalPool = ICapitalPool(_capitalPool);
        claimsProcessor = IClaimsProcessor(_claimsProcessor);
        owner = msg.sender;
    }

    function purchaseCover(
        address protocol,
        RiskCategory category,
        uint256 coverageAmount,
        uint256 durationDays
    ) external returns (uint256 policyId) {
        require(whitelistedProtocols[protocol], "Protocol not whitelisted");
        require(coverageAmount >= MIN_COVERAGE && coverageAmount <= MAX_COVERAGE, "Coverage out of range");
        require(durationDays >= 30 && durationDays <= 365, "Duration out of range");

        uint256 rateBps = protocolPremiumRates[protocol][category];
        require(rateBps > 0, "Category not available");

        uint256 duration = durationDays * 1 days;
        uint256 premium = (coverageAmount * rateBps * durationDays) / (10_000 * 365);

        require(usdc.transferFrom(msg.sender, address(capitalPool), premium), "Premium transfer failed");
        require(capitalPool.getAvailableCapacity() >= coverageAmount, "Insufficient capacity");

        capitalPool.lockCapacity(coverageAmount);

        policyId = nextPolicyId++;
        Policy storage p = policies[policyId];
        p.id = policyId;
        p.policyholder = msg.sender;
        p.protocol = protocol;
        p.category = category;
        p.coverageAmount = coverageAmount;
        p.premium = premium;
        p.premiumRateBps = rateBps;
        p.startTime = block.timestamp;
        p.endTime = block.timestamp + duration;
        p.status = PolicyStatus.ACTIVE;
        p.claimCount = 0;

        policyholderPolicies[msg.sender].push(policyId);

        emit PolicyCreated(policyId, msg.sender, coverageAmount, premium);
    }

    function cancelPolicy(uint256 policyId) external {
        Policy storage p = policies[policyId];
        require(p.policyholder == msg.sender, "Not policyholder");
        require(p.status == PolicyStatus.ACTIVE, "Not active");

        uint256 remaining = p.endTime - block.timestamp;
        uint256 totalDuration = p.endTime - p.startTime;
        uint256 refund = (p.premium * remaining) / totalDuration;

        p.status = PolicyStatus.CANCELLED;
        capitalPool.releaseCapacity(p.coverageAmount);

        if (refund > 0) {
            usdc.transfer(msg.sender, refund);
        }

        emit PolicyCancelled(policyId, refund);
    }

    function expirePolicy(uint256 policyId) external {
        Policy storage p = policies[policyId];
        require(p.status == PolicyStatus.ACTIVE, "Not active");
        require(block.timestamp >= p.endTime, "Not yet expired");

        p.status = PolicyStatus.EXPIRED;
        capitalPool.releaseCapacity(p.coverageAmount);

        emit PolicyExpired(policyId);
    }

    function markClaimed(uint256 policyId) external {
        require(msg.sender == address(claimsProcessor), "Only claims processor");
        Policy storage p = policies[policyId];
        require(p.status == PolicyStatus.ACTIVE, "Not active");
        p.claimCount++;
        if (p.claimCount >= MAX_CLAIMS_PER_POLICY) {
            p.status = PolicyStatus.CLAIMED;
            capitalPool.releaseCapacity(p.coverageAmount);
        }
    }

    function setProtocolWhitelist(address protocol, bool status) external onlyGovernance {
        whitelistedProtocols[protocol] = status;
        emit ProtocolWhitelisted(protocol, status);
    }

    function setPremiumRate(address protocol, RiskCategory category, uint256 rateBps) external onlyGovernance {
        protocolPremiumRates[protocol][category] = rateBps;
    }

    function getPolicy(uint256 policyId) external view returns (Policy memory) {
        return policies[policyId];
    }

    function getPoliciesByHolder(address holder) external view returns (uint256[] memory) {
        return policyholderPolicies[holder];
    }

    function isPolicyActive(uint256 policyId) external view returns (bool) {
        Policy storage p = policies[policyId];
        return p.status == PolicyStatus.ACTIVE && block.timestamp < p.endTime;
    }
}
