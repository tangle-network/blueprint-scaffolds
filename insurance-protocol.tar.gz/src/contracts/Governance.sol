// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IERC20 {
    function transfer(address, uint256) external returns (bool);
    function balanceOf(address) external view returns (uint256);
}

enum ProposalStatus {
    ACTIVE,
    PASSED,
    FAILED,
    EXECUTED
}

struct Proposal {
    uint256 id;
    string title;
    string description;
    address proposer;
    ProposalStatus status;
    uint256 votesFor;
    uint256 votesAgainst;
    uint256 quorumRequired;
    uint256 startTime;
    uint256 endTime;
    bytes executionData;
    address executionTarget;
    bool executed;
}

contract Governance {
    IERC20 public governanceToken;

    address public owner;
    uint256 public proposalCount;
    uint256 public constant VOTING_PERIOD = 3 days;
    uint256 public constant EXECUTION_DELAY = 1 days;
    uint256 public constant QUORUM_BPS = 400; // 4% of total supply
    uint256 public constant PASS_THRESHOLD_BPS = 6000; // 60%

    mapping(uint256 => Proposal) public proposals;
    mapping(uint256 => mapping(address => bool)) public hasVoted;
    mapping(uint256 => mapping(address => bool)) public voteSupport;

    uint256 public totalSupply;

    event ProposalCreated(uint256 indexed proposalId, address indexed proposer, string title);
    event VoteCast(uint256 indexed proposalId, address voter, bool support, uint256 weight);
    event ProposalPassed(uint256 indexed proposalId);
    event ProposalFailed(uint256 indexed proposalId);
    event ProposalExecuted(uint256 indexed proposalId);

    modifier onlyTokenHolder() {
        require(governanceToken.balanceOf(msg.sender) > 0, "No tokens");
        _;
    }

    constructor(address _governanceToken) {
        governanceToken = IERC20(_governanceToken);
        owner = msg.sender;
    }

    function createProposal(
        string calldata title,
        string calldata description,
        address executionTarget,
        bytes calldata executionData
    ) external onlyTokenHolder returns (uint256 proposalId) {
        proposalId = ++proposalCount;

        Proposal storage p = proposals[proposalId];
        p.id = proposalId;
        p.title = title;
        p.description = description;
        p.proposer = msg.sender;
        p.status = ProposalStatus.ACTIVE;
        p.votesFor = 0;
        p.votesAgainst = 0;
        p.quorumRequired = (totalSupply * QUORUM_BPS) / 10_000;
        p.startTime = block.timestamp;
        p.endTime = block.timestamp + VOTING_PERIOD;
        p.executionData = executionData;
        p.executionTarget = executionTarget;
        p.executed = false;

        emit ProposalCreated(proposalId, msg.sender, title);
    }

    function castVote(uint256 proposalId, bool support) external onlyTokenHolder {
        Proposal storage p = proposals[proposalId];
        require(p.status == ProposalStatus.ACTIVE, "Not active");
        require(block.timestamp >= p.startTime && block.timestamp < p.endTime, "Not in voting window");
        require(!hasVoted[proposalId][msg.sender], "Already voted");

        uint256 weight = governanceToken.balanceOf(msg.sender);
        require(weight > 0, "No weight");

        hasVoted[proposalId][msg.sender] = true;
        voteSupport[proposalId][msg.sender] = support;

        if (support) {
            p.votesFor += weight;
        } else {
            p.votesAgainst += weight;
        }

        emit VoteCast(proposalId, msg.sender, support, weight);
    }

    function finalizeProposal(uint256 proposalId) external {
        Proposal storage p = proposals[proposalId];
        require(p.status == ProposalStatus.ACTIVE, "Not active");
        require(block.timestamp >= p.endTime, "Voting not ended");

        uint256 totalVotes = p.votesFor + p.votesAgainst;
        bool metQuorum = totalVotes >= p.quorumRequired;
        bool majoritySupport = totalVotes > 0 && (p.votesFor * 10_000) / totalVotes >= PASS_THRESHOLD_BPS;

        if (metQuorum && majoritySupport) {
            p.status = ProposalStatus.PASSED;
            emit ProposalPassed(proposalId);
        } else {
            p.status = ProposalStatus.FAILED;
            emit ProposalFailed(proposalId);
        }
    }

    function executeProposal(uint256 proposalId) external {
        Proposal storage p = proposals[proposalId];
        require(p.status == ProposalStatus.PASSED, "Not passed");
        require(!p.executed, "Already executed");
        require(block.timestamp >= p.endTime + EXECUTION_DELAY, "Timelock not expired");

        p.executed = true;
        p.status = ProposalStatus.EXECUTED;

        if (p.executionTarget != address(0) && p.executionData.length > 0) {
            (bool success, ) = p.executionTarget.call(p.executionData);
            require(success, "Execution failed");
        }

        emit ProposalExecuted(proposalId);
    }

    function getProposal(uint256 proposalId) external view returns (Proposal memory) {
        return proposals[proposalId];
    }

    function setTotalSupply(uint256 _totalSupply) external {
        require(msg.sender == owner, "Only owner");
        totalSupply = _totalSupply;
    }
}
