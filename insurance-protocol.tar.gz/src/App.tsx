import { useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from "recharts";
import { claims, coverageProducts, policies, pools } from "./data";
import type { CoverageProduct, RiskCategory } from "./types";

const riskLoad: Record<RiskCategory, number> = {
  "Smart Contract Bug": 1.34,
  "Oracle Failure": 1.24,
  "Stablecoin Depeg": 1.12,
  "Slashing Event": 0.96
};

const colors = ["#0f5f5c", "#d77a2d", "#a93f55", "#6d8b74"];

function currency(value: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0
  }).format(value);
}

function percent(value: number) {
  return `${(value * 100).toFixed(1)}%`;
}

function computeQuote(product: CoverageProduct, amount: number, durationDays: number) {
  const utilizationMultiplier = 1 + product.utilization * 0.65;
  const claimsMultiplier = 1 + product.historicalLossRate * 12;
  const controlsDiscount = 1 - (product.auditScore * 0.18 + product.oracleDiversity * 0.08);
  const annualRate =
    0.032 *
    riskLoad[product.riskCategory] *
    utilizationMultiplier *
    claimsMultiplier *
    Math.max(0.62, controlsDiscount);

  const durationFactor = durationDays / 365;
  const premium = amount * annualRate * durationFactor;
  const protocolFee = premium * 0.08;
  const reserveContribution = premium * 0.17;

  return {
    annualRate,
    premium,
    protocolFee,
    reserveContribution,
    coverageRatio: amount / product.maxCapacity
  };
}

export default function App() {
  const [selectedProductId, setSelectedProductId] = useState(coverageProducts[0].id);
  const [coverageAmount, setCoverageAmount] = useState(250000);
  const [durationDays, setDurationDays] = useState(180);

  const selectedProduct = useMemo(
    () => coverageProducts.find((product) => product.id === selectedProductId) ?? coverageProducts[0],
    [selectedProductId]
  );

  const quote = useMemo(
    () => computeQuote(selectedProduct, coverageAmount, durationDays),
    [coverageAmount, durationDays, selectedProduct]
  );

  const poolCoverage = pools.map((pool) => ({
    name: pool.name.replace(" Pool", ""),
    capital: pool.capital / 1_000_000,
    reserved: pool.reservedForClaims / 1_000_000
  }));

  const exposureMix = coverageProducts.map((product) => ({
    name: product.riskCategory,
    value: product.capitalAllocated
  }));

  return (
    <div className="app-shell">
      <header className="hero">
        <div>
          <p className="eyebrow">Decentralized Insurance Protocol</p>
          <h1>Nexus Shield</h1>
          <p className="hero-copy">
            Onchain cover for smart contract exploits, oracle outages, stablecoin depegs, and
            validator slashing. Pricing adapts to utilization, controls, and observed loss history.
          </p>
        </div>
        <div className="hero-metrics">
          <div className="metric-card">
            <span>Total Capacity</span>
            <strong>{currency(coverageProducts.reduce((sum, item) => sum + item.maxCapacity, 0))}</strong>
          </div>
          <div className="metric-card">
            <span>Capital Backing</span>
            <strong>{currency(pools.reduce((sum, item) => sum + item.capital, 0))}</strong>
          </div>
          <div className="metric-card">
            <span>Claims Reserve</span>
            <strong>{currency(pools.reduce((sum, item) => sum + item.reservedForClaims, 0))}</strong>
          </div>
        </div>
      </header>

      <main className="grid">
        <section className="panel product-panel">
          <div className="section-heading">
            <div>
              <p className="eyebrow">Coverage Browser</p>
              <h2>Insurable risk markets</h2>
            </div>
            <span className="badge">{coverageProducts.length} live products</span>
          </div>
          <div className="product-list">
            {coverageProducts.map((product) => (
              <button
                key={product.id}
                type="button"
                className={`product-card ${selectedProduct.id === product.id ? "selected" : ""}`}
                onClick={() => setSelectedProductId(product.id)}
              >
                <div>
                  <strong>{product.protocol}</strong>
                  <span>
                    {product.chain} · {product.riskCategory}
                  </span>
                </div>
                <div className="product-stats">
                  <span>Utilization {percent(product.utilization)}</span>
                  <span>Audit {percent(product.auditScore)}</span>
                </div>
              </button>
            ))}
          </div>
        </section>

        <section className="panel quote-panel">
          <div className="section-heading">
            <div>
              <p className="eyebrow">Quote Engine</p>
              <h2>Risk-based premium</h2>
            </div>
            <span className="badge accent">Dynamic pricing</span>
          </div>
          <div className="quote-layout">
            <div className="form-grid">
              <label>
                Coverage amount
                <input
                  type="range"
                  min="25000"
                  max="1000000"
                  step="25000"
                  value={coverageAmount}
                  onChange={(event) => setCoverageAmount(Number(event.target.value))}
                />
                <strong>{currency(coverageAmount)}</strong>
              </label>
              <label>
                Duration
                <input
                  type="range"
                  min="30"
                  max="365"
                  step="15"
                  value={durationDays}
                  onChange={(event) => setDurationDays(Number(event.target.value))}
                />
                <strong>{durationDays} days</strong>
              </label>
            </div>
            <div className="quote-card">
              <h3>{selectedProduct.protocol}</h3>
              <p>{selectedProduct.riskCategory}</p>
              <div className="quote-price">{currency(quote.premium)}</div>
              <div className="quote-breakdown">
                <span>Annualized rate {percent(quote.annualRate)}</span>
                <span>Protocol fee {currency(quote.protocolFee)}</span>
                <span>Reserve contribution {currency(quote.reserveContribution)}</span>
                <span>Capacity consumed {percent(quote.coverageRatio)}</span>
              </div>
            </div>
          </div>
        </section>

        <section className="panel chart-panel">
          <div className="section-heading">
            <div>
              <p className="eyebrow">Capital Pools</p>
              <h2>Backstop liquidity</h2>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={poolCoverage}>
              <defs>
                <linearGradient id="capital" x1="0" x2="0" y1="0" y2="1">
                  <stop offset="5%" stopColor="#d77a2d" stopOpacity={0.85} />
                  <stop offset="95%" stopColor="#d77a2d" stopOpacity={0.05} />
                </linearGradient>
                <linearGradient id="reserved" x1="0" x2="0" y1="0" y2="1">
                  <stop offset="5%" stopColor="#0f5f5c" stopOpacity={0.85} />
                  <stop offset="95%" stopColor="#0f5f5c" stopOpacity={0.05} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#d9d2c5" />
              <XAxis dataKey="name" stroke="#5f574f" />
              <YAxis stroke="#5f574f" unit="m" />
              <Tooltip formatter={(value: number) => `${value.toFixed(2)}m`} />
              <Area type="monotone" dataKey="capital" stroke="#d77a2d" fill="url(#capital)" />
              <Area type="monotone" dataKey="reserved" stroke="#0f5f5c" fill="url(#reserved)" />
            </AreaChart>
          </ResponsiveContainer>
          <div className="pool-grid">
            {pools.map((pool) => (
              <article key={pool.id} className="pool-card">
                <h3>{pool.name}</h3>
                <p>{pool.supportedRisks.join(" · ")}</p>
                <div>
                  <strong>{currency(pool.capital)}</strong>
                  <span>{pool.apy.toFixed(1)}% supplier APY</span>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="panel chart-panel">
          <div className="section-heading">
            <div>
              <p className="eyebrow">Risk Mix</p>
              <h2>Exposure by cover line</h2>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={exposureMix} dataKey="value" nameKey="name" innerRadius={64} outerRadius={96}>
                {exposureMix.map((entry, index) => (
                  <Cell key={entry.name} fill={colors[index % colors.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value: number) => currency(value)} />
            </PieChart>
          </ResponsiveContainer>
          <div className="legend">
            {exposureMix.map((entry, index) => (
              <span key={entry.name}>
                <i style={{ backgroundColor: colors[index % colors.length] }} />
                {entry.name}
              </span>
            ))}
          </div>
        </section>

        <section className="panel table-panel">
          <div className="section-heading">
            <div>
              <p className="eyebrow">Policy Management</p>
              <h2>Active cover positions</h2>
            </div>
          </div>
          <table>
            <thead>
              <tr>
                <th>Policy</th>
                <th>Holder</th>
                <th>Product</th>
                <th>Coverage</th>
                <th>Premium</th>
                <th>Expiry</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {policies.map((policy) => (
                <tr key={policy.id}>
                  <td>{policy.id}</td>
                  <td>{policy.holder}</td>
                  <td>{coverageProducts.find((product) => product.id === policy.productId)?.protocol}</td>
                  <td>{currency(policy.coverageAmount)}</td>
                  <td>{currency(policy.premium)}</td>
                  <td>{policy.expiresAt}</td>
                  <td>
                    <span className={`status ${policy.status.toLowerCase()}`}>{policy.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>

        <section className="panel claims-panel">
          <div className="section-heading">
            <div>
              <p className="eyebrow">Claims Processor</p>
              <h2>Voting-based adjudication</h2>
            </div>
          </div>
          <div className="claims-grid">
            {claims.map((claim) => {
              const yesVotes = claim.votes.filter((vote) => vote.support).reduce((sum, vote) => sum + vote.votingPower, 0);
              const totalVotes = claim.votes.reduce((sum, vote) => sum + vote.votingPower, 0);
              return (
                <article key={claim.id} className="claim-card">
                  <div className="claim-header">
                    <div>
                      <h3>{claim.id}</h3>
                      <p>{coverageProducts.find((product) => product.id === claim.productId)?.protocol}</p>
                    </div>
                    <span className={`status ${claim.status.toLowerCase()}`}>{claim.status}</span>
                  </div>
                  <p className="incident">{claim.incident}</p>
                  <div className="claim-meta">
                    <span>Filed {claim.filedAt}</span>
                    <span>Requested {currency(claim.amount)}</span>
                    <span>Approval {percent(totalVotes === 0 ? 0 : yesVotes / totalVotes)}</span>
                  </div>
                  <div className="vote-list">
                    {claim.votes.map((vote) => (
                      <div key={vote.assessor} className="vote-row">
                        <span>{vote.assessor}</span>
                        <span>{vote.support ? "Approve" : "Reject"}</span>
                        <span>{(vote.votingPower / 1000).toFixed(0)}k veNSH</span>
                      </div>
                    ))}
                  </div>
                </article>
              );
            })}
          </div>
        </section>
      </main>
    </div>
  );
}
