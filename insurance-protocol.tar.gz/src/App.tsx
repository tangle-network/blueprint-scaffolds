import { Routes, Route, NavLink, Navigate } from 'react-router-dom'
import { Shield, Search, Calculator, FileWarning, FolderOpen, Landmark, Vote } from 'lucide-react'
import CoverageBrowser from './pages/CoverageBrowser'
import QuoteCalculator from './pages/QuoteCalculator'
import ClaimsInterface from './pages/ClaimsInterface'
import PolicyManagement from './pages/PolicyManagement'
import CapitalPools from './pages/CapitalPools'
import Governance from './pages/Governance'

const navItems = [
  { to: '/coverage', label: 'Coverage', icon: Search },
  { to: '/quote', label: 'Quote', icon: Calculator },
  { to: '/policies', label: 'Policies', icon: FolderOpen },
  { to: '/claims', label: 'Claims', icon: FileWarning },
  { to: '/pools', label: 'Capital Pools', icon: Landmark },
  { to: '/governance', label: 'Governance', icon: Vote },
]

export default function App() {
  return (
    <div className="min-h-screen flex">
      <aside className="w-64 border-r bg-card flex flex-col shrink-0">
        <div className="p-6 flex items-center gap-3 border-b">
          <Shield className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-lg font-bold text-foreground">DeFi Shield</h1>
            <p className="text-xs text-muted-foreground">Insurance Protocol</p>
          </div>
        </div>
        <nav className="flex-1 p-4 space-y-1">
          {navItems.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-primary/10 text-primary'
                    : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                }`
              }
            >
              <Icon className="h-4 w-4" />
              {label}
            </NavLink>
          ))}
        </nav>
        <div className="p-4 border-t">
          <div className="text-xs text-muted-foreground">
            Total Value Covered
            <div className="text-lg font-bold text-foreground mt-1">$113.3M</div>
          </div>
        </div>
      </aside>
      <main className="flex-1 overflow-auto">
        <div className="p-8">
          <Routes>
            <Route path="/" element={<Navigate to="/coverage" replace />} />
            <Route path="/coverage" element={<CoverageBrowser />} />
            <Route path="/quote" element={<QuoteCalculator />} />
            <Route path="/policies" element={<PolicyManagement />} />
            <Route path="/claims" element={<ClaimsInterface />} />
            <Route path="/pools" element={<CapitalPools />} />
            <Route path="/governance" element={<Governance />} />
          </Routes>
        </div>
      </main>
    </div>
  )
}
