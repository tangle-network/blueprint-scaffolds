export type RiskCategory =
  | "smart_contract_bug"
  | "oracle_failure"
  | "stablecoin_depeg"
  | "slashing_event";

export type PolicyStatus = "active" | "expired" | "claimed" | "cancelled";
export type ClaimStatus = "submitted" | "voting" | "approved" | "rejected" | "paid";

export interface RiskTier {
  category: RiskCategory;
  label: string;
  description: string;
  basePremiumBps: number;
  maxCoverageRatio: number;
  icon: string;
}

export interface Protocol {
  id: string;
  name: string;
  chain: string;
  tvl: number;
  riskScore: number;
  categories: RiskCategory[];
  incidentCount: number;
}

export interface CoverageProduct {
  id: string;
  protocolId: string;
  protocol: Protocol;
  category: RiskCategory;
  premiumRateBps: number;
  capacityAvailable: number;
  capacityTotal: number;
  minDurationDays: number;
  maxDurationDays: number;
}

export interface QuoteRequest {
  protocolId: string;
  category: RiskCategory;
  coverageAmount: number;
  durationDays: number;
}

export interface Quote {
  id: string;
  request: QuoteRequest;
  protocol: Protocol;
  premiumAnnual: number;
  premiumTotal: number;
  premiumRateBps: number;
  coverageAmount: number;
  startDate: string;
  endDate: string;
  riskScore: number;
  expiresAt: string;
}

export interface Policy {
  id: string;
  quoteId: string;
  protocolId: string;
  protocolName: string;
  category: RiskCategory;
  coverageAmount: number;
  premium: number;
  premiumRateBps: number;
  startDate: string;
  endDate: string;
  status: PolicyStatus;
  claimCount: number;
}

export interface Claim {
  id: string;
  policyId: string;
  protocolName: string;
  category: RiskCategory;
  amount: number;
  status: ClaimStatus;
  submittedAt: string;
  evidenceHash: string;
  votesFor: number;
  votesAgainst: number;
  voterCount: number;
  resolutionDate?: string;
}

export interface CapitalPoolInfo {
  totalCapacity: number;
  utilized: number;
  available: number;
  utilizationRate: number;
  totalPremiumsCollected: number;
  totalClaimsPaid: number;
  reserveRatio: number;
  stakingApr: number;
}

export interface GovernanceProposal {
  id: string;
  title: string;
  description: string;
  proposer: string;
  status: "active" | "passed" | "failed" | "executed";
  votesFor: number;
  votesAgainst: number;
  quorum: number;
  startDate: string;
  endDate: string;
}

export interface PoolDeposit {
  id: string;
  amount: number;
  depositDate: string;
  shares: number;
  currentValue: number;
  yieldEarned: number;
}
