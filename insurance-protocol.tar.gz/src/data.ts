import type { ClaimRecord, CoverageProduct, PolicyRecord, Pool } from "./types";

export const coverageProducts: CoverageProduct[] = [
  {
    id: "aave-v3",
    protocol: "Aave V3",
    chain: "Ethereum",
    riskCategory: "Smart Contract Bug",
    utilization: 0.61,
    capitalAllocated: 12400000,
    maxCapacity: 21000000,
    historicalLossRate: 0.018,
    oracleDiversity: 0.76,
    auditScore: 0.91,
    activePolicies: 428
  },
  {
    id: "maker-peg",
    protocol: "MakerDAO DAI",
    chain: "Ethereum",
    riskCategory: "Stablecoin Depeg",
    utilization: 0.47,
    capitalAllocated: 9800000,
    maxCapacity: 24000000,
    historicalLossRate: 0.011,
    oracleDiversity: 0.83,
    auditScore: 0.94,
    activePolicies: 387
  },
  {
    id: "pyth-solana",
    protocol: "Pyth",
    chain: "Solana",
    riskCategory: "Oracle Failure",
    utilization: 0.74,
    capitalAllocated: 8900000,
    maxCapacity: 12000000,
    historicalLossRate: 0.026,
    oracleDiversity: 0.65,
    auditScore: 0.8,
    activePolicies: 143
  },
  {
    id: "lido-eth",
    protocol: "Lido stETH",
    chain: "Ethereum",
    riskCategory: "Slashing Event",
    utilization: 0.42,
    capitalAllocated: 15400000,
    maxCapacity: 36000000,
    historicalLossRate: 0.009,
    oracleDiversity: 0.79,
    auditScore: 0.9,
    activePolicies: 265
  }
];

export const pools: Pool[] = [
  {
    id: "genesis-pool",
    name: "Genesis Capital Pool",
    apy: 13.4,
    capital: 18200000,
    utilization: 0.58,
    reservedForClaims: 2300000,
    supportedRisks: ["Smart Contract Bug", "Oracle Failure"]
  },
  {
    id: "peg-pool",
    name: "Peg Stability Pool",
    apy: 10.2,
    capital: 14100000,
    utilization: 0.49,
    reservedForClaims: 1750000,
    supportedRisks: ["Stablecoin Depeg"]
  },
  {
    id: "validator-pool",
    name: "Validator Safety Pool",
    apy: 8.8,
    capital: 9700000,
    utilization: 0.41,
    reservedForClaims: 1080000,
    supportedRisks: ["Slashing Event"]
  }
];

export const policies: PolicyRecord[] = [
  {
    id: "POL-1042",
    holder: "0x4dA9...c12e",
    productId: "aave-v3",
    coverageAmount: 250000,
    premium: 14375,
    durationDays: 180,
    expiresAt: "2025-12-18",
    status: "Active"
  },
  {
    id: "POL-2310",
    holder: "0x18b3...9Fa0",
    productId: "maker-peg",
    coverageAmount: 500000,
    premium: 19800,
    durationDays: 90,
    expiresAt: "2025-10-02",
    status: "Active"
  },
  {
    id: "POL-3104",
    holder: "0x82c1...71d2",
    productId: "lido-eth",
    coverageAmount: 125000,
    premium: 6100,
    durationDays: 365,
    expiresAt: "2026-03-29",
    status: "Claimed"
  }
];

export const claims: ClaimRecord[] = [
  {
    id: "CLM-778",
    policyId: "POL-3104",
    productId: "lido-eth",
    claimant: "0x82c1...71d2",
    incident: "Consensus client outage caused correlated validator penalties.",
    amount: 80000,
    filedAt: "2025-05-12",
    status: "Approved",
    votes: [
      { assessor: "NodeAlpha", votingPower: 310000, support: true },
      { assessor: "RiskDAO", votingPower: 180000, support: true },
      { assessor: "PoolSentinel", votingPower: 120000, support: false }
    ]
  },
  {
    id: "CLM-901",
    policyId: "POL-1042",
    productId: "aave-v3",
    claimant: "0x4dA9...c12e",
    incident: "Emergency pause triggered after abnormal liquidation behavior.",
    amount: 65000,
    filedAt: "2025-06-30",
    status: "Pending",
    votes: [
      { assessor: "RiskDAO", votingPower: 180000, support: true },
      { assessor: "Nexus Council", votingPower: 250000, support: false }
    ]
  }
];
