export type RiskCategory = 'smart-contract' | 'oracle-failure' | 'stablecoin-depeg' | 'slashing'

export interface CoverageProduct {
  id: string
  name: string
  category: RiskCategory
  description: string
  protocol: string
  riskScore: number
  maxCoverage: number
  premiumRateAPY: number
  active: boolean
  totalCovered: number
  capacityAvailable: number
}

export interface Quote {
  id: string
  productId: string
  coverageAmount: number
  premium: number
  durationMonths: number
  riskScore: number
  expiresAt: number
}

export interface Policy {
  id: string
  productId: string
  productName: string
  category: RiskCategory
  coverageAmount: number
  premium: number
  startDate: number
  endDate: number
  status: 'active' | 'expired' | 'claimed' | 'cancelled'
  claimsCount: number
}

export interface Claim {
  id: string
  policyId: string
  productName: string
  amount: number
  status: 'pending' | 'voting' | 'approved' | 'rejected' | 'paid'
  submittedAt: number
  description: string
  votesFor: number
  votesAgainst: number
  votingDeadline: number
  evidence: string
}

export interface CapitalPool {
  id: string
  name: string
  totalCapital: number
  totalCovered: number
  utilization: number
  apy: number
  riskCategory: RiskCategory
}

export interface GovernanceProposal {
  id: string
  title: string
  description: string
  status: 'active' | 'passed' | 'rejected' | 'executed'
  votesFor: number
  votesAgainst: number
  quorum: number
  deadline: number
  proposer: string
}

export const RISK_LABELS: Record<RiskCategory, string> = {
  'smart-contract': 'Smart Contract Bug',
  'oracle-failure': 'Oracle Failure',
  'stablecoin-depeg': 'Stablecoin Depeg',
  'slashing': 'Slashing Event',
}

export const RISK_COLORS: Record<RiskCategory, string> = {
  'smart-contract': 'bg-red-500/20 text-red-400 border-red-500/30',
  'oracle-failure': 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  'stablecoin-depeg': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  'slashing': 'bg-purple-500/20 text-purple-400 border-purple-500/30',
}
