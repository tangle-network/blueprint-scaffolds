import type { RiskTier, Protocol, CoverageProduct } from "@/types";

export const RISK_TIERS: Record<string, RiskTier> = {
  smart_contract_bug: {
    category: "smart_contract_bug",
    label: "Smart Contract Bug",
    description: "Coverage against exploits, reentrancy attacks, and logic errors in audited smart contracts",
    basePremiumBps: 350,
    maxCoverageRatio: 0.8,
    icon: "Bug",
  },
  oracle_failure: {
    category: "oracle_failure",
    label: "Oracle Failure",
    description: "Coverage for losses from oracle manipulation, stale feeds, or data source failures",
    basePremiumBps: 275,
    maxCoverageRatio: 0.7,
    icon: "Radio",
  },
  stablecoin_depeg: {
    category: "stablecoin_depeg",
    label: "Stablecoin Depeg",
    description: "Coverage for losses when a stablecoin deviates beyond threshold from its peg",
    basePremiumBps: 200,
    maxCoverageRatio: 0.9,
    icon: "TrendingDown",
  },
  slashing_event: {
    category: "slashing_event",
    label: "Slashing Event",
    description: "Coverage for validator staking losses due to slashing penalties on PoS networks",
    basePremiumBps: 150,
    maxCoverageRatio: 0.6,
    icon: "Zap",
  },
};

export const PROTOCOLS: Protocol[] = [
  { id: "aave-v3", name: "Aave V3", chain: "Ethereum", tvl: 12_400_000_000, riskScore: 25, categories: ["smart_contract_bug", "oracle_failure"], incidentCount: 0 },
  { id: "compound-v3", name: "Compound V3", chain: "Ethereum", tvl: 3_200_000_000, riskScore: 30, categories: ["smart_contract_bug", "oracle_failure"], incidentCount: 0 },
  { id: "lido", name: "Lido", chain: "Ethereum", tvl: 33_500_000_000, riskScore: 22, categories: ["smart_contract_bug", "slashing_event"], incidentCount: 0 },
  { id: "curve", name: "Curve Finance", chain: "Ethereum", tvl: 4_100_000_000, riskScore: 45, categories: ["smart_contract_bug", "oracle_failure"], incidentCount: 2 },
  { id: "makerdao", name: "MakerDAO", chain: "Ethereum", tvl: 8_900_000_000, riskScore: 28, categories: ["smart_contract_bug", "stablecoin_depeg"], incidentCount: 0 },
  { id: "uniswap-v3", name: "Uniswap V3", chain: "Ethereum", tvl: 5_600_000_000, riskScore: 20, categories: ["smart_contract_bug"], incidentCount: 0 },
  { id: "rocketpool", name: "Rocket Pool", chain: "Ethereum", tvl: 4_800_000_000, riskScore: 35, categories: ["smart_contract_bug", "slashing_event"], incidentCount: 1 },
  { id: "frax", name: "Frax Finance", chain: "Ethereum", tvl: 1_900_000_000, riskScore: 40, categories: ["smart_contract_bug", "stablecoin_depeg"], incidentCount: 1 },
  { id: "convex", name: "Convex Finance", chain: "Ethereum", tvl: 2_100_000_000, riskScore: 38, categories: ["smart_contract_bug", "oracle_failure"], incidentCount: 1 },
  { id: "yearn", name: "Yearn Finance", chain: "Ethereum", tvl: 800_000_000, riskScore: 42, categories: ["smart_contract_bug", "oracle_failure"], incidentCount: 1 },
];

export const MOCK_COVERAGE_PRODUCTS: CoverageProduct[] = PROTOCOLS.flatMap((p) =>
  p.categories.map((cat, i) => {
    const tier = RISK_TIERS[cat];
    const riskMultiplier = 1 + (p.riskScore / 100) * 0.5;
    const adjustedBps = Math.round(tier.basePremiumBps * riskMultiplier);
    const capacity = Math.round(p.tvl * tier.maxCoverageRatio * 0.1);
    return {
      id: `${p.id}-${cat}-${i}`,
      protocolId: p.id,
      protocol: p,
      category: cat,
      premiumRateBps: adjustedBps,
      capacityAvailable: Math.round(capacity * (0.4 + Math.random() * 0.5)),
      capacityTotal: capacity,
      minDurationDays: 30,
      maxDurationDays: 365,
    };
  })
);

export const MOCK_CAPITAL_POOL = {
  totalCapacity: 250_000_000,
  utilized: 87_500_000,
  available: 162_500_000,
  utilizationRate: 0.35,
  totalPremiumsCollected: 12_400_000,
  totalClaimsPaid: 3_200_000,
  reserveRatio: 2.8,
  stakingApr: 8.4,
};

export const CLAIM_VOTING_PERIOD_DAYS = 7;
export const CLAIM_QUORUM = 0.1;
export const CLAIM_PASS_THRESHOLD = 0.6;
export const MIN_COVERAGE_USD = 1_000;
export const MAX_COVERAGE_USD = 50_000_000;
export const MIN_DURATION_DAYS = 30;
export const MAX_DURATION_DAYS = 365;
