export type RiskCategory =
  | "Smart Contract Bug"
  | "Oracle Failure"
  | "Stablecoin Depeg"
  | "Slashing Event";

export interface CoverageProduct {
  id: string;
  protocol: string;
  chain: string;
  riskCategory: RiskCategory;
  utilization: number;
  capitalAllocated: number;
  maxCapacity: number;
  historicalLossRate: number;
  oracleDiversity: number;
  auditScore: number;
  activePolicies: number;
}

export interface Pool {
  id: string;
  name: string;
  apy: number;
  capital: number;
  utilization: number;
  reservedForClaims: number;
  supportedRisks: RiskCategory[];
}

export interface ClaimVote {
  assessor: string;
  votingPower: number;
  support: boolean;
}

export interface ClaimRecord {
  id: string;
  policyId: string;
  productId: string;
  claimant: string;
  incident: string;
  amount: number;
  filedAt: string;
  status: "Pending" | "Approved" | "Rejected" | "Paid";
  votes: ClaimVote[];
}

export interface PolicyRecord {
  id: string;
  holder: string;
  productId: string;
  coverageAmount: number;
  premium: number;
  durationDays: number;
  expiresAt: string;
  status: "Active" | "Expired" | "Claimed";
}
