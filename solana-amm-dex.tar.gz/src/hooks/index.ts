import { useState, useCallback, useMemo } from "react";
import type { PoolInfo, PositionInfo, SwapQuote, TokenInfo, SwapDirection } from "../lib/types";
import { KNOWN_TOKENS, FEE_TIERS } from "../lib/constants";
import { MOCK_POOLS, MOCK_POSITIONS, getMockSwapQuote } from "../lib/mock-data";

export function usePools() {
  return useMemo(() => MOCK_POOLS, []);
}

export function usePositions() {
  return useMemo(() => MOCK_POSITIONS, []);
}

export function useSwap(tokenA: TokenInfo, tokenB: TokenInfo, direction: SwapDirection) {
  const [amount, setAmount] = useState<string>("");
  const [slippage, setSlippage] = useState(0.5);
  const [quote, setQuote] = useState<SwapQuote | null>(null);
  const [loading, setLoading] = useState(false);

  const getQuote = useCallback(
    (amt: string) => {
      setAmount(amt);
      if (!amt || parseFloat(amt) <= 0) {
        setQuote(null);
        return;
      }
      setLoading(true);
      setTimeout(() => {
        const q = getMockSwapQuote(tokenA.mint, tokenB.mint, parseFloat(amt));
        setQuote(q);
        setLoading(false);
      }, 300);
    },
    [tokenA, tokenB]
  );

  return { amount, slippage, setSlippage, quote, loading, getQuote, tokenA, tokenB };
}

export function useTokenSelector() {
  const [selected, setSelected] = useState<TokenInfo>(KNOWN_TOKENS[0]);
  const tokens = useMemo(() => KNOWN_TOKENS, []);
  return { selected, setSelected, tokens };
}

export function usePoolFactory() {
  const feeTiers = useMemo(() => FEE_TIERS, []);
  const createPool = useCallback(
    (tokenA: TokenInfo, tokenB: TokenInfo, feeRate: number) => {
      const pool: PoolInfo = {
        address: `PoOL${Date.now()}`,
        tokenA,
        tokenB,
        feeRate,
        tickSpacing: FEE_TIERS.find((f) => f.feeRate === feeRate)?.tickSpacing ?? 60,
        sqrtPrice: "18446744073709551616",
        tick: 0,
        liquidity: "0",
        tvlUsd: 0,
        volume24h: 0,
        fees24h: 0,
      };
      return pool;
    },
    []
  );
  return { feeTiers, createPool, pools: MOCK_POOLS };
}

export function useLiquidity(pool: PoolInfo | null) {
  const [tickLower, setTickLower] = useState(-100);
  const [tickUpper, setTickUpper] = useState(100);
  const [amountA, setAmountA] = useState("");
  const [amountB, setAmountB] = useState("");
  const [singleSided, setSingleSided] = useState(false);
  const [singleSidedToken, setSingleSidedToken] = useState<"A" | "B">("A");

  return {
    pool,
    tickLower,
    tickUpper,
    setTickLower,
    setTickUpper,
    amountA,
    setAmountA,
    amountB,
    setAmountB,
    singleSided,
    setSingleSided,
    singleSidedToken,
    setSingleSidedToken,
  };
}

export function useTWAP(poolAddress: string) {
  const observations = useMemo(
    () =>
      Array.from({ length: 100 }, (_, i) => ({
        timestamp: Date.now() - (100 - i) * 60000,
        price: 150 + Math.sin(i / 10) * 5 + Math.random() * 2,
      })),
    []
  );
  const twapPrice = useMemo(() => {
    const sum = observations.reduce((s, o) => s + o.price, 0);
    return sum / observations.length;
  }, [observations]);
  return { poolAddress, observations, twapPrice };
}
