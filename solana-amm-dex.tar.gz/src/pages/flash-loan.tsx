import { useState, useMemo } from "react";
import type { TokenInfo } from "@/lib/types";
import { KNOWN_TOKENS, SOL_TOKEN, USDC_TOKEN } from "@/lib/constants";
import { MOCK_POOLS } from "@/lib/mock-data";
import { formatNumber, formatUsd } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Zap,
  AlertTriangle,
  ArrowRight,
  Clock,
  Shield,
  Info,
  Layers,
  TrendingUp,
  Wallet,
} from "lucide-react";

const FLASH_LOAN_FEE_BPS = 30;

export default function FlashLoanPage() {
  const [token, setToken] = useState<TokenInfo>(SOL_TOKEN);
  const [amount, setAmount] = useState("");
  const [recipient, setRecipient] = useState("");
  const [showConfirm, setShowConfirm] = useState(false);

  const parsedAmount = useMemo(() => parseFloat(amount) || 0, [amount]);
  const fee = useMemo(
    () => (parsedAmount * FLASH_LOAN_FEE_BPS) / 10000,
    [parsedAmount]
  );
  const totalRepay = useMemo(() => parsedAmount + fee, [parsedAmount, fee]);

  const availablePools = useMemo(
    () =>
      MOCK_POOLS.filter(
        (p) => p.tokenA.mint === token.mint || p.tokenB.mint === token.mint
      ),
    [token]
  );

  const maxAvailable = useMemo(() => {
    if (availablePools.length === 0) return 0;
    return Math.max(...availablePools.map((p) => p.tvlUsd));
  }, [availablePools]);

  const handleAmountChange = (val: string) => {
    if (/^\d*\.?\d*$/.test(val) || val === "") {
      setAmount(val);
    }
  };

  return (
    <div className="max-w-lg mx-auto space-y-6">
      <div className="text-center mb-6">
        <h1 className="text-3xl font-bold mb-2">Flash Loan</h1>
        <p className="text-muted-foreground">
          Borrow and repay within a single transaction — no collateral required
        </p>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg flex items-center gap-2">
              <Zap className="h-5 w-5 text-primary" /> Flash Borrow
            </CardTitle>
            <Badge variant="outline" className="gap-1">
              <Clock className="h-3 w-3" /> Single TX
            </Badge>
          </div>
          <CardDescription>
            Fee: {(FLASH_LOAN_FEE_BPS / 100).toFixed(2)}% — Must repay in the same transaction
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Borrow Token</span>
              <span className="text-muted-foreground">
                Max: ~{formatUsd(maxAvailable)}
              </span>
            </div>
            <div className="flex gap-2">
              <Input
                placeholder="0.0"
                value={amount}
                onChange={(e) => handleAmountChange(e.target.value)}
                className="text-lg font-mono"
              />
              <Select
                value={token.mint}
                onValueChange={(v) => {
                  const t = KNOWN_TOKENS.find((t) => t.mint === v);
                  if (t) setToken(t);
                }}
              >
                <SelectTrigger className="w-28">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {KNOWN_TOKENS.map((t) => (
                    <SelectItem key={t.mint} value={t.mint}>
                      {t.symbol}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Recipient Address</span>
            </div>
            <Input
              placeholder="Enter or paste Solana address"
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              className="font-mono text-sm"
            />
          </div>

          {parsedAmount > 0 && (
            <div className="bg-muted/50 rounded-md p-4 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Borrow Amount</span>
                <span className="font-mono">
                  {formatNumber(parsedAmount, 4)} {token.symbol}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Fee ({(FLASH_LOAN_FEE_BPS / 100).toFixed(2)}%)</span>
                <span className="font-mono">
                  {formatNumber(fee, 6)} {token.symbol}
                </span>
              </div>
              <Separator />
              <div className="flex justify-between font-semibold">
                <span>Total Repay</span>
                <span className="font-mono">
                  {formatNumber(totalRepay, 4)} {token.symbol}
                </span>
              </div>
            </div>
          )}

          <Dialog open={showConfirm} onOpenChange={setShowConfirm}>
            <DialogTrigger asChild>
              <Button
                className="w-full gap-2"
                size="lg"
                disabled={parsedAmount <= 0 || !recipient}
              >
                <Zap className="h-4 w-4" />
                Execute Flash Loan
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-400" /> Confirm Flash Loan
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-2">
                <div className="bg-muted/50 rounded-md p-4 space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Token</span>
                    <span className="font-mono">{token.symbol}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Borrow</span>
                    <span className="font-mono">{formatNumber(parsedAmount, 4)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Fee</span>
                    <span className="font-mono">{formatNumber(fee, 6)}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-semibold">
                    <span>Total Repay</span>
                    <span className="font-mono">{formatNumber(totalRepay, 4)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Recipient</span>
                    <span className="font-mono text-xs">
                      {recipient.slice(0, 8)}...{recipient.slice(-4)}
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-2 p-3 rounded-md bg-yellow-500/10 text-yellow-400 text-sm">
                  <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0" />
                  <span>
                    Flash loans must be repaid in the same transaction. Failure to
                    repay will cause the entire transaction to revert.
                  </span>
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1" onClick={() => setShowConfirm(false)}>
                    Cancel
                  </Button>
                  <Button className="flex-1 gap-2" onClick={() => setShowConfirm(false)}>
                    <Zap className="h-4 w-4" /> Confirm
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Info className="h-5 w-5" /> How Flash Loans Work
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm text-muted-foreground">
          <div className="flex items-start gap-3">
            <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary shrink-0">
              1
            </div>
            <span>Borrow tokens from ConcentraDEX pool liquidity with zero collateral</span>
          </div>
          <div className="flex items-start gap-3">
            <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary shrink-0">
              2
            </div>
            <span>Execute arbitrary logic: arbitrage, liquidations, self-liquidation, etc.</span>
          </div>
          <div className="flex items-start gap-3">
            <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary shrink-0">
              3
            </div>
            <span>Repay the borrowed amount plus the fee within the same transaction</span>
          </div>
          <div className="flex items-start gap-3">
            <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary shrink-0">
              4
            </div>
            <span>If repayment fails, the entire transaction reverts — no risk to lenders</span>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Available Liquidity</CardTitle>
          <CardDescription>Pools with {token.symbol} available for flash loans</CardDescription>
        </CardHeader>
        <CardContent>
          {availablePools.length === 0 ? (
            <div className="text-sm text-muted-foreground text-center py-4">
              No pools found for {token.symbol}
            </div>
          ) : (
            <div className="space-y-3">
              {availablePools.map((pool) => (
                <div
                  key={pool.address}
                  className="flex items-center justify-between py-2 px-3 rounded-md bg-muted/30"
                >
                  <div className="flex items-center gap-2">
                    <div className="flex -space-x-1">
                      <div className="h-5 w-5 rounded-full bg-purple-500/30 flex items-center justify-center text-[10px] font-bold border border-background">
                        {pool.tokenA.symbol[0]}
                      </div>
                      <div className="h-5 w-5 rounded-full bg-blue-500/30 flex items-center justify-center text-[10px] font-bold border border-background">
                        {pool.tokenB.symbol[0]}
                      </div>
                    </div>
                    <span className="text-sm font-medium">
                      {pool.tokenA.symbol}/{pool.tokenB.symbol}
                    </span>
                    <Badge variant="secondary" className="text-xs">
                      {(pool.feeRate / 10000).toFixed(2)}%
                    </Badge>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-mono">{formatUsd(pool.tvlUsd)}</div>
                    <div className="text-xs text-muted-foreground">TVL</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <div className="flex gap-2 flex-wrap justify-center">
        <Badge variant="secondary" className="gap-1">
          <Shield className="h-3 w-3" /> No Collateral
        </Badge>
        <Badge variant="secondary" className="gap-1">
          <Clock className="h-3 w-3" /> Instant Execution
        </Badge>
        <Badge variant="secondary" className="gap-1">
          <TrendingUp className="h-3 w-3" /> Arbitrage Ready
        </Badge>
        <Badge variant="secondary" className="gap-1">
          <Layers className="h-3 w-3" /> JIT Compatible
        </Badge>
      </div>
    </div>
  );
}
