import { useState, useMemo } from "react";
import type { TokenInfo, FeeTierConfig, PoolInfo } from "@/lib/types";
import { KNOWN_TOKENS, SOL_TOKEN, USDC_TOKEN, FEE_TIERS, MIN_TICK, MAX_TICK } from "@/lib/constants";
import { MOCK_POOLS, MOCK_TICKS } from "@/lib/mock-data";
import { nearestUsableTick, calcDynamicFee } from "@/lib/amm";
import { formatNumber, formatUsd, formatPercent } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Plus,
  Minus,
  Droplets,
  Settings,
  TrendingUp,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Layers,
  Zap,
} from "lucide-react";

export default function LiquidityPage() {
  const [tokenA, setTokenA] = useState<TokenInfo>(SOL_TOKEN);
  const [tokenB, setTokenB] = useState<TokenInfo>(USDC_TOKEN);
  const [feeTier, setFeeTier] = useState<FeeTierConfig>(FEE_TIERS[2]);
  const [tickLower, setTickLower] = useState(-100);
  const [tickUpper, setTickUpper] = useState(100);
  const [amountA, setAmountA] = useState("");
  const [amountB, setAmountB] = useState("");
  const [singleSided, setSingleSided] = useState(false);
  const [singleSidedToken, setSingleSidedToken] = useState<"A" | "B">("A");
  const [tab, setTab] = useState("add");

  const selectedPool = useMemo(
    () => MOCK_POOLS.find((p) => p.feeRate === feeTier.feeRate) ?? null,
    [feeTier]
  );

  const currentTick = selectedPool?.tick ?? 0;
  const currentPrice = useMemo(() => Math.pow(1.0001, currentTick), [currentTick]);
  const lowerPrice = useMemo(() => Math.pow(1.0001, tickLower), [tickLower]);
  const upperPrice = useMemo(() => Math.pow(1.0001, tickUpper), [tickUpper]);

  const rangePercent = useMemo(() => {
    if (!selectedPool) return 0;
    const inRange = tickLower <= currentTick && tickUpper >= currentTick;
    if (!inRange) return 0;
    const totalRange = tickUpper - tickLower;
    if (totalRange === 0) return 100;
    const positionOfCurrent = currentTick - tickLower;
    return Math.round((positionOfCurrent / totalRange) * 100);
  }, [tickLower, tickUpper, currentTick, selectedPool]);

  const maxLiquidityTick = useMemo(() => {
    const tick = MOCK_TICKS.reduce((max, t) => (Math.abs(parseInt(t.liquidityGross)) > Math.abs(parseInt(max.liquidityGross)) ? t : max), MOCK_TICKS[0]);
    return tick.tick;
  }, []);

  const dynamicFee = useMemo(() => calcDynamicFee(feeTier.feeRate, 0.02, 0.4), [feeTier]);

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="text-center mb-6">
        <h1 className="text-3xl font-bold mb-2">Liquidity</h1>
        <p className="text-muted-foreground">
          Provide concentrated liquidity with custom price ranges and fee tiers
        </p>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Select Pair</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2 items-center">
            <Select value={tokenA.mint} onValueChange={(v) => { const t = KNOWN_TOKENS.find((t) => t.mint === v); if (t) setTokenA(t); }}>
              <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
              <SelectContent>{KNOWN_TOKENS.map((t) => <SelectItem key={t.mint} value={t.mint}>{t.symbol}</SelectItem>)}</SelectContent>
            </Select>
            <span className="text-muted-foreground">/</span>
            <Select value={tokenB.mint} onValueChange={(v) => { const t = KNOWN_TOKENS.find((t) => t.mint === v); if (t) setTokenB(t); }}>
              <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
              <SelectContent>{KNOWN_TOKENS.map((t) => <SelectItem key={t.mint} value={t.mint}>{t.symbol}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Fee Tier</label>
            <div className="grid grid-cols-2 gap-2">
              {FEE_TIERS.map((ft) => (
                <Button
                  key={ft.feeRate}
                  variant={feeTier.feeRate === ft.feeRate ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFeeTier(ft)}
                  className="justify-start text-xs h-auto py-2"
                >
                  <div className="text-left">
                    <div className="font-semibold">{(ft.feeRate / 10000).toFixed(2)}%</div>
                    <div className="text-xs opacity-70">Tick spacing: {ft.tickSpacing}</div>
                  </div>
                </Button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg">Price Range</CardTitle>
            <Badge variant={tickLower <= currentTick && tickUpper >= currentTick ? "success" : "warning"}>
              {tickLower <= currentTick && tickUpper >= currentTick ? "In Range" : "Out of Range"}
            </Badge>
          </div>
          <CardDescription>
            Current price: {currentPrice.toFixed(4)} {tokenB.symbol}/{tokenA.symbol}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="flex-1 text-center">
              <div className="text-xs text-muted-foreground mb-1">Min Price</div>
              <div className="text-lg font-semibold">{lowerPrice.toFixed(4)}</div>
            </div>
            <div className="flex flex-col items-center gap-1">
              <Progress value={rangePercent} className="w-32" />
              <span className="text-xs text-muted-foreground">{rangePercent}%</span>
            </div>
            <div className="flex-1 text-center">
              <div className="text-xs text-muted-foreground mb-1">Max Price</div>
              <div className="text-lg font-semibold">{upperPrice.toFixed(4)}</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Lower Tick</label>
              <Input
                type="number"
                value={tickLower}
                onChange={(e) => setTickLower(nearestUsableTick(parseInt(e.target.value) || 0, feeTier.tickSpacing))}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Upper Tick</label>
              <Input
                type="number"
                value={tickUpper}
                onChange={(e) => setTickUpper(nearestUsableTick(parseInt(e.target.value) || 0, feeTier.tickSpacing))}
              />
            </div>
          </div>

          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => { setTickLower(nearestUsableTick(currentTick - 200, feeTier.tickSpacing)); setTickUpper(nearestUsableTick(currentTick + 200, feeTier.tickSpacing)); }}>
              Wide
            </Button>
            <Button variant="outline" size="sm" onClick={() => { setTickLower(nearestUsableTick(currentTick - 50, feeTier.tickSpacing)); setTickUpper(nearestUsableTick(currentTick + 50, feeTier.tickSpacing)); }}>
              Narrow
            </Button>
            <Button variant="outline" size="sm" onClick={() => { setTickLower(nearestUsableTick(currentTick - 10, feeTier.tickSpacing)); setTickUpper(nearestUsableTick(currentTick + 10, feeTier.tickSpacing)); }}>
              Tight
            </Button>
          </div>

          <div className="bg-muted/50 rounded-md p-3">
            <div className="text-xs font-medium mb-2">Liquidity Distribution (Ticks)</div>
            <div className="flex items-end gap-px h-16">
              {MOCK_TICKS.map((t, i) => {
                const liq = Math.abs(parseInt(t.liquidityGross));
                const maxLiq = Math.max(...MOCK_TICKS.map((x) => Math.abs(parseInt(x.liquidityGross))));
                const height = maxLiq > 0 ? (liq / maxLiq) * 100 : 0;
                const isCurrent = t.tick >= tickLower && t.tick <= tickUpper;
                return (
                  <div
                    key={i}
                    className="flex-1 rounded-t-sm"
                    style={{
                      height: `${height}%`,
                      backgroundColor: isCurrent ? "hsl(var(--primary))" : "hsl(var(--muted-foreground) / 0.3)",
                    }}
                  />
                );
              })}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">Deposit Amount</CardTitle>
            <Button
              variant={singleSided ? "default" : "outline"}
              size="sm"
              onClick={() => setSingleSided(!singleSided)}
              className="gap-1"
            >
              <Layers className="h-3 w-3" />
              Single-Sided
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {singleSided && (
            <div className="flex gap-2 mb-2">
              <Button
                variant={singleSidedToken === "A" ? "default" : "outline"}
                size="sm"
                onClick={() => setSingleSidedToken("A")}
              >
                {tokenA.symbol} Only
              </Button>
              <Button
                variant={singleSidedToken === "B" ? "default" : "outline"}
                size="sm"
                onClick={() => setSingleSidedToken("B")}
              >
                {tokenB.symbol} Only
              </Button>
            </div>
          )}

          {(!singleSided || singleSidedToken === "A") && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>{tokenA.symbol}</span>
                <span className="text-muted-foreground">Balance: --</span>
              </div>
              <Input
                placeholder="0.0"
                value={amountA}
                onChange={(e) => setAmountA(e.target.value)}
                className="font-mono"
              />
            </div>
          )}

          {(!singleSided || singleSidedToken === "B") && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>{tokenB.symbol}</span>
                <span className="text-muted-foreground">Balance: --</span>
              </div>
              <Input
                placeholder="0.0"
                value={amountB}
                onChange={(e) => setAmountB(e.target.value)}
                className="font-mono"
              />
            </div>
          )}

          {selectedPool && (
            <div className="text-sm space-y-1 mt-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Pool TVL</span>
                <span>{formatUsd(selectedPool.tvlUsd)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Pool Volume (24h)</span>
                <span>{formatUsd(selectedPool.volume24h)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Dynamic Fee</span>
                <span>{(dynamicFee / 10000).toFixed(3)}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Est. APR</span>
                <span className="text-green-400">~{(selectedPool.fees24h / selectedPool.tvlUsd * 365 * 100).toFixed(1)}%</span>
              </div>
            </div>
          )}

          <Button className="w-full gap-2" size="lg">
            <Plus className="h-4 w-4" />
            Add Liquidity
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
