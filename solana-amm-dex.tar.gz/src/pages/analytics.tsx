import { useState, useMemo } from "react";
import { MOCK_POOLS, MOCK_TWAP, MOCK_TICKS } from "@/lib/mock-data";
import { formatNumber, formatUsd, formatPercent } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  BarChart3,
  TrendingUp,
  Droplets,
  DollarSign,
  Activity,
  Clock,
  Layers,
  Eye,
} from "lucide-react";
import type { PoolInfo } from "@/lib/types";

export default function AnalyticsPage() {
  const [selectedPool, setSelectedPool] = useState<PoolInfo>(MOCK_POOLS[0]);

  const totalTvl = useMemo(() => MOCK_POOLS.reduce((s, p) => s + p.tvlUsd, 0), []);
  const totalVolume = useMemo(() => MOCK_POOLS.reduce((s, p) => s + p.volume24h, 0), []);
  const totalFees = useMemo(() => MOCK_POOLS.reduce((s, p) => s + p.fees24h, 0), []);
  const avgApr = useMemo(
    () =>
      MOCK_POOLS.reduce((s, p) => s + (p.fees24h / p.tvlUsd) * 365 * 100, 0) /
      MOCK_POOLS.length,
    []
  );

  const volumeHistory = useMemo(
    () =>
      Array.from({ length: 14 }, (_, i) => ({
        day: `Day ${i + 1}`,
        volume: 2000000 + Math.random() * 4000000,
        fees: 2000 + Math.random() * 10000,
      })),
    []
  );

  const twapObservations = useMemo(
    () =>
      Array.from({ length: 48 }, (_, i) => ({
        timestamp: Date.now() - (48 - i) * 1800000,
        price: 150 + Math.sin(i / 6) * 8 + (Math.random() - 0.5) * 4,
      })),
    []
  );

  const twapPrice = useMemo(
    () => twapObservations.reduce((s, o) => s + o.price, 0) / twapObservations.length,
    [twapObservations]
  );

  const maxVol = useMemo(() => Math.max(...volumeHistory.map((v) => v.volume)), [volumeHistory]);
  const maxPrice = useMemo(() => Math.max(...twapObservations.map((o) => o.price)), [twapObservations]);
  const minPrice = useMemo(() => Math.min(...twapObservations.map((o) => o.price)), [twapObservations]);

  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h1 className="text-3xl font-bold mb-2">Analytics</h1>
        <p className="text-muted-foreground">
          Pool overview, TWAP oracle data, and protocol analytics
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
              <Droplets className="h-4 w-4" /> Total TVL
            </div>
            <div className="text-2xl font-bold">{formatUsd(totalTvl)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
              <BarChart3 className="h-4 w-4" /> Volume (24h)
            </div>
            <div className="text-2xl font-bold">{formatUsd(totalVolume)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
              <DollarSign className="h-4 w-4" /> Fees (24h)
            </div>
            <div className="text-2xl font-bold">{formatUsd(totalFees)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
              <TrendingUp className="h-4 w-4" /> Avg APR
            </div>
            <div className="text-2xl font-bold text-green-400">{avgApr.toFixed(1)}%</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="pools" className="space-y-4">
        <TabsList>
          <TabsTrigger value="pools" className="gap-2">
            <Layers className="h-4 w-4" /> All Pools
          </TabsTrigger>
          <TabsTrigger value="twap" className="gap-2">
            <Clock className="h-4 w-4" /> TWAP Oracle
          </TabsTrigger>
          <TabsTrigger value="volume" className="gap-2">
            <BarChart3 className="h-4 w-4" /> Volume
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pools" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Pool Overview</CardTitle>
              <CardDescription>All active concentrated liquidity pools</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b text-muted-foreground">
                      <th className="text-left py-3 px-2">Pair</th>
                      <th className="text-left py-3 px-2">Fee</th>
                      <th className="text-right py-3 px-2">TVL</th>
                      <th className="text-right py-3 px-2">Volume 24h</th>
                      <th className="text-right py-3 px-2">Fees 24h</th>
                      <th className="text-right py-3 px-2">APR</th>
                      <th className="text-center py-3 px-2">Tick</th>
                    </tr>
                  </thead>
                  <tbody>
                    {MOCK_POOLS.map((pool) => (
                      <tr key={pool.address} className="border-b hover:bg-muted/50 transition-colors">
                        <td className="py-3 px-2">
                          <div className="flex items-center gap-2">
                            <div className="flex -space-x-1">
                              <div className="h-5 w-5 rounded-full bg-purple-500/30 flex items-center justify-center text-[10px] font-bold border border-background">
                                {pool.tokenA.symbol[0]}
                              </div>
                              <div className="h-5 w-5 rounded-full bg-blue-500/30 flex items-center justify-center text-[10px] font-bold border border-background">
                                {pool.tokenB.symbol[0]}
                              </div>
                            </div>
                            <span className="font-medium">{pool.tokenA.symbol}/{pool.tokenB.symbol}</span>
                          </div>
                        </td>
                        <td className="py-3 px-2">
                          <Badge variant="secondary" className="text-xs">
                            {(pool.feeRate / 10000).toFixed(2)}%
                          </Badge>
                        </td>
                        <td className="text-right py-3 px-2 font-mono">{formatUsd(pool.tvlUsd)}</td>
                        <td className="text-right py-3 px-2 font-mono">{formatUsd(pool.volume24h)}</td>
                        <td className="text-right py-3 px-2 font-mono">{formatUsd(pool.fees24h)}</td>
                        <td className="text-right py-3 px-2 font-mono text-green-400">
                          {((pool.fees24h / pool.tvlUsd) * 365 * 100).toFixed(1)}%
                        </td>
                        <td className="text-center py-3 px-2 font-mono text-xs">{pool.tick}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="twap" className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">TWAP Oracle</h2>
            <Select
              value={selectedPool.address}
              onValueChange={(v) => {
                const p = MOCK_POOLS.find((p) => p.address === v);
                if (p) setSelectedPool(p);
              }}
            >
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {MOCK_POOLS.map((p) => (
                  <SelectItem key={p.address} value={p.address}>
                    {p.tokenA.symbol}/{p.tokenB.symbol}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Card>
            <CardHeader className="pb-3">
              <div className="flex justify-between items-center">
                <CardTitle className="text-lg">
                  {selectedPool.tokenA.symbol}/{selectedPool.tokenB.symbol} Price
                </CardTitle>
                <Badge variant="outline" className="gap-1">
                  <Eye className="h-3 w-3" /> TWAP: ${twapPrice.toFixed(2)}
                </Badge>
              </div>
              <CardDescription>
                24-hour time-weighted average price with oracle observations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-48 flex items-end gap-px">
                {twapObservations.map((obs, i) => {
                  const range = maxPrice - minPrice || 1;
                  const height = ((obs.price - minPrice) / range) * 100;
                  return (
                    <div
                      key={i}
                      className="flex-1 rounded-t-sm transition-all hover:opacity-80"
                      style={{
                        height: `${Math.max(height, 2)}%`,
                        backgroundColor:
                          obs.price >= twapPrice
                            ? "hsl(142 76% 36% / 0.6)"
                            : "hsl(0 84% 60% / 0.6)",
                      }}
                      title={`$${obs.price.toFixed(2)}`}
                    />
                  );
                })}
              </div>
              <div className="flex justify-between mt-2 text-xs text-muted-foreground">
                <span>24h ago</span>
                <span>Now</span>
              </div>
              <div className="mt-2 border-t border-dashed border-primary/30 pt-2 text-xs text-center text-primary">
                TWAP Line: ${twapPrice.toFixed(2)}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Oracle Observations</CardTitle>
              <CardDescription>Recent TWAP oracle accumulator snapshots</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {MOCK_TWAP.observations.map((obs, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between py-2 px-3 rounded-md bg-muted/30 text-sm"
                  >
                    <span className="text-muted-foreground">
                      {new Date(obs.timestamp).toLocaleTimeString()}
                    </span>
                    <span className="font-mono">sqrtPrice: {obs.sqrtPrice.slice(0, 12)}...</span>
                    <Badge variant="outline" className="text-xs">tick: {obs.tick}</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="volume" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">14-Day Volume</CardTitle>
              <CardDescription>Daily trading volume across all pools</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-48 flex items-end gap-1">
                {volumeHistory.map((d, i) => {
                  const height = (d.volume / maxVol) * 100;
                  return (
                    <div key={i} className="flex-1 flex flex-col items-center gap-1">
                      <div
                        className="w-full rounded-t-sm bg-primary/70 hover:bg-primary transition-colors"
                        style={{ height: `${Math.max(height, 2)}%` }}
                        title={`${formatUsd(d.volume)}`}
                      />
                      {i % 2 === 0 && (
                        <span className="text-[10px] text-muted-foreground">{i + 1}</span>
                      )}
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Activity className="h-5 w-5" /> Liquidity Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end gap-px h-24">
                  {MOCK_TICKS.map((t, i) => {
                    const liq = Math.abs(parseInt(t.liquidityGross));
                    const maxL = Math.max(
                      ...MOCK_TICKS.map((x) => Math.abs(parseInt(x.liquidityGross)))
                    );
                    const height = maxL > 0 ? (liq / maxL) * 100 : 0;
                    return (
                      <div
                        key={i}
                        className="flex-1 rounded-t-sm bg-primary/50"
                        style={{ height: `${height}%` }}
                      />
                    );
                  })}
                </div>
                <div className="text-xs text-muted-foreground mt-2 text-center">
                  Tick range — concentrated liquidity depth
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Protocol Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Total Pools</span>
                  <span className="font-mono">{MOCK_POOLS.length}</span>
                </div>
                <Separator />
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Total Value Locked</span>
                  <span className="font-mono">{formatUsd(totalTvl)}</span>
                </div>
                <Separator />
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">24h Volume</span>
                  <span className="font-mono">{formatUsd(totalVolume)}</span>
                </div>
                <Separator />
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">24h Fees</span>
                  <span className="font-mono">{formatUsd(totalFees)}</span>
                </div>
                <Separator />
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Fee/Volume Ratio</span>
                  <span className="font-mono">{formatPercent(totalFees / totalVolume)}</span>
                </div>
                <Separator />
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Unique Tick Observations</span>
                  <span className="font-mono">{MOCK_TICKS.length}</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
