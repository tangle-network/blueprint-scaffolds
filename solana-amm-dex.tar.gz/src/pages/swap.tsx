import { useState, useMemo } from "react";
import type { TokenInfo } from "@/lib/types";
import { KNOWN_TOKENS, SOL_TOKEN, USDC_TOKEN } from "@/lib/constants";
import { getMockSwapQuote } from "@/lib/mock-data";
import { calcDynamicFee } from "@/lib/amm";
import { formatNumber, formatPercent } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { ArrowDown, ArrowUpDown, Settings2, Zap, TrendingUp, Shield } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export default function SwapPage() {
  const [tokenIn, setTokenIn] = useState<TokenInfo>(SOL_TOKEN);
  const [tokenOut, setTokenOut] = useState<TokenInfo>(USDC_TOKEN);
  const [amountIn, setAmountIn] = useState("");
  const [slippage, setSlippage] = useState(0.5);
  const [settingsOpen, setSettingsOpen] = useState(false);

  const quote = useMemo(() => {
    if (!amountIn || parseFloat(amountIn) <= 0) return null;
    return getMockSwapQuote(tokenIn.mint, tokenOut.mint, parseFloat(amountIn));
  }, [amountIn, tokenIn, tokenOut]);

  const dynamicFee = useMemo(
    () => calcDynamicFee(3000, 0.02, 0.4),
    []
  );

  const handleSwapTokens = () => {
    setTokenIn(tokenOut);
    setTokenOut(tokenIn);
    setAmountIn("");
  };

  const handleAmountChange = (val: string) => {
    if (/^\d*\.?\d*$/.test(val) || val === "") {
      setAmountIn(val);
    }
  };

  return (
    <div className="max-w-md mx-auto space-y-4">
      <div className="text-center mb-6">
        <h1 className="text-3xl font-bold mb-2">Swap</h1>
        <p className="text-muted-foreground">Concentrated liquidity swap with Jupiter & OpenBook routing</p>
      </div>

      <Card>
        <CardContent className="p-4 space-y-3">
          <div className="space-y-1">
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>You pay</span>
              <span>Balance: --</span>
            </div>
            <div className="flex gap-2">
              <Input
                placeholder="0.0"
                value={amountIn}
                onChange={(e) => handleAmountChange(e.target.value)}
                className="text-lg font-mono"
              />
              <TokenSelector tokens={KNOWN_TOKENS} selected={tokenIn} onSelect={setTokenIn} />
            </div>
          </div>

          <div className="flex justify-center">
            <Button variant="ghost" size="icon" onClick={handleSwapTokens} className="rounded-full h-8 w-8">
              <ArrowDown className="h-4 w-4" />
            </Button>
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>You receive</span>
              <span>Balance: --</span>
            </div>
            <div className="flex gap-2">
              <Input
                readOnly
                placeholder="0.0"
                value={quote ? quote.outAmount.toFixed(quote.outAmount < 1 ? 6 : 2) : ""}
                className="text-lg font-mono"
              />
              <TokenSelector tokens={KNOWN_TOKENS} selected={tokenOut} onSelect={setTokenOut} />
            </div>
          </div>
        </CardContent>
      </Card>

      {quote && (
        <Card>
          <CardContent className="p-4 space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Rate</span>
              <span>1 {tokenIn.symbol} = {(quote.outAmount / quote.inAmount).toFixed(4)} {tokenOut.symbol}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Price Impact</span>
              <span className={quote.priceImpact > 0.01 ? "text-yellow-400" : ""}>
                {formatPercent(quote.priceImpact)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Network Fee</span>
              <span>{quote.fee.toFixed(4)} {tokenIn.symbol}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Min. Received</span>
              <span>{quote.minimumOut.toFixed(2)} {tokenOut.symbol}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Dynamic Fee</span>
              <span>{(dynamicFee / 10000).toFixed(3)}%</span>
            </div>
            <Separator />
            <div className="flex justify-between">
              <span className="text-muted-foreground">Route</span>
              <span>{quote.route.join(" → ")}</span>
            </div>
            <div className="flex gap-1 mt-1">
              <Badge variant="secondary" className="text-xs gap-1">
                <Zap className="h-3 w-3" /> Jupiter
              </Badge>
              <Badge variant="secondary" className="text-xs gap-1">
                <TrendingUp className="h-3 w-3" /> OpenBook
              </Badge>
              <Badge variant="secondary" className="text-xs gap-1">
                <Shield className="h-3 w-3" /> JIT Liquidity
              </Badge>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="flex gap-2">
        <Dialog open={settingsOpen} onOpenChange={setSettingsOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" className="gap-2 flex-1">
              <Settings2 className="h-4 w-4" />
              Settings
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Swap Settings</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Slippage Tolerance: {slippage}%</label>
                <Slider
                  value={[slippage]}
                  onValueChange={([v]) => setSlippage(v)}
                  min={0.1}
                  max={5}
                  step={0.1}
                />
                <div className="flex gap-2">
                  {[0.1, 0.5, 1.0].map((v) => (
                    <Button key={v} variant={slippage === v ? "default" : "outline"} size="sm" onClick={() => setSlippage(v)}>
                      {v}%
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
        <Button className="flex-[2] gap-2" size="lg">
          <ArrowUpDown className="h-4 w-4" />
          Swap
        </Button>
      </div>
    </div>
  );
}

function TokenSelector({ tokens, selected, onSelect }: { tokens: TokenInfo[]; selected: TokenInfo; onSelect: (t: TokenInfo) => void }) {
  return (
    <Select value={selected.mint} onValueChange={(v) => { const t = tokens.find((t) => t.mint === v); if (t) onSelect(t); }}>
      <SelectTrigger className="w-28">
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {tokens.map((t) => (
          <SelectItem key={t.mint} value={t.mint}>
            {t.symbol}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
