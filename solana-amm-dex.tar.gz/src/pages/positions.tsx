import { useState } from "react";
import { MOCK_POSITIONS } from "@/lib/mock-data";
import { formatNumber, formatUsd, formatPercent, shortenAddress } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  LayoutDashboard,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Coins,
  ArrowUpRight,
  ArrowDownRight,
  ExternalLink,
  Gift,
  X,
  Minus,
} from "lucide-react";

export default function PositionsPage() {
  const [selectedPos, setSelectedPos] = useState<string | null>(null);

  const totalPnl = MOCK_POSITIONS.reduce((s, p) => s + p.pnlUsd, 0);
  const totalFees = MOCK_POSITIONS.reduce((s, p) => s + p.unclaimedFeesA + p.unclaimedFeesB, 0);
  const inRangeCount = MOCK_POSITIONS.filter((p) => p.inRange).length;

  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h1 className="text-3xl font-bold mb-2">Positions</h1>
        <p className="text-muted-foreground">Manage your concentrated liquidity positions</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground">Total Value</div>
            <div className="text-2xl font-bold">
              {formatUsd(MOCK_POSITIONS.reduce((s, p) => s + p.tokenAAmount * 152 + p.tokenBAmount, 0))}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground">Total PnL</div>
            <div className={`text-2xl font-bold ${totalPnl >= 0 ? "text-green-400" : "text-red-400"}`}>
              {totalPnl >= 0 ? "+" : ""}{formatUsd(totalPnl)}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground">In Range</div>
            <div className="text-2xl font-bold">
              {inRangeCount}/{MOCK_POSITIONS.length}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4">
        {MOCK_POSITIONS.map((pos) => (
          <Card key={pos.id} className="overflow-hidden">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="flex -space-x-2">
                    <div className="h-8 w-8 rounded-full bg-purple-500/30 flex items-center justify-center text-xs font-bold border-2 border-background">
                      {pos.pool.tokenA.symbol[0]}
                    </div>
                    <div className="h-8 w-8 rounded-full bg-blue-500/30 flex items-center justify-center text-xs font-bold border-2 border-background">
                      {pos.pool.tokenB.symbol[0]}
                    </div>
                  </div>
                  <div>
                    <div className="font-semibold">
                      {pos.pool.tokenA.symbol}/{pos.pool.tokenB.symbol}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {(pos.pool.feeRate / 10000).toFixed(2)}% fee · Tick [{pos.tickLower}, {pos.tickUpper}]
                    </div>
                  </div>
                </div>
                <Badge variant={pos.inRange ? "success" : "warning"}>
                  {pos.inRange ? "In Range" : "Out of Range"}
                </Badge>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-3">
                <div>
                  <div className="text-xs text-muted-foreground">Liquidity</div>
                  <div className="font-mono text-sm">{formatNumber(parseFloat(pos.liquidity))}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">{pos.pool.tokenA.symbol}</div>
                  <div className="font-mono text-sm">{pos.tokenAAmount.toFixed(4)}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">{pos.pool.tokenB.symbol}</div>
                  <div className="font-mono text-sm">{pos.tokenBAmount.toFixed(2)}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">PnL</div>
                  <div className={`font-mono text-sm ${pos.pnlUsd >= 0 ? "text-green-400" : "text-red-400"}`}>
                    {pos.pnlUsd >= 0 ? "+" : ""}{formatUsd(pos.pnlUsd)}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm">
                  <Gift className="h-4 w-4 text-yellow-400" />
                  <span className="text-muted-foreground">Unclaimed fees:</span>
                  <span className="font-mono">{pos.unclaimedFeesA.toFixed(4)} {pos.pool.tokenA.symbol}</span>
                  <span className="font-mono">{pos.unclaimedFeesB.toFixed(2)} {pos.pool.tokenB.symbol}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="gap-1">
                    <TrendingUp className="h-3 w-3" />
                    {pos.apr.toFixed(1)}% APR
                  </Badge>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" onClick={() => setSelectedPos(pos.id)}>
                        <ExternalLink className="h-3 w-3" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-lg">
                      <DialogHeader>
                        <DialogTitle>
                          {pos.pool.tokenA.symbol}/{pos.pool.tokenB.symbol} Position
                        </DialogTitle>
                      </DialogHeader>
                      <PositionDetail pos={pos} />
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

function PositionDetail({ pos }: { pos: typeof MOCK_POSITIONS[0] }) {
  const currentTick = pos.pool.tick;
  const rangePercent =
    pos.tickUpper !== pos.tickLower
      ? Math.round(((currentTick - pos.tickLower) / (pos.tickUpper - pos.tickLower)) * 100)
      : 50;

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <div className="text-sm font-medium">Price Range Position</div>
        <div className="flex items-center gap-4">
          <div className="flex-1">
            <div className="text-xs text-muted-foreground">Min Tick ({pos.tickLower})</div>
            <div className="font-mono">{Math.pow(1.0001, pos.tickLower).toFixed(4)}</div>
          </div>
          <div className="flex-1">
            <Progress value={Math.max(0, Math.min(100, rangePercent))} />
            <div className="text-xs text-center text-muted-foreground mt-1">
              {rangePercent}% — {pos.inRange ? "Active" : "Inactive"}
            </div>
          </div>
          <div className="flex-1 text-right">
            <div className="text-xs text-muted-foreground">Max Tick ({pos.tickUpper})</div>
            <div className="font-mono">{Math.pow(1.0001, pos.tickUpper).toFixed(4)}</div>
          </div>
        </div>
      </div>

      <Separator />

      <div className="grid grid-cols-2 gap-4 text-sm">
        <div>
          <div className="text-muted-foreground">{pos.pool.tokenA.symbol} deposited</div>
          <div className="font-mono text-lg">{pos.tokenAAmount.toFixed(4)}</div>
        </div>
        <div>
          <div className="text-muted-foreground">{pos.pool.tokenB.symbol} deposited</div>
          <div className="font-mono text-lg">{pos.tokenBAmount.toFixed(2)}</div>
        </div>
        <div>
          <div className="text-muted-foreground">Unclaimed {pos.pool.tokenA.symbol} fees</div>
          <div className="font-mono text-green-400">{pos.unclaimedFeesA.toFixed(4)}</div>
        </div>
        <div>
          <div className="text-muted-foreground">Unclaimed {pos.pool.tokenB.symbol} fees</div>
          <div className="font-mono text-green-400">{pos.unclaimedFeesB.toFixed(2)}</div>
        </div>
      </div>

      <Separator />

      <div className="grid grid-cols-2 gap-4 text-sm">
        <div>
          <div className="text-muted-foreground">Pool Address</div>
          <div className="font-mono text-xs">{shortenAddress(pos.pool.address, 8)}</div>
        </div>
        <div>
          <div className="text-muted-foreground">NFT Position ID</div>
          <div className="font-mono text-xs">{pos.id}</div>
        </div>
      </div>

      <div className="flex gap-2">
        <Button variant="outline" className="flex-1 gap-2">
          <Gift className="h-4 w-4" />
          Collect Fees
        </Button>
        <Button variant="outline" className="flex-1 gap-2">
          <Minus className="h-4 w-4" />
          Remove Liquidity
        </Button>
      </div>
    </div>
  );
}
