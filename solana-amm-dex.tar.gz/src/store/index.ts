import { create } from "zustand";
import type { Token, Pool, Position, PositionTab } from "@/types";
import { SOL, USDC, POOLS, POSITIONS } from "@/data/defaults";

interface AppState {
  swapFromToken: Token | null;
  swapToToken: Token | null;
  swapAmount: string;
  slippageBps: number;
  setSwapFromToken: (t: Token) => void;
  setSwapToToken: (t: Token) => void;
  setSwapAmount: (a: string) => void;
  setSlippageBps: (b: number) => void;

  selectedPool: Pool | null;
  positionTab: PositionTab;
  priceRange: { lower: number; upper: number };
  depositAmounts: { token0: string; token1: string };
  selectPool: (p: Pool) => void;
  setPositionTab: (t: PositionTab) => void;
  setPriceRange: (r: { lower: number; upper: number }) => void;
  setDepositAmounts: (d: { token0: string; token1: string }) => void;

  connected: boolean;
  positions: Position[];
  connectWallet: () => void;
  disconnectWallet: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  swapFromToken: SOL,
  swapToToken: USDC,
  swapAmount: "",
  slippageBps: 50,
  setSwapFromToken: (t) => set({ swapFromToken: t }),
  setSwapToToken: (t) => set({ swapToToken: t }),
  setSwapAmount: (a) => set({ swapAmount: a }),
  setSlippageBps: (b) => set({ slippageBps: b }),

  selectedPool: POOLS[0],
  positionTab: "add",
  priceRange: { lower: 95.0, upper: 105.0 },
  depositAmounts: { token0: "", token1: "" },
  selectPool: (p) => set({ selectedPool: p }),
  setPositionTab: (t) => set({ positionTab: t }),
  setPriceRange: (r) => set({ priceRange: r }),
  setDepositAmounts: (d) => set({ depositAmounts: d }),

  connected: false,
  positions: POSITIONS,
  connectWallet: () => set({ connected: true, positions: POSITIONS }),
  disconnectWallet: () => set({ connected: false, positions: [] }),
}));
