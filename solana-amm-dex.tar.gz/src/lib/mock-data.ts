import type { PoolInfo, PositionInfo, SwapQuote, TWAPData, TickData } from "./types";
import { SOL_TOKEN, USDC_TOKEN, USDT_TOKEN, BONK_TOKEN, RAY_TOKEN } from "./constants";

export const MOCK_POOLS: PoolInfo[] = [
  {
    address: "PoOL1SoLSolanaUSDc111111111111111111111111",
    tokenA: SOL_TOKEN,
    tokenB: USDC_TOKEN,
    feeRate: 3000,
    tickSpacing: 60,
    sqrtPrice: "18446744073709551616000",
    tick: 1000,
    liquidity: "1500000000000",
    tvlUsd: 12_450_000,
    volume24h: 3_200_000,
    fees24h: 9_600,
  },
  {
    address: "PoOL2UsdcUsdt1111111111111111111111111111",
    tokenA: USDC_TOKEN,
    tokenB: USDT_TOKEN,
    feeRate: 100,
    tickSpacing: 1,
    sqrtPrice: "18446744073709551616",
    tick: 0,
    liquidity: "50000000000000",
    tvlUsd: 45_000_000,
    volume24h: 18_500_000,
    fees24h: 1_850,
  },
  {
    address: "PoOL3SolBonk11111111111111111111111111111",
    tokenA: SOL_TOKEN,
    tokenB: BONK_TOKEN,
    feeRate: 10000,
    tickSpacing: 200,
    sqrtPrice: "79226653553422686600864006",
    tick: 200000,
    liquidity: "800000000000",
    tvlUsd: 2_100_000,
    volume24h: 850_000,
    fees24h: 8_500,
  },
  {
    address: "PoOL4SolRay111111111111111111111111111111",
    tokenA: SOL_TOKEN,
    tokenB: RAY_TOKEN,
    feeRate: 3000,
    tickSpacing: 60,
    sqrtPrice: "36893488147419103232",
    tick: -500,
    liquidity: "3000000000000",
    tvlUsd: 5_800_000,
    volume24h: 1_400_000,
    fees24h: 4_200,
  },
  {
    address: "PoOL5UsdcRay11111111111111111111111111111",
    tokenA: USDC_TOKEN,
    tokenB: RAY_TOKEN,
    feeRate: 500,
    tickSpacing: 10,
    sqrtPrice: "9223372036854775808",
    tick: -8000,
    liquidity: "12000000000000",
    tvlUsd: 8_200_000,
    volume24h: 2_100_000,
    fees24h: 1_050,
  },
];

export const MOCK_POSITIONS: PositionInfo[] = [
  {
    id: "pos-1",
    pool: MOCK_POOLS[0],
    tickLower: -100,
    tickUpper: 100,
    liquidity: "500000000",
    tokenAAmount: 12.5,
    tokenBAmount: 1875.0,
    unclaimedFeesA: 0.15,
    unclaimedFeesB: 22.5,
    inRange: true,
    pnlUsd: 345.2,
    apr: 42.5,
  },
  {
    id: "pos-2",
    pool: MOCK_POOLS[1],
    tickLower: -10,
    tickUpper: 10,
    liquidity: "20000000000",
    tokenAAmount: 25000,
    tokenBAmount: 25050,
    unclaimedFeesA: 5.2,
    unclaimedFeesB: 5.1,
    inRange: true,
    pnlUsd: 12.8,
    apr: 8.2,
  },
  {
    id: "pos-3",
    pool: MOCK_POOLS[2],
    tickLower: 180000,
    tickUpper: 220000,
    liquidity: "100000000",
    tokenAAmount: 3.2,
    tokenBAmount: 45000000,
    unclaimedFeesA: 0.01,
    unclaimedFeesB: 250000,
    inRange: false,
    pnlUsd: -120.5,
    apr: 125.0,
  },
  {
    id: "pos-4",
    pool: MOCK_POOLS[0],
    tickLower: -60,
    tickUpper: 60,
    liquidity: "800000000",
    tokenAAmount: 8.3,
    tokenBAmount: 1245.0,
    unclaimedFeesA: 0.08,
    unclaimedFeesB: 12.0,
    inRange: true,
    pnlUsd: 189.4,
    apr: 55.1,
  },
];

export const MOCK_SWAP_QUOTE: SwapQuote = {
  inputMint: SOL_TOKEN.mint,
  outputMint: USDC_TOKEN.mint,
  inAmount: 10,
  outAmount: 1520.45,
  priceImpact: 0.0012,
  fee: 0.456,
  feeTier: 3000,
  route: ["SOL", "USDC"],
  minimumOut: 1505.25,
};

export const MOCK_TWAP: TWAPData = {
  poolAddress: MOCK_POOLS[0].address,
  tokenA: SOL_TOKEN.symbol,
  tokenB: USDC_TOKEN.symbol,
  observations: [
    { timestamp: Date.now() - 3600000 * 24, sqrtPrice: "18300000000000000000", tick: 980 },
    { timestamp: Date.now() - 3600000 * 18, sqrtPrice: "18400000000000000000", tick: 990 },
    { timestamp: Date.now() - 3600000 * 12, sqrtPrice: "18500000000000000000", tick: 1010 },
    { timestamp: Date.now() - 3600000 * 6, sqrtPrice: "18450000000000000000", tick: 1005 },
    { timestamp: Date.now(), sqrtPrice: "18446744073709551616", tick: 1000 },
  ],
  averageSqrtPrice: "18430000000000000000",
  averageTick: 997,
};

export const MOCK_TICKS: TickData[] = Array.from({ length: 21 }, (_, i) => ({
  tick: -100 + i * 10,
  liquidityNet: String(Math.floor(Math.random() * 100000000) - 50000000),
  liquidityGross: String(Math.floor(Math.random() * 500000000)),
}));

export function getMockSwapQuote(inputToken: string, outputToken: string, amount: number): SwapQuote {
  const prices: Record<string, number> = {
    [SOL_TOKEN.mint]: 152.0,
    [USDC_TOKEN.mint]: 1.0,
    [USDT_TOKEN.mint]: 1.0,
    [BONK_TOKEN.mint]: 0.000025,
    [RAY_TOKEN.mint]: 2.15,
  };
  const inPrice = prices[inputToken] ?? 1;
  const outPrice = prices[outputToken] ?? 1;
  const outAmount = (amount * inPrice) / outPrice;
  const fee = amount * 0.003;
  const impact = Math.min(amount * 0.0001, 0.05);
  return {
    inputMint: inputToken,
    outputMint: outputToken,
    inAmount: amount,
    outAmount: outAmount * (1 - impact),
    priceImpact: impact,
    fee,
    feeTier: 3000,
    route: [inputToken === SOL_TOKEN.mint ? "SOL" : outputToken === USDC_TOKEN.mint ? "USDC" : "TOKEN"],
    minimumOut: outAmount * 0.99,
  };
}
