import type { TokenInfo, FeeTierConfig } from "./types";

export const SOL_TOKEN: TokenInfo = {
  symbol: "SOL",
  name: "Solana",
  mint: "So11111111111111111111111111111111111111112",
  decimals: 9,
  logoUri: "https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/So11111111111111111111111111111111111111112/logo.png",
};

export const USDC_TOKEN: TokenInfo = {
  symbol: "USDC",
  name: "USD Coin",
  mint: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
  decimals: 6,
  logoUri: "https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v/logo.png",
};

export const USDT_TOKEN: TokenInfo = {
  symbol: "USDT",
  name: "Tether USD",
  mint: "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",
  decimals: 6,
};

export const BONK_TOKEN: TokenInfo = {
  symbol: "BONK",
  name: "Bonk",
  mint: "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
  decimals: 5,
};

export const RAY_TOKEN: TokenInfo = {
  symbol: "RAY",
  name: "Raydium",
  mint: "4k3Dyjzvz8M4RimZmYe5gJGP7oM4ZyB5qERjAbKJqY",
  decimals: 6,
};

export const KNOWN_TOKENS: TokenInfo[] = [
  SOL_TOKEN,
  USDC_TOKEN,
  USDT_TOKEN,
  BONK_TOKEN,
  RAY_TOKEN,
];

export const FEE_TIERS: FeeTierConfig[] = [
  { feeRate: 100, tickSpacing: 1, description: "0.01% — Best for stablecoin pairs" },
  { feeRate: 500, tickSpacing: 10, description: "0.05% — Best for correlated pairs" },
  { feeRate: 3000, tickSpacing: 60, description: "0.3% — Best for most pairs" },
  { feeRate: 10000, tickSpacing: 200, description: "1% — Best for exotic pairs" },
];

export const MIN_TICK = -443636;
export const MAX_TICK = 443636;
export const MIN_SQRT_PRICE = 4295048016;
export const MAX_SQRT_PRICE = "79226653553422686600864006";

export const PROGRAM_ID = "ConcentraDEX11111111111111111111111111111111";
export const FACTORY_ADDRESS = "FcONcEpt1PX11111111111111111111111111111111";
export const ROUTER_ADDRESS = "RoutER11111111111111111111111111111111111111";
export const POSITION_NFT_ADDRESS = "PosNFT1111111111111111111111111111111111111";
export const TWAP_ORACLE_ADDRESS = "TWAP111111111111111111111111111111111111111";
