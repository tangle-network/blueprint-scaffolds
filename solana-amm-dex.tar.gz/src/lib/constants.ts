export const CLAMM_PROGRAM_ID = "CLAMMDeX1SWAP11111111111111111111111111111111";

export const FEE_TIER = {
  LOWEST: 100,
  LOW: 500,
  MEDIUM: 3000,
  HIGH: 10000,
} as const;

export const TICK_SPACING: Record<number, number> = {
  [FEE_TIER.LOWEST]: 1,
  [FEE_TIER.LOW]: 10,
  [FEE_TIER.MEDIUM]: 60,
  [FEE_TIER.HIGH]: 200,
};

export const MIN_TICK = -443636;
export const MAX_TICK = 443636;
export const MIN_SQRT_PRICE = 4295048016;
export const MAX_SQRT_PRICE = 79226653545326124419791481401679582n;

export const Q64 = 2n ** 64n;
export const Q128 = 2n ** 128n;

export const FEE_RATE_SCALE = 1_000_000;
export const DYNAMIC_FEE_ENABLED = true;
export const FLASH_LOAN_FEE_BPS = 30;

export const MAX_TICK_ARRAY_SIZE = 512;
export const POSITION_STATE_VERSION = 1;
export const POOL_STATE_VERSION = 1;

export const SEED_POOL = "pool";
export const SEED_POSITION = "position";
export const SEED_TICK_ARRAY = "tick_array";
export const SEED_ORACLE = "oracle";
export const SEED_FACTORY = "factory";
export const SEED_PROTOCOL = "protocol";
