export interface TokenInfo {
  symbol: string;
  name: string;
  mint: string;
  decimals: number;
  logoUri?: string;
}

export interface PoolInfo {
  address: string;
  tokenA: TokenInfo;
  tokenB: TokenInfo;
  feeRate: number;
  tickSpacing: number;
  sqrtPrice: string;
  tick: number;
  liquidity: string;
  tvlUsd: number;
  volume24h: number;
  fees24h: number;
}

export interface PositionInfo {
  id: string;
  pool: PoolInfo;
  tickLower: number;
  tickUpper: number;
  liquidity: string;
  tokenAAmount: number;
  tokenBAmount: number;
  unclaimedFeesA: number;
  unclaimedFeesB: number;
  inRange: boolean;
  pnlUsd: number;
  apr: number;
}

export interface SwapQuote {
  inputMint: string;
  outputMint: string;
  inAmount: number;
  outAmount: number;
  priceImpact: number;
  fee: number;
  feeTier: number;
  route: string[];
  minimumOut: number;
}

export interface TickData {
  tick: number;
  liquidityNet: string;
  liquidityGross: string;
}

export interface TWAPData {
  poolAddress: string;
  tokenA: string;
  tokenB: string;
  observations: Array<{ timestamp: number; sqrtPrice: string; tick: number }>;
  averageSqrtPrice: string;
  averageTick: number;
}

export interface FeeTierConfig {
  feeRate: number;
  tickSpacing: number;
  description: string;
}

export interface FlashLoanQuote {
  token: string;
  amount: number;
  fee: number;
  totalRepay: number;
}

export type SwapDirection = "exactIn" | "exactOut";
