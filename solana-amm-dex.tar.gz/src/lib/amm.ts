import BN from "bn.js";

const Q64 = new BN(1).shln(64);
const Q128 = new BN(1).shln(128);

export function sqrtPriceToTick(sqrtPriceX64: BN): number {
  const log2 = sqrtPriceX64.bitLength() - 65;
  const ratio = sqrtPriceX64.shln(64).div(new BN(1).shln(Math.abs(log2)));
  const lnRatio = ratio.toNumber() / Q64.toNumber();
  const log2Price = log2 + Math.log2(lnRatio || 1);
  return Math.floor(log2Price / Math.log2(1.0001));
}

export function tickToSqrtPrice(tick: number): BN {
  const ratio = Math.pow(1.0001, tick);
  const sqrtRatio = Math.sqrt(ratio);
  return new BN(Math.floor(sqrtRatio * Q64.toNumber()));
}

export function getSqrtPriceAtTick(tick: number): BN {
  const absTick = Math.abs(tick);
  let ratio =
    absTick & 0x1
      ? 0xfffcb933bd6fad37aa2d162d1a594001
      : 0x100000000000000000000000000000000;
  if (absTick & 0x2) ratio = (ratio * 0xfff97272373d413259a46990580e213a) / Q128.toNumber();
  if (absTick & 0x4) ratio = (ratio * 0xfff2e50f5f656932ef12357cf3c7fdcc) / Q128.toNumber();
  if (absTick & 0x8) ratio = (ratio * 0xffe5caca7e10e4e61c3624eaa0941cd0) / Q128.toNumber();
  if (absTick & 0x10) ratio = (ratio * 0xffcb9843d60f6159c9db58835c926644) / Q128.toNumber();
  if (absTick & 0x20) ratio = (ratio * 0xff973b41fa98c081472e6896dfb254c0) / Q128.toNumber();
  if (absTick & 0x40) ratio = (ratio * 0xff2ea16466c96a3843ec78b326b52861) / Q128.toNumber();
  if (absTick & 0x80) ratio = (ratio * 0xfe5dee046a99a2a811c461f1969c3053) / Q128.toNumber();
  if (absTick & 0x100) ratio = (ratio * 0xfcbe86c7900a88aedcffc83b479aa3a4) / Q128.toNumber();
  if (absTick & 0x200) ratio = (ratio * 0xf987a7253ac413176f2b074cf7815e54) / Q128.toNumber();
  if (absTick & 0x400) ratio = (ratio * 0xf3392b0822b70005940c7a398e4b70f3) / Q128.toNumber();
  if (absTick & 0x800) ratio = (ratio * 0xe7159475a2c29b7443b29c7fa6e889d9) / Q128.toNumber();
  if (absTick & 0x1000) ratio = (ratio * 0xd097f3bdfd2022b8845ad8f792aa5825) / Q128.toNumber();
  if (absTick & 0x2000) ratio = (ratio * 0xa9f746462d870fdf8a65dc1f90e061e5) / Q128.toNumber();
  if (absTick & 0x4000) ratio = (ratio * 0x70d869a156d2a1b890bb3df62baf32f7) / Q128.toNumber();
  if (absTick & 0x8000) ratio = (ratio * 0x31be135f97d08fd981231505542fcfa6) / Q128.toNumber();
  if (absTick & 0x10000) ratio = (ratio * 0x9aa508b5b7a84e28c6286a93b2e0d2b5) / Q128.toNumber();
  if (absTick & 0x20000) ratio = (ratio * 0x5d6af8dedb81196699c329225ee604) / Q128.toNumber();
  if (absTick & 0x40000) ratio = (ratio * 0x2216e584f5fa1ea92654c98e5e6c7e) / Q128.toNumber();
  if (absTick & 0x80000) ratio = (ratio * 0x48a170391f7dc42444e8fa2) / Q128.toNumber();
  if (tick > 0) ratio = (ratio * Q128.toNumber()) / 0x100000000000000000000000000000000;
  const result = new BN(Math.floor(ratio));
  return result.addn(1) > new BN(0) ? result.addn(1) : result;
}

export function getAmountADelta(
  sqrtRatioAX64: BN,
  sqrtRatioBX64: BN,
  liquidity: BN,
  roundUp: boolean
): BN {
  const numerator = liquidity.mul(sqrtRatioBX64.sub(sqrtRatioAX64));
  const denominator = sqrtRatioBX64;
  if (roundUp) return numerator.add(denominator).subn(1).div(denominator);
  return numerator.div(denominator);
}

export function getAmountBDelta(
  sqrtRatioAX64: BN,
  sqrtRatioBX64: BN,
  liquidity: BN,
  roundUp: boolean
): BN {
  const numerator = liquidity.mul(Q64);
  const denominator = sqrtRatioBX64;
  if (roundUp) return numerator.add(denominator).subn(1).div(denominator);
  return numerator.div(denominator);
}

export function calculateSwapAmount(
  sqrtPriceCurrent: BN,
  sqrtPriceTarget: BN,
  liquidity: BN,
  zeroForOne: boolean
): BN {
  if (zeroForOne) {
    return getAmountADelta(sqrtPriceTarget, sqrtPriceCurrent, liquidity, false);
  }
  return getAmountBDelta(sqrtPriceCurrent, sqrtPriceTarget, liquidity, false);
}

export function computePriceImpact(
  inputAmount: number,
  outputAmount: number,
  midPrice: number
): number {
  if (inputAmount === 0) return 0;
  const expectedOutput = inputAmount * midPrice;
  if (expectedOutput === 0) return 0;
  return 1 - outputAmount / expectedOutput;
}

export function calcDynamicFee(
  baseFee: number,
  volatility: number,
  utilization: number
): number {
  const volatilityAdj = Math.floor(volatility * 100);
  const utilizationAdj = Math.min(Math.floor(utilization * 50), 5000);
  return baseFee + volatilityAdj + utilizationAdj;
}

export function getLiquidityForAmounts(
  sqrtRatioAX64: BN,
  sqrtRatioBX64: BN,
  amount0: BN,
  amount1: BN
): BN {
  const [sqrtRatioLower, sqrtRatioUpper] = sqrtRatioAX64.lt(sqrtRatioBX64)
    ? [sqrtRatioAX64, sqrtRatioBX64]
    : [sqrtRatioBX64, sqrtRatioAX64];

  const amount0Liq = amount0.mul(sqrtRatioLower).mul(sqrtRatioUpper).div(
    sqrtRatioUpper.sub(sqrtRatioLower)
  );
  const amount1Liq = amount1.mul(Q64).div(
    sqrtRatioUpper.sub(sqrtRatioLower).gt(new BN(0)) ? sqrtRatioUpper.sub(sqrtRatioLower) : new BN(1)
  );

  return amount0Liq.lt(amount1Liq) ? amount0Liq : amount1Liq;
}

export function getTokenAmountsFromLiquidity(
  sqrtPriceCurrentX64: BN,
  sqrtRatioLowerX64: BN,
  sqrtRatioUpperX64: BN,
  liquidity: BN
): { amount0: BN; amount1: BN } {
  let amount0 = new BN(0);
  let amount1 = new BN(0);

  if (sqrtPriceCurrentX64.lte(sqrtRatioLowerX64)) {
    amount0 = getAmountADelta(sqrtRatioLowerX64, sqrtRatioUpperX64, liquidity, false);
  } else if (sqrtPriceCurrentX64.lt(sqrtRatioUpperX64)) {
    amount0 = getAmountADelta(sqrtPriceCurrentX64, sqrtRatioUpperX64, liquidity, false);
    amount1 = getAmountBDelta(sqrtRatioLowerX64, sqrtPriceCurrentX64, liquidity, false);
  } else {
    amount1 = getAmountBDelta(sqrtRatioLowerX64, sqrtRatioUpperX64, liquidity, false);
  }

  return { amount0, amount1 };
}

export function nearestUsableTick(tick: number, tickSpacing: number): number {
  return Math.round(tick / tickSpacing) * tickSpacing;
}
