import { Routes, Route } from "react-router-dom";
import { Layout } from "@/components/layout/layout";
import SwapPage from "@/pages/swap";
import LiquidityPage from "@/pages/liquidity";
import PositionsPage from "@/pages/positions";
import AnalyticsPage from "@/pages/analytics";
import FlashLoanPage from "@/pages/flash-loan";

export default function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<SwapPage />} />
        <Route path="/liquidity" element={<LiquidityPage />} />
        <Route path="/positions" element={<PositionsPage />} />
        <Route path="/analytics" element={<AnalyticsPage />} />
        <Route path="/flash-loan" element={<FlashLoanPage />} />
      </Routes>
    </Layout>
  );
}
