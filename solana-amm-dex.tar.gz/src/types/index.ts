export interface Token {
  mint: string;
  symbol: string;
  name: string;
  decimals: number;
  logoURI?: string;
  verified: boolean;
}

export interface FeeTier {
  feeBps: number;
  tickSpacing: number;
  label: string;
}

export interface Pool {
  address: string;
  token0: Token;
  token1: Token;
  feeTier: FeeTier;
  sqrtPrice: string;
  currentTick: number;
  liquidity: string;
  tvlUsdc: number;
  volume24h: number;
  fees24h: number;
}

export interface Position {
  id: string;
  pool: Pool;
  owner: string;
  tickLower: number;
  tickUpper: number;
  liquidity: string;
  token0Amount: number;
  token1Amount: number;
  unclaimedFees0: number;
  unclaimedFees1: number;
  inRange: boolean;
  nftMint: string;
}

export interface SwapQuote {
  inputMint: string;
  outputMint: string;
  amountIn: number;
  amountOut: number;
  minAmountOut: number;
  priceImpact: number;
  fee: number;
  route: string[];
}

export interface TWAPObservation {
  pool: string;
  timestamp: number;
  sqrtPriceX64: string;
  tick: number;
  cumulativePrice: string;
}

export interface TickData {
  tick: number;
  liquidityNet: string;
  liquidityGross: string;
}

export interface FlashLoanQuote {
  token: string;
  amount: number;
  fee: number;
  totalRepay: number;
}

export type SwapDirection = "exactIn" | "exactOut";

export type PositionTab = "add" | "remove" | "collect";
