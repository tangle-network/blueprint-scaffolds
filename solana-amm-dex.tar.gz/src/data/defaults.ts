import type { Token, FeeTier, Pool, Position } from "@/types";

export const SOL: Token = {
  mint: "So11111111111111111111111111111111111111112",
  symbol: "SOL",
  name: "Solana",
  decimals: 9,
  logoURI:
    "https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/So11111111111111111111111111111111111111112/logo.png",
  verified: true,
};

export const USDC: Token = {
  mint: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
  symbol: "USDC",
  name: "USD Coin",
  decimals: 6,
  logoURI:
    "https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v/logo.png",
  verified: true,
};

export const USDT: Token = {
  mint: "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",
  symbol: "USDT",
  name: "Tether USD",
  decimals: 6,
  verified: true,
};

export const RAY: Token = {
  mint: "4k3Dyjzvz8M4RimZmYe5gJGP7oM4ZyB5qERjAbKJqY",
  symbol: "RAY",
  name: "Raydium",
  decimals: 6,
  verified: true,
};

export const BONK: Token = {
  mint: "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
  symbol: "BONK",
  name: "Bonk",
  decimals: 5,
  verified: true,
};

export const JTO: Token = {
  mint: "jtojtomepa8beP8AuQc6eXt5FriJwfFMwQx2v2f9mCL",
  symbol: "JTO",
  name: "Jito",
  decimals: 9,
  verified: true,
};

export const JUP: Token = {
  mint: "JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN",
  symbol: "JUP",
  name: "Jupiter",
  decimals: 6,
  verified: true,
};

export const PYTH: Token = {
  mint: "HZ1JovNiVvGrGNiiYvEozEVgZ58xaU3RKwX8eACQBCt3",
  symbol: "PYTH",
  name: "Pyth Network",
  decimals: 6,
  verified: true,
};

export const TOKENS: Token[] = [SOL, USDC, USDT, RAY, BONK, JTO, JUP, PYTH];

export const FEE_TIER_01: FeeTier = {
  feeBps: 1,
  tickSpacing: 1,
  label: "0.01%",
};

export const FEE_TIER_05: FeeTier = {
  feeBps: 5,
  tickSpacing: 10,
  label: "0.05%",
};

export const FEE_TIER_30: FeeTier = {
  feeBps: 30,
  tickSpacing: 60,
  label: "0.3%",
};

export const FEE_TIER_100: FeeTier = {
  feeBps: 100,
  tickSpacing: 200,
  label: "1%",
};

export const FEE_TIERS: FeeTier[] = [
  FEE_TIER_01,
  FEE_TIER_05,
  FEE_TIER_30,
  FEE_TIER_100,
];

const MOCK_WALLET = "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU";

export const POOLS: Pool[] = [
  {
    address: "CLAMM_SOL_USDC_30BPS_111111111111111111111",
    token0: SOL,
    token1: USDC,
    feeTier: FEE_TIER_30,
    sqrtPrice: "18446744073709551616000",
    currentTick: 184180,
    liquidity: "1500000000000",
    tvlUsdc: 12_450_000,
    volume24h: 3_100_000,
    fees24h: 9_300,
  },
  {
    address: "CLAMM_SOL_USDC_01BPS_111111111111111111111",
    token0: SOL,
    token1: USDC,
    feeTier: FEE_TIER_01,
    sqrtPrice: "18447000000000000000000",
    currentTick: 184175,
    liquidity: "800000000000",
    tvlUsdc: 8_200_000,
    volume24h: 15_700_000,
    fees24h: 1_570,
  },
  {
    address: "CLAMM_SOL_RAY_30BPS_1111111111111111111111",
    token0: SOL,
    token1: RAY,
    feeTier: FEE_TIER_30,
    sqrtPrice: "36893488147419103232",
    currentTick: -66720,
    liquidity: "3000000000000",
    tvlUsdc: 1_800_000,
    volume24h: 420_000,
    fees24h: 1_260,
  },
  {
    address: "CLAMM_BONK_SOL_100BPS_11111111111111111111",
    token0: BONK,
    token1: SOL,
    feeTier: FEE_TIER_100,
    sqrtPrice: "79226653553422686600",
    currentTick: -320160,
    liquidity: "500000000000",
    tvlUsdc: 980_000,
    volume24h: 210_000,
    fees24h: 2_100,
  },
];

export const POSITIONS: Position[] = [
  {
    id: "pos-1",
    pool: POOLS[0],
    owner: MOCK_WALLET,
    tickLower: 183720,
    tickUpper: 184680,
    liquidity: "500000000",
    token0Amount: 12.5,
    token1Amount: 1875.0,
    unclaimedFees0: 0.15,
    unclaimedFees1: 22.5,
    inRange: true,
    nftMint: "NFT111111111111111111111111111111111111111",
  },
  {
    id: "pos-2",
    pool: POOLS[1],
    owner: MOCK_WALLET,
    tickLower: 184080,
    tickUpper: 184260,
    liquidity: "20000000000",
    token0Amount: 5.8,
    token1Amount: 870.0,
    unclaimedFees0: 0.02,
    unclaimedFees1: 3.1,
    inRange: true,
    nftMint: "NFT222222222222222222222222222222222222222",
  },
  {
    id: "pos-3",
    pool: POOLS[2],
    owner: MOCK_WALLET,
    tickLower: -67200,
    tickUpper: -66240,
    liquidity: "100000000",
    token0Amount: 3.2,
    token1Amount: 450.0,
    unclaimedFees0: 0.05,
    unclaimedFees1: 7.8,
    inRange: false,
    nftMint: "NFT333333333333333333333333333333333333333",
  },
];

export const PRICES: Record<string, number> = {
  [SOL.mint]: 152.0,
  [USDC.mint]: 1.0,
  [USDT.mint]: 1.0,
  [RAY.mint]: 2.15,
  [BONK.mint]: 0.000025,
  [JTO.mint]: 2.84,
  [JUP.mint]: 0.92,
  [PYTH.mint]: 0.38,
};

export const PROGRAM_ID = "CLAMM111111111111111111111111111111111111111";
export const MIN_TICK = -443636;
export const MAX_TICK = 443636;
