use anchor_lang::prelude::*;

declare_id!("CLAMMqPtGKahESp8njQJ7UPkGSq8w18h6ZQfH3qQZ1G");

pub mod constants {
    pub const MIN_TICK: i32 = -443636;
    pub const MAX_TICK: i32 = 443636;
    pub const MIN_SQRT_PRICE: u128 = 4295048016;
    pub const MAX_SQRT_PRICE: u128 = 79226673515401279992447579055;
    pub const TICK_SPACING_1: i32 = 1;
    pub const TICK_SPACING_10: i32 = 10;
    pub const TICK_SPACING_60: i32 = 60;
    pub const TICK_SPACING_200: i32 = 200;
    pub const FEE_RATE_DENOMINATOR: u64 = 1_000_000;
    pub const PROTOCOL_FEE_DENOMINATOR: u64 = 4;
    pub const MAX_FEE_RATE: u64 = 100_000;
    pub const FLASH_LOAN_FEE_BPS: u64 = 300;
    pub const BPS_DENOMINATOR: u64 = 10_000;
    pub const TWAP_PERIOD: u64 = 1800;
}

pub mod errors {
    use anchor_lang::prelude::*;

    #[error_code]
    pub enum ClammError {
        #[msg("Invalid tick range")]
        InvalidTickRange,
        #[msg("Tick out of range")]
        TickOutOfRange,
        #[msg("Invalid tick spacing")]
        InvalidTickSpacing,
        #[msg("Insufficient liquidity")]
        InsufficientLiquidity,
        #[msg("Invalid sqrt price")]
        InvalidSqrtPrice,
        #[msg("Price slippage exceeded")]
        PriceSlippageExceeded,
        #[msg("Insufficient output amount")]
        InsufficientOutputAmount,
        #[msg("Invalid fee tier")]
        InvalidFeeTier,
        #[msg("Pool already exists")]
        PoolAlreadyExists,
        #[msg("Invalid token order")]
        InvalidTokenOrder,
        #[msg("Position has no liquidity")]
        PositionEmpty,
        #[msg("Flash loan not repaid")]
        FlashLoanNotRepaid,
        #[msg("Unauthorized")]
        Unauthorized,
        #[msg("Math overflow")]
        MathOverflow,
        #[msg("Invalid amount")]
        InvalidAmount,
        #[msg("Dynamic fee exceeds max")]
        DynamicFeeExceedsMax,
        #[msg("JIT liquidity expired")]
        JitLiquidityExpired,
        #[msg("Single sided range invalid")]
        SingleSidedRangeInvalid,
    }
}

pub mod math {
    use super::errors::ClammError;

    pub fn mul_shl(a: u128, b: u128) -> Result<u128> {
        a.checked_mul(b)
            .ok_or(error!(ClammError::MathOverflow))
    }

    pub fn get_amount_delta_a(
        sqrt_price_lower: u128,
        sqrt_price_upper: u128,
        liquidity: u128,
        round_up: bool,
    ) -> Result<u64> {
        let numerator = liquidity
            .checked_mul(sqrt_price_upper.checked_sub(sqrt_price_lower).unwrap())
            .ok_or(error!(ClammError::MathOverflow))?;
        let denominator = sqrt_price_lower.checked_mul(sqrt_price_upper).unwrap();
        let quotient = numerator / denominator;
        let remainder = numerator % denominator;
        let result = if round_up && remainder > 0 {
            quotient.checked_add(1).unwrap()
        } else {
            quotient
        };
        u64::try_from(result).map_err(|_| error!(ClammError::MathOverflow))
    }

    pub fn get_amount_delta_b(
        sqrt_price_lower: u128,
        sqrt_price_upper: u128,
        liquidity: u128,
        round_up: bool,
    ) -> Result<u64> {
        let numerator = liquidity
            .checked_mul(sqrt_price_upper.checked_sub(sqrt_price_lower).unwrap())
            .ok_or(error!(ClammError::MathOverflow))?;
        let result = numerator >> 64;
        let remainder = numerator & ((1u128 << 64) - 1);
        if round_up && remainder > 0 {
            Ok(result.checked_add(1).unwrap() as u64)
        } else {
            Ok(result as u64)
        }
    }

    pub fn get_next_sqrt_price(
        sqrt_price: u128,
        liquidity: u128,
        amount: u64,
        is_amount_a: bool,
    ) -> Result<u128> {
        if is_amount_a {
            let numerator = sqrt_price
                .checked_mul(liquidity)
                .ok_or(error!(ClammError::MathOverflow))?;
            let denominator = liquidity
                .checked_add((amount as u128).checked_mul(sqrt_price).ok_or(error!(ClammError::MathOverflow))? >> 64)
                .ok_or(error!(ClammError::MathOverflow))?;
            Ok(numerator / denominator)
        } else {
            let product = (amount as u128)
                .checked_mul(1 << 64)
                .ok_or(error!(ClammError::MathOverflow))?;
            let quotient = product / liquidity;
            Ok(sqrt_price.checked_add(quotient).ok_or(error!(ClammError::MathOverflow))?)
        }
    }

    pub fn tick_to_sqrt_price(tick: i32) -> Result<u128> {
        let abs_tick = tick.unsigned_abs() as u64;
        if abs_tick > 443636 {
            return Err(error!(ClammError::TickOutOfRange));
        }
        let ratio = if tick >= 0 {
            let mut r: u128 = 1 << 64;
            let mut abs_t = abs_tick;
            let mut bit = 0;
            while abs_t > 0 {
                if abs_t & 1 == 1 {
                    let factor = TICK_FACTORS[bit];
                    r = r.checked_mul(factor).unwrap() >> 64;
                }
                abs_t >>= 1;
                bit += 1;
            }
            r
        } else {
            let mut r: u128 = 1 << 64;
            let mut abs_t = abs_tick;
            let mut bit = 0;
            while abs_t > 0 {
                if abs_t & 1 == 1 {
                    let factor = TICK_FACTORS[bit];
                    r = (r << 64) / factor;
                }
                abs_t >>= 1;
                bit += 1;
            }
            r
        };
        Ok(ratio)
    }

    pub fn sqrt_price_to_tick(sqrt_price: u128) -> Result<i32> {
        if sqrt_price < 4295048016 || sqrt_price > 79226673515401279992447579055 {
            return Err(error!(ClammError::InvalidSqrtPrice));
        }
        let ratio = sqrt_price;
        let mut tick: i32 = 0;
        let mut msb: u32 = 128 - ratio.leading_zeros();
        let pow2 = if msb >= 64 { msb - 64 } else { 0 };
        let mut r = if pow2 > 0 { ratio >> (pow2 - 1) } else { ratio << (1 - pow2) };
        r >>= 63;
        tick += (pow2 as i32) * 64;
        if r >= 2 {
            r >>= 1;
            tick += 32;
        }
        if r >= 1 {
            r >>= 1;
            tick += 16;
        }
        if r >= 1 {
            r >>= 1;
            tick += 8;
        }
        if r >= 1 {
            r >>= 1;
            tick += 4;
        }
        if r >= 1 {
            r >>= 1;
            tick += 2;
        }
        if r >= 1 {
            tick += 1;
        }
        Ok(tick - 64)
    }

    const TICK_FACTORS: [u128; 20] = [
        0xfffcb933bd6fad37aa2d162d1a594001,
        0xfff97272373d413259a46990580e213a,
        0xfff2e50f5f656932ef12357cf3c7fdcc,
        0xffe5caca7e10e4e61c3624eaa0941cd0,
        0xffcb9843d60f6159c9db58835c926644,
        0xff973b41fa98c081472e6896dfb254c0,
        0xff2ea16466c96a3843ad78a361a96c9a,
        0xfe5dee046a99a2a811c461f1969c3053,
        0xfcbe86c7900a88aedcffc83b479aa3a4,
        0xf987a7253ac413176f2b074cf7815e54,
        0xf3392b0822b70005940c7a398e4b70f3,
        0xe7159475a2c29b7443b29c7fa6e889d9,
        0xd621f12c8fada14894e8d961e1ec3d27,
        0xbda0615e0b99380e1ac34b7bed5b019,
        0x9d6d30e1c80d22d2a4d7c0df15f14db2,
        0x8c949cf82478f8a5b1f6bc75d7b38ef2,
        0x66f10b31c9d75a8d90095f19349d08e4,
        0x4d1f33cfc2e9f0b6ed5d1e6bdc219da,
        0x30e28c3718ba5d1bce35c8f73dda1fb,
        0x16bda94f479e9c16bbe5934d6c219b8,
    ];
}

pub mod state;
pub mod instructions;

use instructions::*;
