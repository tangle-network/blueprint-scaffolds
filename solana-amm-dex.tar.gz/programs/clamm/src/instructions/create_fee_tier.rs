use anchor_lang::prelude::*;
use crate::state::{FactoryState, FeeTier};
use crate::constants::*;
use crate::errors::ClammError;

#[derive(Accounts)]
#[instruction(fee_rate: u64, tick_spacing: i32)]
pub struct CreateFeeTier<'info> {
    #[account(
        mut,
        constraint = factory.admin == authority.key() @ ClammError::Unauthorized
    )]
    pub factory: Account<'info, FactoryState>,
    #[account(
        init,
        payer = authority,
        space = FeeTier::LEN,
        seeds = [
            b"fee_tier",
            factory.key().as_ref(),
            &fee_rate.to_le_bytes(),
            &tick_spacing.to_le_bytes()
        ],
        bump
    )]
    pub fee_tier: Account<'info, FeeTier>,
    #[account(mut)]
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}

pub fn create_fee_tier(ctx: Context<CreateFeeTier>, fee_rate: u64, tick_spacing: i32) -> Result<()> {
    require!(
        fee_rate <= MAX_FEE_RATE,
        ClammError::InvalidFeeTier
    );
    require!(
        tick_spacing > 0,
        ClammError::InvalidTickSpacing
    );

    let fee_tier = &mut ctx.accounts.fee_tier;
    fee_tier.fee_rate = fee_rate;
    fee_tier.tick_spacing = tick_spacing;
    fee_tier.is_supported = true;
    fee_tier.default_protocol_fee_rate = ctx.accounts.factory.default_protocol_fee_rate;
    fee_tier.bump = *ctx.bumps.get("fee_tier").unwrap();
    Ok(())
}
