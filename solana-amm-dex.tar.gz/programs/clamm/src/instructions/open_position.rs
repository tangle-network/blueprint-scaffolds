use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Mint};
use crate::state::{Pool, Position, PositionNFT, Tick};
use crate::errors::ClammError;
use crate::math;

#[derive(Accounts)]
pub struct OpenPosition<'info> {
    #[account(mut)]
    pub payer: Signer<'info>,
    #[account(
        mut,
        constraint = pool.token_mint_a == token_mint_a.key()
    )]
    pub pool: Account<'info, Pool>,
    #[account(
        init,
        payer = payer,
        space = Position::LEN,
        seeds = [
            b"position",
            pool.key().as_ref(),
            nft_mint.key().as_ref()
        ],
        bump
    )]
    pub position: Account<'info, Position>,
    #[account(
        init,
        payer = payer,
        mint::decimals = 0,
        mint::authority = position_nft,
        mint::freeze_authority = position_nft,
    )]
    pub nft_mint: Account<'info, Mint>,
    #[account(
        init,
        payer = payer,
        space = PositionNFT::LEN,
        seeds = [
            b"position_nft",
            nft_mint.key().as_ref()
        ],
        bump
    )]
    pub position_nft: Account<'info, PositionNFT>,
    /// CHECK: checked by constraint
    pub token_mint_a: AccountInfo<'info>,
    #[account(mut)]
    pub token_account_a: Account<'info, TokenAccount>,
    #[account(mut)]
    pub token_account_b: Account<'info, TokenAccount>,
    #[account(mut)]
    pub token_vault_a: Account<'info, TokenAccount>,
    #[account(mut)]
    pub token_vault_b: Account<'info, TokenAccount>,
    #[account(
        mut,
        constraint = tick_lower.pool == pool.key()
    )]
    pub tick_lower: Account<'info, Tick>,
    #[account(
        mut,
        constraint = tick_upper.pool == pool.key()
    )]
    pub tick_upper: Account<'info, Tick>,
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

pub fn open_position(
    ctx: Context<OpenPosition>,
    tick_lower_index: i32,
    tick_upper_index: i32,
    liquidity_delta: u128,
    amount_a_max: u64,
    amount_b_max: u64,
) -> Result<()> {
    require!(
        tick_lower_index < tick_upper_index,
        ClammError::InvalidTickRange
    );
    require!(
        tick_lower_index >= crate::constants::MIN_TICK && tick_upper_index <= crate::constants::MAX_TICK,
        ClammError::TickOutOfRange
    );

    let position = &mut ctx.accounts.position;
    position.nft_mint = ctx.accounts.nft_mint.key();
    position.pool = ctx.accounts.pool.key();
    position.owner = ctx.accounts.payer.key();
    position.tick_lower_index = tick_lower_index;
    position.tick_upper_index = tick_upper_index;
    position.liquidity = 0;
    position.fee_growth_checkpoint_a = 0;
    position.fee_growth_checkpoint_b = 0;
    position.fees_owed_a = 0;
    position.fees_owed_b = 0;
    position.created_at = Clock::get()?.unix_timestamp as u64;
    position.is_jit = false;
    position.jit_expiry = 0;
    position.bump = *ctx.bumps.get("position").unwrap();

    let position_nft = &mut ctx.accounts.position_nft;
    position_nft.position = position.key();
    position_nft.bump = *ctx.bumps.get("position_nft").unwrap();

    if liquidity_delta > 0 {
        let pool = &mut ctx.accounts.pool;
        let sqrt_price_lower = math::tick_to_sqrt_price(tick_lower_index)?;
        let sqrt_price_upper = math::tick_to_sqrt_price(tick_upper_index)?;

        let amount_a = math::get_amount_delta_a(
            sqrt_price_lower, sqrt_price_upper, liquidity_delta, true,
        )?;
        let amount_b = math::get_amount_delta_b(
            sqrt_price_lower, sqrt_price_upper, liquidity_delta, true,
        )?;

        require!(amount_a <= amount_a_max, ClammError::PriceSlippageExceeded);
        require!(amount_b <= amount_b_max, ClammError::PriceSlippageExceeded);

        token::transfer(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                token::Transfer {
                    from: ctx.accounts.token_account_a.to_account_info(),
                    to: ctx.accounts.token_vault_a.to_account_info(),
                    authority: ctx.accounts.payer.to_account_info(),
                },
            ),
            amount_a,
        )?;

        token::transfer(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                token::Transfer {
                    from: ctx.accounts.token_account_b.to_account_info(),
                    to: ctx.accounts.token_vault_b.to_account_info(),
                    authority: ctx.accounts.payer.to_account_info(),
                },
            ),
            amount_b,
        )?;

        position.liquidity = liquidity_delta;
        position.fee_growth_checkpoint_a = pool.fee_growth_global_a;
        position.fee_growth_checkpoint_b = pool.fee_growth_global_b;

        pool.liquidity = pool.liquidity.checked_add(liquidity_delta).unwrap();

        update_tick(&mut ctx.accounts.tick_lower, liquidity_delta, true, pool.fee_growth_global_a, pool.fee_growth_global_b);
        update_tick(&mut ctx.accounts.tick_upper, liquidity_delta, false, pool.fee_growth_global_a, pool.fee_growth_global_b);
    }

    Ok(())
}

fn update_tick(tick: &mut Tick, liquidity_delta: u128, is_lower: bool, fee_growth_a: u128, fee_growth_b: u128) {
    if tick.liquidity_gross == 0 {
        tick.fee_growth_outside_a = fee_growth_a;
        tick.fee_growth_outside_b = fee_growth_b;
    }
    tick.liquidity_gross = tick.liquidity_gross.checked_add(liquidity_delta).unwrap();
    if is_lower {
        tick.liquidity_net = tick.liquidity_net.checked_add(liquidity_delta as i128).unwrap();
    } else {
        tick.liquidity_net = tick.liquidity_net.checked_sub(liquidity_delta as i128).unwrap();
    }
}
