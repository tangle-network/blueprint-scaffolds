use anchor_lang::prelude::*;
use crate::state::FactoryState;

#[derive(Accounts)]
pub struct CreateFactory<'info> {
    #[account(
        init,
        payer = admin,
        space = FactoryState::LEN,
        seeds = [b"factory"],
        bump
    )]
    pub factory: Account<'info, FactoryState>,
    #[account(mut)]
    pub admin: Signer<'info>,
    pub system_program: Program<'info, System>,
}

pub fn create_factory(ctx: Context<CreateFactory>) -> Result<()> {
    let factory = &mut ctx.accounts.factory;
    factory.admin = ctx.accounts.admin.key();
    factory.pool_count = 0;
    factory.fee_authority = ctx.accounts.admin.key();
    factory.default_protocol_fee_rate = 250_000;
    factory.bump = *ctx.bumps.get("factory").unwrap();
    Ok(())
}
