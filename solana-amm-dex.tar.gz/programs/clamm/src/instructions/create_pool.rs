use anchor_lang::prelude::*;
use anchor_spl::token::{TokenAccount, Token};
use crate::state::{FactoryState, FeeTier, Pool, Tick};
use crate::constants::*;
use crate::errors::ClammError;
use crate::math;

#[derive(Accounts)]
#[instruction(tick_spacing: i32)]
pub struct CreatePool<'info> {
    #[account(mut)]
    pub factory: Account<'info, FactoryState>,
    #[account(
        constraint = fee_tier.is_supported @ ClammError::InvalidFeeTier
    )]
    pub fee_tier: Account<'info, FeeTier>,
    #[account(
        init,
        payer = payer,
        space = Pool::LEN,
        seeds = [
            b"pool",
            factory.key().as_ref(),
            token_mint_a.key().as_ref(),
            token_mint_b.key().as_ref(),
            &tick_spacing.to_le_bytes()
        ],
        bump
    )]
    pub pool: Account<'info, Pool>,
    /// CHECK: validated by constraint
    pub token_mint_a: AccountInfo<'info>,
    /// CHECK: validated by constraint
    pub token_mint_b: AccountInfo<'info>,
    #[account(
        init,
        payer = payer,
        token::mint = token_mint_a,
        token::authority = pool
    )]
    pub token_vault_a: Account<'info, TokenAccount>,
    #[account(
        init,
        payer = payer,
        token::mint = token_mint_b,
        token::authority = pool
    )]
    pub token_vault_b: Account<'info, TokenAccount>,
    #[account(
        init,
        payer = payer,
        space = Tick::LEN,
        seeds = [
            b"tick",
            pool.key().as_ref(),
            &0i32.to_le_bytes()
        ],
        bump
    )]
    pub initial_tick: Account<'info, Tick>,
    #[account(mut)]
    pub payer: Signer<'info>,
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
}

pub fn create_pool(
    ctx: Context<CreatePool>,
    tick_spacing: i32,
    initial_sqrt_price: u128,
    initial_tick: i32,
) -> Result<()> {
    require!(
        token_ordering(ctx.accounts.token_mint_a.key(), ctx.accounts.token_mint_b.key()),
        ClammError::InvalidTokenOrder
    );
    require!(
        initial_sqrt_price >= MIN_SQRT_PRICE && initial_sqrt_price <= MAX_SQRT_PRICE,
        ClammError::InvalidSqrtPrice
    );
    require!(
        initial_tick >= MIN_TICK && initial_tick <= MAX_TICK,
        ClammError::TickOutOfRange
    );

    let pool = &mut ctx.accounts.pool;
    pool.factory = ctx.accounts.factory.key();
    pool.token_mint_a = ctx.accounts.token_mint_a.key();
    pool.token_mint_b = ctx.accounts.token_mint_b.key();
    pool.token_vault_a = ctx.accounts.token_vault_a.key();
    pool.token_vault_b = ctx.accounts.token_vault_b.key();
    pool.fee_rate = ctx.accounts.fee_tier.fee_rate;
    pool.protocol_fee_rate = ctx.accounts.fee_tier.default_protocol_fee_rate;
    pool.tick_spacing = tick_spacing;
    pool.liquidity = 0;
    pool.sqrt_price = initial_sqrt_price;
    pool.current_tick_index = initial_tick;
    pool.fee_growth_global_a = 0;
    pool.fee_growth_global_b = 0;
    pool.protocol_fee_token_a = 0;
    pool.protocol_fee_token_b = 0;
    pool.swap_in_progress = false;
    pool.twap_start_sqrt_price = initial_sqrt_price;
    pool.twap_last_updated = Clock::get()?.unix_timestamp as u64;
    pool.twap_accumulator = 0;
    pool.dynamic_fee_enabled = false;
    pool.volume_usd_24h = 0;
    pool.bump = *ctx.bumps.get("pool").unwrap();

    let tick = &mut ctx.accounts.initial_tick;
    tick.pool = pool.key();
    tick.tick_index = 0;
    tick.liquidity_gross = 0;
    tick.liquidity_net = 0;
    tick.fee_growth_outside_a = 0;
    tick.fee_growth_outside_b = 0;
    tick.bump = *ctx.bumps.get("initial_tick").unwrap();

    ctx.accounts.factory.pool_count += 1;
    Ok(())
}

fn token_ordering(mint_a: Pubkey, mint_b: Pubkey) -> bool {
    mint_a < mint_b
}
