use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount};
use crate::state::Position;
use crate::errors::ClammError;

#[derive(Accounts)]
pub struct ClosePosition<'info> {
    #[account(mut)]
    pub owner: Signer<'info>,
    #[account(
        mut,
        constraint = position.owner == owner.key() @ ClammError::Unauthorized,
        constraint = position.liquidity == 0 @ ClammError::PositionEmpty,
        close = owner
    )]
    pub position: Account<'info, Position>,
    pub system_program: Program<'info, System>,
}

pub fn close_position(_ctx: Context<ClosePosition>) -> Result<()> {
    Ok(())
}
