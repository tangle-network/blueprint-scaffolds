use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount};
use crate::state::{Pool, Position, Tick};
use crate::errors::ClammError;
use crate::math;

#[derive(Accounts)]
pub struct IncreaseLiquidity<'info> {
    #[account(mut)]
    pub owner: Signer<'info>,
    #[account(
        mut,
        constraint = position.owner == owner.key() @ ClammError::Unauthorized
    )]
    pub position: Account<'info, Position>,
    #[account(mut)]
    pub pool: Account<'info, Pool>,
    #[account(mut)]
    pub token_account_a: Account<'info, TokenAccount>,
    #[account(mut)]
    pub token_account_b: Account<'info, TokenAccount>,
    #[account(mut)]
    pub token_vault_a: Account<'info, TokenAccount>,
    #[account(mut)]
    pub token_vault_b: Account<'info, TokenAccount>,
    #[account(mut)]
    pub tick_lower: Account<'info, Tick>,
    #[account(mut)]
    pub tick_upper: Account<'info, Tick>,
    pub token_program: Program<'info, Token>,
}

pub fn increase_liquidity(
    ctx: Context<IncreaseLiquidity>,
    liquidity_delta: u128,
    amount_a_max: u64,
    amount_b_max: u64,
) -> Result<()> {
    require!(liquidity_delta > 0, ClammError::InvalidAmount);

    let sqrt_price_lower = math::tick_to_sqrt_price(ctx.accounts.position.tick_lower_index)?;
    let sqrt_price_upper = math::tick_to_sqrt_price(ctx.accounts.position.tick_upper_index)?;

    let amount_a = math::get_amount_delta_a(
        sqrt_price_lower, sqrt_price_upper, liquidity_delta, true,
    )?;
    let amount_b = math::get_amount_delta_b(
        sqrt_price_lower, sqrt_price_upper, liquidity_delta, true,
    )?;

    require!(amount_a <= amount_a_max, ClammError::PriceSlippageExceeded);
    require!(amount_b <= amount_b_max, ClammError::PriceSlippageExceeded);

    token::transfer(
        CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            token::Transfer {
                from: ctx.accounts.token_account_a.to_account_info(),
                to: ctx.accounts.token_vault_a.to_account_info(),
                authority: ctx.accounts.owner.to_account_info(),
            },
        ),
        amount_a,
    )?;

    token::transfer(
        CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            token::Transfer {
                from: ctx.accounts.token_account_b.to_account_info(),
                to: ctx.accounts.token_vault_b.to_account_info(),
                authority: ctx.accounts.owner.to_account_info(),
            },
        ),
        amount_b,
    )?;

    let position = &mut ctx.accounts.position;
    let pool = &mut ctx.accounts.pool;

    position.fee_growth_checkpoint_a = pool.fee_growth_global_a;
    position.fee_growth_checkpoint_b = pool.fee_growth_global_b;
    position.liquidity = position.liquidity.checked_add(liquidity_delta).unwrap();

    pool.liquidity = pool.liquidity.checked_add(liquidity_delta).unwrap();

    ctx.accounts.tick_lower.liquidity_gross += liquidity_delta;
    ctx.accounts.tick_lower.liquidity_net += liquidity_delta as i128;
    ctx.accounts.tick_upper.liquidity_gross += liquidity_delta;
    ctx.accounts.tick_upper.liquidity_net -= liquidity_delta as i128;

    Ok(())
}
