use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount};
use crate::state::Pool;
use crate::constants::*;
use crate::errors::ClammError;
use crate::math;

#[derive(Accounts)]
pub struct Swap<'info> {
    #[account(mut)]
    pub swapper: Signer<'info>,
    #[account(mut)]
    pub pool: Account<'info, Pool>,
    #[account(mut)]
    pub token_vault_a: Account<'info, TokenAccount>,
    #[account(mut)]
    pub token_vault_b: Account<'info, TokenAccount>,
    #[account(mut)]
    pub token_account_in: Account<'info, TokenAccount>,
    #[account(mut)]
    pub token_account_out: Account<'info, TokenAccount>,
    /// CHECK: pool authority
    pub pool_authority: AccountInfo<'info>,
    pub token_program: Program<'info, Token>,
}

pub fn swap(
    ctx: Context<Swap>,
    amount_in: u64,
    minimum_amount_out: u64,
    is_token_a: bool,
    sqrt_price_limit: u128,
) -> Result<()> {
    require!(amount_in > 0, ClammError::InvalidAmount);
    require!(
        ctx.accounts.pool.liquidity > 0,
        ClammError::InsufficientLiquidity
    );

    let pool = &mut ctx.accounts.pool;

    if is_token_a {
        require!(
            sqrt_price_limit < pool.sqrt_price && sqrt_price_limit > MIN_SQRT_PRICE,
            ClammError::InvalidSqrtPrice
        );
    } else {
        require!(
            sqrt_price_limit > pool.sqrt_price && sqrt_price_limit < MAX_SQRT_PRICE,
            ClammError::InvalidSqrtPrice
        );
    }

    let fee_rate = if pool.dynamic_fee_enabled {
        compute_dynamic_fee(pool.fee_rate, pool.volume_usd_24h)?
    } else {
        pool.fee_rate
    };

    let fee_amount = (amount_in as u128)
        .checked_mul(fee_rate as u128)
        .unwrap()
        .checked_div(FEE_RATE_DENOMINATOR as u128)
        .unwrap() as u64;
    let amount_in_less_fee = amount_in.checked_sub(fee_amount).unwrap();

    let new_sqrt_price = math::get_next_sqrt_price(
        pool.sqrt_price,
        pool.liquidity,
        amount_in_less_fee,
        is_token_a,
    )?;

    let amount_out = if is_token_a {
        math::get_amount_delta_b(pool.sqrt_price, new_sqrt_price, pool.liquidity, false)?
    } else {
        math::get_amount_delta_a(new_sqrt_price, pool.sqrt_price, pool.liquidity, false)?
    };

    require!(
        amount_out >= minimum_amount_out,
        ClammError::PriceSlippageExceeded
    );

    token::transfer(
        CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            token::Transfer {
                from: ctx.accounts.token_account_in.to_account_info(),
                to: if is_token_a {
                    ctx.accounts.token_vault_a.to_account_info()
                } else {
                    ctx.accounts.token_vault_b.to_account_info()
                },
                authority: ctx.accounts.swapper.to_account_info(),
            },
        ),
        amount_in,
    )?;

    let pool_key = pool.key();
    let bump = pool.bump;
    let signer_seeds: &[&[&[u8]]] = &[&[
        b"pool",
        pool.factory.as_ref(),
        pool_key.as_ref(),
        &[bump],
    ]];

    token::transfer(
        CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            token::Transfer {
                from: if is_token_a {
                    ctx.accounts.token_vault_b.to_account_info()
                } else {
                    ctx.accounts.token_vault_a.to_account_info()
                },
                to: ctx.accounts.token_account_out.to_account_info(),
                authority: ctx.accounts.pool_authority.to_account_info(),
            },
            signer_seeds,
        ),
        amount_out,
    )?;

    let protocol_fee_share = fee_amount / PROTOCOL_FEE_DENOMINATOR as u64;
    if is_token_a {
        pool.protocol_fee_token_a += protocol_fee_share;
        pool.fee_growth_global_a += ((fee_amount - protocol_fee_share) as u128)
            .checked_mul(1 << 64)
            .unwrap()
            .checked_div(pool.liquidity)
            .unwrap();
    } else {
        pool.protocol_fee_token_b += protocol_fee_share;
        pool.fee_growth_global_b += ((fee_amount - protocol_fee_share) as u128)
            .checked_mul(1 << 64)
            .unwrap()
            .checked_div(pool.liquidity)
            .unwrap();
    }

    pool.sqrt_price = new_sqrt_price;
    pool.current_tick_index = math::sqrt_price_to_tick(new_sqrt_price)?;

    let now = Clock::get()?.unix_timestamp as u64;
    let elapsed = now - pool.twap_last_updated;
    if elapsed > 0 {
        pool.twap_accumulator += (pool.twap_start_sqrt_price as u128)
            .checked_mul(elapsed as u128)
            .unwrap();
        pool.twap_start_sqrt_price = new_sqrt_price;
        pool.twap_last_updated = now;
    }

    pool.volume_usd_24h += amount_in;

    Ok(())
}

fn compute_dynamic_fee(base_fee: u64, volume_24h: u64) -> Result<u64> {
    let volatility_factor = if volume_24h > 1_000_000_000 {
        2u64
    } else if volume_24h > 100_000_000 {
        1u64
    } else {
        1u64
    };
    let dynamic_fee = base_fee * volatility_factor;
    require!(
        dynamic_fee <= MAX_FEE_RATE,
        ClammError::DynamicFeeExceedsMax
    );
    Ok(dynamic_fee)
}
