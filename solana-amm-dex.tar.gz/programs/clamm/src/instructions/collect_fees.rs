use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount};
use crate::state::{Pool, Position};
use crate::errors::ClammError;

#[derive(Accounts)]
pub struct CollectFees<'info> {
    #[account(mut)]
    pub owner: Signer<'info>,
    #[account(
        mut,
        constraint = position.owner == owner.key() @ ClammError::Unauthorized
    )]
    pub position: Account<'info, Position>,
    #[account(mut)]
    pub pool: Account<'info, Pool>,
    #[account(mut)]
    pub token_account_a: Account<'info, TokenAccount>,
    #[account(mut)]
    pub token_account_b: Account<'info, TokenAccount>,
    #[account(mut)]
    pub token_vault_a: Account<'info, TokenAccount>,
    #[account(mut)]
    pub token_vault_b: Account<'info, TokenAccount>,
    /// CHECK: pool authority
    pub pool_authority: AccountInfo<'info>,
    pub token_program: Program<'info, Token>,
}

pub fn collect_fees(ctx: Context<CollectFees>) -> Result<()> {
    let position = &mut ctx.accounts.position;
    let pool = &mut ctx.accounts.pool;

    let fees_a = compute_fees_owed(
        pool.fee_growth_global_a,
        position.fee_growth_checkpoint_a,
        position.liquidity,
    );
    let fees_b = compute_fees_owed(
        pool.fee_growth_global_b,
        position.fee_growth_checkpoint_b,
        position.liquidity,
    );

    let total_a = position.fees_owed_a + fees_a;
    let total_b = position.fees_owed_b + fees_b;

    position.fee_growth_checkpoint_a = pool.fee_growth_global_a;
    position.fee_growth_checkpoint_b = pool.fee_growth_global_b;
    position.fees_owed_a = 0;
    position.fees_owed_b = 0;

    let pool_key = pool.key();
    let bump = pool.bump;
    let signer_seeds: &[&[&[u8]]] = &[&[
        b"pool",
        pool.factory.as_ref(),
        pool_key.as_ref(),
        &[bump],
    ]];

    if total_a > 0 {
        token::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                token::Transfer {
                    from: ctx.accounts.token_vault_a.to_account_info(),
                    to: ctx.accounts.token_account_a.to_account_info(),
                    authority: ctx.accounts.pool_authority.to_account_info(),
                },
                signer_seeds,
            ),
            total_a,
        )?;
    }

    if total_b > 0 {
        token::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                token::Transfer {
                    from: ctx.accounts.token_vault_b.to_account_info(),
                    to: ctx.accounts.token_account_b.to_account_info(),
                    authority: ctx.accounts.pool_authority.to_account_info(),
                },
                signer_seeds,
            ),
            total_b,
        )?;
    }

    Ok(())
}

fn compute_fees_owed(fee_growth_global: u128, fee_growth_checkpoint: u128, liquidity: u128) -> u64 {
    let delta = fee_growth_global.saturating_sub(fee_growth_checkpoint);
    ((delta * liquidity) >> 64) as u64
}
