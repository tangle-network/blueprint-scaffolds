use anchor_lang::prelude::*;
use crate::constants::*;
use crate::errors::ClammError;

#[account]
pub struct FactoryState {
    pub admin: Pubkey,
    pub pool_count: u64,
    pub fee_authority: Pubkey,
    pub default_protocol_fee_rate: u64,
    pub bump: u8,
}

impl FactoryState {
    pub const LEN: usize = 8 + 32 + 8 + 32 + 8 + 1;
}

#[account]
pub struct FeeTier {
    pub fee_rate: u64,
    pub tick_spacing: i32,
    pub is_supported: bool,
    pub default_protocol_fee_rate: u64,
    pub bump: u8,
}

impl FeeTier {
    pub const LEN: usize = 8 + 8 + 4 + 1 + 8 + 1;
}

#[account]
pub struct Pool {
    pub factory: Pubkey,
    pub token_mint_a: Pubkey,
    pub token_mint_b: Pubkey,
    pub token_vault_a: Pubkey,
    pub token_vault_b: Pubkey,
    pub fee_rate: u64,
    pub protocol_fee_rate: u64,
    pub tick_spacing: i32,
    pub liquidity: u128,
    pub sqrt_price: u128,
    pub current_tick_index: i32,
    pub fee_growth_global_a: u128,
    pub fee_growth_global_b: u128,
    pub protocol_fee_token_a: u64,
    pub protocol_fee_token_b: u64,
    pub swap_in_progress: bool,
    pub twap_start_sqrt_price: u128,
    pub twap_last_updated: u64,
    pub twap_accumulator: u128,
    pub dynamic_fee_enabled: bool,
    pub volume_usd_24h: u64,
    pub bump: u8,
}

impl Pool {
    pub const LEN: usize = 8 + 32 + 32 + 32 + 32 + 32 + 8 + 8 + 4 + 16 + 16 + 4 + 16 + 16 + 8 + 8 + 1 + 16 + 8 + 16 + 1 + 8 + 1;
}

#[account]
pub struct Tick {
    pub pool: Pubkey,
    pub tick_index: i32,
    pub liquidity_gross: u128,
    pub liquidity_net: i128,
    pub fee_growth_outside_a: u128,
    pub fee_growth_outside_b: u128,
    pub bump: u8,
}

impl Tick {
    pub const LEN: usize = 8 + 32 + 4 + 16 + 16 + 16 + 16 + 1;
}

#[account]
pub struct Position {
    pub nft_mint: Pubkey,
    pub pool: Pubkey,
    pub owner: Pubkey,
    pub tick_lower_index: i32,
    pub tick_upper_index: i32,
    pub liquidity: u128,
    pub fee_growth_checkpoint_a: u128,
    pub fee_growth_checkpoint_b: u128,
    pub fees_owed_a: u64,
    pub fees_owed_b: u64,
    pub created_at: u64,
    pub is_jit: bool,
    pub jit_expiry: u64,
    pub bump: u8,
}

impl Position {
    pub const LEN: usize = 8 + 32 + 32 + 32 + 4 + 4 + 16 + 16 + 16 + 8 + 8 + 8 + 1 + 8 + 1;
}

#[account]
pub struct PositionNFT {
    pub position: Pubkey,
    pub bump: u8,
}

impl PositionNFT {
    pub const LEN: usize = 8 + 32 + 1;
}

#[account]
pub struct Observation {
    pub pool: Pubkey,
    pub slot: u64,
    pub timestamp: u64,
    pub sqrt_price: u128,
    pub tick: i32,
    pub accumulator: u128,
    pub initialized: bool,
    pub bump: u8,
}

impl Observation {
    pub const LEN: usize = 8 + 32 + 8 + 8 + 16 + 4 + 16 + 1 + 1;
}

#[account]
pub struct FlashLoanReceipt {
    pub pool: Pubkey,
    pub borrower: Pubkey,
    pub amount_a: u64,
    pub amount_b: u64,
    pub fee_a: u64,
    pub fee_b: u64,
    pub deadline: u64,
    pub repaid: bool,
    pub bump: u8,
}

impl FlashLoanReceipt {
    pub const LEN: usize = 8 + 32 + 32 + 8 + 8 + 8 + 8 + 8 + 1 + 1;
}
