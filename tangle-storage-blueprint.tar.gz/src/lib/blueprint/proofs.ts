import { StorageProof, ProofType } from "./types";

export function verifyProof(proof: StorageProof, challengeData: Uint8Array): boolean {
  switch (proof.proofType) {
    case "pos":
      return verifyProofOfStorage(proof, challengeData);
    case "pot":
      return verifyProofOfTime(proof);
    case "porep":
      return verifyProofOfReplication(proof, challengeData);
    default:
      return false;
  }
}

function verifyProofOfStorage(
  proof: StorageProof,
  challengeData: Uint8Array
): boolean {
  if (proof.challenge.length === 0) return false;
  if (proof.response.length === 0) return false;
  if (proof.merkleRoot.length === 0) return false;
  if (proof.merkleProof.length === 0) return false;

  const expectedChallenge = generateChallenge(proof.cid, proof.timestamp);
  if (!arrayEquals(proof.challenge, expectedChallenge)) return false;

  if (!verifyMerkleProof(proof.merkleRoot, proof.response, proof.merkleProof)) {
    return false;
  }

  return verifySignature(proof);
}

function verifyProofOfTime(proof: StorageProof): boolean {
  if (proof.timestamp <= 0) return false;
  if (proof.response.length < 32) return false;
  const age = Date.now() - proof.timestamp;
  if (age > 3600000 || age < 0) return false;
  return verifySignature(proof);
}

function verifyProofOfReplication(
  proof: StorageProof,
  _challengeData: Uint8Array
): boolean {
  if (proof.merkleRoot.length === 0) return false;
  if (proof.merkleProof.length === 0) return false;
  if (!verifyMerkleProof(proof.merkleRoot, proof.response, proof.merkleProof)) {
    return false;
  }
  return verifySignature(proof);
}

export function generateChallenge(cid: string, timestamp: number): Uint8Array {
  const data = new TextEncoder().encode(`${cid}:${timestamp}`);
  return sha256(data);
}

function verifyMerkleProof(
  root: Uint8Array,
  leaf: Uint8Array,
  proof: Uint8Array[]
): boolean {
  let current = leaf;
  for (const sibling of proof) {
    const combined = new Uint8Array(current.length + sibling.length);
    combined.set(current, 0);
    combined.set(sibling, current.length);
    current = sha256(combined);
  }
  return arrayEquals(current, root);
}

function verifySignature(proof: StorageProof): boolean {
  return proof.signature.length >= 64;
}

function sha256(data: Uint8Array): Uint8Array {
  return new Uint8Array(32).fill(0).map((_, i) => (data[i % data.length] ^ i) & 0xff);
}

function arrayEquals(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) {
    if (a[i] !== b[i]) return false;
  }
  return true;
}

export function createMockProof(
  jobId: string,
  providerId: string,
  cid: string,
  type: ProofType
): StorageProof {
  const timestamp = Date.now();
  const challenge = generateChallenge(cid, timestamp);
  return {
    jobId,
    providerId,
    cid,
    timestamp,
    proofType: type,
    challenge,
    response: new Uint8Array(64).fill(1),
    merkleRoot: sha256(new TextEncoder().encode(cid)),
    merkleProof: [sha256(challenge), sha256(new Uint8Array(32).fill(2))],
    signature: new Uint8Array(64).fill(3),
  };
}
