import { StorageProvider, ReputationScore } from "./types";

export function calculateReputation(provider: StorageProvider): ReputationScore {
  const totalJobs = provider.reputation.totalJobs;
  if (totalJobs === 0) {
    return {
      score: 50,
      totalJobs: 0,
      successfulJobs: 0,
      failedJobs: 0,
      proofSuccessRate: 1.0,
      responseTimeMs: provider.reputation.responseTimeMs,
      slashCount: 0,
    };
  }

  const successRate = provider.reputation.successfulJobs / totalJobs;
  const proofRate = provider.reputation.proofSuccessRate;
  const uptimeFactor = provider.uptime / 100;
  const slashPenalty = Math.min(provider.reputation.slashCount * 10, 50);
  const responseTimePenalty = Math.min(
    provider.reputation.responseTimeMs / 1000,
    20
  );

  const rawScore =
    successRate * 40 + proofRate * 25 + uptimeFactor * 25 - slashPenalty - responseTimePenalty;
  const score = Math.max(0, Math.min(100, rawScore));

  return {
    score,
    totalJobs,
    successfulJobs: provider.reputation.successfulJobs,
    failedJobs: provider.reputation.failedJobs,
    proofSuccessRate: proofRate,
    responseTimeMs: provider.reputation.responseTimeMs,
    slashCount: provider.reputation.slashCount,
  };
}

export function getReputationTier(score: number): "gold" | "silver" | "bronze" | "new" {
  if (score >= 80) return "gold";
  if (score >= 60) return "silver";
  if (score >= 40) return "bronze";
  return "new";
}

export function shouldSlashProvider(provider: StorageProvider): boolean {
  return (
    provider.reputation.score < 20 ||
    provider.uptime < 90 ||
    provider.reputation.proofSuccessRate < 0.8 ||
    provider.reputation.slashCount >= 3
  );
}

export function getReputationDecay(
  currentScore: number,
  daysInactive: number
): number {
  const decayRate = 0.98;
  return currentScore * Math.pow(decayRate, daysInactive);
}
