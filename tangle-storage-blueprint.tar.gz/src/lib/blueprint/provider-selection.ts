import {
  StorageProvider,
  ProviderSelectionCriteria,
  ShardLocation,
} from "./types";

export function selectProviders(
  providers: StorageProvider[],
  count: number,
  criteria: ProviderSelectionCriteria
): StorageProvider[] {
  const eligible = providers.filter((p) => {
    if (p.reputation.score < criteria.minReputation) return false;
    if (p.uptime < criteria.minUptime) return false;
    if (criteria.preferredRegions.length > 0 && !criteria.preferredRegions.includes(p.region))
      return false;
    if (p.pricing.storagePerGbPerMonth > criteria.maxPricePerGb) return false;
    if (criteria.excludeProviders.includes(p.id)) return false;
    for (const feature of criteria.requiredFeatures) {
      if (!p.supportedFeatures.includes(feature)) return false;
    }
    return true;
  });

  const scored = eligible.map((p) => ({
    provider: p,
    score: scoreProvider(p),
  }));

  scored.sort((a, b) => b.score - a.score);

  const selected: StorageProvider[] = [];
  const usedRegions = new Set<string>();

  for (const { provider } of scored) {
    if (selected.length >= count) break;
    if (!usedRegions.has(provider.region) || scored.length <= count) {
      selected.push(provider);
      usedRegions.add(provider.region);
    }
  }

  return selected.slice(0, count);
}

function scoreProvider(provider: StorageProvider): number {
  const reputationWeight = 0.35;
  const uptimeWeight = 0.25;
  const capacityWeight = 0.15;
  const priceWeight = 0.15;
  const latencyWeight = 0.10;

  const totalCapacity = Number(provider.capacity.totalBytes) / 1e9;
  const availableCapacity = Number(provider.capacity.availableBytes) / 1e9;
  const capacityRatio = totalCapacity > 0 ? availableCapacity / totalCapacity : 0;
  const priceScore = 100 - Math.min(100, Number(provider.pricing.storagePerGbPerMonth) / 1e6);

  const latencyScore = Math.max(
    0,
    100 - provider.reputation.responseTimeMs / 10
  );

  return (
    provider.reputation.score * reputationWeight +
    provider.uptime * uptimeWeight +
    capacityRatio * 100 * capacityWeight +
    priceScore * priceWeight +
    latencyScore * latencyWeight
  );
}

export function assignShards(
  providers: StorageProvider[],
  dataShards: number,
  parityShards: number
): ShardLocation[] {
  const locations: ShardLocation[] = [];
  const totalShards = dataShards + parityShards;

  for (let i = 0; i < totalShards; i++) {
    const providerIndex = i % providers.length;
    locations.push({
      shardIndex: i,
      providerId: providers[providerIndex].id,
      cid: "",
      isParity: i >= dataShards,
    });
  }

  return locations;
}

export function calculateRequiredProviders(
  dataShards: number,
  parityShards: number,
  regions: number
): number {
  const totalShards = dataShards + parityShards;
  return Math.max(totalShards, regions * 2);
}
