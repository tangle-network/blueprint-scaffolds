import { StorageJob, StorageProvider, ShardLocation, FileMetadata } from "./types";
import { selectProviders, assignShards } from "./provider-selection";
import { ProviderSelectionCriteria } from "./types";
import { canReconstruct } from "./erasure-coding";

export interface RepairPlan {
  jobId: string;
  cid: string;
  missingShards: number[];
  newProviders: StorageProvider[];
  newShardAssignments: ShardLocation[];
  priority: RepairPriority;
  estimatedTimeMs: number;
}

export type RepairPriority = "critical" | "high" | "medium" | "low";

export function detectRepairsNeeded(
  job: StorageJob,
  file: FileMetadata,
  availableProviders: Set<string>
): RepairPlan | null {
  const availableShards = new Map<number, Uint8Array>();
  const missing: number[] = [];

  for (const shard of file.shardLocations) {
    if (availableProviders.has(shard.providerId)) {
      availableShards.set(shard.shardIndex, new Uint8Array(0));
    } else {
      missing.push(shard.shardIndex);
    }
  }

  if (missing.length === 0) return null;

  if (!canReconstruct(availableShards, job.erasureCoding.dataShards)) {
    return {
      jobId: job.id,
      cid: job.cid,
      missingShards: missing,
      newProviders: [],
      newShardAssignments: [],
      priority: "critical",
      estimatedTimeMs: 0,
    };
  }

  const priority = calculatePriority(job, missing.length, file.minReplicas);

  return {
    jobId: job.id,
    cid: job.cid,
    missingShards: missing,
    newProviders: [],
    newShardAssignments: [],
    priority,
    estimatedTimeMs: missing.length * 5000,
  };
}

export function createRepairAssignment(
  plan: RepairPlan,
  allProviders: StorageProvider[],
  criteria: ProviderSelectionCriteria
): RepairPlan {
  const needed = plan.missingShards.length;
  const newProviders = selectProviders(allProviders, needed, criteria);
  const newShards = assignShards(newProviders, plan.missingShards.length, 0);

  return {
    ...plan,
    newProviders,
    newShardAssignments: newShards,
    estimatedTimeMs: needed * 5000,
  };
}

function calculatePriority(
  job: StorageJob,
  missingCount: number,
  minReplicas: number
): RepairPriority {
  const currentReplicas = job.replicas - missingCount;
  if (currentReplicas < minReplicas / 2) return "critical";
  if (currentReplicas < minReplicas) return "high";
  if (missingCount <= 2) return "medium";
  return "low";
}

export function scheduleRepairs(
  plans: RepairPlan[]
): RepairPlan[] {
  const priorityOrder: Record<RepairPriority, number> = {
    critical: 0,
    high: 1,
    medium: 2,
    low: 3,
  };

  return [...plans].sort(
    (a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]
  );
}
