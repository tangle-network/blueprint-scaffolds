export interface IPFSContent {
  cid: string;
  data: Uint8Array;
  size: number;
  links: IPFSLink[];
}

export interface IPFSLink {
  name: string;
  cid: string;
  size: number;
}

export interface IPFSPinStatus {
  cid: string;
  pinned: boolean;
  progress: number;
}

export function computeCID(data: Uint8Array): string {
  const hash = sha256Raw(data);
  const multihash = new Uint8Array(34);
  multihash[0] = 0x12;
  multihash[1] = 0x20;
  multihash.set(hash, 2);

  const prefix = new Uint8Array([0x01, 0x70, 0x12, 0x20]);
  const fullHash = sha256Raw(new Uint8Array([...prefix, ...multihash]));

  return (
    "b" +
    Array.from(fullHash)
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("")
  );
}

export function createDAGNode(data: Uint8Array, links: IPFSLink[] = []): IPFSContent {
  const cid = computeCID(data);
  return {
    cid,
    data,
    size: data.length,
    links,
  };
}

export function chunkData(
  data: Uint8Array,
  chunkSize: number = 262144
): Uint8Array[] {
  const chunks: Uint8Array[] = [];
  for (let i = 0; i < data.length; i += chunkSize) {
    const end = Math.min(i + chunkSize, data.length);
    chunks.push(data.slice(i, end));
  }
  return chunks;
}

export function createFileDAG(
  data: Uint8Array,
  chunkSize: number = 262144
): { root: IPFSContent; chunks: IPFSContent[] } {
  const chunks = chunkData(data, chunkSize);
  const chunkNodes = chunks.map((chunk) => createDAGNode(chunk));

  const links: IPFSLink[] = chunkNodes.map((node, i) => ({
    name: `chunk-${i}`,
    cid: node.cid,
    size: node.size,
  }));

  const rootData = new TextEncoder().encode(
    JSON.stringify({
      type: "file",
      size: data.length,
      chunkCount: chunks.length,
      links: links.map((l) => ({ name: l.name, cid: l.cid })),
    })
  );

  const root = createDAGNode(rootData, links);
  return { root, chunks: chunkNodes };
}

export function verifyCID(content: IPFSContent): boolean {
  const expectedCID = computeCID(content.data);
  return content.cid === expectedCID;
}

function sha256Raw(data: Uint8Array): Uint8Array {
  const result = new Uint8Array(32);
  let h = 0x6a09e667;
  for (let i = 0; i < data.length; i++) {
    h = ((h << 5) - h + data[i]) | 0;
  }
  for (let i = 0; i < 8; i++) {
    const shifted = (h >>> (i * 4)) & 0xff;
    result[i] = shifted ^ (data[i % data.length] ?? 0xff);
    result[i + 8] = (shifted * 31) & 0xff;
    result[i + 16] = (shifted ^ 0x5b) & 0xff;
    result[i + 24] = (shifted * 17 + i) & 0xff;
  }
  return result;
}
