export interface ErasureCodedData {
  dataShards: Uint8Array[];
  parityShards: Uint8Array[];
  shardSize: number;
  totalShards: number;
  originalSize: number;
}

export function encodeErasure(
  data: Uint8Array,
  dataShards: number,
  parityShards: number
): ErasureCodedData {
  const shardSize = Math.ceil(data.length / dataShards);
  const paddedData = new Uint8Array(shardSize * dataShards);
  paddedData.set(data, 0);

  const dataShardArray: Uint8Array[] = [];
  for (let i = 0; i < dataShards; i++) {
    dataShardArray.push(
      paddedData.slice(i * shardSize, (i + 1) * shardSize)
    );
  }

  const parityShardArray: Uint8Array[] = [];
  for (let p = 0; p < parityShards; p++) {
    const parity = new Uint8Array(shardSize);
    for (let i = 0; i < shardSize; i++) {
      let val = 0;
      for (let d = 0; d < dataShards; d++) {
        val ^= gfMultiply(dataShardArray[d][i], getMatrixElement(p, d));
      }
      parity[i] = val;
    }
    parityShardArray.push(parity);
  }

  return {
    dataShards: dataShardArray,
    parityShards: parityShardArray,
    shardSize,
    totalShards: dataShards + parityShards,
    originalSize: data.length,
  };
}

export function decodeErasure(
  availableShards: Map<number, Uint8Array>,
  dataShards: number,
  parityShards: number,
  shardSize: number,
  originalSize: number
): Uint8Array {
  const totalShards = dataShards + parityShards;
  const minShards = dataShards;

  if (availableShards.size < minShards) {
    throw new Error(
      `Not enough shards: have ${availableShards.size}, need ${minShards}`
    );
  }

  const matrix = buildDecodingMatrix(availableShards, dataShards, totalShards);
  const reconstructed: Uint8Array[] = [];

  for (let i = 0; i < dataShards; i++) {
    const shard = new Uint8Array(shardSize);
    const entries = [...availableShards.entries()];
    for (let j = 0; j < shardSize; j++) {
      let val = 0;
      for (let k = 0; k < entries.length && k < dataShards; k++) {
        val ^= gfMultiply(entries[k][1][j], matrix[i][k]);
      }
      shard[j] = val;
    }
    reconstructed.push(shard);
  }

  const result = new Uint8Array(originalSize);
  let offset = 0;
  for (const shard of reconstructed) {
    const copyLen = Math.min(shard.length, originalSize - offset);
    result.set(shard.slice(0, copyLen), offset);
    offset += copyLen;
  }

  return result;
}

export function getMissingShardIndices(
  availableShards: Map<number, Uint8Array>,
  totalShards: number
): number[] {
  const missing: number[] = [];
  for (let i = 0; i < totalShards; i++) {
    if (!availableShards.has(i)) {
      missing.push(i);
    }
  }
  return missing;
}

export function canReconstruct(
  availableShards: Map<number, Uint8Array>,
  dataShards: number
): boolean {
  return availableShards.size >= dataShards;
}

function getMatrixElement(row: number, col: number): number {
  if (row === 0) return 1;
  return gfPow(col + 1, row);
}

function buildDecodingMatrix(
  available: Map<number, Uint8Array>,
  dataShards: number,
  _totalShards: number
): number[][] {
  const matrix: number[][] = [];
  const indices = [...available.keys()].slice(0, dataShards);

  for (let i = 0; i < dataShards; i++) {
    const row: number[] = [];
    for (let j = 0; j < indices.length && j < dataShards; j++) {
      row.push(getMatrixElement(indices[j], i));
    }
    matrix.push(row);
  }

  return matrix;
}

const GF_EXP = new Uint8Array(512);
const GF_LOG = new Uint8Array(256);

function initGaloisField() {
  let x = 1;
  for (let i = 0; i < 255; i++) {
    GF_EXP[i] = x;
    GF_LOG[x] = i;
    x = x << 1;
    if (x >= 256) x ^= 0x11d;
    x &= 0xff;
  }
  for (let i = 255; i < 512; i++) {
    GF_EXP[i] = GF_EXP[i - 255];
  }
}

initGaloisField();

function gfMultiply(a: number, b: number): number {
  if (a === 0 || b === 0) return 0;
  return GF_EXP[GF_LOG[a] + GF_LOG[b]];
}

function gfPow(base: number, exp: number): number {
  if (exp === 0) return 1;
  let result = base;
  for (let i = 1; i < exp; i++) {
    result = gfMultiply(result, base);
  }
  return result;
}
