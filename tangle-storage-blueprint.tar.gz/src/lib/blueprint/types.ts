export interface StorageJob {
  id: string;
  cid: string;
  size: number;
  replicas: number;
  encryption: EncryptionConfig;
  erasureCoding: ErasureCodingConfig;
  owner: string;
  createdAt: number;
  expiresAt: number;
  status: JobStatus;
  payments: PaymentSchedule[];
}

export type JobStatus =
  | "pending"
  | "uploading"
  | "replicating"
  | "active"
  | "repairing"
  | "expired"
  | "failed";

export interface EncryptionConfig {
  algorithm: "aes-256-gcm" | "chacha20-poly1305";
  keyWrapper: "ecies" | "rsa-oaep";
  enabled: boolean;
}

export interface ErasureCodingConfig {
  algorithm: "reed-solomon";
  dataShards: number;
  parityShards: number;
  shardSize: number;
}

export interface PaymentSchedule {
  providerId: string;
  amount: bigint;
  intervalMs: number;
  lastPaid: number;
  proofRequired: boolean;
}

export interface StorageProvider {
  id: string;
  accountId: string;
  endpoint: string;
  capacity: ProviderCapacity;
  reputation: ReputationScore;
  region: string;
  uptime: number;
  lastSeen: number;
  pricing: ProviderPricing;
  supportedFeatures: string[];
}

export interface ProviderCapacity {
  totalBytes: bigint;
  usedBytes: bigint;
  availableBytes: bigint;
  bandwidth: BandwidthCapacity;
}

export interface BandwidthCapacity {
  uploadMbps: number;
  downloadMbps: number;
  usedTodayBytes: bigint;
  quotaDayBytes: bigint;
}

export interface ReputationScore {
  score: number;
  totalJobs: number;
  successfulJobs: number;
  failedJobs: number;
  proofSuccessRate: number;
  responseTimeMs: number;
  slashCount: number;
}

export interface ProviderPricing {
  storagePerGbPerMonth: bigint;
  bandwidthPerGb: bigint;
  proofPerGeneration: bigint;
  minContractDurationMs: number;
}

export interface StorageProof {
  jobId: string;
  providerId: string;
  cid: string;
  timestamp: number;
  proofType: ProofType;
  challenge: Uint8Array;
  response: Uint8Array;
  merkleRoot: Uint8Array;
  merkleProof: Uint8Array[];
  signature: Uint8Array;
}

export type ProofType = "pos" | "pot" | "porep";

export interface FileAccessControl {
  fileId: string;
  owner: string;
  permissions: Permission[];
  accessTokens: AccessToken[];
  multiSigRequirements: MultiSigConfig;
}

export interface Permission {
  grantee: string;
  canRead: boolean;
  canWrite: boolean;
  canShare: boolean;
  canDelete: boolean;
  expiresAt: number | null;
}

export interface AccessToken {
  token: string;
  grantee: string;
  scope: "read" | "write" | "admin";
  expiresAt: number;
  uses: number;
  maxUses: number;
  bandwidthLimitBytes: bigint;
  bandwidthUsedBytes: bigint;
}

export interface MultiSigConfig {
  requiredSignatures: number;
  signers: string[];
  pendingOperations: PendingOperation[];
}

export interface PendingOperation {
  operationId: string;
  operation: string;
  signatures: string[];
  createdAt: number;
}

export interface NetworkHealth {
  totalProviders: number;
  activeProviders: number;
  totalStorageBytes: bigint;
  usedStorageBytes: bigint;
  averageUptime: number;
  averageReputation: number;
  pendingJobs: number;
  activeJobs: number;
  networkLatencyMs: number;
  replicationHealth: ReplicationHealth;
}

export interface ReplicationHealth {
  fullyReplicated: number;
  partiallyReplicated: number;
  underReplicated: number;
  repairingNow: number;
}

export interface FileMetadata {
  cid: string;
  name: string;
  size: number;
  mimeType: string;
  uploadedAt: number;
  owner: string;
  encryption: boolean;
  replicas: number;
  minReplicas: number;
  shardLocations: ShardLocation[];
  accessControl: FileAccessControl;
  tags: string[];
}

export interface ShardLocation {
  shardIndex: number;
  providerId: string;
  cid: string;
  isParity: boolean;
}

export interface CostEstimate {
  storageCostPerMonth: bigint;
  bandwidthCostPerMonth: bigint;
  proofCostPerMonth: bigint;
  totalPerMonth: bigint;
  redundancyCostMultiplier: number;
}

export interface ProviderSelectionCriteria {
  minReputation: number;
  minUptime: number;
  preferredRegions: string[];
  maxPricePerGb: bigint;
  requiredFeatures: string[];
  excludeProviders: string[];
}
