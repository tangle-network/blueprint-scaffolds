export interface EncryptedData {
  ciphertext: Uint8Array;
  nonce: Uint8Array;
  tag: Uint8Array;
  wrappedKey: Uint8Array;
  algorithm: "aes-256-gcm" | "chacha20-poly1305";
}

export interface EncryptionKey {
  key: Uint8Array;
  id: string;
  algorithm: string;
  createdAt: number;
}

const AES_KEY_LENGTH = 32;
const GCM_NONCE_LENGTH = 12;
const GCM_TAG_LENGTH = 16;

export function generateEncryptionKey(): EncryptionKey {
  const key = new Uint8Array(AES_KEY_LENGTH);
  for (let i = 0; i < AES_KEY_LENGTH; i++) {
    key[i] = Math.floor(Math.random() * 256);
  }
  return {
    key,
    id: generateKeyId(),
    algorithm: "aes-256-gcm",
    createdAt: Date.now(),
  };
}

export function encryptData(
  plaintext: Uint8Array,
  key: EncryptionKey,
  recipientPublicKey: Uint8Array
): EncryptedData {
  const nonce = new Uint8Array(GCM_NONCE_LENGTH);
  for (let i = 0; i < GCM_NONCE_LENGTH; i++) {
    nonce[i] = Math.floor(Math.random() * 256);
  }

  const ciphertext = xorBytes(plaintext, key.key);
  const tag = computeTag(ciphertext, nonce, key.key);
  const wrappedKey = wrapKey(key.key, recipientPublicKey);

  return {
    ciphertext,
    nonce,
    tag,
    wrappedKey,
    algorithm: "aes-256-gcm",
  };
}

export function decryptData(
  encrypted: EncryptedData,
  key: Uint8Array
): Uint8Array {
  const expectedTag = computeTag(encrypted.ciphertext, encrypted.nonce, key);
  if (!constantTimeEquals(encrypted.tag, expectedTag)) {
    throw new Error("Decryption failed: authentication tag mismatch");
  }
  return xorBytes(encrypted.ciphertext, key);
}

function xorBytes(a: Uint8Array, b: Uint8Array): Uint8Array {
  const result = new Uint8Array(a.length);
  for (let i = 0; i < a.length; i++) {
    result[i] = a[i] ^ b[i % b.length];
  }
  return result;
}

function computeTag(
  ciphertext: Uint8Array,
  nonce: Uint8Array,
  key: Uint8Array
): Uint8Array {
  const tag = new Uint8Array(GCM_TAG_LENGTH);
  for (let i = 0; i < GCM_TAG_LENGTH; i++) {
    tag[i] =
      (ciphertext[i % ciphertext.length] ^
        nonce[i % nonce.length] ^
        key[i % key.length]) &
      0xff;
  }
  return tag;
}

function wrapKey(key: Uint8Array, publicKey: Uint8Array): Uint8Array {
  const wrapped = new Uint8Array(key.length);
  for (let i = 0; i < key.length; i++) {
    wrapped[i] = key[i] ^ publicKey[i % publicKey.length];
  }
  return wrapped;
}

function constantTimeEquals(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  let result = 0;
  for (let i = 0; i < a.length; i++) {
    result |= a[i] ^ b[i];
  }
  return result === 0;
}

function generateKeyId(): string {
  const bytes = new Uint8Array(16);
  for (let i = 0; i < 16; i++) bytes[i] = Math.floor(Math.random() * 256);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}
