import { StorageJob, JobStatus, StorageProvider, ErasureCodingConfig, EncryptionConfig } from "./types";

let jobCounter = 0;

export function createStorageJob(
  cid: string,
  size: number,
  owner: string,
  replicas: number,
  erasureCoding: ErasureCodingConfig,
  encryption: EncryptionConfig,
  durationMs: number
): StorageJob {
  jobCounter++;
  const now = Date.now();
  return {
    id: `job-${now}-${jobCounter}`,
    cid,
    size,
    replicas,
    encryption,
    erasureCoding,
    owner,
    createdAt: now,
    expiresAt: now + durationMs,
    status: "pending",
    payments: [],
  };
}

export function transitionJob(job: StorageJob, event: JobEvent): StorageJob {
  const transitions: Record<JobStatus, JobStatus[]> = {
    pending: ["uploading"],
    uploading: ["replicating", "failed"],
    replicating: ["active", "failed"],
    active: ["repairing", "expired", "failed"],
    repairing: ["active", "failed"],
    expired: [],
    failed: ["pending"],
  };

  const allowed = transitions[job.status];
  if (!allowed.includes(event.nextStatus)) {
    throw new Error(
      `Invalid transition from ${job.status} to ${event.nextStatus}`
    );
  }

  return {
    ...job,
    status: event.nextStatus,
    payments: event.payments ?? job.payments,
  };
}

export interface JobEvent {
  nextStatus: JobStatus;
  payments?: StorageJob["payments"];
}

export function assignProvidersToJob(
  job: StorageJob,
  providers: StorageProvider[]
): StorageJob {
  return {
    ...job,
    payments: providers.map((p) => ({
      providerId: p.id,
      amount: p.pricing.storagePerGbPerMonth,
      intervalMs: 86400000,
      lastPaid: 0,
      proofRequired: true,
    })),
    status: "uploading",
  };
}

export function isJobHealthy(job: StorageJob, activeProviders: number): boolean {
  if (job.status !== "active") return false;
  return activeProviders >= Math.ceil(job.replicas / 2);
}

export function getJobsByProvider(
  jobs: StorageJob[],
  providerId: string
): StorageJob[] {
  return jobs.filter((j) =>
    j.payments.some((p) => p.providerId === providerId)
  );
}

export function getExpiringJobs(jobs: StorageJob[], withinMs: number): StorageJob[] {
  const threshold = Date.now() + withinMs;
  return jobs.filter(
    (j) =>
      (j.status === "active" || j.status === "repairing") &&
      j.expiresAt <= threshold
  );
}
