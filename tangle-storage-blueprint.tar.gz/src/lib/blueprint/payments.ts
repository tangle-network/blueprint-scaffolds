import { StorageJob, StorageProvider, PaymentSchedule } from "./types";

export interface PaymentDistribution {
  jobId: string;
  totalAmount: bigint;
  distributions: ProviderPayment[];
  feeRecipients: FeeRecipient[];
  createdAt: number;
}

export interface ProviderPayment {
  providerId: string;
  amount: bigint;
  proofCount: number;
  uptimeSeconds: number;
  reputationBonus: bigint;
  penalty: bigint;
  netAmount: bigint;
}

export interface FeeRecipient {
  recipient: string;
  amount: bigint;
  reason: string;
}

const PROTOCOL_FEE_BASIS_POINTS = 250;
const REPUTATION_BONUS_THRESHOLD = 80;
const SLASH_PENALTY_PERCENT = 10;

export function distributePayment(
  job: StorageJob,
  providers: StorageProvider[],
  epochMs: number
): PaymentDistribution {
  const totalPerProvider = job.payments.reduce(
    (sum, p) => sum + p.amount,
    BigInt(0)
  );

  const totalAmount = totalPerProvider * BigInt(providers.length);
  const protocolFee = (totalAmount * BigInt(PROTOCOL_FEE_BASIS_POINTS)) / BigInt(10000);
  const distributable = totalAmount - protocolFee;

  const distributions = providers.map((provider) => {
    const baseShare = distributable / BigInt(providers.length);
    let reputationBonus = BigInt(0);
    if (provider.reputation.score >= REPUTATION_BONUS_THRESHOLD) {
      reputationBonus = (baseShare * BigInt(5)) / BigInt(100);
    }

    let penalty = BigInt(0);
    if (provider.uptime < 95) {
      const uptimeDeficit = 95 - provider.uptime;
      penalty = (baseShare * BigInt(Math.floor(uptimeDeficit))) / BigInt(100);
    }

    const netAmount = baseShare + reputationBonus - penalty;

    return {
      providerId: provider.id,
      amount: baseShare,
      proofCount: 0,
      uptimeSeconds: 0,
      reputationBonus,
      penalty,
      netAmount: netAmount > BigInt(0) ? netAmount : BigInt(0),
    };
  });

  return {
    jobId: job.id,
    totalAmount,
    distributions,
    feeRecipients: [
      {
        recipient: "tangle-protocol-treasury",
        amount: protocolFee,
        reason: "Protocol fee",
      },
    ],
    createdAt: epochMs,
  };
}

export function calculateSlashPenalty(
  provider: StorageProvider,
  missedProofs: number
): bigint {
  const basePenalty = BigInt(missedProofs) * BigInt(1e12);
  const reputationMultiplier =
    provider.reputation.score < 40
      ? BigInt(3)
      : provider.reputation.score < 60
        ? BigInt(2)
        : BigInt(1);

  const slashPercent = BigInt(SLASH_PENALTY_PERCENT);
  const stakeBased = (BigInt(1e18) * slashPercent) / BigInt(100);

  return basePenalty * reputationMultiplier + stakeBased;
}

export function calculateProviderEarnings(
  job: StorageJob,
  provider: StorageProvider,
  daysActive: number
): bigint {
  const dailyRate = job.payments.reduce(
    (sum, p) => sum + p.amount,
    BigInt(0)
  ) / BigInt(30);

  const baseEarnings = dailyRate * BigInt(daysActive);
  const reputationMultiplier =
    provider.reputation.score >= 80
      ? BigInt(110)
      : provider.reputation.score >= 60
        ? BigInt(105)
        : BigInt(100);

  return (baseEarnings * reputationMultiplier) / BigInt(100);
}
