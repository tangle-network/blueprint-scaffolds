import { FileAccessControl, Permission, AccessToken, MultiSigConfig, PendingOperation } from "./types";

export function createAccessControl(fileId: string, owner: string): FileAccessControl {
  return {
    fileId,
    owner,
    permissions: [
      {
        grantee: owner,
        canRead: true,
        canWrite: true,
        canShare: true,
        canDelete: true,
        expiresAt: null,
      },
    ],
    accessTokens: [],
    multiSigRequirements: {
      requiredSignatures: 1,
      signers: [owner],
      pendingOperations: [],
    },
  };
}

export function grantPermission(
  ac: FileAccessControl,
  permission: Permission,
  grantedBy: string
): FileAccessControl {
  const granterPerm = ac.permissions.find((p) => p.grantee === grantedBy);
  if (!granterPerm?.canShare) {
    throw new Error("Granter does not have share permission");
  }

  const existing = ac.permissions.findIndex((p) => p.grantee === permission.grantee);
  const updated = [...ac.permissions];
  if (existing >= 0) {
    updated[existing] = permission;
  } else {
    updated.push(permission);
  }

  return { ...ac, permissions: updated };
}

export function revokePermission(
  ac: FileAccessControl,
  grantee: string,
  revokedBy: string
): FileAccessControl {
  if (grantee === ac.owner) {
    throw new Error("Cannot revoke owner permissions");
  }
  const revoker = ac.permissions.find((p) => p.grantee === revokedBy);
  if (!revoker?.canShare) {
    throw new Error("Revoker does not have share permission");
  }

  return {
    ...ac,
    permissions: ac.permissions.filter((p) => p.grantee !== grantee),
  };
}

export function createAccessToken(
  ac: FileAccessControl,
  grantee: string,
  scope: AccessToken["scope"],
  durationMs: number,
  maxUses: number,
  bandwidthLimitBytes: bigint,
  createdBy: string
): FileAccessControl {
  const creator = ac.permissions.find((p) => p.grantee === createdBy);
  if (!creator?.canShare) {
    throw new Error("Creator does not have share permission");
  }

  const token: AccessToken = {
    token: generateToken(),
    grantee,
    scope,
    expiresAt: Date.now() + durationMs,
    uses: 0,
    maxUses,
    bandwidthLimitBytes,
    bandwidthUsedBytes: BigInt(0),
  };

  return {
    ...ac,
    accessTokens: [...ac.accessTokens, token],
  };
}

export function validateAccessToken(
  ac: FileAccessControl,
  token: string,
  bandwidthUsed: bigint
): { valid: boolean; scope?: AccessToken["scope"]; reason?: string } {
  const at = ac.accessTokens.find((t) => t.token === token);
  if (!at) return { valid: false, reason: "Token not found" };
  if (Date.now() > at.expiresAt)
    return { valid: false, reason: "Token expired" };
  if (at.uses >= at.maxUses)
    return { valid: false, reason: "Token uses exceeded" };
  if (at.bandwidthUsedBytes + bandwidthUsed > at.bandwidthLimitBytes)
    return { valid: false, reason: "Bandwidth limit exceeded" };

  return { valid: true, scope: at.scope };
}

export function useAccessToken(
  ac: FileAccessControl,
  token: string,
  bandwidthUsed: bigint
): FileAccessControl {
  return {
    ...ac,
    accessTokens: ac.accessTokens.map((t) =>
      t.token === token
        ? {
            ...t,
            uses: t.uses + 1,
            bandwidthUsedBytes: t.bandwidthUsedBytes + bandwidthUsed,
          }
        : t
    ),
  };
}

export function proposeMultiSigOperation(
  ac: FileAccessControl,
  operation: string,
  proposer: string
): FileAccessControl {
  const ms = ac.multiSigRequirements;
  if (!ms.signers.includes(proposer)) {
    throw new Error("Proposer is not an authorized signer");
  }

  const pendingOp: PendingOperation = {
    operationId: `op-${Date.now()}`,
    operation,
    signatures: [proposer],
    createdAt: Date.now(),
  };

  return {
    ...ac,
    multiSigRequirements: {
      ...ms,
      pendingOperations: [...ms.pendingOperations, pendingOp],
    },
  };
}

export function signMultiSigOperation(
  ac: FileAccessControl,
  operationId: string,
  signer: string
): { ac: FileAccessControl; executed: boolean } {
  const ms = ac.multiSigRequirements;
  if (!ms.signers.includes(signer)) {
    throw new Error("Signer is not authorized");
  }

  const op = ms.pendingOperations.find((o) => o.operationId === operationId);
  if (!op) throw new Error("Operation not found");
  if (op.signatures.includes(signer)) {
    throw new Error("Already signed");
  }

  const newSigs = [...op.signatures, signer];
  const executed = newSigs.length >= ms.requiredSignatures;

  const updatedOps = executed
    ? ms.pendingOperations.filter((o) => o.operationId !== operationId)
    : ms.pendingOperations.map((o) =>
        o.operationId === operationId ? { ...o, signatures: newSigs } : o
      );

  return {
    ac: {
      ...ac,
      multiSigRequirements: { ...ms, pendingOperations: updatedOps },
    },
    executed,
  };
}

function generateToken(): string {
  const bytes = new Uint8Array(32);
  for (let i = 0; i < 32; i++) bytes[i] = Math.floor(Math.random() * 256);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}
