import { StorageProvider, ErasureCodingConfig } from "./types";

export function selectProviders(
  providers: StorageProvider[],
  count: number,
  preferences?: {
    maxLatency?: number;
    maxPrice?: number;
    minReputation?: number;
    preferredRegions?: string[];
  }
): StorageProvider[] {
  let candidates = [...providers];

  if (preferences) {
    if (preferences.maxLatency !== undefined) {
      candidates = candidates.filter((p) => p.latency <= preferences.maxLatency!);
    }
    if (preferences.maxPrice !== undefined) {
      candidates = candidates.filter((p) => p.pricePerGB <= preferences.maxPrice!);
    }
    if (preferences.minReputation !== undefined) {
      candidates = candidates.filter((p) => p.reputation >= preferences.minReputation!);
    }
    if (preferences.preferredRegions && preferences.preferredRegions.length > 0) {
      const preferred = candidates.filter((p) => preferences.preferredRegions!.includes(p.region));
      if (preferred.length >= count) {
        candidates = preferred;
      }
    }
  }

  candidates.sort((a, b) => {
    const scoreA = a.reputation * 0.4 + (100 - a.latency) * 0.3 + (1 - a.pricePerGB / 1) * 0.2 + (a.uptime / 100) * 10 * 0.1;
    const scoreB = b.reputation * 0.4 + (100 - b.latency) * 0.3 + (1 - b.pricePerGB / 1) * 0.2 + (b.uptime / 100) * 10 * 0.1;
    return scoreB - scoreA;
  });

  return candidates.slice(0, count);
}

export function computeErasureCoding(fileSize: number, config: ErasureCodingConfig): {
  totalShards: number;
  shardSizeBytes: number;
  overhead: number;
  faultTolerance: number;
} {
  const totalShards = config.dataShards + config.parityShards;
  const shardSizeBytes = config.shardSize;
  const overhead = config.parityShards / config.dataShards;
  const faultTolerance = config.parityShards / totalShards;
  return { totalShards, shardSizeBytes, overhead, faultTolerance };
}

export function calculateStorageCost(
  sizeGB: number,
  durationMonths: number,
  replicationFactor: number,
  pricePerGB: number
): number {
  return sizeGB * durationMonths * replicationFactor * pricePerGB;
}

export function formatBytes(bytes: number): string {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB", "TB", "PB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
}

export function generateProofChallenge(): string {
  const chars = "0123456789abcdef";
  let result = "0x";
  for (let i = 0; i < 64; i++) {
    result += chars[Math.floor(Math.random() * chars.length)];
  }
  return result;
}

export function computeMerkleRoot(dataChunks: string[]): string {
  if (dataChunks.length === 0) return "";
  if (dataChunks.length === 1) return dataChunks[0];
  const nextLevel: string[] = [];
  for (let i = 0; i < dataChunks.length; i += 2) {
    const left = dataChunks[i];
    const right = i + 1 < dataChunks.length ? dataChunks[i + 1] : left;
    nextLevel.push(`${left}:${right}`);
  }
  return computeMerkleRoot(nextLevel);
}

export function distributePayment(
  providers: StorageProvider[],
  totalAmount: number
): { providerId: string; amount: number }[] {
  const totalReputation = providers.reduce((sum, p) => sum + p.reputation, 0);
  return providers.map((p) => ({
    providerId: p.id,
    amount: (p.reputation / totalReputation) * totalAmount,
  }));
}
