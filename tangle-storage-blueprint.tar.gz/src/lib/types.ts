export interface StorageFile {
  id: string;
  name: string;
  cid: string;
  size: number;
  replicas: number;
  encryption: string;
  uploadedAt: string;
  status: "available" | "repairing" | "pending";
}

export interface StorageProvider {
  id: string;
  address: string;
  reputation: number;
  usedSpace: number;
  totalSpace: number;
  uptime: number;
  latency: number;
  pricePerGB: number;
  proofsGenerated: number;
  proofsVerified: number;
  region: string;
}

export interface ProofOfStorage {
  fileId: string;
  providerId: string;
  timestamp: number;
  challenge: string;
  response: string;
  merkleRoot: string;
  merkleProof: string[];
  verified: boolean;
}

export interface AccessGrant {
  id: string;
  fileId: string;
  grantee: string;
  grantor: string;
  permissions: ("read" | "write" | "delete" | "share")[];
  expiresAt: number;
  tokenHash: string;
  multiSigRequired: number;
  signatures: string[];
}

export interface BlueprintJob {
  id: string;
  type: "store" | "retrieve" | "replicate" | "repair" | "delete" | "prove";
  params: Record<string, unknown>;
  requester: string;
  assignedProvider: string;
  status: "queued" | "running" | "completed" | "failed";
  createdAt: number;
  completedAt?: number;
  result?: Record<string, unknown>;
  payment: {
    amount: number;
    token: string;
    distributed: boolean;
  };
}

export interface ErasureCodingConfig {
  dataShards: number;
  parityShards: number;
  shardSize: number;
}

export interface NetworkStats {
  totalNodes: number;
  activeNodes: number;
  totalStorage: number;
  usedStorage: number;
  filesStored: number;
  avgReplicationFactor: number;
  proofsGenerated24h: number;
  repairJobs24h: number;
  bandwidthUsedGB: number;
}

export const MOCK_FILES: StorageFile[] = [
  { id: "f1", name: "dataset-v3.csv", cid: "QmX7bV...a3Kp", size: 524288000, replicas: 5, encryption: "AES-256-GCM", uploadedAt: "2026-03-28", status: "available" },
  { id: "f2", name: "model-weights.bin", cid: "QmNp2k...f8Wr", size: 2147483648, replicas: 7, encryption: "AES-256-GCM", uploadedAt: "2026-03-25", status: "available" },
  { id: "f3", name: "backup-2026-03.tar.gz", cid: "QmRk9m...b2Ln", size: 10737418240, replicas: 3, encryption: "ChaCha20-Poly1305", uploadedAt: "2026-03-20", status: "repairing" },
  { id: "f4", name: "config.json", cid: "QmWp4n...c7Dx", size: 4096, replicas: 6, encryption: "AES-256-GCM", uploadedAt: "2026-03-30", status: "available" },
  { id: "f5", name: "logs-q1.ndjson", cid: "QmTv8r...e5Fg", size: 3221225472, replicas: 4, encryption: "AES-256-GCM", uploadedAt: "2026-03-15", status: "available" },
  { id: "f6", name: "snapshot-latest.img", cid: "QmYh3s...d9Qw", size: 8589934592, replicas: 5, encryption: "ChaCha20-Poly1305", uploadedAt: "2026-04-01", status: "pending" },
];

export const MOCK_PROVIDERS: StorageProvider[] = [
  { id: "p1", address: "5GrwvaEF...z1op", reputation: 97, usedSpace: 450, totalSpace: 2000, uptime: 99.98, latency: 12, pricePerGB: 0.5, proofsGenerated: 15420, proofsVerified: 15418, region: "US-East" },
  { id: "p2", address: "5FHneW46...y9B5", reputation: 94, usedSpace: 820, totalSpace: 4000, uptime: 99.95, latency: 28, pricePerGB: 0.4, proofsGenerated: 22100, proofsVerified: 22095, region: "EU-West" },
  { id: "p3", address: "5DAAnr07...w2Qm", reputation: 89, usedSpace: 1200, totalSpace: 8000, uptime: 99.90, latency: 45, pricePerGB: 0.3, proofsGenerated: 31200, proofsVerified: 31180, region: "AP-Southeast" },
  { id: "p4", address: "5HGjWAeF...r7Kp", reputation: 91, usedSpace: 300, totalSpace: 1500, uptime: 99.92, latency: 18, pricePerGB: 0.55, proofsGenerated: 8900, proofsVerified: 8898, region: "US-West" },
  { id: "p5", address: "5Ck5SLSH...t4Bn", reputation: 85, usedSpace: 2800, totalSpace: 10000, uptime: 99.85, latency: 62, pricePerGB: 0.25, proofsGenerated: 45000, proofsVerified: 44950, region: "AP-East" },
  { id: "p6", address: "5DqQqM2S...v8Jx", reputation: 78, usedSpace: 600, totalSpace: 3000, uptime: 99.70, latency: 35, pricePerGB: 0.35, proofsGenerated: 12300, proofsVerified: 12270, region: "EU-North" },
];

export const MOCK_NETWORK: NetworkStats = {
  totalNodes: 128,
  activeNodes: 121,
  totalStorage: 50000,
  usedStorage: 18200,
  filesStored: 1247832,
  avgReplicationFactor: 4.8,
  proofsGenerated24h: 89420,
  repairJobs24h: 342,
  bandwidthUsedGB: 84500,
};

export const MOCK_JOBS: BlueprintJob[] = [
  { id: "j1", type: "store", params: { cid: "QmX7bV...a3Kp", replicas: 5 }, requester: "5GrwvaEF...z1op", assignedProvider: "p1", status: "completed", createdAt: Date.now() - 86400000, completedAt: Date.now() - 86300000, result: { stored: true }, payment: { amount: 2.5, token: "TNT", distributed: true } },
  { id: "j2", type: "prove", params: { fileId: "f1", challenge: "0xabc123" }, requester: "system", assignedProvider: "p2", status: "completed", createdAt: Date.now() - 43200000, completedAt: Date.now() - 43195000, result: { verified: true }, payment: { amount: 0.1, token: "TNT", distributed: true } },
  { id: "j3", type: "repair", params: { fileId: "f3", targetReplicas: 5 }, requester: "system", assignedProvider: "p5", status: "running", createdAt: Date.now() - 3600000, payment: { amount: 1.8, token: "TNT", distributed: false } },
  { id: "j4", type: "replicate", params: { cid: "QmYh3s...d9Qw", targetNodes: 3 }, requester: "5FHneW46...y9B5", assignedProvider: "p3", status: "queued", createdAt: Date.now() - 600000, payment: { amount: 3.2, token: "TNT", distributed: false } },
  { id: "j5", type: "retrieve", params: { cid: "QmNp2k...f8Wr", encryption: "AES-256-GCM" }, requester: "5DAAnr07...w2Qm", assignedProvider: "p4", status: "completed", createdAt: Date.now() - 172800000, completedAt: Date.now() - 172790000, result: { delivered: true }, payment: { amount: 0.5, token: "TNT", distributed: true } },
  { id: "j6", type: "delete", params: { fileId: "f_old_1" }, requester: "5GrwvaEF...z1op", assignedProvider: "p1", status: "completed", createdAt: Date.now() - 259200000, completedAt: Date.now() - 259190000, result: { deleted: true }, payment: { amount: 0, token: "TNT", distributed: true } },
];

export const MOCK_ACCESS_GRANTS: AccessGrant[] = [
  { id: "a1", fileId: "f1", grantee: "5DAAnr07...w2Qm", grantor: "5GrwvaEF...z1op", permissions: ["read"], expiresAt: Date.now() + 86400000 * 7, tokenHash: "0xdead...beef", multiSigRequired: 1, signatures: ["sig1"] },
  { id: "a2", fileId: "f2", grantee: "5FHneW46...y9B5", grantor: "5GrwvaEF...z1op", permissions: ["read", "write"], expiresAt: Date.now() + 86400000 * 30, tokenHash: "0xcafe...babe", multiSigRequired: 2, signatures: ["sig1", "sig2"] },
  { id: "a3", fileId: "f4", grantee: "5HGjWAeF...r7Kp", grantor: "5Ck5SLSH...t4Bn", permissions: ["read", "share"], expiresAt: Date.now() + 86400000 * 3, tokenHash: "0x1234...5678", multiSigRequired: 1, signatures: ["sig1"] },
];
