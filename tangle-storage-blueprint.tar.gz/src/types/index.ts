export interface StorageFile {
  id: string;
  name: string;
  size: number;
  cid: string;
  encrypted: boolean;
  replicas: number;
  uploadedAt: string;
  expiresAt?: string;
  ownerId: string;
  mimeType: string;
}

export interface StorageProvider {
  id: string;
  name: string;
  address: string;
  status: "active" | "inactive" | "suspended";
  reputation: number;
  availableSpace: number;
  usedSpace: number;
  pricePerGB: number;
  uptime: number;
  latency: number;
  bandwidth: number;
  location: string;
  proofsGenerated: number;
  proofsVerified: number;
}

export interface StorageJob {
  id: string;
  type: "upload" | "download" | "replicate" | "repair" | "delete" | "prove";
  status: "pending" | "processing" | "completed" | "failed";
  fileId: string;
  providerId: string;
  createdAt: string;
  completedAt?: string;
  reward: number;
  proof?: StorageProof;
  params: Record<string, unknown>;
}

export interface StorageProof {
  id: string;
  jobId: string;
  fileId: string;
  providerId: string;
  type: "pos" | "poc" | "pot";
  challenge: string;
  response: string;
  verified: boolean;
  timestamp: string;
  merkleRoot: string;
  merkleProof: string[];
}

export interface AccessPolicy {
  id: string;
  fileId: string;
  granteeId: string;
  permission: "read" | "write" | "admin";
  expiresAt?: string;
  token?: string;
  multiSigRequired: number;
  multiSigApprovals: string[];
  bandwidthLimit?: number;
  bandwidthUsed: number;
}

export interface NetworkStats {
  totalNodes: number;
  activeNodes: number;
  totalStorage: number;
  usedStorage: number;
  filesStored: number;
  proofsPending: number;
  networkHealth: number;
  avgLatency: number;
  avgUptime: number;
  throughput: number;
}

export interface PaymentDistribution {
  providerId: string;
  amount: number;
  epoch: number;
  proofsSubmitted: number;
  proofsVerified: number;
  penalty: number;
  bonus: number;
  netReward: number;
}

export interface ErasureConfig {
  dataShards: number;
  parityShards: number;
  shardSize: number;
}

export interface ReplicationConfig {
  minReplicas: number;
  maxReplicas: number;
  repairThreshold: number;
  geographicSpread: boolean;
}

export interface BlueprintConfig {
  erasure: ErasureConfig;
  replication: ReplicationConfig;
  proofInterval: number;
  proofTimeout: number;
  slashingAmount: number;
  rewardPerProof: number;
}
