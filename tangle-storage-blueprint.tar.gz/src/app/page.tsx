import { FileManagement } from "@/components/FileManagement";
import { ProviderMetrics } from "@/components/ProviderMetrics";
import { NetworkHealth } from "@/components/NetworkHealth";
import { BlueprintView } from "@/components/BlueprintView";
import { CostCalculator } from "@/components/CostCalculator";
import { AccessControl } from "@/components/AccessControl";

export default function Home() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <section className="text-center py-12">
        <h1 className="text-4xl font-bold mb-4">
          Decentralized Storage <span className="text-tangle-400">Blueprint</span>
        </h1>
        <p className="text-gray-400 max-w-2xl mx-auto text-lg">
          Reliable file storage with cryptographic proofs, erasure coding, and
          multi-provider replication on the Tangle Network.
        </p>
        <div className="flex justify-center gap-8 mt-8">
          <Stat label="Storage Nodes" value="128" />
          <Stat label="Files Stored" value="1.2M" />
          <Stat label="Uptime" value="99.97%" />
          <Stat label="Avg Latency" value="42ms" />
        </div>
      </section>

      <section id="files">
        <FileManagement />
      </section>

      <section id="access">
        <AccessControl />
      </section>

      <section id="providers">
        <ProviderMetrics />
      </section>

      <section id="network">
        <NetworkHealth />
      </section>

      <section id="blueprint">
        <BlueprintView />
      </section>

      <section id="calculator">
        <CostCalculator />
      </section>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="text-center">
      <div className="text-2xl font-bold text-tangle-400">{value}</div>
      <div className="text-sm text-gray-500">{label}</div>
    </div>
  );
}
