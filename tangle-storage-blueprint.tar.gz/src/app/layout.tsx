import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Tangle Storage Blueprint",
  description: "Decentralized storage service blueprint for Tangle Network",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-surface">
        <nav className="border-b border-surface-300 bg-surface-100/80 backdrop-blur-sm sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-tangle-600 flex items-center justify-center">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
                    <polyline points="3.27 6.96 12 12.01 20.73 6.96" />
                    <line x1="12" y1="22.08" x2="12" y2="12" />
                  </svg>
                </div>
                <span className="text-lg font-bold">Tangle Storage</span>
                <span className="badge-blue">Blueprint</span>
              </div>
              <div className="flex items-center gap-6 text-sm">
                <a href="#files" className="text-gray-400 hover:text-white transition-colors">Files</a>
                <a href="#providers" className="text-gray-400 hover:text-white transition-colors">Providers</a>
                <a href="#network" className="text-gray-400 hover:text-white transition-colors">Network</a>
                <a href="#blueprint" className="text-gray-400 hover:text-white transition-colors">Blueprint</a>
                <a href="#calculator" className="text-gray-400 hover:text-white transition-colors">Cost</a>
              </div>
            </div>
          </div>
        </nav>
        <main>{children}</main>
      </body>
    </html>
  );
}
