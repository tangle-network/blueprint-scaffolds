"use client";

import { MOCK_NETWORK } from "@/lib/types";

export function NetworkHealth() {
  const stats = MOCK_NETWORK;
  const healthPct = ((stats.activeNodes / stats.totalNodes) * 100).toFixed(1);
  const storagePct = ((stats.usedStorage / stats.totalStorage) * 100).toFixed(1);

  const timeSeries = Array.from({ length: 24 }, (_, i) => ({
    hour: `${i}:00`,
    proofs: 3000 + Math.floor(Math.random() * 1500),
    repairs: 8 + Math.floor(Math.random() * 25),
    bandwidth: 3000 + Math.floor(Math.random() * 2000),
  }));

  return (
    <div className="card">
      <h2 className="text-xl font-bold mb-5">Network Health</h2>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <HealthCard
          label="Active Nodes"
          value={`${stats.activeNodes} / ${stats.totalNodes}`}
          pct={healthPct}
          color="green"
        />
        <HealthCard
          label="Storage Used"
          value={`${stats.usedStorage.toLocaleString()} / ${stats.totalStorage.toLocaleString()} TB`}
          pct={storagePct}
          color="blue"
        />
        <HealthCard
          label="Avg Replication"
          value={stats.avgReplicationFactor.toFixed(1)}
          sub="factor"
          color="purple"
        />
        <HealthCard
          label="Files Stored"
          value={stats.filesStored.toLocaleString()}
          sub="total"
          color="cyan"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <MetricTile
          label="Proofs Generated (24h)"
          value={stats.proofsGenerated24h.toLocaleString()}
          items={timeSeries.slice(0, 8).map((t) => ({
            label: t.hour,
            value: t.proofs,
          }))}
        />
        <MetricTile
          label="Repair Jobs (24h)"
          value={stats.repairJobs24h.toLocaleString()}
          items={timeSeries.slice(0, 8).map((t) => ({
            label: t.hour,
            value: t.repairs,
          }))}
        />
        <MetricTile
          label="Bandwidth Used (GB)"
          value={stats.bandwidthUsedGB.toLocaleString()}
          items={timeSeries.slice(0, 8).map((t) => ({
            label: t.hour,
            value: t.bandwidth,
          }))}
        />
      </div>

      <div className="mt-6 p-4 bg-surface-200 rounded-lg border border-surface-300">
        <h3 className="font-semibold mb-3">Automatic Repair Log</h3>
        <div className="space-y-2 text-sm max-h-48 overflow-y-auto">
          {[
            { time: "2 min ago", file: "backup-2026-03.tar.gz", action: "Replica restored on p5", status: "complete" },
            { time: "15 min ago", file: "dataset-v3.csv", action: "Integrity check passed", status: "complete" },
            { time: "1 hr ago", file: "snapshot-latest.img", action: "Re-erasure coding shards 7-10", status: "in_progress" },
            { time: "3 hr ago", file: "logs-q1.ndjson", action: "Provider p3 timeout, switching to p4", status: "complete" },
            { time: "5 hr ago", file: "model-weights.bin", action: "Proof challenge verified (all replicas)", status: "complete" },
          ].map((entry, i) => (
            <div
              key={i}
              className="flex items-center gap-3 py-1.5 border-b border-surface-300/50 last:border-0"
            >
              <span className="text-gray-500 w-20 shrink-0">{entry.time}</span>
              <span className="font-mono text-xs w-40 shrink-0 truncate">
                {entry.file}
              </span>
              <span className="text-gray-300 flex-1">{entry.action}</span>
              <span
                className={
                  entry.status === "complete"
                    ? "badge-green"
                    : "badge-yellow"
                }
              >
                {entry.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function HealthCard({
  label,
  value,
  pct,
  color,
  sub,
}: {
  label: string;
  value: string;
  pct?: string;
  color: string;
  sub?: string;
}) {
  const barColor =
    color === "green"
      ? "bg-green-500"
      : color === "blue"
      ? "bg-tangle-500"
      : color === "purple"
      ? "bg-purple-500"
      : "bg-cyan-500";

  return (
    <div className="bg-surface-200 rounded-lg p-4 border border-surface-300">
      <div className="text-gray-500 text-xs mb-1">{label}</div>
      <div className="text-lg font-bold">{value}</div>
      {pct && (
        <div className="mt-2 w-full bg-surface-300 rounded-full h-1.5">
          <div
            className={`h-1.5 rounded-full ${barColor}`}
            style={{ width: `${pct}%` }}
          />
        </div>
      )}
      {sub && <div className="text-xs text-gray-500 mt-1">{sub}</div>}
    </div>
  );
}

function MetricTile({
  label,
  value,
  items,
}: {
  label: string;
  value: string;
  items: { label: string; value: number }[];
}) {
  const maxVal = Math.max(...items.map((i) => i.value));
  return (
    <div className="bg-surface-200 rounded-lg p-4 border border-surface-300">
      <div className="text-gray-500 text-xs mb-1">{label}</div>
      <div className="text-xl font-bold text-tangle-400 mb-3">{value}</div>
      <div className="flex items-end gap-1 h-16">
        {items.map((item, i) => (
          <div key={i} className="flex-1 flex flex-col items-center gap-1">
            <div
              className="w-full bg-tangle-600/60 rounded-sm"
              style={{ height: `${(item.value / maxVal) * 100}%`, minHeight: 2 }}
            />
            <span className="text-[9px] text-gray-600">{item.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
