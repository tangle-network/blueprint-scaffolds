"use client";

import { useState } from "react";
import { MOCK_JOBS, MOCK_PROVIDERS } from "@/lib/types";
import { selectProviders, distributePayment } from "@/lib/storage";

export function BlueprintView() {
  const [activeTab, setActiveTab] = useState<"jobs" | "proofs" | "selection" | "payment">("jobs");

  const tabs = [
    { id: "jobs" as const, label: "Job Definitions" },
    { id: "proofs" as const, label: "Proof Verification" },
    { id: "selection" as const, label: "Provider Selection" },
    { id: "payment" as const, label: "Payment Distribution" },
  ];

  return (
    <div className="card">
      <h2 className="text-xl font-bold mb-5">Blueprint Implementation</h2>

      <div className="flex gap-1 mb-5 bg-surface-200 rounded-lg p-1">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              activeTab === tab.id
                ? "bg-tangle-600 text-white"
                : "text-gray-400 hover:text-white"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === "jobs" && <JobsPanel />}
      {activeTab === "proofs" && <ProofsPanel />}
      {activeTab === "selection" && <SelectionPanel />}
      {activeTab === "payment" && <PaymentPanel />}
    </div>
  );
}

function JobsPanel() {
  const statusColor = (s: string) => {
    switch (s) {
      case "completed":
        return "badge-green";
      case "running":
        return "badge-yellow";
      case "queued":
        return "badge-blue";
      case "failed":
        return "badge-red";
      default:
        return "badge";
    }
  };

  return (
    <div>
      <h3 className="font-semibold mb-3">Storage Job Definitions</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-surface-300 text-left text-gray-400">
              <th className="pb-3 pr-4">ID</th>
              <th className="pb-3 pr-4">Type</th>
              <th className="pb-3 pr-4">Provider</th>
              <th className="pb-3 pr-4">Status</th>
              <th className="pb-3 pr-4">Created</th>
              <th className="pb-3 pr-4">Payment</th>
              <th className="pb-3">Params</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_JOBS.map((job) => (
              <tr
                key={job.id}
                className="border-b border-surface-300/50 hover:bg-surface-200/50"
              >
                <td className="py-3 pr-4 font-mono text-xs">{job.id}</td>
                <td className="py-3 pr-4">
                  <span className="badge-blue">{job.type}</span>
                </td>
                <td className="py-3 pr-4 text-xs">{job.assignedProvider}</td>
                <td className="py-3 pr-4">
                  <span className={statusColor(job.status)}>{job.status}</span>
                </td>
                <td className="py-3 pr-4 text-xs text-gray-400">
                  {new Date(job.createdAt).toLocaleString()}
                </td>
                <td className="py-3 pr-4 text-xs">
                  {job.payment.amount} {job.payment.token}
                  {job.payment.distributed && (
                    <span className="text-green-400 ml-1">✓</span>
                  )}
                </td>
                <td className="py-3 text-xs text-gray-400 font-mono max-w-48 truncate">
                  {JSON.stringify(job.params)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-4 p-4 bg-surface-200 rounded-lg border border-surface-300">
        <h4 className="font-medium text-sm mb-2">Job Type Reference</h4>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-xs">
          {[
            { type: "store", desc: "Upload and replicate file to storage nodes" },
            { type: "retrieve", desc: "Fetch and decrypt file from provider" },
            { type: "replicate", desc: "Create additional replicas on new nodes" },
            { type: "repair", desc: "Restore damaged or missing shards" },
            { type: "delete", desc: "Remove file and all replicas from network" },
            { type: "prove", desc: "Generate and verify proof of storage" },
          ].map((jt) => (
            <div key={jt.type} className="bg-surface-300/50 rounded p-2">
              <div className="font-mono text-tangle-400">{jt.type}</div>
              <div className="text-gray-500 mt-0.5">{jt.desc}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ProofsPanel() {
  return (
    <div>
      <h3 className="font-semibold mb-3">Proof Verification Logic</h3>

      <div className="space-y-4">
        <div className="p-4 bg-surface-200 rounded-lg border border-surface-300">
          <h4 className="text-sm font-medium text-tangle-400 mb-2">
            1. Challenge Generation
          </h4>
          <p className="text-sm text-gray-400">
            The blueprint generates a random challenge from the latest block hash
            on the Tangle Network. Each storage provider must respond with a
            proof that they still hold the assigned data shard.
          </p>
          <div className="mt-2 font-mono text-xs bg-surface-300/50 p-3 rounded">
            challenge = H(block_hash || file_cid || nonce)
          </div>
        </div>

        <div className="p-4 bg-surface-200 rounded-lg border border-surface-300">
          <h4 className="text-sm font-medium text-tangle-400 mb-2">
            2. Proof Construction
          </h4>
          <p className="text-sm text-gray-400">
            The provider reads the challenged shard, computes a Merkle proof
            from the shard to the stored Merkle root, and signs the response.
          </p>
          <div className="mt-2 font-mono text-xs bg-surface-300/50 p-3 rounded">
            {"{"}
            <br />
            {"  "}challenge, response, merkle_root, merkle_proof[], signature
            <br />
            {"}"}
          </div>
        </div>

        <div className="p-4 bg-surface-200 rounded-lg border border-surface-300">
          <h4 className="text-sm font-medium text-tangle-400 mb-2">
            3. On-Chain Verification
          </h4>
          <p className="text-sm text-gray-400">
            The blueprint verifier checks: (a) Merkle proof validity, (b)
            response matches challenge for the claimed Merkle root, (c) provider
            signature is valid. If all pass, the provider receives payment.
          </p>
          <div className="mt-2 font-mono text-xs bg-surface-300/50 p-3 rounded">
            verify(merkle_proof, merkle_root, challenge, response) && verify_sig(signature, provider_pubkey)
          </div>
        </div>
      </div>

      <div className="mt-4 p-4 bg-surface-200 rounded-lg border border-surface-300">
        <h4 className="font-medium text-sm mb-2">Recent Proof Results</h4>
        <div className="space-y-2 text-sm">
          {MOCK_PROVIDERS.map((p) => (
            <div
              key={p.id}
              className="flex items-center justify-between py-1.5 border-b border-surface-300/50 last:border-0"
            >
              <span className="font-mono text-xs">{p.address.slice(0, 12)}...</span>
              <span className="text-xs text-gray-400">
                {p.proofsVerified} / {p.proofsGenerated} verified
              </span>
              <span className="badge-green">
                {((p.proofsVerified / p.proofsGenerated) * 100).toFixed(2)}%
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function SelectionPanel() {
  const selected = selectProviders(MOCK_PROVIDERS, 3, {
    maxLatency: 50,
    minReputation: 85,
    preferredRegions: ["US-East", "EU-West"],
  });

  return (
    <div>
      <h3 className="font-semibold mb-3">Provider Selection Algorithm</h3>

      <div className="p-4 bg-surface-200 rounded-lg border border-surface-300 mb-4">
        <h4 className="text-sm font-medium text-tangle-400 mb-2">
          Scoring Formula
        </h4>
        <div className="font-mono text-xs bg-surface-300/50 p-3 rounded">
          score = reputation * 0.4 + (100 - latency) * 0.3 + (1 - price/1) *
          0.2 + (uptime/100 * 10) * 0.1
        </div>
        <div className="mt-3 text-sm text-gray-400">
          Providers are scored and filtered by: max latency (50ms), min
          reputation (85), preferred regions (US-East, EU-West).
        </div>
      </div>

      <h4 className="font-medium text-sm mb-2">
        Selected Providers (top 3 of {MOCK_PROVIDERS.length} candidates)
      </h4>
      <div className="space-y-2">
        {selected.map((p, i) => (
          <div
            key={p.id}
            className="flex items-center justify-between bg-surface-200 rounded-lg p-3 border border-surface-300"
          >
            <div className="flex items-center gap-3">
              <span className="text-lg font-bold text-tangle-400">#{i + 1}</span>
              <div>
                <div className="font-mono text-sm">{p.address.slice(0, 16)}...</div>
                <div className="text-xs text-gray-500">{p.region}</div>
              </div>
            </div>
            <div className="flex gap-6 text-xs">
              <span>Rep: <b>{p.reputation}</b></span>
              <span>Latency: <b>{p.latency}ms</b></span>
              <span>Price: <b>{p.pricePerGB} TNT</b></span>
              <span>Uptime: <b>{p.uptime}%</b></span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function PaymentPanel() {
  const topProviders = MOCK_PROVIDERS.slice(0, 4);
  const dist = distributePayment(topProviders, 10.0);

  return (
    <div>
      <h3 className="font-semibold mb-3">Payment Distribution</h3>

      <div className="p-4 bg-surface-200 rounded-lg border border-surface-300 mb-4">
        <h4 className="text-sm font-medium text-tangle-400 mb-2">
          Distribution Formula
        </h4>
        <div className="font-mono text-xs bg-surface-300/50 p-3 rounded">
          payment_i = (reputation_i / sum(reputation_j)) * total_amount
        </div>
        <div className="mt-3 text-sm text-gray-400">
          Payments are weighted by provider reputation scores, ensuring higher-quality
          providers earn more. Total pool: <b>10.0 TNT</b> across{" "}
          <b>{topProviders.length} providers</b>.
        </div>
      </div>

      <div className="space-y-3">
        {dist.map((d, i) => {
          const provider = topProviders[i];
          const pct = (d.amount / 10.0) * 100;
          return (
            <div key={d.providerId} className="bg-surface-200 rounded-lg p-3 border border-surface-300">
              <div className="flex items-center justify-between mb-2">
                <span className="font-mono text-sm">
                  {provider?.address.slice(0, 14)}...
                </span>
                <span className="text-lg font-bold text-tangle-400">
                  {d.amount.toFixed(3)} TNT
                </span>
              </div>
              <div className="w-full bg-surface-300 rounded-full h-2">
                <div
                  className="bg-tangle-500 h-2 rounded-full"
                  style={{ width: `${pct}%` }}
                />
              </div>
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>Reputation: {provider?.reputation}</span>
                <span>{pct.toFixed(1)}% of total</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
