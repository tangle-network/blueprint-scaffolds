"use client";

import { useState } from "react";
import { calculateStorageCost } from "@/lib/storage";

export function CostCalculator() {
  const [sizeGB, setSizeGB] = useState(10);
  const [months, setMonths] = useState(6);
  const [replicas, setReplicas] = useState(5);
  const [pricePerGB, setPricePerGB] = useState(0.40);

  const cost = calculateStorageCost(sizeGB, months, replicas, pricePerGB);
  const erasureOverhead = replicas > 1 ? 0.4 : 0;
  const totalWithErasure = cost * (1 + erasureOverhead);

  return (
    <div className="card">
      <h2 className="text-xl font-bold mb-5">Cost Calculator</h2>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <SliderInput
            label="Storage Size"
            unit="GB"
            value={sizeGB}
            min={1}
            max={10000}
            step={1}
            onChange={setSizeGB}
          />
          <SliderInput
            label="Duration"
            unit="months"
            value={months}
            min={1}
            max={36}
            step={1}
            onChange={setMonths}
          />
          <SliderInput
            label="Replication Factor"
            unit="replicas"
            value={replicas}
            min={1}
            max={12}
            step={1}
            onChange={setReplicas}
          />
          <SliderInput
            label="Price per GB"
            unit="TNT/GB/month"
            value={pricePerGB}
            min={0.1}
            max={2.0}
            step={0.05}
            onChange={setPricePerGB}
          />
        </div>

        <div className="bg-surface-200 rounded-lg p-6 border border-surface-300">
          <h3 className="font-semibold mb-4">Cost Breakdown</h3>

          <div className="space-y-3">
            <CostRow
              label="Base Storage Cost"
              value={`${cost.toFixed(2)} TNT`}
            />
            <CostRow
              label="Erasure Coding Overhead"
              value={`${(erasureOverhead * 100).toFixed(0)}%`}
            />
            <CostRow
              label="Bandwidth (est.)"
              value={`${(sizeGB * replicas * 0.1).toFixed(1)} GB`}
            />
            <CostRow
              label="Proof Generation"
              value={`${(cost * 0.02).toFixed(3)} TNT`}
            />

            <div className="border-t border-surface-300 pt-3 mt-3">
              <div className="flex justify-between items-center">
                <span className="font-semibold">Total (estimated)</span>
                <span className="text-2xl font-bold text-tangle-400">
                  {totalWithErasure.toFixed(2)} TNT
                </span>
              </div>
              <div className="text-xs text-gray-500 mt-1">
                ≈ ${(totalWithErasure * 0.15).toFixed(2)} USD equivalent
              </div>
            </div>
          </div>

          <div className="mt-6 p-3 bg-surface-300/50 rounded-lg">
            <div className="text-xs text-gray-400 mb-2">
              Cost Comparison
            </div>
            <div className="space-y-1.5 text-xs">
              <ComparisonRow label="Tangle Storage" value={totalWithErasure} current />
              <ComparisonRow label="AWS S3" value={totalWithErasure * 2.8} />
              <ComparisonRow label="Google Cloud" value={totalWithErasure * 2.5} />
              <ComparisonRow label="Filecoin" value={totalWithErasure * 1.4} />
              <ComparisonRow label="Arweave" value={totalWithErasure * 3.1} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function SliderInput({
  label,
  unit,
  value,
  min,
  max,
  step,
  onChange,
}: {
  label: string;
  unit: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
}) {
  return (
    <div>
      <div className="flex justify-between text-sm mb-2">
        <span className="text-gray-400">{label}</span>
        <span className="font-mono font-medium">
          {value} <span className="text-gray-500">{unit}</span>
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="w-full accent-tangle-500"
      />
      <div className="flex justify-between text-xs text-gray-600 mt-1">
        <span>{min}</span>
        <span>{max}</span>
      </div>
    </div>
  );
}

function CostRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between text-sm">
      <span className="text-gray-400">{label}</span>
      <span className="font-mono">{value}</span>
    </div>
  );
}

function ComparisonRow({
  label,
  value,
  current,
}: {
  label: string;
  value: number;
  current?: boolean;
}) {
  return (
    <div className="flex justify-between">
      <span className={current ? "text-tangle-400 font-medium" : "text-gray-400"}>
        {label}
      </span>
      <span className={current ? "text-tangle-400 font-bold" : "text-gray-300"}>
        {value.toFixed(2)} TNT
      </span>
    </div>
  );
}
