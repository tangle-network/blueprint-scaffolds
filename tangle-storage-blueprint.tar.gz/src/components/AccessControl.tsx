"use client";

import { useState } from "react";
import { MOCK_ACCESS_GRANTS, AccessGrant } from "@/lib/types";

export function AccessControl() {
  const [grants] = useState<AccessGrant[]>(MOCK_ACCESS_GRANTS);
  const [showNew, setShowNew] = useState(false);

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-xl font-bold">Access Control</h2>
        <button className="btn-primary" onClick={() => setShowNew(!showNew)}>
          {showNew ? "Cancel" : "Grant Access"}
        </button>
      </div>

      {showNew && (
        <div className="mb-5 p-4 bg-surface-200 rounded-lg border border-surface-300">
          <h3 className="font-semibold mb-3">New Access Grant</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-gray-500 block mb-1">File ID</label>
              <input type="text" placeholder="f1" className="w-full" />
            </div>
            <div>
              <label className="text-xs text-gray-500 block mb-1">Grantee Address</label>
              <input type="text" placeholder="5GrwvaEF..." className="w-full" />
            </div>
            <div>
              <label className="text-xs text-gray-500 block mb-1">Permissions</label>
              <div className="flex gap-2">
                {["read", "write", "delete", "share"].map((perm) => (
                  <label key={perm} className="flex items-center gap-1.5 text-sm">
                    <input type="checkbox" defaultChecked={perm === "read"} />
                    {perm}
                  </label>
                ))}
              </div>
            </div>
            <div>
              <label className="text-xs text-gray-500 block mb-1">Expires In</label>
              <select className="w-full">
                <option>1 day</option>
                <option>7 days</option>
                <option>30 days</option>
                <option>90 days</option>
                <option>Never</option>
              </select>
            </div>
            <div>
              <label className="text-xs text-gray-500 block mb-1">Multi-Sig Required</label>
              <input type="number" min={1} max={10} defaultValue={1} className="w-24" />
            </div>
            <div className="flex items-end">
              <button className="btn-primary">Create Grant</button>
            </div>
          </div>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-surface-300 text-left text-gray-400">
              <th className="pb-3 pr-4">File</th>
              <th className="pb-3 pr-4">Grantee</th>
              <th className="pb-3 pr-4">Grantor</th>
              <th className="pb-3 pr-4">Permissions</th>
              <th className="pb-3 pr-4">Expires</th>
              <th className="pb-3 pr-4">Multi-Sig</th>
              <th className="pb-3 pr-4">Bandwidth</th>
              <th className="pb-3">Token</th>
            </tr>
          </thead>
          <tbody>
            {grants.map((grant) => {
              const expiresDate = new Date(grant.expiresAt);
              const isExpired = expiresDate.getTime() < Date.now();
              const daysLeft = Math.ceil(
                (expiresDate.getTime() - Date.now()) / 86400000
              );
              return (
                <tr
                  key={grant.id}
                  className="border-b border-surface-300/50 hover:bg-surface-200/50"
                >
                  <td className="py-3 pr-4 font-mono text-xs">{grant.fileId}</td>
                  <td className="py-3 pr-4 font-mono text-xs">
                    {grant.grantee.slice(0, 12)}...
                  </td>
                  <td className="py-3 pr-4 font-mono text-xs">
                    {grant.grantor.slice(0, 12)}...
                  </td>
                  <td className="py-3 pr-4">
                    <div className="flex gap-1">
                      {grant.permissions.map((p) => (
                        <span key={p} className="badge-blue text-[10px]">
                          {p}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="py-3 pr-4 text-xs">
                    {isExpired ? (
                      <span className="badge-red">expired</span>
                    ) : (
                      <span className="badge-green">{daysLeft}d left</span>
                    )}
                  </td>
                  <td className="py-3 pr-4 text-xs">
                    {grant.signatures.length}/{grant.multiSigRequired}
                  </td>
                  <td className="py-3 pr-4 text-xs text-gray-400">
                    {(Math.random() * 5).toFixed(1)} GB
                  </td>
                  <td className="py-3 text-xs font-mono text-gray-500">
                    {grant.tokenHash.slice(0, 10)}...
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="mt-4 p-4 bg-surface-200 rounded-lg border border-surface-300">
        <h4 className="font-medium text-sm mb-2">Bandwidth Metering</h4>
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-lg font-bold text-tangle-400">12.4 GB</div>
            <div className="text-xs text-gray-500">Read (24h)</div>
          </div>
          <div>
            <div className="text-lg font-bold text-green-400">3.2 GB</div>
            <div className="text-xs text-gray-500">Write (24h)</div>
          </div>
          <div>
            <div className="text-lg font-bold text-yellow-400">0.8 GB</div>
            <div className="text-xs text-gray-500">Repair Transfer (24h)</div>
          </div>
        </div>
      </div>
    </div>
  );
}
