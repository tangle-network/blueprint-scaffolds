"use client";

import { MOCK_PROVIDERS, StorageProvider } from "@/lib/types";

export function ProviderMetrics() {
  return (
    <div className="card">
      <h2 className="text-xl font-bold mb-5">Storage Providers</h2>
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
        {MOCK_PROVIDERS.map((provider) => (
          <ProviderCard key={provider.id} provider={provider} />
        ))}
      </div>

      <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
        <GlobalStat label="Avg Reputation" value="89" suffix="/ 100" />
        <GlobalStat label="Avg Uptime" value="99.88" suffix="%" />
        <GlobalStat label="Total Capacity" value="28.5" suffix=" TB" />
        <GlobalStat label="Avg Price" value="0.39" suffix=" TNT/GB" />
      </div>
    </div>
  );
}

function ProviderCard({ provider }: { provider: StorageProvider }) {
  const usedPct = ((provider.usedSpace / provider.totalSpace) * 100).toFixed(1);
  const reputationColor =
    provider.reputation >= 90
      ? "text-green-400"
      : provider.reputation >= 80
      ? "text-yellow-400"
      : "text-red-400";

  return (
    <div className="bg-surface-200 rounded-lg p-4 border border-surface-300">
      <div className="flex items-center justify-between mb-3">
        <div>
          <div className="font-medium text-sm">
            {provider.address.slice(0, 12)}...
          </div>
          <div className="text-xs text-gray-500">{provider.region}</div>
        </div>
        <span className={`text-lg font-bold ${reputationColor}`}>
          {provider.reputation}
        </span>
      </div>

      <div className="space-y-2">
        <Bar label="Storage" used={Number(usedPct)} />
        <div className="flex justify-between text-xs text-gray-400">
          <span>
            {provider.usedSpace} / {provider.totalSpace} GB
          </span>
          <span>{usedPct}%</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 mt-3 text-xs">
        <MiniStat label="Uptime" value={`${provider.uptime}%`} />
        <MiniStat label="Latency" value={`${provider.latency}ms`} />
        <MiniStat label="Price" value={`${provider.pricePerGB} TNT/GB`} />
        <MiniStat
          label="Proofs"
          value={`${provider.proofsVerified}/${provider.proofsGenerated}`}
        />
      </div>
    </div>
  );
}

function Bar({ used }: { label: string; used: number }) {
  const color =
    used > 90 ? "bg-red-500" : used > 70 ? "bg-yellow-500" : "bg-tangle-500";
  return (
    <div className="w-full bg-surface-300 rounded-full h-1.5">
      <div
        className={`h-1.5 rounded-full ${color}`}
        style={{ width: `${Math.min(used, 100)}%` }}
      />
    </div>
  );
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-gray-500">{label}</div>
      <div className="font-medium">{value}</div>
    </div>
  );
}

function GlobalStat({
  label,
  value,
  suffix,
}: {
  label: string;
  value: string;
  suffix: string;
}) {
  return (
    <div className="bg-surface-200 rounded-lg p-3 border border-surface-300">
      <div className="text-gray-500 text-xs">{label}</div>
      <div className="text-xl font-bold text-tangle-400">
        {value}
        <span className="text-sm text-gray-400">{suffix}</span>
      </div>
    </div>
  );
}
