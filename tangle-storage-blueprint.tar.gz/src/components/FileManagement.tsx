"use client";

import { useState } from "react";
import { MOCK_FILES, StorageFile } from "@/lib/types";
import { formatBytes } from "@/lib/storage";

export function FileManagement() {
  const [files] = useState<StorageFile[]>(MOCK_FILES);
  const [search, setSearch] = useState("");
  const [selectedFile, setSelectedFile] = useState<StorageFile | null>(null);

  const filtered = files.filter((f) =>
    f.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-xl font-bold">File Management</h2>
        <div className="flex items-center gap-3">
          <input
            type="text"
            placeholder="Search files..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-64"
          />
          <button className="btn-primary">Upload File</button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-surface-300 text-left text-gray-400">
              <th className="pb-3 pr-4">Name</th>
              <th className="pb-3 pr-4">CID</th>
              <th className="pb-3 pr-4">Size</th>
              <th className="pb-3 pr-4">Replicas</th>
              <th className="pb-3 pr-4">Encryption</th>
              <th className="pb-3 pr-4">Uploaded</th>
              <th className="pb-3 pr-4">Status</th>
              <th className="pb-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((file) => (
              <tr
                key={file.id}
                className="border-b border-surface-300/50 hover:bg-surface-200/50 cursor-pointer"
                onClick={() =>
                  setSelectedFile(selectedFile?.id === file.id ? null : file)
                }
              >
                <td className="py-3 pr-4 font-medium">{file.name}</td>
                <td className="py-3 pr-4 text-gray-400 font-mono text-xs">
                  {file.cid}
                </td>
                <td className="py-3 pr-4 text-gray-300">
                  {formatBytes(file.size)}
                </td>
                <td className="py-3 pr-4">
                  <span className="text-tangle-400">{file.replicas}</span>
                </td>
                <td className="py-3 pr-4 text-gray-400 text-xs">
                  {file.encryption}
                </td>
                <td className="py-3 pr-4 text-gray-400">{file.uploadedAt}</td>
                <td className="py-3 pr-4">
                  <StatusBadge status={file.status} />
                </td>
                <td className="py-3">
                  <div className="flex gap-2">
                    <button className="text-xs btn-secondary py-1 px-2">
                      Retrieve
                    </button>
                    <button className="text-xs btn-secondary py-1 px-2">
                      Share
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selectedFile && (
        <div className="mt-4 p-4 bg-surface-200 rounded-lg border border-surface-300">
          <h3 className="font-semibold mb-3">
            File Details: {selectedFile.name}
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <Detail label="Content ID" value={selectedFile.cid} />
            <Detail label="Size" value={formatBytes(selectedFile.size)} />
            <Detail
              label="Replicas"
              value={String(selectedFile.replicas)}
            />
            <Detail label="Encryption" value={selectedFile.encryption} />
            <Detail label="Erasure Coding" value="10 data + 4 parity" />
            <Detail label="Merkle Root" value="0xab12...cd34" />
            <Detail
              label="Last Proven"
              value="2 minutes ago"
            />
            <Detail label="Bandwidth Used" value="1.2 GB" />
          </div>
          <div className="mt-4 flex gap-3">
            <button className="btn-primary text-sm py-1.5">
              Request Proof of Storage
            </button>
            <button className="btn-secondary text-sm py-1.5">
              Increase Replication
            </button>
            <button className="btn-secondary text-sm py-1.5">
              Trigger Repair
            </button>
          </div>
        </div>
      )}

      <div className="mt-4 flex items-center justify-between text-sm text-gray-500">
        <span>
          Showing {filtered.length} of {files.length} files
        </span>
        <span>
          Total storage: {formatBytes(files.reduce((s, f) => s + f.size, 0))}
        </span>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: StorageFile["status"] }) {
  const cls =
    status === "available"
      ? "badge-green"
      : status === "repairing"
      ? "badge-yellow"
      : "badge-blue";
  return <span className={cls}>{status}</span>;
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-gray-500 text-xs">{label}</div>
      <div className="font-mono text-xs mt-0.5">{value}</div>
    </div>
  );
}
