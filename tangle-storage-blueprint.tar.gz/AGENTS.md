# AGENTS.md

## Goal

Build a decentralized storage service Blueprint for Tangle Network. File upload, erasure coding, retrieval, payment channels.

## Stack

- Family: `tangle-blueprint`
- Layers: 
- Partner: `tangle`

## Entry Points

- `tangle-storage-blueprint-bin/src/main.rs`
- `tangle-storage-blueprint-lib/src/lib.rs`
- `blueprint.json`
- `contracts/src/HelloBlueprint.sol`
- `Cargo.toml`

## Commands

- `cargo test -p tangle-storage-blueprint-lib`
- `cargo build --release`

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
