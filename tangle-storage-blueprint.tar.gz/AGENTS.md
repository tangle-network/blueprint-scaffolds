# AGENTS.md

Build a decentralized storage service Blueprint for Tangle Network. File upload, erasure coding, retrieval, payment channels.

## What's here

This project was scaffolded by starter-foundry. The user's prompt drove the choices below — read their prompt first, it takes priority over everything in this file.

- **Family:** `tangle-blueprint`
- **Layers:** `framework:tangle-blueprint`
- **Partner:** `tangle`

## Getting started

```bash
cargo test -p tangle-storage-blueprint-lib
cargo build --release
```

Key files: `tangle-storage-blueprint-bin/src/main.rs`, `tangle-storage-blueprint-lib/src/lib.rs`, `blueprint.json`, `contracts/src/HelloBlueprint.sol`, `Cargo.toml`

## How to use this scaffold

This is a starting point, not a contract. You own every file.

- **Customize freely.** Replace components, change the layout, swap the color scheme — whatever fits the user's product.
- **The scaffold saves you setup time** — Tailwind, shadcn/ui, path aliases, and framework config are ready. Don't redo them.
- **Check `.starter-foundry/compose-report.json`** if you want to see which layer wrote which file.
- **Update this file** as the project evolves. Delete sections that no longer apply.
