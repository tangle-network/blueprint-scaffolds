import fs from "node:fs/promises";
import path from "node:path";
import type { Download } from "@playwright/test";
import type { RunRecord, TaskAction, TaskDefinition } from "../shared/types.js";
import { paths } from "./paths.js";
import { Repository } from "./repository.js";
import { BrowserSessionManager } from "./session-manager.js";

const actionLabel = (action: TaskAction, index: number): string => action.label ?? `${action.type} #${index + 1}`;

export class AutomationRunner {
  constructor(
    private readonly repository: Repository,
    private readonly sessions: BrowserSessionManager
  ) {}

  async execute(task: TaskDefinition, run: RunRecord): Promise<void> {
    await this.repository.updateRunStatus(run.id, "running");
    const session = await this.sessions.createSession(run.id);
    const downloads: string[] = [];
    const onDownload = async (download: Download) => {
      const suggested = download.suggestedFilename();
      const destination = path.join(session.downloadsDir, suggested);
      await download.saveAs(destination);
      downloads.push(path.relative(paths.projectRoot, destination));
    };
    session.page.on("download", (download) => {
      void onDownload(download);
    });

    try {
      for (let index = 0; index < task.actions.length; index += 1) {
        const action = task.actions[index];
        const retries = action.retries ?? 0;
        let success = false;
        let lastError: unknown;

        for (let attempt = 1; attempt <= retries + 1; attempt += 1) {
          await this.repository.startAttempt(run.id, index, attempt);
          try {
            const details = await this.performAction(run.id, index, session.page, action);
            await this.repository.finishAttempt(run.id, index, "completed", details);
            success = true;
            break;
          } catch (error) {
            lastError = error;
            await this.repository.finishAttempt(run.id, index, "failed", {
              error: error instanceof Error ? error.message : String(error)
            });
          }
        }

        if (!success) {
          throw new Error(`Step failed: ${actionLabel(action, index)}. ${String(lastError)}`);
        }
      }

      await this.repository.recordDownloadedArtifacts(run.id, downloads);
      await this.repository.updateRunStatus(run.id, "completed");
    } catch (error) {
      await this.repository.recordDownloadedArtifacts(run.id, downloads);
      await this.repository.updateRunStatus(
        run.id,
        "failed",
        error instanceof Error ? error.message : String(error)
      );
    } finally {
      await session.close();
    }
  }

  private async performAction(runId: string, stepIndex: number, page: import("@playwright/test").Page, action: TaskAction) {
    switch (action.type) {
      case "goto": {
        await page.goto(action.url, {
          timeout: action.timeoutMs ?? 30_000,
          waitUntil: "domcontentloaded"
        });
        return await this.captureStepArtifacts(runId, stepIndex, page, action.type);
      }
      case "waitForSelector": {
        await page.waitForSelector(action.selector, {
          state: action.state ?? "visible",
          timeout: action.timeoutMs ?? 15_000
        });
        return await this.captureStepArtifacts(runId, stepIndex, page, action.type);
      }
      case "click": {
        await page.locator(action.selector).click({ timeout: action.timeoutMs ?? 15_000 });
        return await this.captureStepArtifacts(runId, stepIndex, page, action.type);
      }
      case "type": {
        await page.locator(action.selector).fill(action.value, { timeout: action.timeoutMs ?? 15_000 });
        return await this.captureStepArtifacts(runId, stepIndex, page, action.type);
      }
      case "extractText": {
        const value = (await page.locator(action.selector).first().textContent({ timeout: action.timeoutMs ?? 15_000 }))?.trim();
        if (!value) {
          throw new Error(`No text found for selector: ${action.selector}`);
        }
        const details = await this.captureStepArtifacts(runId, stepIndex, page, action.type);
        return {
          ...details,
          extraction: {
            key: action.key,
            value
          }
        };
      }
      case "extractAttribute": {
        const value = await page
          .locator(action.selector)
          .first()
          .getAttribute(action.attribute, { timeout: action.timeoutMs ?? 15_000 });
        if (!value) {
          throw new Error(`No attribute ${action.attribute} found for selector: ${action.selector}`);
        }
        const details = await this.captureStepArtifacts(runId, stepIndex, page, action.type);
        return {
          ...details,
          extraction: {
            key: action.key,
            value
          }
        };
      }
      case "screenshot": {
        const screenshotPath = await this.writeScreenshot(runId, page, `${stepIndex + 1}-${action.name}.png`, action.fullPage ?? true);
        return {
          screenshotPath
        };
      }
      case "snapshotDOM": {
        const domSnapshotPath = await this.writeDomSnapshot(runId, page, `${stepIndex + 1}-${action.name}.html`);
        return {
          domSnapshotPath
        };
      }
    }
  }

  private async captureStepArtifacts(runId: string, stepIndex: number, page: import("@playwright/test").Page, actionType: string) {
    const screenshotPath = await this.writeScreenshot(runId, page, `${stepIndex + 1}-${actionType}.png`, false);
    const domSnapshotPath = await this.writeDomSnapshot(runId, page, `${stepIndex + 1}-${actionType}.html`);
    return {
      screenshotPath,
      domSnapshotPath
    };
  }

  private async writeScreenshot(runId: string, page: import("@playwright/test").Page, fileName: string, fullPage: boolean) {
    const target = path.join(paths.artifactDir, runId, fileName);
    await fs.mkdir(path.dirname(target), { recursive: true });
    await page.screenshot({ path: target, fullPage });
    return path.relative(paths.projectRoot, target);
  }

  private async writeDomSnapshot(runId: string, page: import("@playwright/test").Page, fileName: string) {
    const target = path.join(paths.artifactDir, runId, fileName);
    await fs.mkdir(path.dirname(target), { recursive: true });
    const content = await page.content();
    await fs.writeFile(target, content, "utf8");
    return path.relative(paths.projectRoot, target);
  }
}
