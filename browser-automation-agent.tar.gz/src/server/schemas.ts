import { z } from "zod";

const baseAction = {
  label: z.string().optional(),
  retries: z.number().int().min(0).max(5).optional(),
  timeoutMs: z.number().int().positive().max(120_000).optional()
};

export const taskActionSchema = z.discriminatedUnion("type", [
  z.object({
    type: z.literal("goto"),
    url: z.url(),
    ...baseAction
  }),
  z.object({
    type: z.literal("waitForSelector"),
    selector: z.string().min(1),
    state: z.enum(["attached", "detached", "visible", "hidden"]).optional(),
    ...baseAction
  }),
  z.object({
    type: z.literal("click"),
    selector: z.string().min(1),
    ...baseAction
  }),
  z.object({
    type: z.literal("type"),
    selector: z.string().min(1),
    value: z.string(),
    ...baseAction
  }),
  z.object({
    type: z.literal("extractText"),
    selector: z.string().min(1),
    key: z.string().min(1),
    ...baseAction
  }),
  z.object({
    type: z.literal("extractAttribute"),
    selector: z.string().min(1),
    attribute: z.string().min(1),
    key: z.string().min(1),
    ...baseAction
  }),
  z.object({
    type: z.literal("screenshot"),
    name: z.string().min(1),
    fullPage: z.boolean().optional(),
    label: z.string().optional(),
    retries: z.number().int().min(0).max(5).optional()
  }),
  z.object({
    type: z.literal("snapshotDOM"),
    name: z.string().min(1),
    label: z.string().optional(),
    retries: z.number().int().min(0).max(5).optional()
  })
]);

export const createTaskSchema = z.object({
  name: z.string().min(3),
  description: z.string().min(3),
  startUrl: z.url(),
  actions: z.array(taskActionSchema).min(1)
});

export const createRunSchema = z.object({
  taskId: z.string().min(1)
});
