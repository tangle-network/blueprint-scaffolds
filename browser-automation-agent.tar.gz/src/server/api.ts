import express from "express";
import path from "node:path";
import type { DashboardState } from "../shared/types.js";
import { createRunSchema, createTaskSchema } from "./schemas.js";
import { paths } from "./paths.js";
import { Repository } from "./repository.js";
import { WorkerQueue } from "./queue.js";
import { AutomationRunner } from "./runner.js";

export const createApiRouter = (
  repository: Repository,
  queue: WorkerQueue<{ taskId: string; runId: string }>,
  runner: AutomationRunner
) => {
  const router = express.Router();

  const dashboardState = (): DashboardState => repository.getDashboardState(queue.size());

  router.get("/state", (_req, res) => {
    res.json(dashboardState());
  });

  router.post("/tasks", async (req, res) => {
    const parsed = createTaskSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.flatten() });
    }
    const task = await repository.createTask(parsed.data);
    return res.status(201).json(task);
  });

  router.post("/runs", async (req, res) => {
    const parsed = createRunSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.flatten() });
    }
    const task = repository.getTask(parsed.data.taskId);
    if (!task) {
      return res.status(404).json({ error: "Task not found" });
    }
    const run = await repository.createRun(task);
    queue.enqueue({ taskId: task.id, runId: run.id });
    return res.status(202).json(run);
  });

  router.post("/runs/:runId/replay", async (req, res) => {
    const previous = repository.getRun(req.params.runId);
    if (!previous) {
      return res.status(404).json({ error: "Run not found" });
    }
    const task = repository.getTask(previous.taskId);
    if (!task) {
      return res.status(404).json({ error: "Task not found" });
    }
    const run = await repository.createRun(task);
    queue.enqueue({ taskId: task.id, runId: run.id });
    return res.status(202).json(run);
  });

  router.get("/artifacts/:filePath(*)", (req, res) => {
    const relativePath = req.params["filePath(*)"];
    if (!relativePath) {
      return res.status(404).end();
    }
    const filePath = path.join(paths.projectRoot, relativePath);
    return res.sendFile(filePath);
  });

  router.use((error: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    const message = error instanceof Error ? error.message : "Unexpected server error";
    res.status(500).json({ error: message });
  });

  return router;
};
