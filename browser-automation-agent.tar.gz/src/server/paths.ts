import path from "node:path";
import { fileURLToPath } from "node:url";

const currentDir = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(currentDir, "../..");

export const paths = {
  projectRoot,
  dataDir: path.join(projectRoot, "data"),
  artifactDir: path.join(projectRoot, "data", "artifacts"),
  downloadsDir: path.join(projectRoot, "data", "downloads"),
  stateFile: path.join(projectRoot, "data", "state.json"),
  clientDir: path.join(projectRoot, "dist", "client")
};
