export class WorkerQueue<T> {
  private jobs: T[] = [];
  private running = false;

  constructor(private readonly handler: (job: T) => Promise<void>) {}

  enqueue(job: T): void {
    this.jobs.push(job);
    void this.drain();
  }

  size(): number {
    return this.jobs.length + (this.running ? 1 : 0);
  }

  private async drain(): Promise<void> {
    if (this.running) {
      return;
    }
    this.running = true;
    while (this.jobs.length > 0) {
      const job = this.jobs.shift();
      if (!job) {
        continue;
      }
      await this.handler(job);
    }
    this.running = false;
  }
}
