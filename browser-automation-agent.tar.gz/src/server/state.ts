import fs from "node:fs/promises";
import path from "node:path";
import { nanoid } from "nanoid";
import type { PersistedState, TaskDefinition } from "../shared/types.js";
import { paths } from "./paths.js";

const seedTasks = (): TaskDefinition[] => [
  {
    id: nanoid(),
    name: "Example: Capture Hacker News",
    description: "Loads Hacker News, captures the title, and stores a screenshot.",
    startUrl: "https://news.ycombinator.com/",
    createdAt: new Date().toISOString(),
    actions: [
      {
        type: "goto",
        url: "https://news.ycombinator.com/",
        label: "Open Hacker News",
        retries: 1
      },
      {
        type: "extractText",
        selector: "title",
        key: "pageTitle",
        label: "Extract page title",
        retries: 1
      },
      {
        type: "screenshot",
        name: "hacker-news-home",
        fullPage: true,
        label: "Capture full page",
        retries: 1
      },
      {
        type: "snapshotDOM",
        name: "hacker-news-dom",
        label: "Store DOM snapshot",
        retries: 1
      }
    ]
  },
  {
    id: nanoid(),
    name: "Example: Example.com metadata",
    description: "Visits example.com and extracts the heading and the first paragraph.",
    startUrl: "https://example.com/",
    createdAt: new Date().toISOString(),
    actions: [
      {
        type: "goto",
        url: "https://example.com/",
        label: "Open example.com",
        retries: 1
      },
      {
        type: "extractText",
        selector: "h1",
        key: "headline",
        label: "Extract heading",
        retries: 1
      },
      {
        type: "extractText",
        selector: "p",
        key: "summary",
        label: "Extract summary",
        retries: 1
      },
      {
        type: "screenshot",
        name: "example-home",
        fullPage: true,
        label: "Take screenshot",
        retries: 1
      }
    ]
  }
];

export class StateStore {
  private state: PersistedState | null = null;

  async init(): Promise<void> {
    await fs.mkdir(paths.dataDir, { recursive: true });
    await fs.mkdir(paths.artifactDir, { recursive: true });
    await fs.mkdir(paths.downloadsDir, { recursive: true });

    try {
      const contents = await fs.readFile(paths.stateFile, "utf8");
      this.state = JSON.parse(contents) as PersistedState;
    } catch {
      this.state = {
        tasks: seedTasks(),
        runs: []
      };
      await this.flush();
    }
  }

  getState(): PersistedState {
    if (!this.state) {
      throw new Error("StateStore not initialized");
    }
    return this.state;
  }

  async flush(): Promise<void> {
    if (!this.state) {
      throw new Error("StateStore not initialized");
    }
    await fs.mkdir(path.dirname(paths.stateFile), { recursive: true });
    await fs.writeFile(paths.stateFile, JSON.stringify(this.state, null, 2), "utf8");
  }
}
