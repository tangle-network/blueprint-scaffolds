import cors from "cors";
import express from "express";
import fs from "node:fs/promises";
import path from "node:path";
import { createApiRouter } from "./api.js";
import { paths } from "./paths.js";
import { WorkerQueue } from "./queue.js";
import { Repository } from "./repository.js";
import { AutomationRunner } from "./runner.js";
import { BrowserSessionManager } from "./session-manager.js";
import { StateStore } from "./state.js";

const port = Number(process.env.PORT ?? 3001);

async function main(): Promise<void> {
  await fs.mkdir(paths.clientDir, { recursive: true });

  const store = new StateStore();
  await store.init();
  const repository = new Repository(store);
  const sessions = new BrowserSessionManager();
  const runner = new AutomationRunner(repository, sessions);
  const queue = new WorkerQueue<{ taskId: string; runId: string }>(async (job) => {
    const task = repository.getTask(job.taskId);
    const run = repository.getRun(job.runId);
    if (!task || !run) {
      return;
    }
    await runner.execute(task, run);
  });

  const app = express();
  app.use(cors());
  app.use(express.json({ limit: "1mb" }));
  app.use("/api", createApiRouter(repository, queue, runner));

  if (await exists(path.join(paths.clientDir, "index.html"))) {
    app.use(express.static(paths.clientDir));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(paths.clientDir, "index.html"));
    });
  }

  app.listen(port, () => {
    console.log(`Browser agent platform listening on http://localhost:${port}`);
  });
}

async function exists(target: string): Promise<boolean> {
  try {
    await fs.access(target);
    return true;
  } catch {
    return false;
  }
}

void main();
