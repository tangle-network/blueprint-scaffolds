import { nanoid } from "nanoid";
import type {
  DashboardState,
  RunRecord,
  RunStatus,
  RunStep,
  StepAttempt,
  TaskDefinition
} from "../shared/types.js";
import { StateStore } from "./state.js";

export class Repository {
  constructor(private readonly store: StateStore) {}

  getDashboardState(queueDepth: number): DashboardState {
    const state = this.store.getState();
    return {
      tasks: [...state.tasks].sort((a, b) => b.createdAt.localeCompare(a.createdAt)),
      runs: [...state.runs].sort((a, b) => b.createdAt.localeCompare(a.createdAt)),
      queueDepth
    };
  }

  getTask(taskId: string): TaskDefinition | undefined {
    return this.store.getState().tasks.find((task) => task.id === taskId);
  }

  async createTask(input: Omit<TaskDefinition, "id" | "createdAt">): Promise<TaskDefinition> {
    const task: TaskDefinition = {
      ...input,
      id: nanoid(),
      createdAt: new Date().toISOString()
    };
    this.store.getState().tasks.unshift(task);
    await this.store.flush();
    return task;
  }

  async createRun(task: TaskDefinition): Promise<RunRecord> {
    const run: RunRecord = {
      id: nanoid(),
      taskId: task.id,
      taskName: task.name,
      status: "queued",
      createdAt: new Date().toISOString(),
      currentStepIndex: -1,
      screenshots: [],
      domSnapshots: [],
      downloadedArtifacts: [],
      extractionResults: {},
      history: task.actions.map<RunStep>((action, actionIndex) => ({
        id: nanoid(),
        actionIndex,
        actionType: action.type,
        label: action.label ?? `${action.type} step ${actionIndex + 1}`,
        status: "pending",
        retriesConfigured: action.retries ?? 0,
        attempts: []
      }))
    };
    this.store.getState().runs.unshift(run);
    await this.store.flush();
    return run;
  }

  getRun(runId: string): RunRecord | undefined {
    return this.store.getState().runs.find((run) => run.id === runId);
  }

  async updateRun(runId: string, mutator: (run: RunRecord) => void): Promise<RunRecord> {
    const run = this.getRun(runId);
    if (!run) {
      throw new Error(`Run not found: ${runId}`);
    }
    mutator(run);
    await this.store.flush();
    return run;
  }

  async updateRunStatus(runId: string, status: RunStatus, error?: string): Promise<void> {
    await this.updateRun(runId, (run) => {
      run.status = status;
      if (status === "running") {
        run.startedAt = new Date().toISOString();
      }
      if (status === "completed" || status === "failed") {
        run.finishedAt = new Date().toISOString();
      }
      run.error = error;
    });
  }

  async startAttempt(runId: string, stepIndex: number, attempt: number): Promise<void> {
    await this.updateRun(runId, (run) => {
      run.currentStepIndex = stepIndex;
      const step = run.history[stepIndex];
      step.status = "running";
      if (!step.startedAt) {
        step.startedAt = new Date().toISOString();
      }
      const item: StepAttempt = {
        attempt,
        startedAt: new Date().toISOString(),
        status: "running"
      };
      step.attempts.push(item);
    });
  }

  async finishAttempt(
    runId: string,
    stepIndex: number,
    status: "completed" | "failed",
    details?: Partial<Pick<RunStep, "screenshotPath" | "domSnapshotPath" | "extraction" | "error">>
  ): Promise<void> {
    await this.updateRun(runId, (run) => {
      const step = run.history[stepIndex];
      step.status = status;
      step.finishedAt = new Date().toISOString();
      Object.assign(step, details);
      const currentAttempt = step.attempts.at(-1);
      if (currentAttempt) {
        currentAttempt.status = status;
        currentAttempt.finishedAt = new Date().toISOString();
        currentAttempt.error = details?.error;
      }
      if (details?.screenshotPath) {
        run.screenshots.unshift(details.screenshotPath);
      }
      if (details?.domSnapshotPath) {
        run.domSnapshots.unshift(details.domSnapshotPath);
      }
      if (details?.extraction) {
        run.extractionResults[details.extraction.key] = details.extraction.value;
      }
    });
  }

  async recordDownloadedArtifacts(runId: string, files: string[]): Promise<void> {
    await this.updateRun(runId, (run) => {
      run.downloadedArtifacts = files;
    });
  }
}
