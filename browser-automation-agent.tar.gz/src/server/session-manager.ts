import fs from "node:fs/promises";
import path from "node:path";
import { chromium, type Browser, type BrowserContext, type Page } from "@playwright/test";
import { paths } from "./paths.js";

export interface SessionHandle {
  context: BrowserContext;
  page: Page;
  downloadsDir: string;
  close: () => Promise<void>;
}

export class BrowserSessionManager {
  private browserPromise: Promise<Browser> | null = null;

  private async getBrowser(): Promise<Browser> {
    if (!this.browserPromise) {
      this.browserPromise = chromium.launch({ headless: true });
    }
    return this.browserPromise;
  }

  async createSession(runId: string): Promise<SessionHandle> {
    const browser = await this.getBrowser();
    const downloadsDir = path.join(paths.downloadsDir, runId);
    await fs.mkdir(downloadsDir, { recursive: true });
    const context = await browser.newContext({
      acceptDownloads: true,
      viewport: { width: 1440, height: 960 }
    });
    const page = await context.newPage();
    return {
      context,
      page,
      downloadsDir,
      close: async () => {
        await context.close();
      }
    };
  }
}
