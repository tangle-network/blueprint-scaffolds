import { useEffect, useMemo, useState } from "react";
import clsx from "clsx";
import type { DashboardState, RunRecord, TaskAction, TaskDefinition } from "../shared/types";

const emptyTask = {
  name: "New Task",
  description: "Repeatable browser task",
  startUrl: "https://example.com",
  actions: JSON.stringify(
    [
      { type: "goto", url: "https://example.com", label: "Open page", retries: 1 },
      { type: "extractText", selector: "h1", key: "headline", label: "Read heading", retries: 1 },
      { type: "screenshot", name: "final-state", fullPage: true, label: "Capture screenshot", retries: 1 }
    ],
    null,
    2
  )
};

export function App() {
  const [state, setState] = useState<DashboardState>({ tasks: [], runs: [], queueDepth: 0 });
  const [selectedRunId, setSelectedRunId] = useState<string | null>(null);
  const [taskDraft, setTaskDraft] = useState(emptyTask);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    void refresh();
    const timer = window.setInterval(() => {
      void refresh(false);
    }, 2500);
    return () => window.clearInterval(timer);
  }, []);

  const selectedRun = useMemo(
    () => state.runs.find((run) => run.id === selectedRunId) ?? state.runs[0] ?? null,
    [selectedRunId, state.runs]
  );

  async function refresh(resetSelection = true) {
    const response = await fetch("/api/state");
    const payload = (await response.json()) as DashboardState;
    setState(payload);
    if (resetSelection && !selectedRunId && payload.runs[0]) {
      setSelectedRunId(payload.runs[0].id);
    }
  }

  async function createTask(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const actions = JSON.parse(taskDraft.actions) as TaskAction[];
      const response = await fetch("/api/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: taskDraft.name,
          description: taskDraft.description,
          startUrl: taskDraft.startUrl,
          actions
        })
      });
      if (!response.ok) {
        throw new Error("Unable to create task");
      }
      setTaskDraft(emptyTask);
      await refresh();
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Unknown error");
    } finally {
      setSubmitting(false);
    }
  }

  async function launchTask(taskId: string) {
    const response = await fetch("/api/runs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ taskId })
    });
    if (response.ok) {
      await refresh();
    }
  }

  async function replayRun(runId: string) {
    const response = await fetch(`/api/runs/${runId}/replay`, {
      method: "POST"
    });
    if (response.ok) {
      await refresh();
    }
  }

  return (
    <div className="shell">
      <header className="hero">
        <div>
          <p className="eyebrow">Browser Automation Control Plane</p>
          <h1>Repeatable web tasks with persistent runs, artifacts, and replay.</h1>
        </div>
        <div className="heroStats">
          <Stat label="Tasks" value={state.tasks.length} />
          <Stat label="Runs" value={state.runs.length} />
          <Stat label="Queue Depth" value={state.queueDepth} />
        </div>
      </header>

      <main className="layout">
        <section className="panel">
          <div className="panelHeader">
            <h2>Task Definitions</h2>
            <span>{state.tasks.length} total</span>
          </div>
          <div className="taskList">
            {state.tasks.map((task) => (
              <TaskCard key={task.id} task={task} onLaunch={() => launchTask(task.id)} />
            ))}
          </div>
        </section>

        <section className="panel">
          <div className="panelHeader">
            <h2>Create Task</h2>
            <span>JSON action pipeline</span>
          </div>
          <form className="taskForm" onSubmit={createTask}>
            <label>
              <span>Name</span>
              <input value={taskDraft.name} onChange={(event) => setTaskDraft({ ...taskDraft, name: event.target.value })} />
            </label>
            <label>
              <span>Description</span>
              <input
                value={taskDraft.description}
                onChange={(event) => setTaskDraft({ ...taskDraft, description: event.target.value })}
              />
            </label>
            <label>
              <span>Start URL</span>
              <input value={taskDraft.startUrl} onChange={(event) => setTaskDraft({ ...taskDraft, startUrl: event.target.value })} />
            </label>
            <label>
              <span>Actions</span>
              <textarea
                rows={14}
                value={taskDraft.actions}
                onChange={(event) => setTaskDraft({ ...taskDraft, actions: event.target.value })}
              />
            </label>
            {error ? <p className="error">{error}</p> : null}
            <button type="submit" disabled={submitting}>
              {submitting ? "Creating..." : "Save Task"}
            </button>
          </form>
        </section>

        <section className="panel wide">
          <div className="panelHeader">
            <h2>Run History</h2>
            <span>Review steps, artifacts, failures, and replay</span>
          </div>
          <div className="runsGrid">
            <div className="runList">
              {state.runs.map((run) => (
                <button
                  key={run.id}
                  className={clsx("runRow", selectedRun?.id === run.id && "selected")}
                  onClick={() => setSelectedRunId(run.id)}
                >
                  <strong>{run.taskName}</strong>
                  <span>{run.status}</span>
                  <span>{new Date(run.createdAt).toLocaleString()}</span>
                </button>
              ))}
            </div>
            <div className="runDetail">{selectedRun ? <RunDetail run={selectedRun} onReplay={() => replayRun(selectedRun.id)} /> : <EmptyState />}</div>
          </div>
        </section>
      </main>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="stat">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function TaskCard({ task, onLaunch }: { task: TaskDefinition; onLaunch: () => void }) {
  return (
    <article className="taskCard">
      <div>
        <h3>{task.name}</h3>
        <p>{task.description}</p>
      </div>
      <ul className="actionChips">
        {task.actions.map((action, index) => (
          <li key={`${task.id}-${index}`}>{action.type}</li>
        ))}
      </ul>
      <button onClick={onLaunch}>Launch Task</button>
    </article>
  );
}

function RunDetail({ run, onReplay }: { run: RunRecord; onReplay: () => void }) {
  return (
    <div className="detailShell">
      <div className="detailHeader">
        <div>
          <h3>{run.taskName}</h3>
          <p>
            Status: <strong>{run.status}</strong>
          </p>
          {run.error ? <p className="error">{run.error}</p> : null}
        </div>
        <button onClick={onReplay}>Replay Run</button>
      </div>

      <div className="detailColumns">
        <section>
          <h4>Step Timeline</h4>
          <div className="stepList">
            {run.history.map((step) => (
              <div key={step.id} className={clsx("stepRow", step.status)}>
                <div>
                  <strong>{step.label}</strong>
                  <p>
                    {step.actionType} · retries {step.retriesConfigured}
                  </p>
                </div>
                <div>
                  <span>{step.status}</span>
                  {step.error ? <p>{step.error}</p> : null}
                  {step.extraction ? (
                    <p>
                      {step.extraction.key}: {step.extraction.value}
                    </p>
                  ) : null}
                </div>
              </div>
            ))}
          </div>
        </section>

        <section>
          <h4>Artifacts</h4>
          <ArtifactList title="Screenshots" items={run.screenshots} />
          <ArtifactList title="DOM Snapshots" items={run.domSnapshots} />
          <ArtifactList title="Downloads" items={run.downloadedArtifacts} />
        </section>

        <section>
          <h4>Extraction Pipeline</h4>
          <div className="kvList">
            {Object.entries(run.extractionResults).map(([key, value]) => (
              <div key={key} className="kvRow">
                <span>{key}</span>
                <strong>{value}</strong>
              </div>
            ))}
            {Object.keys(run.extractionResults).length === 0 ? <p>No extraction results yet.</p> : null}
          </div>
        </section>
      </div>
    </div>
  );
}

function ArtifactList({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="artifactGroup">
      <h5>{title}</h5>
      {items.length === 0 ? (
        <p>None</p>
      ) : (
        items.map((item) => (
          <a key={item} href={`/api/artifacts/${item}`} target="_blank" rel="noreferrer">
            {item}
          </a>
        ))
      )}
    </div>
  );
}

function EmptyState() {
  return <div className="emptyState">Launch a task to inspect screenshots, DOM snapshots, retries, and failures.</div>;
}
