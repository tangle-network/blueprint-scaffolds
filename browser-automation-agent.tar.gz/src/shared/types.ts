export type RunStatus = "queued" | "running" | "completed" | "failed";

export type TaskAction =
  | {
      type: "goto";
      url: string;
      label?: string;
      timeoutMs?: number;
      retries?: number;
    }
  | {
      type: "waitForSelector";
      selector: string;
      state?: "attached" | "detached" | "visible" | "hidden";
      timeoutMs?: number;
      label?: string;
      retries?: number;
    }
  | {
      type: "click";
      selector: string;
      label?: string;
      timeoutMs?: number;
      retries?: number;
    }
  | {
      type: "type";
      selector: string;
      value: string;
      label?: string;
      timeoutMs?: number;
      retries?: number;
    }
  | {
      type: "extractText";
      selector: string;
      key: string;
      label?: string;
      timeoutMs?: number;
      retries?: number;
    }
  | {
      type: "extractAttribute";
      selector: string;
      attribute: string;
      key: string;
      label?: string;
      timeoutMs?: number;
      retries?: number;
    }
  | {
      type: "screenshot";
      name: string;
      fullPage?: boolean;
      label?: string;
      retries?: number;
    }
  | {
      type: "snapshotDOM";
      name: string;
      label?: string;
      retries?: number;
    };

export interface TaskDefinition {
  id: string;
  name: string;
  description: string;
  startUrl: string;
  createdAt: string;
  actions: TaskAction[];
}

export interface StepAttempt {
  attempt: number;
  startedAt: string;
  finishedAt?: string;
  status: "running" | "completed" | "failed";
  error?: string;
}

export interface RunStep {
  id: string;
  actionIndex: number;
  actionType: TaskAction["type"];
  label: string;
  status: "pending" | "running" | "completed" | "failed";
  startedAt?: string;
  finishedAt?: string;
  retriesConfigured: number;
  attempts: StepAttempt[];
  screenshotPath?: string;
  domSnapshotPath?: string;
  extraction?: {
    key: string;
    value: string;
  };
  error?: string;
}

export interface RunRecord {
  id: string;
  taskId: string;
  taskName: string;
  status: RunStatus;
  createdAt: string;
  startedAt?: string;
  finishedAt?: string;
  currentStepIndex: number;
  error?: string;
  screenshots: string[];
  domSnapshots: string[];
  downloadedArtifacts: string[];
  extractionResults: Record<string, string>;
  history: RunStep[];
}

export interface PersistedState {
  tasks: TaskDefinition[];
  runs: RunRecord[];
}

export interface DashboardState {
  tasks: TaskDefinition[];
  runs: RunRecord[];
  queueDepth: number;
}
