import type { Metadata } from 'next'


export const metadata: Metadata = {
  title: 'browser-agent-platform',
  description: 'browser-agent-platform',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
