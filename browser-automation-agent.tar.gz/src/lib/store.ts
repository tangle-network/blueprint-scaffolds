import { TaskDefinition, Run, Step, Artifact, WorkerQueueItem, BrowserAction, ExtractionPipeline } from "./types";
import { v4 as uuidv4 } from "uuid";

let tasks: TaskDefinition[] = [];
let runs: Run[] = [];
let workerQueue: WorkerQueueItem[] = [];

function generateId(): string {
  return uuidv4();
}

function now(): string {
  return new Date().toISOString();
}

export function getTasks(): TaskDefinition[] {
  return tasks;
}

export function getTask(id: string): TaskDefinition | undefined {
  return tasks.find((t) => t.id === id);
}

export function createTask(data: {
  name: string;
  description: string;
  url: string;
  actions: BrowserAction[];
  extractions: ExtractionPipeline[];
  maxRetries?: number;
  retryDelay?: number;
  screenshotInterval?: number;
  domSnapshotEnabled?: boolean;
}): TaskDefinition {
  const task: TaskDefinition = {
    id: generateId(),
    name: data.name,
    description: data.description,
    url: data.url,
    actions: data.actions,
    extractions: data.extractions,
    maxRetries: data.maxRetries ?? 3,
    retryDelay: data.retryDelay ?? 1000,
    screenshotInterval: data.screenshotInterval ?? 1000,
    domSnapshotEnabled: data.domSnapshotEnabled ?? true,
    status: "active",
    createdAt: now(),
    updatedAt: now(),
  };
  tasks.push(task);
  return task;
}

export function updateTask(id: string, data: Partial<TaskDefinition>): TaskDefinition | undefined {
  const idx = tasks.findIndex((t) => t.id === id);
  if (idx === -1) return undefined;
  tasks[idx] = { ...tasks[idx], ...data, updatedAt: now() };
  return tasks[idx];
}

export function deleteTask(id: string): boolean {
  const idx = tasks.findIndex((t) => t.id === id);
  if (idx === -1) return false;
  tasks.splice(idx, 1);
  return true;
}

export function getRuns(): Run[] {
  return runs;
}

export function getRun(id: string): Run | undefined {
  return runs.find((r) => r.id === id);
}

export function getRunsByTask(taskId: string): Run[] {
  return runs.filter((r) => r.taskId === taskId);
}

export function createRun(taskId: string): Run | undefined {
  const task = getTask(taskId);
  if (!task) return undefined;

  const steps: Step[] = task.actions.map((action, index) => ({
    id: generateId(),
    runId: "",
    actionIndex: index,
    action: { ...action },
    status: "pending",
    screenshotUrl: null,
    domSnapshot: null,
    result: null,
    error: null,
    startedAt: null,
    completedAt: null,
    retryCount: 0,
    duration: null,
  }));

  const runId = generateId();
  steps.forEach((s) => {
    s.runId = runId;
  });

  const run: Run = {
    id: runId,
    taskId,
    taskName: task.name,
    status: "queued",
    steps,
    artifacts: [],
    extractedData: null,
    currentStepIndex: 0,
    totalSteps: steps.length,
    startedAt: null,
    completedAt: null,
    duration: null,
    error: null,
    retryCount: 0,
    createdAt: now(),
  };

  runs.push(run);

  workerQueue.push({
    runId,
    taskId,
    priority: 0,
    addedAt: now(),
  });

  return run;
}

export function updateRun(id: string, data: Partial<Run>): Run | undefined {
  const idx = runs.findIndex((r) => r.id === id);
  if (idx === -1) return undefined;
  runs[idx] = { ...runs[idx], ...data };
  return runs[idx];
}

export function updateStep(runId: string, stepId: string, data: Partial<Step>): Step | undefined {
  const run = runs.find((r) => r.id === runId);
  if (!run) return undefined;
  const idx = run.steps.findIndex((s) => s.id === stepId);
  if (idx === -1) return undefined;
  run.steps[idx] = { ...run.steps[idx], ...data };
  return run.steps[idx];
}

export function addArtifact(runId: string, artifact: Omit<Artifact, "id" | "createdAt">): Artifact | undefined {
  const run = runs.find((r) => r.id === runId);
  if (!run) return undefined;
  const a: Artifact = {
    id: generateId(),
    createdAt: now(),
    ...artifact,
  };
  run.artifacts.push(a);
  return a;
}

export function getWorkerQueue(): WorkerQueueItem[] {
  return workerQueue;
}

export function removeFromQueue(runId: string): void {
  workerQueue = workerQueue.filter((item) => item.runId !== runId);
}

export function seedData(): void {
  const task1 = createTask({
    name: "Login Test Flow",
    description: "Automated login test that navigates to a demo site, fills in credentials, and verifies successful authentication.",
    url: "https://example.com/login",
    actions: [
      { id: generateId(), type: "navigate", label: "Navigate to login page", url: "https://example.com/login" },
      { id: generateId(), type: "wait", label: "Wait for page load", timeout: 2000 },
      { id: generateId(), type: "screenshot", label: "Screenshot: login page loaded" },
      { id: generateId(), type: "type", label: "Enter username", selector: "#username", value: "testuser@example.com" },
      { id: generateId(), type: "type", label: "Enter password", selector: "#password", value: "••••••••" },
      { id: generateId(), type: "click", label: "Click login button", selector: "button[type='submit']" },
      { id: generateId(), type: "wait", label: "Wait for redirect", timeout: 3000 },
      { id: generateId(), type: "screenshot", label: "Screenshot: post-login" },
      { id: generateId(), type: "extract", label: "Extract welcome message", selector: ".welcome-message" },
    ],
    extractions: [
      { id: generateId(), name: "welcomeText", selector: ".welcome-message", transform: "text" },
      { id: generateId(), name: "userAvatar", selector: ".avatar", transform: "src" },
    ],
  });

  const task2 = createTask({
    name: "Product Scraper",
    description: "Scrapes product listings from an e-commerce category page including names, prices, and availability.",
    url: "https://example.com/products",
    actions: [
      { id: generateId(), type: "navigate", label: "Navigate to products page", url: "https://example.com/products" },
      { id: generateId(), type: "wait", label: "Wait for products to load", selector: ".product-list", timeout: 5000 },
      { id: generateId(), type: "screenshot", label: "Screenshot: product listing" },
      { id: generateId(), type: "scroll", label: "Scroll to load more", value: "bottom" },
      { id: generateId(), type: "wait", label: "Wait for lazy load", timeout: 2000 },
      { id: generateId(), type: "screenshot", label: "Screenshot: after scroll" },
      { id: generateId(), type: "extract", label: "Extract product data", selector: ".product-item" },
    ],
    extractions: [
      { id: generateId(), name: "productNames", selector: ".product-item .name", transform: "text" },
      { id: generateId(), name: "productPrices", selector: ".product-item .price", transform: "text" },
      { id: generateId(), name: "productImages", selector: ".product-item img", transform: "src" },
    ],
  });

  const task3 = createTask({
    name: "Form Submission",
    description: "Fills out and submits a multi-step contact form with validation checks at each stage.",
    url: "https://example.com/contact",
    actions: [
      { id: generateId(), type: "navigate", label: "Navigate to contact form", url: "https://example.com/contact" },
      { id: generateId(), type: "wait", label: "Wait for form load", selector: "#contact-form", timeout: 3000 },
      { id: generateId(), type: "type", label: "Enter name", selector: "#name", value: "John Doe" },
      { id: generateId(), type: "type", label: "Enter email", selector: "#email", value: "john@example.com" },
      { id: generateId(), type: "type", label: "Enter message", selector: "#message", value: "Hello, this is a test message." },
      { id: generateId(), type: "select", label: "Select subject", selector: "#subject", value: "general" },
      { id: generateId(), type: "click", label: "Click submit", selector: "#submit-btn" },
      { id: generateId(), type: "wait", label: "Wait for confirmation", timeout: 3000 },
      { id: generateId(), type: "screenshot", label: "Screenshot: submission result" },
      { id: generateId(), type: "extract", label: "Extract confirmation", selector: ".confirmation-message" },
    ],
    extractions: [
      { id: generateId(), name: "confirmationText", selector: ".confirmation-message", transform: "text" },
      { id: generateId(), name: "referenceNumber", selector: ".ref-number", transform: "text" },
    ],
  });

  const completedRun = createRun(task1.id);
  if (completedRun) {
    completedRun.status = "completed";
    completedRun.startedAt = new Date(Date.now() - 45000).toISOString();
    completedRun.completedAt = new Date(Date.now() - 30000).toISOString();
    completedRun.duration = 15000;
    completedRun.currentStepIndex = 9;
    completedRun.steps.forEach((step, i) => {
      step.status = "completed";
      step.startedAt = new Date(Date.now() - 45000 + i * 1500).toISOString();
      step.completedAt = new Date(Date.now() - 43500 + i * 1500).toISOString();
      step.duration = 1200 + Math.floor(Math.random() * 600);
      step.screenshotUrl = i === 2 || i === 7 ? `/api/screenshots/step-${i}.png` : null;
      step.domSnapshot = i % 3 === 0 ? `<html><body>Step ${i} snapshot</body></html>` : null;
      step.result = i === 8 ? "Welcome, testuser!" : null;
    });
    completedRun.artifacts = [
      { id: generateId(), runId: completedRun.id, type: "screenshot", name: "login-page.png", url: "/api/screenshots/step-2.png", size: 45200, createdAt: now() },
      { id: generateId(), runId: completedRun.id, type: "screenshot", name: "post-login.png", url: "/api/screenshots/step-7.png", size: 52100, createdAt: now() },
      { id: generateId(), runId: completedRun.id, type: "extracted-data", name: "extraction-results.json", url: "/api/extractions/run-1.json", size: 1240, createdAt: now() },
    ];
    completedRun.extractedData = { welcomeText: "Welcome, testuser!", userAvatar: "/avatars/testuser.png" };
  }

  const failedRun = createRun(task2.id);
  if (failedRun) {
    failedRun.status = "failed";
    failedRun.startedAt = new Date(Date.now() - 20000).toISOString();
    failedRun.completedAt = new Date(Date.now() - 12000).toISOString();
    failedRun.duration = 8000;
    failedRun.currentStepIndex = 4;
    failedRun.retryCount = 3;
    failedRun.error = "Timeout waiting for selector '.product-list' after 5000ms";
    failedRun.steps.forEach((step, i) => {
      if (i < 3) {
        step.status = "completed";
        step.startedAt = new Date(Date.now() - 20000 + i * 2000).toISOString();
        step.completedAt = new Date(Date.now() - 18000 + i * 2000).toISOString();
        step.duration = 1500 + Math.floor(Math.random() * 800);
        step.screenshotUrl = i === 2 ? `/api/screenshots/failed-step-${i}.png` : null;
      } else if (i === 3) {
        step.status = "failed";
        step.error = "Element not found: scroll container";
        step.retryCount = 3;
        step.startedAt = new Date(Date.now() - 14000).toISOString();
        step.completedAt = new Date(Date.now() - 12000).toISOString();
        step.duration = 2000;
      }
    });
    failedRun.artifacts = [
      { id: generateId(), runId: failedRun.id, type: "screenshot", name: "product-listing.png", url: "/api/screenshots/failed-step-2.png", size: 38900, createdAt: now() },
      { id: generateId(), runId: failedRun.id, type: "log", name: "error.log", url: "/api/logs/failed-run.log", size: 2048, createdAt: now() },
    ];
  }

  const runningRun = createRun(task3.id);
  if (runningRun) {
    runningRun.status = "running";
    runningRun.startedAt = new Date(Date.now() - 8000).toISOString();
    runningRun.currentStepIndex = 4;
    runningRun.steps.forEach((step, i) => {
      if (i < 4) {
        step.status = "completed";
        step.startedAt = new Date(Date.now() - 8000 + i * 1800).toISOString();
        step.completedAt = new Date(Date.now() - 6200 + i * 1800).toISOString();
        step.duration = 1400 + Math.floor(Math.random() * 700);
      } else if (i === 4) {
        step.status = "running";
        step.startedAt = new Date(Date.now() - 800).toISOString();
      }
    });
  }
}

seedData();
