import {
  TaskDefinition,
  Run,
  RunStatus,
  BrowserSession,
  WorkerNode,
  StepSnapshot,
  DashboardStats,
} from "./types";

const tasks: Map<string, TaskDefinition> = new Map();
const runs: Map<string, Run> = new Map();
const sessions: Map<string, BrowserSession> = new Map();
const workers: Map<string, WorkerNode> = new Map();

function generateId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
}

function seed() {
  const task1: TaskDefinition = {
    id: "task-001",
    name: "Scrape Product Prices",
    description: "Navigate to an e-commerce category page, paginate through results, and extract product names, prices, and ratings.",
    url: "https://example-shop.com/electronics",
    actions: [
      { id: "a1", type: "navigate", url: "https://example-shop.com/electronics", retries: 0, maxRetries: 2 },
      { id: "a2", type: "wait", selector: ".product-grid", waitMs: 2000, retries: 0, maxRetries: 2 },
      { id: "a3", type: "screenshot", retries: 0, maxRetries: 1 },
      { id: "a4", type: "extract", extractSelector: ".product-card", extractAttribute: "data-json", retries: 0, maxRetries: 3 },
      { id: "a5", type: "click", selector: ".pagination-next", retries: 0, maxRetries: 2 },
      { id: "a6", type: "wait", selector: ".product-grid", waitMs: 1500, retries: 0, maxRetries: 2 },
      { id: "a7", type: "screenshot", retries: 0, maxRetries: 1 },
    ],
    extractionPipeline: {
      id: "ep-1",
      name: "Product Data",
      fields: [
        { name: "title", selector: ".product-title", attribute: "text", transform: "text" },
        { name: "price", selector: ".product-price", attribute: "data-price", transform: "text" },
        { name: "rating", selector: ".star-rating", attribute: "aria-label", transform: "text" },
        { name: "image", selector: ".product-image img", attribute: "src", transform: "src" },
      ],
      paginationSelector: ".pagination-next:not(.disabled)",
      maxPages: 5,
    },
    maxRetries: 3,
    retryDelayMs: 5000,
    timeoutMs: 120000,
    status: "active",
    createdAt: "2025-12-01T10:00:00Z",
    updatedAt: "2025-12-03T14:30:00Z",
    tags: ["scraping", "e-commerce", "prices"],
  };

  const task2: TaskDefinition = {
    id: "task-002",
    name: "Login and Download Report",
    description: "Log into a dashboard, navigate to the reports section, select date range, and download the CSV export.",
    url: "https://portal.example.com/login",
    actions: [
      { id: "b1", type: "navigate", url: "https://portal.example.com/login", retries: 0, maxRetries: 2 },
      { id: "b2", type: "type", selector: "#username", value: "agent@company.com", retries: 0, maxRetries: 1 },
      { id: "b3", type: "type", selector: "#password", value: "****", retries: 0, maxRetries: 1 },
      { id: "b4", type: "click", selector: "button[type=submit]", retries: 0, maxRetries: 2 },
      { id: "b5", type: "wait", selector: ".dashboard", waitMs: 3000, retries: 0, maxRetries: 3 },
      { id: "b6", type: "click", selector: "nav a[href='/reports']", retries: 0, maxRetries: 2 },
      { id: "b7", type: "wait", selector: ".report-filters", waitMs: 1000, retries: 0, maxRetries: 2 },
      { id: "b8", type: "screenshot", retries: 0, maxRetries: 1 },
      { id: "b9", type: "click", selector: "#download-csv", retries: 0, maxRetries: 2 },
    ],
    maxRetries: 2,
    retryDelayMs: 3000,
    timeoutMs: 60000,
    status: "active",
    createdAt: "2025-12-02T08:00:00Z",
    updatedAt: "2025-12-03T09:15:00Z",
    tags: ["automation", "reports", "download"],
  };

  const task3: TaskDefinition = {
    id: "task-003",
    name: "Monitor Competitor Site",
    description: "Visit competitor landing pages, capture full-page screenshots, and extract key metrics from their pricing tables.",
    url: "https://competitor.io/pricing",
    actions: [
      { id: "c1", type: "navigate", url: "https://competitor.io/pricing", retries: 0, maxRetries: 3 },
      { id: "c2", type: "wait", selector: ".pricing-table", waitMs: 2000, retries: 0, maxRetries: 2 },
      { id: "c3", type: "screenshot", retries: 0, maxRetries: 1 },
      { id: "c4", type: "extract", extractSelector: ".pricing-tier", extractAttribute: "innerHTML", retries: 0, maxRetries: 2 },
      { id: "c5", type: "scroll", selector: "footer", waitMs: 500, retries: 0, maxRetries: 1 },
      { id: "c6", type: "screenshot", retries: 0, maxRetries: 1 },
    ],
    maxRetries: 3,
    retryDelayMs: 10000,
    timeoutMs: 90000,
    status: "active",
    createdAt: "2025-12-01T15:00:00Z",
    updatedAt: "2025-12-02T11:00:00Z",
    tags: ["monitoring", "competitor", "pricing"],
  };

  const task4: TaskDefinition = {
    id: "task-004",
    name: "Form Submission Bot",
    description: "Fill out a multi-step form with predefined data, submit, and verify confirmation page.",
    url: "https://forms.example.com/apply",
    actions: [
      { id: "d1", type: "navigate", url: "https://forms.example.com/apply", retries: 0, maxRetries: 2 },
      { id: "d2", type: "wait", selector: "form", waitMs: 1000, retries: 0, maxRetries: 2 },
      { id: "d3", type: "type", selector: "#fullname", value: "Jane Doe", retries: 0, maxRetries: 1 },
      { id: "d4", type: "type", selector: "#email", value: "jane@example.com", retries: 0, maxRetries: 1 },
      { id: "d5", type: "click", selector: ".next-step", retries: 0, maxRetries: 2 },
      { id: "d6", type: "type", selector: "#company", value: "Acme Inc", retries: 0, maxRetries: 1 },
      { id: "d7", type: "click", selector: "button[type=submit]", retries: 0, maxRetries: 2 },
      { id: "d8", type: "wait", selector: ".confirmation", waitMs: 2000, retries: 0, maxRetries: 3 },
      { id: "d9", type: "screenshot", retries: 0, maxRetries: 1 },
    ],
    maxRetries: 1,
    retryDelayMs: 2000,
    timeoutMs: 45000,
    status: "paused",
    createdAt: "2025-12-03T12:00:00Z",
    updatedAt: "2025-12-03T12:00:00Z",
    tags: ["forms", "submission", "testing"],
  };

  tasks.set(task1.id, task1);
  tasks.set(task2.id, task2);
  tasks.set(task3.id, task3);
  tasks.set(task4.id, task4);

  const makeSteps = (taskId: string, count: number, hasError: boolean): StepSnapshot[] => {
    const actionMap: Record<string, { type: string; selector?: string; url?: string }> = {
      "task-001": { type: "navigate", url: "https://example-shop.com/electronics" },
      "task-002": { type: "navigate", url: "https://portal.example.com/login" },
      "task-003": { type: "navigate", url: "https://competitor.io/pricing" },
      "task-004": { type: "navigate", url: "https://forms.example.com/apply" },
    };
    return Array.from({ length: count }, (_, i) => ({
      stepIndex: i,
      action: {
        id: `step-${i}`,
        type: (i === 0 ? "navigate" : i % 3 === 0 ? "screenshot" : i % 3 === 1 ? "click" : "type") as StepSnapshot["action"]["type"],
        selector: i > 0 ? `#element-${i}` : undefined,
        url: i === 0 ? actionMap[taskId]?.url : undefined,
        retries: 0,
        maxRetries: 2,
      },
      screenshotUrl: `/screenshots/run-placeholder/step-${i}.png`,
      domSnapshot: `<html><body><div>Step ${i} DOM snapshot for task ${taskId}</div></body></html>`,
      url: actionMap[taskId]?.url || "https://example.com",
      title: `Step ${i} - Browser Automation`,
      timestamp: new Date(Date.now() - (count - i) * 60000).toISOString(),
      durationMs: Math.floor(Math.random() * 3000) + 200,
      error: hasError && i === count - 1 ? "Element not found: .target-element" : undefined,
      extractedData: i % 3 === 0 ? [{ title: "Sample Item", price: "$29.99" }] : undefined,
    }));
  };

  const run1: Run = {
    id: "run-001",
    taskId: "task-001",
    taskName: "Scrape Product Prices",
    status: "completed",
    steps: makeSteps("task-001", 7, false),
    artifacts: [
      { id: "art-1", name: "page-1.png", type: "screenshot", url: "/artifacts/run-001/page-1.png", sizeBytes: 245000, createdAt: "2025-12-03T14:00:00Z" },
      { id: "art-2", name: "page-2.png", type: "screenshot", url: "/artifacts/run-001/page-2.png", sizeBytes: 312000, createdAt: "2025-12-03T14:00:05Z" },
      { id: "art-3", name: "products.json", type: "extracted_data", url: "/artifacts/run-001/products.json", sizeBytes: 15400, createdAt: "2025-12-03T14:00:10Z" },
    ],
    retryCount: 0,
    maxRetries: 3,
    startedAt: "2025-12-03T14:00:00Z",
    completedAt: "2025-12-03T14:01:15Z",
    durationMs: 75000,
    extractedData: [
      { title: "Widget Pro", price: "$49.99", rating: "4.5/5" },
      { title: "Gadget X", price: "$29.99", rating: "4.2/5" },
      { title: "ToolKit Plus", price: "$89.99", rating: "4.8/5" },
    ],
    workerId: "worker-001",
  };

  const run2: Run = {
    id: "run-002",
    taskId: "task-002",
    taskName: "Login and Download Report",
    status: "completed",
    steps: makeSteps("task-002", 9, false),
    artifacts: [
      { id: "art-4", name: "dashboard.png", type: "screenshot", url: "/artifacts/run-002/dashboard.png", sizeBytes: 445000, createdAt: "2025-12-03T09:00:00Z" },
      { id: "art-5", name: "report.csv", type: "extracted_data", url: "/artifacts/run-002/report.csv", sizeBytes: 102400, createdAt: "2025-12-03T09:00:12Z" },
    ],
    retryCount: 1,
    maxRetries: 2,
    startedAt: "2025-12-03T09:00:00Z",
    completedAt: "2025-12-03T09:01:30Z",
    durationMs: 90000,
    workerId: "worker-002",
  };

  const run3: Run = {
    id: "run-003",
    taskId: "task-003",
    taskName: "Monitor Competitor Site",
    status: "failed",
    steps: makeSteps("task-003", 4, true),
    artifacts: [
      { id: "art-6", name: "error-screenshot.png", type: "screenshot", url: "/artifacts/run-003/error.png", sizeBytes: 198000, createdAt: "2025-12-02T11:00:00Z" },
    ],
    retryCount: 3,
    maxRetries: 3,
    startedAt: "2025-12-02T11:00:00Z",
    completedAt: "2025-12-02T11:03:45Z",
    durationMs: 225000,
    error: "Element not found: .pricing-table after 3 retries. The page structure may have changed.",
    workerId: "worker-001",
  };

  const run4: Run = {
    id: "run-004",
    taskId: "task-001",
    taskName: "Scrape Product Prices",
    status: "running",
    steps: makeSteps("task-001", 3, false),
    artifacts: [],
    retryCount: 0,
    maxRetries: 3,
    startedAt: new Date().toISOString(),
    durationMs: 0,
    workerId: "worker-001",
  };

  const run5: Run = {
    id: "run-005",
    taskId: "task-002",
    taskName: "Login and Download Report",
    status: "queued",
    steps: [],
    artifacts: [],
    retryCount: 0,
    maxRetries: 2,
    startedAt: new Date().toISOString(),
    durationMs: 0,
  };

  const run6: Run = {
    id: "run-006",
    taskId: "task-004",
    taskName: "Form Submission Bot",
    status: "retrying",
    steps: makeSteps("task-004", 5, true),
    artifacts: [
      { id: "art-7", name: "form-step3.png", type: "screenshot", url: "/artifacts/run-006/form-step3.png", sizeBytes: 176000, createdAt: "2025-12-03T12:05:00Z" },
    ],
    retryCount: 1,
    maxRetries: 1,
    startedAt: "2025-12-03T12:05:00Z",
    durationMs: 15000,
    error: "Timeout waiting for element .next-step",
    workerId: "worker-002",
  };

  runs.set(run1.id, run1);
  runs.set(run2.id, run2);
  runs.set(run3.id, run3);
  runs.set(run4.id, run4);
  runs.set(run5.id, run5);
  runs.set(run6.id, run6);

  const session1: BrowserSession = {
    id: "sess-001",
    workerId: "worker-001",
    status: "active",
    currentUrl: "https://example-shop.com/electronics?page=3",
    title: "Electronics - Example Shop",
    viewport: { width: 1920, height: 1080 },
    userAgent: "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0",
    activeRunId: "run-004",
    lastActivityAt: new Date().toISOString(),
    createdAt: "2025-12-03T14:00:00Z",
    screenshotCount: 5,
    domSnapshotCount: 5,
  };

  const session2: BrowserSession = {
    id: "sess-002",
    workerId: "worker-002",
    status: "idle",
    currentUrl: "about:blank",
    title: "New Tab",
    viewport: { width: 1366, height: 768 },
    userAgent: "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0",
    lastActivityAt: new Date(Date.now() - 300000).toISOString(),
    createdAt: "2025-12-03T09:00:00Z",
    screenshotCount: 12,
    domSnapshotCount: 12,
  };

  const session3: BrowserSession = {
    id: "sess-003",
    workerId: "worker-001",
    status: "closed",
    currentUrl: "https://competitor.io/pricing",
    title: "Competitor Pricing",
    viewport: { width: 1920, height: 1080 },
    userAgent: "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0",
    lastActivityAt: "2025-12-02T11:03:45Z",
    createdAt: "2025-12-02T11:00:00Z",
    screenshotCount: 4,
    domSnapshotCount: 4,
  };

  sessions.set(session1.id, session1);
  sessions.set(session2.id, session2);
  sessions.set(session3.id, session3);

  const worker1: WorkerNode = {
    id: "worker-001",
    name: "chrome-worker-01",
    status: "busy",
    currentRunId: "run-004",
    completedRuns: 47,
    failedRuns: 3,
    uptimeSeconds: 864000,
    lastHeartbeat: new Date().toISOString(),
  };

  const worker2: WorkerNode = {
    id: "worker-002",
    name: "chrome-worker-02",
    status: "online",
    completedRuns: 31,
    failedRuns: 2,
    uptimeSeconds: 432000,
    lastHeartbeat: new Date(Date.now() - 10000).toISOString(),
  };

  workers.set(worker1.id, worker1);
  workers.set(worker2.id, worker2);
}

seed();

export function getAllTasks(): TaskDefinition[] {
  return Array.from(tasks.values()).sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
}

export function getTask(id: string): TaskDefinition | undefined {
  return tasks.get(id);
}

export function createTask(data: Omit<TaskDefinition, "id" | "createdAt" | "updatedAt">): TaskDefinition {
  const task: TaskDefinition = { ...data, id: `task-${generateId()}`, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
  tasks.set(task.id, task);
  return task;
}

export function updateTask(id: string, data: Partial<TaskDefinition>): TaskDefinition | undefined {
  const task = tasks.get(id);
  if (!task) return undefined;
  const updated = { ...task, ...data, id: task.id, updatedAt: new Date().toISOString() };
  tasks.set(id, updated);
  return updated;
}

export function deleteTask(id: string): boolean {
  return tasks.delete(id);
}

export function getAllRuns(): Run[] {
  return Array.from(runs.values()).sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime());
}

export function getRunsForTask(taskId: string): Run[] {
  return getAllRuns().filter((r) => r.taskId === taskId);
}

export function getRun(id: string): Run | undefined {
  return runs.get(id);
}

export function createRun(taskId: string): Run | undefined {
  const task = tasks.get(taskId);
  if (!task) return undefined;
  const run: Run = {
    id: `run-${generateId()}`,
    taskId,
    taskName: task.name,
    status: "queued",
    steps: [],
    artifacts: [],
    retryCount: 0,
    maxRetries: task.maxRetries,
    startedAt: new Date().toISOString(),
    durationMs: 0,
  };
  runs.set(run.id, run);
  assignRunToWorker(run.id);
  return run;
}

export function updateRun(id: string, data: Partial<Run>): Run | undefined {
  const run = runs.get(id);
  if (!run) return undefined;
  const updated = { ...run, ...data, id: run.id };
  runs.set(id, updated);
  return updated;
}

function assignRunToWorker(runId: string): void {
  const worker = Array.from(workers.values()).find((w) => w.status === "online");
  if (worker) {
    worker.status = "busy";
    worker.currentRunId = runId;
    const run = runs.get(runId);
    if (run) {
      run.status = "running";
      run.workerId = worker.id;
      run.startedAt = new Date().toISOString();
    }
  }
}

export function retryRun(id: string): Run | undefined {
  const run = runs.get(id);
  if (!run) return undefined;
  const updated: Run = { ...run, status: "retrying", retryCount: run.retryCount + 1, steps: [], artifacts: [], error: undefined };
  runs.set(id, updated);
  assignRunToWorker(id);
  return runs.get(id);
}

export function cancelRun(id: string): Run | undefined {
  const run = runs.get(id);
  if (!run) return undefined;
  const updated: Run = { ...run, status: "failed", error: "Cancelled by user", completedAt: new Date().toISOString() };
  runs.set(id, updated);
  if (run.workerId) {
    const w = workers.get(run.workerId);
    if (w) { w.status = "online"; w.currentRunId = undefined; }
  }
  return updated;
}

export function getAllSessions(): BrowserSession[] {
  return Array.from(sessions.values()).sort((a, b) => new Date(b.lastActivityAt).getTime() - new Date(a.lastActivityAt).getTime());
}

export function getSession(id: string): BrowserSession | undefined {
  return sessions.get(id);
}

export function closeSession(id: string): BrowserSession | undefined {
  const session = sessions.get(id);
  if (!session) return undefined;
  const updated = { ...session, status: "closed" as const, lastActivityAt: new Date().toISOString() };
  sessions.set(id, updated);
  return updated;
}

export function getAllWorkers(): WorkerNode[] {
  return Array.from(workers.values());
}

export function getWorker(id: string): WorkerNode | undefined {
  return workers.get(id);
}

export function getDashboardStats(): DashboardStats {
  const allTasks = getAllTasks();
  const allRuns = getAllRuns();
  const allSessions = getAllSessions();
  const allWorkers = getAllWorkers();
  const completedRuns = allRuns.filter((r) => r.status === "completed");
  const totalDuration = completedRuns.reduce((sum, r) => sum + r.durationMs, 0);
  return {
    totalTasks: allTasks.length,
    activeTasks: allTasks.filter((t) => t.status === "active").length,
    totalRuns: allRuns.length,
    completedRuns: completedRuns.length,
    failedRuns: allRuns.filter((r) => r.status === "failed").length,
    queuedRuns: allRuns.filter((r) => r.status === "queued").length,
    activeSessions: allSessions.filter((s) => s.status === "active").length,
    onlineWorkers: allWorkers.filter((w) => w.status !== "offline").length,
    avgRunDurationMs: completedRuns.length > 0 ? Math.round(totalDuration / completedRuns.length) : 0,
    successRate: allRuns.length > 0 ? Math.round((completedRuns.length / allRuns.length) * 100) : 0,
  };
}
