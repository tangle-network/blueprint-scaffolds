export type TaskStatus = "active" | "paused" | "archived";
export type RunStatus = "queued" | "running" | "completed" | "failed" | "retrying";
export type SessionStatus = "active" | "idle" | "closed";
export type ActionType = "navigate" | "click" | "type" | "scroll" | "wait" | "screenshot" | "extract" | "evaluate";

export interface TaskAction {
  id: string;
  type: ActionType;
  selector?: string;
  value?: string;
  url?: string;
  waitMs?: number;
  extractSelector?: string;
  extractAttribute?: string;
  script?: string;
  retries: number;
  maxRetries: number;
}

export interface ExtractionField {
  name: string;
  selector: string;
  attribute: string;
  transform?: "text" | "html" | "attr" | "href" | "src";
}

export interface ExtractionPipeline {
  id: string;
  name: string;
  fields: ExtractionField[];
  paginationSelector?: string;
  maxPages: number;
}

export interface TaskDefinition {
  id: string;
  name: string;
  description: string;
  url: string;
  actions: TaskAction[];
  extractionPipeline?: ExtractionPipeline;
  maxRetries: number;
  retryDelayMs: number;
  timeoutMs: number;
  status: TaskStatus;
  createdAt: string;
  updatedAt: string;
  tags: string[];
}

export interface StepSnapshot {
  stepIndex: number;
  action: TaskAction;
  screenshotUrl: string;
  domSnapshot: string;
  url: string;
  title: string;
  timestamp: string;
  durationMs: number;
  error?: string;
  extractedData?: Record<string, string>[];
}

export interface RunArtifact {
  id: string;
  name: string;
  type: "screenshot" | "dom" | "extracted_data" | "har" | "console_log";
  url: string;
  sizeBytes: number;
  createdAt: string;
}

export interface Run {
  id: string;
  taskId: string;
  taskName: string;
  status: RunStatus;
  steps: StepSnapshot[];
  artifacts: RunArtifact[];
  retryCount: number;
  maxRetries: number;
  startedAt: string;
  completedAt?: string;
  durationMs: number;
  error?: string;
  extractedData?: Record<string, string>[];
  workerId?: string;
}

export interface BrowserSession {
  id: string;
  workerId: string;
  status: SessionStatus;
  currentUrl: string;
  title: string;
  viewport: { width: number; height: number };
  userAgent: string;
  activeRunId?: string;
  lastActivityAt: string;
  createdAt: string;
  screenshotCount: number;
  domSnapshotCount: number;
}

export interface WorkerNode {
  id: string;
  name: string;
  status: "online" | "offline" | "busy";
  currentRunId?: string;
  completedRuns: number;
  failedRuns: number;
  uptimeSeconds: number;
  lastHeartbeat: string;
}

export interface DashboardStats {
  totalTasks: number;
  activeTasks: number;
  totalRuns: number;
  completedRuns: number;
  failedRuns: number;
  queuedRuns: number;
  activeSessions: number;
  onlineWorkers: number;
  avgRunDurationMs: number;
  successRate: number;
}
