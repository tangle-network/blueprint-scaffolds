export type TaskStatus = "active" | "paused" | "archived";
export type RunStatus = "queued" | "running" | "completed" | "failed" | "retrying";
export type StepStatus = "pending" | "running" | "completed" | "failed" | "skipped";
export type ActionType = "navigate" | "click" | "type" | "scroll" | "wait" | "extract" | "screenshot" | "evaluate" | "select" | "hover";

export interface BrowserAction {
  id: string;
  type: ActionType;
  label: string;
  selector?: string;
  value?: string;
  url?: string;
  timeout?: number;
  retries?: number;
}

export interface ExtractionPipeline {
  id: string;
  name: string;
  selector: string;
  attribute?: string;
  transform?: "text" | "html" | "attr" | "href" | "src";
}

export interface TaskDefinition {
  id: string;
  name: string;
  description: string;
  url: string;
  actions: BrowserAction[];
  extractions: ExtractionPipeline[];
  maxRetries: number;
  retryDelay: number;
  screenshotInterval: number;
  domSnapshotEnabled: boolean;
  status: TaskStatus;
  createdAt: string;
  updatedAt: string;
}

export interface Step {
  id: string;
  runId: string;
  actionIndex: number;
  action: BrowserAction;
  status: StepStatus;
  screenshotUrl: string | null;
  domSnapshot: string | null;
  result: string | null;
  error: string | null;
  startedAt: string | null;
  completedAt: string | null;
  retryCount: number;
  duration: number | null;
}

export interface Artifact {
  id: string;
  runId: string;
  type: "screenshot" | "dom-snapshot" | "extracted-data" | "log";
  name: string;
  url: string;
  size: number;
  createdAt: string;
}

export interface Run {
  id: string;
  taskId: string;
  taskName: string;
  status: RunStatus;
  steps: Step[];
  artifacts: Artifact[];
  extractedData: Record<string, unknown> | null;
  currentStepIndex: number;
  totalSteps: number;
  startedAt: string | null;
  completedAt: string | null;
  duration: number | null;
  error: string | null;
  retryCount: number;
  createdAt: string;
}

export interface WorkerQueueItem {
  runId: string;
  taskId: string;
  priority: number;
  addedAt: string;
}
