# AGENTS.md

Build a browser automation agent platform for running repeatable web tasks. Task definition, browser control, result extraction.

## What's here

This project was scaffolded by starter-foundry. The user's prompt drove the choices below — read their prompt first, it takes priority over everything in this file.

- **Family:** `agent-service-ts`
- **Layers:** `framework:agent-service-ts`, `capability:agent-browser`, `database:sqlite`, `sdk:none`, `auth:none`, `payments:none`, `queue:none`

### Architecture notes
- Agent control loop: plan → act → reflect
- Tool registration
- Memory/state management
- HTTP health endpoint
- Use Playwright for reliable cross-browser automation.
- Capture DOM snapshots (simplified HTML) for the LLM context, not raw HTML.
- Record actions for replay and debugging.
- Take screenshots at key decision points for vision model feedback.

## Getting started

```bash
node agent.mjs
```

Key files: `agent.mjs`, `agent.config.json`

## Suggested build plan

These are starting points — adapt them to the user's actual needs.

- **Components:** BrowserSession, ActionRecorder, DOMSnapshot
- **Data models:** BrowserAction, PageState, Screenshot
- **Integrations:** Playwright, CDP (Chrome DevTools Protocol), Vision model for screenshots

## How to use this scaffold

This is a starting point, not a contract. You own every file.

- **Customize freely.** Replace components, change the layout, swap the color scheme — whatever fits the user's product.
- **The scaffold saves you setup time** — Tailwind, shadcn/ui, path aliases, and framework config are ready. Don't redo them.
- **Check `.starter-foundry/compose-report.json`** if you want to see which layer wrote which file.
- **Update this file** as the project evolves. Delete sections that no longer apply.
