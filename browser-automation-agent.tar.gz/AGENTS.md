# AGENTS.md

## Goal

Build a browser automation agent platform for running repeatable web tasks. Task definition, browser control, result extraction.

## Stack

- Family: `agent-service-ts`
- Layers: `capability:agent-browser`, `database:sqlite`, `sdk:none`, `auth:none`, `payments:none`, `queue:none`

## Architecture

- Agent control loop: plan → act → reflect
- Tool registration
- Memory/state management
- HTTP health endpoint
- Use Playwright for reliable cross-browser automation.
- Capture DOM snapshots (simplified HTML) for the LLM context, not raw HTML.
- Record actions for replay and debugging.
- Take screenshots at key decision points for vision model feedback.

## Entry Points

- `agent.mjs`
- `agent.config.json`

## Commands

- `node agent.mjs`

## Build Plan

Components: BrowserSession, ActionRecorder, DOMSnapshot
Data models: BrowserAction, PageState, Screenshot
Integrations: Playwright, CDP (Chrome DevTools Protocol), Vision model for screenshots

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
