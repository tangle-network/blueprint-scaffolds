pragma circom 2.1.8;

include "../node_modules/circomlib/circuits/poseidon.circom";

template SelectiveDisclosure() {
    signal input nullifierHash;
    signal input commitment;
    signal input jurisdiction;
    signal input travelRuleRef;
    signal input auditorKey;

    signal output complianceDigest;

    component disclosureHasher = Poseidon(5);
    disclosureHasher.inputs[0] <== nullifierHash;
    disclosureHasher.inputs[1] <== commitment;
    disclosureHasher.inputs[2] <== jurisdiction;
    disclosureHasher.inputs[3] <== travelRuleRef;
    disclosureHasher.inputs[4] <== auditorKey;
    complianceDigest <== disclosureHasher.out;
}

component main {public [nullifierHash, commitment, complianceDigest]} = SelectiveDisclosure();
