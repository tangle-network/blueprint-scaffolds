pragma circom 2.1.8;

include "../node_modules/circomlib/circuits/comparators.circom";
include "./poseidon_commitment.circom";

template ShieldedPool() {
    signal input root;
    signal input nullifier;
    signal input secret;
    signal input amount;
    signal input recipient;
    signal input chainDomain;
    signal input expectedCommitment;
    signal input expectedNullifierHash;

    signal output commitment;
    signal output nullifierHash;

    component note = PoseidonCommitment();
    note.secret <== secret;
    note.nullifier <== nullifier;
    note.amount <== amount;
    note.chainDomain <== chainDomain;

    commitment <== note.commitment;
    nullifierHash <== note.nullifierHash;

    component commitmentEq = IsEqual();
    commitmentEq.in[0] <== commitment;
    commitmentEq.in[1] <== expectedCommitment;
    commitmentEq.out === 1;

    component nullifierEq = IsEqual();
    nullifierEq.in[0] <== nullifierHash;
    nullifierEq.in[1] <== expectedNullifierHash;
    nullifierEq.out === 1;

    root === root;
    recipient === recipient;
}

component main {public [root, recipient, chainDomain, expectedCommitment, expectedNullifierHash]} = ShieldedPool();
