pragma circom 2.1.8;

include "../node_modules/circomlib/circuits/poseidon.circom";

template PoseidonCommitment() {
    signal input secret;
    signal input nullifier;
    signal input amount;
    signal input chainDomain;
    signal output commitment;
    signal output nullifierHash;

    component commitmentHasher = Poseidon(4);
    commitmentHasher.inputs[0] <== secret;
    commitmentHasher.inputs[1] <== nullifier;
    commitmentHasher.inputs[2] <== amount;
    commitmentHasher.inputs[3] <== chainDomain;
    commitment <== commitmentHasher.out;

    component nullifierHasher = Poseidon(2);
    nullifierHasher.inputs[0] <== nullifier;
    nullifierHasher.inputs[1] <== chainDomain;
    nullifierHash <== nullifierHasher.out;
}

component main = PoseidonCommitment();
