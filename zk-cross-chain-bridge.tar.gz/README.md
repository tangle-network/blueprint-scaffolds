# ShadowBridge

Privacy-preserving cross-chain bridge demo with:

- Shielded pools backed by Poseidon commitments
- Nullifier hashes for double-spend prevention
- Groth16 proof hooks via `snarkjs`
- Optional selective disclosure witness generation
- Solidity verifier registry and per-chain pool fee model
- Vite + React frontend with local note storage

## Commands

```bash
pnpm install
pnpm build
pnpm dev
```
