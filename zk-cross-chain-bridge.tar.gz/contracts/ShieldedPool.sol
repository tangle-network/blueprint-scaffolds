// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "./BridgeVerifier.sol";

contract ShieldedPool {
    BridgeVerifierRegistry public immutable verifierRegistry;
    mapping(bytes32 => bool) public commitments;
    mapping(bytes32 => bool) public nullifiers;
    mapping(uint256 => uint256) public relayerFeeBps;

    event Deposited(bytes32 indexed commitment, uint256 amount, uint256 indexed chainId);
    event Withdrawn(
        bytes32 indexed nullifierHash,
        address indexed recipient,
        address indexed relayer,
        uint256 payout,
        uint256 relayerFee
    );

    constructor(BridgeVerifierRegistry registry) {
        verifierRegistry = registry;
        relayerFeeBps[1] = 22;
        relayerFeeBps[137] = 12;
        relayerFeeBps[56] = 10;
    }

    function deposit(bytes32 commitment) external payable {
        require(msg.value > 0, "amount=0");
        require(!commitments[commitment], "commitment exists");
        commitments[commitment] = true;
        emit Deposited(commitment, msg.value, block.chainid);
    }

    function withdraw(
        bytes32 nullifierHash,
        address payable recipient,
        address payable relayer,
        bytes calldata encodedProof,
        uint256[] calldata publicSignals
    ) external {
        require(!nullifiers[nullifierHash], "nullifier spent");
        require(verifierRegistry.verifyOn(block.chainid, encodedProof, publicSignals), "invalid proof");

        nullifiers[nullifierHash] = true;

        uint256 fee = (address(this).balance * relayerFeeBps[block.chainid]) / 10_000;
        uint256 payout = address(this).balance - fee;
        if (fee > 0) {
            relayer.transfer(fee);
        }
        recipient.transfer(payout);

        emit Withdrawn(nullifierHash, recipient, relayer, payout, fee);
    }
}
