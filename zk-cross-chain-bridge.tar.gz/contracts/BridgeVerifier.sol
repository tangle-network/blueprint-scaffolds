// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IGroth16Verifier {
    function verifyProof(
        uint256[2] calldata a,
        uint256[2][2] calldata b,
        uint256[2] calldata c,
        uint256[] calldata publicSignals
    ) external view returns (bool);
}

contract BridgeVerifierRegistry {
    mapping(uint256 => IGroth16Verifier) public verifiers;
    address public owner;

    event VerifierConfigured(uint256 indexed chainId, address verifier);

    modifier onlyOwner() {
        require(msg.sender == owner, "not owner");
        _;
    }

    constructor() {
        owner = msg.sender;
    }

    function configureVerifier(uint256 chainId, IGroth16Verifier verifier) external onlyOwner {
        verifiers[chainId] = verifier;
        emit VerifierConfigured(chainId, address(verifier));
    }

    function verifyOn(uint256 chainId, bytes calldata encodedProof, uint256[] calldata publicSignals)
        external
        view
        returns (bool)
    {
        (
            uint256[2] memory a,
            uint256[2][2] memory b,
            uint256[2] memory c
        ) = abi.decode(encodedProof, (uint256[2], uint256[2][2], uint256[2]));
        return verifiers[chainId].verifyProof(a, b, c, publicSignals);
    }
}
