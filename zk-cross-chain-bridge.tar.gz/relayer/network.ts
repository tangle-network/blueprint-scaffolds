export type RelayerNode = {
  id: string;
  ingressChainId: number;
  egressChainId: number;
  feeBps: number;
  complianceMode: "private" | "selective-disclosure";
};

export const relayerNetwork: RelayerNode[] = [
  { id: "us-east-1", ingressChainId: 1, egressChainId: 137, feeBps: 22, complianceMode: "private" },
  { id: "eu-west-1", ingressChainId: 137, egressChainId: 56, feeBps: 12, complianceMode: "selective-disclosure" },
  { id: "ap-sg-1", ingressChainId: 56, egressChainId: 1, feeBps: 10, complianceMode: "private" }
];
