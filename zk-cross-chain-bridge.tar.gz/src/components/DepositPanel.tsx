import { useState } from "react";
import { useStore } from "../store";
import { CHAINS, type ChainId } from "../config/chains";
import { generateDepositNote, serializeNote, bigIntToHex } from "../crypto/poseidon";
import { MerkleTree } from "../crypto/merkle";
import type { DepositNote } from "../crypto/poseidon";

export default function DepositPanel() {
  const { state, dispatch } = useStore();
  const [amount, setAmount] = useState("0.1");
  const [sourceChain, setSourceChain] = useState<ChainId>("ethereum");
  const [note, setNote] = useState<DepositNote | null>(null);
  const [noteStr, setNoteStr] = useState("");
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  async function handleDeposit() {
    dispatch({ type: "SET_ERROR", error: null });
    dispatch({ type: "SET_SUCCESS", success: null });
    dispatch({ type: "SET_GENERATING", value: true });

    try {
      const depositNote = await generateDepositNote(amount, sourceChain);
      const serialized = serializeNote(depositNote);

      const tree = new MerkleTree(20);
      await tree.insert(depositNote.commitment);

      setNote(depositNote);
      setNoteStr(serialized);
      dispatch({ type: "ADD_NOTE", note: depositNote });
      dispatch({
        type: "SET_SUCCESS",
        success: `Deposit commitment generated: ${bigIntToHex(depositNote.commitment).slice(0, 20)}...`,
      });
    } catch (err: any) {
      dispatch({ type: "SET_ERROR", error: err.message || "Failed to generate deposit" });
    } finally {
      dispatch({ type: "SET_GENERATING", value: false });
    }
  }

  function handleCopy() {
    navigator.clipboard.writeText(noteStr);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  function handleSaveNote() {
    const existing = localStorage.getItem("zk-bridge-notes");
    const notes = existing ? JSON.parse(existing) : [];
    notes.push(noteStr);
    localStorage.setItem("zk-bridge-notes", JSON.stringify(notes));
    setSaved(true);
  }

  return (
    <div className="grid-2">
      <div className="card">
        <div className="card-title">
          <span className="icon">&#x1F512;</span> Shielded Deposit
        </div>

        <div className="form-group">
          <label>Source Chain</label>
          <select value={sourceChain} onChange={(e) => setSourceChain(e.target.value as ChainId)}>
            {Object.values(CHAINS).map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label>Amount ({CHAINS[sourceChain].symbol})</label>
          <input
            type="number"
            step="0.01"
            min="0"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="0.1"
          />
        </div>

        <div className="form-group">
          <label>Recipient Address (optional, for compliance)</label>
          <input type="text" placeholder="0x..." />
        </div>

        <button
          className="btn btn-primary"
          onClick={handleDeposit}
          disabled={state.isGenerating || !amount || parseFloat(amount) <= 0}
        >
          {state.isGenerating ? (
            <>
              <span className="spinner" />
              Generating commitment...
            </>
          ) : (
            "Generate Shielded Deposit"
          )}
        </button>

        {state.error && <div className="warning" style={{ marginTop: 16 }}>{state.error}</div>}
        {state.success && <div className="success-box" style={{ marginTop: 16 }}>{state.success}</div>}
      </div>

      <div className="card">
        <div className="card-title">
          <span className="icon">&#x1F4CB;</span> Deposit Note
        </div>

        {noteStr ? (
          <>
            <div className="warning">
              Store this note securely. It is required to withdraw your funds. Losing it means losing access to your deposit.
            </div>

            <div className="note-display">
              {noteStr}
              <button className="copy-btn" onClick={handleCopy}>
                {copied ? "Copied!" : "Copy"}
              </button>
            </div>

            <div style={{ marginTop: 12 }}>
              <strong>Commitment:</strong>{" "}
              <code style={{ fontSize: "0.75rem", color: "var(--accent)" }}>
                {bigIntToHex(note!.commitment)}
              </code>
            </div>
            <div style={{ marginTop: 4 }}>
              <strong>Nullifier Hash:</strong>{" "}
              <code style={{ fontSize: "0.75rem", color: "var(--text-dim)" }}>
                {bigIntToHex(note!.nullifierHash)}
              </code>
            </div>
            <div style={{ marginTop: 4 }}>
              <strong>Amount:</strong> {note!.amount} {CHAINS[note!.chain as ChainId]?.symbol}
            </div>
            <div style={{ marginTop: 4 }}>
              <strong>Chain:</strong> {CHAINS[note!.chain as ChainId]?.name}
            </div>

            <button
              className="btn btn-accent"
              style={{ marginTop: 16 }}
              onClick={handleSaveNote}
              disabled={saved}
            >
              {saved ? "Note Saved to Local Storage" : "Save Note"}
            </button>
          </>
        ) : (
          <div style={{ color: "var(--text-dim)", textAlign: "center", padding: 40 }}>
            Generate a deposit to see your private note here.
          </div>
        )}
      </div>
    </div>
  );
}
