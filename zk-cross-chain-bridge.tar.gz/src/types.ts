export type ChainId = "ethereum" | "polygon" | "bsc";

export type PoolNote = {
  id: string;
  chain: ChainId;
  amount: string;
  commitment: string;
  nullifierHash: string;
  secret: string;
  nullifier: string;
  recipientHint: string;
  createdAt: string;
  selectiveDisclosure: {
    jurisdiction: string;
    travelRuleRef: string;
    auditorKey: string;
  };
};

export type WitnessPackage = {
  circuit: "shielded_pool" | "selective_disclosure";
  input: Record<string, string | string[]>;
  manifestCheckedAt: string;
};

export type RelayerQuote = {
  chain: ChainId;
  feeBps: number;
  gasToken: string;
  eta: string;
};

export type ProofResult =
  | {
      ok: true;
      proof: unknown;
      publicSignals: string[];
    }
  | {
      ok: false;
      reason: string;
    };
