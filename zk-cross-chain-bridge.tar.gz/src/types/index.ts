export enum ChainId {
  Ethereum = 1,
  BSC = 56,
  Polygon = 137,
}

export interface Token {
  symbol: string
  name: string
  address: Partial<Record<ChainId, string>>
  decimals: number
  icon: string
}

export interface ShieldedPool {
  poolId: string
  token: Token
  merkleRoot: string
  depth: number
  size: number
  chainId: ChainId
  tvl: number
}

export interface Commitment {
  hash: string
  leafIndex: number
  timestamp: number
  poolId: string
  amount: number
}

export interface Nullifier {
  nullifierHash: string
  spent: boolean
  spentTxHash?: string
  spentTimestamp?: number
}

export interface DepositNote {
  id: string
  poolId: string
  amount: number
  secret: string
  nullifier: string
  commitment: string
  nullifierHash: string
  createdAt: number
  chainId: ChainId
  token: Token
  withdrawn: boolean
  withdrawnChainId?: ChainId
}

export interface BridgeTransaction {
  id: string
  type: "deposit" | "withdraw" | "bridge"
  fromChain: ChainId
  toChain: ChainId
  amount: number
  token: Token
  status: "pending" | "confirmed" | "failed" | "proving" | "relaying"
  txHash: string
  proof?: string
  nullifierHash?: string
  commitment?: string
  timestamp: number
  relayerFee: number
}

export interface RelayerInfo {
  url: string
  chainIds: ChainId[]
  feePct: number
  reputation: number
  address: string
}

export interface SelectiveDisclosure {
  nullifierHash: string
  revealedAmount: boolean
  revealedToken: boolean
  verifierSignature: string
  timestamp: number
}

export const CHAIN_NAMES: Record<ChainId, string> = {
  [ChainId.Ethereum]: "Ethereum",
  [ChainId.BSC]: "BSC",
  [ChainId.Polygon]: "Polygon",
}

export const CHAIN_ICONS: Record<ChainId, string> = {
  [ChainId.Ethereum]: "⟠",
  [ChainId.BSC]: "◆",
  [ChainId.Polygon]: "⬡",
}

export const CHAIN_COLORS: Record<ChainId, string> = {
  [ChainId.Ethereum]: "bg-blue-500",
  [ChainId.BSC]: "bg-yellow-500",
  [ChainId.Polygon]: "bg-purple-500",
}

export const ETH: Token = {
  symbol: "ETH",
  name: "Ether",
  address: {
    [ChainId.Ethereum]: "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE",
  },
  decimals: 18,
  icon: "⟠",
}

export const WETH: Token = {
  symbol: "WETH",
  name: "Wrapped Ether",
  address: {
    [ChainId.Ethereum]: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",
    [ChainId.Polygon]: "0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619",
    [ChainId.BSC]: "0x2170Ed0880ac9A755fd29B2688956BD959F933F8",
  },
  decimals: 18,
  icon: "⟠",
}

export const USDC: Token = {
  symbol: "USDC",
  name: "USD Coin",
  address: {
    [ChainId.Ethereum]: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
    [ChainId.Polygon]: "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174",
    [ChainId.BSC]: "0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d",
  },
  decimals: 6,
  icon: "$",
}

export const WBNB: Token = {
  symbol: "WBNB",
  name: "Wrapped BNB",
  address: {
    [ChainId.BSC]: "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c",
    [ChainId.Ethereum]: "0xB8c77482e45F1F44dE1745F52C74426C631bDD52",
  },
  decimals: 18,
  icon: "◆",
}

export const MATIC: Token = {
  symbol: "MATIC",
  name: "Polygon",
  address: {
    [ChainId.Polygon]: "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE",
    [ChainId.Ethereum]: "0x7D1AfA7B718fb893dB30A3aBc0Cfc608AaCfeBB0",
    [ChainId.BSC]: "0xCC42724C6683B7E57334c4E856f4c9965ED682bD",
  },
  decimals: 18,
  icon: "⬡",
}

export const TOKEN_PRESETS = [ETH, WETH, USDC, WBNB, MATIC]
