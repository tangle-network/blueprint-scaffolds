export type ChainId = "ethereum" | "polygon" | "bsc";

export interface ChainConfig {
  id: ChainId;
  name: string;
  symbol: string;
  color: string;
  explorerUrl: string;
  bridgeAddress: string;
}

export const CHAINS: Record<ChainId, ChainConfig> = {
  ethereum: {
    id: "ethereum",
    name: "Ethereum",
    symbol: "ETH",
    color: "#627eea",
    explorerUrl: "https://etherscan.io",
    bridgeAddress: "0x0000000000000000000000000000000000000001",
  },
  polygon: {
    id: "polygon",
    name: "Polygon",
    symbol: "MATIC",
    color: "#8247e5",
    explorerUrl: "https://polygonscan.com",
    bridgeAddress: "0x0000000000000000000000000000000000000002",
  },
  bsc: {
    id: "bsc",
    name: "BSC",
    symbol: "BNB",
    color: "#f3ba2f",
    explorerUrl: "https://bscscan.com",
    bridgeAddress: "0x0000000000000000000000000000000000000003",
  },
};
