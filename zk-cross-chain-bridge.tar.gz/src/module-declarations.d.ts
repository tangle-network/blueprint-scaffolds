declare module "circomlibjs" {
  export function buildPoseidon(): Promise<{
    (inputs: bigint[]): unknown;
    F: {
      toString(value: unknown, radix: number): string;
    };
  }>;
}

declare module "snarkjs" {
  export const groth16: {
    fullProve: (
      input: Record<string, string | string[]>,
      wasmPath: string,
      zkeyPath: string
    ) => Promise<{ proof: unknown; publicSignals: string[] }>;
  };
}
