import { create } from "zustand"
import {
  type ShieldedPool,
  type DepositNote,
  type BridgeTransaction,
  type RelayerInfo,
  type Token,
  ChainId,
  ETH,
  USDC,
  WBNB,
} from "@/types"
import { generateMockHex } from "@/lib/utils"

interface BridgeState {
  pools: ShieldedPool[]
  notes: DepositNote[]
  transactions: BridgeTransaction[]
  relayers: RelayerInfo[]
  selectedPool: ShieldedPool | null
  selectedFromChain: ChainId
  selectedToChain: ChainId
  depositAmount: string
  withdrawNoteId: string | null
  isDepositing: boolean
  isWithdrawing: boolean
  isBridging: boolean
  darkMode: boolean

  selectPool: (pool: ShieldedPool) => void
  setFromChain: (chain: ChainId) => void
  setToChain: (chain: ChainId) => void
  setDepositAmount: (amount: string) => void
  setWithdrawNote: (id: string | null) => void
  toggleDarkMode: () => void
  deposit: (amount: number, token: Token, fromChain: ChainId, poolId: string) => Promise<void>
  withdraw: (noteId: string, toChain: ChainId) => Promise<void>
  bridge: (noteId: string, toChain: ChainId) => Promise<void>
  addNote: (note: DepositNote) => void
  removeNote: (id: string) => void
  addTransaction: (tx: BridgeTransaction) => void
  updateTransactionStatus: (id: string, status: BridgeTransaction["status"]) => void
}

const mockPools: ShieldedPool[] = [
  {
    poolId: "pool-eth-mainnet-01",
    token: ETH,
    merkleRoot: "0x4a5b2c3d8e9f1a0b6c7d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2",
    depth: 20,
    size: 15432,
    chainId: ChainId.Ethereum,
    tvl: 4521.87,
  },
  {
    poolId: "pool-usdc-polygon-01",
    token: USDC,
    merkleRoot: "0x7f8e9d0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8",
    depth: 20,
    size: 8291,
    chainId: ChainId.Polygon,
    tvl: 1847320.5,
  },
  {
    poolId: "pool-wbnb-bsc-01",
    token: WBNB,
    merkleRoot: "0x1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2",
    depth: 18,
    size: 4218,
    chainId: ChainId.BSC,
    tvl: 3187.42,
  },
]

const mockNotes: DepositNote[] = [
  {
    id: "note-001",
    poolId: "pool-eth-mainnet-01",
    amount: 1.5,
    secret: "0x3a7f9c2e1b8d4f6a0c5e7b9d1f3a5c8e2b4d6f0a8c1e3b5d7f9a2c4e6b8d0f2",
    nullifier: "0x7b2c4d6e8f0a1c3e5b7d9f1a3c5e7b9d0f2a4c6e8b0d2f4a6c8e0b2d4f6a8c1",
    commitment: "0x1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a",
    nullifierHash: "0xa1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b",
    createdAt: Date.now() - 86400000 * 3,
    chainId: ChainId.Ethereum,
    token: ETH,
    withdrawn: false,
  },
  {
    id: "note-002",
    poolId: "pool-eth-mainnet-01",
    amount: 0.5,
    secret: "0x5e1a9c3f7b2d8a4c0e6f1b3d5a7c9e2f4b6d8a0c2e4f6b8d0a2c4e6f8b0d2a4c",
    nullifier: "0x2d4f6a8c0e2b4d6f8a0c2e4f6a8b0d2c4e6f8a0b2c4e6f8a0b2d4e6f8a0b2d4",
    commitment: "0x3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4",
    nullifierHash: "0xc4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d",
    createdAt: Date.now() - 86400000 * 7,
    chainId: ChainId.Ethereum,
    token: ETH,
    withdrawn: true,
    withdrawnChainId: ChainId.Polygon,
  },
  {
    id: "note-003",
    poolId: "pool-usdc-polygon-01",
    amount: 5000,
    secret: "0x8a2c4e6b0d2f4a6c8e0b2d4f6a8c0e2b4d6f8a0c2e4b6d8f0a2c4e6b8d0f2a4c6e",
    nullifier: "0x4a6c8e0b2d4f6a8c0e2b4d6f8a0c2e4f6a8b0d2c4e6f8a0b2d4e6f8a0b2d4e6",
    commitment: "0x5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6",
    nullifierHash: "0xd5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6",
    createdAt: Date.now() - 86400000 * 1,
    chainId: ChainId.Polygon,
    token: USDC,
    withdrawn: false,
  },
  {
    id: "note-004",
    poolId: "pool-wbnb-bsc-01",
    amount: 2.0,
    secret: "0xb1d3f5a7c9e1b3d5f7a9c1e3b5d7f9a1c3e5b7d9f1a3c5e7b9d1f3a5c7e9b1d3",
    nullifier: "0x6c8e0b2d4f6a8c0e2b4d6f8a0c2e4f6a8b0d2c4e6f8a0b2d4e6f8a0b2d4e6f8",
    commitment: "0x7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8",
    nullifierHash: "0xe6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7",
    createdAt: Date.now() - 86400000 * 12,
    chainId: ChainId.BSC,
    token: WBNB,
    withdrawn: true,
    withdrawnChainId: ChainId.Ethereum,
  },
  {
    id: "note-005",
    poolId: "pool-eth-mainnet-01",
    amount: 0.1,
    secret: "0xf2a4c6e8b0d2f4a6c8e0b2d4f6a8c0e2b4d6f8a0c2e4b6d8f0a2c4e6b8d0f2a4c",
    nullifier: "0x8e0b2d4f6a8c0e2b4d6f8a0c2e4f6a8b0d2c4e6f8a0b2d4e6f8a0b2d4e6f8a0",
    commitment: "0x9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0",
    nullifierHash: "0xf7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8",
    createdAt: Date.now() - 86400000 * 0.5,
    chainId: ChainId.Ethereum,
    token: ETH,
    withdrawn: false,
  },
]

const mockTransactions: BridgeTransaction[] = [
  {
    id: "tx-001",
    type: "deposit",
    fromChain: ChainId.Ethereum,
    toChain: ChainId.Ethereum,
    amount: 1.5,
    token: ETH,
    status: "confirmed",
    txHash: "0xabc123def456789012345678901234567890abcdef1234567890abcdef123456",
    commitment: "0x1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a",
    timestamp: Date.now() - 86400000 * 3,
    relayerFee: 0.001,
  },
  {
    id: "tx-002",
    type: "bridge",
    fromChain: ChainId.Ethereum,
    toChain: ChainId.Polygon,
    amount: 0.5,
    token: ETH,
    status: "confirmed",
    txHash: "0xdef789abc012345678901234567890abcdef123456789012345678901234abcd",
    nullifierHash: "0xc4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d",
    proof: "0xproof_a1b2c3d4e5f6",
    timestamp: Date.now() - 86400000 * 7,
    relayerFee: 0.002,
  },
  {
    id: "tx-003",
    type: "deposit",
    fromChain: ChainId.Polygon,
    toChain: ChainId.Polygon,
    amount: 5000,
    token: USDC,
    status: "confirmed",
    txHash: "0x456789abcdef01234567890123456789abcdef0123456789abcdef0123456789",
    timestamp: Date.now() - 86400000,
    relayerFee: 0.5,
  },
  {
    id: "tx-004",
    type: "withdraw",
    fromChain: ChainId.BSC,
    toChain: ChainId.Ethereum,
    amount: 2.0,
    token: WBNB,
    status: "confirmed",
    txHash: "0x789abcdef01234567890123456789abcdef0123456789abcdef0123456789012",
    nullifierHash: "0xe6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7",
    proof: "0xproof_d4e5f6a7b8c9",
    timestamp: Date.now() - 86400000 * 12,
    relayerFee: 0.003,
  },
  {
    id: "tx-005",
    type: "bridge",
    fromChain: ChainId.Ethereum,
    toChain: ChainId.BSC,
    amount: 0.75,
    token: ETH,
    status: "proving",
    txHash: "0xbcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789a",
    timestamp: Date.now() - 120000,
    relayerFee: 0.002,
  },
  {
    id: "tx-006",
    type: "deposit",
    fromChain: ChainId.Ethereum,
    toChain: ChainId.Ethereum,
    amount: 0.1,
    token: ETH,
    status: "confirmed",
    txHash: "0xef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcd",
    timestamp: Date.now() - 43200000,
    relayerFee: 0.001,
  },
  {
    id: "tx-007",
    type: "withdraw",
    fromChain: ChainId.Polygon,
    toChain: ChainId.Ethereum,
    amount: 2500,
    token: USDC,
    status: "relaying",
    txHash: "0x23456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef01",
    nullifierHash: "0xb5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c",
    proof: "0xproof_f6a7b8c9d0e1",
    timestamp: Date.now() - 300000,
    relayerFee: 0.25,
  },
  {
    id: "tx-008",
    type: "bridge",
    fromChain: ChainId.BSC,
    toChain: ChainId.Polygon,
    amount: 1.0,
    token: WBNB,
    status: "failed",
    txHash: "0x6789abcdef0123456789abcdef0123456789abcdef0123456789abcdef012345",
    timestamp: Date.now() - 86400000 * 5,
    relayerFee: 0.004,
  },
]

const mockRelayers: RelayerInfo[] = [
  {
    url: "https://relay.zkbridge.io",
    chainIds: [ChainId.Ethereum, ChainId.Polygon, ChainId.BSC],
    feePct: 0.1,
    reputation: 4.9,
    address: "0x742d35Cc6634C0532925a3b844Bc9e7595f2bD38",
  },
  {
    url: "https://zkp-relayer.example.com",
    chainIds: [ChainId.Ethereum, ChainId.Polygon],
    feePct: 0.15,
    reputation: 4.7,
    address: "0x8Ba1f109551bD432803012645Ac136ddd64DBA72",
  },
  {
    url: "https://privacy-relay.net",
    chainIds: [ChainId.Ethereum, ChainId.BSC],
    feePct: 0.25,
    reputation: 4.5,
    address: "0xdD2FD4581271e230360230F9337D5c0430Bf44C0",
  },
  {
    url: "https://shield-relay.xyz",
    chainIds: [ChainId.Polygon, ChainId.BSC],
    feePct: 0.5,
    reputation: 4.2,
    address: "0x23618e81E3f5cdF7f54C3d65f7FBc0aBf5B21E8f",
  },
]

export const useBridgeStore = create<BridgeState>((set, get) => ({
  pools: mockPools,
  notes: mockNotes,
  transactions: mockTransactions,
  relayers: mockRelayers,
  selectedPool: mockPools[0],
  selectedFromChain: ChainId.Ethereum,
  selectedToChain: ChainId.Polygon,
  depositAmount: "",
  withdrawNoteId: null,
  isDepositing: false,
  isWithdrawing: false,
  isBridging: false,
  darkMode: false,

  selectPool: (pool) => set({ selectedPool: pool }),
  setFromChain: (chain) => set({ selectedFromChain: chain }),
  setToChain: (chain) => set({ selectedToChain: chain }),
  setDepositAmount: (amount) => set({ depositAmount: amount }),
  setWithdrawNote: (id) => set({ withdrawNoteId: id }),
  toggleDarkMode: () => {
    const next = !get().darkMode
    document.documentElement.classList.toggle("dark", next)
    set({ darkMode: next })
  },

  deposit: async (amount, token, fromChain, poolId) => {
    set({ isDepositing: true })
    const secret = generateMockHex(64)
    const nullifier = generateMockHex(64)
    const commitment = generateMockHex(64)
    const nullifierHash = generateMockHex(64)
    const txId = `tx-${Date.now()}`

    const tx: BridgeTransaction = {
      id: txId,
      type: "deposit",
      fromChain,
      toChain: fromChain,
      amount,
      token,
      status: "pending",
      txHash: generateMockHex(64),
      commitment,
      timestamp: Date.now(),
      relayerFee: amount * 0.001,
    }

    set((s) => ({ transactions: [tx, ...s.transactions] }))

    await new Promise((r) => setTimeout(r, 1500))
    set((s) => ({
      transactions: s.transactions.map((t) =>
        t.id === txId ? { ...t, status: "proving" as const } : t
      ),
    }))

    await new Promise((r) => setTimeout(r, 2000))

    const note: DepositNote = {
      id: `note-${Date.now()}`,
      poolId,
      amount,
      secret,
      nullifier,
      commitment,
      nullifierHash,
      createdAt: Date.now(),
      chainId: fromChain,
      token,
      withdrawn: false,
    }

    set((s) => ({
      notes: [note, ...s.notes],
      transactions: s.transactions.map((t) =>
        t.id === txId ? { ...t, status: "confirmed" as const } : t
      ),
      isDepositing: false,
      depositAmount: "",
    }))
  },

  withdraw: async (noteId, toChain) => {
    set({ isWithdrawing: true })
    const note = get().notes.find((n) => n.id === noteId)
    if (!note) {
      set({ isWithdrawing: false })
      return
    }

    const txId = `tx-${Date.now()}`
    const tx: BridgeTransaction = {
      id: txId,
      type: "withdraw",
      fromChain: note.chainId,
      toChain,
      amount: note.amount,
      token: note.token,
      status: "proving",
      txHash: generateMockHex(64),
      nullifierHash: note.nullifierHash,
      proof: generateMockHex(48),
      timestamp: Date.now(),
      relayerFee: note.amount * 0.002,
    }

    set((s) => ({ transactions: [tx, ...s.transactions] }))

    await new Promise((r) => setTimeout(r, 2000))
    set((s) => ({
      transactions: s.transactions.map((t) =>
        t.id === txId ? { ...t, status: "relaying" as const } : t
      ),
    }))

    await new Promise((r) => setTimeout(r, 1500))
    set((s) => ({
      notes: s.notes.map((n) =>
        n.id === noteId ? { ...n, withdrawn: true, withdrawnChainId: toChain } : n
      ),
      transactions: s.transactions.map((t) =>
        t.id === txId ? { ...t, status: "confirmed" as const } : t
      ),
      isWithdrawing: false,
      withdrawNoteId: null,
    }))
  },

  bridge: async (noteId, toChain) => {
    set({ isBridging: true })
    const note = get().notes.find((n) => n.id === noteId)
    if (!note) {
      set({ isBridging: false })
      return
    }

    const txId = `tx-${Date.now()}`
    const tx: BridgeTransaction = {
      id: txId,
      type: "bridge",
      fromChain: note.chainId,
      toChain,
      amount: note.amount,
      token: note.token,
      status: "proving",
      txHash: generateMockHex(64),
      nullifierHash: note.nullifierHash,
      proof: generateMockHex(48),
      timestamp: Date.now(),
      relayerFee: note.amount * 0.003,
    }

    set((s) => ({ transactions: [tx, ...s.transactions] }))

    await new Promise((r) => setTimeout(r, 2500))
    set((s) => ({
      transactions: s.transactions.map((t) =>
        t.id === txId ? { ...t, status: "relaying" as const } : t
      ),
    }))

    await new Promise((r) => setTimeout(r, 2000))
    set((s) => ({
      notes: s.notes.map((n) =>
        n.id === noteId ? { ...n, withdrawn: true, withdrawnChainId: toChain } : n
      ),
      transactions: s.transactions.map((t) =>
        t.id === txId ? { ...t, status: "confirmed" as const } : t
      ),
      isBridging: false,
    }))
  },

  addNote: (note) => set((s) => ({ notes: [note, ...s.notes] })),
  removeNote: (id) => set((s) => ({ notes: s.notes.filter((n) => n.id !== id) })),
  addTransaction: (tx) => set((s) => ({ transactions: [tx, ...s.transactions] })),
  updateTransactionStatus: (id, status) =>
    set((s) => ({
      transactions: s.transactions.map((t) => (t.id === id ? { ...t, status } : t)),
    })),
}))
