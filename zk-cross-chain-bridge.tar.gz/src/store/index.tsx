import { createContext, useContext, useReducer, type ReactNode } from "react";
import type { DepositNote } from "../crypto/poseidon";

export type TabId = "deposit" | "withdraw" | "notes" | "relayers" | "pools";

export interface AppState {
  activeTab: TabId;
  notes: DepositNote[];
  selectedNote: DepositNote | null;
  isGenerating: boolean;
  isSubmitting: boolean;
  lastTxHash: string | null;
  error: string | null;
  success: string | null;
  selectiveDisclosure: boolean;
  disclosureAmount: boolean;
  disclosureSource: boolean;
  disclosureDest: boolean;
  disclosureTimestamp: boolean;
}

export type Action =
  | { type: "SET_TAB"; tab: TabId }
  | { type: "ADD_NOTE"; note: DepositNote }
  | { type: "REMOVE_NOTE"; index: number }
  | { type: "SELECT_NOTE"; note: DepositNote | null }
  | { type: "SET_GENERATING"; value: boolean }
  | { type: "SET_SUBMITTING"; value: boolean }
  | { type: "SET_TX_HASH"; hash: string | null }
  | { type: "SET_ERROR"; error: string | null }
  | { type: "SET_SUCCESS"; success: string | null }
  | { type: "TOGGLE_SELECTIVE_DISCLOSURE" }
  | { type: "TOGGLE_DISCLOSURE_AMOUNT" }
  | { type: "TOGGLE_DISCLOSURE_SOURCE" }
  | { type: "TOGGLE_DISCLOSURE_DEST" }
  | { type: "TOGGLE_DISCLOSURE_TIMESTAMP" };

const initialState: AppState = {
  activeTab: "deposit",
  notes: [],
  selectedNote: null,
  isGenerating: false,
  isSubmitting: false,
  lastTxHash: null,
  error: null,
  success: null,
  selectiveDisclosure: false,
  disclosureAmount: false,
  disclosureSource: false,
  disclosureDest: false,
  disclosureTimestamp: false,
};

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case "SET_TAB":
      return { ...state, activeTab: action.tab, error: null, success: null };
    case "ADD_NOTE":
      return { ...state, notes: [...state.notes, action.note] };
    case "REMOVE_NOTE":
      return { ...state, notes: state.notes.filter((_, i) => i !== action.index) };
    case "SELECT_NOTE":
      return { ...state, selectedNote: action.note };
    case "SET_GENERATING":
      return { ...state, isGenerating: action.value };
    case "SET_SUBMITTING":
      return { ...state, isSubmitting: action.value };
    case "SET_TX_HASH":
      return { ...state, lastTxHash: action.hash };
    case "SET_ERROR":
      return { ...state, error: action.error };
    case "SET_SUCCESS":
      return { ...state, success: action.success };
    case "TOGGLE_SELECTIVE_DISCLOSURE":
      return { ...state, selectiveDisclosure: !state.selectiveDisclosure };
    case "TOGGLE_DISCLOSURE_AMOUNT":
      return { ...state, disclosureAmount: !state.disclosureAmount };
    case "TOGGLE_DISCLOSURE_SOURCE":
      return { ...state, disclosureSource: !state.disclosureSource };
    case "TOGGLE_DISCLOSURE_DEST":
      return { ...state, disclosureDest: !state.disclosureDest };
    case "TOGGLE_DISCLOSURE_TIMESTAMP":
      return { ...state, disclosureTimestamp: !state.disclosureTimestamp };
    default:
      return state;
  }
}

const StoreContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<Action>;
}>({ state: initialState, dispatch: () => {} });

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  return <StoreContext.Provider value={{ state, dispatch }}>{children}</StoreContext.Provider>;
}

export function useStore() {
  return useContext(StoreContext);
}
