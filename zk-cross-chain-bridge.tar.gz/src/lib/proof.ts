import type { PoolNote, ProofResult, WitnessPackage } from "../types";

type SnarkModule = {
  groth16: {
    fullProve: (
      input: Record<string, string | string[]>,
      wasmPath: string,
      zkeyPath: string
    ) => Promise<{ proof: unknown; publicSignals: string[] }>;
  };
};

type ProvingManifest = {
  circuits: Record<
    string,
    {
      wasm: string;
      zkey: string;
    }
  >;
};

async function loadManifest(): Promise<ProvingManifest> {
  const response = await fetch("/proving/manifest.json");
  if (!response.ok) {
    throw new Error("Missing proving asset manifest.");
  }

  return (await response.json()) as ProvingManifest;
}

export async function buildWithdrawalWitness(note: PoolNote, recipient: string): Promise<WitnessPackage> {
  await loadManifest();

  return {
    circuit: "shielded_pool",
    input: {
      root: "0",
      nullifier: note.nullifier,
      secret: note.secret,
      amount: note.amount,
      recipient,
      nullifierHash: note.nullifierHash,
      commitment: note.commitment
    },
    manifestCheckedAt: new Date().toISOString()
  };
}

export async function buildDisclosureWitness(note: PoolNote): Promise<WitnessPackage> {
  await loadManifest();

  return {
    circuit: "selective_disclosure",
    input: {
      nullifierHash: note.nullifierHash,
      commitment: note.commitment,
      jurisdiction: note.selectiveDisclosure.jurisdiction,
      travelRuleRef: note.selectiveDisclosure.travelRuleRef,
      auditorKey: note.selectiveDisclosure.auditorKey
    },
    manifestCheckedAt: new Date().toISOString()
  };
}

export async function createProof(pkg: WitnessPackage): Promise<ProofResult> {
  try {
    const manifest = await loadManifest();
    const circuitAssets = manifest.circuits[pkg.circuit];
    if (!circuitAssets?.wasm || !circuitAssets?.zkey) {
      return { ok: false, reason: "Circuit assets are not configured in the manifest." };
    }

    const snarkjs = (await import("snarkjs")) as unknown as SnarkModule;
    const result = await snarkjs.groth16.fullProve(pkg.input, circuitAssets.wasm, circuitAssets.zkey);
    return { ok: true, proof: result.proof, publicSignals: result.publicSignals };
  } catch (error) {
    const reason = error instanceof Error ? error.message : "Unknown proof generation failure.";
    return { ok: false, reason };
  }
}
