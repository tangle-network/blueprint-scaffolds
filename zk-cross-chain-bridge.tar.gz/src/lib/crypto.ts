import { buildPoseidon } from "circomlibjs";
import { formatEther, parseEther } from "ethers";
import type { ChainId, PoolNote } from "../types";

type PoseidonHash = (inputs: bigint[]) => string;
type PoseidonFactory = {
  (inputs: bigint[]): unknown;
  F: {
    toString(value: unknown, radix: number): string;
  };
};

let poseidonHashPromise: Promise<PoseidonHash> | null = null;

function randomFieldHex(): string {
  const bytes = new Uint8Array(31);
  crypto.getRandomValues(bytes);
  return `0x${Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("")}`;
}

function chainDomain(chain: ChainId): bigint {
  return BigInt({ ethereum: 1, polygon: 137, bsc: 56 }[chain]);
}

async function getPoseidonHash(): Promise<PoseidonHash> {
  if (!poseidonHashPromise) {
    poseidonHashPromise = buildPoseidon().then((poseidon) => {
      const hash = poseidon as PoseidonFactory;
      return (inputs: bigint[]) => {
        const result = hash(inputs);
        return `0x${hash.F.toString(result, 16)}`;
      };
    });
  }

  return poseidonHashPromise!;
}

export async function createPoolNote(args: {
  chain: ChainId;
  amount: string;
  recipientHint: string;
  jurisdiction: string;
  travelRuleRef: string;
  auditorKey: string;
}): Promise<PoolNote> {
  const poseidonHash = await getPoseidonHash();
  const secret = randomFieldHex();
  const nullifier = randomFieldHex();
  const amountWei = parseEther(args.amount || "0");
  const commitment = poseidonHash([
    BigInt(secret),
    BigInt(nullifier),
    amountWei,
    chainDomain(args.chain)
  ]);
  const nullifierHash = poseidonHash([BigInt(nullifier), chainDomain(args.chain)]);

  return {
    id: crypto.randomUUID(),
    chain: args.chain,
    amount: formatEther(amountWei),
    commitment,
    nullifierHash,
    secret,
    nullifier,
    recipientHint: args.recipientHint,
    createdAt: new Date().toISOString(),
    selectiveDisclosure: {
      jurisdiction: args.jurisdiction,
      travelRuleRef: args.travelRuleRef,
      auditorKey: args.auditorKey
    }
  };
}
