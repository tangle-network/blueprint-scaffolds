import type { PoolNote } from "../types";

const STORAGE_KEY = "shadowbridge.notes.v1";

export function loadNotes(): PoolNote[] {
  if (typeof window === "undefined") {
    return [];
  }

  const raw = window.localStorage.getItem(STORAGE_KEY);
  if (!raw) {
    return [];
  }

  try {
    return JSON.parse(raw) as PoolNote[];
  } catch {
    return [];
  }
}

export function saveNotes(notes: PoolNote[]): void {
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
}
