import type { ChainId, RelayerQuote } from "../types";

const feeTable: Record<ChainId, RelayerQuote> = {
  ethereum: { chain: "ethereum", feeBps: 22, gasToken: "ETH", eta: "~4 min" },
  polygon: { chain: "polygon", feeBps: 12, gasToken: "MATIC", eta: "~90 sec" },
  bsc: { chain: "bsc", feeBps: 10, gasToken: "BNB", eta: "~75 sec" }
};

export function getRelayerQuote(chain: ChainId): RelayerQuote {
  return feeTable[chain];
}

export function describeRoute(source: ChainId, destination: ChainId): string {
  if (source === destination) {
    return `Same-chain exit via ${destination} verifier`;
  }

  return `${source} deposit -> relayer message bus -> ${destination} verifier`;
}
