import { useEffect, useMemo, useState } from "react";
import { createPoolNote } from "./lib/crypto";
import { buildDisclosureWitness, buildWithdrawalWitness, createProof } from "./lib/proof";
import { describeRoute, getRelayerQuote } from "./lib/relayer";
import { loadNotes, saveNotes } from "./lib/storage";
import { MetricCard } from "./components/MetricCard";
import type { ChainId, PoolNote, ProofResult, WitnessPackage } from "./types";

const chains: ChainId[] = ["ethereum", "polygon", "bsc"];

const emptyWitness: WitnessPackage | null = null;
const emptyProof: ProofResult | null = null;

export default function App() {
  const [notes, setNotes] = useState<PoolNote[]>([]);
  const [sourceChain, setSourceChain] = useState<ChainId>("ethereum");
  const [destinationChain, setDestinationChain] = useState<ChainId>("polygon");
  const [amount, setAmount] = useState("0.50");
  const [recipientHint, setRecipientHint] = useState("0xRecipient...");
  const [jurisdiction, setJurisdiction] = useState("US");
  const [travelRuleRef, setTravelRuleRef] = useState("TR-2025-001");
  const [auditorKey, setAuditorKey] = useState("auditor-pubkey-demo");
  const [activeNoteId, setActiveNoteId] = useState<string>("");
  const [withdrawRecipient, setWithdrawRecipient] = useState("0xWithdrawRecipient...");
  const [status, setStatus] = useState("Ready.");
  const [witness, setWitness] = useState<WitnessPackage>(emptyWitness as WitnessPackage);
  const [proofResult, setProofResult] = useState<ProofResult>(emptyProof as ProofResult);
  const [selectedTab, setSelectedTab] = useState<"deposit" | "withdraw" | "compliance">("deposit");

  useEffect(() => {
    const stored = loadNotes();
    setNotes(stored);
    setActiveNoteId(stored[0]?.id ?? "");
  }, []);

  useEffect(() => {
    saveNotes(notes);
  }, [notes]);

  const activeNote = useMemo(
    () => notes.find((note) => note.id === activeNoteId) ?? null,
    [activeNoteId, notes]
  );

  const routeQuote = getRelayerQuote(destinationChain);

  async function handleDeposit() {
    setStatus("Creating Poseidon commitment and note...");
    const note = await createPoolNote({
      chain: sourceChain,
      amount,
      recipientHint,
      jurisdiction,
      travelRuleRef,
      auditorKey
    });

    setNotes((current) => [note, ...current]);
    setActiveNoteId(note.id);
    setSelectedTab("withdraw");
    setWitness(emptyWitness as WitnessPackage);
    setProofResult(emptyProof as ProofResult);
    setStatus(`Note created for ${sourceChain}. Commitment ${note.commitment.slice(0, 18)}...`);
  }

  async function handleBuildWithdrawalWitness() {
    if (!activeNote) {
      return;
    }

    setStatus("Building withdrawal witness in browser...");
    const nextWitness = await buildWithdrawalWitness(activeNote, withdrawRecipient);
    setWitness(nextWitness);
    setProofResult(emptyProof as ProofResult);
    setStatus("Withdrawal witness ready.");
  }

  async function handleBuildDisclosureWitness() {
    if (!activeNote) {
      return;
    }

    setStatus("Building selective disclosure witness...");
    const nextWitness = await buildDisclosureWitness(activeNote);
    setWitness(nextWitness);
    setProofResult(emptyProof as ProofResult);
    setStatus("Disclosure witness ready.");
  }

  async function handleGenerateProof() {
    if (!witness) {
      return;
    }

    setStatus("Running Groth16 proof generation...");
    const result = await createProof(witness);
    setProofResult(result);
    setStatus(result.ok ? "Proof generated." : `Proof unavailable: ${result.reason}`);
  }

  return (
    <div className="shell">
      <section className="hero">
        <div>
          <p className="eyebrow">Privacy-preserving cross-chain bridge</p>
          <h1>ShadowBridge</h1>
          <p className="lede">
            Shielded pools with Poseidon commitments, nullifier-based double-spend protection,
            Groth16 proofs, and optional selective disclosure for compliance workflows.
          </p>
        </div>
        <div className="hero-panel">
          <MetricCard label="Source pool" value={sourceChain} hint="Deposit chain" />
          <MetricCard label="Exit verifier" value={destinationChain} hint="Withdrawal chain" />
          <MetricCard
            label="Relayer fee"
            value={`${routeQuote.feeBps} bps`}
            hint={`${routeQuote.gasToken} settlement ${routeQuote.eta}`}
          />
        </div>
      </section>

      <section className="workspace">
        <aside className="sidebar">
          <div className="tab-row">
            <button className={selectedTab === "deposit" ? "active" : ""} onClick={() => setSelectedTab("deposit")}>
              Deposit
            </button>
            <button className={selectedTab === "withdraw" ? "active" : ""} onClick={() => setSelectedTab("withdraw")}>
              Withdraw
            </button>
            <button
              className={selectedTab === "compliance" ? "active" : ""}
              onClick={() => setSelectedTab("compliance")}
            >
              Compliance
            </button>
          </div>

          {selectedTab === "deposit" ? (
            <div className="panel">
              <label>
                Source chain
                <select value={sourceChain} onChange={(event) => setSourceChain(event.target.value as ChainId)}>
                  {chains.map((chain) => (
                    <option key={chain} value={chain}>
                      {chain}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Exit chain
                <select
                  value={destinationChain}
                  onChange={(event) => setDestinationChain(event.target.value as ChainId)}
                >
                  {chains.map((chain) => (
                    <option key={chain} value={chain}>
                      {chain}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Amount
                <input value={amount} onChange={(event) => setAmount(event.target.value)} />
              </label>
              <label>
                Recipient hint
                <input value={recipientHint} onChange={(event) => setRecipientHint(event.target.value)} />
              </label>
              <label>
                Jurisdiction
                <input value={jurisdiction} onChange={(event) => setJurisdiction(event.target.value)} />
              </label>
              <label>
                Travel rule ref
                <input value={travelRuleRef} onChange={(event) => setTravelRuleRef(event.target.value)} />
              </label>
              <label>
                Auditor key
                <input value={auditorKey} onChange={(event) => setAuditorKey(event.target.value)} />
              </label>
              <button className="primary" onClick={handleDeposit}>
                Create shielded note
              </button>
              <p className="route">{describeRoute(sourceChain, destinationChain)}</p>
            </div>
          ) : null}

          {selectedTab === "withdraw" ? (
            <div className="panel">
              <label>
                Active note
                <select value={activeNoteId} onChange={(event) => setActiveNoteId(event.target.value)}>
                  {notes.length === 0 ? <option value="">No notes yet</option> : null}
                  {notes.map((note) => (
                    <option key={note.id} value={note.id}>
                      {note.chain} | {note.amount} | {note.commitment.slice(0, 12)}...
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Withdrawal recipient
                <input
                  value={withdrawRecipient}
                  onChange={(event) => setWithdrawRecipient(event.target.value)}
                />
              </label>
              <button className="primary" onClick={handleBuildWithdrawalWitness} disabled={!activeNote}>
                Build witness
              </button>
              <button onClick={handleGenerateProof} disabled={!witness}>
                Generate Groth16 proof
              </button>
            </div>
          ) : null}

          {selectedTab === "compliance" ? (
            <div className="panel">
              <p className="lede small">
                Selective disclosure reveals only compliance metadata while preserving note secrecy.
              </p>
              <button className="primary" onClick={handleBuildDisclosureWitness} disabled={!activeNote}>
                Build disclosure witness
              </button>
              <button onClick={handleGenerateProof} disabled={!witness}>
                Generate disclosure proof
              </button>
            </div>
          ) : null}
        </aside>

        <main className="content">
          <section className="panel">
            <div className="section-heading">
              <h2>Note vault</h2>
              <span>{notes.length} stored notes</span>
            </div>
            <div className="note-list">
              {notes.map((note) => (
                <article
                  key={note.id}
                  className={`note-card ${note.id === activeNoteId ? "selected" : ""}`}
                  onClick={() => setActiveNoteId(note.id)}
                >
                  <strong>{note.chain}</strong>
                  <span>{note.amount} native</span>
                  <code>{note.commitment}</code>
                  <small>Nullifier {note.nullifierHash.slice(0, 18)}...</small>
                </article>
              ))}
              {notes.length === 0 ? <p className="empty">No notes created yet.</p> : null}
            </div>
          </section>

          <section className="panel">
            <div className="section-heading">
              <h2>Witness package</h2>
              <span>{witness ? witness.circuit : "No witness yet"}</span>
            </div>
            <pre>{witness ? JSON.stringify(witness, null, 2) : "Witness data will appear here."}</pre>
          </section>

          <section className="panel">
            <div className="section-heading">
              <h2>Proof status</h2>
              <span>{status}</span>
            </div>
            <pre>{proofResult ? JSON.stringify(proofResult, null, 2) : "Generate a proof to populate output."}</pre>
          </section>
        </main>
      </section>
    </div>
  );
}
