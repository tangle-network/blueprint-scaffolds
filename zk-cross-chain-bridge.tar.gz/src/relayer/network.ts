export interface RelayerInfo {
  id: string;
  name: string;
  url: string;
  chains: string[];
  feePercent: number;
  status: "online" | "offline" | "busy";
  totalRelayed: number;
}

export const MOCK_RELAYERS: RelayerInfo[] = [
  {
    id: "r1",
    name: "ZK-Relay Alpha",
    url: "https://relay-alpha.zkbridge.example",
    chains: ["ethereum", "polygon"],
    feePercent: 0.5,
    status: "online",
    totalRelayed: 1243,
  },
  {
    id: "r2",
    name: "ShieldRelay",
    url: "https://shield-relay.example",
    chains: ["ethereum", "bsc"],
    feePercent: 0.3,
    status: "online",
    totalRelayed: 892,
  },
  {
    id: "r3",
    name: "CrossChain Privacy",
    url: "https://ccp-relay.example",
    chains: ["polygon", "bsc"],
    feePercent: 0.4,
    status: "busy",
    totalRelayed: 567,
  },
  {
    id: "r4",
    name: "PrivateBridge Node",
    url: "https://pb-node.example",
    chains: ["ethereum", "polygon", "bsc"],
    feePercent: 0.25,
    status: "online",
    totalRelayed: 2104,
  },
];

export function calculateRelayerFee(amount: string, feePercent: number): string {
  const amt = parseFloat(amount);
  const fee = amt * (feePercent / 100);
  return fee.toFixed(6);
}

export async function submitToRelayer(
  relayer: RelayerInfo,
  proof: object,
  publicSignals: string[],
  targetChain: string
): Promise<{ txHash: string; status: string }> {
  await new Promise((r) => setTimeout(r, 2000));
  return {
    txHash: "0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(""),
    status: "submitted",
  };
}
