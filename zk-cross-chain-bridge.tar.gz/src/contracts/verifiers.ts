import { CHAINS, type ChainId } from "../config/chains";

export interface VerifierConfig {
  chainId: ChainId;
  verifierAddress: string;
  verifierAbi: object[];
}

const VERIFIER_ABI = [
  {
    inputs: [
      { name: "proof", type: "uint256[2]" },
      { name: "proofBits", type: "uint256[2][2]" },
      { name: "proofC", type: "uint256[2]" },
      { name: "input", type: "uint256[]" },
    ],
    name: "verifyProof",
    outputs: [{ name: "", type: "bool" }],
    stateMutability: "view",
    type: "function",
  },
];

export const VERIFIERS: Record<ChainId, VerifierConfig> = {
  ethereum: {
    chainId: "ethereum",
    verifierAddress: "0xAAA0000000000000000000000000000000000001",
    verifierAbi: VERIFIER_ABI,
  },
  polygon: {
    chainId: "polygon",
    verifierAddress: "0xBBB0000000000000000000000000000000000002",
    verifierAbi: VERIFIER_ABI,
  },
  bsc: {
    chainId: "bsc",
    verifierAddress: "0xCCC0000000000000000000000000000000000003",
    verifierAbi: VERIFIER_ABI,
  },
};

export interface BridgeContractConfig {
  chainId: ChainId;
  bridgeAddress: string;
  bridgeAbi: object[];
}

const BRIDGE_ABI = [
  {
    inputs: [{ name: "commitment", type: "bytes32" }],
    name: "deposit",
    outputs: [],
    stateMutability: "payable",
    type: "function",
  },
  {
    inputs: [
      { name: "proof", type: "uint256[2]" },
      { name: "proofBits", type: "uint256[2][2]" },
      { name: "proofC", type: "uint256[2]" },
      { name: "root", type: "bytes32" },
      { name: "nullifierHash", type: "bytes32" },
      { name: "recipient", type: "address" },
      { name: "relayer", type: "address" },
      { name: "fee", type: "uint256" },
      { name: "refund", type: "uint256" },
    ],
    name: "withdraw",
    outputs: [],
    stateMutability: "payable",
    type: "function",
  },
  {
    inputs: [{ name: "nullifierHash", type: "bytes32" }],
    name: "isSpent",
    outputs: [{ name: "", type: "bool" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [{ name: "commitment", type: "bytes32" }],
    name: "commitments",
    outputs: [{ name: "", type: "bool" }],
    stateMutability: "view",
    type: "function",
  },
];

export const BRIDGE_CONTRACTS: Record<ChainId, BridgeContractConfig> = {
  ethereum: {
    chainId: "ethereum",
    bridgeAddress: CHAINS.ethereum.bridgeAddress,
    bridgeAbi: BRIDGE_ABI,
  },
  polygon: {
    chainId: "polygon",
    bridgeAddress: CHAINS.polygon.bridgeAddress,
    bridgeAbi: BRIDGE_ABI,
  },
  bsc: {
    chainId: "bsc",
    bridgeAddress: CHAINS.bsc.bridgeAddress,
    bridgeAbi: BRIDGE_ABI,
  },
};
