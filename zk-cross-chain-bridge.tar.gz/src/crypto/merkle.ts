import { poseidonHash } from "./poseidon";

export interface MerkleProof {
  pathElements: bigint[];
  pathIndices: number[];
  root: bigint;
}

const ZERO_VALUES: bigint[] = [];
let initialized = false;

function initZeroValues() {
  if (initialized) return;
  for (let i = 0; i < 20; i++) {
    const val = BigInt(i + 1) * BigInt("21888242871839275222246405745257275088548364400416034343698204186575808495617") / BigInt("1000000000000000000000000000");
    ZERO_VALUES.push(val);
  }
  initialized = true;
}

export class MerkleTree {
  levels: number;
  capacity: number;
  leaves: bigint[];
  layers: bigint[][];
  zeros: bigint[];
  cachedHashes: Map<string, bigint>;

  constructor(levels: number = 20) {
    this.levels = levels;
    this.capacity = 2 ** levels;
    this.leaves = [];
    this.zeros = [];
    this.layers = [];
    this.cachedHashes = new Map();
    initZeroValues();
    this.zeros = [...ZERO_VALUES];
  }

  private async hashPair(left: bigint, right: bigint): Promise<bigint> {
    const key = `${left.toString()}_${right.toString()}`;
    if (this.cachedHashes.has(key)) return this.cachedHashes.get(key)!;
    const h = await poseidonHash([left, right]);
    this.cachedHashes.set(key, h);
    return h;
  }

  async root(): Promise<bigint> {
    if (this.layers.length === 0) return this.zeros[this.zeros.length - 1];
    return this.layers[this.levels][0];
  }

  async insert(leaf: bigint): Promise<number> {
    const index = this.leaves.length;
    this.leaves.push(leaf);
    await this._updateTree(index);
    return index;
  }

  private async _updateTree(index: number) {
    if (this.layers.length === 0) {
      this.layers[0] = [...this.leaves];
    } else {
      this.layers[0][index] = this.leaves[index];
    }

    for (let level = 0; level < this.levels; level++) {
      const currentLevel = this.layers[level] || [];
      const nextLevel: bigint[] = [];

      for (let i = 0; i < currentLevel.length; i += 2) {
        const left = currentLevel[i] || this.zeros[level];
        const right = currentLevel[i + 1] || this.zeros[level];
        nextLevel[i / 2] = await this.hashPair(left, right);
      }

      this.layers[level + 1] = nextLevel;
    }
  }

  proof(index: number): MerkleProof {
    if (index >= this.leaves.length) {
      throw new Error("Index out of bounds");
    }

    const pathElements: bigint[] = [];
    const pathIndices: number[] = [];

    let currentIdx = index;
    for (let level = 0; level < this.levels; level++) {
      const layer = this.layers[level] || [];
      const siblingIdx = currentIdx % 2 === 0 ? currentIdx + 1 : currentIdx - 1;
      pathElements.push(layer[siblingIdx] || this.zeros[level]);
      pathIndices.push(currentIdx % 2);
      currentIdx = Math.floor(currentIdx / 2);
    }

    const rootVal = this.layers[this.levels]?.[0] || this.zeros[this.zeros.length - 1];
    return {
      pathElements,
      pathIndices,
      root: rootVal,
    };
  }

  size(): number {
    return this.leaves.length;
  }
}
