const SNARK_FIELD_SIZE = BigInt("21888242871839275222246405745257275088548364400416034343698204186575808495617");

export function bigIntToHex(n: bigint): string {
  return "0x" + n.toString(16);
}

export function hexToBigInt(hex: string): bigint {
  return BigInt(hex);
}

export function randomFieldElement(): bigint {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  const hex = Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
  let n = BigInt("0x" + hex) % SNARK_FIELD_SIZE;
  if (n === 0n) n = 1n;
  return n;
}

async function sha256(input: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(hashBuffer)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

export async function poseidonHash(inputs: bigint[]): Promise<bigint> {
  const serialized = inputs.map((i) => i.toString(16).padStart(64, "0")).join("");
  const hash = await sha256(serialized);
  let result = BigInt("0x" + hash) % SNARK_FIELD_SIZE;
  if (result === 0n) result = 1n;
  return result;
}

export interface DepositNote {
  secret: bigint;
  nullifier: bigint;
  commitment: bigint;
  nullifierHash: bigint;
  amount: string;
  chain: string;
  timestamp: number;
}

export async function generateDepositNote(amount: string, chain: string): Promise<DepositNote> {
  const secret = randomFieldElement();
  const nullifier = randomFieldElement();
  const commitment = await poseidonHash([nullifier, secret]);
  const nullifierHash = await poseidonHash([nullifier]);
  return {
    secret,
    nullifier,
    commitment,
    nullifierHash,
    amount,
    chain,
    timestamp: Date.now(),
  };
}

export function serializeNote(note: DepositNote): string {
  const obj = {
    s: bigIntToHex(note.secret),
    n: bigIntToHex(note.nullifier),
    c: bigIntToHex(note.commitment),
    nh: bigIntToHex(note.nullifierHash),
    a: note.amount,
    ch: note.chain,
    t: note.timestamp,
  };
  return btoa(JSON.stringify(obj));
}

export function deserializeNote(encoded: string): DepositNote {
  const obj = JSON.parse(atob(encoded));
  return {
    secret: hexToBigInt(obj.s),
    nullifier: hexToBigInt(obj.n),
    commitment: hexToBigInt(obj.c),
    nullifierHash: hexToBigInt(obj.nh),
    amount: obj.a,
    chain: obj.ch,
    timestamp: obj.t,
  };
}
