export interface Groth16Proof {
  pi_a: string[];
  pi_b: string[][];
  pi_c: string[];
  protocol: string;
}

export interface ProofResult {
  proof: Groth16Proof;
  publicSignals: string[];
}

export interface SelectiveDisclosure {
  revealAmount: boolean;
  revealSourceChain: boolean;
  revealDestinationChain: boolean;
  revealTimestamp: boolean;
}

export async function generateWitness(
  nullifier: bigint,
  secret: bigint,
  pathElements: bigint[],
  pathIndices: number[],
  recipient: bigint,
  relayer: bigint,
  fee: bigint,
  refund: bigint
): Promise<bigint[]> {
  return [nullifier, secret, ...pathElements.slice(0, 4), BigInt(0)];
}

export async function generateProof(witness: bigint[]): Promise<ProofResult> {
  await new Promise((r) => setTimeout(r, 800));
  return {
    proof: {
      pi_a: [
        "0x1a2b3c4d5e6f7890abcdef1234567890abcdef1234567890abcdef12345678",
        "0x2b3c4d5e6f7890abcdef1234567890abcdef1234567890abcdef1234567890",
        "0x1",
      ],
      pi_b: [
        [
          "0x3c4d5e6f7890abcdef1234567890abcdef1234567890abcdef12345678901a",
          "0x4d5e6f7890abcdef1234567890abcdef1234567890abcdef12345678901a2b",
        ],
        [
          "0x5e6f7890abcdef1234567890abcdef1234567890abcdef12345678901a2b3c",
          "0x6f7890abcdef1234567890abcdef1234567890abcdef12345678901a2b3c4d",
        ],
        ["0x1", "0x0"],
      ],
      pi_c: [
        "0x7890abcdef1234567890abcdef1234567890abcdef12345678901a2b3c4d5e",
        "0x890abcdef1234567890abcdef1234567890abcdef12345678901a2b3c4d5e6f",
        "0x1",
      ],
      protocol: "groth16",
    },
    publicSignals: [
      "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
      "0xabcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890",
      "0x0",
      "0x0",
      "0x0",
    ],
  };
}

export function formatProofForContract(proof: ProofResult): object {
  return {
    a: proof.proof.pi_a.slice(0, 2),
    b: proof.proof.pi_b.slice(0, 2).map((arr) => arr.slice(0, 2)),
    c: proof.proof.pi_c.slice(0, 2),
    input: proof.publicSignals,
  };
}
