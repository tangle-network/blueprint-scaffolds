# x402 API Service

Monetized Express API that protects endpoints with x402 micropayments, settles through the Coinbase-hosted facilitator, and records usage plus revenue metrics in PostgreSQL.

## Features

- Route-level x402 protection for REST endpoints
- Dynamic pricing per endpoint and request shape
- Multiple payment assets on Base mainnet: USDC and WETH (exposed as ETH pricing)
- Coinbase facilitator integration via `https://api.cdp.coinbase.com/platform/v2/x402`
- PostgreSQL-backed usage attempts, payment verification, and settlement tracking
- Admin analytics endpoint for revenue visibility

## Endpoints

- `GET /health`
- `GET /pricing`
- `GET /api/weather`
- `GET /api/fx`
- `POST /api/insights`
- `GET /analytics/summary` with `x-admin-token`

## Setup

1. Copy `.env.example` to `.env` and set real values.
2. Ensure PostgreSQL is reachable at `DATABASE_URL`.
3. Install dependencies with `pnpm install`.
4. Build with `pnpm build`.
5. Start with `pnpm start` or `pnpm dev`.

## Notes

- Base mainnet network id is `eip155:8453`.
- The Coinbase facilitator URL comes from the x402 seller quickstart mainnet section.
- Base WETH address is used for the ETH-denominated payment option because the x402 exact EVM flow operates on ERC-20 assets.
