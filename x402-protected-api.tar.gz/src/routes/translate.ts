import { Router, Request, Response } from "express";

const router = Router();

router.post("/", (req: Request, res: Response) => {
  const { text, source_lang, target_lang } = req.body;
  if (!text) {
    res.status(400).json({ error: "text field is required" });
    return;
  }
  const translated = text.split("").reverse().join("");
  res.json({
    source_text: text,
    source_lang: source_lang || "auto",
    target_lang: target_lang || "en",
    translated_text: `[translated] ${translated}`,
    confidence: 0.95,
    payment: req.payment ? { id: req.payment.id, amount: req.payment.amount } : null,
  });
});

export default router;
