import { Router, Request, Response } from "express";
import { getAnalyticsSummary, getPaymentsByPayer, getUnsettledPayments, settlePayment } from "../services/payments";
import { adminAuth } from "../middleware/auth";

const router = Router();

router.get("/usage", async (req: Request, res: Response) => {
  try {
    const days = parseInt(req.query.days as string) || 30;
    const summary = await getAnalyticsSummary(days);
    res.json(summary);
  } catch (err) {
    res.status(500).json({ error: "Failed to retrieve analytics", details: (err as Error).message });
  }
});

router.get("/payments/:payer", async (req: Request, res: Response) => {
  try {
    const payments = await getPaymentsByPayer(req.params.payer);
    res.json({ payer: req.params.payer, payments });
  } catch (err) {
    res.status(500).json({ error: "Failed to retrieve payments", details: (err as Error).message });
  }
});

router.get("/settlements/pending", adminAuth, async (req: Request, res: Response) => {
  try {
    const unsettled = await getUnsettledPayments();
    res.json({ count: unsettled.length, payments: unsettled });
  } catch (err) {
    res.status(500).json({ error: "Failed to retrieve unsettled payments", details: (err as Error).message });
  }
});

router.post("/settlements/:paymentId", adminAuth, async (req: Request, res: Response) => {
  try {
    const { txHash } = req.body;
    if (!txHash) {
      res.status(400).json({ error: "txHash is required" });
      return;
    }
    const result = await settlePayment(req.params.paymentId, txHash);
    if (result.success) {
      res.json({ success: true, txHash: result.txHash });
    } else {
      res.status(400).json({ success: false, error: result.error });
    }
  } catch (err) {
    res.status(500).json({ error: "Settlement failed", details: (err as Error).message });
  }
});

router.get("/revenue", adminAuth, async (req: Request, res: Response) => {
  try {
    const days = parseInt(req.query.days as string) || 30;
    const summary = await getAnalyticsSummary(days);
    res.json({
      period_days: days,
      total_revenue: summary.total_revenue,
      total_requests: summary.total_requests,
      daily_revenue: summary.daily_revenue,
      top_endpoints: summary.endpoints.slice(0, 10),
    });
  } catch (err) {
    res.status(500).json({ error: "Failed to retrieve revenue", details: (err as Error).message });
  }
});

export default router;
