import { Router, Request, Response } from "express";

const router = Router();

router.get("/data", (req: Request, res: Response) => {
  res.json({
    endpoint: "premium_data",
    data: {
      market_summary: {
        indices: {
          SPX: { value: 5234.18, change: +0.45 },
          NDAQ: { value: 16399.52, change: -0.12 },
        },
        top_movers: [
          { symbol: "AAPL", price: 189.84, change_pct: 2.3 },
          { symbol: "TSLA", price: 248.42, change_pct: -1.1 },
        ],
      },
    },
    payment: req.payment ? { id: req.payment.id, amount: req.payment.amount } : null,
  });
});

router.post("/compute", (req: Request, res: Response) => {
  const { operation, params } = req.body;
  res.json({
    endpoint: "premium_compute",
    operation: operation || "unknown",
    result: { computed: true, params: params || {} },
    credits_used: 1,
    payment: req.payment ? { id: req.payment.id, amount: req.payment.amount } : null,
  });
});

router.put("/config", (req: Request, res: Response) => {
  res.json({
    endpoint: "premium_config",
    updated: true,
    config: req.body,
    payment: req.payment ? { id: req.payment.id, amount: req.payment.amount } : null,
  });
});

router.delete("/data/:id", (req: Request, res: Response) => {
  res.json({
    endpoint: "premium_delete",
    deleted_id: req.params.id,
    payment: req.payment ? { id: req.payment.id, amount: req.payment.amount } : null,
  });
});

export default router;
