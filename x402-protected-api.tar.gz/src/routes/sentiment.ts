import { Router, Request, Response } from "express";

const router = Router();

router.post("/", (req: Request, res: Response) => {
  const { text } = req.body;
  if (!text) {
    res.status(400).json({ error: "text field is required" });
    return;
  }
  const words = text.split(/\s+/);
  const positive = ["good", "great", "excellent", "amazing", "wonderful", "best", "love", "happy"];
  const negative = ["bad", "terrible", "awful", "worst", "hate", "horrible", "angry", "sad"];
  let score = 0;
  for (const word of words) {
    const lower = word.toLowerCase();
    if (positive.includes(lower)) score++;
    if (negative.includes(lower)) score--;
  }
  const normalized = Math.max(-1, Math.min(1, score / Math.max(words.length, 1)));
  res.json({
    text,
    sentiment: normalized > 0.1 ? "positive" : normalized < -0.1 ? "negative" : "neutral",
    score: normalized,
    confidence: 0.85 + Math.random() * 0.1,
    word_count: words.length,
    payment: req.payment ? { id: req.payment.id, amount: req.payment.amount } : null,
  });
});

router.get("/", (req: Request, res: Response) => {
  const text = req.query.text as string;
  if (!text) {
    res.status(400).json({ error: "text query parameter is required" });
    return;
  }
  res.json({
    text,
    sentiment: "neutral",
    score: 0,
    confidence: 0.7,
    payment: req.payment ? { id: req.payment.id, amount: req.payment.amount } : null,
  });
});

export default router;
