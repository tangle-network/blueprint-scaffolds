import { Router, Request, Response } from "express";
import { x402PaymentMiddleware, verifySettlement } from "../middleware/payment";
import { pricingConfig, supportedTokens, getPriceForRoute } from "../config";

const router = Router();

router.get("/", (req: Request, res: Response) => {
  const endpoints = Object.entries(pricingConfig).map(([path, methods]) => ({
    path,
    methods: Object.entries(methods).map(([method, price]) => ({ method, price })),
  }));

  res.json({
    service: "x402 Paid API",
    version: "1.0.0",
    description: "API endpoints protected by x402 micropayments",
    network: "base",
    supportedTokens: supportedTokens.map((t) => t.symbol),
    endpoints,
    usage: "Include an X-Payment header with your request containing a valid x402 payment payload. A 402 response will include payment requirements.",
  });
});

router.get("/pricing", (req: Request, res: Response) => {
  const allPricing = Object.entries(pricingConfig).map(([path, methods]) => ({
    path,
    methods: Object.entries(methods).map(([method, price]) => ({ method, price })),
  }));
  res.json({ pricing: allPricing, supportedTokens });
});

router.get("/pricing/:path", (req: Request, res: Response) => {
  const routePath = "/" + req.params.path;
  const methods = pricingConfig[routePath];
  if (!methods) {
    res.status(404).json({ error: "Endpoint not found in pricing config" });
    return;
  }
  res.json({ path: routePath, methods });
});

router.post("/pricing", (req: Request, res: Response) => {
  const { path, method, price, maxAmount, token, description } = req.body;
  if (!path || !method || !price) {
    res.status(400).json({ error: "path, method, and price are required" });
    return;
  }
  if (!pricingConfig[path]) {
    pricingConfig[path] = {};
  }
  pricingConfig[path][method as keyof typeof pricingConfig[typeof path]] = price;
  res.json({ success: true, path, method, price });
});

export default router;
