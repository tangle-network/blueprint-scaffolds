import { Router, Request, Response } from "express";

const router = Router();

router.get("/", (req: Request, res: Response) => {
  const city = req.query.city as string || "New York";
  res.json({
    location: city,
    temperature: 72,
    unit: "fahrenheit",
    condition: "partly_cloudy",
    humidity: 45,
    wind_speed: 8,
    forecast: [
      { day: "Monday", high: 75, low: 60, condition: "sunny" },
      { day: "Tuesday", high: 70, low: 58, condition: "cloudy" },
      { day: "Wednesday", high: 68, low: 55, condition: "rain" },
    ],
    payment: req.payment ? { id: req.payment.id, amount: req.payment.amount } : null,
  });
});

router.post("/", (req: Request, res: Response) => {
  const { city, units, days } = req.body;
  res.json({
    location: city || "Unknown",
    units: units || "fahrenheit",
    days: days || 7,
    data: Array.from({ length: days || 7 }, (_, i) => ({
      day: i + 1,
      high: Math.round(65 + Math.random() * 20),
      low: Math.round(45 + Math.random() * 15),
      condition: ["sunny", "cloudy", "rain", "partly_cloudy"][Math.floor(Math.random() * 4)],
    })),
    payment: req.payment ? { id: req.payment.id, amount: req.payment.amount } : null,
  });
});

export default router;
