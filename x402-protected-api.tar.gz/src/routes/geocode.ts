import { Router, Request, Response } from "express";

const router = Router();

router.get("/", (req: Request, res: Response) => {
  const address = req.query.address as string;
  const lat = req.query.lat as string;
  const lng = req.query.lng as string;

  if (!address && (!lat || !lng)) {
    res.status(400).json({ error: "Provide 'address' or 'lat'+'lng' query parameters" });
    return;
  }

  const resultLat = lat ? parseFloat(lat) : 40.7128 + (Math.random() - 0.5) * 0.01;
  const resultLng = lng ? parseFloat(lng) : -74.006 + (Math.random() - 0.5) * 0.01;

  res.json({
    query: address || `${lat},${lng}`,
    results: [
      {
        formatted_address: address || `${resultLat.toFixed(4)}, ${resultLng.toFixed(4)}`,
        lat: resultLat,
        lng: resultLng,
        types: ["street_address"],
        confidence: 0.95,
      },
    ],
    payment: req.payment ? { id: req.payment.id, amount: req.payment.amount } : null,
  });
});

export default router;
