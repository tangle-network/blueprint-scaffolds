export interface EndpointPricing {
  path: string;
  method: string;
  price: string;
  maxAmount: string;
  token: string;
  description: string;
}

export interface PaymentRecord {
  id: string;
  request_id: string;
  path: string;
  method: string;
  payer: string;
  payee: string;
  token: string;
  amount: string;
  tx_hash: string;
  settled: boolean;
  created_at: Date;
}

export interface UsageStats {
  path: string;
  total_requests: number;
  total_revenue: string;
  unique_payers: number;
  last_accessed: Date;
}

export interface AnalyticsSummary {
  total_revenue: string;
  total_requests: number;
  total_unique_payers: number;
  endpoints: UsageStats[];
  daily_revenue: { date: string; revenue: string; requests: number }[];
}

export interface PriceConfig {
  [key: string]: {
    GET?: string;
    POST?: string;
    PUT?: string;
    DELETE?: string;
    PATCH?: string;
  };
}

export interface SettlementResult {
  success: boolean;
  txHash?: string;
  error?: string;
}
