import { Pool, PoolConfig } from "pg";
import { config } from "../config";

const poolConfig: PoolConfig = {
  connectionString: config.databaseUrl,
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
};

export const pool = new Pool(poolConfig);

export async function initializeDatabase(): Promise<void> {
  const client = await pool.connect();
  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS payments (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        request_id VARCHAR(255) NOT NULL,
        path VARCHAR(500) NOT NULL,
        method VARCHAR(10) NOT NULL,
        payer VARCHAR(255) NOT NULL,
        payee VARCHAR(255) NOT NULL,
        token VARCHAR(255) NOT NULL,
        amount VARCHAR(255) NOT NULL,
        tx_hash VARCHAR(255),
        settled BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT NOW()
      );

      CREATE INDEX IF NOT EXISTS idx_payments_path ON payments(path);
      CREATE INDEX IF NOT EXISTS idx_payments_payer ON payments(payer);
      CREATE INDEX IF NOT EXISTS idx_payments_created_at ON payments(created_at);
      CREATE INDEX IF NOT EXISTS idx_payments_settled ON payments(settled);

      CREATE TABLE IF NOT EXISTS endpoint_config (
        path VARCHAR(500) PRIMARY KEY,
        method VARCHAR(10) NOT NULL,
        price VARCHAR(255) NOT NULL,
        max_amount VARCHAR(255),
        token VARCHAR(50) DEFAULT 'USDC',
        description TEXT,
        enabled BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS usage_logs (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        payment_id UUID REFERENCES payments(id),
        path VARCHAR(500) NOT NULL,
        method VARCHAR(10) NOT NULL,
        response_code INTEGER NOT NULL,
        response_time_ms INTEGER,
        user_agent TEXT,
        ip_address VARCHAR(45),
        created_at TIMESTAMP DEFAULT NOW()
      );

      CREATE INDEX IF NOT EXISTS idx_usage_logs_path ON usage_logs(path);
      CREATE INDEX IF NOT EXISTS idx_usage_logs_created_at ON usage_logs(created_at);
    `);
    console.log("Database schema initialized");
  } finally {
    client.release();
  }
}

export async function query(text: string, params?: unknown[]) {
  const start = Date.now();
  const result = await pool.query(text, params);
  const duration = Date.now() - start;
  console.log("Executed query", { text: text.substring(0, 80), duration, rows: result.rowCount });
  return result;
}
