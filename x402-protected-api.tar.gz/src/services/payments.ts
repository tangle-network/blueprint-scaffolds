import { v4 as uuidv4 } from "uuid";
import { query } from "./database";
import { PaymentRecord, SettlementResult, AnalyticsSummary, UsageStats } from "../types";
import { config } from "../config";

export async function recordPayment(payment: Omit<PaymentRecord, "id" | "created_at">): Promise<PaymentRecord> {
  const result = await query(
    `INSERT INTO payments (request_id, path, method, payer, payee, token, amount, tx_hash, settled)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
     RETURNING *`,
    [payment.request_id, payment.path, payment.method, payment.payer, payment.payee, payment.token, payment.amount, payment.tx_hash, payment.settled]
  );
  return result.rows[0];
}

export async function getPaymentByRequestId(requestId: string): Promise<PaymentRecord | null> {
  const result = await query("SELECT * FROM payments WHERE request_id = $1", [requestId]);
  return result.rows[0] || null;
}

export async function getPaymentsByPath(path: string, limit = 100): Promise<PaymentRecord[]> {
  const result = await query("SELECT * FROM payments WHERE path = $1 ORDER BY created_at DESC LIMIT $2", [path, limit]);
  return result.rows;
}

export async function getPaymentsByPayer(payer: string, limit = 100): Promise<PaymentRecord[]> {
  const result = await query("SELECT * FROM payments WHERE payer = $1 ORDER BY created_at DESC LIMIT $2", [payer, limit]);
  return result.rows;
}

export async function settlePayment(paymentId: string, txHash: string): Promise<SettlementResult> {
  try {
    const result = await query(
      "UPDATE payments SET settled = TRUE, tx_hash = $1 WHERE id = $2 RETURNING *",
      [txHash, paymentId]
    );
    if (result.rows[0]) {
      return { success: true, txHash };
    }
    return { success: false, error: "Payment not found" };
  } catch (err) {
    return { success: false, error: (err as Error).message };
  }
}

export async function getUnsettledPayments(): Promise<PaymentRecord[]> {
  const result = await query("SELECT * FROM payments WHERE settled = FALSE ORDER BY created_at ASC");
  return result.rows;
}

export async function logUsage(
  paymentId: string | null,
  path: string,
  method: string,
  responseCode: number,
  responseTimeMs: number,
  userAgent?: string,
  ipAddress?: string
): Promise<void> {
  await query(
    `INSERT INTO usage_logs (payment_id, path, method, response_code, response_time_ms, user_agent, ip_address)
     VALUES ($1, $2, $3, $4, $5, $6, $7)`,
    [paymentId, path, method, responseCode, responseTimeMs, userAgent, ipAddress]
  );
}

export async function getAnalyticsSummary(days = 30): Promise<AnalyticsSummary> {
  const revenueResult = await query(
    `SELECT COALESCE(SUM(CAST(amount AS DECIMAL)), 0) as total_revenue, COUNT(*) as total_requests
     FROM payments WHERE created_at >= NOW() - INTERVAL '1 day' * $1`,
    [days]
  );

  const uniquePayersResult = await query(
    `SELECT COUNT(DISTINCT payer) as unique_payers FROM payments WHERE created_at >= NOW() - INTERVAL '1 day' * $1`,
    [days]
  );

  const endpointStats = await query<UsageStats>(
    `SELECT path, COUNT(*) as total_requests, COALESCE(SUM(CAST(amount AS DECIMAL)), 0)::text as total_revenue,
            COUNT(DISTINCT payer) as unique_payers, MAX(created_at) as last_accessed
     FROM payments WHERE created_at >= NOW() - INTERVAL '1 day' * $1
     GROUP BY path ORDER BY total_revenue DESC`,
    [days]
  );

  const dailyRevenue = await query(
    `SELECT DATE(created_at)::text as date, COALESCE(SUM(CAST(amount AS DECIMAL)), 0)::text as revenue, COUNT(*) as requests
     FROM payments WHERE created_at >= NOW() - INTERVAL '1 day' * $1
     GROUP BY DATE(created_at) ORDER BY date`,
    [days]
  );

  return {
    total_revenue: revenueResult.rows[0]?.total_revenue?.toString() || "0",
    total_requests: parseInt(revenueResult.rows[0]?.total_requests || "0", 10),
    total_unique_payers: parseInt(uniquePayersResult.rows[0]?.unique_payers || "0", 10),
    endpoints: endpointStats.rows,
    daily_revenue: dailyRevenue.rows,
  };
}

export { uuidv4 };
