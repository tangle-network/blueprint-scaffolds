import { Request, Response } from "express";

export function handleWeather(req: Request, res: Response): void {
  const location = (req.query.location as string) || "San Francisco";
  const conditions = ["sunny", "cloudy", "rainy", "partly cloudy", "snowy"];
  const condition = conditions[Math.floor(Math.random() * conditions.length)];
  const temperature = Math.floor(Math.random() * 40) + 30;
  const humidity = Math.floor(Math.random() * 60) + 20;
  const windSpeed = Math.floor(Math.random() * 30) + 5;

  res.json({
    location,
    condition,
    temperature,
    humidity,
    windSpeed,
    unit: "fahrenheit",
    timestamp: new Date().toISOString(),
  });
}

export function handleStock(req: Request, res: Response): void {
  const symbol = ((req.query.symbol as string) || "AAPL").toUpperCase();
  const price = (Math.random() * 500 + 50).toFixed(2);
  const change = ((Math.random() - 0.5) * 10).toFixed(2);
  const volume = Math.floor(Math.random() * 100000000);

  res.json({
    symbol,
    price: parseFloat(price),
    change: parseFloat(change),
    changePercent: ((parseFloat(change) / parseFloat(price)) * 100).toFixed(2),
    volume,
    marketCap: Math.floor(parseFloat(price) * 1e9),
    timestamp: new Date().toISOString(),
  });
}

export function handleTranslate(req: Request, res: Response): void {
  const { text, target_lang } = req.body || {};

  if (!text || !target_lang) {
    res.status(400).json({
      error: "Missing required fields: text, target_lang",
    });
    return;
  }

  const translations: Record<string, string> = {
    es: "Hola",
    fr: "Bonjour",
    de: "Hallo",
    ja: "こんにちは",
    zh: "你好",
    ko: "안녕하세요",
    pt: "Olá",
    it: "Ciao",
    ru: "Привет",
    ar: "مرحبا",
  };

  const translatedText =
    translations[target_lang.toLowerCase()] || `[Translated to ${target_lang}]: ${text}`;

  res.json({
    original_text: text,
    translated_text: translatedText,
    source_lang: "en",
    target_lang,
    timestamp: new Date().toISOString(),
  });
}

export function handleSentiment(req: Request, res: Response): void {
  const { text } = req.body || {};

  if (!text) {
    res.status(400).json({
      error: "Missing required field: text",
    });
    return;
  }

  const positiveWords = ["good", "great", "excellent", "amazing", "wonderful", "happy", "love", "best"];
  const negativeWords = ["bad", "terrible", "awful", "horrible", "sad", "hate", "worst", "poor"];
  const lowerText = text.toLowerCase();

  const positiveCount = positiveWords.filter((w) => lowerText.includes(w)).length;
  const negativeCount = negativeWords.filter((w) => lowerText.includes(w)).length;

  let sentiment: "positive" | "negative" | "neutral";
  let score: number;
  if (positiveCount > negativeCount) {
    sentiment = "positive";
    score = 0.5 + positiveCount * 0.1;
  } else if (negativeCount > positiveCount) {
    sentiment = "negative";
    score = 0.5 - negativeCount * 0.1;
  } else {
    sentiment = "neutral";
    score = 0.5;
  }

  res.json({
    text,
    sentiment,
    score: Math.min(1, Math.max(0, score)),
    confidence: 0.85 + Math.random() * 0.14,
    timestamp: new Date().toISOString(),
  });
}

export function handleGeocode(req: Request, res: Response): void {
  const address = req.query.address as string;
  const lat = req.query.lat as string;
  const lng = req.query.lng as string;

  if (address) {
    const hash = address.split("").reduce((a, c) => a + c.charCodeAt(0), 0);
    res.json({
      type: "forward",
      input: address,
      results: [
        {
          formatted_address: address,
          latitude: ((hash % 180) - 90).toFixed(6),
          longitude: (((hash * 7) % 360) - 180).toFixed(6),
          confidence: 0.9,
        },
      ],
      timestamp: new Date().toISOString(),
    });
  } else if (lat && lng) {
    res.json({
      type: "reverse",
      input: { latitude: lat, longitude: lng },
      results: [
        {
          formatted_address: `${parseFloat(lat).toFixed(4)}°N, ${parseFloat(lng).toFixed(4)}°E`,
          city: "Sample City",
          state: "Sample State",
          country: "Sample Country",
          confidence: 0.85,
        },
      ],
      timestamp: new Date().toISOString(),
    });
  } else {
    res.status(400).json({
      error: "Provide either 'address' for forward geocoding or 'lat' and 'lng' for reverse geocoding",
    });
  }
}
