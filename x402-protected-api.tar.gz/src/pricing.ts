export interface EndpointConfig {
  path: string;
  method: "GET" | "POST" | "PUT" | "DELETE";
  price: string;
  description: string;
  mimeType: string;
  network?: string;
}

export const endpointPricing: EndpointConfig[] = [
  {
    path: "/weather",
    method: "GET",
    price: "$0.001",
    description: "Current weather data for a location",
    mimeType: "application/json",
  },
  {
    path: "/stock",
    method: "GET",
    price: "$0.01",
    description: "Real-time stock quote data",
    mimeType: "application/json",
  },
  {
    path: "/translate",
    method: "POST",
    price: "$0.005",
    description: "Translation service for text content",
    mimeType: "application/json",
  },
  {
    path: "/sentiment",
    method: "POST",
    price: "$0.02",
    description: "AI sentiment analysis of text",
    mimeType: "application/json",
  },
  {
    path: "/geocode",
    method: "GET",
    price: "$0.002",
    description: "Geocoding and reverse geocoding service",
    mimeType: "application/json",
  },
];

export function getEndpointConfig(path: string, method: string): EndpointConfig | undefined {
  return endpointPricing.find((e) => e.path === path && e.method === method.toUpperCase());
}
