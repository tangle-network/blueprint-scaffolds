import type { HTTPRequestContext, RoutesConfig } from "@x402/core/server";
import type { AssetAmount, Network } from "@x402/core/types";
import type { Request } from "express";

import { config, tokenCatalog } from "./config.js";

type EndpointDescriptor = {
  name: string;
  routePattern: string;
  method: "GET" | "POST";
  path: string;
  description: string;
  minUsd: number;
  maxUsd: number;
  priceUsd: (input: Request | HTTPRequestContext) => number;
};

type PaymentOption = {
  scheme: string;
  payTo: string;
  price: AssetAmount;
  network: Network;
  maxTimeoutSeconds?: number;
  extra?: Record<string, unknown>;
};

type QuotedPrice = {
  usd: number;
  usdc: AssetAmount;
  weth: AssetAmount;
};

const centsToUsd = (value: number): number => Math.round(value * 1000) / 1000;

const toTokenUnits = (amount: number, decimals: number): string => {
  const normalized = amount.toFixed(decimals);
  const [whole, fraction = ""] = normalized.split(".");
  const paddedFraction = fraction.padEnd(decimals, "0").slice(0, decimals);
  const units = `${whole}${paddedFraction}`.replace(/^0+(\d)/, "$1");
  return units === "" ? "0" : units;
};

const clampPrice = (value: number, minUsd: number, maxUsd: number): number => {
  return Math.min(Math.max(value, minUsd), maxUsd);
};

const quotePrice = (usd: number): QuotedPrice => {
  const wethAmount = usd / config.ETH_USD_PRICE;

  return {
    usd,
    usdc: {
      asset: tokenCatalog.usdc.asset,
      amount: toTokenUnits(usd, tokenCatalog.usdc.decimals),
      extra: {
        tokenSymbol: tokenCatalog.usdc.symbol
      }
    },
    weth: {
      asset: tokenCatalog.weth.asset,
      amount: toTokenUnits(wethAmount, tokenCatalog.weth.decimals),
      extra: {
        tokenSymbol: "ETH",
        settlementAsset: tokenCatalog.weth.symbol
      }
    }
  };
};

export const endpointCatalog: EndpointDescriptor[] = [
  {
    name: "weather",
    routePattern: "GET /api/weather",
    method: "GET",
    path: "/api/weather",
    description: "Premium weather snapshot with route-level micropayment protection.",
    minUsd: 0.001,
    maxUsd: 0.01,
    priceUsd: () => 0.001
  },
  {
    name: "fx",
    routePattern: "GET /api/fx",
    method: "GET",
    path: "/api/fx",
    description: "FX snapshot with dynamic pricing based on lookback window.",
    minUsd: 0.002,
    maxUsd: 0.015,
    priceUsd: (input) => {
      const days =
        "query" in input
          ? Number(input.query.days ?? 1)
          : Number(input.adapter.getQueryParam?.("days") ?? 1);
      return centsToUsd(0.002 + Math.min(Math.max(days, 1), 7) * 0.001);
    }
  },
  {
    name: "insights",
    routePattern: "POST /api/insights",
    method: "POST",
    path: "/api/insights",
    description: "Synthetic product intelligence priced by request complexity.",
    minUsd: 0.003,
    maxUsd: 0.02,
    priceUsd: (input) => {
      const body = "body" in input ? input.body : input.adapter.getBody?.();
      const prompt = typeof body?.prompt === "string" ? body.prompt : "";
      return centsToUsd(0.003 + Math.min(prompt.length, 800) / 100000);
    }
  }
];

const buildTokenOption = (
  input: Request | HTTPRequestContext,
  endpoint: EndpointDescriptor,
  token: "usdc" | "weth"
): PaymentOption => {
  const priceUsd = clampPrice(endpoint.priceUsd(input), endpoint.minUsd, endpoint.maxUsd);
  const quoted = quotePrice(priceUsd);
  const assetAmount = token === "usdc" ? quoted.usdc : quoted.weth;

  return {
    scheme: "exact",
    network: config.BASE_NETWORK as Network,
    payTo: config.PAY_TO_ADDRESS,
    price: assetAmount,
    maxTimeoutSeconds: 120,
    extra: {
      endpoint: endpoint.name,
      routePattern: endpoint.routePattern,
      minUsd: endpoint.minUsd,
      maxUsd: endpoint.maxUsd,
      quotedUsd: quoted.usd,
      acceptedToken: token === "usdc" ? "USDC" : "ETH"
    }
  };
};

export const buildRouteConfig = (request: Request): RoutesConfig => {
  return Object.fromEntries(
    endpointCatalog.map((endpoint) => [
      endpoint.routePattern,
      {
        accepts: [
          buildTokenOption(request, endpoint, "usdc"),
          buildTokenOption(request, endpoint, "weth")
        ],
        description: endpoint.description,
        mimeType: "application/json",
        unpaidResponseBody: () => ({
          contentType: "application/json",
          body: {
            error: "payment_required",
            message: `x402 payment required for ${endpoint.path}`,
            endpoint: endpoint.name,
            pricing: {
              minUsd: endpoint.minUsd,
              maxUsd: endpoint.maxUsd
            }
          }
        }),
        extensions: {
          bazaar: {
            discoverable: true,
            category: "api",
            tags: ["x402", endpoint.name, "micropayments"]
          }
        }
      }
    ])
  );
};

export const createRoutesConfig = (): RoutesConfig => {
  return Object.fromEntries(
    endpointCatalog.map((endpoint) => [
      endpoint.routePattern,
      {
        accepts: [
          {
            scheme: "exact",
            network: config.BASE_NETWORK as Network,
            payTo: config.PAY_TO_ADDRESS,
            price: async (context: HTTPRequestContext) => buildTokenOption(context, endpoint, "usdc").price,
            maxTimeoutSeconds: 120,
            extra: {
              endpoint: endpoint.name,
              routePattern: endpoint.routePattern,
              minUsd: endpoint.minUsd,
              maxUsd: endpoint.maxUsd,
              acceptedToken: "USDC"
            }
          },
          {
            scheme: "exact",
            network: config.BASE_NETWORK as Network,
            payTo: config.PAY_TO_ADDRESS,
            price: async (context: HTTPRequestContext) => buildTokenOption(context, endpoint, "weth").price,
            maxTimeoutSeconds: 120,
            extra: {
              endpoint: endpoint.name,
              routePattern: endpoint.routePattern,
              minUsd: endpoint.minUsd,
              maxUsd: endpoint.maxUsd,
              acceptedToken: "ETH"
            }
          }
        ],
        description: endpoint.description,
        mimeType: "application/json",
        unpaidResponseBody: () => ({
          contentType: "application/json",
          body: {
            error: "payment_required",
            message: `x402 payment required for ${endpoint.path}`,
            endpoint: endpoint.name,
            pricing: {
              minUsd: endpoint.minUsd,
              maxUsd: endpoint.maxUsd
            }
          }
        }),
        extensions: {
          bazaar: {
            discoverable: true,
            category: "api",
            tags: ["x402", endpoint.name, "micropayments"]
          }
        }
      }
    ])
  );
};

export const getEndpointByRoutePattern = (routePattern: string): EndpointDescriptor | undefined => {
  return endpointCatalog.find((endpoint) => endpoint.routePattern === routePattern);
};
