import express, { type NextFunction, type Request, type Response } from "express";
import { HTTPFacilitatorClient, x402HTTPResourceServer, x402ResourceServer } from "@x402/core/server";
import type { RouteConfig } from "@x402/core/server";
import type { Network, PaymentRequirements } from "@x402/core/types";
import { paymentMiddlewareFromHTTPServer } from "@x402/express";
import { ExactEvmScheme } from "@x402/evm/exact/server";

import { config, tokenCatalog } from "./config.js";
import { AnalyticsRepository } from "./database.js";
import { buildRouteConfig, createRoutesConfig, endpointCatalog } from "./pricing.js";

type RequestWithRoutePattern = Request & {
  x402RoutePattern?: string;
};

type PublicPaymentOption = {
  scheme: string;
  network: Network;
  price: {
    asset: string;
    amount: string;
  };
  payTo: string;
  maxTimeoutSeconds?: number;
  extra?: Record<string, unknown>;
};

const app = express();
const analytics = new AnalyticsRepository(config.DATABASE_URL);

app.set("trust proxy", true);
app.use(express.json({ limit: "256kb" }));

const facilitatorClient = new HTTPFacilitatorClient({
  url: config.FACILITATOR_URL
});

const resourceServer = new x402ResourceServer(facilitatorClient).register(
  config.BASE_NETWORK as `${string}:${string}`,
  new ExactEvmScheme()
);

const buildRequestMetadata = (request: Request) => ({
  method: request.method,
  path: request.path,
  routePattern: (request as RequestWithRoutePattern).x402RoutePattern ?? `${request.method} ${request.path}`,
  clientIp: request.ip ?? null,
  userAgent: request.get("user-agent") ?? null
});

const attachLifecycleTracking = (): void => {
  resourceServer
    .onAfterVerify(async (context) => {
      await analytics.recordVerification({
        method: "UNKNOWN",
        path: "unknown",
        routePattern:
          typeof context.requirements.extra.routePattern === "string"
            ? context.requirements.extra.routePattern
            : `${context.requirements.network}:${context.requirements.asset}`,
        network: context.requirements.network,
        asset: context.requirements.asset,
        amount: context.requirements.amount,
        payer: context.result.payer ?? null,
        clientIp: null,
        userAgent: null
      });
    })
    .onAfterSettle(async (context) => {
      const transportRequest = context.transportContext as { request?: { path?: string; method?: string; routePattern?: string } } | undefined;
      await analytics.recordSettlement({
        method: transportRequest?.request?.method ?? "UNKNOWN",
        path: transportRequest?.request?.path ?? "unknown",
        routePattern: transportRequest?.request?.routePattern ?? `${context.requirements.network}:${context.requirements.asset}`,
        network: context.requirements.network,
        asset: context.requirements.asset,
        amount: context.requirements.amount,
        payer: context.result.payer ?? null,
        transaction: context.result.transaction,
        success: context.result.success,
        errorReason: context.result.errorReason ?? null,
        errorMessage: context.result.errorMessage ?? null,
        clientIp: null,
        userAgent: null
      });
    });
};

attachLifecycleTracking();

const httpServer = new x402HTTPResourceServer(resourceServer, createRoutesConfig());

app.use((request, _response, next) => {
  const protectedEndpoint = endpointCatalog.find(
    (endpoint) => endpoint.method === request.method && endpoint.path === request.path
  );

  if (protectedEndpoint) {
    (request as RequestWithRoutePattern).x402RoutePattern = protectedEndpoint.routePattern;
    void analytics.recordUsageAttempt(buildRequestMetadata(request));
  }

  next();
});

app.use(paymentMiddlewareFromHTTPServer(httpServer));

const requireAdmin = (request: Request, response: Response, next: NextFunction) => {
  if (request.get("x-admin-token") !== config.ADMIN_API_TOKEN) {
    response.status(401).json({
      error: "unauthorized"
    });
    return;
  }

  next();
};

const formatRequirements = (requirements: PaymentRequirements) => ({
  network: requirements.network,
  asset: requirements.asset,
  amount: requirements.amount,
  payTo: requirements.payTo,
  maxTimeoutSeconds: requirements.maxTimeoutSeconds,
  token:
    requirements.asset.toLowerCase() === tokenCatalog.usdc.asset.toLowerCase()
      ? "USDC"
      : requirements.asset.toLowerCase() === tokenCatalog.weth.asset.toLowerCase()
        ? "ETH"
        : "UNKNOWN",
  quotedUsd: requirements.extra.quotedUsd ?? null
});

app.get("/health", (_request, response) => {
  response.json({
    status: "ok",
    network: config.BASE_NETWORK,
    facilitator: config.FACILITATOR_URL
  });
});

app.get("/pricing", (request, response) => {
  const routeConfig = buildRouteConfig(request);
  const routeConfigByPattern = routeConfig as Record<string, RouteConfig>;

  response.json({
    facilitator: config.FACILITATOR_URL,
    network: config.BASE_NETWORK,
    payTo: config.PAY_TO_ADDRESS,
    endpoints: endpointCatalog.map((endpoint) => {
      const configForEndpoint = routeConfigByPattern[endpoint.routePattern];
      const accepts = (Array.isArray(configForEndpoint.accepts)
        ? configForEndpoint.accepts
        : [configForEndpoint.accepts]) as PublicPaymentOption[];

      return {
        name: endpoint.name,
        method: endpoint.method,
        path: endpoint.path,
        description: endpoint.description,
        pricing: {
          minUsd: endpoint.minUsd,
          maxUsd: endpoint.maxUsd
        },
        accepts: accepts.map((option) =>
          formatRequirements({
            scheme: option.scheme,
            network: option.network,
            asset: option.price.asset,
            amount: option.price.amount,
            payTo: option.payTo,
            maxTimeoutSeconds: option.maxTimeoutSeconds ?? 120,
            extra: option.extra ?? {}
          })
        )
      };
    })
  });
});

app.get("/api/weather", (request, response) => {
  response.json({
    location: String(request.query.location ?? "San Francisco, CA"),
    forecast: {
      condition: "sunny",
      temperatureF: 72,
      humidityPct: 44,
      windMph: 7
    },
    billedRoute: (request as RequestWithRoutePattern).x402RoutePattern ?? "GET /api/weather"
  });
});

app.get("/api/fx", (request, response) => {
  const base = String(request.query.base ?? "USD").toUpperCase();
  const quote = String(request.query.quote ?? "EUR").toUpperCase();
  const days = Math.min(Math.max(Number(request.query.days ?? 1), 1), 7);

  response.json({
    pair: `${base}/${quote}`,
    days,
    quotes: Array.from({ length: days }, (_value, index) => ({
      dayOffset: index,
      rate: Number((0.91 + index * 0.0025).toFixed(4))
    })),
    billedRoute: (request as RequestWithRoutePattern).x402RoutePattern ?? "GET /api/fx"
  });
});

app.post("/api/insights", (request, response) => {
  const prompt = typeof request.body?.prompt === "string" ? request.body.prompt : "";

  response.json({
    promptLength: prompt.length,
    insight: {
      summary: "Synthetic premium insight generated for a paid request.",
      urgency: prompt.length > 300 ? "high" : "normal",
      recommendation: "Route this signal into downstream scoring or enrichment pipelines."
    },
    billedRoute: (request as RequestWithRoutePattern).x402RoutePattern ?? "POST /api/insights"
  });
});

app.get("/analytics/summary", requireAdmin, async (_request, response, next) => {
  try {
    const overview = await analytics.getRevenueOverview();
    response.json({
      ...overview,
      assets: {
        usdc: tokenCatalog.usdc.asset,
        weth: tokenCatalog.weth.asset
      }
    });
  } catch (error) {
    next(error);
  }
});

app.use((error: unknown, _request: Request, response: Response, _next: NextFunction) => {
  const message = error instanceof Error ? error.message : "unknown_error";
  response.status(500).json({
    error: "internal_server_error",
    message
  });
});

const start = async (): Promise<void> => {
  await analytics.initialize();
  await httpServer.initialize();

  app.listen(config.PORT, () => {
    console.log(`x402 API listening on http://localhost:${config.PORT}`);
  });
};

void start();
