import { config } from "dotenv";
import express, { Request, Response, NextFunction } from "express";
import { paymentMiddleware, x402ResourceServer } from "@x402/express";
import type { RouteConfig } from "@x402/core/server";
import { ExactEvmScheme } from "@x402/evm/exact/server";
import { HTTPFacilitatorClient } from "@x402/core/server";
import { NETWORK_BASE_MAINNET, DEFAULT_FACILITATOR_URL, DEFAULT_PORT } from "./constants.js";
import { endpointPricing } from "./pricing.js";
import { usageTracker } from "./analytics.js";
import {
  handleWeather,
  handleStock,
  handleTranslate,
  handleSentiment,
  handleGeocode,
} from "./services.js";

config();

const evmAddress = (process.env.EVM_ADDRESS || "0x0000000000000000000000000000000000000000") as `0x${string}`;
const facilitatorUrl = process.env.FACILITATOR_URL || DEFAULT_FACILITATOR_URL;
const port = parseInt(process.env.PORT || String(DEFAULT_PORT), 10);

const facilitatorClient = new HTTPFacilitatorClient({ url: facilitatorUrl });

const resourceServer = new x402ResourceServer(facilitatorClient).register(
  NETWORK_BASE_MAINNET,
  new ExactEvmScheme(),
);

const routes: Record<string, RouteConfig> = {};
for (const ep of endpointPricing) {
  routes[`${ep.method} ${ep.path}`] = {
    accepts: {
      scheme: "exact",
      price: ep.price,
      network: NETWORK_BASE_MAINNET,
      payTo: evmAddress,
      maxTimeoutSeconds: 300,
    },
    description: ep.description,
    mimeType: ep.mimeType,
  };
}

const app = express();

app.use(express.json());

app.use(paymentMiddleware(routes, resourceServer));

app.use((req: Request, res: Response, next: NextFunction) => {
  const paymentResponseHeader = res.getHeader("PAYMENT-RESPONSE");
  if (paymentResponseHeader && typeof paymentResponseHeader === "string") {
    try {
      const decoded = JSON.parse(Buffer.from(paymentResponseHeader, "base64").toString("utf-8"));
      if (decoded.success) {
        usageTracker.recordUsage({
          endpoint: req.path,
          method: req.method,
          payer: decoded.payer || "unknown",
          network: decoded.network || "unknown",
          amount: decoded.requirements?.amount || "0",
          asset: decoded.requirements?.asset || "unknown",
          txHash: decoded.transaction || "unknown",
        });
      }
    } catch {
      // ignore parse errors
    }
  }
  next();
});

app.get("/weather", handleWeather);
app.get("/stock", handleStock);
app.post("/translate", handleTranslate);
app.post("/sentiment", handleSentiment);
app.get("/geocode", handleGeocode);

app.get("/analytics/usage", (_req: Request, res: Response) => {
  const limit = parseInt(String(_req.query.limit), 10) || 100;
  const offset = parseInt(String(_req.query.offset), 10) || 0;
  res.json({
    records: usageTracker.getUsageHistory(limit, offset),
    total: usageTracker.getRevenueSummary().totalRequests,
  });
});

app.get("/analytics/revenue", (_req: Request, res: Response) => {
  res.json(usageTracker.getRevenueSummary());
});

app.get("/analytics/endpoint/:path", (req: Request, res: Response) => {
  const endpoint = "/" + req.params.path;
  res.json({
    endpoint,
    records: usageTracker.getEndpointUsage(endpoint),
  });
});

app.get("/analytics/payer/:address", (req: Request, res: Response) => {
  const payer = String(req.params.address);
  res.json({
    payer,
    records: usageTracker.getPayerUsage(payer),
  });
});

app.get("/pricing", (_req: Request, res: Response) => {
  res.json({
    network: NETWORK_BASE_MAINNET,
    facilitator: facilitatorUrl,
    payTo: evmAddress,
    endpoints: endpointPricing.map((ep) => ({
      path: ep.path,
      method: ep.method,
      price: ep.price,
      description: ep.description,
    })),
  });
});

app.get("/health", (_req: Request, res: Response) => {
  res.json({
    status: "ok",
    service: "x402-monetized-api",
    version: "1.0.0",
    network: NETWORK_BASE_MAINNET,
    facilitator: facilitatorUrl,
    endpoints: endpointPricing.length,
    timestamp: new Date().toISOString(),
  });
});

app.use((_req: Request, res: Response) => {
  res.status(404).json({
    error: "Not found",
    availableEndpoints: ["/weather", "/stock", "/translate", "/sentiment", "/geocode"],
    docs: "/pricing",
  });
});

app.listen(port, () => {
  console.log(`x402 Monetized API Server`);
  console.log(`Listening on http://localhost:${port}`);
  console.log(`Network: ${NETWORK_BASE_MAINNET} (Base Mainnet)`);
  console.log(`Facilitator: ${facilitatorUrl}`);
  console.log(`Payment address: ${evmAddress}`);
  console.log(`Protected endpoints:`);
  for (const ep of endpointPricing) {
    console.log(`  ${ep.method} ${ep.path} - ${ep.price} - ${ep.description}`);
  }
  console.log(`Analytics: http://localhost:${port}/analytics/revenue`);
  console.log(`Pricing: http://localhost:${port}/pricing`);
  console.log(`Health: http://localhost:${port}/health`);
});

export { app, resourceServer };
