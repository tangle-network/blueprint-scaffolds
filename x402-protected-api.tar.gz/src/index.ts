import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import { config } from "./config";
import { initializeDatabase } from "./services/database";
import { x402PaymentMiddleware, verifySettlement } from "./middleware/payment";
import { requestLogger } from "./middleware/auth";
import indexRoutes from "./routes/index";
import weatherRoutes from "./routes/weather";
import translateRoutes from "./routes/translate";
import sentimentRoutes from "./routes/sentiment";
import geocodeRoutes from "./routes/geocode";
import analyticsRoutes from "./routes/analytics";
import premiumRoutes from "./routes/premium";

async function main(): Promise<void> {
  const app = express();

  app.use(helmet());
  app.use(cors());
  app.use(express.json());
  app.use(morgan("combined"));
  app.use(requestLogger);

  app.get("/health", (_req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  app.use("/", indexRoutes);

  app.use(x402PaymentMiddleware);
  app.use(verifySettlement);

  app.use("/weather", weatherRoutes);
  app.use("/translate", translateRoutes);
  app.use("/sentiment", sentimentRoutes);
  app.use("/geocode", geocodeRoutes);
  app.use("/analytics", analyticsRoutes);
  app.use("/premium", premiumRoutes);

  app.use((_req, res) => {
    res.status(404).json({ error: "Not Found" });
  });

  app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    console.error("Unhandled error:", err);
    res.status(500).json({ error: "Internal Server Error" });
  });

  try {
    await initializeDatabase();
    console.log("Database initialized successfully");
  } catch (err) {
    console.warn("Database initialization failed (running without DB):", (err as Error).message);
  }

  app.listen(config.port, () => {
    console.log(`x402 API service running on port ${config.port}`);
    console.log(`Network: ${config.network}`);
    console.log(`Facilitator: ${config.facilitatorUrl}`);
  });
}

main().catch((err) => {
  console.error("Fatal error:", err);
  process.exit(1);
});
