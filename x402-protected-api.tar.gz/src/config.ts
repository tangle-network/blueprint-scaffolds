import "dotenv/config";

import { z } from "zod";

const envSchema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  PORT: z.coerce.number().int().min(1).max(65535).default(4021),
  DATABASE_URL: z.string().min(1),
  PAY_TO_ADDRESS: z.string().regex(/^0x[a-fA-F0-9]{40}$/),
  ADMIN_API_TOKEN: z.string().min(16),
  FACILITATOR_URL: z.string().url().default("https://api.cdp.coinbase.com/platform/v2/x402"),
  BASE_NETWORK: z.string().default("eip155:8453"),
  USDC_BASE_ASSET: z.string().regex(/^0x[a-fA-F0-9]{40}$/),
  WETH_BASE_ASSET: z.string().regex(/^0x[a-fA-F0-9]{40}$/),
  ETH_USD_PRICE: z.coerce.number().positive().default(3500)
});

const parsedEnv = envSchema.safeParse(process.env);

if (!parsedEnv.success) {
  const details = parsedEnv.error.issues
    .map((issue) => `${issue.path.join(".") || "env"}: ${issue.message}`)
    .join("; ");
  throw new Error(`Invalid environment configuration: ${details}`);
}

export const config = parsedEnv.data;

export const tokenCatalog = {
  usdc: {
    symbol: "USDC",
    asset: config.USDC_BASE_ASSET,
    decimals: 6
  },
  weth: {
    symbol: "WETH",
    asset: config.WETH_BASE_ASSET,
    decimals: 18
  }
} as const;
