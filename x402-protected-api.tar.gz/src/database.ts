import { Pool } from "pg";

export type UsageAttempt = {
  method: string;
  path: string;
  routePattern: string;
  clientIp: string | null;
  userAgent: string | null;
};

export type VerificationEvent = {
  method: string;
  path: string;
  routePattern: string;
  network: string;
  asset: string;
  amount: string;
  payer: string | null;
  clientIp: string | null;
  userAgent: string | null;
};

export type SettlementEvent = VerificationEvent & {
  transaction: string;
  success: boolean;
  errorReason: string | null;
  errorMessage: string | null;
};

export type RevenueSummaryRow = {
  route_pattern: string;
  request_count: number;
  settlement_count: number;
  total_amount: string;
  asset: string;
  network: string;
  last_transaction_at: string | null;
};

export type RevenueOverview = {
  totals: {
    requests: number;
    settlements: number;
    uniquePayers: number;
  };
  byEndpoint: RevenueSummaryRow[];
};

export class AnalyticsRepository {
  private readonly pool: Pool;

  public constructor(connectionString: string) {
    this.pool = new Pool({
      connectionString
    });
  }

  public async initialize(): Promise<void> {
    await this.pool.query(`
      CREATE TABLE IF NOT EXISTS usage_attempts (
        id BIGSERIAL PRIMARY KEY,
        method TEXT NOT NULL,
        path TEXT NOT NULL,
        route_pattern TEXT NOT NULL,
        client_ip TEXT,
        user_agent TEXT,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
    `);

    await this.pool.query(`
      CREATE TABLE IF NOT EXISTS payment_verifications (
        id BIGSERIAL PRIMARY KEY,
        method TEXT NOT NULL,
        path TEXT NOT NULL,
        route_pattern TEXT NOT NULL,
        network TEXT NOT NULL,
        asset TEXT NOT NULL,
        amount NUMERIC(78, 0) NOT NULL,
        payer TEXT,
        client_ip TEXT,
        user_agent TEXT,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
    `);

    await this.pool.query(`
      CREATE TABLE IF NOT EXISTS payment_settlements (
        id BIGSERIAL PRIMARY KEY,
        method TEXT NOT NULL,
        path TEXT NOT NULL,
        route_pattern TEXT NOT NULL,
        network TEXT NOT NULL,
        asset TEXT NOT NULL,
        amount NUMERIC(78, 0) NOT NULL,
        payer TEXT,
        transaction_hash TEXT NOT NULL,
        success BOOLEAN NOT NULL,
        error_reason TEXT,
        error_message TEXT,
        client_ip TEXT,
        user_agent TEXT,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        UNIQUE (transaction_hash, route_pattern)
      );
    `);
  }

  public async recordUsageAttempt(event: UsageAttempt): Promise<void> {
    await this.pool.query(
      `
        INSERT INTO usage_attempts (method, path, route_pattern, client_ip, user_agent)
        VALUES ($1, $2, $3, $4, $5)
      `,
      [event.method, event.path, event.routePattern, event.clientIp, event.userAgent]
    );
  }

  public async recordVerification(event: VerificationEvent): Promise<void> {
    await this.pool.query(
      `
        INSERT INTO payment_verifications (
          method,
          path,
          route_pattern,
          network,
          asset,
          amount,
          payer,
          client_ip,
          user_agent
        )
        VALUES ($1, $2, $3, $4, $5, $6::numeric, $7, $8, $9)
      `,
      [
        event.method,
        event.path,
        event.routePattern,
        event.network,
        event.asset,
        event.amount,
        event.payer,
        event.clientIp,
        event.userAgent
      ]
    );
  }

  public async recordSettlement(event: SettlementEvent): Promise<void> {
    await this.pool.query(
      `
        INSERT INTO payment_settlements (
          method,
          path,
          route_pattern,
          network,
          asset,
          amount,
          payer,
          transaction_hash,
          success,
          error_reason,
          error_message,
          client_ip,
          user_agent
        )
        VALUES ($1, $2, $3, $4, $5, $6::numeric, $7, $8, $9, $10, $11, $12, $13)
        ON CONFLICT (transaction_hash, route_pattern) DO UPDATE
        SET
          success = EXCLUDED.success,
          error_reason = EXCLUDED.error_reason,
          error_message = EXCLUDED.error_message,
          client_ip = EXCLUDED.client_ip,
          user_agent = EXCLUDED.user_agent
      `,
      [
        event.method,
        event.path,
        event.routePattern,
        event.network,
        event.asset,
        event.amount,
        event.payer,
        event.transaction,
        event.success,
        event.errorReason,
        event.errorMessage,
        event.clientIp,
        event.userAgent
      ]
    );
  }

  public async getRevenueOverview(): Promise<RevenueOverview> {
    const [totalsResult, byEndpointResult] = await Promise.all([
      this.pool.query<{
        requests: string;
        settlements: string;
        unique_payers: string;
      }>(`
        SELECT
          (SELECT COUNT(*)::text FROM usage_attempts) AS requests,
          (SELECT COUNT(*)::text FROM payment_settlements WHERE success = TRUE) AS settlements,
          (
            SELECT COUNT(DISTINCT payer)::text
            FROM payment_settlements
            WHERE success = TRUE AND payer IS NOT NULL
          ) AS unique_payers
      `),
      this.pool.query<RevenueSummaryRow>(`
        SELECT
          route_pattern,
          COUNT(*) FILTER (WHERE success = TRUE)::int AS settlement_count,
          COUNT(*)::int AS request_count,
          COALESCE(SUM(amount), 0)::text AS total_amount,
          asset,
          network,
          MAX(created_at)::text AS last_transaction_at
        FROM payment_settlements
        GROUP BY route_pattern, asset, network
        ORDER BY settlement_count DESC, route_pattern ASC
      `)
    ]);

    const totalsRow = totalsResult.rows[0];

    return {
      totals: {
        requests: Number(totalsRow?.requests ?? 0),
        settlements: Number(totalsRow?.settlements ?? 0),
        uniquePayers: Number(totalsRow?.unique_payers ?? 0)
      },
      byEndpoint: byEndpointResult.rows
    };
  }

  public async close(): Promise<void> {
    await this.pool.end();
  }
}
