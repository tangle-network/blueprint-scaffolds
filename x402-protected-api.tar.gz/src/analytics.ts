export interface UsageRecord {
  id: string;
  endpoint: string;
  method: string;
  payer: string;
  network: string;
  amount: string;
  asset: string;
  txHash: string;
  timestamp: number;
}

export interface RevenueSummary {
  totalRequests: number;
  totalRevenue: string;
  byEndpoint: Record<string, { requests: number; revenue: string }>;
  byNetwork: Record<string, { requests: number; revenue: string }>;
  byPayer: Record<string, { requests: number; revenue: string }>;
}

class UsageTracker {
  private records: UsageRecord[] = [];
  private idCounter = 0;

  recordUsage(entry: Omit<UsageRecord, "id" | "timestamp">): UsageRecord {
    const record: UsageRecord = {
      ...entry,
      id: `usage_${++this.idCounter}`,
      timestamp: Date.now(),
    };
    this.records.push(record);
    return record;
  }

  getUsageHistory(limit = 100, offset = 0): UsageRecord[] {
    return this.records.slice(offset, offset + limit);
  }

  getRevenueSummary(): RevenueSummary {
    const summary: RevenueSummary = {
      totalRequests: this.records.length,
      totalRevenue: "0",
      byEndpoint: {},
      byNetwork: {},
      byPayer: {},
    };

    for (const record of this.records) {
      const amount = BigInt(record.amount);
      summary.totalRevenue = (BigInt(summary.totalRevenue) + amount).toString();

      if (!summary.byEndpoint[record.endpoint]) {
        summary.byEndpoint[record.endpoint] = { requests: 0, revenue: "0" };
      }
      summary.byEndpoint[record.endpoint].requests++;
      summary.byEndpoint[record.endpoint].revenue = (
        BigInt(summary.byEndpoint[record.endpoint].revenue) + amount
      ).toString();

      if (!summary.byNetwork[record.network]) {
        summary.byNetwork[record.network] = { requests: 0, revenue: "0" };
      }
      summary.byNetwork[record.network].requests++;
      summary.byNetwork[record.network].revenue = (
        BigInt(summary.byNetwork[record.network].revenue) + amount
      ).toString();

      if (!summary.byPayer[record.payer]) {
        summary.byPayer[record.payer] = { requests: 0, revenue: "0" };
      }
      summary.byPayer[record.payer].requests++;
      summary.byPayer[record.payer].revenue = (
        BigInt(summary.byPayer[record.payer].revenue) + amount
      ).toString();
    }

    return summary;
  }

  getEndpointUsage(endpoint: string): UsageRecord[] {
    return this.records.filter((r) => r.endpoint === endpoint);
  }

  getPayerUsage(payer: string): UsageRecord[] {
    return this.records.filter((r) => r.payer === payer);
  }

  clear(): void {
    this.records = [];
    this.idCounter = 0;
  }
}

export const usageTracker = new UsageTracker();
