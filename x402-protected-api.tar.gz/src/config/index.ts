import dotenv from "dotenv";
import path from "path";
import { PriceConfig } from "../types";

dotenv.config({ path: path.resolve(process.cwd(), ".env") });

export const config = {
  port: parseInt(process.env.PORT || "3000", 10),
  databaseUrl: process.env.DATABASE_URL || "postgresql://user:password@localhost:5432/x402_api",
  facilitatorUrl: process.env.FACILITATOR_URL || "https://facilitator.x402.org",
  network: process.env.NETWORK || "base",
  settlementAddress: process.env.SETTLEMENT_ADDRESS || "0x0000000000000000000000000000000000000000",
  adminApiKey: process.env.ADMIN_API_KEY || "change-me-in-production",
};

export const pricingConfig: PriceConfig = {
  "/weather": {
    GET: "$0.001",
    POST: "$0.002",
  },
  "/sentiment": {
    GET: "$0.005",
    POST: "$0.01",
  },
  "/translate": {
    POST: "$0.003",
  },
  "/geocode": {
    GET: "$0.002",
  },
  "/analytics/usage": {
    GET: "$0.01",
  },
  "/premium/*": {
    GET: "$0.05",
    POST: "$0.10",
    PUT: "$0.08",
    DELETE: "$0.08",
  },
};

export const supportedTokens = [
  { symbol: "USDC", address: "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913", decimals: 6 },
  { symbol: "ETH", address: "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE", decimals: 18 },
];

export function getPriceForRoute(routePath: string, method: string): string | null {
  if (pricingConfig[routePath]) {
    return pricingConfig[routePath][method as keyof typeof pricingConfig[typeof routePath]] || null;
  }

  for (const pattern of Object.keys(pricingConfig)) {
    if (pattern.includes("*")) {
      const regex = new RegExp("^" + pattern.replace(/\*/g, ".*") + "$");
      if (regex.test(routePath)) {
        return pricingConfig[pattern][method as keyof typeof pricingConfig[typeof pattern]] || null;
      }
    }
  }

  return null;
}
