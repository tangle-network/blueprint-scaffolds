import { Request, Response, NextFunction } from "express";
import { config, getPriceForRoute } from "../config";
import { recordPayment, logUsage, uuidv4 } from "../services/payments";
import { PaymentRecord } from "../types";

interface X402PaymentPayload {
  x402Version?: number;
  scheme?: string;
  network?: string;
  payload?: {
    signature?: string;
    authorization?: {
      from?: string;
      to?: string;
      value?: string;
      token?: string;
    };
  };
}

declare global {
  namespace Express {
    interface Request {
      payment?: PaymentRecord;
      paymentPayload?: X402PaymentPayload;
    }
  }
}

function parseAmount(priceString: string): string {
  const match = priceString.match(/\$?([\d.]+)/);
  return match ? match[1] : "0";
}

export async function x402PaymentMiddleware(req: Request, res: Response, next: NextFunction): Promise<void> {
  const startTime = Date.now();
  const price = getPriceForRoute(req.path, req.method);

  if (!price) {
    next();
    return;
  }

  const paymentHeader = req.headers["x-payment"] as string | undefined;
  const paymentPayload: X402PaymentPayload = paymentHeader ? JSON.parse(paymentHeader) : {};

  if (!paymentHeader || !paymentPayload.payload?.authorization) {
    res.status(402).json({
      error: "Payment Required",
      x402Version: 1,
      accepts: {
        "x402": {
          scheme: "exact",
          network: config.network,
          maxAmountRequired: parseAmount(price),
          asset: "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913",
          extra: {
            name: "USDC",
            version: "2",
          },
          payTo: config.settlementAddress,
          resource: req.path,
          description: `Access to ${req.path} costs ${price}`,
        },
      },
    });
    await logUsage(null, req.path, req.method, 402, Date.now() - startTime, req.headers["user-agent"], req.ip);
    return;
  }

  const auth = paymentPayload.payload.authorization;
  const requiredAmount = parseAmount(price);
  const paidAmount = auth.value || "0";

  if (parseFloat(paidAmount) < parseFloat(requiredAmount)) {
    res.status(402).json({
      error: "Insufficient Payment",
      required: requiredAmount,
      received: paidAmount,
    });
    await logUsage(null, req.path, req.method, 402, Date.now() - startTime, req.headers["user-agent"], req.ip);
    return;
  }

  const requestId = uuidv4();
  const payment = await recordPayment({
    request_id: requestId,
    path: req.path,
    method: req.method,
    payer: auth.from || "unknown",
    payee: auth.to || config.settlementAddress,
    token: auth.token || "USDC",
    amount: paidAmount,
    tx_hash: paymentPayload.payload.signature || "pending",
    settled: false,
  });

  req.payment = payment;
  req.paymentPayload = paymentPayload;

  res.setHeader("X-Payment-ID", payment.id);
  res.setHeader("X-Payment-Amount", paidAmount);

  const originalEnd = res.end.bind(res);
  res.end = function (...args: unknown[]) {
    logUsage(
      payment.id,
      req.path,
      req.method,
      res.statusCode,
      Date.now() - startTime,
      req.headers["user-agent"],
      req.ip
    );
    return originalEnd(...args);
  } as typeof res.end;

  next();
}

export async function verifySettlement(req: Request, res: Response, next: NextFunction): Promise<void> {
  if (!req.payment) {
    next();
    return;
  }

  try {
    const facilitatorUrl = `${config.facilitatorUrl}/verify`;
    const response = await fetch(facilitatorUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        payload: req.paymentPayload,
        requiredAmount: parseAmount(getPriceForRoute(req.path, req.method) || "$0"),
        token: req.payment.token,
      }),
    });

    if (response.ok) {
      const verification = await response.json() as { valid: boolean };
      if (!verification.valid) {
        res.status(402).json({ error: "Payment verification failed" });
        return;
      }
    }
  } catch (err) {
    console.warn("Facilitator verification failed, allowing with unverified payment:", (err as Error).message);
  }

  next();
}
