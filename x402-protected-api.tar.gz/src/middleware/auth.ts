import { Request, Response, NextFunction } from "express";

export function adminAuth(req: Request, res: Response, next: NextFunction): void {
  const apiKey = req.headers["x-api-key"] || req.headers["authorization"]?.replace("Bearer ", "");

  if (!apiKey || apiKey !== process.env.ADMIN_API_KEY) {
    res.status(401).json({ error: "Unauthorized: valid API key required" });
    return;
  }
  next();
}

export function rateLimitByPayer(req: Request, res: Response, next: NextFunction): void {
  if (!req.payment) {
    next();
    return;
  }
  next();
}

export function requestLogger(req: Request, res: Response, next: NextFunction): void {
  const start = Date.now();
  res.on("finish", () => {
    const duration = Date.now() - start;
    console.log(`${req.method} ${req.path} ${res.statusCode} ${duration}ms${req.payment ? ` payment=${req.payment.amount}` : ""}`);
  });
  next();
}
