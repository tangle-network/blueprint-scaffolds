// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

interface IPriceConsumer {
    struct PriceData {
        uint256 price;
        uint256 timestamp;
        uint256 confidence;
    }

    function getPrice(bytes32 feedId) external view returns (PriceData memory);
    function getPriceSafe(bytes32 feedId) external view returns (PriceData memory);
    function isFresh(bytes32 feedId) external view returns (bool);
}
