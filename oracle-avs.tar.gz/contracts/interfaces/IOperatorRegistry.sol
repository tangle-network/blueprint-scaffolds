// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

interface IOperatorRegistry {
    struct OperatorInfo {
        address operator;
        uint256 stake;
        uint256 registeredAt;
        uint256 totalSubmissions;
        uint256 validSubmissions;
        uint256 slashingEvents;
        bool active;
    }

    event OperatorRegistered(address indexed operator, uint256 stake);
    event OperatorDeregistered(address indexed operator);
    event OperatorSlashed(address indexed operator, uint256 amount, bytes32 reason);
    event OperatorJailed(address indexed operator);

    function registerOperator() external payable;
    function deregisterOperator() external;
    function slashOperator(address operator, bytes32 feedId, uint256 deviation) external;
    function jailOperator(address operator) external;
    function getOperator(address operator) external view returns (OperatorInfo memory);
    function isOperatorActive(address operator) external view returns (bool);
    function getOperatorStake(address operator) external view returns (uint256);
    function getActiveOperators() external view returns (address[] memory);
}
