// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IPriceOracle {
    struct Price {
        uint256 value; // fixed-point with `decimals`
        uint8 decimals;
        uint256 timestamp;
    }

    function latestPrice(bytes32 feedId) external view returns (Price memory);
}
