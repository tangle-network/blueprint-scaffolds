// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IPriceOracle} from "./IPriceOracle.sol";

/// @notice Reference price aggregator storing latest value per feed.
/// Real implementation would validate submissions, apply stake-weighting,
/// compute median/TWAP, and provide freshness guarantees.
contract PriceAggregator is IPriceOracle {
    event PriceUpdated(bytes32 indexed feedId, uint256 value, uint8 decimals, uint256 timestamp);

    mapping(bytes32 => Price) private _latest;

    function updatePrice(bytes32 feedId, uint256 value, uint8 decimals, uint256 timestamp) external {
        // Access control omitted (reference only).
        _latest[feedId] = Price({value: value, decimals: decimals, timestamp: timestamp});
        emit PriceUpdated(feedId, value, decimals, timestamp);
    }

    function latestPrice(bytes32 feedId) external view returns (Price memory) {
        return _latest[feedId];
    }
}
