// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "./interfaces/IPriceConsumer.sol";
import "./interfaces/IOperatorRegistry.sol";

contract PriceAggregator {
    IOperatorRegistry public registry;

    struct Submission {
        address operator;
        uint256 price;
        uint256 timestamp;
        uint256 stake;
    }

    struct FeedConfig {
        bytes32 feedId;
        string name;
        uint8 decimals;
        uint256 heartbeat;
        uint256 deviationThreshold;
        uint256 minSubmissions;
        AggregationMethod method;
    }

    enum AggregationMethod { Median, TWAP, WeightedMedian }

    struct Round {
        uint256 aggregatedPrice;
        uint256 timestamp;
        uint256 submissionCount;
        bool finalized;
        uint256 startedAt;
    }

    mapping(bytes32 => FeedConfig) public feeds;
    mapping(bytes32 => mapping(uint256 => Submission[])) public roundSubmissions;
    mapping(bytes32 => mapping(uint256 => Round)) public rounds;
    mapping(bytes32 => uint256) public latestRoundId;
    mapping(bytes32 => uint256[]) public priceHistory;

    uint256 public constant MAX_DEVIATION = 200;
    uint256 public constant SLASH_THRESHOLD = 50;
    uint256 public constant OUTLIER_THRESHOLD = 200;

    event PriceUpdated(bytes32 indexed feedId, uint256 price, uint256 timestamp);
    event SubmissionReceived(bytes32 indexed feedId, address indexed operator, uint256 price, uint256 roundId);
    event RoundFinalized(bytes32 indexed feedId, uint256 roundId, uint256 price);
    event OutlierDetected(bytes32 indexed feedId, address indexed operator, uint256 submittedPrice, uint256 aggregatedPrice);

    constructor(address _registry) {
        registry = IOperatorRegistry(_registry);
    }

    function submitPrice(bytes32 feedId, uint256 price) external {
        require(registry.isOperatorActive(msg.sender), "Not active operator");
        FeedConfig storage feed = feeds[feedId];
        require(feed.feedId != bytes32(0), "Feed not found");

        uint256 roundId = latestRoundId[feedId];
        Round storage round = rounds[feedId][roundId];

        if (round.startedAt == 0 || block.timestamp - round.timestamp >= feed.heartbeat) {
            roundId++;
            latestRoundId[feedId] = roundId;
            rounds[feedId][roundId] = Round({
                aggregatedPrice: 0,
                timestamp: block.timestamp,
                submissionCount: 0,
                finalized: false,
                startedAt: block.timestamp
            });
        }

        uint256 stake = registry.getOperatorStake(msg.sender);
        roundSubmissions[feedId][roundId].push(Submission({
            operator: msg.sender,
            price: price,
            timestamp: block.timestamp,
            stake: stake
        }));

        rounds[feedId][roundId].submissionCount++;

        emit SubmissionReceived(feedId, msg.sender, price, roundId);

        if (rounds[feedId][roundId].submissionCount >= feed.minSubmissions) {
            _finalizeRound(feedId, roundId);
        }
    }

    function _finalizeRound(bytes32 feedId, uint256 roundId) internal {
        Submission[] storage subs = roundSubmissions[feedId][roundId];
        require(subs.length >= feeds[feedId].minSubmissions, "Not enough submissions");

        uint256 aggregatedPrice;
        FeedConfig storage feed = feeds[feedId];

        if (feed.method == AggregationMethod.Median) {
            aggregatedPrice = _computeMedian(subs);
        } else if (feed.method == AggregationMethod.TWAP) {
            aggregatedPrice = _computeTWAP(subs);
        } else {
            aggregatedPrice = _computeWeightedMedian(subs);
        }

        rounds[feedId][roundId].aggregatedPrice = aggregatedPrice;
        rounds[feedId][roundId].finalized = true;
        rounds[feedId][roundId].timestamp = block.timestamp;

        priceHistory[feedId].push(aggregatedPrice);

        _detectAndSlashOutliers(feedId, roundId, aggregatedPrice);

        emit RoundFinalized(feedId, roundId, aggregatedPrice);
        emit PriceUpdated(feedId, aggregatedPrice, block.timestamp);
    }

    function _computeMedian(Submission[] storage subs) internal view returns (uint256) {
        uint256[] memory prices = new uint256[](subs.length);
        for (uint256 i = 0; i < subs.length; i++) {
            prices[i] = subs[i].price;
        }
        _sortUint256(prices);
        if (prices.length % 2 == 0) {
            return (prices[prices.length / 2 - 1] + prices[prices.length / 2]) / 2;
        }
        return prices[prices.length / 2];
    }

    function _computeTWAP(Submission[] storage subs) internal view returns (uint256) {
        if (subs.length == 1) return subs[0].price;
        uint256 weightedSum = 0;
        uint256 totalTime = 0;
        for (uint256 i = 1; i < subs.length; i++) {
            uint256 dt = subs[i].timestamp - subs[i - 1].timestamp;
            weightedSum += subs[i - 1].price * dt;
            totalTime += dt;
        }
        if (totalTime == 0) return subs[subs.length - 1].price;
        return weightedSum / totalTime;
    }

    function _computeWeightedMedian(Submission[] storage subs) internal view returns (uint256) {
        uint256[] memory prices = new uint256[](subs.length);
        uint256 totalStake = 0;
        for (uint256 i = 0; i < subs.length; i++) {
            prices[i] = subs[i].price;
            totalStake += subs[i].stake;
        }
        uint256 cumulative = 0;
        for (uint256 i = 0; i < subs.length; i++) {
            cumulative += subs[i].stake;
            if (cumulative >= totalStake / 2) {
                return subs[i].price;
            }
        }
        return subs[subs.length - 1].price;
    }

    function _detectAndSlashOutliers(bytes32 feedId, uint256 roundId, uint256 aggregatedPrice) internal {
        Submission[] storage subs = roundSubmissions[feedId][roundId];
        for (uint256 i = 0; i < subs.length; i++) {
            uint256 deviation = _calculateDeviation(subs[i].price, aggregatedPrice);
            if (deviation > OUTLIER_THRESHOLD) {
                emit OutlierDetected(feedId, subs[i].operator, subs[i].price, aggregatedPrice);
                if (deviation > SLASH_THRESHOLD * 10) {
                    registry.slashOperator(subs[i].operator, feedId, deviation);
                }
            }
        }
    }

    function _calculateDeviation(uint256 submitted, uint256 aggregated) internal pure returns (uint256) {
        if (aggregated == 0) return 0;
        uint256 diff = submitted > aggregated ? submitted - aggregated : aggregated - submitted;
        return (diff * 10000) / aggregated;
    }

    function _sortUint256(uint256[] memory arr) internal pure {
        for (uint256 i = 0; i < arr.length; i++) {
            for (uint256 j = i + 1; j < arr.length; j++) {
                if (arr[i] > arr[j]) {
                    uint256 temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
        }
    }

    function getLatestPrice(bytes32 feedId) external view returns (IPriceConsumer.PriceData memory) {
        uint256 roundId = latestRoundId[feedId];
        Round storage round = rounds[feedId][roundId];
        require(round.finalized, "Round not finalized");
        return IPriceConsumer.PriceData({
            price: round.aggregatedPrice,
            timestamp: round.timestamp,
            confidence: round.submissionCount
        });
    }

    function isFresh(bytes32 feedId) external view returns (bool) {
        uint256 roundId = latestRoundId[feedId];
        Round storage round = rounds[feedId][roundId];
        return round.finalized && (block.timestamp - round.timestamp) < feeds[feedId].heartbeat;
    }
}
