// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "./interfaces/IOperatorRegistry.sol";
import "./interfaces/IPriceConsumer.sol";
import "./PriceAggregator.sol";

contract OracleCoordinator is IOperatorRegistry {
    address public owner;
    PriceAggregator public aggregator;

    mapping(address => OperatorInfo) private operators;
    address[] private operatorList;

    uint256 public constant MIN_STAKE = 100 ether;
    uint256 public constant SLASH_BASE_PCT = 10;

    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }

    modifier onlyAggregator() {
        require(msg.sender == address(aggregator), "Not aggregator");
        _;
    }

    constructor() {
        owner = msg.sender;
    }

    function setAggregator(address _aggregator) external onlyOwner {
        aggregator = PriceAggregator(_aggregator);
    }

    function registerOperator() external payable override {
        require(msg.value >= MIN_STAKE, "Insufficient stake");
        require(!operators[msg.sender].active, "Already registered");

        operators[msg.sender] = OperatorInfo({
            operator: msg.sender,
            stake: msg.value,
            registeredAt: block.timestamp,
            totalSubmissions: 0,
            validSubmissions: 0,
            slashingEvents: 0,
            active: true
        });

        operatorList.push(msg.sender);
        emit OperatorRegistered(msg.sender, msg.value);
    }

    function deregisterOperator() external override {
        require(operators[msg.sender].active, "Not registered");
        operators[msg.sender].active = false;
        emit OperatorDeregistered(msg.sender);
    }

    function slashOperator(address operator, bytes32 feedId, uint256 deviation) external override onlyAggregator {
        require(operators[operator].active, "Operator not active");
        uint256 slashAmount = (operators[operator].stake * SLASH_BASE_PCT) / 100;
        if (deviation > 5000) {
            slashAmount = (operators[operator].stake * 50) / 100;
        }
        operators[operator].stake -= slashAmount;
        operators[operator].slashingEvents++;

        if (operators[operator].stake < MIN_STAKE) {
            operators[operator].active = false;
            emit OperatorJailed(operator);
        }

        emit OperatorSlashed(operator, slashAmount, feedId);
    }

    function jailOperator(address operator) external override onlyOwner {
        require(operators[operator].active, "Not active");
        operators[operator].active = false;
        emit OperatorJailed(operator);
    }

    function recordSubmission(address operator, bool valid) external onlyAggregator {
        operators[operator].totalSubmissions++;
        if (valid) {
            operators[operator].validSubmissions++;
        }
    }

    function getOperator(address operator) external view override returns (OperatorInfo memory) {
        return operators[operator];
    }

    function isOperatorActive(address operator) external view override returns (bool) {
        return operators[operator].active;
    }

    function getOperatorStake(address operator) external view override returns (uint256) {
        return operators[operator].stake;
    }

    function getActiveOperators() external view override returns (address[] memory) {
        uint256 count = 0;
        for (uint256 i = 0; i < operatorList.length; i++) {
            if (operators[operatorList[i]].active) count++;
        }
        address[] memory active = new address[](count);
        uint256 idx = 0;
        for (uint256 i = 0; i < operatorList.length; i++) {
            if (operators[operatorList[i]].active) {
                active[idx++] = operatorList[i];
            }
        }
        return active;
    }
}
