// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @notice Reference coordinator for an EigenLayer AVS oracle.
/// This contract is a minimal placeholder showing how an AVS might
/// track operators and accept signed submissions. Production code
/// would integrate EigenLayer middleware and a slashing module.
contract OracleCoordinator {
    event OperatorRegistered(address indexed operator, uint256 stake);
    event EvidenceOutlier(address indexed operator, bytes32 indexed feedId, uint256 value, uint256 timestamp);

    mapping(address => uint256) public stakeOf;

    function registerOperator(uint256 stake) external {
        // In a real AVS, stake comes from EigenLayer delegation shares.
        stakeOf[msg.sender] = stake;
        emit OperatorRegistered(msg.sender, stake);
    }

    function emitEvidenceOutlier(address operator, bytes32 feedId, uint256 value, uint256 timestamp) external {
        // In a real AVS, only aggregator/coordinator would call this.
        emit EvidenceOutlier(operator, feedId, value, timestamp);
    }
}
