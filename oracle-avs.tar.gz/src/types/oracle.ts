export type FeedCategory = "crypto" | "forex" | "commodities" | "custom";

export interface PriceFeed {
  id: string;
  name: string;
  symbol: string;
  category: FeedCategory;
  decimals: number;
  currentPrice: number;
  previousPrice: number;
  change24h: number;
  changePercent24h: number;
  lastUpdated: number;
  sources: PriceSource[];
  aggregatedPrice: AggregatedPrice;
  heartbeat: number;
  deviationThreshold: number;
}

export interface PriceSource {
  name: string;
  url: string;
  lastPrice: number;
  lastFetch: number;
  status: "active" | "stale" | "error";
  latencyMs: number;
}

export interface AggregatedPrice {
  median: number;
  twap: number;
  mean: number;
  updatedAt: number;
  submissionCount: number;
  totalStakeWeight: number;
}

export interface PriceSubmission {
  id: string;
  feedId: string;
  operator: OperatorInfo;
  price: number;
  timestamp: number;
  stakeWeight: number;
  signature: string;
  status: "accepted" | "rejected" | "disputed";
}

export interface OperatorInfo {
  id: string;
  address: string;
  name: string;
  stakeAmount: number;
  stakeWeight: number;
  status: "active" | "jailed" | "slashed" | "deregistered";
  registeredAt: number;
  totalSubmissions: number;
  accuracyScore: number;
  delegationCount: number;
}

export interface SlashingEvent {
  id: string;
  operatorId: string;
  operatorAddress: string;
  operatorName: string;
  feedId: string;
  feedName: string;
  reason: SlashingReason;
  amount: number;
  timestamp: number;
  evidence: SlashingEvidence;
  status: "pending" | "executed" | "appealed" | "overturned";
}

export type SlashingReason =
  | "stale_data"
  | "outlier_submission"
  | "manipulation"
  | "downtime"
  | "invalid_signature";

export interface SlashingEvidence {
  submittedPrice: number;
  consensusPrice: number;
  deviationPercent: number;
  blockNumber: number;
  txHash: string;
}

export interface FeedHistoryPoint {
  timestamp: number;
  price: number;
  twap: number;
  volume: number;
}

export interface NetworkStats {
  totalOperators: number;
  activeOperators: number;
  totalStake: number;
  totalFeeds: number;
  totalSubmissions24h: number;
  avgLatencyMs: number;
  slashingEvents24h: number;
  uptimePercent: number;
}
