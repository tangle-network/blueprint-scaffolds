import type { OperatorSubmission } from "./types";

export function computeMedian(values: number[]): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

export function computeTWAP(prices: { timestamp: number; price: number }[]): number {
  if (prices.length === 0) return 0;
  if (prices.length === 1) return prices[0].price;

  let weightedSum = 0;
  let totalTime = 0;

  for (let i = 1; i < prices.length; i++) {
    const dt = prices[i].timestamp - prices[i - 1].timestamp;
    weightedSum += prices[i - 1].price * dt;
    totalTime += dt;
  }

  if (totalTime === 0) return prices[prices.length - 1].price;
  return weightedSum / totalTime;
}

export function detectOutliers(
  submissions: OperatorSubmission[],
  threshold = 2.0
): { valid: OperatorSubmission[]; outliers: OperatorSubmission[] } {
  const prices = submissions.map((s) => s.price);
  const median = computeMedian(prices);
  const deviations = prices.map((p) => Math.abs(p - median) / (median || 1));

  const valid: OperatorSubmission[] = [];
  const outliers: OperatorSubmission[] = [];

  submissions.forEach((sub, i) => {
    if (deviations[i] > threshold) {
      outliers.push({ ...sub, isValid: false, deviation: deviations[i] });
    } else {
      valid.push({ ...sub, isValid: true, deviation: deviations[i] });
    }
  });

  return { valid, outliers };
}

export function weightedMedian(submissions: OperatorSubmission[]): number {
  if (submissions.length === 0) return 0;

  const sorted = [...submissions].sort((a, b) => a.price - b.price);
  const totalStake = sorted.reduce((sum, s) => sum + s.stake, 0);
  let cumulative = 0;

  for (const sub of sorted) {
    cumulative += sub.stake;
    if (cumulative >= totalStake / 2) {
      return sub.price;
    }
  }

  return sorted[sorted.length - 1].price;
}
