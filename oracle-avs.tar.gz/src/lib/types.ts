export type FeedCategory = "crypto" | "forex" | "commodities" | "custom";

export type AggregationMethod = "median" | "twap" | "weighted_median";

export type FeedStatus = "active" | "paused" | "deprecated";

export interface PriceFeed {
  id: string;
  name: string;
  pair: string;
  category: FeedCategory;
  status: FeedStatus;
  decimals: number;
  aggregationMethod: AggregationMethod;
  heartbeat: number;
  deviationThreshold: number;
  latestPrice: number;
  previousPrice: number;
  lastUpdated: number;
  submissionCount: number;
}

export interface PricePoint {
  timestamp: number;
  price: number;
}

export interface OperatorSubmission {
  operatorId: string;
  operatorName: string;
  operatorAddress: string;
  price: number;
  timestamp: number;
  stake: number;
  isValid: boolean;
  deviation: number;
}

export interface Operator {
  id: string;
  name: string;
  address: string;
  stake: number;
  totalSubmissions: number;
  validSubmissions: number;
  slashingEvents: number;
  registeredSince: number;
  activeFeeds: string[];
  status: "active" | "jailed" | "deregistered";
  accuracy: number;
}

export interface DashboardStats {
  totalFeeds: number;
  activeFeeds: number;
  totalOperators: number;
  totalStake: number;
  avgLatency: number;
  slashingEvents: number;
}

export interface AggregationResult {
  method: AggregationMethod;
  value: number;
  submissions: OperatorSubmission[];
  outliers: OperatorSubmission[];
  timestamp: number;
}
