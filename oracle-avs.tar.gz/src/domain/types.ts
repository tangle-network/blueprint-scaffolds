export type FeedKind = 'CRYPTO' | 'FOREX' | 'COMMODITY' | 'CUSTOM'

export type AggregationMethod = 'MEDIAN' | 'TWAP'

export type SourceId =
  | 'COINBASE'
  | 'KRAKEN'
  | 'BINANCE'
  | 'OKX'
  | 'FX_INTERNAL'
  | 'CME'
  | 'CUSTOM'

export type OperatorId = string

export type PricePoint = {
  t: number // unix seconds
  p: number // price
}

export type OperatorSubmission = {
  operator: OperatorId
  stake: number
  source: SourceId
  feedId: string
  value: number
  timestamp: number
  signature?: string
}

export type FeedConfig = {
  feedId: string
  symbol: string
  kind: FeedKind
  decimals: number
  quote: string
  heartbeatSec: number
  maxAgeSec: number
  outlierBps: number
  minStakeBpsToReport: number
  aggregation: AggregationMethod
  twapWindowSec: number
}

export type AggregationReport = {
  feedId: string
  symbol: string
  kind: FeedKind
  aggregation: AggregationMethod
  timestamp: number
  fresh: boolean
  price: number
  priceDecimals: number
  median?: number
  twap?: number
  numSubmissions: number
  numAccepted: number
  rejected: {
    outlier: number
    stale: number
    lowStake: number
  }
  stakeAccepted: number
  stakeTotal: number
}
