import type { OperatorSubmission, PricePoint } from '@/domain/types'

export function clamp(n: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, n))
}

export function median(values: number[]): number {
  if (values.length === 0) throw new Error('median: empty')
  const sorted = [...values].sort((a, b) => a - b)
  const mid = Math.floor(sorted.length / 2)
  if (sorted.length % 2 === 1) return sorted[mid]
  return (sorted[mid - 1] + sorted[mid]) / 2
}

export function weightedMedian(values: { v: number; w: number }[]): number {
  if (values.length === 0) throw new Error('weightedMedian: empty')
  const sorted = [...values].sort((a, b) => a.v - b.v)
  const total = sorted.reduce((acc, x) => acc + x.w, 0)
  if (total <= 0) throw new Error('weightedMedian: nonpositive total weight')
  let cum = 0
  for (const x of sorted) {
    cum += x.w
    if (cum >= total / 2) return x.v
  }
  return sorted[sorted.length - 1].v
}

export function bpsDiff(a: number, b: number): number {
  if (a === 0 && b === 0) return 0
  const denom = Math.max(1e-12, Math.abs(b))
  return (Math.abs(a - b) / denom) * 10000
}

export function twap(points: PricePoint[], nowSec: number, windowSec: number): number {
  if (points.length === 0) throw new Error('twap: empty')
  const start = nowSec - windowSec
  const within = points
    .filter((pt) => pt.t >= start && pt.t <= nowSec)
    .sort((a, b) => a.t - b.t)
  if (within.length === 0) return points[points.length - 1].p
  const pts = [...within]
  if (pts[0].t > start) {
    pts.unshift({ t: start, p: pts[0].p })
  }
  if (pts[pts.length - 1].t < nowSec) {
    pts.push({ t: nowSec, p: pts[pts.length - 1].p })
  }
  let area = 0
  for (let i = 0; i + 1 < pts.length; i++) {
    const dt = pts[i + 1].t - pts[i].t
    area += pts[i].p * dt
  }
  return area / windowSec
}

export function normalizeStake(subs: OperatorSubmission[]): OperatorSubmission[] {
  const total = subs.reduce((acc, s) => acc + s.stake, 0)
  if (total <= 0) return subs
  return subs.map((s) => ({ ...s, stake: s.stake / total }))
}
