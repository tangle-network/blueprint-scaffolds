import type { FeedConfig, OperatorSubmission, SourceId } from '@/domain/types'

export const feeds: FeedConfig[] = [
  {
    feedId: 'crypto:eth-usd',
    symbol: 'ETH/USD',
    kind: 'CRYPTO',
    decimals: 2,
    quote: 'USD',
    heartbeatSec: 30,
    maxAgeSec: 25,
    outlierBps: 150,
    minStakeBpsToReport: 50,
    aggregation: 'MEDIAN',
    twapWindowSec: 300,
  },
  {
    feedId: 'crypto:btc-usd',
    symbol: 'BTC/USD',
    kind: 'CRYPTO',
    decimals: 2,
    quote: 'USD',
    heartbeatSec: 30,
    maxAgeSec: 25,
    outlierBps: 120,
    minStakeBpsToReport: 50,
    aggregation: 'TWAP',
    twapWindowSec: 600,
  },
  {
    feedId: 'fx:eur-usd',
    symbol: 'EUR/USD',
    kind: 'FOREX',
    decimals: 5,
    quote: 'USD',
    heartbeatSec: 60,
    maxAgeSec: 55,
    outlierBps: 35,
    minStakeBpsToReport: 75,
    aggregation: 'MEDIAN',
    twapWindowSec: 600,
  },
  {
    feedId: 'cmdty:xau-usd',
    symbol: 'XAU/USD',
    kind: 'COMMODITY',
    decimals: 2,
    quote: 'USD',
    heartbeatSec: 120,
    maxAgeSec: 110,
    outlierBps: 60,
    minStakeBpsToReport: 100,
    aggregation: 'TWAP',
    twapWindowSec: 3600,
  },
  {
    feedId: 'custom:acme-index',
    symbol: 'ACME/INDEX',
    kind: 'CUSTOM',
    decimals: 3,
    quote: 'IDX',
    heartbeatSec: 20,
    maxAgeSec: 18,
    outlierBps: 200,
    minStakeBpsToReport: 50,
    aggregation: 'MEDIAN',
    twapWindowSec: 120,
  },
]

const operators = [
  { id: 'op-0xA1', stake: 120 },
  { id: 'op-0xB2', stake: 90 },
  { id: 'op-0xC3', stake: 60 },
  { id: 'op-0xD4', stake: 40 },
  { id: 'op-0xE5', stake: 25 },
]

const sources: SourceId[] = ['COINBASE', 'KRAKEN', 'BINANCE', 'OKX', 'CUSTOM']

export function makeSubmissions(feedId: string, base: number, nowSec: number): OperatorSubmission[] {
  const subs: OperatorSubmission[] = []
  for (let i = 0; i < operators.length; i++) {
    const op = operators[i]
    const src = sources[i % sources.length]
    // generate small dispersion; include one potential outlier
    const jitter = (Math.sin((nowSec / 13) + i * 1.7) * 0.004 + (i - 2) * 0.0009) * base
    let value = base + jitter
    if (i === 3 && (nowSec % 37) < 7) value = base * 1.08 // occasional bad/outlier submission
    const staleSkew = i === 4 ? 40 : 0
    subs.push({
      operator: op.id,
      stake: op.stake,
      source: src,
      feedId,
      value,
      timestamp: nowSec - staleSkew,
    })
  }
  return subs
}

export function basePriceForFeed(feedId: string, nowSec: number): number {
  // deterministic pseudo-price evolutions per feed
  const t = nowSec
  if (feedId === 'crypto:eth-usd') return 3200 + 120 * Math.sin(t / 45) + 40 * Math.sin(t / 11)
  if (feedId === 'crypto:btc-usd') return 65000 + 1200 * Math.sin(t / 70) + 500 * Math.sin(t / 17)
  if (feedId === 'fx:eur-usd') return 1.083 + 0.004 * Math.sin(t / 120) + 0.001 * Math.sin(t / 23)
  if (feedId === 'cmdty:xau-usd') return 2150 + 35 * Math.sin(t / 500) + 10 * Math.sin(t / 90)
  return 102.5 + 1.8 * Math.sin(t / 18) + 0.6 * Math.sin(t / 6)
}
