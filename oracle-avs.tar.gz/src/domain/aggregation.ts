import type { AggregationMethod, AggregationReport, FeedConfig, OperatorSubmission } from '@/domain/types'
import { bpsDiff, clamp, median, twap, weightedMedian } from '@/domain/math'

export type AggregationInput = {
  feed: FeedConfig
  nowSec: number
  submissions: OperatorSubmission[]
  history: { t: number; p: number }[]
}

export function aggregate(input: AggregationInput): AggregationReport {
  const { feed, nowSec } = input
  const totalStake = input.submissions.reduce((acc, s) => acc + s.stake, 0)

  const minStakeFrac = clamp(feed.minStakeBpsToReport / 10000, 0, 1)
  const minStakeToAccept = totalStake * minStakeFrac

  const latestByOp = new Map<string, OperatorSubmission>()
  for (const s of input.submissions) {
    const cur = latestByOp.get(s.operator)
    if (!cur || s.timestamp > cur.timestamp) latestByOp.set(s.operator, s)
  }

  const deduped = [...latestByOp.values()]
  const freshCutoff = nowSec - feed.maxAgeSec
  const freshSubs = deduped.filter((s) => s.timestamp >= freshCutoff)

  const weights = freshSubs.map((s) => ({ v: s.value, w: s.stake }))
  const ref = weights.length ? weightedMedian(weights) : (input.history.length ? input.history[input.history.length - 1].p : 0)

  let outlierRejected = 0
  let staleRejected = deduped.length - freshSubs.length
  let lowStakeRejected = 0
  const accepted: OperatorSubmission[] = []
  for (const s of freshSubs) {
    if (s.stake < minStakeToAccept) {
      lowStakeRejected++
      continue
    }
    const diffBps = bpsDiff(s.value, ref)
    if (diffBps > feed.outlierBps) {
      outlierRejected++
      continue
    }
    accepted.push(s)
  }

  const acceptedStake = accepted.reduce((acc, s) => acc + s.stake, 0)
  const acceptedValues = accepted.map((s) => s.value)
  const acceptedWeighted = accepted.map((s) => ({ v: s.value, w: s.stake }))

  let med: number | undefined
  let t: number | undefined
  let price = 0
  if (accepted.length) {
    med = median(acceptedValues)
    if (feed.aggregation === 'MEDIAN') {
      price = weightedMedian(acceptedWeighted)
    } else {
      const recentPoints = [...input.history, { t: nowSec, p: weightedMedian(acceptedWeighted) }]
      t = twap(recentPoints, nowSec, feed.twapWindowSec)
      price = t
    }
  } else {
    // fallback to last known
    const last = input.history.length ? input.history[input.history.length - 1].p : 0
    if (feed.aggregation === 'TWAP') {
      t = input.history.length ? twap(input.history, nowSec, feed.twapWindowSec) : last
      price = t
    } else {
      price = last
    }
  }

  const lastTs = input.history.length ? input.history[input.history.length - 1].t : 0
  const fresh = nowSec - lastTs <= feed.heartbeatSec

  return {
    feedId: feed.feedId,
    symbol: feed.symbol,
    kind: feed.kind,
    aggregation: feed.aggregation as AggregationMethod,
    timestamp: nowSec,
    fresh,
    price,
    priceDecimals: feed.decimals,
    median: med,
    twap: t,
    numSubmissions: deduped.length,
    numAccepted: accepted.length,
    rejected: {
      outlier: outlierRejected,
      stale: staleRejected,
      lowStake: lowStakeRejected,
    },
    stakeAccepted: acceptedStake,
    stakeTotal: totalStake,
  }
}
