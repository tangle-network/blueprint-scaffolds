import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Dashboard from "./pages/Dashboard";
import Feeds from "./pages/Feeds";
import FeedDetail from "./pages/FeedDetail";
import Operators from "./pages/Operators";
import OperatorDetail from "./pages/OperatorDetail";

export default function App() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 py-6">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/feeds" element={<Feeds />} />
          <Route path="/feeds/:feedId" element={<FeedDetail />} />
          <Route path="/operators" element={<Operators />} />
          <Route path="/operators/:operatorId" element={<OperatorDetail />} />
        </Routes>
      </main>
    </div>
  );
}
