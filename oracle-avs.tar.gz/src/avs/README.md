# Oracle AVS (EigenLayer) - Reference Design

This repo includes:

- `contracts/` Solidity reference contracts for an oracle AVS coordinator + aggregator + consumer interface.
- `operator/` Go operator reference for fetching and submitting price data.
- `src/` Vite+React feed explorer that simulates multi-operator stake-weighted submissions with outlier detection and median/TWAP aggregation.

Note: contracts/operator code are intentionally minimal reference implementations to keep the build pipeline focused on the frontend compilation requirement.
