import { Link, useLocation } from "react-router-dom";
import { Activity, Database, Users, Radio } from "lucide-react";
import { cn } from "@/lib/utils";

const links = [
  { to: "/", label: "Dashboard", icon: Activity },
  { to: "/feeds", label: "Feeds", icon: Database },
  { to: "/operators", label: "Operators", icon: Users },
];

export default function Navbar() {
  const location = useLocation();

  return (
    <nav className="border-b bg-card">
      <div className="container mx-auto px-4 flex items-center h-14 gap-8">
        <Link to="/" className="flex items-center gap-2 font-bold text-lg">
          <Radio className="h-5 w-5 text-primary" />
          <span>Oracle AVS</span>
        </Link>
        <div className="flex items-center gap-1">
          {links.map(({ to, label, icon: Icon }) => {
            const active = location.pathname === to || (to !== "/" && location.pathname.startsWith(to));
            return (
              <Link
                key={to}
                to={to}
                className={cn(
                  "flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition-colors",
                  active ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                )}
              >
                <Icon className="h-4 w-4" />
                {label}
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
