import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { formatPrice, formatTimestamp } from "@/lib/utils";
import type { PricePoint } from "@/lib/types";

interface PriceChartProps {
  data: PricePoint[];
  decimals?: number;
  height?: number;
}

export default function PriceChart({ data, decimals = 2, height = 300 }: PriceChartProps) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={data} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
        <XAxis
          dataKey="timestamp"
          tickFormatter={(ts) => new Date(ts * 1000).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
          tick={{ fontSize: 12 }}
          className="text-muted-foreground"
        />
        <YAxis
          domain={["auto", "auto"]}
          tickFormatter={(v) => "$" + formatPrice(v, decimals)}
          tick={{ fontSize: 12 }}
          width={80}
          className="text-muted-foreground"
        />
        <Tooltip
          formatter={(value: number) => ["$" + formatPrice(value, decimals), "Price"]}
          labelFormatter={(ts) => formatTimestamp(ts as number)}
        />
        <Line type="monotone" dataKey="price" stroke="hsl(222.2, 47.4%, 11.2%)" strokeWidth={2} dot={false} />
      </LineChart>
    </ResponsiveContainer>
  );
}
