import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatPrice, formatAddress, formatPercent } from "@/lib/utils";
import { computeMedian, weightedMedian } from "@/lib/aggregation";
import type { OperatorSubmission, AggregationMethod } from "@/lib/types";

interface AggregationViewProps {
  submissions: OperatorSubmission[];
  method: AggregationMethod;
  decimals: number;
}

export default function AggregationView({ submissions, method, decimals }: AggregationViewProps) {
  const prices = submissions.map((s) => s.price);
  const median = computeMedian(prices);
  const wMedian = weightedMedian(submissions);

  const methodLabel = method === "median" ? "Median" : method === "twap" ? "TWAP" : "Weighted Median";
  const resultValue = method === "weighted_median" ? wMedian : median;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Method</p>
            <p className="text-lg font-semibold">{methodLabel}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Aggregated Price</p>
            <p className="text-lg font-bold">${formatPrice(resultValue, decimals)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Submissions</p>
            <p className="text-lg font-semibold">{submissions.length} operators</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Operator Submissions</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Operator</TableHead>
                <TableHead>Address</TableHead>
                <TableHead className="text-right">Price</TableHead>
                <TableHead className="text-right">Stake</TableHead>
                <TableHead className="text-right">Deviation</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {submissions.map((sub) => (
                <TableRow key={sub.operatorId}>
                  <TableCell className="font-medium">{sub.operatorName}</TableCell>
                  <TableCell className="text-muted-foreground">{formatAddress(sub.operatorAddress)}</TableCell>
                  <TableCell className="text-right">${formatPrice(sub.price, decimals)}</TableCell>
                  <TableCell className="text-right">{sub.stake.toLocaleString()} ETH</TableCell>
                  <TableCell className="text-right">{formatPercent(sub.deviation)}</TableCell>
                  <TableCell>
                    <Badge variant={sub.isValid ? "default" : "destructive"}>
                      {sub.isValid ? "Valid" : "Outlier"}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
