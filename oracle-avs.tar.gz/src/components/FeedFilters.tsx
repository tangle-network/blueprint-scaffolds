import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { FeedCategory } from "@/lib/types";

interface FeedFiltersProps {
  selected: FeedCategory | "all";
  onSelect: (cat: FeedCategory | "all") => void;
}

const categories: { value: FeedCategory | "all"; label: string }[] = [
  { value: "all", label: "All" },
  { value: "crypto", label: "Crypto" },
  { value: "forex", label: "Forex" },
  { value: "commodities", label: "Commodities" },
  { value: "custom", label: "Custom" },
];

export default function FeedFilters({ selected, onSelect }: FeedFiltersProps) {
  return (
    <div className="flex items-center gap-2">
      {categories.map(({ value, label }) => (
        <Button
          key={value}
          variant={selected === value ? "default" : "outline"}
          size="sm"
          onClick={() => onSelect(value)}
          className={cn("capitalize")}
        >
          {label}
        </Button>
      ))}
    </div>
  );
}
