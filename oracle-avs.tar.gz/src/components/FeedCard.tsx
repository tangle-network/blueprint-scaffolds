import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatPrice, formatPercent, timeAgo } from "@/lib/utils";
import type { PriceFeed } from "@/lib/types";
import { Link } from "react-router-dom";

interface FeedCardProps {
  feed: PriceFeed;
}

export default function FeedCard({ feed }: FeedCardProps) {
  const change = ((feed.latestPrice - feed.previousPrice) / feed.previousPrice) * 100;
  const isUp = change > 0;
  const isDown = change < 0;

  return (
    <Link to={`/feeds/${feed.id}`}>
      <Card className="hover:shadow-md transition-shadow cursor-pointer">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-2">
            <div>
              <p className="font-semibold text-sm">{feed.pair}</p>
              <p className="text-xs text-muted-foreground">{feed.name}</p>
            </div>
            <div className="flex items-center gap-1.5">
              <Badge variant={feed.status === "active" ? "default" : feed.status === "paused" ? "secondary" : "destructive"}>
                {feed.status}
              </Badge>
              <Badge variant="outline" className="text-xs capitalize">
                {feed.category}
              </Badge>
            </div>
          </div>
          <div className="flex items-end justify-between">
            <p className="text-2xl font-bold">${formatPrice(feed.latestPrice, feed.decimals)}</p>
            <div className={`flex items-center gap-1 text-sm font-medium ${isUp ? "text-green-600" : isDown ? "text-red-600" : "text-muted-foreground"}`}>
              {isUp ? <TrendingUp className="h-4 w-4" /> : isDown ? <TrendingDown className="h-4 w-4" /> : <Minus className="h-4 w-4" />}
              {formatPercent(change)}
            </div>
          </div>
          <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
            <span>{feed.submissionCount} submissions</span>
            <span>{timeAgo(feed.lastUpdated)}</span>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
