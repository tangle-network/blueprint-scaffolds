import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatAddress, timeAgo } from "@/lib/utils";
import { Shield, TrendingUp, AlertTriangle, Clock } from "lucide-react";
import type { Operator } from "@/lib/types";

interface OperatorPanelProps {
  operator: Operator;
}

export default function OperatorPanel({ operator }: OperatorPanelProps) {
  const statusVariant = operator.status === "active" ? "default" : operator.status === "jailed" ? "destructive" : "secondary";

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <Card>
        <CardContent className="p-4 flex items-center gap-3">
          <Shield className="h-8 w-8 text-primary" />
          <div>
            <p className="font-semibold">{operator.name}</p>
            <p className="text-sm text-muted-foreground">{formatAddress(operator.address)}</p>
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="p-4 flex items-center gap-3">
          <TrendingUp className="h-8 w-8 text-green-600" />
          <div>
            <p className="text-sm text-muted-foreground">Stake</p>
            <p className="text-lg font-semibold">{operator.stake.toLocaleString()} ETH</p>
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="p-4 flex items-center gap-3">
          <AlertTriangle className="h-8 w-8 text-yellow-600" />
          <div>
            <p className="text-sm text-muted-foreground">Slashing Events</p>
            <p className="text-lg font-semibold">{operator.slashingEvents}</p>
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="p-4 flex items-center gap-3">
          <Clock className="h-8 w-8 text-blue-600" />
          <div>
            <p className="text-sm text-muted-foreground">Registered</p>
            <p className="text-lg font-semibold">{timeAgo(operator.registeredSince)}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
