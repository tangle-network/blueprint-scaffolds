import React, { useEffect, useMemo, useState } from 'react'
import type { AggregationReport, FeedConfig, OperatorSubmission } from '@/domain/types'
import { aggregate } from '@/domain/aggregation'
import { basePriceForFeed, feeds, makeSubmissions } from '@/domain/sampleData'
import { formatNumber, formatTs, pct } from '@/ui/format'

type Mode = 'SIMULATED'

export function App(): React.JSX.Element {
  const [mode] = useState<Mode>('SIMULATED')
  const [selectedFeedId, setSelectedFeedId] = useState<string>(feeds[0].feedId)
  const [nowSec, setNowSec] = useState<number>(() => Math.floor(Date.now() / 1000))
  const [history, setHistory] = useState<Record<string, { t: number; p: number }[]>>(() => ({}))
  const [submissions, setSubmissions] = useState<OperatorSubmission[]>([])
  const feed = useMemo<FeedConfig>(() => feeds.find((f) => f.feedId === selectedFeedId) ?? feeds[0], [selectedFeedId])

  useEffect(() => {
    const id = window.setInterval(() => setNowSec(Math.floor(Date.now() / 1000)), 1000)
    return () => window.clearInterval(id)
  }, [])

  // create simulated submissions periodically
  useEffect(() => {
    const base = basePriceForFeed(feed.feedId, nowSec)
    const subs = makeSubmissions(feed.feedId, base, nowSec)
    setSubmissions(subs)
  }, [feed.feedId, nowSec])

  const report: AggregationReport = useMemo(() => {
    const hist = history[feed.feedId] ?? []
    return aggregate({
      feed,
      nowSec,
      submissions,
      history: hist,
    })
  }, [feed, nowSec, submissions, history])

  useEffect(() => {
    setHistory((prev: Record<string, { t: number; p: number }[]>) => {
      const hist = prev[feed.feedId] ?? []
      const next = [...hist, { t: report.timestamp, p: report.price }]
      // keep ~2 hours
      const cutoff = report.timestamp - 2 * 3600
      const pruned = next.filter((x) => x.t >= cutoff)
      return { ...prev, [feed.feedId]: pruned }
    })
  }, [feed.feedId, report.timestamp, report.price])

  const freshnessPill = report.fresh ? 'good' : 'warn'
  const stakeCoverage = report.stakeTotal > 0 ? report.stakeAccepted / report.stakeTotal : 0

  return (
    <div className="container fade-in">
      <div className="topbar">
        <div className="brand">
          <h1>Oracle AVS on EigenLayer - Feed Explorer</h1>
          <p>
            Multi-source aggregation (stake-weighted), median/TWAP, outlier detection, freshness guarantees, and slashing signals.
          </p>
        </div>
        <div className="badge-row">
          <span className="badge">Mode: {mode}</span>
          <span className="badge mono">t={nowSec}</span>
          <span className={`pill ${freshnessPill}`}>{report.fresh ? 'Fresh' : 'Stale'}</span>
        </div>
      </div>

      <div className="grid">
        <div className="panel">
          <div className="panel-header">
            <h2>Feed</h2>
            <div className="row" style={{ width: 380, maxWidth: '100%' }}>
              <select value={selectedFeedId} onChange={(e) => setSelectedFeedId(e.target.value)}>
                {feeds.map((f) => (
                  <option key={f.feedId} value={f.feedId}>
                    {f.symbol} - {f.kind}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="panel-body">
            <div className="kpi">
              <div className="kpi-card">
                <div className="t">Aggregated Price</div>
                <div className="v mono">
                  {formatNumber(report.price, report.priceDecimals)} {feed.quote}
                </div>
                <div className="s">Updated: {formatTs(report.timestamp)}</div>
              </div>
              <div className="kpi-card">
                <div className="t">Method</div>
                <div className="v mono">{feed.aggregation}</div>
                <div className="s">
                  {feed.aggregation === 'TWAP' ? `Window: ${feed.twapWindowSec}s` : `Outlier: ${feed.outlierBps} bps`}
                </div>
              </div>
              <div className="kpi-card">
                <div className="t">Stake Coverage</div>
                <div className="v mono">{pct(stakeCoverage)}</div>
                <div className="s">
                  Accepted: {report.numAccepted}/{report.numSubmissions} operators
                </div>
              </div>
              <div className="kpi-card">
                <div className="t">Rejections</div>
                <div className="v mono">
                  O:{report.rejected.outlier} S:{report.rejected.stale} L:{report.rejected.lowStake}
                </div>
                <div className="s">Outlier / Stale / LowStake</div>
              </div>
            </div>

            <div style={{ height: 14 }} />

            <table className="table">
              <thead>
                <tr>
                  <th>Operator</th>
                  <th>Source</th>
                  <th>Stake</th>
                  <th>Value</th>
                  <th>Age</th>
                </tr>
              </thead>
              <tbody>
                {submissions
                  .slice()
                  .sort((a, b) => b.stake - a.stake)
                  .map((s) => {
                    const age = nowSec - s.timestamp
                    const stale = age > feed.maxAgeSec
                    const baseRef = report.median ?? report.price
                    const diffBps = baseRef ? Math.abs((s.value - baseRef) / baseRef) * 10000 : 0
                    const status = stale ? 'warn' : diffBps > feed.outlierBps ? 'bad' : 'good'
                    return (
                      <tr key={`${s.feedId}:${s.operator}`}>
                        <td className="mono">{s.operator}</td>
                        <td className="mono">{s.source}</td>
                        <td className="mono">{formatNumber(s.stake, 0)}</td>
                        <td className="mono">
                          {formatNumber(s.value, feed.decimals)}
                          <span style={{ marginLeft: 10 }} className={`pill ${status}`}>bps {formatNumber(diffBps, 0)}</span>
                        </td>
                        <td className="mono">{age}s</td>
                      </tr>
                    )
                  })}
              </tbody>
            </table>
          </div>
        </div>

        <div className="panel">
          <div className="panel-header">
            <h2>AVS Rules</h2>
            <div className="row wrap" style={{ justifyContent: 'flex-end' }}>
              <a className="btn secondary" href="#contracts" onClick={(e) => e.preventDefault()}>
                Contracts
              </a>
              <a className="btn secondary" href="#operator" onClick={(e) => e.preventDefault()}>
                Operator
              </a>
            </div>
          </div>
          <div className="panel-body">
            <Rules feed={feed} report={report} />
            <div style={{ height: 12 }} />
            <MiniContracts />
          </div>
        </div>
      </div>
    </div>
  )
}

function Rules({ feed, report }: { feed: FeedConfig; report: AggregationReport }): React.JSX.Element {
  return (
    <div>
      <div className="row wrap" style={{ gap: 8, marginBottom: 10 }}>
        <span className="pill">freshness: maxAge {feed.maxAgeSec}s</span>
        <span className="pill">heartbeat: {feed.heartbeatSec}s</span>
        <span className="pill">outlier: {feed.outlierBps} bps</span>
        <span className="pill">minStake: {feed.minStakeBpsToReport} bps</span>
      </div>
      <div style={{ color: 'rgba(255,255,255,0.72)', fontSize: 13, lineHeight: 1.55 }}>
        <div>
          This explorer simulates an EigenLayer oracle AVS: operators submit signed prices, weighted by stake, filtered by
          freshness and outlier checks, and aggregated via {feed.aggregation}.
        </div>
        <div style={{ marginTop: 10 }}>
          Slashing signal (demo): if an operator is repeatedly rejected as outlier and the accepted set is sufficiently
          stake-covered, the coordinator would emit an evidence event.
        </div>
        <div style={{ marginTop: 10, display: 'flex', gap: 10, flexWrap: 'wrap' }}>
          <span className="pill good">Accepted {report.numAccepted}</span>
          <span className="pill warn">Stale {report.rejected.stale}</span>
          <span className="pill bad">Outliers {report.rejected.outlier}</span>
        </div>
      </div>
    </div>
  )
}

function MiniContracts(): React.JSX.Element {
  return (
    <div>
      <h3 style={{ margin: '10px 0 8px', fontSize: 13, letterSpacing: 0.4, textTransform: 'uppercase', color: 'rgba(255,255,255,0.70)' }}>
        Reference Modules
      </h3>
      <table className="table">
        <thead>
          <tr>
            <th>Module</th>
            <th>Role</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className="mono">OracleCoordinator</td>
            <td>tracks operators, verifies signatures, emits slashing evidence</td>
          </tr>
          <tr>
            <td className="mono">PriceAggregator</td>
            <td>maintains per-feed state, computes median/TWAP, freshness</td>
          </tr>
          <tr>
            <td className="mono">IPriceOracle</td>
            <td>consumer interface for dApps to read latest prices</td>
          </tr>
        </tbody>
      </table>
    </div>
  )
}
