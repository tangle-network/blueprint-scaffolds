export function formatNumber(n: number, decimals: number): string {
  if (!Number.isFinite(n)) return '0'
  return n.toLocaleString(undefined, {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })
}

export function pct(frac: number): string {
  if (!Number.isFinite(frac)) return '0%'
  return `${(frac * 100).toFixed(1)}%`
}

export function formatTs(ts: number): string {
  const d = new Date(ts * 1000)
  return d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', second: '2-digit' })
}
