import { Database, Users, Shield, Zap, AlertTriangle, Radio } from "lucide-react";
import StatsCard from "@/components/StatsCard";
import FeedCard from "@/components/FeedCard";
import { feeds, operators, dashboardStats } from "@/lib/mock-data";
import { shortenNumber } from "@/lib/utils";

export default function Dashboard() {
  const topFeeds = feeds.slice(0, 6);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Oracle AVS Dashboard</h1>
        <p className="text-muted-foreground">EigenLayer price feed overview</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <StatsCard
          title="Total Feeds"
          value={dashboardStats.totalFeeds}
          icon={<Database className="h-4 w-4" />}
        />
        <StatsCard
          title="Active Feeds"
          value={dashboardStats.activeFeeds}
          icon={<Radio className="h-4 w-4" />}
        />
        <StatsCard
          title="Operators"
          value={dashboardStats.totalOperators}
          icon={<Users className="h-4 w-4" />}
        />
        <StatsCard
          title="Total Stake"
          value={shortenNumber(dashboardStats.totalStake) + " ETH"}
          icon={<Shield className="h-4 w-4" />}
        />
        <StatsCard
          title="Avg Latency"
          value={dashboardStats.avgLatency + "s"}
          icon={<Zap className="h-4 w-4" />}
        />
        <StatsCard
          title="Slashing Events"
          value={dashboardStats.slashingEvents}
          icon={<AlertTriangle className="h-4 w-4" />}
        />
      </div>

      <div>
        <h2 className="text-lg font-semibold mb-3">Top Price Feeds</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {topFeeds.map((feed) => (
            <FeedCard key={feed.id} feed={feed} />
          ))}
        </div>
      </div>

      <div>
        <h2 className="text-lg font-semibold mb-3">Top Operators</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {operators.slice(0, 6).map((op) => (
            <div key={op.id} className="border rounded-lg p-4 hover:shadow-sm transition-shadow">
              <div className="flex items-center justify-between mb-2">
                <p className="font-semibold">{op.name}</p>
                <span className={`text-xs px-2 py-0.5 rounded-full ${op.status === "active" ? "bg-green-100 text-green-800" : op.status === "jailed" ? "bg-red-100 text-red-800" : "bg-gray-100 text-gray-800"}`}>
                  {op.status}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <p className="text-muted-foreground">Stake</p>
                  <p className="font-medium">{op.stake.toLocaleString()} ETH</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Accuracy</p>
                  <p className="font-medium">{op.accuracy}%</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Submissions</p>
                  <p className="font-medium">{shortenNumber(op.totalSubmissions)}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Feeds</p>
                  <p className="font-medium">{op.activeFeeds.length}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
