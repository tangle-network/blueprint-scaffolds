import { useParams, Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import OperatorPanel from "@/components/OperatorPanel";
import { operators, feeds } from "@/lib/mock-data";
import { formatAddress, formatPrice, timeAgo, shortenNumber } from "@/lib/utils";

export default function OperatorDetail() {
  const { operatorId } = useParams<{ operatorId: string }>();
  const operator = operators.find((o) => o.id === operatorId);

  if (!operator) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">Operator not found.</p>
        <Link to="/operators"><Button variant="outline" className="mt-4">Back to Operators</Button></Link>
      </div>
    );
  }

  const operatorFeeds = feeds.filter((f) => operator.activeFeeds.includes(f.id));
  const validRate = operator.totalSubmissions > 0 ? ((operator.validSubmissions / operator.totalSubmissions) * 100).toFixed(2) : "0";

  return (
    <div className="space-y-6">
      <div>
        <Link to="/operators" className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-2">
          <ArrowLeft className="h-4 w-4" /> Back to Operators
        </Link>
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-bold">{operator.name}</h1>
          <Badge variant={operator.status === "active" ? "default" : operator.status === "jailed" ? "destructive" : "secondary"}>
            {operator.status}
          </Badge>
        </div>
        <p className="text-muted-foreground font-mono text-sm">{operator.address}</p>
      </div>

      <OperatorPanel operator={operator} />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Total Submissions</p>
            <p className="text-xl font-bold">{shortenNumber(operator.totalSubmissions)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Valid Submissions</p>
            <p className="text-xl font-bold">{shortenNumber(operator.validSubmissions)}</p>
            <p className="text-xs text-muted-foreground">{validRate}% validity rate</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Accuracy</p>
            <p className="text-xl font-bold">{operator.accuracy}%</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Slashing Events</p>
            <p className="text-xl font-bold text-red-600">{operator.slashingEvents}</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Active Feeds ({operatorFeeds.length})</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Pair</TableHead>
                <TableHead>Category</TableHead>
                <TableHead className="text-right">Price</TableHead>
                <TableHead className="text-right">Method</TableHead>
                <TableHead className="text-right">Last Updated</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {operatorFeeds.map((feed) => (
                <TableRow key={feed.id}>
                  <TableCell>
                    <Link to={`/feeds/${feed.id}`} className="font-medium hover:underline">{feed.pair}</Link>
                  </TableCell>
                  <TableCell className="capitalize">{feed.category}</TableCell>
                  <TableCell className="text-right">${formatPrice(feed.latestPrice, feed.decimals)}</TableCell>
                  <TableCell className="text-right capitalize">{feed.aggregationMethod.replace("_", " ")}</TableCell>
                  <TableCell className="text-right text-muted-foreground">{timeAgo(feed.lastUpdated)}</TableCell>
                  <TableCell>
                    <Badge variant={feed.status === "active" ? "default" : "secondary"}>{feed.status}</Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
