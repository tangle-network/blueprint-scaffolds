import { useState } from "react";
import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { operators } from "@/lib/mock-data";
import { formatAddress, shortenNumber, timeAgo } from "@/lib/utils";
import { Search } from "lucide-react";

export default function Operators() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const filtered = operators.filter((op) => {
    const matchSearch = op.name.toLowerCase().includes(search.toLowerCase()) || op.address.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || op.status === statusFilter;
    return matchSearch && matchStatus;
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Operators</h1>
        <p className="text-muted-foreground">Registered oracle operators and their performance</p>
      </div>

      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
        <div className="relative max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search operators..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex gap-2">
          {["all", "active", "jailed", "deregistered"].map((s) => (
            <Button key={s} variant={statusFilter === s ? "default" : "outline"} size="sm" onClick={() => setStatusFilter(s)} className="capitalize">
              {s}
            </Button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Total Operators</p>
            <p className="text-2xl font-bold">{operators.length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Total Stake</p>
            <p className="text-2xl font-bold">{shortenNumber(operators.reduce((s, o) => s + o.stake, 0))} ETH</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Avg Accuracy</p>
            <p className="text-2xl font-bold">{(operators.reduce((s, o) => s + o.accuracy, 0) / operators.length).toFixed(2)}%</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Operator</TableHead>
                <TableHead>Address</TableHead>
                <TableHead className="text-right">Stake</TableHead>
                <TableHead className="text-right">Accuracy</TableHead>
                <TableHead className="text-right">Submissions</TableHead>
                <TableHead className="text-right">Slashes</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Registered</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((op) => (
                <TableRow key={op.id}>
                  <TableCell>
                    <Link to={`/operators/${op.id}`} className="font-medium hover:underline">{op.name}</Link>
                  </TableCell>
                  <TableCell className="text-muted-foreground">{formatAddress(op.address)}</TableCell>
                  <TableCell className="text-right">{op.stake.toLocaleString()} ETH</TableCell>
                  <TableCell className="text-right">{op.accuracy}%</TableCell>
                  <TableCell className="text-right">{shortenNumber(op.totalSubmissions)}</TableCell>
                  <TableCell className="text-right">{op.slashingEvents}</TableCell>
                  <TableCell>
                    <Badge variant={op.status === "active" ? "default" : op.status === "jailed" ? "destructive" : "secondary"}>
                      {op.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right text-muted-foreground">{timeAgo(op.registeredSince)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
