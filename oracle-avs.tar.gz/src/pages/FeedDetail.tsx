import { useParams, Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import PriceChart from "@/components/PriceChart";
import AggregationView from "@/components/AggregationView";
import { feeds, generateSubmissions, generatePriceHistory } from "@/lib/mock-data";
import { detectOutliers } from "@/lib/aggregation";
import { formatPrice, formatPercent, timeAgo } from "@/lib/utils";

export default function FeedDetail() {
  const { feedId } = useParams<{ feedId: string }>();
  const feed = feeds.find((f) => f.id === feedId);

  if (!feed) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">Feed not found.</p>
        <Link to="/feeds"><Button variant="outline" className="mt-4">Back to Feeds</Button></Link>
      </div>
    );
  }

  const change = ((feed.latestPrice - feed.previousPrice) / feed.previousPrice) * 100;
  const submissions = generateSubmissions(feed.id);
  const { valid, outliers } = detectOutliers(submissions);
  const allSubs = [...valid, ...outliers];
  const priceHistory = generatePriceHistory(feed.id);

  return (
    <div className="space-y-6">
      <div>
        <Link to="/feeds" className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-2">
          <ArrowLeft className="h-4 w-4" /> Back to Feeds
        </Link>
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-bold">{feed.pair}</h1>
          <Badge variant="outline" className="capitalize">{feed.category}</Badge>
          <Badge variant={feed.status === "active" ? "default" : "secondary"}>{feed.status}</Badge>
        </div>
        <p className="text-muted-foreground">{feed.name}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Current Price</p>
            <p className="text-2xl font-bold">${formatPrice(feed.latestPrice, feed.decimals)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">24h Change</p>
            <p className={`text-2xl font-bold ${change >= 0 ? "text-green-600" : "text-red-600"}`}>
              {formatPercent(change)}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Aggregation</p>
            <p className="text-2xl font-bold capitalize">{feed.aggregationMethod.replace("_", " ")}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Last Updated</p>
            <p className="text-2xl font-bold">{timeAgo(feed.lastUpdated)}</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Price History</CardTitle>
        </CardHeader>
        <CardContent>
          <PriceChart data={priceHistory} decimals={feed.decimals} height={350} />
        </CardContent>
      </Card>

      <Tabs defaultValue="submissions">
        <TabsList>
          <TabsTrigger value="submissions">Submissions ({allSubs.length})</TabsTrigger>
          <TabsTrigger value="outliers">Outliers ({outliers.length})</TabsTrigger>
        </TabsList>
        <TabsContent value="submissions">
          <AggregationView submissions={allSubs} method={feed.aggregationMethod} decimals={feed.decimals} />
        </TabsContent>
        <TabsContent value="outliers">
          {outliers.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">No outliers detected in the current round.</p>
          ) : (
            <AggregationView submissions={outliers} method={feed.aggregationMethod} decimals={feed.decimals} />
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
