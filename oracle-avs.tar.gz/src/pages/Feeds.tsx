import { useState } from "react";
import FeedCard from "@/components/FeedCard";
import FeedFilters from "@/components/FeedFilters";
import { Input } from "@/components/ui/input";
import { feeds } from "@/lib/mock-data";
import type { FeedCategory } from "@/lib/types";

export default function Feeds() {
  const [category, setCategory] = useState<FeedCategory | "all">("all");
  const [search, setSearch] = useState("");

  const filtered = feeds.filter((feed) => {
    const matchCategory = category === "all" || feed.category === category;
    const matchSearch = feed.pair.toLowerCase().includes(search.toLowerCase()) || feed.name.toLowerCase().includes(search.toLowerCase());
    return matchCategory && matchSearch;
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Price Feeds</h1>
        <p className="text-muted-foreground">Browse all oracle price feeds</p>
      </div>

      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
        <FeedFilters selected={category} onSelect={setCategory} />
        <Input
          placeholder="Search feeds..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="max-w-xs"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filtered.map((feed) => (
          <FeedCard key={feed.id} feed={feed} />
        ))}
      </div>

      {filtered.length === 0 && (
        <p className="text-center text-muted-foreground py-8">No feeds match your filters.</p>
      )}
    </div>
  );
}
