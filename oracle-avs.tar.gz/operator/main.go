package main

import (
	"context"
	"crypto/ecdsa"
	"encoding/json"
	"flag"
	"fmt"
	"math/big"
	"net/http"
	"os"
	"time"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/crypto"
)

type Submission struct {
	Operator  string  `json:"operator"`
	FeedID    string  `json:"feedId"`
	Source    string  `json:"source"`
	Value     float64 `json:"value"`
	Timestamp int64   `json:"timestamp"`
	Sig       string  `json:"signature"`
}

func main() {
	var (
		feedID = flag.String("feed", "crypto:eth-usd", "feed id")
		source = flag.String("source", "COINBASE", "source id")
		url    = flag.String("url", "https://api.coinbase.com/v2/prices/ETH-USD/spot", "fetch URL")
		keyHex = flag.String("key", "", "operator ECDSA private key hex (no 0x)")
	)
	flag.Parse()

	if *keyHex == "" {
		fmt.Fprintln(os.Stderr, "missing -key")
		os.Exit(2)
	}
	priv, err := crypto.HexToECDSA(*keyHex)
	if err != nil {
		panic(err)
	}
	operator := crypto.PubkeyToAddress(priv.PublicKey)

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	price, err := fetchCoinbase(ctx, *url)
	if err != nil {
		panic(err)
	}

	ts := time.Now().Unix()
	msgHash := submissionHash(*feedID, *source, price, ts)
	sig, err := crypto.Sign(msgHash.Bytes(), priv)
	if err != nil {
		panic(err)
	}

	sub := Submission{
		Operator:  operator.Hex(),
		FeedID:    *feedID,
		Source:    *source,
		Value:     price,
		Timestamp: ts,
		Sig:       common.Bytes2Hex(sig),
	}
	enc := json.NewEncoder(os.Stdout)
	enc.SetIndent("", "  ")
	_ = enc.Encode(sub)
}

func submissionHash(feedID, source string, value float64, ts int64) common.Hash {
	// Reference hash for signing. Production would use EIP-712.
	// Pack as a simple string for demo purposes.
	payload := fmt.Sprintf("%s|%s|%0.10f|%d", feedID, source, value, ts)
	return crypto.Keccak256Hash([]byte(payload))
}

func fetchCoinbase(ctx context.Context, url string) (float64, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return 0, err
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return 0, err
	}
	defer resp.Body.Close()
	if resp.StatusCode/100 != 2 {
		return 0, fmt.Errorf("bad status: %s", resp.Status)
	}
	var out struct {
		Data struct {
			Amount string `json:"amount"`
		} `json:"data"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&out); err != nil {
		return 0, err
	}
	f, ok := new(big.Float).SetString(out.Data.Amount)
	if !ok {
		return 0, fmt.Errorf("parse amount")
	}
	v, _ := f.Float64()
	return v, nil
}

// Keep compiler from optimizing away imports in templates.
var _ *ecdsa.PrivateKey
