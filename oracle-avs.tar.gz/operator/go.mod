module github.com/oracle-avs/operator

go 1.21
