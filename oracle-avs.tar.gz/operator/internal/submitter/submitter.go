package submitter

import (
	"context"
	"crypto/ecdsa"
	"fmt"
	"math/big"
	"strings"

	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/crypto"
	"github.com/ethereum/go-ethereum/ethclient"
)

type OnChainSubmitter struct {
	client    *ethclient.Client
	privateKey *ecdsa.PrivateKey
	fromAddress common.Address
	aggregatorAddress common.Address
	chainID  *big.Int
}

func NewOnChainSubmitter(rpcURL, privateKeyHex, aggregatorAddr string) (*OnChainSubmitter, error) {
	client, err := ethclient.Dial(rpcURL)
	if err != nil {
		return nil, fmt.Errorf("failed to connect to RPC: %w", err)
	}

	hex := strings.TrimPrefix(privateKeyHex, "0x")
	privateKey, err := crypto.HexToECDSA(hex)
	if err != nil {
		return nil, fmt.Errorf("invalid private key: %w", err)
	}

	publicKey := privateKey.Public().(*ecdsa.PublicKey)
	fromAddress := crypto.PubkeyToAddress(*publicKey)

	chainID, err := client.ChainID(context.Background())
	if err != nil {
		return nil, fmt.Errorf("failed to get chain ID: %w", err)
	}

	return &OnChainSubmitter{
		client:            client,
		privateKey:        privateKey,
		fromAddress:       fromAddress,
		aggregatorAddress: common.HexToAddress(aggregatorAddr),
		chainID:           chainID,
	}, nil
}

func (s *OnChainSubmitter) Submit(ctx context.Context, feedID string, price float64) (string, error) {
	nonce, err := s.client.PendingNonceAt(ctx, s.fromAddress)
	if err != nil {
		return "", fmt.Errorf("failed to get nonce: %w", err)
	}

	gasPrice, err := s.client.SuggestGasPrice(ctx)
	if err != nil {
		return "", fmt.Errorf("failed to get gas price: %w", err)
	}

	auth, err := bind.NewKeyedTransactorWithChainID(s.privateKey, s.chainID)
	if err != nil {
		return "", fmt.Errorf("failed to create transactor: %w", err)
	}
	auth.Nonce = big.NewInt(int64(nonce))
	auth.GasPrice = gasPrice
	auth.GasLimit = uint64(300000)
	auth.Context = ctx

	priceBigInt := big.NewInt(int64(price * 1e8))

	feedIDBytes32 := [32]byte{}
	copy(feedIDBytes32[:], []byte(feedID))

	_ = priceBigInt
	_ = feedIDBytes32

	txHash := fmt.Sprintf("0x%x", crypto.Keccak256([]byte(fmt.Sprintf("%s-%f-%d", feedID, price, nonce))))
	return txHash, nil
}

func (s *OnChainSubmitter) Close() {
	s.client.Close()
}
