package fetcher

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"net/http"
	"sync"
	"time"
)

type PriceResult struct {
	Source    string
	FeedID    string
	Price     float64
	Timestamp int64
	Error     error
}

type SourceConfig struct {
	Name     string
	FetchFn  func(ctx context.Context, feedID string) (float64, error)
	Priority int
}

type MultiSourceFetcher struct {
	sources []SourceConfig
	client  *http.Client
}

type Option func(*MultiSourceFetcher)

func WithCoinGecko() Option {
	return func(f *MultiSourceFetcher) {
		f.sources = append(f.sources, SourceConfig{
			Name:     "coingecko",
			Priority: 1,
			FetchFn:  f.fetchCoinGecko,
		})
	}
}

func WithCoinCap() Option {
	return func(f *MultiSourceFetcher) {
		f.sources = append(f.sources, SourceConfig{
			Name:     "coincap",
			Priority: 2,
			FetchFn:  f.fetchCoinCap,
		})
	}
}

func WithFallbackPrice() Option {
	return func(f *MultiSourceFetcher) {
		f.sources = append(f.sources, SourceConfig{
			Name:     "fallback",
			Priority: 99,
			FetchFn: func(ctx context.Context, feedID string) (float64, error) {
				return 0, fmt.Errorf("no price available for %s", feedID)
			},
		})
	}
}

func NewMultiSourceFetcher(opts ...Option) *MultiSourceFetcher {
	f := &MultiSourceFetcher{
		client: &http.Client{Timeout: 10 * time.Second},
	}
	for _, opt := range opts {
		opt(f)
	}
	return f
}

func (f *MultiSourceFetcher) Fetch(ctx context.Context, feedID string) ([]PriceResult, error) {
	var wg sync.WaitGroup
	results := make([]PriceResult, len(f.sources))

	for i, src := range f.sources {
		wg.Add(1)
		go func(idx int, s SourceConfig) {
			defer wg.Done()
			price, err := s.FetchFn(ctx, feedID)
			results[idx] = PriceResult{
				Source:    s.Name,
				FeedID:    feedID,
				Price:     price,
				Timestamp: time.Now().Unix(),
				Error:     err,
			}
		}(i, src)
	}
	wg.Wait()

	var valid []PriceResult
	for _, r := range results {
		if r.Error == nil && !math.IsNaN(r.Price) && r.Price > 0 {
			valid = append(valid, r)
		}
	}

	if len(valid) == 0 {
		return nil, fmt.Errorf("no valid prices for feed %s", feedID)
	}
	return valid, nil
}

func (f *MultiSourceFetcher) fetchCoinGecko(ctx context.Context, feedID string) (float64, error) {
	coinMap := map[string]string{
		"btc-usd": "bitcoin", "eth-usd": "ethereum", "sol-usd": "solana",
		"dai-usd": "dai", "steth-usd": "steth", "reth-usd": "rocket-pool-eth",
	}
	coin, ok := coinMap[feedID]
	if !ok {
		return 0, fmt.Errorf("feed %s not supported by coingecko", feedID)
	}

	url := fmt.Sprintf("https://api.coingecko.com/api/v3/simple/price?ids=%s&vs_currencies=usd", coin)
	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return 0, err
	}

	resp, err := f.client.Do(req)
	if err != nil {
		return 0, err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return 0, err
	}

	var result map[string]map[string]float64
	if err := json.Unmarshal(body, &result); err != nil {
		return 0, err
	}

	if data, ok := result[coin]; ok {
		if price, ok := data["usd"]; ok {
			return price, nil
		}
	}
	return 0, fmt.Errorf("price not found in response")
}

func (f *MultiSourceFetcher) fetchCoinCap(ctx context.Context, feedID string) (float64, error) {
	assetMap := map[string]string{
		"btc-usd": "bitcoin", "eth-usd": "ethereum", "sol-usd": "solana",
	}
	asset, ok := assetMap[feedID]
	if !ok {
		return 0, fmt.Errorf("feed %s not supported by coincap", feedID)
	}

	url := fmt.Sprintf("https://api.coincap.io/v2/assets/%s", asset)
	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return 0, err
	}

	resp, err := f.client.Do(req)
	if err != nil {
		return 0, err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return 0, err
	}

	var result struct {
		Data struct {
			PriceUsd string `json:"priceUsd"`
		} `json:"data"`
	}
	if err := json.Unmarshal(body, &result); err != nil {
		return 0, err
	}

	var price float64
	fmt.Sscanf(result.Data.PriceUsd, "%f", &price)
	if price <= 0 {
		return 0, fmt.Errorf("invalid price from coincap")
	}
	return price, nil
}
