package aggregator

import (
	"math"
	"sort"

	"github.com/oracle-avs/operator/internal/fetcher"
)

type AggregationResult struct {
	Value       float64
	ValidPrices []float64
	Outliers    []float64
	Method      string
}

type LocalAggregator struct {
	outlierThreshold float64
}

func NewLocalAggregator(outlierThreshold float64) *LocalAggregator {
	return &LocalAggregator{outlierThreshold: outlierThreshold}
}

func (a *LocalAggregator) Aggregate(results []fetcher.PriceResult) AggregationResult {
	prices := make([]float64, 0, len(results))
	for _, r := range results {
		if r.Error == nil && r.Price > 0 {
			prices = append(prices, r.Price)
		}
	}

	if len(prices) == 0 {
		return AggregationResult{Method: "median"}
	}

	median := computeMedian(prices)

	validPrices := make([]float64, 0)
	outliers := make([]float64, 0)

	for _, p := range prices {
		deviation := math.Abs(p-median) / median
		if deviation > a.outlierThreshold {
			outliers = append(outliers, p)
		} else {
			validPrices = append(validPrices, p)
		}
	}

	finalMedian := median
	if len(validPrices) > 0 {
		finalMedian = computeMedian(validPrices)
	}

	return AggregationResult{
		Value:       finalMedian,
		ValidPrices: validPrices,
		Outliers:    outliers,
		Method:      "median",
	}
}

func computeMedian(prices []float64) float64 {
	if len(prices) == 0 {
		return 0
	}
	sorted := make([]float64, len(prices))
	copy(sorted, prices)
	sort.Float64s(sorted)

	mid := len(sorted) / 2
	if len(sorted)%2 == 0 {
		return (sorted[mid-1] + sorted[mid]) / 2
	}
	return sorted[mid]
}
