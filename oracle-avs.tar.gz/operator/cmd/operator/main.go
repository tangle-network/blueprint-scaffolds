package main

import (
	"context"
	"log"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/oracle-avs/operator/internal/aggregator"
	"github.com/oracle-avs/operator/internal/fetcher"
	"github.com/oracle-avs/operator/internal/submitter"
)

type Config struct {
	Feeds             []string
	FetchInterval     time.Duration
	RPCURL            string
	PrivateKey        string
	AggregatorAddress string
	OutlierThreshold  float64
}

func main() {
	cfg := Config{
		Feeds: []string{
			"btc-usd", "eth-usd", "sol-usd",
			"eur-usd", "gbp-usd",
			"xau-usd", "xag-usd", "cl-usd",
			"steth-usd", "reth-usd", "dai-usd",
		},
		FetchInterval:     60 * time.Second,
		RPCURL:            getEnv("RPC_URL", "http://localhost:8545"),
		PrivateKey:        getEnv("PRIVATE_KEY", ""),
		AggregatorAddress: getEnv("AGGREGATOR_ADDRESS", ""),
		OutlierThreshold:  2.0,
	}

	if cfg.PrivateKey == "" {
		log.Fatal("PRIVATE_KEY env var is required")
	}
	if cfg.AggregatorAddress == "" {
		log.Fatal("AGGREGATOR_ADDRESS env var is required")
	}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)

	f := fetcher.NewMultiSourceFetcher(
		fetcher.WithCoinGecko(),
		fetcher.WithCoinCap(),
		fetcher.WithFallbackPrice(),
	)

	agg := aggregator.NewLocalAggregator(cfg.OutlierThreshold)

	sub, err := submitter.NewOnChainSubmitter(cfg.RPCURL, cfg.PrivateKey, cfg.AggregatorAddress)
	if err != nil {
		log.Fatalf("Failed to create submitter: %v", err)
	}

	ticker := time.NewTicker(cfg.FetchInterval)
	defer ticker.Stop()

	log.Println("Oracle operator started, monitoring feeds:", cfg.Feeds)

	for {
		select {
		case <-ctx.Done():
			log.Println("Shutting down...")
			return
		case sig := <-sigCh:
			log.Printf("Received signal %v, shutting down...", sig)
			cancel()
		case <-ticker.C:
			for _, feedID := range cfg.Feeds {
				prices, err := f.Fetch(ctx, feedID)
				if err != nil {
					log.Printf("Error fetching %s: %v", feedID, err)
					continue
				}

				result := agg.Aggregate(prices)
				log.Printf("[%s] aggregated=%.4f (sources=%d, outliers=%d)",
					feedID, result.Value, len(result.ValidPrices), len(result.Outliers))

				txHash, err := sub.Submit(ctx, feedID, result.Value)
				if err != nil {
					log.Printf("Error submitting %s: %v", feedID, err)
					continue
				}
				log.Printf("[%s] submitted price=%.4f tx=%s", feedID, result.Value, txHash)
			}
		}
	}
}

func getEnv(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}
