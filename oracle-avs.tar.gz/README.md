# EigenLayer Oracle AVS (Demo Build)

This is a compile-clean demo project that includes:

- Vite + React + TypeScript frontend feed explorer (`src/`)
- Reference Solidity contracts (`contracts/`) describing an oracle AVS coordinator + aggregator + consumer interface
- Reference Go operator fetcher/submitter (`operator/`)

The frontend simulates the AVS mechanics locally: multi-operator stake-weighted submissions, median/TWAP aggregation, outlier
detection, and freshness checks.

## Scripts

- `pnpm dev`
- `pnpm build`
