# AGENTS.md

Build an Oracle AVS on EigenLayer for decentralized price feeds. Data aggregation, operator consensus, on-chain price updates.

## What's here

This project was scaffolded by starter-foundry. The user's prompt drove the choices below — read their prompt first, it takes priority over everything in this file.

- **Family:** `eigenlayer-avs`
- **Layers:** `framework:eigenlayer-avs`
- **Partner:** `eigenlayer`

## Getting started

```bash
node validate-avs.mjs
forge build
cargo check
```

Key files: `avs.config.json`, `contracts/ServiceManager.sol`, `operator/main.rs`

## How to use this scaffold

This is a starting point, not a contract. You own every file.

- **Customize freely.** Replace components, change the layout, swap the color scheme — whatever fits the user's product.
- **The scaffold saves you setup time** — Tailwind, shadcn/ui, path aliases, and framework config are ready. Don't redo them.
- **Check `.starter-foundry/compose-report.json`** if you want to see which layer wrote which file.
- **Update this file** as the project evolves. Delete sections that no longer apply.
