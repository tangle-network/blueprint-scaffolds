# Oracle AVS on EigenLayer — Build Plan

## Overview
Decentralized oracle AVS on EigenLayer for multi-source price feeds with aggregation, slashing, and stake-weighted submissions.

## Architecture
- **Smart Contracts (Solidity)**: OracleCoordinator, PriceAggregator, IPriceConsumer, OperatorRegistry
- **Operator Software (Go)**: Price fetcher, submitter, aggregation engine
- **Frontend (Vite + React + TypeScript)**: Feed explorer dashboard

## Frontend Pages
- `/` — Dashboard with feed overview, latest prices, operator stats
- `/feeds` — Feed explorer with all price feeds (crypto, forex, commodities, custom)
- `/feeds/:feedId` — Single feed detail with price chart, aggregation method, operator submissions
- `/operators` — Operator registry with staking info, performance metrics
- `/operators/:operatorId` — Single operator detail with submission history

## Frontend Components
- `src/components/ui/` — shadcn/ui primitives (Button, Card, Badge, Tabs, Table, Input, Select, Tooltip)
- `src/components/Navbar.tsx` — Navigation bar
- `src/components/FeedCard.tsx` — Price feed card with latest price, change, status
- `src/components/PriceChart.tsx` — Price history chart (recharts)
- `src/components/AggregationView.tsx` — Shows median/TWAP calculation, operator submissions
- `src/components/OperatorPanel.tsx` — Operator staking/submission panel
- `src/components/FeedFilters.tsx` — Filter by category (crypto, forex, commodities, custom)
- `src/components/StatsCard.tsx` — Dashboard stat card

## Lib Files
- `src/lib/types.ts` — TypeScript types for feeds, operators, prices, submissions
- `src/lib/utils.ts` — Formatting helpers (formatPrice, formatPercent, cn)
- `src/lib/mock-data.ts` — Realistic mock data for all feeds, operators, submissions
- `src/lib/aggregation.ts` — Client-side median/TWAP/outlier detection logic

## Smart Contracts (contracts/)
- `contracts/OracleCoordinator.sol` — Main coordinator: manages feeds, operator registration, slashing
- `contracts/PriceAggregator.sol` — Aggregation logic: median, TWAP, outlier detection, freshness
- `contracts/interfaces/IPriceConsumer.sol` — Consumer interface for reading prices
- `contracts/interfaces/IOperatorRegistry.sol` — Operator registration interface

## Operator Software (operator/)
- `operator/cmd/operator/main.go` — Entry point
- `operator/internal/fetcher/fetcher.go` — Multi-source price fetching
- `operator/internal/submitter/submitter.go` — On-chain submission
- `operator/internal/aggregator/aggregator.go` — Local aggregation/outlier detection

## Build
- `pnpm install && pnpm build` must pass
