import { useEffect, useState } from 'react';
import { Header } from './components/Header';
import { FileList } from './components/FileList';
import { CodeViewer } from './components/CodeViewer';
import { ManipulationPanel } from './components/ManipulationPanel';
import { MetricCards } from './components/MetricCards';
import { ToolPanel } from './components/ToolPanel';
import { sampleDocuments } from './data/samples';
import { analyzeDocument } from './core/analyzer';
import { createMcpManifest } from './core/mcp';
import type { AnalysisReport } from './types';

export default function App() {
  const [activePath, setActivePath] = useState(sampleDocuments[0].path);
  const [report, setReport] = useState<AnalysisReport | null>(null);
  const manifest = createMcpManifest();

  useEffect(() => {
    const activeDocument = sampleDocuments.find((document) => document.path === activePath);
    if (!activeDocument) {
      return;
    }

    analyzeDocument(activeDocument).then(setReport);
  }, [activePath]);

  return (
    <div className="app-shell">
      <Header />
      <main className="layout">
        <div className="sidebar">
          <FileList documents={sampleDocuments} activePath={activePath} onSelect={setActivePath} />
          <ToolPanel tools={manifest.tools} report={report} />
        </div>
        <div className="content">
          {report ? <MetricCards metrics={report.metrics} /> : null}
          <CodeViewer report={report} />
          <ManipulationPanel report={report} />
        </div>
      </main>
    </div>
  );
}
