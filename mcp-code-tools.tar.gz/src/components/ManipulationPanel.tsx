import type { AnalysisReport } from '../types';

interface ManipulationPanelProps {
  report: AnalysisReport | null;
}

export function ManipulationPanel({ report }: ManipulationPanelProps) {
  if (!report) {
    return null;
  }

  return (
    <section className="panel">
      <div className="panel-header">
        <h2>Manipulation</h2>
        <span>Preview only</span>
      </div>
      <div className="preview-grid">
        {[report.manipulation.formatted, report.manipulation.organizedImports].map((preview) => (
          <article key={preview.label} className="preview-card">
            <h3>{preview.label}</h3>
            <div className="preview-columns">
              <div>
                <span>Before</span>
                <pre>{preview.before}</pre>
              </div>
              <div>
                <span>After</span>
                <pre>{preview.after}</pre>
              </div>
            </div>
          </article>
        ))}
      </div>
      <article className="subpanel">
        <h3>Refactoring Suggestions</h3>
        {report.suggestions.map((suggestion) => (
          <div key={suggestion.id} className="suggestion">
            <strong>{suggestion.title}</strong>
            <p>{suggestion.rationale}</p>
            <span>{suggestion.action}</span>
          </div>
        ))}
      </article>
    </section>
  );
}
