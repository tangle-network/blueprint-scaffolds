import type { MetricSummary } from '../types';

interface MetricCardsProps {
  metrics: MetricSummary;
}

export function MetricCards({ metrics }: MetricCardsProps) {
  const cards = [
    ['Lines', metrics.lines],
    ['Functions', metrics.functions],
    ['Classes', metrics.classes],
    ['Imports', metrics.imports],
    ['Complexity', metrics.cyclomaticComplexity],
    ['Coverage', `${metrics.coverageEstimate}%`],
    ['Maintainability', metrics.maintainabilityIndex],
  ];

  return (
    <section className="metrics-grid">
      {cards.map(([label, value]) => (
        <article key={label} className="metric-card">
          <span>{label}</span>
          <strong>{value}</strong>
        </article>
      ))}
    </section>
  );
}
