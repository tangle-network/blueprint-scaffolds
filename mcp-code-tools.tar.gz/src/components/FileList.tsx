import type { SourceDocument } from '../types';
import { languageLabels } from '../core/language';

interface FileListProps {
  documents: SourceDocument[];
  activePath: string;
  onSelect: (path: string) => void;
}

export function FileList({ documents, activePath, onSelect }: FileListProps) {
  return (
    <section className="panel">
      <div className="panel-header">
        <h2>Workspace</h2>
        <span>{documents.length} files</span>
      </div>
      <div className="file-list">
        {documents.map((document) => (
          <button
            key={document.path}
            className={document.path === activePath ? 'file-item active' : 'file-item'}
            onClick={() => onSelect(document.path)}
          >
            <strong>{document.path}</strong>
            <span>{languageLabels[document.language]}</span>
          </button>
        ))}
      </div>
    </section>
  );
}
