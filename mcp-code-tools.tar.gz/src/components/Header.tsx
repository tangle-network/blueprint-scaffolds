export function Header() {
  return (
    <header className="hero">
      <div>
        <p className="eyebrow">Model Context Protocol</p>
        <h1>MCP tools for code analysis and manipulation.</h1>
        <p className="hero-copy">
          Tree-sitter-powered analysis for TypeScript, Python, Go, and Rust with
          lint adapters, metrics, search, formatting previews, dead code checks,
          and refactoring guidance.
        </p>
      </div>
      <div className="hero-card">
        <span>Capabilities</span>
        <strong>8 MCP tools</strong>
        <p>AST parsing, regex and symbol search, complexity, coverage, imports, formatting, and suggestions.</p>
      </div>
    </header>
  );
}
