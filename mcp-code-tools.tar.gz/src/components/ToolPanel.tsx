import type { AnalysisReport, ToolDescriptor } from '../types';

interface ToolPanelProps {
  tools: ToolDescriptor[];
  report: AnalysisReport | null;
}

export function ToolPanel({ tools, report }: ToolPanelProps) {
  return (
    <section className="panel">
      <div className="panel-header">
        <h2>MCP Tooling</h2>
        <span>{tools.length} registered</span>
      </div>
      <div className="tool-grid">
        {tools.map((tool) => (
          <article key={tool.name} className="tool-card">
            <div className="tool-topline">
              <strong>{tool.name}</strong>
              <span>{tool.category}</span>
            </div>
            <p>{tool.description}</p>
          </article>
        ))}
      </div>
      {report ? (
        <div className="results-grid">
          <article className="subpanel">
            <h3>Symbols</h3>
            {report.symbols.map((symbol) => (
              <div key={`${symbol.name}-${symbol.line}`} className="row">
                <span>{symbol.kind}</span>
                <strong>{symbol.name}</strong>
                <span>L{symbol.line}</span>
              </div>
            ))}
          </article>
          <article className="subpanel">
            <h3>Lint</h3>
            {report.lintIssues.map((issue) => (
              <div key={`${issue.rule}-${issue.line}`} className="row">
                <span>{issue.tool}</span>
                <strong>{issue.rule}</strong>
                <span>L{issue.line}</span>
              </div>
            ))}
          </article>
          <article className="subpanel">
            <h3>Search</h3>
            {report.searches.regex.map((match) => (
              <div key={`${match.line}-${match.column}`} className="row">
                <span>{match.kind}</span>
                <strong>{match.preview}</strong>
                <span>L{match.line}</span>
              </div>
            ))}
          </article>
          <article className="subpanel">
            <h3>Dead Code</h3>
            {report.deadCode.map((name) => (
              <div key={name} className="row">
                <span>candidate</span>
                <strong>{name}</strong>
              </div>
            ))}
          </article>
        </div>
      ) : null}
    </section>
  );
}
