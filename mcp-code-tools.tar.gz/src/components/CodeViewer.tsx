import type { AnalysisReport } from '../types';

interface CodeViewerProps {
  report: AnalysisReport | null;
}

export function CodeViewer({ report }: CodeViewerProps) {
  if (!report) {
    return null;
  }

  return (
    <section className="panel code-panel">
      <div className="panel-header">
        <h2>Code Viewer</h2>
        <span>{report.document.language}</span>
      </div>
      <pre>
        <code>{report.document.content}</code>
      </pre>
    </section>
  );
}
