export interface SourceFile {
  path: string;
  language: string;
  content: string;
}

export interface ASTNode {
  type: string;
  start: { row: number; column: number };
  end: { row: number; column: number };
  children: ASTNode[];
  text?: string;
}

export interface Diagnostic {
  severity: "error" | "warning" | "info";
  message: string;
  line: number;
  column: number;
  endLine?: number;
  endColumn?: number;
  ruleId?: string;
  source?: string;
}

export interface CodeMetrics {
  cyclomaticComplexity: number;
  linesOfCode: number;
  commentLines: number;
  blankLines: number;
  functions: number;
  classes: number;
  imports: number;
  maintainabilityIndex: number;
}

export interface SearchResult {
  file: string;
  line: number;
  column: number;
  match: string;
  context: string;
}

export interface SymbolInfo {
  name: string;
  kind: "function" | "class" | "interface" | "variable" | "import" | "export" | "type" | "enum" | "method" | "property";
  file: string;
  line: number;
  column: number;
}

export interface ReferenceResult {
  symbol: string;
  references: Array<{
    file: string;
    line: number;
    column: number;
    context: string;
  }>;
}

export interface RefactorSuggestion {
  type: "extract-function" | "extract-variable" | "rename" | "remove-unused" | "simplify" | "inline";
  description: string;
  file: string;
  startLine: number;
  endLine: number;
  suggestion: string;
  confidence: number;
}

export interface AnalysisResult {
  file: string;
  ast?: ASTNode;
  diagnostics: Diagnostic[];
  metrics: CodeMetrics;
  symbols: SymbolInfo[];
  suggestions: RefactorSuggestion[];
}

export type ToolName =
  | "parse_ast"
  | "lint"
  | "compute_metrics"
  | "search_regex"
  | "search_symbols"
  | "search_references"
  | "format_code"
  | "organize_imports"
  | "detect_dead_code"
  | "suggest_refactors";

export interface ToolCall {
  tool: ToolName;
  args: Record<string, unknown>;
}

export interface ToolResponse {
  success: boolean;
  data?: unknown;
  error?: string;
}
