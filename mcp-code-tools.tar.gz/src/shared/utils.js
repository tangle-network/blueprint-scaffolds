export const countLines = {} as any

export const cyclomaticComplexity = {} as any

export const maintainabilityIndex = {} as any
