export function detectLanguage(filePath: string): string {
  const ext = filePath.split(".").pop()?.toLowerCase() ?? "";
  const map: Record<string, string> = {
    ts: "typescript",
    tsx: "typescript",
    js: "javascript",
    jsx: "javascript",
    py: "python",
    go: "go",
    rs: "rust",
  };
  return map[ext] ?? "unknown";
}

export function countLines(content: string): {
  total: number;
  code: number;
  comment: number;
  blank: number;
} {
  const lines = content.split("\n");
  let code = 0;
  let comment = 0;
  let blank = 0;
  let inBlockComment = false;

  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed === "") {
      blank++;
      continue;
    }
    if (inBlockComment) {
      comment++;
      if (trimmed.includes("*/")) inBlockComment = false;
      continue;
    }
    if (trimmed.startsWith("/*")) {
      comment++;
      if (!trimmed.includes("*/")) inBlockComment = true;
      continue;
    }
    if (trimmed.startsWith("//") || trimmed.startsWith("#") || trimmed.startsWith("--")) {
      comment++;
      continue;
    }
    code++;
  }

  return { total: lines.length, code, comment, blank };
}

export function cyclomaticComplexity(content: string, language: string): number {
  let complexity = 1;
  const patterns = [
    /\bif\b/g,
    /\belse\s+if\b/g,
    /\bfor\b/g,
    /\bwhile\b/g,
    /\bcase\b/g,
    /\bcatch\b/g,
    /\b&&\b/g,
    /\|\|\b/g,
    /\?\?/g,
    /\?\./g,
  ];
  if (language === "python") {
    patterns.push(/\belif\b/g, /\bexcept\b/g);
  }
  for (const pattern of patterns) {
    const matches = content.match(pattern);
    if (matches) complexity += matches.length;
  }
  return complexity;
}

export function maintainabilityIndex(
  loc: number,
  cyclomatic: number,
  commentRatio: number
): number {
  if (loc === 0) return 100;
  const avgVol = Math.max(1, loc * Math.log2(Math.max(2, loc)));
  const mi =
    171 -
    5.2 * Math.log(avgVol) -
    0.23 * cyclomatic -
    16.2 * Math.log(Math.max(0.01, commentRatio * 100));
  return Math.max(0, Math.min(100, mi));
}
