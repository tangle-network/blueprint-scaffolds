import { analyzeDocument } from './analyzer';
import { formatDocument, organizeImports, detectDeadCode, suggestRefactors } from './manipulation';
import { extractSymbolsFromText } from './parser';
import { computeMetrics } from './metrics';
import { regexSearch, referenceSearch, symbolSearch } from './search';
import { runLintAdapters } from './lint';
import type { SourceDocument, ToolDescriptor, ToolResult } from '../types';

export const toolRegistry: ToolDescriptor[] = [
  {
    name: 'parse_ast',
    category: 'analysis',
    description: 'Parse TypeScript, Python, Go, and Rust source with tree-sitter.',
  },
  {
    name: 'lint_code',
    category: 'analysis',
    description: 'Run ESLint and Ruff adapters against source documents.',
  },
  {
    name: 'code_metrics',
    category: 'analysis',
    description: 'Compute complexity, maintainability, and coverage estimates.',
  },
  {
    name: 'search_code',
    category: 'analysis',
    description: 'Search by regex, symbol names, and lightweight references.',
  },
  {
    name: 'format_code',
    category: 'manipulation',
    description: 'Preview formatting changes before applying them.',
  },
  {
    name: 'organize_imports',
    category: 'manipulation',
    description: 'Sort imports and group declarations by language convention.',
  },
  {
    name: 'detect_dead_code',
    category: 'manipulation',
    description: 'Find symbols with no local references.',
  },
  {
    name: 'suggest_refactors',
    category: 'manipulation',
    description: 'Generate high-signal refactoring recommendations.',
  },
];

export async function invokeTool(tool: string, document: SourceDocument): Promise<ToolResult> {
  const symbols = extractSymbolsFromText(document);

  switch (tool) {
    case 'parse_ast': {
      const report = await analyzeDocument(document);
      return {
        tool,
        summary: `Parsed ${report.symbols.length} symbols from ${document.path}.`,
        payload: report.symbols,
      };
    }
    case 'lint_code':
      return {
        tool,
        summary: `Produced ${runLintAdapters(document).length} lint issue(s).`,
        payload: runLintAdapters(document),
      };
    case 'code_metrics':
      return {
        tool,
        summary: `Cyclomatic complexity ${computeMetrics(document, symbols).cyclomaticComplexity}.`,
        payload: computeMetrics(document, symbols),
      };
    case 'search_code':
      return {
        tool,
        summary: 'Executed regex, symbol, and reference searches.',
        payload: {
          regex: regexSearch(document, /unused|todo|scan/i),
          symbols: symbolSearch(symbols, 'er'),
          references: referenceSearch(document, symbols[0]?.name ?? ''),
        },
      };
    case 'format_code':
      return {
        tool,
        summary: 'Generated formatter preview.',
        payload: formatDocument(document),
      };
    case 'organize_imports':
      return {
        tool,
        summary: 'Generated import organizer preview.',
        payload: organizeImports(document),
      };
    case 'detect_dead_code':
      return {
        tool,
        summary: `Flagged ${detectDeadCode(symbols, document).length} dead code candidate(s).`,
        payload: detectDeadCode(symbols, document),
      };
    case 'suggest_refactors': {
      const deadCode = detectDeadCode(symbols, document);
      return {
        tool,
        summary: `Produced ${suggestRefactors(document, symbols, deadCode).length} suggestion(s).`,
        payload: suggestRefactors(document, symbols, deadCode),
      };
    }
    default:
      return {
        tool,
        summary: `Unknown tool "${tool}".`,
        payload: null,
      };
  }
}

export function createMcpManifest() {
  return {
    name: 'mcp-code-tools',
    version: '0.1.0',
    protocol: 'Model Context Protocol',
    tools: toolRegistry,
  };
}
