import type { SearchMatch, SourceDocument, SymbolInfo } from '../types';

export function regexSearch(document: SourceDocument, query: RegExp): SearchMatch[] {
  return document.content
    .split('\n')
    .flatMap((line, index) => {
      const match = line.match(query);
      if (!match || match.index === undefined) {
        return [];
      }
      return [
        {
          line: index + 1,
          column: match.index + 1,
          preview: line.trim(),
          kind: 'regex' as const,
        },
      ];
    });
}

export function symbolSearch(symbols: SymbolInfo[], query: string): SearchMatch[] {
  const lowered = query.toLowerCase();
  return symbols
    .filter((symbol) => symbol.name.toLowerCase().includes(lowered))
    .map((symbol) => ({
      line: symbol.line,
      column: 1,
      preview: `${symbol.kind} ${symbol.name}`,
      kind: 'symbol' as const,
    }));
}

export function referenceSearch(document: SourceDocument, symbolName: string): SearchMatch[] {
  const needle = symbolName.toLowerCase();
  return document.content
    .split('\n')
    .flatMap((line, index) => {
      const column = line.toLowerCase().indexOf(needle);
      if (column === -1) {
        return [];
      }
      return [
        {
          line: index + 1,
          column: column + 1,
          preview: line.trim(),
          kind: 'reference' as const,
        },
      ];
    });
}
