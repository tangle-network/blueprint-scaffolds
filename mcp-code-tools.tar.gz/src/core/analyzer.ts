import { computeMetrics } from './metrics';
import { parseDocument, extractSymbolsFromText } from './parser';
import { runLintAdapters } from './lint';
import { detectDeadCode, formatDocument, organizeImports, suggestRefactors } from './manipulation';
import { regexSearch, referenceSearch, symbolSearch } from './search';
import type { AnalysisReport, SourceDocument } from '../types';

export async function analyzeDocument(document: SourceDocument): Promise<AnalysisReport> {
  await parseDocument(document);
  const symbols = extractSymbolsFromText(document);
  const lintIssues = runLintAdapters(document);
  const metrics = computeMetrics(document, symbols);
  const deadCode = detectDeadCode(symbols, document);
  const suggestions = suggestRefactors(document, symbols, deadCode);

  return {
    document,
    symbols,
    lintIssues,
    metrics,
    deadCode,
    suggestions,
    searches: {
      regex: regexSearch(document, /unused|todo|Analyzer|Reporter/i),
      symbols: symbolSearch(symbols, 'an'),
      references: referenceSearch(document, symbols[0]?.name ?? ''),
    },
    manipulation: {
      formatted: formatDocument(document),
      organizedImports: organizeImports(document),
    },
  };
}
