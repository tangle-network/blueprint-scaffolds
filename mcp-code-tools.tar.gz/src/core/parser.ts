import { Language, Parser } from 'web-tree-sitter';
import type { SourceDocument, SupportedLanguage, SymbolInfo } from '../types';

const languageModules: Record<SupportedLanguage, string> = {
  typescript: 'tree-sitter-typescript',
  python: 'tree-sitter-python',
  go: 'tree-sitter-go',
  rust: 'tree-sitter-rust',
};

let parserInitPromise: Promise<boolean> | null = null;

async function ensureParserReady() {
  if (!parserInitPromise) {
    parserInitPromise = Parser.init()
      .then(() => true)
      .catch(() => false);
  }
  return parserInitPromise;
}

export async function createLanguage(
  language: SupportedLanguage,
): Promise<Language | null> {
  const ready = await ensureParserReady();
  if (!ready) {
    return null;
  }
  try {
    const loaded = await import(/* @vite-ignore */ languageModules[language]);
    const candidate = loaded.default ?? loaded.language ?? loaded.typescript ?? loaded.tsx;
    if (candidate && typeof candidate !== 'string') {
      return candidate as Language;
    }
  } catch {
    return null;
  }
  return null;
}

export async function parseDocument(document: SourceDocument) {
  const ready = await ensureParserReady();
  if (!ready) {
    return null;
  }
  const parser = new Parser();
  const language = await createLanguage(document.language);
  if (language) {
    parser.setLanguage(language);
    try {
      return parser.parse(document.content);
    } catch {
      return null;
    }
  }
  return null;
}

export function extractSymbolsFromText(document: SourceDocument): SymbolInfo[] {
  const lines = document.content.split('\n');
  const symbols: SymbolInfo[] = [];

  lines.forEach((line, index) => {
    const tsMatch = line.match(
      /^\s*export\s+(class|function|interface|const)\s+([A-Za-z0-9_]+)/,
    ) ?? line.match(/^\s*(class|function|interface)\s+([A-Za-z0-9_]+)/);
    const pyMatch =
      line.match(/^\s*class\s+([A-Za-z0-9_]+)/) ??
      line.match(/^\s*def\s+([A-Za-z0-9_]+)/);
    const goMatch =
      line.match(/^\s*type\s+([A-Za-z0-9_]+)\s+struct/) ??
      line.match(/^\s*func\s+([A-Za-z0-9_]+)/);
    const rustMatch =
      line.match(/^\s*pub\s+struct\s+([A-Za-z0-9_]+)/) ??
      line.match(/^\s*pub\s+fn\s+([A-Za-z0-9_]+)/) ??
      line.match(/^\s*fn\s+([A-Za-z0-9_]+)/);

    if (tsMatch) {
      const [, kind, name] = tsMatch;
      symbols.push({
        name,
        kind: kind === 'const' ? 'variable' : (kind as SymbolInfo['kind']),
        line: index + 1,
        signature: line.trim(),
      });
      return;
    }

    if (pyMatch) {
      const [, name] = pyMatch;
      symbols.push({
        name,
        kind: line.includes('class ') ? 'class' : 'function',
        line: index + 1,
        signature: line.trim(),
      });
      return;
    }

    if (goMatch) {
      const [, name] = goMatch;
      symbols.push({
        name,
        kind: line.includes('struct') ? 'struct' : 'function',
        line: index + 1,
        signature: line.trim(),
      });
      return;
    }

    if (rustMatch) {
      const [, name] = rustMatch;
      symbols.push({
        name,
        kind: line.includes('struct') ? 'struct' : 'function',
        line: index + 1,
        signature: line.trim(),
      });
    }
  });

  return symbols;
}
