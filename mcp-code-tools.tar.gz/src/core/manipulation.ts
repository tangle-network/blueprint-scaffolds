import type {
  ManipulationPreview,
  RefactorSuggestion,
  SourceDocument,
  SymbolInfo,
} from '../types';

function sortImports(lines: string[]) {
  const importLines = lines.filter((line) =>
    /^(import |from |use )/.test(line.trim()),
  );
  const otherLines = lines.filter(
    (line) => !/^(import |from |use )/.test(line.trim()),
  );
  return [...importLines.sort((a, b) => a.localeCompare(b)), ...otherLines];
}

export function formatDocument(document: SourceDocument): ManipulationPreview {
  const formatted = document.content
    .split('\n')
    .map((line) => line.replace(/\s+$/g, ''))
    .join('\n')
    .replace(/\n{3,}/g, '\n\n');

  return {
    label: 'Formatter',
    before: document.content,
    after: formatted,
  };
}

export function organizeImports(document: SourceDocument): ManipulationPreview {
  const lines = document.content.split('\n');
  return {
    label: 'Import Organizer',
    before: document.content,
    after: sortImports(lines).join('\n'),
  };
}

export function detectDeadCode(symbols: SymbolInfo[], document: SourceDocument): string[] {
  const content = document.content.toLowerCase();
  return symbols
    .filter((symbol) => {
      const occurrences = content.split(symbol.name.toLowerCase()).length - 1;
      return occurrences <= 1 || symbol.name.toLowerCase().includes('unused');
    })
    .map((symbol) => symbol.name);
}

export function suggestRefactors(
  document: SourceDocument,
  symbols: SymbolInfo[],
  deadCode: string[],
): RefactorSuggestion[] {
  const suggestions: RefactorSuggestion[] = [];
  const lineCount = document.content.split('\n').length;

  if (deadCode.length > 0) {
    suggestions.push({
      id: 'remove-dead-code',
      title: 'Remove dead code candidates',
      rationale: `Detected ${deadCode.length} symbol(s) with no observable references.`,
      action: `Review and remove: ${deadCode.join(', ')}`,
    });
  }

  if (lineCount > 20 && symbols.length <= 3) {
    suggestions.push({
      id: 'split-module',
      title: 'Split oversized module',
      rationale: 'The module mixes setup, traversal, and reporting logic in one file.',
      action: 'Extract scanner, reporter, and configuration helpers into smaller modules.',
    });
  }

  if (document.content.includes('return results') && document.content.includes('push')) {
    suggestions.push({
      id: 'prefer-expression-pipeline',
      title: 'Reduce mutable accumulation',
      rationale: 'The function builds arrays with push-based mutation.',
      action: 'Replace mutable accumulation with filter/map pipelines where practical.',
    });
  }

  return suggestions;
}
