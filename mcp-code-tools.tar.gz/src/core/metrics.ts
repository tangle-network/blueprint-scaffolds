import type { MetricSummary, SourceDocument, SymbolInfo } from '../types';

const branchTokens = ['if', 'for', 'while', 'case', 'catch', '&&', '||', '?'];

export function computeMetrics(
  document: SourceDocument,
  symbols: SymbolInfo[],
): MetricSummary {
  const lines = document.content.split('\n');
  const imports = lines.filter((line) =>
    /^(import |from |use |package |#include )/.test(line.trim()),
  ).length;
  const functions = symbols.filter((symbol) => symbol.kind === 'function').length;
  const classes = symbols.filter((symbol) =>
    ['class', 'interface', 'struct'].includes(symbol.kind),
  ).length;
  const cyclomaticComplexity =
    1 +
    branchTokens.reduce(
      (sum, token) =>
        sum + lines.filter((line) => line.includes(token)).length,
      0,
    );
  const coverageEstimate = Math.max(
    42,
    Math.min(96, 68 + functions * 4 - classes * 2 + imports),
  );
  const maintainabilityIndex = Math.max(
    35,
    Math.min(100, 100 - cyclomaticComplexity - Math.floor(lines.length / 8)),
  );

  return {
    lines: lines.length,
    functions,
    classes,
    imports,
    cyclomaticComplexity,
    coverageEstimate,
    maintainabilityIndex,
  };
}
