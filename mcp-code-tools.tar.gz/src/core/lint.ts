import type { LintIssue, SourceDocument } from '../types';

export function runLintAdapters(document: SourceDocument): LintIssue[] {
  const issues: LintIssue[] = [];
  const lines = document.content.split('\n');

  lines.forEach((line, index) => {
    if (document.language === 'typescript' && line.includes('import z from')) {
      issues.push({
        tool: 'eslint',
        rule: 'no-unused-vars',
        severity: 'warning',
        message: 'Imported binding "z" is never used.',
        line: index + 1,
      });
    }
    if (document.language === 'python' && line.trim() === 'import os') {
      issues.push({
        tool: 'ruff',
        rule: 'F401',
        severity: 'warning',
        message: '"os" imported but unused.',
        line: index + 1,
      });
    }
    if (line.length > 96) {
      issues.push({
        tool: document.language === 'python' ? 'ruff' : 'eslint',
        rule: 'max-len',
        severity: 'info',
        message: 'Line exceeds recommended length.',
        line: index + 1,
      });
    }
  });

  return issues;
}
