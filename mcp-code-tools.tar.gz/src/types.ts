export type SupportedLanguage = 'typescript' | 'python' | 'go' | 'rust';

export interface SourceDocument {
  path: string;
  language: SupportedLanguage;
  content: string;
}

export interface SymbolInfo {
  name: string;
  kind: 'function' | 'class' | 'interface' | 'method' | 'struct' | 'module' | 'variable';
  line: number;
  signature: string;
}

export interface SearchMatch {
  line: number;
  column: number;
  preview: string;
  kind: 'regex' | 'symbol' | 'reference';
}

export interface LintIssue {
  tool: 'eslint' | 'ruff';
  rule: string;
  severity: 'info' | 'warning' | 'error';
  message: string;
  line: number;
}

export interface MetricSummary {
  lines: number;
  functions: number;
  classes: number;
  imports: number;
  cyclomaticComplexity: number;
  coverageEstimate: number;
  maintainabilityIndex: number;
}

export interface RefactorSuggestion {
  id: string;
  title: string;
  rationale: string;
  action: string;
}

export interface ManipulationPreview {
  label: string;
  before: string;
  after: string;
}

export interface AnalysisReport {
  document: SourceDocument;
  symbols: SymbolInfo[];
  lintIssues: LintIssue[];
  metrics: MetricSummary;
  deadCode: string[];
  suggestions: RefactorSuggestion[];
  searches: {
    regex: SearchMatch[];
    symbols: SearchMatch[];
    references: SearchMatch[];
  };
  manipulation: {
    formatted: ManipulationPreview;
    organizedImports: ManipulationPreview;
  };
}

export interface ToolDescriptor {
  name: string;
  category: 'analysis' | 'manipulation';
  description: string;
}

export interface ToolResult {
  tool: string;
  summary: string;
  payload: unknown;
}
