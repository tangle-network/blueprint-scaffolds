import type { SourceDocument } from '../types';

export const sampleDocuments: SourceDocument[] = [
  {
    path: 'src/server/analyzer.ts',
    language: 'typescript',
    content: `import z from 'zod';
import fs from 'node:fs';
import { walk } from './walk';
import { loadConfig } from './config';

export class Analyzer {
  constructor(private readonly root: string) {}

  public analyze(pattern: string) {
    const results: string[] = [];
    if (!pattern) {
      return results;
    }

    walk(this.root, (file) => {
      if (file.includes(pattern)) {
        results.push(file);
      }
    });

    return results;
  }
}

export function unusedHelper(value: string) {
  return value.trim();
}

export const loadAnalyzer = async () => {
  const cfg = loadConfig();
  return new Analyzer(cfg.root);
};`,
  },
  {
    path: 'services/report.py',
    language: 'python',
    content: `import json
import os

class Reporter:
    def __init__(self, root):
        self.root = root

    def emit(self, payload):
        if payload is None:
            return None
        return json.dumps(payload)

def iter_files(root):
    for name in os.listdir(root):
        yield name

def unused_function():
    return "unused"
`,
  },
  {
    path: 'cmd/scan/main.go',
    language: 'go',
    content: `package main

import (
    "fmt"
    "strings"
)

type Scanner struct {}

func (s Scanner) Match(input string) bool {
    if strings.Contains(input, "todo") {
        return true
    }
    return false
}

func main() {
    fmt.Println("scan")
}`,
  },
  {
    path: 'crates/indexer/src/lib.rs',
    language: 'rust',
    content: `use std::collections::HashMap;

pub struct Indexer {
    items: HashMap<String, usize>,
}

impl Indexer {
    pub fn new() -> Self {
        Self { items: HashMap::new() }
    }

    pub fn insert(&mut self, key: String) {
        self.items.insert(key, 1);
    }
}

fn unused_private() -> usize {
    1
}`,
  },
];
