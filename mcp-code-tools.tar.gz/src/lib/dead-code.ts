import type { Language, DeadCodeResult } from "@/lib/types"

export function detectDeadCode(source: string, language: Language): DeadCodeResult {
  const unusedVariables: DeadCodeResult["unusedVariables"] = []
  const unusedImports: DeadCodeResult["unusedImports"] = []
  const unreachableCode: DeadCodeResult["unreachableCode"] = []
  const unusedExports: DeadCodeResult["unusedExports"] = []

  const lines = source.split("\n")

  if (language === "typescript") {
    const declarations = new Map<string, { line: number; type: string }>()
    const usage = new Set<string>()

    for (let i = 0; i < lines.length; i++) {
      const trimmed = lines[i].trim()
      const constMatch = trimmed.match(/^(?:const|let|var)\s+(\w+)/)
      const funcMatch = trimmed.match(/^function\s+(\w+)/)
      const classMatch = trimmed.match(/^class\s+(\w+)/)
      const identifier = constMatch?.[1] || funcMatch?.[1] || classMatch?.[1]
      if (identifier) {
        declarations.set(identifier, {
          line: i + 1,
          type: constMatch ? "variable" : funcMatch ? "function" : "class",
        })
      }
      const identifiers = trimmed.match(/\b[a-zA-Z_]\w*\b/g)
      if (identifiers) {
        for (const id of identifiers) {
          if (!trimmed.match(new RegExp(`^(?:const|let|var|function|class)\\s+${id}`))) {
            usage.add(id)
          }
        }
      }
    }

    for (const [name, info] of declarations) {
      if (!usage.has(name)) {
        unusedVariables.push({ name, line: info.line, type: info.type })
      }
    }

    const importPattern = /import\s+(?:\{([^}]+)\}|(\w+))\s+from/
    for (let i = 0; i < lines.length; i++) {
      const match = lines[i].match(importPattern)
      if (match) {
        const items = match[1]
          ? match[1].split(",").map(s => s.trim())
          : match[2] ? [match[2]] : []
        for (const item of items) {
          if (!usage.has(item)) {
            unusedImports.push({ name: item, line: i + 1, module: lines[i] })
          }
        }
      }
    }

    for (let i = 0; i < lines.length - 1; i++) {
      const trimmed = lines[i].trim()
      if (/^return\b/.test(trimmed) || /^throw\b/.test(trimmed) || /^break\b/.test(trimmed) || /^continue\b/.test(trimmed)) {
        const nextTrimmed = lines[i + 1].trim()
        if (nextTrimmed && nextTrimmed !== "}" && nextTrimmed !== ")" && !nextTrimmed.startsWith("case") && !nextTrimmed.startsWith("default")) {
          let endLine = i + 1
          while (endLine < lines.length && lines[endLine].trim() !== "}" && lines[endLine].trim() !== "case" && lines[endLine].trim() !== "default") {
            endLine++
          }
          unreachableCode.push({
            startLine: i + 2,
            endLine: endLine,
            description: `Unreachable code after ${trimmed.split(" ")[0]} statement`,
          })
        }
      }
    }

    const exports = new Map<string, { line: number; type: string }>()
    for (let i = 0; i < lines.length; i++) {
      const trimmed = lines[i].trim()
      const exportMatch = trimmed.match(/^export\s+(?:function|class|const|let|var|interface|type|enum)\s+(\w+)/)
      if (exportMatch) {
        exports.set(exportMatch[1], { line: i + 1, type: exportMatch[0].split(" ")[1] })
      }
    }

    const importUsages = new Set<string>()
    for (let i = 0; i < lines.length; i++) {
      const match = lines[i].match(/import\s+\{([^}]+)\}/)
      if (match) {
        match[1].split(",").forEach(s => importUsages.add(s.trim()))
      }
    }

    for (const [name, info] of exports) {
      if (!importUsages.has(name) && !usage.has(name + "Ref")) {
        const selfUses = lines.filter(l => l.includes(name)).length
        if (selfUses <= 2) {
          unusedExports.push({ name, line: info.line, type: info.type })
        }
      }
    }
  }

  if (language === "python") {
    for (let i = 0; i < lines.length; i++) {
      const trimmed = lines[i].trim()
      const match = trimmed.match(/^(\w+)\s*=\s*/)
      if (match && !trimmed.startsWith("self.") && !trimmed.startsWith("_")) {
        const name = match[1]
        const pattern = new RegExp(`\\b${name}\\b`, "g")
        const count = source.split("\n").filter(l => pattern.test(l)).length
        if (count <= 1) {
          unusedVariables.push({ name, line: i + 1, type: "variable" })
        }
      }
    }
  }

  const totalDeadCode = unusedVariables.length + unusedImports.length + unreachableCode.length + unusedExports.length

  return { unusedVariables, unusedImports, unreachableCode, unusedExports, totalDeadCode }
}
