import type { Language, ASTNode, ParseResult } from "@/lib/types"

function makeId(): string {
  return Math.random().toString(36).substring(2, 10)
}

function buildASTFromLines(lines: string[], depth: number = 0): ASTNode[] {
  const nodes: ASTNode[] = []
  let i = 0
  while (i < lines.length) {
    const line = lines[i]
    const trimmed = line.trim()

    if (trimmed === "") {
      i++
      continue
    }

    if (trimmed.startsWith("//") || trimmed.startsWith("#") || trimmed.startsWith("/*")) {
      nodes.push({
        id: makeId(),
        type: "comment",
        text: trimmed,
        startRow: i,
        startCol: line.indexOf(trimmed),
        endRow: i,
        endCol: line.length,
        children: [],
      })
      i++
      continue
    }

    const isBlock = trimmed.endsWith("{") || trimmed.endsWith(":") || trimmed.endsWith("=> {")
    const blockKeywords = /^(function|const|let|var|class|interface|type|enum|if|else|for|while|switch|try|catch|fn|pub|impl|mod|use|import|export|def|async)/

    if (isBlock && blockKeywords.test(trimmed)) {
      const childLines: string[] = []
      let braceCount = trimmed.includes("{") ? 1 : 0
      let j = i + 1
      while (j < lines.length) {
        const inner = lines[j]
        const innerTrimmed = inner.trim()
        if (innerTrimmed.includes("{")) braceCount += (innerTrimmed.match(/{/g) || []).length
        if (innerTrimmed.includes("}")) braceCount -= (innerTrimmed.match(/}/g) || []).length
        if (braceCount <= 0 && innerTrimmed === "}") break
        childLines.push(inner)
        j++
      }
      const typeGuess = trimmed.split(/[\s({:]/)[0] || "statement"
      const nodeType = mapKeywordToNodeType(typeGuess)
      const endRow = j < lines.length ? j : i
      nodes.push({
        id: makeId(),
        type: nodeType,
        text: trimmed.replace(/{$/, "").trim(),
        startRow: i,
        startCol: line.indexOf(trimmed),
        endRow,
        endCol: lines[endRow]?.length || line.length,
        children: buildASTFromLines(childLines, depth + 1),
      })
      i = j + 1
    } else {
      let nodeType = "expression_statement"
      if (/^(import|from|use)/.test(trimmed)) nodeType = "import_statement"
      else if (/^(export)/.test(trimmed)) nodeType = "export_statement"
      else if (/^(return)/.test(trimmed)) nodeType = "return_statement"
      else if (/^\w+\s*=\s*/.test(trimmed)) nodeType = "variable_declarator"
      else if (/^\w+\s*\(/.test(trimmed)) nodeType = "call_expression"

      nodes.push({
        id: makeId(),
        type: nodeType,
        text: trimmed,
        startRow: i,
        startCol: line.indexOf(trimmed),
        endRow: i,
        endCol: line.length,
        children: [],
      })
      i++
    }
  }
  return nodes
}

function mapKeywordToNodeType(keyword: string): string {
  const map: Record<string, string> = {
    function: "function_declaration",
    async: "function_declaration",
    const: "variable_declaration",
    let: "variable_declaration",
    var: "variable_declaration",
    class: "class_declaration",
    interface: "interface_declaration",
    type: "type_alias_declaration",
    enum: "enum_declaration",
    if: "if_statement",
    else: "else_clause",
    for: "for_statement",
    while: "while_statement",
    switch: "switch_statement",
    try: "try_statement",
    catch: "catch_clause",
    fn: "function_item",
    pub: "function_item",
    impl: "impl_item",
    mod: "mod_item",
    use: "use_declaration",
    def: "function_definition",
    import: "import_statement",
    export: "export_statement",
  }
  return map[keyword] || "statement"
}

export function parseCode(source: string, language: Language): ParseResult {
  const start = performance.now()
  const lines = source.split("\n")
  const children = buildASTFromLines(lines)
  const root: ASTNode = {
    id: "root",
    type: "program",
    text: `Root (${language})`,
    startRow: 0,
    startCol: 0,
    endRow: lines.length - 1,
    endCol: lines[lines.length - 1]?.length || 0,
    children,
  }
  return {
    language,
    source,
    ast: root,
    parseTime: performance.now() - start,
  }
}

export function countNodes(node: ASTNode): number {
  return 1 + node.children.reduce((sum, c) => sum + countNodes(c), 0)
}

export function flattenNodes(node: ASTNode, depth = 0): { node: ASTNode; depth: number }[] {
  return [{ node, depth }, ...node.children.flatMap(c => flattenNodes(c, depth + 1))]
}
