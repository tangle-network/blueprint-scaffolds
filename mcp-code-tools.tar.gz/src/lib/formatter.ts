import type { Language, FormatResult } from "@/lib/types"

export function formatCode(source: string, language: Language): FormatResult {
  const start = performance.now()
  let formatted = source
  const changes: FormatResult["changes"] = []

  formatted = formatted.replace(/\t/g, "  ")

  const lines = formatted.split("\n")
  const newLines: string[] = []
  for (let i = 0; i < lines.length; i++) {
    const original = lines[i]
    const trimmed = original.trimEnd()
    if (trimmed !== original) {
      changes.push({ line: i + 1, type: "modified" })
    }
    newLines.push(trimmed)
  }
  formatted = newLines.join("\n")

  if (language === "typescript" || language === "rust") {
    const withSemis = formatted.split("\n").map((line, idx) => {
      const trimmed = line.trim()
      if (
        trimmed.length > 0 &&
        !trimmed.endsWith(";") &&
        !trimmed.endsWith("{") &&
        !trimmed.endsWith("}") &&
        !trimmed.endsWith(",") &&
        !trimmed.endsWith("(") &&
        !trimmed.endsWith("\\") &&
        !trimmed.startsWith("//") &&
        !trimmed.startsWith("/*") &&
        !trimmed.startsWith("*") &&
        !trimmed.startsWith("import") &&
        !trimmed.startsWith("export") &&
        !trimmed.endsWith(":")
      ) {
        const isStatement = /^(const|let|var|return|throw|break|continue|yield)/.test(trimmed) ||
          /^\w+\s*=/.test(trimmed) ||
          /^\w+\.\w+/.test(trimmed) ||
          /^(console|process|Math)\./.test(trimmed)
        if (isStatement) {
          changes.push({ line: idx + 1, type: "modified" })
          return line + ";"
        }
      }
      return line
    })
    formatted = withSemis.join("\n")
  }

  formatted = formatted.replace(/\n{3,}/g, "\n\n")

  if (language === "python") {
    formatted = formatted.split("\n").map(line => {
      if (/^def |^class |^if |^for |^while |^try:|^except|^with /.test(line.trim())) {
        const prev = line
        const result = line.replace(/\t/g, "    ")
        if (result !== prev) changes.push({ line: 0, type: "modified" })
        return result
      }
      return line.replace(/\t/g, "    ")
    }).join("\n")
  }

  const changed = formatted !== source
  return {
    original: source,
    formatted,
    changed,
    changes: [...new Map(changes.map(c => [c.line, c])).values()],
    formatTime: performance.now() - start,
  }
}
