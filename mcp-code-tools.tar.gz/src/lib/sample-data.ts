import type { Language, MCPTool } from "@/lib/types"

export const mcpTools: MCPTool[] = [
  {
    name: "parse_ast",
    description: "Parse source code into an AST for TypeScript, Python, Go, or Rust",
    inputSchema: {
      type: "object",
      properties: {
        source: { type: "string", description: "Source code to parse" },
        language: { type: "string", enum: ["typescript", "python", "go", "rust"] },
      },
      required: ["source", "language"],
    },
    handler: "ast-parser.parseCode",
  },
  {
    name: "lint_code",
    description: "Run linter analysis (ESLint for TS, Ruff for Python, golangci-lint for Go, clippy for Rust)",
    inputSchema: {
      type: "object",
      properties: {
        source: { type: "string", description: "Source code to lint" },
        language: { type: "string", enum: ["typescript", "python", "go", "rust"] },
      },
      required: ["source", "language"],
    },
    handler: "linter.lintCode",
  },
  {
    name: "compute_metrics",
    description: "Compute code metrics including complexity, Halstead volume, and maintainability index",
    inputSchema: {
      type: "object",
      properties: {
        source: { type: "string", description: "Source code to analyze" },
        language: { type: "string", enum: ["typescript", "python", "go", "rust"] },
      },
      required: ["source", "language"],
    },
    handler: "metrics.computeMetrics",
  },
  {
    name: "search_code",
    description: "Search code using regex, symbol, or reference search",
    inputSchema: {
      type: "object",
      properties: {
        source: { type: "string" },
        query: { type: "string", description: "Search pattern or symbol name" },
        type: { type: "string", enum: ["regex", "symbol", "reference"] },
      },
      required: ["source", "query", "type"],
    },
    handler: "search.searchCode",
  },
  {
    name: "find_symbols",
    description: "Find all symbol definitions in source code",
    inputSchema: {
      type: "object",
      properties: {
        source: { type: "string" },
        language: { type: "string", enum: ["typescript", "python", "go", "rust"] },
      },
      required: ["source", "language"],
    },
    handler: "search.findSymbols",
  },
  {
    name: "format_code",
    description: "Format source code according to language conventions",
    inputSchema: {
      type: "object",
      properties: {
        source: { type: "string" },
        language: { type: "string", enum: ["typescript", "python", "go", "rust"] },
      },
      required: ["source", "language"],
    },
    handler: "formatter.formatCode",
  },
  {
    name: "organize_imports",
    description: "Analyze and organize imports, detect unused and duplicate imports",
    inputSchema: {
      type: "object",
      properties: {
        source: { type: "string" },
        language: { type: "string", enum: ["typescript", "python", "go", "rust"] },
      },
      required: ["source", "language"],
    },
    handler: "import-organizer.analyzeImports",
  },
  {
    name: "detect_dead_code",
    description: "Detect unused variables, imports, unreachable code, and unused exports",
    inputSchema: {
      type: "object",
      properties: {
        source: { type: "string" },
        language: { type: "string", enum: ["typescript", "python", "go", "rust"] },
      },
      required: ["source", "language"],
    },
    handler: "dead-code.detectDeadCode",
  },
  {
    name: "suggest_refactors",
    description: "Generate refactoring suggestions for code improvement",
    inputSchema: {
      type: "object",
      properties: {
        source: { type: "string" },
        language: { type: "string", enum: ["typescript", "python", "go", "rust"] },
      },
      required: ["source", "language"],
    },
    handler: "refactor.suggestRefactors",
  },
]

export const sampleCode: Record<Language, string> = {
  typescript: `import React, { useState, useEffect } from 'react'
import { Card, CardHeader } from './components/ui/card'
import { unused } from './unused-module'

interface User {
  id: number
  name: string
  email: any
  role: 'admin' | 'user'
}

function processUsers(users: User[]) {
  var result = []
  const cache = new Map()

  for (let i = 0; i < users.length; i++) {
    if (users[i].role == 'admin') {
      console.log('Processing admin:', users[i].name)
      result.push({
        ...users[i],
        processed: true,
        score: 85
      })
    } else {
      if (users[i].name != null) {
        console.log('Processing user:', users[i].name)
        if (cache.has(users[i].id)) {
          result.push(cache.get(users[i].id))
        } else {
          result.push({
            ...users[i],
            processed: false,
            score: 42
          })
        }
      }
    }
  }

  return result
}

class UserService {
  private users: User[] = []

  async fetchUsers() {
    const response = await fetch('/api/users')
    const data = await response.json()
    this.users = data
    return data
  }

  getUserById(id: number) {
    const user = this.users.find(u => u.id === id)
    if (!user) {
      throw new Error('User not found')
      console.log('This is unreachable')
    }
    return user
  }

  processAndFormat() {
    const processed = processUsers(this.users)
    const formatted = processed.map(p => ({
      label: \`\${p.name} (\${p.role})\`,
      value: p.score
    }))
    return formatted
  }
}

export { UserService, processUsers }
export type { User }
`,
  python: `import os
import sys
from typing import List, Dict, Optional
from collections import *
from dataclasses import dataclass

@dataclass
class User:
    id: int
    name: str
    email: str
    role: str

def process_users(users: List[User]) -> List[Dict]:
    result = []
    cache = {}

    for i in range(len(users)):
        user = users[i]
        if user.role == "admin":
            print(f"Processing admin: {user.name}")
            result.append({
                "id": user.id,
                "name": user.name,
                "processed": True,
                "score": 85
            })
        else:
            if user.name is not None:
                print(f"Processing user: {user.name}")
                if user.id in cache:
                    result.append(cache[user.id])
                else:
                    result.append({
                        "id": user.id,
                        "name": user.name,
                        "processed": False,
                        "score": 42
                    })
    return result

class UserService:
    def __init__(self):
        self.users: List[User] = []

    def fetch_users(self):
        import requests
        response = requests.get("/api/users")
        data = response.json()
        self.users = data
        return data

    def get_user_by_id(self, user_id: int) -> Optional[User]:
        for user in self.users:
            if user.id == user_id:
                return user
        raise ValueError("User not found")
        print("This is unreachable")

    def process_and_format(self) -> List[Dict]:
        processed = process_users(self.users)
        formatted = []
        for p in processed:
            formatted.append({
                "label": f"{p['name']} ({p['role']})",
                "value": p.get("score", 0)
            })
        return formatted

def calculate_score(data=[]):
    total = 0
    for item in data:
        total += item.get("score", 0)
    return total / len(data) if data else 0
`,
  go: `package main

import (
\t"fmt"
\t"strings"
\t"net/http"
\t"encoding/json"
)

type User struct {
\tID    int    \`json:"id"\`
\tName  string \`json:"name"\`
\tEmail string \`json:"email"\`
\tRole  string \`json:"role"\`
}

func processUsers(users []User) []map[string]interface{} {
\tresult := make([]map[string]interface{}, 0)

\tfor i := 0; i < len(users); i++ {
\t\tif users[i].Role == "admin" {
\t\t\tfmt.Println("Processing admin:", users[i].Name)
\t\t\tresult = append(result, map[string]interface{}{
\t\t\t\t"id":        users[i].ID,
\t\t\t\t"name":      users[i].Name,
\t\t\t\t"processed": true,
\t\t\t\t"score":     85,
\t\t\t})
\t\t} else {
\t\t\tresult = append(result, map[string]interface{}{
\t\t\t\t"id":        users[i].ID,
\t\t\t\t"name":      users[i].Name,
\t\t\t\t"processed": false,
\t\t\t\t"score":     42,
\t\t\t})
\t\t}
\t}

\treturn result
}

type UserService struct {
\tusers []User
}

func (s *UserService) FetchUsers() ([]User, error) {
\tresp, err := http.Get("/api/users")
\tif err != nil {
\t\treturn nil, err
\t}
\tdefer resp.Body.Close()

\tvar users []User
\tdecoder := json.NewDecoder(resp.Body)
\terr = decoder.Decode(&users)
\ts.users = users
\treturn users, err
}

func (s *UserService) ProcessAndFormat() []map[string]interface{} {
\tprocessed := processUsers(s.users)
\tformatted := make([]map[string]interface{}, 0)
\tfor _, p := range processed {
\t\tname := p["name"].(string)
\t\trole := p["name"].(string)
\t\tformatted = append(formatted, map[string]interface{}{
\t\t\t"label": fmt.Sprintf("%s (%s)", name, role),
\t\t\t"value": p["score"],
\t\t})
\t}
\treturn formatted
}

func main() {
\tservice := &UserService{}
\tusers, err := service.FetchUsers()
\tfmt.Println("Users:", users)
\t_ = strings.ToLower("test")
\t_ = err
}
`,
  rust: `use std::collections::HashMap;
use std::io;
use serde::{Serialize, Deserialize};

#[derive(Debug, Serialize, Deserialize)]
struct User {
    id: u32,
    name: String,
    email: String,
    role: String,
}

fn process_users(users: &[User]) -> Vec<HashMap<&str, serde_json::Value>> {
    let mut result = Vec::new();

    for user in users {
        if user.role == "admin" {
            println!("Processing admin: {}", user.name);
            let mut map = HashMap::new();
            map.insert("id", serde_json::Value::Number(user.id.into()));
            map.insert("name", serde_json::Value::String(user.name.clone()));
            map.insert("processed", serde_json::Value::Bool(true));
            map.insert("score", serde_json::Value::Number(85.into()));
            result.push(map);
        } else {
            let mut map = HashMap::new();
            map.insert("id", serde_json::Value::Number(user.id.into()));
            map.insert("name", serde_json::Value::String(user.name.clone()));
            map.insert("processed", serde_json::Value::Bool(false));
            map.insert("score", serde_json::Value::Number(42.into()));
            result.push(map);
        }
    }

    result
}

struct UserService {
    users: Vec<User>,
}

impl UserService {
    fn new() -> Self {
        UserService { users: Vec::new() }
    }

    fn get_user_by_id(&self, id: u32) -> Option<&User> {
        for user in &self.users {
            if user.id == id {
                return Some(user);
            }
        }
        None
    }

    fn process_and_format(&self) -> Vec<HashMap<String, String>> {
        let processed = process_users(&self.users);
        let mut formatted = Vec::new();
        for p in &processed {
            let name = p.get("name").unwrap().as_str().unwrap();
            let role = p.get("role").unwrap().as_str().unwrap_or("user");
            let mut map = HashMap::new();
            map.insert("label".to_string(), format!("{} ({})", name, role));
            map.insert("value".to_string(), p.get("score").unwrap().to_string());
            formatted.push(map);
        }
        formatted
    }
}

fn main() {
    let service = UserService::new();
    let users = vec![
        User { id: 1, name: "Alice".to_string(), email: "alice@test.com".to_string(), role: "admin".to_string() },
        User { id: 2, name: "Bob".to_string(), email: "bob@test.com".to_string(), role: "user".to_string() },
    ];

    let result = process_users(&users);
    println!("Result: {:?}", result);

    let val = service.get_user_by_id(1);
    match val {
        Some(user) => println!("Found: {:?}", user),
        None => println!("Not found"),
    }

    todo!("Implement rest of main");
}
`,
}
