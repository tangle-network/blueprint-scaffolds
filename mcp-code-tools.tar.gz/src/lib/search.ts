import type { Language, SearchResult, SearchResults } from "@/lib/types"

export function searchCode(
  source: string,
  query: string,
  type: "regex" | "symbol" | "reference",
  filePath: string = "main.ts"
): SearchResults {
  const start = performance.now()
  const results: SearchResult[] = []
  const lines = source.split("\n")

  try {
    let pattern: RegExp
    if (type === "regex") {
      pattern = new RegExp(query, "gi")
    } else if (type === "symbol") {
      pattern = new RegExp(`\\b${escapeRegex(query)}\\b`, "g")
    } else {
      pattern = new RegExp(`\\b${escapeRegex(query)}\\b`, "g")
    }

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i]
      let match: RegExpExecArray | null
      const tempPattern = new RegExp(pattern.source, pattern.flags)
      while ((match = tempPattern.exec(line)) !== null) {
        const contextStart = Math.max(0, i - 2)
        const contextEnd = Math.min(lines.length - 1, i + 2)
        results.push({
          filePath,
          line: i + 1,
          column: match.index + 1,
          text: match[0],
          matchLength: match[0].length,
          context: lines.slice(contextStart, contextEnd + 1).map((l, idx) => {
            const lineNum = contextStart + idx + 1
            const marker = lineNum === i + 1 ? ">" : " "
            return `${marker} ${String(lineNum).padStart(4)} | ${l}`
          }).join("\n"),
        })
      }
    }
  } catch {
    return {
      query,
      type,
      results: [],
      totalMatches: 0,
      searchTime: performance.now() - start,
    }
  }

  return {
    query,
    type,
    results,
    totalMatches: results.length,
    searchTime: performance.now() - start,
  }
}

export function findSymbols(source: string, language: Language): SearchResult[] {
  const symbolPatterns: Record<Language, RegExp> = {
    typescript: /\b(function|class|interface|type|enum|const|let|var)\s+(\w+)/g,
    python: /\b(def|class)\s+(\w+)/g,
    go: /\b(func|type|struct|interface|const|var)\s+(\w+)/g,
    rust: /\b(fn|struct|enum|trait|impl|type|const|static|mod)\s+(\w+)/g,
  }
  const results: SearchResult[] = []
  const lines = source.split("\n")
  const pattern = symbolPatterns[language]

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]
    let match: RegExpExecArray | null
    const tempPattern = new RegExp(pattern.source, pattern.flags)
    while ((match = tempPattern.exec(line)) !== null) {
      results.push({
        filePath: "main",
        line: i + 1,
        column: match.index + 1,
        text: match[2],
        matchLength: match[2].length,
        context: `${String(i + 1).padStart(4)} | ${line}`,
      })
    }
  }
  return results
}

export function findReferences(source: string, symbol: string): SearchResult[] {
  const results: SearchResult[] = []
  const lines = source.split("\n")
  const pattern = new RegExp(`\\b${escapeRegex(symbol)}\\b`, "g")

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]
    let match: RegExpExecArray | null
    const tempPattern = new RegExp(pattern.source, pattern.flags)
    while ((match = tempPattern.exec(line)) !== null) {
      results.push({
        filePath: "main",
        line: i + 1,
        column: match.index + 1,
        text: match[0],
        matchLength: match[0].length,
        context: `${String(i + 1).padStart(4)} | ${line}`,
      })
    }
  }
  return results
}

function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
}
