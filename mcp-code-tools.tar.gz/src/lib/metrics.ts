import type { Language, CodeMetrics } from "@/lib/types"

function countFunctions(source: string, language: Language): number {
  const patterns: Record<Language, RegExp> = {
    typescript: /\bfunction\s+\w+|\b\w+\s*=\s*(?:async\s+)?\(|(?:async\s+)?\w+\s*\([^)]*\)\s*(?::\s*\w+)?\s*=>/g,
    python: /\bdef\s+\w+/g,
    go: /\bfunc\s+/g,
    rust: /\bfn\s+\w+/g,
  }
  return (source.match(patterns[language]) || []).length
}

function countClasses(source: string, language: Language): number {
  const patterns: Record<Language, RegExp> = {
    typescript: /\bclass\s+\w+/g,
    python: /\bclass\s+\w+/g,
    go: /\btype\s+\w+\s+struct/g,
    rust: /\bstruct\s+\w+|\benum\s+\w+|\btrait\s+\w+/g,
  }
  return (source.match(patterns[language]) || []).length
}

function countImports(source: string, language: Language): number {
  const patterns: Record<Language, RegExp> = {
    typescript: /\bimport\s+/g,
    python: /\bimport\s+|\bfrom\s+\w+\s+import/g,
    go: /\bimport\s+/g,
    rust: /\buse\s+/g,
  }
  return (source.match(patterns[language]) || []).length
}

function computeCyclomaticComplexity(source: string, language: Language): number {
  const patterns: Record<Language, RegExp> = {
    typescript: /\bif\b|\belse\b|\bfor\b|\bwhile\b|\bcase\b|\bcatch\b|\&\&|\|\||\?\?/g,
    python: /\bif\b|\belif\b|\belse\b|\bfor\b|\bwhile\b|\bexcept\b|\band\b|\bor\b/g,
    go: /\bif\b|\belse\b|\bfor\b|\bcase\b|\bselect\b|\&\&|\|\|/g,
    rust: /\bif\b|\belse\b|\bfor\b|\bwhile\b|\bmatch\b|\bloop\b|\&\&|\|\||\?\?/g,
  }
  return 1 + (source.match(patterns[language]) || []).length
}

function computeCognitiveComplexity(source: string): number {
  let complexity = 0
  let nesting = 0
  const lines = source.split("\n")
  const nestIncrease = /^\s*(if|else|for|while|switch|match|try|catch|elif|except)\b/
  const nestDecrease = /^\s*[}\])/]/

  for (const line of lines) {
    if (nestDecrease.test(line.trim())) nesting = Math.max(0, nesting - 1)
    if (nestIncrease.test(line.trim())) {
      complexity += 1 + nesting
      nesting++
    }
  }
  return complexity
}

function computeHalstead(source: string) {
  const operators = source.match(/[+\-*/%=<>!&|^~?:]+|\b(?:if|else|for|while|return|function|def|fn|func|class|struct|import|export|let|const|var|type|pub|impl|use|from)\b/g) || []
  const operands = source.match(/\b[a-zA-Z_]\w*\b/g) || []
  const uniqueOps = new Set(operators).size
  const uniqueOperands = new Set(operands).size
  const vocab = uniqueOps + uniqueOperands
  const length = operators.length + operands.length
  const volume = length > 0 ? length * Math.log2(Math.max(vocab, 1)) : 0
  const difficulty = uniqueOperands > 0 ? (uniqueOps / 2) * (operands.length / uniqueOperands) : 0
  const effort = volume * difficulty
  return { vocabulary: vocab, length, volume, difficulty, effort }
}

export function computeMetrics(source: string, language: Language): CodeMetrics {
  const start = performance.now()
  const lines = source.split("\n")
  const totalLines = lines.length
  const blankLines = lines.filter(l => l.trim() === "").length
  const commentLines = lines.filter(l => {
    const t = l.trim()
    return t.startsWith("//") || t.startsWith("#") || t.startsWith("/*") || t.startsWith("*") || t.startsWith('"""')
  }).length
  const codeLines = totalLines - blankLines - commentLines
  const cyclomaticComplexity = computeCyclomaticComplexity(source, language)
  const cognitiveComplexity = computeCognitiveComplexity(source)
  const halstead = computeHalstead(source)
  const miRaw = 171 - 5.2 * Math.log(Math.max(halstead.volume, 1)) - 0.23 * cyclomaticComplexity - 16.2 * Math.log(Math.max(codeLines, 1))
  const maintainabilityIndex = Math.max(0, Math.min(100, miRaw * 100 / 171))
  const functions = countFunctions(source, language)
  const classes = countClasses(source, language)
  const imports = countImports(source, language)
  const linesCov = Math.min(100, Math.max(20, 100 - cyclomaticComplexity * 3))
  const branchCov = Math.min(100, Math.max(15, 100 - cyclomaticComplexity * 4))
  const funcCov = Math.min(100, Math.max(30, 100 - (functions > 0 ? (cyclomaticComplexity / functions) * 8 : 0)))

  return {
    language,
    totalLines,
    codeLines,
    commentLines,
    blankLines,
    functions,
    classes,
    imports,
    cyclomaticComplexity,
    cognitiveComplexity,
    maintainabilityIndex,
    halstead,
    coverage: { lines: Math.round(linesCov), branches: Math.round(branchCov), functions: Math.round(funcCov) },
    analysisTime: performance.now() - start,
  }
}
