import type { Language, LintResult, LintDiagnostic } from "@/lib/types"

function makeId(): string {
  return Math.random().toString(36).substring(2, 10)
}

const tsRules: Array<{ rule: string; pattern: RegExp; message: string; severity: LintDiagnostic["severity"] }> = [
  { rule: "no-console", pattern: /console\.(log|warn|error|info|debug)/, message: "Unexpected console statement", severity: "warning" },
  { rule: "no-any", pattern: /:\s*any\b/, message: "Unexpected 'any'. Specify a different type", severity: "warning" },
  { rule: "no-var", pattern: /\bvar\s+\w+/, message: "Unexpected var, use let or const instead", severity: "warning" },
  { rule: "eqeqeq", pattern: /[^=!]==[^=]/, message: "Expected '===' and instead saw '=='.", severity: "error" },
  { rule: "no-unused-vars", pattern: /(?:const|let)\s+(\w+)\s*=\s*[^;]+;(?:\s*\n)*?(?!\1)/, message: "Variable is declared but never used", severity: "warning" },
  { rule: "prefer-const", pattern: /\blet\s+(\w+)\s*=\s*[^;]+;(?![\s\S]*?\1\s*=)/, message: "Variable is never reassigned. Use 'const' instead", severity: "hint" },
  { rule: "no-debugger", pattern: /\bdebugger\b/, message: "Unexpected 'debugger' statement", severity: "error" },
  { rule: "no-empty", pattern: /\{\s*\}/, message: "Empty block statement", severity: "warning" },
  { rule: "no-trailing-spaces", pattern: / $/m, message: "Trailing spaces not allowed", severity: "info" },
  { rule: "semi", pattern: /^[^{}/]*[^;{}]\s*$/m, message: "Missing semicolon", severity: "warning" },
]

const pythonRules: Array<{ rule: string; pattern: RegExp; message: string; severity: LintDiagnostic["severity"] }> = [
  { rule: "print-found", pattern: /\bprint\s*\(/, message: "Found print statement (use logging instead)", severity: "warning" },
  { rule: "bare-except", pattern: /except\s*:/, message: "Do not use bare 'except'", severity: "error" },
  { rule: "mutable-default", pattern: /def\s+\w+\s*\([^)]*(?:=\s*\[\]|=\s*\{\})/, message: "Do not use mutable default arguments", severity: "error" },
  { rule: "f-string", pattern: /["'].*%[sd].*["']\s*%/, message: "Use f-strings instead of % formatting", severity: "info" },
  { rule: "no-wildcard-import", pattern: /from\s+\w+\s+import\s+\*/, message: "Do not use wildcard imports", severity: "warning" },
  { rule: "line-too-long", pattern: /.{121,}/, message: "Line too long (>120 characters)", severity: "info" },
]

const goRules: Array<{ rule: string; pattern: RegExp; message: string; severity: LintDiagnostic["severity"] }> = [
  { rule: "error-check", pattern: /(?:\w+,\s*)?err\s*:?=\s*[^;]+;(?![\s\S]*?if\s+err)/, message: "Error return value is not checked", severity: "warning" },
  { rule: "exported-comment", pattern: /^func\s+[A-Z]/, message: "Exported function should have a comment", severity: "info" },
  { rule: "unused-import", pattern: /import\s*\([^)]+\)/, message: "Check for unused imports", severity: "warning" },
]

const rustRules: Array<{ rule: string; pattern: RegExp; message: string; severity: LintDiagnostic["severity"] }> = [
  { rule: "unwrap-used", pattern: /\.unwrap\(\)/, message: "Usage of .unwrap() in production code", severity: "warning" },
  { rule: "todo-found", pattern: /todo!\(\)/, message: "Found TODO macro", severity: "warning" },
  { rule: "print-found", pattern: /println!\(/, message: "Use logging instead of println!", severity: "info" },
]

function lintWithRules(source: string, rules: typeof tsRules, linterName: string, language: Language): LintResult {
  const start = performance.now()
  const diagnostics: LintDiagnostic[] = []
  const lines = source.split("\n")

  for (const rule of rules) {
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i]
      if (rule.pattern.test(line)) {
        diagnostics.push({
          id: makeId(),
          severity: rule.severity,
          message: rule.message,
          line: i + 1,
          column: 1,
          endLine: i + 1,
          endColumn: line.length + 1,
          rule: rule.rule,
          source: linterName,
          fixable: rule.severity === "hint" || rule.severity === "info",
        })
      }
    }
  }

  return {
    language,
    linter: linterName,
    diagnostics,
    errorCount: diagnostics.filter(d => d.severity === "error").length,
    warningCount: diagnostics.filter(d => d.severity === "warning").length,
    infoCount: diagnostics.filter(d => d.severity === "info" || d.severity === "hint").length,
    lintTime: performance.now() - start,
  }
}

export function lintCode(source: string, language: Language): LintResult {
  switch (language) {
    case "typescript":
      return lintWithRules(source, tsRules, "ESLint", language)
    case "python":
      return lintWithRules(source, pythonRules, "Ruff", language)
    case "go":
      return lintWithRules(source, goRules, "golangci-lint", language)
    case "rust":
      return lintWithRules(source, rustRules, "clippy", language)
  }
}
