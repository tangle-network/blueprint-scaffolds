import type { Language, RefactorSuggestion } from "@/lib/types"

function makeId(): string {
  return Math.random().toString(36).substring(2, 10)
}

export function suggestRefactors(source: string, language: Language): RefactorSuggestion[] {
  const suggestions: RefactorSuggestion[] = []
  const lines = source.split("\n")

  if (language === "typescript") {
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i]
      const trimmed = line.trim()

      const callbackMatch = trimmed.match(/^const\s+(\w+)\s*=\s*\(.*\)\s*=>\s*\{/)
      if (callbackMatch) {
        let braceCount = 0
        let endLine = i
        let bodyLength = 0
        for (let j = i; j < lines.length; j++) {
          bodyLength++
          if (lines[j].includes("{")) braceCount += (lines[j].match(/{/g) || []).length
          if (lines[j].includes("}")) braceCount -= (lines[j].match(/}/g) || []).length
          if (braceCount === 0 && j > i) { endLine = j; break }
        }
        if (bodyLength > 15) {
          suggestions.push({
            id: makeId(),
            title: "Extract function",
            description: `Function '${callbackMatch[1]}' is ${bodyLength} lines long. Consider extracting parts into smaller functions.`,
            category: "extract",
            severity: "medium",
            startLine: i + 1,
            endLine: endLine + 1,
            originalCode: lines.slice(i, endLine + 1).join("\n"),
            suggestedCode: `// Consider extracting logic from ${callbackMatch[1]} into smaller helper functions`,
            rationale: "Long functions are harder to test and maintain. Breaking them into smaller pieces improves readability.",
          })
        }
      }

      const nestedIf = trimmed.match(/^if\s*\(/)
      if (nestedIf) {
        const nextLine = lines[i + 1]?.trim()
        const nextNextLine = lines[i + 2]?.trim()
        if (nextLine?.match(/^if\s*\(/) && !nextNextLine?.match(/^else/)) {
          suggestions.push({
            id: makeId(),
            title: "Combine nested conditions",
            description: "Nested if statements can be combined with && operator",
            category: "simplify",
            severity: "low",
            startLine: i + 1,
            endLine: i + 3,
            originalCode: lines.slice(i, i + 3).join("\n"),
            suggestedCode: `if (${trimmed.replace(/^if\s*\(\s*/, "").replace(/\s*\)$/, "")} && ${nextLine.replace(/^if\s*\(\s*/, "").replace(/\s*\)$/, "")}) {\n  ${lines[i + 2]?.trim()}\n}`,
            rationale: "Combining conditions reduces nesting and improves readability.",
          })
        }
      }

      if (trimmed.includes("== null") || trimmed.includes("!= null")) {
        suggestions.push({
          id: makeId(),
          title: "Use nullish coalescing",
          description: "Replace null checks with ?? operator",
          category: "modernize",
          severity: "low",
          startLine: i + 1,
          endLine: i + 1,
          originalCode: trimmed,
          suggestedCode: trimmed.replace(/\s*==\s*null\s*\?.*:/g, " ?? "),
          rationale: "The ?? operator is more concise and handles only null/undefined.",
        })
      }

      const forLoopMatch = trimmed.match(/^for\s*\(let\s+(\w+)\s*=\s*0;\s*\w+\s*<\s*(\w+)\.length/)
      if (forLoopMatch) {
        suggestions.push({
          id: makeId(),
          title: "Use for...of or forEach",
          description: "Replace traditional for loop with modern iteration",
          category: "modernize",
          severity: "low",
          startLine: i + 1,
          endLine: i + 1,
          originalCode: trimmed,
          suggestedCode: `for (const ${forLoopMatch[1]} of ${forLoopMatch[2]}) {`,
          rationale: "Modern iteration patterns are more readable and less error-prone.",
        })
      }

      const callbackHell = (trimmed.match(/\.then\(/g) || []).length
      if (callbackHell > 0) {
        suggestions.push({
          id: makeId(),
          title: "Convert to async/await",
          description: "Replace .then() chains with async/await syntax",
          category: "modernize",
          severity: "medium",
          startLine: i + 1,
          endLine: i + 1,
          originalCode: trimmed,
          suggestedCode: "// await the promise instead of using .then()",
          rationale: "async/await is more readable and easier to debug than promise chains.",
        })
      }

      const magicNumber = trimmed.match(/(?<![.\w])(\d{2,})+(?![.\w])/)
      if (magicNumber && !trimmed.includes("const") && !trimmed.includes("0x") && !trimmed.match(/\d+px/)) {
        const num = parseInt(magicNumber[0])
        if (num > 1 && num !== 100 && num !== 1000 && num !== 10) {
          suggestions.push({
            id: makeId(),
            title: "Extract magic number",
            description: `Magic number ${num} should be extracted to a named constant`,
            category: "extract",
            severity: "low",
            startLine: i + 1,
            endLine: i + 1,
            originalCode: trimmed,
            suggestedCode: `const MAGIC_NUMBER = ${num};\n${trimmed.replace(String(num), "MAGIC_NUMBER")}`,
            rationale: "Named constants improve code readability and maintainability.",
          })
        }
      }
    }
  }

  if (language === "python") {
    for (let i = 0; i < lines.length; i++) {
      const trimmed = lines[i].trim()
      if (trimmed.match(/^for\s+\w+\s+in\s+range\(len\(/)) {
        suggestions.push({
          id: makeId(),
          title: "Use enumerate() or direct iteration",
          description: "Replace range(len(...)) with enumerate() or direct iteration",
          category: "simplify",
          severity: "medium",
          startLine: i + 1,
          endLine: i + 1,
          originalCode: trimmed,
          suggestedCode: trimmed.replace(/for\s+(\w+)\s+in\s+range\(len\((\w+)\)\)/, "for i, $1 in enumerate($2)"),
          rationale: "enumerate() is more Pythonic and provides both index and value.",
        })
      }
      if (trimmed.match(/\.append\(/) && trimmed.includes("for")) {
        suggestions.push({
          id: makeId(),
          title: "Use list comprehension",
          description: "Replace for loop with append with a list comprehension",
          category: "simplify",
          severity: "low",
          startLine: i + 1,
          endLine: i + 1,
          originalCode: trimmed,
          suggestedCode: "# Convert to list comprehension",
          rationale: "List comprehensions are more Pythonic and often faster.",
        })
      }
    }
  }

  return suggestions.slice(0, 10)
}
