import type { Language, ImportInfo, ImportAnalysis } from "@/lib/types"

function extractTSImports(source: string): ImportInfo[] {
  const imports: ImportInfo[] = []
  const lines = source.split("\n")
  const importPattern = /^import\s+(?:(?:type\s+)?(?:\{([^}]*)\}|(\w+))\s+from\s+)?['"]([^'"]+)['"]/

  for (let i = 0; i < lines.length; i++) {
    const match = lines[i].match(importPattern)
    if (match) {
      const namedItems = match[1] ? match[1].split(",").map(s => s.trim()).filter(Boolean) : []
      const isDefault = !!match[2]
      const isTypeOnly = lines[i].includes("import type")
      imports.push({
        module: match[3],
        items: isDefault ? [match[2]!] : namedItems,
        isDefault,
        isTypeOnly,
        line: i + 1,
      })
    }
  }
  return imports
}

function extractPythonImports(source: string): ImportInfo[] {
  const imports: ImportInfo[] = []
  const lines = source.split("\n")
  const fromPattern = /^from\s+([\w.]+)\s+import\s+(.+)/
  const importPattern = /^import\s+([\w.]+)/

  for (let i = 0; i < lines.length; i++) {
    const trimmed = lines[i].trim()
    const fromMatch = trimmed.match(fromPattern)
    if (fromMatch) {
      imports.push({
        module: fromMatch[1],
        items: fromMatch[2].split(",").map(s => s.trim()).filter(Boolean),
        isDefault: false,
        isTypeOnly: false,
        line: i + 1,
      })
      continue
    }
    const importMatch = trimmed.match(importPattern)
    if (importMatch) {
      imports.push({
        module: importMatch[1],
        items: [importMatch[1]],
        isDefault: true,
        isTypeOnly: false,
        line: i + 1,
      })
    }
  }
  return imports
}

function extractGoImports(source: string): ImportInfo[] {
  const imports: ImportInfo[] = []
  const lines = source.split("\n")
  const multiImportStart = /^\s*import\s*\(/
  let inBlock = false
  let blockStart = -1

  for (let i = 0; i < lines.length; i++) {
    if (multiImportStart.test(lines[i])) {
      inBlock = true
      blockStart = i
      continue
    }
    if (inBlock && lines[i].trim() === ")") {
      inBlock = false
      continue
    }
    if (inBlock) {
      const mod = lines[i].trim().replace(/"/g, "")
      if (mod) {
        imports.push({ module: mod, items: [], isDefault: false, isTypeOnly: false, line: i + 1 })
      }
      continue
    }
    const singleMatch = lines[i].match(/^\s*import\s+"([^"]+)"/)
    if (singleMatch) {
      imports.push({ module: singleMatch[1], items: [], isDefault: false, isTypeOnly: false, line: i + 1 })
    }
  }
  return imports
}

function extractRustImports(source: string): ImportInfo[] {
  const imports: ImportInfo[] = []
  const lines = source.split("\n")
  const usePattern = /^\s*use\s+([\w:]+)(?:::\{([^}]+)\})?/

  for (let i = 0; i < lines.length; i++) {
    const match = lines[i].match(usePattern)
    if (match) {
      const items = match[2] ? match[2].split(",").map(s => s.trim()).filter(Boolean) : []
      imports.push({
        module: match[1],
        items,
        isDefault: items.length === 0,
        isTypeOnly: false,
        line: i + 1,
      })
    }
  }
  return imports
}

export function analyzeImports(source: string, language: Language): ImportAnalysis {
  let imports: ImportInfo[]

  switch (language) {
    case "typescript":
      imports = extractTSImports(source)
      break
    case "python":
      imports = extractPythonImports(source)
      break
    case "go":
      imports = extractGoImports(source)
      break
    case "rust":
      imports = extractRustImports(source)
      break
  }

  const sourceLines = source.split("\n")
  const unused: ImportInfo[] = []
  for (const imp of imports) {
    const usedItems = imp.items.filter(item => {
      const identifier = item.replace(/\s+as\s+\w+/, "").trim()
      const pattern = new RegExp(`\\b${identifier}\\b`)
      return sourceLines.some((line, idx) => idx + 1 !== imp.line && pattern.test(line))
    })
    if (usedItems.length === 0 && imp.items.length > 0) {
      unused.push(imp)
    }
  }

  const moduleSet = new Set<string>()
  const duplicates: string[] = []
  for (const imp of imports) {
    if (moduleSet.has(imp.module)) {
      duplicates.push(imp.module)
    }
    moduleSet.add(imp.module)
  }

  const suggestedOrder = [...imports].sort((a, b) => {
    const aLocal = a.module.startsWith(".") || a.module.startsWith("/")
    const bLocal = b.module.startsWith(".") || b.module.startsWith("/")
    if (aLocal !== bLocal) return aLocal ? 1 : -1
    if (a.isTypeOnly !== b.isTypeOnly) return a.isTypeOnly ? 1 : -1
    return a.module.localeCompare(b.module)
  })

  return { imports, unused, duplicates, suggestedOrder }
}
