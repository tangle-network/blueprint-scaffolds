export type Language = "typescript" | "python" | "go" | "rust"

export interface ASTNode {
  id: string
  type: string
  text: string
  startRow: number
  startCol: number
  endRow: number
  endCol: number
  children: ASTNode[]
}

export interface ParseResult {
  language: Language
  source: string
  ast: ASTNode
  error?: string
  parseTime: number
}

export interface LintDiagnostic {
  id: string
  severity: "error" | "warning" | "info" | "hint"
  message: string
  line: number
  column: number
  endLine?: number
  endColumn?: number
  rule: string
  source: string
  fixable: boolean
  suggestion?: string
}

export interface LintResult {
  language: Language
  linter: string
  diagnostics: LintDiagnostic[]
  errorCount: number
  warningCount: number
  infoCount: number
  lintTime: number
}

export interface CodeMetrics {
  language: Language
  totalLines: number
  codeLines: number
  commentLines: number
  blankLines: number
  functions: number
  classes: number
  imports: number
  cyclomaticComplexity: number
  cognitiveComplexity: number
  maintainabilityIndex: number
  halstead: {
    vocabulary: number
    length: number
    volume: number
    difficulty: number
    effort: number
  }
  coverage: {
    lines: number
    branches: number
    functions: number
  }
  analysisTime: number
}

export interface SearchResult {
  filePath: string
  line: number
  column: number
  text: string
  matchLength: number
  context: string
}

export interface SearchResults {
  query: string
  type: "regex" | "symbol" | "reference"
  results: SearchResult[]
  totalMatches: number
  searchTime: number
}

export interface ImportInfo {
  module: string
  items: string[]
  isDefault: boolean
  isTypeOnly: boolean
  line: number
}

export interface ImportAnalysis {
  imports: ImportInfo[]
  unused: ImportInfo[]
  duplicates: string[]
  suggestedOrder: ImportInfo[]
}

export interface DeadCodeResult {
  unusedVariables: { name: string; line: number; type: string }[]
  unusedImports: { name: string; line: number; module: string }[]
  unreachableCode: { startLine: number; endLine: number; description: string }[]
  unusedExports: { name: string; line: number; type: string }[]
  totalDeadCode: number
}

export interface RefactorSuggestion {
  id: string
  title: string
  description: string
  category: "extract" | "rename" | "simplify" | "modernize" | "optimize" | "restructure"
  severity: "high" | "medium" | "low"
  startLine: number
  endLine: number
  originalCode: string
  suggestedCode: string
  rationale: string
}

export interface FormatResult {
  original: string
  formatted: string
  changed: boolean
  changes: { line: number; type: "added" | "removed" | "modified" }[]
  formatTime: number
}

export interface MCPTool {
  name: string
  description: string
  inputSchema: Record<string, unknown>
  handler: string
}

export type ViewMode = "dashboard" | "ast" | "linter" | "metrics" | "search" | "refactor"
