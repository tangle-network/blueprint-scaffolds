export const registerTools = {} as any

export const handleToolCall = {} as any
