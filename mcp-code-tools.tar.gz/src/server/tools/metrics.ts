import type { CodeMetrics } from "../../shared/types.js";
import { countLines, cyclomaticComplexity, maintainabilityIndex } from "../../shared/utils.js";

export function computeMetrics(content: string, language: string): CodeMetrics {
  const lineInfo = countLines(content);
  const complexity = cyclomaticComplexity(content, language);
  const commentRatio = lineInfo.total > 0 ? lineInfo.comment / lineInfo.total : 0;
  const mi = maintainabilityIndex(lineInfo.code, complexity, commentRatio);

  const functionCount = countFunctions(content, language);
  const classCount = countClasses(content, language);
  const importCount = countImports(content, language);

  return {
    cyclomaticComplexity: complexity,
    linesOfCode: lineInfo.code,
    commentLines: lineInfo.comment,
    blankLines: lineInfo.blank,
    functions: functionCount,
    classes: classCount,
    imports: importCount,
    maintainabilityIndex: Math.round(mi * 10) / 10,
  };
}

function countFunctions(content: string, language: string): number {
  const patterns: Record<string, RegExp> = {
    typescript: /(?:export\s+)?(?:async\s+)?function\s+\w+/g,
    javascript: /(?:export\s+)?(?:async\s+)?function\s+\w+/g,
    python: /(?:async\s+)?def\s+\w+/g,
    go: /func\s+(?:\(.*?\)\s*)?\w+/g,
    rust: /(?:pub\s+)?(?:async\s+)?fn\s+\w+/g,
  };
  const pattern = patterns[language];
  if (!pattern) return 0;
  const matches = content.match(pattern);
  return matches ? matches.length : 0;
}

function countClasses(content: string, language: string): number {
  const patterns: Record<string, RegExp> = {
    typescript: /(?:export\s+)?class\s+\w+/g,
    javascript: /(?:export\s+)?class\s+\w+/g,
    python: /class\s+\w+/g,
    go: /type\s+\w+\s+struct/g,
    rust: /(?:pub\s+)?struct\s+\w+/g,
  };
  const pattern = patterns[language];
  if (!pattern) return 0;
  const matches = content.match(pattern);
  return matches ? matches.length : 0;
}

function countImports(content: string, language: string): number {
  const patterns: Record<string, RegExp> = {
    typescript: /import\s+.*?from\s+['"]/g,
    javascript: /import\s+.*?from\s+['"]/g,
    python: /(?:import\s+\w+|from\s+\w+\s+import)/g,
    go: /import\s+/g,
    rust: /use\s+/g,
  };
  const pattern = patterns[language];
  if (!pattern) return 0;
  const matches = content.match(pattern);
  return matches ? matches.length : 0;
}
