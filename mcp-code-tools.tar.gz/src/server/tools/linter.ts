import type { Diagnostic } from "../../shared/types.js";

interface LintResult {
  diagnostics: Diagnostic[];
  summary: { errors: number; warnings: number; info: number };
}

const TS_RULES: Array<{
  id: string;
  pattern: RegExp;
  message: string;
  severity: Diagnostic["severity"];
}> = [
  { id: "no-eval", pattern: /\beval\s*\(/, message: "Unexpected use of eval()", severity: "error" },
  { id: "no-console", pattern: /\bconsole\.(log|warn|error|debug|info)\s*\(/, message: "Unexpected console statement", severity: "warning" },
  { id: "no-debugger", pattern: /\bdebugger\b/, message: "Unexpected debugger statement", severity: "warning" },
  { id: "no-any", pattern: /:\s*any\b/, message: "Unexpected 'any' type annotation", severity: "warning" },
  { id: "no-var", pattern: /\bvar\s+\w+/, message: "Use 'let' or 'const' instead of 'var'", severity: "warning" },
  { id: "eq-eq-eq", pattern: /[^=!]==[^=]/, message: "Expected '===' instead of '=='", severity: "warning" },
  { id: "no-unused-var", pattern: /(?:const|let|var)\s+(\w+)\s*=[^;]*;(?!.*\b\1\b)/, message: "Variable may be unused", severity: "info" },
  { id: "no-empty-block", pattern: /\{\s*\}/, message: "Empty block statement", severity: "info" },
  { id: "prefer-const", pattern: /\blet\s+(\w+)\s*=\s*[^;]+;(?!.*\b\1\s*=)/, message: "Variable is never reassigned, use 'const' instead", severity: "info" },
  { id: "no-trailing-spaces", pattern: /\s+$/, message: "Trailing whitespace", severity: "info" },
  { id: "max-line-length", pattern: /.{121,}/, message: "Line exceeds 120 characters", severity: "info" },
  { id: "no-ts-ignore", pattern: /\/\/\s*@ts-ignore/, message: "Unexpected @ts-ignore", severity: "warning" },
  { id: "no-eslint-disable", pattern: /\/\/\s*eslint-disable/, message: "Unexpected eslint-disable", severity: "info" },
];

const PY_RULES: Array<{
  id: string;
  pattern: RegExp;
  message: string;
  severity: Diagnostic["severity"];
}> = [
  { id: "no-eval", pattern: /\beval\s*\(/, message: "Unexpected use of eval()", severity: "error" },
  { id: "no-exec", pattern: /\bexec\s*\(/, message: "Unexpected use of exec()", severity: "error" },
  { id: "bare-except", pattern: /\bexcept\s*:/, message: "Bare except clause, specify exception type", severity: "warning" },
  { id: "mutable-default", pattern: /def\s+\w+\([^)]*(?:=\s*\[|=\s*\{)/, message: "Mutable default argument", severity: "error" },
  { id: "no-print", pattern: /\bprint\s*\(/, message: "Unexpected print statement", severity: "warning" },
  { id: "f-string-no-placeholder", pattern: /f"[^"]*"/, message: "f-string without placeholders", severity: "info" },
  { id: "star-import", pattern: /from\s+\w+\s+import\s+\*/, message: "Wildcard import not allowed", severity: "warning" },
];

export function lintCode(content: string, language: string): LintResult {
  const diagnostics: Diagnostic[] = [];
  const lines = content.split("\n");

  const rules = language === "python" ? PY_RULES : TS_RULES;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    for (const rule of rules) {
      if (rule.pattern.test(line)) {
        diagnostics.push({
          severity: rule.severity,
          message: rule.message,
          line: i + 1,
          column: 0,
          ruleId: rule.id,
          source: language === "python" ? "ruff" : "eslint",
        });
      }
    }
  }

  const summary = {
    errors: diagnostics.filter((d) => d.severity === "error").length,
    warnings: diagnostics.filter((d) => d.severity === "warning").length,
    info: diagnostics.filter((d) => d.severity === "info").length,
  };

  return { diagnostics, summary };
}
