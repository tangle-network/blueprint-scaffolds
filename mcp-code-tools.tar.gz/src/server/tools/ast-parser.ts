import type { ASTNode } from "../../shared/types.js";

interface ParseResult {
  language: string;
  root: ASTNode;
  symbolTable: Array<{ name: string; kind: string; line: number; column: number }>;
}

export function parseAST(content: string, language: string): ParseResult {
  const root = buildSimpleAST(content, language);
  const symbolTable = extractSymbols(content, language);
  return { language, root, symbolTable };
}

function buildSimpleAST(content: string, language: string): ASTNode {
  const root: ASTNode = {
    type: "program",
    start: { row: 0, column: 0 },
    end: { row: content.split("\n").length - 1, column: 0 },
    children: [],
  };

  const lines = content.split("\n");

  if (language === "typescript" || language === "javascript") {
    parseTSLike(lines, root);
  } else if (language === "python") {
    parsePython(lines, root);
  } else if (language === "go") {
    parseGo(lines, root);
  } else if (language === "rust") {
    parseRust(lines, root);
  }

  return root;
}

function parseTSLike(lines: string[], root: ASTNode): void {
  let inBlock = false;
  let braceDepth = 0;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    const row = i;

    if (line.startsWith("import ") || line.startsWith("import{")) {
      root.children.push(makeNode("import_statement", row, line));
    } else if (/^(export\s+)?(async\s+)?function\s+\w+/.test(line)) {
      const match = line.match(/function\s+(\w+)/);
      root.children.push(makeNode("function_declaration", row, line, match?.[1]));
      if (line.includes("{")) braceDepth++;
    } else if (/^(export\s+)?(const|let|var)\s+\w+\s*[:=]/.test(line)) {
      const match = line.match(/(const|let|var)\s+(\w+)/);
      root.children.push(makeNode("variable_declaration", row, line, match?.[2]));
    } else if (/^(export\s+)?(interface|type)\s+\w+/.test(line)) {
      const match = line.match(/(interface|type)\s+(\w+)/);
      root.children.push(makeNode("type_declaration", row, line, match?.[2]));
    } else if (/^(export\s+)?class\s+\w+/.test(line)) {
      const match = line.match(/class\s+(\w+)/);
      root.children.push(makeNode("class_declaration", row, line, match?.[1]));
    } else if (/^(export\s+)?enum\s+\w+/.test(line)) {
      const match = line.match(/enum\s+(\w+)/);
      root.children.push(makeNode("enum_declaration", row, line, match?.[1]));
    }

    if (!inBlock && line.includes("{")) {
      braceDepth++;
      inBlock = true;
    }
    if (line.includes("}")) {
      braceDepth--;
      if (braceDepth <= 0) {
        inBlock = false;
        braceDepth = 0;
      }
    }
  }
}

function parsePython(lines: string[], root: ASTNode): void {
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();
    const row = i;

    if (trimmed.startsWith("import ") || trimmed.startsWith("from ")) {
      root.children.push(makeNode("import_statement", row, trimmed));
    } else if (/^(async\s+)?def\s+\w+/.test(trimmed)) {
      const match = trimmed.match(/def\s+(\w+)/);
      root.children.push(makeNode("function_definition", row, trimmed, match?.[1]));
    } else if (/^class\s+\w+/.test(trimmed)) {
      const match = trimmed.match(/class\s+(\w+)/);
      root.children.push(makeNode("class_definition", row, trimmed, match?.[1]));
    } else if (/^\w+\s*=\s*/.test(trimmed) && !trimmed.startsWith("self.")) {
      const match = trimmed.match(/^(\w+)\s*=/);
      if (match && !["if", "for", "while", "with", "try", "else", "elif"].includes(match[1])) {
        root.children.push(makeNode("assignment", row, trimmed, match[1]));
      }
    }
  }
}

function parseGo(lines: string[], root: ASTNode): void {
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    const row = i;

    if (line.startsWith("import ")) {
      root.children.push(makeNode("import_declaration", row, line));
    } else if (/^func\s+(\w+|\(.*?\)\s*\w+)\(/.test(line)) {
      const match = line.match(/func\s+(?:\(.*?\)\s*)?(\w+)/);
      root.children.push(makeNode("function_declaration", row, line, match?.[1]));
    } else if (/^type\s+\w+\s+struct/.test(line)) {
      const match = line.match(/type\s+(\w+)/);
      root.children.push(makeNode("struct_declaration", row, line, match?.[1]));
    } else if (/^type\s+\w+\s+interface/.test(line)) {
      const match = line.match(/type\s+(\w+)/);
      root.children.push(makeNode("interface_declaration", row, line, match?.[1]));
    } else if (/^type\s+\w+/.test(line)) {
      const match = line.match(/type\s+(\w+)/);
      root.children.push(makeNode("type_declaration", row, line, match?.[1]));
    } else if (/^var\s+\w+/.test(line)) {
      const match = line.match(/var\s+(\w+)/);
      root.children.push(makeNode("var_declaration", row, line, match?.[1]));
    } else if (/^const\s+\w+/.test(line)) {
      const match = line.match(/const\s+(\w+)/);
      root.children.push(makeNode("const_declaration", row, line, match?.[1]));
    }
  }
}

function parseRust(lines: string[], root: ASTNode): void {
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    const row = i;

    if (line.startsWith("use ")) {
      root.children.push(makeNode("use_declaration", row, line));
    } else if (/^(pub\s+)?(async\s+)?fn\s+\w+/.test(line)) {
      const match = line.match(/fn\s+(\w+)/);
      root.children.push(makeNode("function_definition", row, line, match?.[1]));
    } else if (/^(pub\s+)?struct\s+\w+/.test(line)) {
      const match = line.match(/struct\s+(\w+)/);
      root.children.push(makeNode("struct_definition", row, line, match?.[1]));
    } else if (/^(pub\s+)?enum\s+\w+/.test(line)) {
      const match = line.match(/enum\s+(\w+)/);
      root.children.push(makeNode("enum_definition", row, line, match?.[1]));
    } else if (/^(pub\s+)?trait\s+\w+/.test(line)) {
      const match = line.match(/trait\s+(\w+)/);
      root.children.push(makeNode("trait_definition", row, line, match?.[1]));
    } else if (/^(pub\s+)?impl\s+/.test(line)) {
      root.children.push(makeNode("impl_block", row, line));
    } else if (/^(pub\s+)?mod\s+\w+/.test(line)) {
      const match = line.match(/mod\s+(\w+)/);
      root.children.push(makeNode("module_declaration", row, line, match?.[1]));
    } else if (/^let\s+mut\s+\w+/.test(line)) {
      const match = line.match(/let\s+mut\s+(\w+)/);
      root.children.push(makeNode("mutable_binding", row, line, match?.[1]));
    } else if (/^let\s+\w+/.test(line)) {
      const match = line.match(/let\s+(\w+)/);
      root.children.push(makeNode("immutable_binding", row, line, match?.[1]));
    }
  }
}

function makeNode(type: string, row: number, text: string, name?: string): ASTNode {
  return {
    type,
    start: { row, column: 0 },
    end: { row, column: text.length },
    children: [],
    text: name ?? text.substring(0, 80),
  };
}

function extractSymbols(
  content: string,
  language: string
): Array<{ name: string; kind: string; line: number; column: number }> {
  const symbols: Array<{ name: string; kind: string; line: number; column: number }> = [];
  const lines = content.split("\n");

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const col = line.search(/\S/);

    if (language === "typescript" || language === "javascript") {
      const funcMatch = line.match(/(?:export\s+)?(?:async\s+)?function\s+(\w+)/);
      if (funcMatch) {
        symbols.push({ name: funcMatch[1], kind: "function", line: i + 1, column: line.indexOf(funcMatch[1]) });
      }
      const classMatch = line.match(/(?:export\s+)?class\s+(\w+)/);
      if (classMatch) {
        symbols.push({ name: classMatch[1], kind: "class", line: i + 1, column: line.indexOf(classMatch[1]) });
      }
      const ifaceMatch = line.match(/(?:export\s+)?interface\s+(\w+)/);
      if (ifaceMatch) {
        symbols.push({ name: ifaceMatch[1], kind: "interface", line: i + 1, column: line.indexOf(ifaceMatch[1]) });
      }
      const typeMatch = line.match(/(?:export\s+)?type\s+(\w+)/);
      if (typeMatch) {
        symbols.push({ name: typeMatch[1], kind: "type", line: i + 1, column: line.indexOf(typeMatch[1]) });
      }
      const enumMatch = line.match(/(?:export\s+)?enum\s+(\w+)/);
      if (enumMatch) {
        symbols.push({ name: enumMatch[1], kind: "enum", line: i + 1, column: line.indexOf(enumMatch[1]) });
      }
      const constMatch = line.match(/(?:export\s+)?(?:const|let|var)\s+(\w+)/);
      if (constMatch) {
        symbols.push({ name: constMatch[1], kind: "variable", line: i + 1, column: line.indexOf(constMatch[1]) });
      }
    } else if (language === "python") {
      const funcMatch = line.match(/(?:async\s+)?def\s+(\w+)/);
      if (funcMatch) {
        symbols.push({ name: funcMatch[1], kind: "function", line: i + 1, column: line.indexOf(funcMatch[1]) });
      }
      const classMatch = line.match(/class\s+(\w+)/);
      if (classMatch) {
        symbols.push({ name: classMatch[1], kind: "class", line: i + 1, column: line.indexOf(classMatch[1]) });
      }
    } else if (language === "go") {
      const funcMatch = line.match(/func\s+(?:\(.*?\)\s*)?(\w+)/);
      if (funcMatch) {
        symbols.push({ name: funcMatch[1], kind: "function", line: i + 1, column: line.indexOf(funcMatch[1]) });
      }
      const typeMatch = line.match(/type\s+(\w+)/);
      if (typeMatch) {
        symbols.push({ name: typeMatch[1], kind: "class", line: i + 1, column: line.indexOf(typeMatch[1]) });
      }
    } else if (language === "rust") {
      const funcMatch = line.match(/(?:pub\s+)?(?:async\s+)?fn\s+(\w+)/);
      if (funcMatch) {
        symbols.push({ name: funcMatch[1], kind: "function", line: i + 1, column: line.indexOf(funcMatch[1]) });
      }
      const structMatch = line.match(/(?:pub\s+)?struct\s+(\w+)/);
      if (structMatch) {
        symbols.push({ name: structMatch[1], kind: "class", line: i + 1, column: line.indexOf(structMatch[1]) });
      }
      const enumMatch = line.match(/(?:pub\s+)?enum\s+(\w+)/);
      if (enumMatch) {
        symbols.push({ name: enumMatch[1], kind: "enum", line: i + 1, column: line.indexOf(enumMatch[1]) });
      }
    }

    void col;
  }

  return symbols;
}
