from pydantic import BaseModel
from typing import Optional


class QueryRequest(BaseModel):
    query: str
    top_k: Optional[int] = 5
    use_reranking: Optional[bool] = True
    use_query_expansion: Optional[bool] = True


class CitationResponse(BaseModel):
    source_id: str
    source_title: str
    source_type: str
    chunk_text: str
    relevance_score: float
    page_number: Optional[int] = None
    chunk_index: int


class QueryResponse(BaseModel):
    answer: str
    citations: list[CitationResponse]
    expanded_query: Optional[str] = None
    reasoning: Optional[str] = None
    retrieval_method: str
    confidence_score: float


class DocumentUploadResponse(BaseModel):
    document_id: str
    filename: str
    chunks_count: int
    status: str


class SystemStatus(BaseModel):
    total_documents: int
    total_chunks: int
    vector_store_size: int
    optimization_status: str
    model_name: str
