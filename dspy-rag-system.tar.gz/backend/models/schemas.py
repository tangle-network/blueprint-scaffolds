from pydantic import BaseModel
from typing import Optional


class QueryRequest(BaseModel):
    query: str
    top_k: int = 5
    use_reranking: bool = True
    use_query_expansion: bool = True
    conversation_history: Optional[list[dict[str, str]]] = None


class CitationResponse(BaseModel):
    chunk_id: str
    document_id: str
    document_title: str
    page_number: Optional[int] = None
    text: str
    score: float
    source_type: str


class QueryResponse(BaseModel):
    answer: str
    citations: list[CitationResponse]
    confidence: float
    reasoning: str
    expanded_queries: Optional[list[str]] = None
    retrieval_scores: Optional[list[float]] = None


class DocumentInfo(BaseModel):
    id: str
    title: str
    source_type: str
    chunk_count: int
    created_at: str
    file_size: Optional[int] = None


class UrlIngestRequest(BaseModel):
    url: str
    title: Optional[str] = None


class SystemStatus(BaseModel):
    status: str
    documents_count: int
    chunks_count: int
    index_size: int
    optimizer_status: str
    last_optimized: Optional[str] = None


class OptimizationResult(BaseModel):
    score_before: float
    score_after: float
    examples_used: int
    duration_seconds: float


class ChunkData(BaseModel):
    id: str
    document_id: str
    text: str
    metadata: dict
    embedding: Optional[list[float]] = None
