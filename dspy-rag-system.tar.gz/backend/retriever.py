import os
import json
import numpy as np
from typing import Optional
from rank_bm25 import BM25Okapi

from backend.store import get_all_chunks, CHUNKS_DIR, CHROMA_DIR, _ensure_dirs


_tokenizer = None
_bm25_index: Optional[BM25Okapi] = None
_bm25_corpus: list[str] = []
_bm25_ids: list[str] = []
_dense_ready = False


def _get_tokenizer():
    global _tokenizer
    if _tokenizer is None:
        try:
            from sentence_transformers import SentenceTransformer
            _tokenizer = SentenceTransformer("all-MiniLM-L6-v2")
        except Exception:
            _tokenizer = None
    return _tokenizer


def _get_chroma_client():
    try:
        import chromadb
        _ensure_dirs()
        client = chromadb.PersistentClient(path=CHROMA_DIR)
        return client
    except Exception:
        return None


def build_indexes():
    global _bm25_index, _bm25_corpus, _bm25_ids, _dense_ready
    chunks = get_all_chunks()
    if not chunks:
        return

    texts = [c["text"] for c in chunks]
    ids = [c["id"] for c in chunks]
    _bm25_corpus = texts
    _bm25_ids = ids

    tokenized = [t.lower().split() for t in texts]
    _bm25_index = BM25Okapi(tokenized)

    chroma_client = _get_chroma_client()
    if chroma_client:
        try:
            collection = chroma_client.get_or_create_collection("rag_documents")
            existing = set(collection.get()["ids"]) if collection.count() > 0 else set()
            new_chunks = [(cid, txt, json.dumps(chunks[i].get("metadata", {}))) for i, (cid, txt) in enumerate(zip(ids, texts)) if cid not in existing]
            if new_chunks:
                batch_ids, batch_texts, batch_metas = zip(*new_chunks)
                collection.add(ids=list(batch_ids), documents=list(batch_texts), metadatas=list(batch_metas))
            _dense_ready = True
        except Exception:
            _dense_ready = False


def sparse_search(query: str, top_k: int = 10) -> list[dict]:
    if _bm25_index is None:
        return []
    tokenized_query = query.lower().split()
    scores = _bm25_index.get_scores(tokenized_query)
    top_indices = np.argsort(scores)[::-1][:top_k]
    results = []
    for idx in top_indices:
        if scores[idx] > 0:
            results.append({
                "id": _bm25_ids[idx],
                "text": _bm25_corpus[idx],
                "score": float(scores[idx]),
            })
    return results


def dense_search(query: str, top_k: int = 10) -> list[dict]:
    if not _dense_ready:
        return []
    chroma_client = _get_chroma_client()
    if not chroma_client:
        return []
    try:
        collection = chroma_client.get_collection("rag_documents")
        results = collection.query(query_texts=[query], n_results=min(top_k, collection.count()) if collection.count() > 0 else top_k)
        output = []
        if results and results["ids"] and results["ids"][0]:
            for i, doc_id in enumerate(results["ids"][0]):
                output.append({
                    "id": doc_id,
                    "text": results["documents"][0][i] if results["documents"] else "",
                    "score": 1.0 - results["distances"][0][i] if results["distances"] else 0.0,
                    "metadata": json.loads(results["metadatas"][0][i]) if results["metadatas"] and results["metadatas"][0] else {},
                })
        return output
    except Exception:
        return []


def hybrid_search(query: str, top_k: int = 10) -> list[dict]:
    sparse_results = sparse_search(query, top_k=top_k * 2)
    dense_results = dense_search(query, top_k=top_k * 2)

    combined: dict[str, dict] = {}
    max_sparse = max((r["score"] for r in sparse_results), default=1.0) or 1.0
    max_dense = max((r["score"] for r in dense_results), default=1.0) or 1.0

    for r in sparse_results:
        rid = r["id"]
        combined[rid] = {"id": rid, "text": r["text"], "sparse_score": r["score"] / max_sparse, "dense_score": 0.0, "metadata": r.get("metadata", {})}
    for r in dense_results:
        rid = r["id"]
        if rid in combined:
            combined[rid]["dense_score"] = r["score"] / max_dense
        else:
            combined[rid] = {"id": rid, "text": r["text"], "sparse_score": 0.0, "dense_score": r["score"] / max_dense, "metadata": r.get("metadata", {})}

    for entry in combined.values():
        entry["score"] = 0.5 * entry["sparse_score"] + 0.5 * entry["dense_score"]

    sorted_results = sorted(combined.values(), key=lambda x: x["score"], reverse=True)
    return sorted_results[:top_k]


def rerank(query: str, results: list[dict], top_k: int = 5) -> list[dict]:
    model = _get_tokenizer()
    if model is None or not results:
        return results[:top_k]
    try:
        from sentence_transformers import CrossEncoder
        try:
            cross_encoder = CrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2")
        except Exception:
            return results[:top_k]
        pairs = [(query, r["text"]) for r in results]
        scores = cross_encoder.predict(pairs)
        for i, score in enumerate(scores):
            results[i]["rerank_score"] = float(score)
        results.sort(key=lambda x: x.get("rerank_score", 0), reverse=True)
        return results[:top_k]
    except Exception:
        return results[:top_k]


def expand_query(query: str) -> str:
    return query


def get_retriever_status() -> dict:
    return {
        "sparse_ready": _bm25_index is not None,
        "dense_ready": _dense_ready,
        "total_chunks": len(_bm25_corpus),
    }
