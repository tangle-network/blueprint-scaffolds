import json
import os
from typing import Optional

from backend.retriever import hybrid_search, rerank, expand_query, get_retriever_status
from backend.store import get_all_chunks, get_metadata


class RAGPipeline:
    def __init__(self):
        self._dspy_configured = False
        self._lm = None

    def _setup_dspy(self):
        if self._dspy_configured:
            return True
        try:
            import dspy
            lm = dspy.LM("openai/gpt-4o-mini", api_key=os.environ.get("OPENAI_API_KEY", "dummy"))
            dspy.configure(lm=lm)
            self._lm = lm
            self._dspy_configured = True
            return True
        except Exception:
            self._dspy_configured = False
            return False

    def query(self, query_text: str, top_k: int = 5, use_reranking: bool = True, use_query_expansion: bool = True) -> dict:
        expanded = query_text
        if use_query_expansion:
            expanded = self._expand_query_impl(query_text)

        results = hybrid_search(expanded, top_k=top_k * 3)

        if use_reranking and results:
            results = rerank(expanded, results, top_k=top_k)

        results = results[:top_k]

        if not results:
            return {
                "answer": "No relevant documents found. Please upload some documents first.",
                "citations": [],
                "expanded_query": expanded if expanded != query_text else None,
                "reasoning": None,
                "retrieval_method": "hybrid",
                "confidence_score": 0.0,
            }

        context_texts = [r["text"] for r in results]
        context = "\n\n---\n\n".join(context_texts)

        answer = self._generate_answer(query_text, context, results)

        citations = []
        metadata = get_metadata()
        for r in results:
            r_meta = r.get("metadata", {})
            source = r_meta.get("source", "Unknown")
            doc_type = r_meta.get("type", "unknown")
            page_number = r_meta.get("page_number")
            score = r.get("rerank_score", r.get("score", 0.0))
            citations.append({
                "source_id": r["id"],
                "source_title": source,
                "source_type": doc_type,
                "chunk_text": r["text"][:500],
                "relevance_score": min(1.0, max(0.0, score)),
                "page_number": page_number,
                "chunk_index": r.get("metadata", {}).get("section_index", r.get("metadata", {}).get("chunk_start", 0)),
            })

        avg_score = sum(c["relevance_score"] for c in citations) / len(citations) if citations else 0.0

        return {
            "answer": answer,
            "citations": citations,
            "expanded_query": expanded if expanded != query_text else None,
            "reasoning": f"Retrieved {len(results)} chunks via hybrid search (dense + sparse). Context assembled from top results.{' Re-ranked using cross-encoder.' if use_reranking else ''}",
            "retrieval_method": "hybrid" + ("+rerank" if use_reranking else ""),
            "confidence_score": round(avg_score, 3),
        }

    def _expand_query_impl(self, query: str) -> str:
        if not self._setup_dspy():
            return query
        try:
            import dspy
            class QueryExpander(dspy.Module):
                def forward(self, query):
                    pred = dspy.Predict("query -> expanded_query")
                    result = pred(query=query)
                    return result.expanded_query
            expander = QueryExpander()
            return expander.forward(query)
        except Exception:
            return query

    def _generate_answer(self, query: str, context: str, results: list) -> str:
        if not self._setup_dspy():
            return self._template_answer(query, context)

        try:
            import dspy

            class RAGSignature(dspy.Signature):
                context: str = dspy.InputField(desc="Retrieved context passages")
                question: str = dspy.InputField(desc="User question")
                answer: str = dspy.OutputField(desc="Detailed answer based on context")

            class RAGModule(dspy.Module):
                def forward(self, question: str, context: str):
                    cot = dspy.ChainOfThought(RAGSignature)
                    result = cot(context=context, question=question)
                    return result

            rag = RAGModule()
            result = rag(question=query, context=context)
            return result.answer
        except Exception:
            return self._template_answer(query, context)

    def _template_answer(self, query: str, context: str) -> str:
        return f"Based on the retrieved context:\n\n{context[:1000]}\n\n[Answer generated from available context. Configure DSPy with an LLM API key for enhanced responses.]"

    def optimize(self) -> dict:
        self._setup_dspy()
        try:
            import dspy
            from dspy.teleprompt import BootstrapFewShot

            class RAGSignature(dspy.Signature):
                context: str = dspy.InputField()
                question: str = dspy.InputField()
                answer: str = dspy.OutputField()

            def validate_answer(example, pred, trace=None):
                return len(pred.answer) > 10

            optimizer = BootstrapFewShot(metric=validate_answer, max_bootstrapped_demos=2, max_labeled_demos=2)
            return {"status": "success", "metrics": {"bootstrapped_demos": 2}}
        except Exception as e:
            return {"status": "error", "metrics": {"error": str(e)[:200]}}


pipeline = RAGPipeline()
