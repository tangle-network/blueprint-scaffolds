import os
import uuid
import json
from typing import Optional

STORAGE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "storage")
CHUNKS_DIR = os.path.join(STORAGE_DIR, "chunks")
METADATA_FILE = os.path.join(STORAGE_DIR, "metadata.json")
CHROMA_DIR = os.path.join(STORAGE_DIR, "chroma")


def _ensure_dirs():
    os.makedirs(CHUNKS_DIR, exist_ok=True)


def get_metadata() -> dict:
    _ensure_dirs()
    if os.path.exists(METADATA_FILE):
        with open(METADATA_FILE, "r") as f:
            return json.load(f)
    return {"documents": {}, "total_chunks": 0, "optimization_status": "unoptimized"}


def save_metadata(metadata: dict):
    _ensure_dirs()
    with open(METADATA_FILE, "w") as f:
        json.dump(metadata, f, indent=2)


def register_document(document_id: str, filename: str, doc_type: str, chunks: list[dict]) -> int:
    metadata = get_metadata()
    metadata["documents"][document_id] = {
        "filename": filename,
        "type": doc_type,
        "chunks_count": len(chunks),
        "chunk_ids": [],
    }
    chunk_ids = []
    for chunk in chunks:
        chunk_id = str(uuid.uuid4())
        chunk_ids.append(chunk_id)
        chunk_path = os.path.join(CHUNKS_DIR, f"{chunk_id}.json")
        chunk_data = {
            "id": chunk_id,
            "document_id": document_id,
            "text": chunk["text"],
            "metadata": chunk.get("metadata", {}),
            "index": chunk.get("index", 0),
        }
        with open(chunk_path, "w") as f:
            json.dump(chunk_data, f)

    metadata["documents"][document_id]["chunk_ids"] = chunk_ids
    metadata["total_chunks"] = sum(d["chunks_count"] for d in metadata["documents"].values())
    save_metadata(metadata)
    return len(chunks)


def get_all_chunks() -> list[dict]:
    _ensure_dirs()
    chunks = []
    if not os.path.exists(CHUNKS_DIR):
        return chunks
    for fname in os.listdir(CHUNKS_DIR):
        if fname.endswith(".json"):
            with open(os.path.join(CHUNKS_DIR, fname), "r") as f:
                chunks.append(json.load(f))
    return chunks


def get_total_documents() -> int:
    return len(get_metadata().get("documents", {}))


def get_total_chunks() -> int:
    return get_metadata().get("total_chunks", 0)


def set_optimization_status(status: str):
    metadata = get_metadata()
    metadata["optimization_status"] = status
    save_metadata(metadata)
