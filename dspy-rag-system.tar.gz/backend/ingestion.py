import re
import os
from typing import Optional
from bs4 import BeautifulSoup
import markdown


def parse_pdf(content: bytes, filename: str) -> list[dict]:
    try:
        from pypdf import PdfReader
        import io
        reader = PdfReader(io.BytesIO(content))
        chunks = []
        for i, page in enumerate(reader.pages):
            text = page.extract_text()
            if text and text.strip():
                chunks.append({
                    "text": text.strip(),
                    "metadata": {
                        "source": filename,
                        "page_number": i + 1,
                        "type": "pdf",
                    },
                    "index": i,
                })
        return chunks
    except Exception as e:
        return [{"text": f"Error parsing PDF: {e}", "metadata": {"source": filename, "type": "pdf", "error": True}, "index": 0}]


def parse_markdown(content: bytes, filename: str) -> list[dict]:
    text = content.decode("utf-8", errors="replace")
    sections = re.split(r'\n(?=#{1,3}\s)', text)
    chunks = []
    for i, section in enumerate(sections):
        section = section.strip()
        if section:
            html = markdown.markdown(section)
            soup = BeautifulSoup(html, "html.parser")
            clean_text = soup.get_text(separator="\n").strip()
            if clean_text:
                chunks.append({
                    "text": clean_text,
                    "metadata": {
                        "source": filename,
                        "type": "markdown",
                        "section_index": i,
                    },
                    "index": i,
                })
    if not chunks:
        chunks.append({
            "text": text.strip(),
            "metadata": {"source": filename, "type": "markdown"},
            "index": 0,
        })
    return chunks


def parse_html(content: bytes, filename: str) -> list[dict]:
    text = content.decode("utf-8", errors="replace")
    soup = BeautifulSoup(text, "html.parser")
    for tag in soup(["script", "style", "nav", "footer", "header"]):
        tag.decompose()
    elements = soup.find_all(["h1", "h2", "h3", "section", "article", "div"])
    chunks = []
    seen_texts = set()
    for i, el in enumerate(elements):
        chunk_text = el.get_text(separator="\n").strip()
        if chunk_text and len(chunk_text) > 50 and chunk_text not in seen_texts:
            seen_texts.add(chunk_text)
            heading = el.find(["h1", "h2", "h3"])
            chunks.append({
                "text": chunk_text,
                "metadata": {
                    "source": filename,
                    "type": "html",
                    "section_index": i,
                    "heading": heading.get_text(strip=True) if heading else None,
                },
                "index": i,
            })
    if not chunks:
        body = soup.find("body")
        full_text = body.get_text(separator="\n").strip() if body else soup.get_text(separator="\n").strip()
        if full_text:
            chunks.append({
                "text": full_text,
                "metadata": {"source": filename, "type": "html"},
                "index": 0,
            })
    return chunks


def semantic_chunk(chunks: list[dict], max_chunk_size: int = 500, overlap: int = 50) -> list[dict]:
    result = []
    idx = 0
    for chunk in chunks:
        text = chunk["text"]
        if len(text) <= max_chunk_size:
            chunk["index"] = idx
            result.append(chunk)
            idx += 1
        else:
            words = text.split()
            start = 0
            while start < len(words):
                end = min(start + max_chunk_size, len(words))
                sub_text = " ".join(words[start:end])
                result.append({
                    "text": sub_text,
                    "metadata": {
                        **chunk["metadata"],
                        "chunk_start": start,
                        "chunk_end": end,
                    },
                    "index": idx,
                })
                idx += 1
                start += max_chunk_size - overlap
    return result


def ingest_file(content: bytes, filename: str) -> list[dict]:
    ext = os.path.splitext(filename)[1].lower()
    if ext == ".pdf":
        raw_chunks = parse_pdf(content, filename)
    elif ext in (".md", ".markdown"):
        raw_chunks = parse_markdown(content, filename)
    elif ext in (".html", ".htm"):
        raw_chunks = parse_html(content, filename)
    else:
        raw_chunks = [{"text": content.decode("utf-8", errors="replace").strip(), "metadata": {"source": filename, "type": "text"}, "index": 0}]
    return semantic_chunk(raw_chunks)
