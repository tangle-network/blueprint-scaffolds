import os
import sys
import uuid
import traceback

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from backend.models import QueryRequest, QueryResponse, DocumentUploadResponse, SystemStatus, CitationResponse
from backend.ingestion import ingest_file
from backend.store import register_document, get_total_documents, get_total_chunks, set_optimization_status, get_metadata
from backend.retriever import build_indexes, get_retriever_status
from backend.pipeline import pipeline

app = FastAPI(title="RAG DSPy System", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

_indexes_built = False


def ensure_indexes():
    global _indexes_built
    if not _indexes_built:
        build_indexes()
        _indexes_built = True


@app.post("/api/query", response_model=QueryResponse)
async def query_endpoint(request: QueryRequest):
    ensure_indexes()
    try:
        result = pipeline.query(
            query_text=request.query,
            top_k=request.top_k or 5,
            use_reranking=request.use_reranking if request.use_reranking is not None else True,
            use_query_expansion=request.use_query_expansion if request.use_query_expansion is not None else True,
        )
        citations = [
            CitationResponse(
                source_id=c["source_id"],
                source_title=c["source_title"],
                source_type=c["source_type"],
                chunk_text=c["chunk_text"],
                relevance_score=c["relevance_score"],
                page_number=c.get("page_number"),
                chunk_index=c.get("chunk_index", 0),
            )
            for c in result["citations"]
        ]
        return QueryResponse(
            answer=result["answer"],
            citations=citations,
            expanded_query=result.get("expanded_query"),
            reasoning=result.get("reasoning"),
            retrieval_method=result["retrieval_method"],
            confidence_score=result["confidence_score"],
        )
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/documents/upload", response_model=DocumentUploadResponse)
async def upload_document(file: UploadFile = File(...)):
    try:
        content = await file.read()
        if not content:
            raise HTTPException(status_code=400, detail="Empty file")

        document_id = str(uuid.uuid4())
        chunks = ingest_file(content, file.filename or "unknown")
        count = register_document(document_id, file.filename or "unknown", chunks[0]["metadata"]["type"] if chunks else "unknown", chunks)

        global _indexes_built
        _indexes_built = False
        ensure_indexes()

        return DocumentUploadResponse(
            document_id=document_id,
            filename=file.filename or "unknown",
            chunks_count=count,
            status="processed",
        )
    except HTTPException:
        raise
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/status", response_model=SystemStatus)
async def status_endpoint():
    metadata = get_metadata()
    retriever_info = get_retriever_status()
    return SystemStatus(
        total_documents=get_total_documents(),
        total_chunks=get_total_chunks(),
        vector_store_size=retriever_info["total_chunks"],
        optimization_status=metadata.get("optimization_status", "unoptimized"),
        model_name="dspy-optimized",
    )


@app.post("/api/optimize")
async def optimize_endpoint():
    try:
        set_optimization_status("optimizing")
        result = pipeline.optimize()
        if result["status"] == "success":
            set_optimization_status("optimized")
        else:
            set_optimization_status("failed")
        return result
    except Exception as e:
        set_optimization_status("failed")
        return {"status": "error", "metrics": {"error": str(e)[:200]}}


@app.get("/api/health")
async def health():
    return {"status": "ok"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
