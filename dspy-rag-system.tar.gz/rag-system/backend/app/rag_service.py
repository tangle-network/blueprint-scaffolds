from __future__ import annotations

import uuid
from typing import Optional

from .ingestion import ingest_document
from .vector_store import VectorStore
from .retriever import RAGRetriever
from .dspy_modules import DSPyRAGModule, BootstrapFewShotOptimizer, MIPROv2Optimizer
from .chunker import DocumentChunk


class RAGService:
    _instance: Optional["RAGService"] = None

    def __init__(self):
        self.store = VectorStore()
        self.retriever = RAGRetriever(self.store, top_k=10, final_k=5)
        self.module = DSPyRAGModule(self.retriever)
        self.conversations: dict[str, list[dict]] = {}

    @classmethod
    def get_instance(cls) -> "RAGService":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def ingest_file(self, content: bytes, filename: str) -> dict:
        chunks, document_id = ingest_document(content, filename)
        self.store.add_chunks(chunks)
        return {
            "document_id": document_id,
            "chunks": len(chunks),
            "status": "ingested",
        }

    def query(self, query: str, conversation_id: Optional[str] = None) -> dict:
        if conversation_id is None:
            conversation_id = str(uuid.uuid4())

        result = self.module.forward(query)

        self.conversations.setdefault(conversation_id, []).append({
            "query": query,
            "answer": result["answer"],
        })

        return {
            "answer": result["answer"],
            "citations": result["citations"],
            "query_expansions": result["expansions"],
            "confidence": result["confidence"],
            "conversation_id": conversation_id,
        }

    def optimize(self, method: str = "bootstrap") -> dict:
        if method == "miprov2":
            optimizer = MIPROv2Optimizer(self.module)
            _, score_before, score_after = optimizer.compile()
        else:
            optimizer = BootstrapFewShotOptimizer(self.module)
            _, score_before, score_after = optimizer.compile()

        return {
            "score_before": score_before,
            "score_after": score_after,
            "status": "optimized",
        }

    @property
    def total_chunks(self) -> int:
        return self.store.total_chunks
