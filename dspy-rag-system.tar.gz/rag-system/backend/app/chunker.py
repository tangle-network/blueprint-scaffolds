import os
import re
import uuid
import hashlib
from dataclasses import dataclass, field
from typing import Optional

import numpy as np


@dataclass
class DocumentChunk:
    chunk_id: str
    document_id: str
    source: str
    content: str
    page: Optional[int] = None
    chunk_index: int = 0
    metadata: dict = field(default_factory=dict)
    embedding: Optional[list] = None
    sparse_tokens: dict = field(default_factory=dict)


def _compute_sparse_tokens(text: str) -> dict:
    tokens = re.findall(r"\b\w+\b", text.lower())
    freq: dict[str, int] = {}
    for t in tokens:
        freq[t] = freq.get(t, 0) + 1
    return freq


def _simple_hash_embedding(text: str, dim: int = 768) -> list[float]:
    rng = np.random.RandomState(int(hashlib.md5(text.encode()).hexdigest()[:8], 16))
    vec = rng.randn(dim).astype(np.float32)
    vec = vec / (np.linalg.norm(vec) + 1e-8)
    return vec.tolist()


def chunk_text(
    text: str,
    document_id: str,
    source: str,
    page: Optional[int] = None,
    max_chunk_size: int = 512,
    overlap: int = 64,
) -> list[DocumentChunk]:
    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
    chunks: list[DocumentChunk] = []
    current_chunk = ""
    idx = 0

    for para in paragraphs:
        if len(current_chunk) + len(para) + 2 > max_chunk_size and current_chunk:
            emb = _simple_hash_embedding(current_chunk)
            chunks.append(
                DocumentChunk(
                    chunk_id=str(uuid.uuid4()),
                    document_id=document_id,
                    source=source,
                    content=current_chunk.strip(),
                    page=page,
                    chunk_index=idx,
                    embedding=emb,
                    sparse_tokens=_compute_sparse_tokens(current_chunk),
                )
            )
            idx += 1
            words = current_chunk.split()
            current_chunk = " ".join(words[-overlap:]) if overlap else ""

        current_chunk += "\n\n" + para if current_chunk else para

    if current_chunk.strip():
        emb = _simple_hash_embedding(current_chunk)
        chunks.append(
            DocumentChunk(
                chunk_id=str(uuid.uuid4()),
                document_id=document_id,
                source=source,
                content=current_chunk.strip(),
                page=page,
                chunk_index=idx,
                embedding=emb,
                sparse_tokens=_compute_sparse_tokens(current_chunk),
            )
        )

    return chunks
