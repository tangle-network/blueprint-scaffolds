from __future__ import annotations

from typing import Any, Optional

from .retriever import RAGRetriever
from .chunker import DocumentChunk
from .vector_store import VectorStore
from .generator import generate_answer, generate_citations


class DSPyRAGModule:
    def __init__(self, retriever: RAGRetriever):
        self.retriever = retriever
        self._optimized = False

    def forward(self, query: str) -> dict:
        chunks, expansions = self.retriever.retrieve_with_expansion_and_rerank(query)
        answer = generate_answer(query, chunks)
        scores = [0.9 - (i * 0.05) for i in range(len(chunks))]
        citations = generate_citations(chunks, scores)
        confidence = min(0.95, 0.5 + len(chunks) * 0.08) if chunks else 0.1

        return {
            "answer": answer,
            "citations": citations,
            "expansions": expansions,
            "confidence": confidence,
        }


class BootstrapFewShotOptimizer:
    def __init__(self, module: DSPyRAGModule, metric_fn=None):
        self.module = module
        self.metric_fn = metric_fn or self._default_metric
        self._demonstrations: list[dict] = []

    @staticmethod
    def _default_metric(prediction: dict, label: Optional[dict] = None) -> float:
        score = 0.0
        if prediction.get("answer"):
            score += 0.3
        if prediction.get("citations"):
            score += 0.3
            avg_rel = sum(c["relevance_score"] for c in prediction["citations"]) / len(prediction["citations"])
            score += avg_rel * 0.3
        if prediction.get("expansions"):
            score += 0.1
        return min(score, 1.0)

    def compile(
        self, trainset: Optional[list[dict]] = None
    ) -> tuple[DSPyRAGModule, float, float]:
        if trainset is None:
            trainset = self._get_default_trainset()

        score_before = 0.0
        for example in trainset[:3]:
            pred = self.module.forward(example["question"])
            score_before += self.metric_fn(pred, example)
        score_before /= min(len(trainset), 3) or 1

        self._demonstrations = []
        for example in trainset:
            pred = self.module.forward(example["question"])
            metric_score = self.metric_fn(pred, example)
            if metric_score > 0.6:
                self._demonstrations.append({
                    "question": example["question"],
                    "prediction": pred,
                    "score": metric_score,
                })

        score_after = 0.0
        for example in trainset[:3]:
            pred = self.module.forward(example["question"])
            score_after += self.metric_fn(pred, example)
        score_after /= min(len(trainset), 3) or 1

        self.module._optimized = True
        return self.module, score_before, score_after

    def _get_default_trainset(self) -> list[dict]:
        return [
            {"question": "What is the main topic of the documents?"},
            {"question": "Can you summarize the key findings?"},
            {"question": "What are the important conclusions?"},
        ]


class MIPROv2Optimizer:
    def __init__(self, module: DSPyRAGModule, metric_fn=None):
        self.module = module
        self.metric_fn = metric_fn or BootstrapFewShotOptimizer._default_metric
        self._candidates: list[dict] = []

    def compile(
        self,
        trainset: Optional[list[dict]] = None,
        num_candidates: int = 3,
    ) -> tuple[DSPyRAGModule, float, float]:
        if trainset is None:
            trainset = [
                {"question": "What is discussed in these documents?"},
                {"question": "What are the key takeaways?"},
            ]

        score_before = 0.0
        for ex in trainset:
            pred = self.module.forward(ex["question"])
            score_before += self.metric_fn(pred, ex)
        score_before /= len(trainset) or 1

        best_score = score_before
        best_config = {"alpha": 0.7, "top_k": 10, "final_k": 5}

        alphas = [0.5, 0.6, 0.7, 0.8, 0.9]
        top_ks = [5, 10, 15]
        final_ks = [3, 5, 7]

        evaluated = 0
        for alpha in alphas:
            for top_k in top_ks:
                for final_k in final_ks:
                    if evaluated >= num_candidates * 3:
                        break
                    self.module.retriever.hybrid.alpha = alpha
                    self.module.retriever.top_k = top_k
                    self.module.retriever.final_k = final_k

                    score = 0.0
                    for ex in trainset:
                        pred = self.module.forward(ex["question"])
                        score += self.metric_fn(pred, ex)
                    score /= len(trainset) or 1

                    self._candidates.append({
                        "alpha": alpha,
                        "top_k": top_k,
                        "final_k": final_k,
                        "score": score,
                    })

                    if score > best_score:
                        best_score = score
                        best_config = {"alpha": alpha, "top_k": top_k, "final_k": final_k}
                    evaluated += 1

        self.module.retriever.hybrid.alpha = best_config["alpha"]
        self.module.retriever.top_k = best_config["top_k"]
        self.module.retriever.final_k = best_config["final_k"]
        self.module._optimized = True

        return self.module, score_before, best_score
