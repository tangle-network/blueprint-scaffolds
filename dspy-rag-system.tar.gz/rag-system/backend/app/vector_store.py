from __future__ import annotations

import json
import math
import os
import threading
from collections import defaultdict
from typing import Optional

import numpy as np

from .chunker import DocumentChunk

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "vector_store")
METADATA_FILE = os.path.join(DATA_DIR, "metadata.json")
EMBEDDINGS_FILE = os.path.join(DATA_DIR, "embeddings.npy")
IDS_FILE = os.path.join(DATA_DIR, "ids.json")


class VectorStore:
    def __init__(self):
        self._chunks: dict[str, DocumentChunk] = {}
        self._embeddings: dict[str, list[float]] = {}
        self._idf: dict[str, float] = defaultdict(float)
        self._doc_freq: dict[str, int] = defaultdict(int)
        self._total_docs = 0
        self._lock = threading.Lock()
        self._load()

    def _load(self):
        os.makedirs(DATA_DIR, exist_ok=True)
        if os.path.exists(METADATA_FILE):
            with open(METADATA_FILE) as f:
                data = json.load(f)
            for cid, meta in data.items():
                chunk = DocumentChunk(
                    chunk_id=cid,
                    document_id=meta["document_id"],
                    source=meta["source"],
                    content=meta["content"],
                    page=meta.get("page"),
                    chunk_index=meta.get("chunk_index", 0),
                    metadata=meta.get("metadata", {}),
                    sparse_tokens=meta.get("sparse_tokens", {}),
                )
                self._chunks[cid] = chunk
                self._doc_freq[chunk.document_id] += 1
            self._total_docs = len(set(c.document_id for c in self._chunks.values()))

        if os.path.exists(EMBEDDINGS_FILE) and os.path.exists(IDS_FILE):
            emb_matrix = np.load(EMBEDDINGS_FILE)
            with open(IDS_FILE) as f:
                ids = json.load(f)
            for i, cid in enumerate(ids):
                if cid in self._chunks:
                    self._embeddings[cid] = emb_matrix[i].tolist()
                    self._chunks[cid].embedding = emb_matrix[i].tolist()

        self._rebuild_idf()

    def _rebuild_idf(self):
        self._idf.clear()
        doc_tokens: dict[str, set[str]] = defaultdict(set)
        for chunk in self._chunks.values():
            for token in chunk.sparse_tokens:
                doc_tokens[chunk.document_id].add(token)
        for doc_id, tokens in doc_tokens.items():
            for t in tokens:
                self._idf[t] += 1
        self._total_docs = len(doc_tokens)

    def _save(self):
        os.makedirs(DATA_DIR, exist_ok=True)
        metadata = {}
        for cid, chunk in self._chunks.items():
            metadata[cid] = {
                "document_id": chunk.document_id,
                "source": chunk.source,
                "content": chunk.content,
                "page": chunk.page,
                "chunk_index": chunk.chunk_index,
                "metadata": chunk.metadata,
                "sparse_tokens": chunk.sparse_tokens,
            }
        with open(METADATA_FILE, "w") as f:
            json.dump(metadata, f)

        if self._embeddings:
            ids = list(self._embeddings.keys())
            matrix = np.array([self._embeddings[cid] for cid in ids])
            np.save(EMBEDDINGS_FILE, matrix)
            with open(IDS_FILE, "w") as f:
                json.dump(ids, f)

    def add_chunks(self, chunks: list[DocumentChunk]):
        with self._lock:
            for chunk in chunks:
                self._chunks[chunk.chunk_id] = chunk
                if chunk.embedding:
                    self._embeddings[chunk.chunk_id] = chunk.embedding
                self._doc_freq[chunk.document_id] += 1
                for token in chunk.sparse_tokens:
                    self._idf[token] += 1
            self._total_docs = len(set(c.document_id for c in self._chunks.values()))
            self._save()

    def _dense_search(self, query_embedding: list[float], top_k: int) -> list[tuple[str, float]]:
        if not self._embeddings:
            return []
        q = np.array(query_embedding)
        ids = list(self._embeddings.keys())
        matrix = np.array([self._embeddings[cid] for cid in ids])
        norms = np.linalg.norm(matrix, axis=1, keepdims=True) + 1e-8
        matrix_normed = matrix / norms
        q_norm = q / (np.linalg.norm(q) + 1e-8)
        scores = (matrix_normed @ q_norm).flatten()
        top_indices = np.argsort(scores)[::-1][:top_k]
        return [(ids[i], float(scores[i])) for i in top_indices]

    def _sparse_search(self, query_tokens: dict[str, int], top_k: int) -> list[tuple[str, float]]:
        scores: dict[str, float] = defaultdict(float)
        query_norm = 0.0
        for qt, qf in query_tokens.items():
            tfidf_q = qf
            idf = math.log((self._total_docs + 1) / (self._idf.get(qt, 0) + 1)) + 1
            query_norm += (tfidf_q * idf) ** 2
            for cid, chunk in self._chunks.items():
                if qt in chunk.sparse_tokens:
                    tf = chunk.sparse_tokens[qt]
                    scores[cid] += tfidf_q * idf * tf * idf

        if query_norm > 0:
            query_norm = math.sqrt(query_norm)
            for cid in scores:
                doc_norm = sum(
                    (f * math.log((self._total_docs + 1) / (self._idf.get(t, 0) + 1) + 1)) ** 2
                    for t, f in self._chunks[cid].sparse_tokens.items()
                )
                doc_norm = math.sqrt(doc_norm) if doc_norm > 0 else 1.0
                scores[cid] /= (query_norm * doc_norm + 1e-8)

        sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:top_k]
        return sorted_scores

    def hybrid_search(
        self,
        query_embedding: list[float],
        query_tokens: dict[str, int],
        top_k: int = 10,
        alpha: float = 0.7,
    ) -> list[tuple[str, float]]:
        dense_results = self._dense_search(query_embedding, top_k * 2)
        sparse_results = self._sparse_search(query_tokens, top_k * 2)

        max_dense = max((s for _, s in dense_results), default=1.0) or 1.0
        max_sparse = max((s for _, s in sparse_results), default=1.0) or 1.0

        combined: dict[str, float] = {}
        for cid, score in dense_results:
            combined[cid] = combined.get(cid, 0.0) + alpha * (score / max_dense)
        for cid, score in sparse_results:
            combined[cid] = combined.get(cid, 0.0) + (1 - alpha) * (score / max_sparse)

        sorted_results = sorted(combined.items(), key=lambda x: x[1], reverse=True)[:top_k]
        return sorted_results

    def get_chunk(self, chunk_id: str) -> Optional[DocumentChunk]:
        return self._chunks.get(chunk_id)

    def get_all_chunks(self) -> list[DocumentChunk]:
        return list(self._chunks.values())

    @property
    def total_chunks(self) -> int:
        return len(self._chunks)
