from __future__ import annotations

import re
from typing import Optional

from .chunker import DocumentChunk


def generate_answer(query: str, context_chunks: list[DocumentChunk]) -> str:
    if not context_chunks:
        return "I could not find any relevant information to answer your question."

    context_parts = []
    for i, chunk in enumerate(context_chunks, 1):
        source = f"{chunk.source}"
        if chunk.page is not None:
            source += f" (page {chunk.page})"
        context_parts.append(f"[{i}] From {source}:\n{chunk.content}")

    context_text = "\n\n---\n\n".join(context_parts)

    answer = (
        f"Based on the provided documents, here is the answer to your question:\n\n"
        f"Query: {query}\n\n"
        f"Based on the retrieved context, the key points are:\n\n"
    )

    for i, chunk in enumerate(context_chunks, 1):
        sentences = re.split(r'(?<=[.!?])\s+', chunk.content.strip())
        key_sentence = sentences[0] if sentences else chunk.content[:200]
        answer += f"- According to [{i}] {chunk.source}"
        if chunk.page is not None:
            answer += f" (page {chunk.page})"
        answer += f": {key_sentence}\n"

    answer += f"\nThis answer was synthesized from {len(context_chunks)} source passages."
    return answer


def generate_citations(
    chunks: list[DocumentChunk], scores: list[float]
) -> list[dict]:
    citations = []
    for i, (chunk, score) in enumerate(zip(chunks, scores), 1):
        citations.append({
            "id": i,
            "text": chunk.content[:500],
            "source": chunk.source,
            "page": chunk.page,
            "relevance_score": round(min(score, 1.0), 4),
        })
    return citations
