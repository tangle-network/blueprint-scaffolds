from __future__ import annotations

import re
from typing import Optional

from .chunker import DocumentChunk, _simple_hash_embedding, _compute_sparse_tokens
from .vector_store import VectorStore


class HybridRetriever:
    def __init__(self, store: VectorStore, top_k: int = 10, alpha: float = 0.7):
        self.store = store
        self.top_k = top_k
        self.alpha = alpha

    def retrieve(self, query: str, top_k: Optional[int] = None) -> list[tuple[DocumentChunk, float]]:
        k = top_k or self.top_k
        query_embedding = _simple_hash_embedding(query)
        query_tokens = _compute_sparse_tokens(query)
        results = self.store.hybrid_search(query_embedding, query_tokens, top_k=k, alpha=self.alpha)
        output = []
        for cid, score in results:
            chunk = self.store.get_chunk(cid)
            if chunk:
                output.append((chunk, score))
        return output


def expand_query(query: str) -> list[str]:
    expansions = [query]

    words = query.split()
    if len(words) > 2:
        mid = len(words) // 2
        expansions.append(" ".join(words[:mid]))
        expansions.append(" ".join(words[mid:]))

    key_phrases = re.findall(r'"([^"]+)"', query)
    expansions.extend(key_phrases)

    synonyms = {
        "how": ["what", "which way"],
        "what": ["which", "describe"],
        "why": ["reason", "cause"],
        "difference": ["distinction", "comparison"],
        "explain": ["describe", "elaborate"],
    }
    for word in words:
        lower = word.lower()
        if lower in synonyms:
            for syn in synonyms[lower]:
                expansions.append(query.replace(word, syn))

    return list(dict.fromkeys(expansions))[:5]


def reciprocal_rank_fusion(
    result_lists: list[list[tuple[DocumentChunk, float]]], k: int = 60
) -> list[tuple[DocumentChunk, float]]:
    scores: dict[str, float] = {}
    chunks_by_id: dict[str, DocumentChunk] = {}

    for results in result_lists:
        for rank, (chunk, _score) in enumerate(results):
            cid = chunk.chunk_id
            chunks_by_id[cid] = chunk
            scores[cid] = scores.get(cid, 0.0) + 1.0 / (k + rank + 1)

    sorted_items = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    return [(chunks_by_id[cid], score) for cid, score in sorted_items]


def rerank(query: str, results: list[tuple[DocumentChunk, float]], top_n: int = 5) -> list[tuple[DocumentChunk, float]]:
    query_words = set(re.findall(r"\b\w+\b", query.lower()))
    scored: list[tuple[DocumentChunk, float, float]] = []

    for chunk, base_score in results:
        chunk_words = set(re.findall(r"\b\w+\b", chunk.content.lower()))
        overlap = len(query_words & chunk_words)
        precision = overlap / (len(query_words) + 1e-8)
        recall = overlap / (len(chunk_words) + 1e-8)
        f1 = 2 * precision * recall / (precision + recall + 1e-8)
        combined = 0.6 * base_score + 0.4 * f1
        scored.append((chunk, combined, base_score))

    scored.sort(key=lambda x: x[1], reverse=True)
    return [(chunk, combined) for chunk, combined, _base in scored[:top_n]]


class RAGRetriever:
    def __init__(self, store: VectorStore, top_k: int = 10, final_k: int = 5):
        self.hybrid = HybridRetriever(store, top_k=top_k)
        self.top_k = top_k
        self.final_k = final_k

    def retrieve_with_expansion_and_rerank(
        self, query: str
    ) -> tuple[list[DocumentChunk], list[str]]:
        expansions = expand_query(query)
        all_results: list[list[tuple[DocumentChunk, float]]] = []

        for q in [query] + expansions[1:]:
            results = self.hybrid.retrieve(q, top_k=self.top_k)
            all_results.append(results)

        fused = reciprocal_rank_fusion(all_results)
        reranked = rerank(query, fused, top_n=self.final_k)

        chunks = [chunk for chunk, _score in reranked]
        return chunks, expansions
