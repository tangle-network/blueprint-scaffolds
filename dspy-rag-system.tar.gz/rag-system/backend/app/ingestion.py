import os
import re
import uuid
from typing import Optional

from .chunker import DocumentChunk, chunk_text


def _extract_text_from_html(content: str) -> str:
    content = re.sub(r"<script[^>]*>.*?</script>", "", content, flags=re.DOTALL | re.IGNORECASE)
    content = re.sub(r"<style[^>]*>.*?</style>", "", content, flags=re.DOTALL | re.IGNORECASE)
    content = re.sub(r"<br\s*/?>", "\n", content, flags=re.IGNORECASE)
    content = re.sub(r"</?p[^>]*>", "\n", content, flags=re.IGNORECASE)
    content = re.sub(r"<h[1-6][^>]*>", "\n\n", content, flags=re.IGNORECASE)
    content = re.sub(r"</h[1-6]>", "\n\n", content, flags=re.IGNORECASE)
    content = re.sub(r"<[^>]+>", " ", content)
    content = re.sub(r"&nbsp;", " ", content)
    content = re.sub(r"&amp;", "&", content)
    content = re.sub(r"&lt;", "<", content)
    content = re.sub(r"&gt;", ">", content)
    content = re.sub(r"&quot;", '"', content)
    content = re.sub(r"&#\d+;", "", content)
    content = re.sub(r"\n{3,}", "\n\n", content)
    return content.strip()


def _extract_text_from_pdf_simple(content: bytes) -> str:
    try:
        import fitz
        doc = fitz.open(stream=content, filetype="pdf")
        pages = []
        for page in doc:
            pages.append(page.get_text())
        doc.close()
        return "\n\n".join(pages)
    except ImportError:
        text = content.decode("latin-1", errors="ignore")
        strings = re.findall(r"\(([^)]{10,})\)", text)
        return "\n".join(strings) if strings else text[:50000]


def ingest_document(
    content: bytes,
    filename: str,
    max_chunk_size: int = 512,
    overlap: int = 64,
) -> tuple[list[DocumentChunk], str]:
    ext = os.path.splitext(filename)[1].lower()
    document_id = str(uuid.uuid4())

    if ext == ".pdf":
        text = _extract_text_from_pdf_simple(content)
    elif ext in (".html", ".htm"):
        text = _extract_text_from_html(content.decode("utf-8", errors="ignore"))
    elif ext == ".md":
        text = content.decode("utf-8", errors="ignore")
    elif ext == ".txt":
        text = content.decode("utf-8", errors="ignore")
    else:
        raise ValueError(f"Unsupported file type: {ext}")

    if not text.strip():
        raise ValueError("No text content extracted from document")

    chunks = chunk_text(
        text=text,
        document_id=document_id,
        source=filename,
        max_chunk_size=max_chunk_size,
        overlap=overlap,
    )

    return chunks, document_id
