from __future__ import annotations

from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional

from .rag_service import RAGService

app = FastAPI(title="RAG System API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class QueryRequest(BaseModel):
    query: str
    conversation_id: Optional[str] = None


class OptimizeRequest(BaseModel):
    method: str = "bootstrap"


def _get_service() -> RAGService:
    return RAGService.get_instance()


@app.get("/api/health")
async def health():
    svc = _get_service()
    return {"status": "ok", "total_chunks": svc.total_chunks}


@app.post("/api/query")
async def query(req: QueryRequest):
    svc = _get_service()
    return svc.query(req.query, req.conversation_id)


@app.post("/api/ingest")
async def ingest(file: UploadFile = File(...)):
    svc = _get_service()
    content = await file.read()
    return svc.ingest_file(content, file.filename or "document.txt")


@app.post("/api/optimize")
async def optimize():
    svc = _get_service()
    return svc.optimize(method="bootstrap")
