export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
  citations?: Citation[];
}

export interface Citation {
  id: number;
  text: string;
  source: string;
  page?: number;
  relevance_score: number;
}

export interface QueryRequest {
  query: string;
  conversation_id?: string;
}

export interface QueryResponse {
  answer: string;
  citations: Citation[];
  query_expansions: string[];
  confidence: number;
  conversation_id: string;
}

export interface IngestResponse {
  document_id: string;
  chunks: number;
  status: string;
}

export interface OptimizeResponse {
  score_before: number;
  score_after: number;
  status: string;
}

const API_BASE = "/api";

export async function sendQuery(req: QueryRequest): Promise<QueryResponse> {
  const res = await fetch(`${API_BASE}/query`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(req),
  });
  if (!res.ok) throw new Error(`Query failed: ${res.statusText}`);
  return res.json();
}

export async function ingestFile(file: File): Promise<IngestResponse> {
  const form = new FormData();
  form.append("file", file);
  const res = await fetch(`${API_BASE}/ingest`, {
    method: "POST",
    body: form,
  });
  if (!res.ok) throw new Error(`Ingest failed: ${res.statusText}`);
  return res.json();
}

export async function optimize(): Promise<OptimizeResponse> {
  const res = await fetch(`${API_BASE}/optimize`, { method: "POST" });
  if (!res.ok) throw new Error(`Optimize failed: ${res.statusText}`);
  return res.json();
}

export async function getHealth(): Promise<{ status: string }> {
  const res = await fetch(`${API_BASE}/health`);
  if (!res.ok) throw new Error("Health check failed");
  return res.json();
}
