import React, { useState, useRef, useCallback } from "react";
import { ChatMessage, Citation, sendQuery, ingestFile, optimize } from "./api";

interface CitationDisplayProps {
  citation: Citation;
}

function CitationDisplay({ citation }: CitationDisplayProps) {
  return (
    <div className="citation-item">
      <div>{citation.text}</div>
      <div className="citation-meta">
        <span className="citation-source">
          [{citation.id}] {citation.source}
          {citation.page != null ? ` (p.${citation.page})` : ""}
        </span>
        <span className="citation-score">
          {Math.round(citation.relevance_score * 100)}% match
        </span>
      </div>
    </div>
  );
}

function MessageView({ msg }: { msg: ChatMessage }) {
  return (
    <div className={`message ${msg.role}`}>
      <div className="message-bubble">{msg.content}</div>
      {msg.citations && msg.citations.length > 0 && (
        <div className="citations-section">
          <div className="citations-header">Sources ({msg.citations.length})</div>
          {msg.citations.map((c) => (
            <CitationDisplay key={c.id} citation={c} />
          ))}
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [conversationId, setConversationId] = useState<string | undefined>();
  const [backendStatus, setBackendStatus] = useState<
    "unknown" | "ok" | "err" | "loading"
  >("unknown");
  const [optimizing, setOptimizing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = useCallback(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  const handleSend = useCallback(async () => {
    const query = input.trim();
    if (!query || loading) return;

    const userMsg: ChatMessage = { role: "user", content: query };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const res = await sendQuery({
        query,
        conversation_id: conversationId,
      });
      setConversationId(res.conversation_id);
      const assistantMsg: ChatMessage = {
        role: "assistant",
        content: res.answer,
        citations: res.citations,
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } catch {
      const errMsg: ChatMessage = {
        role: "assistant",
        content: "Error: Failed to get response from the RAG system.",
      };
      setMessages((prev) => [...prev, errMsg]);
    } finally {
      setLoading(false);
      setTimeout(scrollToBottom, 100);
    }
  }, [input, loading, conversationId, scrollToBottom]);

  const handleFileUpload = useCallback(
    async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      setLoading(true);
      try {
        const res = await ingestFile(file);
        const infoMsg: ChatMessage = {
          role: "assistant",
          content: `Ingested "${file.name}" — ${res.chunks} chunks created (ID: ${res.document_id})`,
        };
        setMessages((prev) => [...prev, infoMsg]);
      } catch {
        const errMsg: ChatMessage = {
          role: "assistant",
          content: "Error: Failed to ingest document.",
        };
        setMessages((prev) => [...prev, errMsg]);
      } finally {
        setLoading(false);
        if (fileInputRef.current) fileInputRef.current.value = "";
      }
    },
    []
  );

  const handleOptimize = useCallback(async () => {
    setOptimizing(true);
    try {
      const res = await optimize();
      const msg: ChatMessage = {
        role: "assistant",
        content: `Optimization complete. Score: ${res.score_before.toFixed(2)} → ${res.score_after.toFixed(2)} (${res.status})`,
      };
      setMessages((prev) => [...prev, msg]);
    } catch {
      const errMsg: ChatMessage = {
        role: "assistant",
        content: "Error: Optimization failed.",
      };
      setMessages((prev) => [...prev, errMsg]);
    } finally {
      setOptimizing(false);
    }
  }, []);

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        handleSend();
      }
    },
    [handleSend]
  );

  return (
    <div className="app">
      <div className="header">
        <h1>RAG System — DSPy Powered</h1>
        <div className="header-actions">
          <button onClick={() => fileInputRef.current?.click()}>
            Upload Document
          </button>
          <button onClick={handleOptimize} disabled={optimizing}>
            {optimizing ? "Optimizing..." : "Optimize"}
          </button>
          <input
            ref={fileInputRef}
            type="file"
            className="file-input"
            accept=".pdf,.md,.html,.htm,.txt"
            onChange={handleFileUpload}
          />
        </div>
      </div>

      <div className="chat-container">
        {messages.length === 0 && (
          <div
            style={{
              textAlign: "center",
              color: "var(--text-secondary)",
              marginTop: "40%",
              fontSize: "14px",
            }}
          >
            Upload a document and ask questions.
            <br />
            Powered by DSPy with automatic optimization.
          </div>
        )}
        {messages.map((m, i) => (
          <MessageView key={i} msg={m} />
        ))}
        {loading && (
          <div className="message assistant">
            <div className="message-bubble" style={{ opacity: 0.6 }}>
              Thinking...
            </div>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      <div className="input-area">
        <div className="input-row">
          <input
            type="text"
            placeholder="Ask a question about your documents..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={loading}
          />
          <button onClick={handleSend} disabled={loading || !input.trim()}>
            Send
          </button>
        </div>
      </div>

      <div className="status-bar">
        <span>
          <span className={`status-dot ${backendStatus}`} />
          {backendStatus === "ok"
            ? "Connected"
            : backendStatus === "err"
              ? "Disconnected"
              : backendStatus === "loading"
                ? "Connecting..."
                : "Not connected"}
        </span>
        <span>{messages.length} messages</span>
      </div>
    </div>
  );
}
