export interface Citation {
  chunk_id: string;
  document_id: string;
  document_title: string;
  page_number?: number;
  text: string;
  score: number;
  source_type: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  citations?: Citation[];
  confidence?: number;
  reasoning?: string;
  timestamp: Date;
}

export interface QueryRequest {
  query: string;
  top_k?: number;
  use_reranking?: boolean;
  use_query_expansion?: boolean;
  conversation_history?: Array<{ role: string; content: string }>;
}

export interface QueryResponse {
  answer: string;
  citations: Citation[];
  confidence: number;
  reasoning: string;
  expanded_queries?: string[];
  retrieval_scores?: number[];
}

export interface DocumentUpload {
  file: File;
  title?: string;
}

export interface DocumentInfo {
  id: string;
  title: string;
  source_type: string;
  chunk_count: number;
  created_at: string;
  file_size?: number;
}

export interface SystemStatus {
  status: string;
  documents_count: number;
  chunks_count: number;
  index_size: number;
  optimizer_status: string;
  last_optimized?: string;
}

export interface OptimizationResult {
  score_before: number;
  score_after: number;
  examples_used: number;
  duration_seconds: number;
}
