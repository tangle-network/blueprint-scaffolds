import { useEffect, useRef, useCallback } from "react"

export function useQuery<T>(
  fetcher: () => Promise<T>,
  deps: unknown[],
  options?: { enabled?: boolean }
) {
  const mountedRef = useRef(true)

  const execute = useCallback(() => {
    if (options?.enabled === false) return
    fetcher().catch(() => {})
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)

  useEffect(() => {
    mountedRef.current = true
    execute()
    return () => { mountedRef.current = false }
  }, [execute])
}
