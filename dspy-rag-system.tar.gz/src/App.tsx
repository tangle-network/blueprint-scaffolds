import { useState } from "react";
import ChatPanel from "./components/ChatPanel";
import Sidebar from "./components/Sidebar";
import StatusBar from "./components/StatusBar";

export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="flex h-screen overflow-hidden">
      {sidebarOpen && (
        <div className="w-80 flex-shrink-0 border-r border-[var(--border-color)] bg-[var(--bg-secondary)]">
          <Sidebar />
        </div>
      )}
      <div className="flex flex-col flex-1 min-w-0">
        <header className="flex items-center gap-3 px-4 py-3 border-b border-[var(--border-color)] bg-[var(--bg-secondary)]">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-1.5 rounded-md hover:bg-[var(--bg-tertiary)] transition-colors"
            title={sidebarOpen ? "Close sidebar" : "Open sidebar"}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
              <line x1="9" y1="3" x2="9" y2="21" />
            </svg>
          </button>
          <h1 className="text-lg font-semibold">RAG System</h1>
          <span className="text-xs px-2 py-0.5 rounded-full bg-primary-600/20 text-primary-400">DSPy Optimized</span>
          <div className="ml-auto">
            <StatusBar />
          </div>
        </header>
        <main className="flex-1 overflow-hidden">
          <ChatPanel />
        </main>
      </div>
    </div>
  );
}
