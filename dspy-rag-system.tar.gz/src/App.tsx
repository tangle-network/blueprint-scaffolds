import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import ChatInterface from "@/components/ChatInterface"
import DocumentUpload from "@/components/DocumentUpload"
import StatusPanel from "@/components/StatusPanel"
import { SystemStatus } from "@/lib/types"
import { getSystemStatus } from "@/lib/api"
import { useQuery } from "@/hooks/useQuery"
import { BookOpen, FileUp, Activity } from "lucide-react"

export default function App() {
  const [status, setStatus] = useState<SystemStatus | null>(null)

  useQuery(() => getSystemStatus().then(setStatus).catch(() => null), [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 dark:from-slate-950 dark:to-slate-900">
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-slate-900/80 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
              <BookOpen className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-bold">RAG System</h1>
              <p className="text-xs text-muted-foreground">Powered by DSPy</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {status && (
              <>
                <Badge variant="secondary">{status.total_documents} docs</Badge>
                <Badge variant="secondary">{status.total_chunks} chunks</Badge>
                <Badge variant={status.optimization_status === "optimized" ? "default" : "outline"}>
                  {status.optimization_status}
                </Badge>
              </>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        <Tabs defaultValue="chat" className="space-y-4">
          <TabsList>
            <TabsTrigger value="chat" className="gap-2">
              <BookOpen className="h-4 w-4" /> Chat
            </TabsTrigger>
            <TabsTrigger value="upload" className="gap-2">
              <FileUp className="h-4 w-4" /> Documents
            </TabsTrigger>
            <TabsTrigger value="status" className="gap-2">
              <Activity className="h-4 w-4" /> System
            </TabsTrigger>
          </TabsList>

          <TabsContent value="chat">
            <ChatInterface />
          </TabsContent>

          <TabsContent value="upload">
            <DocumentUpload />
          </TabsContent>

          <TabsContent value="status">
            <StatusPanel status={status} onRefresh={() => getSystemStatus().then(setStatus)} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
