import { useState, useEffect, useCallback } from "react";
import { uploadDocument, listDocuments, deleteDocument, ingestUrl } from "@/lib/api";
import type { DocumentInfo } from "@/types";
import { Upload, File, Trash2, Link, RefreshCw, Loader2 } from "lucide-react";

export default function Sidebar() {
  const [documents, setDocuments] = useState<DocumentInfo[]>([]);
  const [uploading, setUploading] = useState(false);
  const [urlInput, setUrlInput] = useState("");
  const [ingesting, setIngesting] = useState(false);
  const [dragOver, setDragOver] = useState(false);

  const loadDocs = useCallback(async () => {
    try {
      const docs = await listDocuments();
      setDocuments(docs);
    } catch {
      // silently fail
    }
  }, []);

  useEffect(() => {
    loadDocs();
  }, [loadDocs]);

  const handleUpload = useCallback(
    async (files: FileList | null) => {
      if (!files?.length) return;
      setUploading(true);
      try {
        for (const file of Array.from(files)) {
          await uploadDocument(file);
        }
        await loadDocs();
      } catch (err) {
        console.error("Upload failed:", err);
      } finally {
        setUploading(false);
      }
    },
    [loadDocs],
  );

  const handleDelete = useCallback(
    async (id: string) => {
      try {
        await deleteDocument(id);
        await loadDocs();
      } catch (err) {
        console.error("Delete failed:", err);
      }
    },
    [loadDocs],
  );

  const handleUrlIngest = useCallback(async () => {
    if (!urlInput.trim()) return;
    setIngesting(true);
    try {
      await ingestUrl(urlInput.trim());
      setUrlInput("");
      await loadDocs();
    } catch (err) {
      console.error("URL ingest failed:", err);
    } finally {
      setIngesting(false);
    }
  }, [urlInput, loadDocs]);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragOver(false);
      handleUpload(e.dataTransfer.files);
    },
    [handleUpload],
  );

  return (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b border-[var(--border-color)]">
        <h2 className="font-semibold mb-3 flex items-center gap-2">
          <File className="w-4 h-4 text-primary-400" />
          Documents
        </h2>
        <div
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          className={`border-2 border-dashed rounded-lg p-4 text-center transition-colors cursor-pointer ${
            dragOver ? "border-primary-500 bg-primary-600/10" : "border-[var(--border-color)] hover:border-primary-500"
          }`}
          onClick={() => document.getElementById("file-upload")?.click()}
        >
          {uploading ? (
            <Loader2 className="w-6 h-6 mx-auto mb-2 text-primary-400 animate-spin" />
          ) : (
            <Upload className="w-6 h-6 mx-auto mb-2 text-[var(--text-secondary)]" />
          )}
          <p className="text-xs text-[var(--text-secondary)]">
            {uploading ? "Uploading..." : "Drop PDF, Markdown, or HTML files"}
          </p>
          <input
            id="file-upload"
            type="file"
            multiple
            accept=".pdf,.md,.html,.htm,.txt"
            className="hidden"
            onChange={(e) => handleUpload(e.target.files)}
          />
        </div>

        <div className="mt-3 flex gap-2">
          <input
            type="url"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
            placeholder="Paste URL to ingest..."
            className="input-base text-xs py-2"
            onKeyDown={(e) => e.key === "Enter" && handleUrlIngest()}
          />
          <button
            onClick={handleUrlIngest}
            disabled={ingesting || !urlInput.trim()}
            className="btn-primary text-xs px-3 flex items-center gap-1 flex-shrink-0"
          >
            {ingesting ? <Loader2 className="w-3 h-3 animate-spin" /> : <Link className="w-3 h-3" />}
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {documents.length === 0 ? (
          <div className="p-4 text-center text-[var(--text-secondary)] text-sm">
            No documents yet. Upload some files to get started.
          </div>
        ) : (
          <div className="divide-y divide-[var(--border-color)]">
            {documents.map((doc) => (
              <div key={doc.id} className="flex items-center gap-3 p-3 hover:bg-[var(--bg-tertiary)] transition-colors group">
                <File className="w-4 h-4 text-primary-400 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm truncate">{doc.title}</p>
                  <p className="text-xs text-[var(--text-secondary)]">
                    {doc.source_type} &middot; {doc.chunk_count} chunks
                  </p>
                </div>
                <button
                  onClick={() => handleDelete(doc.id)}
                  className="p-1 rounded opacity-0 group-hover:opacity-100 hover:bg-red-900/30 text-red-400 transition-all"
                  title="Delete document"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="p-3 border-t border-[var(--border-color)]">
        <button onClick={loadDocs} className="btn-secondary text-xs w-full flex items-center justify-center gap-2">
          <RefreshCw className="w-3 h-3" />
          Refresh
        </button>
      </div>
    </div>
  );
}
