import type { ChatMessage, Citation } from "@/types";
import ReactMarkdown from "react-markdown";
import { FileText, Brain, AlertCircle } from "lucide-react";

interface Props {
  message: ChatMessage;
  onViewCitations: (citations: Citation[]) => void;
}

export default function MessageBubble({ message, onViewCitations }: Props) {
  if (message.role === "system") {
    return (
      <div className="flex items-start gap-3 p-4 rounded-lg bg-red-900/20 border border-red-800/30 max-w-[85%]">
        <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
        <p className="text-sm text-red-300">{message.content}</p>
      </div>
    );
  }

  const isUser = message.role === "user";

  return (
    <div className={`flex flex-col ${isUser ? "items-end" : "items-start"}`}>
      <div className={`chat-message ${isUser ? "chat-message-user" : "chat-message-assistant"}`}>
        <div className="flex items-center gap-2 mb-2">
          {isUser ? (
            <span className="text-xs font-medium text-primary-200">You</span>
          ) : (
            <>
              <Brain className="w-4 h-4 text-primary-400" />
              <span className="text-xs font-medium text-primary-400">RAG Assistant</span>
              {message.confidence !== undefined && (
                <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                  message.confidence >= 0.8 ? "bg-green-900/30 text-green-400" :
                  message.confidence >= 0.5 ? "bg-yellow-900/30 text-yellow-400" :
                  "bg-red-900/30 text-red-400"
                }`}>
                  {Math.round(message.confidence * 100)}% confident
                </span>
              )}
            </>
          )}
        </div>
        <div className="prose prose-invert prose-sm max-w-none">
          <ReactMarkdown>{message.content}</ReactMarkdown>
        </div>
        {!isUser && message.citations && message.citations.length > 0 && (
          <div className="mt-3 pt-3 border-t border-[var(--border-color)]">
            <button
              onClick={() => onViewCitations(message.citations!)}
              className="flex items-center gap-1.5 text-xs text-primary-400 hover:text-primary-300 transition-colors"
            >
              <FileText className="w-3.5 h-3.5" />
              View {message.citations.length} citation{message.citations.length !== 1 ? "s" : ""}
            </button>
          </div>
        )}
      </div>
      {message.reasoning && !isUser && (
        <details className="mt-1 max-w-[85%]">
          <summary className="text-xs text-[var(--text-secondary)] cursor-pointer hover:text-[var(--text-primary)] transition-colors">
            Show reasoning chain
          </summary>
          <div className="mt-1 p-3 rounded-lg bg-[var(--bg-secondary)] border border-[var(--border-color)] text-xs text-[var(--text-secondary)] whitespace-pre-wrap">
            {message.reasoning}
          </div>
        </details>
      )}
    </div>
  );
}
