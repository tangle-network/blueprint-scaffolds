import { useState, useEffect } from "react";
import { getSystemStatus, triggerOptimization } from "@/lib/api";
import type { SystemStatus } from "@/types";
import { Activity, Zap, Loader2 } from "lucide-react";

export default function StatusBar() {
  const [status, setStatus] = useState<SystemStatus | null>(null);
  const [optimizing, setOptimizing] = useState(false);

  useEffect(() => {
    getSystemStatus().then(setStatus).catch(() => {});
    const interval = setInterval(() => {
      getSystemStatus().then(setStatus).catch(() => {});
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleOptimize = async () => {
    setOptimizing(true);
    try {
      await triggerOptimization();
      const s = await getSystemStatus();
      setStatus(s);
    } catch {
      // ignore
    } finally {
      setOptimizing(false);
    }
  };

  return (
    <div className="flex items-center gap-3 text-xs">
      {status && (
        <>
          <span className="flex items-center gap-1.5 text-[var(--text-secondary)]">
            <Activity className="w-3.5 h-3.5 text-green-400" />
            {status.documents_count} docs &middot; {status.chunks_count} chunks
          </span>
          <button
            onClick={handleOptimize}
            disabled={optimizing}
            className="flex items-center gap-1.5 px-2 py-1 rounded bg-primary-600/20 text-primary-400 hover:bg-primary-600/30 transition-colors disabled:opacity-50"
          >
            {optimizing ? (
              <Loader2 className="w-3 h-3 animate-spin" />
            ) : (
              <Zap className="w-3 h-3" />
            )}
            {optimizing ? "Optimizing..." : "Optimize"}
          </button>
        </>
      )}
      {!status && (
        <span className="flex items-center gap-1.5 text-yellow-400">
          <Activity className="w-3.5 h-3.5" />
          Backend offline
        </span>
      )}
    </div>
  );
}
