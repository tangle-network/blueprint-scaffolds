import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { sendQuery } from "@/lib/api"
import type { ChatMessage, Citation, QueryResponse } from "@/lib/types"
import { Send, Bot, User, FileText, ChevronDown, ChevronUp, Loader2 } from "lucide-react"

function CitationCard({ citation, index }: { citation: Citation; index: number }) {
  const [expanded, setExpanded] = useState(false)

  return (
    <div className="border rounded-lg p-3 text-sm bg-muted/30">
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <Badge variant="secondary" className="shrink-0">[{index + 1}]</Badge>
          <span className="font-medium truncate">{citation.source_title}</span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <Badge variant="outline">{citation.source_type}</Badge>
          {citation.page_number && <Badge variant="outline">p.{citation.page_number}</Badge>}
          <Badge variant="outline">{Math.round(citation.relevance_score * 100)}%</Badge>
        </div>
      </div>
      <div className="mt-2 text-muted-foreground">
        <p className={expanded ? "" : "line-clamp-2"}>{citation.chunk_text}</p>
        {citation.chunk_text.length > 150 && (
          <button
            onClick={() => setExpanded(!expanded)}
            className="text-primary hover:underline text-xs mt-1 inline-flex items-center gap-1"
          >
            {expanded ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
            {expanded ? "Show less" : "Show more"}
          </button>
        )}
      </div>
    </div>
  )
}

function MessageBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === "user"

  return (
    <div className={`flex gap-3 ${isUser ? "flex-row-reverse" : ""}`}>
      <Avatar className="h-8 w-8 shrink-0">
        <AvatarFallback className={isUser ? "bg-primary text-primary-foreground" : "bg-muted"}>
          {isUser ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
        </AvatarFallback>
      </Avatar>
      <div className={`flex flex-col gap-1 max-w-[80%] ${isUser ? "items-end" : "items-start"}`}>
        <div
          className={`rounded-lg px-4 py-2 text-sm ${
            isUser ? "bg-primary text-primary-foreground" : "bg-muted"
          }`}
        >
          {message.content}
        </div>
        {message.expanded_query && !isUser && (
          <div className="text-xs text-muted-foreground px-1">
            Expanded query: <span className="italic">{message.expanded_query}</span>
          </div>
        )}
        {message.reasoning && !isUser && (
          <details className="text-xs text-muted-foreground px-1">
            <summary className="cursor-pointer hover:text-foreground">Reasoning trace</summary>
            <p className="mt-1 whitespace-pre-wrap bg-muted/50 rounded p-2">{message.reasoning}</p>
          </details>
        )}
        {message.citations && message.citations.length > 0 && (
          <div className="space-y-2 w-full mt-2">
            <div className="flex items-center gap-1 text-xs text-muted-foreground px-1">
              <FileText className="h-3 w-3" />
              <span>{message.citations.length} source(s)</span>
            </div>
            {message.citations.map((citation, i) => (
              <CitationCard key={i} citation={citation} index={i} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

export default function ChatInterface() {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const [useReranking, setUseReranking] = useState(true)
  const [useExpansion, setUseExpansion] = useState(true)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages])

  const handleSubmit = async () => {
    if (!input.trim() || loading) return

    const userMessage: ChatMessage = {
      id: crypto.randomUUID(),
      role: "user",
      content: input.trim(),
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setLoading(true)

    try {
      const response: QueryResponse = await sendQuery({
        query: userMessage.content,
        top_k: 5,
        use_reranking: useReranking,
        use_query_expansion: useExpansion,
      })

      const assistantMessage: ChatMessage = {
        id: crypto.randomUUID(),
        role: "assistant",
        content: response.answer,
        citations: response.citations,
        expanded_query: response.expanded_query,
        reasoning: response.reasoning,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, assistantMessage])
    } catch (err) {
      const errorMessage: ChatMessage = {
        id: crypto.randomUUID(),
        role: "assistant",
        content: `Error: ${err instanceof Error ? err.message : "Failed to get response"}`,
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="flex flex-col h-[calc(100vh-200px)]">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base">Chat with your documents</CardTitle>
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant={useReranking ? "default" : "outline"}
              onClick={() => setUseReranking(!useReranking)}
            >
              Re-rank
            </Button>
            <Button
              size="sm"
              variant={useExpansion ? "default" : "outline"}
              onClick={() => setUseExpansion(!useExpansion)}
            >
              Query Expansion
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col gap-4 overflow-hidden p-6 pt-0">
        <ScrollArea className="flex-1" ref={scrollRef}>
          <div className="space-y-4 pr-4">
            {messages.length === 0 && (
              <div className="text-center text-muted-foreground py-12">
                <Bot className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p className="text-lg font-medium">Ask a question</p>
                <p className="text-sm">Query your documents using DSPy-powered RAG</p>
              </div>
            )}
            {messages.map((msg) => (
              <MessageBubble key={msg.id} message={msg} />
            ))}
            {loading && (
              <div className="flex gap-3">
                <Avatar className="h-8 w-8 shrink-0">
                  <AvatarFallback className="bg-muted">
                    <Bot className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
                <div className="bg-muted rounded-lg px-4 py-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                </div>
              </div>
            )}
          </div>
        </ScrollArea>
        <form
          onSubmit={(e) => {
            e.preventDefault()
            handleSubmit()
          }}
          className="flex gap-2"
        >
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about your documents..."
            disabled={loading}
            className="flex-1"
          />
          <Button type="submit" disabled={loading || !input.trim()}>
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
