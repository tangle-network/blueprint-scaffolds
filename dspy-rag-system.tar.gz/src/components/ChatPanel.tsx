import { useState, useRef, useEffect, useCallback } from "react";
import { useChat } from "@/hooks/useChat";
import MessageBubble from "./MessageBubble";
import CitationPanel from "./CitationPanel";
import type { Citation } from "@/types";
import { Send, Square, Sparkles } from "lucide-react";

export default function ChatPanel() {
  const { messages, isLoading, sendMessage, clearMessages } = useChat();
  const [input, setInput] = useState("");
  const [selectedCitations, setSelectedCitations] = useState<Citation[]>([]);
  const [showCitations, setShowCitations] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSubmit = useCallback(
    async (e?: React.FormEvent) => {
      e?.preventDefault();
      const trimmed = input.trim();
      if (!trimmed || isLoading) return;
      setInput("");
      await sendMessage(trimmed);
      inputRef.current?.focus();
    },
    [input, isLoading, sendMessage],
  );

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        handleSubmit();
      }
    },
    [handleSubmit],
  );

  const handleViewCitations = useCallback((citations: Citation[]) => {
    setSelectedCitations(citations);
    setShowCitations(true);
  }, []);

  return (
    <div className="flex h-full">
      <div className="flex flex-col flex-1 min-w-0">
        <div className="flex-1 overflow-y-auto px-4 py-6 space-y-4">
          {messages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full text-center text-[var(--text-secondary)]">
              <Sparkles className="w-12 h-12 mb-4 text-primary-500" />
              <h2 className="text-2xl font-semibold text-[var(--text-primary)] mb-2">
                DSPy RAG System
              </h2>
              <p className="max-w-md mb-6">
                Ask questions about your uploaded documents. The system uses hybrid search,
                re-ranking, and automatic DSPy optimization for high-quality answers.
              </p>
              <div className="grid grid-cols-2 gap-3 max-w-lg">
                {["What are the main findings?", "Summarize the key points", "Compare the approaches discussed", "What conclusions are drawn?"].map(
                  (q) => (
                    <button
                      key={q}
                      onClick={() => {
                        setInput(q);
                        inputRef.current?.focus();
                      }}
                      className="p-3 text-sm text-left rounded-lg border border-[var(--border-color)] hover:border-primary-500 hover:bg-primary-600/10 transition-colors"
                    >
                      {q}
                    </button>
                  ),
                )}
              </div>
            </div>
          )}
          {messages.map((msg) => (
            <MessageBubble
              key={msg.id}
              message={msg}
              onViewCitations={handleViewCitations}
            />
          ))}
          {isLoading && (
            <div className="flex items-center gap-2 p-4 chat-message chat-message-assistant">
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-primary-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
                <span className="w-2 h-2 bg-primary-400 rounded-full animate-bounce [animation-delay:-0.15s]" />
                <span className="w-2 h-2 bg-primary-400 rounded-full animate-bounce" />
              </div>
              <span className="text-sm text-[var(--text-secondary)]">Searching & reasoning...</span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="border-t border-[var(--border-color)] p-4 bg-[var(--bg-secondary)]">
          <form onSubmit={handleSubmit} className="flex gap-2">
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask a question about your documents..."
              className="input-base resize-none min-h-[48px] max-h-[200px]"
              rows={1}
              disabled={isLoading}
            />
            {isLoading ? (
              <button type="button" onClick={clearMessages} className="btn-secondary flex items-center gap-2 flex-shrink-0">
                <Square className="w-4 h-4" />
              </button>
            ) : (
              <button type="submit" disabled={!input.trim()} className="btn-primary flex items-center gap-2 flex-shrink-0">
                <Send className="w-4 h-4" />
              </button>
            )}
          </form>
          <div className="flex items-center gap-4 mt-2 text-xs text-[var(--text-secondary)]">
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input type="checkbox" defaultChecked className="rounded" />
              Re-ranking
            </label>
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input type="checkbox" defaultChecked className="rounded" />
              Query expansion
            </label>
            <button type="button" onClick={clearMessages} className="ml-auto hover:text-[var(--text-primary)] transition-colors">
              Clear chat
            </button>
          </div>
        </div>
      </div>

      {showCitations && (
        <CitationPanel
          citations={selectedCitations}
          onClose={() => setShowCitations(false)}
        />
      )}
    </div>
  );
}
