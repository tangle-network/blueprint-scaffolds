import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { triggerOptimization } from "@/lib/api"
import type { SystemStatus } from "@/lib/types"
import { RefreshCw, Zap, Database, Brain, FileText, Loader2 } from "lucide-react"

interface StatusPanelProps {
  status: SystemStatus | null
  onRefresh: () => void
}

export default function StatusPanel({ status, onRefresh }: StatusPanelProps) {
  const [optimizing, setOptimizing] = useState(false)
  const [optResult, setOptResult] = useState<{ status: string; metrics: Record<string, number> } | null>(null)

  const handleOptimize = async () => {
    setOptimizing(true)
    setOptResult(null)
    try {
      const result = await triggerOptimization()
      setOptResult(result)
      onRefresh()
    } catch {
      setOptResult({ status: "error", metrics: {} })
    } finally {
      setOptimizing(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-base">System Status</CardTitle>
              <CardDescription>Current state of the RAG pipeline</CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={onRefresh}>
              <RefreshCw className="h-4 w-4 mr-1" /> Refresh
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {status ? (
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-3 p-3 rounded-lg border">
                <FileText className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-2xl font-bold">{status.total_documents}</p>
                  <p className="text-xs text-muted-foreground">Documents</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 rounded-lg border">
                <Database className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-2xl font-bold">{status.total_chunks}</p>
                  <p className="text-xs text-muted-foreground">Chunks</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 rounded-lg border">
                <Brain className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm font-bold truncate">{status.model_name || "N/A"}</p>
                  <p className="text-xs text-muted-foreground">Model</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 rounded-lg border">
                <Zap className="h-5 w-5 text-muted-foreground" />
                <div>
                  <Badge variant={status.optimization_status === "optimized" ? "default" : "outline"}>
                    {status.optimization_status}
                  </Badge>
                  <p className="text-xs text-muted-foreground mt-1">Optimization</p>
                </div>
              </div>
              <div className="col-span-2 flex items-center gap-3 p-3 rounded-lg border">
                <Database className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-2xl font-bold">{status.vector_store_size}</p>
                  <p className="text-xs text-muted-foreground">Vector Store Size</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center text-muted-foreground py-8">
              <p>Unable to fetch system status</p>
              <p className="text-xs mt-1">Make sure the backend is running</p>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">DSPy Optimization</CardTitle>
          <CardDescription>
            Optimize the RAG pipeline using BootstrapFewShot and MIPROv2
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              DSPy will automatically optimize the prompts and few-shot examples for your retrieval and
              generation modules. This uses BootstrapFewShot for demonstration generation and MIPROv2
              for prompt optimization.
            </p>
            <Button onClick={handleOptimize} disabled={optimizing}>
              {optimizing ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" /> Optimizing...
                </>
              ) : (
                <>
                  <Zap className="h-4 w-4 mr-2" /> Run Optimization
                </>
              )}
            </Button>
            {optResult && (
              <div className="border rounded-lg p-4 space-y-2">
                <div className="flex items-center gap-2">
                  <Badge variant={optResult.status === "success" ? "default" : "destructive"}>
                    {optResult.status}
                  </Badge>
                </div>
                {Object.keys(optResult.metrics).length > 0 && (
                  <div className="grid grid-cols-2 gap-2">
                    {Object.entries(optResult.metrics).map(([key, value]) => (
                      <div key={key} className="text-sm">
                        <span className="text-muted-foreground">{key}:</span>{" "}
                        <span className="font-medium">{typeof value === "number" ? value.toFixed(3) : value}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
