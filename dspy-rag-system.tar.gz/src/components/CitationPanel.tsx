import type { Citation } from "@/types";
import { X, FileText, ExternalLink, Hash } from "lucide-react";

interface Props {
  citations: Citation[];
  onClose: () => void;
}

export default function CitationPanel({ citations, onClose }: Props) {
  return (
    <div className="w-96 flex-shrink-0 border-l border-[var(--border-color)] bg-[var(--bg-secondary)] flex flex-col">
      <div className="flex items-center justify-between p-4 border-b border-[var(--border-color)]">
        <h3 className="font-semibold flex items-center gap-2">
          <FileText className="w-4 h-4 text-primary-400" />
          Citations ({citations.length})
        </h3>
        <button onClick={onClose} className="p-1 rounded hover:bg-[var(--bg-tertiary)] transition-colors">
          <X className="w-4 h-4" />
        </button>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {citations.map((citation, i) => (
          <div key={citation.chunk_id || i} className="citation-card">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="citation-badge">{i + 1}</span>
                <span className="font-medium text-[var(--text-primary)] truncate max-w-[200px]">
                  {citation.document_title || "Untitled"}
                </span>
              </div>
              <span className="text-xs px-1.5 py-0.5 rounded bg-primary-600/20 text-primary-400">
                {Math.round(citation.score * 100)}%
              </span>
            </div>
            <p className="text-[var(--text-secondary)] text-xs leading-relaxed mb-2">
              {citation.text.length > 300 ? citation.text.slice(0, 300) + "..." : citation.text}
            </p>
            <div className="flex items-center gap-3 text-xs text-[var(--text-secondary)]">
              {citation.page_number && (
                <span className="flex items-center gap-1">
                  <Hash className="w-3 h-3" />
                  Page {citation.page_number}
                </span>
              )}
              <span className="flex items-center gap-1">
                <ExternalLink className="w-3 h-3" />
                {citation.source_type}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
