import { useState, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { uploadDocument } from "@/lib/api"
import type { DocumentUploadResponse } from "@/lib/types"
import { Upload, FileText, CheckCircle2, AlertCircle, Loader2, X } from "lucide-react"

interface UploadedFile {
  name: string
  status: "uploading" | "success" | "error"
  response?: DocumentUploadResponse
  error?: string
}

export default function DocumentUpload() {
  const [files, setFiles] = useState<UploadedFile[]>([])
  const [dragActive, setDragActive] = useState(false)

  const handleUpload = useCallback(async (fileList: FileList | File[]) => {
    const newFiles: UploadedFile[] = Array.from(fileList).map((f) => ({
      name: f.name,
      status: "uploading" as const,
    }))
    setFiles((prev) => [...prev, ...newFiles])

    for (const file of Array.from(fileList)) {
      try {
        const response = await uploadDocument(file)
        setFiles((prev) =>
          prev.map((f) =>
            f.name === file.name && f.status === "uploading"
              ? { ...f, status: "success", response }
              : f
          )
        )
      } catch (err) {
        setFiles((prev) =>
          prev.map((f) =>
            f.name === file.name && f.status === "uploading"
              ? { ...f, status: "error", error: err instanceof Error ? err.message : "Upload failed" }
              : f
          )
        )
      }
    }
  }, [])

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setDragActive(false)
      if (e.dataTransfer.files.length) {
        handleUpload(e.dataTransfer.files)
      }
    },
    [handleUpload]
  )

  const handleFileInput = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files?.length) {
        handleUpload(e.target.files)
        e.target.value = ""
      }
    },
    [handleUpload]
  )

  const removeFile = (index: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== index))
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Upload Documents</CardTitle>
          <CardDescription>
            Upload PDF, Markdown, or HTML files for ingestion and semantic chunking
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div
            onDragOver={(e) => {
              e.preventDefault()
              setDragActive(true)
            }}
            onDragLeave={() => setDragActive(false)}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              dragActive ? "border-primary bg-primary/5" : "border-muted-foreground/25"
            }`}
          >
            <Upload className="h-10 w-10 mx-auto mb-3 text-muted-foreground" />
            <p className="text-sm text-muted-foreground mb-3">
              Drag and drop files here, or click to browse
            </p>
            <label>
              <input
                type="file"
                multiple
                accept=".pdf,.md,.html,.htm,.markdown"
                onChange={handleFileInput}
                className="hidden"
              />
              <Button variant="outline" size="sm" asChild>
                <span className="cursor-pointer">Choose Files</span>
              </Button>
            </label>
            <p className="text-xs text-muted-foreground mt-2">
              Supports PDF, Markdown (.md), and HTML files
            </p>
          </div>
        </CardContent>
      </Card>

      {files.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Upload History</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {files.map((file, i) => (
                <div
                  key={i}
                  className="flex items-center gap-3 p-3 rounded-lg border bg-card"
                >
                  <FileText className="h-5 w-5 text-muted-foreground shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{file.name}</p>
                    {file.status === "success" && file.response && (
                      <p className="text-xs text-muted-foreground">
                        {file.response.chunks_count} chunks created &middot; ID: {file.response.document_id.slice(0, 8)}...
                      </p>
                    )}
                    {file.status === "error" && (
                      <p className="text-xs text-destructive">{file.error}</p>
                    )}
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {file.status === "uploading" && (
                      <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                    )}
                    {file.status === "success" && (
                      <Badge variant="default" className="gap-1">
                        <CheckCircle2 className="h-3 w-3" /> Done
                      </Badge>
                    )}
                    {file.status === "error" && (
                      <Badge variant="destructive" className="gap-1">
                        <AlertCircle className="h-3 w-3" /> Failed
                      </Badge>
                    )}
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => removeFile(i)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
