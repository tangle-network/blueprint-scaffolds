import { QueryRequest, QueryResponse, DocumentUploadResponse, SystemStatus } from "./types";

const API_BASE = "/api";

export async function sendQuery(request: QueryRequest): Promise<QueryResponse> {
  const res = await fetch(`${API_BASE}/query`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(request),
  });
  if (!res.ok) throw new Error(`Query failed: ${res.statusText}`);
  return res.json();
}

export async function uploadDocument(file: File): Promise<DocumentUploadResponse> {
  const formData = new FormData();
  formData.append("file", file);
  const res = await fetch(`${API_BASE}/documents/upload`, {
    method: "POST",
    body: formData,
  });
  if (!res.ok) throw new Error(`Upload failed: ${res.statusText}`);
  return res.json();
}

export async function getSystemStatus(): Promise<SystemStatus> {
  const res = await fetch(`${API_BASE}/status`);
  if (!res.ok) throw new Error(`Status failed: ${res.statusText}`);
  return res.json();
}

export async function triggerOptimization(): Promise<{ status: string; metrics: Record<string, number> }> {
  const res = await fetch(`${API_BASE}/optimize`, { method: "POST" });
  if (!res.ok) throw new Error(`Optimization failed: ${res.statusText}`);
  return res.json();
}
