const API_BASE = "/api";

async function fetchAPI<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${endpoint}`, {
    headers: { "Content-Type": "application/json", ...options?.headers },
    ...options,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(err.detail || `API error: ${res.status}`);
  }
  return res.json();
}

import type {
  QueryRequest,
  QueryResponse,
  DocumentInfo,
  SystemStatus,
  OptimizationResult,
} from "@/types";

export async function sendQuery(req: QueryRequest): Promise<QueryResponse> {
  return fetchAPI<QueryResponse>("/query", {
    method: "POST",
    body: JSON.stringify(req),
  });
}

export async function uploadDocument(file: File, title?: string): Promise<DocumentInfo> {
  const form = new FormData();
  form.append("file", file);
  if (title) form.append("title", title);
  const res = await fetch(`${API_BASE}/documents/upload`, { method: "POST", body: form });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(err.detail || `Upload error: ${res.status}`);
  }
  return res.json();
}

export async function listDocuments(): Promise<DocumentInfo[]> {
  return fetchAPI<DocumentInfo[]>("/documents");
}

export async function deleteDocument(id: string): Promise<void> {
  await fetchAPI<void>(`/documents/${id}`, { method: "DELETE" });
}

export async function getSystemStatus(): Promise<SystemStatus> {
  return fetchAPI<SystemStatus>("/status");
}

export async function triggerOptimization(): Promise<OptimizationResult> {
  return fetchAPI<OptimizationResult>("/optimize", { method: "POST" });
}

export async function ingestUrl(url: string, title?: string): Promise<DocumentInfo> {
  return fetchAPI<DocumentInfo>("/documents/ingest-url", {
    method: "POST",
    body: JSON.stringify({ url, title }),
  });
}
