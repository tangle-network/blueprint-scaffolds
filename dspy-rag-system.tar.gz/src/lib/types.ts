export interface Citation {
  source_id: string;
  source_title: string;
  source_type: string;
  chunk_text: string;
  relevance_score: number;
  page_number?: number;
  chunk_index: number;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  citations?: Citation[];
  expanded_query?: string;
  reasoning?: string;
  timestamp: Date;
}

export interface QueryRequest {
  query: string;
  top_k?: number;
  use_reranking?: boolean;
  use_query_expansion?: boolean;
}

export interface QueryResponse {
  answer: string;
  citations: Citation[];
  expanded_query?: string;
  reasoning?: string;
  retrieval_method: string;
  confidence_score: number;
}

export interface DocumentUploadResponse {
  document_id: string;
  filename: string;
  chunks_count: number;
  status: string;
}

export interface SystemStatus {
  total_documents: number;
  total_chunks: number;
  vector_store_size: number;
  optimization_status: string;
  model_name: string;
}
