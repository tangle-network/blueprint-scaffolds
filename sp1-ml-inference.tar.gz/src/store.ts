import { create } from 'zustand';
import type { ModelConfig, InferenceRequest, BatchInferenceJob, VerificationResult, TabId } from './types';

interface AppState {
  activeTab: TabId;
  setActiveTab: (tab: TabId) => void;
  models: ModelConfig[];
  addModel: (model: ModelConfig) => void;
  removeModel: (id: string) => void;
  inferenceRequests: InferenceRequest[];
  addInferenceRequest: (req: InferenceRequest) => void;
  updateInferenceRequest: (id: string, updates: Partial<InferenceRequest>) => void;
  batchJobs: BatchInferenceJob[];
  addBatchJob: (job: BatchInferenceJob) => void;
  updateBatchJob: (id: string, updates: Partial<BatchInferenceJob>) => void;
  verificationResults: VerificationResult[];
  addVerificationResult: (result: VerificationResult) => void;
}

export const useStore = create<AppState>((set) => ({
  activeTab: 'models',
  setActiveTab: (tab) => set({ activeTab: tab }),
  models: [],
  addModel: (model) => set((s) => ({ models: [...s.models, model] })),
  removeModel: (id) => set((s) => ({ models: s.models.filter((m) => m.id !== id) })),
  inferenceRequests: [],
  addInferenceRequest: (req) => set((s) => ({ inferenceRequests: [...s.inferenceRequests, req] })),
  updateInferenceRequest: (id, updates) =>
    set((s) => ({
      inferenceRequests: s.inferenceRequests.map((r) => (r.id === id ? { ...r, ...updates } : r)),
    })),
  batchJobs: [],
  addBatchJob: (job) => set((s) => ({ batchJobs: [...s.batchJobs, job] })),
  updateBatchJob: (id, updates) =>
    set((s) => ({
      batchJobs: s.batchJobs.map((j) => (j.id === id ? { ...j, ...updates } : j)),
    })),
  verificationResults: [],
  addVerificationResult: (result) => set((s) => ({ verificationResults: [...s.verificationResults, result] })),
}));
