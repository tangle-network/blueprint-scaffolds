import React from 'react';
import { classNames } from './utils/helpers';
import type { TabId } from './types';
import { useStore } from './store';
import { ModelManager } from './components/ModelManager';
import { InferencePanel } from './components/InferencePanel';
import { BatchProofs } from './components/BatchProofs';
import { VerificationPanel } from './components/VerificationPanel';
import { ContractViewer } from './components/ContractViewer';
import { Brain, Upload, Layers, ShieldCheck, FileCode } from 'lucide-react';

const TABS: { id: TabId; label: string; icon: React.ReactNode }[] = [
  { id: 'models', label: 'Models', icon: <Upload size={16} /> },
  { id: 'inference', label: 'Inference', icon: <Brain size={16} /> },
  { id: 'batch', label: 'Batch Proofs', icon: <Layers size={16} /> },
  { id: 'verify', label: 'Verify', icon: <ShieldCheck size={16} /> },
  { id: 'contracts', label: 'Contracts', icon: <FileCode size={16} /> },
];

export default function App() {
  const { activeTab, setActiveTab } = useStore();

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-gray-800 bg-gray-950/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-sp1-600 flex items-center justify-center">
                <Brain size={18} className="text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-white leading-tight">SP1 ML Inference</h1>
                <p className="text-xs text-gray-500 leading-tight">Verifiable AI Proofs on-chain</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-3 py-1 text-xs font-medium text-emerald-400 border border-emerald-500/20">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                SP1 Online
              </span>
            </div>
          </div>
        </div>
      </header>

      <nav className="border-b border-gray-800 bg-gray-900/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-1 overflow-x-auto py-2">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={classNames(
                  'inline-flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium whitespace-nowrap transition-colors',
                  activeTab === tab.id
                    ? 'bg-sp1-600/20 text-sp1-400 border border-sp1-500/30'
                    : 'text-gray-400 hover:text-gray-200 hover:bg-gray-800/60'
                )}
              >
                {tab.icon}
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'models' && <ModelManager />}
        {activeTab === 'inference' && <InferencePanel />}
        {activeTab === 'batch' && <BatchProofs />}
        {activeTab === 'verify' && <VerificationPanel />}
        {activeTab === 'contracts' && <ContractViewer />}
      </main>

      <footer className="border-t border-gray-800 py-4 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-gray-500">
            <span>SP1 ML Inference System — ZK Proofs for AI</span>
            <div className="flex items-center gap-4">
              <span>Use Cases: DeFi Oracle • Content Moderation • Credit Scoring</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
