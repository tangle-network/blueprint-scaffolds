export type ArchitectureType = 'mlp' | 'cnn';

export interface LayerConfig {
  type: 'dense' | 'conv2d' | 'relu' | 'softmax' | 'flatten' | 'maxpool';
  inputSize?: number;
  outputSize?: number;
  filters?: number;
  kernelSize?: number;
  stride?: number;
  padding?: number;
}

export interface ModelConfig {
  id: string;
  name: string;
  architecture: ArchitectureType;
  layers: LayerConfig[];
  inputShape: number[];
  outputShape: number[];
  commitmentHash: string;
}

export interface ModelWeights {
  layerIndex: number;
  weights: number[][];
  biases: number[];
}

export interface InferenceRequest {
  id: string;
  modelId: string;
  input: number[];
  timestamp: number;
  status: 'pending' | 'proving' | 'verified' | 'failed';
}

export interface InferenceResult {
  requestId: string;
  output: number[];
  predictedClass: number;
  confidence: number;
  proof: SP1Proof;
}

export interface SP1Proof {
  proofBytes: string;
  publicValues: string;
  vkey: string;
  verifierAddress: string;
}

export interface BatchProof {
  batchId: string;
  requestIds: string[];
  proof: SP1Proof;
  results: InferenceResult[];
}

export interface VerificationStatus {
  isVerified: boolean;
  gasUsed?: number;
  blockNumber?: number;
  txHash?: string;
  error?: string;
}
