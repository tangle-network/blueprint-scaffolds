export interface LayerConfig {
  type: 'dense' | 'conv2d' | 'relu' | 'softmax' | 'flatten' | 'maxpool' | 'dropout';
  inputSize?: number;
  outputSize?: number;
  kernelSize?: number;
  stride?: number;
  padding?: number;
  filters?: number;
  weightsHash?: string;
}

export interface ModelConfig {
  id: string;
  name: string;
  architecture: 'MLP' | 'CNN';
  layers: LayerConfig[];
  inputShape: number[];
  outputShape: number[];
  commitmentHash: string;
  version: number;
  createdAt: number;
}

export interface InferenceRequest {
  id: string;
  modelId: string;
  inputData: number[];
  status: 'pending' | 'proving' | 'verified' | 'failed';
  proof?: SP1Proof;
  result?: number[];
  submittedAt: number;
  completedAt?: number;
}

export interface SP1Proof {
  vkey: string;
  publicValues: string;
  proofBytes: string;
  proofType: 'groth16' | 'plonk' | 'composite';
}

export interface BatchInferenceJob {
  id: string;
  modelId: string;
  requests: InferenceRequest[];
  status: 'queued' | 'processing' | 'completed' | 'failed';
  batchSize: number;
  submittedAt: number;
  completedAt?: number;
}

export interface VerificationResult {
  verified: boolean;
  modelCommitment: string;
  predictedClass: number;
  confidence: number;
  gasUsed?: number;
}

export type TabId = 'models' | 'inference' | 'batch' | 'verify' | 'contracts';
