import type { SP1Proof, InferenceResult, BatchProof, InferenceRequest, VerificationStatus } from '../types';

function generateHexBytes(length: number): string {
  const bytes: string[] = [];
  for (let i = 0; i < length; i++) {
    bytes.push(Math.floor(Math.random() * 256).toString(16).padStart(2, '0'));
  }
  return '0x' + bytes.join('');
}

export function generateMockSP1Proof(modelId: string, inputHash: string, outputHash: string): SP1Proof {
  return {
    proofBytes: generateHexBytes(256),
    publicValues: `${modelId}:${inputHash}:${outputHash}`,
    vkey: generateHexBytes(32),
    verifierAddress: '0x0000000000000000000000000000000000000001',
  };
}

function hashData(data: string): string {
  let hash = 0;
  for (let i = 0; i < data.length; i++) {
    hash = ((hash << 5) - hash + data.charCodeAt(i)) | 0;
  }
  return Math.abs(hash).toString(16).padStart(8, '0');
}

export async function requestProof(
  modelId: string,
  input: number[],
  output: number[]
): Promise<InferenceResult> {
  await new Promise((r) => setTimeout(r, 1500 + Math.random() * 1500));

  const inputHash = hashData(input.join(','));
  const outputHash = hashData(output.join(','));
  const proof = generateMockSP1Proof(modelId, inputHash, outputHash);

  const predictedClass = output.indexOf(Math.max(...output));
  const confidence = output[predictedClass];

  return {
    requestId: generateHexBytes(16),
    output,
    predictedClass,
    confidence,
    proof,
  };
}

export async function requestBatchProofs(
  requests: InferenceRequest[],
  outputs: number[][]
): Promise<BatchProof> {
  await new Promise((r) => setTimeout(r, 2000 + Math.random() * 2000));

  const results: InferenceResult[] = requests.map((req, idx) => {
    const output = outputs[idx];
    const inputHash = hashData(req.id);
    const outputHash = hashData(output.join(','));
    const proof = generateMockSP1Proof(req.modelId, inputHash, outputHash);
    const predictedClass = output.indexOf(Math.max(...output));
    return {
      requestId: req.id,
      output,
      predictedClass,
      confidence: output[predictedClass],
      proof,
    };
  });

  return {
    batchId: generateHexBytes(16),
    requestIds: requests.map((r) => r.id),
    proof: generateMockSP1Proof('batch', hashData(requests.map((r) => r.id).join(',')), hashData(outputs.flat().join(','))),
    results,
  };
}

export async function verifyProofOnChain(proof: SP1Proof): Promise<VerificationStatus> {
  await new Promise((r) => setTimeout(r, 1000 + Math.random() * 1000));

  const isValid = proof.proofBytes.length > 64;

  if (isValid) {
    return {
      isVerified: true,
      gasUsed: Math.floor(150000 + Math.random() * 50000),
      blockNumber: Math.floor(18000000 + Math.random() * 1000),
      txHash: generateHexBytes(32),
    };
  }

  return {
    isVerified: false,
    error: 'Proof verification failed: invalid proof bytes',
  };
}

export function serializeProofForContract(proof: SP1Proof): { proofCalldata: string; publicInputs: string[] } {
  const proofCalldata = proof.proofBytes;
  const publicInputs = proof.publicValues.split(':');
  return { proofCalldata, publicInputs };
}
