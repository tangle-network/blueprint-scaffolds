import type { LayerConfig, ModelConfig, ModelWeights } from '../types';

function relu(x: number): number {
  return Math.max(0, x);
}

function softmax(logits: number[]): number[] {
  const maxLogit = Math.max(...logits);
  const exps = logits.map((l) => Math.exp(l - maxLogit));
  const sum = exps.reduce((a, b) => a + b, 0);
  return exps.map((e) => e / sum);
}

function matMul(input: number[], weights: number[][], outputSize: number): number[] {
  const output = new Array(outputSize).fill(0);
  for (let j = 0; j < outputSize; j++) {
    for (let i = 0; i < input.length; i++) {
      output[j] += input[i] * weights[j][i];
    }
  }
  return output;
}

function conv2d(
  input: number[],
  inputChannels: number,
  inputH: number,
  inputW: number,
  filters: number,
  kernelSize: number,
  stride: number,
  padding: number,
  weights: number[],
  biases: number[]
): { output: number[]; outH: number; outW: number } {
  const outH = Math.floor((inputH + 2 * padding - kernelSize) / stride) + 1;
  const outW = Math.floor((inputW + 2 * padding - kernelSize) / stride) + 1;
  const output = new Array(filters * outH * outW).fill(0);

  for (let f = 0; f < filters; f++) {
    for (let oh = 0; oh < outH; oh++) {
      for (let ow = 0; ow < outW; ow++) {
        let sum = 0;
        for (let c = 0; c < inputChannels; c++) {
          for (let kh = 0; kh < kernelSize; kh++) {
            for (let kw = 0; kw < kernelSize; kw++) {
              const ih = oh * stride + kh - padding;
              const iw = ow * stride + kw - padding;
              if (ih >= 0 && ih < inputH && iw >= 0 && iw < inputW) {
                const inputIdx = c * inputH * inputW + ih * inputW + iw;
                const weightIdx = f * inputChannels * kernelSize * kernelSize + c * kernelSize * kernelSize + kh * kernelSize + kw;
                sum += input[inputIdx] * weights[weightIdx];
              }
            }
          }
        }
        output[f * outH * outW + oh * outW + ow] = sum + biases[f];
      }
    }
  }

  return { output, outH, outW };
}

function maxPool2d(input: number[], channels: number, h: number, w: number, poolSize: number, stride: number): { output: number[]; outH: number; outW: number } {
  const outH = Math.floor((h - poolSize) / stride) + 1;
  const outW = Math.floor((w - poolSize) / stride) + 1;
  const output = new Array(channels * outH * outW).fill(-Infinity);

  for (let c = 0; c < channels; c++) {
    for (let oh = 0; oh < outH; oh++) {
      for (let ow = 0; ow < outW; ow++) {
        for (let ph = 0; ph < poolSize; ph++) {
          for (let pw = 0; pw < poolSize; pw++) {
            const ih = oh * stride + ph;
            const iw = ow * stride + pw;
            const val = input[c * h * w + ih * w + iw];
            const outIdx = c * outH * outW + oh * outW + ow;
            if (val > output[outIdx]) output[outIdx] = val;
          }
        }
      }
    }
  }

  return { output, outH, outW };
}

export function computeModelCommitment(config: ModelConfig, weights: ModelWeights[]): string {
  let hashInput = config.architecture + ':' + config.layers.map((l) => l.type).join(',');
  for (const w of weights) {
    hashInput += ';' + w.weights.flat().join(',') + '|' + w.biases.join(',');
  }
  let hash = 0;
  for (let i = 0; i < hashInput.length; i++) {
    const ch = hashInput.charCodeAt(i);
    hash = ((hash << 5) - hash + ch) | 0;
  }
  const hex = Math.abs(hash).toString(16).padStart(8, '0');
  return '0x' + hex.repeat(8);
}

export function inferModel(
  config: ModelConfig,
  weights: ModelWeights[],
  input: number[]
): number[] {
  let current = [...input];
  let spatialDims = { channels: 0, h: 0, w: 0 };

  if (config.architecture === 'cnn' && config.inputShape.length === 3) {
    spatialDims = {
      channels: config.inputShape[0],
      h: config.inputShape[1],
      w: config.inputShape[2],
    };
  }

  for (let i = 0; i < config.layers.length; i++) {
    const layer = config.layers[i];
    const layerWeights = weights.find((w) => w.layerIndex === i);

    switch (layer.type) {
      case 'dense': {
        if (layerWeights) {
          current = matMul(current, layerWeights.weights, layer.outputSize!);
          current = current.map((v, j) => v + layerWeights.biases[j]);
        }
        break;
      }
      case 'conv2d': {
        if (layerWeights) {
          const flatWeights = layerWeights.weights.flat();
          const result = conv2d(
            current,
            spatialDims.channels || 1,
            spatialDims.h || 1,
            spatialDims.w || 1,
            layer.filters!,
            layer.kernelSize!,
            layer.stride || 1,
            layer.padding || 0,
            flatWeights,
            layerWeights.biases
          );
          current = result.output;
          spatialDims = { channels: layer.filters!, h: result.outH, w: result.outW };
        }
        break;
      }
      case 'relu': {
        current = current.map(relu);
        break;
      }
      case 'softmax': {
        current = softmax(current);
        break;
      }
      case 'maxpool': {
        const ps = layer.kernelSize || 2;
        const st = layer.stride || 2;
        const result = maxPool2d(current, spatialDims.channels, spatialDims.h, spatialDims.w, ps, st);
        current = result.output;
        spatialDims = { channels: spatialDims.channels, h: result.outH, w: result.outW };
        break;
      }
      case 'flatten': {
        break;
      }
    }
  }

  return current;
}

export function generateRandomWeights(config: ModelConfig): ModelWeights[] {
  const result: ModelWeights[] = [];
  for (let i = 0; i < config.layers.length; i++) {
    const layer = config.layers[i];
    if (layer.type === 'dense') {
      const inSize = layer.inputSize!;
      const outSize = layer.outputSize!;
      const w: number[][] = [];
      for (let j = 0; j < outSize; j++) {
        const row: number[] = [];
        for (let k = 0; k < inSize; k++) {
          row.push((Math.random() - 0.5) * 0.5);
        }
        w.push(row);
      }
      result.push({ layerIndex: i, weights: w, biases: new Array(outSize).fill(0).map(() => (Math.random() - 0.5) * 0.1) });
    } else if (layer.type === 'conv2d') {
      const filters = layer.filters!;
      const ks = layer.kernelSize!;
      const channels = spatialDimsForLayer(config, i);
      const totalWeights = filters * channels * ks * ks;
      const flatWeights: number[] = [];
      for (let j = 0; j < totalWeights; j++) {
        flatWeights.push((Math.random() - 0.5) * 0.5);
      }
      const w2d: number[][] = [];
      for (let f = 0; f < filters; f++) {
        const row: number[] = [];
        for (let j = 0; j < channels * ks * ks; j++) {
          row.push(flatWeights[f * channels * ks * ks + j]);
        }
        w2d.push(row);
      }
      result.push({ layerIndex: i, weights: w2d, biases: new Array(filters).fill(0).map(() => (Math.random() - 0.5) * 0.1) });
    }
  }
  return result;
}

function spatialDimsForLayer(config: ModelConfig, layerIdx: number): number {
  if (config.architecture === 'cnn' && config.inputShape.length === 3) {
    if (layerIdx === 0) return config.inputShape[0];
  }
  let channels = config.inputShape.length === 3 ? config.inputShape[0] : 1;
  for (let i = 0; i < layerIdx && i < config.layers.length; i++) {
    if (config.layers[i].type === 'conv2d') {
      channels = config.layers[i].filters || channels;
    }
  }
  return channels;
}

export function argmax(arr: number[]): number {
  return arr.indexOf(Math.max(...arr));
}
