export type ModelArchitecture = "MLP" | "CNN"

export interface ModelLayer {
  type: string
  inputDim?: number
  outputDim?: number
  kernelSize?: number
  stride?: number
  activation?: string
}

export interface RegisteredModel {
  id: string
  name: string
  architecture: ModelArchitecture
  commitmentHash: string
  layers: ModelLayer[]
  inputShape: number[]
  outputShape: number[]
  registeredAt: string
  registeredBy: string
  status: "active" | "deprecated" | "pending"
  totalInferences: number
}

export interface InferenceRequest {
  id: string
  modelId: string
  modelName: string
  inputHash: string
  inputData: number[]
  outputData: number[]
  predictedClass: string
  confidence: number
  proofStatus: "generating" | "verified" | "failed" | "pending"
  sp1ProofHash: string
  cycleCount: number
  submittedAt: string
  verifiedAt?: string
}

export interface BatchProof {
  id: string
  proofIds: string[]
  modelId: string
  modelName: string
  batchSize: number
  aggregateProofHash: string
  status: "aggregating" | "verified" | "failed"
  totalCycles: number
  submittedAt: string
  verifiedAt?: string
}

export interface ProofVerification {
  proofHash: string
  isVerified: boolean
  verifierKey: string
  publicInputs: string[]
  cycleCount: number
}

export interface DashboardStats {
  totalModels: number
  totalInferences: number
  verifiedProofs: number
  pendingProofs: number
  avgCyclesPerProof: number
  totalBatchesProcessed: number
}
