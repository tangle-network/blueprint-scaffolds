export const SP1_VERIFIER_ADDRESS = '0x0000000000000000000000000000000000000001';

export const SUPPORTED_ARCHITECTURES: Record<string, { name: string; description: string }> = {
  mlp: {
    name: 'Multi-Layer Perceptron',
    description: 'Feed-forward neural network for tabular data classification',
  },
  cnn: {
    name: 'Convolutional Neural Network',
    description: 'Convolutional network for image and spatial data',
  },
};

export const EXAMPLE_MODELS = [
  {
    id: 'mlp-classifier-v1',
    name: 'MLP Credit Scorer',
    architecture: 'mlp' as const,
    layers: [
      { type: 'dense' as const, inputSize: 10, outputSize: 32 },
      { type: 'relu' as const },
      { type: 'dense' as const, inputSize: 32, outputSize: 16 },
      { type: 'relu' as const },
      { type: 'dense' as const, inputSize: 16, outputSize: 2 },
      { type: 'softmax' as const },
    ],
    inputShape: [10],
    outputShape: [2],
    commitmentHash: '0xabc1230000000000000000000000000000000000000000000000000000000000',
  },
  {
    id: 'cnn-moderator-v1',
    name: 'CNN Content Moderator',
    architecture: 'cnn' as const,
    layers: [
      { type: 'conv2d' as const, filters: 8, kernelSize: 3, stride: 1, padding: 1 },
      { type: 'relu' as const },
      { type: 'maxpool' as const, kernelSize: 2, stride: 2 },
      { type: 'flatten' as const },
      { type: 'dense' as const, inputSize: 128, outputSize: 32 },
      { type: 'relu' as const },
      { type: 'dense' as const, inputSize: 32, outputSize: 3 },
      { type: 'softmax' as const },
    ],
    inputShape: [1, 8, 8],
    outputShape: [3],
    commitmentHash: '0xdef4560000000000000000000000000000000000000000000000000000000000',
  },
];

export const USE_CASES = [
  {
    id: 'defi-oracle',
    title: 'AI Oracle for DeFi',
    description: 'Verifiable price predictions and risk assessments for DeFi protocols',
    icon: '📊',
  },
  {
    id: 'content-moderation',
    title: 'Content Moderation Proofs',
    description: 'Provable content classification for decentralized social platforms',
    icon: '🛡️',
  },
  {
    id: 'credit-scoring',
    title: 'Credit Scoring Verification',
    description: 'Transparent and auditable creditworthiness predictions',
    icon: '🏦',
  },
];
