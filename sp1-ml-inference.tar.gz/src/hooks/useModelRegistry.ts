import { useState, useCallback } from 'react';
import type { ModelConfig, ModelWeights } from '../types';
import { EXAMPLE_MODELS } from '../constants';
import { computeModelCommitment, generateRandomWeights } from '../lib/ml';

export function useModelRegistry() {
  const [models, setModels] = useState<ModelConfig[]>(EXAMPLE_MODELS);
  const [weightsMap, setWeightsMap] = useState<Map<string, ModelWeights[]>>(new Map());

  const registerModel = useCallback(
    (config: Omit<ModelConfig, 'id' | 'commitmentHash'>) => {
      const id = `model-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      const weights = generateRandomWeights(config as ModelConfig);
      const commitmentHash = computeModelCommitment(config as ModelConfig, weights);

      const newModel: ModelConfig = {
        ...config,
        id,
        commitmentHash,
      };

      setModels((prev) => [...prev, newModel]);
      setWeightsMap((prev) => new Map(prev).set(id, weights));
      return newModel;
    },
    []
  );

  const getModel = useCallback(
    (modelId: string): ModelConfig | undefined => {
      return models.find((m) => m.id === modelId);
    },
    [models]
  );

  const getWeights = useCallback(
    (modelId: string): ModelWeights[] | undefined => {
      if (weightsMap.has(modelId)) return weightsMap.get(modelId);
      const model = models.find((m) => m.id === modelId);
      if (!model) return undefined;
      const w = generateRandomWeights(model);
      setWeightsMap((prev) => new Map(prev).set(modelId, w));
      return w;
    },
    [weightsMap, models]
  );

  return { models, registerModel, getModel, getWeights };
}
