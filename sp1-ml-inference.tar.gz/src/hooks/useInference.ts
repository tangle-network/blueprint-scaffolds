import { useState, useCallback } from 'react';
import type { InferenceRequest, InferenceResult, ModelConfig, ModelWeights, BatchProof } from '../types';
import { inferModel, generateRandomWeights, computeModelCommitment, argmax } from '../lib/ml';
import { requestProof, requestBatchProofs } from '../lib/sp1';

export function useInference() {
  const [requests, setRequests] = useState<InferenceRequest[]>([]);
  const [results, setResults] = useState<Map<string, InferenceResult>>(new Map());
  const [batchProofs, setBatchProofs] = useState<BatchProof[]>([]);
  const [loading, setLoading] = useState(false);

  const submitInference = useCallback(
    async (model: ModelConfig, input: number[]) => {
      const reqId = `req-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      const request: InferenceRequest = {
        id: reqId,
        modelId: model.id,
        input,
        timestamp: Date.now(),
        status: 'pending',
      };
      setRequests((prev) => [...prev, request]);
      setLoading(true);

      try {
        setRequests((prev) => prev.map((r) => (r.id === reqId ? { ...r, status: 'proving' } : r)));

        const weights = generateRandomWeights(model);
        const output = inferModel(model, weights, input);
        const result = await requestProof(model.id, input, output);

        setResults((prev) => new Map(prev).set(reqId, result));
        setRequests((prev) => prev.map((r) => (r.id === reqId ? { ...r, status: 'verified' } : r)));

        return result;
      } catch {
        setRequests((prev) => prev.map((r) => (r.id === reqId ? { ...r, status: 'failed' } : r)));
        return null;
      } finally {
        setLoading(false);
      }
    },
    []
  );

  const submitBatchInference = useCallback(
    async (model: ModelConfig, inputs: number[][]) => {
      setLoading(true);
      const batchReqs: InferenceRequest[] = inputs.map((input, i) => ({
        id: `batch-${Date.now()}-${i}`,
        modelId: model.id,
        input,
        timestamp: Date.now(),
        status: 'proving' as const,
      }));
      setRequests((prev) => [...prev, ...batchReqs]);

      try {
        const weights = generateRandomWeights(model);
        const outputs = inputs.map((input) => inferModel(model, weights, input));
        const batchResult = await requestBatchProofs(batchReqs, outputs);

        setBatchProofs((prev) => [...prev, batchResult]);
        for (const result of batchResult.results) {
          setResults((prev) => new Map(prev).set(result.requestId, result));
        }
        setRequests((prev) =>
          prev.map((r) =>
            batchReqs.some((b) => b.id === r.id) ? { ...r, status: 'verified' } : r
          )
        );
        return batchResult;
      } catch {
        setRequests((prev) =>
          prev.map((r) =>
            batchReqs.some((b) => b.id === r.id) ? { ...r, status: 'failed' } : r
          )
        );
        return null;
      } finally {
        setLoading(false);
      }
    },
    []
  );

  return { requests, results, batchProofs, loading, submitInference, submitBatchInference };
}
