import { useState, useCallback } from 'react';
import type { ModelConfig, LayerConfig } from './types';

export function useModelUpload() {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const parseModelFile = useCallback((content: string): Omit<ModelConfig, 'id' | 'createdAt'> | null => {
    try {
      const data = JSON.parse(content);
      const layers: LayerConfig[] = (data.layers || []).map((l: LayerConfig) => ({
        type: l.type,
        inputSize: l.inputSize,
        outputSize: l.outputSize,
        kernelSize: l.kernelSize,
        stride: l.stride,
        padding: l.padding,
        filters: l.filters,
        weightsHash: l.weightsHash || `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`,
      }));

      const hasConv = layers.some((l) => l.type === 'conv2d' || l.type === 'maxpool');
      const architecture = hasConv ? 'CNN' : 'MLP';
      const inputSize = layers[0]?.inputSize || 0;
      const outputSize = [...layers].reverse().find((l) => l.outputSize)?.outputSize || 0;

      return {
        name: data.name || 'Unnamed Model',
        architecture,
        layers,
        inputShape: data.inputShape || [inputSize],
        outputShape: data.outputShape || [outputSize],
        commitmentHash: `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`,
        version: data.version || 1,
      };
    } catch {
      setError('Invalid model file format');
      return null;
    }
  }, []);

  const uploadModel = useCallback(
    async (file: File): Promise<ModelConfig | null> => {
      setUploading(true);
      setProgress(0);
      setError(null);

      try {
        const content = await file.text();
        const parsed = parseModelFile(content);
        if (!parsed) return null;

        for (let i = 0; i <= 100; i += 20) {
          setProgress(i);
          await new Promise((r) => setTimeout(r, 150));
        }

        const model: ModelConfig = {
          ...parsed,
          id: `model_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
          createdAt: Date.now(),
        };

        setProgress(100);
        return model;
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Upload failed');
        return null;
      } finally {
        setUploading(false);
      }
    },
    [parseModelFile],
  );

  return { uploadModel, uploading, progress, error, setError };
}
