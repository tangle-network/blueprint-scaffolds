import { useState, useCallback } from 'react';
import type { SP1Proof, VerificationResult } from '../types';

export function useProofVerification() {
  const [verifying, setVerifying] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const verifyProof = useCallback(async (proof: SP1Proof): Promise<VerificationResult> => {
    setVerifying(true);
    setError(null);

    try {
      await new Promise((r) => setTimeout(r, 1200));

      const publicValues = proof.publicValues.replace('0x', '');
      const predictedClass = parseInt(publicValues.slice(0, 8), 16) % 10;
      const confidence = 0.85 + Math.random() * 0.14;

      const result: VerificationResult = {
        verified: true,
        modelCommitment: proof.vkey,
        predictedClass,
        confidence: Math.round(confidence * 10000) / 10000,
        gasUsed: 150000 + Math.floor(Math.random() * 50000),
      };

      return result;
    } catch (e) {
      const err = e instanceof Error ? e.message : 'Verification failed';
      setError(err);
      return { verified: false, modelCommitment: '', predictedClass: -1, confidence: 0 };
    } finally {
      setVerifying(false);
    }
  }, []);

  const simulateSP1Execution = useCallback(
    async (modelCommitment: string, inputData: number[]): Promise<SP1Proof> => {
      await new Promise((r) => setTimeout(r, 2000));

      const proof: SP1Proof = {
        vkey: modelCommitment,
        publicValues: `0x${inputData.slice(0, 4).map((v) => Math.floor(v * 255).toString(16).padStart(2, '0')).join('')}${Date.now().toString(16)}`,
        proofBytes: `0x${Array.from({ length: 256 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`,
        proofType: 'groth16',
      };

      return proof;
    },
    [],
  );

  return { verifyProof, simulateSP1Execution, verifying, error };
}
