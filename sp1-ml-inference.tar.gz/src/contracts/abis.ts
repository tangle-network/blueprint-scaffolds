export const ML_VERIFIER_ABI = [
  {
    type: 'function',
    name: 'verifyInference',
    inputs: [
      { name: 'vkey', type: 'bytes32' },
      { name: 'publicValues', type: 'bytes' },
      { name: 'proofBytes', type: 'bytes' },
    ],
    outputs: [{ name: '', type: 'bool' }],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'verifyBatch',
    inputs: [
      { name: 'vkeys', type: 'bytes32[]' },
      { name: 'publicValues', type: 'bytes[]' },
      { name: 'proofBytes', type: 'bytes[]' },
    ],
    outputs: [{ name: '', type: 'bool' }],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'getVerifiedResult',
    inputs: [{ name: 'proofHash', type: 'bytes32' }],
    outputs: [
      { name: 'modelCommitment', type: 'bytes32' },
      { name: 'predictedClass', type: 'uint256' },
      { name: 'confidence', type: 'uint256' },
      { name: 'timestamp', type: 'uint256' },
      { name: 'verified', type: 'bool' },
    ],
    stateMutability: 'view',
  },
  {
    type: 'event',
    name: 'InferenceVerified',
    inputs: [
      { name: 'proofHash', type: 'bytes32', indexed: true },
      { name: 'modelCommitment', type: 'bytes32', indexed: true },
      { name: 'prover', type: 'address', indexed: true },
    ],
  },
] as const;

export const MODEL_REGISTRY_ABI = [
  {
    type: 'function',
    name: 'registerModel',
    inputs: [
      { name: 'commitmentHash', type: 'bytes32' },
      { name: 'architectureType', type: 'uint8' },
      { name: 'metadataURI', type: 'string' },
    ],
    outputs: [{ name: '', type: 'uint256' }],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'getModel',
    inputs: [{ name: 'modelId', type: 'uint256' }],
    outputs: [
      { name: 'commitmentHash', type: 'bytes32' },
      { name: 'owner', type: 'address' },
      { name: 'architectureType', type: 'uint8' },
      { name: 'metadataURI', type: 'string' },
      { name: 'version', type: 'uint256' },
      { name: 'active', type: 'bool' },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'deactivateModel',
    inputs: [{ name: 'modelId', type: 'uint256' }],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'getModelCount',
    inputs: [],
    outputs: [{ name: '', type: 'uint256' }],
    stateMutability: 'view',
  },
  {
    type: 'event',
    name: 'ModelRegistered',
    inputs: [
      { name: 'modelId', type: 'uint256', indexed: true },
      { name: 'owner', type: 'address', indexed: true },
      { name: 'commitmentHash', type: 'bytes32', indexed: false },
    ],
  },
] as const;

export const ML_VERIFIER_ADDRESS = '0x1234578901234567890123456789012345678901' as `0x${string}`;
export const MODEL_REGISTRY_ADDRESS = '0x2234578901234567890123456789012345678902' as `0x${string}`;

export const ARCHITECTURE_TYPES: Record<string, number> = {
  MLP: 0,
  CNN: 1,
};
