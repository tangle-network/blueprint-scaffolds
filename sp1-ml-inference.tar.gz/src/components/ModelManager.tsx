import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { useStore } from '../store';
import { useModelUpload } from '../hooks/useModelUpload';
import { formatTimestamp, formatAddress } from '../utils/helpers';
import { Upload, Trash2, Cpu, Network, Hash } from 'lucide-react';
import type { LayerConfig } from '../types';

const SAMPLE_MLP = {
  name: 'MNIST Classifier (MLP)',
  inputShape: [784],
  outputShape: [10],
  layers: [
    { type: 'dense', inputSize: 784, outputSize: 256 },
    { type: 'relu' },
    { type: 'dense', inputSize: 256, outputSize: 128 },
    { type: 'relu' },
    { type: 'dense', inputSize: 128, outputSize: 10 },
    { type: 'softmax' },
  ],
};

const SAMPLE_CNN = {
  name: 'Image Classifier (CNN)',
  inputShape: [1, 28, 28],
  outputShape: [10],
  layers: [
    { type: 'conv2d', filters: 32, kernelSize: 3, padding: 1 },
    { type: 'relu' },
    { type: 'maxpool', kernelSize: 2, stride: 2 },
    { type: 'conv2d', filters: 64, kernelSize: 3, padding: 1 },
    { type: 'relu' },
    { type: 'maxpool', kernelSize: 2, stride: 2 },
    { type: 'flatten' },
    { type: 'dense', inputSize: 3136, outputSize: 128 },
    { type: 'relu' },
    { type: 'dense', inputSize: 128, outputSize: 10 },
    { type: 'softmax' },
  ],
};

function LayerBadge({ layer }: { layer: LayerConfig }) {
  const colors: Record<string, string> = {
    dense: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
    conv2d: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
    relu: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
    softmax: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
    flatten: 'bg-gray-500/20 text-gray-400 border-gray-500/30',
    maxpool: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
    dropout: 'bg-red-500/20 text-red-400 border-red-500/30',
  };
  return (
    <span className={`inline-flex items-center rounded px-2 py-0.5 text-xs font-mono border ${colors[layer.type] || 'bg-gray-700 text-gray-300'}`}>
      {layer.type}
      {layer.inputSize ? ` ${layer.inputSize}` : ''}
      {layer.outputSize ? `→${layer.outputSize}` : ''}
      {layer.filters ? ` f:${layer.filters}` : ''}
      {layer.kernelSize ? ` k:${layer.kernelSize}` : ''}
    </span>
  );
}

export function ModelManager() {
  const { models, addModel, removeModel } = useStore();
  const { uploadModel, uploading, progress, error } = useModelUpload();

  const onDrop = useCallback(
    async (acceptedFiles: File[]) => {
      for (const file of acceptedFiles) {
        const model = await uploadModel(file);
        if (model) addModel(model);
      }
    },
    [uploadModel, addModel],
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'application/json': ['.json'], 'text/plain': ['.txt'] },
    multiple: true,
  });

  const loadSample = async (sample: typeof SAMPLE_MLP) => {
    const blob = new Blob([JSON.stringify(sample)], { type: 'application/json' });
    const file = new File([blob], `${sample.name}.json`, { type: 'application/json' });
    const model = await uploadModel(file);
    if (model) addModel(model);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">Model Registry</h2>
          <p className="text-sm text-gray-400 mt-1">Upload and manage ML models for verifiable inference</p>
        </div>
        <span className="text-sm text-gray-500">{models.length} model{models.length !== 1 ? 's' : ''} registered</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card">
          <h3 className="text-sm font-semibold text-gray-200 mb-4 flex items-center gap-2">
            <Upload size={16} />
            Upload Model
          </h3>
          <div
            {...getRootProps()}
            className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
              isDragActive ? 'border-sp1-500 bg-sp1-500/5' : 'border-gray-700 hover:border-gray-600'
            }`}
          >
            <input {...getInputProps()} />
            <Upload className="mx-auto mb-3 text-gray-500" size={32} />
            <p className="text-sm text-gray-400">
              {isDragActive ? 'Drop model files here...' : 'Drag & drop model JSON files, or click to browse'}
            </p>
          </div>
          {uploading && (
            <div className="mt-4">
              <div className="w-full bg-gray-800 rounded-full h-2">
                <div className="bg-sp1-500 h-2 rounded-full transition-all" style={{ width: `${progress}%` }} />
              </div>
              <p className="text-xs text-gray-500 mt-1">Processing commitment... {progress}%</p>
            </div>
          )}
          {error && <p className="mt-2 text-xs text-red-400">{error}</p>}
          <div className="mt-4 flex gap-2">
            <button onClick={() => loadSample(SAMPLE_MLP)} className="btn-secondary text-xs">
              <Cpu size={14} /> Sample MLP
            </button>
            <button onClick={() => loadSample(SAMPLE_CNN)} className="btn-secondary text-xs">
              <Network size={14} /> Sample CNN
            </button>
          </div>
        </div>

        <div className="card">
          <h3 className="text-sm font-semibold text-gray-200 mb-4">Use Cases</h3>
          <div className="space-y-3">
            {[
              { title: 'AI Oracle for DeFi', desc: 'Prove price predictions and risk assessments on-chain for trustless DeFi protocols', icon: '💰' },
              { title: 'Content Moderation', desc: 'Generate ZK proofs that content was classified according to committed moderation policies', icon: '🛡️' },
              { title: 'Credit Scoring', desc: 'Verify credit decisions without revealing applicant data, proving fair algorithm application', icon: '📊' },
            ].map((uc) => (
              <div key={uc.title} className="flex gap-3 p-3 rounded-lg bg-gray-800/50 border border-gray-700/50">
                <span className="text-lg">{uc.icon}</span>
                <div>
                  <p className="text-sm font-medium text-gray-200">{uc.title}</p>
                  <p className="text-xs text-gray-500 mt-0.5">{uc.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {models.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-gray-200">Registered Models</h3>
          {models.map((model) => (
            <div key={model.id} className="card">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h4 className="font-semibold text-white">{model.name}</h4>
                    <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${
                      model.architecture === 'CNN'
                        ? 'bg-purple-500/20 text-purple-400'
                        : 'bg-blue-500/20 text-blue-400'
                    }`}>
                      {model.architecture}
                    </span>
                    <span className="text-xs text-gray-500">v{model.version}</span>
                  </div>
                  <div className="flex items-center gap-4 text-xs text-gray-500 mb-3">
                    <span className="flex items-center gap-1"><Hash size={12} /> {formatAddress(model.commitmentHash)}</span>
                    <span>Input: [{model.inputShape.join(', ')}]</span>
                    <span>Output: [{model.outputShape.join(', ')}]</span>
                    <span>{formatTimestamp(model.createdAt)}</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {model.layers.map((layer, i) => (
                      <LayerBadge key={i} layer={layer} />
                    ))}
                  </div>
                </div>
                <button
                  onClick={() => removeModel(model.id)}
                  className="ml-4 p-1.5 text-gray-500 hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-colors"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
