import React, { useState, useCallback } from 'react';
import { useStore } from '../store';
import { useProofVerification } from '../hooks/useProofVerification';
import { formatTimestamp, formatAddress } from '../utils/helpers';
import { Layers, Loader2, CheckCircle2, XCircle, Play } from 'lucide-react';
import type { BatchInferenceJob, InferenceRequest } from '../types';

export function BatchProofs() {
  const { models, addBatchJob, updateBatchJob, addInferenceRequest, updateInferenceRequest, batchJobs } = useStore();
  const { simulateSP1Execution, verifyProof } = useProofVerification();
  const [selectedModel, setSelectedModel] = useState('');
  const [batchSize, setBatchSize] = useState(4);
  const [processing, setProcessing] = useState(false);

  const runBatch = useCallback(async () => {
    const model = models.find((m) => m.id === selectedModel);
    if (!model) return;

    setProcessing(true);
    const requests: InferenceRequest[] = [];

    for (let i = 0; i < batchSize; i++) {
      const inputSize = Math.min(model.inputShape[0] || 10, 10);
      const inputData = Array.from({ length: inputSize }, () => Math.random());

      const req: InferenceRequest = {
        id: `batch_inf_${Date.now()}_${i}_${Math.random().toString(36).slice(2, 6)}`,
        modelId: model.id,
        inputData,
        status: 'pending',
        submittedAt: Date.now(),
      };
      requests.push(req);
      addInferenceRequest(req);
    }

    const job: BatchInferenceJob = {
      id: `batch_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      modelId: model.id,
      requests,
      status: 'processing',
      batchSize,
      submittedAt: Date.now(),
    };
    addBatchJob(job);

    try {
      for (let i = 0; i < requests.length; i++) {
        updateInferenceRequest(requests[i].id, { status: 'proving' });

        const proof = await simulateSP1Execution(model.commitmentHash, requests[i].inputData);
        const result = requests[i].inputData.slice(0, 5).map(() => Math.round(Math.random() * 100) / 100);

        updateInferenceRequest(requests[i].id, {
          status: 'verified',
          proof,
          result,
          completedAt: Date.now(),
        });

        await verifyProof(proof);
      }

      updateBatchJob(job.id, { status: 'completed', completedAt: Date.now() });
    } catch {
      updateBatchJob(job.id, { status: 'failed', completedAt: Date.now() });
    } finally {
      setProcessing(false);
    }
  }, [models, selectedModel, batchSize, addBatchJob, updateBatchJob, addInferenceRequest, updateInferenceRequest, simulateSP1Execution, verifyProof]);

  const statusIcon = (s: string) => {
    switch (s) {
      case 'completed': return <CheckCircle2 size={14} className="text-emerald-400" />;
      case 'processing': return <Loader2 size={14} className="text-sp1-400 animate-spin" />;
      case 'failed': return <XCircle size={14} className="text-red-400" />;
      default: return <Layers size={14} className="text-gray-400" />;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white">Batch Proof Generation</h2>
        <p className="text-sm text-gray-400 mt-1">Generate proofs for multiple inferences in a single batch</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="card space-y-4">
          <h3 className="text-sm font-semibold text-gray-200 flex items-center gap-2">
            <Layers size={16} /> Configure Batch
          </h3>

          <div>
            <label className="label-text">Model</label>
            <select value={selectedModel} onChange={(e) => setSelectedModel(e.target.value)} className="input-field">
              <option value="">Select a model...</option>
              {models.map((m) => (
                <option key={m.id} value={m.id}>{m.name} ({m.architecture})</option>
              ))}
            </select>
          </div>

          <div>
            <label className="label-text">Batch Size (1–64)</label>
            <input
              type="number"
              min={1}
              max={64}
              value={batchSize}
              onChange={(e) => setBatchSize(Math.max(1, Math.min(64, parseInt(e.target.value) || 1)))}
              className="input-field"
            />
          </div>

          <button onClick={runBatch} disabled={!selectedModel || processing} className="btn-primary w-full justify-center">
            {processing ? <><Loader2 size={16} className="animate-spin" /> Processing Batch...</> : <><Play size={16} /> Run Batch ({batchSize} inferences)</>}
          </button>
        </div>

        <div className="card lg:col-span-2">
          <h3 className="text-sm font-semibold text-gray-200 mb-3">Batch Benefits</h3>
          <div className="grid grid-cols-2 gap-4">
            {[
              { title: 'Gas Efficiency', desc: 'Amortize verification costs across multiple proofs', value: '~60% savings' },
              { title: 'Throughput', desc: 'Process up to 64 inferences in a single transaction', value: '64 max' },
              { title: 'Proof Aggregation', desc: 'SP1 composite proofs reduce on-chain data', value: 'Single proof' },
              { title: 'Latency', desc: 'Parallel execution in SP1 RISC-V zkVM', value: '~2s/inf' },
            ].map((item) => (
              <div key={item.title} className="p-3 rounded-lg bg-gray-800/50 border border-gray-700/50">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm font-medium text-gray-200">{item.title}</p>
                  <span className="text-xs font-mono text-sp1-400">{item.value}</span>
                </div>
                <p className="text-xs text-gray-500">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {batchJobs.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-gray-200">Batch History</h3>
          {[...batchJobs].reverse().map((job) => {
            const model = models.find((m) => m.id === job.modelId);
            return (
              <div key={job.id} className="card">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {statusIcon(job.status)}
                    <div>
                      <p className="text-sm font-medium text-gray-200">
                        Batch {formatAddress(job.id)} — {job.batchSize} inferences
                      </p>
                      <p className="text-xs text-gray-500">
                        Model: {model?.name || 'Unknown'} • {formatTimestamp(job.submittedAt)}
                        {job.completedAt && ` • Completed: ${formatTimestamp(job.completedAt)}`}
                      </p>
                    </div>
                  </div>
                  <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium border ${
                    job.status === 'completed' ? 'text-emerald-400 bg-emerald-400/10 border-emerald-400/30' :
                    job.status === 'processing' ? 'text-sp1-400 bg-sp1-400/10 border-sp1-400/30' :
                    job.status === 'failed' ? 'text-red-400 bg-red-400/10 border-red-400/30' :
                    'text-gray-400 bg-gray-400/10 border-gray-400/30'
                  }`}>
                    {job.status}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
