import React from 'react'

export function ContractViewer({ children }: { children?: React.ReactNode }) { return <div>{children}</div> }
