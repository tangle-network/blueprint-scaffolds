import React, { useState, useCallback } from 'react';
import { useStore } from '../store';
import { useProofVerification } from '../hooks/useProofVerification';
import { hexHash, formatTimestamp, formatAddress } from '../utils/helpers';
import { Brain, Loader2, CheckCircle2, XCircle, Zap } from 'lucide-react';
import type { InferenceRequest, SP1Proof } from '../types';

const STATUS_CONFIG: Record<string, { color: string; icon: React.ReactNode }> = {
  pending: { color: 'text-amber-400 bg-amber-400/10 border-amber-400/30', icon: <Loader2 size={12} className="animate-spin" /> },
  proving: { color: 'text-sp1-400 bg-sp1-400/10 border-sp1-400/30', icon: <Loader2 size={12} className="animate-spin" /> },
  verified: { color: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/30', icon: <CheckCircle2 size={12} /> },
  failed: { color: 'text-red-400 bg-red-400/10 border-red-400/30', icon: <XCircle size={12} /> },
};

export function InferencePanel() {
  const { models, inferenceRequests, addInferenceRequest, updateInferenceRequest, addVerificationResult } = useStore();
  const { simulateSP1Execution, verifyProof } = useProofVerification();
  const [selectedModel, setSelectedModel] = useState('');
  const [inputData, setInputData] = useState('');
  const [provingId, setProvingId] = useState<string | null>(null);

  const handleInfer = useCallback(async () => {
    const model = models.find((m) => m.id === selectedModel);
    if (!model) return;

    const parsed = inputData
      .split(',')
      .map((s) => parseFloat(s.trim()))
      .filter((n) => !isNaN(n));

    if (parsed.length === 0) return;

    const req: InferenceRequest = {
      id: `inf_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      modelId: model.id,
      inputData: parsed,
      status: 'pending',
      submittedAt: Date.now(),
    };

    addInferenceRequest(req);
    setProvingId(req.id);

    try {
      updateInferenceRequest(req.id, { status: 'proving' });

      const proof: SP1Proof = await simulateSP1Execution(model.commitmentHash, parsed);

      const result = parsed.length > 0
        ? parsed.slice(0, model.outputShape[0] || 5).map((_, i) => Math.round(Math.random() * 100) / 100)
        : [];

      updateInferenceRequest(req.id, {
        status: 'verified',
        proof,
        result,
        completedAt: Date.now(),
      });

      const vr = await verifyProof(proof);
      addVerificationResult(vr);
    } catch {
      updateInferenceRequest(req.id, { status: 'failed', completedAt: Date.now() });
    } finally {
      setProvingId(null);
    }
  }, [models, selectedModel, inputData, addInferenceRequest, updateInferenceRequest, addVerificationResult, simulateSP1Execution, verifyProof]);

  const loadSampleInput = () => {
    const model = models.find((m) => m.id === selectedModel);
    const size = model?.inputShape[0] || 784;
    if (size <= 20) {
      setInputData(Array.from({ length: size }, () => (Math.random()).toFixed(3)).join(', '));
    } else {
      setInputData(Array.from({ length: 20 }, () => (Math.random()).toFixed(3)).join(', ') + `, ... (${size - 20} more values)`);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white">SP1 Inference</h2>
        <p className="text-sm text-gray-400 mt-1">Submit ML inference requests and generate ZK proofs with SP1</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card space-y-4">
          <h3 className="text-sm font-semibold text-gray-200 flex items-center gap-2">
            <Brain size={16} /> New Inference Request
          </h3>

          <div>
            <label className="label-text">Model</label>
            <select
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value)}
              className="input-field"
            >
              <option value="">Select a model...</option>
              {models.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name} ({m.architecture})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="label-text">Input Data (comma-separated)</label>
            <textarea
              value={inputData}
              onChange={(e) => setInputData(e.target.value)}
              placeholder="0.5, 0.3, 0.8, ..."
              rows={4}
              className="input-field font-mono text-xs"
            />
          </div>

          <div className="flex gap-2">
            <button onClick={handleInfer} disabled={!selectedModel || !inputData || provingId !== null} className="btn-primary">
              {provingId ? <><Loader2 size={16} className="animate-spin" /> Proving...</> : <><Zap size={16} /> Run Inference + Generate Proof</>}
            </button>
            {selectedModel && (
              <button onClick={loadSampleInput} className="btn-secondary text-xs">
                Sample Input
              </button>
            )}
          </div>

          {models.length === 0 && (
            <p className="text-xs text-amber-400">No models registered. Go to Models tab to upload one first.</p>
          )}
        </div>

        <div className="card">
          <h3 className="text-sm font-semibold text-gray-200 mb-3">Inference Pipeline</h3>
          <div className="space-y-3">
            {[
              { step: 1, label: 'Input Encoding', desc: 'Input data encoded into SP1-compatible format' },
              { step: 2, label: 'Model Loading', desc: 'Neural network weights loaded from commitment' },
              { step: 3, label: 'Forward Pass', desc: 'MLP/CNN forward propagation in RISC-V zkVM' },
              { step: 4, label: 'Proof Generation', desc: 'SP1 generates Groth16/PLONK proof of execution' },
              { step: 5, label: 'On-chain Verification', desc: 'Smart contract verifies proof and records result' },
            ].map((s) => (
              <div key={s.step} className="flex gap-3 items-start">
                <div className="w-7 h-7 rounded-full bg-sp1-600/20 border border-sp1-500/40 flex items-center justify-center text-xs font-bold text-sp1-400 flex-shrink-0">
                  {s.step}
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-200">{s.label}</p>
                  <p className="text-xs text-gray-500">{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {inferenceRequests.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-gray-200">Inference History</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-800">
                  <th className="text-left py-2 px-3 text-gray-500 font-medium">ID</th>
                  <th className="text-left py-2 px-3 text-gray-500 font-medium">Model</th>
                  <th className="text-left py-2 px-3 text-gray-500 font-medium">Status</th>
                  <th className="text-left py-2 px-3 text-gray-500 font-medium">Result</th>
                  <th className="text-left py-2 px-3 text-gray-500 font-medium">Proof Type</th>
                  <th className="text-left py-2 px-3 text-gray-500 font-medium">Time</th>
                </tr>
              </thead>
              <tbody>
                {[...inferenceRequests].reverse().map((req) => {
                  const model = models.find((m) => m.id === req.modelId);
                  const sc = STATUS_CONFIG[req.status];
                  return (
                    <tr key={req.id} className="border-b border-gray-800/50">
                      <td className="py-2 px-3 font-mono text-xs text-gray-400">{formatAddress(req.id)}</td>
                      <td className="py-2 px-3 text-gray-300">{model?.name || 'Unknown'}</td>
                      <td className="py-2 px-3">
                        <span className={`inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-xs font-medium border ${sc.color}`}>
                          {sc.icon} {req.status}
                        </span>
                      </td>
                      <td className="py-2 px-3 font-mono text-xs text-gray-400">
                        {req.result ? `[${req.result.slice(0, 4).map((r) => r.toFixed(3)).join(', ')}${req.result.length > 4 ? ', ...' : ''}]` : '—'}
                      </td>
                      <td className="py-2 px-3 text-xs text-gray-400">{req.proof?.proofType || '—'}</td>
                      <td className="py-2 px-3 text-xs text-gray-500">{formatTimestamp(req.submittedAt)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
