import React from 'react'

export function VerificationPanel({ children }: { children?: React.ReactNode }) { return <div>{children}</div> }
