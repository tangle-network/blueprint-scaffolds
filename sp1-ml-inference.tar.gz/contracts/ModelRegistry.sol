// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract ModelRegistry {
    enum ArchitectureType { MLP, CNN }

    struct Model {
        bytes32 commitmentHash;
        address owner;
        ArchitectureType architectureType;
        string metadataURI;
        uint256 version;
        bool active;
        uint256 registeredAt;
    }

    mapping(uint256 => Model) public models;
    mapping(bytes32 => uint256) public commitmentToId;
    uint256 public modelCount;

    event ModelRegistered(
        uint256 indexed modelId,
        address indexed owner,
        bytes32 commitmentHash,
        ArchitectureType architectureType
    );

    event ModelDeactivated(uint256 indexed modelId, address indexed owner);

    event ModelUpdated(uint256 indexed modelId, uint256 newVersion);

    function registerModel(
        bytes32 commitmentHash,
        ArchitectureType architectureType,
        string calldata metadataURI
    ) external returns (uint256) {
        require(commitmentHash != bytes32(0), "Invalid commitment");
        require(commitmentToId[commitmentHash] == 0, "Commitment already registered");

        uint256 modelId = ++modelCount;

        models[modelId] = Model({
            commitmentHash: commitmentHash,
            owner: msg.sender,
            architectureType: architectureType,
            metadataURI: metadataURI,
            version: 1,
            active: true,
            registeredAt: block.timestamp
        });

        commitmentToId[commitmentHash] = modelId;

        emit ModelRegistered(modelId, msg.sender, commitmentHash, architectureType);

        return modelId;
    }

    function deactivateModel(uint256 modelId) external {
        Model storage model = models[modelId];
        require(model.owner == msg.sender, "Not model owner");
        require(model.active, "Already inactive");

        model.active = false;
        emit ModelDeactivated(modelId, msg.sender);
    }

    function getModel(uint256 modelId)
        external
        view
        returns (
            bytes32 commitmentHash,
            address owner,
            ArchitectureType architectureType,
            string memory metadataURI,
            uint256 version,
            bool active
        )
    {
        Model storage m = models[modelId];
        return (m.commitmentHash, m.owner, m.architectureType, m.metadataURI, m.version, m.active);
    }

    function getModelsByOwner(address owner) external view returns (uint256[] memory) {
        uint256 count;
        for (uint256 i = 1; i <= modelCount; i++) {
            if (models[i].owner == owner) count++;
        }

        uint256[] memory ids = new uint256[](count);
        uint256 idx;
        for (uint256 i = 1; i <= modelCount; i++) {
            if (models[i].owner == owner) {
                ids[idx++] = i;
            }
        }
        return ids;
    }

    function verifyCommitment(bytes32 commitmentHash) external view returns (bool) {
        uint256 id = commitmentToId[commitmentHash];
        return id != 0 && models[id].active;
    }
}
