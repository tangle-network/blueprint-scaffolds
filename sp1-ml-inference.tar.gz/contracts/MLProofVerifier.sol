-- SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface ISP1Verifier {
    function verifyProof(
        bytes32 vkey,
        bytes calldata publicValues,
        bytes calldata proofBytes
    ) external view returns (bool);
}

contract MLProofVerifier {
    ISP1Verifier public verifier;

    struct InferenceResult {
        bytes32 modelCommitment;
        uint256 predictedClass;
        uint256 confidence;
        uint256 timestamp;
        bool verified;
    }

    mapping(bytes32 => InferenceResult) public results;
    mapping(bytes32 => bool) public processedProofs;

    event InferenceVerified(
        bytes32 indexed proofHash,
        bytes32 indexed modelCommitment,
        address indexed prover,
        uint256 predictedClass,
        uint256 confidence
    );

    event BatchVerified(
        bytes32 indexed batchHash,
        uint256 count,
        address indexed prover
    );

    constructor(address _verifier) {
        verifier = ISP1Verifier(_verifier);
    }

    function verifyInference(
        bytes32 vkey,
        bytes calldata publicValues,
        bytes32[] calldata publicInputs,
        bytes calldata proofBytes
    ) external returns (bool) {
        bytes32 proofHash = keccak256(abi.encodePacked(vkey, publicValues, proofBytes));
        require(!processedProofs[proofHash], "Proof already processed");

        bool valid = verifier.verifyProof(vkey, publicValues, proofBytes);
        require(valid, "Invalid SP1 proof");

        require(publicInputs.length >= 2, "Insufficient public inputs");

        results[proofHash] = InferenceResult({
            modelCommitment: vkey,
            predictedClass: publicInputs[0],
            confidence: publicInputs[1],
            timestamp: block.timestamp,
            verified: true
        });

        processedProofs[proofHash] = true;

        emit InferenceVerified(
            proofHash,
            vkey,
            msg.sender,
            publicInputs[0],
            publicInputs[1]
        );

        return true;
    }

    function verifyBatch(
        bytes32[] calldata vkeys,
        bytes[] calldata publicValues,
        bytes32[][] calldata allPublicInputs,
        bytes[] calldata proofBytes
    ) external returns (bool) {
        require(
            vkeys.length == publicValues.length &&
            vkeys.length == proofBytes.length,
            "Array length mismatch"
        );
        require(vkeys.length > 0 && vkeys.length <= 64, "Invalid batch size");

        for (uint256 i = 0; i < vkeys.length; i++) {
            bool valid = verifier.verifyProof(vkeys[i], publicValues[i], proofBytes[i]);
            require(valid, "Invalid proof in batch");

            bytes32 proofHash = keccak256(
                abi.encodePacked(vkeys[i], publicValues[i], proofBytes[i])
            );

            if (allPublicInputs[i].length >= 2) {
                results[proofHash] = InferenceResult({
                    modelCommitment: vkeys[i],
                    predictedClass: allPublicInputs[i][0],
                    confidence: allPublicInputs[i][1],
                    timestamp: block.timestamp,
                    verified: true
                });
            }

            processedProofs[proofHash] = true;

            emit InferenceVerified(
                proofHash,
                vkeys[i],
                msg.sender,
                allPublicInputs[i].length > 0 ? allPublicInputs[i][0] : 0,
                allPublicInputs[i].length > 1 ? allPublicInputs[i][1] : 0
            );
        }

        bytes32 batchHash = keccak256(abi.encodePacked(vkeys, publicValues, proofBytes));
        emit BatchVerified(batchHash, vkeys.length, msg.sender);

        return true;
    }

    function getVerifiedResult(bytes32 proofHash) external view returns (InferenceResult memory) {
        require(results[proofHash].verified, "Result not found");
        return results[proofHash];
    }

    function isProofProcessed(bytes32 proofHash) external view returns (bool) {
        return processedProofs[proofHash];
    }
}
