/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          purple: {
            50: '#f5f0ff',
            100: '#ede5ff',
            200: '#dcceff',
            300: '#c4a8ff',
            400: '#a875ff',
            500: '#8b3dff',
            600: '#7c1fff',
            700: '#6d0eef',
            800: '#5b0ec5',
            900: '#4c0f9e',
            950: '#2d046a',
          },
          blue: {
            50: '#eff8ff',
            100: '#dbeffe',
            200: '#bfe3ff',
            300: '#93d1ff',
            400: '#60b5ff',
            500: '#3b91ff',
            600: '#1a6ff5',
            700: '#1459e1',
            800: '#1749b6',
            900: '#193f8f',
            950: '#142757',
          },
          green: {
            50: '#edfff6',
            100: '#d5ffea',
            200: '#aeffd9',
            300: '#70ffbd',
            400: '#2bfd99',
            500: '#00e67e',
            600: '#00bf65',
            700: '#009552',
            800: '#067544',
            900: '#07603a',
            950: '#003721',
          },
        },
      },
    },
  },
  plugins: [],
}
