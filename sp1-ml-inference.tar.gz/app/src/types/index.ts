export type ModelArchitecture = 'MLP' | 'CNN'

export interface ModelLayer {
  type: string
  inputDim?: number
  outputDim?: number
  kernelSize?: number
  stride?: number
  activation?: string
}

export interface MLModel {
  id: string
  name: string
  architecture: ModelArchitecture
  inputShape: number[]
  layers: ModelLayer[]
  commitHash: string
  verifierKey: string
  owner: string
  registeredAt: string
  status: 'active' | 'deprecated' | 'pending'
}

export interface InferenceRequest {
  id: string
  modelId: string
  inputData: number[]
  prediction: string
  confidence: number
  proofId: string
  status: 'generating' | 'verified' | 'failed' | 'pending'
  timestamp: string
}

export interface ProofBatch {
  id: string
  proofIds: string[]
  modelId: string
  status: 'aggregating' | 'verified' | 'failed'
  sp1Version: string
  gasUsed: number
  verifiedAt?: string
}

export interface VerificationResult {
  proofId: string
  isValid: boolean
  verifierAddress: string
  blockNumber: number
  gasCost: number
}

export interface ModelMetrics {
  totalInferences: number
  avgLatency: number
  successRate: number
  totalProofsVerified: number
}

export interface RegisteredModel {
  id: string
  name: string
  architecture: ModelArchitecture
  commitmentHash: string
  layers: ModelLayer[]
  inputShape: number[]
  outputShape: number[]
  registeredAt: string
  registeredBy: string
  status: 'active' | 'deprecated' | 'pending'
  totalInferences: number
}

export interface BatchProof {
  id: string
  proofIds: string[]
  modelId: string
  modelName: string
  batchSize: number
  aggregateProofHash: string
  status: 'aggregating' | 'verified' | 'failed'
  totalCycles: number
  submittedAt: string
  verifiedAt?: string
}

export interface ProofVerification {
  proofHash: string
  isVerified: boolean
  verifierKey: string
  publicInputs: string[]
  cycleCount: number
}

export interface DashboardStats {
  totalModels: number
  totalInferences: number
  verifiedProofs: number
  pendingProofs: number
  avgCyclesPerProof: number
  totalBatchesProcessed: number
}
