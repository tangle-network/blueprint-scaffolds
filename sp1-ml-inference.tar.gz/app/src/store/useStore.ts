import { create } from 'zustand'
import type { MLModel, InferenceRequest, ProofBatch } from '@/types'

interface AppState {
  models: MLModel[]
  inferences: InferenceRequest[]
  proofBatches: ProofBatch[]
  addModel: (model: MLModel) => void
  submitInference: (inference: InferenceRequest) => void
  verifyProof: (proofId: string) => void
}

export const useStore = create<AppState>((set) => ({
  models: [
    {
      id: 'model-001',
      name: 'ETH Price Predictor MLP',
      architecture: 'MLP',
      inputShape: [16],
      layers: [
        { type: 'dense', inputDim: 16, outputDim: 64, activation: 'relu' },
        { type: 'dense', inputDim: 64, outputDim: 32, activation: 'relu' },
        { type: 'dense', inputDim: 32, outputDim: 1, activation: 'linear' },
      ],
      commitHash: '0x7a3f2e1b9c4d5a6f8e0d1c2b3a4f5e6d7c8b9a0f1e2d3c4b5a6f7e8d9c0b1a2',
      verifierKey: 'vk_sp1_eth_pred_mlp_v1',
      owner: '0x1234567890abcdef1234567890abcdef12345678',
      registeredAt: '2025-12-15T10:30:00Z',
      status: 'active',
    },
    {
      id: 'model-002',
      name: 'Content Moderation CNN',
      architecture: 'CNN',
      inputShape: [28, 28, 1],
      layers: [
        { type: 'conv2d', kernelSize: 3, stride: 1, activation: 'relu' },
        { type: 'maxpool', kernelSize: 2, stride: 2 },
        { type: 'flatten' },
        { type: 'dense', inputDim: 256, outputDim: 128, activation: 'relu' },
        { type: 'dense', inputDim: 128, outputDim: 4, activation: 'softmax' },
      ],
      commitHash: '0x8b4c3f2a1d5e6f7a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f',
      verifierKey: 'vk_sp1_content_mod_cnn_v2',
      owner: '0x567890abcdef1234567890abcdef1234567890ab',
      registeredAt: '2025-11-20T14:00:00Z',
      status: 'active',
    },
    {
      id: 'model-003',
      name: 'Credit Scoring MLP',
      architecture: 'MLP',
      inputShape: [32],
      layers: [
        { type: 'dense', inputDim: 32, outputDim: 128, activation: 'relu' },
        { type: 'dense', inputDim: 128, outputDim: 64, activation: 'relu' },
        { type: 'dense', inputDim: 64, outputDim: 16, activation: 'relu' },
        { type: 'dense', inputDim: 16, outputDim: 2, activation: 'softmax' },
      ],
      commitHash: '0x1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2',
      verifierKey: 'vk_sp1_credit_score_mlp_v3',
      owner: '0x9abcdef1234567890abcdef1234567890abcdef1',
      registeredAt: '2026-01-05T09:15:00Z',
      status: 'active',
    },
  ],

  inferences: [
    {
      id: 'inf-001',
      modelId: 'model-001',
      inputData: [0.85, 0.42, 0.91, 0.33, 0.67, 0.78, 0.55, 0.12, 0.99, 0.44, 0.61, 0.28, 0.73, 0.86, 0.15, 0.52],
      prediction: '$3,847.21',
      confidence: 0.92,
      proofId: '0xproof001aabbccdd',
      status: 'verified',
      timestamp: '2026-03-28T12:00:00Z',
    },
    {
      id: 'inf-002',
      modelId: 'model-002',
      inputData: [0.12, 0.88, 0.45, 0.67],
      prediction: 'Safe Content',
      confidence: 0.88,
      proofId: '0xproof002eeff0011',
      status: 'verified',
      timestamp: '2026-03-28T11:30:00Z',
    },
    {
      id: 'inf-003',
      modelId: 'model-001',
      inputData: [0.22, 0.15, 0.38, 0.71, 0.44, 0.29, 0.18, 0.63, 0.51, 0.82, 0.37, 0.94, 0.11, 0.48, 0.66, 0.73],
      prediction: '$3,612.45',
      confidence: 0.66,
      proofId: '',
      status: 'generating',
      timestamp: '2026-03-28T13:00:00Z',
    },
    {
      id: 'inf-004',
      modelId: 'model-003',
      inputData: [0.55, 0.72, 0.38, 0.91, 0.47, 0.63],
      prediction: 'Credit Score: 742',
      confidence: 0.85,
      proofId: '0xproof00422334455',
      status: 'verified',
      timestamp: '2026-03-27T09:45:00Z',
    },
    {
      id: 'inf-005',
      modelId: 'model-002',
      inputData: [0.91, 0.33, 0.67, 0.48],
      prediction: 'Flagged: Violence',
      confidence: 0.72,
      proofId: '',
      status: 'pending',
      timestamp: '2026-03-28T13:15:00Z',
    },
  ],

  proofBatches: [
    {
      id: 'batch-001',
      proofIds: ['0xproof001aabbccdd', '0xproof002eeff0011', '0xproof00422334455'],
      modelId: 'multi',
      status: 'verified',
      sp1Version: 'v3.0.0',
      gasUsed: 284756,
      verifiedAt: '2026-03-28T12:32:00Z',
    },
    {
      id: 'batch-002',
      proofIds: [],
      modelId: 'multi',
      status: 'aggregating',
      sp1Version: 'v3.0.0',
      gasUsed: 0,
    },
  ],

  addModel: (model) => set((state) => ({ models: [...state.models, model] })),

  submitInference: (inference) => set((state) => ({ inferences: [...state.inferences, inference] })),

  verifyProof: (proofId) =>
    set((state) => ({
      inferences: state.inferences.map((inf) =>
        inf.proofId === proofId ? { ...inf, status: 'verified' as const } : inf
      ),
    })),
}))
