import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom'
import {
  LayoutDashboard,
  Brain,
  Play,
  FileCheck,
  ShieldCheck,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useStore } from '@/store/useStore'

const navItems = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/models', label: 'Models', icon: Brain },
  { to: '/inference', label: 'Inference', icon: Play },
  { to: '/proofs', label: 'Proofs', icon: FileCheck },
  { to: '/verify', label: 'Verify', icon: ShieldCheck },
]

function Sidebar() {
  return (
    <aside className="flex h-screen w-60 flex-col border-r border-zinc-800 bg-zinc-950">
      <div className="flex items-center gap-2 border-b border-zinc-800 px-4 py-4">
        <ShieldCheck className="h-6 w-6 text-brand-purple-500" />
        <span className="text-lg font-bold text-white">SP1 ML Verifier</span>
      </div>
      <nav className="flex flex-col gap-1 p-2">
        {navItems.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            end={to === '/'}
            className={({ isActive }) =>
              cn(
                'flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors',
                isActive
                  ? 'bg-brand-purple-900/40 text-brand-purple-300'
                  : 'text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200'
              )
            }
          >
            <Icon className="h-4 w-4" />
            {label}
          </NavLink>
        ))}
      </nav>
    </aside>
  )
}

function DashboardPage() {
  const { models, inferences, proofBatches } = useStore()
  const verifiedCount = inferences.filter((i) => i.status === 'verified').length
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Dashboard</h1>
      <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
        {[
          { label: 'Models', value: models.length, color: 'text-brand-purple-400' },
          { label: 'Inferences', value: inferences.length, color: 'text-brand-blue-400' },
          { label: 'Verified Proofs', value: verifiedCount, color: 'text-brand-green-400' },
          { label: 'Batches', value: proofBatches.length, color: 'text-brand-purple-300' },
        ].map((stat) => (
          <div key={stat.label} className="rounded-xl border border-zinc-800 bg-zinc-900 p-6">
            <p className="text-sm text-zinc-400">{stat.label}</p>
            <p className={cn('mt-1 text-3xl font-bold', stat.color)}>{stat.value}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

function ModelsPage() {
  const { models } = useStore()
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Registered Models</h1>
      <div className="grid gap-4">
        {models.map((m) => (
          <div key={m.id} className="rounded-xl border border-zinc-800 bg-zinc-900 p-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold text-white">{m.name}</h2>
                <p className="text-sm text-zinc-400">
                  {m.architecture} &middot; {m.layers.length} layers &middot; {m.status}
                </p>
              </div>
              <span className="rounded-full bg-brand-purple-900/40 px-3 py-1 text-xs font-medium text-brand-purple-300">
                {m.architecture}
              </span>
            </div>
            <p className="mt-2 font-mono text-xs text-zinc-500">commit: {m.commitHash.slice(0, 20)}...</p>
          </div>
        ))}
      </div>
    </div>
  )
}

function InferencePage() {
  const { inferences } = useStore()
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Inference Requests</h1>
      <div className="rounded-xl border border-zinc-800 bg-zinc-900">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-zinc-800 text-left text-zinc-400">
              <th className="p-4">ID</th>
              <th className="p-4">Model</th>
              <th className="p-4">Prediction</th>
              <th className="p-4">Confidence</th>
              <th className="p-4">Status</th>
            </tr>
          </thead>
          <tbody>
            {inferences.map((inf) => (
              <tr key={inf.id} className="border-b border-zinc-800/50">
                <td className="p-4 font-mono text-xs text-zinc-300">{inf.id}</td>
                <td className="p-4 text-zinc-300">{inf.modelId}</td>
                <td className="p-4 font-medium text-white">{inf.prediction}</td>
                <td className="p-4 text-zinc-300">{(inf.confidence * 100).toFixed(0)}%</td>
                <td className="p-4">
                  <span
                    className={cn(
                      'rounded-full px-2 py-0.5 text-xs font-medium',
                      inf.status === 'verified' && 'bg-brand-green-900/40 text-brand-green-400',
                      inf.status === 'generating' && 'bg-brand-blue-900/40 text-brand-blue-400',
                      inf.status === 'pending' && 'bg-zinc-800 text-zinc-400',
                      inf.status === 'failed' && 'bg-red-900/40 text-red-400'
                    )}
                  >
                    {inf.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function ProofsPage() {
  const { proofBatches } = useStore()
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Proof Batches</h1>
      {proofBatches.map((batch) => (
        <div key={batch.id} className="rounded-xl border border-zinc-800 bg-zinc-900 p-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold text-white">Batch {batch.id}</h2>
              <p className="text-sm text-zinc-400">
                {batch.proofIds.length} proofs &middot; SP1 {batch.sp1Version} &middot; Gas: {batch.gasUsed.toLocaleString()}
              </p>
            </div>
            <span
              className={cn(
                'rounded-full px-3 py-1 text-xs font-medium',
                batch.status === 'verified' && 'bg-brand-green-900/40 text-brand-green-400',
                batch.status === 'aggregating' && 'bg-brand-blue-900/40 text-brand-blue-400',
                batch.status === 'failed' && 'bg-red-900/40 text-red-400'
              )}
            >
              {batch.status}
            </span>
          </div>
        </div>
      ))}
    </div>
  )
}

function VerifyPage() {
  const { inferences, verifyProof } = useStore()
  const pendingInferences = inferences.filter((i) => i.status !== 'verified')
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Verify Proofs</h1>
      {pendingInferences.length === 0 ? (
        <p className="text-zinc-400">All inferences are verified.</p>
      ) : (
        <div className="space-y-3">
          {pendingInferences.map((inf) => (
            <div key={inf.id} className="flex items-center justify-between rounded-xl border border-zinc-800 bg-zinc-900 p-4">
              <div>
                <p className="font-medium text-white">{inf.prediction}</p>
                <p className="text-sm text-zinc-400">{inf.id} &middot; {inf.status}</p>
              </div>
              <button
                onClick={() => verifyProof(inf.proofId)}
                className="rounded-md bg-brand-purple-600 px-4 py-2 text-sm font-medium text-white hover:bg-brand-purple-700"
              >
                Verify
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function AppLayout() {
  return (
    <div className="flex h-screen bg-zinc-950 text-zinc-100">
      <Sidebar />
      <main className="flex-1 overflow-auto p-8">
        <Routes>
          <Route path="/" element={<DashboardPage />} />
          <Route path="/models" element={<ModelsPage />} />
          <Route path="/inference" element={<InferencePage />} />
          <Route path="/proofs" element={<ProofsPage />} />
          <Route path="/verify" element={<VerifyPage />} />
        </Routes>
      </main>
    </div>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <AppLayout />
    </BrowserRouter>
  )
}
