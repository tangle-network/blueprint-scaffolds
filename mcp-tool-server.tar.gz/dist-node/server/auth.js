const DEFAULT_TOKEN = 'dev-token';
export class Authenticator {
    validTokens;
    constructor(options = {}) {
        this.validTokens = options.validTokens ?? {
            [DEFAULT_TOKEN]: ['admin', 'developer'],
            'readonly-token': ['viewer'],
        };
    }
    authenticate(token, clientId, transport) {
        if (!token) {
            return {
                clientId,
                roles: [],
                authenticated: false,
                transport,
            };
        }
        const roles = this.validTokens[token];
        if (!roles) {
            return {
                clientId,
                token,
                roles: [],
                authenticated: false,
                transport,
            };
        }
        return {
            clientId,
            token,
            roles,
            authenticated: true,
            transport,
        };
    }
}
