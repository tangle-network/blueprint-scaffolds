import { Authenticator } from './auth.js';
import { RateLimiter } from './rateLimiter.js';
import type { JsonRpcResponse, ServerMetrics } from './types.js';
export interface McpServerOptions {
    auth?: Authenticator;
    rateLimiter?: RateLimiter;
}
export declare class McpServer {
    private readonly auth;
    private readonly rateLimiter;
    private readonly tools;
    private readonly metrics;
    constructor(options?: McpServerOptions);
    connectionOpened(): void;
    connectionClosed(): void;
    snapshotMetrics(): ServerMetrics;
    authenticate(token: string | undefined, clientId: string, transport: 'stdio' | 'websocket'): import("./types.js").AuthContext;
    handleMessage(rawMessage: string, authInput: {
        token?: string;
        clientId: string;
        transport: 'stdio' | 'websocket';
    }): Promise<JsonRpcResponse | null>;
    private dispatch;
    private handleToolCall;
    private errorResponse;
}
