import type { JsonRpcError, JsonValue } from './types.js';
export declare class RpcError extends Error {
    readonly code: number;
    readonly data?: JsonValue;
    constructor(code: number, message: string, data?: JsonValue);
    toJson(): JsonRpcError;
}
export declare const rpcErrors: {
    parseError: (data?: JsonValue) => RpcError;
    invalidRequest: (data?: JsonValue) => RpcError;
    methodNotFound: (method: string) => RpcError;
    invalidParams: (data?: JsonValue) => RpcError;
    internalError: (data?: JsonValue) => RpcError;
    unauthorized: () => RpcError;
    forbidden: () => RpcError;
    rateLimited: (resetAt: number) => RpcError;
    toolFailure: (tool: string, reason: string) => RpcError;
};
