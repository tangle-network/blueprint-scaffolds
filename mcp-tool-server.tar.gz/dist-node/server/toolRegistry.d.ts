import type { JsonObject, JsonValue, RequestContext, ToolDefinition } from './types.js';
export declare class ToolRegistry {
    private readonly tools;
    register(tool: ToolDefinition): void;
    list(): JsonObject[];
    execute(name: string, input: unknown, context: RequestContext): Promise<JsonValue>;
}
