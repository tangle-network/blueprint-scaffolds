import { McpServer } from './mcpServer.js';
import { startStdioTransport } from './transports/stdio.js';
import { startWebSocketTransport } from './transports/websocket.js';
const server = new McpServer();
const transport = process.env.MCP_TRANSPORT ?? 'websocket';
if (transport === 'stdio') {
    startStdioTransport(server);
}
else {
    const port = Number(process.env.PORT ?? 8787);
    startWebSocketTransport(server, port);
    process.stdout.write(`MCP WebSocket server listening on ws://localhost:${port}/mcp\n`);
}
