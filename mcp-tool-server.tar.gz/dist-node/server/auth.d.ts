import type { AuthContext } from './types.js';
export interface AuthOptions {
    validTokens?: Record<string, string[]>;
}
export declare class Authenticator {
    private readonly validTokens;
    constructor(options?: AuthOptions);
    authenticate(token: string | undefined, clientId: string, transport: AuthContext['transport']): AuthContext;
}
