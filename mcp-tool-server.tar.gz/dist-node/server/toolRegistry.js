import { z } from 'zod';
import { RpcError, rpcErrors } from './errors.js';
const toolDescriptionSchema = z.object({
    name: z.string(),
    category: z.enum(['file', 'database', 'api', 'code']),
    description: z.string(),
    inputSchema: z.unknown(),
    outputSchema: z.unknown(),
});
export class ToolRegistry {
    tools = new Map();
    register(tool) {
        if (this.tools.has(tool.name)) {
            throw new RpcError(5002, `Duplicate tool registration: ${tool.name}`);
        }
        this.tools.set(tool.name, tool);
    }
    list() {
        return Array.from(this.tools.values()).map((tool) => toolDescriptionSchema.parse({
            name: tool.name,
            category: tool.category,
            description: tool.description,
            inputSchema: zodShape(tool.inputSchema),
            outputSchema: zodShape(tool.outputSchema),
        }));
    }
    async execute(name, input, context) {
        const tool = this.tools.get(name);
        if (!tool) {
            throw rpcErrors.methodNotFound(`tools/${name}`);
        }
        const parsedInput = tool.inputSchema.safeParse(input);
        if (!parsedInput.success) {
            throw rpcErrors.invalidParams(parsedInput.error.flatten());
        }
        try {
            const output = await tool.execute(parsedInput.data, context);
            const parsedOutput = tool.outputSchema.safeParse(output);
            if (!parsedOutput.success) {
                throw rpcErrors.internalError(parsedOutput.error.flatten());
            }
            return parsedOutput.data;
        }
        catch (error) {
            if (error instanceof RpcError) {
                throw error;
            }
            const message = error instanceof Error ? error.message : 'Unknown error';
            throw rpcErrors.toolFailure(name, message);
        }
    }
}
function zodShape(schema) {
    const def = schema._def;
    if (def.typeName === 'ZodObject' && def.shape) {
        return Object.fromEntries(Object.entries(def.shape()).map(([key, value]) => [key, zodShape(value)]));
    }
    if (def.typeName === 'ZodArray') {
        return { type: 'array' };
    }
    return { type: def.typeName ?? 'unknown' };
}
