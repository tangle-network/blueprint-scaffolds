import http from 'node:http';
import express from 'express';
import { WebSocketServer } from 'ws';
export function startWebSocketTransport(serverCore, port = 8787) {
    const app = express();
    app.get('/health', (_request, response) => {
        response.json({
            ok: true,
            metrics: serverCore.snapshotMetrics(),
        });
    });
    const server = http.createServer(app);
    const wss = new WebSocketServer({ server, path: '/mcp' });
    wss.on('connection', (socket, request) => {
        const clientId = request.headers['x-client-id']?.toString() ?? `ws-${Math.random().toString(16).slice(2)}`;
        const tokenHeader = request.headers.authorization;
        const token = tokenHeader?.startsWith('Bearer ') ? tokenHeader.slice(7) : undefined;
        serverCore.connectionOpened();
        socket.on('message', async (payload) => {
            const response = await serverCore.handleMessage(payload.toString(), {
                token,
                clientId,
                transport: 'websocket',
            });
            if (response) {
                socket.send(JSON.stringify(response));
            }
        });
        socket.on('close', () => {
            serverCore.connectionClosed();
        });
    });
    server.listen(port);
    return { app, server };
}
