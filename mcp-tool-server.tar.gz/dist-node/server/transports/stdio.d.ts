import type { McpServer } from '../mcpServer.js';
export declare function startStdioTransport(server: McpServer, token?: string | undefined): void;
