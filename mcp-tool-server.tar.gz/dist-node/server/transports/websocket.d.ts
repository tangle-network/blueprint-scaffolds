import http from 'node:http';
import express from 'express';
import type { McpServer } from '../mcpServer.js';
export interface WebSocketTransportHandle {
    app: express.Express;
    server: http.Server;
}
export declare function startWebSocketTransport(serverCore: McpServer, port?: number): WebSocketTransportHandle;
