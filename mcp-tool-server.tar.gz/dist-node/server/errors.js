export class RpcError extends Error {
    code;
    data;
    constructor(code, message, data) {
        super(message);
        this.code = code;
        this.data = data;
    }
    toJson() {
        return {
            code: this.code,
            message: this.message,
            data: this.data,
        };
    }
}
export const rpcErrors = {
    parseError: (data) => new RpcError(-32700, 'Parse error', data),
    invalidRequest: (data) => new RpcError(-32600, 'Invalid request', data),
    methodNotFound: (method) => new RpcError(-32601, `Method not found: ${method}`),
    invalidParams: (data) => new RpcError(-32602, 'Invalid params', data),
    internalError: (data) => new RpcError(-32603, 'Internal error', data),
    unauthorized: () => new RpcError(401, 'Unauthorized'),
    forbidden: () => new RpcError(403, 'Forbidden'),
    rateLimited: (resetAt) => new RpcError(429, 'Rate limit exceeded', { resetAt: new Date(resetAt).toISOString() }),
    toolFailure: (tool, reason) => new RpcError(5001, `Tool execution failed: ${tool}`, { reason }),
};
