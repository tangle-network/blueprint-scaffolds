import type { RateLimitState } from './types.js';
export interface RateLimiterOptions {
    limit: number;
    windowMs: number;
}
export declare class RateLimiter {
    private readonly buckets;
    private readonly limit;
    private readonly windowMs;
    constructor(options: RateLimiterOptions);
    consume(key: string): RateLimitState;
}
