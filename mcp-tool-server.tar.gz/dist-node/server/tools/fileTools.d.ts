import { z } from 'zod';
import type { RequestContext } from '../types.js';
declare const readInput: z.ZodObject<{
    path: z.ZodString;
    encoding: z.ZodDefault<z.ZodEnum<["utf8"]>>;
}, "strip", z.ZodTypeAny, {
    path: string;
    encoding: "utf8";
}, {
    path: string;
    encoding?: "utf8" | undefined;
}>;
declare const writeInput: z.ZodObject<{
    path: z.ZodString;
    content: z.ZodString;
}, "strip", z.ZodTypeAny, {
    path: string;
    content: string;
}, {
    path: string;
    content: string;
}>;
export declare const fileReadTool: {
    name: string;
    category: "file";
    description: string;
    inputSchema: z.ZodObject<{
        path: z.ZodString;
        encoding: z.ZodDefault<z.ZodEnum<["utf8"]>>;
    }, "strip", z.ZodTypeAny, {
        path: string;
        encoding: "utf8";
    }, {
        path: string;
        encoding?: "utf8" | undefined;
    }>;
    outputSchema: z.ZodObject<{
        path: z.ZodString;
        content: z.ZodString;
        bytes: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        path: string;
        content: string;
        bytes: number;
    }, {
        path: string;
        content: string;
        bytes: number;
    }>;
    execute(input: z.infer<typeof readInput>): Promise<{
        path: string;
        content: string;
        bytes: number;
    }>;
};
export declare const fileWriteTool: {
    name: string;
    category: "file";
    description: string;
    inputSchema: z.ZodObject<{
        path: z.ZodString;
        content: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        path: string;
        content: string;
    }, {
        path: string;
        content: string;
    }>;
    outputSchema: z.ZodObject<{
        path: z.ZodString;
        written: z.ZodBoolean;
        bytes: z.ZodNumber;
        requestedBy: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        path: string;
        bytes: number;
        written: boolean;
        requestedBy: string;
    }, {
        path: string;
        bytes: number;
        written: boolean;
        requestedBy: string;
    }>;
    execute(input: z.infer<typeof writeInput>, context: RequestContext): Promise<{
        path: string;
        written: boolean;
        bytes: number;
        requestedBy: string;
    }>;
};
export {};
