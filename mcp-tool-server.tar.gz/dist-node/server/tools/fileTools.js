import { promises as fs } from 'node:fs';
import path from 'node:path';
import { z } from 'zod';
const workspaceRoot = path.resolve(process.cwd());
const readInput = z.object({
    path: z.string().min(1),
    encoding: z.enum(['utf8']).default('utf8'),
});
const readOutput = z.object({
    path: z.string(),
    content: z.string(),
    bytes: z.number().int().nonnegative(),
});
const writeInput = z.object({
    path: z.string().min(1),
    content: z.string(),
});
const writeOutput = z.object({
    path: z.string(),
    written: z.boolean(),
    bytes: z.number().int().nonnegative(),
    requestedBy: z.string(),
});
function resolveSafePath(candidate) {
    const resolved = path.resolve(workspaceRoot, candidate);
    if (!resolved.startsWith(workspaceRoot)) {
        throw new Error('Path escapes workspace');
    }
    return resolved;
}
export const fileReadTool = {
    name: 'file.read',
    category: 'file',
    description: 'Read a UTF-8 text file inside the workspace.',
    inputSchema: readInput,
    outputSchema: readOutput,
    async execute(input) {
        const filePath = resolveSafePath(input.path);
        const content = await fs.readFile(filePath, input.encoding);
        return {
            path: path.relative(workspaceRoot, filePath),
            content,
            bytes: Buffer.byteLength(content, 'utf8'),
        };
    },
};
export const fileWriteTool = {
    name: 'file.write',
    category: 'file',
    description: 'Write a UTF-8 text file inside the workspace.',
    inputSchema: writeInput,
    outputSchema: writeOutput,
    async execute(input, context) {
        const filePath = resolveSafePath(input.path);
        await fs.mkdir(path.dirname(filePath), { recursive: true });
        await fs.writeFile(filePath, input.content, 'utf8');
        return {
            path: path.relative(workspaceRoot, filePath),
            written: true,
            bytes: Buffer.byteLength(input.content, 'utf8'),
            requestedBy: context.clientId,
        };
    },
};
