import { z } from 'zod';
const tables = {
    services: [
        { id: 1, name: 'filesystem', status: 'healthy', requests: 1240 },
        { id: 2, name: 'database', status: 'degraded', requests: 218 },
        { id: 3, name: 'integrations', status: 'healthy', requests: 412 },
    ],
    audits: [
        { id: 100, action: 'tool.call', actor: 'cli-agent', severity: 'info' },
        { id: 101, action: 'auth.failed', actor: 'unknown', severity: 'warn' },
    ],
};
const queryInput = z.object({
    table: z.enum(['services', 'audits']),
    filter: z.record(z.union([z.string(), z.number()])).optional(),
    limit: z.number().int().positive().max(100).default(25),
});
const queryOutput = z.object({
    table: z.string(),
    rows: z.array(z.record(z.union([z.string(), z.number()]))),
    count: z.number().int().nonnegative(),
});
export const databaseQueryTool = {
    name: 'db.query',
    category: 'database',
    description: 'Query an in-memory operational dataset using structured filters.',
    inputSchema: queryInput,
    outputSchema: queryOutput,
    async execute(input) {
        const dataset = tables[input.table];
        const rows = dataset
            .filter((row) => Object.entries(input.filter ?? {}).every(([key, value]) => row[key] === value))
            .slice(0, input.limit);
        return {
            table: input.table,
            rows,
            count: rows.length,
        };
    },
};
