import { z } from 'zod';
declare const apiInput: z.ZodObject<{
    url: z.ZodString;
    method: z.ZodDefault<z.ZodEnum<["GET", "POST"]>>;
    headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
}, "strip", z.ZodTypeAny, {
    url: string;
    method: "GET" | "POST";
    headers?: Record<string, string> | undefined;
}, {
    url: string;
    method?: "GET" | "POST" | undefined;
    headers?: Record<string, string> | undefined;
}>;
export declare const apiFetchTool: {
    name: string;
    category: "api";
    description: string;
    inputSchema: z.ZodObject<{
        url: z.ZodString;
        method: z.ZodDefault<z.ZodEnum<["GET", "POST"]>>;
        headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        method: "GET" | "POST";
        headers?: Record<string, string> | undefined;
    }, {
        url: string;
        method?: "GET" | "POST" | undefined;
        headers?: Record<string, string> | undefined;
    }>;
    outputSchema: z.ZodObject<{
        ok: z.ZodBoolean;
        status: z.ZodNumber;
        statusText: z.ZodString;
        contentType: z.ZodString;
        snippet: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        status: number;
        ok: boolean;
        statusText: string;
        contentType: string;
        snippet: string;
    }, {
        status: number;
        ok: boolean;
        statusText: string;
        contentType: string;
        snippet: string;
    }>;
    execute(input: z.infer<typeof apiInput>): Promise<{
        ok: boolean;
        status: number;
        statusText: string;
        contentType: string;
        snippet: string;
    }>;
};
export {};
