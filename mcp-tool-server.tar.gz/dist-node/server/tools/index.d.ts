import type { ToolDefinition } from '../types.js';
export declare const defaultTools: ToolDefinition[];
