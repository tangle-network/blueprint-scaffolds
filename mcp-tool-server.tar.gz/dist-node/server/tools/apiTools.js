import { z } from 'zod';
const apiInput = z.object({
    url: z.string().url(),
    method: z.enum(['GET', 'POST']).default('GET'),
    headers: z.record(z.string()).optional(),
});
const apiOutput = z.object({
    ok: z.boolean(),
    status: z.number().int(),
    statusText: z.string(),
    contentType: z.string(),
    snippet: z.string(),
});
export const apiFetchTool = {
    name: 'api.fetchStatus',
    category: 'api',
    description: 'Perform a bounded HTTP request to inspect an integration endpoint.',
    inputSchema: apiInput,
    outputSchema: apiOutput,
    async execute(input) {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 4000);
        try {
            const response = await fetch(input.url, {
                method: input.method,
                headers: input.headers,
                signal: controller.signal,
            });
            const contentType = response.headers.get('content-type') ?? 'unknown';
            const body = await response.text();
            return {
                ok: response.ok,
                status: response.status,
                statusText: response.statusText,
                contentType,
                snippet: body.slice(0, 280),
            };
        }
        finally {
            clearTimeout(timeout);
        }
    },
};
