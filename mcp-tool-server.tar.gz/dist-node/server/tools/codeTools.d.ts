import { z } from 'zod';
declare const analysisInput: z.ZodObject<{
    path: z.ZodDefault<z.ZodString>;
    extensions: z.ZodDefault<z.ZodArray<z.ZodEnum<[".ts", ".tsx", ".js", ".jsx"]>, "many">>;
}, "strip", z.ZodTypeAny, {
    path: string;
    extensions: (".ts" | ".tsx" | ".js" | ".jsx")[];
}, {
    path?: string | undefined;
    extensions?: (".ts" | ".tsx" | ".js" | ".jsx")[] | undefined;
}>;
export declare const codeAnalysisTool: {
    name: string;
    category: "code";
    description: string;
    inputSchema: z.ZodObject<{
        path: z.ZodDefault<z.ZodString>;
        extensions: z.ZodDefault<z.ZodArray<z.ZodEnum<[".ts", ".tsx", ".js", ".jsx"]>, "many">>;
    }, "strip", z.ZodTypeAny, {
        path: string;
        extensions: (".ts" | ".tsx" | ".js" | ".jsx")[];
    }, {
        path?: string | undefined;
        extensions?: (".ts" | ".tsx" | ".js" | ".jsx")[] | undefined;
    }>;
    outputSchema: z.ZodObject<{
        root: z.ZodString;
        files: z.ZodNumber;
        lines: z.ZodNumber;
        todos: z.ZodNumber;
        exportedSymbols: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        root: string;
        files: number;
        lines: number;
        todos: number;
        exportedSymbols: number;
    }, {
        root: string;
        files: number;
        lines: number;
        todos: number;
        exportedSymbols: number;
    }>;
    execute(input: z.infer<typeof analysisInput>): Promise<{
        root: string;
        files: number;
        lines: number;
        todos: number;
        exportedSymbols: number;
    }>;
};
export {};
