import { promises as fs } from 'node:fs';
import path from 'node:path';
import { z } from 'zod';
const analysisInput = z.object({
    path: z.string().default('src'),
    extensions: z.array(z.enum(['.ts', '.tsx', '.js', '.jsx'])).default(['.ts', '.tsx']),
});
const analysisOutput = z.object({
    root: z.string(),
    files: z.number().int().nonnegative(),
    lines: z.number().int().nonnegative(),
    todos: z.number().int().nonnegative(),
    exportedSymbols: z.number().int().nonnegative(),
});
export const codeAnalysisTool = {
    name: 'code.analyze',
    category: 'code',
    description: 'Analyze source files for volume, TODOs, and exported symbol count.',
    inputSchema: analysisInput,
    outputSchema: analysisOutput,
    async execute(input) {
        const root = path.resolve(process.cwd(), input.path);
        const files = await collectFiles(root, new Set(input.extensions));
        let lines = 0;
        let todos = 0;
        let exportedSymbols = 0;
        for (const file of files) {
            const content = await fs.readFile(file, 'utf8');
            const split = content.split('\n');
            lines += split.length;
            todos += split.filter((line) => line.includes('TODO')).length;
            exportedSymbols += split.filter((line) => line.trim().startsWith('export ')).length;
        }
        return {
            root: input.path,
            files: files.length,
            lines,
            todos,
            exportedSymbols,
        };
    },
};
async function collectFiles(root, extensions) {
    const entries = await fs.readdir(root, { withFileTypes: true });
    const results = [];
    for (const entry of entries) {
        const fullPath = path.join(root, entry.name);
        if (entry.isDirectory()) {
            results.push(...(await collectFiles(fullPath, extensions)));
            continue;
        }
        if (extensions.has(path.extname(entry.name))) {
            results.push(fullPath);
        }
    }
    return results;
}
