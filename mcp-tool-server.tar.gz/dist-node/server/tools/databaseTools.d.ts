import { z } from 'zod';
declare const queryInput: z.ZodObject<{
    table: z.ZodEnum<["services", "audits"]>;
    filter: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<[z.ZodString, z.ZodNumber]>>>;
    limit: z.ZodDefault<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    table: "services" | "audits";
    limit: number;
    filter?: Record<string, string | number> | undefined;
}, {
    table: "services" | "audits";
    filter?: Record<string, string | number> | undefined;
    limit?: number | undefined;
}>;
export declare const databaseQueryTool: {
    name: string;
    category: "database";
    description: string;
    inputSchema: z.ZodObject<{
        table: z.ZodEnum<["services", "audits"]>;
        filter: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<[z.ZodString, z.ZodNumber]>>>;
        limit: z.ZodDefault<z.ZodNumber>;
    }, "strip", z.ZodTypeAny, {
        table: "services" | "audits";
        limit: number;
        filter?: Record<string, string | number> | undefined;
    }, {
        table: "services" | "audits";
        filter?: Record<string, string | number> | undefined;
        limit?: number | undefined;
    }>;
    outputSchema: z.ZodObject<{
        table: z.ZodString;
        rows: z.ZodArray<z.ZodRecord<z.ZodString, z.ZodUnion<[z.ZodString, z.ZodNumber]>>, "many">;
        count: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        table: string;
        rows: Record<string, string | number>[];
        count: number;
    }, {
        table: string;
        rows: Record<string, string | number>[];
        count: number;
    }>;
    execute(input: z.infer<typeof queryInput>): Promise<{
        table: "services" | "audits";
        rows: Record<string, string | number>[];
        count: number;
    }>;
};
export {};
