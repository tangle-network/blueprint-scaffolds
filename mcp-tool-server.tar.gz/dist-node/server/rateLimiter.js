export class RateLimiter {
    buckets = new Map();
    limit;
    windowMs;
    constructor(options) {
        this.limit = options.limit;
        this.windowMs = options.windowMs;
    }
    consume(key) {
        const now = Date.now();
        const windowStart = now - this.windowMs;
        const timestamps = (this.buckets.get(key) ?? []).filter((value) => value >= windowStart);
        if (timestamps.length >= this.limit) {
            const resetAt = timestamps[0] + this.windowMs;
            this.buckets.set(key, timestamps);
            return {
                key,
                remaining: 0,
                resetAt,
                limit: this.limit,
            };
        }
        timestamps.push(now);
        this.buckets.set(key, timestamps);
        return {
            key,
            remaining: this.limit - timestamps.length,
            resetAt: now + this.windowMs,
            limit: this.limit,
        };
    }
}
