import { z } from 'zod';
import { RpcError, rpcErrors } from './errors.js';
import type { JsonObject, JsonValue, RequestContext, ToolDefinition } from './types.js';

const toolDescriptionSchema = z.object({
  name: z.string(),
  category: z.enum(['file', 'database', 'api', 'code']),
  description: z.string(),
  inputSchema: z.unknown(),
  outputSchema: z.unknown(),
});

export class ToolRegistry {
  private readonly tools = new Map<string, ToolDefinition>();

  register(tool: ToolDefinition): void {
    if (this.tools.has(tool.name)) {
      throw new RpcError(5002, `Duplicate tool registration: ${tool.name}`);
    }
    this.tools.set(tool.name, tool);
  }

  list(): JsonObject[] {
    return Array.from(this.tools.values()).map((tool) =>
      toolDescriptionSchema.parse({
        name: tool.name,
        category: tool.category,
        description: tool.description,
        inputSchema: zodShape(tool.inputSchema),
        outputSchema: zodShape(tool.outputSchema),
      }) as JsonObject,
    );
  }

  async execute(name: string, input: unknown, context: RequestContext): Promise<JsonValue> {
    const tool = this.tools.get(name);
    if (!tool) {
      throw rpcErrors.methodNotFound(`tools/${name}`);
    }

    const parsedInput = tool.inputSchema.safeParse(input);
    if (!parsedInput.success) {
      throw rpcErrors.invalidParams(parsedInput.error.flatten() as unknown as JsonObject);
    }

    try {
      const output = await tool.execute(parsedInput.data, context);
      const parsedOutput = tool.outputSchema.safeParse(output);
      if (!parsedOutput.success) {
        throw rpcErrors.internalError(parsedOutput.error.flatten() as unknown as JsonObject);
      }
      return parsedOutput.data as JsonValue;
    } catch (error) {
      if (error instanceof RpcError) {
        throw error;
      }
      const message = error instanceof Error ? error.message : 'Unknown error';
      throw rpcErrors.toolFailure(name, message);
    }
  }
}

function zodShape(schema: z.ZodTypeAny): JsonObject {
  const def = schema._def as { typeName?: string; shape?: () => Record<string, z.ZodTypeAny> };
  if (def.typeName === 'ZodObject' && def.shape) {
    return Object.fromEntries(
      Object.entries(def.shape()).map(([key, value]) => [key, zodShape(value)]),
    );
  }

  if (def.typeName === 'ZodArray') {
    return { type: 'array' };
  }

  return { type: def.typeName ?? 'unknown' };
}
