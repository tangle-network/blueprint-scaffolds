import readline from 'node:readline';
import type { McpServer } from '../mcpServer.js';

export function startStdioTransport(server: McpServer, token = process.env.MCP_AUTH_TOKEN): void {
  server.connectionOpened();

  const rl = readline.createInterface({
    input: process.stdin,
    crlfDelay: Infinity,
  });

  rl.on('line', async (line) => {
    const response = await server.handleMessage(line, {
      token,
      clientId: 'stdio-client',
      transport: 'stdio',
    });

    if (response) {
      process.stdout.write(`${JSON.stringify(response)}\n`);
    }
  });

  rl.on('close', () => {
    server.connectionClosed();
  });
}
