import { z } from 'zod';

export const jsonValueSchema: z.ZodType<JsonValue> = z.lazy(() =>
  z.union([
    z.string(),
    z.number(),
    z.boolean(),
    z.null(),
    z.array(jsonValueSchema),
    z.record(jsonValueSchema),
  ]),
);

export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonValue[] | { [key: string]: JsonValue };
export type JsonObject = { [key: string]: JsonValue };

export interface JsonRpcRequest {
  jsonrpc: '2.0';
  id?: string | number | null;
  method: string;
  params?: JsonValue;
}

export interface JsonRpcError {
  code: number;
  message: string;
  data?: JsonValue;
}

export interface JsonRpcResponse {
  jsonrpc: '2.0';
  id: string | number | null;
  result?: JsonValue;
  error?: JsonRpcError;
}

export interface AuthContext {
  clientId: string;
  token?: string;
  roles: string[];
  authenticated: boolean;
  transport: 'stdio' | 'websocket';
}

export interface RequestContext extends AuthContext {
  requestId: string;
  receivedAt: string;
}

export interface ToolDefinition {
  name: string;
  category: 'file' | 'database' | 'api' | 'code';
  description: string;
  inputSchema: z.ZodTypeAny;
  outputSchema: z.ZodTypeAny;
  execute: (input: any, context: RequestContext) => Promise<unknown>;
}

export interface RateLimitState {
  key: string;
  remaining: number;
  resetAt: number;
  limit: number;
}

export interface ServerMetrics {
  totalRequests: number;
  successfulRequests: number;
  failedRequests: number;
  activeConnections: number;
  recentErrors: Array<{ at: string; message: string; clientId: string }>;
  toolUsage: Record<string, number>;
}
