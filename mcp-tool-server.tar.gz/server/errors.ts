import type { JsonRpcError, JsonValue } from './types.js';

export class RpcError extends Error {
  public readonly code: number;
  public readonly data?: JsonValue;

  constructor(code: number, message: string, data?: JsonValue) {
    super(message);
    this.code = code;
    this.data = data;
  }

  toJson(): JsonRpcError {
    return {
      code: this.code,
      message: this.message,
      data: this.data,
    };
  }
}

export const rpcErrors = {
  parseError: (data?: JsonValue) => new RpcError(-32700, 'Parse error', data),
  invalidRequest: (data?: JsonValue) => new RpcError(-32600, 'Invalid request', data),
  methodNotFound: (method: string) => new RpcError(-32601, `Method not found: ${method}`),
  invalidParams: (data?: JsonValue) => new RpcError(-32602, 'Invalid params', data),
  internalError: (data?: JsonValue) => new RpcError(-32603, 'Internal error', data),
  unauthorized: () => new RpcError(401, 'Unauthorized'),
  forbidden: () => new RpcError(403, 'Forbidden'),
  rateLimited: (resetAt: number) =>
    new RpcError(429, 'Rate limit exceeded', { resetAt: new Date(resetAt).toISOString() }),
  toolFailure: (tool: string, reason: string) =>
    new RpcError(5001, `Tool execution failed: ${tool}`, { reason }),
};
