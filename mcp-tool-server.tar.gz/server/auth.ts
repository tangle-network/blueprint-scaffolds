import type { AuthContext } from './types.js';

const DEFAULT_TOKEN = 'dev-token';

export interface AuthOptions {
  validTokens?: Record<string, string[]>;
}

export class Authenticator {
  private readonly validTokens: Record<string, string[]>;

  constructor(options: AuthOptions = {}) {
    this.validTokens = options.validTokens ?? {
      [DEFAULT_TOKEN]: ['admin', 'developer'],
      'readonly-token': ['viewer'],
    };
  }

  authenticate(token: string | undefined, clientId: string, transport: AuthContext['transport']): AuthContext {
    if (!token) {
      return {
        clientId,
        roles: [],
        authenticated: false,
        transport,
      };
    }

    const roles = this.validTokens[token];
    if (!roles) {
      return {
        clientId,
        token,
        roles: [],
        authenticated: false,
        transport,
      };
    }

    return {
      clientId,
      token,
      roles,
      authenticated: true,
      transport,
    };
  }
}
