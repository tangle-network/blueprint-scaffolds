import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { Authenticator } from './auth.js';
import { RpcError, rpcErrors } from './errors.js';
import { RateLimiter } from './rateLimiter.js';
import { ToolRegistry } from './toolRegistry.js';
import { defaultTools } from './tools/index.js';
import type {
  JsonRpcRequest,
  JsonRpcResponse,
  JsonValue,
  RequestContext,
  ServerMetrics,
} from './types.js';

const requestSchema = z.object({
  jsonrpc: z.literal('2.0'),
  id: z.union([z.string(), z.number(), z.null()]).optional(),
  method: z.string().min(1),
  params: z.unknown().optional(),
});

export interface McpServerOptions {
  auth?: Authenticator;
  rateLimiter?: RateLimiter;
}

export class McpServer {
  private readonly auth: Authenticator;
  private readonly rateLimiter: RateLimiter;
  private readonly tools = new ToolRegistry();
  private readonly metrics: ServerMetrics = {
    totalRequests: 0,
    successfulRequests: 0,
    failedRequests: 0,
    activeConnections: 0,
    recentErrors: [],
    toolUsage: {},
  };

  constructor(options: McpServerOptions = {}) {
    this.auth = options.auth ?? new Authenticator();
    this.rateLimiter = options.rateLimiter ?? new RateLimiter({ limit: 60, windowMs: 60_000 });
    defaultTools.forEach((tool) => this.tools.register(tool));
  }

  connectionOpened(): void {
    this.metrics.activeConnections += 1;
  }

  connectionClosed(): void {
    this.metrics.activeConnections = Math.max(0, this.metrics.activeConnections - 1);
  }

  snapshotMetrics(): ServerMetrics {
    return {
      ...this.metrics,
      recentErrors: [...this.metrics.recentErrors],
      toolUsage: { ...this.metrics.toolUsage },
    };
  }

  authenticate(token: string | undefined, clientId: string, transport: 'stdio' | 'websocket') {
    return this.auth.authenticate(token, clientId, transport);
  }

  async handleMessage(
    rawMessage: string,
    authInput: { token?: string; clientId: string; transport: 'stdio' | 'websocket' },
  ): Promise<JsonRpcResponse | null> {
    let parsedJson: unknown;

    try {
      parsedJson = JSON.parse(rawMessage);
    } catch {
      return this.errorResponse(null, rpcErrors.parseError());
    }

    const requestResult = requestSchema.safeParse(parsedJson);
    if (!requestResult.success) {
      return this.errorResponse(null, rpcErrors.invalidRequest(requestResult.error.flatten()));
    }

    const request = requestResult.data as JsonRpcRequest;
    const authContext = this.authenticate(authInput.token, authInput.clientId, authInput.transport);
    const rateLimitState = this.rateLimiter.consume(authContext.clientId);

    if (rateLimitState.remaining === 0) {
      return this.errorResponse(request.id ?? null, rpcErrors.rateLimited(rateLimitState.resetAt));
    }

    const context: RequestContext = {
      ...authContext,
      requestId: randomUUID(),
      receivedAt: new Date().toISOString(),
    };

    this.metrics.totalRequests += 1;

    try {
      const result = await this.dispatch(request, context);
      this.metrics.successfulRequests += 1;
      return {
        jsonrpc: '2.0',
        id: request.id ?? null,
        result,
      };
    } catch (error) {
      const rpcError = error instanceof RpcError ? error : rpcErrors.internalError();
      this.metrics.failedRequests += 1;
      this.metrics.recentErrors.unshift({
        at: new Date().toISOString(),
        message: rpcError.message,
        clientId: context.clientId,
      });
      this.metrics.recentErrors = this.metrics.recentErrors.slice(0, 10);
      return this.errorResponse(request.id ?? null, rpcError);
    }
  }

  private async dispatch(request: JsonRpcRequest, context: RequestContext): Promise<JsonValue> {
    switch (request.method) {
      case 'ping':
        return { pong: true, at: context.receivedAt };
      case 'auth.status':
        return {
          authenticated: context.authenticated,
          clientId: context.clientId,
          roles: context.roles,
          transport: context.transport,
        };
      case 'tools.list':
        this.metrics.toolUsage['tools.list'] = (this.metrics.toolUsage['tools.list'] ?? 0) + 1;
        return this.tools.list();
      case 'metrics.get':
        return this.snapshotMetrics() as unknown as JsonValue;
      case 'tools.call':
        return this.handleToolCall(request.params, context);
      default:
        throw rpcErrors.methodNotFound(request.method);
    }
  }

  private async handleToolCall(params: unknown, context: RequestContext): Promise<JsonValue> {
    if (!context.authenticated) {
      throw rpcErrors.unauthorized();
    }

    const callSchema = z.object({
      name: z.string().min(1),
      arguments: z.unknown().default({}),
    });
    const parsed = callSchema.safeParse(params);
    if (!parsed.success) {
      throw rpcErrors.invalidParams(parsed.error.flatten());
    }

    const { name, arguments: toolArguments } = parsed.data;
    this.metrics.toolUsage[name] = (this.metrics.toolUsage[name] ?? 0) + 1;
    return this.tools.execute(name, toolArguments, context);
  }

  private errorResponse(id: string | number | null, error: RpcError): JsonRpcResponse {
    return {
      jsonrpc: '2.0',
      id,
      error: error.toJson(),
    };
  }
}
