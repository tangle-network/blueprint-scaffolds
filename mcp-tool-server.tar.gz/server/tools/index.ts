import { apiFetchTool } from './apiTools.js';
import { codeAnalysisTool } from './codeTools.js';
import { databaseQueryTool } from './databaseTools.js';
import { fileReadTool, fileWriteTool } from './fileTools.js';
import type { ToolDefinition } from '../types.js';

export const defaultTools: ToolDefinition[] = [
  fileReadTool,
  fileWriteTool,
  databaseQueryTool,
  apiFetchTool,
  codeAnalysisTool,
];
