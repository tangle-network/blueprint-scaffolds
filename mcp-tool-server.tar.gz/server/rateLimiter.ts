import type { RateLimitState } from './types.js';

export interface RateLimiterOptions {
  limit: number;
  windowMs: number;
}

export class RateLimiter {
  private readonly buckets = new Map<string, number[]>();
  private readonly limit: number;
  private readonly windowMs: number;

  constructor(options: RateLimiterOptions) {
    this.limit = options.limit;
    this.windowMs = options.windowMs;
  }

  consume(key: string): RateLimitState {
    const now = Date.now();
    const windowStart = now - this.windowMs;
    const timestamps = (this.buckets.get(key) ?? []).filter((value) => value >= windowStart);

    if (timestamps.length >= this.limit) {
      const resetAt = timestamps[0] + this.windowMs;
      this.buckets.set(key, timestamps);
      return {
        key,
        remaining: 0,
        resetAt,
        limit: this.limit,
      };
    }

    timestamps.push(now);
    this.buckets.set(key, timestamps);
    return {
      key,
      remaining: this.limit - timestamps.length,
      resetAt: now + this.windowMs,
      limit: this.limit,
    };
  }
}
