import express from 'express';
import cors from 'cors';
import { ToolRegistry } from './registry.js';
import { createFileTools, createDatabaseTools, createApiTools, createCodeTools } from './tools/index.js';
import { startWebSocketServer } from './transport/index.js';
import { generateToken } from './auth.js';

const PORT = parseInt(process.env.PORT || '3000', 10);

const registry = new ToolRegistry();
registry.registerMany([
  ...createFileTools(),
  ...createDatabaseTools(),
  ...createApiTools(),
  ...createCodeTools(),
]);

const app = express();
app.use(cors());
app.use(express.json());

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', uptime: Date.now() - registry.getMetrics().uptime, tools: registry.list().length });
});

app.get('/api/tools', (_req, res) => {
  res.json({ tools: registry.list() });
});

app.get('/api/metrics', (_req, res) => {
  res.json(registry.getMetrics());
});

app.post('/api/token', (req, res) => {
  const scopes = (req.body?.scopes as string[]) || ['*'];
  const ttl = (req.body?.ttlMs as number) || 3600000;
  const token = generateToken(scopes, ttl);
  res.json({ token: token.token, expiresAt: new Date(token.expiresAt).toISOString(), scopes: token.scopes });
});

app.post('/api/execute', async (req, res) => {
  const clientId = req.ip || 'unknown';
  const authHeader = req.headers.authorization;
  const authToken = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : undefined;
  const request = {
    jsonrpc: '2.0' as const,
    id: Date.now(),
    method: 'tools/call',
    params: req.body,
  };
  const response = await registry.execute(request, clientId, authToken);
  if (response.error) {
    res.status(response.error.code === -32001 ? 401 : response.error.code === -32002 ? 429 : 400).json(response);
  } else {
    res.json(response);
  }
});

const server = app.listen(PORT, () => {
  console.log(`[HTTP] API server listening on http://localhost:${PORT}`);
});

startWebSocketServer(registry, PORT + 1);

process.on('SIGINT', () => {
  console.log('\nShutting down...');
  server.close();
  process.exit(0);
});
