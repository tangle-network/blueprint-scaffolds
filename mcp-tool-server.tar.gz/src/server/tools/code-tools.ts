import { z } from 'zod';
import type { ToolDefinition } from '../shared/types.js';

const AnalyzeInput = z.object({
  code: z.string().min(1),
  language: z.enum(['typescript', 'javascript', 'python', 'rust', 'go', 'java']),
  rules: z.array(z.string()).optional(),
});

const AnalyzeOutput = z.object({
  language: z.string(),
  issues: z.array(
    z.object({
      severity: z.enum(['error', 'warning', 'info']),
      message: z.string(),
      line: z.number(),
      column: z.number().optional(),
      rule: z.string().optional(),
    })
  ),
  metrics: z.object({
    lines: z.number(),
    characters: z.number(),
    complexity: z.number(),
    functions: z.number(),
  }),
  suggestions: z.array(z.string()),
});

const FormatInput = z.object({
  code: z.string().min(1),
  language: z.enum(['typescript', 'javascript', 'python', 'rust', 'go', 'java']),
  indentSize: z.number().default(2),
  maxWidth: z.number().default(100),
});

const FormatOutput = z.object({
  formatted: z.string(),
  changed: z.boolean(),
  diff: z.string().optional(),
});

const DependencyInput = z.object({
  packageJson: z.string(),
});

const DependencyOutput = z.object({
  dependencies: z.array(
    z.object({
      name: z.string(),
      version: z.string(),
      type: z.enum(['dependency', 'devDependency']),
    })
  ),
  total: z.number(),
  outdated: z.array(z.string()),
});

function analyzeCode(code: string, language: string) {
  const lines = code.split('\n');
  const issues: Array<{
    severity: 'error' | 'warning' | 'info';
    message: string;
    line: number;
    column?: number;
    rule?: string;
  }> = [];
  let complexity = 1;
  let functions = 0;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();

    if (trimmed.startsWith('//') || trimmed.startsWith('#') || trimmed.startsWith('/*') || trimmed.startsWith('*')) continue;

    if (/function\s+\w+|const\s+\w+\s*=\s*(\(|async)/.test(line)) functions++;
    if (/\bif\b|\bswitch\b|\bcase\b/.test(line)) complexity++;
    if (/\bfor\b|\bwhile\b|\bmap\(|\.forEach\(/.test(line)) complexity++;

    if (trimmed.length > 120) {
      issues.push({ severity: 'warning', message: 'Line exceeds 120 characters', line: i + 1, rule: 'max-len' });
    }

    if (language === 'typescript' || language === 'javascript') {
      if (/\bconsole\.(log|debug|info)\(/.test(line)) {
        issues.push({ severity: 'warning', message: 'Unexpected console statement', line: i + 1, rule: 'no-console' });
      }
      if (/var\s+/.test(line)) {
        issues.push({ severity: 'warning', message: "Use 'let' or 'const' instead of 'var'", line: i + 1, rule: 'no-var' });
      }
      if (/eval\s*\(/.test(line)) {
        issues.push({ severity: 'error', message: 'eval() is a security risk', line: i + 1, rule: 'no-eval' });
      }
      if (/==(?!=)/.test(line) && !/===/.test(line)) {
        issues.push({ severity: 'warning', message: "Expected '===' instead of '=='", line: i + 1, rule: 'eqeqeq' });
      }
    }

    if (language === 'python') {
      if (/except:/.test(line)) {
        issues.push({ severity: 'warning', message: 'Bare except clause', line: i + 1, rule: 'bare-except' });
      }
      if (/import \*/.test(line)) {
        issues.push({ severity: 'warning', message: 'Wildcard import', line: i + 1, rule: 'wildcard-import' });
      }
    }

    if (language === 'rust') {
      if (/unwrap\(\)/.test(line)) {
        issues.push({ severity: 'warning', message: 'unwrap() may panic', line: i + 1, rule: 'unwrap' });
      }
    }
  }

  return { issues, complexity, functions };
}

export function createCodeTools(): ToolDefinition[] {
  return [
    {
      name: 'code_analyze',
      description: 'Analyze source code for issues, metrics, and suggestions',
      category: 'code',
      inputSchema: AnalyzeInput,
      outputSchema: AnalyzeOutput,
      rateLimit: { windowMs: 60000, maxRequests: 40 },
      handler: async (params) => {
        const input = AnalyzeInput.parse(params);
        const { issues, complexity, functions } = analyzeCode(input.code, input.language);
        const lines = input.code.split('\n');
        const suggestions: string[] = [];
        if (complexity > 10) suggestions.push('Consider breaking down complex functions');
        if (lines.length > 300) suggestions.push('File is long, consider splitting into modules');
        if (functions === 0 && lines.length > 5) suggestions.push('No functions detected, consider modularizing');
        if (issues.filter((i) => i.severity === 'error').length > 0)
          suggestions.push('Fix errors before proceeding');
        return {
          language: input.language,
          issues,
          metrics: {
            lines: lines.length,
            characters: input.code.length,
            complexity,
            functions,
          },
          suggestions,
        };
      },
    },
    {
      name: 'code_format',
      description: 'Auto-format source code',
      category: 'code',
      inputSchema: FormatInput,
      outputSchema: FormatOutput,
      handler: async (params) => {
        const input = FormatInput.parse(params);
        const indent = ' '.repeat(input.indentSize);
        let formatted = input.code;
        formatted = formatted.replace(/\t/g, indent);
        formatted = formatted.replace(/[ \t]+$/gm, '');
        formatted = formatted.replace(/\n{3,}/g, '\n\n');
        formatted = formatted.trimEnd() + '\n';
        const changed = formatted !== input.code;
        const diffLines: string[] = [];
        const originalLines = input.code.split('\n');
        const formattedLines = formatted.split('\n');
        for (let i = 0; i < Math.max(originalLines.length, formattedLines.length); i++) {
          if (originalLines[i] !== formattedLines[i]) {
            if (originalLines[i]) diffLines.push(`-${originalLines[i]}`);
            if (formattedLines[i]) diffLines.push(`+${formattedLines[i]}`);
          }
        }
        return { formatted, changed, diff: diffLines.length > 0 ? diffLines.join('\n') : undefined };
      },
    },
    {
      name: 'code_dependencies',
      description: 'Analyze package.json dependencies',
      category: 'code',
      inputSchema: DependencyInput,
      outputSchema: DependencyOutput,
      handler: async (params) => {
        const input = DependencyInput.parse(params);
        let parsed: { dependencies?: Record<string, string>; devDependencies?: Record<string, string> };
        try {
          parsed = JSON.parse(input.packageJson);
        } catch {
          throw new Error('Invalid package.json format');
        }
        const dependencies: Array<{ name: string; version: string; type: 'dependency' | 'devDependency' }> = [];
        if (parsed.dependencies) {
          for (const [name, version] of Object.entries(parsed.dependencies)) {
            dependencies.push({ name, version, type: 'dependency' });
          }
        }
        if (parsed.devDependencies) {
          for (const [name, version] of Object.entries(parsed.devDependencies)) {
            dependencies.push({ name, version, type: 'devDependency' });
          }
        }
        return { dependencies, total: dependencies.length, outdated: [] };
      },
    },
  ];
}
