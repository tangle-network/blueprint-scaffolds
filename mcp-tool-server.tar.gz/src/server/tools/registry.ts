import { z } from 'zod';

export interface ToolSchema {
  name: string;
  description: string;
  inputSchema: z.ZodType<unknown>;
  outputSchema: z.ZodType<unknown>;
  category: string;
  scope: string;
}

export interface ToolResult {
  content: Array<{
    type: 'text' | 'image' | 'resource';
    text?: string;
    data?: unknown;
    mimeType?: string;
  }>;
  isError?: boolean;
}

export type ToolHandler = (params: unknown) => Promise<ToolResult>;

interface RegisteredTool {
  schema: ToolSchema;
  handler: ToolHandler;
  callCount: number;
  lastCalled?: number;
  avgDuration: number;
}

const tools = new Map<string, RegisteredTool>();

export function registerTool(schema: ToolSchema, handler: ToolHandler): void {
  tools.set(schema.name, {
    schema,
    handler,
    callCount: 0,
    avgDuration: 0,
  });
}

export function getTool(name: string): RegisteredTool | undefined {
  return tools.get(name);
}

export function listTools(): ToolSchema[] {
  return Array.from(tools.values()).map((t) => t.schema);
}

export function listToolsByCategory(): Record<string, ToolSchema[]> {
  const result: Record<string, ToolSchema[]> = {};
  for (const tool of tools.values()) {
    const cat = tool.schema.category;
    if (!result[cat]) result[cat] = [];
    result[cat].push(tool.schema);
  }
  return result;
}

export async function executeTool(name: string, params: unknown): Promise<ToolResult> {
  const tool = tools.get(name);
  if (!tool) {
    return {
      content: [{ type: 'text', text: `Tool not found: ${name}` }],
      isError: true,
    };
  }

  const parsed = tool.schema.inputSchema.safeParse(params);
  if (!parsed.success) {
    return {
      content: [
        {
          type: 'text',
          text: `Invalid params: ${parsed.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join(', ')}`,
        },
      ],
      isError: true,
    };
  }

  const start = Date.now();
  try {
    const result = await tool.handler(parsed.data);
    const duration = Date.now() - start;
    tool.callCount++;
    tool.avgDuration = tool.avgDuration === 0 ? duration : Math.round((tool.avgDuration + duration) / 2);
    tool.lastCalled = Date.now();
    return result;
  } catch (err) {
    const duration = Date.now() - start;
    tool.callCount++;
    tool.avgDuration = tool.avgDuration === 0 ? duration : Math.round((tool.avgDuration + duration) / 2);
    tool.lastCalled = Date.now();
    return {
      content: [{ type: 'text', text: `Execution error: ${err instanceof Error ? err.message : String(err)}` }],
      isError: true,
    };
  }
}

export function getToolStats(): Array<{
  name: string;
  category: string;
  callCount: number;
  lastCalled?: number;
  avgDuration: number;
}> {
  return Array.from(tools.values()).map((t) => ({
    name: t.schema.name,
    category: t.schema.category,
    callCount: t.callCount,
    lastCalled: t.lastCalled,
    avgDuration: t.avgDuration,
  }));
}
