import { z } from 'zod';
import type { ToolDefinition } from '../shared/types.js';

const ReadFileInput = z.object({
  path: z.string().min(1),
  encoding: z.string().default('utf-8'),
  offset: z.number().min(0).optional(),
  limit: z.number().min(1).optional(),
});

const ReadFileOutput = z.object({
  path: z.string(),
  content: z.string(),
  size: z.number(),
  lines: z.number(),
});

const WriteFileInput = z.object({
  path: z.string().min(1),
  content: z.string(),
  encoding: z.string().default('utf-8'),
  createDirs: z.boolean().default(false),
});

const WriteFileOutput = z.object({
  path: z.string(),
  bytesWritten: z.number(),
  created: z.boolean(),
});

const ListFilesInput = z.object({
  path: z.string().min(1),
  recursive: z.boolean().default(false),
  pattern: z.string().optional(),
});

const ListFilesOutput = z.object({
  path: z.string(),
  entries: z.array(
    z.object({
      name: z.string(),
      path: z.string(),
      type: z.enum(['file', 'directory']),
      size: z.number().optional(),
    })
  ),
  total: z.number(),
});

const SearchFilesInput = z.object({
  path: z.string().min(1),
  query: z.string().min(1),
  maxResults: z.number().min(1).max(1000).default(100),
});

const SearchFilesOutput = z.object({
  query: z.string(),
  results: z.array(
    z.object({
      file: z.string(),
      line: z.number(),
      content: z.string(),
    })
  ),
  total: z.number(),
});

const fileStore = new Map<string, { content: string; modifiedAt: number }>();

export function createFileTools(): ToolDefinition[] {
  return [
    {
      name: 'file_read',
      description: 'Read file contents from the virtual filesystem',
      category: 'file',
      inputSchema: ReadFileInput,
      outputSchema: ReadFileOutput,
      rateLimit: { windowMs: 60000, maxRequests: 100 },
      handler: async (params) => {
        const input = ReadFileInput.parse(params);
        const entry = fileStore.get(input.path);
        if (!entry) throw new Error(`File not found: ${input.path}`);
        const lines = entry.content.split('\n');
        const start = input.offset ?? 0;
        const end = input.limit ? start + input.limit : lines.length;
        const content = lines.slice(start, end).join('\n');
        return {
          path: input.path,
          content,
          size: Buffer.byteLength(entry.content, input.encoding),
          lines: lines.length,
        };
      },
    },
    {
      name: 'file_write',
      description: 'Write content to a file in the virtual filesystem',
      category: 'file',
      inputSchema: WriteFileInput,
      outputSchema: WriteFileOutput,
      rateLimit: { windowMs: 60000, maxRequests: 50 },
      handler: async (params) => {
        const input = WriteFileInput.parse(params);
        const existed = fileStore.has(input.path);
        fileStore.set(input.path, {
          content: input.content,
          modifiedAt: Date.now(),
        });
        return {
          path: input.path,
          bytesWritten: Buffer.byteLength(input.content, input.encoding),
          created: !existed,
        };
      },
    },
    {
      name: 'file_list',
      description: 'List files and directories',
      category: 'file',
      inputSchema: ListFilesInput,
      outputSchema: ListFilesOutput,
      handler: async (params) => {
        const input = ListFilesInput.parse(params);
        const entries: Array<{ name: string; path: string; type: 'file' | 'directory'; size?: number }> = [];
        const prefix = input.path.endsWith('/') ? input.path : input.path + '/';
        for (const [filePath, data] of fileStore.entries()) {
          if (!filePath.startsWith(prefix)) continue;
          const relative = filePath.slice(prefix.length);
          if (!relative) continue;
          const parts = relative.split('/');
          if (!input.recursive && parts.length > 1) continue;
          if (input.pattern && !parts[0].match(new RegExp(input.pattern))) continue;
          const isDir = relative.includes('/');
          entries.push({
            name: parts[0],
            path: prefix + parts[0],
            type: isDir ? 'directory' : 'file',
            size: isDir ? undefined : Buffer.byteLength(data.content),
          });
        }
        return { path: input.path, entries, total: entries.length };
      },
    },
    {
      name: 'file_search',
      description: 'Search for text patterns in files',
      category: 'file',
      inputSchema: SearchFilesInput,
      outputSchema: SearchFilesOutput,
      handler: async (params) => {
        const input = SearchFilesInput.parse(params);
        const results: Array<{ file: string; line: number; content: string }> = [];
        const regex = new RegExp(input.query, 'gi');
        const prefix = input.path.endsWith('/') ? input.path : input.path + '/';
        for (const [filePath, data] of fileStore.entries()) {
          if (!filePath.startsWith(prefix) && filePath !== input.path) continue;
          const lines = data.content.split('\n');
          for (let i = 0; i < lines.length; i++) {
            if (regex.test(lines[i])) {
              results.push({ file: filePath, line: i + 1, content: lines[i].trim() });
              if (results.length >= input.maxResults) break;
            }
            regex.lastIndex = 0;
          }
          if (results.length >= input.maxResults) break;
        }
        return { query: input.query, results, total: results.length };
      },
    },
  ];
}
