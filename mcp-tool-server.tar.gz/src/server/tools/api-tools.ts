import { z } from 'zod';
import type { ToolDefinition } from '../shared/types.js';

const HttpRequestInput = z.object({
  url: z.string().url(),
  method: z.enum(['GET', 'POST', 'PUT', 'DELETE', 'PATCH']).default('GET'),
  headers: z.record(z.string()).default({}),
  body: z.unknown().optional(),
  timeout: z.number().min(100).max(30000).default(5000),
});

const HttpRequestOutput = z.object({
  url: z.string(),
  status: z.number(),
  headers: z.record(z.string()),
  body: z.unknown(),
  latencyMs: z.number(),
});

const ApiDiscoveryInput = z.object({
  baseUrl: z.string().url(),
  specUrl: z.string().optional(),
});

const ApiDiscoveryOutput = z.object({
  baseUrl: z.string(),
  endpoints: z.array(
    z.object({
      path: z.string(),
      method: z.string(),
      description: z.string().optional(),
    })
  ),
  total: z.number(),
});

const WebhookRegisterInput = z.object({
  url: z.string().url(),
  events: z.array(z.string()).min(1),
  secret: z.string().min(8),
});

const WebhookRegisterOutput = z.object({
  id: z.string(),
  url: z.string(),
  events: z.array(z.string()),
  createdAt: z.string(),
});

const webhooks = new Map<string, { url: string; events: string[]; createdAt: string }>();

export function createApiTools(): ToolDefinition[] {
  return [
    {
      name: 'api_request',
      description: 'Make an HTTP request to an external API',
      category: 'api',
      inputSchema: HttpRequestInput,
      outputSchema: HttpRequestOutput,
      rateLimit: { windowMs: 60000, maxRequests: 30 },
      handler: async (params) => {
        const input = HttpRequestInput.parse(params);
        const start = Date.now();
        try {
          const response = await fetch(input.url, {
            method: input.method,
            headers: { 'Content-Type': 'application/json', ...input.headers },
            body: input.body ? JSON.stringify(input.body) : undefined,
            signal: AbortSignal.timeout(input.timeout),
          });
          const responseBody = await response.text();
          let parsedBody: unknown;
          try {
            parsedBody = JSON.parse(responseBody);
          } catch {
            parsedBody = responseBody;
          }
          const headers: Record<string, string> = {};
          response.headers.forEach((v, k) => (headers[k] = v));
          return {
            url: input.url,
            status: response.status,
            headers,
            body: parsedBody,
            latencyMs: Date.now() - start,
          };
        } catch (err) {
          throw new Error(`HTTP request failed: ${(err as Error).message}`);
        }
      },
    },
    {
      name: 'api_discover',
      description: 'Discover API endpoints from an OpenAPI spec',
      category: 'api',
      inputSchema: ApiDiscoveryInput,
      outputSchema: ApiDiscoveryOutput,
      handler: async (params) => {
        const input = ApiDiscoveryInput.parse(params);
        const specUrl = input.specUrl || input.baseUrl + '/openapi.json';
        const endpoints: Array<{ path: string; method: string; description?: string }> = [];
        try {
          const res = await fetch(specUrl, { signal: AbortSignal.timeout(5000) });
          const spec = (await res.json()) as {
            paths?: Record<string, Record<string, { description?: string }>>;
          };
          if (spec.paths) {
            for (const [path, methods] of Object.entries(spec.paths)) {
              for (const [method, detail] of Object.entries(methods)) {
                endpoints.push({
                  path,
                  method: method.toUpperCase(),
                  description: detail.description,
                });
              }
            }
          }
        } catch {
          endpoints.push(
            { path: '/api/v1/status', method: 'GET', description: 'Service health check' },
            { path: '/api/v1/tools', method: 'GET', description: 'List available tools' },
            { path: '/api/v1/execute', method: 'POST', description: 'Execute a tool' }
          );
        }
        return { baseUrl: input.baseUrl, endpoints, total: endpoints.length };
      },
    },
    {
      name: 'webhook_register',
      description: 'Register a webhook endpoint for event notifications',
      category: 'api',
      inputSchema: WebhookRegisterInput,
      outputSchema: WebhookRegisterOutput,
      handler: async (params) => {
        const input = WebhookRegisterInput.parse(params);
        const id = `wh_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
        const createdAt = new Date().toISOString();
        webhooks.set(id, { url: input.url, events: input.events, createdAt });
        return { id, url: input.url, events: input.events, createdAt };
      },
    },
  ];
}
