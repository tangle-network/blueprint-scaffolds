import { z } from 'zod';
import type { ToolDefinition } from '../shared/types.js';

const QueryInput = z.object({
  query: z.string().min(1),
  params: z.record(z.unknown()).default({}),
  database: z.string().default('default'),
});

const QueryOutput = z.object({
  query: z.string(),
  rows: z.array(z.record(z.unknown())),
  rowCount: z.number(),
  executionTimeMs: z.number(),
});

const ListTablesInput = z.object({
  database: z.string().default('default'),
  schema: z.string().default('public'),
});

const ListTablesOutput = z.object({
  tables: z.array(
    z.object({
      name: z.string(),
      schema: z.string(),
      columns: z.number(),
      rowCount: z.number(),
    })
  ),
  total: z.number(),
});

const DescribeTableInput = z.object({
  table: z.string().min(1),
  database: z.string().default('default'),
  schema: z.string().default('public'),
});

const DescribeTableOutput = z.object({
  table: z.string(),
  columns: z.array(
    z.object({
      name: z.string(),
      type: z.string(),
      nullable: z.boolean(),
      defaultValue: z.unknown().optional(),
    })
  ),
  indexes: z.array(
    z.object({
      name: z.string(),
      columns: z.array(z.string()),
      unique: z.boolean(),
    })
  ),
});

interface TableData {
  columns: Array<{ name: string; type: string; nullable: boolean; defaultValue?: unknown }>;
  rows: Array<Record<string, unknown>>;
  indexes: Array<{ name: string; columns: string[]; unique: boolean }>;
}

const databases = new Map<string, Map<string, TableData>>();

function ensureDb(name: string): Map<string, TableData> {
  if (!databases.has(name)) {
    const tables = new Map<string, TableData>();
    tables.set('users', {
      columns: [
        { name: 'id', type: 'integer', nullable: false },
        { name: 'name', type: 'varchar(255)', nullable: false },
        { name: 'email', type: 'varchar(255)', nullable: false },
        { name: 'created_at', type: 'timestamp', nullable: false, defaultValue: 'now()' },
      ],
      rows: [
        { id: 1, name: 'Alice', email: 'alice@example.com', created_at: '2025-01-01' },
        { id: 2, name: 'Bob', email: 'bob@example.com', created_at: '2025-01-15' },
        { id: 3, name: 'Charlie', email: 'charlie@example.com', created_at: '2025-02-01' },
      ],
      indexes: [{ name: 'users_pk', columns: ['id'], unique: true }],
    });
    tables.set('projects', {
      columns: [
        { name: 'id', type: 'integer', nullable: false },
        { name: 'name', type: 'varchar(255)', nullable: false },
        { name: 'owner_id', type: 'integer', nullable: false },
        { name: 'status', type: 'varchar(50)', nullable: false, defaultValue: 'active' },
      ],
      rows: [
        { id: 1, name: 'MCP Server', owner_id: 1, status: 'active' },
        { id: 2, name: 'Web Platform', owner_id: 2, status: 'active' },
        { id: 3, name: 'Mobile App', owner_id: 1, status: 'archived' },
      ],
      indexes: [
        { name: 'projects_pk', columns: ['id'], unique: true },
        { name: 'projects_owner', columns: ['owner_id'], unique: false },
      ],
    });
    databases.set(name, tables);
  }
  return databases.get(name)!;
}

export function createDatabaseTools(): ToolDefinition[] {
  return [
    {
      name: 'db_query',
      description: 'Execute a SQL-like query against the virtual database',
      category: 'database',
      inputSchema: QueryInput,
      outputSchema: QueryOutput,
      rateLimit: { windowMs: 60000, maxRequests: 60 },
      handler: async (params) => {
        const input = QueryInput.parse(params);
        const db = ensureDb(input.database);
        const tableName = input.query.match(/from\s+(\w+)/i)?.[1];
        if (!tableName) throw new Error('Could not parse table name from query');
        const table = db.get(tableName.toLowerCase());
        if (!table) throw new Error(`Table not found: ${tableName}`);
        let rows = [...table.rows];
        const whereMatch = input.query.match(/where\s+(\w+)\s*=\s*'?([^']*)'?/i);
        if (whereMatch) {
          const [, col, val] = whereMatch;
          rows = rows.filter((r) => String(r[col]) === val);
        }
        const limitMatch = input.query.match(/limit\s+(\d+)/i);
        if (limitMatch) rows = rows.slice(0, parseInt(limitMatch[1]));
        const start = Date.now();
        await new Promise((r) => setTimeout(r, Math.random() * 10));
        return {
          query: input.query,
          rows,
          rowCount: rows.length,
          executionTimeMs: Date.now() - start,
        };
      },
    },
    {
      name: 'db_list_tables',
      description: 'List all tables in the database',
      category: 'database',
      inputSchema: ListTablesInput,
      outputSchema: ListTablesOutput,
      handler: async (params) => {
        const input = ListTablesInput.parse(params);
        const db = ensureDb(input.database);
        const tables = Array.from(db.entries()).map(([name, data]) => ({
          name,
          schema: input.schema,
          columns: data.columns.length,
          rowCount: data.rows.length,
        }));
        return { tables, total: tables.length };
      },
    },
    {
      name: 'db_describe_table',
      description: 'Get schema details for a specific table',
      category: 'database',
      inputSchema: DescribeTableInput,
      outputSchema: DescribeTableOutput,
      handler: async (params) => {
        const input = DescribeTableInput.parse(params);
        const db = ensureDb(input.database);
        const table = db.get(input.table.toLowerCase());
        if (!table) throw new Error(`Table not found: ${input.table}`);
        return {
          table: input.table,
          columns: table.columns,
          indexes: table.indexes,
        };
      },
    },
  ];
}
