export const generateToken = {} as any
