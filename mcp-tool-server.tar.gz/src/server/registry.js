import React from 'react'

export function ToolRegistry(props: Record<string, any>) { return <div>{props.children}</div> }
