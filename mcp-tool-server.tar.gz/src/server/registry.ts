import { z } from 'zod';
import type { ToolDefinition, JsonRpcRequest, JsonRpcResponse, ServerMetrics } from '../shared/types.js';
import { validateToken, checkRateLimit } from './auth.js';

export class ToolRegistry {
  private tools = new Map<string, ToolDefinition>();
  private metrics: ServerMetrics = {
    totalRequests: 0,
    totalErrors: 0,
    activeConnections: 0,
    requestsByCategory: {},
    averageLatencyMs: 0,
    uptime: Date.now(),
    toolExecutions: {},
  };
  private latencySum = 0;

  register(tool: ToolDefinition): void {
    this.tools.set(tool.name, tool);
  }

  registerMany(tools: ToolDefinition[]): void {
    for (const tool of tools) this.register(tool);
  }

  list(): Array<{ name: string; description: string; category: string; inputSchema: unknown }> {
    return Array.from(this.tools.values()).map((t) => ({
      name: t.name,
      description: t.description,
      category: t.category,
      inputSchema: zodToJsonSchema(t.inputSchema),
    }));
  }

  getMetrics(): ServerMetrics {
    return {
      ...this.metrics,
      averageLatencyMs: this.metrics.totalRequests > 0 ? Math.round(this.latencySum / this.metrics.totalRequests) : 0,
    };
  }

  async execute(
    request: JsonRpcRequest,
    clientId: string,
    authToken?: string
  ): Promise<JsonRpcResponse> {
    const startTime = Date.now();
    this.metrics.totalRequests++;

    try {
      if (request.method === 'tools/list') {
        return { jsonrpc: '2.0', id: request.id, result: { tools: this.list() } };
      }

      if (request.method === 'tools/call') {
        const params = request.params || {};
        const toolName = params.name as string;
        const toolArgs = params.arguments as Record<string, unknown>;

        if (!toolName) {
          return { jsonrpc: '2.0', id: request.id, error: { code: -32602, message: 'Missing tool name' } };
        }

        const tool = this.tools.get(toolName);
        if (!tool) {
          return { jsonrpc: '2.0', id: request.id, error: { code: -32601, message: `Tool not found: ${toolName}` } };
        }

        if (authToken) {
          const token = validateToken(authToken);
          if (!token) {
            return { jsonrpc: '2.0', id: request.id, error: { code: -32001, message: 'Invalid or expired token' } };
          }
        }

        if (tool.rateLimit) {
          const rl = checkRateLimit(clientId, toolName, tool.rateLimit.windowMs, tool.rateLimit.maxRequests);
          if (!rl.allowed) {
            return {
              jsonrpc: '2.0',
              id: request.id,
              error: { code: -32002, message: 'Rate limit exceeded', data: { retryAfter: rl.resetAt - Date.now() } },
            };
          }
        }

        let parsedInput: unknown;
        try {
          parsedInput = tool.inputSchema.parse(toolArgs);
        } catch (err) {
          if (err instanceof z.ZodError) {
            return {
              jsonrpc: '2.0',
              id: request.id,
              error: {
                code: -32602,
                message: 'Invalid input',
                data: err.errors.map((e) => ({ path: e.path.join('.'), message: e.message })),
              },
            };
          }
          throw err;
        }

        const result = await tool.handler(parsedInput);

        try {
          tool.outputSchema.parse(result);
        } catch (err) {
          if (err instanceof z.ZodError) {
            return {
              jsonrpc: '2.0',
              id: request.id,
              error: { code: -32003, message: 'Output validation failed', data: err.errors.map((e) => e.message) },
            };
          }
        }

        this.metrics.toolExecutions[toolName] = (this.metrics.toolExecutions[toolName] || 0) + 1;
        this.metrics.requestsByCategory[tool.category] = (this.metrics.requestsByCategory[tool.category] || 0) + 1;

        const elapsed = Date.now() - startTime;
        this.latencySum += elapsed;

        return { jsonrpc: '2.0', id: request.id, result: { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] } };
      }

      if (request.method === 'metrics') {
        return { jsonrpc: '2.0', id: request.id, result: this.getMetrics() };
      }

      return { jsonrpc: '2.0', id: request.id, error: { code: -32601, message: `Method not found: ${request.method}` } };
    } catch (err) {
      this.metrics.totalErrors++;
      return {
        jsonrpc: '2.0',
        id: request.id,
        error: { code: -32603, message: 'Internal error', data: (err as Error).message },
      };
    }
  }
}

function zodToJsonSchema(schema: z.ZodType<unknown>): unknown {
  if (schema instanceof z.ZodObject) {
    const properties: Record<string, unknown> = {};
    const required: string[] = [];
    for (const [key, value] of Object.entries(schema.shape)) {
      properties[key] = zodToJsonSchema(value as z.ZodType<unknown>);
      if (!(value instanceof z.ZodOptional)) required.push(key);
    }
    return { type: 'object', properties, required: required.length > 0 ? required : undefined };
  }
  if (schema instanceof z.ZodString) return { type: 'string' };
  if (schema instanceof z.ZodNumber) return { type: 'number' };
  if (schema instanceof z.ZodBoolean) return { type: 'boolean' };
  if (schema instanceof z.ZodArray) return { type: 'array', items: zodToJsonSchema(schema.element) };
  if (schema instanceof z.ZodOptional) return zodToJsonSchema(schema.unwrap());
  if (schema instanceof z.ZodDefault) return zodToJsonSchema(schema._def.innerType);
  if (schema instanceof z.ZodEnum) return { type: 'string', enum: schema._def.values };
  if (schema instanceof z.ZodLiteral) return { const: schema.value };
  return {};
}
