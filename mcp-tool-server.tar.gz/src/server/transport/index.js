export const startWebSocketServer = {} as any
