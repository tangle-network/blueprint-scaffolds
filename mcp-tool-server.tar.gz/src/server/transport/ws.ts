import { WebSocketServer, WebSocket } from 'ws';
import { createServer } from 'http';
import type { JsonRpcRequest, JsonRpcResponse } from '../shared/types.js';
import { JsonRpcRequestSchema } from '../shared/types.js';
import { ToolRegistry } from './registry.js';

export function startWebSocketServer(registry: ToolRegistry, port: number): void {
  const server = createServer();
  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws: WebSocket) => {
    const clientId = `ws_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    registry.getMetrics().activeConnections++;
    console.log(`[WS] Client connected: ${clientId}`);

    ws.on('message', async (data) => {
      let parsed: unknown;
      try {
        parsed = JSON.parse(data.toString());
      } catch {
        ws.send(JSON.stringify({ jsonrpc: '2.0', id: null, error: { code: -32700, message: 'Parse error' } }));
        return;
      }

      const parseResult = JsonRpcRequestSchema.safeParse(parsed);
      if (!parseResult.success) {
        ws.send(JSON.stringify({ jsonrpc: '2.0', id: null, error: { code: -32600, message: 'Invalid Request' } }));
        return;
      }

      const authToken = (parseResult.data.params as Record<string, unknown>)?.token as string | undefined;
      const response = await registry.execute(parseResult.data, clientId, authToken);
      ws.send(JSON.stringify(response));
    });

    ws.on('close', () => {
      registry.getMetrics().activeConnections--;
      console.log(`[WS] Client disconnected: ${clientId}`);
    });
  });

  server.listen(port, () => {
    console.log(`[WS] WebSocket server listening on ws://localhost:${port}/ws`);
  });
}
