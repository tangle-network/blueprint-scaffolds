import { EventEmitter } from 'events';
import type { WebSocket } from 'ws';
import type { JsonRpcRequest, JsonRpcResponse } from '../../lib/json-rpc.js';

export class WebSocketTransport extends EventEmitter {
  private ws: WebSocket;

  constructor(ws: WebSocket) {
    super();
    this.ws = ws;

    ws.on('message', (data: Buffer) => {
      try {
        const parsed = JSON.parse(data.toString());
        this.emit('message', parsed as JsonRpcRequest);
      } catch {
        this.emit('error', new Error('Invalid JSON'));
      }
    });

    ws.on('close', () => this.emit('close'));
    ws.on('error', (err: Error) => this.emit('error', err));
  }

  send(response: JsonRpcResponse): void {
    if (this.ws.readyState === 1) {
      this.ws.send(JSON.stringify(response));
    }
  }

  close(): void {
    this.ws.close();
  }
}
