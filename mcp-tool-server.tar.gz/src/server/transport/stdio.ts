import { EventEmitter } from 'events';
import type { JsonRpcRequest, JsonRpcResponse } from '../lib/json-rpc.js';

export interface Transport extends EventEmitter {
  send(response: JsonRpcResponse): void;
  close(): void;
}

export class StdioTransport extends EventEmitter implements Transport {
  constructor() {
    super();
    let buffer = '';

    process.stdin.on('data', (chunk) => {
      buffer += chunk.toString();
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        if (line.trim()) {
          try {
            const parsed = JSON.parse(line);
            this.emit('message', parsed as JsonRpcRequest);
          } catch {
            this.emit('error', new Error(`Failed to parse: ${line}`));
          }
        }
      }
    });

    process.stdin.on('end', () => {
      this.emit('close');
    });
  }

  send(response: JsonRpcResponse): void {
    process.stdout.write(JSON.stringify(response) + '\n');
  }

  close(): void {
    process.stdin.destroy();
  }
}
