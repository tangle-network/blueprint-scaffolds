import * as readline from 'readline';
import type { JsonRpcRequest } from '../shared/types.js';
import { JsonRpcRequestSchema } from '../shared/types.js';
import { ToolRegistry } from '../registry.js';

export function startStdioTransport(registry: ToolRegistry): void {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: false });
  const clientId = 'stdio';

  console.error('[STDIO] Stdio transport ready');

  rl.on('line', async (line) => {
    let parsed: unknown;
    try {
      parsed = JSON.parse(line.trim());
    } catch {
      console.log(JSON.stringify({ jsonrpc: '2.0', id: null, error: { code: -32700, message: 'Parse error' } }));
      return;
    }

    const parseResult = JsonRpcRequestSchema.safeParse(parsed);
    if (!parseResult.success) {
      console.log(JSON.stringify({ jsonrpc: '2.0', id: null, error: { code: -32600, message: 'Invalid Request' } }));
      return;
    }

    const authToken = (parseResult.data.params as Record<string, unknown>)?.token as string | undefined;
    const response = await registry.execute(parseResult.data, clientId, authToken);
    console.log(JSON.stringify(response));
  });
}
