import crypto from 'crypto';
import type { AuthToken, RateLimitEntry } from '../shared/types.js';

const tokens = new Map<string, AuthToken>();
const rateLimits = new Map<string, Map<string, RateLimitEntry>>();

export function generateToken(scopes: string[] = ['*'], ttlMs: number = 3600000): AuthToken {
  const token: AuthToken = {
    token: crypto.randomBytes(32).toString('hex'),
    scopes,
    expiresAt: Date.now() + ttlMs,
  };
  tokens.set(token.token, token);
  return token;
}

export function validateToken(tokenString: string): AuthToken | null {
  const token = tokens.get(tokenString);
  if (!token) return null;
  if (Date.now() > token.expiresAt) {
    tokens.delete(tokenString);
    return null;
  }
  return token;
}

export function checkRateLimit(
  clientId: string,
  toolName: string,
  windowMs: number,
  maxRequests: number
): { allowed: boolean; remaining: number; resetAt: number } {
  if (!rateLimits.has(clientId)) rateLimits.set(clientId, new Map());
  const clientLimits = rateLimits.get(clientId)!;
  const key = toolName;
  const now = Date.now();
  const entry = clientLimits.get(key);

  if (!entry || now >= entry.resetAt) {
    clientLimits.set(key, { count: 1, resetAt: now + windowMs });
    return { allowed: true, remaining: maxRequests - 1, resetAt: now + windowMs };
  }

  if (entry.count >= maxRequests) {
    return { allowed: false, remaining: 0, resetAt: entry.resetAt };
  }

  entry.count++;
  return { allowed: true, remaining: maxRequests - entry.count, resetAt: entry.resetAt };
}

export function checkScope(token: AuthToken, requiredScope: string): boolean {
  if (token.scopes.includes('*')) return true;
  return token.scopes.includes(requiredScope);
}
