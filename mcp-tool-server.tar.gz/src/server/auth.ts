import crypto from 'crypto';

export interface ApiKey {
  key: string;
  name: string;
  createdAt: number;
  scopes: string[];
}

const apiKeys = new Map<string, ApiKey>();

export function generateApiKey(name: string, scopes: string[] = ['*']): ApiKey {
  const key = `mcp_${crypto.randomBytes(32).toString('hex')}`;
  const apiKey: ApiKey = { key, name, createdAt: Date.now(), scopes };
  apiKeys.set(key, apiKey);
  return apiKey;
}

export function validateApiKey(key: string | undefined): ApiKey | null {
  if (!key) return null;
  return apiKeys.get(key) ?? null;
}

export function hasScope(apiKey: ApiKey, requiredScope: string): boolean {
  if (apiKey.scopes.includes('*')) return true;
  return apiKey.scopes.includes(requiredScope);
}

export function listApiKeys(): Omit<ApiKey, 'key'>[] {
  return Array.from(apiKeys.values()).map(({ name, createdAt, scopes }) => ({
    name,
    createdAt,
    scopes,
  }));
}

generateApiKey('default', ['*']);
