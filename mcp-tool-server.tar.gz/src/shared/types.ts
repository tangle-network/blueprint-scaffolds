import { z } from 'zod';

export const JsonRpcRequestSchema = z.object({
  jsonrpc: z.literal('2.0'),
  id: z.union([z.string(), z.number()]).optional(),
  method: z.string(),
  params: z.record(z.unknown()).optional(),
});

export const JsonRpcResponseSchema = z.object({
  jsonrpc: z.literal('2.0'),
  id: z.union([z.string(), z.number(), z.null()]).optional(),
  result: z.unknown().optional(),
  error: z
    .object({
      code: z.number(),
      message: z.string(),
      data: z.unknown().optional(),
    })
    .optional(),
});

export type JsonRpcRequest = z.infer<typeof JsonRpcRequestSchema>;
export type JsonRpcResponse = z.infer<typeof JsonRpcResponseSchema>;

export interface ToolDefinition {
  name: string;
  description: string;
  inputSchema: z.ZodType<unknown>;
  outputSchema: z.ZodType<unknown>;
  handler: (params: unknown) => Promise<unknown>;
  category: ToolCategory;
  rateLimit?: { windowMs: number; maxRequests: number };
}

export type ToolCategory = 'file' | 'database' | 'api' | 'code';

export interface AuthToken {
  token: string;
  scopes: string[];
  expiresAt: number;
}

export interface RateLimitEntry {
  count: number;
  resetAt: number;
}

export interface ServerMetrics {
  totalRequests: number;
  totalErrors: number;
  activeConnections: number;
  requestsByCategory: Record<string, number>;
  averageLatencyMs: number;
  uptime: number;
  toolExecutions: Record<string, number>;
}
