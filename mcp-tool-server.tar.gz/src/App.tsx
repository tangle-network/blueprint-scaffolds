import { Header } from './components/Header';
import { MonitoringPanel } from './components/MonitoringPanel';
import { RequestWorkbench } from './components/RequestWorkbench';
import { StatsGrid } from './components/StatsGrid';
import { ToolCatalog } from './components/ToolCatalog';
import { metrics, requestLogs, tools } from './mockData';

export default function App(): JSX.Element {
  return (
    <div className="app-shell">
      <Header />
      <StatsGrid metrics={metrics} />
      <main className="content-grid">
        <ToolCatalog tools={tools} />
        <RequestWorkbench />
        <MonitoringPanel metrics={metrics} requestLogs={requestLogs} />
      </main>
    </div>
  );
}
