import type { Metrics } from '../types';

interface StatsGridProps {
  metrics: Metrics;
}

export function StatsGrid({ metrics }: StatsGridProps): JSX.Element {
  const successRate =
    metrics.totalRequests === 0 ? 0 : Math.round((metrics.successfulRequests / metrics.totalRequests) * 100);

  const items = [
    { label: 'Requests', value: metrics.totalRequests.toLocaleString() },
    { label: 'Success Rate', value: `${successRate}%` },
    { label: 'Active Connections', value: metrics.activeConnections.toString() },
    { label: 'Failures', value: metrics.failedRequests.toString() },
  ];

  return (
    <section className="stats-grid">
      {items.map((item) => (
        <article key={item.label} className="panel stat-card">
          <span>{item.label}</span>
          <strong>{item.value}</strong>
        </article>
      ))}
    </section>
  );
}
