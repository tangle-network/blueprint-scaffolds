import { useState } from 'react';
import { sampleRequest, sampleResponse } from '../mockData';

export function RequestWorkbench(): JSX.Element {
  const [requestText, setRequestText] = useState(sampleRequest);
  const [responseText, setResponseText] = useState(sampleResponse);

  const runSimulation = (): void => {
    try {
      const request = JSON.parse(requestText) as { params?: { name?: string } };
      const nextResponse = {
        jsonrpc: '2.0',
        id: 'demo-1',
        result: {
          accepted: true,
          tool: request.params?.name ?? 'unknown',
          executedAt: new Date().toISOString(),
          traceId: `trace-${Math.random().toString(16).slice(2, 8)}`,
        },
      };
      setResponseText(JSON.stringify(nextResponse, null, 2));
    } catch {
      setResponseText(
        JSON.stringify(
          {
            jsonrpc: '2.0',
            id: null,
            error: {
              code: -32700,
              message: 'Parse error',
            },
          },
          null,
          2,
        ),
      );
    }
  };

  return (
    <section className="panel workbench">
      <div className="section-heading">
        <div>
          <p className="eyebrow">Testing Interface</p>
          <h2>JSON-RPC workbench</h2>
        </div>
        <button className="action-button" onClick={runSimulation}>
          Simulate Request
        </button>
      </div>
      <div className="editor-grid">
        <label>
          <span>Request</span>
          <textarea value={requestText} onChange={(event) => setRequestText(event.target.value)} />
        </label>
        <label>
          <span>Response</span>
          <textarea value={responseText} onChange={(event) => setResponseText(event.target.value)} readOnly />
        </label>
      </div>
    </section>
  );
}
