import type { ToolDescriptor } from '../types';

interface ToolCatalogProps {
  tools: ToolDescriptor[];
}

export function ToolCatalog({ tools }: ToolCatalogProps): JSX.Element {
  return (
    <section className="panel">
      <div className="section-heading">
        <div>
          <p className="eyebrow">Tool Catalog</p>
          <h2>Structured tool surfaces</h2>
        </div>
      </div>
      <div className="tool-grid">
        {tools.map((tool) => (
          <article key={tool.name} className="tool-card">
            <div className="tool-topline">
              <span className={`badge badge-${tool.category}`}>{tool.category}</span>
              <strong>{tool.name}</strong>
            </div>
            <p>{tool.description}</p>
            <dl>
              <div>
                <dt>Input</dt>
                <dd>{Object.keys(tool.inputSchema).join(', ')}</dd>
              </div>
              <div>
                <dt>Output</dt>
                <dd>{Object.keys(tool.outputSchema).join(', ')}</dd>
              </div>
            </dl>
          </article>
        ))}
      </div>
    </section>
  );
}
