export function Header(): JSX.Element {
  return (
    <header className="hero">
      <div>
        <p className="eyebrow">Model Context Protocol</p>
        <h1>Operational MCP server with typed tools and live transport coverage.</h1>
      </div>
      <div className="hero-card">
        <span>Transports</span>
        <strong>WebSocket + stdio</strong>
        <span>Auth, rate limits, JSON-RPC, validation</span>
      </div>
    </header>
  );
}
