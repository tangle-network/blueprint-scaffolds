import type { Metrics, RequestLog } from '../types';

interface MonitoringPanelProps {
  metrics: Metrics;
  requestLogs: RequestLog[];
}

export function MonitoringPanel({ metrics, requestLogs }: MonitoringPanelProps): JSX.Element {
  const usageEntries = Object.entries(metrics.toolUsage).sort((left, right) => right[1] - left[1]);

  return (
    <section className="monitor-layout">
      <article className="panel">
        <div className="section-heading">
          <div>
            <p className="eyebrow">Monitoring</p>
            <h2>Recent activity</h2>
          </div>
        </div>
        <ul className="request-list">
          {requestLogs.map((log) => (
            <li key={log.id}>
              <div>
                <strong>{log.method}</strong>
                <span>{log.detail}</span>
              </div>
              <div>
                <span className={`status-pill status-${log.status}`}>{log.status}</span>
                <time>{log.at}</time>
              </div>
            </li>
          ))}
        </ul>
      </article>
      <article className="panel">
        <div className="section-heading">
          <div>
            <p className="eyebrow">Usage</p>
            <h2>Most called methods</h2>
          </div>
        </div>
        <ul className="usage-list">
          {usageEntries.map(([name, count]) => (
            <li key={name}>
              <span>{name}</span>
              <strong>{count}</strong>
            </li>
          ))}
        </ul>
        <div className="error-block">
          <h3>Recent errors</h3>
          {metrics.recentErrors.map((error) => (
            <p key={`${error.at}-${error.clientId}`}>
              {error.message} <span>{error.clientId}</span>
            </p>
          ))}
        </div>
      </article>
    </section>
  );
}
