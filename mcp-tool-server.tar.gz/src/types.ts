export interface ToolDescriptor {
  name: string;
  category: 'file' | 'database' | 'api' | 'code';
  description: string;
  inputSchema: Record<string, unknown>;
  outputSchema: Record<string, unknown>;
}

export interface Metrics {
  totalRequests: number;
  successfulRequests: number;
  failedRequests: number;
  activeConnections: number;
  recentErrors: Array<{ at: string; message: string; clientId: string }>;
  toolUsage: Record<string, number>;
}

export interface RequestLog {
  id: string;
  method: string;
  status: 'ok' | 'error';
  at: string;
  detail: string;
}

export interface JsonRpcResult {
  jsonrpc: '2.0';
  id: string | number | null;
  result?: unknown;
  error?: {
    code: number;
    message: string;
    data?: unknown;
  };
}
