import { z } from 'zod';

export const JsonRpcRequestSchema = z.object({
  jsonrpc: z.literal('2.0'),
  id: z.union([z.string(), z.number(), z.null()]).optional(),
  method: z.string(),
  params: z.record(z.unknown()).optional(),
});

export const JsonRpcResponseSchema = z.object({
  jsonrpc: z.literal('2.0'),
  id: z.union([z.string(), z.number(), z.null()]),
  result: z.unknown().optional(),
  error: z
    .object({
      code: z.number(),
      message: z.string(),
      data: z.unknown().optional(),
    })
    .optional(),
});

export type JsonRpcRequest = z.infer<typeof JsonRpcRequestSchema>;
export type JsonRpcResponse = z.infer<typeof JsonRpcResponseSchema>;

export interface JsonRpcError {
  code: number;
  message: string;
  data?: unknown;
}

export const PARSE_ERROR: JsonRpcError = { code: -32700, message: 'Parse error' };
export const INVALID_REQUEST: JsonRpcError = { code: -32600, message: 'Invalid Request' };
export const METHOD_NOT_FOUND: JsonRpcError = { code: -32601, message: 'Method not found' };
export const INVALID_PARAMS: JsonRpcError = { code: -32602, message: 'Invalid params' };
export const INTERNAL_ERROR: JsonRpcError = { code: -32603, message: 'Internal error' };

export function makeResponse(id: JsonRpcRequest['id'], result: unknown): JsonRpcResponse {
  return { jsonrpc: '2.0', id: id ?? null, result };
}

export function makeError(id: JsonRpcRequest['id'], error: JsonRpcError): JsonRpcResponse {
  return { jsonrpc: '2.0', id: id ?? null, error };
}
