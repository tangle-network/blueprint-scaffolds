import type { Metrics, RequestLog, ToolDescriptor } from './types';

export const tools: ToolDescriptor[] = [
  {
    name: 'file.read',
    category: 'file',
    description: 'Read UTF-8 files within the workspace boundary.',
    inputSchema: { path: { type: 'string' } },
    outputSchema: { content: { type: 'string' }, bytes: { type: 'number' } },
  },
  {
    name: 'db.query',
    category: 'database',
    description: 'Run structured, bounded queries against operational datasets.',
    inputSchema: { table: { type: 'enum' }, filter: { type: 'record' } },
    outputSchema: { rows: { type: 'array' }, count: { type: 'number' } },
  },
  {
    name: 'api.fetchStatus',
    category: 'api',
    description: 'Inspect third-party APIs with timeout protection and typed results.',
    inputSchema: { url: { type: 'string' }, method: { type: 'enum' } },
    outputSchema: { ok: { type: 'boolean' }, status: { type: 'number' } },
  },
  {
    name: 'code.analyze',
    category: 'code',
    description: 'Analyze source trees for file counts, TODOs, and exports.',
    inputSchema: { path: { type: 'string' }, extensions: { type: 'array' } },
    outputSchema: { files: { type: 'number' }, todos: { type: 'number' } },
  },
];

export const metrics: Metrics = {
  totalRequests: 1834,
  successfulRequests: 1769,
  failedRequests: 65,
  activeConnections: 14,
  recentErrors: [
    { at: '2025-03-27T11:20:00Z', message: 'Unauthorized', clientId: 'ws-a12' },
    { at: '2025-03-27T11:16:00Z', message: 'Rate limit exceeded', clientId: 'cli-agent' },
    { at: '2025-03-27T11:09:00Z', message: 'Tool execution failed: api.fetchStatus', clientId: 'monitor-ui' },
  ],
  toolUsage: {
    'tools.list': 214,
    'file.read': 621,
    'db.query': 298,
    'api.fetchStatus': 184,
    'code.analyze': 79,
  },
};

export const requestLogs: RequestLog[] = [
  {
    id: 'req-1',
    method: 'tools.call:file.read',
    status: 'ok',
    at: '11:24:13',
    detail: 'Read src/App.tsx',
  },
  {
    id: 'req-2',
    method: 'tools.call:db.query',
    status: 'ok',
    at: '11:24:21',
    detail: 'Filtered services by healthy status',
  },
  {
    id: 'req-3',
    method: 'tools.call:api.fetchStatus',
    status: 'error',
    at: '11:24:38',
    detail: 'Timeout on upstream integration',
  },
  {
    id: 'req-4',
    method: 'auth.status',
    status: 'ok',
    at: '11:25:02',
    detail: 'Viewer token validated over WebSocket',
  },
];

export const sampleRequest = `{
  "jsonrpc": "2.0",
  "id": "demo-1",
  "method": "tools.call",
  "params": {
    "name": "code.analyze",
    "arguments": {
      "path": "src",
      "extensions": [".ts", ".tsx"]
    }
  }
}`;

export const sampleResponse = `{
  "jsonrpc": "2.0",
  "id": "demo-1",
  "result": {
    "root": "src",
    "files": 8,
    "lines": 512,
    "todos": 3,
    "exportedSymbols": 19
  }
}`;
