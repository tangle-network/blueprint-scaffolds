# AGENTS.md

Build a Model Context Protocol server providing tools for AI assistants. Tool definition, input validation, resource management.

## What's here

This project was scaffolded by starter-foundry. The user's prompt drove the choices below — read their prompt first, it takes priority over everything in this file.

- **Family:** `mcp-server-ts`
- **Layers:** `framework:mcp-server-ts`, `database:sqlite`, `sdk:none`, `auth:none`, `payments:none`, `queue:none`

## Getting started

```bash
node server.mjs
```

Key files: `server.mjs`, `mcp.config.json`

## How to use this scaffold

This is a starting point, not a contract. You own every file.

- **Customize freely.** Replace components, change the layout, swap the color scheme — whatever fits the user's product.
- **The scaffold saves you setup time** — Tailwind, shadcn/ui, path aliases, and framework config are ready. Don't redo them.
- **Check `.starter-foundry/compose-report.json`** if you want to see which layer wrote which file.
- **Update this file** as the project evolves. Delete sections that no longer apply.
