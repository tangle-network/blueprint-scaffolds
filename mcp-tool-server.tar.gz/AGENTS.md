# AGENTS.md

## Goal

Build a Model Context Protocol server providing tools for AI assistants. Tool definition, input validation, resource management.

## Stack

- Family: `mcp-server-ts`
- Layers: `database:sqlite`, `sdk:none`, `auth:none`, `payments:none`, `queue:none`

## Entry Points

- `server.mjs`
- `mcp.config.json`

## Commands

- `node server.mjs`

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
