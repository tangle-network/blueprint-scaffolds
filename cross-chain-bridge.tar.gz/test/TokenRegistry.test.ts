import { expect } from "chai";
import { ethers } from "hardhat";

describe("TokenRegistry", function () {
  it("should register and query tokens", async function () {
    const [owner, addr1] = await ethers.getSigners();
    const TokenRegistry = await ethers.getContractFactory("TokenRegistry");
    const registry = await TokenRegistry.deploy();
    await registry.deployed();

    const l1Token = addr1.address;
    const l2Token = owner.address;

    await registry.registerToken(l1Token, l2Token, 1000);
    expect(await registry.isRegistered(l1Token)).to.be.true;
    expect(await registry.getL2Token(l1Token)).to.equal(l2Token);
    expect(await registry.getL1Token(l2Token)).to.equal(l1Token);
  });

  it("should enforce rate limits", async function () {
    const [owner, addr1, addr2] = await ethers.getSigners();
    const TokenRegistry = await ethers.getContractFactory("TokenRegistry");
    const registry = await TokenRegistry.deploy();
    await registry.deployed();

    await registry.registerToken(addr1.address, addr2.address, 1000);

    expect(await registry.checkAndUpdateLimit(addr1.address, 500)).to.be.true;
    expect(await registry.checkAndUpdateLimit(addr1.address, 600)).to.be.false;
  });

  it("should deregister tokens", async function () {
    const [owner, addr1, addr2] = await ethers.getSigners();
    const TokenRegistry = await ethers.getContractFactory("TokenRegistry");
    const registry = await TokenRegistry.deploy();
    await registry.deployed();

    await registry.registerToken(addr1.address, addr2.address, 1000);
    expect(await registry.isRegistered(addr1.address)).to.be.true;

    await registry.deregisterToken(addr1.address);
    expect(await registry.isRegistered(addr1.address)).to.be.false;
  });

  it("should update daily limits", async function () {
    const [owner, addr1, addr2] = await ethers.getSigners();
    const TokenRegistry = await ethers.getContractFactory("TokenRegistry");
    const registry = await TokenRegistry.deploy();
    await registry.deployed();

    await registry.registerToken(addr1.address, addr2.address, 1000);
    await registry.updateDailyLimit(addr1.address, 5000);

    const info = await registry.l1ToL2(addr1.address);
    expect(info.dailyLimit).to.equal(5000);
  });
});
