import { ethers } from "hardhat";

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying contracts with:", deployer.address);

  const TokenRegistry = await ethers.getContractFactory("TokenRegistry");
  const registry = await TokenRegistry.deploy();
  await registry.deployed();
  console.log("TokenRegistry deployed to:", registry.address);

  const inboxAddress = "0x0000000000000000000000000000000000000001";

  const L1Gateway = await ethers.getContractFactory("L1Gateway");
  const l1Gateway = await L1Gateway.deploy(registry.address, inboxAddress);
  await l1Gateway.deployed();
  console.log("L1Gateway deployed to:", l1Gateway.address);

  const L2Gateway = await ethers.getContractFactory("L2Gateway");
  const l2Gateway = await L2Gateway.deploy();
  await l2Gateway.deployed();
  console.log("L2Gateway deployed to:", l2Gateway.address);

  await l2Gateway.setL1Gateway(l1Gateway.address);
  console.log("L2Gateway: L1 gateway set to", l1Gateway.address);

  console.log("\nDeployment complete!");
  console.log("Set these env vars:");
  console.log(`L1_GATEWAY_ADDRESS=${l1Gateway.address}`);
  console.log(`L2_GATEWAY_ADDRESS=${l2Gateway.address}`);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
