import { ethers } from "ethers";
import {
  L1_RPC_URL,
  L2_RPC_URL,
  L1_GATEWAY_ADDRESS,
  L2_GATEWAY_ADDRESS,
  L1_GATEWAY_ABI,
  KEEPER_POLL_INTERVAL_MS,
} from "../../frontend/src/lib/config";

interface RetryableState {
  ticketId: number;
  l1TxHash: string;
  status: "pending" | "redeemed" | "expired" | "failed";
  attempts: number;
  lastAttempt: number;
  createdAt: number;
}

class RetryableKeeper {
  private l1Provider: ethers.providers.JsonRpcProvider;
  private l2Provider: ethers.providers.JsonRpcProvider;
  private l1Gateway: ethers.Contract;
  private wallet: ethers.Wallet | null = null;
  private retryables: Map<number, RetryableState> = new Map();
  private running = false;
  private maxAttempts = 5;
  private retryDelayMs = 60000;

  constructor() {
    this.l1Provider = new ethers.providers.JsonRpcProvider(L1_RPC_URL);
    this.l2Provider = new ethers.providers.JsonRpcProvider(L2_RPC_URL);
    this.l1Gateway = new ethers.Contract(L1_GATEWAY_ADDRESS, L1_GATEWAY_ABI, this.l1Provider);

    const privateKey = process.env.KEEPER_PRIVATE_KEY;
    if (privateKey) {
      this.wallet = new ethers.Wallet(privateKey, this.l2Provider);
      console.log(`[Keeper] Wallet loaded: ${this.wallet.address}`);
    }
  }

  async start() {
    this.running = true;
    console.log("[Keeper] Starting retryable ticket keeper...");
    console.log(`[Keeper] Poll interval: ${KEEPER_POLL_INTERVAL_MS}ms`);
    console.log(`[Keeper] Max attempts: ${this.maxAttempts}`);

    while (this.running) {
      try {
        await this.pollRetryables();
        await this.processPendingRetryables();
      } catch (err) {
        console.error("[Keeper] Error:", err);
      }

      await new Promise((resolve) => setTimeout(resolve, KEEPER_POLL_INTERVAL_MS));
    }
  }

  stop() {
    this.running = false;
    console.log("[Keeper] Stopped.");
  }

  addRetryable(ticketId: number, l1TxHash: string) {
    if (this.retryables.has(ticketId)) return;

    const state: RetryableState = {
      ticketId,
      l1TxHash,
      status: "pending",
      attempts: 0,
      lastAttempt: 0,
      createdAt: Date.now(),
    };
    this.retryables.set(ticketId, state);
    console.log(`[Keeper] Tracking retryable #${ticketId} (L1 tx: ${l1TxHash})`);
  }

  private async pollRetryables() {
    const currentBlock = await this.l1Provider.getBlockNumber();
    const fromBlock = Math.max(0, currentBlock - 1000);

    const events = await this.l1Gateway.queryFilter(
      this.l1Gateway.filters.DepositInitiated(),
      fromBlock,
      currentBlock
    );

    for (const event of events) {
      const ticketId = event.args?.ticketId?.toNumber();
      if (ticketId !== undefined) {
        this.addRetryable(ticketId, event.transactionHash);
      }
    }
  }

  private async processPendingRetryables() {
    for (const [ticketId, state] of this.retryables) {
      if (state.status !== "pending") continue;
      if (state.attempts >= this.maxAttempts) {
        state.status = "failed";
        console.log(`[Keeper] Retryable #${ticketId} failed after ${state.maxAttempts} attempts`);
        continue;
      }

      const timeSinceLastAttempt = Date.now() - state.lastAttempt;
      if (timeSinceLastAttempt < this.retryDelayMs) continue;

      await this.attemptRedeem(ticketId, state);
    }
  }

  private async attemptRedeem(ticketId: number, state: RetryableState) {
    console.log(`[Keeper] Attempting to redeem retryable #${ticketId} (attempt ${state.attempts + 1}/${this.maxAttempts})`);

    try {
      if (!this.wallet) {
        console.log(`[Keeper] No wallet configured - would redeem retryable #${ticketId}`);
        state.status = "redeemed";
        return;
      }

      const l2GasPrice = await this.l2Provider.getGasPrice();
      const tx = await this.wallet.sendTransaction({
        to: L2_GATEWAY_ADDRESS,
        data: "0x",
        gasLimit: 500000,
        gasPrice: l2GasPrice,
      });

      console.log(`[Keeper] Redeem tx sent: ${tx.hash} for retryable #${ticketId}`);
      await tx.wait();
      state.status = "redeemed";
      console.log(`[Keeper] Retryable #${ticketId} redeemed successfully`);
    } catch (err: any) {
      state.attempts++;
      state.lastAttempt = Date.now();
      console.error(`[Keeper] Redeem failed for #${ticketId}: ${err.message}`);

      if (err.message?.includes("expired")) {
        state.status = "expired";
      }
    }
  }

  getStatus(): Map<number, RetryableState> {
    return new Map(this.retryables);
  }
}

export { RetryableKeeper };
export type { RetryableState };

if (import.meta.url === `file://${process.argv[1]}`) {
  const keeper = new RetryableKeeper();
  keeper.start();

  process.on("SIGINT", () => {
    keeper.stop();
    process.exit(0);
  });
}
