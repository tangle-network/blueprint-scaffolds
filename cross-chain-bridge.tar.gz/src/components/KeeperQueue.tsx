import type { KeeperTask } from '../types';
import { formatTimestamp } from '../lib/format';

interface KeeperQueueProps {
  tasks: KeeperTask[];
  onRun: () => void;
}

export function KeeperQueue({ tasks, onRun }: KeeperQueueProps) {
  return (
    <section className="panel">
      <div className="section-title">
        <h2>Keeper Bot</h2>
        <span>Retryable redemption automation</span>
      </div>
      <button type="button" className="primary-button" onClick={onRun}>
        Run keeper cycle
      </button>
      <div className="keeper-list">
        {tasks.map((task) => (
          <article key={task.id} className="keeper-card">
            <strong>{task.retryableId}</strong>
            <p>{task.status}</p>
            <span>{task.attempts} attempt(s)</span>
            <span>Scheduled {formatTimestamp(task.scheduledFor)}</span>
          </article>
        ))}
      </div>
    </section>
  );
}
