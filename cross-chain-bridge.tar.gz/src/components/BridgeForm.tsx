import { useEffect, useMemo, useState } from 'react';
import clsx from 'clsx';
import { assets } from '../data/assets';
import { estimateFee } from '../lib/bridge';
import type { AssetConfig, BridgeDirection, BridgeRequest, FeeBreakdown } from '../types';

interface BridgeFormProps {
  paused: boolean;
  hourlyUsed: Record<string, number>;
  onSubmit: (request: BridgeRequest) => void;
  onEstimate: (fee: FeeBreakdown) => void;
}

const DEFAULT_SENDER = '0xB8c77482e45F1F44de1745F52C74426C631bDd52';
const DEFAULT_RECIPIENT = '0x35f5d70E7F4dB86fA8E84B2462d953EAb3F27D2A';

export function BridgeForm({ paused, hourlyUsed, onSubmit, onEstimate }: BridgeFormProps) {
  const [assetSymbol, setAssetSymbol] = useState<string>(assets[0].symbol);
  const [direction, setDirection] = useState<BridgeDirection>('L1_TO_L2');
  const [amount, setAmount] = useState<number>(12);
  const [batchCount, setBatchCount] = useState<number>(1);
  const [sender, setSender] = useState<string>(DEFAULT_SENDER);
  const [recipient, setRecipient] = useState<string>(DEFAULT_RECIPIENT);

  const asset = useMemo<AssetConfig>(
    () => assets.find((candidate) => candidate.symbol === assetSymbol) ?? assets[0],
    [assetSymbol]
  );

  const fee = useMemo(() => estimateFee(asset, amount, batchCount), [asset, amount, batchCount]);
  const projectedUsage = (hourlyUsed[asset.symbol] ?? 0) + amount;
  const rateExceeded = projectedUsage > asset.rateLimitPerHour;

  useEffect(() => {
    onEstimate(fee);
  }, [fee, onEstimate]);

  return (
    <section className="panel bridge-form">
      <div className="section-title">
        <h2>Bridge Transfer</h2>
        <span>Lock/release on L1, mint/burn on L2</span>
      </div>
      <div className="segmented">
        {(['L1_TO_L2', 'L2_TO_L1'] as BridgeDirection[]).map((value) => (
          <button
            key={value}
            type="button"
            className={clsx('chip', direction === value && 'chip-active')}
            onClick={() => setDirection(value)}
          >
            {value === 'L1_TO_L2' ? 'Ethereum → Arbitrum' : 'Arbitrum → Ethereum'}
          </button>
        ))}
      </div>
      <div className="form-grid">
        <label>
          Asset
          <select value={assetSymbol} onChange={(event) => setAssetSymbol(event.target.value)}>
            {assets.map((item) => (
              <option key={item.symbol} value={item.symbol}>
                {item.symbol} · {item.kind}
              </option>
            ))}
          </select>
        </label>
        <label>
          Amount
          <input
            type="number"
            min="0"
            step="0.01"
            value={amount}
            onChange={(event) => setAmount(Number(event.target.value))}
          />
        </label>
        <label>
          Batch Size
          <input
            type="number"
            min="1"
            max="25"
            value={batchCount}
            onChange={(event) => setBatchCount(Number(event.target.value))}
          />
        </label>
        <label>
          Sender
          <input value={sender} onChange={(event) => setSender(event.target.value)} />
        </label>
        <label>
          Recipient
          <input value={recipient} onChange={(event) => setRecipient(event.target.value)} />
        </label>
      </div>
      <div className="notice-row">
        <div className={clsx('notice', paused && 'notice-danger')}>
          Gateway pause: <strong>{paused ? 'active' : 'inactive'}</strong>
        </div>
        <div className={clsx('notice', rateExceeded && 'notice-warning')}>
          Hourly usage: <strong>{projectedUsage.toLocaleString()}</strong> /{' '}
          {asset.rateLimitPerHour.toLocaleString()} {asset.symbol}
        </div>
      </div>
      <button
        type="button"
        className="primary-button"
        onClick={() =>
          onSubmit({
            asset,
            amount,
            sender,
            recipient,
            direction,
            batchCount
          })
        }
      >
        Queue transfer
      </button>
    </section>
  );
}
