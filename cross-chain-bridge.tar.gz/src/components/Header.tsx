export function Header() {
  return (
    <header className="hero">
      <div>
        <p className="eyebrow">Ethereum ↔ Arbitrum Native Messaging</p>
        <h1>Canonical bridge operations in one surface.</h1>
      </div>
      <p className="hero-copy">
        Model L1 locks, L2 mints, retryable redemption, outbox release, emergency controls,
        and batch transfer capacity without leaving the dashboard.
      </p>
    </header>
  );
}
