import type { IndexedEvent } from '../types';
import { formatTimestamp } from '../lib/format';

interface EventFeedProps {
  events: IndexedEvent[];
}

export function EventFeed({ events }: EventFeedProps) {
  return (
    <section className="panel">
      <div className="section-title">
        <h2>Event Indexer</h2>
        <span>Gateway, inbox, and outbox activity</span>
      </div>
      <div className="event-list">
        {events.map((event) => (
          <article key={event.id} className="event-card">
            <div>
              <strong>{event.event}</strong>
              <p>{event.details}</p>
            </div>
            <div className="event-meta">
              <span>{event.chain}</span>
              <span>{event.txId}</span>
              <span>{formatTimestamp(event.timestamp)}</span>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
