const contracts = [
  {
    name: 'L1 Gateway',
    summary: 'Locks ERC-20/ETH, enforces pause and rate limits, and emits retryable ticket metadata.',
    file: 'contracts/L1Gateway.sol'
  },
  {
    name: 'L2 Gateway',
    summary: 'Mints canonical representations on inbound transfer and burns on withdrawal.',
    file: 'contracts/L2Gateway.sol'
  },
  {
    name: 'Token Registry',
    summary: 'Maps L1 canonical token addresses to their L2 counterparts.',
    file: 'contracts/TokenRegistry.sol'
  }
];

export function ContractPanel() {
  return (
    <section className="panel">
      <div className="section-title">
        <h2>Contract Set</h2>
        <span>Native L1↔L2 messaging endpoints</span>
      </div>
      <div className="contract-grid">
        {contracts.map((contract) => (
          <article key={contract.name} className="contract-card">
            <strong>{contract.name}</strong>
            <p>{contract.summary}</p>
            <span>{contract.file}</span>
          </article>
        ))}
      </div>
    </section>
  );
}
