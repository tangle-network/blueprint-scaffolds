import clsx from 'clsx';
import type { BridgeTransaction } from '../types';
import { formatCurrency, formatTimestamp, shortenAddress } from '../lib/format';

interface TrackerProps {
  transactions: BridgeTransaction[];
}

export function Tracker({ transactions }: TrackerProps) {
  return (
    <section className="panel">
      <div className="section-title">
        <h2>Transaction Tracker</h2>
        <span>Retryables, outbox queue, completion state</span>
      </div>
      <div className="tracker-list">
        {transactions.map((transaction) => (
          <article key={transaction.id} className="tracker-card">
            <div className="tracker-top">
              <div>
                <strong>{transaction.id}</strong>
                <p>
                  {transaction.asset} · {transaction.direction === 'L1_TO_L2' ? 'L1 → L2' : 'L2 → L1'}
                </p>
              </div>
              <span className={clsx('status-pill', `status-${transaction.status.toLowerCase()}`)}>
                {transaction.status.split('_').join(' ')}
              </span>
            </div>
            <div className="tracker-meta">
              <span>{transaction.amount.toLocaleString()} units</span>
              <span>{formatCurrency(transaction.fee.total)} fees</span>
              <span>{formatTimestamp(transaction.createdAt)}</span>
              <span>{shortenAddress(transaction.sender)} → {shortenAddress(transaction.recipient)}</span>
            </div>
            <div className="tracker-notes">
              {transaction.notes.map((note) => (
                <p key={note}>{note}</p>
              ))}
              {transaction.retryableId && <p>Retryable: {transaction.retryableId}</p>}
              {transaction.outboxReadyAt && <p>Outbox ready: {formatTimestamp(transaction.outboxReadyAt)}</p>}
              {transaction.batchId && <p>Batch: {transaction.batchId}</p>}
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
