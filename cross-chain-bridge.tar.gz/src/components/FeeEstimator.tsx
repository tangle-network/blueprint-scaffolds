import type { FeeBreakdown } from '../types';
import { formatCurrency } from '../lib/format';

interface FeeEstimatorProps {
  fee: FeeBreakdown;
}

export function FeeEstimator({ fee }: FeeEstimatorProps) {
  return (
    <section className="panel">
      <div className="section-title">
        <h2>Fee Estimator</h2>
        <span>Retryable + outbox costs</span>
      </div>
      <div className="fee-grid">
        <div>
          <label>Submission</label>
          <strong>{formatCurrency(fee.submissionCost)}</strong>
        </div>
        <div>
          <label>Execution</label>
          <strong>{formatCurrency(fee.executionCost)}</strong>
        </div>
        <div>
          <label>L1 Gas</label>
          <strong>{formatCurrency(fee.l1GasCost)}</strong>
        </div>
        <div>
          <label>Challenge Reserve</label>
          <strong>{formatCurrency(fee.challengeReserve)}</strong>
        </div>
      </div>
      <div className="fee-total">
        <span>Total projected spend</span>
        <strong>{formatCurrency(fee.total)}</strong>
      </div>
    </section>
  );
}
