import clsx from 'clsx';
import { assets } from '../data/assets';
import { formatCompactNumber } from '../lib/format';

interface ControlPanelProps {
  paused: boolean;
  hourlyUsed: Record<string, number>;
  onTogglePause: () => void;
}

export function ControlPanel({ paused, hourlyUsed, onTogglePause }: ControlPanelProps) {
  return (
    <section className="panel">
      <div className="section-title">
        <h2>Emergency Controls</h2>
        <span>Pause + hourly rate buckets</span>
      </div>
      <button
        type="button"
        className={clsx('primary-button', paused && 'danger-button')}
        onClick={onTogglePause}
      >
        {paused ? 'Resume gateway' : 'Pause gateway'}
      </button>
      <div className="rate-grid">
        {assets.map((asset) => {
          const used = hourlyUsed[asset.symbol] ?? 0;
          const pct = Math.min(100, (used / asset.rateLimitPerHour) * 100);
          return (
            <div key={asset.symbol} className="rate-card">
              <div className="rate-card-header">
                <strong>{asset.symbol}</strong>
                <span>{formatCompactNumber(asset.rateLimitPerHour)}/hr</span>
              </div>
              <div className="meter">
                <div style={{ width: `${pct}%` }} />
              </div>
              <p>{formatCompactNumber(used)} consumed this hour</p>
            </div>
          );
        })}
      </div>
    </section>
  );
}
