import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from 'recharts';
import { assets } from '../data/assets';

export function LiquidityChart() {
  return (
    <section className="panel chart-panel">
      <div className="section-title">
        <h2>Bridge Liquidity</h2>
        <span>L1 reserves vs L2 canonical float</span>
      </div>
      <div className="chart-wrap">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={assets}>
            <CartesianGrid strokeDasharray="4 4" stroke="rgba(26, 45, 72, 0.12)" />
            <XAxis dataKey="symbol" stroke="#17304d" />
            <YAxis stroke="#17304d" />
            <Tooltip />
            <Legend />
            <Bar dataKey="liquidityOnL1" fill="#17304d" radius={[6, 6, 0, 0]} name="L1 locked" />
            <Bar dataKey="liquidityOnL2" fill="#d66a3d" radius={[6, 6, 0, 0]} name="L2 supply" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </section>
  );
}
