import type { AssetConfig } from '../types';

export const assets: AssetConfig[] = [
  {
    symbol: 'ETH',
    name: 'Ether',
    kind: 'ETH',
    l1Address: '0x0000000000000000000000000000000000000000',
    l2Address: '0x0000000000000000000000000000000000000000',
    decimals: 18,
    rateLimitPerHour: 480,
    liquidityOnL1: 3400,
    liquidityOnL2: 2100
  },
  {
    symbol: 'USDC',
    name: 'USD Coin',
    kind: 'ERC20',
    l1Address: '0xA0b86991c6218b36c1d19d4a2e9eb0ce3606eb48',
    l2Address: '0xaf88d065e77c8cC2239327C5EDb3A432268e5831',
    decimals: 6,
    rateLimitPerHour: 250000,
    liquidityOnL1: 5400000,
    liquidityOnL2: 2900000
  },
  {
    symbol: 'ARB',
    name: 'Arbitrum',
    kind: 'ERC20',
    l1Address: '0x912CE59144191C1204E64559FE8253a0e49E6548',
    l2Address: '0x912CE59144191C1204E64559FE8253a0e49E6548',
    decimals: 18,
    rateLimitPerHour: 900000,
    liquidityOnL1: 1800000,
    liquidityOnL2: 3700000
  }
];
