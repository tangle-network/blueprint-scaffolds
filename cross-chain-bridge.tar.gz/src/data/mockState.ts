import type { BridgeControls, BridgeTransaction, IndexedEvent, KeeperTask } from '../types';

export const initialControls: BridgeControls = {
  paused: false,
  hourlyUsed: {
    ETH: 126,
    USDC: 96000,
    ARB: 312000
  }
};

export const initialTransactions: BridgeTransaction[] = [
  {
    id: 'BRG-1001',
    asset: 'ETH',
    amount: 12.4,
    sender: '0x8dA6bf26964aF9D7eEd9e03E53415D37aA96045B',
    recipient: '0x19E7E376E7C213B7E7E7E46CC70A5DD086DAFF2A',
    direction: 'L1_TO_L2',
    status: 'RETRYABLE_PENDING',
    createdAt: '2025-03-25T10:14:00Z',
    messageId: 'msg-eth-1001',
    retryableId: 'rt-1001',
    fee: {
      submissionCost: 2.1,
      executionCost: 0.6,
      l1GasCost: 8.2,
      challengeReserve: 0,
      total: 10.9
    },
    notes: ['Retryable ticket funded on L1', 'Keeper will redeem automatically on Arbitrum']
  },
  {
    id: 'BRG-1002',
    asset: 'USDC',
    amount: 240000,
    sender: '0x742d35Cc6634C0532925a3b844Bc454e4438f44e',
    recipient: '0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC',
    direction: 'L2_TO_L1',
    status: 'CHALLENGE_PERIOD',
    createdAt: '2025-03-21T08:00:00Z',
    messageId: 'msg-usdc-1002',
    outboxReadyAt: '2025-03-28T08:00:00Z',
    fee: {
      submissionCost: 0.7,
      executionCost: 0.5,
      l1GasCost: 5.8,
      challengeReserve: 1.4,
      total: 8.4
    },
    notes: ['Withdrawal burned canonical L2 token', 'Outbox execution available after the fraud proof window']
  },
  {
    id: 'BRG-1003',
    asset: 'ARB',
    amount: 85000,
    sender: '0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266',
    recipient: '0x90f79bf6eb2c4f870365e785982e1f101e93b906',
    direction: 'L1_TO_L2',
    status: 'COMPLETED',
    createdAt: '2025-03-24T16:42:00Z',
    messageId: 'msg-arb-1003',
    retryableId: 'rt-1003',
    batchId: 'batch-11',
    fee: {
      submissionCost: 1.3,
      executionCost: 0.4,
      l1GasCost: 6.1,
      challengeReserve: 0,
      total: 7.8
    },
    notes: ['Batch transfer bundled 4 recipients', 'Redeemed in keeper attempt #1']
  }
];

export const initialEvents: IndexedEvent[] = [
  {
    id: 'evt-1',
    txId: 'BRG-1001',
    event: 'DepositInitiated',
    chain: 'Ethereum',
    timestamp: '2025-03-25T10:14:02Z',
    details: 'ETH deposit locked on L1 Gateway and retryable created.'
  },
  {
    id: 'evt-2',
    txId: 'BRG-1001',
    event: 'RetryableTicketScheduled',
    chain: 'Ethereum',
    timestamp: '2025-03-25T10:14:08Z',
    details: 'Keeper scheduled auto-redeem for ticket rt-1001.'
  },
  {
    id: 'evt-3',
    txId: 'BRG-1002',
    event: 'WithdrawalInitiated',
    chain: 'Arbitrum',
    timestamp: '2025-03-21T08:00:09Z',
    details: 'Canonical token burned on L2 Gateway.'
  },
  {
    id: 'evt-4',
    txId: 'BRG-1002',
    event: 'OutboxCountdown',
    chain: 'Arbitrum',
    timestamp: '2025-03-25T12:30:00Z',
    details: 'Four days remain before outbox execution can be finalized on L1.'
  }
];

export const initialKeeperTasks: KeeperTask[] = [
  {
    id: 'keeper-1',
    retryableId: 'rt-1001',
    scheduledFor: '2025-03-25T10:16:00Z',
    attempts: 0,
    status: 'PENDING'
  },
  {
    id: 'keeper-2',
    retryableId: 'rt-1003',
    scheduledFor: '2025-03-24T16:45:00Z',
    attempts: 1,
    status: 'EXECUTED'
  }
];
