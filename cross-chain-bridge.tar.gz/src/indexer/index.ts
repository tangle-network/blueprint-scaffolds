import { ethers } from "ethers";
import {
  L1_RPC_URL,
  L2_RPC_URL,
  L1_GATEWAY_ADDRESS,
  L2_GATEWAY_ADDRESS,
  L1_GATEWAY_ABI,
  L2_GATEWAY_ABI,
  INDEXER_POLL_INTERVAL_MS,
} from "../frontend/src/lib/config";
import { BridgeTransaction, BridgeTxStatus } from "../frontend/src/lib/types";

interface StoredEvent {
  type: string;
  blockNumber: number;
  transactionHash: string;
  data: Record<string, unknown>;
  timestamp: number;
}

class BridgeIndexer {
  private l1Provider: ethers.providers.JsonRpcProvider;
  private l2Provider: ethers.providers.JsonRpcProvider;
  private l1Gateway: ethers.Contract;
  private l2Gateway: ethers.Contract;
  private events: StoredEvent[] = [];
  private l1LastBlock = 0;
  private l2LastBlock = 0;
  private running = false;

  constructor() {
    this.l1Provider = new ethers.providers.JsonRpcProvider(L1_RPC_URL);
    this.l2Provider = new ethers.providers.JsonRpcProvider(L2_RPC_URL);

    this.l1Gateway = new ethers.Contract(L1_GATEWAY_ADDRESS, L1_GATEWAY_ABI, this.l1Provider);
    this.l2Gateway = new ethers.Contract(L2_GATEWAY_ADDRESS, L2_GATEWAY_ABI, this.l2Provider);
  }

  async start() {
    this.running = true;
    console.log("[Indexer] Starting bridge event indexer...");
    console.log(`[Indexer] L1 RPC: ${L1_RPC_URL}`);
    console.log(`[Indexer] L2 RPC: ${L2_RPC_URL}`);

    try {
      this.l1LastBlock = await this.l1Provider.getBlockNumber();
      this.l2LastBlock = await this.l2Provider.getBlockNumber();
    } catch (err) {
      console.error("[Indexer] Failed to get initial block numbers:", err);
    }

    while (this.running) {
      try {
        await this.indexL1Events();
        await this.indexL2Events();
      } catch (err) {
        console.error("[Indexer] Indexing error:", err);
      }

      await new Promise((resolve) => setTimeout(resolve, INDEXER_POLL_INTERVAL_MS));
    }
  }

  stop() {
    this.running = false;
    console.log("[Indexer] Stopped.");
  }

  private async indexL1Events() {
    const currentBlock = await this.l1Provider.getBlockNumber();
    if (currentBlock <= this.l1LastBlock) return;

    const fromBlock = this.l1LastBlock + 1;
    const toBlock = Math.min(fromBlock + 1000, currentBlock);

    const depositEvents = await this.l1Gateway.queryFilter(
      this.l1Gateway.filters.DepositInitiated(),
      fromBlock,
      toBlock
    );

    for (const event of depositEvents) {
      const stored: StoredEvent = {
        type: "DepositInitiated",
        blockNumber: event.blockNumber,
        transactionHash: event.transactionHash,
        data: {
          l1Token: event.args?.l1Token,
          from: event.args?.from,
          to: event.args?.to,
          amount: event.args?.amount?.toString(),
          ticketId: event.args?.ticketId?.toNumber(),
        },
        timestamp: Date.now(),
      };
      this.events.push(stored);
      console.log(`[Indexer] L1 Deposit: ${stored.data.amount} tokens -> ${stored.data.to} (ticket: ${stored.data.ticketId})`);
    }

    const withdrawalEvents = await this.l1Gateway.queryFilter(
      this.l1Gateway.filters.WithdrawalFinalized(),
      fromBlock,
      toBlock
    );

    for (const event of withdrawalEvents) {
      const stored: StoredEvent = {
        type: "WithdrawalFinalized",
        blockNumber: event.blockNumber,
        transactionHash: event.transactionHash,
        data: {
          l1Token: event.args?.l1Token,
          to: event.args?.to,
          amount: event.args?.amount?.toString(),
        },
        timestamp: Date.now(),
      };
      this.events.push(stored);
      console.log(`[Indexer] L1 Withdrawal finalized: ${stored.data.amount} -> ${stored.data.to}`);
    }

    this.l1LastBlock = toBlock;
  }

  private async indexL2Events() {
    const currentBlock = await this.l2Provider.getBlockNumber();
    if (currentBlock <= this.l2LastBlock) return;

    const fromBlock = this.l2LastBlock + 1;
    const toBlock = Math.min(fromBlock + 1000, currentBlock);

    const mintEvents = await this.l2Gateway.queryFilter(
      this.l2Gateway.filters.MintOnL2(),
      fromBlock,
      toBlock
    );

    for (const event of mintEvents) {
      const stored: StoredEvent = {
        type: "MintOnL2",
        blockNumber: event.blockNumber,
        transactionHash: event.transactionHash,
        data: {
          l2Token: event.args?.l2Token,
          to: event.args?.to,
          amount: event.args?.amount?.toString(),
          ticketId: event.args?.ticketId?.toNumber(),
        },
        timestamp: Date.now(),
      };
      this.events.push(stored);
      console.log(`[Indexer] L2 Mint: ${stored.data.amount} tokens -> ${stored.data.to}`);
    }

    const withdrawalEvents = await this.l2Gateway.queryFilter(
      this.l2Gateway.filters.WithdrawalInitiated(),
      fromBlock,
      toBlock
    );

    for (const event of withdrawalEvents) {
      const stored: StoredEvent = {
        type: "WithdrawalInitiated",
        blockNumber: event.blockNumber,
        transactionHash: event.transactionHash,
        data: {
          l2Token: event.args?.l2Token,
          from: event.args?.from,
          to: event.args?.to,
          amount: event.args?.amount?.toString(),
        },
        timestamp: Date.now(),
      };
      this.events.push(stored);
      console.log(`[Indexer] L2 Withdrawal initiated: ${stored.data.amount} from ${stored.data.from}`);
    }

    this.l2LastBlock = toBlock;
  }

  getEvents(type?: string): StoredEvent[] {
    if (type) return this.events.filter((e) => e.type === type);
    return [...this.events];
  }
}

export { BridgeIndexer };
export type { StoredEvent };

if (import.meta.url === `file://${process.argv[1]}`) {
  const indexer = new BridgeIndexer();
  indexer.start();

  process.on("SIGINT", () => {
    indexer.stop();
    process.exit(0);
  });
}
