export type Chain = 'Ethereum' | 'Arbitrum';
export type AssetKind = 'ETH' | 'ERC20';
export type BridgeDirection = 'L1_TO_L2' | 'L2_TO_L1';
export type TransactionStatus =
  | 'QUEUED'
  | 'SUBMITTED'
  | 'RETRYABLE_PENDING'
  | 'EXECUTED'
  | 'CHALLENGE_PERIOD'
  | 'READY_FOR_OUTBOX'
  | 'COMPLETED'
  | 'BLOCKED';

export interface AssetConfig {
  symbol: string;
  name: string;
  kind: AssetKind;
  l1Address: string;
  l2Address: string;
  decimals: number;
  rateLimitPerHour: number;
  liquidityOnL1: number;
  liquidityOnL2: number;
}

export interface FeeBreakdown {
  submissionCost: number;
  executionCost: number;
  l1GasCost: number;
  challengeReserve: number;
  total: number;
}

export interface BridgeTransaction {
  id: string;
  asset: string;
  amount: number;
  sender: string;
  recipient: string;
  direction: BridgeDirection;
  status: TransactionStatus;
  createdAt: string;
  messageId: string;
  retryableId?: string;
  batchId?: string;
  outboxReadyAt?: string;
  fee: FeeBreakdown;
  notes: string[];
}

export interface BridgeControls {
  paused: boolean;
  hourlyUsed: Record<string, number>;
}

export interface BridgeRequest {
  asset: AssetConfig;
  amount: number;
  sender: string;
  recipient: string;
  direction: BridgeDirection;
  batchCount: number;
}

export interface IndexedEvent {
  id: string;
  txId: string;
  event: string;
  chain: Chain;
  timestamp: string;
  details: string;
}

export interface KeeperTask {
  id: string;
  retryableId: string;
  scheduledFor: string;
  attempts: number;
  status: 'PENDING' | 'EXECUTED' | 'FAILED';
}
