import type { BridgeTransaction, IndexedEvent } from '../types';

export class EventIndexer {
  private readonly events: IndexedEvent[];

  constructor(seed: IndexedEvent[]) {
    this.events = [...seed].sort((a, b) => b.timestamp.localeCompare(a.timestamp));
  }

  ingest(transaction: BridgeTransaction, incoming: IndexedEvent[]): IndexedEvent[] {
    this.events.unshift(
      ...incoming.map((event) => ({
        ...event,
        details: `${event.details} [tracked:${transaction.messageId}]`
      }))
    );
    this.events.sort((a, b) => b.timestamp.localeCompare(a.timestamp));
    return this.snapshot();
  }

  snapshot(): IndexedEvent[] {
    return [...this.events];
  }
}
