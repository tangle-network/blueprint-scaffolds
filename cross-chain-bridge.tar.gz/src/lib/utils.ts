import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export type Network = 'ethereum' | 'arbitrum'

export type BridgeDirection = 'l1-to-l2' | 'l2-to-l1'

export type TokenType = 'ETH' | 'ERC-20'

export type TxStatus =
  | 'pending'
  | 'confirming'
  | 'confirmed'
  | 'executing'
  | 'completed'
  | 'failed'
  | 'challenge-period'

export interface TokenInfo {
  symbol: string
  name: string
  decimals: number
  address: string
  l2Address?: string
  type: TokenType
}

export interface BridgeTransaction {
  id: string
  direction: BridgeDirection
  token: TokenInfo
  amount: string
  sender: string
  recipient: string
  status: TxStatus
  l1TxHash?: string
  l2TxHash?: string
  retryableTicketId?: string
  outboxEntryIndex?: number
  createdAt: number
  estimatedCompletion?: number
  challengePeriodEnd?: number
}

export interface FeeEstimate {
  l1Gas: string
  l2Gas: string
  submissionCost: string
  totalEstimate: string
}

export const SUPPORTED_TOKENS: TokenInfo[] = [
  {
    symbol: 'ETH',
    name: 'Ether',
    decimals: 18,
    address: '0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE',
    type: 'ETH',
  },
  {
    symbol: 'USDC',
    name: 'USD Coin',
    decimals: 6,
    address: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
    l2Address: '0xFF970A61A04b1cA14834A43f5dE4533eBDDB5CC8',
    type: 'ERC-20',
  },
  {
    symbol: 'USDT',
    name: 'Tether USD',
    decimals: 6,
    address: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
    l2Address: '0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9',
    type: 'ERC-20',
  },
  {
    symbol: 'WBTC',
    name: 'Wrapped BTC',
    decimals: 8,
    address: '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599',
    l2Address: '0x2f2a2543B76A4166549F7aaB2e75Bef0aefC5B0f',
    type: 'ERC-20',
  },
  {
    symbol: 'ARB',
    name: 'Arbitrum',
    decimals: 18,
    address: '0xB50721BCf8d664c30412Cfbc6cf7a15145234ad1',
    l2Address: '0x912CE59144191C1204E64559FE8253a0e49E6548',
    type: 'ERC-20',
  },
]

export const CHALLENGE_PERIOD_MS = 7 * 24 * 60 * 60 * 1000

export const RATE_LIMIT_WINDOW_MS = 60 * 60 * 1000
export const RATE_LIMIT_MAX_TRANSFERS = 10
export const RATE_LIMIT_MAX_AMOUNT = 1000000
