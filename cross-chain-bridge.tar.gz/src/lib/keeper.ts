import type { BridgeTransaction, KeeperTask } from '../types';

export function runKeeper(tasks: KeeperTask[], transactions: BridgeTransaction[]): {
  tasks: KeeperTask[];
  transactions: BridgeTransaction[];
} {
  const now = Date.now();

  const updatedTasks = tasks.map((task) => {
    if (task.status !== 'PENDING') {
      return task;
    }

    const isDue = new Date(task.scheduledFor).getTime() <= now;
    if (!isDue) {
      return task;
    }

    return {
      ...task,
      attempts: task.attempts + 1,
      status: 'EXECUTED' as const
    };
  });

  const executedRetryables = new Set(
    updatedTasks.filter((task) => task.status === 'EXECUTED').map((task) => task.retryableId)
  );

  const updatedTransactions = transactions.map((transaction) => {
    if (!transaction.retryableId || !executedRetryables.has(transaction.retryableId)) {
      return transaction;
    }

    return {
      ...transaction,
      status: 'COMPLETED' as const,
      notes: [...transaction.notes, 'Retryable redeemed by keeper and finalized on L2.']
    };
  });

  return {
    tasks: updatedTasks,
    transactions: updatedTransactions
  };
}
