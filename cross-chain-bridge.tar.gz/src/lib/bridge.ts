import { addDays, addMinutes } from 'date-fns';
import type {
  AssetConfig,
  BridgeControls,
  BridgeRequest,
  BridgeTransaction,
  FeeBreakdown,
  IndexedEvent,
  KeeperTask,
  TransactionStatus
} from '../types';

function computeFee(asset: AssetConfig, amount: number, batchCount: number): FeeBreakdown {
  const volumeFactor = Math.max(1, amount / Math.max(asset.rateLimitPerHour / 12, 1));
  const submissionCost = Number((1.15 + batchCount * 0.22).toFixed(2));
  const executionCost = Number((0.45 + volumeFactor * 0.18).toFixed(2));
  const l1GasCost = Number((5.2 + batchCount * 0.55 + volumeFactor * 0.35).toFixed(2));
  const challengeReserve = asset.kind === 'ETH' ? 0 : Number((0.85 + amount * 0.00001).toFixed(2));
  const total = Number((submissionCost + executionCost + l1GasCost + challengeReserve).toFixed(2));

  return {
    submissionCost,
    executionCost,
    l1GasCost,
    challengeReserve,
    total
  };
}

export function estimateFee(asset: AssetConfig, amount: number, batchCount: number): FeeBreakdown {
  return computeFee(asset, amount, batchCount);
}

export function createBridgeFlow(
  request: BridgeRequest,
  controls: BridgeControls
): {
  transaction: BridgeTransaction;
  events: IndexedEvent[];
  keeperTask?: KeeperTask;
  nextControls: BridgeControls;
} {
  const assetUsed = controls.hourlyUsed[request.asset.symbol] ?? 0;
  const nextUsed = assetUsed + request.amount;
  const blockedByPause = controls.paused;
  const blockedByRateLimit = nextUsed > request.asset.rateLimitPerHour;
  const now = new Date();
  const fee = computeFee(request.asset, request.amount, request.batchCount);
  const txId = `BRG-${Math.floor(now.getTime() / 1000)}`;
  const messageId = `msg-${request.asset.symbol.toLowerCase()}-${now.getTime()}`;
  const retryableId = request.direction === 'L1_TO_L2' ? `rt-${now.getTime()}` : undefined;
  const batchId = request.batchCount > 1 ? `batch-${now.getTime()}` : undefined;
  const status: TransactionStatus = blockedByPause || blockedByRateLimit
    ? 'BLOCKED'
    : request.direction === 'L1_TO_L2'
      ? 'RETRYABLE_PENDING'
      : 'CHALLENGE_PERIOD';

  const notes = blockedByPause
    ? ['Emergency pause is active on the gateway.']
    : blockedByRateLimit
      ? [`Rate limit exceeded for ${request.asset.symbol}.`]
      : request.direction === 'L1_TO_L2'
        ? ['Retryable ticket created on L1 inbox.', 'Keeper will redeem on Arbitrum.']
        : ['Withdrawal burned on L2.', 'Funds release after the 7-day outbox challenge window.'];

  const transaction: BridgeTransaction = {
    id: txId,
    asset: request.asset.symbol,
    amount: request.amount,
    sender: request.sender,
    recipient: request.recipient,
    direction: request.direction,
    status,
    createdAt: now.toISOString(),
    messageId,
    retryableId,
    batchId,
    outboxReadyAt: request.direction === 'L2_TO_L1' ? addDays(now, 7).toISOString() : undefined,
    fee,
    notes
  };

  const events: IndexedEvent[] = [
    {
      id: `${txId}-1`,
      txId,
      event: request.direction === 'L1_TO_L2' ? 'DepositInitiated' : 'WithdrawalInitiated',
      chain: request.direction === 'L1_TO_L2' ? 'Ethereum' : 'Arbitrum',
      timestamp: now.toISOString(),
      details:
        request.direction === 'L1_TO_L2'
          ? `${request.asset.symbol} locked on L1 Gateway and retryable posted to the inbox.`
          : `${request.asset.symbol} burned on L2 Gateway and pending outbox proof.`
    }
  ];

  let keeperTask: KeeperTask | undefined;

  if (!blockedByPause && !blockedByRateLimit && request.direction === 'L1_TO_L2' && retryableId) {
    const scheduledFor = addMinutes(now, 2).toISOString();
    events.push({
      id: `${txId}-2`,
      txId,
      event: 'RetryableScheduled',
      chain: 'Ethereum',
      timestamp: now.toISOString(),
      details: `Keeper queued redemption for retryable ${retryableId}.`
    });
    keeperTask = {
      id: `keeper-${now.getTime()}`,
      retryableId,
      scheduledFor,
      attempts: 0,
      status: 'PENDING'
    };
  }

  if (!blockedByPause && !blockedByRateLimit && request.direction === 'L2_TO_L1') {
    events.push({
      id: `${txId}-2`,
      txId,
      event: 'OutboxReadyAt',
      chain: 'Arbitrum',
      timestamp: addDays(now, 7).toISOString(),
      details: 'Outbox execution unlocks after the fraud proof period.'
    });
  }

  return {
    transaction,
    events,
    keeperTask,
    nextControls: {
      ...controls,
      hourlyUsed: blockedByPause || blockedByRateLimit
        ? controls.hourlyUsed
        : {
            ...controls.hourlyUsed,
            [request.asset.symbol]: nextUsed
          }
    }
  };
}
