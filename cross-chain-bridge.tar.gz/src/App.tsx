import { useMemo, useState } from 'react';
import { BridgeForm } from './components/BridgeForm';
import { ContractPanel } from './components/ContractPanel';
import { ControlPanel } from './components/ControlPanel';
import { EventFeed } from './components/EventFeed';
import { FeeEstimator } from './components/FeeEstimator';
import { Header } from './components/Header';
import { KeeperQueue } from './components/KeeperQueue';
import { LiquidityChart } from './components/LiquidityChart';
import { StatCard } from './components/StatCard';
import { Tracker } from './components/Tracker';
import { initialControls, initialEvents, initialKeeperTasks, initialTransactions } from './data/mockState';
import { createBridgeFlow, estimateFee } from './lib/bridge';
import { EventIndexer } from './lib/indexer';
import { runKeeper } from './lib/keeper';
import { formatCompactNumber } from './lib/format';
import type { BridgeRequest, FeeBreakdown } from './types';

const indexer = new EventIndexer(initialEvents);

function App() {
  const [controls, setControls] = useState(initialControls);
  const [transactions, setTransactions] = useState(initialTransactions);
  const [events, setEvents] = useState(indexer.snapshot());
  const [keeperTasks, setKeeperTasks] = useState(initialKeeperTasks);
  const [feeEstimate, setFeeEstimate] = useState<FeeBreakdown>(estimateFee({
    symbol: 'ETH',
    name: 'Ether',
    kind: 'ETH',
    l1Address: '0x0000000000000000000000000000000000000000',
    l2Address: '0x0000000000000000000000000000000000000000',
    decimals: 18,
    rateLimitPerHour: 480,
    liquidityOnL1: 3400,
    liquidityOnL2: 2100
  }, 12, 1));

  const stats = useMemo(() => {
    const pendingRetryables = transactions.filter((tx) => tx.status === 'RETRYABLE_PENDING').length;
    const waitingOutbox = transactions.filter((tx) => tx.status === 'CHALLENGE_PERIOD').length;
    const batchedVolume = transactions
      .filter((tx) => tx.batchId)
      .reduce((sum, tx) => sum + tx.amount, 0);

    return [
      {
        label: 'Pending retryables',
        value: String(pendingRetryables),
        detail: 'Tickets waiting for keeper execution'
      },
      {
        label: 'Outbox exits',
        value: String(waitingOutbox),
        detail: 'Withdrawals still in challenge window'
      },
      {
        label: 'Batched volume',
        value: formatCompactNumber(batchedVolume),
        detail: 'Value moved via multi-recipient submission'
      }
    ];
  }, [transactions]);

  function handleBridgeSubmit(request: BridgeRequest) {
    const flow = createBridgeFlow(request, controls);
    setControls(flow.nextControls);
    setTransactions((current) => [flow.transaction, ...current]);
    setEvents(indexer.ingest(flow.transaction, flow.events));
    if (flow.keeperTask) {
      setKeeperTasks((current) => [flow.keeperTask!, ...current]);
    }
  }

  function handleKeeperRun() {
    const result = runKeeper(keeperTasks, transactions);
    setKeeperTasks(result.tasks);
    setTransactions(result.transactions);
  }

  return (
    <div className="app-shell">
      <Header />
      <section className="stats-grid">
        {stats.map((stat) => (
          <StatCard key={stat.label} {...stat} />
        ))}
      </section>
      <section className="main-grid">
        <BridgeForm
          paused={controls.paused}
          hourlyUsed={controls.hourlyUsed}
          onSubmit={handleBridgeSubmit}
          onEstimate={setFeeEstimate}
        />
        <FeeEstimator fee={feeEstimate} />
      </section>
      <section className="main-grid">
        <ControlPanel
          paused={controls.paused}
          hourlyUsed={controls.hourlyUsed}
          onTogglePause={() => setControls((current) => ({ ...current, paused: !current.paused }))}
        />
        <LiquidityChart />
      </section>
      <Tracker transactions={transactions} />
      <section className="main-grid">
        <EventFeed events={events} />
        <KeeperQueue tasks={keeperTasks} onRun={handleKeeperRun} />
      </section>
      <ContractPanel />
    </div>
  );
}

export default App;
