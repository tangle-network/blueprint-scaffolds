pragma solidity ^0.8.20;

import "@openzeppelin/contracts/access/Ownable.sol";
import "./interfaces/ITokenRegistry.sol";

contract TokenRegistry is ITokenRegistry, Ownable {
    mapping(address => TokenInfo) public l1ToL2;
    mapping(address => address) public l2ToL1;
    address[] public registeredTokens;

    uint256 public constant DEFAULT_DAILY_LIMIT = 1_000_000e18;

    function registerToken(
        address l1Token,
        address l2Token,
        uint256 dailyLimit
    ) external override onlyOwner {
        require(l1Token != address(0) && l2Token != address(0), "Zero address");
        require(!l1ToL2[l1Token].isRegistered, "Already registered");

        if (dailyLimit == 0) dailyLimit = DEFAULT_DAILY_LIMIT;

        l1ToL2[l1Token] = TokenInfo({
            l1Token: l1Token,
            l2Token: l2Token,
            isRegistered: true,
            dailyLimit: dailyLimit,
            usedToday: 0,
            lastResetDay: _currentDay()
        });
        l2ToL1[l2Token] = l1Token;
        registeredTokens.push(l1Token);

        emit TokenRegistered(l1Token, l2Token, dailyLimit);
    }

    function deregisterToken(address l1Token) external override onlyOwner {
        require(l1ToL2[l1Token].isRegistered, "Not registered");

        address l2Token = l1ToL2[l1Token].l2Token;
        l1ToL2[l1Token].isRegistered = false;
        delete l2ToL1[l2Token];

        emit TokenDeregistered(l1Token, l2Token);
    }

    function getL2Token(address l1Token) external view override returns (address) {
        require(l1ToL2[l1Token].isRegistered, "Not registered");
        return l1ToL2[l1Token].l2Token;
    }

    function getL1Token(address l2Token) external view override returns (address) {
        address l1 = l2ToL1[l2Token];
        require(l1 != address(0), "Not registered");
        return l1;
    }

    function isRegistered(address l1Token) external view override returns (bool) {
        return l1ToL2[l1Token].isRegistered;
    }

    function checkAndUpdateLimit(address l1Token, uint256 amount) external override returns (bool) {
        require(l1ToL2[l1Token].isRegistered, "Not registered");
        TokenInfo storage info = l1ToL2[l1Token];

        uint256 today = _currentDay();
        if (info.lastResetDay < today) {
            info.usedToday = 0;
            info.lastResetDay = today;
        }

        if (info.usedToday + amount > info.dailyLimit) {
            return false;
        }

        info.usedToday += amount;
        return true;
    }

    function updateDailyLimit(address l1Token, uint256 newLimit) external override onlyOwner {
        require(l1ToL2[l1Token].isRegistered, "Not registered");
        l1ToL2[l1Token].dailyLimit = newLimit;
        emit DailyLimitUpdated(l1Token, newLimit);
    }

    function getRegisteredCount() external view returns (uint256) {
        return registeredTokens.length;
    }

    function _currentDay() internal view returns (uint256) {
        return block.timestamp / 1 days;
    }
}
