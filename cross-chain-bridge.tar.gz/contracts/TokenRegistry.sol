// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

contract TokenRegistry {
    address public owner;

    struct TokenInfo {
        address l1Address;
        address l2Address;
        bool isRegistered;
        uint8 decimals;
        string symbol;
        string name;
    }

    mapping(address => TokenInfo) public l1Tokens;
    mapping(address => address) public l2ToL1;
    address[] public registeredTokens;

    event TokenRegistered(
        address indexed l1Token,
        address indexed l2Token,
        string symbol,
        string name
    );

    event TokenDeregistered(address indexed l1Token);

    modifier onlyOwner() {
        require(msg.sender == owner, "TokenRegistry: not owner");
        _;
    }

    constructor() {
        owner = msg.sender;
    }

    function registerToken(
        address l1Token,
        address l2Token,
        uint8 decimals,
        string calldata symbol,
        string calldata name
    ) external onlyOwner {
        require(!l1Tokens[l1Token].isRegistered, "TokenRegistry: already registered");
        require(l2ToL1[l2Token] == address(0), "TokenRegistry: L2 token taken");

        l1Tokens[l1Token] = TokenInfo({
            l1Address: l1Token,
            l2Address: l2Token,
            isRegistered: true,
            decimals: decimals,
            symbol: symbol,
            name: name
        });

        l2ToL1[l2Token] = l1Token;
        registeredTokens.push(l1Token);

        emit TokenRegistered(l1Token, l2Token, symbol, name);
    }

    function deregisterToken(address l1Token) external onlyOwner {
        require(l1Tokens[l1Token].isRegistered, "TokenRegistry: not registered");

        address l2Token = l1Tokens[l1Token].l2Address;
        l2ToL1[l2Token] = address(0);
        l1Tokens[l1Token].isRegistered = false;

        for (uint256 i = 0; i < registeredTokens.length; i++) {
            if (registeredTokens[i] == l1Token) {
                registeredTokens[i] = registeredTokens[registeredTokens.length - 1];
                registeredTokens.pop();
                break;
            }
        }

        emit TokenDeregistered(l1Token);
    }

    function getL2Token(address l1Token) external view returns (address) {
        require(l1Tokens[l1Token].isRegistered, "TokenRegistry: not registered");
        return l1Tokens[l1Token].l2Address;
    }

    function getL1Token(address l2Token) external view returns (address) {
        address l1 = l2ToL1[l2Token];
        require(l1 != address(0), "TokenRegistry: not registered");
        return l1;
    }

    function getTokenInfo(address l1Token) external view returns (TokenInfo memory) {
        return l1Tokens[l1Token];
    }

    function getRegisteredTokenCount() external view returns (uint256) {
        return registeredTokens.length;
    }

    function getAllRegisteredTokens() external view returns (address[] memory) {
        return registeredTokens;
    }
}
