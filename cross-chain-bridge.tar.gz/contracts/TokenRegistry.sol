// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract TokenRegistry {
    address public owner;
    mapping(address => address) public l1ToL2Token;
    mapping(address => bool) public isNativeGasToken;

    event TokenRegistered(address indexed l1Token, address indexed l2Token, bool nativeGasToken);

    modifier onlyOwner() {
        require(msg.sender == owner, "ONLY_OWNER");
        _;
    }

    constructor() {
        owner = msg.sender;
    }

    function register(address l1Token, address l2Token, bool nativeGasToken) external onlyOwner {
        l1ToL2Token[l1Token] = l2Token;
        isNativeGasToken[l1Token] = nativeGasToken;
        emit TokenRegistered(l1Token, l2Token, nativeGasToken);
    }
}
