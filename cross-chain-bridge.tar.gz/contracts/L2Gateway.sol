pragma solidity ^0.8.20;

import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/security/ReentrancyGuard.sol";
import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "./interfaces/IL2Gateway.sol";

contract L2Gateway is IL2Gateway, Ownable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    address public l1Gateway;
    mapping(uint256 => bool) public processedTickets;
    mapping(address => bool) public supportedTokens;

    uint256 public constant WITHDRAWAL_L1_GAS = 300_000;

    event TokenSupported(address indexed token, bool supported);
    event L1GatewayUpdated(address indexed newGateway);

    modifier onlyL1Gateway() {
        require(msg.sender == l1Gateway, "Not L1 gateway");
        _;
    }

    function setL1Gateway(address _l1Gateway) external onlyOwner {
        require(_l1Gateway != address(0), "Zero address");
        l1Gateway = _l1Gateway;
        emit L1GatewayUpdated(_l1Gateway);
    }

    function setSupportedToken(address token, bool supported) external onlyOwner {
        supportedTokens[token] = supported;
        emit TokenSupported(token, supported);
    }

    function mint(
        address l2Token,
        address to,
        uint256 amount,
        uint256 ticketId
    ) external override onlyL1Gateway nonReentrant {
        require(!processedTickets[ticketId], "Ticket already processed");
        require(to != address(0), "Zero address");

        processedTickets[ticketId] = true;

        if (l2Token == address(0)) {
            (bool success,) = to.call{value: amount}("");
            require(success, "ETH mint failed");
        } else {
            require(supportedTokens[l2Token], "Token not supported");
            _safeMint(l2Token, to, amount);
        }

        emit MintOnL2(l2Token, to, amount, ticketId);
    }

    function withdrawETH(address to) external payable override nonReentrant {
        require(msg.value > 0, "Zero amount");
        require(to != address(0), "Zero address");

        bytes memory data = abi.encodeWithSelector(
            IL1Gateway.finalizeWithdrawal.selector,
            address(0),
            to,
            msg.value,
            bytes32(0)
        );

        emit WithdrawalInitiated(address(0), msg.sender, to, msg.value);
    }

    function withdrawERC20(
        address l2Token,
        uint256 amount,
        address to
    ) external override nonReentrant {
        require(amount > 0, "Zero amount");
        require(to != address(0), "Zero address");
        require(supportedTokens[l2Token], "Token not supported");

        _safeBurn(l2Token, msg.sender, amount);

        emit WithdrawalInitiated(l2Token, msg.sender, to, amount);
    }

    function withdrawERC20Batch(
        address[] calldata l2Tokens,
        uint256[] calldata amounts,
        address to
    ) external override nonReentrant {
        require(l2Tokens.length == amounts.length, "Length mismatch");
        require(to != address(0), "Zero address");

        for (uint256 i = 0; i < l2Tokens.length; i++) {
            require(amounts[i] > 0, "Zero amount");
            require(supportedTokens[l2Tokens[i]], "Token not supported");

            _safeBurn(l2Tokens[i], msg.sender, amounts[i]);
            emit WithdrawalInitiated(l2Tokens[i], msg.sender, to, amounts[i]);
        }
    }

    function burn(address l2Token, uint256 amount) external override {
        require(amount > 0, "Zero amount");
        require(supportedTokens[l2Token], "Token not supported");
        _safeBurn(l2Token, msg.sender, amount);
    }

    function _safeMint(address token, address to, uint256 amount) internal {
        (bool success, bytes memory data) = token.call(
            abi.encodeWithSelector(IERC20.transfer.selector, to, amount)
        );
        require(success && (data.length == 0 || abi.decode(data, (bool))), "Mint failed");
    }

    function _safeBurn(address token, address from, uint256 amount) internal {
        IERC20(token).safeTransferFrom(from, address(this), amount);
    }

    receive() external payable {}
}
