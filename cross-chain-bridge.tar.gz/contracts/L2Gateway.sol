// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface ITokenRegistry {
    function l1ToL2Token(address token) external view returns (address);
}

contract L2Gateway {
    address public owner;
    address public counterpartGateway;
    bool public paused;
    mapping(address => uint256) public mintedSupply;

    event Minted(address indexed token, address indexed to, uint256 amount, bytes data);
    event Burned(address indexed token, address indexed from, address indexed to, uint256 amount, bytes data);
    event Paused(bool status);

    modifier onlyOwner() {
        require(msg.sender == owner, "ONLY_OWNER");
        _;
    }

    modifier onlyCounterpart() {
        require(msg.sender == counterpartGateway, "ONLY_COUNTERPART");
        _;
    }

    modifier whenNotPaused() {
        require(!paused, "PAUSED");
        _;
    }

    constructor(address _counterpartGateway) {
        owner = msg.sender;
        counterpartGateway = _counterpartGateway;
    }

    function setPaused(bool status) external onlyOwner {
        paused = status;
        emit Paused(status);
    }

    function finalizeInboundTransfer(
        address token,
        address from,
        address to,
        uint256 amount,
        bytes calldata data
    ) external onlyCounterpart whenNotPaused {
        from;
        mintedSupply[token] += amount;
        emit Minted(token, to, amount, data);
    }

    function withdraw(address token, address to, uint256 amount, bytes calldata data) external whenNotPaused {
        mintedSupply[token] -= amount;
        emit Burned(token, msg.sender, to, amount, data);
    }
}
