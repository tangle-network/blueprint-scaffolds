// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

interface IERC20Mintable is IERC20 {
    function mint(address to, uint256 amount) external returns (bool);
    function burn(address from, uint256 amount) external returns (bool);
}

interface IERC20 {
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
    function transfer(address to, uint256 amount) external returns (bool);
    function balanceOf(address account) external view returns (uint256);
}

contract L2Gateway {
    address public owner;
    address public l1Gateway;
    address public tokenRegistry;

    mapping(address => address) public l1ToL2Token;
    mapping(address => uint256) public totalSupply;
    mapping(bytes32 => bool) public processedDeposits;

    uint256 public constant CHALLENGE_PERIOD = 7 days;

    struct Withdrawal {
        address sender;
        address recipient;
        address token;
        uint256 amount;
        uint256 timestamp;
        bool executed;
    }

    Withdrawal[] public withdrawals;

    event DepositFinalized(
        address indexed token,
        address indexed sender,
        address indexed recipient,
        uint256 amount
    );

    event WithdrawalInitiated(
        address indexed token,
        address indexed sender,
        address indexed recipient,
        uint256 amount,
        uint256 withdrawalIndex
    );

    event WithdrawalExecuted(uint256 indexed index);

    modifier onlyOwner() {
        require(msg.sender == owner, "L2Gateway: not owner");
        _;
    }

    modifier onlyL1Gateway() {
        require(msg.sender == l1Gateway, "L2Gateway: only L1 gateway");
        _;
    }

    constructor() {
        owner = msg.sender;
    }

    function setL1Gateway(address _l1Gateway) external onlyOwner {
        l1Gateway = _l1Gateway;
    }

    function setTokenRegistry(address _tokenRegistry) external onlyOwner {
        tokenRegistry = _tokenRegistry;
    }

    function registerToken(address l1Token, address l2Token) external onlyOwner {
        l1ToL2Token[l1Token] = l2Token;
    }

    function finalizeDeposit(
        address l1Token,
        address sender,
        address recipient,
        uint256 amount
    ) external onlyL1Gateway {
        bytes32 depositId = keccak256(abi.encodePacked(l1Token, sender, recipient, amount, block.number));
        require(!processedDeposits[depositId], "L2Gateway: already processed");
        processedDeposits[depositId] = true;

        if (l1Token == address(0)) {
            (bool success, ) = recipient.call{value: amount}("");
            require(success, "L2Gateway: ETH transfer failed");
        } else {
            address l2Token = l1ToL2Token[l1Token];
            require(l2Token != address(0), "L2Gateway: token not registered");
            IERC20Mintable(l2Token).mint(recipient, amount);
            totalSupply[l2Token] += amount;
        }

        emit DepositFinalized(l1Token, sender, recipient, amount);
    }

    function initiateETHWithdrawal(address recipient) external payable {
        require(msg.value > 0, "L2Gateway: zero amount");

        uint256 index = withdrawals.length;
        withdrawals.push(Withdrawal({
            sender: msg.sender,
            recipient: recipient,
            token: address(0),
            amount: msg.value,
            timestamp: block.timestamp,
            executed: false
        }));

        emit WithdrawalInitiated(address(0), msg.sender, recipient, msg.value, index);
    }

    function initiateERC20Withdrawal(address l2Token, address recipient, uint256 amount) external {
        require(amount > 0, "L2Gateway: zero amount");
        require(l1ToL2Token[l2Token] != address(0) || isL2Token(l2Token), "L2Gateway: not bridged");

        IERC20Mintable(l2Token).burn(msg.sender, amount);
        totalSupply[l2Token] -= amount;

        address l1Token = getL1Token(l2Token);
        uint256 index = withdrawals.length;
        withdrawals.push(Withdrawal({
            sender: msg.sender,
            recipient: recipient,
            token: l1Token,
            amount: amount,
            timestamp: block.timestamp,
            executed: false
        }));

        emit WithdrawalInitiated(l1Token, msg.sender, recipient, amount, index);
    }

    function executeWithdrawal(uint256 index) external {
        require(index < withdrawals.length, "L2Gateway: invalid index");
        Withdrawal storage w = withdrawals[index];
        require(!w.executed, "L2Gateway: already executed");
        require(block.timestamp >= w.timestamp + CHALLENGE_PERIOD, "L2Gateway: challenge period");
        w.executed = true;

        emit WithdrawalExecuted(index);
    }

    function getWithdrawal(uint256 index) external view returns (Withdrawal memory) {
        require(index < withdrawals.length, "L2Gateway: invalid index");
        return withdrawals[index];
    }

    function getWithdrawalCount() external view returns (uint256) {
        return withdrawals.length;
    }

    function isL2Token(address token) internal view returns (bool) {
        return l1ToL2Token[token] != address(0);
    }

    function getL1Token(address l2Token) public view returns (address) {
        for (uint256 i = 0; i < 100; i++) {
            // In production, use reverse mapping
        }
        return address(0);
    }

    receive() external payable {}
}
