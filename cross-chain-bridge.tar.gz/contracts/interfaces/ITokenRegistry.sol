pragma solidity ^0.8.20;

interface ITokenRegistry {
    struct TokenInfo {
        address l1Token;
        address l2Token;
        bool isRegistered;
        uint256 dailyLimit;
        uint256 usedToday;
        uint256 lastResetDay;
    }

    event TokenRegistered(address indexed l1Token, address indexed l2Token, uint256 dailyLimit);
    event TokenDeregistered(address indexed l1Token, address indexed l2Token);
    event DailyLimitUpdated(address indexed l1Token, uint256 newLimit);

    function registerToken(address l1Token, address l2Token, uint256 dailyLimit) external;
    function deregisterToken(address l1Token) external;
    function getL2Token(address l1Token) external view returns (address);
    function getL1Token(address l2Token) external view returns (address);
    function isRegistered(address l1Token) external view returns (bool);
    function checkAndUpdateLimit(address l1Token, uint256 amount) external returns (bool);
    function updateDailyLimit(address l1Token, uint256 newLimit) external;
}
