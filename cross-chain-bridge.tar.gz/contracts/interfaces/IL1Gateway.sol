pragma solidity ^0.8.20;

interface IL1Gateway {
    event DepositInitiated(
        address indexed l1Token,
        address indexed from,
        address indexed to,
        uint256 amount,
        uint256 ticketId
    );
    event WithdrawalFinalized(
        address indexed l1Token,
        address indexed to,
        uint256 amount
    );
    event BridgePaused(address indexed by);
    event BridgeUnpaused(address indexed by);

    function depositETH(address to) external payable returns (uint256 ticketId);
    function depositERC20(address l1Token, uint256 amount, address to) external returns (uint256 ticketId);
    function depositERC20Batch(address[] calldata l1Tokens, uint256[] calldata amounts, address to) external returns (uint256[] calldata ticketIds);
    function finalizeWithdrawal(address l1Token, address to, uint256 amount, bytes32[] calldata proof) external;
    function pause() external;
    function unpause() external;
    function isPaused() external view returns (bool);
}
