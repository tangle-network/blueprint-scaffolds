pragma solidity ^0.8.20;

interface IL2Gateway {
    event MintOnL2(
        address indexed l2Token,
        address indexed to,
        uint256 amount,
        uint256 ticketId
    );
    event BurnOnL2(
        address indexed l2Token,
        address indexed from,
        address indexed to,
        uint256 amount
    );
    event WithdrawalInitiated(
        address indexed l2Token,
        address indexed from,
        address indexed to,
        uint256 amount
    );

    function mint(address l2Token, address to, uint256 amount, uint256 ticketId) external;
    function withdrawETH(address to) external payable;
    function withdrawERC20(address l2Token, uint256 amount, address to) external;
    function withdrawERC20Batch(address[] calldata l2Tokens, uint256[] calldata amounts, address to) external;
    function burn(address l2Token, uint256 amount) external;
}
