// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IL2Gateway {
    function finalizeInboundTransfer(
        address token,
        address from,
        address to,
        uint256 amount,
        bytes calldata data
    ) external;
}

contract L1Gateway {
    struct RateBucket {
        uint128 capacity;
        uint128 used;
        uint64 windowStarted;
    }

    address public owner;
    address public inbox;
    address public router;
    bool public paused;
    mapping(address => bool) public supportedTokens;
    mapping(address => mapping(address => uint256)) public lockedBalance;
    mapping(address => RateBucket) public tokenRateLimits;

    event DepositInitiated(
        address indexed token,
        address indexed from,
        address indexed to,
        uint256 amount,
        uint256 ticketId
    );
    event ETHDepositInitiated(address indexed from, address indexed to, uint256 amount, uint256 ticketId);
    event WithdrawalFinalized(address indexed token, address indexed to, uint256 amount);
    event Paused(bool status);
    event TokenConfigured(address indexed token, bool supported, uint128 capacity);

    modifier onlyOwner() {
        require(msg.sender == owner, "ONLY_OWNER");
        _;
    }

    modifier whenNotPaused() {
        require(!paused, "PAUSED");
        _;
    }

    constructor(address _inbox, address _router) {
        owner = msg.sender;
        inbox = _inbox;
        router = _router;
    }

    function configureToken(address token, bool supported, uint128 capacity) external onlyOwner {
        supportedTokens[token] = supported;
        tokenRateLimits[token] = RateBucket(capacity, 0, uint64(block.timestamp));
        emit TokenConfigured(token, supported, capacity);
    }

    function setPaused(bool status) external onlyOwner {
        paused = status;
        emit Paused(status);
    }

    function depositERC20(
        address token,
        address to,
        uint256 amount,
        uint256 maxSubmissionCost,
        uint256 maxGas,
        uint256 gasPriceBid,
        bytes calldata data
    ) external payable whenNotPaused returns (uint256 ticketId) {
        require(supportedTokens[token], "TOKEN_NOT_SUPPORTED");
        _consumeRate(token, amount);
        lockedBalance[token][msg.sender] += amount;
        ticketId = uint256(
            keccak256(abi.encodePacked(block.chainid, token, msg.sender, to, amount, block.number))
        );
        data;
        maxSubmissionCost;
        maxGas;
        gasPriceBid;
        emit DepositInitiated(token, msg.sender, to, amount, ticketId);
    }

    function depositETH(
        address to,
        uint256 maxSubmissionCost,
        uint256 maxGas,
        uint256 gasPriceBid,
        bytes calldata data
    ) external payable whenNotPaused returns (uint256 ticketId) {
        _consumeRate(address(0), msg.value);
        ticketId = uint256(
            keccak256(abi.encodePacked(block.chainid, msg.sender, to, msg.value, block.timestamp))
        );
        data;
        maxSubmissionCost;
        maxGas;
        gasPriceBid;
        emit ETHDepositInitiated(msg.sender, to, msg.value, ticketId);
    }

    function finalizeWithdrawal(address token, address to, uint256 amount) external {
        require(msg.sender == router, "ONLY_OUTBOX");
        emit WithdrawalFinalized(token, to, amount);
    }

    function _consumeRate(address token, uint256 amount) internal {
        RateBucket storage bucket = tokenRateLimits[token];
        if (block.timestamp > bucket.windowStarted + 1 hours) {
            bucket.used = 0;
            bucket.windowStarted = uint64(block.timestamp);
        }
        require(bucket.used + amount <= bucket.capacity, "RATE_LIMIT");
        bucket.used += uint128(amount);
    }
}
