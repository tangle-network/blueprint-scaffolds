// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

interface IInbox {
    function createRetryableTicket(
        address to,
        uint256 l2CallValue,
        uint256 maxSubmissionCost,
        address excessFeeRefundAddress,
        address callValueRefundAddress,
        uint256 gasLimit,
        uint256 maxFeePerGas,
        bytes calldata data
    ) external payable returns (uint256);
}

interface IOutbox {
    function executeTransaction(
        bytes32[] calldata proof,
        uint256 index,
        address l2Sender,
        address to,
        uint256 l2Block,
        uint256 l1Block,
        uint256 l2Timestamp,
        uint256 value,
        bytes calldata data
    ) external;
}

interface IERC20 {
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
    function transfer(address to, uint256 amount) external returns (bool);
    function balanceOf(address account) external view returns (uint256);
    function approve(address spender, uint256 amount) external returns (bool);
}

contract L1Gateway {
    address public owner;
    address public inbox;
    address public l2Gateway;
    address public tokenRegistry;
    bool public paused;

    mapping(address => uint256) public lockedTokens;
    mapping(bytes32 => bool) public processedMessages;

    uint256 public constant CHALLENGE_PERIOD = 7 days;
    uint256 public constant RATE_LIMIT_WINDOW = 1 hours;
    uint256 public constant MAX_TRANSFERS_PER_WINDOW = 10;

    mapping(address => uint256[]) private transferTimestamps;
    mapping(address => bool) public operators;

    event BridgeInitiated(
        address indexed sender,
        address indexed recipient,
        address indexed token,
        uint256 amount,
        uint256 retryableTicketId
    );

    event BridgeCompleted(
        address indexed recipient,
        address indexed token,
        uint256 amount,
        bytes32 messageHash
    );

    event TokensLocked(address indexed token, address indexed from, uint256 amount);
    event TokensReleased(address indexed token, address indexed to, uint256 amount);
    event Paused(address indexed by);
    event Unpaused(address indexed by);

    modifier onlyOwner() {
        require(msg.sender == owner, "L1Gateway: not owner");
        _;
    }

    modifier onlyL2Gateway() {
        require(msg.sender == l2Gateway, "L1Gateway: not L2 gateway");
        _;
    }

    modifier notPaused() {
        require(!paused, "L1Gateway: paused");
        _;
    }

    modifier rateLimited(address user) {
        uint256[] storage timestamps = transferTimestamps[user];
        uint256 cutoff = block.timestamp - RATE_LIMIT_WINDOW;
        while (timestamps.length > 0 && timestamps[0] < cutoff) {
            timestamps[0] = timestamps[timestamps.length - 1];
            timestamps.pop();
        }
        require(timestamps.length < MAX_TRANSFERS_PER_WINDOW, "L1Gateway: rate limited");
        timestamps.push(block.timestamp);
        _;
    }

    constructor(address _inbox) {
        owner = msg.sender;
        inbox = _inbox;
        paused = false;
    }

    function setL2Gateway(address _l2Gateway) external onlyOwner {
        l2Gateway = _l2Gateway;
    }

    function setTokenRegistry(address _tokenRegistry) external onlyOwner {
        tokenRegistry = _tokenRegistry;
    }

    function setInbox(address _inbox) external onlyOwner {
        inbox = _inbox;
    }

    function addOperator(address op) external onlyOwner {
        operators[op] = true;
    }

    function removeOperator(address op) external onlyOwner {
        operators[op] = false;
    }

    function pause() external onlyOwner {
        paused = true;
        emit Paused(msg.sender);
    }

    function unpause() external onlyOwner {
        paused = false;
        emit Unpaused(msg.sender);
    }

    function depositETH(address recipient) external payable notPaused rateLimited(msg.sender) {
        require(msg.value > 0, "L1Gateway: zero amount");

        bytes memory data = abi.encodeWithSignature(
            "finalizeDeposit(address,address,address,uint256)",
            address(0),
            msg.sender,
            recipient,
            msg.value
        );

        uint256 ticketId = IInbox(inbox).createRetryableTicket{value: msg.value}(
            l2Gateway,
            0,
            0.01 ether,
            msg.sender,
            msg.sender,
            1_000_000,
            0.1 gwei,
            data
        );

        emit BridgeInitiated(msg.sender, recipient, address(0), msg.value, ticketId);
    }

    function depositERC20(
        address token,
        address recipient,
        uint256 amount
    ) external notPaused rateLimited(msg.sender) {
        require(amount > 0, "L1Gateway: zero amount");

        IERC20(token).transferFrom(msg.sender, address(this), amount);
        lockedTokens[token] += amount;

        emit TokensLocked(token, msg.sender, amount);

        bytes memory data = abi.encodeWithSignature(
            "finalizeDeposit(address,address,address,uint256)",
            token,
            msg.sender,
            recipient,
            amount
        );

        uint256 ticketId = IInbox(inbox).createRetryableTicket{value: msg.value}(
            l2Gateway,
            0,
            0.01 ether,
            msg.sender,
            msg.sender,
            1_000_000,
            0.1 gwei,
            data
        );

        emit BridgeInitiated(msg.sender, recipient, token, amount, ticketId);
    }

    function withdrawETH(
        address payable recipient,
        uint256 amount,
        bytes32 messageHash
    ) external onlyL2Gateway {
        require(!processedMessages[messageHash], "L1Gateway: already processed");
        processedMessages[messageHash] = true;

        (bool success, ) = recipient.call{value: amount}("");
        require(success, "L1Gateway: ETH transfer failed");

        emit TokensReleased(address(0), recipient, amount);
        emit BridgeCompleted(recipient, address(0), amount, messageHash);
    }

    function withdrawERC20(
        address token,
        address recipient,
        uint256 amount,
        bytes32 messageHash
    ) external onlyL2Gateway {
        require(!processedMessages[messageHash], "L1Gateway: already processed");
        require(lockedTokens[token] >= amount, "L1Gateway: insufficient locked");
        processedMessages[messageHash] = true;

        lockedTokens[token] -= amount;
        IERC20(token).transfer(recipient, amount);

        emit TokensReleased(token, recipient, amount);
        emit BridgeCompleted(recipient, token, amount, messageHash);
    }

    function batchDepositETH(address[] calldata recipients, uint256[] calldata amounts)
        external
        payable
        notPaused
        rateLimited(msg.sender)
    {
        require(recipients.length == amounts.length, "L1Gateway: length mismatch");
        uint256 total;
        for (uint256 i = 0; i < amounts.length; i++) {
            total += amounts[i];
        }
        require(msg.value >= total, "L1Gateway: insufficient ETH");

        for (uint256 i = 0; i < recipients.length; i++) {
            bytes memory data = abi.encodeWithSignature(
                "finalizeDeposit(address,address,address,uint256)",
                address(0),
                msg.sender,
                recipients[i],
                amounts[i]
            );

            IInbox(inbox).createRetryableTicket{value: amounts[i]}(
                l2Gateway,
                0,
                0.01 ether,
                msg.sender,
                msg.sender,
                1_000_000,
                0.1 gwei,
                data
            );

            emit BridgeInitiated(msg.sender, recipients[i], address(0), amounts[i], 0);
        }
    }

    receive() external payable {}
}
