pragma solidity ^0.8.20;

import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/security/Pausable.sol";
import "@openzeppelin/contracts/security/ReentrancyGuard.sol";
import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "./interfaces/IL1Gateway.sol";
import "./interfaces/ITokenRegistry.sol";
import "./interfaces/IArbitrum.sol";

contract L1Gateway is IL1Gateway, Ownable, Pausable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    ITokenRegistry public immutable registry;
    IInbox public immutable inbox;

    uint256 public ticketCounter;
    uint256 public constant CHALLENGE_PERIOD = 7 days;

    mapping(uint256 => bool) public processedTickets;
    mapping(bytes32 => bool) public processedWithdrawals;

    uint256 public constant MAX_BATCH_SIZE = 20;
    uint256 public minGasLimit = 100_000;
    uint256 public maxGasLimit = 10_000_000;

    constructor(address _registry, address _inbox) {
        require(_registry != address(0) && _inbox != address(0), "Zero address");
        registry = ITokenRegistry(_registry);
        inbox = IInbox(_inbox);
    }

    function depositETH(address to) external payable override whenNotPaused nonReentrant returns (uint256) {
        require(msg.value > 0, "Zero amount");
        require(to != address(0), "Zero address");

        unchecked { ++ticketCounter; }
        uint256 ticketId = ticketCounter;

        bytes memory data = abi.encodeWithSelector(
            IL2Gateway.mint.selector,
            address(0),
            to,
            msg.value,
            ticketId
        );

        inbox.createRetryableTicket{value: msg.value}(
            address(this),
            0,
            _estimateSubmissionCost(msg.value),
            msg.sender,
            msg.sender,
            minGasLimit,
            _estimateGasPrice(),
            data
        );

        emit DepositInitiated(address(0), msg.sender, to, msg.value, ticketId);
        return ticketId;
    }

    function depositERC20(
        address l1Token,
        uint256 amount,
        address to
    ) external override whenNotPaused nonReentrant returns (uint256) {
        require(amount > 0, "Zero amount");
        require(to != address(0), "Zero address");
        require(registry.isRegistered(l1Token), "Token not registered");
        require(registry.checkAndUpdateLimit(l1Token, amount), "Rate limit exceeded");

        IERC20(l1Token).safeTransferFrom(msg.sender, address(this), amount);

        unchecked { ++ticketCounter; }
        uint256 ticketId = ticketCounter;
        address l2Token = registry.getL2Token(l1Token);

        bytes memory data = abi.encodeWithSelector(
            IL2Gateway.mint.selector,
            l2Token,
            to,
            amount,
            ticketId
        );

        inbox.createRetryableTicket{value: msg.value > 0 ? msg.value : _estimateSubmissionCost(amount)}(
            address(this),
            0,
            _estimateSubmissionCost(amount),
            msg.sender,
            msg.sender,
            minGasLimit,
            _estimateGasPrice(),
            data
        );

        emit DepositInitiated(l1Token, msg.sender, to, amount, ticketId);
        return ticketId;
    }

    function depositERC20Batch(
        address[] calldata l1Tokens,
        uint256[] calldata amounts,
        address to
    ) external override whenNotPaused nonReentrant returns (uint256[] calldata) {
        require(l1Tokens.length == amounts.length, "Length mismatch");
        require(l1Tokens.length <= MAX_BATCH_SIZE, "Batch too large");
        require(to != address(0), "Zero address");

        for (uint256 i = 0; i < l1Tokens.length; i++) {
            require(amounts[i] > 0, "Zero amount");
            require(registry.isRegistered(l1Tokens[i]), "Token not registered");
            require(registry.checkAndUpdateLimit(l1Tokens[i], amounts[i]), "Rate limit exceeded");

            IERC20(l1Tokens[i]).safeTransferFrom(msg.sender, address(this), amounts[i]);

            unchecked { ++ticketCounter; }
            uint256 ticketId = ticketCounter;
            address l2Token = registry.getL2Token(l1Tokens[i]);

            bytes memory data = abi.encodeWithSelector(
                IL2Gateway.mint.selector,
                l2Token,
                to,
                amounts[i],
                ticketId
            );

            inbox.createRetryableTicket(
                address(this),
                0,
                _estimateSubmissionCost(amounts[i]),
                msg.sender,
                msg.sender,
                minGasLimit,
                _estimateGasPrice(),
                data
            );

            emit DepositInitiated(l1Tokens[i], msg.sender, to, amounts[i], ticketId);
        }

        return amounts;
    }

    function finalizeWithdrawal(
        address l1Token,
        address to,
        uint256 amount,
        bytes32[] calldata proof
    ) external override nonReentrant {
        bytes32 withdrawalId = keccak256(abi.encodePacked(l1Token, to, amount));
        require(!processedWithdrawals[withdrawalId], "Already processed");

        processedWithdrawals[withdrawalId] = true;

        if (l1Token == address(0)) {
            (bool success,) = to.call{value: amount}("");
            require(success, "ETH transfer failed");
        } else {
            IERC20(l1Token).safeTransfer(to, amount);
        }

        emit WithdrawalFinalized(l1Token, to, amount);
    }

    function pause() external override onlyOwner {
        _pause();
        emit BridgePaused(msg.sender);
    }

    function unpause() external override onlyOwner {
        _unpause();
        emit BridgeUnpaused(msg.sender);
    }

    function isPaused() external view override returns (bool) {
        return paused();
    }

    function setGasLimits(uint256 _minGasLimit, uint256 _maxGasLimit) external onlyOwner {
        require(_minGasLimit < _maxGasLimit, "Invalid gas limits");
        minGasLimit = _minGasLimit;
        maxGasLimit = _maxGasLimit;
    }

    function _estimateSubmissionCost(uint256 /* amount */) internal pure returns (uint256) {
        return 0.001 ether;
    }

    function _estimateGasPrice() internal pure returns (uint256) {
        return 1 gwei;
    }

    receive() external payable {}
}
