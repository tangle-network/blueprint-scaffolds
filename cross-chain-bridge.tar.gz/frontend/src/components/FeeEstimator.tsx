import React, { useState, useEffect } from "react";

interface FeeData {
  l1Gas: string;
  l2Gas: string;
  submissionCost: string;
  totalEstimate: string;
}

interface FeeEstimatorProps {
  inline?: boolean;
  amount?: string;
  direction?: string;
  tokenType?: string;
}

const FeeEstimator: React.FC<FeeEstimatorProps> = ({
  inline = false,
  amount = "0",
  direction = "l1-to-l2",
  tokenType = "ETH",
}) => {
  const [fees, setFees] = useState<FeeData>({
    l1Gas: "0.000",
    l2Gas: "0.000",
    submissionCost: "0.001",
    totalEstimate: "0.001",
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const estimateFees = () => {
      setLoading(true);
      setTimeout(() => {
        const parsedAmount = parseFloat(amount) || 0;
        const baseL2Gas = 0.0001;
        const baseL1Gas = direction === "l2-to-l1" ? 0.002 : 0.0005;
        const submissionCost = direction === "l1-to-l2" ? 0.001 : 0;
        const total = baseL1Gas + baseL2Gas + submissionCost;

        setFees({
          l1Gas: baseL1Gas.toFixed(4),
          l2Gas: baseL2Gas.toFixed(4),
          submissionCost: submissionCost.toFixed(4),
          totalEstimate: total.toFixed(4),
        });
        setLoading(false);
      }, 300);
    };

    estimateFees();
  }, [amount, direction, tokenType]);

  if (inline) {
    return (
      <div className="bg-gray-800/30 rounded-xl p-4 space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-gray-400">Est. Gas (L1)</span>
          <span>{fees.l1Gas} ETH</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-400">Est. Gas (L2)</span>
          <span>{fees.l2Gas} ETH</span>
        </div>
        {direction === "l1-to-l2" && (
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Submission Cost</span>
            <span>{fees.submissionCost} ETH</span>
          </div>
        )}
        <div className="border-t border-gray-700 pt-2 flex justify-between text-sm font-semibold">
          <span className="text-gray-400">Total</span>
          <span className="text-bridge-primary">{fees.totalEstimate} ETH</span>
        </div>
      </div>
    );
  }

  return (
    <div className="glass rounded-2xl p-6 space-y-4">
      <h3 className="text-lg font-semibold">Fee Estimator</h3>

      <div className="space-y-3">
        <div className="flex justify-between">
          <span className="text-gray-400 text-sm">L1 Gas Cost</span>
          <span className="text-sm">{fees.l1Gas} ETH</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-400 text-sm">L2 Gas Cost</span>
          <span className="text-sm">{fees.l2Gas} ETH</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-400 text-sm">Retryable Submission</span>
          <span className="text-sm">{fees.submissionCost} ETH</span>
        </div>
        <div className="border-t border-gray-700 pt-3 flex justify-between font-semibold">
          <span>Total Estimated Fee</span>
          <span className="text-bridge-primary">{fees.totalEstimate} ETH</span>
        </div>
      </div>

      {direction === "l1-to-l2" && (
        <p className="text-xs text-gray-500">
          L1→L2 deposits use retryable tickets. Fees include L2 gas + submission cost.
        </p>
      )}

      {loading && (
        <div className="text-xs text-gray-500 animate-pulse">Updating estimates...</div>
      )}
    </div>
  );
};

export default FeeEstimator;
