import React, { useState } from "react";

type TxStatus =
  | "pending-l1"
  | "confirmed-l1"
  | "retryable-created"
  | "executed-l2"
  | "pending-challenge"
  | "confirmed"
  | "failed";

interface Transaction {
  id: string;
  hash: string;
  direction: "l1-to-l2" | "l2-to-l1";
  token: string;
  amount: string;
  status: TxStatus;
  timestamp: number;
}

const STATUS_LABELS: Record<TxStatus, string> = {
  "pending-l1": "Pending L1",
  "confirmed-l1": "Confirmed L1",
  "retryable-created": "Retryable Created",
  "executed-l2": "Executed on L2",
  "pending-challenge": "Challenge Period (7d)",
  confirmed: "Confirmed",
  failed: "Failed",
};

const STATUS_COLORS: Record<TxStatus, string> = {
  "pending-l1": "text-yellow-400",
  "confirmed-l1": "text-blue-400",
  "retryable-created": "text-purple-400",
  "executed-l2": "text-green-400",
  "pending-challenge": "text-orange-400",
  confirmed: "text-green-400",
  failed: "text-red-400",
};

const MOCK_TXS: Transaction[] = [
  {
    id: "1",
    hash: "0xabc123...def456",
    direction: "l1-to-l2",
    token: "ETH",
    amount: "1.5",
    status: "confirmed",
    timestamp: Date.now() - 3600000,
  },
  {
    id: "2",
    hash: "0x789abc...012def",
    direction: "l2-to-l1",
    token: "USDC",
    amount: "5000",
    status: "pending-challenge",
    timestamp: Date.now() - 86400000,
  },
];

const TransactionTracker: React.FC = () => {
  const [transactions] = useState<Transaction[]>(MOCK_TXS);
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);

  const formatTime = (ts: number) => {
    const diff = Date.now() - ts;
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    return `${Math.floor(hrs / 24)}d ago`;
  };

  return (
    <div className="glass rounded-2xl p-6 space-y-4">
      <h3 className="text-lg font-semibold">Recent Transactions</h3>

      {transactions.length === 0 ? (
        <p className="text-gray-500 text-sm text-center py-6">No recent transactions</p>
      ) : (
        <div className="space-y-2">
          {transactions.map((tx) => (
            <div
              key={tx.id}
              className="bg-gray-800/40 rounded-xl p-3 cursor-pointer hover:bg-gray-800/60 transition-colors"
              onClick={() =>
                setSelectedTx(selectedTx?.id === tx.id ? null : tx)
              }
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xs bg-gray-700 px-2 py-0.5 rounded">
                    {tx.direction === "l1-to-l2" ? "L1→L2" : "L2→L1"}
                  </span>
                  <span className="text-sm font-medium">
                    {tx.amount} {tx.token}
                  </span>
                </div>
                <span className={`text-xs ${STATUS_COLORS[tx.status]}`}>
                  {STATUS_LABELS[tx.status]}
                </span>
              </div>
              <div className="flex items-center justify-between mt-1">
                <span className="text-xs text-gray-500 font-mono">
                  {tx.hash}
                </span>
                <span className="text-xs text-gray-500">
                  {formatTime(tx.timestamp)}
                </span>
              </div>

              {selectedTx?.id === tx.id && (
                <div className="mt-3 pt-3 border-t border-gray-700">
                  <div className="flex items-center gap-2 text-xs text-gray-400">
                    {tx.direction === "l1-to-l2" ? (
                      <>
                        <span className={STATUS_COLORS["confirmed-l1"]}>● L1 Confirm</span>
                        <span>→</span>
                        <span className={STATUS_COLORS["retryable-created"]}>● Retryable</span>
                        <span>→</span>
                        <span className={STATUS_COLORS["executed-l2"]}>● L2 Exec</span>
                      </>
                    ) : (
                      <>
                        <span className={STATUS_COLORS["confirmed-l1"]}>● L2 Burn</span>
                        <span>→</span>
                        <span className={STATUS_COLORS["pending-challenge"]}>● 7d Wait</span>
                        <span>→</span>
                        <span className={STATUS_COLORS["confirmed"]}>● L1 Claim</span>
                      </>
                    )}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default TransactionTracker;
