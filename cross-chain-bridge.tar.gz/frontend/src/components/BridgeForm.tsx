import React, { useState } from "react";
import FeeEstimator from "./FeeEstimator";

type Direction = "l1-to-l2" | "l2-to-l1";
type TokenType = "ETH" | "ERC20";

const BridgeForm: React.FC = () => {
  const [direction, setDirection] = useState<Direction>("l1-to-l2");
  const [tokenType, setTokenType] = useState<TokenType>("ETH");
  const [tokenAddress, setTokenAddress] = useState("");
  const [amount, setAmount] = useState("");
  const [recipient, setRecipient] = useState("");
  const [isBatch, setIsBatch] = useState(false);
  const [batchTokens, setBatchTokens] = useState("");
  const [batchAmounts, setBatchAmounts] = useState("");

  const handleBridge = () => {
    if (!amount) return;
    console.log("Bridge:", { direction, tokenType, amount, recipient });
  };

  return (
    <div className="glass rounded-2xl p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Bridge Tokens</h2>
        <div className="flex bg-gray-800 rounded-lg p-1">
          <button
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              direction === "l1-to-l2"
                ? "bg-bridge-primary text-white"
                : "text-gray-400 hover:text-white"
            }`}
            onClick={() => setDirection("l1-to-l2")}
          >
            L1 → L2
          </button>
          <button
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              direction === "l2-to-l1"
                ? "bg-bridge-primary text-white"
                : "text-gray-400 hover:text-white"
            }`}
            onClick={() => setDirection("l2-to-l1")}
          >
            L2 → L1
          </button>
        </div>
      </div>

      {direction === "l2-to-l1" && (
        <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-3">
          <p className="text-yellow-400 text-sm">
            ⚠ L2→L1 withdrawals require a 7-day challenge period before claiming on L1.
          </p>
        </div>
      )}

      <div className="flex gap-3">
        <button
          className={`flex-1 py-2 rounded-lg text-sm font-medium ${
            tokenType === "ETH"
              ? "bg-bridge-primary text-white"
              : "bg-gray-800 text-gray-400"
          }`}
          onClick={() => setTokenType("ETH")}
        >
          ETH
        </button>
        <button
          className={`flex-1 py-2 rounded-lg text-sm font-medium ${
            tokenType === "ERC20"
              ? "bg-bridge-primary text-white"
              : "bg-gray-800 text-gray-400"
          }`}
          onClick={() => setTokenType("ERC20")}
        >
          ERC-20
        </button>
      </div>

      {tokenType === "ERC20" && (
        <div>
          <label className="block text-sm text-gray-400 mb-1">Token Address</label>
          <input
            className="input-field"
            placeholder="0x..."
            value={tokenAddress}
            onChange={(e) => setTokenAddress(e.target.value)}
          />
        </div>
      )}

      <div className="flex items-center gap-2 mb-2">
        <input
          type="checkbox"
          id="batch"
          checked={isBatch}
          onChange={(e) => setIsBatch(e.target.checked)}
          className="rounded border-gray-600"
        />
        <label htmlFor="batch" className="text-sm text-gray-400">
          Batch Transfer (up to 20 tokens)
        </label>
      </div>

      {isBatch ? (
        <div className="space-y-3">
          <div>
            <label className="block text-sm text-gray-400 mb-1">Token Addresses (comma-separated)</label>
            <textarea
              className="input-field min-h-[60px]"
              placeholder="0xAAA..., 0xBBB..."
              value={batchTokens}
              onChange={(e) => setBatchTokens(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">Amounts (comma-separated)</label>
            <textarea
              className="input-field min-h-[60px]"
              placeholder="100, 250"
              value={batchAmounts}
              onChange={(e) => setBatchAmounts(e.target.value)}
            />
          </div>
        </div>
      ) : (
        <div>
          <label className="block text-sm text-gray-400 mb-1">Amount</label>
          <input
            className="input-field"
            type="number"
            placeholder="0.0"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
        </div>
      )}

      <div>
        <label className="block text-sm text-gray-400 mb-1">Recipient (optional)</label>
        <input
          className="input-field"
          placeholder="0x... (defaults to connected wallet)"
          value={recipient}
          onChange={(e) => setRecipient(e.target.value)}
        />
      </div>

      <FeeEstimator inline amount={amount} direction={direction} tokenType={tokenType} />

      <button
        className="btn-primary w-full text-lg"
        onClick={handleBridge}
        disabled={!amount}
      >
        {direction === "l1-to-l2" ? "Bridge to L2" : "Withdraw to L1"}
      </button>
    </div>
  );
};

export default BridgeForm;
