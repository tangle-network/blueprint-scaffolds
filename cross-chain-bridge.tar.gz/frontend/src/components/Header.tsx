import React from "react";

const Header: React.FC = () => {
  return (
    <header className="border-b border-gray-800">
      <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-bridge-primary rounded-lg flex items-center justify-center text-white font-bold text-sm">
            ⟠
          </div>
          <h1 className="text-xl font-bold text-white">Arb Bridge</h1>
          <span className="text-xs bg-bridge-primary/20 text-bridge-primary px-2 py-0.5 rounded-full">
            L1 ↔ L2
          </span>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex gap-1">
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-xs text-gray-400">Mainnet</span>
          </div>
          <button className="btn-primary text-sm !py-2 !px-4">
            Connect Wallet
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
