export const L1_RPC_URL = process.env.L1_RPC_URL || "http://localhost:8545";
export const L2_RPC_URL = process.env.L2_RPC_URL || "http://localhost:8547";
export const L1_GATEWAY_ADDRESS = process.env.L1_GATEWAY_ADDRESS || "";
export const L2_GATEWAY_ADDRESS = process.env.L2_GATEWAY_ADDRESS || "";
export const L1_CHAIN_ID = 1;
export const L2_CHAIN_ID = 42161;
export const CHALLENGE_PERIOD_MS = 7 * 24 * 60 * 60 * 1000;
export const INDEXER_POLL_INTERVAL_MS = 5000;
export const KEEPER_POLL_INTERVAL_MS = 10000;

export const L1_GATEWAY_ABI = [
  "event DepositInitiated(address indexed l1Token, address indexed from, address indexed to, uint256 amount, uint256 ticketId)",
  "event WithdrawalFinalized(address indexed l1Token, address indexed to, uint256 amount)",
  "event BridgePaused(address indexed by)",
  "event BridgeUnpaused(address indexed by)",
];

export const L2_GATEWAY_ABI = [
  "event MintOnL2(address indexed l2Token, address indexed to, uint256 amount, uint256 ticketId)",
  "event WithdrawalInitiated(address indexed l2Token, address indexed from, address indexed to, uint256 amount)",
];

export const TOKEN_REGISTRY_ABI = [
  "event TokenRegistered(address indexed l1Token, address indexed l2Token, uint256 dailyLimit)",
  "event TokenDeregistered(address indexed l1Token, address indexed l2Token)",
  "function getL2Token(address l1Token) view returns (address)",
  "function isRegistered(address l1Token) view returns (bool)",
];
