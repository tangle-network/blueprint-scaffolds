export interface BridgeTransaction {
  id: string;
  txHash: string;
  direction: "l1-to-l2" | "l2-to-l1";
  token: string;
  amount: string;
  sender: string;
  recipient: string;
  status: BridgeTxStatus;
  ticketId?: number;
  createdAt: number;
  updatedAt: number;
  l1BlockNumber?: number;
  l2BlockNumber?: number;
}

export type BridgeTxStatus =
  | "pending-l1"
  | "confirmed-l1"
  | "retryable-created"
  | "executed-l2"
  | "pending-challenge"
  | "ready-to-claim"
  | "claimed"
  | "failed";

export interface RetryableTicket {
  ticketId: number;
  l1TxHash: string;
  l2TxHash?: string;
  status: "pending" | "redeemed" | "expired" | "failed";
  createdAt: number;
  expiresAt: number;
}

export interface TokenMapping {
  l1Address: string;
  l2Address: string;
  symbol: string;
  decimals: number;
  dailyLimit: string;
  usedToday: string;
}

export interface FeeEstimate {
  l1GasCost: string;
  l2GasCost: string;
  submissionCost: string;
  totalCost: string;
}
