import React from "react";
import BridgeForm from "./components/BridgeForm";
import TransactionTracker from "./components/TransactionTracker";
import FeeEstimator from "./components/FeeEstimator";
import Header from "./components/Header";

const App: React.FC = () => {
  return (
    <div className="min-h-screen gradient-bg">
      <Header />
      <main className="max-w-4xl mx-auto px-4 py-8 space-y-8">
        <BridgeForm />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FeeEstimator />
          <TransactionTracker />
        </div>
      </main>
    </div>
  );
};

export default App;
