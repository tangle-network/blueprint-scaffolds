import { useState, useEffect, useCallback } from "react";
import { BridgeTransaction, BridgeTxStatus } from "../lib/types";
import { L1_GATEWAY_ADDRESS, L2_GATEWAY_ADDRESS } from "../lib/config";

const STORAGE_KEY = "arb-bridge-transactions";

export function useBridgeTransactions() {
  const [transactions, setTransactions] = useState<BridgeTransaction[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(transactions));
  }, [transactions]);

  const addTransaction = useCallback((tx: Omit<BridgeTransaction, "id" | "createdAt" | "updatedAt">) => {
    const newTx: BridgeTransaction = {
      ...tx,
      id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    setTransactions((prev) => [newTx, ...prev]);
    return newTx.id;
  }, []);

  const updateStatus = useCallback((id: string, status: BridgeTxStatus) => {
    setTransactions((prev) =>
      prev.map((tx) =>
        tx.id === id ? { ...tx, status, updatedAt: Date.now() } : tx
      )
    );
  }, []);

  const getByStatus = useCallback(
    (status: BridgeTxStatus) => transactions.filter((tx) => tx.status === status),
    [transactions]
  );

  const getPendingRetryables = useCallback(
    () => transactions.filter((tx) => tx.status === "retryable-created"),
    [transactions]
  );

  return { transactions, addTransaction, updateStatus, getByStatus, getPendingRetryables };
}
