import { useState, useCallback } from "react";
import { FeeEstimate } from "../lib/types";

export function useFeeEstimate() {
  const [estimate, setEstimate] = useState<FeeEstimate | null>(null);
  const [loading, setLoading] = useState(false);

  const estimateFees = useCallback(
    async (direction: "l1-to-l2" | "l2-to-l1", tokenType: "ETH" | "ERC20") => {
      setLoading(true);
      try {
        const l1Base = direction === "l1-to-l2" ? "0.0005" : "0.002";
        const l2Base = "0.0001";
        const submission = direction === "l1-to-l2" ? "0.001" : "0";

        const l1Gas = parseFloat(l1Base) * (tokenType === "ERC20" ? 1.5 : 1);
        const l2Gas = parseFloat(l2Base);
        const submissionCost = parseFloat(submission);

        setEstimate({
          l1GasCost: l1Gas.toFixed(6),
          l2GasCost: l2Gas.toFixed(6),
          submissionCost: submissionCost.toFixed(6),
          totalCost: (l1Gas + l2Gas + submissionCost).toFixed(6),
        });
      } finally {
        setLoading(false);
      }
    },
    []
  );

  return { estimate, loading, estimateFees };
}
