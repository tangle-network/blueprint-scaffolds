module move-token-launchpad::TreasuryVaultTests {
    use move-token-launchpad::TreasuryVault;

    #[test(account = @move-token-launchpad)]
    fun initializes_balance(account: signer) {
        TreasuryVault::initialize(&account);
        assert!(TreasuryVault::balance(@move-token-launchpad) == 0, 0);
    }
}
