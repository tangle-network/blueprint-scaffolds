# Aptos Fair Launchpad

Token launchpad prototype for Aptos with:

- Fixed-price sales
- Dutch auctions
- Overflow / pro-rata raises
- Whitelist presales
- Vesting schedules
- Anti-snipe windows
- Contribution limits
- Auto LP provision
- LP lock vault

## Structure

- `src/`: Vite + React frontend with launch calendar, contribution flow, claim portal, and creator dashboard.
- `contracts/`: Aptos Move package with core launch registry, vesting helpers, and LP lock receipt module.

## Commands

```bash
pnpm install
pnpm build
pnpm dev
```
