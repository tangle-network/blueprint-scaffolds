module launchpad::lp_lock {
    use std::error;
    use std::signer;
    use std::string::String;

    const E_LOCK_ACTIVE: u64 = 1;
    const E_UNLOCK_NOT_READY: u64 = 2;

    struct LockReceipt has key {
        pool_id: String,
        owner: address,
        unlock_ts: u64,
        released: bool,
    }

    public entry fun lock(owner: &signer, pool_id: String, unlock_ts: u64) {
        move_to(owner, LockReceipt {
            pool_id,
            owner: signer::address_of(owner),
            unlock_ts,
            released: false,
        });
    }

    public entry fun release(owner: &signer, now_ts: u64) acquires LockReceipt {
        let owner_address = signer::address_of(owner);
        let receipt = borrow_global_mut<LockReceipt>(owner_address);
        assert!(!receipt.released, error::already_exists(E_LOCK_ACTIVE));
        assert!(now_ts >= receipt.unlock_ts, error::invalid_state(E_UNLOCK_NOT_READY));
        receipt.released = true;
    }
}
