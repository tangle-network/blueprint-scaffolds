module launchpad::fair_launchpad {
    use std::error;
    use std::signer;
    use std::string::{Self, String};
    use std::vector;

    const E_ALREADY_INITIALIZED: u64 = 1;
    const E_NOT_INITIALIZED: u64 = 2;
    const E_LAUNCH_EXISTS: u64 = 3;
    const E_LAUNCH_NOT_FOUND: u64 = 4;
    const E_INVALID_CONTRIBUTION: u64 = 5;
    const E_CLAIM_NOT_READY: u64 = 6;
    const E_ALREADY_CLAIMED: u64 = 7;

    struct Launchpad has key {
        launches: vector<Launch>,
    }

    struct Launch has copy, drop, store {
        sale_id: String,
        project_name: String,
        launch_type: String,
        owner: address,
        price_microunits: u64,
        min_contribution: u64,
        max_contribution: u64,
        wallet_cap: u64,
        anti_snipe_window_minutes: u64,
        lp_allocation_percent: u64,
        lp_lock_days: u64,
        total_raised: u64,
        finalized: bool,
    }

    struct Position has copy, drop, store {
        sale_id: String,
        account: address,
        contribution: u64,
        tokens_claimed: bool,
    }

    struct Positions has key {
        items: vector<Position>,
    }

    public entry fun initialize(admin: &signer) {
        let admin_address = signer::address_of(admin);
        assert!(!exists<Launchpad>(admin_address), error::already_exists(E_ALREADY_INITIALIZED));
        move_to(admin, Launchpad { launches: vector::empty<Launch>() });
        move_to(admin, Positions { items: vector::empty<Position>() });
    }

    public entry fun create_launch(
        admin: &signer,
        sale_id: String,
        project_name: String,
        launch_type: String,
        price_microunits: u64,
        min_contribution: u64,
        max_contribution: u64,
        wallet_cap: u64,
        anti_snipe_window_minutes: u64,
        lp_allocation_percent: u64,
        lp_lock_days: u64
    ) acquires Launchpad {
        let admin_address = signer::address_of(admin);
        assert!(exists<Launchpad>(admin_address), error::not_found(E_NOT_INITIALIZED));

        let registry = borrow_global_mut<Launchpad>(admin_address);
        assert!(!has_launch(&registry.launches, &sale_id), error::already_exists(E_LAUNCH_EXISTS));

        vector::push_back(&mut registry.launches, Launch {
            sale_id,
            project_name,
            launch_type,
            owner: admin_address,
            price_microunits,
            min_contribution,
            max_contribution,
            wallet_cap,
            anti_snipe_window_minutes,
            lp_allocation_percent,
            lp_lock_days,
            total_raised: 0,
            finalized: false,
        });
    }

    public entry fun contribute(
        admin: &signer,
        sale_id: String,
        account: address,
        amount: u64
    ) acquires Launchpad, Positions {
        let admin_address = signer::address_of(admin);
        assert!(exists<Launchpad>(admin_address), error::not_found(E_NOT_INITIALIZED));
        assert!(exists<Positions>(admin_address), error::not_found(E_NOT_INITIALIZED));

        let registry = borrow_global_mut<Launchpad>(admin_address);
        let launch_index = launch_index_of(&registry.launches, &sale_id);
        let launch = vector::borrow_mut(&mut registry.launches, launch_index);

        assert!(
            amount >= launch.min_contribution && amount <= launch.max_contribution,
            error::invalid_argument(E_INVALID_CONTRIBUTION)
        );

        launch.total_raised = launch.total_raised + amount;

        let positions = borrow_global_mut<Positions>(admin_address);
        vector::push_back(&mut positions.items, Position {
            sale_id,
            account,
            contribution: amount,
            tokens_claimed: false,
        });
    }

    public entry fun finalize(admin: &signer, sale_id: String) acquires Launchpad {
        let admin_address = signer::address_of(admin);
        let registry = borrow_global_mut<Launchpad>(admin_address);
        let launch_index = launch_index_of(&registry.launches, &sale_id);
        let launch = vector::borrow_mut(&mut registry.launches, launch_index);
        launch.finalized = true;
    }

    public entry fun claim(
        admin: &signer,
        sale_id: String,
        account: address
    ) acquires Launchpad, Positions {
        let admin_address = signer::address_of(admin);
        let registry = borrow_global<Launchpad>(admin_address);
        let launch_index = launch_index_of(&registry.launches, &sale_id);
        let launch = vector::borrow(&registry.launches, launch_index);
        assert!(launch.finalized, error::invalid_state(E_CLAIM_NOT_READY));

        let positions = borrow_global_mut<Positions>(admin_address);
        let index = position_index_of(&positions.items, &sale_id, account);
        let position = vector::borrow_mut(&mut positions.items, index);
        assert!(!position.tokens_claimed, error::already_exists(E_ALREADY_CLAIMED));
        position.tokens_claimed = true;
    }

    fun has_launch(launches: &vector<Launch>, sale_id: &String): bool {
        let length = vector::length(launches);
        let i = 0;
        while (i < length) {
            let launch = vector::borrow(launches, i);
            if (&launch.sale_id == sale_id) {
                return true
            };
            i = i + 1;
        };
        false
    }

    fun launch_index_of(launches: &vector<Launch>, sale_id: &String): u64 {
        let length = vector::length(launches);
        let i = 0;
        while (i < length) {
            let launch = vector::borrow(launches, i);
            if (&launch.sale_id == sale_id) {
                return i
            };
            i = i + 1;
        };
        abort error::not_found(E_LAUNCH_NOT_FOUND)
    }

    fun position_index_of(positions: &vector<Position>, sale_id: &String, account: address): u64 {
        let length = vector::length(positions);
        let i = 0;
        while (i < length) {
            let position = vector::borrow(positions, i);
            if (&position.sale_id == sale_id && position.account == account) {
                return i
            };
            i = i + 1;
        };
        abort error::not_found(E_LAUNCH_NOT_FOUND)
    }
}
