module launchpad::vesting {
    use std::string::String;
    use std::vector;

    struct VestingSlice has copy, drop, store {
        label: String,
        unlock_ts: u64,
        bps: u64,
    }

    public fun total_bps(schedule: &vector<VestingSlice>): u64 {
        let total = 0;
        let i = 0;
        let len = vector::length(schedule);

        while (i < len) {
            let slice = vector::borrow(schedule, i);
            total = total + slice.bps;
            i = i + 1;
        };

        total
    }

    public fun unlocked_bps(schedule: &vector<VestingSlice>, now_ts: u64): u64 {
        let total = 0;
        let i = 0;
        let len = vector::length(schedule);

        while (i < len) {
            let slice = vector::borrow(schedule, i);
            if (now_ts >= slice.unlock_ts) {
                total = total + slice.bps;
            };
            i = i + 1;
        };

        total
    }
}
