import type { ContributorPosition, DashboardMetric, Launch } from "../types";

export const launches: Launch[] = [
  {
    id: "aurora",
    project: "Aurora Lend",
    summary: "Fixed-price credit market with instant LP seeding and 180-day lock.",
    type: "fixed",
    status: "Live",
    opensAt: "2025-04-05T16:00:00Z",
    closesAt: "2025-04-07T16:00:00Z",
    whitelistOnly: false,
    antiSnipeWindowMinutes: 10,
    contributionMin: 50,
    contributionMax: 25000,
    walletCap: 15000,
    lpAllocationPercent: 22,
    lpLockDays: 180,
    tokenomics: {
      ticker: "AUR",
      totalRaise: 1200000,
      tokensForSale: 8000000,
      price: 0.15,
      fdv: 15000000
    },
    vesting: [
      { label: "TGE", percent: 20, unlockAt: "2025-04-10T16:00:00Z" },
      { label: "Month 1", percent: 20, unlockAt: "2025-05-10T16:00:00Z" },
      { label: "Month 2", percent: 20, unlockAt: "2025-06-10T16:00:00Z" },
      { label: "Month 3", percent: 20, unlockAt: "2025-07-10T16:00:00Z" },
      { label: "Month 4", percent: 20, unlockAt: "2025-08-10T16:00:00Z" }
    ],
    progress: 74,
    participants: 941,
    creator: "0xlaunch_aurora"
  },
  {
    id: "tidal",
    project: "Tidal AMM",
    summary: "Dutch auction sale that compresses price every 15 minutes to maximize fair clearing.",
    type: "dutch",
    status: "Upcoming",
    opensAt: "2025-04-11T15:00:00Z",
    closesAt: "2025-04-12T15:00:00Z",
    whitelistOnly: false,
    antiSnipeWindowMinutes: 15,
    contributionMin: 100,
    contributionMax: 30000,
    walletCap: 20000,
    lpAllocationPercent: 30,
    lpLockDays: 365,
    tokenomics: {
      ticker: "TIDE",
      totalRaise: 1800000,
      tokensForSale: 9000000,
      price: 0.28,
      fdv: 28000000
    },
    vesting: [
      { label: "TGE", percent: 10, unlockAt: "2025-04-15T15:00:00Z" },
      { label: "Quarter 1", percent: 30, unlockAt: "2025-07-15T15:00:00Z" },
      { label: "Quarter 2", percent: 30, unlockAt: "2025-10-15T15:00:00Z" },
      { label: "Quarter 3", percent: 30, unlockAt: "2026-01-15T15:00:00Z" }
    ],
    progress: 0,
    participants: 0,
    creator: "0xtidal_foundry"
  },
  {
    id: "quartz",
    project: "Quartz Vaults",
    summary: "Overflow raise with pro-rata fill, USDC refunds, and treasury LP lock manager.",
    type: "overflow",
    status: "Claim",
    opensAt: "2025-03-19T14:00:00Z",
    closesAt: "2025-03-21T14:00:00Z",
    whitelistOnly: false,
    antiSnipeWindowMinutes: 5,
    contributionMin: 25,
    contributionMax: 50000,
    walletCap: 10000,
    lpAllocationPercent: 18,
    lpLockDays: 270,
    tokenomics: {
      ticker: "QRZ",
      totalRaise: 950000,
      tokensForSale: 5000000,
      price: 0.19,
      fdv: 19000000
    },
    vesting: [
      { label: "TGE", percent: 25, unlockAt: "2025-03-25T14:00:00Z" },
      { label: "Month 1", percent: 25, unlockAt: "2025-04-25T14:00:00Z" },
      { label: "Month 2", percent: 25, unlockAt: "2025-05-25T14:00:00Z" },
      { label: "Month 3", percent: 25, unlockAt: "2025-06-25T14:00:00Z" }
    ],
    progress: 100,
    participants: 1358,
    creator: "0xquartz_core"
  },
  {
    id: "ember",
    project: "Ember Compute",
    summary: "Whitelist presale for GPU marketplace operators with staged unlocks and capped deposits.",
    type: "whitelist",
    status: "Upcoming",
    opensAt: "2025-04-18T18:00:00Z",
    closesAt: "2025-04-19T18:00:00Z",
    whitelistOnly: true,
    antiSnipeWindowMinutes: 20,
    contributionMin: 250,
    contributionMax: 60000,
    walletCap: 25000,
    lpAllocationPercent: 25,
    lpLockDays: 540,
    tokenomics: {
      ticker: "EMB",
      totalRaise: 2400000,
      tokensForSale: 10000000,
      price: 0.24,
      fdv: 24000000
    },
    vesting: [
      { label: "TGE", percent: 5, unlockAt: "2025-04-25T18:00:00Z" },
      { label: "Month 2", percent: 20, unlockAt: "2025-06-25T18:00:00Z" },
      { label: "Month 4", percent: 25, unlockAt: "2025-08-25T18:00:00Z" },
      { label: "Month 6", percent: 25, unlockAt: "2025-10-25T18:00:00Z" },
      { label: "Month 8", percent: 25, unlockAt: "2025-12-25T18:00:00Z" }
    ],
    progress: 0,
    participants: 86,
    creator: "0xember_ops"
  }
];

export const contributorPositions: ContributorPosition[] = [
  {
    launchId: "aurora",
    contributed: 1250,
    claimable: 1666.67,
    refund: 0,
    vestingProgress: 20
  },
  {
    launchId: "quartz",
    contributed: 3000,
    claimable: 3947.37,
    refund: 421.12,
    vestingProgress: 50
  }
];

export const creatorMetrics: DashboardMetric[] = [
  { label: "Capital raised", value: "$9.4M", hint: "Across 11 sale pools" },
  { label: "Median fill time", value: "3h 12m", hint: "After anti-snipe extensions" },
  { label: "LP locked", value: "$4.1M", hint: "Current active pool value" },
  { label: "Claim completion", value: "82%", hint: "Average on completed launches" }
];
