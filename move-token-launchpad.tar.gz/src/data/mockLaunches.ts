import { LaunchConfig, LaunchStatus } from '../types';

const SYMBOLS = ['APT', 'MOVE', 'SOL', 'ETH', 'USDC'];
const NAMES = ['AptosFi', 'MoveDeFi', 'SuiFlip', 'AptosPepe', 'MoveCat', 'AptosRocket', 'LiquidMove', 'AptosDAO', 'MoveSwap', 'AptosPad'];
const STATUSES: LaunchStatus[] = ['upcoming', 'live', 'ended', 'claimed'];
const TYPES: LaunchConfig['launchType'][] = ['fixed_price', 'dutch_auction', 'overflow', 'whitelist_presale'];

function rand(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randAddr() {
  const hex = Array.from({ length: 64 }, () => rand(0, 15).toString(16)).join('');
  return `0x${hex}`;
}

export function generateMockLaunches(count: number = 12): LaunchConfig[] {
  const now = Math.floor(Date.now() / 1000);
  return Array.from({ length: count }, (_, i) => {
    const type = TYPES[i % TYPES.length];
    const status = STATUSES[rand(0, 3)];
    const startOffset = rand(-86400, 86400 * 7);
    const duration = rand(3600, 86400 * 3);
    const saleSupply = rand(100_000, 100_000_000);
    const price = (rand(1, 500) / 100).toFixed(4);

    return {
      id: `launch_${i}_${Date.now()}`,
      creator: randAddr(),
      launchType: type,
      status,
      tokenName: NAMES[i % NAMES.length],
      tokenSymbol: SYMBOLS[rand(0, SYMBOLS.length - 1)] + i,
      tokenDecimals: 8,
      totalSupply: String(saleSupply * 4),
      saleAmount: String(saleSupply),
      pricePerToken: price,
      startPrice: type === 'dutch_auction' ? (Number(price) * 3).toFixed(4) : price,
      endPrice: type === 'dutch_auction' ? (Number(price) * 0.3).toFixed(4) : price,
      raiseCap: String(saleSupply * Number(price)),
      minContribution: '1',
      maxContribution: String(rand(100, 10000)),
      startTime: now + startOffset,
      endTime: now + startOffset + duration,
      antiSnipeDelaySec: rand(5, 30),
      autoLpPercent: rand(30, 70),
      lpLockMonths: rand(3, 24),
      vesting: {
        cliffMonths: rand(0, 3),
        durationMonths: rand(6, 24),
        releaseIntervalMonths: 1,
      },
      whitelistedAddresses: Array.from({ length: rand(5, 20) }, () => randAddr()),
      claimedAmount: status === 'claimed' ? String(saleSupply) : '0',
      raisedAmount: status === 'upcoming' ? '0' : String(Math.floor(saleSupply * Number(price) * (rand(20, 100) / 100))),
      contributors: status === 'upcoming' ? 0 : rand(10, 500),
    };
  });
}

export const mockLaunches = generateMockLaunches();
