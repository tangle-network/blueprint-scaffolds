export const APTOS_MODULE = `module launchpad::launchpad {
    use std::signer;
    use aptos_framework::coin;
    use aptos_framework::fungible_asset;
    use aptos_framework::object;
    use aptos_framework::timestamp;

    // === Launch Types ===
    // fixed_price, dutch_auction, overflow, whitelist_presale

    struct LaunchConfig has store, drop {
        creator: address,
        launch_type: u8,
        token_metadata: object::Object,
        total_sale_amount: u64,
        price_per_token: u64,
        start_time: u64,
        end_time: u64,
        min_contribution: u64,
        max_contribution: u64,
        anti_snipe_delay: u64,
        auto_lp_percent: u64,
        lp_lock_months: u64,
        vesting_cliff_months: u64,
        vesting_duration_months: u64,
        raised_amount: u64,
        is_finalized: bool,
    }

    struct Contribution has store, drop {
        contributor: address,
        amount: u64,
        timestamp: u64,
        tokens_claimed: bool,
    }

    // Entry functions for on-chain interaction
    // These would be called via the wallet adapter
}`;

export const MOVE_TOML = `[package]
name = "aptos-launchpad"
version = "1.0.0"
edition = "2024.beta"

[addresses]
launchpad = "_"

[dependencies]
AptosFramework = { git = "https://github.com/aptos-labs/aptos-core.git", subdir = "aptos-move/framework/aptos-framework", rev = "mainnet" }`;
