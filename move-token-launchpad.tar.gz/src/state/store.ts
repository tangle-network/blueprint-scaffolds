import { LaunchConfig } from '../types';
import { mockLaunches } from '../data/mockLaunches';

const STORAGE_KEY = 'aptos_launchpad_state';

interface AppState {
  launches: LaunchConfig[];
  contributions: Record<string, string>;
}

function loadState(): AppState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* */ }
  return { launches: mockLaunches, contributions: {} };
}

function saveState(state: AppState) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

export function getLaunches(): LaunchConfig[] {
  return loadState().launches;
}

export function getLaunch(id: string): LaunchConfig | undefined {
  return loadState().launches.find(l => l.id === id);
}

export function getContributions(launchId: string): string {
  return loadState().contributions[launchId] || '0';
}

export function contribute(launchId: string, amount: string): LaunchConfig | undefined {
  const state = loadState();
  const launch = state.launches.find(l => l.id === launchId);
  if (!launch || (launch.status !== 'live' && launch.status !== 'upcoming')) return undefined;

  const prev = Number(state.contributions[launchId] || '0');
  state.contributions[launchId] = String(prev + Number(amount));
  launch.raisedAmount = String(Number(launch.raisedAmount) + Number(amount));
  launch.contributors += 1;
  saveState(state);
  return launch;
}

export function claimTokens(launchId: string): boolean {
  const state = loadState();
  const launch = state.launches.find(l => l.id === launchId);
  if (!launch || launch.status !== 'ended') return false;
  launch.status = 'claimed';
  saveState(state);
  return true;
}

export function createLaunch(config: Omit<LaunchConfig, 'id' | 'status' | 'claimedAmount' | 'raisedAmount' | 'contributors'>): LaunchConfig {
  const state = loadState();
  const launch: LaunchConfig = {
    ...config,
    id: `launch_${state.launches.length}_${Date.now()}`,
    status: 'upcoming',
    claimedAmount: '0',
    raisedAmount: '0',
    contributors: 0,
  };
  state.launches.unshift(launch);
  saveState(state);
  return launch;
}

export function resetState() {
  localStorage.removeItem(STORAGE_KEY);
}
