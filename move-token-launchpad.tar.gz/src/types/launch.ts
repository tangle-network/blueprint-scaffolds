export type LaunchType = "fixed_price" | "dutch_auction" | "overflow" | "whitelist_presale";

export type LaunchStatus = "upcoming" | "active" | "completed" | "cancelled";

export interface VestingSchedule {
  cliffMonths: number;
  vestingMonths: number;
  cliffReleaseBps: number;
}

export interface WhitelistEntry {
  address: string;
  maxContribution: number;
}

export interface AntiSnipeConfig {
  minContribution: number;
  maxContribution: number;
  cooldownSeconds: number;
  botDetectionEnabled: boolean;
}

export interface LaunchConfig {
  id: string;
  creatorAddress: string;
  name: string;
  symbol: string;
  description: string;
  logoUrl: string;
  launchType: LaunchType;
  status: LaunchStatus;
  totalSupply: number;
  tokensForSale: number;
  pricePerToken: number;
  startPrice?: number;
  endPrice?: number;
  priceDecayDuration?: number;
  startTime: number;
  endTime: number;
  minContribution: number;
  maxContribution: number;
  softCap: number;
  hardCap: number;
  raisedAmount: number;
  contributorsCount: number;
  vestingSchedule: VestingSchedule;
  antiSnipe: AntiSnipeConfig;
  autoLpProvision: boolean;
  lpLockDurationMonths: number;
  whitelist: WhitelistEntry[];
  isWhitelistOnly: boolean;
  metadata: Record<string, string>;
}

export interface Contribution {
  id: string;
  launchId: string;
  contributorAddress: string;
  amount: number;
  timestamp: number;
  claimed: boolean;
  claimableTokens: number;
  refunded: boolean;
}

export interface ClaimInfo {
  launchId: string;
  totalContributed: number;
  claimableTokens: number;
  claimed: boolean;
  vestingCliffEnd: number;
  vestingEnd: number;
  vestedAmount: number;
}
