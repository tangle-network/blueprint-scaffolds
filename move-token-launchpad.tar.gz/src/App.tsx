import { useMemo, useState } from "react";
import { ArrowRight, CalendarDays, CircleDollarSign, Lock, Sparkles } from "lucide-react";
import { ClaimPortal } from "./components/ClaimPortal";
import { ContributionPanel } from "./components/ContributionPanel";
import { CreatorDashboard } from "./components/CreatorDashboard";
import { LaunchCard } from "./components/LaunchCard";
import { SectionTitle } from "./components/SectionTitle";
import { contributorPositions, creatorMetrics, launches } from "./data/launches";
import { formatDate, getLaunchTypeLabel, toCompactNumber, toCurrency } from "./lib/aptos";

export default function App() {
  const [selectedId, setSelectedId] = useState(launches[0].id);
  const selectedLaunch = useMemo(
    () => launches.find((launch) => launch.id === selectedId) ?? launches[0],
    [selectedId]
  );

  return (
    <div className="app-shell">
      <header className="hero">
        <nav className="topbar">
          <div className="brand">
            <span className="brand__mark">A</span>
            <div>
              <strong>Aptos Fair Launchpad</strong>
              <span>Primary issuance without privileged fill paths</span>
            </div>
          </div>
          <div className="topbar__meta">
            <span>Testnet-ready flows</span>
            <button type="button" className="ghost-button">
              Creator Access
            </button>
          </div>
        </nav>

        <div className="hero__content">
          <div>
            <span className="eyebrow">Fair Launch Infrastructure</span>
            <h1>Run Aptos token sales with deterministic allocation, auto-LP, and claim-safe vesting.</h1>
            <p>
              Support fixed-price sales, Dutch auctions, overflow pools, and whitelist presales from the
              same contract surface. Every launch exposes anti-snipe rules, contribution limits, and LP
              lock guarantees up front.
            </p>
            <div className="hero__actions">
              <button type="button" className="primary-button">
                Browse Live Launches
              </button>
              <button type="button" className="ghost-button">
                View Move Package
              </button>
            </div>
          </div>

          <aside className="hero__spotlight">
            <span className="pill pill--live">Live on Testnet</span>
            <h2>{selectedLaunch.project}</h2>
            <p>{selectedLaunch.summary}</p>
            <div className="hero__stats">
              <div>
                <CalendarDays size={18} />
                <span>{formatDate(selectedLaunch.opensAt)}</span>
              </div>
              <div>
                <CircleDollarSign size={18} />
                <span>{toCurrency(selectedLaunch.tokenomics.totalRaise)} target</span>
              </div>
              <div>
                <Lock size={18} />
                <span>{selectedLaunch.lpLockDays}d LP lock</span>
              </div>
            </div>
            <div className="hero__quote">
              <Sparkles size={18} />
              <p>
                {getLaunchTypeLabel(selectedLaunch.type)} flow with {selectedLaunch.antiSnipeWindowMinutes}m
                rolling anti-snipe and {selectedLaunch.lpAllocationPercent}% liquidity allocation.
              </p>
            </div>
          </aside>
        </div>
      </header>

      <main className="content">
        <section className="section">
          <SectionTitle eyebrow="Launch Calendar" title="Upcoming and active sales">
            Select a launch to inspect sale mechanics, vesting, and on-chain entry payloads.
          </SectionTitle>
          <div className="launch-grid">
            {launches.map((launch) => (
              <LaunchCard
                key={launch.id}
                launch={launch}
                selected={selectedId === launch.id}
                onSelect={(item) => setSelectedId(item.id)}
              />
            ))}
          </div>
        </section>

        <section className="section section--two-column">
          <SectionTitle eyebrow="Sale Surface" title="Contribution interface">
            Frontend flow for committing capital, previewing fills, and exposing anti-snipe behavior.
          </SectionTitle>
          <div className="two-column">
            <ContributionPanel launch={selectedLaunch} />
            <section className="panel">
              <div className="panel__title-row">
                <div>
                  <span className="eyebrow">Launch Terms</span>
                  <h3>{selectedLaunch.project} terms</h3>
                </div>
              </div>

              <div className="terms-grid">
                <article>
                  <span>Type</span>
                  <strong>{getLaunchTypeLabel(selectedLaunch.type)}</strong>
                </article>
                <article>
                  <span>Price</span>
                  <strong>{toCurrency(selectedLaunch.tokenomics.price)}</strong>
                </article>
                <article>
                  <span>Tokens for sale</span>
                  <strong>{toCompactNumber(selectedLaunch.tokenomics.tokensForSale)}</strong>
                </article>
                <article>
                  <span>FDV</span>
                  <strong>{toCurrency(selectedLaunch.tokenomics.fdv)}</strong>
                </article>
                <article>
                  <span>Whitelist</span>
                  <strong>{selectedLaunch.whitelistOnly ? "Required" : "Open access"}</strong>
                </article>
                <article>
                  <span>Participants</span>
                  <strong>{toCompactNumber(selectedLaunch.participants)}</strong>
                </article>
              </div>

              <div className="vesting-list">
                {selectedLaunch.vesting.map((slice) => (
                  <div className="vesting-row" key={slice.label}>
                    <div>
                      <strong>{slice.label}</strong>
                      <span>{formatDate(slice.unlockAt)}</span>
                    </div>
                    <span>{slice.percent}%</span>
                  </div>
                ))}
              </div>

              <a className="inline-link" href="#contracts">
                Inspect Move modules <ArrowRight size={16} />
              </a>
            </section>
          </div>
        </section>

        <section className="section section--two-column">
          <SectionTitle eyebrow="Post Sale" title="Claims and creator operations">
            Claim portal and creator controls cover vesting, refunds, auto-LP, and lock tracking.
          </SectionTitle>
          <div className="stack">
            <ClaimPortal launches={launches} positions={contributorPositions} />
            <CreatorDashboard metrics={creatorMetrics} featuredLaunch={selectedLaunch} />
          </div>
        </section>

        <section className="section" id="contracts">
          <SectionTitle eyebrow="Contracts" title="Move package included">
            The repository ships with a Move package covering launch creation, sale participation, claims,
            vesting checkpoints, and LP lock scheduling.
          </SectionTitle>
          <div className="contracts-panel">
            <article>
              <h3>`fair_launchpad.move`</h3>
              <p>Core launch registry, sale accounting, contribution limits, anti-snipe extension, and claims.</p>
            </article>
            <article>
              <h3>`lp_lock.move`</h3>
              <p>Receipt lock vault with deterministic unlock timestamps and release gating for LP positions.</p>
            </article>
            <article>
              <h3>`vesting.move`</h3>
              <p>Schedule representation and linear checkpoint helpers for creator-defined unlock cliffs.</p>
            </article>
          </div>
        </section>
      </main>
    </div>
  );
}
