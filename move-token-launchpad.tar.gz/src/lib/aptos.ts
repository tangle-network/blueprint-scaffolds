import type { Launch } from "../types";

const MODULE_ADDRESS = "0xlaunchpad";
const MODULE_NAME = "fair_launchpad";

export async function getAptosClient() {
  const { Aptos, AptosConfig, Network } = await import("@aptos-labs/ts-sdk");
  return new Aptos(
    new AptosConfig({
      network: Network.TESTNET
    })
  );
}

export function shortenAddress(address: string) {
  if (address.length < 12) return address;
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

export function toCurrency(value: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: value > 100 ? 0 : 2
  }).format(value);
}

export function toCompactNumber(value: number) {
  return new Intl.NumberFormat("en-US", {
    notation: "compact",
    maximumFractionDigits: 1
  }).format(value);
}

export function formatDate(value: string) {
  return new Intl.DateTimeFormat("en-US", {
    dateStyle: "medium",
    timeStyle: "short"
  }).format(new Date(value));
}

export function getLaunchTypeLabel(type: Launch["type"]) {
  switch (type) {
    case "fixed":
      return "Fixed Price";
    case "dutch":
      return "Dutch Auction";
    case "overflow":
      return "Overflow";
    case "whitelist":
      return "Whitelist";
    default:
      return type;
  }
}

export function buildContributePayload(launch: Launch, amount: number, account: string) {
  return {
    function: `${MODULE_ADDRESS}::${MODULE_NAME}::contribute`,
    typeArguments: [],
    functionArguments: [launch.id, account, Math.round(amount * 1_000_000)]
  };
}

export function buildClaimPayload(launch: Launch, account: string) {
  return {
    function: `${MODULE_ADDRESS}::${MODULE_NAME}::claim`,
    typeArguments: [],
    functionArguments: [launch.id, account]
  };
}

export function buildLaunchPayload(launch: Launch) {
  return {
    function: `${MODULE_ADDRESS}::${MODULE_NAME}::create_launch`,
    typeArguments: [],
    functionArguments: [
      launch.id,
      launch.project,
      getLaunchTypeLabel(launch.type),
      Math.round(launch.tokenomics.price * 1_000_000),
      launch.contributionMin,
      launch.contributionMax,
      launch.walletCap,
      launch.antiSnipeWindowMinutes,
      launch.lpAllocationPercent,
      launch.lpLockDays
    ]
  };
}
