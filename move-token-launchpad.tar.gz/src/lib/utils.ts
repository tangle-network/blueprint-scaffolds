import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatApt(lamports: number): string {
  return (lamports / 1e8).toFixed(4) + " APT";
}

export function formatTimestamp(ts: number): string {
  return new Date(ts).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function shortenAddress(addr: string): string {
  if (addr.length <= 12) return addr;
  return addr.slice(0, 6) + "..." + addr.slice(-4);
}

export function formatPercent(value: number, total: number): string {
  if (total === 0) return "0%";
  return ((value / total) * 100).toFixed(1) + "%";
}

export function getStatusColor(status: string): string {
  switch (status) {
    case "active":
      return "text-green-400";
    case "upcoming":
      return "text-blue-400";
    case "completed":
      return "text-muted-foreground";
    case "cancelled":
      return "text-red-400";
    default:
      return "text-muted-foreground";
  }
}
