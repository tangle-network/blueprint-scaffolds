import { Gift, RefreshCcw, TimerReset } from "lucide-react";
import { buildClaimPayload, formatDate, toCurrency } from "../lib/aptos";
import type { ContributorPosition, Launch } from "../types";

interface ClaimPortalProps {
  launches: Launch[];
  positions: ContributorPosition[];
}

export function ClaimPortal({ launches, positions }: ClaimPortalProps) {
  return (
    <section className="panel">
      <div className="panel__title-row">
        <div>
          <span className="eyebrow">Claim Portal</span>
          <h3>Unlock tokens, refunds, and vesting events</h3>
        </div>
      </div>

      <div className="claim-list">
        {positions.map((position) => {
          const launch = launches.find((item) => item.id === position.launchId);
          if (!launch) return null;

          return (
            <article className="claim-card" key={position.launchId}>
              <div>
                <h4>{launch.project}</h4>
                <span>{formatDate(launch.vesting[0].unlockAt)} initial unlock</span>
              </div>
              <div className="claim-card__metrics">
                <div>
                  <Gift size={16} />
                  <span>{position.claimable.toLocaleString()} claimable</span>
                </div>
                <div>
                  <RefreshCcw size={16} />
                  <span>{toCurrency(position.refund)} refund</span>
                </div>
                <div>
                  <TimerReset size={16} />
                  <span>{position.vestingProgress}% vested</span>
                </div>
              </div>
              <div className="code-inline">
                <code>{JSON.stringify(buildClaimPayload(launch, "0xyour_wallet"))}</code>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}
