import React from 'react';
import { LaunchType, LaunchStatus } from '../types';
import './LaunchTypeBadge.css';

const LAUNCH_TYPE_LABELS: Record<LaunchType, string> = {
  fixed_price: 'Fixed Price',
  dutch_auction: 'Dutch Auction',
  overflow: 'Overflow',
  whitelist_presale: 'Whitelist',
};

const STATUS_LABELS: Record<LaunchStatus, string> = {
  upcoming: 'Upcoming',
  live: 'Live',
  ended: 'Ended',
  claimed: 'Claimed',
  cancelled: 'Cancelled',
};

export function LaunchTypeBadge({ type }: { type: LaunchType }) {
  return (
    <span className={`launch-type-badge launch-type-${type}`}>
      {LAUNCH_TYPE_LABELS[type]}
    </span>
  );
}

export function StatusBadge({ status }: { status: LaunchStatus }) {
  return (
    <span className={`status-badge status-${status}`}>
      <span className="status-dot" />
      {STATUS_LABELS[status]}
    </span>
  );
}

export function ProgressBar({ value, max, label }: { value: number; max: number; label?: string }) {
  const pct = max > 0 ? Math.min((value / max) * 100, 100) : 0;
  return (
    <div style={{ width: '100%' }}>
      {label && (
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', marginBottom: 4, color: '#64748b' }}>
          <span>{label}</span>
          <span>{pct.toFixed(1)}%</span>
        </div>
      )}
      <div style={{ background: '#e2e8f0', borderRadius: 6, height: 8, overflow: 'hidden' }}>
        <div
          style={{
            width: `${pct}%`,
            height: '100%',
            borderRadius: 6,
            background: pct >= 100 ? '#22c55e' : '#6366f1',
            transition: 'width 0.4s ease',
          }}
        />
      </div>
    </div>
  );
}

export function Card({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div
      style={{
        background: '#fff',
        border: '1px solid #e2e8f0',
        borderRadius: 12,
        padding: 20,
        ...style,
      }}
    >
      {children}
    </div>
  );
}

export function Button({
  children,
  onClick,
  variant = 'primary',
  disabled = false,
  fullWidth = false,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost';
  disabled?: boolean;
  fullWidth?: boolean;
}) {
  const colors = {
    primary: { background: '#6366f1', color: '#fff' },
    secondary: { background: '#f1f5f9', color: '#334155' },
    danger: { background: '#ef4444', color: '#fff' },
    ghost: { background: 'transparent', color: '#6366f1' },
  };
  const c = colors[variant];
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        padding: '10px 20px',
        borderRadius: 8,
        border: variant === 'ghost' ? '1px solid #6366f1' : 'none',
        background: disabled ? '#e2e8f0' : c.background,
        color: disabled ? '#94a3b8' : c.color,
        fontWeight: 600,
        cursor: disabled ? 'not-allowed' : 'pointer',
        width: fullWidth ? '100%' : 'auto',
        fontSize: '0.875rem',
        transition: 'all 0.15s ease',
      }}
    >
      {children}
    </button>
  );
}
