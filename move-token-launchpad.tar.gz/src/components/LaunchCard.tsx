import clsx from "clsx";
import { Clock3, Lock, ShieldCheck, Wallet } from "lucide-react";
import { formatDate, getLaunchTypeLabel, toCompactNumber, toCurrency } from "../lib/aptos";
import type { Launch } from "../types";

interface LaunchCardProps {
  launch: Launch;
  selected: boolean;
  onSelect: (launch: Launch) => void;
}

export function LaunchCard({ launch, selected, onSelect }: LaunchCardProps) {
  return (
    <button
      type="button"
      className={clsx("launch-card", selected && "selected")}
      onClick={() => onSelect(launch)}
    >
      <div className="launch-card__header">
        <div>
          <span className={`pill pill--${launch.status.toLowerCase()}`}>{launch.status}</span>
          <h3>{launch.project}</h3>
        </div>
        <span className="launch-card__type">{getLaunchTypeLabel(launch.type)}</span>
      </div>

      <p>{launch.summary}</p>

      <div className="launch-card__progress">
        <div>
          <strong>{launch.progress}%</strong>
          <span>Filled</span>
        </div>
        <div className="progress-bar">
          <div style={{ width: `${launch.progress}%` }} />
        </div>
      </div>

      <div className="launch-card__grid">
        <div>
          <Clock3 size={16} />
          <span>{formatDate(launch.opensAt)}</span>
        </div>
        <div>
          <Wallet size={16} />
          <span>{toCurrency(launch.contributionMax)} max</span>
        </div>
        <div>
          <ShieldCheck size={16} />
          <span>{launch.antiSnipeWindowMinutes}m anti-snipe</span>
        </div>
        <div>
          <Lock size={16} />
          <span>{launch.lpLockDays}d LP lock</span>
        </div>
      </div>

      <div className="launch-card__footer">
        <span>{toCurrency(launch.tokenomics.totalRaise)} target</span>
        <span>{toCompactNumber(launch.participants)} participants</span>
      </div>
    </button>
  );
}
