import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Calendar, Rocket, User, LayoutDashboard } from 'lucide-react';

const NAV_ITEMS = [
  { path: '/', label: 'Calendar', icon: Calendar },
  { path: '/launches', label: 'Launches', icon: Rocket },
  { path: '/claim', label: 'Claim', icon: User },
  { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
];

export function Navbar() {
  const { pathname } = useLocation();
  return (
    <nav
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '12px 24px',
        background: '#fff',
        borderBottom: '1px solid #e2e8f0',
        position: 'sticky',
        top: 0,
        zIndex: 50,
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <div
          style={{
            width: 32,
            height: 32,
            borderRadius: 8,
            background: 'linear-gradient(135deg, #6366f1, #8b5cf6)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#fff',
            fontWeight: 800,
            fontSize: 14,
          }}
        >
          A
        </div>
        <span style={{ fontWeight: 700, fontSize: 18, color: '#0f172a' }}>AptosPad</span>
      </div>
      <div style={{ display: 'flex', gap: 4 }}>
        {NAV_ITEMS.map(({ path, label, icon: Icon }) => {
          const active = pathname === path || (path !== '/' && pathname.startsWith(path));
          return (
            <Link
              key={path}
              to={path}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                padding: '8px 14px',
                borderRadius: 8,
                textDecoration: 'none',
                fontSize: '0.875rem',
                fontWeight: active ? 600 : 400,
                color: active ? '#6366f1' : '#64748b',
                background: active ? '#eef2ff' : 'transparent',
                transition: 'all 0.15s ease',
              }}
            >
              <Icon size={16} />
              {label}
            </Link>
          );
        })}
      </div>
      <button
        style={{
          padding: '8px 18px',
          borderRadius: 8,
          background: '#6366f1',
          color: '#fff',
          border: 'none',
          fontWeight: 600,
          fontSize: '0.85rem',
          cursor: 'pointer',
        }}
      >
        Connect Wallet
      </button>
    </nav>
  );
}
