import { useMemo, useState } from "react";
import { BadgeDollarSign, Flame, Waves } from "lucide-react";
import { buildContributePayload, formatDate, toCurrency } from "../lib/aptos";
import type { Launch } from "../types";

interface ContributionPanelProps {
  launch: Launch;
}

export function ContributionPanel({ launch }: ContributionPanelProps) {
  const [amount, setAmount] = useState(launch.contributionMin);
  const projectedTokens = useMemo(
    () => Number((amount / launch.tokenomics.price).toFixed(2)),
    [amount, launch.tokenomics.price]
  );
  const payload = useMemo(
    () => buildContributePayload(launch, amount, "0xyour_wallet"),
    [amount, launch]
  );

  return (
    <section className="panel panel--accent">
      <div className="panel__title-row">
        <div>
          <span className="eyebrow">Contribute</span>
          <h3>{launch.project}</h3>
        </div>
        <span className="pill pill--ghost">{launch.tokenomics.ticker}</span>
      </div>

      <div className="metric-row">
        <div>
          <span>Sale window</span>
          <strong>{formatDate(launch.closesAt)}</strong>
        </div>
        <div>
          <span>Wallet cap</span>
          <strong>{toCurrency(launch.walletCap)}</strong>
        </div>
      </div>

      <label className="field">
        <span>Commit in USDC</span>
        <input
          type="range"
          min={launch.contributionMin}
          max={launch.contributionMax}
          step={25}
          value={amount}
          onChange={(event) => setAmount(Number(event.target.value))}
        />
        <div className="field__value">
          <strong>{toCurrency(amount)}</strong>
          <span>
            Min {toCurrency(launch.contributionMin)} / Max {toCurrency(launch.contributionMax)}
          </span>
        </div>
      </label>

      <div className="callout-grid">
        <div>
          <BadgeDollarSign size={18} />
          <span>Projected fill</span>
          <strong>{projectedTokens.toLocaleString()} tokens</strong>
        </div>
        <div>
          <Flame size={18} />
          <span>Anti-snipe</span>
          <strong>Extends {launch.antiSnipeWindowMinutes}m on late bids</strong>
        </div>
        <div>
          <Waves size={18} />
          <span>Auto LP</span>
          <strong>{launch.lpAllocationPercent}% paired post-sale</strong>
        </div>
      </div>

      <div className="code-block">
        <span>Prepared Aptos entry function payload</span>
        <pre>{JSON.stringify(payload, null, 2)}</pre>
      </div>

      <button type="button" className="primary-button">
        Simulate Contribution
      </button>
    </section>
  );
}
