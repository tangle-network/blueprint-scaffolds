import type { PropsWithChildren } from "react";

interface SectionTitleProps extends PropsWithChildren {
  eyebrow: string;
  title: string;
}

export function SectionTitle({ eyebrow, title, children }: SectionTitleProps) {
  return (
    <div className="section-heading">
      <span>{eyebrow}</span>
      <h2>{title}</h2>
      {children ? <p>{children}</p> : null}
    </div>
  );
}
