import { Coins, LayoutTemplate, LockKeyhole, UserRoundCheck } from "lucide-react";
import { buildLaunchPayload, shortenAddress, toCurrency } from "../lib/aptos";
import type { DashboardMetric, Launch } from "../types";

interface CreatorDashboardProps {
  metrics: DashboardMetric[];
  featuredLaunch: Launch;
}

export function CreatorDashboard({ metrics, featuredLaunch }: CreatorDashboardProps) {
  return (
    <section className="panel">
      <div className="panel__title-row">
        <div>
          <span className="eyebrow">Creator Dashboard</span>
          <h3>Configure launch logic and treasury outcomes</h3>
        </div>
      </div>

      <div className="stats-grid">
        {metrics.map((metric) => (
          <article className="stat-card" key={metric.label}>
            <span>{metric.label}</span>
            <strong>{metric.value}</strong>
            <p>{metric.hint}</p>
          </article>
        ))}
      </div>

      <div className="feature-grid">
        <article>
          <LayoutTemplate size={18} />
          <strong>Launch templates</strong>
          <p>Fixed-price, Dutch, overflow, and whitelist presets with audited constraints.</p>
        </article>
        <article>
          <UserRoundCheck size={18} />
          <strong>Contribution guards</strong>
          <p>Per-wallet caps, whitelist roots, min/max ticketing, and anti-bot timing rules.</p>
        </article>
        <article>
          <Coins size={18} />
          <strong>LP automation</strong>
          <p>Reserve allocation for liquidity, paired provisioning, and instant pool receipt custody.</p>
        </article>
        <article>
          <LockKeyhole size={18} />
          <strong>LP lock vault</strong>
          <p>Timelocked LP receipts with creator-facing release countdowns and emergency admin pause.</p>
        </article>
      </div>

      <div className="dashboard-footer">
        <div>
          <span>Launch owner</span>
          <strong>{shortenAddress(featuredLaunch.creator)}</strong>
        </div>
        <div>
          <span>LP allocation</span>
          <strong>{featuredLaunch.lpAllocationPercent}% / {featuredLaunch.lpLockDays}d lock</strong>
        </div>
        <div>
          <span>Raise target</span>
          <strong>{toCurrency(featuredLaunch.tokenomics.totalRaise)}</strong>
        </div>
      </div>

      <div className="code-block">
        <span>Create launch entry function payload</span>
        <pre>{JSON.stringify(buildLaunchPayload(featuredLaunch), null, 2)}</pre>
      </div>
    </section>
  );
}
