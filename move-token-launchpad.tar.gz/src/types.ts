export type LaunchType = 'fixed_price' | 'dutch_auction' | 'overflow' | 'whitelist_presale';
export type LaunchStatus = 'upcoming' | 'live' | 'ended' | 'claimed' | 'cancelled';

export interface VestingSchedule {
  cliffMonths: number;
  durationMonths: number;
  releaseIntervalMonths: number;
}

export interface LaunchConfig {
  id: string;
  creator: string;
  launchType: LaunchType;
  status: LaunchStatus;
  tokenName: string;
  tokenSymbol: string;
  tokenDecimals: number;
  totalSupply: string;
  saleAmount: string;
  pricePerToken: string;
  startPrice?: string;
  endPrice?: string;
  raiseCap: string;
  minContribution: string;
  maxContribution: string;
  startTime: number;
  endTime: number;
  antiSnipeDelaySec: number;
  autoLpPercent: number;
  lpLockMonths: number;
  vesting: VestingSchedule;
  whitelistedAddresses: string[];
  claimedAmount: string;
  raisedAmount: string;
  contributors: number;
}

export interface Contribution {
  launchId: string;
  contributor: string;
  amount: string;
  timestamp: number;
  tokensAllocated: string;
  claimed: boolean;
}

export interface DashboardStats {
  totalLaunches: number;
  activeLaunches: number;
  totalRaised: string;
  totalParticipants: number;
}
