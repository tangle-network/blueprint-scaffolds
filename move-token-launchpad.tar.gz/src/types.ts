export type LaunchType = "fixed" | "dutch" | "overflow" | "whitelist";
export type LaunchStatus = "Upcoming" | "Live" | "Claim" | "Completed";

export interface VestingSlice {
  label: string;
  percent: number;
  unlockAt: string;
}

export interface Tokenomics {
  ticker: string;
  totalRaise: number;
  tokensForSale: number;
  price: number;
  fdv: number;
}

export interface Launch {
  id: string;
  project: string;
  summary: string;
  type: LaunchType;
  status: LaunchStatus;
  opensAt: string;
  closesAt: string;
  whitelistOnly: boolean;
  antiSnipeWindowMinutes: number;
  contributionMin: number;
  contributionMax: number;
  walletCap: number;
  lpAllocationPercent: number;
  lpLockDays: number;
  tokenomics: Tokenomics;
  vesting: VestingSlice[];
  progress: number;
  participants: number;
  creator: string;
}

export interface ContributorPosition {
  launchId: string;
  contributed: number;
  claimable: number;
  refund: number;
  vestingProgress: number;
}

export interface DashboardMetric {
  label: string;
  value: string;
  hint: string;
}
