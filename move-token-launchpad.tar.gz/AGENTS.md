# AGENTS.md

Build a token launchpad on Aptos for fair launches. Token creation, bonding curves, vesting schedules.

## What's here

This project was scaffolded by starter-foundry. The user's prompt drove the choices below — read their prompt first, it takes priority over everything in this file.

- **Family:** `move-contracts`
- **Layers:** `framework:move-package`, `capability:move-launchpad`

## Getting started

```bash
aptos move test
sui move test
```

Key files: `Move.toml`, `sources/TreasuryVault.move`, `tests/TreasuryVaultTests.move`

## Suggested build plan

These are starting points — adapt them to the user's actual needs.

- **Components:** SaleModule, VestingModule, WhitelistModule
- **Data models:** Sale, Allocation, VestingSchedule
- **Integrations:** Fixed-price sale, Dutch auction, Linear vesting

## How to use this scaffold

This is a starting point, not a contract. You own every file.

- **Customize freely.** Replace components, change the layout, swap the color scheme — whatever fits the user's product.
- **The scaffold saves you setup time** — Tailwind, shadcn/ui, path aliases, and framework config are ready. Don't redo them.
- **Check `.starter-foundry/compose-report.json`** if you want to see which layer wrote which file.
- **Update this file** as the project evolves. Delete sections that no longer apply.
