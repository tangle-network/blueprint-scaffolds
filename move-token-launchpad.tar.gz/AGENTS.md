# AGENTS.md

## Goal

Build a token launchpad on Aptos for fair launches. Token creation, bonding curves, vesting schedules.

## Stack

- Family: `move-contracts`
- Layers: `capability:move-launchpad`

## Entry Points

- `Move.toml`
- `sources/TreasuryVault.move`
- `tests/TreasuryVaultTests.move`

## Commands

- `aptos move test`
- `sui move test`

## Build Plan

Components: SaleModule, VestingModule, WhitelistModule
Data models: Sale, Allocation, VestingSchedule
Integrations: Fixed-price sale, Dutch auction, Linear vesting

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
