import { useMemo, useState } from "react";
import { Aptos, AptosConfig, Network } from "@aptos-labs/ts-sdk";
import { shortAddr } from "../lib/format";

type WalletState = {
  address?: string;
  network: Network;
};

export function WalletBar() {
  const [state, setState] = useState<WalletState>({ network: Network.TESTNET });
  const [busy, setBusy] = useState(false);
  const aptos = useMemo(() => new Aptos(new AptosConfig({ network: state.network })), [state.network]);

  async function connectPetra() {
    const anyWindow = window as unknown as { aptos?: { connect: () => Promise<{ address: string }> } };
    if (!anyWindow.aptos?.connect) {
      alert("No Aptos wallet found. Install Petra or compatible wallet.");
      return;
    }
    setBusy(true);
    try {
      const res = await anyWindow.aptos.connect();
      setState((s) => ({ ...s, address: res.address }));
    } finally {
      setBusy(false);
    }
  }

  async function pingChain() {
    setBusy(true);
    try {
      const li = await aptos.getLedgerInfo();
      alert(`Connected to ${state.network}. Ledger version: ${li.ledger_version}`);
    } catch (e) {
      alert(`RPC error: ${String(e)}`);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="wallet">
      <select
        className="select"
        value={state.network}
        onChange={(e) => setState((s) => ({ ...s, network: e.target.value as Network }))}
        aria-label="Network"
      >
        <option value={Network.DEVNET}>Devnet</option>
        <option value={Network.TESTNET}>Testnet</option>
        <option value={Network.MAINNET}>Mainnet</option>
      </select>
      <button className="btn" onClick={pingChain} disabled={busy}>
        RPC
      </button>
      {state.address ? (
        <div className="pill" title={state.address}>
          {shortAddr(state.address)}
        </div>
      ) : (
        <button className="btnPrimary" onClick={connectPetra} disabled={busy}>
          Connect Wallet
        </button>
      )}
    </div>
  );
}
