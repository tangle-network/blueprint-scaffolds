import { useMemo } from "react";
import { ResponsiveContainer, Area, AreaChart, CartesianGrid, Tooltip, XAxis, YAxis } from "recharts";
import { formatNumber } from "../lib/format";

type Point = { t: string; vol: number; tvl: number };

function makeSeries(): Point[] {
  const now = Date.now();
  const days = 30;
  const pts: Point[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(now - i * 24 * 3600 * 1000);
    const t = `${d.getMonth() + 1}/${d.getDate()}`;
    const base = 100 + (days - i) * 6;
    pts.push({
      t,
      vol: base * 1000 + Math.sin(i / 3) * 12000,
      tvl: 2_000_000 + base * 5000 + Math.cos(i / 4) * 25000,
    });
  }
  return pts;
}

export default function AnalyticsPage() {
  const data = useMemo(() => makeSeries(), []);
  const tvl = data[data.length - 1]?.tvl ?? 0;
  const vol = data[data.length - 1]?.vol ?? 0;

  return (
    <div className="grid2">
      <section className="card">
        <h2 className="h2">Overview</h2>
        <div className="subgrid">
          <div className="kv">
            <div className="k">TVL (demo)</div>
            <div className="v">${formatNumber(tvl, 0)}</div>
          </div>
          <div className="kv">
            <div className="k">24h Volume (demo)</div>
            <div className="v">${formatNumber(vol, 0)}</div>
          </div>
          <div className="kv">
            <div className="k">Pools</div>
            <div className="v">12</div>
          </div>
        </div>
      </section>

      <section className="card">
        <h2 className="h2">Volume / TVL</h2>
        <div style={{ width: "100%", height: 280 }}>
          <ResponsiveContainer>
            <AreaChart data={data} margin={{ left: 8, right: 8, top: 8, bottom: 0 }}>
              <defs>
                <linearGradient id="c1" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#266dff" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="#266dff" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="c2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#ff8a3d" stopOpacity={0.25} />
                  <stop offset="100%" stopColor="#ff8a3d" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="rgba(255,255,255,0.08)" vertical={false} />
              <XAxis dataKey="t" tick={{ fill: "rgba(255,255,255,0.75)", fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "rgba(255,255,255,0.75)", fontSize: 12 }} axisLine={false} tickLine={false} width={52} />
              <Tooltip
                contentStyle={{
                  background: "rgba(12, 14, 18, 0.92)",
                  border: "1px solid rgba(255,255,255,0.12)",
                  borderRadius: 12,
                }}
                labelStyle={{ color: "rgba(255,255,255,0.85)" }}
              />
              <Area type="monotone" dataKey="tvl" stroke="#ff8a3d" fill="url(#c2)" strokeWidth={2} />
              <Area type="monotone" dataKey="vol" stroke="#266dff" fill="url(#c1)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </section>
    </div>
  );
}
