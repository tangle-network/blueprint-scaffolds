import { useMemo, useState } from "react";
import { Token, sampleTokens } from "../services/quote";
import { formatNumber } from "../lib/format";

type Position = {
  id: string;
  token0: Token;
  token1: Token;
  lowerTick: number;
  upperTick: number;
  liquidity: number;
};

export default function LiquidityPage() {
  const tokens = useMemo(() => sampleTokens(), []);
  const [token0, setToken0] = useState(tokens[0]);
  const [token1, setToken1] = useState(tokens[1]);
  const [lower, setLower] = useState(-600);
  const [upper, setUpper] = useState(600);
  const [liquidity, setLiquidity] = useState("1000");
  const [positions, setPositions] = useState<Position[]>(() => [
    {
      id: "pos_1",
      token0: tokens[0],
      token1: tokens[1],
      lowerTick: -300,
      upperTick: 300,
      liquidity: 500,
    },
  ]);

  function addPosition() {
    const liq = Number(liquidity);
    if (!Number.isFinite(liq) || liq <= 0) return;
    setPositions((p) => [
      {
        id: `pos_${p.length + 1}`,
        token0,
        token1,
        lowerTick: lower,
        upperTick: upper,
        liquidity: liq,
      },
      ...p,
    ]);
  }

  return (
    <div className="grid2">
      <section className="card">
        <h2 className="h2">Add Liquidity (Concentrated)</h2>
        <div className="row">
          <label className="label">Token 0</label>
          <select
            className="select grow"
            value={token0.symbol}
            onChange={(e) => setToken0(tokens.find((t) => t.symbol === e.target.value) ?? tokens[0])}
          >
            {tokens.map((t) => (
              <option key={t.symbol} value={t.symbol}>
                {t.symbol}
              </option>
            ))}
          </select>
        </div>
        <div className="row">
          <label className="label">Token 1</label>
          <select
            className="select grow"
            value={token1.symbol}
            onChange={(e) => setToken1(tokens.find((t) => t.symbol === e.target.value) ?? tokens[1])}
          >
            {tokens.map((t) => (
              <option key={t.symbol} value={t.symbol}>
                {t.symbol}
              </option>
            ))}
          </select>
        </div>

        <div className="row">
          <label className="label">Lower tick</label>
          <input className="input" value={String(lower)} onChange={(e) => setLower(Math.floor(Number(e.target.value)))} />
        </div>
        <div className="row">
          <label className="label">Upper tick</label>
          <input className="input" value={String(upper)} onChange={(e) => setUpper(Math.floor(Number(e.target.value)))} />
        </div>

        <div className="row">
          <label className="label">Liquidity</label>
          <input className="input" value={liquidity} onChange={(e) => setLiquidity(e.target.value)} inputMode="decimal" />
        </div>

        <button className="btnPrimary wide" onClick={addPosition} disabled={token0.symbol === token1.symbol}>
          Mint Position (demo)
        </button>
        <p className="muted">
          Replace with on-chain position mint (NFT or FA) and pool init if missing.
        </p>
      </section>

      <section className="card">
        <h2 className="h2">Your Positions</h2>
        <div className="table">
          <div className="thead">
            <div>ID</div>
            <div>Pair</div>
            <div>Range</div>
            <div>Liquidity</div>
          </div>
          {positions.map((p) => (
            <div className="trow" key={p.id}>
              <div className="mono">{p.id}</div>
              <div>
                {p.token0.symbol}/{p.token1.symbol}
              </div>
              <div className="mono">
                [{p.lowerTick}, {p.upperTick}]
              </div>
              <div className="mono">{formatNumber(p.liquidity, 2)}</div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
