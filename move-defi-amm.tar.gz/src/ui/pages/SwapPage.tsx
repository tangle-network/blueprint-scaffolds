import { useMemo, useState } from "react";
import { z } from "zod";
import { formatNumber } from "../lib/format";
import { QuoteEngine, Token, sampleTokens } from "../services/quote";

const AmountSchema = z
  .string()
  .trim()
  .refine((s) => s === "" || (!Number.isNaN(Number(s)) && Number(s) >= 0), "Invalid amount");

export default function SwapPage() {
  const tokens = useMemo(() => sampleTokens(), []);
  const [from, setFrom] = useState<Token>(tokens[0]);
  const [to, setTo] = useState<Token>(tokens[1]);
  const [amountIn, setAmountIn] = useState("1");
  const [slippageBps, setSlippageBps] = useState(50);
  const [hops, setHops] = useState(3);

  const validation = AmountSchema.safeParse(amountIn);
  const amountInNum = validation.success ? Number(amountIn || 0) : NaN;
  const engine = useMemo(() => new QuoteEngine(), []);

  const quote = useMemo(() => {
    if (!validation.success || !Number.isFinite(amountInNum)) return null;
    return engine.quoteBestRoute({
      tokenIn: from,
      tokenOut: to,
      amountIn: amountInNum,
      maxHops: hops,
      slippageBps,
    });
  }, [amountInNum, engine, from, hops, slippageBps, to, validation.success]);

  return (
    <div className="grid2">
      <section className="card">
        <h2 className="h2">Swap</h2>
        <div className="row">
          <label className="label">From</label>
          <select
            className="select grow"
            value={from.symbol}
            onChange={(e) => setFrom(tokens.find((t) => t.symbol === e.target.value) ?? tokens[0])}
          >
            {tokens.map((t) => (
              <option key={t.symbol} value={t.symbol}>
                {t.symbol}
              </option>
            ))}
          </select>
          <input
            className="input amount"
            value={amountIn}
            onChange={(e) => setAmountIn(e.target.value)}
            placeholder="0.0"
            inputMode="decimal"
          />
        </div>

        <div className="row">
          <label className="label">To</label>
          <select
            className="select grow"
            value={to.symbol}
            onChange={(e) => setTo(tokens.find((t) => t.symbol === e.target.value) ?? tokens[1])}
          >
            {tokens.map((t) => (
              <option key={t.symbol} value={t.symbol}>
                {t.symbol}
              </option>
            ))}
          </select>
          <div className="pill amount" aria-label="Estimated output">
            {quote ? formatNumber(quote.amountOut, 6) : "-"}
          </div>
        </div>

        <div className="row">
          <label className="label">Slippage</label>
          <input
            className="input"
            value={(slippageBps / 100).toFixed(2)}
            onChange={(e) => setSlippageBps(Math.max(0, Math.round(Number(e.target.value) * 100)))}
            inputMode="decimal"
          />
          <div className="muted">%</div>
        </div>

        <div className="row">
          <label className="label">Max hops</label>
          <input
            className="input"
            value={String(hops)}
            onChange={(e) => setHops(Math.max(1, Math.min(4, Math.floor(Number(e.target.value) || 1))))}
            inputMode="numeric"
          />
          <div className="muted">(1-4)</div>
        </div>

        {!validation.success && <div className="error">{validation.error.issues[0]?.message}</div>}

        <button
          className="btnPrimary wide"
          onClick={() => alert("Hook up on-chain swap payload here")}
          disabled={!quote || !validation.success || from.symbol === to.symbol}
        >
          Swap (demo)
        </button>

        {quote && (
          <div className="subgrid">
            <div className="kv">
              <div className="k">Route</div>
              <div className="v">{quote.route.map((t) => t.symbol).join(" -> ")}</div>
            </div>
            <div className="kv">
              <div className="k">Min received</div>
              <div className="v">{formatNumber(quote.minAmountOut, 6)} {to.symbol}</div>
            </div>
            <div className="kv">
              <div className="k">Price impact</div>
              <div className="v">{formatNumber(quote.priceImpactPct, 4)}%</div>
            </div>
          </div>
        )}
      </section>

      <section className="card">
        <h2 className="h2">Pool preview</h2>
        <p className="muted">
          This UI includes a local quote engine for routing demos. Replace with on-chain pool discovery + quoting.
        </p>
        <div className="code">
          <div>Move packages are in <code>move/</code>.</div>
          <div>Features: pools, LP token, CL positions, TWAP, flash loans.</div>
        </div>
      </section>
    </div>
  );
}
