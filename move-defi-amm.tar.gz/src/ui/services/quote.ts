export type Token = {
  symbol: string;
  decimals: number;
};

type Edge = {
  a: string;
  b: string;
  feeBps: number;
  price: number; // b per a
  depth: number; // larger => lower impact
};

export function sampleTokens(): Token[] {
  return [
    { symbol: "APT", decimals: 8 },
    { symbol: "USDC", decimals: 6 },
    { symbol: "USDT", decimals: 6 },
    { symbol: "WETH", decimals: 8 },
    { symbol: "WBTC", decimals: 8 },
  ];
}

function sampleEdges(): Edge[] {
  return [
    { a: "APT", b: "USDC", feeBps: 30, price: 9.2, depth: 200_000 },
    { a: "APT", b: "USDT", feeBps: 30, price: 9.15, depth: 160_000 },
    { a: "USDC", b: "USDT", feeBps: 5, price: 0.999, depth: 900_000 },
    { a: "USDC", b: "WETH", feeBps: 30, price: 1 / 3200, depth: 600_000 },
    { a: "WETH", b: "WBTC", feeBps: 30, price: 1 / 18.5, depth: 280_000 },
    { a: "APT", b: "WETH", feeBps: 30, price: 1 / 350, depth: 120_000 },
  ];
}

export type QuoteRequest = {
  tokenIn: Token;
  tokenOut: Token;
  amountIn: number;
  maxHops: number;
  slippageBps: number;
};

export type QuoteResult = {
  route: Token[];
  amountOut: number;
  minAmountOut: number;
  priceImpactPct: number;
  totalFeePct: number;
};

export class QuoteEngine {
  private tokensBySymbol: Map<string, Token>;
  private edges: Edge[];

  constructor(tokens = sampleTokens(), edges = sampleEdges()) {
    this.tokensBySymbol = new Map(tokens.map((t) => [t.symbol, t]));
    this.edges = edges;
  }

  quoteBestRoute(req: QuoteRequest): QuoteResult | null {
    const start = req.tokenIn.symbol;
    const goal = req.tokenOut.symbol;
    if (start === goal) return null;
    if (!Number.isFinite(req.amountIn) || req.amountIn <= 0) return null;
    const maxHops = Math.max(1, Math.min(4, req.maxHops));

    const routes = this.enumerateRoutes(start, goal, maxHops);
    let best: QuoteResult | null = null;
    for (const r of routes) {
      const q = this.quoteRoute(r, req.amountIn, req.slippageBps);
      if (!q) continue;
      if (!best || q.amountOut > best.amountOut) best = q;
    }
    return best;
  }

  private enumerateRoutes(start: string, goal: string, maxHops: number): string[][] {
    const adj = new Map<string, string[]>();
    for (const e of this.edges) {
      adj.set(e.a, [...(adj.get(e.a) ?? []), e.b]);
      adj.set(e.b, [...(adj.get(e.b) ?? []), e.a]);
    }

    const routes: string[][] = [];
    const dfs = (path: string[]) => {
      const last = path[path.length - 1];
      if (last === goal) {
        routes.push(path.slice());
        return;
      }
      if (path.length - 1 >= maxHops) return;
      for (const nxt of adj.get(last) ?? []) {
        if (path.includes(nxt)) continue;
        path.push(nxt);
        dfs(path);
        path.pop();
      }
    };
    dfs([start]);
    return routes;
  }

  private quoteRoute(routeSymbols: string[], amountIn: number, slippageBps: number): QuoteResult | null {
    let amt = amountIn;
    let feePct = 0;
    let impactPct = 0;

    for (let i = 0; i < routeSymbols.length - 1; i++) {
      const a = routeSymbols[i];
      const b = routeSymbols[i + 1];
      const edge = this.findEdge(a, b);
      if (!edge) return null;
      const fee = edge.feeBps / 10_000;
      feePct += fee;
      const outBeforeImpact = this.convert(edge, a, b, amt) * (1 - fee);
      const impact = Math.min(0.02, amt / edge.depth / 6);
      impactPct += impact;
      amt = outBeforeImpact * (1 - impact);
    }

    const minAmountOut = amt * (1 - slippageBps / 10_000);
    const route = routeSymbols
      .map((s) => this.tokensBySymbol.get(s))
      .filter((t): t is Token => Boolean(t));

    if (route.length !== routeSymbols.length) return null;

    return {
      route,
      amountOut: amt,
      minAmountOut,
      priceImpactPct: impactPct * 100,
      totalFeePct: feePct * 100,
    };
  }

  private findEdge(a: string, b: string): Edge | null {
    for (const e of this.edges) {
      if ((e.a === a && e.b === b) || (e.a === b && e.b === a)) return e;
    }
    return null;
  }

  private convert(edge: Edge, a: string, b: string, amountA: number): number {
    if (edge.a === a && edge.b === b) return amountA * edge.price;
    if (edge.a === b && edge.b === a) return amountA / edge.price;
    return NaN;
  }
}
