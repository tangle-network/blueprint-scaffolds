import { NavLink, Route, Routes } from "react-router-dom";
import SwapPage from "./pages/SwapPage";
import LiquidityPage from "./pages/LiquidityPage";
import AnalyticsPage from "./pages/AnalyticsPage";
import { useMemo } from "react";
import { WalletBar } from "./components/WalletBar";
import { clsx } from "./lib/clsx";

export default function App() {
  const links = useMemo(
    () => [
      { to: "/", label: "Swap" },
      { to: "/liquidity", label: "Liquidity" },
      { to: "/analytics", label: "Analytics" },
    ],
    [],
  );

  return (
    <div className="app">
      <header className="top">
        <div className="brand">
          <div className="mark" />
          <div>
            <div className="brandTitle">Aptos AMM DEX</div>
            <div className="brandSub">Permissionless pools • CL positions • Flash loans</div>
          </div>
        </div>
        <WalletBar />
      </header>

      <nav className="nav">
        {links.map((l) => (
          <NavLink
            key={l.to}
            to={l.to}
            className={({ isActive }) => clsx("navItem", isActive && "navItemActive")}
            end={l.to === "/"}
          >
            {l.label}
          </NavLink>
        ))}
      </nav>

      <main className="main">
        <Routes>
          <Route path="/" element={<SwapPage />} />
          <Route path="/liquidity" element={<LiquidityPage />} />
          <Route path="/analytics" element={<AnalyticsPage />} />
        </Routes>
      </main>

      <footer className="footer">
        <div className="muted">
          UI builds locally; Move modules live in <code>move/</code>.
        </div>
      </footer>
    </div>
  );
}
