module aptos_amm::lp_token {
    use std::string;
    use aptos_framework::fungible_asset::{Self, FungibleAsset, Metadata, MintRef, BurnRef, TransferRef};

    struct LPAsset has key {
        metadata: Metadata,
        mint_ref: MintRef,
        burn_ref: BurnRef,
        transfer_ref: TransferRef,
    }

    public fun initialize(asset: &signer, name: string::String, symbol: string::String) {
        let constructor_ref = fungible_asset::create(asset, string::utf8(b""), name, symbol, 8, string::utf8(b""));
        let metadata = fungible_asset::mint_ref_metadata(&constructor_ref);
        let mint_ref = fungible_asset::generate_mint_ref(&constructor_ref);
        let burn_ref = fungible_asset::generate_burn_ref(&constructor_ref);
        let transfer_ref = fungible_asset::generate_transfer_ref(&constructor_ref);
        fungible_asset::constructor_ref_to_fungible_asset(&constructor_ref);
        move_to(asset, LPAsset { metadata, mint_ref, burn_ref, transfer_ref });
    }

    public fun mint(account: &signer, lp: &LPAsset, amount: u64): FungibleAsset {
        fungible_asset::mint(&lp.mint_ref, amount, address_of(account))
    }

    public fun burn(lp: &LPAsset, fa: FungibleAsset) {
        fungible_asset::burn(&lp.burn_ref, fa);
    }

    public fun metadata(lp: &LPAsset): Metadata {
        lp.metadata
    }

    public fun exists_at(addr: address): bool {
        exists<LPAsset>(addr)
    }

    public fun mint_to(account: &signer, lp: &LPAsset, to: address, amount: u64) {
        let fa = fungible_asset::mint(&lp.mint_ref, amount, address_of(account));
        fungible_asset::deposit_with_ref(&lp.transfer_ref, to, fa);
    }

    public fun burn_from(lp: &LPAsset, from: address, amount: u64) {
        let fa = fungible_asset::withdraw_with_ref(&lp.transfer_ref, from, amount);
        fungible_asset::burn(&lp.burn_ref, fa);
    }
}
