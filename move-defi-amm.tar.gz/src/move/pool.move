module aptos_amm::pool {
    use std::signer;
    use aptos_framework::coin::{Self, Coin};
    use aptos_amm::math;
    use aptos_amm::lp_token;

    const E_NOT_INITIALIZED: u64 = 100;
    const E_INSUFFICIENT_LIQUIDITY: u64 = 101;
    const E_INVALID_AMOUNT: u64 = 102;
    const E_SLIPPAGE_EXCEEDED: u64 = 103;
    const E_IDENTICAL_TOKENS: u64 = 104;
    const E_NO_LIQUIDITY: u64 = 105;

    struct Pool<phantom X, phantom Y> has key {
        coin_x_reserve: Coin<X>,
        coin_y_reserve: Coin<Y>,
        fee_bps: u64,
        k_last: u128,
    }

    struct PoolInfo has key, store, drop, copy {
        reserve_x: u64,
        reserve_y: u64,
        fee_bps: u64,
        total_lp: u64,
    }

    struct ConcentratedPosition has store, drop {
        tick_lower: u64,
        tick_upper: u64,
        liquidity: u64,
        fee_growth_inside_last: u64,
    }

    struct UserPositions has key {
        positions: vector<ConcentratedPosition>,
    }

    public fun initialize<X, Y>(admin: &signer, fee_bps: u64) {
        math::validate_fee_bps(fee_bps);
        move_to(admin, Pool<X, Y> {
            coin_x_reserve: coin::zero<X>(),
            coin_y_reserve: coin::zero<Y>(),
            fee_bps,
            k_last: 0,
        });
    }

    public entry fun create_pool<X, Y>(admin: &signer, fee_bps: u64) {
        initialize<X, Y>(admin, fee_bps);
    }

    public entry fun add_liquidity<X, Y>(
        user: &signer,
        amount_x: u64,
        amount_y: u64,
        min_lp: u64,
    ) acquires Pool {
        assert!(amount_x > 0 && amount_y > 0, E_INVALID_AMOUNT);
        let pool = borrow_global_mut<Pool<X, Y>>(signer::address_of(user));
        let reserve_x = coin::value(&pool.coin_x_reserve);
        let reserve_y = coin::value(&pool.coin_y_reserve);

        let optimal_y = if (reserve_x == 0 && reserve_y == 0) {
            amount_y
        } else {
            math::quote(amount_x, reserve_x, reserve_y)
        };

        assert!(optimal_y >= amount_y || amount_y >= optimal_y, E_INVALID_AMOUNT);

        let coin_x = coin::withdraw<X>(user, amount_x);
        let coin_y = coin::withdraw<Y>(user, optimal_y > amount_y ? amount_y : optimal_y);

        let deposited_x = coin::value(&coin_x);
        let deposited_y = coin::value(&coin_y);

        let lp_amount = if (pool.k_last == 0) {
            let prod = (deposited_x as u128) * (deposited_y as u128);
            (math::sqrt(((prod as u128) as u64)) as u64)
        } else {
            math::mul_div(deposited_x, (pool.k_last as u64), reserve_x)
        };

        assert!(lp_amount >= min_lp, E_SLIPPAGE_EXCEEDED);

        coin::merge(&mut pool.coin_x_reserve, coin_x);
        coin::merge(&mut pool.coin_y_reserve, coin_y);

        pool.k_last = ((coin::value(&pool.coin_x_reserve) as u128) * (coin::value(&pool.coin_y_reserve) as u128));
    }

    public entry fun remove_liquidity<X, Y>(
        user: &signer,
        lp_amount: u64,
        min_x: u64,
        min_y: u64,
    ) acquires Pool {
        assert!(lp_amount > 0, E_INVALID_AMOUNT);
        let pool = borrow_global_mut<Pool<X, Y>>(signer::address_of(user));

        let reserve_x = coin::value(&pool.coin_x_reserve);
        let reserve_y = coin::value(&pool.coin_y_reserve);
        let total_lp = math::sqrt(((reserve_x as u128) * (reserve_y as u128)) as u64);

        assert!(total_lp > 0, E_NO_LIQUIDITY);

        let amount_x = math::mul_div(lp_amount, reserve_x, total_lp);
        let amount_y = math::mul_div(lp_amount, reserve_y, total_lp);

        assert!(amount_x >= min_x, E_SLIPPAGE_EXCEEDED);
        assert!(amount_y >= min_y, E_SLIPPAGE_EXCEEDED);

        let coin_x = coin::extract(&mut pool.coin_x_reserve, amount_x);
        let coin_y = coin::extract(&mut pool.coin_y_reserve, amount_y);

        coin::deposit(signer::address_of(user), coin_x);
        coin::deposit(signer::address_of(user), coin_y);

        pool.k_last = ((coin::value(&pool.coin_x_reserve) as u128) * (coin::value(&pool.coin_y_reserve) as u128));
    }

    public entry fun swap_x_to_y<X, Y>(
        user: &signer,
        amount_in: u64,
        min_amount_out: u64,
    ) acquires Pool {
        assert!(amount_in > 0, E_INVALID_AMOUNT);
        let pool = borrow_global_mut<Pool<X, Y>>(signer::address_of(user));

        let reserve_x = coin::value(&pool.coin_x_reserve);
        let reserve_y = coin::value(&pool.coin_y_reserve);
        assert!(reserve_x > 0 && reserve_y > 0, E_NO_LIQUIDITY);

        let amount_out = math::get_amount_out(amount_in, reserve_x, reserve_y, pool.fee_bps);
        assert!(amount_out >= min_amount_out, E_SLIPPAGE_EXCEEDED);
        assert!(amount_out < reserve_y, E_INSUFFICIENT_LIQUIDITY);

        let coin_in = coin::withdraw<X>(user, amount_in);
        let coin_out = coin::extract(&mut pool.coin_y_reserve, amount_out);

        coin::merge(&mut pool.coin_x_reserve, coin_in);
        coin::deposit(signer::address_of(user), coin_out);
    }

    public entry fun swap_y_to_x<X, Y>(
        user: &signer,
        amount_in: u64,
        min_amount_out: u64,
    ) acquires Pool {
        assert!(amount_in > 0, E_INVALID_AMOUNT);
        let pool = borrow_global_mut<Pool<X, Y>>(signer::address_of(user));

        let reserve_x = coin::value(&pool.coin_x_reserve);
        let reserve_y = coin::value(&pool.coin_y_reserve);
        assert!(reserve_x > 0 && reserve_y > 0, E_NO_LIQUIDITY);

        let amount_out = math::get_amount_out(amount_in, reserve_y, reserve_x, pool.fee_bps);
        assert!(amount_out >= min_amount_out, E_SLIPPAGE_EXCEEDED);
        assert!(amount_out < reserve_x, E_INSUFFICIENT_LIQUIDITY);

        let coin_in = coin::withdraw<Y>(user, amount_in);
        let coin_out = coin::extract(&mut pool.coin_x_reserve, amount_out);

        coin::merge(&mut pool.coin_y_reserve, coin_in);
        coin::deposit(signer::address_of(user), coin_out);
    }

    public entry fun multi_hop_swap<X, Y, Z>(
        user: &signer,
        amount_in: u64,
        min_amount_out: u64,
    ) acquires Pool {
        assert!(amount_in > 0, E_INVALID_AMOUNT);

        let pool_xy = borrow_global_mut<Pool<X, Y>>(signer::address_of(user));
        let reserve_x = coin::value(&pool_xy.coin_x_reserve);
        let reserve_y = coin::value(&pool_xy.coin_y_reserve);
        let mid_amount = math::get_amount_out(amount_in, reserve_x, reserve_y, pool_xy.fee_bps);

        let coin_in = coin::withdraw<X>(user, amount_in);
        let coin_mid = coin::extract(&mut pool_xy.coin_y_reserve, mid_amount);
        coin::merge(&mut pool_xy.coin_x_reserve, coin_in);

        let pool_yz = borrow_global_mut<Pool<Y, Z>>(signer::address_of(user));
        let reserve_y2 = coin::value(&pool_yz.coin_x_reserve);
        let reserve_z = coin::value(&pool_yz.coin_y_reserve);
        let final_amount = math::get_amount_out(mid_amount, reserve_y2, reserve_z, pool_yz.fee_bps);

        assert!(final_amount >= min_amount_out, E_SLIPPAGE_EXCEEDED);

        let coin_out = coin::extract(&mut pool_yz.coin_y_reserve, final_amount);
        coin::merge(&mut pool_yz.coin_x_reserve, coin_mid);
        coin::deposit(signer::address_of(user), coin_out);
    }

    public entry fun open_concentrated_position<X, Y>(
        user: &signer,
        tick_lower: u64,
        tick_upper: u64,
        liquidity: u64,
    ) acquires Pool, UserPositions {
        assert!(tick_upper > tick_lower, E_INVALID_TICK);
        assert!(liquidity > 0, E_INVALID_AMOUNT);

        let pool = borrow_global_mut<Pool<X, Y>>(signer::address_of(user));
        let amount = math::get_concentrated_liquidity_amount(
            tick_lower, tick_upper, liquidity,
        );

        let coin_x = coin::withdraw<X>(user, amount);
        let coin_y = coin::withdraw<Y>(user, math::quote(amount, coin::value(&pool.coin_x_reserve), coin::value(&pool.coin_y_reserve)));

        coin::merge(&mut pool.coin_x_reserve, coin_x);
        coin::merge(&mut pool.coin_y_reserve, coin_y);

        let pos = ConcentratedPosition {
            tick_lower,
            tick_upper,
            liquidity,
            fee_growth_inside_last: 0,
        };

        if (!exists<UserPositions>(signer::address_of(user))) {
            move_to(user, UserPositions { positions: vector::empty() });
        };
        let user_positions = borrow_global_mut<UserPositions>(signer::address_of(user));
        vector::push_back(&mut user_positions.positions, pos);
    }

    public fun get_reserves<X, Y>(pool_addr: address): (u64, u64) acquires Pool {
        let pool = borrow_global<Pool<X, Y>>(pool_addr);
        (coin::value(&pool.coin_x_reserve), coin::value(&pool.coin_y_reserve))
    }

    public fun get_fee_bps<X, Y>(pool_addr: address): u64 acquires Pool {
        borrow_global<Pool<X, Y>>(pool_addr).fee_bps
    }

    public fun set_fee<X, Y>(admin: &signer, new_fee_bps: u64) acquires Pool {
        math::validate_fee_bps(new_fee_bps);
        let pool = borrow_global_mut<Pool<X, Y>>(signer::address_of(admin));
        pool.fee_bps = new_fee_bps;
    }

    fun sqrt(x: u64): u64 {
        math::sqrt(x)
    }
}
