module aptos_amm::math {
    const SCALE: u64 = 1000000;
    const MAX_FEE_BPS: u64 = 10000;
    const E_FEE_EXCEEDS_MAX: u64 = 1;
    const E_INSUFFICIENT_OUTPUT: u64 = 2;
    const E_ZERO_AMOUNT: u64 = 3;
    const E_INVALID_TICK: u64 = 4;

    public fun scale(): u64 {
        SCALE
    }

    public fun mul_div(x: u64, y: u64, z: u64): u64 {
        assert!(z > 0, E_ZERO_AMOUNT);
        let x128 = (x as u128) * (y as u128);
        ((x128 / (z as u128)) as u64)
    }

    public fun get_amount_out(amount_in: u64, reserve_in: u64, reserve_out: u64, fee_bps: u64): u64 {
        assert!(amount_in > 0, E_ZERO_AMOUNT);
        assert!(reserve_in > 0 && reserve_out > 0, E_ZERO_AMOUNT);
        assert!(fee_bps <= MAX_FEE_BPS, E_FEE_EXCEEDS_MAX);
        let fee = mul_div(amount_in, fee_bps, MAX_FEE_BPS);
        let amount_in_with_fee = amount_in - fee;
        let numerator = (amount_in_with_fee as u128) * (reserve_out as u128);
        let denominator = (reserve_in as u128) + (amount_in_with_fee as u128);
        ((numerator / denominator) as u64)
    }

    public fun get_amount_in(amount_out: u64, reserve_in: u64, reserve_out: u64, fee_bps: u64): u64 {
        assert!(amount_out > 0, E_ZERO_AMOUNT);
        assert!(reserve_in > 0 && reserve_out > 0, E_ZERO_AMOUNT);
        assert!(amount_out < reserve_out, E_INSUFFICIENT_OUTPUT);
        assert!(fee_bps <= MAX_FEE_BPS, E_FEE_EXCEEDS_MAX);
        let numerator = (reserve_in as u128) * (amount_out as u128);
        let denominator = ((reserve_out - amount_out) as u128);
        let amount_in = ((numerator / denominator) as u64);
        let fee = mul_div(amount_in, fee_bps, MAX_FEE_BPS);
        amount_in + fee
    }

    public fun quote(amount_a: u64, reserve_a: u64, reserve_b: u64): u64 {
        assert!(amount_a > 0, E_ZERO_AMOUNT);
        assert!(reserve_a > 0 && reserve_b > 0, E_ZERO_AMOUNT);
        mul_div(amount_a, reserve_b, reserve_a)
    }

    public fun validate_fee_bps(fee_bps: u64) {
        assert!(fee_bps <= MAX_FEE_BPS, E_FEE_EXCEEDS_MAX);
    }

    public fun tick_to_price(tick: u64): u64 {
        tick
    }

    public fun price_to_tick(price: u64): u64 {
        assert!(price > 0, E_INVALID_TICK);
        price
    }

    public fun get_concentrated_liquidity_amount(
        sqrt_price_a: u64,
        sqrt_price_b: u64,
        liquidity: u64,
    ): u64 {
        assert!(sqrt_price_b > sqrt_price_a, E_INVALID_TICK);
        let delta = sqrt_price_b - sqrt_price_a;
        mul_div(liquidity, delta, SCALE)
    }

    public fun sqrt(x: u64): u64 {
        if (x == 0) { return 0 };
        if (x < 4) { return 1 };
        let mut z = x;
        let mut y = (x + 1) / 2;
        while (y < z) {
            z = y;
            y = (x / y + y) / 2;
        };
        z
    }

    #[test]
    fun test_get_amount_out() {
        let out = get_amount_out(1000000, 100000000, 200000000, 30);
        assert!(out > 0);
    }

    #[test]
    fun test_quote() {
        let q = quote(1000000, 100000000, 200000000);
        assert!(q == 2000000);
    }

    #[test]
    fun test_sqrt() {
        assert!(sqrt(0) == 0);
        assert!(sqrt(1) == 1);
        assert!(sqrt(4) == 2);
        assert!(sqrt(9) == 3);
        assert!(sqrt(100) == 10);
    }
}
