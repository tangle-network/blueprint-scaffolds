module amm_dex::lp_token {
  use aptos_framework::fungible_asset;
  use aptos_framework::object;

  /// Create a new LP fungible asset under a pool object.
  public fun create_lp_asset(pool: &object::Object, name: vector<u8>, symbol: vector<u8>, decimals: u8): fungible_asset::Metadata {
    // Metadata is created under the pool object, so it is pool-scoped.
    fungible_asset::create_named_metadata(pool, name, symbol, decimals)
  }

  public fun mint_to(metadata: &fungible_asset::Metadata, recipient: address, amount: u64) {
    fungible_asset::mint_to(metadata, recipient, amount);
  }

  public fun burn_from(metadata: &fungible_asset::Metadata, owner: address, amount: u64) {
    fungible_asset::burn_from(metadata, owner, amount);
  }
}
