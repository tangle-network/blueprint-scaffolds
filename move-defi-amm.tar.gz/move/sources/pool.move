module amm_dex::pool {
  use std::error;
  use std::signer;
  use std::string;

  use aptos_framework::fungible_asset;
  use aptos_framework::object;
  use aptos_framework::primary_fungible_store;

  use amm_dex::fee;
  use amm_dex::lp_token;
  use amm_dex::math;
  use amm_dex::twap;

  const E_SAME_ASSET: u64 = 1;
  const E_ZERO: u64 = 2;
  const E_SLIPPAGE: u64 = 3;
  const E_FLASH_NOT_REPAID: u64 = 4;

  /// Pool resources are stored under a pool Object.
  struct Pool has key {
    asset_x: fungible_asset::Metadata,
    asset_y: fungible_asset::Metadata,
    reserve_x: u64,
    reserve_y: u64,
    lp: fungible_asset::Metadata,
    fee_cfg: fee::FeeConfig,
    oracle: twap::TwapState,
  }

  /// Concentrated liquidity position, simplified.
  struct Position has key {
    owner: address,
    lower_tick: i32,
    upper_tick: i32,
    liquidity: u128,
  }

  /// A registry for all pools (permissionless creation).
  struct Registry has key {
    pools: vector<object::Object>,
  }

  public entry fun init_registry(admin: &signer) {
    move_to(admin, Registry { pools: vector[] });
  }

  public fun has_registry(addr: address): bool {
    exists<Registry>(addr)
  }

  public entry fun create_pool(
    creator: &signer,
    registry_addr: address,
    asset_x: fungible_asset::Metadata,
    asset_y: fungible_asset::Metadata,
    swap_fee_bps: u64,
    flash_fee_bps: u64,
    lp_name: vector<u8>,
    lp_symbol: vector<u8>,
    lp_decimals: u8,
  ): object::Object {
    assert!(fungible_asset::metadata_address(&asset_x) != fungible_asset::metadata_address(&asset_y), error::invalid_argument(E_SAME_ASSET));
    let reg = borrow_global_mut<Registry>(registry_addr);
    let pool_obj = object::create_named_object(creator, string::utf8(lp_symbol));
    let lp_meta = lp_token::create_lp_asset(&pool_obj, lp_name, lp_symbol, lp_decimals);
    let oracle = twap::init(0);
    let fee_cfg = fee::new(swap_fee_bps, flash_fee_bps);
    move_to(&object::generate_signer(&pool_obj), Pool {
      asset_x,
      asset_y,
      reserve_x: 0,
      reserve_y: 0,
      lp: lp_meta,
      fee_cfg,
      oracle,
    });
    vector::push_back(&mut reg.pools, pool_obj);
    pool_obj
  }

  public fun get_reserves(pool_obj: &object::Object): (u64, u64) acquires Pool {
    let p = borrow_global<Pool>(object::object_address(pool_obj));
    (p.reserve_x, p.reserve_y)
  }

  public entry fun add_liquidity(
    user: &signer,
    pool_obj: object::Object,
    amount_x: u64,
    amount_y: u64,
    min_lp_out: u64,
  ) acquires Pool {
    assert!(amount_x > 0 && amount_y > 0, error::invalid_argument(E_ZERO));
    let pool_addr = object::object_address(&pool_obj);
    let p = borrow_global_mut<Pool>(pool_addr);

    // Transfer assets into pool's primary store.
    primary_fungible_store::transfer(user, pool_addr, p.asset_x, amount_x);
    primary_fungible_store::transfer(user, pool_addr, p.asset_y, amount_y);

    // Mint LP token proportional. Simplified: initial mint = sqrt(x*y) approximated.
    let lp_out = if (p.reserve_x == 0 && p.reserve_y == 0) {
      // crude geometric mean: (x*y)^(1/2) approx via integer sqrt using u128.
      let prod = (amount_x as u128) * (amount_y as u128);
      let s = isqrt_u128(prod);
      s as u64
    } else {
      let lp_supply = fungible_asset::supply(&p.lp);
      let lx = (lp_supply as u128) * (amount_x as u128) / (p.reserve_x as u128);
      let ly = (lp_supply as u128) * (amount_y as u128) / (p.reserve_y as u128);
      math::min_u128(lx, ly) as u64
    };
    assert!(lp_out >= min_lp_out, error::invalid_argument(E_SLIPPAGE));
    lp_token::mint_to(&p.lp, signer::address_of(user), lp_out);

    p.reserve_x = p.reserve_x + amount_x;
    p.reserve_y = p.reserve_y + amount_y;
    twap::update(&mut p.oracle, price_x64(p.reserve_x, p.reserve_y));
  }

  public entry fun remove_liquidity(
    user: &signer,
    pool_obj: object::Object,
    lp_in: u64,
    min_x_out: u64,
    min_y_out: u64,
  ) acquires Pool {
    assert!(lp_in > 0, error::invalid_argument(E_ZERO));
    let pool_addr = object::object_address(&pool_obj);
    let p = borrow_global_mut<Pool>(pool_addr);
    let supply = fungible_asset::supply(&p.lp);
    assert!(supply > 0, error::invalid_argument(E_ZERO));
    lp_token::burn_from(&p.lp, signer::address_of(user), lp_in);

    let x_out = ((p.reserve_x as u128) * (lp_in as u128) / (supply as u128)) as u64;
    let y_out = ((p.reserve_y as u128) * (lp_in as u128) / (supply as u128)) as u64;
    assert!(x_out >= min_x_out && y_out >= min_y_out, error::invalid_argument(E_SLIPPAGE));

    p.reserve_x = p.reserve_x - x_out;
    p.reserve_y = p.reserve_y - y_out;
    primary_fungible_store::transfer(&object::generate_signer(&pool_obj), signer::address_of(user), p.asset_x, x_out);
    primary_fungible_store::transfer(&object::generate_signer(&pool_obj), signer::address_of(user), p.asset_y, y_out);
    twap::update(&mut p.oracle, price_x64(p.reserve_x, p.reserve_y));
  }

  /// Constant product swap X->Y with slippage protection.
  public entry fun swap_x_to_y(
    user: &signer,
    pool_obj: object::Object,
    amount_x_in: u64,
    min_y_out: u64,
  ) acquires Pool {
    assert!(amount_x_in > 0, error::invalid_argument(E_ZERO));
    let pool_addr = object::object_address(&pool_obj);
    let p = borrow_global_mut<Pool>(pool_addr);

    primary_fungible_store::transfer(user, pool_addr, p.asset_x, amount_x_in);

    let fee_bps = fee::swap_fee_bps(&p.fee_cfg);
    let x_in_post_fee = math::apply_fee_bps(amount_x_in as u128, fee_bps) as u64;

    // y_out = (reserve_y * x_in) / (reserve_x + x_in)
    let num = (p.reserve_y as u128) * (x_in_post_fee as u128);
    let den = (p.reserve_x as u128) + (x_in_post_fee as u128);
    let y_out = (num / den) as u64;
    assert!(y_out >= min_y_out, error::invalid_argument(E_SLIPPAGE));

    p.reserve_x = p.reserve_x + x_in_post_fee;
    p.reserve_y = p.reserve_y - y_out;
    primary_fungible_store::transfer(&object::generate_signer(&pool_obj), signer::address_of(user), p.asset_y, y_out);
    twap::update(&mut p.oracle, price_x64(p.reserve_x, p.reserve_y));
  }

  /// Flash loan both assets. Borrower must return amounts + fees within the same tx.
  /// This is a simplified pattern using balances in the pool store.
  public entry fun flash_loan(
    borrower: &signer,
    pool_obj: object::Object,
    amount_x: u64,
    amount_y: u64,
    receiver: address,
  ) acquires Pool {
    let pool_addr = object::object_address(&pool_obj);
    let p = borrow_global_mut<Pool>(pool_addr);
    assert!(amount_x <= p.reserve_x && amount_y <= p.reserve_y, error::invalid_argument(E_ZERO));

    let fee_bps = fee::flash_fee_bps(&p.fee_cfg);
    let fee_x = ((amount_x as u128) * (fee_bps as u128) / 10_000u128) as u64;
    let fee_y = ((amount_y as u128) * (fee_bps as u128) / 10_000u128) as u64;

    // Send out
    if (amount_x > 0) {
      p.reserve_x = p.reserve_x - amount_x;
      primary_fungible_store::transfer(&object::generate_signer(&pool_obj), receiver, p.asset_x, amount_x);
    };
    if (amount_y > 0) {
      p.reserve_y = p.reserve_y - amount_y;
      primary_fungible_store::transfer(&object::generate_signer(&pool_obj), receiver, p.asset_y, amount_y);
    };

    // Borrower must have returned principal + fee by now (same transaction).
    let bal_x = primary_fungible_store::balance(pool_addr, p.asset_x);
    let bal_y = primary_fungible_store::balance(pool_addr, p.asset_y);
    let min_x = p.reserve_x + amount_x + fee_x;
    let min_y = p.reserve_y + amount_y + fee_y;
    assert!(bal_x >= min_x && bal_y >= min_y, error::invalid_argument(E_FLASH_NOT_REPAID));

    // Update reserves to actual balances
    p.reserve_x = bal_x;
    p.reserve_y = bal_y;
    twap::update(&mut p.oracle, price_x64(p.reserve_x, p.reserve_y));
    let _b = borrower; // silence unused
  }

  /// Very small integer sqrt for u128.
  fun isqrt_u128(n: u128): u128 {
    let x = n;
    let y = (x + 1) / 2;
    while (y < x) {
      x = y;
      y = (x + n / x) / 2;
    };
    x
  }

  fun price_x64(rx: u64, ry: u64): u128 {
    if (rx == 0) 0 else ((ry as u128) << 64) / (rx as u128)
  }
}
