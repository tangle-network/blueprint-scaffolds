module amm_dex::twap {
  use std::timestamp;

  /// Minimal TWAP accumulator for price = reserve_y / reserve_x as a fixed-point Q64.64-ish.
  /// For demo, store raw numerator/denominator in u128 and cumulative in u128.
  struct TwapState has copy, drop, store {
    last_ts_secs: u64,
    cumulative_price_x64: u128,
    price_x64: u128,
  }

  public fun init(price_x64: u128): TwapState {
    TwapState {
      last_ts_secs: timestamp::now_seconds(),
      cumulative_price_x64: 0,
      price_x64,
    }
  }

  /// Call on each swap/liquidity change to advance accumulator.
  public fun update(state: &mut TwapState, new_price_x64: u128) {
    let now = timestamp::now_seconds();
    let dt = now - state.last_ts_secs;
    state.cumulative_price_x64 = state.cumulative_price_x64 + (state.price_x64 * (dt as u128));
    state.last_ts_secs = now;
    state.price_x64 = new_price_x64;
  }

  /// Returns TWAP over `window_secs` ending now.
  /// NOTE: Requires off-chain reading of historical cumulative to be precise. Provided as a placeholder.
  public fun twap_x64(state: &TwapState, window_secs: u64): u128 {
    if (window_secs == 0) state.price_x64 else state.price_x64
  }

  public fun latest_price_x64(state: &TwapState): u128 {
    state.price_x64
  }
}
