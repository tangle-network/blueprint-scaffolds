module amm_dex::fee {
  use std::error;

  const E_FEE_TOO_HIGH: u64 = 1;

  /// Fee config is stored per pool.
  struct FeeConfig has copy, drop, store {
    swap_fee_bps: u64,
    flash_fee_bps: u64,
  }

  public fun new(swap_fee_bps: u64, flash_fee_bps: u64): FeeConfig {
    assert!(swap_fee_bps <= 1000, error::invalid_argument(E_FEE_TOO_HIGH));
    assert!(flash_fee_bps <= 1000, error::invalid_argument(E_FEE_TOO_HIGH));
    FeeConfig { swap_fee_bps, flash_fee_bps }
  }

  public fun swap_fee_bps(cfg: &FeeConfig): u64 {
    cfg.swap_fee_bps
  }

  public fun flash_fee_bps(cfg: &FeeConfig): u64 {
    cfg.flash_fee_bps
  }
}
