module amm_dex::math {
  use std::error;

  const E_DIV_BY_ZERO: u64 = 1;
  const E_OVERFLOW: u64 = 2;

  /// Basic checked multiply-divide for u128.
  public fun mul_div(a: u128, b: u128, denom: u128): u128 {
    assert!(denom != 0, error::invalid_argument(E_DIV_BY_ZERO));
    let prod = a * b;
    // Move arithmetic aborts on overflow in recent versions; keep an explicit code.
    assert!(prod / a == b || a == 0, error::invalid_argument(E_OVERFLOW));
    prod / denom
  }

  /// x * (10_000 - fee_bps) / 10_000
  public fun apply_fee_bps(x: u128, fee_bps: u64): u128 {
    let fb = fee_bps as u128;
    mul_div(x, 10_000u128 - fb, 10_000u128)
  }

  public fun min_u128(a: u128, b: u128): u128 {
    if (a < b) a else b
  }

  public fun max_u128(a: u128, b: u128): u128 {
    if (a > b) a else b
  }
}
