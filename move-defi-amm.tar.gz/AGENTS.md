# AGENTS.md

## Goal

Build an AMM DEX on Aptos using Move. Constant-product pools, swap routing, liquidity management.

## Stack

- Family: `move-contracts`
- Layers: `capability:move-amm`

## Entry Points

- `Move.toml`
- `sources/TreasuryVault.move`
- `tests/TreasuryVaultTests.move`

## Commands

- `aptos move test`
- `sui move test`

## Build Plan

Components: PoolModule, SwapRouter, LPToken
Data models: Pool, Position, SwapRoute
Integrations: Constant product AMM, Multi-hop routing

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
