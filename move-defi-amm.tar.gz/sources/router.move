module amm::router {
    use std::signer;
    use aptos_framework::coin::{Self, Coin};
    use amm::pool;
    use amm::math;

    const E_INSUFFICIENT_OUTPUT: u64 = 200;
    const E_ZERO_AMOUNT: u64 = 201;
    const E_SLIPPAGE: u64 = 202;

    public entry fun swap_exact_input<CoinA, CoinB>(
        account: &signer,
        amount_in: u64,
        amount_out_min: u64,
    ) acquires pool::Pool {
        assert!(amount_in > 0, E_ZERO_AMOUNT);
        pool::swap_exact_coin_a_for_coin_b<CoinA, CoinB>(account, amount_in, amount_out_min);
    }

    public entry fun multi_hop_swap_3<CoinA, CoinB, CoinC>(
        account: &signer,
        amount_in: u64,
        amount_out_min: u64,
    ) acquires pool::Pool {
        assert!(amount_in > 0, E_ZERO_AMOUNT);
        pool::swap_exact_coin_a_for_coin_b<CoinA, CoinB>(account, amount_in, 0);
        pool::swap_exact_coin_a_for_coin_b<CoinB, CoinC>(account, 0, amount_out_min);
    }

    public entry fun multi_hop_swap_4<CoinA, CoinB, CoinC, CoinD>(
        account: &signer,
        amount_in: u64,
        amount_out_min: u64,
    ) acquires pool::Pool {
        assert!(amount_in > 0, E_ZERO_AMOUNT);
        pool::swap_exact_coin_a_for_coin_b<CoinA, CoinB>(account, amount_in, 0);
        pool::swap_exact_coin_a_for_coin_b<CoinB, CoinC>(account, 0, 0);
        pool::swap_exact_coin_a_for_coin_b<CoinC, CoinD>(account, 0, amount_out_min);
    }

    public entry fun add_liquidity<CoinA, CoinB>(
        account: &signer,
        amount_a: u64,
        amount_b: u64,
        amount_a_min: u64,
        amount_b_min: u64,
    ) acquires pool::Pool {
        pool::add_liquidity<CoinA, CoinB>(account, amount_a, amount_b, amount_a_min, amount_b_min);
    }

    public entry fun remove_liquidity<CoinA, CoinB>(
        account: &signer,
        lp_amount: u64,
        amount_a_min: u64,
        amount_b_min: u64,
    ) acquires pool::Pool {
        pool::remove_liquidity<CoinA, CoinB>(account, lp_amount, amount_a_min, amount_b_min);
    }
}
