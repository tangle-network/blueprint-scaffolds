module amm::pool {
    use std::signer;
    use std::string;
    use aptos_framework::coin::{Self, Coin};
    use aptos_framework::fungible_asset;
    use aptos_framework::object;
    use aptos_framework::event;
    use amm::math;
    use amm::lp_token::{Self, LPMintCapability};

    const MINIMUM_LIQUIDITY: u64 = 1000;
    const MAX_FEE_BPS: u64 = 1000;
    const E_NOT_INITIALIZED: u64 = 100;
    const E_INSUFFICIENT_LIQUIDITY: u64 = 101;
    const E_INSUFFICIENT_INPUT: u64 = 102;
    const E_INVALID_FEE: u64 = 103;
    const E_IDENTICAL_TOKENS: u64 = 104;
    const E_SLIPPAGE_EXCEEDED: u64 = 105;
    const E_ZERO_AMOUNT: u64 = 106;
    const E_UNAUTHORIZED: u64 = 107;
    const E_POOL_EXISTS: u64 = 108;
    const E_INVALID_TICK: u64 = 109;
    const E_POSITION_NOT_FOUND: u64 = 110;
    const E_FEE_NOT_PAID: u64 = 111;

    struct Pool<CoinTypeA, CoinTypeB> has key {
        coin_a: Coin<CoinTypeA>,
        coin_b: Coin<CoinTypeB>,
        reserve_a: u64,
        reserve_b: u64,
        fee_bps: u64,
        lp_capability: LPMintCapability,
        total_lp: u64,
        k_last: u64,
        protocol_fee_bps: u64,
    }

    struct PoolInfo has key, store {
        fee_bps: u64,
        tick_spacing: u64,
        active: bool,
    }

    struct ConcentratedPosition has key, store {
        owner: address,
        tick_lower: u64,
        tick_upper: u64,
        liquidity: u64,
        fee_growth_inside_last: u64,
        tokens_owed_a: u64,
        tokens_owed_b: u64,
    }

    struct PoolCreatedEvent has copy, drop, store {
        creator: address,
        coin_a_type: string::String,
        coin_b_type: string::String,
        fee_bps: u64,
    }

    struct SwapEvent has copy, drop, store {
        pool: address,
        amount_in: u64,
        amount_out: u64,
        fee: u64,
    }

    struct LiquidityEvent has copy, drop, store {
        pool: address,
        provider: address,
        amount_a: u64,
        amount_b: u64,
        lp_minted: u64,
    }

    struct GlobalConfig has key {
        protocol_fee_recipient: address,
        flash_loan_fee_bps: u64,
    }

    public fun create_pool<CoinTypeA, CoinTypeB>(
        account: &signer,
        fee_bps: u64,
        tick_spacing: u64,
    ): address {
        assert!(fee_bps <= MAX_FEE_BPS, E_INVALID_FEE);
        assert!(!std::type_info::type_of<CoinTypeA>().account_address == std::type_info::type_of<CoinTypeB>().account_address, E_IDENTICAL_TOKENS);

        let pool_addr = signer::address_of(account);
        assert!(!exists<Pool<CoinTypeA, CoinTypeB>>(pool_addr), E_POOL_EXISTS);

        let type_a = std::type_info::type_of<CoinTypeA>();
        let type_b = std::type_info::type_of<CoinTypeB>();
        let name = string::utf8(b"AMM_LP_TOKEN");
        let symbol = string::utf8(b"LP");
        let icon = string::utf8(b"");
        let (_metadata, lp_capability) = lp_token::create_lp_token(account, name, symbol, icon);

        let pool = Pool<CoinTypeA, CoinTypeB> {
            coin_a: coin::zero<CoinTypeA>(),
            coin_b: coin::zero<CoinTypeB>(),
            reserve_a: 0,
            reserve_b: 0,
            fee_bps,
            lp_capability,
            total_lp: 0,
            k_last: 0,
            protocol_fee_bps: 500,
        };

        move_to(account, pool);

        let pool_info = PoolInfo {
            fee_bps,
            tick_spacing,
            active: true,
        };
        move_to(account, pool_info);

        if (!exists<GlobalConfig>(pool_addr)) {
            move_to(account, GlobalConfig {
                protocol_fee_recipient: pool_addr,
                flash_loan_fee_bps: 5,
            });
        };

        event::emit(PoolCreatedEvent {
            creator: pool_addr,
            coin_a_type: string::utf8(b"CoinA"),
            coin_b_type: string::utf8(b"CoinB"),
            fee_bps,
        });

        pool_addr
    }

    public entry fun add_liquidity<CoinTypeA, CoinTypeB>(
        account: &signer,
        amount_a_desired: u64,
        amount_b_desired: u64,
        amount_a_min: u64,
        amount_b_min: u64,
    ) acquires Pool {
        assert!(amount_a_desired > 0 && amount_b_desired > 0, E_ZERO_AMOUNT);
        let pool = borrow_global_mut<Pool<CoinTypeA, CoinTypeB>>(signer::address_of(account));
        let (amount_a, amount_b) = if (pool.reserve_a == 0 && pool.reserve_b == 0) {
            (amount_a_desired, amount_b_desired)
        } else {
            let amount_b_optimal = math::quote(amount_a_desired, pool.reserve_a, pool.reserve_b);
            if (amount_b_optimal <= amount_b_desired) {
                assert!(amount_b_optimal >= amount_b_min, E_SLIPPAGE_EXCEEDED);
                (amount_a_desired, amount_b_optimal)
            } else {
                let amount_a_optimal = math::quote(amount_b_desired, pool.reserve_b, pool.reserve_a);
                assert!(amount_a_optimal <= amount_a_desired, E_INSUFFICIENT_INPUT);
                assert!(amount_a_optimal >= amount_a_min, E_SLIPPAGE_EXCEEDED);
                (amount_a_optimal, amount_b_desired)
            }
        };

        let lp_amount = if (pool.total_lp == 0) {
            let s = math::sqrt(amount_a * amount_b);
            if (s > MINIMUM_LIQUIDITY) s - MINIMUM_LIQUIDITY else 1
        } else {
            math::min(
                (amount_a * pool.total_lp) / pool.reserve_a,
                (amount_b * pool.total_lp) / pool.reserve_b,
            )
        };

        assert!(lp_amount > 0, E_INSUFFICIENT_LIQUIDITY);

        let coin_a = coin::withdraw<CoinTypeA>(account, amount_a);
        let coin_b = coin::withdraw<CoinTypeB>(account, amount_b);

        coin::merge(&mut pool.coin_a, coin_a);
        coin::merge(&mut pool.coin_b, coin_b);

        pool.reserve_a = pool.reserve_a + amount_a;
        pool.reserve_b = pool.reserve_b + amount_b;
        pool.total_lp = pool.total_lp + lp_amount;
        pool.k_last = pool.reserve_a * pool.reserve_b;

        lp_token::mint_and_deposit(&pool.lp_capability, signer::address_of(account), lp_amount);

        event::emit(LiquidityEvent {
            pool: signer::address_of(account),
            provider: signer::address_of(account),
            amount_a,
            amount_b,
            lp_minted: lp_amount,
        });
    }

    public entry fun remove_liquidity<CoinTypeA, CoinTypeB>(
        account: &signer,
        lp_amount: u64,
        amount_a_min: u64,
        amount_b_min: u64,
    ) acquires Pool {
        assert!(lp_amount > 0, E_ZERO_AMOUNT);
        let pool = borrow_global_mut<Pool<CoinTypeA, CoinTypeB>>(signer::address_of(account));
        assert!(lp_amount <= pool.total_lp, E_INSUFFICIENT_LIQUIDITY);

        let amount_a = (lp_amount * pool.reserve_a) / pool.total_lp;
        let amount_b = (lp_amount * pool.reserve_b) / pool.total_lp;

        assert!(amount_a >= amount_a_min, E_SLIPPAGE_EXCEEDED);
        assert!(amount_b >= amount_b_min, E_SLIPPAGE_EXCEEDED);

        pool.reserve_a = pool.reserve_a - amount_a;
        pool.reserve_b = pool.reserve_b - amount_b;
        pool.total_lp = pool.total_lp - lp_amount;
        pool.k_last = pool.reserve_a * pool.reserve_b;

        lp_token::burn_from(&pool.lp_capability, signer::address_of(account), lp_amount);

        let coin_a = coin::extract(&mut pool.coin_a, amount_a);
        let coin_b = coin::extract(&mut pool.coin_b, amount_b);

        coin::deposit(signer::address_of(account), coin_a);
        coin::deposit(signer::address_of(account), coin_b);

        event::emit(LiquidityEvent {
            pool: signer::address_of(account),
            provider: signer::address_of(account),
            amount_a,
            amount_b,
            lp_minted: 0,
        });
    }

    public entry fun swap_exact_coin_a_for_coin_b<CoinTypeA, CoinTypeB>(
        account: &signer,
        amount_in: u64,
        amount_out_min: u64,
    ) acquires Pool {
        assert!(amount_in > 0, E_ZERO_AMOUNT);
        let pool = borrow_global_mut<Pool<CoinTypeA, CoinTypeB>>(signer::address_of(account));
        let amount_out = math::get_amount_out(amount_in, pool.reserve_a, pool.reserve_b, pool.fee_bps);
        assert!(amount_out >= amount_out_min, E_SLIPPAGE_EXCEEDED);
        assert!(amount_out < pool.reserve_b, E_INSUFFICIENT_LIQUIDITY);

        let fee = amount_in * pool.fee_bps / 10000;

        let coin_in = coin::withdraw<CoinTypeA>(account, amount_in);
        coin::merge(&mut pool.coin_a, coin_in);

        let coin_out = coin::extract(&mut pool.coin_b, amount_out);
        coin::deposit(signer::address_of(account), coin_out);

        pool.reserve_a = pool.reserve_a + amount_in;
        pool.reserve_b = pool.reserve_b - amount_out;
        pool.k_last = pool.reserve_a * pool.reserve_b;

        event::emit(SwapEvent {
            pool: signer::address_of(account),
            amount_in,
            amount_out,
            fee,
        });
    }

    public entry fun swap_exact_coin_b_for_coin_a<CoinTypeA, CoinTypeB>(
        account: &signer,
        amount_in: u64,
        amount_out_min: u64,
    ) acquires Pool {
        assert!(amount_in > 0, E_ZERO_AMOUNT);
        let pool = borrow_global_mut<Pool<CoinTypeA, CoinTypeB>>(signer::address_of(account));
        let amount_out = math::get_amount_out(amount_in, pool.reserve_b, pool.reserve_a, pool.fee_bps);
        assert!(amount_out >= amount_out_min, E_SLIPPAGE_EXCEEDED);
        assert!(amount_out < pool.reserve_a, E_INSUFFICIENT_LIQUIDITY);

        let fee = amount_in * pool.fee_bps / 10000;

        let coin_in = coin::withdraw<CoinTypeB>(account, amount_in);
        coin::merge(&mut pool.coin_b, coin_in);

        let coin_out = coin::extract(&mut pool.coin_a, amount_out);
        coin::deposit(signer::address_of(account), coin_out);

        pool.reserve_b = pool.reserve_b + amount_in;
        pool.reserve_a = pool.reserve_a - amount_out;
        pool.k_last = pool.reserve_a * pool.reserve_b;

        event::emit(SwapEvent {
            pool: signer::address_of(account),
            amount_in,
            amount_out,
            fee,
        });
    }

    public entry fun flash_loan<CoinTypeA, CoinTypeB>(
        account: &signer,
        amount_a: u64,
        amount_b: u64,
    ) acquires Pool, GlobalConfig {
        let pool_addr = signer::address_of(account);
        let pool = borrow_global_mut<Pool<CoinTypeA, CoinTypeB>>(pool_addr);
        let config = borrow_global<GlobalConfig>(pool_addr);

        assert!(amount_a <= pool.reserve_a, E_INSUFFICIENT_LIQUIDITY);
        assert!(amount_b <= pool.reserve_b, E_INSUFFICIENT_LIQUIDITY);

        let fee_a = amount_a * config.flash_loan_fee_bps / 10000;
        let fee_b = amount_b * config.flash_loan_fee_bps / 10000;

        let loan_a = if (amount_a > 0) coin::extract(&mut pool.coin_a, amount_a) else coin::zero<CoinTypeA>();
        let loan_b = if (amount_b > 0) coin::extract(&mut pool.coin_b, amount_b) else coin::zero<CoinTypeB>();

        coin::deposit(signer::address_of(account), loan_a);
        coin::deposit(signer::address_of(account), loan_b);

        let repay_a = coin::withdraw<CoinTypeA>(account, amount_a + fee_a);
        let repay_b = coin::withdraw<CoinTypeB>(account, amount_b + fee_b);

        coin::merge(&mut pool.coin_a, repay_a);
        coin::merge(&mut pool.coin_b, repay_b);

        assert!(
            coin::value(&pool.coin_a) >= pool.reserve_a + fee_a,
            E_FEE_NOT_PAID
        );
        assert!(
            coin::value(&pool.coin_b) >= pool.reserve_b + fee_b,
            E_FEE_NOT_PAID
        );

        pool.reserve_a = pool.reserve_a + fee_a;
        pool.reserve_b = pool.reserve_b + fee_b;
    }

    public entry fun set_fee<CoinTypeA, CoinTypeB>(
        account: &signer,
        new_fee_bps: u64,
    ) acquires Pool, PoolInfo {
        assert!(new_fee_bps <= MAX_FEE_BPS, E_INVALID_FEE);
        let pool_addr = signer::address_of(account);
        let pool = borrow_global_mut<Pool<CoinTypeA, CoinTypeB>>(pool_addr);
        pool.fee_bps = new_fee_bps;

        let pool_info = borrow_global_mut<PoolInfo>(pool_addr);
        pool_info.fee_bps = new_fee_bps;
    }

    public fun get_reserves<CoinTypeA, CoinTypeB>(pool_addr: address): (u64, u64) acquires Pool {
        let pool = borrow_global<Pool<CoinTypeA, CoinTypeB>>(pool_addr);
        (pool.reserve_a, pool.reserve_b)
    }

    public fun get_amount_out<CoinTypeA, CoinTypeB>(amount_in: u64, is_a_to_b: bool): u64 acquires Pool {
        let pool = borrow_global<Pool<CoinTypeA, CoinTypeB>>(@amm);
        if (is_a_to_b) {
            math::get_amount_out(amount_in, pool.reserve_a, pool.reserve_b, pool.fee_bps)
        } else {
            math::get_amount_out(amount_in, pool.reserve_b, pool.reserve_a, pool.fee_bps)
        }
    }

    public entry fun create_concentrated_position<CoinTypeA, CoinTypeB>(
        account: &signer,
        tick_lower: u64,
        tick_upper: u64,
        amount_a: u64,
        amount_b: u64,
    ) acquires Pool, PoolInfo {
        assert!(tick_lower < tick_upper, E_INVALID_TICK);
        let pool = borrow_global_mut<Pool<CoinTypeA, CoinTypeB>>(signer::address_of(account));
        let pool_info = borrow_global<PoolInfo>(signer::address_of(account));
        assert!(pool_info.active, E_NOT_INITIALIZED);

        let sqrt_price = math::sqrt((pool.reserve_a * 1000000) / pool.reserve_b);
        let liquidity = math::liquidity_from_amounts(
            math::price_from_tick(tick_lower),
            math::price_from_tick(tick_upper),
            amount_a,
            amount_b,
        );
        assert!(liquidity > 0, E_INSUFFICIENT_LIQUIDITY);

        let coin_a = coin::withdraw<CoinTypeA>(account, amount_a);
        let coin_b = coin::withdraw<CoinTypeB>(account, amount_b);
        coin::merge(&mut pool.coin_a, coin_a);
        coin::merge(&mut pool.coin_b, coin_b);

        pool.reserve_a = pool.reserve_a + amount_a;
        pool.reserve_b = pool.reserve_b + amount_b;

        let position = ConcentratedPosition {
            owner: signer::address_of(account),
            tick_lower,
            tick_upper,
            liquidity,
            fee_growth_inside_last: 0,
            tokens_owed_a: 0,
            tokens_owed_b: 0,
        };
        move_to(account, position);
    }

    #[test_only]
    use aptos_framework::aptos_coin::{Self, AptosCoin};
    #[test_only]
    use aptos_framework::managed_coin;

    #[test(account = @0x123)]
    fun test_create_pool(account: &signer) acquires Pool, PoolInfo {
        aptos_framework::account::create_account_for_test(@0x123);
        managed_coin::register<AptosCoin>(account);
        aptos_coin::mint(account, 100000000);
        let pool_addr = create_pool<AptosCoin, AptosCoin>(account, 30, 10);
        assert!(pool_addr == @0x123, 0);
    }
}
