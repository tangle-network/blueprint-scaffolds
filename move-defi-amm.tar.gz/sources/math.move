module amm::math {
    const SCALE: u64 = 1000000;
    const MAX_FEE: u64 = 100000;

    public fun mul_div(a: u64, b: u64, d: u64): u64 {
        assert!(d > 0, 1);
        let r1 = (a / d) * b;
        let r2 = ((a % d) * b) / d;
        r1 + r2
    }

    public fun sqrt(y: u64): u64 {
        if (y <= 1) return y;
        let z = y;
        let x = y / 2 + 1;
        while (x < z) {
            z = x;
            x = (y / x + x) / 2;
        };
        z
    }

    public fun min(a: u64, b: u64): u64 {
        if (a < b) a else b
    }

    public fun max(a: u64, b: u64): u64 {
        if (a > b) a else b
    }

    public fun abs_diff(a: u64, b: u64): u64 {
        if (a > b) a - b else b - a
    }

    public fun to_fee_basis_points(fee_percent: u64): u64 {
        assert!(fee_percent <= MAX_FEE, 2);
        fee_percent * 100
    }

    public fun apply_fee(amount: u64, fee_bps: u64): u64 {
        amount - ((amount * fee_bps) / 10000)
    }

    public fun quote(amount_a: u64, reserve_a: u64, reserve_b: u64): u64 {
        assert!(amount_a > 0, 3);
        assert!(reserve_a > 0 && reserve_b > 0, 4);
        (amount_a * reserve_b) / reserve_a
    }

    public fun get_amount_out(amount_in: u64, reserve_in: u64, reserve_out: u64, fee_bps: u64): u64 {
        assert!(amount_in > 0, 3);
        assert!(reserve_in > 0 && reserve_out > 0, 4);
        let amount_in_with_fee = amount_in * (10000 - fee_bps);
        let numerator = amount_in_with_fee * reserve_out;
        let denominator = (reserve_in * 10000) + amount_in_with_fee;
        numerator / denominator
    }

    public fun get_amount_in(amount_out: u64, reserve_in: u64, reserve_out: u64, fee_bps: u64): u64 {
        assert!(amount_out > 0, 3);
        assert!(reserve_in > 0 && reserve_out > 0, 4);
        let numerator = reserve_in * amount_out * 10000;
        let denominator = (reserve_out - amount_out) * (10000 - fee_bps);
        (numerator / denominator) + 1
    }

    public fun check_slippage(expected: u64, actual: u64, max_bps: u64): bool {
        let diff = abs_diff(expected, actual) * 10000;
        diff <= expected * max_bps
    }

    public fun tick_from_price(price: u64, tick_spacing: u64): u64 {
        let tick = sqrt(price);
        (tick / tick_spacing) * tick_spacing
    }

    public fun price_from_tick(tick: u64): u64 {
        tick * tick
    }

    public fun liquidity_from_amounts(sqrt_ratio_a: u64, sqrt_ratio_b: u64, amount_0: u64, amount_1: u64): u64 {
        if (sqrt_ratio_a > sqrt_ratio_b) {
            let tmp = sqrt_ratio_a;
            sqrt_ratio_a = sqrt_ratio_b;
            sqrt_ratio_b = tmp;
        };
        let liquidity0 = mul_div(amount_0, sqrt_ratio_a, sqrt_ratio_b - sqrt_ratio_a);
        let liquidity1 = if (sqrt_ratio_b > 0) amount_1 / sqrt_ratio_b else 0;
        min(liquidity0, liquidity1)
    }

    public fun encode_flag(flag: bool, value: u64): u64 {
        if (flag) value | 0x8000000000000000 else value
    }

    public fun decode_flag(encoded: u64): (bool, u64) {
        let flag = (encoded & 0x8000000000000000) > 0;
        let value = encoded & 0x7FFFFFFFFFFFFFFF;
        (flag, value)
    }
}
