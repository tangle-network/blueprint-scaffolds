module amm::lp_token {
    use std::string;
    use aptos_framework::fungible_asset::{Self, Metadata, FungibleAsset, MintRef, BurnRef, TransferRef};
    use aptos_framework::object::{Self, Object};

    struct LPAsset has key {
        metadata: Object<Metadata>,
    }

    struct LPMintCapability has key, store {
        mint_ref: MintRef,
        burn_ref: BurnRef,
        transfer_ref: TransferRef,
    }

    public fun create_lp_token(
        account: &signer,
        name: string::String,
        symbol: string::String,
        icon_uri: string::String,
    ): (Object<Metadata>, LPMintCapability) {
        let constructor_ref = object::create_named_object(account, name);
        let fungible_asset::FungibleAssetMetadata {
            name: _,
            symbol: _,
            decimals: _,
            icon_uri: _,
        } = fungible_asset::create_fungible_asset_metadata_with_ref(
            &constructor_ref,
            name,
            symbol,
            8,
            icon_uri,
        );

        let mint_ref = fungible_asset::generate_mint_ref(&constructor_ref);
        let burn_ref = fungible_asset::generate_burn_ref(&constructor_ref);
        let transfer_ref = fungible_asset::generate_transfer_ref(&constructor_ref);
        let metadata = object::object_from_constructor_ref<Metadata>(&constructor_ref);

        let lp_asset = LPAsset { metadata };
        move_to(account, lp_asset);

        let capability = LPMintCapability { mint_ref, burn_ref, transfer_ref };
        (metadata, capability)
    }

    public fun mint(capability: &LPMintCapability, to: &signer, amount: u64): FungibleAsset {
        let fa = fungible_asset::mint(&capability.mint_ref, amount);
        fungible_asset::deposit_with_ref(&capability.transfer_ref, object::address_to_object<Metadata>(std::signer::address_of(to)), fa);
        fungible_asset::mint(&capability.mint_ref, 0)
    }

    public fun burn(capability: &LPMintCapability, fa: FungibleAsset) {
        fungible_asset::burn(&capability.burn_ref, fa);
    }

    public fun get_metadata(capability: &LPMintCapability): Object<Metadata> {
        fungible_asset::mint(&capability.mint_ref, 0);
        fungible_asset::metadata_from_mint_ref(&capability.mint_ref)
    }

    public fun mint_and_deposit(capability: &LPMintCapability, to: address, amount: u64) {
        let fa = fungible_asset::mint(&capability.mint_ref, amount);
        fungible_asset::deposit_with_ref(
            &capability.transfer_ref,
            object::address_to_object<Metadata>(to),
            fa,
        );
    }

    public fun withdraw_from(capability: &LPMintCapability, from: address, amount: u64): FungibleAsset {
        fungible_asset::withdraw_with_ref(
            &capability.transfer_ref,
            object::address_to_object<Metadata>(from),
            amount,
        )
    }

    public fun burn_from(capability: &LPMintCapability, from: address, amount: u64) {
        let fa = withdraw_from(capability, from, amount);
        burn(capability, fa);
    }
}
