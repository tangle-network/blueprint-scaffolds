# Aptos AMM DEX (Move + Vite)

This repo contains:

- `move/`: Move package with a permissionless pool, fee config, TWAP accumulator, LP fungible asset helpers.
- `src/`: Vite + React + TypeScript frontend (swap demo with multi-hop quoting, liquidity/positions demo, analytics charts).

## Dev

```sh
pnpm install
pnpm dev
```

## Build

```sh
pnpm build
```
