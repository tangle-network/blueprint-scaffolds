// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IRiscZeroVerifier {
    function verify(
        bytes calldata seal,
        bytes32 imageId,
        bytes calldata journal
    ) external view returns (bool);
}

contract RiscZeroVerifier is IRiscZeroVerifier {
    mapping(bytes32 => bool) public verifiedProofs;

    function verify(
        bytes calldata seal,
        bytes32 imageId,
        bytes calldata journal
    ) external view override returns (bool) {
        bytes32 proofHash = keccak256(abi.encodePacked(seal, imageId, journal));
        return verifiedProofs[proofHash];
    }

    function submitAndVerify(
        bytes calldata seal,
        bytes32 imageId,
        bytes calldata journal
    ) external returns (bool) {
        bytes32 proofHash = keccak256(abi.encodePacked(seal, imageId, journal));
        verifiedProofs[proofHash] = true;
        return true;
    }
}
