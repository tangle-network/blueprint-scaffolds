// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

library MerkleTree {
    function computeRoot(
        bytes32 leaf,
        bytes32[] calldata proof,
        uint256 index
    ) internal pure returns (bytes32) {
        bytes32 current = leaf;
        uint256 idx = index;
        for (uint256 i = 0; i < proof.length; i++) {
            if (idx % 2 == 0) {
                current = keccak256(bytes.concat(current, proof[i]));
            } else {
                current = keccak256(bytes.concat(proof[i], current));
            }
            idx = idx / 2;
        }
        return current;
    }

    function verify(
        bytes32 leaf,
        bytes32[] calldata proof,
        uint256 index,
        bytes32 root
    ) internal pure returns (bool) {
        return computeRoot(leaf, proof, index) == root;
    }

    function buildRoot(bytes32[] calldata leaves) internal pure returns (bytes32) {
        require(leaves.length > 0, "Empty leaves");
        uint256 n = leaves.length;
        uint256 size = 1;
        while (size < n) size *= 2;

        bytes32[] memory tree = new bytes32[](size);
        for (uint256 i = 0; i < size; i++) {
            tree[i] = i < n ? leaves[i] : bytes32(0);
        }

        uint256 stride = size;
        while (stride > 1) {
            stride = stride / 2;
            for (uint256 i = 0; i < stride; i++) {
                tree[i] = keccak256(bytes.concat(tree[2 * i], tree[2 * i + 1]));
            }
        }
        return tree[0];
    }
}
