// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IRiscZeroVerifier} from "./RiscZeroVerifier.sol";
import {MerkleTree} from "./libraries/MerkleTree.sol";

struct CommittedOrder {
    bytes32 commitment;
    address depositor;
    uint256 timestamp;
    bool revealed;
}

struct RevealedOrder {
    bytes32 orderHash;
    bytes32 nullifier;
    address tokenIn;
    address tokenOut;
    uint256 amountIn;
    uint256 minAmountOut;
    bool isBuy;
    uint256 deadline;
    uint256 merkleIndex;
}

contract DarkPool {
    IRiscZeroVerifier public verifier;
    bytes32 public imageId;

    bytes32 public merkleRoot;
    uint256 public orderCount;
    uint256 public batchNonce;

    mapping(bytes32 => CommittedOrder) public commitments;
    mapping(bytes32 => RevealedOrder) public revealedOrders;
    mapping(bytes32 => bool) public usedNullifiers;
    mapping(address => uint256) public deposits;

    bytes32[] public commitmentList;

    event OrderCommitted(bytes32 indexed commitment, address indexed depositor, uint256 timestamp);
    event OrderRevealed(bytes32 indexed orderHash, bytes32 indexed nullifier);
    event BatchSettled(bytes32 indexed auctionId, bytes32 merkleRoot, uint256 matchCount);
    event SolvencyVerified(uint256 poolBalance, uint256 totalObligations, uint256 timestamp);
    event Deposit(address indexed user, uint256 amount);
    event Withdrawal(address indexed user, uint256 amount);

    modifier onlyValidImageId() {
        require(imageId != bytes32(0), "Image ID not set");
        _;
    }

    constructor(address _verifier, bytes32 _imageId) {
        verifier = IRiscZeroVerifier(_verifier);
        imageId = _imageId;
        merkleRoot = bytes32(0);
    }

    function deposit() external payable {
        deposits[msg.sender] += msg.value;
        emit Deposit(msg.sender, msg.value);
    }

    function withdraw(uint256 amount) external {
        require(deposits[msg.sender] >= amount, "Insufficient deposit");
        deposits[msg.sender] -= amount;
        (bool ok,) = msg.sender.call{value: amount}("");
        require(ok, "Transfer failed");
        emit Withdrawal(msg.sender, amount);
    }

    function commitOrder(bytes32 commitment, bytes32 _merkleRoot) external {
        require(commitments[commitment].timestamp == 0, "Already committed");

        commitments[commitment] = CommittedOrder({
            commitment: commitment,
            depositor: msg.sender,
            timestamp: block.timestamp,
            revealed: false
        });

        commitmentList.push(commitment);
        orderCount++;

        if (_merkleRoot != bytes32(0)) {
            merkleRoot = _merkleRoot;
        } else if (commitmentList.length > 0) {
            merkleRoot = MerkleTree.buildRoot(commitmentList);
        }

        emit OrderCommitted(commitment, msg.sender, block.timestamp);
    }

    function revealOrder(
        bytes32 orderHash,
        bytes32 nullifier,
        address tokenIn,
        address tokenOut,
        uint256 amountIn,
        uint256 minAmountOut,
        bool isBuy,
        uint256 deadline,
        bytes32 salt,
        bytes32[] calldata merkleProof,
        uint256 merkleIndex
    ) external {
        bytes32 orderDataHash = keccak256(
            abi.encodePacked(tokenIn, tokenOut, amountIn, minAmountOut, isBuy, deadline, salt)
        );
        bytes32 expectedCommitment = keccak256(abi.encodePacked(orderDataHash, nullifier));

        require(commitments[expectedCommitment].timestamp > 0, "No matching commitment");
        require(!commitments[expectedCommitment].revealed, "Already revealed");
        require(!usedNullifiers[nullifier], "Nullifier used");
        require(deadline >= block.timestamp, "Order expired");

        bytes32 leaf = expectedCommitment;
        require(
            MerkleTree.verify(leaf, merkleProof, merkleIndex, merkleRoot),
            "Invalid Merkle proof"
        );

        commitments[expectedCommitment].revealed = true;
        usedNullifiers[nullifier] = true;

        revealedOrders[orderHash] = RevealedOrder({
            orderHash: orderHash,
            nullifier: nullifier,
            tokenIn: tokenIn,
            tokenOut: tokenOut,
            amountIn: amountIn,
            minAmountOut: minAmountOut,
            isBuy: isBuy,
            deadline: deadline,
            merkleIndex: merkleIndex
        });

        emit OrderRevealed(orderHash, nullifier);
    }

    function settleBatch(
        bytes calldata seal,
        bytes32 _imageId,
        bytes calldata journal
    ) external onlyValidImageId {
        require(_imageId == imageId, "Wrong image ID");
        require(verifier.verify(seal, _imageId, journal), "Proof verification failed");

        batchNonce++;

        bytes32 auctionId = keccak256(abi.encodePacked(batchNonce, block.timestamp));

        commitmentList = new bytes32[](0);
        merkleRoot = bytes32(0);

        emit BatchSettled(auctionId, merkleRoot, 0);
    }

    function verifySolvency(
        bytes calldata seal,
        bytes32 _imageId,
        bytes calldata journal
    ) external onlyValidImageId returns (bool) {
        require(_imageId == imageId, "Wrong image ID");
        require(verifier.verify(seal, _imageId, journal), "Proof verification failed");

        emit SolvencyVerified(address(this).balance, 0, block.timestamp);
        return true;
    }

    function getCommitmentList() external view returns (bytes32[] memory) {
        return commitmentList;
    }

    function getOrderCommitment(bytes32 orderId) external view returns (bytes32) {
        return commitments[orderId].commitment;
    }
}
