import { keccak256, toBytes, encodeAbiParameters, parseAbiParameters, hexToBytes, bytesToHex } from "viem";
import type { Order, MerkleProof } from "@/types";

const POSEIDON_ZERO =
  "0x0000000000000000000000000000000000000000000000000000000000000000" as const;

export function hashOrder(order: {
  tokenIn: `0x${string}`;
  tokenOut: `0x${string}`;
  amountIn: bigint;
  minAmountOut: bigint;
  isBuy: boolean;
  deadline: number;
  salt: `0x${string}`;
}): `0x${string}` {
  const encoded = encodeAbiParameters(
    parseAbiParameters(
      "address tokenIn, address tokenOut, uint256 amountIn, uint256 minAmountOut, bool isBuy, uint256 deadline, bytes32 salt"
    ),
    [
      order.tokenIn,
      order.tokenOut,
      order.amountIn,
      order.minAmountOut,
      order.isBuy,
      BigInt(order.deadline),
      order.salt,
    ]
  );
  return keccak256(encoded);
}

export function generateCommitment(orderHash: `0x${string}`, nullifier: `0x${string}`): `0x${string}` {
  return keccak256(
    encodeAbiParameters(parseAbiParameters("bytes32 orderHash, bytes32 nullifier"), [orderHash, nullifier])
  );
}

export function generateNullifier(): `0x${string}` {
  const randomBytes = new Uint8Array(32);
  crypto.getRandomValues(randomBytes);
  return bytesToHex(randomBytes) as `0x${string}`;
}

export function generateSalt(): `0x${string}` {
  const randomBytes = new Uint8Array(32);
  crypto.getRandomValues(randomBytes);
  return bytesToHex(randomBytes) as `0x${string}`;
}

export function buildMerkleTree(leaves: `0x${string}`[]): {
  root: `0x${string}`;
  proofs: MerkleProof[];
} {
  if (leaves.length === 0) {
    return { root: POSEIDON_ZERO, proofs: [] };
  }

  const nextPowerOf2 = Math.pow(2, Math.ceil(Math.log2(leaves.length)));
  const padded = [...leaves];
  while (padded.length < nextPowerOf2) {
    padded.push(POSEIDON_ZERO);
  }

  const tree: `0x${string}`[][] = [padded];
  let current = padded;
  while (current.length > 1) {
    const next: `0x${string}`[] = [];
    for (let i = 0; i < current.length; i += 2) {
      const left = current[i];
      const right = current[i + 1];
      next.push(keccak256(concatHex(left, right)));
    }
    tree.push(next);
    current = next;
  }

  const root = current[0];
  const proofs: MerkleProof[] = [];

  for (let i = 0; i < leaves.length; i++) {
    const siblings: `0x${string}`[] = [];
    let index = i;
    for (let level = 0; level < tree.length - 1; level++) {
      const siblingIndex = index % 2 === 0 ? index + 1 : index - 1;
      siblings.push(tree[level][siblingIndex]);
      index = Math.floor(index / 2);
    }
    proofs.push({
      leaf: leaves[i],
      index: i,
      siblings,
      root,
    });
  }

  return { root, proofs };
}

function concatHex(a: `0x${string}`, b: `0x${string}`): Uint8Array {
  return new Uint8Array([...hexToBytes(a), ...hexToBytes(b)]);
}

export function verifyMerkleProof(proof: MerkleProof): boolean {
  let current = proof.leaf;
  let index = proof.index;
  for (const sibling of proof.siblings) {
    if (index % 2 === 0) {
      current = keccak256(concatHex(current, sibling));
    } else {
      current = keccak256(concatHex(sibling, current));
    }
    index = Math.floor(index / 2);
  }
  return current === proof.root;
}
