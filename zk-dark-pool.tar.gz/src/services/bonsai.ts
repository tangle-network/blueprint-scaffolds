import { ProofPhase, ProofStatus } from '../types';
import { toHex, fromHex } from '../crypto';

interface BonsaiRequest {
  imageId: string;
  journal: string;
  input: string;
}

interface BonsaiResponse {
  requestId: string;
  status: 'queued' | 'running' | 'complete' | 'failed';
  seal?: string;
  journal?: string;
}

const MOCK_IMAGE_ID = 'zk-darkpool-match-v1';

export async function requestProof(
  journalData: Uint8Array,
  input: Uint8Array,
): Promise<string> {
  const request: BonsaiRequest = {
    imageId: MOCK_IMAGE_ID,
    journal: toHex(journalData),
    input: toHex(input),
  };

  console.log('[Bonsai] Requesting proof:', request);
  return `req-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

export async function pollProofStatus(
  requestId: string,
): Promise<BonsaiResponse> {
  console.log('[Bonsai] Polling:', requestId);
  return {
    requestId,
    status: 'complete',
    seal: `0x${'ab'.repeat(256)}`,
    journal: `0x${'00'.repeat(128)}`,
  };
}

export async function submitToVerifier(
  seal: `0x${string}`,
  journal: `0x${string}`,
  verifierAddress: `0x${string}`,
): Promise<{ txHash: `0x${string}`; verified: boolean }> {
  console.log('[Verifier] Submitting:', {
    seal: seal.slice(0, 18) + '...',
    verifier: verifierAddress,
  });
  return {
    txHash: `0x${Date.now().toString(16)}${'0'.repeat(56)}`.slice(0, 66) as `0x${string}`,
    verified: true,
  };
}

export function buildMatchingJournal(
  orderIds: string[],
  matches: { buyOrderId: string; sellOrderId: string; fillAmount: bigint; price: bigint }[],
  merkleRoot: `0x${string}`,
): Uint8Array {
  const parts: string[] = [
    `MATCHING_PROOF_V1`,
    `orders:${orderIds.length}`,
    `matches:${matches.length}`,
    `merkle_root:${merkleRoot}`,
  ];
  for (const m of matches) {
    parts.push(`match:${m.buyOrderId}:${m.sellOrderId}:${m.fillAmount}:${m.price}`);
  }
  return new TextEncoder().encode(parts.join('\n'));
}

export function buildSolvencyJournal(
  trader: string,
  balanceRoot: `0x${string}`,
  obligations: bigint,
  assets: bigint,
): Uint8Array {
  const data = [
    'SOLVENCY_PROOF_V1',
    `trader:${trader}`,
    `balance_root:${balanceRoot}`,
    `obligations:${obligations}`,
    `assets:${assets}`,
    `solvent:${assets >= obligations}`,
  ];
  return new TextEncoder().encode(data.join('\n'));
}
