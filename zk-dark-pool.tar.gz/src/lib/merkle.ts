import type { MerkleTree } from "./types"

function hashLeaf(leaf: string): string {
  let hash = 0
  for (let i = 0; i < leaf.length; i++) {
    const char = leaf.charCodeAt(i)
    hash = ((hash << 5) - hash) + char
    hash = hash & hash
  }
  return "0x" + Math.abs(hash).toString(16).padStart(16, "0") + leaf.slice(2, 18)
}

export function buildMerkleTree(leaves: string[]): MerkleTree {
  const depth = Math.ceil(Math.log2(Math.max(leaves.length, 1)))
  const paddedLeaves = [...leaves]
  while (paddedLeaves.length < Math.pow(2, depth)) {
    paddedLeaves.push("0x" + "00".repeat(32))
  }

  const layers: string[][] = [paddedLeaves]
  let currentLayer = paddedLeaves

  for (let i = 0; i < depth; i++) {
    const nextLayer: string[] = []
    for (let j = 0; j < currentLayer.length; j += 2) {
      const combined = hashLeaf(currentLayer[j] + currentLayer[j + 1])
      nextLayer.push(combined)
    }
    layers.push(nextLayer)
    currentLayer = nextLayer
  }

  return {
    root: currentLayer[0],
    depth,
    leaves: paddedLeaves,
    layers,
  }
}

export function getMerkleProof(tree: MerkleTree, leafIndex: number): string[] {
  const proof: string[] = []
  let index = leafIndex

  for (let i = 0; i < tree.depth; i++) {
    const siblingIndex = index % 2 === 0 ? index + 1 : index - 1
    if (siblingIndex < tree.layers[i].length) {
      proof.push(tree.layers[i][siblingIndex])
    } else {
      proof.push("0x" + "00".repeat(32))
    }
    index = Math.floor(index / 2)
  }

  return proof
}

export function verifyMerkleProof(root: string, leaf: string, proof: string[], index: number): boolean {
  let currentHash = leaf
  for (const sibling of proof) {
    if (index % 2 === 0) {
      currentHash = hashLeaf(currentHash + sibling)
    } else {
      currentHash = hashLeaf(sibling + currentHash)
    }
    index = Math.floor(index / 2)
  }
  return currentHash === root
}
