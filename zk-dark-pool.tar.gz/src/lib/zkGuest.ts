import type { BatchAuction, MatchResult, Order } from "./types"

export interface GuestCodeInput {
  orders: Order[]
  anonymitySetRoot: string
  solvencyData: {
    totalAssets: Record<string, string>
    totalLiabilities: Record<string, string>
  }
}

export interface GuestCodeOutput {
  matchedPairs: MatchResult[]
  clearingPrice: string
  totalVolume: string
  solvencyRoot: string
  newAnonymitySetRoot: string
  journal: string
}

function simulateMatching(orders: Order[]): { matches: MatchResult[]; clearingPrice: string; volume: string } {
  const buys = orders.filter(o => o.side === "buy" && o.status === "revealed").sort((a, b) => Number(b.price) - Number(a.price))
  const sells = orders.filter(o => o.side === "sell" && o.status === "revealed").sort((a, b) => Number(a.price) - Number(b.price))

  const matches: MatchResult[] = []
  let volume = 0

  let bi = 0
  let si = 0

  while (bi < buys.length && si < sells.length) {
    const buy = buys[bi]
    const sell = sells[si]

    if (Number(buy.price) >= Number(sell.price)) {
      const matchPrice = ((Number(buy.price) + Number(sell.price)) / 2).toFixed(2)
      const matchAmount = Math.min(Number(buy.amount), Number(sell.amount)).toString()

      matches.push({
        buyOrderId: buy.id,
        sellOrderId: sell.id,
        price: matchPrice,
        amount: matchAmount,
        buyTrader: buy.trader,
        sellTrader: sell.trader,
      })

      volume += Number(matchAmount)
      bi++
      si++
    } else {
      break
    }
  }

  const clearingPrice = matches.length > 0 ? matches[matches.length - 1].price : "0"
  return { matches, clearingPrice, volume: volume.toString() }
}

export function executeGuestCode(input: GuestCodeInput): GuestCodeOutput {
  const { matches, clearingPrice, volume } = simulateMatching(input.orders)

  const totalAssetValues = Object.values(input.solvencyData.totalAssets).reduce((a, b) => a + Number(b), 0)
  const totalLiabilityValues = Object.values(input.solvencyData.totalLiabilities).reduce((a, b) => a + Number(b), 0)
  const solvent = totalAssetValues >= totalLiabilityValues

  const journal = JSON.stringify({
    matchCount: matches.length,
    clearingPrice,
    totalVolume: volume,
    solvent,
    timestamp: Date.now(),
  })

  return {
    matchedPairs: matches,
    clearingPrice,
    totalVolume: volume,
    solvencyRoot: solvent ? "0x" + "ff".repeat(32) : "0x" + "00".repeat(32),
    newAnonymitySetRoot: "0x" + Math.abs(matches.length).toString(16).padStart(64, "0"),
    journal,
  }
}

export function simulateProofGeneration(output: GuestCodeOutput): string {
  return "0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join("")
}
