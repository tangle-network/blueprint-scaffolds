export interface Order {
  id: string
  trader: string
  side: "buy" | "sell"
  tokenIn: string
  tokenOut: string
  amount: string
  price: string
  nonce: string
  commitmentHash: string
  nullifier: string
  status: "pending" | "committed" | "revealed" | "matched" | "settled" | "expired"
  createdAt: number
  revealDeadline: number
}

export interface Commitment {
  hash: string
  orderId: string
  nullifier: string
  amount: string
  tokenIn: string
  tokenOut: string
  timestamp: number
}

export interface BatchAuction {
  id: string
  orders: string[]
  clearingPrice: string
  totalVolume: string
  matchedPairs: MatchResult[]
  proofHash: string
  status: "collecting" | "matching" | "proving" | "settled" | "failed"
  startedAt: number
  settledAt?: number
}

export interface MatchResult {
  buyOrderId: string
  sellOrderId: string
  price: string
  amount: string
  buyTrader: string
  sellTrader: string
}

export interface ZKProof {
  id: string
  journal: string
  seal: string
  imageId: string
  status: "generating" | "submitted" | "verified" | "failed"
  auctionId: string
  createdAt: number
  verifiedAt?: number
}

export interface SolvencyProof {
  id: string
  totalAssets: Record<string, string>
  totalLiabilities: Record<string, string>
  merkleRoot: string
  proof: ZKProof
  timestamp: number
  verified: boolean
}

export interface MerkleTree {
  root: string
  depth: number
  leaves: string[]
  layers: string[][]
}

export interface AnonymitySet {
  id: string
  merkleRoot: string
  members: string[]
  size: number
  createdAt: number
  active: boolean
}

export type OrderSide = "buy" | "sell"
export type ProofStatus = "generating" | "submitted" | "verified" | "failed"
export type AuctionStatus = "collecting" | "matching" | "proving" | "settled" | "failed"

export const DEFAULT_ORDERS: Order[] = [
  {
    id: "0xa1b2c3d4",
    trader: "0x742d35Cc6634C0532925a3b844Bc9e7595f2bD08",
    side: "buy",
    tokenIn: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
    tokenOut: "0x0000000000000000000000000000000000000000",
    amount: "2.5",
    price: "3842.50",
    nonce: "0x1a2b3c4d5e6f7890",
    commitmentHash: "0xabc123def456789012345678901234567890abcdef1234567890abcdef123456",
    nullifier: "0x111222333444555666777888999aaabbbcccdddeeefff000111222333444555",
    status: "settled",
    createdAt: Date.now() - 3600000,
    revealDeadline: Date.now() - 3000000,
  },
  {
    id: "0xe5f6a7b8",
    trader: "0x8ba1f109551bF4CD8044776c688BAb2C5D8F3E9A",
    side: "sell",
    tokenIn: "0x0000000000000000000000000000000000000000",
    tokenOut: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
    amount: "1.8",
    price: "3845.00",
    nonce: "0x2b3c4d5e6f789012",
    commitmentHash: "0xdef78901234567890123456789abcdef0123456789abcdef0123456789abcdef",
    nullifier: "0x666777888999aaabbbcccdddeeefff000111222333444555666777888999000",
    status: "settled",
    createdAt: Date.now() - 3500000,
    revealDeadline: Date.now() - 2900000,
  },
  {
    id: "0xc9d0e1f2",
    trader: "0x5aAeb6053F3E94C9b9A09f33669435E7Ef1BeAed",
    side: "buy",
    tokenIn: "0x6B175474E89094C44Da98b954EedeAC495271d0F",
    tokenOut: "0x0000000000000000000000000000000000000000",
    amount: "5.0",
    price: "3840.75",
    nonce: "0x3c4d5e6f78901234",
    commitmentHash: "0x456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123",
    nullifier: "0xaaabbbcccdddeeefff000111222333444555666777888999000111222333444",
    status: "revealed",
    createdAt: Date.now() - 1800000,
    revealDeadline: Date.now() - 1200000,
  },
  {
    id: "0xa3b4c5d6",
    trader: "0xfB6916095ca1df60bB79Ce92cE3Ea74c37c5d359",
    side: "sell",
    tokenIn: "0x0000000000000000000000000000000000000000",
    tokenOut: "0x6B175474E89094C44Da98b954EedeAC495271d0F",
    amount: "3.2",
    price: "3848.25",
    nonce: "0x4d5e6f7890123456",
    commitmentHash: "0x789abcdef0123456789abcdef0123456789abcdef0123456789abcdef01234567",
    nullifier: "0xbbbcccdddeeefff000111222333444555666777888999000111222333444555666",
    status: "committed",
    createdAt: Date.now() - 900000,
    revealDeadline: Date.now() - 300000,
  },
  {
    id: "0xd7e8f9a0",
    trader: "0xAb5801a7D398351b8bE11C439e05C5B3259aeC9B",
    side: "buy",
    tokenIn: "0xdAC17F958D2ee523a2206206994597C13D831ec7",
    tokenOut: "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599",
    amount: "0.15",
    price: "62450.00",
    nonce: "0x5e6f789012345678",
    commitmentHash: "0xbcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789ab",
    nullifier: "0xcccdddeeefff000111222333444555666777888999000111222333444555666777",
    status: "pending",
    createdAt: Date.now() - 300000,
    revealDeadline: Date.now() + 300000,
  },
  {
    id: "0xb1c2d3e4",
    trader: "0x1Db3436F50a82307c4EF02bC8C1f9E41d95c2915",
    side: "sell",
    tokenIn: "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599",
    tokenOut: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
    amount: "0.08",
    price: "62480.00",
    nonce: "0x6f78901234567890",
    commitmentHash: "0xef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
    nullifier: "0xdddeeefff000111222333444555666777888999000111222333444555666777888",
    status: "matched",
    createdAt: Date.now() - 7200000,
    revealDeadline: Date.now() - 6600000,
  },
]

export const DEFAULT_AUCTIONS: BatchAuction[] = [
  {
    id: "0x00112233",
    orders: ["0xa1b2c3d4", "0xe5f6a7b8", "0xb1c2d3e4"],
    clearingPrice: "3843.75",
    totalVolume: "4.3",
    matchedPairs: [
      {
        buyOrderId: "0xa1b2c3d4",
        sellOrderId: "0xe5f6a7b8",
        price: "3843.75",
        amount: "1.8",
        buyTrader: "0x742d35Cc6634C0532925a3b844Bc9e7595f2bD08",
        sellTrader: "0x8ba1f109551bF4CD8044776c688BAb2C5D8F3E9A",
      },
    ],
    proofHash: "0x" + "a1b2".repeat(16),
    status: "settled",
    startedAt: Date.now() - 7200000,
    settledAt: Date.now() - 6000000,
  },
  {
    id: "0x44556677",
    orders: ["0xc9d0e1f2", "0xa3b4c5d6"],
    clearingPrice: "0",
    totalVolume: "0",
    matchedPairs: [],
    proofHash: "",
    status: "collecting",
    startedAt: Date.now() - 1800000,
  },
]

export const DEFAULT_PROOFS: ZKProof[] = [
  {
    id: "0xp001a001",
    journal: JSON.stringify({ matchCount: 1, clearingPrice: "3843.75", totalVolume: "1.8", solvent: true, timestamp: Date.now() - 6000000 }),
    seal: "0x" + "aa11".repeat(16),
    imageId: "0x" + "ab".repeat(32),
    status: "verified",
    auctionId: "0x00112233",
    createdAt: Date.now() - 6600000,
    verifiedAt: Date.now() - 6200000,
  },
  {
    id: "0xp002b002",
    journal: JSON.stringify({ matchCount: 2, clearingPrice: "3841.50", totalVolume: "3.6", solvent: true, timestamp: Date.now() - 86400000 }),
    seal: "0x" + "bb22".repeat(16),
    imageId: "0x" + "ab".repeat(32),
    status: "verified",
    auctionId: "0xff001100",
    createdAt: Date.now() - 86400000,
    verifiedAt: Date.now() - 82800000,
  },
]

export const DEFAULT_SOLVENCY_PROOFS: SolvencyProof[] = [
  {
    id: "0xsp001",
    totalAssets: { ETH: "1000", USDC: "2000000", DAI: "500000", WBTC: "12.5" },
    totalLiabilities: { ETH: "800", USDC: "1500000", DAI: "400000", WBTC: "10.0" },
    merkleRoot: "0x" + "ff".repeat(32),
    proof: {
      id: "0xsp_proof001",
      journal: JSON.stringify({ solvencyData: { totalAssets: { ETH: "1000" }, totalLiabilities: { ETH: "800" } }, merkleRoot: "0x" + "ff".repeat(32), timestamp: Date.now() - 3600000 }),
      seal: "0x" + "cc33".repeat(16),
      imageId: "0x" + "ab".repeat(32),
      status: "verified",
      auctionId: "",
      createdAt: Date.now() - 3600000,
      verifiedAt: Date.now() - 3000000,
    },
    timestamp: Date.now() - 3600000,
    verified: true,
  },
]

export const DEFAULT_ANONYMITY_SETS: AnonymitySet[] = [
  {
    id: "0xas01",
    merkleRoot: "0x" + "dd44".repeat(16),
    members: [
      "0xabc123def456789012345678901234567890abcdef1234567890abcdef123456",
      "0xdef78901234567890123456789abcdef0123456789abcdef0123456789abcdef",
      "0x456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123",
      "0xef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
    ],
    size: 64,
    createdAt: Date.now() - 86400000,
    active: true,
  },
]
