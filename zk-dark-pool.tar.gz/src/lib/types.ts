export interface Order {
  id: string
  trader: string
  side: "buy" | "sell"
  tokenIn: string
  tokenOut: string
  amount: string
  price: string
  nonce: string
  commitmentHash: string
  nullifier: string
  status: "pending" | "committed" | "revealed" | "matched" | "settled" | "expired"
  createdAt: number
  revealDeadline: number
}

export interface Commitment {
  hash: string
  orderId: string
  nullifier: string
  amount: string
  tokenIn: string
  tokenOut: string
  timestamp: number
}

export interface BatchAuction {
  id: string
  orders: string[]
  clearingPrice: string
  totalVolume: string
  matchedPairs: MatchResult[]
  proofHash: string
  status: "collecting" | "matching" | "proving" | "settled" | "failed"
  startedAt: number
  settledAt?: number
}

export interface MatchResult {
  buyOrderId: string
  sellOrderId: string
  price: string
  amount: string
  buyTrader: string
  sellTrader: string
}

export interface ZKProof {
  id: string
  journal: string
  seal: string
  imageId: string
  status: "generating" | "submitted" | "verified" | "failed"
  auctionId: string
  createdAt: number
  verifiedAt?: number
}

export interface SolvencyProof {
  id: string
  totalAssets: Record<string, string>
  totalLiabilities: Record<string, string>
  merkleRoot: string
  proof: ZKProof
  timestamp: number
  verified: boolean
}

export interface MerkleTree {
  root: string
  depth: number
  leaves: string[]
  layers: string[][]
}

export interface AnonymitySet {
  id: string
  merkleRoot: string
  members: string[]
  size: number
  createdAt: number
  active: boolean
}

export type OrderSide = "buy" | "sell"
export type ProofStatus = "generating" | "submitted" | "verified" | "failed"
export type AuctionStatus = "collecting" | "matching" | "proving" | "settled" | "failed"
