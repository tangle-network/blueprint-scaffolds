export const TOKENS: Record<string, { symbol: string; name: string; decimals: number }> = {
  "0x0000000000000000000000000000000000000000": { symbol: "ETH", name: "Ether", decimals: 18 },
  "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48": { symbol: "USDC", name: "USD Coin", decimals: 6 },
  "0x6B175474E89094C44Da98b954EedeAC495271d0F": { symbol: "DAI", name: "Dai Stablecoin", decimals: 18 },
  "0xdAC17F958D2ee523a2206206994597C13D831ec7": { symbol: "USDT", name: "Tether USD", decimals: 6 },
  "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599": { symbol: "WBTC", name: "Wrapped BTC", decimals: 8 },
}

export const SUPPORTED_PAIRS = [
  { base: "ETH", quote: "USDC" },
  { base: "ETH", quote: "DAI" },
  { base: "WBTC", quote: "ETH" },
  { base: "WBTC", quote: "USDC" },
]

export const DARK_POOL_CONFIG = {
  batchIntervalMs: 30000,
  maxBatchSize: 100,
  minOrderSize: "0.01",
  revealWindowMs: 60000,
  merkleTreeDepth: 32,
  anonymitySetMinSize: 64,
}

export const RISC_ZERO_CONFIG = {
  imageId: "0x" + "ab".repeat(32),
  bonsaiApiUrl: "https://bonsai-api.risczero.com",
  verifierAddress: "0x1234567890abcdef1234567890abcdef12345678",
  settlementContract: "0xabcdef1234567890abcdef1234567890abcdef12",
}

export const AUCTION_STATES = {
  collecting: { label: "Collecting Orders", color: "text-yellow-400" },
  matching: { label: "Running Matching", color: "text-blue-400" },
  proving: { label: "Generating Proof", color: "text-purple-400" },
  settled: { label: "Settled", color: "text-green-400" },
  failed: { label: "Failed", color: "text-red-400" },
} as const

export const ORDER_STATES = {
  pending: { label: "Pending", color: "text-yellow-400" },
  committed: { label: "Committed", color: "text-blue-400" },
  revealed: { label: "Revealed", color: "text-purple-400" },
  matched: { label: "Matched", color: "text-green-400" },
  settled: { label: "Settled", color: "text-emerald-400" },
  expired: { label: "Expired", color: "text-red-400" },
} as const
