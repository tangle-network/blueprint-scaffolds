export async function mockBonsaiProve(journal: string): Promise<{ seal: string; imageId: string }> {
  const encoder = new TextEncoder()
  const data = encoder.encode(journal + Date.now())
  const hashBuffer = await crypto.subtle.digest("SHA-256", data)
  const seal = "0x" + Array.from(new Uint8Array(hashBuffer)).map(b => b.toString(16).padStart(2, "0")).join("")
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        seal,
        imageId: "0x" + "ab".repeat(32),
      })
    }, 2000)
  })
}
