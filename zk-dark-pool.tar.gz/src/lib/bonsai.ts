import { createHash, randomBytes } from "crypto"

export function mockBonsaiProve(journal: string): Promise<{ seal: string; imageId: string }> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const seal = "0x" + createHash("sha256").update(journal + Date.now()).digest("hex")
      resolve({
        seal,
        imageId: "0x" + "ab".repeat(32),
      })
    }, 2000)
  })
}
