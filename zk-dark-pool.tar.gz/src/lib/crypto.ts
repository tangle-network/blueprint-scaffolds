export async function hashCommitment(data: string): Promise<string> {
  const encoder = new TextEncoder()
  const dataBuffer = encoder.encode(data)
  const hashBuffer = await crypto.subtle.digest("SHA-256", dataBuffer)
  return "0x" + Array.from(new Uint8Array(hashBuffer)).map(b => b.toString(16).padStart(2, "0")).join("")
}

export async function generateNullifier(secret: string, orderId: string): Promise<string> {
  return hashCommitment(`${secret}:${orderId}`)
}

export async function computeOrderCommitment(
  side: string,
  tokenIn: string,
  tokenOut: string,
  amount: string,
  price: string,
  nonce: string,
  secret: string
): Promise<string> {
  const payload = `${side}:${tokenIn}:${tokenOut}:${amount}:${price}:${nonce}:${secret}`
  return hashCommitment(payload)
}

export function generateSecret(): string {
  const bytes = new Uint8Array(32)
  crypto.getRandomValues(bytes)
  return "0x" + Array.from(bytes).map(b => b.toString(16).padStart(2, "0")).join("")
}

export function generateNonce(): string {
  const bytes = new Uint8Array(16)
  crypto.getRandomValues(bytes)
  return "0x" + Array.from(bytes).map(b => b.toString(16).padStart(2, "0")).join("")
}
