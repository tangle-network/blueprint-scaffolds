import { ProofPhase } from '../types';

export interface MatchingInput {
  orders: {
    trader: string;
    tokenIn: string;
    tokenOut: string;
    amountIn: string;
    minAmountOut: string;
    nonce: string;
  }[];
  batchSize: number;
}

export interface MatchingOutput {
  matches: {
    buyIdx: number;
    sellIdx: number;
    fillAmount: string;
    price: string;
  }[];
  clearingPrices: Record<string, string>;
  totalVolume: string;
  merkleRoot: string;
  solventProofs: { trader: string; solvent: boolean }[];
}

export function encodeMatchingInput(input: MatchingInput): Uint8Array {
  return new TextEncoder().encode(JSON.stringify(input));
}

export function decodeMatchingOutput(data: Uint8Array): MatchingOutput {
  return JSON.parse(new TextDecoder().decode(data));
}

export function simulateGuestMatching(
  input: MatchingInput,
): MatchingOutput {
  const matches: MatchingOutput['matches'] = [];
  const clearingPrices: Record<string, string> = {};
  const solventProofs: MatchingOutput['solventProofs'] = [];
  let totalVolume = 0n;

  const buys = input.orders.filter((o) => BigInt(o.amountIn) > 0n);
  const sells = [...input.orders];

  for (let bi = 0; bi < buys.length; bi++) {
    for (let si = 0; si < sells.length; si++) {
      if (
        buys[bi].tokenIn === sells[si].tokenOut &&
        buys[bi].tokenOut === sells[si].tokenIn &&
        buys[bi].trader !== sells[si].trader
      ) {
        const buyAmt = BigInt(buys[bi].amountIn);
        const sellAmt = BigInt(sells[si].amountIn);
        const fill = buyAmt < sellAmt ? buyAmt : sellAmt;
        const price =
          (BigInt(buys[bi].minAmountOut) + sellAmt) / 2n;

        matches.push({
          buyIdx: input.orders.indexOf(buys[bi]),
          sellIdx: input.orders.indexOf(sells[si]),
          fillAmount: fill.toString(),
          price: price.toString(),
        });

        const pair = `${buys[bi].tokenIn}-${buys[bi].tokenOut}`;
        clearingPrices[pair] = price.toString();
        totalVolume += fill;

        solventProofs.push({ trader: buys[bi].trader, solvent: true });
        solventProofs.push({ trader: sells[si].trader, solvent: true });
        break;
      }
    }
  }

  return {
    matches,
    clearingPrices,
    totalVolume: totalVolume.toString(),
    merkleRoot: `0x${'0'.repeat(64)}`,
    solventProofs,
  };
}
