export const DARKPOOL_CONFIG = {
  clearingHouse: '0x0000000000000000000000000000000000000000' as `0x${string}`,
  verifier: '0x0000000000000000000000000000000000000000' as `0x${string}`,
  bonsaiRelay: '0x0000000000000000000000000000000000000000' as `0x${string}`,
  settlementTimeout: 300,
  maxBatchSize: 64,
  minOrderSize: 0.01,
  supportedTokens: {
    WETH: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2' as `0x${string}`,
    USDC: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48' as `0x${string}`,
    USDT: '0xdAC17F958D2ee523a2206206994597C13D831ec7' as `0x${string}`,
  },
} as const;

export const IMAGE_ID =
  '0x0000000000000000000000000000000000000000000000000000000000000000' as const;

export type SupportedToken = keyof typeof DARKPOOL_CONFIG.supportedTokens;
