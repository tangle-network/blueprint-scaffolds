export const DARK_POOL_ABI = [
  {
    type: "function",
    name: "commitOrder",
    inputs: [
      { name: "commitment", type: "bytes32" },
      { name: "merkleRoot", type: "bytes32" },
    ],
    outputs: [],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "revealOrder",
    inputs: [
      { name: "orderHash", type: "bytes32" },
      { name: "nullifier", type: "bytes32" },
      { name: "tokenIn", type: "address" },
      { name: "tokenOut", type: "address" },
      { name: "amountIn", type: "uint256" },
      { name: "minAmountOut", type: "uint256" },
      { name: "isBuy", type: "bool" },
      { name: "deadline", type: "uint256" },
      { name: "salt", type: "bytes32" },
      { name: "merkleProof", type: "bytes32[]" },
    ],
    outputs: [],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "settleBatch",
    inputs: [
      { name: "seal", type: "bytes" },
      { name: "imageId", type: "bytes32" },
      { name: "journal", type: "bytes" },
    ],
    outputs: [],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "verifySolvency",
    inputs: [
      { name: "seal", type: "bytes" },
      { name: "imageId", type: "bytes32" },
      { name: "journal", type: "bytes" },
    ],
    outputs: [{ name: "", type: "bool" }],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "getOrderCommitment",
    inputs: [{ name: "orderId", type: "bytes32" }],
    outputs: [{ name: "", type: "bytes32" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "merkleRoot",
    inputs: [],
    outputs: [{ name: "", type: "bytes32" }],
    stateMutability: "view",
  },
  {
    type: "event",
    name: "OrderCommitted",
    inputs: [
      { name: "commitment", type: "bytes32", indexed: true },
      { name: "depositor", type: "address", indexed: true },
      { name: "timestamp", type: "uint256", indexed: false },
    ],
  },
  {
    type: "event",
    name: "BatchSettled",
    inputs: [
      { name: "auctionId", type: "bytes32", indexed: true },
      { name: "merkleRoot", type: "bytes32", indexed: false },
      { name: "matchCount", type: "uint256", indexed: false },
    ],
  },
  {
    type: "event",
    name: "SolvencyVerified",
    inputs: [
      { name: "poolBalance", type: "uint256", indexed: false },
      { name: "totalObligations", type: "uint256", indexed: false },
      { name: "timestamp", type: "uint256", indexed: false },
    ],
  },
] as const;

export const ERC20_ABI = [
  {
    type: "function",
    name: "approve",
    inputs: [
      { name: "spender", type: "address" },
      { name: "amount", type: "uint256" },
    ],
    outputs: [{ name: "", type: "bool" }],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "balanceOf",
    inputs: [{ name: "account", type: "address" }],
    outputs: [{ name: "", type: "uint256" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "allowance",
    inputs: [
      { name: "owner", type: "address" },
      { name: "spender", type: "address" },
    ],
    outputs: [{ name: "", type: "uint256" }],
    stateMutability: "view",
  },
] as const;

export const DARK_POOL_ADDRESS = "0x0000000000000000000000000000000000000001" as `0x${string}`;

export const CHAIN_ID = 1;

export const BONSAI_API_URL = "https://api.bonsai.xyz/v1";
