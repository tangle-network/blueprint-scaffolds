import { OrderForm } from "@/components/OrderForm";
import { ProofStatusViewer } from "@/components/ProofStatusViewer";
import { WalletConnect } from "@/components/WalletConnect";
import { SolvencyPanel } from "@/components/SolvencyPanel";
import { BatchViewer } from "@/components/BatchViewer";

export default function App() {
  return (
    <div className="min-h-screen bg-dark-900">
      <header className="border-b border-gray-800 bg-dark-800/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-accent-600 rounded-lg flex items-center justify-center text-white font-bold text-sm">
              ZK
            </div>
            <div>
              <h1 className="text-lg font-bold text-white">ZK Dark Pool</h1>
              <p className="text-xs text-gray-500">Private order matching on RISC Zero</p>
            </div>
          </div>
          <WalletConnect />
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 space-y-6">
            <OrderForm />
            <SolvencyPanel />
          </div>

          <div className="lg:col-span-2 space-y-6">
            <ProofStatusViewer />
            <BatchViewer />

            <div className="bg-dark-700 rounded-xl p-6 border border-gray-800">
              <h2 className="text-xl font-semibold mb-4 text-white">Architecture</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  {
                    title: "zkVM",
                    desc: "RISC Zero guest code for batch auction matching with MEV protection",
                    icon: "🔐",
                  },
                  {
                    title: "Commit-Reveal",
                    desc: "Orders hidden until settlement — prices/sizes never exposed on-chain",
                    icon: "🙈",
                  },
                  {
                    title: "Merkle Sets",
                    desc: "Anonymity sets via Merkle tree commitments with zero-knowledge proofs",
                    icon: "🌳",
                  },
                  {
                    title: "Bonsai",
                    desc: "Groth16 proofs via Bonsai proving service, verified on EVM",
                    icon: "⚡",
                  },
                ].map((item) => (
                  <div
                    key={item.title}
                    className="bg-dark-800 rounded-lg p-4 border border-gray-700"
                  >
                    <div className="text-2xl mb-2">{item.icon}</div>
                    <h3 className="text-sm font-medium text-white mb-1">
                      {item.title}
                    </h3>
                    <p className="text-xs text-gray-500">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
