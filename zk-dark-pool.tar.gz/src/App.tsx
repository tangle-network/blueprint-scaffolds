import { BrowserRouter, Routes, Route, NavLink } from "react-router-dom"
import { Separator } from "@/components/ui/separator"
import Dashboard from "@/pages/Dashboard"
import OrderBook from "@/pages/OrderBook"
import Auctions from "@/pages/Auctions"
import Proofs from "@/pages/Proofs"
import { Shield } from "lucide-react"

const navItems = [
  { to: "/", label: "Dashboard" },
  { to: "/orders", label: "Orders" },
  { to: "/auctions", label: "Auctions" },
  { to: "/proofs", label: "Proofs" },
]

function Nav() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-sm">
      <div className="container mx-auto flex h-14 items-center px-4">
        <div className="flex items-center gap-2 mr-8">
          <Shield className="h-6 w-6 text-primary" />
          <span className="font-bold text-lg tracking-tight">ZK Dark Pool</span>
        </div>
        <nav className="flex items-center gap-1">
          {navItems.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === "/"}
              className={({ isActive }) =>
                `px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                  isActive
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-2">
          <span className="text-xs text-muted-foreground font-mono">RISC Zero zkVM</span>
          <Separator orientation="vertical" className="h-4" />
          <span className="text-xs text-muted-foreground">v1.0.0</span>
        </div>
      </div>
    </header>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-background">
        <Nav />
        <main className="container mx-auto px-4 py-6">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/orders" element={<OrderBook />} />
            <Route path="/auctions" element={<Auctions />} />
            <Route path="/proofs" element={<Proofs />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  )
}
