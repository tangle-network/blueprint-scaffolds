import { useState, useCallback } from "react";
import type { ProofStatus, MatchProof, SolvencyProof } from "@/types";

const MOCK_PROVING_TIME_MS = 3000;

export function useProofManager() {
  const [proofStatuses, setProofStatuses] = useState<Map<string, ProofStatus>>(new Map());
  const [isProving, setIsProving] = useState(false);

  const submitForProving = useCallback(
    async (orderId: string, orderData: unknown) => {
      setIsProving(true);

      const pending: ProofStatus = {
        orderId,
        status: "pending",
        timestamp: Date.now(),
      };
      setProofStatuses((prev) => new Map(prev).set(orderId, pending));

      await new Promise((r) => setTimeout(r, 500));

      setProofStatuses((prev) => {
        const next = new Map(prev);
        next.set(orderId, { ...pending, status: "proving" });
        return next;
      });

      await new Promise((r) => setTimeout(r, MOCK_PROVING_TIME_MS));

      const mockSeal = generateMockSeal();
      const mockImageId = generateMockImageId();

      const journal = encodeMatchJournal(orderData);

      const proof: MatchProof = {
        imageId: mockImageId,
        journal,
        seal: mockSeal,
        orderIds: [orderId, generateMockOrderId()],
        fillAmounts: [0n, 0n],
      };

      setProofStatuses((prev) => {
        const next = new Map(prev);
        next.set(orderId, {
          orderId,
          status: "submitted",
          seal: mockSeal,
          timestamp: Date.now(),
        });
        return next;
      });

      await new Promise((r) => setTimeout(r, 1500));

      const txHash = generateMockTxHash();
      setProofStatuses((prev) => {
        const next = new Map(prev);
        next.set(orderId, {
          orderId,
          status: "verified",
          seal: mockSeal,
          txHash,
          timestamp: Date.now(),
        });
        return next;
      });

      setIsProving(false);
      return proof;
    },
    []
  );

  const generateSolvencyProof = useCallback(async (): Promise<SolvencyProof> => {
    setIsProving(true);
    await new Promise((r) => setTimeout(r, MOCK_PROVING_TIME_MS));

    const proof: SolvencyProof = {
      imageId: generateMockImageId(),
      journal: generateMockSolvencyJournal(),
      seal: generateMockSeal(),
      poolBalance: BigInt("1000000000000000000000"),
      totalObligations: BigInt("750000000000000000000"),
      timestamp: Date.now(),
    };

    setIsProving(false);
    return proof;
  }, []);

  return {
    proofStatuses,
    isProving,
    submitForProving,
    generateSolvencyProof,
  };
}

function generateMockSeal(): `0x${string}` {
  const bytes = new Uint8Array(256);
  crypto.getRandomValues(bytes);
  const hex = Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
  return `0x${hex}` as `0x${string}`;
}

function generateMockImageId(): `0x${string}` {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  const hex = Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
  return `0x${hex}` as `0x${string}`;
}

function generateMockOrderId(): string {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function generateMockTxHash(): `0x${string}` {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  const hex = Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
  return `0x${hex}` as `0x${string}`;
}

function encodeMatchJournal(orderData: unknown): `0x${string}` {
  const bytes = new Uint8Array(128);
  crypto.getRandomValues(bytes);
  const hex = Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
  return `0x${hex}` as `0x${string}`;
}

function generateMockSolvencyJournal(): `0x${string}` {
  const bytes = new Uint8Array(96);
  crypto.getRandomValues(bytes);
  const hex = Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
  return `0x${hex}` as `0x${string}`;
}
