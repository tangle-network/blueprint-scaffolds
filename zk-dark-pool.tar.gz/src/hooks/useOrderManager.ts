import { useState, useCallback } from "react";
import { useAccount, useWriteContract, useWaitForTransactionReceipt, useReadContract } from "wagmi";
import { parseUnits } from "viem";
import { DARK_POOL_ABI, DARK_POOL_ADDRESS, ERC20_ABI } from "@/config/contracts";
import { hashOrder, generateCommitment, generateNullifier, generateSalt } from "@/utils/crypto";
import type { Order, OrderStatus } from "@/types";

const USDC_ADDRESS = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48" as `0x${string}`;
const WETH_ADDRESS = "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2" as `0x${string}`;

export function useOrderManager() {
  const { address } = useAccount();
  const { writeContractAsync } = useWriteContract();
  const [orders, setOrders] = useState<Map<string, Order>>(new Map());
  const [isSubmitting, setIsSubmitting] = useState(false);

  const pendingTxHash = useState<`0x${string}` | undefined>(undefined)[0];

  const { isLoading: isConfirming } = useWaitForTransactionReceipt({
    hash: pendingTxHash,
  });

  const submitCommitOrder = useCallback(
    async (params: {
      tokenIn: string;
      tokenOut: string;
      amountIn: string;
      minAmountOut: string;
      isBuy: boolean;
      deadline: number;
    }) => {
      if (!address) throw new Error("Wallet not connected");
      setIsSubmitting(true);

      try {
        const amountInBN = parseUnits(params.amountIn, 18);
        const minAmountOutBN = parseUnits(params.minAmountOut, 18);
        const salt = generateSalt();
        const nullifier = generateNullifier();

        const orderHash = hashOrder({
          tokenIn: params.tokenIn as `0x${string}`,
          tokenOut: params.tokenOut as `0x${string}`,
          amountIn: amountInBN,
          minAmountOut: minAmountOutBN,
          isBuy: params.isBuy,
          deadline: params.deadline,
          salt,
        });

        const commitment = generateCommitment(orderHash, nullifier);

        await writeContractAsync({
          address: params.tokenIn as `0x${string}`,
          abi: ERC20_ABI,
          functionName: "approve",
          args: [DARK_POOL_ADDRESS, amountInBN],
        });

        const txHash = await writeContractAsync({
          address: DARK_POOL_ADDRESS,
          abi: DARK_POOL_ABI,
          functionName: "commitOrder",
          args: [commitment, "0x0000000000000000000000000000000000000000000000000000000000000000"],
        });

        const orderId = orderHash;

        const order: Order = {
          id: orderId,
          commitment,
          nullifier,
          tokenIn: params.tokenIn as `0x${string}`,
          tokenOut: params.tokenOut as `0x${string}`,
          amountIn: amountInBN,
          minAmountOut: minAmountOutBN,
          isBuy: params.isBuy,
          deadline: params.deadline,
          merkleIndex: -1,
          status: "committed" as OrderStatus,
        };

        setOrders((prev) => new Map(prev).set(orderId, order));
        return { orderId, commitment, txHash };
      } finally {
        setIsSubmitting(false);
      }
    },
    [address, writeContractAsync]
  );

  return {
    orders,
    isSubmitting,
    isConfirming,
    submitCommitOrder,
    USDC_ADDRESS,
    WETH_ADDRESS,
  };
}
