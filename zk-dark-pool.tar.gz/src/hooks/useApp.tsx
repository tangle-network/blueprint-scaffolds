import React, { createContext, useContext, useReducer, useCallback } from "react"
import type { Order, BatchAuction, ZKProof, SolvencyProof, AnonymitySet } from "@/lib/types"
import { buildMerkleTree } from "@/lib/merkle"
import { generateSecret, generateNonce, computeOrderCommitment, generateNullifier } from "@/lib/crypto"
import { executeGuestCode, simulateProofGeneration } from "@/lib/zkGuest"
import { mockBonsaiProve } from "@/lib/bonsai"
import { DARK_POOL_CONFIG } from "@/lib/constants"

interface AppState {
  orders: Order[]
  auctions: BatchAuction[]
  proofs: ZKProof[]
  solvencyProofs: SolvencyProof[]
  anonymitySets: AnonymitySet[]
  currentAuction: BatchAuction | null
}

type Action =
  | { type: "ADD_ORDER"; payload: Order }
  | { type: "UPDATE_ORDER"; payload: { id: string; updates: Partial<Order> } }
  | { type: "CREATE_AUCTION"; payload: BatchAuction }
  | { type: "UPDATE_AUCTION"; payload: { id: string; updates: Partial<BatchAuction> } }
  | { type: "ADD_PROOF"; payload: ZKProof }
  | { type: "UPDATE_PROOF"; payload: { id: string; updates: Partial<ZKProof> } }
  | { type: "ADD_SOLVENCY_PROOF"; payload: SolvencyProof }
  | { type: "ADD_ANONYMITY_SET"; payload: AnonymitySet }
  | { type: "SET_CURRENT_AUCTION"; payload: BatchAuction | null }

const initialState: AppState = {
  orders: [],
  auctions: [],
  proofs: [],
  solvencyProofs: [],
  anonymitySets: [],
  currentAuction: null,
}

function appReducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case "ADD_ORDER":
      return { ...state, orders: [...state.orders, action.payload] }
    case "UPDATE_ORDER":
      return {
        ...state,
        orders: state.orders.map(o => o.id === action.payload.id ? { ...o, ...action.payload.updates } : o),
      }
    case "CREATE_AUCTION":
      return { ...state, auctions: [...state.auctions, action.payload], currentAuction: action.payload }
    case "UPDATE_AUCTION":
      return {
        ...state,
        auctions: state.auctions.map(a => a.id === action.payload.id ? { ...a, ...action.payload.updates } : a),
        currentAuction: state.currentAuction?.id === action.payload.id
          ? { ...state.currentAuction, ...action.payload.updates }
          : state.currentAuction,
      }
    case "ADD_PROOF":
      return { ...state, proofs: [...state.proofs, action.payload] }
    case "UPDATE_PROOF":
      return {
        ...state,
        proofs: state.proofs.map(p => p.id === action.payload.id ? { ...p, ...action.payload.updates } : p),
      }
    case "ADD_SOLVENCY_PROOF":
      return { ...state, solvencyProofs: [...state.solvencyProofs, action.payload] }
    case "ADD_ANONYMITY_SET":
      return { ...state, anonymitySets: [...state.anonymitySets, action.payload] }
    case "SET_CURRENT_AUCTION":
      return { ...state, currentAuction: action.payload }
    default:
      return state
  }
}

interface AppContextType {
  state: AppState
  submitOrder: (params: {
    side: "buy" | "sell"
    tokenIn: string
    tokenOut: string
    amount: string
    price: string
    trader: string
  }) => Promise<Order>
  revealOrder: (orderId: string) => Promise<void>
  runBatchAuction: () => Promise<void>
  generateSolvencyProof: () => Promise<void>
}

const AppContext = createContext<AppContextType | null>(null)

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState)

  const submitOrder = useCallback(async (params: {
    side: "buy" | "sell"
    tokenIn: string
    tokenOut: string
    amount: string
    price: string
    trader: string
  }) => {
    const secret = generateSecret()
    const nonce = generateNonce()
    const commitmentHash = await computeOrderCommitment(
      params.side, params.tokenIn, params.tokenOut, params.amount, params.price, nonce, secret
    )
    const nullifier = await generateNullifier(secret, nonce)

    const order: Order = {
      id: "0x" + Array.from({ length: 8 }, () => Math.floor(Math.random() * 16).toString(16)).join(""),
      trader: params.trader,
      side: params.side,
      tokenIn: params.tokenIn,
      tokenOut: params.tokenOut,
      amount: params.amount,
      price: params.price,
      nonce,
      commitmentHash,
      nullifier,
      status: "committed",
      createdAt: Date.now(),
      revealDeadline: Date.now() + DARK_POOL_CONFIG.revealWindowMs,
    }

    dispatch({ type: "ADD_ORDER", payload: order })

    if (state.anonymitySets.length === 0) {
      const tree = buildMerkleTree([order.commitmentHash])
      dispatch({
        type: "ADD_ANONYMITY_SET",
        payload: {
          id: "0x" + "01",
          merkleRoot: tree.root,
          members: [order.commitmentHash],
          size: 1,
          createdAt: Date.now(),
          active: true,
        },
      })
    }

    return order
  }, [state.anonymitySets.length])

  const revealOrder = useCallback(async (orderId: string) => {
    dispatch({ type: "UPDATE_ORDER", payload: { id: orderId, updates: { status: "revealed" } } })
  }, [])

  const runBatchAuction = useCallback(async () => {
    const revealedOrders = state.orders.filter(o => o.status === "revealed")
    if (revealedOrders.length === 0) return

    const auctionId = "0x" + Array.from({ length: 8 }, () => Math.floor(Math.random() * 16).toString(16)).join("")

    const auction: BatchAuction = {
      id: auctionId,
      orders: revealedOrders.map(o => o.id),
      clearingPrice: "0",
      totalVolume: "0",
      matchedPairs: [],
      proofHash: "",
      status: "matching",
      startedAt: Date.now(),
    }

    dispatch({ type: "CREATE_AUCTION", payload: auction })

    const solvencyData = {
      totalAssets: { ETH: "1000", USDC: "2000000" },
      totalLiabilities: { ETH: "800", USDC: "1500000" },
    }

    const anonymityRoot = state.anonymitySets.find(s => s.active)?.merkleRoot || "0x" + "00".repeat(32)

    const guestOutput = executeGuestCode({
      orders: revealedOrders,
      anonymitySetRoot: anonymityRoot,
      solvencyData,
    })

    dispatch({
      type: "UPDATE_AUCTION",
      payload: {
        id: auctionId,
        updates: {
          matchedPairs: guestOutput.matchedPairs,
          clearingPrice: guestOutput.clearingPrice,
          totalVolume: guestOutput.totalVolume,
          status: "proving",
        },
      },
    })

    const proofId = "0x" + Array.from({ length: 8 }, () => Math.floor(Math.random() * 16).toString(16)).join("")
    const proof: ZKProof = {
      id: proofId,
      journal: guestOutput.journal,
      seal: "",
      imageId: "0x" + "ab".repeat(32),
      status: "generating",
      auctionId,
      createdAt: Date.now(),
    }

    dispatch({ type: "ADD_PROOF", payload: proof })

    const bonsaiResult = await mockBonsaiProve(guestOutput.journal)

    dispatch({
      type: "UPDATE_PROOF",
      payload: {
        id: proofId,
        updates: {
          seal: bonsaiResult.seal,
          status: "submitted",
        },
      },
    })

    const simulatedSeal = simulateProofGeneration(guestOutput)

    dispatch({
      type: "UPDATE_PROOF",
      payload: {
        id: proofId,
        updates: {
          seal: simulatedSeal,
          status: "verified",
          verifiedAt: Date.now(),
        },
      },
    })

    dispatch({
      type: "UPDATE_AUCTION",
      payload: {
        id: auctionId,
        updates: {
          proofHash: simulatedSeal,
          status: "settled",
          settledAt: Date.now(),
        },
      },
    })

    for (const match of guestOutput.matchedPairs) {
      dispatch({ type: "UPDATE_ORDER", payload: { id: match.buyOrderId, updates: { status: "settled" } } })
      dispatch({ type: "UPDATE_ORDER", payload: { id: match.sellOrderId, updates: { status: "settled" } } })
    }
  }, [state.orders, state.anonymitySets])

  const generateSolvencyProof = useCallback(async () => {
    const solvencyData = {
      totalAssets: { ETH: "1000", USDC: "2000000", DAI: "500000" },
      totalLiabilities: { ETH: "800", USDC: "1500000", DAI: "400000" },
    }

    const tree = buildMerkleTree(Object.values(solvencyData.totalAssets))
    const journal = JSON.stringify({ solvencyData, merkleRoot: tree.root, timestamp: Date.now() })
    const bonsaiResult = await mockBonsaiProve(journal)

    const proof: ZKProof = {
      id: "0x" + Array.from({ length: 8 }, () => Math.floor(Math.random() * 16).toString(16)).join(""),
      journal,
      seal: bonsaiResult.seal,
      imageId: "0x" + "ab".repeat(32),
      status: "verified",
      auctionId: "",
      createdAt: Date.now(),
      verifiedAt: Date.now(),
    }

    const solvencyProof: SolvencyProof = {
      id: "0x" + Array.from({ length: 8 }, () => Math.floor(Math.random() * 16).toString(16)).join(""),
      totalAssets: solvencyData.totalAssets,
      totalLiabilities: solvencyData.totalLiabilities,
      merkleRoot: tree.root,
      proof,
      timestamp: Date.now(),
      verified: true,
    }

    dispatch({ type: "ADD_PROOF", payload: proof })
    dispatch({ type: "ADD_SOLVENCY_PROOF", payload: solvencyProof })
  }, [])

  return (
    <AppContext.Provider value={{ state, submitOrder, revealOrder, runBatchAuction, generateSolvencyProof }}>
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error("useApp must be used within AppProvider")
  return ctx
}
