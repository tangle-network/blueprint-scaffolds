export interface Order {
  id: string;
  trader: `0x${string}`;
  tokenIn: `0x${string}`;
  tokenOut: `0x${string}`;
  amountIn: bigint;
  minAmountOut: bigint;
  nonce: bigint;
  deadline: number;
  status: OrderStatus;
  commitment: `0x${string}`;
  proof?: `0x${string}`;
}

export enum OrderStatus {
  COMMITTED = 'committed',
  REVEALED = 'revealed',
  MATCHED = 'matched',
  PROVING = 'proving',
  SETTLED = 'settled',
  EXPIRED = 'expired',
  CANCELLED = 'cancelled',
}

export interface BatchAuction {
  id: string;
  orders: string[];
  clearingPrice: Record<string, bigint>;
  matches: MatchResult[];
  merkleRoot: `0x${string}`;
  proof?: `0x${string}`;
  status: BatchStatus;
  createdAt: number;
}

export enum BatchStatus {
  COLLECTING = 'collecting',
  MATCHING = 'matching',
  PROVING = 'proving',
  SETTLED = 'settled',
  FAILED = 'failed',
}

export interface MatchResult {
  buyOrderId: string;
  sellOrderId: string;
  fillAmount: bigint;
  price: bigint;
  buyTrader: `0x${string}`;
  sellTrader: `0x${string}`;
}

export interface SolvencyProof {
  trader: `0x${string}`;
  balanceRoot: `0x${string}`;
  balanceProof: `0x${string}`;
  timestamp: number;
}

export interface ProofStatus {
  orderId: string;
  batchId?: string;
  status: ProofPhase;
  journal?: string;
  seal?: `0x${string}`;
  submittedAt?: number;
  verifiedAt?: number;
  error?: string;
}

export enum ProofPhase {
  QUEUED = 'queued',
  GENERATING = 'generating',
  SUBMITTED = 'submitted',
  ONCHAIN_VERIFIED = 'onchain_verified',
  FAILED = 'failed',
}

export interface MerkleNode {
  hash: `0x${string}`;
  left?: MerkleNode;
  right?: MerkleNode;
  index: number;
}

export interface AnonymitySet {
  root: `0x${string}`;
  size: number;
  leaves: `0x${string}`[];
}
