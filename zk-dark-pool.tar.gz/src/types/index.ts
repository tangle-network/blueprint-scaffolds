export interface Order {
  id: string;
  commitment: `0x${string}`;
  nullifier: `0x${string}`;
  tokenIn: `0x${string}`;
  tokenOut: `0x${string}`;
  amountIn: bigint;
  minAmountOut: bigint;
  isBuy: boolean;
  deadline: number;
  merkleIndex: number;
  status: OrderStatus;
}

export enum OrderStatus {
  COMMITTED = "committed",
  REVEALED = "revealed",
  MATCHED = "matched",
  SETTLED = "settled",
  EXPIRED = "expired",
  CANCELLED = "cancelled",
}

export interface MatchProof {
  imageId: `0x${string}`;
  journal: `0x${string}`;
  seal: `0x${string}`;
  orderIds: [string, string];
  fillAmounts: [bigint, bigint];
}

export interface BatchAuction {
  auctionId: string;
  orderCommitments: `0x${string}`[];
  merkleRoot: `0x${string}`;
  settledAt: number;
  proof: MatchProof | null;
}

export interface SolvencyProof {
  imageId: `0x${string}`;
  journal: `0x${string}`;
  seal: `0x${string}`;
  poolBalance: bigint;
  totalObligations: bigint;
  timestamp: number;
}

export interface ProofStatus {
  orderId: string;
  status: "pending" | "proving" | "submitted" | "verified" | "failed";
  txHash?: `0x${string}`;
  seal?: `0x${string}`;
  timestamp: number;
}

export interface MerkleProof {
  leaf: `0x${string}`;
  index: number;
  siblings: `0x${string}`[];
  root: `0x${string}`;
}
