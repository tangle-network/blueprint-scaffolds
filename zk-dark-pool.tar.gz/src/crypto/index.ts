const encoder = new TextEncoder();

function concat(...buffers: Uint8Array[]): Uint8Array {
  const total = buffers.reduce((s, b) => s + b.length, 0);
  const result = new Uint8Array(total);
  let offset = 0;
  for (const b of buffers) {
    result.set(b, offset);
    offset += b.length;
  }
  return result;
}

export async function sha256(data: Uint8Array): Promise<Uint8Array> {
  const hash = await crypto.subtle.digest('SHA-256', data);
  return new Uint8Array(hash);
}

export function toHex(bytes: Uint8Array): `0x${string}` {
  return `0x${Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')}` as `0x${string}`;
}

export function fromHex(hex: string): Uint8Array {
  const clean = hex.startsWith('0x') ? hex.slice(2) : hex;
  const bytes = new Uint8Array(clean.length / 2);
  for (let i = 0; i < clean.length; i += 2) {
    bytes[i / 2] = parseInt(clean.substring(i, i + 2), 16);
  }
  return bytes;
}

export async function hashCommitment(
  trader: string,
  tokenIn: string,
  tokenOut: string,
  amountIn: bigint,
  minAmountOut: bigint,
  nonce: bigint,
  deadline: number,
  secret: bigint,
): Promise<`0x${string}`> {
  const data = concat(
    encoder.encode(trader),
    encoder.encode(tokenIn),
    encoder.encode(tokenOut),
    encoder.encode(amountIn.toString()),
    encoder.encode(minAmountOut.toString()),
    encoder.encode(nonce.toString()),
    encoder.encode(deadline.toString()),
    encoder.encode(secret.toString()),
  );
  return toHex(await sha256(data));
}

export function randomSecret(): bigint {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  let result = 0n;
  for (const b of bytes) result = (result << 8n) | BigInt(b);
  return result;
}

export function computeMerkleRoot(leaves: `0x${string}`[]): `0x${string}` {
  if (leaves.length === 0) return `0x${'0'.repeat(64)}` as `0x${string}`;
  let layer = [...leaves];
  while (layer.length > 1) {
    const next: `0x${string}`[] = [];
    for (let i = 0; i < layer.length; i += 2) {
      const left = layer[i];
      const right = layer[i + 1] ?? left;
      const combined = toHex(
        new Uint8Array([...fromHex(left), ...fromHex(right)]),
      );
      next.push(combined);
    }
    layer = next;
  }
  return layer[0];
}

export async function computeMerkleProof(
  leaves: `0x${string}`[],
  index: number,
): Promise<{ root: `0x${string}`; proof: `0x${string}`[] }> {
  const proof: `0x${string}`[] = [];
  let layer = [...leaves];
  let idx = index;

  while (layer.length > 1) {
    const next: `0x${string}`[] = [];
    for (let i = 0; i < layer.length; i += 2) {
      const left = layer[i];
      const right = layer[i + 1] ?? left;
      const combined = toHex(
        new Uint8Array([...fromHex(left), ...fromHex(right)]),
      );
      next.push(combined);
      if (i === idx || i + 1 === idx) {
        const sibling = idx % 2 === 0 ? right : left;
        proof.push(sibling);
      }
    }
    idx = Math.floor(idx / 2);
    layer = next;
  }

  return { root: layer[0], proof };
}

export function generateNullifier(orderId: string, secret: bigint): `0x${string}` {
  const data = concat(
    encoder.encode(orderId),
    encoder.encode(secret.toString()),
  );
  const hash = Array.from(new Uint8Array(new ArrayBuffer(32)));
  for (let i = 0; i < 32; i++) hash[i] = (data[i] ?? 0) ^ (i & 0xff);
  return toHex(new Uint8Array(hash));
}
