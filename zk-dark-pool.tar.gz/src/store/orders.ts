import { Order, OrderStatus, ProofStatus, ProofPhase } from '../types';
import { hashCommitment, randomSecret, toHex } from '../crypto';

const STORAGE_KEY = 'zk-darkpool-orders';

interface StoredOrder extends Order {
  secret?: string;
}

function loadOrders(): StoredOrder[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveOrders(orders: StoredOrder[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(orders));
}

export async function createOrder(params: {
  trader: `0x${string}`;
  tokenIn: `0x${string}`;
  tokenOut: `0x${string}`;
  amountIn: bigint;
  minAmountOut: bigint;
  deadline: number;
}): Promise<{ order: StoredOrder; secret: bigint }> {
  const secret = randomSecret();
  const nonce = BigInt(Date.now());
  const commitment = await hashCommitment(
    params.trader,
    params.tokenIn,
    params.tokenOut,
    params.amountIn,
    params.minAmountOut,
    nonce,
    params.deadline,
    secret,
  );

  const order: StoredOrder = {
    id: commitment.slice(0, 18),
    trader: params.trader,
    tokenIn: params.tokenIn,
    tokenOut: params.tokenOut,
    amountIn: params.amountIn,
    minAmountOut: params.minAmountOut,
    nonce,
    deadline: params.deadline,
    status: OrderStatus.COMMITTED,
    commitment,
    secret: secret.toString(),
  };

  const orders = loadOrders();
  orders.push(order);
  saveOrders(orders);

  return { order, secret };
}

export function getOrders(): StoredOrder[] {
  return loadOrders();
}

export function getOrderById(id: string): StoredOrder | undefined {
  return loadOrders().find((o) => o.id === id);
}

export function revealOrder(id: string): StoredOrder | null {
  const orders = loadOrders();
  const idx = orders.findIndex((o) => o.id === id);
  if (idx === -1) return null;
  if (orders[idx].status !== OrderStatus.COMMITTED) return null;
  orders[idx].status = OrderStatus.REVEALED;
  saveOrders(orders);
  return orders[idx];
}

export function updateOrderStatus(id: string, status: OrderStatus): void {
  const orders = loadOrders();
  const idx = orders.findIndex((o) => o.id === id);
  if (idx !== -1) {
    orders[idx].status = status;
    saveOrders(orders);
  }
}

export function cancelOrder(id: string): boolean {
  const orders = loadOrders();
  const idx = orders.findIndex((o) => o.id === id);
  if (idx === -1) return false;
  if (orders[idx].status !== OrderStatus.COMMITTED) return false;
  orders[idx].status = OrderStatus.CANCELLED;
  saveOrders(orders);
  return true;
}

export function getProofStatuses(): ProofStatus[] {
  return loadOrders().map((o) => ({
    orderId: o.id,
    status: mapOrderToProof(o.status),
    submittedAt:
      o.status === OrderStatus.PROVING ? Date.now() - 30000 : undefined,
    verifiedAt:
      o.status === OrderStatus.SETTLED ? Date.now() - 5000 : undefined,
  }));
}

function mapOrderToProof(status: OrderStatus): ProofPhase {
  switch (status) {
    case OrderStatus.COMMITTED:
    case OrderStatus.REVEALED:
      return ProofPhase.QUEUED;
    case OrderStatus.MATCHED:
      return ProofPhase.GENERATING;
    case OrderStatus.PROVING:
      return ProofPhase.SUBMITTED;
    case OrderStatus.SETTLED:
      return ProofPhase.ONCHAIN_VERIFIED;
    default:
      return ProofPhase.FAILED;
  }
}
