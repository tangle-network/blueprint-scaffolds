import { BatchAuction, BatchStatus, MatchResult, Order, OrderStatus } from '../types';
import { computeMerkleRoot, toHex } from '../crypto';

const BATCH_KEY = 'zk-darkpool-batches';

function loadBatches(): BatchAuction[] {
  try {
    return JSON.parse(localStorage.getItem(BATCH_KEY) || '[]');
  } catch {
    return [];
  }
}

function saveBatches(batches: BatchAuction[]) {
  localStorage.setItem(BATCH_KEY, JSON.stringify(batches));
}

export function createBatch(orderIds: string[]): BatchAuction {
  const commitments = orderIds.map(
    (id) => `0x${id.padEnd(66, '0').slice(0, 64)}` as `0x${string}`,
  );
  const merkleRoot = computeMerkleRoot(commitments);

  const batch: BatchAuction = {
    id: `batch-${Date.now()}`,
    orders: orderIds,
    clearingPrice: {},
    matches: [],
    merkleRoot,
    status: BatchStatus.COLLECTING,
    createdAt: Date.now(),
  };

  const batches = loadBatches();
  batches.push(batch);
  saveBatches(batches);
  return batch;
}

export function matchOrders(
  batchId: string,
  orders: Order[],
): { matches: MatchResult[]; clearingPrices: Record<string, bigint> } {
  const buys = orders.filter(
    (o) => o.status === OrderStatus.REVEALED && o.amountIn > 0n,
  );
  const sells = [...buys];

  const matches: MatchResult[] = [];
  const clearingPrices: Record<string, bigint> = {};

  for (const buy of buys) {
    for (const sell of sells) {
      if (
        buy.tokenIn === sell.tokenOut &&
        buy.tokenOut === sell.tokenIn &&
        buy.trader !== sell.trader
      ) {
        const midPrice = (buy.minAmountOut + sell.amountIn) / 2n;
        clearingPrices[`${buy.tokenIn}-${buy.tokenOut}`] = midPrice;

        matches.push({
          buyOrderId: buy.id,
          sellOrderId: sell.id,
          fillAmount: buy.amountIn < sell.amountIn ? buy.amountIn : sell.amountIn,
          price: midPrice,
          buyTrader: buy.trader,
          sellTrader: sell.trader,
        });
        break;
      }
    }
  }

  const batches = loadBatches();
  const idx = batches.findIndex((b) => b.id === batchId);
  if (idx !== -1) {
    batches[idx].matches = matches;
    batches[idx].clearingPrice = clearingPrices;
    batches[idx].status = BatchStatus.MATCHING;
    saveBatches(batches);
  }

  return { matches, clearingPrices };
}

export function getBatches(): BatchAuction[] {
  return loadBatches();
}

export function getBatchById(id: string): BatchAuction | undefined {
  return loadBatches().find((b) => b.id === id);
}
