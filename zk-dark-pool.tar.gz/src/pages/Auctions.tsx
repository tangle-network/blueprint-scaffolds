import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { Button } from "@/components/ui/button"
import { DEFAULT_AUCTIONS, DEFAULT_ORDERS, DEFAULT_PROOFS } from "@/lib/types"
import { AUCTION_STATES, ORDER_STATES } from "@/lib/constants"
import {
  Clock,
  Zap,
  FileCheck,
  CheckCircle2,
  XCircle,
  Timer,
  Layers,
} from "lucide-react"
import { useState } from "react"

function timeAgo(ts: number) {
  const diff = Date.now() - ts
  if (diff < 60000) return `${Math.floor(diff / 1000)}s ago`
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`
  return `${Math.floor(diff / 3600000)}h ago`
}

function formatDuration(ms: number) {
  const s = Math.floor(ms / 1000)
  if (s < 60) return `${s}s`
  const m = Math.floor(s / 60)
  return `${m}m ${s % 60}s`
}

function StatusIcon({ status }: { status: string }) {
  switch (status) {
    case "collecting":
      return <Clock className="h-4 w-4 text-yellow-400" />
    case "matching":
      return <Zap className="h-4 w-4 text-blue-400" />
    case "proving":
      return <FileCheck className="h-4 w-4 text-purple-400" />
    case "settled":
      return <CheckCircle2 className="h-4 w-4 text-green-400" />
    case "failed":
      return <XCircle className="h-4 w-4 text-red-400" />
    default:
      return null
  }
}

function AuctionDetail({ auction }: { auction: typeof DEFAULT_AUCTIONS[0] }) {
  const proof = DEFAULT_PROOFS.find(p => p.auctionId === auction.id)
  const orders = DEFAULT_ORDERS.filter(o => auction.orders.includes(o.id))
  const progressMap: Record<string, number> = {
    collecting: 15,
    matching: 40,
    proving: 70,
    settled: 100,
    failed: 100,
  }
  const stateInfo = AUCTION_STATES[auction.status]
  const duration = auction.settledAt
    ? auction.settledAt - auction.startedAt
    : Date.now() - auction.startedAt

  return (
    <Card className="glass-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <StatusIcon status={auction.status} />
            <div>
              <CardTitle className="text-lg font-mono">{auction.id}</CardTitle>
              <CardDescription>Started {timeAgo(auction.startedAt)}</CardDescription>
            </div>
          </div>
          <Badge variant="secondary" className={stateInfo.color}>
            {stateInfo.label}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <div className="flex items-center justify-between text-sm mb-2">
            <span className="text-muted-foreground">Auction Progress</span>
            <span className="font-mono">{progressMap[auction.status]}%</span>
          </div>
          <Progress value={progressMap[auction.status]} className="h-2" />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Total Volume</p>
            <p className="text-sm font-mono font-medium">{auction.totalVolume || "—"} ETH</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Clearing Price</p>
            <p className="text-sm font-mono font-medium">
              {auction.clearingPrice && auction.clearingPrice !== "0" ? `$${auction.clearingPrice}` : "Pending"}
            </p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Matched Pairs</p>
            <p className="text-sm font-mono font-medium">{auction.matchedPairs.length}</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Duration</p>
            <p className="text-sm font-mono font-medium">{formatDuration(duration)}</p>
          </div>
        </div>

        <Separator />

        <div className="space-y-2">
          <h4 className="text-sm font-medium flex items-center gap-2">
            <Layers className="h-4 w-4" /> Orders in Batch ({orders.length})
          </h4>
          {orders.length > 0 ? (
            <div className="space-y-1">
              {orders.map(order => (
                <div key={order.id} className="flex items-center justify-between text-xs py-1.5 px-2 rounded bg-muted/30">
                  <div className="flex items-center gap-2">
                    <span className={`font-mono ${order.side === "buy" ? "text-green-400" : "text-red-400"}`}>
                      {order.side.toUpperCase()}
                    </span>
                    <span className="font-mono">{order.amount} @ ${order.price}</span>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {ORDER_STATES[order.status]?.label ?? order.status}
                  </Badge>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-muted-foreground">No orders in this batch</p>
          )}
        </div>

        {auction.matchedPairs.length > 0 && (
          <>
            <Separator />
            <div className="space-y-2">
              <h4 className="text-sm font-medium flex items-center gap-2">
                <Zap className="h-4 w-4" /> Match Results
              </h4>
              <div className="space-y-1">
                {auction.matchedPairs.map((match, i) => (
                  <div key={i} className="flex items-center justify-between text-xs py-1.5 px-2 rounded bg-muted/30">
                    <span className="font-mono">{match.amount} ETH @ ${match.price}</span>
                    <span className="text-muted-foreground">
                      Buy: {match.buyOrderId.slice(0, 8)} ↔ Sell: {match.sellOrderId.slice(0, 8)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {proof && (
          <>
            <Separator />
            <div className="space-y-2">
              <h4 className="text-sm font-medium flex items-center gap-2">
                <FileCheck className="h-4 w-4" /> ZK Proof
              </h4>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-muted-foreground">Proof ID:</span>{" "}
                  <span className="font-mono">{proof.id.slice(0, 14)}...</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Status:</span>{" "}
                  <Badge variant="secondary" className="text-xs">{proof.status}</Badge>
                </div>
                <div>
                  <span className="text-muted-foreground">Seal:</span>{" "}
                  <span className="font-mono">{proof.seal.slice(0, 14)}...</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Verified:</span>{" "}
                  {proof.verifiedAt ? new Date(proof.verifiedAt).toLocaleTimeString() : "Pending"}
                </div>
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}

export default function Auctions() {
  const settled = DEFAULT_AUCTIONS.filter(a => a.status === "settled")
  const active = DEFAULT_AUCTIONS.filter(a => a.status !== "settled" && a.status !== "failed")
  const totalSettledVolume = settled.reduce((s, a) => s + Number(a.totalVolume || 0), 0)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Batch Auctions</h1>
        <p className="text-muted-foreground mt-1">
          Zero-knowledge batch auction rounds with verifiable settlement
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Active Auctions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{active.length}</div>
            <p className="text-xs text-muted-foreground">Currently collecting or processing</p>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Settled Auctions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400">{settled.length}</div>
            <p className="text-xs text-muted-foreground">Successfully completed</p>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Settled Volume</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalSettledVolume.toFixed(1)} ETH</div>
            <p className="text-xs text-muted-foreground">Across {settled.length} settled batches</p>
          </CardContent>
        </Card>
      </div>

      {active.length > 0 && (
        <div>
          <h2 className="text-xl font-semibold mb-3 flex items-center gap-2">
            <Timer className="h-5 w-5 text-yellow-400" /> Active Auctions
          </h2>
          <div className="space-y-4">
            {active.map(a => <AuctionDetail key={a.id} auction={a} />)}
          </div>
        </div>
      )}

      <div>
        <h2 className="text-xl font-semibold mb-3 flex items-center gap-2">
          <CheckCircle2 className="h-5 w-5 text-green-400" /> Settled Auctions
        </h2>
        <div className="space-y-4">
          {settled.length > 0 ? (
            settled.map(a => <AuctionDetail key={a.id} auction={a} />)
          ) : (
            <Card className="glass-card">
              <CardContent className="py-12 text-center text-muted-foreground">
                No settled auctions yet.
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
