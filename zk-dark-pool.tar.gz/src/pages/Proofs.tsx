import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { DEFAULT_PROOFS, DEFAULT_SOLVENCY_PROOFS, DEFAULT_ANONYMITY_SETS } from "@/lib/types"
import {
  Shield,
  FileCheck,
  CheckCircle2,
  AlertTriangle,
  Loader2,
  TreePine,
  Lock,
} from "lucide-react"
import { useState } from "react"

function timeAgo(ts: number) {
  const diff = Date.now() - ts
  if (diff < 60000) return `${Math.floor(diff / 1000)}s ago`
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`
  return `${Math.floor(diff / 3600000)}h ago`
}

function ProofStatusIcon({ status }: { status: string }) {
  switch (status) {
    case "generating":
      return <Loader2 className="h-4 w-4 text-yellow-400 animate-spin" />
    case "submitted":
      return <FileCheck className="h-4 w-4 text-blue-400" />
    case "verified":
      return <CheckCircle2 className="h-4 w-4 text-green-400" />
    case "failed":
      return <AlertTriangle className="h-4 w-4 text-red-400" />
    default:
      return null
  }
}

function statusColor(status: string) {
  switch (status) {
    case "generating": return "text-yellow-400"
    case "submitted": return "text-blue-400"
    case "verified": return "text-green-400"
    case "failed": return "text-red-400"
    default: return ""
  }
}

function ProofCard({ proof }: { proof: typeof DEFAULT_PROOFS[0] }) {
  let journalData: Record<string, unknown> = {}
  try {
    journalData = JSON.parse(proof.journal)
  } catch {
    journalData = { raw: proof.journal }
  }

  return (
    <Card className="glass-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <ProofStatusIcon status={proof.status} />
            <div>
              <CardTitle className="text-lg font-mono">{proof.id}</CardTitle>
              <CardDescription>Created {timeAgo(proof.createdAt)}</CardDescription>
            </div>
          </div>
          <Badge variant="secondary" className={statusColor(proof.status)}>
            {proof.status.toUpperCase()}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Auction</p>
            <p className="text-sm font-mono">{proof.auctionId || "N/A"}</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Image ID</p>
            <p className="text-sm font-mono truncate">{proof.imageId.slice(0, 18)}...</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Seal</p>
            <p className="text-sm font-mono truncate">{proof.seal || "Pending"}</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Verified At</p>
            <p className="text-sm font-mono">
              {proof.verifiedAt ? new Date(proof.verifiedAt).toLocaleTimeString() : "Pending"}
            </p>
          </div>
        </div>

        <Separator />

        <div className="space-y-2">
          <h4 className="text-sm font-medium">Journal Data</h4>
          <pre className="text-xs bg-muted/50 p-3 rounded-md overflow-x-auto font-mono">
            {JSON.stringify(journalData, null, 2)}
          </pre>
        </div>

        {proof.status === "generating" && (
          <div>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-muted-foreground">Proof Generation</span>
              <span className="text-yellow-400">In progress...</span>
            </div>
            <Progress value={45} className="h-2" />
          </div>
        )}
      </CardContent>
    </Card>
  )
}

function SolvencyCard({ proof }: { proof: typeof DEFAULT_SOLVENCY_PROOFS[0] }) {
  const assetEntries = Object.entries(proof.totalAssets)
  const liabilityEntries = Object.entries(proof.totalLiabilities)

  return (
    <Card className="glass-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {proof.verified ? (
              <CheckCircle2 className="h-5 w-5 text-green-400" />
            ) : (
              <AlertTriangle className="h-5 w-5 text-yellow-400" />
            )}
            <div>
              <CardTitle className="text-lg">Solvency Proof</CardTitle>
              <CardDescription>ID: {proof.id} &middot; {timeAgo(proof.timestamp)}</CardDescription>
            </div>
          </div>
          <Badge variant="secondary" className={proof.verified ? "text-green-400" : "text-yellow-400"}>
            {proof.verified ? "VERIFIED" : "PENDING"}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-green-400">Total Assets</h4>
            {assetEntries.map(([token, amount]) => (
              <div key={token} className="flex justify-between text-sm py-1 px-2 rounded bg-green-500/5">
                <span>{token}</span>
                <span className="font-mono">{amount}</span>
              </div>
            ))}
          </div>
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-red-400">Total Liabilities</h4>
            {liabilityEntries.map(([token, amount]) => (
              <div key={token} className="flex justify-between text-sm py-1 px-2 rounded bg-red-500/5">
                <span>{token}</span>
                <span className="font-mono">{amount}</span>
              </div>
            ))}
          </div>
        </div>

        <Separator />

        <div className="grid grid-cols-2 gap-4 text-xs">
          <div>
            <span className="text-muted-foreground">Merkle Root:</span>
            <p className="font-mono truncate mt-0.5">{proof.merkleRoot}</p>
          </div>
          <div>
            <span className="text-muted-foreground">Proof Seal:</span>
            <p className="font-mono truncate mt-0.5">{proof.proof.seal}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default function Proofs() {
  const verifiedCount = DEFAULT_PROOFS.filter(p => p.status === "verified").length
  const totalProofs = DEFAULT_PROOFS.length
  const activeSets = DEFAULT_ANONYMITY_SETS.filter(s => s.active)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">ZK Proofs & Privacy</h1>
        <p className="text-muted-foreground mt-1">
          Verification proofs, solvency attestations, and anonymity set management
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Proofs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalProofs}</div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Verified</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400">{verifiedCount}</div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Solvency Proofs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{DEFAULT_SOLVENCY_PROOFS.length}</div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Anonymity Sets</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeSets.length}</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="proofs" className="space-y-4">
        <TabsList>
          <TabsTrigger value="proofs">Auction Proofs</TabsTrigger>
          <TabsTrigger value="solvency">Solvency</TabsTrigger>
          <TabsTrigger value="anonymity">Anonymity Sets</TabsTrigger>
        </TabsList>

        <TabsContent value="proofs">
          <div className="space-y-4">
            {DEFAULT_PROOFS.map(proof => (
              <ProofCard key={proof.id} proof={proof} />
            ))}
            {DEFAULT_PROOFS.length === 0 && (
              <Card className="glass-card">
                <CardContent className="py-12 text-center text-muted-foreground">
                  No auction proofs generated yet.
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="solvency">
          <div className="space-y-4">
            {DEFAULT_SOLVENCY_PROOFS.map(proof => (
              <SolvencyCard key={proof.id} proof={proof} />
            ))}
            {DEFAULT_SOLVENCY_PROOFS.length === 0 && (
              <Card className="glass-card">
                <CardContent className="py-12 text-center text-muted-foreground">
                  No solvency proofs generated yet.
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="anonymity">
          <div className="space-y-4">
            {DEFAULT_ANONYMITY_SETS.map(set => (
              <Card key={set.id} className="glass-card">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <TreePine className="h-5 w-5 text-primary" />
                      <div>
                        <CardTitle className="text-lg font-mono">{set.id}</CardTitle>
                        <CardDescription>Created {timeAgo(set.createdAt)}</CardDescription>
                      </div>
                    </div>
                    <Badge variant={set.active ? "default" : "secondary"}>
                      {set.active ? "ACTIVE" : "INACTIVE"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground">Set Size</p>
                      <p className="text-lg font-mono font-bold">{set.size}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground">Members</p>
                      <p className="text-lg font-mono font-bold">{set.members.length}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <Lock className="h-3 w-3" /> Merkle Root
                      </p>
                      <p className="text-xs font-mono truncate">{set.merkleRoot}</p>
                    </div>
                  </div>
                  <Separator />
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">Commitment Members</h4>
                    <div className="space-y-1 max-h-40 overflow-y-auto">
                      {set.members.map((member, i) => (
                        <div key={i} className="flex items-center gap-2 text-xs py-1 px-2 rounded bg-muted/30">
                          <span className="text-muted-foreground w-6">{i + 1}.</span>
                          <span className="font-mono truncate">{member}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
