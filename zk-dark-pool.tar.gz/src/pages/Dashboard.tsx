import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { Button } from "@/components/ui/button"
import { DEFAULT_ORDERS, DEFAULT_AUCTIONS, DEFAULT_PROOFS, DEFAULT_ANONYMITY_SETS } from "@/lib/types"
import { TOKENS, ORDER_STATES, AUCTION_STATES } from "@/lib/constants"
import { Link } from "react-router-dom"
import {
  BarChart3,
  Shield,
  Lock,
  Activity,
  TrendingUp,
  Eye,
  EyeOff,
} from "lucide-react"

function formatAddress(addr: string) {
  return `${addr.slice(0, 6)}...${addr.slice(-4)}`
}

function formatTime(ts: number) {
  return new Date(ts).toLocaleTimeString()
}

function getTokenSymbol(address: string) {
  return TOKENS[address]?.symbol ?? address.slice(0, 8)
}

export default function Dashboard() {
  const totalVolume = DEFAULT_AUCTIONS.reduce((sum, a) => sum + Number(a.totalVolume || 0), 0)
  const settledAuctions = DEFAULT_AUCTIONS.filter(a => a.status === "settled").length
  const verifiedProofs = DEFAULT_PROOFS.filter(p => p.status === "verified").length
  const activeAnonymitySet = DEFAULT_ANONYMITY_SETS.find(s => s.active)
  const pendingOrders = DEFAULT_ORDERS.filter(o => o.status === "committed" || o.status === "pending").length
  const recentOrders = DEFAULT_ORDERS.slice(0, 4)
  const recentAuctions = DEFAULT_AUCTIONS.slice(0, 3)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground mt-1">
          Zero-knowledge dark pool overview &mdash; private order matching powered by RISC Zero
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="glass-card glow-purple">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Volume</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalVolume.toFixed(1)} ETH</div>
            <p className="text-xs text-muted-foreground">Across {DEFAULT_AUCTIONS.length} batch auctions</p>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Orders</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pendingOrders}</div>
            <p className="text-xs text-muted-foreground">{DEFAULT_ORDERS.length} total orders submitted</p>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Verified Proofs</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{verifiedProofs}/{DEFAULT_PROOFS.length}</div>
            <p className="text-xs text-muted-foreground">ZK proofs verified on-chain</p>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Anonymity Set</CardTitle>
            <Lock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeAnonymitySet?.size ?? 0}</div>
            <p className="text-xs text-muted-foreground">Active members in merkle set</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="glass-card">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg">Recent Orders</CardTitle>
                <CardDescription>Latest order commitments in the dark pool</CardDescription>
              </div>
              <Link to="/orders">
                <Button variant="outline" size="sm">View All</Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentOrders.map((order) => {
                const stateInfo = ORDER_STATES[order.status]
                return (
                  <div key={order.id} className="flex items-center justify-between rounded-md border p-3">
                    <div className="flex items-center gap-3">
                      {order.side === "buy" ? (
                        <TrendingUp className="h-4 w-4 text-green-400" />
                      ) : (
                        <TrendingUp className="h-4 w-4 text-red-400 rotate-180" />
                      )}
                      <div>
                        <div className="text-sm font-medium">
                          {order.side.toUpperCase()} {order.amount} {getTokenSymbol(order.tokenIn)}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {formatAddress(order.trader)} &middot; {formatTime(order.createdAt)}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-mono">${order.price}</span>
                      <Badge variant="secondary" className={stateInfo.color}>
                        {stateInfo.label}
                      </Badge>
                    </div>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg">Batch Auctions</CardTitle>
                <CardDescription>Current and recent auction rounds</CardDescription>
              </div>
              <Link to="/auctions">
                <Button variant="outline" size="sm">View All</Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentAuctions.map((auction) => {
                const stateInfo = AUCTION_STATES[auction.status]
                const progressMap: Record<string, number> = {
                  collecting: 15,
                  matching: 40,
                  proving: 70,
                  settled: 100,
                  failed: 100,
                }
                return (
                  <div key={auction.id} className="rounded-md border p-3 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-mono">{auction.id}</span>
                        <Badge variant="secondary" className={stateInfo.color}>
                          {stateInfo.label}
                        </Badge>
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {auction.orders.length} orders
                      </span>
                    </div>
                    <Progress value={progressMap[auction.status]} className="h-2" />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Vol: {auction.totalVolume || "0"} ETH</span>
                      <span>Clearing: ${auction.clearingPrice || "pending"}</span>
                    </div>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-lg">Privacy Architecture</CardTitle>
          <CardDescription>How your trades remain hidden from adversaries</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="flex items-start gap-3 p-4 rounded-md border">
              <EyeOff className="h-5 w-5 text-primary mt-0.5" />
              <div>
                <h4 className="text-sm font-medium">Commit Phase</h4>
                <p className="text-xs text-muted-foreground mt-1">
                  Orders are submitted as hashed commitments. Trade details remain encrypted until the reveal phase.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-4 rounded-md border">
              <Shield className="h-5 w-5 text-primary mt-0.5" />
              <div>
                <h4 className="text-sm font-medium">ZK Matching</h4>
                <p className="text-xs text-muted-foreground mt-1">
                  RISC Zero guest code matches orders inside a zkVM, producing a verifiable proof without exposing order data.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-4 rounded-md border">
              <Eye className="h-5 w-5 text-primary mt-0.5" />
              <div>
                <h4 className="text-sm font-medium">Settlement</h4>
                <p className="text-xs text-muted-foreground mt-1">
                  Only matched results and a validity proof are published on-chain. Individual trader details stay private.
                </p>
              </div>
            </div>
          </div>
          <Separator className="my-4" />
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Merkle Tree Depth: 32 levels</span>
            <span>Min Anonymity Set: 64 members</span>
            <span>Batch Interval: 30s</span>
            <span>Reveal Window: 60s</span>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
