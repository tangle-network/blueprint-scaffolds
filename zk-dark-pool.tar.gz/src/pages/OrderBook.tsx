import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from "@/components/ui/select"
import { DEFAULT_ORDERS } from "@/lib/types"
import { TOKENS, ORDER_STATES, SUPPORTED_PAIRS } from "@/lib/constants"
import {
  ArrowUpRight,
  ArrowDownRight,
  Plus,
  Search,
} from "lucide-react"
import { useState } from "react"

function formatAddress(addr: string) {
  return `${addr.slice(0, 6)}...${addr.slice(-4)}`
}

function getTokenSymbol(address: string) {
  return TOKENS[address]?.symbol ?? address.slice(0, 8)
}

function timeAgo(ts: number) {
  const diff = Date.now() - ts
  if (diff < 60000) return `${Math.floor(diff / 1000)}s ago`
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`
  return `${Math.floor(diff / 86400000)}d ago`
}

export default function OrderBook() {
  const [search, setSearch] = useState("")
  const [filterSide, setFilterSide] = useState<"all" | "buy" | "sell">("all")

  const filtered = DEFAULT_ORDERS.filter(o => {
    if (filterSide !== "all" && o.side !== filterSide) return false
    if (search) {
      const s = search.toLowerCase()
      return (
        o.id.toLowerCase().includes(s) ||
        o.trader.toLowerCase().includes(s) ||
        getTokenSymbol(o.tokenIn).toLowerCase().includes(s) ||
        getTokenSymbol(o.tokenOut).toLowerCase().includes(s)
      )
    }
    return true
  })

  const buys = DEFAULT_ORDERS.filter(o => o.side === "buy")
  const sells = DEFAULT_ORDERS.filter(o => o.side === "sell")
  const bestBid = buys.length ? Math.max(...buys.map(o => Number(o.price))) : 0
  const bestAsk = sells.length ? Math.min(...sells.map(o => Number(o.price))) : 0
  const spread = bestBid && bestAsk ? (bestAsk - bestBid).toFixed(2) : "—"

  const statusCounts = DEFAULT_ORDERS.reduce<Record<string, number>>((acc, o) => {
    acc[o.status] = (acc[o.status] || 0) + 1
    return acc
  }, {})

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Order Book</h1>
          <p className="text-muted-foreground mt-1">
            Manage and monitor encrypted order commitments
          </p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{DEFAULT_ORDERS.length}</div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Best Bid</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400">${bestBid || "—"}</div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Best Ask</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-400">${bestAsk || "—"}</div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Spread</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${spread}</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all" onClick={() => setFilterSide("all")}>All Orders</TabsTrigger>
          <TabsTrigger value="buy" onClick={() => setFilterSide("buy")}>Bids</TabsTrigger>
          <TabsTrigger value="sell" onClick={() => setFilterSide("sell")}>Asks</TabsTrigger>
        </TabsList>

        <div className="flex items-center gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by ID, trader, token..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            {Object.entries(statusCounts).map(([status, count]) => {
              const info = ORDER_STATES[status as keyof typeof ORDER_STATES]
              return (
                <Badge key={status} variant="outline" className={info?.color}>
                  {info?.label}: {count}
                </Badge>
              )
            })}
          </div>
        </div>

        <TabsContent value="all">
          <OrderTable orders={filtered} />
        </TabsContent>
        <TabsContent value="buy">
          <OrderTable orders={filtered} />
        </TabsContent>
        <TabsContent value="sell">
          <OrderTable orders={filtered} />
        </TabsContent>
      </Tabs>
    </div>
  )
}

function OrderTable({ orders }: { orders: typeof DEFAULT_ORDERS }) {
  if (orders.length === 0) {
    return (
      <Card className="glass-card">
        <CardContent className="py-12 text-center text-muted-foreground">
          No orders match your filters.
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="glass-card">
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-left text-muted-foreground">
                <th className="px-4 py-3 font-medium">Side</th>
                <th className="px-4 py-3 font-medium">Pair</th>
                <th className="px-4 py-3 font-medium">Amount</th>
                <th className="px-4 py-3 font-medium">Price</th>
                <th className="px-4 py-3 font-medium">Trader</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium">Time</th>
                <th className="px-4 py-3 font-medium">Commitment</th>
              </tr>
            </thead>
            <tbody>
              {orders.map(order => {
                const stateInfo = ORDER_STATES[order.status]
                return (
                  <tr key={order.id} className="border-b last:border-0 hover:bg-muted/50 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        {order.side === "buy" ? (
                          <ArrowUpRight className="h-4 w-4 text-green-400" />
                        ) : (
                          <ArrowDownRight className="h-4 w-4 text-red-400" />
                        )}
                        <span className={order.side === "buy" ? "text-green-400" : "text-red-400"}>
                          {order.side.toUpperCase()}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3 font-mono text-xs">
                      {getTokenSymbol(order.tokenIn)}/{getTokenSymbol(order.tokenOut)}
                    </td>
                    <td className="px-4 py-3 font-mono">{order.amount}</td>
                    <td className="px-4 py-3 font-mono">${order.price}</td>
                    <td className="px-4 py-3 font-mono text-xs">{formatAddress(order.trader)}</td>
                    <td className="px-4 py-3">
                      <Badge variant="secondary" className={stateInfo.color}>
                        {stateInfo.label}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">{timeAgo(order.createdAt)}</td>
                    <td className="px-4 py-3 font-mono text-xs text-muted-foreground">
                      {order.commitmentHash.slice(0, 10)}...
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  )
}
