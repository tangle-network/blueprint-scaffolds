import { useState } from "react";
import { useProofManager } from "@/hooks/useProofManager";

export function SolvencyPanel() {
  const { generateSolvencyProof, isProving } = useProofManager();
  const [lastProof, setLastProof] = useState<{
    poolBalance: bigint;
    totalObligations: bigint;
    timestamp: number;
  } | null>(null);

  const handleGenerate = async () => {
    const proof = await generateSolvencyProof();
    setLastProof({
      poolBalance: proof.poolBalance,
      totalObligations: proof.totalObligations,
      timestamp: proof.timestamp,
    });
  };

  return (
    <div className="bg-dark-700 rounded-xl p-6 border border-gray-800">
      <h2 className="text-xl font-semibold mb-4 text-white">Solvency Proof</h2>

      <button
        onClick={handleGenerate}
        disabled={isProving}
        className="w-full bg-green-700 hover:bg-green-600 disabled:bg-gray-700 disabled:text-gray-500 text-white font-medium py-3 rounded-lg transition mb-4"
      >
        {isProving ? "Generating..." : "Generate Solvency Proof"}
      </button>

      {lastProof && (
        <div className="bg-dark-800 rounded-lg p-4 space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-400">Pool Balance</span>
            <span className="text-white font-mono">
              {(Number(lastProof.poolBalance) / 1e18).toFixed(2)} ETH
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Total Obligations</span>
            <span className="text-white font-mono">
              {(Number(lastProof.totalObligations) / 1e18).toFixed(2)} ETH
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Status</span>
            <span className="text-green-400 font-medium">SOLVENT</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Proven At</span>
            <span className="text-gray-300">
              {new Date(lastProof.timestamp).toLocaleTimeString()}
            </span>
          </div>
        </div>
      )}
    </div>
  );
}
