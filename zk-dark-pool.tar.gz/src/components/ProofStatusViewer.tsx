import { useProofManager } from "@/hooks/useProofManager";

export function ProofStatusViewer() {
  const { proofStatuses, isProving } = useProofManager();

  const statusColors: Record<string, string> = {
    pending: "text-yellow-400",
    proving: "text-blue-400",
    submitted: "text-purple-400",
    verified: "text-green-400",
    failed: "text-red-400",
  };

  const statusIcons: Record<string, string> = {
    pending: "⏳",
    proving: "🔐",
    submitted: "📤",
    verified: "✅",
    failed: "❌",
  };

  const entries = Array.from(proofStatuses.entries());

  return (
    <div className="bg-dark-700 rounded-xl p-6 border border-gray-800">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-white">Proof Status</h2>
        {isProving && (
          <span className="flex items-center gap-2 text-blue-400 text-sm">
            <span className="animate-spin">⟳</span> Generating ZK Proof...
          </span>
        )}
      </div>

      {entries.length === 0 ? (
        <p className="text-gray-500 text-center py-8">
          No proofs generated yet. Submit an order to start.
        </p>
      ) : (
        <div className="space-y-3">
          {entries.map(([orderId, proof]) => (
            <div
              key={orderId}
              className="bg-dark-800 rounded-lg p-4 border border-gray-700"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-400 font-mono truncate max-w-[200px]">
                  {orderId.slice(0, 16)}...
                </span>
                <span className={`text-sm font-medium ${statusColors[proof.status]}`}>
                  {statusIcons[proof.status]} {proof.status.toUpperCase()}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs text-gray-500">
                <div>
                  <span className="text-gray-600">Timestamp:</span>{" "}
                  {new Date(proof.timestamp).toLocaleTimeString()}
                </div>
                {proof.txHash && (
                  <div>
                    <span className="text-gray-600">Tx:</span>{" "}
                    <span className="font-mono">{proof.txHash.slice(0, 12)}...</span>
                  </div>
                )}
                {proof.seal && (
                  <div className="col-span-2">
                    <span className="text-gray-600">Seal:</span>{" "}
                    <span className="font-mono">{proof.seal.slice(0, 20)}...</span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
