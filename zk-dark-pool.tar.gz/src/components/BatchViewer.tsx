import { useState } from "react";

interface BatchEntry {
  id: string;
  orderCount: number;
  merkleRoot: string;
  status: string;
  timestamp: number;
}

export function BatchViewer() {
  const [batches] = useState<BatchEntry[]>([
    {
      id: "0xabc123",
      orderCount: 12,
      merkleRoot: "0xdef456...",
      status: "settled",
      timestamp: Date.now() - 60000,
    },
  ]);

  return (
    <div className="bg-dark-700 rounded-xl p-6 border border-gray-800">
      <h2 className="text-xl font-semibold mb-4 text-white">Batch Auctions</h2>

      {batches.length === 0 ? (
        <p className="text-gray-500 text-center py-8">
          No batches settled yet.
        </p>
      ) : (
        <div className="space-y-3">
          {batches.map((batch) => (
            <div
              key={batch.id}
              className="bg-dark-800 rounded-lg p-4 border border-gray-700"
            >
              <div className="flex justify-between items-center mb-2">
                <span className="font-mono text-sm text-gray-300">
                  {batch.id.slice(0, 14)}...
                </span>
                <span className="text-xs bg-green-900 text-green-400 px-2 py-1 rounded">
                  {batch.status.toUpperCase()}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2 text-xs text-gray-500">
                <div>
                  <span className="text-gray-600">Orders:</span> {batch.orderCount}
                </div>
                <div>
                  <span className="text-gray-600">Root:</span>{" "}
                  <span className="font-mono">{batch.merkleRoot.slice(0, 10)}</span>
                </div>
                <div>
                  <span className="text-gray-600">Time:</span>{" "}
                  {new Date(batch.timestamp).toLocaleTimeString()}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
