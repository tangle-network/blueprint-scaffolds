import { useState, type FormEvent } from "react";
import { useAccount } from "wagmi";
import { useOrderManager } from "@/hooks/useOrderManager";

export function OrderForm() {
  const { isConnected } = useAccount();
  const { submitCommitOrder, isSubmitting, USDC_ADDRESS, WETH_ADDRESS } = useOrderManager();
  const [isBuy, setIsBuy] = useState(true);
  const [amountIn, setAmountIn] = useState("");
  const [minAmountOut, setMinAmountOut] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const tokenIn = isBuy ? USDC_ADDRESS : WETH_ADDRESS;
  const tokenOut = isBuy ? WETH_ADDRESS : USDC_ADDRESS;
  const inSymbol = isBuy ? "USDC" : "WETH";
  const outSymbol = isBuy ? "WETH" : "USDC";

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!amountIn || !minAmountOut) return;
    setSubmitted(false);
    try {
      await submitCommitOrder({
        tokenIn,
        tokenOut,
        amountIn,
        minAmountOut,
        isBuy,
        deadline: Math.floor(Date.now() / 1000) + 3600,
      });
      setSubmitted(true);
      setAmountIn("");
      setMinAmountOut("");
    } catch (err) {
      console.error("Order submission failed:", err);
    }
  };

  if (!isConnected) {
    return (
      <div className="bg-dark-700 rounded-xl p-6 border border-gray-800 text-center">
        <p className="text-gray-400">Connect your wallet to submit orders</p>
      </div>
    );
  }

  return (
    <div className="bg-dark-700 rounded-xl p-6 border border-gray-800">
      <h2 className="text-xl font-semibold mb-4 text-white">Submit Order</h2>

      <div className="flex gap-2 mb-4">
        <button
          onClick={() => setIsBuy(true)}
          className={`flex-1 py-2 rounded-lg font-medium transition ${
            isBuy
              ? "bg-green-600 text-white"
              : "bg-dark-600 text-gray-400 hover:text-white"
          }`}
        >
          Buy
        </button>
        <button
          onClick={() => setIsBuy(false)}
          className={`flex-1 py-2 rounded-lg font-medium transition ${
            !isBuy
              ? "bg-red-600 text-white"
              : "bg-dark-600 text-gray-400 hover:text-white"
          }`}
        >
          Sell
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm text-gray-400 mb-1">
            Amount In ({inSymbol})
          </label>
          <input
            type="text"
            value={amountIn}
            onChange={(e) => setAmountIn(e.target.value)}
            placeholder="0.00"
            className="w-full bg-dark-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-accent-500"
          />
        </div>

        <div>
          <label className="block text-sm text-gray-400 mb-1">
            Min Amount Out ({outSymbol})
          </label>
          <input
            type="text"
            value={minAmountOut}
            onChange={(e) => setMinAmountOut(e.target.value)}
            placeholder="0.00"
            className="w-full bg-dark-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-accent-500"
          />
        </div>

        <div className="bg-dark-800 rounded-lg p-3 text-sm">
          <div className="flex justify-between text-gray-400">
            <span>MEV Protection</span>
            <span className="text-green-400">Enabled (ZK Commit-Reveal)</span>
          </div>
          <div className="flex justify-between text-gray-400 mt-1">
            <span>Anonymity Set</span>
            <span className="text-accent-400">Merkle-based</span>
          </div>
          <div className="flex justify-between text-gray-400 mt-1">
            <span>Matching</span>
            <span className="text-accent-400">Batch Auction</span>
          </div>
        </div>

        <button
          type="submit"
          disabled={isSubmitting || !amountIn || !minAmountOut}
          className="w-full bg-accent-600 hover:bg-accent-500 disabled:bg-gray-700 disabled:text-gray-500 text-white font-medium py-3 rounded-lg transition"
        >
          {isSubmitting ? "Submitting..." : "Commit Order (Hidden)"}
        </button>

        {submitted && (
          <p className="text-green-400 text-sm text-center">
            Order committed! Price and size are hidden.
          </p>
        )}
      </form>
    </div>
  );
}
