import { DARKPOOL_CONFIG } from '../config/constants';

const CLEARING HOUSE_ABI = [
  {
    type: 'function',
    name: 'commitOrder',
    inputs: [
      { name: 'commitment', type: 'bytes32' },
      { name: 'deadline', type: 'uint256' },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'revealOrder',
    inputs: [
      { name: 'trader', type: 'address' },
      { name: 'tokenIn', type: 'address' },
      { name: 'tokenOut', type: 'address' },
      { name: 'amountIn', type: 'uint256' },
      { name: 'minAmountOut', type: 'uint256' },
      { name: 'nonce', type: 'uint256' },
      { name: 'secret', type: 'uint256' },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'settleBatch',
    inputs: [
      { name: 'seal', type: 'bytes' },
      { name: 'journal', type: 'bytes' },
    ],
    outputs: [{ name: '', type: 'bool' }],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'verifySolvency',
    inputs: [
      { name: 'seal', type: 'bytes' },
      { name: 'journal', type: 'bytes' },
    ],
    outputs: [{ name: '', type: 'bool' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'cancelOrder',
    inputs: [{ name: 'commitment', type: 'bytes32' }],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'event',
    name: 'OrderCommitted',
    inputs: [
      { name: 'trader', type: 'address', indexed: true },
      { name: 'commitment', type: 'bytes32', indexed: false },
      { name: 'deadline', type: 'uint256', indexed: false },
    ],
  },
  {
    type: 'event',
    name: 'BatchSettled',
    inputs: [
      { name: 'batchId', type: 'bytes32', indexed: true },
      { name: 'merkleRoot', type: 'bytes32', indexed: false },
      { name: 'matchCount', type: 'uint256', indexed: false },
    ],
  },
] as const;

const VERIFIER_ABI = [
  {
    type: 'function',
    name: 'verify',
    inputs: [
      { name: 'seal', type: 'bytes' },
      { name: 'imageId', type: 'bytes32' },
      { name: 'journal', type: 'bytes' },
    ],
    outputs: [{ name: '', type: 'bool' }],
    stateMutability: 'view',
  },
] as const;

export { CLEARING_HOUSE_ABI, VERIFIER_ABI };
