use darkpool_shared::*;
use risc0_zkvm::guest::env;
use sha2::{Digest, Sha256};

fn main() {
    let input: BatchAuctionInput = env::read();

    assert!(input.orders.len() > 0, "No orders in batch");
    assert!(input.orders.len() <= 256, "Too many orders");

    for order in &input.orders {
        assert!(order.deadline > 0, "Invalid deadline");
        verify_merkle_inclusion(order, &input.merkle_root);
    }

    let mut buy_orders: Vec<(usize, &Order)> = Vec::new();
    let mut sell_orders: Vec<(usize, &Order)> = Vec::new();

    for (i, order) in input.orders.iter().enumerate() {
        if order.is_buy {
            buy_orders.push((i, order));
        } else {
            sell_orders.push((i, order));
        }
    }

    let mut matches: Vec<OrderPair> = Vec::new();
    let mut total_volume: u128 = 0;

    for (buy_idx, buy) in &buy_orders {
        for (sell_idx, sell) in &sell_orders {
            if buy.token_in == sell.token_out
                && buy.token_out == sell.token_in
            {
                let buy_amount = u256_from_be(&buy.amount_in);
                let sell_amount = u256_from_be(&sell.amount_in);
                let fill = buy_amount.min(sell_amount);

                if fill > 0 {
                    let price = compute_clearing_price(buy_amount, sell_amount);
                    let fill_bytes = u256_to_be(fill);

                    matches.push(OrderPair {
                        buy_order_index: *buy_idx,
                        sell_order_index: *sell_idx,
                        fill_amount: fill_bytes,
                        price,
                    });

                    total_volume += fill;
                }
            }
        }
    }

    let mut commitment_hashes: Vec<[u8; 32]> = Vec::new();
    for order in &input.orders {
        let hash = hash_order_commitment(order);
        commitment_hashes.push(hash);
    }

    let new_merkle_root = compute_merkle_root(&commitment_hashes);

    let output = BatchAuctionOutput {
        matches,
        new_merkle_root,
        total_volume: u256_to_be(total_volume),
    };

    env::commit(&output);
}

fn verify_merkle_inclusion(order: &Order, root: &[u8; 32]) {
    let leaf = hash_order_commitment(order);
    let mut current = leaf;
    let mut index = order.merkle_index;

    for sibling in &order.merkle_siblings {
        let mut hasher = Sha256::new();
        if index % 2 == 0 {
            hasher.update(&current);
            hasher.update(sibling);
        } else {
            hasher.update(sibling);
            hasher.update(&current);
        }
        current = hasher.finalize().into();
        index /= 2;
    }

    assert_eq!(current, *root, "Merkle proof verification failed");
}

fn hash_order_commitment(order: &Order) -> [u8; 32] {
    let mut hasher = Sha256::new();
    hasher.update(&order.order_hash);
    hasher.update(&order.nullifier);
    hasher.update(&order.token_in);
    hasher.update(&order.token_out);
    hasher.update(&order.amount_in);
    hasher.update(&order.min_amount_out);
    hasher.update(&[order.is_buy as u8]);
    hasher.update(order.deadline.to_be_bytes());
    hasher.update(&order.salt);
    let result: [u8; 32] = hasher.finalize().into();
    result
}

fn compute_clearing_price(buy_amount: u128, sell_amount: u128) -> [u8; 32] {
    let price = if sell_amount > 0 {
        buy_amount * 10u128.pow(18) / sell_amount
    } else {
        0
    };
    u256_to_be(price)
}

fn compute_merkle_root(leaves: &[[u8; 32]]) -> [u8; 32] {
    if leaves.is_empty() {
        return [0u8; 32];
    }

    let mut nodes: Vec<[u8; 32]> = leaves.to_vec();

    let mut size = 1;
    while size < nodes.len() {
        size *= 2;
    }
    while nodes.len() < size {
        nodes.push([0u8; 32]);
    }

    while nodes.len() > 1 {
        let mut next_level: Vec<[u8; 32]> = Vec::new();
        for chunk in nodes.chunks(2) {
            let mut hasher = Sha256::new();
            hasher.update(&chunk[0]);
            hasher.update(&chunk[1]);
            let hash: [u8; 32] = hasher.finalize().into();
            next_level.push(hash);
        }
        nodes = next_level;
    }

    nodes[0]
}
