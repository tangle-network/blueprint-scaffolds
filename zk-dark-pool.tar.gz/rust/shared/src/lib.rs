use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Order {
    pub order_hash: [u8; 32],
    pub nullifier: [u8; 32],
    pub token_in: [u8; 20],
    pub token_out: [u8; 20],
    pub amount_in: [u8; 32],
    pub min_amount_out: [u8; 32],
    pub is_buy: bool,
    pub deadline: u64,
    pub salt: [u8; 32],
    pub merkle_index: u32,
    pub merkle_siblings: Vec<[u8; 32]>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct OrderPair {
    pub buy_order_index: usize,
    pub sell_order_index: usize,
    pub fill_amount: [u8; 32],
    pub price: [u8; 32],
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct BatchAuctionInput {
    pub orders: Vec<Order>,
    pub merkle_root: [u8; 32],
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct BatchAuctionOutput {
    pub matches: Vec<OrderPair>,
    pub new_merkle_root: [u8; 32],
    pub total_volume: [u8; 32],
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct SolvencyInput {
    pub pool_balance: [u8; 32],
    pub obligations: Vec<[u8; 32]>,
    pub token_address: [u8; 20],
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct SolvencyOutput {
    pub is_solvent: bool,
    pub pool_balance: [u8; 32],
    pub total_obligations: [u8; 32],
}

pub fn hash_bytes(data: &[u8]) -> [u8; 32] {
    let mut hasher = Sha256::new();
    hasher.update(data);
    let result = hasher.finalize();
    let mut out = [0u8; 32];
    out.copy_from_slice(&result);
    out
}

pub fn u256_from_be(bytes: &[u8; 32]) -> u128 {
    let mut arr = [0u8; 16];
    arr.copy_from_slice(&bytes[16..32]);
    u128::from_be_bytes(arr)
}

pub fn u256_to_be(val: u128) -> [u8; 32] {
    let mut out = [0u8; 32];
    out[16..32].copy_from_slice(&val.to_be_bytes());
    out
}
