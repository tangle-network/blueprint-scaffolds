use anyhow::Result;
use darkpool_shared::*;
use risc0_zkvm::{default_prover, ExecutorEnv, Groth16Receipt, Receipt};
use serde::{Deserialize, Serialize};
use std::time::Duration;

const BONSAI_API_URL: &str = "https://api.bonsai.xyz/v1";

pub struct DarkPoolProver {
    image_id: [u32; 8],
    bonsai_api_key: Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
struct BonsaiProofRequest {
    image_id: String,
    input: String,
}

#[derive(Debug, Serialize, Deserialize)]
struct BonsaiProofResponse {
    proof_id: String,
    status: String,
    receipt: Option<serde_json::Value>,
}

impl DarkPoolProver {
    pub fn new(image_id: [u32; 8], bonsai_api_key: Option<String>) -> Self {
        Self {
            image_id,
            bonsai_api_key,
        }
    }

    pub async fn prove_batch_auction(
        &self,
        input: BatchAuctionInput,
    ) -> Result<Receipt> {
        let env = ExecutorEnv::builder()
            .write(&input)?
            .build()?;

        let prover = default_prover();

        let receipt = prover.prove_elf(env, include_bytes!("../../guest/elf/darkpool-guest"))?;

        log::info!(
            "Batch auction proof generated. {} matches found.",
            receipt.journal.decode::<BatchAuctionOutput>()?.matches.len()
        );

        Ok(receipt)
    }

    pub async fn prove_batch_via_bonsai(
        &self,
        input: BatchAuctionInput,
    ) -> Result<String> {
        let api_key = self.bonsai_api_key.as_ref()
            .ok_or_else(|| anyhow::anyhow!("Bonsai API key required"))?;

        let client = reqwest::Client::new();

        let input_bytes = bincode::serialize(&input)?;
        let input_hex = hex::encode(&input_bytes);

        let request = BonsaiProofRequest {
            image_id: format!("0x{}", hex::encode(
                self.image_id.iter()
                    .flat_map(|w| w.to_be_bytes())
                    .collect::<Vec<u8>>()
            )),
            input: input_hex,
        };

        let response = client
            .post(format!("{}/prove", BONSAI_API_URL))
            .header("x-api-key", api_key)
            .json(&request)
            .send()
            .await?;

        let proof_response: BonsaiProofResponse = response.json().await?;
        log::info!("Bonsai proof submitted: {}", proof_response.proof_id);

        Ok(proof_response.proof_id)
    }

    pub async fn poll_bonsai_proof(&self, proof_id: &str) -> Result<Option<Receipt>> {
        let api_key = self.bonsai_api_key.as_ref()
            .ok_or_else(|| anyhow::anyhow!("Bonsai API key required"))?;

        let client = reqwest::Client::new();

        let response = client
            .get(format!("{}/prove/{}", BONSAI_API_URL, proof_id))
            .header("x-api-key", api_key)
            .send()
            .await?;

        let proof_response: BonsaiProofResponse = response.json().await?;

        match proof_response.status.as_str() {
            "completed" => {
                if let Some(receipt_json) = proof_response.receipt {
                    let receipt: Receipt = serde_json::from_value(receipt_json)?;
                    Ok(Some(receipt))
                } else {
                    Err(anyhow::anyhow!("Proof completed but no receipt"))
                }
            }
            "running" | "pending" => Ok(None),
            "failed" => Err(anyhow::anyhow!("Proof generation failed")),
            _ => Err(anyhow::anyhow!("Unknown status: {}", proof_response.status)),
        }
    }

    pub async fn wait_for_bonsai_proof(
        &self,
        proof_id: &str,
        timeout: Duration,
    ) -> Result<Receipt> {
        let start = std::time::Instant::now();

        while start.elapsed() < timeout {
            if let Some(receipt) = self.poll_bonsai_proof(proof_id).await? {
                return Ok(receipt);
            }
            tokio::time::sleep(Duration::from_secs(5)).await;
        }

        Err(anyhow::anyhow!("Bonsai proof timed out"))
    }

    pub fn verify_receipt(&self, receipt: &Receipt) -> Result<bool> {
        let image_id_bytes: Vec<u8> = self.image_id.iter()
            .flat_map(|w| w.to_be_bytes())
            .collect();

        receipt.verify(self.image_id)?;
        Ok(true)
    }
}

pub fn encode_receipt_for_evm(receipt: &Receipt) -> Result<(Vec<u8>, [u8; 32], Vec<u8>)> {
    let groth16: Groth16Receipt<BatchAuctionOutput> = receipt.clone().groth16()?;

    let seal = groth16.clone().seal;
    let image_id = {
        let bytes: Vec<u8> = groth16.claim()?.pre().digest()
            .iter()
            .flat_map(|w| w.to_be_bytes())
            .collect();
        let mut arr = [0u8; 32];
        arr.copy_from_slice(&bytes);
        arr
    };
    let journal = receipt.journal.bytes.clone();

    Ok((seal, image_id, journal))
}

#[tokio::main]
async fn main() -> Result<()> {
    env_logger::init();

    let orders = vec![
        Order {
            order_hash: [1u8; 32],
            nullifier: [2u8; 32],
            token_in: [0xaa; 20],
            token_out: [0xbb; 20],
            amount_in: u256_to_be(1000),
            min_amount_out: u256_to_be(900),
            is_buy: true,
            deadline: 9999999999,
            salt: [3u8; 32],
            merkle_index: 0,
            merkle_siblings: vec![[0u8; 32]],
        },
        Order {
            order_hash: [4u8; 32],
            nullifier: [5u8; 32],
            token_in: [0xbb; 20],
            token_out: [0xaa; 20],
            amount_in: u256_to_be(500),
            min_amount_out: u256_to_be(450),
            is_buy: false,
            deadline: 9999999999,
            salt: [6u8; 32],
            merkle_index: 1,
            merkle_siblings: vec![[0u8; 32]],
        },
    ];

    let merkle_root = compute_mock_merkle_root(&orders);

    let input = BatchAuctionInput {
        orders,
        merkle_root,
    };

    println!("=== ZK Dark Pool - Batch Auction Prover ===");
    println!("Orders: {}", input.orders.len());

    let prover = DarkPoolProver::new([0u32; 8], None);

    println!("Generating local proof...");
    match prover.prove_batch_auction(input).await {
        Ok(receipt) => {
            println!("Proof generated successfully!");
            println!("Journal: {} bytes", receipt.journal.bytes.len());

            match receipt.journal.decode::<BatchAuctionOutput>() {
                Ok(output) => {
                    println!("Matches: {}", output.matches.len());
                    println!("Total volume: {} (u128)", u256_from_be(&output.total_volume));
                }
                Err(e) => println!("Failed to decode output: {}", e),
            }
        }
        Err(e) => {
            println!("Local proving unavailable (no ELF binary): {}", e);
            println!("In production, use: prover.prove_batch_via_bonsai(input).await");
        }
    }

    Ok(())
}

fn compute_mock_merkle_root(orders: &[Order]) -> [u8; 32] {
    use sha2::{Digest, Sha256};

    let leaves: Vec<[u8; 32]> = orders.iter().map(|o| {
        let mut hasher = Sha256::new();
        hasher.update(&o.order_hash);
        hasher.update(&o.nullifier);
        let result: [u8; 32] = hasher.finalize().into();
        result
    }).collect();

    let mut nodes = leaves.clone();
    while nodes.len() > 1 {
        let mut next = Vec::new();
        for chunk in nodes.chunks(2) {
            let mut hasher = Sha256::new();
            hasher.update(&chunk[0]);
            if chunk.len() > 1 {
                hasher.update(&chunk[1]);
            }
            let hash: [u8; 32] = hasher.finalize().into();
            next.push(hash);
        }
        nodes = next;
    }

    nodes[0]
}
