/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        dark: { 900: '#0a0b0e', 800: '#12141a', 700: '#1a1d27', 600: '#222633' },
        accent: { DEFAULT: '#6c5ce7', light: '#a29bfe' },
        success: '#00cec9',
        danger: '#ff7675',
      },
    },
  },
  plugins: [],
};
