import * as anchor from "@coral-xyz/anchor";
import { Program } from "@coral-xyz/anchor";
import { expect } from "chai";

describe("perp-dex", () => {
  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);

  const program = anchor.workspace.PerpDex as Program;

  it("Initializes the global state", async () => {
    const [globalState] = anchor.web3.PublicKey.findProgramAddressSync(
      [Buffer.from("global")],
      program.programId
    );

    await program.methods
      .initialize()
      .accounts({
        globalState,
        admin: provider.wallet.publicKey,
        systemProgram: anchor.web3.SystemProgram.programId,
      })
      .rpc();

    const state = await program.account.globalState.fetch(globalState);
    expect(state.admin.toString()).to.equal(provider.wallet.publicKey.toString());
    expect(state.totalMarkets.toNumber()).to.equal(0);
  });
});
