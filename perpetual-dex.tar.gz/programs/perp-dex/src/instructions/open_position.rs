use anchor_lang::prelude::*;
use crate::state::{Market, Position, Side, UserAccount};
use crate::constants::*;
use crate::errors::PerpError;
use crate::math::*;

#[derive(Accounts)]
#[instruction(side: Side, size_usd: u64, leverage: u8)]
pub struct OpenPosition<'info> {
    #[account(mut)]
    pub market: Account<'info, Market>,
    #[account(
        mut,
        constraint = user_account.owner == user.key() @ PerpError::Unauthorized,
    )]
    pub user_account: Account<'info, UserAccount>,
    #[account(
        init,
        payer = user,
        space = Position::LEN,
        seeds = [
            SEED_POSITION,
            user.key().as_ref(),
            market.key().as_ref(),
            &[side as u8],
        ],
        bump,
    )]
    pub position: Account<'info, Position>,
    #[account(mut)]
    pub user: Signer<'info>,
    pub system_program: Program<'info, System>,
}

pub fn handler(
    ctx: Context<OpenPosition>,
    side: Side,
    size_usd: u64,
    leverage: u8,
) -> Result<()> {
    if size_usd == 0 {
        return Err(PerpError::InvalidSize.into());
    }
    if leverage > ctx.accounts.market.max_leverage {
        return Err(PerpError::LeverageTooHigh.into());
    }
    if leverage < MIN_LEVERAGE {
        return Err(PerpError::LeverageTooLow.into());
    }

    let market = &mut ctx.accounts.market;
    let user_acct = &mut ctx.accounts.user_account;

    let price = market.mark_price;
    let notional = size_usd;
    let required_margin = calculate_initial_margin(notional, leverage)?;

    if user_acct.margin_available < required_margin {
        return Err(PerpError::InsufficientMargin.into());
    }

    let base_delta = match side {
        Side::Long => notional as i64 / (price as i64 / PRICE_DECIMALS as i64).max(1),
        Side::Short => -(notional as i64 / (price as i64 / PRICE_DECIMALS as i64).max(1)),
    };
    market.mark_price = market.get_vamm_price(base_delta);

    if base_delta >= 0 {
        market.base_reserve = market.base_reserve.saturating_sub(base_delta as u64);
        market.quote_reserve = market.quote_reserve.saturating_add(notional);
    } else {
        market.base_reserve = safe_add(market.base_reserve, base_delta.unsigned_abs() as u64)?;
        market.quote_reserve = market.quote_reserve.saturating_sub(notional);
    }

    match side {
        Side::Long => market.total_long_size = safe_add(market.total_long_size, size_usd)?,
        Side::Short => market.total_short_size = safe_add(market.total_short_size, size_usd)?,
    }
    market.open_interest = safe_add(market.open_interest, notional)?;

    let liq_price = calculate_liquidation_price(price, leverage, side)?;

    let position = &mut ctx.accounts.position;
    position.owner = ctx.accounts.user.key();
    position.market = market.key();
    position.side = side;
    position.size = size_usd;
    position.entry_price = price;
    position.margin = required_margin;
    position.set_leverage(leverage);
    position.cumulative_funding_entry = match side {
        Side::Long => market.cumulative_funding_long,
        Side::Short => market.cumulative_funding_short,
    };
    position.unrealized_pnl = 0;
    position.last_update_slot = Clock::get()?.slot;
    position.liquidation_price = liq_price;
    position.bump = ctx.bumps.position;

    user_acct.margin_available = safe_sub(user_acct.margin_available, required_margin)?;
    user_acct.total_notional = safe_add(user_acct.total_notional, notional)?;

    Ok(())
}
