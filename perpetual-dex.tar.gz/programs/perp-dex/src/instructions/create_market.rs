use anchor_lang::prelude::*;
use crate::state::{GlobalState, Market};
use crate::constants::*;
use crate::errors::PerpError;

#[derive(Accounts)]
#[instruction(symbol: String, base_reserve: u64, quote_reserve: u64)]
pub struct CreateMarket<'info> {
    #[account(
        mut,
        constraint = global_state.admin == admin.key() @ PerpError::Unauthorized,
    )]
    pub global_state: Account<'info, GlobalState>,
    #[account(
        init,
        payer = admin,
        space = Market::LEN,
        seeds = [SEED_MARKET, symbol.as_bytes()],
        bump,
    )]
    pub market: Account<'info, Market>,
    #[account(mut)]
    pub admin: Signer<'info>,
    pub system_program: Program<'info, System>,
}

pub fn handler(
    ctx: Context<CreateMarket>,
    symbol: String,
    base_reserve: u64,
    quote_reserve: u64,
    pyth_price: Pubkey,
    max_leverage: u8,
) -> Result<()> {
    if symbol.len() > MAX_SYMBOL_LEN {
        return Err(PerpError::SymbolTooLong.into());
    }
    if max_leverage > MAX_LEVERAGE || max_leverage < MIN_LEVERAGE {
        return Err(PerpError::LeverageTooHigh.into());
    }

    let market = &mut ctx.accounts.market;
    let global = &mut ctx.accounts.global_state;

    market.admin = ctx.accounts.admin.key();
    market.symbol = symbol.clone();
    market.base_reserve = base_reserve;
    market.quote_reserve = quote_reserve;
    market.pyth_price = pyth_price;
    market.mark_price = if base_reserve > 0 {
        quote_reserve * PRICE_DECIMALS / base_reserve
    } else {
        0
    };
    market.index_price = market.mark_price;
    market.cumulative_funding_long = 0;
    market.cumulative_funding_short = 0;
    market.last_funding_slot = Clock::get()?.slot;
    market.last_funding_rate = 0;
    market.total_long_size = 0;
    market.total_short_size = 0;
    market.open_interest = 0;
    market.max_leverage = max_leverage;
    market.bump = ctx.bumps.market;

    global.total_markets = global.total_markets.checked_add(1).ok_or(PerpError::MathOverflow)?;

    Ok(())
}
