use anchor_lang::prelude::*;
use crate::state::{Market, Position, Side, GlobalState, UserAccount};
use crate::constants::*;
use crate::errors::PerpError;
use crate::math::*;

#[derive(Accounts)]
pub struct AutoDeleverage<'info> {
    #[account(
        mut,
        seeds = [SEED_GLOBAL],
        bump = global_state.bump,
    )]
    pub global_state: Account<'info, GlobalState>,
    #[account(mut)]
    pub market: Account<'info, Market>,
    #[account(
        mut,
        constraint = adl_position.market == market.key() @ PerpError::MarketNotFound,
    )]
    pub adl_position: Account<'info, Position>,
    #[account(
        mut,
        constraint = deleveraged_user.key() == adl_position.owner @ PerpError::Unauthorized,
    )]
    pub deleveraged_user: Account<'info, UserAccount>,
    #[account(
        mut,
        constraint = counterparty.key() != adl_position.owner @ PerpError::Unauthorized,
    )]
    pub counterparty: Account<'info, UserAccount>,
    #[account(mut)]
    pub keeper: Signer<'info>,
    pub system_program: Program<'info, System>,
}

pub fn handler(ctx: Context<AutoDeleverage>) -> Result<()> {
    let adl_position = &mut ctx.accounts.adl_position;
    let market = &mut ctx.accounts.market;
    let global = &mut ctx.accounts.global_state;
    let deleveraged = &mut ctx.accounts.deleveraged_user;
    let counterparty = &mut ctx.accounts.counterparty;

    let current_price = market.mark_price;
    let pnl = match adl_position.side {
        Side::Long => calculate_pnl(adl_position.entry_price, current_price, adl_position.size, Side::Long)?,
        Side::Short => calculate_pnl(adl_position.entry_price, current_price, adl_position.size, Side::Short)?,
    };

    let margin_deficit = if pnl < 0 {
        pnl.unsigned_abs().saturating_sub(adl_position.margin)
    } else {
        0
    };

    if margin_deficit == 0 {
        return Err(PerpError::PositionHealthy.into());
    }

    let insurance_covered = global.insurance_fund.min(margin_deficit);
    global.insurance_fund = global.insurance_fund.saturating_sub(insurance_covered);

    let counterparty_cover = margin_deficit.saturating_sub(insurance_covered);
    counterparty.margin_deposited = counterparty.margin_deposited.saturating_sub(counterparty_cover);

    deleveraged.margin_deposited = deleveraged.margin_deposited.saturating_sub(adl_position.margin);
    deleveraged.total_notional = deleveraged.total_notional.saturating_sub(adl_position.size);

    match adl_position.side {
        Side::Long => market.total_long_size = market.total_long_size.saturating_sub(adl_position.size),
        Side::Short => market.total_short_size = market.total_short_size.saturating_sub(adl_position.size),
    }
    market.open_interest = market.open_interest.saturating_sub(adl_position.size);

    adl_position.size = 0;
    adl_position.margin = 0;
    adl_position.unrealized_pnl = 0;
    adl_position.last_update_slot = Clock::get()?.slot;

    Ok(())
}
