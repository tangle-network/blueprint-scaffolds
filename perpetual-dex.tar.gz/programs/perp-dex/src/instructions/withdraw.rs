use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Transfer};
use crate::state::UserAccount;
use crate::errors::PerpError;
use crate::math::*;

#[derive(Accounts)]
pub struct Withdraw<'info> {
    #[account(
        mut,
        constraint = user_account.owner == user.key() @ PerpError::Unauthorized,
    )]
    pub user_account: Account<'info, UserAccount>,
    #[account(mut)]
    pub user: Signer<'info>,
    #[account(mut)]
    pub user_token_account: Account<'info, TokenAccount>,
    #[account(mut)]
    pub vault_token_account: Account<'info, TokenAccount>,
    pub token_program: Program<'info, Token>,
}

pub fn handler(ctx: Context<Withdraw>, amount: u64) -> Result<()> {
    if amount == 0 {
        return Err(PerpError::InvalidSize.into());
    }
    let user_acct = &mut ctx.accounts.user_account;
    if user_acct.margin_available < amount {
        return Err(PerpError::InsufficientBalance.into());
    }

    let seeds = &[
        b"user",
        user_acct.owner.as_ref(),
        &[user_acct.bump],
    ];
    let signer_seeds = &[&seeds[..]];

    let cpi_accounts = Transfer {
        from: ctx.accounts.vault_token_account.to_account_info(),
        to: ctx.accounts.user_token_account.to_account_info(),
        authority: ctx.accounts.user_account.to_account_info(),
    };
    let cpi_program = ctx.accounts.token_program.to_account_info();
    token::transfer(CpiContext::new_with_signer(cpi_program, cpi_accounts, signer_seeds), amount)?;

    user_acct.margin_deposited = safe_sub(user_acct.margin_deposited, amount)?;
    user_acct.margin_available = safe_sub(user_acct.margin_available, amount)?;

    Ok(())
}
