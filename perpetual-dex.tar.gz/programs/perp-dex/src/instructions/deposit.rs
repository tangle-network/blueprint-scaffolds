use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Transfer};
use crate::state::{GlobalState, UserAccount};
use crate::constants::SEED_GLOBAL;
use crate::errors::PerpError;
use crate::math::*;

#[derive(Accounts)]
pub struct Deposit<'info> {
    #[account(
        seeds = [SEED_GLOBAL],
        bump = global_state.bump,
    )]
    pub global_state: Account<'info, GlobalState>,
    #[account(
        init_if_needed,
        payer = user,
        space = UserAccount::LEN,
        seeds = [b"user", user.key().as_ref()],
        bump,
    )]
    pub user_account: Account<'info, UserAccount>,
    #[account(mut)]
    pub user: Signer<'info>,
    #[account(mut)]
    pub user_token_account: Account<'info, TokenAccount>,
    #[account(mut)]
    pub vault_token_account: Account<'info, TokenAccount>,
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

pub fn handler(ctx: Context<Deposit>, amount: u64) -> Result<()> {
    if amount == 0 {
        return Err(PerpError::InvalidSize.into());
    }

    let cpi_accounts = Transfer {
        from: ctx.accounts.user_token_account.to_account_info(),
        to: ctx.accounts.vault_token_account.to_account_info(),
        authority: ctx.accounts.user.to_account_info(),
    };
    let cpi_program = ctx.accounts.token_program.to_account_info();
    token::transfer(CpiContext::new(cpi_program, cpi_accounts), amount)?;

    let user_acct = &mut ctx.accounts.user_account;
    user_acct.margin_deposited = safe_add(user_acct.margin_deposited, amount)?;
    user_acct.margin_available = safe_add(user_acct.margin_available, amount)?;
    user_acct.owner = ctx.accounts.user.key();
    user_acct.bump = ctx.bumps.user_account;

    Ok(())
}
