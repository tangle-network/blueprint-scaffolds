use anchor_lang::prelude::*;
use crate::state::{Market, Position, Side, GlobalState, UserAccount};
use crate::constants::*;
use crate::errors::PerpError;
use crate::math::*;

#[derive(Accounts)]
pub struct Liquidate<'info> {
    #[account(
        seeds = [SEED_GLOBAL],
        bump = global_state.bump,
    )]
    pub global_state: Account<'info, GlobalState>,
    #[account(mut)]
    pub market: Account<'info, Market>,
    #[account(
        mut,
        constraint = position.market == market.key() @ PerpError::MarketNotFound,
    )]
    pub position: Account<'info, Position>,
    #[account(
        mut,
        constraint = user_account.key() == position.owner @ PerpError::Unauthorized,
    )]
    pub user_account: Account<'info, UserAccount>,
    #[account(mut)]
    pub keeper: Signer<'info>,
    pub system_program: Program<'info, System>,
}

pub fn handler(ctx: Context<Liquidate>) -> Result<()> {
    let position = &mut ctx.accounts.position;
    let market = &mut ctx.accounts.market;
    let user_acct = &mut ctx.accounts.user_account;
    let global = &mut ctx.accounts.global_state;

    let current_price = market.mark_price;
    let notional = position.size;
    let maintenance = calculate_maintenance_margin(notional)?;

    let equity = if position.side == Side::Long {
        (position.margin as i64) + calculate_pnl(position.entry_price, current_price, position.size, Side::Long)?
    } else {
        (position.margin as i64) + calculate_pnl(position.entry_price, current_price, position.size, Side::Short)?
    };

    if equity > maintenance as i64 {
        return Err(PerpError::PositionHealthy.into());
    }

    let liquidation_fee = notional * LIQUIDATION_FEE_RATIO / BASIS_POINTS;
    let keeper_incentive = liquidation_fee / 2;
    let insurance_deposit = liquidation_fee.saturating_sub(keeper_incentive);

    let pnl = match position.side {
        Side::Long => calculate_pnl(position.entry_price, current_price, position.size, Side::Long)?,
        Side::Short => calculate_pnl(position.entry_price, current_price, position.size, Side::Short)?,
    };

    let remaining_margin = if pnl >= 0 {
        position.margin.saturating_add(pnl as u64).saturating_sub(liquidation_fee)
    } else {
        position.margin.saturating_sub(pnl.unsigned_abs()).saturating_sub(liquidation_fee)
    };

    user_acct.margin_deposited = user_acct.margin_deposited.saturating_sub(position.margin);
    user_acct.margin_available = user_acct.margin_available.saturating_add(remaining_margin);
    user_acct.total_notional = user_acct.total_notional.saturating_sub(position.size);

    match position.side {
        Side::Long => market.total_long_size = market.total_long_size.saturating_sub(position.size),
        Side::Short => market.total_short_size = market.total_short_size.saturating_sub(position.size),
    }
    market.open_interest = market.open_interest.saturating_sub(notional);

    global.insurance_fund = safe_add(global.insurance_fund, insurance_deposit)?;

    position.size = 0;
    position.margin = 0;
    position.unrealized_pnl = 0;
    position.last_update_slot = Clock::get()?.slot;

    Ok(())
}
