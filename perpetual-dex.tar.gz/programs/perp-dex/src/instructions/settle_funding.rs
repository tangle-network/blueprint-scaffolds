use anchor_lang::prelude::*;
use crate::state::{Market, GlobalState};
use crate::constants::*;
use crate::errors::PerpError;
use crate::math::*;

#[derive(Accounts)]
pub struct SettleFunding<'info> {
    #[account(
        seeds = [SEED_GLOBAL],
        bump = global_state.bump,
    )]
    pub global_state: Account<'info, GlobalState>,
    #[account(mut)]
    pub market: Account<'info, Market>,
}

pub fn handler(ctx: Context<SettleFunding>) -> Result<()> {
    let market = &mut ctx.accounts.market;
    let current_slot = Clock::get()?.slot;

    if current_slot.saturating_sub(market.last_funding_slot) < FUNDING_PERIOD_SLOTS {
        return Err(PerpError::FundingPeriodNotElapsed.into());
    }

    let funding_rate = calculate_funding_rate(market.mark_price, market.index_price);
    market.last_funding_rate = funding_rate;

    if market.total_long_size > 0 {
        let long_funding = (funding_rate as i128)
            * (market.total_long_size as i128)
            / BASIS_POINTS as i128;
        market.cumulative_funding_long = market.cumulative_funding_long.saturating_add(long_funding);
    }

    if market.total_short_size > 0 {
        let short_funding = -(funding_rate as i128)
            * (market.total_short_size as i128)
            / BASIS_POINTS as i128;
        market.cumulative_funding_short = market.cumulative_funding_short.saturating_add(short_funding);
    }

    market.last_funding_slot = current_slot;
    Ok(())
}
