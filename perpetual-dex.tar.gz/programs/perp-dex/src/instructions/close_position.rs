use anchor_lang::prelude::*;
use crate::state::{Market, Position, Side, UserAccount};
use crate::constants::*;
use crate::errors::PerpError;
use crate::math::*;

#[derive(Accounts)]
pub struct ClosePosition<'info> {
    #[account(mut)]
    pub market: Account<'info, Market>,
    #[account(
        mut,
        constraint = user_account.owner == user.key() @ PerpError::Unauthorized,
    )]
    pub user_account: Account<'info, UserAccount>,
    #[account(
        mut,
        constraint = position.owner == user.key() @ PerpError::Unauthorized,
        constraint = position.market == market.key() @ PerpError::MarketNotFound,
    )]
    pub position: Account<'info, Position>,
    #[account(mut)]
    pub user: Signer<'info>,
    pub system_program: Program<'info, System>,
}

pub fn handler(ctx: Context<ClosePosition>, size_usd: u64) -> Result<()> {
    if size_usd == 0 {
        return Err(PerpError::InvalidSize.into());
    }
    let position = &mut ctx.accounts.position;
    if position.size < size_usd {
        return Err(PerpError::InvalidSize.into());
    }

    let market = &mut ctx.accounts.market;
    let user_acct = &mut ctx.accounts.user_account;

    let current_price = market.mark_price;
    let pnl = calculate_pnl(position.entry_price, current_price, size_usd, position.side)?;

    let base_delta = match position.side {
        Side::Long => -(size_usd as i64 / (current_price as i64 / PRICE_DECIMALS as i64).max(1)),
        Side::Short => size_usd as i64 / (current_price as i64 / PRICE_DECIMALS as i64).max(1),
    };
    market.mark_price = market.get_vamm_price(base_delta);

    if base_delta >= 0 {
        market.base_reserve = market.base_reserve.saturating_add(base_delta as u64);
        market.quote_reserve = market.quote_reserve.saturating_sub(size_usd);
    } else {
        market.base_reserve = market.base_reserve.saturating_sub(base_delta.unsigned_abs() as u64);
        market.quote_reserve = market.quote_reserve.saturating_add(size_usd);
    }

    match position.side {
        Side::Long => market.total_long_size = market.total_long_size.saturating_sub(size_usd),
        Side::Short => market.total_short_size = market.total_short_size.saturating_sub(size_usd),
    }
    market.open_interest = market.open_interest.saturating_sub(size_usd);

    let margin_to_release = if position.size == size_usd {
        position.margin
    } else {
        position.margin * size_usd / position.size
    };

    if pnl >= 0 {
        user_acct.margin_available = safe_add(user_acct.margin_available, margin_to_release)?;
        user_acct.margin_available = safe_add(user_acct.margin_available, pnl as u64)?;
        user_acct.margin_deposited = safe_add(user_acct.margin_deposited, pnl as u64)?;
    } else {
        let loss = pnl.unsigned_abs();
        let net = margin_to_release.saturating_sub(loss);
        user_acct.margin_available = safe_add(user_acct.margin_available, net)?;
    }

    position.margin = position.margin.saturating_sub(margin_to_release);
    position.size = position.size.saturating_sub(size_usd);
    position.last_update_slot = Clock::get()?.slot;

    user_acct.total_notional = user_acct.total_notional.saturating_sub(size_usd);

    Ok(())
}
