use anchor_lang::prelude::*;
use crate::state::GlobalState;
use crate::constants::SEED_GLOBAL;

#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(
        init,
        payer = admin,
        space = GlobalState::LEN,
        seeds = [SEED_GLOBAL],
        bump,
    )]
    pub global_state: Account<'info, GlobalState>,
    #[account(mut)]
    pub admin: Signer<'info>,
    pub system_program: Program<'info, System>,
}

pub fn handler(ctx: Context<Initialize>) -> Result<()> {
    let global = &mut ctx.accounts.global_state;
    global.admin = ctx.accounts.admin.key();
    global.total_markets = 0;
    global.insurance_fund = 0;
    global.paused = false;
    global.bump = ctx.bumps.global_state;
    Ok(())
}
