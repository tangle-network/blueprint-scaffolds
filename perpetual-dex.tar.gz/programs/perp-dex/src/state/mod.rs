use anchor_lang::prelude::*;
use crate::constants::*;

#[account]
pub struct GlobalState {
    pub admin: Pubkey,
    pub vault_authority_bump: u8,
    pub insurance_authority_bump: u8,
    pub total_markets: u64,
    pub insurance_fund: u64,
    pub paused: bool,
    pub bump: u8,
}

impl GlobalState {
    pub const LEN: usize = 8 + 32 + 1 + 1 + 8 + 8 + 1 + 1;
}

#[account]
pub struct Market {
    pub admin: Pubkey,
    pub symbol: String,
    pub base_reserve: u64,
    pub quote_reserve: u64,
    pub pyth_price: Pubkey,
    pub mark_price: u64,
    pub index_price: u64,
    pub cumulative_funding_long: i128,
    pub cumulative_funding_short: i128,
    pub last_funding_slot: u64,
    pub last_funding_rate: i64,
    pub total_long_size: u64,
    pub total_short_size: u64,
    pub open_interest: u64,
    pub max_leverage: u8,
    pub bump: u8,
}

impl Market {
    pub const LEN: usize = 8
        + 32
        + (4 + MAX_SYMBOL_LEN)
        + 8 + 8 + 32 + 8 + 8
        + 16 + 16
        + 8 + 8
        + 8 + 8
        + 8
        + 1 + 1;

    pub fn get_vamm_price(&self, base_delta: i64) -> u64 {
        let k = self.base_reserve as u128 * self.quote_reserve as u128;
        let new_base = if base_delta >= 0 {
            (self.base_reserve as u128).checked_add(base_delta as u128).unwrap_or(u128::MAX)
        } else {
            (self.base_reserve as u128).checked_sub(base_delta.unsigned_abs() as u128).unwrap_or(1)
        };
        if new_base == 0 {
            return self.mark_price;
        }
        let new_quote = k / new_base;
        let price_u128 = new_quote * PRICE_DECIMALS as u128 / new_base;
        price_u128.min(u64::MAX as u128) as u64
    }
}

#[account]
pub struct Position {
    pub owner: Pubkey,
    pub market: Pubkey,
    pub side: Side,
    pub size: u64,
    pub entry_price: u64,
    pub margin: u64,
    leverage: u8,
    pub cumulative_funding_entry: i128,
    pub unrealized_pnl: i64,
    pub last_update_slot: u64,
    pub liquidation_price: u64,
    pub bump: u8,
}

impl Position {
    pub const LEN: usize = 8
        + 32 + 32
        + 1
        + 8 + 8 + 8 + 1
        + 16
        + 8 + 8 + 8
        + 1;

    pub fn leverage(&self) -> u8 {
        self.leverage
    }

    pub fn set_leverage(&mut self, lev: u8) {
        self.leverage = lev;
    }
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, Copy, PartialEq, Eq, Debug)]
pub enum Side {
    Long,
    Short,
}

#[account]
pub struct UserAccount {
    pub owner: Pubkey,
    pub margin_deposited: u64,
    pub margin_available: u64,
    pub total_notional: u64,
    pub bump: u8,
}

impl UserAccount {
    pub const LEN: usize = 8 + 32 + 8 + 8 + 8 + 1;
}
