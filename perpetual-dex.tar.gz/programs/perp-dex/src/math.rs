use anchor_lang::prelude::*;

pub fn safe_mul(a: u64, b: u64) -> Result<u64> {
    a.checked_mul(b).ok_or(PerpError::MathOverflow.into())
}

pub fn safe_div(a: u64, b: u64) -> Result<u64> {
    if b == 0 {
        return Err(PerpError::MathOverflow.into());
    }
    a.checked_div(b).ok_or(PerpError::MathOverflow.into())
}

pub fn safe_add(a: u64, b: u64) -> Result<u64> {
    a.checked_add(b).ok_or(PerpError::MathOverflow.into())
}

pub fn safe_sub(a: u64, b: u64) -> Result<u64> {
    a.checked_sub(b).ok_or(PerpError::MathOverflow.into())
}

pub fn calculate_notional(size: u64, price: u64) -> Result<u64> {
    safe_mul(size, price)
}

pub fn calculate_initial_margin(notional: u64, leverage: u8) -> Result<u64> {
    let leverage_u64 = leverage as u64;
    safe_div(notional, leverage_u64)
}

pub fn calculate_maintenance_margin(notional: u64) -> Result<u64> {
    crate::constants::MAINTENANCE_MARGIN_RATIO
        .checked_mul(notional)
        .ok_or(PerpError::MathOverflow)?
        .checked_div(crate::constants::BASIS_POINTS)
        .ok_or(PerpError::MathOverflow.into())
}

pub fn calculate_pnl(entry_price: u64, exit_price: u64, size: u64, side: Side) -> Result<i64> {
    let entry = entry_price as i64;
    let exit = exit_price as i64;
    let sz = size as i64;
    match side {
        Side::Long => Ok(sz * (exit - entry)),
        Side::Short => Ok(sz * (entry - exit)),
    }
}

pub fn calculate_funding_rate(
    mark_price: u64,
    index_price: u64,
) -> i64 {
    let mark = mark_price as i64;
    let index = index_price as i64;
    if index == 0 {
        return 0;
    }
    let diff = mark - index;
    let rate = diff * 10000 / index;
    rate.clamp(-crate::constants::FUNDING_RATE_MAX, crate::constants::FUNDING_RATE_MAX)
}

pub fn calculate_liquidation_price(
    entry_price: u64,
    leverage: u8,
    side: Side,
) -> Result<u64> {
    let lev = leverage as u64;
    let maintenance_ratio = crate::constants::MAINTENANCE_MARGIN_RATIO;
    let liq_fee = crate::constants::LIQUIDATION_FEE_RATIO;
    match side {
        Side::Long => {
            let delta_pct = safe_add(maintenance_ratio, liq_fee)?;
            let delta = entry_price * delta_pct / (lev * crate::constants::BASIS_POINTS);
            Ok(entry_price.saturating_sub(delta))
        }
        Side::Short => {
            let delta_pct = safe_add(maintenance_ratio, liq_fee)?;
            let delta = entry_price * delta_pct / (lev * crate::constants::BASIS_POINTS);
            Ok(safe_add(entry_price, delta)?)
        }
    }
}

pub fn is_position_healthy(
    margin: u64,
    notional: u64,
) -> bool {
    if notional == 0 {
        return true;
    }
    let maintenance = notional * crate::constants::MAINTENANCE_MARGIN_RATIO
        / crate::constants::BASIS_POINTS;
    margin > maintenance
}
