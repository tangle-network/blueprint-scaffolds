pub const SEED_GLOBAL: &[u8] = b"global";
pub const SEED_MARKET: &[u8] = b"market";
pub const SEED_POSITION: &[u8] = b"position";
pub const SEED_VAULT: &[u8] = b"vault";
pub const SEED_INSURANCE: &[u8] = b"insurance";

pub const INITIAL_MARGIN_RATIO: u64 = 1000;
pub const MAINTENANCE_MARGIN_RATIO: u64 = 500;
pub const LIQUIDATION_FEE_RATIO: u64 = 500;
pub const MAX_LEVERAGE: u8 = 20;
pub const MIN_LEVERAGE: u8 = 1;
pub const BASIS_POINTS: u64 = 10000;
pub const FUNDING_PERIOD_SLOTS: u64 = 400;
pub const FUNDING_RATE_MAX: i64 = 1000;
pub const TWAP_PERIOD: u64 = 3600;
pub const PRICE_DECIMALS: u64 = 1_000_000;
pub const MAX_SYMBOL_LEN: usize = 32;
