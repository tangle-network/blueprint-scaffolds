use anchor_lang::prelude::*;

#[error_code]
pub enum PerpError {
    #[msg("Insufficient margin for this operation")]
    InsufficientMargin,
    #[msg("Position would be liquidated")]
    WouldLiquidate,
    #[msg("Leverage exceeds maximum allowed")]
    LeverageTooHigh,
    #[msg("Leverage below minimum allowed")]
    LeverageTooLow,
    #[msg("Invalid position size")]
    InvalidSize,
    #[msg("Position not found")]
    PositionNotFound,
    #[msg("Math overflow")]
    MathOverflow,
    #[msg("Market not found")]
    MarketNotFound,
    #[msg("Invalid oracle price")]
    InvalidOraclePrice,
    #[msg("Funding period not elapsed")]
    FundingPeriodNotElapsed,
    #[msg("Position is healthy, cannot liquidate")]
    PositionHealthy,
    #[msg("Unauthorized")]
    Unauthorized,
    #[msg("Invalid side")]
    InvalidSide,
    #[msg("Insurance fund insufficient")]
    InsuranceInsufficient,
    #[msg("Amount exceeds available balance")]
    InsufficientBalance,
    #[msg("Symbol too long")]
    SymbolTooLong,
}
