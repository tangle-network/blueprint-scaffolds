use anchor_lang::prelude::*;

declare_id!("PerpDex1111111111111111111111111111111111111");

pub mod constants;
pub mod errors;
pub mod math;
pub mod state;
pub mod instructions;

use instructions::*;

#[program]
pub mod perp_dex {
    use super::*;

    pub fn initialize(ctx: Context<Initialize>) -> Result<()> {
        instructions::initialize::handler(ctx)
    }

    pub fn create_market(
        ctx: Context<CreateMarket>,
        symbol: String,
        base_reserve: u64,
        quote_reserve: u64,
        pyth_price: Pubkey,
        max_leverage: u8,
    ) -> Result<()> {
        instructions::create_market::handler(ctx, symbol, base_reserve, quote_reserve, pyth_price, max_leverage)
    }

    pub fn deposit(ctx: Context<Deposit>, amount: u64) -> Result<()> {
        instructions::deposit::handler(ctx, amount)
    }

    pub fn withdraw(ctx: Context<Withdraw>, amount: u64) -> Result<()> {
        instructions::withdraw::handler(ctx, amount)
    }

    pub fn open_position(
        ctx: Context<OpenPosition>,
        side: Side,
        size_usd: u64,
        leverage: u8,
    ) -> Result<()> {
        instructions::open_position::handler(ctx, side, size_usd, leverage)
    }

    pub fn close_position(ctx: Context<ClosePosition>, size_usd: u64) -> Result<()> {
        instructions::close_position::handler(ctx, size_usd)
    }

    pub fn settle_funding(ctx: Context<SettleFunding>) -> Result<()> {
        instructions::settle_funding::handler(ctx)
    }

    pub fn liquidate(ctx: Context<Liquidate>) -> Result<()> {
        instructions::liquidate::handler(ctx)
    }

    pub fn auto_deleverage(ctx: Context<AutoDeleverage>) -> Result<()> {
        instructions::auto_deleverage::handler(ctx)
    }
}
