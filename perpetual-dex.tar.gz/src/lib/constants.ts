import type { Market, AMMState, MarketStats, CandleData, OrderbookEntry, Position, AccountSummary, MarketData } from '@/types'

export const MARKET_CONFIGS: Market[] = [
  {
    symbol: 'SOL-PERP', name: 'Solana Perpetual', baseAsset: 'SOL', quoteAsset: 'USDC',
    baseSymbol: 'SOL', quoteSymbol: 'USDC',
    pythPriceFeed: 'J83w4HKfqxwcq3BEMMkPFSppX3gqekLyLJBexebF1ixZ',
    pythPriceId: 'J83w4HKfqxwcq3BEMMkPFSppX3gqekLyLJBexebF1ixZ',
    decimals: 2, baseDecimals: 9, quoteDecimals: 6, minOrderSize: 0.1, maxLeverage: 20,
    initialMarginRatio: 0.05, maintenanceMarginRatio: 0.025, imrWeight: 1.0,
    fundingPeriodSec: 3600, maxFundingRate: 0.01,
  },
  {
    symbol: 'BTC-PERP', name: 'Bitcoin Perpetual', baseAsset: 'BTC', quoteAsset: 'USDC',
    baseSymbol: 'BTC', quoteSymbol: 'USDC',
    pythPriceFeed: 'GVXRSBjFk6e6J3NbVPXohDJetc1jaRF7J3QFa8fDRSHo',
    pythPriceId: 'GVXRSBjFk6e6J3NbVPXohDJetc1jaRF7J3QFa8fDRSHo',
    decimals: 1, baseDecimals: 8, quoteDecimals: 6, minOrderSize: 0.001, maxLeverage: 20,
    initialMarginRatio: 0.05, maintenanceMarginRatio: 0.025, imrWeight: 1.0,
    fundingPeriodSec: 3600, maxFundingRate: 0.01,
  },
  {
    symbol: 'ETH-PERP', name: 'Ethereum Perpetual', baseAsset: 'ETH', quoteAsset: 'USDC',
    baseSymbol: 'ETH', quoteSymbol: 'USDC',
    pythPriceFeed: 'EdVCmQ9FSPcVe5YySXDPCRmc8aDQLKJ9xvYBMZPie1Vw',
    pythPriceId: 'EdVCmQ9FSPcVe5YySXDPCRmc8aDQLKJ9xvYBMZPie1Vw',
    decimals: 2, baseDecimals: 8, quoteDecimals: 6, minOrderSize: 0.01, maxLeverage: 20,
    initialMarginRatio: 0.05, maintenanceMarginRatio: 0.025, imrWeight: 1.0,
    fundingPeriodSec: 3600, maxFundingRate: 0.01,
  },
]

export const DEFAULT_VAMM: Record<string, AMMState> = {
  'SOL-PERP': { baseReserves: 1000000, quoteReserves: 172000000, invariantK: 172000000000000, totalLongOpenInterest: 25000, totalShortOpenInterest: 18000 },
  'BTC-PERP': { baseReserves: 5000, quoteReserves: 337500000, invariantK: 1687500000000, totalLongOpenInterest: 120, totalShortOpenInterest: 95 },
  'ETH-PERP': { baseReserves: 50000, quoteReserves: 172500000, invariantK: 8625000000000, totalLongOpenInterest: 8000, totalShortOpenInterest: 6200 },
}

export const PROTOCOL_CONSTANTS = {
  fundingIntervalSeconds: 3600,
  fundingIntervalHours: 1,
  makerFeeRate: 0.0002,
  takerFeeRate: 0.0005,
  minLeverage: 1,
  maxLeverage: 20,
  liquidationPenalty: 0.05,
  insuranceFundRatio: 0.6,
  keeperReward: 0.02,
  maxPriceDeviation: 0.10,
  twapWindow: 30,
  insuranceFundBalance: 2_450_000,
  insuranceFundAddress: 'insU1YBpFfJDsGPD4k2F3s7gpCtC2LRqgz5EtbFDY',
}

export function generateMockMarketStats(symbol: string): MarketStats {
  const amm = DEFAULT_VAMM[symbol]
  const basePrice = amm.quoteReserves / amm.baseReserves
  const change = (Math.random() - 0.48) * 0.05
  const markPrice = basePrice * (1 + change)
  const fundingRate = (Math.random() - 0.5) * 0.0004
  return {
    markPrice,
    indexPrice: markPrice * (1 + (Math.random() - 0.5) * 0.001),
    oraclePrice: markPrice * (1 + (Math.random() - 0.5) * 0.0005),
    priceChange24h: change * 100,
    priceChangePercent24h: change * 100,
    volume24h: (Math.random() * 500 + 100) * 1e6,
    openInterest: (amm.totalLongOpenInterest + amm.totalShortOpenInterest) * markPrice,
    openInterestLong: amm.totalLongOpenInterest * markPrice,
    openInterestShort: amm.totalShortOpenInterest * markPrice,
    fundingRate,
    fundingRateAnnualized: fundingRate * 365 * 24,
    nextFundingCountdown: Math.floor(Math.random() * 3600),
    high24h: markPrice * 1.03,
    low24h: markPrice * 0.97,
  }
}

export function generateMockMarketData(symbol: string): MarketData {
  const stats = generateMockMarketStats(symbol)
  return {
    ...stats,
    twapPrice: stats.markPrice * (1 + (Math.random() - 0.5) * 0.001),
    lastUpdated: Date.now(),
  }
}

export function generateMockCandles(basePrice: number, count: number = 200): CandleData[] {
  const candles: CandleData[] = []
  let price = basePrice * 0.85
  const now = Math.floor(Date.now() / 1000)
  for (let i = 0; i < count; i++) {
    const time = now - (count - i) * 3600
    const change = (Math.random() - 0.48) * 0.015
    const open = price
    price = price * (1 + change)
    const close = price
    const high = Math.max(open, close) * (1 + Math.random() * 0.005)
    const low = Math.min(open, close) * (1 - Math.random() * 0.005)
    candles.push({ time, open, high, low, close, volume: Math.random() * 1000 + 100 })
  }
  return candles
}

export function generateMockOrderbook(midPrice: number): OrderbookEntry[] {
  const entries: OrderbookEntry[] = []
  let total = 0
  for (let i = 0; i < 15; i++) {
    const offset = (i + 1) * midPrice * 0.0003
    const size = Math.random() * 50 + 5
    total += size
    entries.push({ price: midPrice + offset, size, total })
  }
  return entries
}

export function generateMockOrderBook(midPrice: number): OrderbookEntry[] {
  return generateMockOrderbook(midPrice)
}

export function generateMockPositions(): Position[] {
  return [
    {
      id: 'pos-1', market: 'BTC-PERP', side: 'long', size: 2.5,
      entryPrice: 66800, markPrice: 67500, leverage: 10, margin: 16700,
      unrealizedPnl: 1750, liquidationPrice: 62490, status: 'open',
      createdAt: Date.now() - 86400000, openedAt: Date.now() - 86400000,
      fundingFeesPaid: -42.5, fundingPaid: -42.5, maintenanceMarginRatio: 0.025,
    },
    {
      id: 'pos-2', market: 'ETH-PERP', side: 'short', size: 15,
      entryPrice: 3510, markPrice: 3450, leverage: 5, margin: 10530,
      unrealizedPnl: 900, liquidationPrice: 3861, status: 'open',
      createdAt: Date.now() - 43200000, openedAt: Date.now() - 43200000,
      fundingFeesPaid: 28.3, fundingPaid: 28.3, maintenanceMarginRatio: 0.025,
    },
    {
      id: 'pos-3', market: 'SOL-PERP', side: 'long', size: 200,
      entryPrice: 168.5, markPrice: 172, leverage: 15, margin: 2246.67,
      unrealizedPnl: 700, liquidationPrice: 157.54, status: 'open',
      createdAt: Date.now() - 21600000, openedAt: Date.now() - 21600000,
      fundingFeesPaid: -15.8, fundingPaid: -15.8, maintenanceMarginRatio: 0.025,
    },
  ]
}

export function generateMockAccountSummary(): AccountSummary {
  return {
    equity: 52645.8,
    totalEquity: 52645.8,
    totalMargin: 29476.67,
    availableMargin: 23169.13,
    unrealizedPnl: 3350,
    realizedPnl: 4320.5,
    totalFundingFees: -30.0,
    totalPositions: 3,
    openPositionCount: 3,
    marginRatio: 0.42,
  }
}
