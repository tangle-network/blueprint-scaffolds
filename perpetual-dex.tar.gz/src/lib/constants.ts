import type { MarketConfig, Position, MarketData, CandleData, OrderBookEntry, vAMMState, AccountSummary } from '@/types'

export const MARKET_CONFIGS: MarketConfig[] = [
  {
    symbol: 'SOL-PERP',
    name: 'Solana Perpetual',
    baseAsset: 'SOL',
    quoteAsset: 'USDC',
    pythPriceId: 'J83w4HKfqxwcq3BEMMkPFSppX3gqekLyLJBexebF1vZ4',
    maxLeverage: 20,
    maintenanceMarginRatio: 0.025,
    initialMarginRatio: 0.05,
    baseDecimals: 9,
    quoteDecimals: 6,
  },
  {
    symbol: 'BTC-PERP',
    name: 'Bitcoin Perpetual',
    baseAsset: 'BTC',
    quoteAsset: 'USDC',
    pythPriceId: 'GVXRSBjFk6e6J3NbVPXohDJetc1jaZ7H3f3pR1d3bD',
    maxLeverage: 10,
    maintenanceMarginRatio: 0.03,
    initialMarginRatio: 0.06,
    baseDecimals: 8,
    quoteDecimals: 6,
  },
  {
    symbol: 'ETH-PERP',
    name: 'Ethereum Perpetual',
    baseAsset: 'ETH',
    quoteAsset: 'USDC',
    pythPriceId: 'JBu1AL4obBcCMqKBBxhpWCNUt136jiuMbQhRRMUtB4nt',
    maxLeverage: 15,
    maintenanceMarginRatio: 0.025,
    initialMarginRatio: 0.05,
    baseDecimals: 8,
    quoteDecimals: 6,
  },
]

export const DEFAULT_VAMM: Record<string, vAMMState> = {
  'SOL-PERP': { baseReserve: 1000000, quoteReserve: 150000000, totalLong: 25000, totalShort: 18000, invariant: 150000000000000, price: 150 },
  'BTC-PERP': { baseReserve: 5000, quoteReserve: 350000000, totalLong: 120, totalShort: 95, invariant: 1750000000000, price: 70000 },
  'ETH-PERP': { baseReserve: 50000, quoteReserve: 175000000, totalLong: 8000, totalShort: 6200, invariant: 8750000000000, price: 3500 },
}

export function generateMockMarketData(symbol: string): MarketData {
  const vamm = DEFAULT_VAMM[symbol]
  const basePrice = vamm.price
  const change = (Math.random() - 0.48) * 0.05
  const markPrice = basePrice * (1 + change)
  return {
    markPrice,
    indexPrice: markPrice * (1 + (Math.random() - 0.5) * 0.001),
    oraclePrice: markPrice * (1 + (Math.random() - 0.5) * 0.0005),
    twapPrice: markPrice * (1 + (Math.random() - 0.5) * 0.002),
    volume24h: (Math.random() * 500 + 100) * 1e6,
    fundingRate: (Math.random() - 0.5) * 0.0004,
    fundingRateAnnualized: (Math.random() - 0.5) * 0.15,
    openInterest: vamm.totalLong * markPrice + vamm.totalShort * markPrice,
    openInterestLong: vamm.totalLong * markPrice,
    openInterestShort: vamm.totalShort * markPrice,
    priceChange24h: change * 100,
    high24h: markPrice * 1.03,
    low24h: markPrice * 0.97,
    lastUpdated: Date.now(),
  }
}

export function generateMockCandles(basePrice: number, count: number = 200): CandleData[] {
  const candles: CandleData[] = []
  let price = basePrice * 0.85
  const now = Math.floor(Date.now() / 1000)
  for (let i = 0; i < count; i++) {
    const time = now - (count - i) * 3600
    const change = (Math.random() - 0.48) * 0.015
    const open = price
    price = price * (1 + change)
    const close = price
    const high = Math.max(open, close) * (1 + Math.random() * 0.005)
    const low = Math.min(open, close) * (1 - Math.random() * 0.005)
    candles.push({ time, open, high, low, close, volume: Math.random() * 1000 + 100 })
  }
  return candles
}

export function generateMockOrderBook(midPrice: number): OrderBookEntry[] {
  const entries: OrderBookEntry[] = []
  let total = 0
  for (let i = 0; i < 15; i++) {
    const offset = (i + 1) * midPrice * 0.0003
    const size = Math.random() * 50 + 5
    total += size
    entries.push({ price: midPrice + offset, size, total })
  }
  return entries
}

export function generateMockPositions(): Position[] {
  return [
    {
      id: 'pos-1',
      market: 'SOL-PERP',
      side: 'long',
      size: 100,
      entryPrice: 148.5,
      markPrice: 151.2,
      leverage: 10,
      margin: 1485,
      unrealizedPnl: 270,
      liquidationPrice: 134.8,
      status: 'open',
      createdAt: Date.now() - 86400000,
      fundingPaid: -12.5,
    },
    {
      id: 'pos-2',
      market: 'BTC-PERP',
      side: 'short',
      size: 0.5,
      entryPrice: 71200,
      markPrice: 69400,
      leverage: 5,
      margin: 7120,
      unrealizedPnl: 900,
      liquidationPrice: 78320,
      status: 'open',
      createdAt: Date.now() - 43200000,
      fundingPaid: 45.2,
    },
    {
      id: 'pos-3',
      market: 'ETH-PERP',
      side: 'long',
      size: 5,
      entryPrice: 3420,
      markPrice: 3480,
      leverage: 15,
      margin: 1140,
      unrealizedPnl: 300,
      liquidationPrice: 3283,
      status: 'open',
      createdAt: Date.now() - 21600000,
      fundingPaid: -8.3,
    },
  ]
}

export function generateMockAccountSummary(): AccountSummary {
  return {
    totalEquity: 52645.8,
    totalMargin: 9745,
    availableMargin: 8230,
    unrealizedPnl: 1170,
    realizedPnl: 4320.5,
    totalPositions: 3,
    marginRatio: 0.42,
  }
}
