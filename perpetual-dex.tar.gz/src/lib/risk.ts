import type { Position, PositionSide, RiskMetrics } from '@/types'

export function calculateLiquidationPrice(
  entryPrice: number,
  side: PositionSide,
  leverage: number,
  maintenanceMarginRatio: number
): number {
  const marginRatio = 1 / leverage
  if (side === 'long') {
    return entryPrice * (1 - marginRatio + maintenanceMarginRatio)
  }
  return entryPrice * (1 + marginRatio - maintenanceMarginRatio)
}

export function calculateMarginRequirements(
  notionalValue: number,
  leverage: number,
  initialMarginRatio: number = 0.05,
  maintenanceMarginRatio: number = 0.025
): { initialMargin: number; maintenanceMargin: number } {
  const effectiveLeverage = Math.min(leverage, 20)
  const effectiveInitialRatio = Math.max(initialMarginRatio, 1 / effectiveLeverage)
  return {
    initialMargin: notionalValue * effectiveInitialRatio,
    maintenanceMargin: notionalValue * maintenanceMarginRatio,
  }
}

export function isLiquidatable(position: Position, markPrice: number, maintenanceMarginRatio: number = 0.025): boolean {
  const notionalValue = Math.abs(position.size * markPrice)
  const maintenanceMargin = notionalValue * maintenanceMarginRatio
  const unrealizedPnl = getUnrealizedPnl(position.entryPrice, markPrice, position.size, position.side)
  const effectiveMargin = position.margin + unrealizedPnl
  return effectiveMargin < maintenanceMargin
}

export function getUnrealizedPnl(entryPrice: number, markPrice: number, size: number, side: PositionSide): number {
  if (side === 'long') {
    return (markPrice - entryPrice) * size
  }
  return (entryPrice - markPrice) * size
}

export function getMarginRatio(position: Position, markPrice: number): number {
  const notionalValue = Math.abs(position.size * markPrice)
  if (notionalValue === 0) return Infinity
  const unrealizedPnl = getUnrealizedPnl(position.entryPrice, markPrice, position.size, position.side)
  return (position.margin + unrealizedPnl) / notionalValue
}

export function computeRiskMetrics(
  position: Position,
  markPrice: number,
  maintenanceMarginRatio: number = 0.025
): RiskMetrics {
  const notionalValue = Math.abs(position.size * markPrice)
  const { initialMargin, maintenanceMargin } = calculateMarginRequirements(
    notionalValue, position.leverage, 0.05, maintenanceMarginRatio
  )
  const unrealizedPnl = getUnrealizedPnl(position.entryPrice, markPrice, position.size, position.side)
  const effectiveMargin = position.margin + unrealizedPnl
  const marginRatio = notionalValue === 0 ? Infinity : effectiveMargin / notionalValue
  return {
    initialMargin,
    maintenanceMargin,
    marginRatio,
    liquidationPrice: calculateLiquidationPrice(position.entryPrice, position.side, position.leverage, maintenanceMarginRatio),
    maxWithdrawable: Math.max(0, effectiveMargin - maintenanceMargin),
    isLiquidatable: effectiveMargin < maintenanceMargin,
  }
}
