import type { RiskParams, Position, Side } from '@/types'

export const DEFAULT_RISK_PARAMS: RiskParams = {
  initialMarginRatio: 0.05,
  maintenanceMarginRatio: 0.025,
  maxLeverage: 20,
  twapWindow: 30,
  liquidationPenalty: 0.05,
  insuranceFundRatio: 0.6,
  keeperReward: 0.02,
}

export function getInitialMargin(notionalValue: number, leverage: number, params: RiskParams): number {
  const effectiveLeverage = Math.min(leverage, params.maxLeverage)
  const marginRatio = Math.max(params.initialMarginRatio, 1 / effectiveLeverage)
  return notionalValue * marginRatio
}

export function getMaintenanceMargin(notionalValue: number, params: RiskParams): number {
  return notionalValue * params.maintenanceMarginRatio
}

export function getLiquidationPrice(
  entryPrice: number,
  side: Side,
  leverage: number,
  maintenanceMarginRatio: number
): number {
  const marginRatio = 1 / leverage
  if (side === 'long') {
    return entryPrice * (1 - marginRatio + maintenanceMarginRatio)
  }
  return entryPrice * (1 + marginRatio - maintenanceMarginRatio)
}

export function getUnrealizedPnl(entryPrice: number, markPrice: number, size: number, side: Side): number {
  if (side === 'long') {
    return (markPrice - entryPrice) * size
  }
  return (entryPrice - markPrice) * size
}

export function isLiquidatable(position: Position, markPrice: number, params: RiskParams): boolean {
  const notionalValue = Math.abs(position.size * markPrice)
  const maintenanceMargin = getMaintenanceMargin(notionalValue, params)
  const unrealizedPnl = getUnrealizedPnl(position.entryPrice, markPrice, position.size, position.side)
  const effectiveMargin = position.margin + unrealizedPnl
  return effectiveMargin < maintenanceMargin
}

export function computeLiquidationPenalty(notionalValue: number, params: RiskParams): {
  totalPenalty: number
  insuranceFundContribution: number
  keeperReward: number
} {
  const totalPenalty = notionalValue * params.liquidationPenalty
  return {
    totalPenalty,
    insuranceFundContribution: totalPenalty * params.insuranceFundRatio,
    keeperReward: totalPenalty * params.keeperReward,
  }
}

export function getMaxLeverage(margin: number, notionalValue: number, params: RiskParams): number {
  const maxByMargin = notionalValue / margin
  return Math.min(maxByMargin, params.maxLeverage)
}

export function checkAutoDeleveraging(
  position: Position,
  marketOi: number,
  insuranceFundBalance: number,
  markPrice: number,
  params: RiskParams
): { shouldAdl: boolean; adlReduction: number } {
  const notional = Math.abs(position.size * markPrice)
  const unrealizedLoss = -getUnrealizedPnl(position.entryPrice, markPrice, position.size, position.side)
  const shouldAdl = unrealizedLoss > insuranceFundBalance && unrealizedLoss > notional * 0.5
  const adlReduction = shouldAdl ? (insuranceFundBalance / markPrice) : 0
  return { shouldAdl, adlReduction }
}

export function getMarginRatio(position: Position, markPrice: number): number {
  const notionalValue = Math.abs(position.size * markPrice)
  if (notionalValue === 0) return Infinity
  const unrealizedPnl = getUnrealizedPnl(position.entryPrice, markPrice, position.size, position.side)
  return (position.margin + unrealizedPnl) / notionalValue
}
