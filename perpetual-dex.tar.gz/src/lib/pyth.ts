export interface PythPrice {
  price: number
  confidence: number
  timestamp: number
  status: 'trading' | 'halted' | 'unknown'
}

export function getPythPriceId(symbol: string): string {
  const ids: Record<string, string> = {
    'SOL/USD': 'J83w4HKfqxwcq3BEMMkPFSppX3gqekLyLJBexebF1vZ4',
    'BTC/USD': 'GVXRSBjFk6e6J3NbVPXohDJetc1jaZ7H3f3pR1d3bD',
    'ETH/USD': 'JBu1AL4obBcCMqKBBxhpWCNUt136jiuMbQhRRMUtB4nt',
    'ARB/USD': '5uvoSUYXZ18BCgBDeKG77v3FidaCTEGG1rHbGBQD6KjW',
  }
  return ids[symbol] || ''
}

export function parsePythPrice(data: number[]): PythPrice {
  return {
    price: data[0] ? data[0] / Math.pow(10, data[3]) : 0,
    confidence: data[1] / Math.pow(10, data[3]),
    timestamp: data[2],
    status: data[4] === 1 ? 'trading' : data[4] === 2 ? 'halted' : 'unknown',
  }
}

export function validatePythPrice(price: PythPrice, lastPrice: number, maxDeviation: number = 0.1): boolean {
  if (price.status !== 'trading') return false
  if (lastPrice === 0) return true
  const deviation = Math.abs(price.price - lastPrice) / lastPrice
  return deviation < maxDeviation
}

export function aggregateTwap(prices: PythPrice[], windowMs: number): number {
  const cutoff = Date.now() - windowMs
  const recent = prices.filter(p => p.timestamp * 1000 > cutoff)
  if (recent.length === 0) return 0
  return recent.reduce((sum, p) => sum + p.price, 0) / recent.length
}
