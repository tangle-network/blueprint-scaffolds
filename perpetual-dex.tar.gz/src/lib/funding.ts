import type { FundingRateHistory } from '@/types'

const FUNDING_INTERVAL = 8 * 3600

export function computeFundingRate(
  markPrice: number,
  indexPrice: number,
  twapMark: number,
  twapIndex: number,
  interestRate: number = 0.0001
): number {
  const premium = (twapMark - twapIndex) / twapIndex
  const clampFactor = interestRate * 3
  const clampedPremium = Math.max(-clampFactor, Math.min(clampFactor, premium))
  return interestRate + clampedPremium
}

export function annualizeFundingRate(rate: number): number {
  return rate * (365 * 24) / 8
}

export function computeFundingPayment(size: number, markPrice: number, fundingRate: number, side: 'long' | 'short'): number {
  const notional = size * markPrice
  if (side === 'long') return -notional * fundingRate
  return notional * fundingRate
}

export function getFundingRateHistory(
  baseRate: number,
  hours: number = 24
): FundingRateHistory[] {
  const now = Math.floor(Date.now() / 1000)
  const history: FundingRateHistory[] = []
  for (let i = 0; i < hours; i++) {
    const variance = (Math.random() - 0.5) * 0.0004
    const rate = baseRate + variance
    history.push({
      timestamp: now - i * FUNDING_INTERVAL,
      rate,
      annualized: annualizeFundingRate(rate),
    })
  }
  return history
}

export function getNextFundingTime(currentTime: number): number {
  const intervals = Math.floor(currentTime / FUNDING_INTERVAL)
  return (intervals + 1) * FUNDING_INTERVAL
}

export function getFundingCountdown(nextFundingTime: number): { hours: number; minutes: number; seconds: number } {
  const diff = Math.max(0, nextFundingTime - Math.floor(Date.now() / 1000))
  return {
    hours: Math.floor(diff / 3600),
    minutes: Math.floor((diff % 3600) / 60),
    seconds: diff % 60,
  }
}
