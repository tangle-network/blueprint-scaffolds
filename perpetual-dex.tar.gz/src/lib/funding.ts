import type { FundingState, PositionSide } from '@/types'

const FUNDING_INTERVAL = 8 * 3600

export function calculateFundingRate(
  markPrice: number,
  indexPrice: number,
  twapMark: number,
  twapIndex: number,
  interestRate: number = 0.0001
): number {
  const premium = (twapMark - twapIndex) / twapIndex
  const clampFactor = interestRate * 3
  const clampedPremium = Math.max(-clampFactor, Math.min(clampFactor, premium))
  return interestRate + clampedPremium
}

export function applyFunding(
  state: FundingState,
  _positions: { size: number; side: PositionSide; markPrice: number }[]
): FundingState {
  let cumulativeLong = state.cumulativeLong
  let cumulativeShort = state.cumulativeShort
  const now = Math.floor(Date.now() / 1000)
  if (now >= state.nextUpdate) {
    const periods = Math.floor((now - state.lastUpdate) / state.period)
    for (let i = 0; i < periods; i++) {
      cumulativeLong += state.currentRate
      cumulativeShort -= state.currentRate
    }
  }
  return {
    ...state,
    cumulativeLong,
    cumulativeShort,
    lastUpdate: now >= state.nextUpdate ? state.nextUpdate : state.lastUpdate,
    nextUpdate: now >= state.nextUpdate ? state.nextUpdate + state.period : state.nextUpdate,
  }
}

export function annualizeFundingRate(rate: number): number {
  return rate * (365 * 24) / 8
}

export function computeFundingPayment(size: number, markPrice: number, fundingRate: number, side: PositionSide): number {
  const notional = size * markPrice
  if (side === 'long') return -notional * fundingRate
  return notional * fundingRate
}

export function getNextFundingTime(currentTime: number): number {
  const intervals = Math.floor(currentTime / FUNDING_INTERVAL)
  return (intervals + 1) * FUNDING_INTERVAL
}

export function getFundingCountdown(nextFundingTime: number): { hours: number; minutes: number; seconds: number } {
  const diff = Math.max(0, nextFundingTime - Math.floor(Date.now() / 1000))
  return {
    hours: Math.floor(diff / 3600),
    minutes: Math.floor((diff % 3600) / 60),
    seconds: diff % 60,
  }
}
