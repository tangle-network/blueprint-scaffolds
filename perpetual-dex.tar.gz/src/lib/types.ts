export type Side = 'long' | 'short'
export type PositionSide = 'long' | 'short'
export type OrderType = 'market' | 'limit' | 'stop'
export type PositionStatus = 'open' | 'closed' | 'liquidated'
export type OrderStatus = 'pending' | 'filled' | 'cancelled'

export interface Market {
  symbol: string
  name: string
  baseAsset: string
  quoteAsset: string
  baseSymbol: string
  quoteSymbol: string
  pythPriceFeed: string
  pythPriceId: string
  decimals: number
  baseDecimals: number
  quoteDecimals: number
  minOrderSize: number
  maxLeverage: number
  initialMarginRatio: number
  maintenanceMarginRatio: number
  imrWeight: number
  fundingPeriodSec: number
  maxFundingRate: number
}

export interface MarketStats {
  markPrice: number
  indexPrice: number
  oraclePrice: number
  priceChange24h: number
  priceChangePercent24h: number
  volume24h: number
  openInterest: number
  openInterestLong: number
  openInterestShort: number
  fundingRate: number
  fundingRateAnnualized: number
  nextFundingCountdown: number
  high24h: number
  low24h: number
}

export interface MarketData extends MarketStats {
  twapPrice: number
  lastUpdated: number
}

export interface Position {
  id: string
  market: string
  side: Side
  size: number
  entryPrice: number
  markPrice: number
  leverage: number
  margin: number
  unrealizedPnl: number
  liquidationPrice: number
  status: PositionStatus
  createdAt: number
  openedAt: number
  fundingPaid: number
  fundingFeesPaid: number
  maintenanceMarginRatio: number
}

export interface Order {
  id: string
  market: string
  side: Side
  type: OrderType
  size: number
  price?: number | null
  triggerPrice?: number
  leverage: number
  status: OrderStatus
  createdAt: number
  reduceOnly: boolean
}

export interface OrderBookEntry {
  price: number
  size: number
  total: number
}

export interface OrderBook {
  bids: OrderBookEntry[]
  asks: OrderBookEntry[]
  spread: number
  midPrice: number
}

export interface CandleData {
  time: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

export interface FundingRate {
  market: string
  currentRate: number
  annualizedRate: number
  indexPrice: number
  markPrice: number
  twapMark: number
  twapIndex: number
  nextFundingTime: number
  predictedRate: number
}

export interface FundingState {
  currentRate: number
  cumulativeLong: number
  cumulativeShort: number
  lastUpdate: number
  nextUpdate: number
  period: number
}

export interface Account {
  totalEquity: number
  totalMargin: number
  availableMargin: number
  unrealizedPnl: number
  realizedPnl: number
  totalPositions: number
  marginRatio: number
  usdcBalance: number
  walletAddress: string | null
  isConnected: boolean
}

export interface AccountSummary {
  totalEquity: number
  equity: number
  totalMargin: number
  availableMargin: number
  unrealizedPnl: number
  realizedPnl: number
  totalPositions: number
  openPositionCount: number
  totalFundingFees: number
  marginRatio: number
}

export interface AMMState {
  baseReserves: number
  quoteReserves: number
  invariantK: number
  totalLongOpenInterest: number
  totalShortOpenInterest: number
}

export interface RiskMetrics {
  initialMargin: number
  maintenanceMargin: number
  marginRatio: number
  liquidationPrice: number
  maxWithdrawable: number
  isLiquidatable: boolean
}

export interface InsuranceFund {
  balance: number
  totalLiquidationPenalties: number
  totalKeeperRewards: number
  address: string
}

export interface AdlQueueEntry {
  positionId: string
  market: string
  side: Side
  size: number
  pnl: number
  leverage: number
  rank: number
}

export interface LiquidationEvent {
  positionId: string
  market: string
  side: Side
  size: number
  liquidationPrice: number
  penalty: number
  insuranceFundContribution: number
  keeperReward: number
  timestamp: number
}

export interface TradeHistoryEntry {
  id: string
  market: string
  side: Side
  size: number
  price: number
  fee: number
  pnl: number
  timestamp: number
  type: 'open' | 'close' | 'liquidation'
}

export interface GovernanceProposal {
  id: string
  title: string
  description: string
  proposer: string
  status: 'active' | 'passed' | 'failed' | 'executed' | 'pending'
  votesFor: number
  votesAgainst: number
  totalVotes: number
  quorum: number
  startTime: number
  endTime: number
  category: 'parameter' | 'market' | 'upgrade' | 'treasury'
}
