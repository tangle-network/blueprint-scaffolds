import type { AMMState } from '@/types'

export function calculateMarkPrice(state: AMMState): number {
  return state.quoteReserves / state.baseReserves
}

export function calculateEntryPrice(state: AMMState, size: number, isBuy: boolean): number {
  const spotPrice = calculateMarkPrice(state)
  const inputQuote = size * spotPrice
  let newQuoteReserves: number
  if (isBuy) {
    newQuoteReserves = state.quoteReserves + inputQuote
  } else {
    newQuoteReserves = state.quoteReserves - inputQuote
  }
  const newBaseReserves = state.invariantK / newQuoteReserves
  const outputBase = isBuy ? state.baseReserves - newBaseReserves : newBaseReserves - state.baseReserves
  return inputQuote / outputBase
}

export function calculateSpread(state: AMMState): number {
  const spotPrice = calculateMarkPrice(state)
  const halfBps = spotPrice * 0.0003
  return halfBps * 2
}

export function getTradeImpact(state: AMMState, size: number, isBuy: boolean): number {
  const spotPrice = calculateMarkPrice(state)
  const inputQuote = size * spotPrice
  let newQuoteReserves: number
  if (isBuy) {
    newQuoteReserves = state.quoteReserves + inputQuote
  } else {
    newQuoteReserves = state.quoteReserves - inputQuote
  }
  const newBaseReserves = state.invariantK / newQuoteReserves
  const outputBase = isBuy ? state.baseReserves - newBaseReserves : newBaseReserves - state.baseReserves
  const avgPrice = inputQuote / outputBase
  const priceImpact = ((avgPrice - spotPrice) / spotPrice) * 100
  return Math.abs(priceImpact)
}

export function computeSwapOutput(state: AMMState, inputQuote: number, isBuy: boolean): { outputBase: number; newPrice: number; priceImpact: number } {
  const spotPrice = calculateMarkPrice(state)
  let newQuoteReserves: number
  if (isBuy) {
    newQuoteReserves = state.quoteReserves + inputQuote
  } else {
    newQuoteReserves = state.quoteReserves - inputQuote
  }
  const newBaseReserves = state.invariantK / newQuoteReserves
  const outputBase = isBuy ? state.baseReserves - newBaseReserves : newBaseReserves - state.baseReserves
  const newPrice = newQuoteReserves / newBaseReserves
  const avgPrice = inputQuote / outputBase
  const priceImpact = ((avgPrice - spotPrice) / spotPrice) * 100
  return { outputBase, newPrice, priceImpact: Math.abs(priceImpact) }
}

export function getOpenInterestNotional(state: AMMState, price: number): { longOi: number; shortOi: number; totalOi: number } {
  const longOi = state.totalLongOpenInterest * price
  const shortOi = state.totalShortOpenInterest * price
  return { longOi, shortOi, totalOi: longOi + shortOi }
}
