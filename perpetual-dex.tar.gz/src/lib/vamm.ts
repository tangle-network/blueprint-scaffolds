import type { vAMMState } from '@/types'

export function createVamm(initialBase: number, initialQuote: number): vAMMState {
  const invariant = initialBase * initialQuote
  const price = initialQuote / initialBase
  return { baseReserve: initialBase, quoteReserve: initialQuote, totalLong: 0, totalShort: 0, invariant, price }
}

export function getSpotPrice(state: vAMMState): number {
  return state.quoteReserve / state.baseReserve
}

export function getTradePriceImpact(state: vAMMState, size: number, isBuy: boolean): number {
  const spotPrice = getSpotPrice(state)
  const newBase = isBuy ? state.baseReserve - size : state.baseReserve + size
  const newQuote = state.invariant / newBase
  const deltaQuote = isBuy ? newQuote - state.quoteReserve : state.quoteReserve - newQuote
  const avgPrice = deltaQuote / size
  return ((avgPrice - spotPrice) / spotPrice) * 100
}

export function computeSwapOutput(state: vAMMState, inputQuote: number, isBuy: boolean): { outputBase: number; newPrice: number; priceImpact: number } {
  const spotPrice = getSpotPrice(state)
  let newQuoteReserve: number
  if (isBuy) {
    newQuoteReserve = state.quoteReserve + inputQuote
  } else {
    newQuoteReserve = state.quoteReserve - inputQuote
  }
  const newBaseReserve = state.invariant / newQuoteReserve
  const outputBase = isBuy ? state.baseReserve - newBaseReserve : newBaseReserve - state.baseReserve
  const newPrice = newQuoteReserve / newBaseReserve
  const avgPrice = inputQuote / outputBase
  const priceImpact = ((avgPrice - spotPrice) / spotPrice) * 100
  return { outputBase, newPrice, priceImpact: Math.abs(priceImpact) }
}

export function getEntryPrice(state: vAMMState, size: number, isBuy: boolean): number {
  const { outputBase } = computeSwapOutput(state, size * getSpotPrice(state), isBuy)
  return (size * getSpotPrice(state)) / outputBase
}

export function getMarkTwap(prices: number[], window: number): number {
  const recent = prices.slice(-window)
  if (recent.length === 0) return 0
  return recent.reduce((a, b) => a + b, 0) / recent.length
}

export function getOpenInterestNotional(state: vAMMState, price: number): { longOi: number; shortOi: number; totalOi: number } {
  const longOi = state.totalLong * price
  const shortOi = state.totalShort * price
  return { longOi, shortOi, totalOi: longOi + shortOi }
}
