import type { CandleData } from '@/types'

export function generateBtcCandles(): CandleData[] {
  const candles: CandleData[] = []
  let price = 64200
  const now = Math.floor(Date.now() / 1000)
  for (let i = 0; i < 200; i++) {
    const time = now - (200 - i) * 3600
    const change = (Math.random() - 0.48) * 0.012
    const open = price
    price = price * (1 + change)
    const close = price
    const high = Math.max(open, close) * (1 + Math.random() * 0.004)
    const low = Math.min(open, close) * (1 - Math.random() * 0.004)
    candles.push({ time, open: Math.round(open * 100) / 100, high: Math.round(high * 100) / 100, low: Math.round(low * 100) / 100, close: Math.round(close * 100) / 100, volume: Math.random() * 800 + 200 })
  }
  return candles
}
