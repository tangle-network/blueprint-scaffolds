import { AppProvider, useApp } from '@/store/app'
import { Header } from '@/components/layout/Header'
import { MarketHeader } from '@/components/trading/MarketHeader'
import { TradingChart } from '@/components/trading/TradingChart'
import { OrderBook } from '@/components/trading/OrderBook'
import { TradePanel } from '@/components/trading/TradePanel'
import { PositionManager } from '@/components/trading/PositionManager'
import { TooltipProvider } from '@/components/ui/tooltip'

function TradingView() {
  const { state } = useApp()
  const market = state.currentMarket
  const marketData = state.marketData[market]
  const candles = state.candles[market] ?? []

  return (
    <div className="flex flex-col h-full">
      <MarketHeader />
      <div className="flex-1 flex min-h-0">
        <div className="flex-1 flex flex-col min-w-0">
          <div className="flex-1 min-h-0">
            <TradingChart candles={candles} markPrice={marketData.markPrice} />
          </div>
          <div className="border-t">
            <PositionManager />
          </div>
        </div>
        <div className="w-[320px] border-l flex flex-col shrink-0">
          <div className="flex-1 overflow-auto">
            <OrderBook midPrice={marketData.markPrice} symbol={market} />
          </div>
          <div className="border-t">
            <TradePanel />
          </div>
        </div>
      </div>
    </div>
  )
}

function AppContent() {
  return (
    <div className="flex flex-col h-screen overflow-hidden">
      <Header />
      <TradingView />
    </div>
  )
}

export default function App() {
  return (
    <TooltipProvider>
      <AppProvider>
        <AppContent />
      </AppProvider>
    </TooltipProvider>
  )
}
