export const PROGRAM_ID = 'PERP_PERP_PERP_PERP_PERP_PERP_PERP_PERP_PERP';
export const RPC_ENDPOINT = 'https://api.devnet.solana.com';
export const USDC_MINT = '4zMMC9srt5Ri5X14GAgXhaHii3GnPAEERYPJgZJDncDU';

export const DECIMALS = 6;
export const BASIS_POINTS = 10000;
export const FUNDING_RATE_INTERVAL = 3600;
export const INITIAL_MARGIN_RATIO = 500;
export const MAINTENANCE_MARGIN_RATIO = 250;
export const MAX_LEVERAGE = 20;
export const LIQUIDATION_BONUS_BPS = 500;
export const TWAP_PERIOD = 300;

export const PYTH_PRICE_FEEDS: Record<string, string> = {
  SOL: 'J83w4HKfqxwcq3BEAf6ZDUun4nKx7Qg7KmV3r2oN7dEB',
  BTC: 'GVXRSBjFk6eBE6opDtDoa7J5SQtQc2QH4KEfT4pMdLnd',
  ETH: 'EdVCmQ9FSPcVe5YySXDPCRmc8aDQLKJ9xvYBMZPie1Vw',
};
