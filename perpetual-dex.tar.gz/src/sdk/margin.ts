import type { MarketState } from '../types';
import {
  INITIAL_MARGIN_RATIO,
  MAINTENANCE_MARGIN_RATIO,
  BASIS_POINTS,
  LIQUIDATION_BONUS_BPS,
  MAX_LEVERAGE,
  TWAP_PERIOD,
} from '../config/constants';

export function calculateMarkPrice(market: MarketState): number {
  return market.vammState.markPrice;
}

export function calculateIndexPrice(market: MarketState): number {
  return market.vammState.indexPrice;
}

export function calculateSpread(market: MarketState): number {
  const { baseReserve, quoteReserve, pegMultiplier } = market.vammState;
  const k = baseReserve * quoteReserve;
  const sqrtK = Math.sqrt(k);
  const midPrice = (quoteReserve / baseReserve) * pegMultiplier;
  const spreadBps = 500;
  return midPrice * (spreadBps / BASIS_POINTS);
}

export function calculateTwap(
  prices: { price: number; timestamp: number }[],
  period: number = TWAP_PERIOD
): number {
  if (prices.length === 0) return 0;
  if (prices.length === 1) return prices[0].price;

  const now = Date.now() / 1000;
  const cutoff = now - period;
  const filtered = prices.filter((p) => p.timestamp >= cutoff);

  if (filtered.length === 0) return prices[prices.length - 1].price;
  if (filtered.length === 1) return filtered[0].price;

  let weightedSum = 0;
  let totalWeight = 0;

  for (let i = 1; i < filtered.length; i++) {
    const dt = filtered[i].timestamp - filtered[i - 1].timestamp;
    weightedSum += filtered[i - 1].price * dt;
    totalWeight += dt;
  }

  return totalWeight > 0 ? weightedSum / totalWeight : filtered[filtered.length - 1].price;
}

export function calculateFundingRate(market: MarketState): number {
  const { markPrice } = market.vammState;
  const indexPrice = market.vammState.indexPrice;
  if (indexPrice === 0) return 0;

  const premium = (markPrice - indexPrice) / indexPrice;
  const clampBound = 0.005;
  const clampedPremium = Math.max(-clampBound, Math.min(clampBound, premium));
  const interestRate = 0.0001;

  return clampedPremium + interestRate;
}

export function calculateEntryPrice(
  baseReserve: number,
  quoteReserve: number,
  pegMultiplier: number,
  sizeUsd: number,
  side: 'long' | 'short'
): number {
  const k = baseReserve * quoteReserve;

  if (side === 'long') {
    const newQuoteReserve = quoteReserve + sizeUsd / pegMultiplier;
    const newBaseReserve = k / newQuoteReserve;
    const baseAmount = baseReserve - newBaseReserve;
    return baseAmount > 0 ? sizeUsd / baseAmount : 0;
  } else {
    const newBaseReserve = baseReserve + sizeUsd / (quoteReserve / baseReserve) / pegMultiplier;
    const newQuoteReserve = k / newBaseReserve;
    const quoteAmount = quoteReserve - newQuoteReserve;
    return quoteAmount * pegMultiplier / (sizeUsd / ((quoteReserve / baseReserve) * pegMultiplier));
  }
}

export function calculateLiquidationPrice(
  entryPrice: number,
  margin: number,
  sizeUsd: number,
  side: 'long' | 'short',
  maintenanceRatio: number = MAINTENANCE_MARGIN_RATIO / BASIS_POINTS
): number {
  if (sizeUsd === 0) return 0;
  const maintenanceMargin = sizeUsd * maintenanceRatio;

  if (side === 'long') {
    const liquidationPrice = entryPrice * (1 - (margin - maintenanceMargin) / sizeUsd);
    return Math.max(0, liquidationPrice);
  } else {
    const liquidationPrice = entryPrice * (1 + (margin - maintenanceMargin) / sizeUsd);
    return liquidationPrice;
  }
}

export function calculateUnrealizedPnl(
  entryPrice: number,
  markPrice: number,
  sizeUsd: number,
  side: 'long' | 'short'
): number {
  if (entryPrice === 0) return 0;
  const priceDiff = side === 'long' ? markPrice - entryPrice : entryPrice - markPrice;
  return (priceDiff / entryPrice) * sizeUsd;
}

export function calculateMarginRatio(
  margin: number,
  sizeUsd: number,
  unrealizedPnl: number
): number {
  if (sizeUsd === 0) return 0;
  return ((margin + unrealizedPnl) / sizeUsd) * 100;
}

export function isLiquidatable(
  margin: number,
  sizeUsd: number,
  unrealizedPnl: number
): boolean {
  if (sizeUsd === 0) return false;
  const marginRatio = (margin + unrealizedPnl) / sizeUsd;
  return marginRatio < MAINTENANCE_MARGIN_RATIO / BASIS_POINTS;
}

export function calculateLeverage(margin: number, sizeUsd: number): number {
  if (margin === 0) return 0;
  return sizeUsd / margin;
}

export function validateLeverage(leverage: number): boolean {
  return leverage >= 1 && leverage <= MAX_LEVERAGE;
}

export function calculateInitialMargin(sizeUsd: number): number {
  return sizeUsd * (INITIAL_MARGIN_RATIO / BASIS_POINTS);
}

export function calculateMaintenanceMargin(sizeUsd: number): number {
  return sizeUsd * (MAINTENANCE_MARGIN_RATIO / BASIS_POINTS);
}

export function calculateLiquidationBonus(sizeUsd: number): number {
  return sizeUsd * (LIQUIDATION_BONUS_BPS / BASIS_POINTS);
}

export function calculateSlippage(
  market: MarketState,
  sizeUsd: number,
  side: 'long' | 'short'
): number {
  const { baseReserve, quoteReserve, pegMultiplier } = market.vammState;
  const k = baseReserve * quoteReserve;
  const midPrice = (quoteReserve / baseReserve) * pegMultiplier;

  if (side === 'long') {
    const newQuoteReserve = quoteReserve + sizeUsd / pegMultiplier;
    const newBaseReserve = k / newQuoteReserve;
    const baseAmount = baseReserve - newBaseReserve;
    const avgPrice = sizeUsd / baseAmount;
    return ((avgPrice - midPrice) / midPrice) * 100;
  } else {
    const newBaseReserve = baseReserve + sizeUsd / midPrice;
    const newQuoteReserve = k / newBaseReserve;
    const quoteAmount = (quoteReserve - newQuoteReserve) * pegMultiplier;
    const avgPrice = quoteAmount / (sizeUsd / midPrice);
    return ((midPrice - avgPrice) / midPrice) * 100;
  }
}
