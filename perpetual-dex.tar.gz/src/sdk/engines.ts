import type { MarketState } from '../types';
import {
  calculateFundingRate,
  calculateUnrealizedPnl,
  calculateLiquidationPrice,
  calculateLeverage,
  calculateMarginRatio,
} from './margin';

export class VammEngine {
  baseReserve: number;
  quoteReserve: number;
  pegMultiplier: number;

  constructor(baseReserve: number, quoteReserve: number, pegMultiplier: number = 1) {
    this.baseReserve = baseReserve;
    this.quoteReserve = quoteReserve;
    this.pegMultiplier = pegMultiplier;
  }

  getK(): number {
    return this.baseReserve * this.quoteReserve;
  }

  getSqrtK(): number {
    return Math.sqrt(this.getK());
  }

  getMarkPrice(): number {
    return (this.quoteReserve / this.baseReserve) * this.pegMultiplier;
  }

  swapQuoteToBase(quoteAmount: number): number {
    const k = this.getK();
    const newQuoteReserve = this.quoteReserve + quoteAmount;
    const newBaseReserve = k / newQuoteReserve;
    const baseOut = this.baseReserve - newBaseReserve;
    this.baseReserve = newBaseReserve;
    this.quoteReserve = newQuoteReserve;
    return baseOut;
  }

  swapBaseToQuote(baseAmount: number): number {
    const k = this.getK();
    const newBaseReserve = this.baseReserve + baseAmount;
    const newQuoteReserve = k / newBaseReserve;
    const quoteOut = this.quoteReserve - newQuoteReserve;
    this.baseReserve = newBaseReserve;
    this.quoteReserve = newQuoteReserve;
    return quoteOut;
  }

  getQuoteForBase(baseAmount: number): number {
    const k = this.getK();
    const newBaseReserve = this.baseReserve + baseAmount;
    const newQuoteReserve = k / newBaseReserve;
    return this.quoteReserve - newQuoteReserve;
  }

  getBaseForQuote(quoteAmount: number): number {
    const k = this.getK();
    const newQuoteReserve = this.quoteReserve + quoteAmount;
    const newBaseReserve = k / newQuoteReserve;
    return this.baseReserve - newBaseReserve;
  }
}

export class FundingEngine {
  fundingRate: number;
  cumulativePremiumFraction: number;
  nextFundingTime: number;
  periodSeconds: number;

  constructor(periodSeconds: number = 3600) {
    this.fundingRate = 0;
    this.cumulativePremiumFraction = 0;
    this.nextFundingTime = Math.floor(Date.now() / 1000) + periodSeconds;
    this.periodSeconds = periodSeconds;
  }

  updateFundingRate(market: MarketState): number {
    this.fundingRate = calculateFundingRate(market);
    return this.fundingRate;
  }

  settleFunding(): number {
    const now = Math.floor(Date.now() / 1000);
    if (now < this.nextFundingTime) return 0;

    this.cumulativePremiumFraction += this.fundingRate;
    this.nextFundingTime += this.periodSeconds;
    return this.cumulativePremiumFraction;
  }

  getFundingPayment(positionSize: number, side: 'long' | 'short'): number {
    const payment = positionSize * this.fundingRate;
    return side === 'long' ? -payment : payment;
  }
}

export class RiskEngine {
  twapPrices: { price: number; timestamp: number }[] = [];
  insuranceFundBalance: number = 0;
  maxTwapPeriod: number;

  constructor(maxTwapPeriod: number = 300) {
    this.maxTwapPeriod = maxTwapPeriod;
  }

  updateTwap(price: number): void {
    this.twapPrices.push({ price, timestamp: Date.now() / 1000 });
    const cutoff = Date.now() / 1000 - this.maxTwapPeriod;
    this.twapPrices = this.twapPrices.filter((p) => p.timestamp >= cutoff);
  }

  getTwap(): number {
    if (this.twapPrices.length === 0) return 0;
    if (this.twapPrices.length === 1) return this.twapPrices[0].price;

    let weightedSum = 0;
    let totalWeight = 0;

    for (let i = 1; i < this.twapPrices.length; i++) {
      const dt = this.twapPrices[i].timestamp - this.twapPrices[i - 1].timestamp;
      weightedSum += this.twapPrices[i - 1].price * dt;
      totalWeight += dt;
    }

    return totalWeight > 0 ? weightedSum / totalWeight : this.twapPrices[this.twapPrices.length - 1].price;
  }

  checkLiquidation(
    margin: number,
    sizeUsd: number,
    entryPrice: number,
    markPrice: number,
    side: 'long' | 'short',
    maintenanceRatio: number
  ): boolean {
    const pnl = calculateUnrealizedPnl(entryPrice, markPrice, sizeUsd, side);
    const marginRatio = (margin + pnl) / sizeUsd;
    return marginRatio < maintenanceRatio;
  }

  depositInsurance(amount: number): void {
    this.insuranceFundBalance += amount;
  }

  withdrawInsurance(amount: number): boolean {
    if (amount > this.insuranceFundBalance) return false;
    this.insuranceFundBalance -= amount;
    return true;
  }

  autoDeleverage(
    positions: { margin: number; sizeUsd: number; entryPrice: number; side: 'long' | 'short' }[],
    markPrice: number,
    deficitAmount: number
  ): { positionIndex: number; reduceBy: number }[] {
    const sorted = positions
      .map((p, i) => ({ ...p, index: i, pnl: calculateUnrealizedPnl(p.entryPrice, markPrice, p.sizeUsd, p.side) }))
      .sort((a, b) => a.pnl - b.pnl);

    const adlResults: { positionIndex: number; reduceBy: number }[] = [];
    let remaining = deficitAmount;

    for (const pos of sorted) {
      if (remaining <= 0) break;
      const reduceBy = Math.min(pos.sizeUsd, remaining);
      adlResults.push({ positionIndex: pos.index, reduceBy });
      remaining -= reduceBy;
    }

    return adlResults;
  }
}
