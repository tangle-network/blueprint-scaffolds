import { BN } from '@coral-xyz/anchor';
import {
  PublicKey,
  SystemProgram,
  TransactionInstruction,
  TransactionSignature,
  Transaction,
  Keypair,
} from '@solana/web3.js';
import {
  getAssociatedTokenAddress,
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
  createAssociatedTokenAccountInstruction,
} from '@solana/spl-token';
import { PROGRAM_ID, USDC_MINT } from '../config/constants';
import type { Position, OrderParams, MarketState } from '../types';

export class PerpSDK {
  programId: PublicKey;
  usdcMint: PublicKey;

  constructor() {
    this.programId = new PublicKey(PROGRAM_ID);
    this.usdcMint = new PublicKey(USDC_MINT);
  }

  async getMarketPda(baseSymbol: string): Promise<[PublicKey, number]> {
    return PublicKey.findProgramAddressSync(
      [Buffer.from('market'), Buffer.from(baseSymbol)],
      this.programId
    );
  }

  async getPositionPda(
    authority: PublicKey,
    market: PublicKey
  ): Promise<[PublicKey, number]> {
    return PublicKey.findProgramAddressSync(
      [Buffer.from('position'), authority.toBuffer(), market.toBuffer()],
      this.programId
    );
  }

  async getInsuranceFundPda(): Promise<[PublicKey, number]> {
    return PublicKey.findProgramAddressSync(
      [Buffer.from('insurance_fund')],
      this.programId
    );
  }

  async getVaultPda(market: PublicKey): Promise<[PublicKey, number]> {
    return PublicKey.findProgramAddressSync(
      [Buffer.from('vault'), market.toBuffer()],
      this.programId
    );
  }

  async getUserTokenAccount(authority: PublicKey): Promise<PublicKey> {
    return getAssociatedTokenAddress(this.usdcMint, authority);
  }

  async openPosition(
    authority: PublicKey,
    params: OrderParams
  ): Promise<Transaction> {
    const [marketPda] = await this.getMarketPda(params.market);
    const [positionPda] = await this.getPositionPda(authority, marketPda);
    const [vaultPda] = await this.getVaultPda(marketPda);
    const userTokenAccount = await this.getUserTokenAccount(authority);

    const tx = new Transaction();

    try {
      await getAssociatedTokenAddress(this.usdcMint, authority);
    } catch {
      tx.add(
        createAssociatedTokenAccountInstruction(
          authority,
          userTokenAccount,
          authority,
          this.usdcMint,
          TOKEN_PROGRAM_ID,
          ASSOCIATED_TOKEN_PROGRAM_ID
        )
      );
    }

    const ix = new TransactionInstruction({
      programId: this.programId,
      keys: [
        { pubkey: authority, isSigner: true, isWritable: true },
        { pubkey: marketPda, isSigner: false, isWritable: true },
        { pubkey: positionPda, isSigner: false, isWritable: true },
        { pubkey: vaultPda, isSigner: false, isWritable: true },
        { pubkey: userTokenAccount, isSigner: false, isWritable: true },
        { pubkey: this.usdcMint, isSigner: false, isWritable: false },
        { pubkey: TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
        { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
      ],
      data: Buffer.from([
        0,
        ...new BN(params.marginDelta).toArray('le', 8),
        params.side === 'long' ? 0 : 1,
        ...new BN(Math.floor(params.leverage * 100)).toArray('le', 4),
      ]),
    });

    tx.add(ix);
    return tx;
  }

  async closePosition(
    authority: PublicKey,
    market: string
  ): Promise<Transaction> {
    const [marketPda] = await this.getMarketPda(market);
    const [positionPda] = await this.getPositionPda(authority, marketPda);
    const [vaultPda] = await this.getVaultPda(marketPda);
    const userTokenAccount = await this.getUserTokenAccount(authority);

    const tx = new Transaction();
    const ix = new TransactionInstruction({
      programId: this.programId,
      keys: [
        { pubkey: authority, isSigner: true, isWritable: true },
        { pubkey: marketPda, isSigner: false, isWritable: true },
        { pubkey: positionPda, isSigner: false, isWritable: true },
        { pubkey: vaultPda, isSigner: false, isWritable: true },
        { pubkey: userTokenAccount, isSigner: false, isWritable: true },
        { pubkey: this.usdcMint, isSigner: false, isWritable: false },
        { pubkey: TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
        { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
      ],
      data: Buffer.from([1]),
    });

    tx.add(ix);
    return tx;
  }

  async addMargin(
    authority: PublicKey,
    market: string,
    marginDelta: number
  ): Promise<Transaction> {
    const [marketPda] = await this.getMarketPda(market);
    const [positionPda] = await this.getPositionPda(authority, marketPda);
    const [vaultPda] = await this.getVaultPda(marketPda);
    const userTokenAccount = await this.getUserTokenAccount(authority);

    const tx = new Transaction();
    const ix = new TransactionInstruction({
      programId: this.programId,
      keys: [
        { pubkey: authority, isSigner: true, isWritable: true },
        { pubkey: marketPda, isSigner: false, isWritable: false },
        { pubkey: positionPda, isSigner: false, isWritable: true },
        { pubkey: vaultPda, isSigner: false, isWritable: true },
        { pubkey: userTokenAccount, isSigner: false, isWritable: true },
        { pubkey: this.usdcMint, isSigner: false, isWritable: false },
        { pubkey: TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
      ],
      data: Buffer.from([2, ...new BN(marginDelta).toArray('le', 8)]),
    });

    tx.add(ix);
    return tx;
  }

  async removeMargin(
    authority: PublicKey,
    market: string,
    marginDelta: number
  ): Promise<Transaction> {
    const [marketPda] = await this.getMarketPda(market);
    const [positionPda] = await this.getPositionPda(authority, marketPda);
    const [vaultPda] = await this.getVaultPda(marketPda);
    const userTokenAccount = await this.getUserTokenAccount(authority);

    const tx = new Transaction();
    const ix = new TransactionInstruction({
      programId: this.programId,
      keys: [
        { pubkey: authority, isSigner: true, isWritable: true },
        { pubkey: marketPda, isSigner: false, isWritable: false },
        { pubkey: positionPda, isSigner: false, isWritable: true },
        { pubkey: vaultPda, isSigner: false, isWritable: true },
        { pubkey: userTokenAccount, isSigner: false, isWritable: true },
        { pubkey: this.usdcMint, isSigner: false, isWritable: false },
        { pubkey: TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
      ],
      data: Buffer.from([3, ...new BN(marginDelta).toArray('le', 8)]),
    });

    tx.add(ix);
    return tx;
  }

  async liquidate(
    keeper: PublicKey,
    positionAuthority: PublicKey,
    market: string
  ): Promise<Transaction> {
    const [marketPda] = await this.getMarketPda(market);
    const [positionPda] = await this.getPositionPda(positionAuthority, marketPda);
    const [vaultPda] = await this.getVaultPda(marketPda);
    const [insuranceFundPda] = await this.getInsuranceFundPda();
    const keeperTokenAccount = await this.getUserTokenAccount(keeper);

    const tx = new Transaction();
    const ix = new TransactionInstruction({
      programId: this.programId,
      keys: [
        { pubkey: keeper, isSigner: true, isWritable: true },
        { pubkey: positionAuthority, isSigner: false, isWritable: false },
        { pubkey: marketPda, isSigner: false, isWritable: true },
        { pubkey: positionPda, isSigner: false, isWritable: true },
        { pubkey: vaultPda, isSigner: false, isWritable: true },
        { pubkey: insuranceFundPda, isSigner: false, isWritable: true },
        { pubkey: keeperTokenAccount, isSigner: false, isWritable: true },
        { pubkey: this.usdcMint, isSigner: false, isWritable: false },
        { pubkey: TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
        { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
      ],
      data: Buffer.from([4]),
    });

    tx.add(ix);
    return tx;
  }
}

export const perpSDK = new PerpSDK();
