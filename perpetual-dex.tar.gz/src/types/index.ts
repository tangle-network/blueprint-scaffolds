export type Side = 'long' | 'short';

export type OrderType = 'market' | 'limit';

export type PositionStatus = 'open' | 'closed' | 'liquidated';

export interface MarketConfig {
  symbol: string;
  name: string;
  baseAsset: string;
  quoteAsset: string;
  pythPriceId: string;
  maxLeverage: number;
  maintenanceMarginRatio: number;
  initialMarginRatio: number;
  baseDecimals: number;
  quoteDecimals: number;
}

export interface MarketData {
  markPrice: number;
  indexPrice: number;
  oraclePrice: number;
  twapPrice: number;
  volume24h: number;
  fundingRate: number;
  fundingRateAnnualized: number;
  openInterest: number;
  openInterestLong: number;
  openInterestShort: number;
  priceChange24h: number;
  high24h: number;
  low24h: number;
  lastUpdated: number;
}

export interface Position {
  id: string;
  market: string;
  side: Side;
  size: number;
  entryPrice: number;
  markPrice: number;
  leverage: number;
  margin: number;
  unrealizedPnl: number;
  liquidationPrice: number;
  status: PositionStatus;
  createdAt: number;
  fundingPaid: number;
}

export interface Order {
  id: string;
  market: string;
  side: Side;
  type: OrderType;
  size: number;
  price?: number;
  leverage: number;
  status: 'pending' | 'filled' | 'cancelled';
  createdAt: number;
}

export interface OrderBookEntry {
  price: number;
  size: number;
  total: number;
}

export interface OrderBook {
  bids: OrderBookEntry[];
  asks: OrderBookEntry[];
  spread: number;
  midPrice: number;
}

export interface CandleData {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface FundingRateHistory {
  timestamp: number;
  rate: number;
  annualized: number;
}

export interface AccountSummary {
  totalEquity: number;
  totalMargin: number;
  availableMargin: number;
  unrealizedPnl: number;
  realizedPnl: number;
  totalPositions: number;
  marginRatio: number;
}

export interface vAMMState {
  baseReserve: number;
  quoteReserve: number;
  totalLong: number;
  totalShort: number;
  invariant: number;
  price: number;
}

export interface LiquidationEvent {
  positionId: string;
  market: string;
  side: Side;
  size: number;
  liquidationPrice: number;
  penalty: number;
  insuranceFundContribution: number;
  keeperReward: number;
  timestamp: number;
}

export interface RiskParams {
  initialMarginRatio: number;
  maintenanceMarginRatio: number;
  maxLeverage: number;
  twapWindow: number;
  liquidationPenalty: number;
  insuranceFundRatio: number;
  keeperReward: number;
}
