export interface MarketState {
  market: string;
  baseSymbol: string;
  baseDecimals: number;
  quoteDecimals: number;
  vammState: VammState;
  fundingState: FundingState;
  riskState: RiskState;
}

export interface VammState {
  baseReserve: number;
  quoteReserve: number;
  sqrtK: number;
  pegMultiplier: number;
  totalLongSize: number;
  totalShortSize: number;
  indexPrice: number;
  markPrice: number;
}

export interface FundingState {
  fundingRate: number;
  fundingRatePeriod: number;
  nextFundingTime: number;
  cumulativePremiumFraction: number;
}

export interface RiskState {
  initialMarginRatio: number;
  maintenanceMarginRatio: number;
  twapMarkPrice: number;
  insuranceFundBalance: number;
}

export interface Position {
  authority: string;
  market: string;
  size: number;
  margin: number;
  entryPrice: number;
  side: 'long' | 'short';
  unrealizedPnl: number;
  liquidationPrice: number;
  leverage: number;
  marginRatio: number;
  lastFundingTime: number;
}

export interface OrderParams {
  market: string;
  side: 'long' | 'short';
  marginDelta: number;
  leverage: number;
  sizeUsd: number;
}

export interface MarketInfo {
  symbol: string;
  price: number;
  change24h: number;
  volume24h: number;
  fundingRate: number;
  openInterest: number;
}
