import { useApp } from '@/store/app'
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { MARKET_CONFIGS } from '@/lib/constants'
import { formatPrice, formatUsd, formatNumber } from '@/lib/utils'
import { getFundingCountdown, getNextFundingTime } from '@/lib/funding'
import { TrendingUp, TrendingDown, BarChart3, Clock, DollarSign, Activity } from 'lucide-react'

export function MarketHeader() {
  const { state, selectMarket } = useApp()
  const market = state.currentMarket
  const data = state.marketData[market]
  const config = MARKET_CONFIGS.find(c => c.symbol === market)

  const funding = getFundingCountdown(getNextFundingTime(Math.floor(Date.now() / 1000)))
  const priceChangePositive = data.priceChange24h >= 0

  return (
    <div className="border-b bg-card">
      <div className="flex flex-wrap items-center gap-4 px-4 py-2">
        <Select value={market} onValueChange={selectMarket}>
          <SelectTrigger className="w-[160px] h-8">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {MARKET_CONFIGS.map(c => (
              <SelectItem key={c.symbol} value={c.symbol}>
                {c.baseAsset}/{c.quoteAsset}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <div className="flex items-baseline gap-2">
          <span className="text-2xl font-bold">{formatPrice(data.markPrice)}</span>
          <Badge variant={priceChangePositive ? 'long' : 'short'}>
            {priceChangePositive ? '+' : ''}{data.priceChange24h.toFixed(2)}%
          </Badge>
        </div>

        <div className="hidden md:flex items-center gap-6 text-xs ml-auto">
          <div className="flex items-center gap-1.5">
            <TrendingUp className="h-3.5 w-3.5 text-long" />
            <div>
              <div className="text-muted-foreground">24h High</div>
              <div>{formatPrice(data.high24h)}</div>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <TrendingDown className="h-3.5 w-3.5 text-short" />
            <div>
              <div className="text-muted-foreground">24h Low</div>
              <div>{formatPrice(data.low24h)}</div>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <BarChart3 className="h-3.5 w-3.5 text-muted-foreground" />
            <div>
              <div className="text-muted-foreground">24h Volume</div>
              <div>{formatUsd(data.volume24h)}</div>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <Activity className="h-3.5 w-3.5 text-muted-foreground" />
            <div>
              <div className="text-muted-foreground">Open Interest</div>
              <div>{formatUsd(data.openInterest)}</div>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <DollarSign className="h-3.5 w-3.5 text-muted-foreground" />
            <div>
              <div className="text-muted-foreground">Funding Rate</div>
              <div className={data.fundingRate >= 0 ? 'text-long' : 'text-short'}>
                {(data.fundingRate * 100).toFixed(4)}%
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <Clock className="h-3.5 w-3.5 text-muted-foreground" />
            <div>
              <div className="text-muted-foreground">Next Funding</div>
              <div>{funding.hours}h {funding.minutes}m</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
