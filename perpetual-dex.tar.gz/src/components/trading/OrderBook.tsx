import { useMemo } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import { generateMockOrderBook } from '@/lib/constants'
import { formatPrice, formatNumber } from '@/lib/utils'

interface OrderBookProps {
  midPrice: number
  symbol: string
}

export function OrderBook({ midPrice, symbol }: OrderBookProps) {
  const asks = useMemo(() => generateMockOrderBook(midPrice).reverse(), [midPrice])
  const bids = useMemo(() => {
    return generateMockOrderBook(midPrice).map(e => ({
      ...e,
      price: midPrice - (midPrice - e.price + midPrice * 0.0003),
    }))
  }, [midPrice])

  const maxTotal = Math.max(
    ...asks.map(a => a.total),
    ...bids.map(b => b.total)
  )

  return (
    <Card className="h-full">
      <CardHeader className="pb-2">
        <CardTitle>Order Book</CardTitle>
      </CardHeader>
      <CardContent className="px-2 pb-2">
        <div className="text-[10px] text-muted-foreground grid grid-cols-3 gap-1 px-2 mb-1">
          <span>Price (USD)</span>
          <span className="text-right">Size ({symbol.split('-')[0]})</span>
          <span className="text-right">Total</span>
        </div>
        <div className="space-y-px max-h-[200px] overflow-hidden">
          {asks.map((entry, i) => (
            <div key={`ask-${i}`} className="relative grid grid-cols-3 gap-1 px-2 py-px text-[11px]">
              <div
                className="absolute inset-0 bg-short/10"
                style={{ width: `${(entry.total / maxTotal) * 100}%`, right: 0, left: 'auto' }}
              />
              <span className="relative text-short">{formatPrice(entry.price)}</span>
              <span className="relative text-right">{formatNumber(entry.size, 4)}</span>
              <span className="relative text-right text-muted-foreground">{formatNumber(entry.total, 2)}</span>
            </div>
          ))}
        </div>
        <div className="text-center py-2 text-lg font-bold text-foreground border-y border-border my-1">
          {formatPrice(midPrice)}
        </div>
        <div className="space-y-px max-h-[200px] overflow-hidden">
          {bids.map((entry, i) => (
            <div key={`bid-${i}`} className="relative grid grid-cols-3 gap-1 px-2 py-px text-[11px]">
              <div
                className="absolute inset-0 bg-long/10"
                style={{ width: `${(entry.total / maxTotal) * 100}%`, right: 0, left: 'auto' }}
              />
              <span className="relative text-long">{formatPrice(entry.price)}</span>
              <span className="relative text-right">{formatNumber(entry.size, 4)}</span>
              <span className="relative text-right text-muted-foreground">{formatNumber(entry.total, 2)}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
