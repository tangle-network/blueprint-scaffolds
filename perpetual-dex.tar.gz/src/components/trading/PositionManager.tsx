import { useApp } from '@/store/app'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { formatPrice, formatUsd, formatNumber, formatPercent } from '@/lib/utils'
import type { Position } from '@/types'

function PositionRow({ position, onClose }: { position: Position; onClose: (id: string) => void }) {
  const pnlColor = position.unrealizedPnl >= 0 ? 'text-long' : 'text-short'

  return (
    <div className="grid grid-cols-12 gap-2 items-center py-2 text-xs">
      <div className="col-span-2">
        <div className="font-medium">{position.market}</div>
        <Badge variant={position.side === 'long' ? 'long' : 'short'} className="mt-0.5 text-[10px]">
          {position.side.toUpperCase()} {position.leverage}x
        </Badge>
      </div>
      <div className="col-span-1 text-right">
        <div>{formatNumber(position.size, 4)}</div>
      </div>
      <div className="col-span-1 text-right">
        <div>{formatPrice(position.markPrice)}</div>
      </div>
      <div className="col-span-1 text-right">
        <div>{formatPrice(position.entryPrice)}</div>
      </div>
      <div className="col-span-1 text-right">
        <div>{formatPrice(position.liquidationPrice)}</div>
      </div>
      <div className="col-span-2 text-right">
        <div className={pnlColor + ' font-medium'}>
          {position.unrealizedPnl >= 0 ? '+' : ''}{formatUsd(position.unrealizedPnl)}
        </div>
        <div className="text-muted-foreground">
          {formatUsd(position.margin)} margin
        </div>
      </div>
      <div className="col-span-1 text-right text-muted-foreground">
        {position.fundingPaid >= 0 ? '+' : ''}{formatNumber(position.fundingPaid, 2)}
      </div>
      <div className="col-span-3 text-right">
        <Button
          variant="destructive"
          size="sm"
          className="h-7 text-xs"
          onClick={() => onClose(position.id)}
        >
          Close
        </Button>
      </div>
    </div>
  )
}

export function PositionManager() {
  const { state, closePosition } = useApp()
  const openPositions = state.positions.filter(p => p.status === 'open')

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle>Positions ({openPositions.length})</CardTitle>
          <div className="flex gap-4 text-xs">
            <div>
              <span className="text-muted-foreground">Total Unrealized PnL: </span>
              <span className={state.account.unrealizedPnl >= 0 ? 'text-long' : 'text-short'}>
                {state.account.unrealizedPnl >= 0 ? '+' : ''}{formatUsd(state.account.unrealizedPnl)}
              </span>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {openPositions.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground text-sm">
            No open positions
          </div>
        ) : (
          <>
            <div className="grid grid-cols-12 gap-2 text-[10px] text-muted-foreground pb-1 border-b">
              <div className="col-span-2">Market</div>
              <div className="col-span-1 text-right">Size</div>
              <div className="col-span-1 text-right">Mark</div>
              <div className="col-span-1 text-right">Entry</div>
              <div className="col-span-1 text-right">Liq. Price</div>
              <div className="col-span-2 text-right">Unrealized PnL</div>
              <div className="col-span-1 text-right">Funding</div>
              <div className="col-span-3 text-right">Action</div>
            </div>
            <div className="divide-y divide-border">
              {openPositions.map(pos => (
                <PositionRow key={pos.id} position={pos} onClose={closePosition} />
              ))}
            </div>
          </>
        )}
        <Separator className="my-3" />
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div>
            <div className="text-muted-foreground">Total Equity</div>
            <div className="font-medium">{formatUsd(state.account.totalEquity)}</div>
          </div>
          <div>
            <div className="text-muted-foreground">Margin Used</div>
            <div className="font-medium">{formatUsd(state.account.totalMargin)}</div>
          </div>
          <div>
            <div className="text-muted-foreground">Available</div>
            <div className="font-medium">{formatUsd(state.account.availableMargin)}</div>
          </div>
          <div>
            <div className="text-muted-foreground">Realized PnL</div>
            <div className={`font-medium ${state.account.realizedPnl >= 0 ? 'text-long' : 'text-short'}`}>
              {state.account.realizedPnl >= 0 ? '+' : ''}{formatUsd(state.account.realizedPnl)}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
