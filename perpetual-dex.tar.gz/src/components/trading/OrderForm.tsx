import { useState, useMemo } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Slider } from '@/components/ui/slider'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useTradingStore } from '@/store/trading-store'
import { MARKET_CONFIGS, PROTOCOL_CONSTANTS } from '@/lib/constants'
import { formatPrice, formatUsd } from '@/lib/utils'

export function OrderForm() {
  const selectedMarket = useTradingStore(s => s.selectedMarket)
  const marketData = useTradingStore(s => s.marketData)
  const account = useTradingStore(s => s.account)
  const openPosition = useTradingStore(s => s.openPosition)
  const isConnected = useTradingStore(s => s.isConnected)

  const config = MARKET_CONFIGS.find(c => c.symbol === selectedMarket)
  const maxLeverage = config?.maxLeverage ?? 20
  const mmr = config?.maintenanceMarginRatio ?? 0.065
  const data = marketData[selectedMarket]

  const [side, setSide] = useState<'long' | 'short'>('long')
  const [size, setSize] = useState('')
  const [leverage, setLeverage] = useState(10)
  const [orderType, setOrderType] = useState<'market' | 'limit' | 'stop'>('market')
  const [limitPrice, setLimitPrice] = useState('')
  const [triggerPrice, setTriggerPrice] = useState('')
  const [sizeUnit, setSizeUnit] = useState<'asset' | 'usd'>('asset')

  const sizeNum = parseFloat(size) || 0
  const price = orderType === 'limit' && limitPrice ? parseFloat(limitPrice) || data.markPrice : data.markPrice
  const sizeInUnits = sizeUnit === 'usd' ? sizeNum / price : sizeNum
  const notional = sizeInUnits * price
  const marginRequired = notional / leverage
  const estimatedFee = notional * PROTOCOL_CONSTANTS.takerFeeRate
  const estLiqPrice = price * (side === 'long' ? 1 - 1 / leverage + mmr : 1 + 1 / leverage - mmr)

  const leverageOptions = useMemo(() => {
    return [1, 2, 3, 5, 10, 15, 20].filter(l => l <= maxLeverage)
  }, [maxLeverage])

  function handleSubmit() {
    if (sizeInUnits <= 0 || marginRequired <= 0) return
    openPosition(selectedMarket, side, sizeInUnits, leverage, marginRequired)
    setSize('')
    setLimitPrice('')
    setTriggerPrice('')
  }

  const setPercentSize = (pct: number) => {
    const available = account.availableMargin
    const maxSizeUsd = available * leverage * pct
    if (sizeUnit === 'usd') {
      setSize(maxSizeUsd > 0 ? maxSizeUsd.toFixed(2) : '')
    } else {
      const maxSizeUnits = maxSizeUsd / price
      setSize(maxSizeUnits > 0 ? maxSizeUnits.toFixed(4) : '')
    }
  }

  return (
    <Card className="h-full">
      <CardHeader className="pb-2">
        <CardTitle>Place Order</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <Tabs value={orderType} onValueChange={v => setOrderType(v as 'market' | 'limit' | 'stop')}>
          <TabsList className="w-full">
            <TabsTrigger value="market" className="flex-1">Market</TabsTrigger>
            <TabsTrigger value="limit" className="flex-1">Limit</TabsTrigger>
            <TabsTrigger value="stop" className="flex-1">Stop</TabsTrigger>
          </TabsList>
        </Tabs>

        {orderType === 'limit' && (
          <div>
            <label className="text-xs text-muted-foreground">Limit Price (USDC)</label>
            <Input
              type="number"
              placeholder="0.00"
              value={limitPrice}
              onChange={e => setLimitPrice(e.target.value)}
              className="mt-1"
            />
          </div>
        )}

        {orderType === 'stop' && (
          <div>
            <label className="text-xs text-muted-foreground">Trigger Price (USDC)</label>
            <Input
              type="number"
              placeholder="0.00"
              value={triggerPrice}
              onChange={e => setTriggerPrice(e.target.value)}
              className="mt-1"
            />
          </div>
        )}

        <div>
          <label className="text-xs text-muted-foreground">Side</label>
          <div className="grid grid-cols-2 gap-2 mt-1">
            <Button
              variant={side === 'long' ? 'long' : 'outline'}
              size="sm"
              onClick={() => setSide('long')}
              className="w-full"
            >
              Long
            </Button>
            <Button
              variant={side === 'short' ? 'short' : 'outline'}
              size="sm"
              onClick={() => setSide('short')}
              className="w-full"
            >
              Short
            </Button>
          </div>
        </div>

        <div>
          <div className="flex justify-between">
            <label className="text-xs text-muted-foreground">
              Size ({sizeUnit === 'asset' ? config?.baseAsset : 'USDC'})
            </label>
            <button
              className="text-[10px] text-primary hover:underline"
              onClick={() => setSizeUnit(u => u === 'asset' ? 'usd' : 'asset')}
            >
              Switch to {sizeUnit === 'asset' ? 'USD' : config?.baseAsset}
            </button>
          </div>
          <Input
            type="number"
            placeholder="0.00"
            value={size}
            onChange={e => setSize(e.target.value)}
            className="mt-1"
          />
          <div className="flex gap-1 mt-1">
            {[25, 50, 75, 100].map(pct => (
              <Button key={pct} variant="outline" size="sm" className="flex-1 text-xs h-6" onClick={() => setPercentSize(pct / 100)}>
                {pct}%
              </Button>
            ))}
          </div>
        </div>

        <div>
          <div className="flex justify-between">
            <label className="text-xs text-muted-foreground">Leverage</label>
            <span className="text-xs font-medium">{leverage}x</span>
          </div>
          <Slider
            value={[leverage]}
            onValueChange={([v]) => setLeverage(v)}
            min={1}
            max={maxLeverage}
            step={1}
            className="mt-2"
          />
          <div className="flex gap-1 mt-1">
            {leverageOptions.map(l => (
              <Button
                key={l}
                variant={leverage === l ? 'default' : 'outline'}
                size="sm"
                className="flex-1 text-xs h-6 px-1"
                onClick={() => setLeverage(l)}
              >
                {l}x
              </Button>
            ))}
          </div>
        </div>

        <div className="space-y-1 text-xs">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Notional Value</span>
            <span>{formatUsd(notional)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Margin Required</span>
            <span>{formatUsd(marginRequired)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Est. Fee ({(PROTOCOL_CONSTANTS.takerFeeRate * 100).toFixed(2)}%)</span>
            <span>{formatUsd(estimatedFee)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Est. Liq. Price</span>
            <span className="text-destructive">{formatPrice(estLiqPrice)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Max Leverage</span>
            <span>{maxLeverage}x</span>
          </div>
        </div>

        <Button
          variant={side === 'long' ? 'long' : 'short'}
          className="w-full"
          size="lg"
          onClick={handleSubmit}
          disabled={sizeInUnits <= 0 || !isConnected}
        >
          {!isConnected ? 'Connect Wallet' : side === 'long' ? 'Open Long' : 'Open Short'}
        </Button>

        <div className="text-xs text-muted-foreground text-center">
          Available: {formatUsd(account.availableMargin)} USDC
        </div>
      </CardContent>
    </Card>
  )
}
