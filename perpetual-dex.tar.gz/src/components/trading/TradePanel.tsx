import { useState, useMemo } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Slider } from '@/components/ui/slider'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { useApp } from '@/store/app'
import { MARKET_CONFIGS } from '@/lib/constants'
import { formatPrice, formatUsd, formatNumber } from '@/lib/utils'

export function TradePanel() {
  const { state, openPosition } = useApp()
  const market = state.currentMarket
  const marketData = state.marketData[market]
  const config = MARKET_CONFIGS.find(c => c.symbol === market)
  const maxLeverage = config?.maxLeverage ?? 20

  const [side, setSide] = useState<'long' | 'short'>('long')
  const [size, setSize] = useState('')
  const [leverage, setLeverage] = useState(10)
  const [orderType, setOrderType] = useState<'market' | 'limit'>('market')
  const [limitPrice, setLimitPrice] = useState('')

  const sizeNum = parseFloat(size) || 0
  const notional = sizeNum * marketData.markPrice
  const marginRequired = notional / leverage

  const estimatedFee = notional * 0.0005
  const estimatedEntry = marketData.markPrice
  const estLiqPrice = estimatedEntry * (side === 'long'
    ? 1 - 1 / leverage + 0.025
    : 1 + 1 / leverage - 0.025)

  const leverageOptions = useMemo(() => {
    const opts = [1, 2, 3, 5, 10, 15, 20]
    return opts.filter(l => l <= maxLeverage)
  }, [maxLeverage])

  function handleSubmit() {
    if (sizeNum <= 0 || marginRequired <= 0) return
    openPosition(market, side, sizeNum, leverage, marginRequired)
    setSize('')
  }

  const setPercentSize = (pct: number) => {
    const available = state.account.availableMargin
    const maxSize = (available * leverage * pct) / marketData.markPrice
    setSize(maxSize > 0 ? maxSize.toFixed(4) : '')
  }

  return (
    <Card className="h-full">
      <CardHeader className="pb-2">
        <CardTitle>Trade</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <Tabs value={orderType} onValueChange={v => setOrderType(v as 'market' | 'limit')}>
          <TabsList className="w-full">
            <TabsTrigger value="market" className="flex-1">Market</TabsTrigger>
            <TabsTrigger value="limit" className="flex-1">Limit</TabsTrigger>
          </TabsList>
        </Tabs>

        {orderType === 'limit' && (
          <div>
            <label className="text-xs text-muted-foreground">Limit Price</label>
            <Input
              type="number"
              placeholder="0.00"
              value={limitPrice}
              onChange={e => setLimitPrice(e.target.value)}
              className="mt-1"
            />
          </div>
        )}

        <div>
          <label className="text-xs text-muted-foreground">Side</label>
          <div className="grid grid-cols-2 gap-2 mt-1">
            <Button
              variant={side === 'long' ? 'long' : 'outline'}
              size="sm"
              onClick={() => setSide('long')}
              className="w-full"
            >
              Long
            </Button>
            <Button
              variant={side === 'short' ? 'short' : 'outline'}
              size="sm"
              onClick={() => setSide('short')}
              className="w-full"
            >
              Short
            </Button>
          </div>
        </div>

        <div>
          <div className="flex justify-between">
            <label className="text-xs text-muted-foreground">Size ({config?.baseAsset})</label>
            <span className="text-xs text-muted-foreground">
              ≈ {formatUsd(notional)}
            </span>
          </div>
          <Input
            type="number"
            placeholder="0.00"
            value={size}
            onChange={e => setSize(e.target.value)}
            className="mt-1"
          />
          <div className="flex gap-1 mt-1">
            {[25, 50, 75, 100].map(pct => (
              <Button key={pct} variant="outline" size="sm" className="flex-1 text-xs h-6" onClick={() => setPercentSize(pct / 100)}>
                {pct}%
              </Button>
            ))}
          </div>
        </div>

        <div>
          <div className="flex justify-between">
            <label className="text-xs text-muted-foreground">Leverage</label>
            <span className="text-xs font-medium">{leverage}x</span>
          </div>
          <Slider
            value={[leverage]}
            onValueChange={([v]) => setLeverage(v)}
            min={1}
            max={maxLeverage}
            step={1}
            className="mt-2"
          />
          <div className="flex gap-1 mt-1">
            {leverageOptions.map(l => (
              <Button
                key={l}
                variant={leverage === l ? 'default' : 'outline'}
                size="sm"
                className="flex-1 text-xs h-6 px-1"
                onClick={() => setLeverage(l)}
              >
                {l}x
              </Button>
            ))}
          </div>
        </div>

        <div className="space-y-1 text-xs">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Margin Required</span>
            <span>{formatUsd(marginRequired)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Est. Fee</span>
            <span>{formatUsd(estimatedFee)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Est. Liq. Price</span>
            <span>{formatPrice(estLiqPrice)}</span>
          </div>
        </div>

        <Button
          variant={side === 'long' ? 'long' : 'short'}
          className="w-full"
          size="lg"
          onClick={handleSubmit}
          disabled={sizeNum <= 0}
        >
          {side === 'long' ? 'Open Long' : 'Open Short'}
        </Button>

        <div className="text-xs text-muted-foreground text-center">
          Available: {formatUsd(state.account.availableMargin)} USDC
        </div>
      </CardContent>
    </Card>
  )
}
