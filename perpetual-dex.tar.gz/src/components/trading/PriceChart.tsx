import { useEffect, useRef, useState } from 'react'
import { createChart, type IChartApi, type ISeriesApi, ColorType } from 'lightweight-charts'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useTradingStore } from '@/store/trading-store'
import { generateMockCandles, DEFAULT_VAMM } from '@/lib/constants'
import { formatPrice, formatNumber } from '@/lib/utils'
import type { CandleData } from '@/types'

const TIMEFRAMES = ['1m', '5m', '15m', '1h', '4h', '1d'] as const

export function PriceChart() {
  const selectedMarket = useTradingStore(s => s.selectedMarket)
  const marketData = useTradingStore(s => s.marketData)
  const [timeframe, setTimeframe] = useState<string>('1h')

  const containerRef = useRef<HTMLDivElement>(null)
  const chartRef = useRef<IChartApi | null>(null)
  const seriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null)

  const data = marketData[selectedMarket]
  const basePrice = DEFAULT_VAMM[selectedMarket]?.price ?? 67500
  const candles = generateMockCandles(basePrice)
  const lastCandle = candles[candles.length - 1]

  useEffect(() => {
    if (!containerRef.current) return

    const chart = createChart(containerRef.current, {
      layout: {
        background: { type: ColorType.Solid, color: 'transparent' },
        textColor: '#9ca3af',
      },
      grid: {
        vertLines: { color: 'rgba(42, 46, 57, 0.3)' },
        horzLines: { color: 'rgba(42, 46, 57, 0.3)' },
      },
      width: containerRef.current.clientWidth,
      height: containerRef.current.clientHeight,
      timeScale: {
        timeVisible: true,
        secondsVisible: false,
        borderColor: 'rgba(42, 46, 57, 0.5)',
      },
      rightPriceScale: {
        borderColor: 'rgba(42, 46, 57, 0.5)',
      },
      crosshair: { mode: 0 },
    })

    const series = chart.addCandlestickSeries({
      upColor: '#22c55e',
      downColor: '#ef4444',
      borderUpColor: '#22c55e',
      borderDownColor: '#ef4444',
      wickUpColor: '#22c55e',
      wickDownColor: '#ef4444',
    })

    chartRef.current = chart
    seriesRef.current = series

    const handleResize = () => {
      if (containerRef.current) {
        chart.applyOptions({
          width: containerRef.current.clientWidth,
          height: containerRef.current.clientHeight,
        })
      }
    }
    window.addEventListener('resize', handleResize)
    return () => {
      window.removeEventListener('resize', handleResize)
      chart.remove()
    }
  }, [])

  useEffect(() => {
    if (seriesRef.current && candles.length > 0) {
      seriesRef.current.setData(candles as never[])
    }
  }, [candles, selectedMarket])

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-2 flex-shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <CardTitle>{selectedMarket}</CardTitle>
            {lastCandle && (
              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <span>O: {formatPrice(lastCandle.open)}</span>
                <span>H: {formatPrice(lastCandle.high)}</span>
                <span>L: {formatPrice(lastCandle.low)}</span>
                <span>C: {formatPrice(lastCandle.close)}</span>
                <span>Vol: {formatNumber(lastCandle.volume, 0)}</span>
              </div>
            )}
          </div>
          <Tabs value={timeframe} onValueChange={setTimeframe}>
            <TabsList className="h-7">
              {TIMEFRAMES.map(tf => (
                <TabsTrigger key={tf} value={tf} className="text-[10px] px-2 h-5">
                  {tf}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
        </div>
      </CardHeader>
      <CardContent className="flex-1 min-h-0 p-0">
        <div ref={containerRef} className="w-full h-full min-h-[300px]" />
      </CardContent>
    </Card>
  )
}
