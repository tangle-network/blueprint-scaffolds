import { useTradingStore } from '@/store/trading-store'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { MARKET_CONFIGS } from '@/lib/constants'
import { formatPrice } from '@/lib/utils'

export function MarketSelector() {
  const selectedMarket = useTradingStore(s => s.selectedMarket)
  const marketData = useTradingStore(s => s.marketData)
  const fundingRates = useTradingStore(s => s.fundingRates)
  const selectMarket = useTradingStore(s => s.selectMarket)

  return (
    <div className="border-b bg-card">
      <Tabs value={selectedMarket} onValueChange={selectMarket}>
        <TabsList className="w-full justify-start rounded-none border-b bg-transparent p-0">
          {MARKET_CONFIGS.map(config => {
            const data = marketData[config.symbol]
            const funding = fundingRates[config.symbol]
            const priceChange = data?.priceChange24h ?? 0
            return (
              <TabsTrigger
                key={config.symbol}
                value={config.symbol}
                className="relative rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none px-4 py-2"
              >
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-sm">{config.baseAsset}-{config.quoteAsset}</span>
                  <span className="text-sm tabular-nums">{data ? formatPrice(data.markPrice) : '—'}</span>
                  <Badge
                    variant={priceChange >= 0 ? 'long' : 'short'}
                    className="text-[10px] px-1.5 py-0"
                  >
                    {priceChange >= 0 ? '+' : ''}{priceChange.toFixed(2)}%
                  </Badge>
                  {funding && (
                    <span className={`text-[10px] ${funding.currentRate >= 0 ? 'text-long' : 'text-short'}`}>
                      {(funding.currentRate * 100).toFixed(4)}%
                    </span>
                  )}
                </div>
              </TabsTrigger>
            )
          })}
        </TabsList>
      </Tabs>
    </div>
  )
}
