import { useApp } from '@/store/app'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { shortenAddress, formatUsd } from '@/lib/utils'
import { Wallet, LogOut, BarChart2, Zap } from 'lucide-react'

export function Header() {
  const { state, connectWallet, disconnectWallet } = useApp()

  return (
    <header className="border-b bg-card">
      <div className="flex items-center justify-between px-4 h-12">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-primary" />
            <span className="font-bold text-lg">PerpDEX</span>
          </div>
          <Badge variant="muted" className="text-[10px]">Solana</Badge>
          <div className="hidden sm:flex items-center gap-1 text-xs text-muted-foreground ml-4">
            <BarChart2 className="h-3.5 w-3.5" />
            <span>vAMM Perpetual Futures</span>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {state.walletConnected ? (
            <>
              <div className="hidden sm:flex items-center gap-2 text-xs">
                <span className="text-muted-foreground">Balance:</span>
                <span className="font-medium">{formatUsd(state.account.totalEquity)}</span>
                <span className="text-muted-foreground">USDC</span>
              </div>
              <Badge variant="outline" className="gap-1.5">
                <div className="h-2 w-2 rounded-full bg-long" />
                {shortenAddress(state.walletAddress!)}
              </Badge>
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={disconnectWallet}>
                <LogOut className="h-4 w-4" />
              </Button>
            </>
          ) : (
            <Button size="sm" onClick={connectWallet} className="gap-2">
              <Wallet className="h-4 w-4" />
              Connect Wallet
            </Button>
          )}
        </div>
      </div>
    </header>
  )
}
