import { create } from 'zustand'
import type {
  Position,
  Order,
  Account,
  FundingRate,
  MarketData,
  OrderBook,
  Side,
  OrderType,
  InsuranceFund,
  AdlQueueEntry,
  LiquidationEvent,
  TradeHistoryEntry,
} from '@/types'
import {
  MOCK_POSITIONS,
  MOCK_ORDERS,
  MOCK_ACCOUNT,
  MOCK_FUNDING_RATES,
  MOCK_INSURANCE_FUND,
  MOCK_ADL_QUEUE,
  MOCK_LIQUIDATION_HISTORY,
  MOCK_TRADE_HISTORY,
  generateMockOrderBook,
} from '@/lib/mock-data'
import {
  MARKET_CONFIGS,
  DEFAULT_VAMM,
  generateMockMarketData,
  generateMockCandles,
} from '@/lib/constants'
import { getUnrealizedPnl } from '@/lib/risk'

interface TradingState {
  selectedMarket: string
  positions: Position[]
  orders: Order[]
  account: Account
  markPrices: Record<string, number>
  marketData: Record<string, MarketData>
  fundingRates: Record<string, FundingRate>
  orderBooks: Record<string, OrderBook>
  insuranceFund: InsuranceFund
  adlQueue: AdlQueueEntry[]
  liquidationHistory: LiquidationEvent[]
  tradeHistory: TradeHistoryEntry[]
  isConnected: boolean
}

interface TradingActions {
  selectMarket: (market: string) => void
  openPosition: (market: string, side: Side, size: number, leverage: number, margin: number) => void
  closePosition: (positionId: string) => void
  updateMarkPrice: (market: string, price: number) => void
  connectWallet: () => void
  disconnectWallet: () => void
  placeOrder: (market: string, side: Side, type: OrderType, size: number, leverage: number, price?: number, triggerPrice?: number) => void
  cancelOrder: (orderId: string) => void
}

const initialMarketData: Record<string, MarketData> = {}
const initialMarkPrices: Record<string, number> = {}

for (const config of MARKET_CONFIGS) {
  initialMarketData[config.symbol] = generateMockMarketData(config.symbol)
  initialMarkPrices[config.symbol] = DEFAULT_VAMM[config.symbol].price
}

const initialOrderBooks: Record<string, OrderBook> = {}
for (const config of MARKET_CONFIGS) {
  initialOrderBooks[config.symbol] = generateMockOrderBook(DEFAULT_VAMM[config.symbol].price)
}

export const useTradingStore = create<TradingState & TradingActions>((set, get) => ({
  selectedMarket: 'BTC-PERP',
  positions: MOCK_POSITIONS,
  orders: MOCK_ORDERS,
  account: MOCK_ACCOUNT,
  markPrices: initialMarkPrices,
  marketData: initialMarketData,
  fundingRates: MOCK_FUNDING_RATES,
  orderBooks: initialOrderBooks,
  insuranceFund: MOCK_INSURANCE_FUND,
  adlQueue: MOCK_ADL_QUEUE,
  liquidationHistory: MOCK_LIQUIDATION_HISTORY,
  tradeHistory: MOCK_TRADE_HISTORY,
  isConnected: false,

  selectMarket: (market) => set({ selectedMarket: market }),

  openPosition: (market, side, size, leverage, margin) => {
    const state = get()
    const marketData = state.marketData[market]
    const entryPrice = marketData.markPrice
    const config = MARKET_CONFIGS.find(c => c.symbol === market)
    const mmr = config?.maintenanceMarginRatio ?? 0.065
    const position: Position = {
      id: `pos-${Date.now()}`,
      market,
      side,
      size,
      entryPrice,
      markPrice: entryPrice,
      leverage,
      margin,
      unrealizedPnl: 0,
      liquidationPrice: entryPrice * (side === 'long' ? 1 - 1 / leverage + mmr : 1 + 1 / leverage - mmr),
      status: 'open',
      createdAt: Date.now(),
      fundingPaid: 0,
      maintenanceMarginRatio: mmr,
    }
    const newPositions = [...state.positions, position]
    const totalMargin = newPositions.reduce((s, p) => s + p.margin, 0)
    const unrealizedPnl = newPositions.reduce(
      (s, p) => s + getUnrealizedPnl(p.entryPrice, state.marketData[p.market]?.markPrice ?? p.markPrice, p.size, p.side),
      0
    )
    set({
      positions: newPositions,
      account: {
        ...state.account,
        totalPositions: newPositions.filter(p => p.status === 'open').length,
        totalMargin,
        unrealizedPnl,
        availableMargin: state.account.totalEquity - totalMargin,
      },
    })
  },

  closePosition: (positionId) => {
    const state = get()
    const pos = state.positions.find(p => p.id === positionId)
    if (!pos) return
    const pnl = getUnrealizedPnl(pos.entryPrice, pos.markPrice, pos.size, pos.side)
    const newPositions = state.positions.map(p =>
      p.id === positionId ? { ...p, status: 'closed' as const } : p
    )
    set({
      positions: newPositions,
      account: {
        ...state.account,
        realizedPnl: state.account.realizedPnl + pnl,
        totalPositions: newPositions.filter(p => p.status === 'open').length,
      },
    })
  },

  updateMarkPrice: (market, price) => {
    const state = get()
    set({
      markPrices: { ...state.markPrices, [market]: price },
      marketData: {
        ...state.marketData,
        [market]: { ...state.marketData[market], markPrice: price, lastUpdated: Date.now() },
      },
    })
  },

  connectWallet: () => {
    const addr = '7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU'
    set({
      isConnected: true,
      account: { ...get().account, isConnected: true, walletAddress: addr },
    })
  },

  disconnectWallet: () => {
    set({
      isConnected: false,
      account: { ...get().account, isConnected: false, walletAddress: null },
    })
  },

  placeOrder: (market, side, type, size, leverage, price, triggerPrice) => {
    const state = get()
    const order: Order = {
      id: `ord-${Date.now()}`,
      market,
      side,
      type,
      size,
      price,
      triggerPrice,
      leverage,
      status: 'pending',
      createdAt: Date.now(),
      reduceOnly: false,
    }
    set({ orders: [...state.orders, order] })
  },

  cancelOrder: (orderId) => {
    const state = get()
    set({
      orders: state.orders.map(o =>
        o.id === orderId ? { ...o, status: 'cancelled' as const } : o
      ),
    })
  },
}))
