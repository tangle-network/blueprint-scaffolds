import { createContext, useContext, useReducer, type ReactNode, useCallback } from 'react'
import type { MarketData, Position, AccountSummary, Side, vAMMState } from '@/types'
import {
  generateMockMarketData,
  generateMockPositions,
  generateMockAccountSummary,
  generateMockCandles,
  MARKET_CONFIGS,
  DEFAULT_VAMM,
} from '@/lib/constants'
import type { CandleData } from '@/types'
import { getUnrealizedPnl } from '@/lib/risk'

interface AppState {
  currentMarket: string
  marketData: Record<string, MarketData>
  positions: Position[]
  account: AccountSummary
  candles: Record<string, CandleData[]>
  vammStates: Record<string, vAMMState>
  walletConnected: boolean
  walletAddress: string | null
}

type Action =
  | { type: 'SET_MARKET'; market: string }
  | { type: 'UPDATE_MARKET_DATA'; symbol: string; data: MarketData }
  | { type: 'UPDATE_CANDLES'; symbol: string; candles: CandleData[] }
  | { type: 'OPEN_POSITION'; position: Position }
  | { type: 'CLOSE_POSITION'; positionId: string }
  | { type: 'UPDATE_POSITION'; positionId: string; updates: Partial<Position> }
  | { type: 'UPDATE_ACCOUNT'; account: Partial<AccountSummary> }
  | { type: 'CONNECT_WALLET'; address: string }
  | { type: 'DISCONNECT_WALLET' }
  | { type: 'UPDATE_VAMM'; symbol: string; state: vAMMState }

const initialMarketData: Record<string, MarketData> = {}
const initialCandles: Record<string, CandleData[]> = {}

for (const config of MARKET_CONFIGS) {
  initialMarketData[config.symbol] = generateMockMarketData(config.symbol)
  initialCandles[config.symbol] = generateMockCandles(DEFAULT_VAMM[config.symbol].price)
}

const initialState: AppState = {
  currentMarket: 'SOL-PERP',
  marketData: initialMarketData,
  positions: generateMockPositions(),
  account: generateMockAccountSummary(),
  candles: initialCandles,
  vammStates: { ...DEFAULT_VAMM },
  walletConnected: false,
  walletAddress: null,
}

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'SET_MARKET':
      return { ...state, currentMarket: action.market }
    case 'UPDATE_MARKET_DATA':
      return { ...state, marketData: { ...state.marketData, [action.symbol]: action.data } }
    case 'UPDATE_CANDLES':
      return { ...state, candles: { ...state.candles, [action.symbol]: action.candles } }
    case 'OPEN_POSITION':
      return { ...state, positions: [...state.positions, action.position] }
    case 'CLOSE_POSITION':
      return {
        ...state,
        positions: state.positions.map(p =>
          p.id === action.positionId ? { ...p, status: 'closed' as const } : p
        ),
      }
    case 'UPDATE_POSITION':
      return {
        ...state,
        positions: state.positions.map(p =>
          p.id === action.positionId ? { ...p, ...action.updates } : p
        ),
      }
    case 'UPDATE_ACCOUNT':
      return { ...state, account: { ...state.account, ...action.account } }
    case 'CONNECT_WALLET':
      return { ...state, walletConnected: true, walletAddress: action.address }
    case 'DISCONNECT_WALLET':
      return { ...state, walletConnected: false, walletAddress: null }
    case 'UPDATE_VAMM':
      return { ...state, vammStates: { ...state.vammStates, [action.symbol]: action.state } }
    default:
      return state
  }
}

interface AppContextType {
  state: AppState
  dispatch: React.Dispatch<Action>
  selectMarket: (market: string) => void
  openPosition: (market: string, side: Side, size: number, leverage: number, margin: number) => void
  closePosition: (positionId: string) => void
  connectWallet: () => void
  disconnectWallet: () => void
}

const AppContext = createContext<AppContextType | null>(null)

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState)

  const selectMarket = useCallback((market: string) => {
    dispatch({ type: 'SET_MARKET', market })
  }, [])

  const openPosition = useCallback(
    (market: string, side: Side, size: number, leverage: number, margin: number) => {
      const marketData = state.marketData[market]
      const entryPrice = marketData.markPrice
      const position: Position = {
        id: `pos-${Date.now()}`,
        market,
        side,
        size,
        entryPrice,
        markPrice: entryPrice,
        leverage,
        margin,
        unrealizedPnl: 0,
        liquidationPrice: entryPrice * (side === 'long' ? 1 - 1 / leverage + 0.025 : 1 + 1 / leverage - 0.025),
        status: 'open',
        createdAt: Date.now(),
        fundingPaid: 0,
      }
      dispatch({ type: 'OPEN_POSITION', position })

      const positions = [...state.positions, position]
      const totalMargin = positions.reduce((s, p) => s + p.margin, 0)
      const unrealizedPnl = positions.reduce(
        (s, p) => s + getUnrealizedPnl(p.entryPrice, state.marketData[p.market]?.markPrice ?? p.markPrice, p.size, p.side),
        0
      )
      dispatch({
        type: 'UPDATE_ACCOUNT',
        account: {
          totalPositions: positions.filter(p => p.status === 'open').length,
          totalMargin,
          unrealizedPnl,
          availableMargin: state.account.totalEquity - totalMargin,
        },
      })
    },
    [state]
  )

  const closePosition = useCallback(
    (positionId: string) => {
      const pos = state.positions.find(p => p.id === positionId)
      if (!pos) return
      dispatch({ type: 'CLOSE_POSITION', positionId })
      const pnl = getUnrealizedPnl(pos.entryPrice, pos.markPrice, pos.size, pos.side)
      dispatch({
        type: 'UPDATE_ACCOUNT',
        account: {
          realizedPnl: state.account.realizedPnl + pnl,
          totalPositions: state.positions.filter(p => p.status === 'open' && p.id !== positionId).length,
        },
      })
    },
    [state]
  )

  const connectWallet = useCallback(() => {
    const addr = '7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU'
    dispatch({ type: 'CONNECT_WALLET', address: addr })
  }, [])

  const disconnectWallet = useCallback(() => {
    dispatch({ type: 'DISCONNECT_WALLET' })
  }, [])

  return (
    <AppContext.Provider
      value={{ state, dispatch, selectMarket, openPosition, closePosition, connectWallet, disconnectWallet }}
    >
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used within AppProvider')
  return ctx
}
