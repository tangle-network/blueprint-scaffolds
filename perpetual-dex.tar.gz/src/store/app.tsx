import { createContext, useContext, useReducer, useCallback, type ReactNode } from 'react'
import type { MarketData, Position, AccountSummary, Side } from '@/types'
import type { CandleData, MarketStats } from '@/types'
import { getUnrealizedPnl, calculateLiquidationPrice } from '@/lib/risk'
import { MARKET_CONFIGS, DEFAULT_VAMM, generateMockCandles } from '@/lib/constants'

function generateMockStats(symbol: string): MarketStats {
  const amm = DEFAULT_VAMM[symbol]
  const basePrice = amm.quoteReserves / amm.baseReserves
  const change = (Math.random() - 0.48) * 0.05
  const markPrice = basePrice * (1 + change)
  const fundingRate = (Math.random() - 0.5) * 0.0004
  return {
    markPrice,
    indexPrice: markPrice * (1 + (Math.random() - 0.5) * 0.001),
    oraclePrice: markPrice * (1 + (Math.random() - 0.5) * 0.0005),
    priceChange24h: change * 100,
    priceChangePercent24h: change * 100,
    volume24h: (Math.random() * 500 + 100) * 1e6,
    openInterest: (amm.totalLongOpenInterest + amm.totalShortOpenInterest) * markPrice,
    openInterestLong: amm.totalLongOpenInterest * markPrice,
    openInterestShort: amm.totalShortOpenInterest * markPrice,
    fundingRate,
    fundingRateAnnualized: fundingRate * 365 * 24,
    nextFundingCountdown: Math.floor(Math.random() * 3600),
    high24h: markPrice * 1.03,
    low24h: markPrice * 0.97,
  }
}

function generateMockMarketData(symbol: string): MarketData {
  const stats = generateMockStats(symbol)
  return { ...stats, twapPrice: stats.markPrice * (1 + (Math.random() - 0.5) * 0.001), lastUpdated: Date.now() }
}

function buildPositions(stats: Record<string, MarketStats>): Position[] {
  const btc = stats['BTC-PERP']
  const eth = stats['ETH-PERP']
  const sol = stats['SOL-PERP']
  return [
    {
      id: 'pos-1', market: 'BTC-PERP', side: 'long' as const, size: 2.5,
      entryPrice: 66800, markPrice: btc.markPrice, leverage: 10, margin: 16700,
      unrealizedPnl: (btc.markPrice - 66800) * 2.5,
      liquidationPrice: calculateLiquidationPrice(66800, 'long', 10, 0.025),
      status: 'open' as const, createdAt: Date.now() - 86400000, openedAt: Date.now() - 86400000,
      fundingPaid: -42.5, fundingFeesPaid: -42.5, maintenanceMarginRatio: 0.025,
    },
    {
      id: 'pos-2', market: 'ETH-PERP', side: 'short' as const, size: 15,
      entryPrice: 3510, markPrice: eth.markPrice, leverage: 5, margin: 10530,
      unrealizedPnl: (3510 - eth.markPrice) * 15,
      liquidationPrice: calculateLiquidationPrice(3510, 'short', 5, 0.025),
      status: 'open' as const, createdAt: Date.now() - 43200000, openedAt: Date.now() - 43200000,
      fundingPaid: 28.3, fundingFeesPaid: 28.3, maintenanceMarginRatio: 0.025,
    },
    {
      id: 'pos-3', market: 'SOL-PERP', side: 'long' as const, size: 200,
      entryPrice: 168.5, markPrice: sol.markPrice, leverage: 15, margin: 2246.67,
      unrealizedPnl: (sol.markPrice - 168.5) * 200,
      liquidationPrice: calculateLiquidationPrice(168.5, 'long', 15, 0.025),
      status: 'open' as const, createdAt: Date.now() - 21600000, openedAt: Date.now() - 21600000,
      fundingPaid: -15.8, fundingFeesPaid: -15.8, maintenanceMarginRatio: 0.025,
    },
  ]
}

function buildInitialMarketData(): Record<string, MarketData> {
  const data: Record<string, MarketData> = {}
  for (const config of MARKET_CONFIGS) {
    data[config.symbol] = generateMockMarketData(config.symbol)
  }
  return data
}

function buildInitialCandles(marketData: Record<string, MarketData>): Record<string, CandleData[]> {
  const candles: Record<string, CandleData[]> = {}
  for (const config of MARKET_CONFIGS) {
    candles[config.symbol] = generateMockCandles(marketData[config.symbol].markPrice)
  }
  return candles
}

const initialMarketData = buildInitialMarketData()
const initialPositions = buildPositions(
  Object.fromEntries(MARKET_CONFIGS.map(c => [c.symbol, initialMarketData[c.symbol]] as const))
)

const initialAccount: AccountSummary = {
  totalEquity: 52645.8,
  equity: 52645.8,
  totalMargin: 29476.67,
  availableMargin: 23169.13,
  unrealizedPnl: initialPositions.reduce((s, p) => s + p.unrealizedPnl, 0),
  realizedPnl: 4320.5,
  totalPositions: 3,
  openPositionCount: 3,
  totalFundingFees: -30.0,
  marginRatio: 0.42,
}

interface AppState {
  currentMarket: string
  marketData: Record<string, MarketData>
  positions: Position[]
  account: AccountSummary
  candles: Record<string, CandleData[]>
  walletConnected: boolean
  walletAddress: string | null
}

type Action =
  | { type: 'SET_MARKET'; market: string }
  | { type: 'UPDATE_MARKET_DATA'; symbol: string; data: MarketData }
  | { type: 'OPEN_POSITION'; position: Position }
  | { type: 'CLOSE_POSITION'; positionId: string }
  | { type: 'UPDATE_ACCOUNT'; account: Partial<AccountSummary> }
  | { type: 'CONNECT_WALLET'; address: string }
  | { type: 'DISCONNECT_WALLET' }

const initialState: AppState = {
  currentMarket: 'SOL-PERP',
  marketData: initialMarketData,
  positions: initialPositions,
  account: initialAccount,
  candles: buildInitialCandles(initialMarketData),
  walletConnected: false,
  walletAddress: null,
}

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'SET_MARKET':
      return { ...state, currentMarket: action.market }
    case 'UPDATE_MARKET_DATA':
      return { ...state, marketData: { ...state.marketData, [action.symbol]: action.data } }
    case 'OPEN_POSITION':
      return { ...state, positions: [...state.positions, action.position] }
    case 'CLOSE_POSITION':
      return {
        ...state,
        positions: state.positions.map(p =>
          p.id === action.positionId ? { ...p, status: 'closed' as const } : p
        ),
      }
    case 'UPDATE_ACCOUNT':
      return { ...state, account: { ...state.account, ...action.account } }
    case 'CONNECT_WALLET':
      return { ...state, walletConnected: true, walletAddress: action.address }
    case 'DISCONNECT_WALLET':
      return { ...state, walletConnected: false, walletAddress: null }
    default:
      return state
  }
}

interface AppContextType {
  state: AppState
  dispatch: React.Dispatch<Action>
  selectMarket: (market: string) => void
  openPosition: (market: string, side: Side, size: number, leverage: number, margin: number) => void
  closePosition: (positionId: string) => void
  connectWallet: () => void
  disconnectWallet: () => void
}

const AppContext = createContext<AppContextType | null>(null)

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState)

  const selectMarket = useCallback((market: string) => {
    dispatch({ type: 'SET_MARKET', market })
  }, [])

  const openPosition = useCallback(
    (market: string, side: Side, size: number, leverage: number, margin: number) => {
      const marketData = state.marketData[market]
      const entryPrice = marketData.markPrice
      const position: Position = {
        id: `pos-${Date.now()}`,
        market, side, size, entryPrice, markPrice: entryPrice, leverage, margin,
        unrealizedPnl: 0,
        liquidationPrice: calculateLiquidationPrice(entryPrice, side, leverage, 0.025),
        status: 'open', createdAt: Date.now(), openedAt: Date.now(),
        fundingPaid: 0, fundingFeesPaid: 0, maintenanceMarginRatio: 0.025,
      }
      dispatch({ type: 'OPEN_POSITION', position })
      const positions = [...state.positions, position]
      const totalMargin = positions.reduce((s, p) => s + p.margin, 0)
      const unrealizedPnl = positions.reduce(
        (s, p) => s + getUnrealizedPnl(p.entryPrice, state.marketData[p.market]?.markPrice ?? p.markPrice, p.size, p.side),
        0
      )
      dispatch({
        type: 'UPDATE_ACCOUNT',
        account: {
          openPositionCount: positions.filter(p => p.status === 'open').length,
          totalPositions: positions.filter(p => p.status === 'open').length,
          totalMargin, unrealizedPnl,
          availableMargin: state.account.equity - totalMargin,
        },
      })
    },
    [state]
  )

  const closePosition = useCallback(
    (positionId: string) => {
      const pos = state.positions.find(p => p.id === positionId)
      if (!pos) return
      dispatch({ type: 'CLOSE_POSITION', positionId })
      const pnl = getUnrealizedPnl(pos.entryPrice, pos.markPrice, pos.size, pos.side)
      const remaining = state.positions.filter(p => p.status === 'open' && p.id !== positionId)
      dispatch({
        type: 'UPDATE_ACCOUNT',
        account: {
          realizedPnl: state.account.realizedPnl + pnl,
          totalPositions: remaining.length,
          openPositionCount: remaining.length,
        },
      })
    },
    [state]
  )

  const connectWallet = useCallback(() => {
    dispatch({ type: 'CONNECT_WALLET', address: '7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU' })
  }, [])

  const disconnectWallet = useCallback(() => {
    dispatch({ type: 'DISCONNECT_WALLET' })
  }, [])

  return (
    <AppContext.Provider value={{ state, dispatch, selectMarket, openPosition, closePosition, connectWallet, disconnectWallet }}>
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used within AppProvider')
  return ctx
}
