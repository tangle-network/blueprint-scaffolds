function App() {
  return (
    <div>
      <h1>Perp DEX</h1>
    </div>
  );
}

export default App;
