import { randomUUID } from 'crypto';
import type { ConnectionConfig, DbType } from '../types.js';
import type { IDbAdapter } from './adapter.js';
import { PostgresAdapter } from './postgres.js';
import { MysqlAdapter } from './mysql.js';
import { SqliteAdapter } from './sqlite.js';
import { MongoAdapter } from './mongo.js';

export interface ManagedConnection {
  id: string;
  config: ConnectionConfig;
  adapter: IDbAdapter;
  createdAt: Date;
}

const connections = new Map<string, ManagedConnection>();

function createAdapter(config: ConnectionConfig): IDbAdapter {
  switch (config.type) {
    case 'postgresql':
      return new PostgresAdapter(config);
    case 'mysql':
      return new MysqlAdapter(config);
    case 'sqlite':
      return new SqliteAdapter(config);
    case 'mongodb':
      return new MongoAdapter(config);
    default:
      throw new Error(`Unsupported database type: ${config.type satisfies never}`);
  }
}

export async function connect(config: ConnectionConfig): Promise<string> {
  const id = randomUUID();
  const adapter = createAdapter(config);
  await adapter.connect();
  connections.set(id, { id, config, adapter, createdAt: new Date() });
  return id;
}

export async function disconnect(connectionId: string): Promise<void> {
  const conn = connections.get(connectionId);
  if (!conn) throw new Error(`Connection not found: ${connectionId}`);
  await conn.adapter.disconnect();
  connections.delete(connectionId);
}

export function getConnection(connectionId: string): ManagedConnection {
  const conn = connections.get(connectionId);
  if (!conn) throw new Error(`Connection not found: ${connectionId}`);
  return conn;
}

export function listConnections(): Array<{ id: string; type: DbType; database: string; createdAt: Date }> {
  return Array.from(connections.values()).map((c) => ({
    id: c.id,
    type: c.config.type,
    database: c.config.database,
    createdAt: c.createdAt,
  }));
}

export async function disconnectAll(): Promise<void> {
  for (const [id] of connections) {
    await disconnect(id);
  }
}
