import type {
  ConnectionConfig,
  SchemaResult,
  QueryResult,
  SampleDataResult,
  TableProfile,
  ColumnInfo,
} from '../types.js';

export interface IDbAdapter {
  connect(): Promise<void>;
  disconnect(): Promise<void>;
  isConnected(): boolean;
  getSchema(schemaName?: string, tableName?: string): Promise<SchemaResult>;
  executeQuery(query: string, params?: unknown[], maxRows?: number): Promise<QueryResult>;
  getSampleData(tableName: string, size: number): Promise<SampleDataResult>;
  searchData(tableName: string, column: string, term: string, limit?: number): Promise<QueryResult>;
  profileTable(tableName: string, columns?: string[]): Promise<TableProfile>;
  getTableNames(schemaName?: string): Promise<string[]>;
}
