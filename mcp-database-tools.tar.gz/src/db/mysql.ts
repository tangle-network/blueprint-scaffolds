import mysql from 'mysql2/promise';
import type { IDbAdapter } from './adapter.js';
import type {
  ConnectionConfig,
  SchemaResult,
  QueryResult,
  SampleDataResult,
  TableProfile,
  ColumnInfo,
  TableInfo,
  IndexInfo,
  RelationshipInfo,
} from '../types.js';

export class MysqlAdapter implements IDbAdapter {
  private pool: mysql.Pool | null = null;
  private config: ConnectionConfig;
  private connected = false;

  constructor(config: ConnectionConfig) {
    this.config = config;
  }

  async connect(): Promise<void> {
    this.pool = mysql.createPool({
      host: this.config.host || 'localhost',
      port: this.config.port || 3306,
      user: this.config.user || 'root',
      password: this.config.password || '',
      database: this.config.database,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
    });
    const conn = await this.pool.getConnection();
    conn.release();
    this.connected = true;
  }

  async disconnect(): Promise<void> {
    if (this.pool) {
      await this.pool.end();
      this.pool = null;
    }
    this.connected = false;
  }

  isConnected(): boolean {
    return this.connected && this.pool !== null;
  }

  async getSchema(schemaName?: string, tableName?: string): Promise<SchemaResult> {
    const schema = schemaName || this.config.database;
    const tableFilter = tableName ? ` AND TABLE_NAME = ?` : '';
    const params: string[] = [schema];
    if (tableName) params.push(tableName);

    const [tablesRows] = await this.pool!.query(
      `SELECT TABLE_NAME, TABLE_TYPE, TABLE_ROWS, TABLE_COMMENT
       FROM information_schema.TABLES
       WHERE TABLE_SCHEMA = ?${tableFilter}
       ORDER BY TABLE_NAME`,
      params
    );

    const tables: TableInfo[] = (tablesRows as Record<string, unknown>[]).map((r) => ({
      schema,
      name: r.TABLE_NAME as string,
      type: (r.TABLE_TYPE as string || '').includes('VIEW') ? 'view' as const : 'table' as const,
      rowCount: Number(r.TABLE_ROWS) || undefined,
      comment: r.TABLE_COMMENT as string || undefined,
    }));

    const allTableNames = tables.map((t) => t.name);
    const columns: Record<string, ColumnInfo[]> = {};
    const indexes: Record<string, IndexInfo[]> = {};

    for (const tbl of allTableNames) {
      const [colRows] = await this.pool!.query(
        `SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, COLUMN_DEFAULT, ORDINAL_POSITION,
                COLUMN_KEY, EXTRA, COLUMN_COMMENT
         FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
         ORDER BY ORDINAL_POSITION`,
        [schema, tbl]
      );

      columns[tbl] = (colRows as Record<string, unknown>[]).map((r) => ({
        name: r.COLUMN_NAME as string,
        type: r.DATA_TYPE as string,
        nullable: r.IS_NULLABLE === 'YES',
        defaultValue: r.COLUMN_DEFAULT as string | undefined,
        isPrimaryKey: r.COLUMN_KEY === 'PRI',
        isUnique: r.COLUMN_KEY === 'UNI',
        isIndexed: r.COLUMN_KEY === 'MUL' || r.COLUMN_KEY === 'PRI' || r.COLUMN_KEY === 'UNI',
        isAutoIncrement: (r.EXTRA as string || '').includes('auto_increment'),
        comment: r.COLUMN_COMMENT as string || undefined,
        ordinalPosition: r.ORDINAL_POSITION as number,
      }));

      const [idxRows] = await this.pool!.query(
        `SELECT INDEX_NAME, COLUMN_NAME, NON_UNIQUE, SEQ_IN_INDEX
         FROM information_schema.STATISTICS
         WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
         ORDER BY INDEX_NAME, SEQ_IN_INDEX`,
        [schema, tbl]
      );

      const idxMap: Record<string, IndexInfo> = {};
      for (const row of idxRows as Record<string, unknown>[]) {
        const idxName = row.INDEX_NAME as string;
        if (!idxMap[idxName]) {
          idxMap[idxName] = {
            name: idxName,
            tableName: tbl,
            columns: [],
            isUnique: !(row.NON_UNIQUE as number),
            isPrimary: idxName === 'PRIMARY',
          };
        }
        idxMap[idxName].columns.push(row.COLUMN_NAME as string);
      }
      indexes[tbl] = Object.values(idxMap);
    }

    const [fkRows] = await this.pool!.query(
      `SELECT
        kcu.CONSTRAINT_NAME,
        kcu.TABLE_NAME,
        kcu.COLUMN_NAME,
        kcu.REFERENCED_TABLE_NAME,
        kcu.REFERENCED_COLUMN_NAME,
        rc.UPDATE_RULE,
        rc.DELETE_RULE
       FROM information_schema.KEY_COLUMN_USAGE kcu
       LEFT JOIN information_schema.REFERENTIAL_CONSTRAINTS rc
         ON rc.CONSTRAINT_NAME = kcu.CONSTRAINT_NAME AND rc.CONSTRAINT_SCHEMA = kcu.TABLE_SCHEMA
       WHERE kcu.TABLE_SCHEMA = ? AND kcu.REFERENCED_TABLE_NAME IS NOT NULL
       ORDER BY kcu.CONSTRAINT_NAME, kcu.ORDINAL_POSITION`,
      [schema]
    );

    const fkMap: Record<string, RelationshipInfo> = {};
    for (const row of fkRows as Record<string, unknown>[]) {
      const name = row.CONSTRAINT_NAME as string;
      if (!fkMap[name]) {
        fkMap[name] = {
          name,
          fromTable: row.TABLE_NAME as string,
          fromColumns: [],
          toTable: row.REFERENCED_TABLE_NAME as string,
          toColumns: [],
          onUpdate: row.UPDATE_RULE as string | undefined,
          onDelete: row.DELETE_RULE as string | undefined,
        };
      }
      fkMap[name].fromColumns.push(row.COLUMN_NAME as string);
      fkMap[name].toColumns.push(row.REFERENCED_COLUMN_NAME as string);
    }

    return { tables, columns, indexes, relationships: Object.values(fkMap) };
  }

  async executeQuery(query: string, params?: unknown[], maxRows?: number): Promise<QueryResult> {
    const limit = maxRows || 1000;
    const start = Date.now();
    const [result] = await this.pool!.query(query, params);
    const executionTimeMs = Date.now() - start;
    const rows = result as Record<string, unknown>[];
    const truncated = rows.length > limit;
    const fields = (result as unknown as { fields?: Array<{ name: string }> }).fields;
    return {
      columns: fields ? fields.map((f) => f.name) : (rows.length > 0 ? Object.keys(rows[0]) : []),
      rows: truncated ? rows.slice(0, limit) : rows,
      rowCount: rows.length,
      executionTimeMs,
      truncated,
    };
  }

  async getSampleData(tableName: string, size: number): Promise<SampleDataResult> {
    const schemaResult = await this.getSchema(undefined, tableName);
    const columns = schemaResult.columns[tableName] || [];
    const countResult = await this.executeQuery(`SELECT COUNT(*) as cnt FROM \`${tableName}\``);
    const totalRows = Number(countResult.rows[0]?.cnt || 0);
    const result = await this.executeQuery(`SELECT * FROM \`${tableName}\` LIMIT ?`, [size]);
    return { tableName, columns, rows: result.rows, totalRows };
  }

  async searchData(tableName: string, column: string, term: string, limit?: number): Promise<QueryResult> {
    const query = `SELECT * FROM \`${tableName}\` WHERE CAST(\`${column}\` AS CHAR) LIKE ? LIMIT ?`;
    return this.executeQuery(query, [`%${term}%`, limit || 100]);
  }

  async profileTable(tableName: string, columns?: string[]): Promise<TableProfile> {
    const start = Date.now();
    const schemaResult = await this.getSchema(undefined, tableName);
    const tableColumns = schemaResult.columns[tableName] || [];
    const targetCols = columns || tableColumns.map((c) => c.name);

    const countResult = await this.executeQuery(`SELECT COUNT(*) as cnt FROM \`${tableName}\``);
    const totalRows = Number(countResult.rows[0]?.cnt || 0);

    const profiles = [];
    for (const colName of targetCols) {
      const col = tableColumns.find((c) => c.name === colName);
      const statsQuery = `SELECT COUNT(\`${colName}\`) as non_null, COUNT(DISTINCT \`${colName}\`) as distinct_count FROM \`${tableName}\``;
      const statsResult = await this.executeQuery(statsQuery);
      const row = statsResult.rows[0] || {};

      const sampleQuery = `SELECT DISTINCT \`${colName}\` FROM \`${tableName}\` WHERE \`${colName}\` IS NOT NULL LIMIT 10`;
      const sampleResult = await this.executeQuery(sampleQuery);

      const isNumeric = col && ['int', 'bigint', 'float', 'double', 'decimal', 'numeric', 'tinyint', 'smallint', 'mediumint'].includes(col.type);
      let minValue: unknown = undefined;
      let maxValue: unknown = undefined;
      let avgValue: number | undefined = undefined;

      if (isNumeric) {
        const numQuery = `SELECT MIN(\`${colName}\`) as mn, MAX(\`${colName}\`) as mx, AVG(\`${colName}\`) as av FROM \`${tableName}\``;
        const numResult = await this.executeQuery(numQuery);
        const nr = numResult.rows[0] || {};
        minValue = nr.mn;
        maxValue = nr.mx;
        avgValue = nr.av ? Number(nr.av) : undefined;
      }

      profiles.push({
        name: colName,
        type: col?.type || 'unknown',
        nullCount: totalRows - Number(row.non_null || 0),
        distinctCount: Number(row.distinct_count || 0),
        sampleValues: sampleResult.rows.map((r) => r[colName]),
        minValue,
        maxValue,
        avgValue,
      });
    }

    return { tableName, totalRows, columns: profiles, executionTimeMs: Date.now() - start };
  }

  async getTableNames(schemaName?: string): Promise<string[]> {
    const schema = schemaName || this.config.database;
    const result = await this.executeQuery(
      `SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? ORDER BY TABLE_NAME`,
      [schema]
    );
    return result.rows.map((r) => r.TABLE_NAME as string);
  }
}
