import { MongoClient, type Db } from 'mongodb';
import type { IDbAdapter } from './adapter.js';
import type {
  ConnectionConfig,
  SchemaResult,
  QueryResult,
  SampleDataResult,
  TableProfile,
  ColumnInfo,
  TableInfo,
  IndexInfo,
} from '../types.js';

export class MongoAdapter implements IDbAdapter {
  private client: MongoClient | null = null;
  private db: Db | null = null;
  private config: ConnectionConfig;
  private connected = false;

  constructor(config: ConnectionConfig) {
    this.config = config;
  }

  async connect(): Promise<void> {
    const cs = this.config.connectionString ||
      `mongodb://${this.config.user ? `${this.config.user}:${this.config.password}@` : ''}${this.config.host || 'localhost'}:${this.config.port || 27017}/${this.config.database}`;
    this.client = new MongoClient(cs);
    await this.client.connect();
    this.db = this.client.db(this.config.database);
    this.connected = true;
  }

  async disconnect(): Promise<void> {
    if (this.client) {
      await this.client.close();
      this.client = null;
      this.db = null;
    }
    this.connected = false;
  }

  isConnected(): boolean {
    return this.connected && this.client !== null;
  }

  async getSchema(): Promise<SchemaResult> {
    const collections = await this.db!.listCollections().toArray();
    const tables: TableInfo[] = [];
    const columns: Record<string, ColumnInfo[]> = {};
    const indexes: Record<string, IndexInfo[]> = {};

    for (const coll of collections) {
      const name = coll.name;
      const type = coll.type === 'view' ? 'view' as const : 'table' as const;
      const count = await this.db!.collection(name).estimatedDocumentCount();
      tables.push({ name, type, rowCount: count });

      const sample = await this.db!.collection(name).findOne();
      const cols: ColumnInfo[] = [];
      if (sample) {
        let ordinal = 0;
        for (const key of Object.keys(sample)) {
          ordinal++;
          const val = sample[key];
          let jsType = typeof val;
          if (val === null) jsType = 'null';
          else if (Array.isArray(val)) jsType = 'array';
          else if (val instanceof Date) jsType = 'date';
          else if (val && typeof val === 'object' && val._bsontype) jsType = 'objectId';

          cols.push({
            name: key,
            type: jsType,
            nullable: val === null || val === undefined,
            isPrimaryKey: key === '_id',
            isUnique: key === '_id',
            isIndexed: key === '_id',
            isAutoIncrement: false,
            ordinalPosition: ordinal,
          });
        }
      }
      columns[name] = cols;

      const idxArray = await this.db!.collection(name).indexes();
      indexes[name] = idxArray.map((idx) => ({
        name: idx.name || '',
        tableName: name,
        columns: Object.keys(idx.key || {}),
        isUnique: idx.unique || false,
        isPrimary: (idx.name || '').startsWith('_id_'),
      }));
    }

    return { tables, columns, indexes, relationships: [] };
  }

  async executeQuery(queryStr: string, _params?: unknown[], maxRows?: number): Promise<QueryResult> {
    const limit = maxRows || 1000;
    const start = Date.now();
    let parsed: { collection: string; operation: string; filter?: unknown; projection?: unknown; sort?: unknown; limit?: number };
    try {
      parsed = JSON.parse(queryStr);
    } catch {
      throw new Error('MongoDB queries must be JSON: {"collection":"...", "operation":"find", "filter":{}}');
    }

    const { collection, operation, filter, projection, sort } = parsed;
    const coll = this.db!.collection(collection);
    let rows: Record<string, unknown>[] = [];

    switch (operation) {
      case 'find': {
        const cursor = coll.find((filter as any) || {});
        if (projection) cursor.project(projection as any);
        if (sort) cursor.sort(sort as any);
        rows = await cursor.limit(limit).toArray();
        break;
      }
      case 'aggregate': {
        rows = await coll.aggregate((Array.isArray(filter) ? filter : []) as any).limit(limit).toArray();
        break;
      }
      case 'count': {
        const cnt = await coll.countDocuments((filter as any) || {});
        rows = [{ count: cnt }];
        break;
      }
      case 'distinct': {
        const field = (parsed as any).field;
        const values = await coll.distinct(field, (filter as any) || {});
        rows = values.map((v) => ({ value: v }));
        break;
      }
      default:
        throw new Error(`Unsupported MongoDB operation: ${operation}. Use: find, aggregate, count, distinct`);
    }

    const executionTimeMs = Date.now() - start;
    const columnsSet = new Set<string>();
    for (const row of rows) {
      for (const key of Object.keys(row)) columnsSet.add(key);
    }

    return {
      columns: Array.from(columnsSet),
      rows: rows.map((r) => {
        const plain: Record<string, unknown> = {};
        for (const [k, v] of Object.entries(r)) {
          if (k === '_id' && v && typeof v === 'object' && 'toString' in v) {
            plain[k] = (v as any).toString();
          } else {
            plain[k] = v;
          }
        }
        return plain;
      }),
      rowCount: rows.length,
      executionTimeMs,
      truncated: rows.length >= limit,
    };
  }

  async getSampleData(tableName: string, size: number): Promise<SampleDataResult> {
    const schemaResult = await this.getSchema();
    const columns = schemaResult.columns[tableName] || [];
    const totalRows = await this.db!.collection(tableName).estimatedDocumentCount();
    const rows = await this.db!.collection(tableName).find().limit(size).toArray();
    const plainRows = rows.map((r) => {
      const plain: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(r)) {
        if (k === '_id' && v && typeof v === 'object' && 'toString' in v) {
          plain[k] = (v as any).toString();
        } else {
          plain[k] = v;
        }
      }
      return plain;
    });
    return { tableName, columns, rows: plainRows, totalRows };
  }

  async searchData(tableName: string, column: string, term: string, limit?: number): Promise<QueryResult> {
    const query = JSON.stringify({
      collection: tableName,
      operation: 'find',
      filter: { [column]: { $regex: term, $options: 'i' } },
    });
    return this.executeQuery(query, undefined, limit);
  }

  async profileTable(tableName: string, columns?: string[]): Promise<TableProfile> {
    const start = Date.now();
    const coll = this.db!.collection(tableName);
    const totalRows = await coll.estimatedDocumentCount();

    const sample = await coll.find().limit(100).toArray();
    const allKeys = new Set<string>();
    for (const doc of sample) {
      for (const key of Object.keys(doc)) {
        if (key !== '_id') allKeys.add(key);
      }
    }

    const targetCols = columns || Array.from(allKeys);
    const profiles = [];

    for (const colName of targetCols) {
      const nonNull = await coll.countDocuments({ [colName]: { $ne: null, $exists: true } });
      const distinctValues = await coll.distinct(colName);
      const sampleValues = distinctValues.slice(0, 10);

      profiles.push({
        name: colName,
        type: sample.length > 0 && sample[0][colName] !== undefined ? typeof sample[0][colName] : 'unknown',
        nullCount: totalRows - nonNull,
        distinctCount: distinctValues.length,
        sampleValues,
      });
    }

    return { tableName, totalRows, columns: profiles, executionTimeMs: Date.now() - start };
  }

  async getTableNames(): Promise<string[]> {
    const collections = await this.db!.listCollections().toArray();
    return collections.map((c) => c.name);
  }
}
