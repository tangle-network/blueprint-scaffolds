import initSqlJs from 'sql.js';
import type { IDbAdapter } from './adapter.js';
import type {
  ConnectionConfig,
  SchemaResult,
  QueryResult,
  SampleDataResult,
  TableProfile,
  ColumnInfo,
  TableInfo,
  IndexInfo,
  RelationshipInfo,
} from '../types.js';

export class SqliteAdapter implements IDbAdapter {
  private db: any = null;
  private config: ConnectionConfig;
  private connected = false;

  constructor(config: ConnectionConfig) {
    this.config = config;
  }

  async connect(): Promise<void> {
    const SQL = await initSqlJs();
    const filename = this.config.filename || this.config.database;
    if (filename === ':memory:' || filename === 'memory') {
      this.db = new SQL.Database();
    } else {
      const fs = await import('fs');
      const buffer = fs.readFileSync(filename);
      this.db = new SQL.Database(buffer);
    }
    this.connected = true;
  }

  async disconnect(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
    this.connected = false;
  }

  isConnected(): boolean {
    return this.connected && this.db !== null;
  }

  private runQuery(sql: string, params?: unknown[]): { columns: string[]; rows: Record<string, unknown>[] } {
    const stmt = this.db.prepare(sql);
    if (params && params.length > 0) stmt.bind(params);
    const columns: string[] = [];
    const rows: Record<string, unknown>[] = [];
    while (stmt.step()) {
      const row = stmt.getAsObject();
      if (columns.length === 0) columns.push(...Object.keys(row));
      rows.push(row);
    }
    stmt.free();
    return { columns, rows };
  }

  async getSchema(schemaName?: string, tableName?: string): Promise<SchemaResult> {
    const tableFilter = tableName ? ` AND name = ?` : '';
    const params = tableName ? [tableName] : [];
    const tablesResult = this.runQuery(
      `SELECT name, type FROM sqlite_master WHERE type IN ('table', 'view')${tableFilter} ORDER BY name`,
      params
    );

    const tables: TableInfo[] = tablesResult.rows
      .filter((r) => (r.name as string) !== 'sqlite_sequence')
      .map((r) => ({
        name: r.name as string,
        type: (r.type as string) === 'view' ? 'view' as const : 'table' as const,
      }));

    const allTableNames = tables.map((t) => t.name);
    const columns: Record<string, ColumnInfo[]> = {};
    const indexes: Record<string, IndexInfo[]> = {};

    for (const tbl of allTableNames) {
      const colResult = this.runQuery(`PRAGMA table_info("${tbl}")`);
      const pkColumns = colResult.rows.filter((r) => r.pk === 1).map((r) => r.name as string);

      columns[tbl] = colResult.rows.map((r, idx) => ({
        name: r.name as string,
        type: r.type as string,
        nullable: (r.notnull as number) === 0,
        defaultValue: r.dflt_value as string | undefined,
        isPrimaryKey: (r.pk as number) === 1,
        isUnique: false,
        isIndexed: false,
        isAutoIncrement: (r.pk as number) === 1 && r.type === 'INTEGER',
        ordinalPosition: (r.cid as number) + 1,
      }));

      const idxResult = this.runQuery(`PRAGMA index_list("${tbl}")`);
      const idxList: IndexInfo[] = [];
      for (const idxRow of idxResult.rows) {
        const idxDetail = this.runQuery(`PRAGMA index_info("${idxRow.name}")`);
        idxList.push({
          name: idxRow.name as string,
          tableName: tbl,
          columns: idxDetail.rows.map((r) => r.name as string),
          isUnique: (idxRow.unique as number) === 1,
          isPrimary: (idxRow.origin as string) === 'pk',
        });
      }
      indexes[tbl] = idxList;

      for (const col of columns[tbl]) {
        col.isIndexed = idxList.some((idx) => idx.columns.includes(col.name));
        col.isUnique = idxList.some((idx) => idx.columns.length === 1 && idx.columns[0] === col.name && idx.isUnique);
      }
    }

    const relationships: RelationshipInfo[] = [];
    for (const tbl of allTableNames) {
      const fkResult = this.runQuery(`PRAGMA foreign_key_list("${tbl}")`);
      const fkMap: Record<number, RelationshipInfo> = {};
      for (const row of fkResult.rows) {
        const id = row.id as number;
        if (!fkMap[id]) {
          fkMap[id] = {
            name: `fk_${tbl}_${id}`,
            fromTable: tbl,
            fromColumns: [],
            toTable: row.table as string,
            toColumns: [],
            onUpdate: row.on_update as string | undefined,
            onDelete: row.on_delete as string | undefined,
          };
        }
        fkMap[id].fromColumns.push(row.from as string);
        fkMap[id].toColumns.push(row.to as string);
      }
      relationships.push(...Object.values(fkMap));
    }

    return { tables, columns, indexes, relationships };
  }

  async executeQuery(query: string, params?: unknown[], maxRows?: number): Promise<QueryResult> {
    const limit = maxRows || 1000;
    const start = Date.now();
    const result = this.runQuery(query, params);
    const executionTimeMs = Date.now() - start;
    const truncated = result.rows.length > limit;
    return {
      columns: result.columns,
      rows: truncated ? result.rows.slice(0, limit) : result.rows,
      rowCount: result.rows.length,
      executionTimeMs,
      truncated,
    };
  }

  async getSampleData(tableName: string, size: number): Promise<SampleDataResult> {
    const schemaResult = await this.getSchema(undefined, tableName);
    const columns = schemaResult.columns[tableName] || [];
    const countResult = this.runQuery(`SELECT COUNT(*) as cnt FROM "${tableName}"`);
    const totalRows = Number(countResult.rows[0]?.cnt || 0);
    const result = await this.executeQuery(`SELECT * FROM "${tableName}" LIMIT ?`, [size]);
    return { tableName, columns, rows: result.rows, totalRows };
  }

  async searchData(tableName: string, column: string, term: string, limit?: number): Promise<QueryResult> {
    const query = `SELECT * FROM "${tableName}" WHERE CAST("${column}" AS TEXT) LIKE ? LIMIT ?`;
    return this.executeQuery(query, [`%${term}%`, limit || 100]);
  }

  async profileTable(tableName: string, columns?: string[]): Promise<TableProfile> {
    const start = Date.now();
    const schemaResult = await this.getSchema(undefined, tableName);
    const tableColumns = schemaResult.columns[tableName] || [];
    const targetCols = columns || tableColumns.map((c) => c.name);

    const countResult = this.runQuery(`SELECT COUNT(*) as cnt FROM "${tableName}"`);
    const totalRows = Number(countResult.rows[0]?.cnt || 0);

    const profiles = [];
    for (const colName of targetCols) {
      const col = tableColumns.find((c) => c.name === colName);
      const statsResult = this.runQuery(
        `SELECT COUNT("${colName}") as non_null, COUNT(DISTINCT "${colName}") as distinct_count FROM "${tableName}"`
      );
      const row = statsResult.rows[0] || {};

      const sampleResult = this.runQuery(
        `SELECT DISTINCT "${colName}" FROM "${tableName}" WHERE "${colName}" IS NOT NULL LIMIT 10`
      );

      const isNumeric = col && ['INTEGER', 'REAL', 'NUMERIC', 'INT', 'FLOAT', 'DOUBLE'].includes(col.type.toUpperCase());
      let minValue: unknown = undefined;
      let maxValue: unknown = undefined;
      let avgValue: number | undefined = undefined;

      if (isNumeric) {
        const numResult = this.runQuery(
          `SELECT MIN("${colName}") as mn, MAX("${colName}") as mx, AVG("${colName}") as av FROM "${tableName}"`
        );
        const nr = numResult.rows[0] || {};
        minValue = nr.mn;
        maxValue = nr.mx;
        avgValue = nr.av != null ? Number(nr.av) : undefined;
      }

      profiles.push({
        name: colName,
        type: col?.type || 'unknown',
        nullCount: totalRows - Number(row.non_null || 0),
        distinctCount: Number(row.distinct_count || 0),
        sampleValues: sampleResult.rows.map((r) => r[colName]),
        minValue,
        maxValue,
        avgValue,
      });
    }

    return { tableName, totalRows, columns: profiles, executionTimeMs: Date.now() - start };
  }

  async getTableNames(): Promise<string[]> {
    const result = this.runQuery(
      `SELECT name FROM sqlite_master WHERE type IN ('table', 'view') AND name != 'sqlite_sequence' ORDER BY name`
    );
    return result.rows.map((r) => r.name as string);
  }
}
