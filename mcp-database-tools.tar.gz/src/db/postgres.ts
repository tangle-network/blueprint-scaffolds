import pg from 'pg';
import type { IDbAdapter } from './adapter.js';
import type {
  ConnectionConfig,
  SchemaResult,
  QueryResult,
  SampleDataResult,
  TableProfile,
  ColumnInfo,
  TableInfo,
  IndexInfo,
  RelationshipInfo,
} from '../types.js';

const { Pool } = pg;

export class PostgresAdapter implements IDbAdapter {
  private pool: pg.Pool | null = null;
  private config: ConnectionConfig;
  private connected = false;

  constructor(config: ConnectionConfig) {
    this.config = config;
  }

  async connect(): Promise<void> {
    const cs = this.config.connectionString ||
      `postgresql://${this.config.user || 'postgres'}:${this.config.password || ''}@${this.config.host || 'localhost'}:${this.config.port || 5432}/${this.config.database}`;
    this.pool = new Pool({ connectionString: cs, max: 10, idleTimeoutMillis: 30000 });
    const client = await this.pool.connect();
    client.release();
    this.connected = true;
  }

  async disconnect(): Promise<void> {
    if (this.pool) {
      await this.pool.end();
      this.pool = null;
    }
    this.connected = false;
  }

  isConnected(): boolean {
    return this.connected && this.pool !== null;
  }

  async getSchema(schemaName?: string, tableName?: string): Promise<SchemaResult> {
    const schema = schemaName || 'public';
    const tableFilter = tableName ? ` AND t.table_name = $2` : '';
    const params = tableName ? [schema, tableName] : [schema];

    const tablesQuery = `
      SELECT t.table_name, t.table_type, obj_description(c.oid) as comment,
             COALESCE(n_live_tup, 0) as row_count
      FROM information_schema.tables t
      LEFT JOIN pg_class c ON c.relname = t.table_name
      LEFT JOIN pg_namespace n ON n.oid = c.relnamespace AND n.nspname = t.table_schema
      LEFT JOIN pg_stat_user_tables s ON s.relname = t.table_name AND s.schemaname = t.table_schema
      WHERE t.table_schema = $1 AND t.table_type IN ('BASE TABLE', 'VIEW', 'MATERIALIZED VIEW')
      ${tableFilter}
      ORDER BY t.table_name`;
    const tablesResult = await this.pool!.query(tablesQuery, params);

    const tables: TableInfo[] = tablesResult.rows.map((r: Record<string, unknown>) => ({
      schema,
      name: r.table_name as string,
      type: (r.table_type as string || 'BASE TABLE').toLowerCase().includes('view')
        ? 'view' as const
        : 'table' as const,
      rowCount: Number(r.row_count) || undefined,
      comment: r.comment as string | undefined,
    }));

    const allTableNames = tables.map((t) => t.name);
    const columns: Record<string, ColumnInfo[]> = {};
    const indexes: Record<string, IndexInfo[]> = {};

    for (const tbl of allTableNames) {
      const colQuery = `
        SELECT c.column_name, c.data_type, c.is_nullable, c.column_default,
               c.ordinal_position, col_description(pgc.oid, c.ordinal_position) as comment,
               CASE WHEN pk.column_name IS NOT NULL THEN true ELSE false END as is_pk
        FROM information_schema.columns c
        LEFT JOIN pg_class pgc ON pgc.relname = c.table_name
        LEFT JOIN pg_namespace pn ON pn.oid = pgc.relnamespace AND pn.nspname = c.table_schema
        LEFT JOIN (
          SELECT ku.column_name, ku.table_name, ku.table_schema
          FROM information_schema.table_constraints tc
          JOIN information_schema.key_column_usage ku ON tc.constraint_name = ku.constraint_name
          WHERE tc.constraint_type = 'PRIMARY KEY'
        ) pk ON pk.column_name = c.column_name AND pk.table_name = c.table_name AND pk.table_schema = c.table_schema
        WHERE c.table_schema = $1 AND c.table_name = $2
        ORDER BY c.ordinal_position`;
      const colResult = await this.pool!.query(colQuery, [schema, tbl]);
      columns[tbl] = colResult.rows.map((r: Record<string, unknown>) => ({
        name: r.column_name as string,
        type: r.data_type as string,
        nullable: r.is_nullable === 'YES',
        defaultValue: r.column_default as string | undefined,
        isPrimaryKey: r.is_pk as boolean,
        isUnique: false,
        isIndexed: false,
        isAutoIncrement: (r.column_default as string || '').includes('nextval'),
        comment: r.comment as string | undefined,
        ordinalPosition: r.ordinal_position as number,
      }));

      const idxQuery = `
        SELECT i.relname as index_name, a.attname as column_name,
               ix.indisunique as is_unique, ix.indisprimary as is_primary
        FROM pg_index ix
        JOIN pg_class t ON t.oid = ix.indrelid
        JOIN pg_class i ON i.oid = ix.indexrelid
        JOIN pg_attribute a ON a.attrelid = t.oid AND a.attnum = ANY(ix.indkey)
        JOIN pg_namespace n ON n.oid = t.relnamespace
        WHERE t.relname = $1 AND n.nspname = $2`;
      const idxResult = await this.pool!.query(idxQuery, [tbl, schema]);

      const idxMap: Record<string, IndexInfo> = {};
      for (const row of idxResult.rows as Record<string, unknown>[]) {
        const idxName = row.index_name as string;
        if (!idxMap[idxName]) {
          idxMap[idxName] = {
            name: idxName,
            tableName: tbl,
            columns: [],
            isUnique: row.is_unique as boolean,
            isPrimary: row.is_primary as boolean,
          };
        }
        idxMap[idxName].columns.push(row.column_name as string);
      }
      indexes[tbl] = Object.values(idxMap);

      for (const col of columns[tbl]) {
        col.isIndexed = indexes[tbl].some((idx) => idx.columns.includes(col.name));
        col.isUnique = indexes[tbl].some((idx) => idx.columns.includes(col.name) && idx.isUnique);
      }
    }

    const fkQuery = `
      SELECT
        tc.constraint_name,
        tc.table_name,
        kcu.column_name,
        ccu.table_name AS foreign_table_name,
        ccu.column_name AS foreign_column_name,
        rc.update_rule,
        rc.delete_rule
      FROM information_schema.table_constraints tc
      JOIN information_schema.key_column_usage kcu ON tc.constraint_name = kcu.constraint_name
      JOIN information_schema.constraint_column_usage ccu ON tc.constraint_name = ccu.constraint_name
      LEFT JOIN information_schema.referential_constraints rc ON rc.constraint_name = tc.constraint_name
      WHERE tc.constraint_type = 'FOREIGN KEY' AND tc.table_schema = $1`;
    const fkParams = [schema];
    const fkResult = await this.pool!.query(fkQuery, fkParams);

    const fkMap: Record<string, RelationshipInfo> = {};
    for (const row of fkResult.rows as Record<string, unknown>[]) {
      const name = row.constraint_name as string;
      if (!fkMap[name]) {
        fkMap[name] = {
          name,
          fromTable: row.table_name as string,
          fromColumns: [],
          toTable: row.foreign_table_name as string,
          toColumns: [],
          onUpdate: row.update_rule as string | undefined,
          onDelete: row.delete_rule as string | undefined,
        };
      }
      fkMap[name].fromColumns.push(row.column_name as string);
      fkMap[name].toColumns.push(row.foreign_column_name as string);
    }

    return {
      tables,
      columns,
      indexes,
      relationships: Object.values(fkMap),
    };
  }

  async executeQuery(query: string, params?: unknown[], maxRows?: number): Promise<QueryResult> {
    const limit = maxRows || 1000;
    const start = Date.now();
    const result = await this.pool!.query(query, params);
    const executionTimeMs = Date.now() - start;
    const rows = result.rows as Record<string, unknown>[];
    const truncated = rows.length > limit;
    return {
      columns: result.fields.map((f) => f.name),
      rows: truncated ? rows.slice(0, limit) : rows,
      rowCount: result.rowCount ?? rows.length,
      executionTimeMs,
      truncated,
    };
  }

  async getSampleData(tableName: string, size: number): Promise<SampleDataResult> {
    const schemaResult = await this.getSchema(undefined, tableName);
    const columns = schemaResult.columns[tableName] || [];
    const countResult = await this.pool!.query(`SELECT COUNT(*) as cnt FROM "${tableName}"`);
    const totalRows = Number((countResult.rows[0] as Record<string, unknown>).cnt);
    const result = await this.executeQuery(`SELECT * FROM "${tableName}" LIMIT $1`, [size]);
    return { tableName, columns, rows: result.rows, totalRows };
  }

  async searchData(tableName: string, column: string, term: string, limit?: number): Promise<QueryResult> {
    const query = `SELECT * FROM "${tableName}" WHERE CAST("${column}" AS TEXT) ILIKE $1 LIMIT $2`;
    return this.executeQuery(query, [`%${term}%`, limit || 100]);
  }

  async profileTable(tableName: string, columns?: string[]): Promise<TableProfile> {
    const start = Date.now();
    const schemaResult = await this.getSchema(undefined, tableName);
    const tableColumns = schemaResult.columns[tableName] || [];
    const targetCols = columns || tableColumns.map((c) => c.name);

    const countResult = await this.pool!.query(`SELECT COUNT(*) as cnt FROM "${tableName}"`);
    const totalRows = Number((countResult.rows[0] as Record<string, unknown>).cnt);

    const profiles = [];
    for (const colName of targetCols) {
      const col = tableColumns.find((c) => c.name === colName);
      const statsQuery = `
        SELECT
          COUNT("${colName}") as non_null,
          COUNT(DISTINCT "${colName}") as distinct_count
        FROM "${tableName}"`;
      const stats = await this.pool!.query(statsQuery);
      const row = stats.rows[0] as Record<string, unknown>;

      const sampleQuery = `SELECT DISTINCT "${colName}" FROM "${tableName}" WHERE "${colName}" IS NOT NULL LIMIT 10`;
      const sampleResult = await this.pool!.query(sampleQuery);

      const isNumeric = col && ['integer', 'numeric', 'real', 'double precision', 'bigint', 'smallint'].includes(col.type);
      let minValue: unknown = undefined;
      let maxValue: unknown = undefined;
      let avgValue: number | undefined = undefined;

      if (isNumeric) {
        const numQuery = `SELECT MIN("${colName}") as mn, MAX("${colName}") as mx, AVG("${colName}") as av FROM "${tableName}"`;
        const numResult = await this.pool!.query(numQuery);
        const nr = numResult.rows[0] as Record<string, unknown>;
        minValue = nr.mn;
        maxValue = nr.mx;
        avgValue = nr.av ? Number(nr.av) : undefined;
      }

      profiles.push({
        name: colName,
        type: col?.type || 'unknown',
        nullCount: totalRows - Number(row.non_null),
        distinctCount: Number(row.distinct_count),
        sampleValues: sampleResult.rows.map((r: Record<string, unknown>) => r[colName]),
        minValue,
        maxValue,
        avgValue,
      });
    }

    return { tableName, totalRows, columns: profiles, executionTimeMs: Date.now() - start };
  }

  async getTableNames(schemaName?: string): Promise<string[]> {
    const schema = schemaName || 'public';
    const result = await this.pool!.query(
      `SELECT table_name FROM information_schema.tables WHERE table_schema = $1 ORDER BY table_name`,
      [schema]
    );
    return result.rows.map((r: Record<string, unknown>) => r.table_name as string);
  }
}
