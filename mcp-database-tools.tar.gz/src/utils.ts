import type { ConnectionConfig, DbType } from './types.js';

export function buildConnectionString(config: ConnectionConfig): string {
  if (config.connectionString) return config.connectionString;

  switch (config.type) {
    case 'postgresql': {
      const host = config.host || 'localhost';
      const port = config.port || 5432;
      const user = config.user || 'postgres';
      const pass = config.password ? `:${config.password}` : '';
      return `postgresql://${user}${pass}@${host}:${port}/${config.database}`;
    }
    case 'mysql': {
      const host = config.host || 'localhost';
      const port = config.port || 3306;
      const user = config.user || 'root';
      const pass = config.password ? `:${config.password}` : '';
      return `mysql://${user}${pass}@${host}:${port}/${config.database}`;
    }
    case 'sqlite':
      return config.filename || config.database;
    case 'mongodb': {
      const host = config.host || 'localhost';
      const port = config.port || 27017;
      const user = config.user || '';
      const pass = config.password ? `:${config.password}` : '';
      const auth = user ? `${user}${pass}@` : '';
      return `mongodb://${auth}${host}:${port}/${config.database}`;
    }
    default:
      throw new Error(`Unsupported database type: ${config.type satisfies never}`);
  }
}

export function getDefaultPort(type: DbType): number {
  switch (type) {
    case 'postgresql':
      return 5432;
    case 'mysql':
      return 3306;
    case 'mongodb':
      return 27017;
    case 'sqlite':
      return 0;
    default:
      return 0;
  }
}
