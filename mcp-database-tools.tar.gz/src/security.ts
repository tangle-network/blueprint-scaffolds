import type { SecurityConfig, QueryResult } from './types.js';
import { DEFAULT_SECURITY } from './types.js';

export function validateQuery(query: string, config: SecurityConfig = DEFAULT_SECURITY): string | null {
  if (!config.readOnly) return null;

  const normalized = query.trim().toUpperCase();

  if (config.blockedPatterns) {
    for (const pattern of config.blockedPatterns) {
      if (pattern.test(query)) {
        return `Query contains blocked pattern: ${pattern.source}`;
      }
    }
  }

  const allowedPrefixes = ['SELECT', 'WITH', 'EXPLAIN', 'SHOW', 'DESCRIBE'];
  const firstWord = normalized.split(/\s+/)[0];
  if (!allowedPrefixes.includes(firstWord)) {
    return `Only read-only queries are allowed. Blocked: ${firstWord}`;
  }

  return null;
}

export function checkAllowlist(query: string, allowlistedQueries?: string[]): boolean {
  if (!allowlistedQueries || allowlistedQueries.length === 0) return true;
  const normalized = query.trim().toLowerCase();
  return allowlistedQueries.some((q) => q.trim().toLowerCase() === normalized);
}

export function maskSensitiveData(
  result: QueryResult,
  config: SecurityConfig = DEFAULT_SECURITY
): QueryResult {
  if (!config.maskedColumns || config.maskedColumns.length === 0) return result;

  const maskPatterns = config.maskedColumns.map((c) => new RegExp(c, 'i'));
  const maskedColumnIndices = result.columns.reduce<number[]>((acc, col, idx) => {
    if (maskPatterns.some((p) => p.test(col))) acc.push(idx);
    return acc;
  }, []);

  if (maskedColumnIndices.length === 0) return result;

  const mask = config.maskCharacter || '***';
  const maskedRows = result.rows.map((row) => {
    const newRow = { ...row };
    for (const idx of maskedColumnIndices) {
      const col = result.columns[idx];
      if (newRow[col] != null) {
        newRow[col] = mask;
      }
    }
    return newRow;
  });

  return { ...result, rows: maskedRows };
}

export function enforceRowLimit(rows: Record<string, unknown>[], maxRows: number): {
  rows: Record<string, unknown>[];
  truncated: boolean;
} {
  if (rows.length <= maxRows) return { rows, truncated: false };
  return { rows: rows.slice(0, maxRows), truncated: true };
}
