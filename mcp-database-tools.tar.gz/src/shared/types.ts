export type DatabaseType = 'postgresql' | 'mysql' | 'sqlite' | 'mongodb';

export interface ConnectionConfig {
  id: string;
  type: DatabaseType;
  name: string;
  host?: string;
  port?: number;
  database: string;
  user?: string;
  password?: string;
  filename?: string;
  poolSize?: number;
}

export interface TableInfo {
  schema?: string;
  name: string;
  type: 'table' | 'view' | 'materialized_view';
  rowCount?: number;
  comment?: string;
}

export interface ColumnInfo {
  name: string;
  dataType: string;
  nullable: boolean;
  defaultValue?: string | null;
  isPrimaryKey: boolean;
  isForeignKey: boolean;
  isUnique: boolean;
  isIndexed: boolean;
  isAutoIncrement: boolean;
  comment?: string;
  maxLength?: number | null;
  enumValues?: string[];
}

export interface IndexInfo {
  name: string;
  tableName: string;
  columns: string[];
  isUnique: boolean;
  isPrimary: boolean;
  type?: string;
}

export interface RelationshipInfo {
  name?: string;
  fromTable: string;
  fromColumn: string;
  toTable: string;
  toColumn: string;
  onDelete?: string;
  onUpdate?: string;
}

export interface SchemaResult {
  tables: TableInfo[];
  columns: Record<string, ColumnInfo[]>;
  indexes: IndexInfo[];
  relationships: RelationshipInfo[];
}

export interface QueryResult {
  columns: string[];
  rows: Record<string, unknown>[];
  rowCount: number;
  executionTimeMs: number;
  truncated: boolean;
}

export interface SampleDataResult {
  tableName: string;
  columns: string[];
  rows: Record<string, unknown>[];
  totalRows: number;
}

export interface ColumnProfile {
  name: string;
  dataType: string;
  nullCount: number;
  uniqueCount: number;
  minValue?: unknown;
  maxValue?: unknown;
  avgValue?: unknown;
  sampleValues: unknown[];
}

export interface TableProfile {
  tableName: string;
  rowCount: number;
  columns: ColumnProfile[];
}

export interface SecurityConfig {
  readOnly: boolean;
  maxRows: number;
  allowedPatterns: string[];
  deniedPatterns: string[];
  sensitiveColumns: SensitiveColumnRule[];
  queryTimeoutMs: number;
}

export interface SensitiveColumnRule {
  pattern: string;
  maskChar?: string;
  unmaskedLength?: number;
}

export interface MCPToolRequest {
  tool: string;
  params: Record<string, unknown>;
}

export interface MCPToolResponse {
  success: boolean;
  data?: unknown;
  error?: string;
  metadata?: {
    executionTimeMs?: number;
    rowCount?: number;
    truncated?: boolean;
  };
}

export type { QueryResult as SearchResult };
