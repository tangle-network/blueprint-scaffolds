export interface MCPToolDefinition {
  name: string
  description: string
  parameters: MCPToolParameter[]
}

export interface MCPToolParameter {
  name: string
  type: "string" | "number" | "boolean" | "object" | "array"
  description: string
  required: boolean
  default?: unknown
}

export interface MCPToolCall {
  tool: string
  arguments: Record<string, unknown>
}

export interface MCPToolResult {
  success: boolean
  data?: unknown
  error?: string
  metadata?: Record<string, unknown>
}
