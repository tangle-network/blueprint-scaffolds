export interface SecurityConfig {
  readOnlyMode: boolean
  maxRows: number
  sensitiveColumns: string[]
  allowedQueries: string[]
  enableAdhocQueries: boolean
  queryTimeout: number
}

export const DEFAULT_SECURITY_CONFIG: SecurityConfig = {
  readOnlyMode: true,
  maxRows: 1000,
  sensitiveColumns: [
    "password", "passwd", "secret", "token", "api_key", "api_secret",
    "credit_card", "ssn", "social_security", "private_key", "access_token",
    "refresh_token", "auth_token", "credentials",
  ],
  allowedQueries: [],
  enableAdhocQueries: true,
  queryTimeout: 30000,
}

export interface QueryValidationResult {
  allowed: boolean
  reason?: string
  sanitizedQuery?: string
}
