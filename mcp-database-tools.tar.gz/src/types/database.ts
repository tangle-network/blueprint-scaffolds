export type DatabaseType = "postgresql" | "mysql" | "sqlite" | "mongodb"

export interface ConnectionConfig {
  id: string
  type: DatabaseType
  host?: string
  port?: number
  database: string
  username?: string
  password?: string
  ssl?: boolean
  label?: string
}

export interface ColumnInfo {
  name: string
  type: string
  nullable: boolean
  defaultValue?: string
  isPrimaryKey: boolean
  isForeignKey: boolean
  isIndexed: boolean
  isUnique: boolean
  isSensitive?: boolean
}

export interface ForeignKeyInfo {
  fromTable: string
  fromColumn: string
  toTable: string
  toColumn: string
  constraintName?: string
}

export interface IndexInfo {
  name: string
  table: string
  columns: string[]
  isUnique: boolean
  isPrimary: boolean
  type?: string
}

export interface TableInfo {
  name: string
  schema?: string
  rowCount?: number
  columns: ColumnInfo[]
}

export interface SchemaInfo {
  tables: TableInfo[]
  foreignKeys: ForeignKeyInfo[]
  indexes: IndexInfo[]
  databaseType: DatabaseType
  databaseName: string
}

export interface QueryResult {
  columns: string[]
  rows: Record<string, unknown>[]
  rowCount: number
  executionTime: number
  truncated?: boolean
}

export interface ColumnProfile {
  name: string
  type: string
  nullCount: number
  uniqueCount: number
  sampleValues: unknown[]
  minValue?: unknown
  maxValue?: unknown
  avgValue?: number
}

export interface TableProfile {
  tableName: string
  totalRows: number
  columns: ColumnProfile[]
}

export interface SearchResults {
  table: string
  matches: Record<string, unknown>[]
  totalMatches: number
}

export interface ConnectionPoolStats {
  id: string
  totalConnections: number
  idleConnections: number
  activeConnections: number
  waitingRequests: number
}
