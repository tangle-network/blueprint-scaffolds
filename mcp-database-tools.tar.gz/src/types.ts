export type DbType = 'postgresql' | 'mysql' | 'sqlite' | 'mongodb';

export interface ConnectionConfig {
  type: DbType;
  host?: string;
  port?: number;
  user?: string;
  password?: string;
  database: string;
  filename?: string;
  connectionString?: string;
}

export interface TableInfo {
  schema?: string;
  name: string;
  type: 'table' | 'view' | 'materialized_view';
  rowCount?: number;
  comment?: string;
}

export interface ColumnInfo {
  name: string;
  type: string;
  nullable: boolean;
  defaultValue?: string;
  isPrimaryKey: boolean;
  isUnique: boolean;
  isIndexed: boolean;
  isAutoIncrement: boolean;
  comment?: string;
  ordinalPosition: number;
}

export interface IndexInfo {
  name: string;
  tableName: string;
  columns: string[];
  isUnique: boolean;
  isPrimary: boolean;
  type?: string;
}

export interface RelationshipInfo {
  name: string;
  fromTable: string;
  fromColumns: string[];
  toTable: string;
  toColumns: string[];
  onUpdate?: string;
  onDelete?: string;
}

export interface SchemaResult {
  tables: TableInfo[];
  columns: Record<string, ColumnInfo[]>;
  indexes: Record<string, IndexInfo[]>;
  relationships: RelationshipInfo[];
}

export interface QueryResult {
  columns: string[];
  rows: Record<string, unknown>[];
  rowCount: number;
  executionTimeMs: number;
  truncated: boolean;
}

export interface SampleDataResult {
  tableName: string;
  columns: ColumnInfo[];
  rows: Record<string, unknown>[];
  totalRows: number;
}

export interface ColumnProfile {
  name: string;
  type: string;
  nullCount: number;
  distinctCount: number;
  sampleValues: unknown[];
  minValue?: unknown;
  maxValue?: unknown;
  avgValue?: number;
}

export interface TableProfile {
  tableName: string;
  totalRows: number;
  columns: ColumnProfile[];
  executionTimeMs: number;
}

export interface SecurityConfig {
  readOnly: boolean;
  maxRows: number;
  allowlistedQueries?: string[];
  maskedColumns?: string[];
  maskCharacter?: string;
  blockedPatterns?: RegExp[];
}

export const DEFAULT_SECURITY: SecurityConfig = {
  readOnly: true,
  maxRows: 1000,
  maskCharacter: '***',
  maskedColumns: ['password', 'secret', 'token', 'ssn', 'credit_card', 'api_key'],
  blockedPatterns: [
    /\b(DROP|DELETE|TRUNCATE|ALTER|CREATE|INSERT|UPDATE|GRANT|REVOKE)\b/i,
  ],
};
