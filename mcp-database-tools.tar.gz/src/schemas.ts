import { z } from 'zod';

export const ConnectSchema = z.object({
  type: z.enum(['postgresql', 'mysql', 'sqlite', 'mongodb']),
  host: z.string().optional(),
  port: z.number().optional(),
  user: z.string().optional(),
  password: z.string().optional(),
  database: z.string(),
  filename: z.string().optional(),
  connectionString: z.string().optional(),
});

export const InspectSchemaSchema = z.object({
  connectionId: z.string(),
  schemaName: z.string().optional(),
  tableName: z.string().optional(),
});

export const BuildQuerySchema = z.object({
  connectionId: z.string(),
  naturalLanguage: z.string(),
  context: z
    .object({
      tables: z.array(z.string()).optional(),
      intent: z.string().optional(),
    })
    .optional(),
});

export const ExecuteQuerySchema = z.object({
  connectionId: z.string(),
  query: z.string(),
  params: z.array(z.unknown()).optional(),
  maxRows: z.number().optional(),
});

export const ExploreDataSchema = z.object({
  connectionId: z.string(),
  tableName: z.string(),
  operation: z.enum(['sample', 'search', 'profile']),
  sampleSize: z.number().optional().default(100),
  searchColumn: z.string().optional(),
  searchTerm: z.string().optional(),
  profileColumns: z.array(z.string()).optional(),
});

export const ListConnectionsSchema = z.object({});

export const DisconnectSchema = z.object({
  connectionId: z.string(),
});
