import { useMemo, useState } from 'react';
import clsx from 'clsx';
import {
  BadgeCheck,
  BriefcaseBusiness,
  Coins,
  Cpu,
  FileLock2,
  GanttChartSquare,
  Gauge,
  HardDriveUpload,
  Hexagon,
  ShieldAlert,
  Sparkles,
} from 'lucide-react';
import { initialJobs, providers } from './data';
import type { Job, JobStatus, Milestone, Provider } from './types';

type WizardState = {
  title: string;
  description: string;
  budgetUsd: number;
  cpu: number;
  memoryGb: number;
  gpu: string;
  maxRuntimeHours: number;
  artifactKind: 'IPFS' | 'Arweave';
  artifactCid: string;
};

const defaultWizard: WizardState = {
  title: 'Fraud detection inference batch',
  description:
    'Verify an off-chain model inference run with SP1 and escrow milestone payouts tied to proof verification.',
  budgetUsd: 18000,
  cpu: 48,
  memoryGb: 128,
  gpu: 'L40S x2',
  maxRuntimeHours: 4,
  artifactKind: 'IPFS',
  artifactCid: 'bafybeifraud-model-artifacts',
};

const statusTone: Record<JobStatus, string> = {
  Open: 'tone-open',
  'In Progress': 'tone-progress',
  'Awaiting Proof': 'tone-proof',
  'Milestone Review': 'tone-review',
  Completed: 'tone-complete',
  Slashed: 'tone-slashed',
};

function currency(value: number) {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  }).format(value);
}

function providerById(providerId?: string) {
  return providers.find((provider) => provider.id === providerId);
}

function milestoneProgress(milestones: Milestone[]) {
  const verified = milestones.filter((milestone) => milestone.proofStatus === 'Verified').length;
  return `${verified}/${milestones.length}`;
}

function App() {
  const [jobs, setJobs] = useState<Job[]>(initialJobs);
  const [wizard, setWizard] = useState<WizardState>(defaultWizard);
  const [selectedJobId, setSelectedJobId] = useState<string>(initialJobs[0]?.id ?? '');

  const selectedJob = jobs.find((job) => job.id === selectedJobId) ?? jobs[0];

  const marketplaceStats = useMemo(() => {
    const totalEscrow = jobs.reduce(
      (sum, job) => sum + job.milestones.filter((milestone) => milestone.escrowed).reduce((mSum, m) => mSum + m.payoutUsd, 0),
      0,
    );
    const totalBonded = providers.reduce((sum, provider) => sum + provider.bondedStakeUsd, 0);
    const pendingProofs = jobs.reduce(
      (sum, job) => sum + job.milestones.filter((milestone) => milestone.proofStatus === 'Pending').length,
      0,
    );

    return { totalEscrow, totalBonded, pendingProofs };
  }, [jobs]);

  const postJob = () => {
    const nextJob: Job = {
      id: `job-${Math.floor(Math.random() * 9000) + 1000}`,
      customer: 'New Customer',
      title: wizard.title,
      description: wizard.description,
      status: 'Open',
      budgetUsd: wizard.budgetUsd,
      resourceSpec: {
        cpu: wizard.cpu,
        memoryGb: wizard.memoryGb,
        gpu: wizard.gpu,
        maxRuntimeHours: wizard.maxRuntimeHours,
      },
      sp1Statement: {
        programVKey: 'sp1_vk_0xnewjob',
        publicValuesCommitment: '0xartifactboundcommitment',
        artifactRoot: wizard.artifactCid,
        executionImage: `${wizard.artifactKind === 'IPFS' ? 'ipfs://' : 'ar://'}bootstrap-manifest`,
      },
      artifacts: [
        {
          kind: wizard.artifactKind,
          cid: wizard.artifactCid,
          description: 'Primary job artifact bundle committed into the SP1 statement',
        },
      ],
      milestones: [
        {
          id: 'm1',
          name: 'Provider bond lock',
          payoutUsd: Math.round(wizard.budgetUsd * 0.25),
          dueLabel: 'Day 1',
          escrowed: true,
          proofStatus: 'Pending',
        },
        {
          id: 'm2',
          name: 'Execution + proof verification',
          payoutUsd: Math.round(wizard.budgetUsd * 0.5),
          dueLabel: 'Day 3',
          escrowed: true,
          proofStatus: 'Pending',
        },
        {
          id: 'm3',
          name: 'Artifact retention release',
          payoutUsd: Math.round(wizard.budgetUsd * 0.25),
          dueLabel: 'Day 5',
          escrowed: false,
          proofStatus: 'Pending',
        },
      ],
    };

    setJobs((currentJobs) => [nextJob, ...currentJobs]);
    setSelectedJobId(nextJob.id);
  };

  const acceptJob = (jobId: string, providerId: string) => {
    setJobs((currentJobs) =>
      currentJobs.map((job) =>
        job.id === jobId
          ? {
              ...job,
              status: 'In Progress',
              selectedProviderId: providerId,
            }
          : job,
      ),
    );
  };

  const verifyProof = (jobId: string) => {
    setJobs((currentJobs) =>
      currentJobs.map((job) =>
        job.id === jobId
          ? {
              ...job,
              status: 'Completed',
              milestones: job.milestones.map((milestone) => ({
                ...milestone,
                escrowed: true,
                proofStatus: 'Verified',
              })),
            }
          : job,
      ),
    );
  };

  const slashProvider = (jobId: string) => {
    setJobs((currentJobs) =>
      currentJobs.map((job) =>
        job.id === jobId
          ? {
              ...job,
              status: 'Slashed',
              milestones: job.milestones.map((milestone, index) =>
                index === job.milestones.length - 1
                  ? {
                      ...milestone,
                      escrowed: false,
                      proofStatus: 'Rejected',
                    }
                  : milestone,
              ),
            }
          : job,
      ),
    );
  };

  return (
    <div className="shell">
      <header className="hero">
        <div className="hero-copy">
          <span className="eyebrow">SP1 Verifiable Compute Exchange</span>
          <h1>Bonded providers, proof-backed execution, milestone escrow.</h1>
          <p>
            A decentralized compute marketplace for off-chain jobs where SP1 statements bind execution outputs,
            artifact hashes, and payout release conditions.
          </p>
          <div className="hero-actions">
            <button className="primary-button" onClick={postJob}>
              Post Sample Job
            </button>
            <div className="chip">
              <Sparkles size={16} />
              SP1 statements include IPFS/Arweave commitments
            </div>
          </div>
        </div>
        <div className="hero-grid">
          <MetricCard icon={<Coins size={18} />} label="Escrow Locked" value={currency(marketplaceStats.totalEscrow)} />
          <MetricCard icon={<ShieldAlert size={18} />} label="Provider Bonds" value={currency(marketplaceStats.totalBonded)} />
          <MetricCard icon={<FileLock2 size={18} />} label="Pending Proofs" value={String(marketplaceStats.pendingProofs)} />
          <MetricCard icon={<Gauge size={18} />} label="Active Jobs" value={String(jobs.length)} />
        </div>
      </header>

      <main className="layout">
        <section className="panel wizard-panel">
          <div className="panel-heading">
            <div>
              <span className="section-kicker">Customer Portal</span>
              <h2>Job Wizard</h2>
            </div>
            <BriefcaseBusiness size={20} />
          </div>
          <div className="form-grid">
            <label>
              Job title
              <input value={wizard.title} onChange={(event) => setWizard({ ...wizard, title: event.target.value })} />
            </label>
            <label>
              Budget
              <input
                type="number"
                value={wizard.budgetUsd}
                onChange={(event) => setWizard({ ...wizard, budgetUsd: Number(event.target.value) })}
              />
            </label>
            <label className="full">
              Description
              <textarea
                rows={4}
                value={wizard.description}
                onChange={(event) => setWizard({ ...wizard, description: event.target.value })}
              />
            </label>
            <label>
              CPU cores
              <input type="number" value={wizard.cpu} onChange={(event) => setWizard({ ...wizard, cpu: Number(event.target.value) })} />
            </label>
            <label>
              Memory (GB)
              <input
                type="number"
                value={wizard.memoryGb}
                onChange={(event) => setWizard({ ...wizard, memoryGb: Number(event.target.value) })}
              />
            </label>
            <label>
              GPU
              <input value={wizard.gpu} onChange={(event) => setWizard({ ...wizard, gpu: event.target.value })} />
            </label>
            <label>
              Runtime limit (hrs)
              <input
                type="number"
                value={wizard.maxRuntimeHours}
                onChange={(event) => setWizard({ ...wizard, maxRuntimeHours: Number(event.target.value) })}
              />
            </label>
            <label>
              Artifact network
              <select
                value={wizard.artifactKind}
                onChange={(event) =>
                  setWizard({
                    ...wizard,
                    artifactKind: event.target.value as WizardState['artifactKind'],
                  })
                }
              >
                <option value="IPFS">IPFS</option>
                <option value="Arweave">Arweave</option>
              </select>
            </label>
            <label className="full">
              Artifact content hash
              <input
                value={wizard.artifactCid}
                onChange={(event) => setWizard({ ...wizard, artifactCid: event.target.value })}
              />
            </label>
          </div>
          <button className="primary-button full-width" onClick={postJob}>
            Create Escrowed Job
          </button>
        </section>

        <section className="panel jobs-panel">
          <div className="panel-heading">
            <div>
              <span className="section-kicker">Customer Tracking</span>
              <h2>Jobs</h2>
            </div>
            <GanttChartSquare size={20} />
          </div>
          <div className="job-list">
            {jobs.map((job) => {
              const provider = providerById(job.selectedProviderId);
              return (
                <button
                  key={job.id}
                  className={clsx('job-card', selectedJob?.id === job.id && 'job-card-active')}
                  onClick={() => setSelectedJobId(job.id)}
                >
                  <div className="job-card-top">
                    <strong>{job.title}</strong>
                    <span className={clsx('status-pill', statusTone[job.status])}>{job.status}</span>
                  </div>
                  <p>{job.description}</p>
                  <div className="job-meta">
                    <span>{currency(job.budgetUsd)}</span>
                    <span>{provider?.name ?? 'Unassigned'}</span>
                    <span>{milestoneProgress(job.milestones)} milestones verified</span>
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        {selectedJob && (
          <>
            <section className="panel detail-panel">
              <div className="panel-heading">
                <div>
                  <span className="section-kicker">Execution Detail</span>
                  <h2>{selectedJob.title}</h2>
                </div>
                <Hexagon size={20} />
              </div>
              <div className="detail-grid">
                <DetailCard
                  icon={<Cpu size={18} />}
                  label="Resource spec"
                  value={`${selectedJob.resourceSpec.cpu} CPU / ${selectedJob.resourceSpec.memoryGb} GB / ${selectedJob.resourceSpec.gpu}`}
                />
                <DetailCard
                  icon={<HardDriveUpload size={18} />}
                  label="Artifact root"
                  value={selectedJob.sp1Statement.artifactRoot}
                />
                <DetailCard
                  icon={<BadgeCheck size={18} />}
                  label="Program vkey"
                  value={selectedJob.sp1Statement.programVKey}
                />
                <DetailCard
                  icon={<Coins size={18} />}
                  label="Escrow budget"
                  value={currency(selectedJob.budgetUsd)}
                />
              </div>
              <div className="statement-box">
                <h3>SP1 statement</h3>
                <code>{selectedJob.sp1Statement.publicValuesCommitment}</code>
                <p>
                  Public values bind the execution image, artifact root, and result commitment so escrow release is
                  conditional on valid proof verification.
                </p>
              </div>
              <div className="artifacts">
                {selectedJob.artifacts.map((artifact) => (
                  <div key={`${artifact.kind}-${artifact.cid}`} className="artifact-card">
                    <span>{artifact.kind}</span>
                    <strong>{artifact.cid}</strong>
                    <p>{artifact.description}</p>
                  </div>
                ))}
              </div>
              <div className="milestones">
                {selectedJob.milestones.map((milestone) => (
                  <div key={milestone.id} className="milestone-card">
                    <div>
                      <strong>{milestone.name}</strong>
                      <p>
                        {currency(milestone.payoutUsd)} · {milestone.dueLabel}
                      </p>
                    </div>
                    <div className="milestone-side">
                      <span className={clsx('status-pill', milestone.proofStatus === 'Verified' ? 'tone-complete' : milestone.proofStatus === 'Rejected' ? 'tone-slashed' : 'tone-proof')}>
                        {milestone.proofStatus}
                      </span>
                      <span>{milestone.escrowed ? 'Escrowed' : 'Released on verify'}</span>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            <section className="panel providers-panel">
              <div className="panel-heading">
                <div>
                  <span className="section-kicker">Provider Portal</span>
                  <h2>Accept Jobs and Submit Proofs</h2>
                </div>
                <ShieldAlert size={20} />
              </div>
              <div className="provider-list">
                {providers.map((provider) => (
                  <ProviderCard
                    key={provider.id}
                    provider={provider}
                    selected={selectedJob.selectedProviderId === provider.id}
                    onAccept={() => acceptJob(selectedJob.id, provider.id)}
                  />
                ))}
              </div>
              <div className="action-row">
                <button className="primary-button" onClick={() => verifyProof(selectedJob.id)}>
                  Verify SP1 Proof + Release Escrow
                </button>
                <button className="secondary-button" onClick={() => slashProvider(selectedJob.id)}>
                  Slash Provider For Invalid Proof
                </button>
              </div>
            </section>
          </>
        )}
      </main>
    </div>
  );
}

function MetricCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="metric-card">
      <div className="metric-icon">{icon}</div>
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function DetailCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="detail-card">
      <div className="metric-icon">{icon}</div>
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function ProviderCard({
  provider,
  selected,
  onAccept,
}: {
  provider: Provider;
  selected: boolean;
  onAccept: () => void;
}) {
  return (
    <div className={clsx('provider-card', selected && 'provider-card-selected')}>
      <div className="provider-top">
        <div>
          <h3>{provider.name}</h3>
          <p>
            {provider.region} · {provider.activeJobs} active jobs
          </p>
        </div>
        <span className="status-pill tone-complete">{provider.reputation} rep</span>
      </div>
      <div className="provider-stats">
        <span>Bonded: {currency(provider.bondedStakeUsd)}</span>
        <span>Success: {provider.successRate}%</span>
        <span>Slash events: {provider.slashEvents}</span>
      </div>
      <p className="provider-specialties">{provider.specialties.join(' · ')}</p>
      <button className={clsx(selected ? 'secondary-button' : 'primary-button')} onClick={onAccept}>
        {selected ? 'Assigned' : 'Accept Job'}
      </button>
    </div>
  );
}

export default App;
