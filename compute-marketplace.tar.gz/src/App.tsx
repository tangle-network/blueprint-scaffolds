import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Navbar } from './components/shared';
import HomePage from './pages/HomePage';
import CustomerDashboard from './pages/CustomerDashboard';
import JobWizard from './pages/JobWizard';
import JobDetail from './pages/JobDetail';
import ProviderDashboard from './pages/ProviderDashboard';
import ProviderRegister from './pages/ProviderRegister';
import SubmitProof from './pages/SubmitProof';
import ExplorerPage from './pages/ExplorerPage';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <main className="max-w-7xl mx-auto px-4 py-6">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/customer" element={<CustomerDashboard />} />
          <Route path="/customer/post" element={<JobWizard />} />
          <Route path="/customer/job/:id" element={<JobDetail />} />
          <Route path="/provider" element={<ProviderDashboard />} />
          <Route path="/provider/register" element={<ProviderRegister />} />
          <Route path="/provider/proof/:jobId" element={<SubmitProof />} />
          <Route path="/explorer" element={<ExplorerPage />} />
        </Routes>
      </main>
    </div>
  );
};

export default App;
