export type ResourceSpec = {
  cpu: number;
  memoryGb: number;
  gpu: string;
  maxRuntimeHours: number;
};

export type ArtifactRef = {
  kind: 'IPFS' | 'Arweave';
  cid: string;
  description: string;
};

export type Sp1Statement = {
  programVKey: string;
  publicValuesCommitment: string;
  artifactRoot: string;
  executionImage: string;
};

export type ProofStatus = 'Pending' | 'Verified' | 'Rejected';

export type JobStatus =
  | 'Open'
  | 'In Progress'
  | 'Awaiting Proof'
  | 'Milestone Review'
  | 'Completed'
  | 'Slashed';

export type Milestone = {
  id: string;
  name: string;
  payoutUsd: number;
  dueLabel: string;
  escrowed: boolean;
  proofStatus: ProofStatus;
};

export type Provider = {
  id: string;
  name: string;
  region: string;
  bondedStakeUsd: number;
  reputation: number;
  successRate: number;
  activeJobs: number;
  slashEvents: number;
  specialties: string[];
};

export type Job = {
  id: string;
  customer: string;
  title: string;
  description: string;
  status: JobStatus;
  budgetUsd: number;
  resourceSpec: ResourceSpec;
  selectedProviderId?: string;
  sp1Statement: Sp1Statement;
  artifacts: ArtifactRef[];
  milestones: Milestone[];
};
