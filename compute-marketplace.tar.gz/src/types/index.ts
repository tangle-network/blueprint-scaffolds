export enum JobStatus {
  Posted = "Posted",
  Matched = "Matched",
  Running = "Running",
  ProofSubmitted = "ProofSubmitted",
  Verified = "Verified",
  Completed = "Completed",
  Slashed = "Slashed",
  Disputed = "Disputed",
  Cancelled = "Cancelled",
}

export interface ResourceSpecs {
  cpuCores: number;
  memoryGB: number;
  storageGB: number;
  gpuRequired: boolean;
  gpuModel: string | null;
  estimatedDuration: number;
}

export interface Milestone {
  id: string;
  description: string;
  cid: string | null;
  reward: number;
  completedAt: number | null;
  proofCid: string | null;
}

export interface Job {
  id: string;
  title: string;
  description: string;
  customer: string;
  provider: string | null;
  status: JobStatus;
  resourceSpecs: ResourceSpecs;
  escrowAmount: number;
  milestones: Milestone[];
  createdAt: number;
  completedAt: number | null;
  sp1ProofVkey: string;
  artifactCid: string | null;
  resultCid: string | null;
  slashingAmount: number | null;
}

export interface Provider {
  id: string;
  address: string;
  reputation: number;
  totalJobs: number;
  successfulJobs: number;
  bondedAmount: number;
  status: "Active" | "Offline";
  joinedAt: number;
}

export interface Escrow {
  id: string;
  jobId: string;
  totalAmount: number;
  releasedAmount: number;
  milestonesReleased: number;
  status: "Locked" | "PartialRelease" | "FullyReleased" | "Refunded";
}
