export type JobStatus =
  | 'draft'
  | 'open'
  | 'assigned'
  | 'in_progress'
  | 'proof_submitted'
  | 'verified'
  | 'completed'
  | 'disputed'
  | 'cancelled'
  | 'slashed';

export type ProofStatus = 'pending' | 'verified' | 'rejected' | 'disputed';

export interface ResourceSpecs {
  cpuCores: number;
  memoryGB: number;
  storageGB: number;
  gpuRequired: boolean;
  gpuModel?: string;
  maxExecutionTimeSec: number;
}

export interface Milestone {
  id: string;
  description: string;
  percentage: number;
  amount: string;
  proofRequired: boolean;
  completed: boolean;
  artifactHash: string;
}

export interface Job {
  id: string;
  customerId: string;
  providerId: string | null;
  title: string;
  description: string;
  resourceSpecs: ResourceSpecs;
  status: JobStatus;
  reward: string;
  token: string;
  escrowAmount: string;
  milestones: Milestone[];
  createdAt: number;
  deadline: number;
  inputArtifactHash: string;
  outputArtifactHash: string | null;
  sp1ProgramHash: string;
  proofHash: string | null;
  proofStatus: ProofStatus | null;
  contentAddressStorage: 'ipfs' | 'arweave';
  tags: string[];
}

export interface Provider {
  id: string;
  address: string;
  bondAmount: string;
  reputation: number;
  jobsCompleted: number;
  jobsSlashed: number;
  availableResources: ResourceSpecs;
  supportedPrograms: string[];
  isActive: boolean;
  registeredAt: number;
}

export interface ProofSubmission {
  jobId: string;
  providerId: string;
  proofBytes: string;
  publicInputs: string[];
  sp1Version: string;
  verificationKey: string;
  submittedAt: number;
  status: ProofStatus;
  milestoneId?: string;
}

export interface SlashingEvent {
  id: string;
  providerId: string;
  jobId: string;
  reason: 'invalid_proof' | 'timeout' | 'data_mismatch' | 'fraud';
  bondSlashed: string;
  timestamp: number;
  evidenceHash: string;
}

export interface Escrow {
  jobId: string;
  totalAmount: string;
  releasedAmount: string;
  remainingAmount: string;
  milestones: {
    id: string;
    amount: string;
    released: boolean;
    releasedAt: number | null;
  }[];
  disputes: {
    id: string;
    raisedBy: string;
    reason: string;
    timestamp: number;
    resolved: boolean;
  }[];
}
