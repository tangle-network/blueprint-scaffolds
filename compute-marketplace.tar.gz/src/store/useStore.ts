import { create } from "zustand";
import type { Job, Provider, Escrow } from "@/types";

const ETH = (n: number) => BigInt(n * 1e18).toString();

const defaultJobs: Job[] = [
  {
    id: "job-001",
    title: "ML Inference Pipeline — ResNet-152 Batch Processing",
    description:
      "Run batch inference on 50,000 ImageNet-scale images using a pre-trained ResNet-152 model. Output top-5 predictions per image in JSON format. Requires high-memory GPU node with at least 24GB VRAM.",
    customer_address: "0x742d35Cc6634C0532925a3b844Bc9e7595f2bD18",
    resource_spec: {
      cpu_cores: 8,
      memory_gb: 64,
      storage_gb: 500,
      gpu_required: true,
      gpu_model: "NVIDIA A100 80GB",
      estimated_duration_secs: 14400,
    },
    reward_token: "ETH",
    reward_amount: ETH(4.5),
    escrow_amount: ETH(5.0),
    milestones: [
      { id: "ms-001-1", description: "Model loading & validation", reward_pct: 10, status: "COMPLETED", proof_hash: "QmX7bV9kL3pR2nS8wT4uY6iO0pA1cE5fG9hJ2kM4nB7q", completed_at: 1712000000 },
      { id: "ms-001-2", description: "Batch 1 (0–10k images)", reward_pct: 25, status: "COMPLETED", proof_hash: "QmY8cW0lM4qS5nT6vU7xZ9aB3dF1gH5iJ8kL2mN6oP0r", completed_at: 1712010000 },
      { id: "ms-001-3", description: "Batch 2 (10k–25k images)", reward_pct: 25, status: "COMPLETED", proof_hash: "QmZ9dX1nO5rT7wV8yA0bC4eG2hI6jK9lM3nN5oQ1sR4t", completed_at: 1712020000 },
      { id: "ms-001-4", description: "Batch 3 (25k–50k images)", reward_pct: 25, status: "IN_PROGRESS", proof_hash: null, completed_at: null },
      { id: "ms-001-5", description: "Results aggregation & delivery", reward_pct: 15, status: "PENDING", proof_hash: null, completed_at: null },
    ],
    status: "RUNNING",
    created_at: 1711950000,
    assigned_provider: "0xa1B2c3D4e5F6a7B8c9D0e1F2a3B4c5D6e7F8a9B0",
    proof: null,
    sp1_program_hash: "0x4a5e6f7c8d9b0a1e2f3c4d5b6a7e8f9c0d1b2a3e4f5c6d7b8a9e0f1c2b3a4e5f",
    input_data_hash: "QmRKq4nA3bB5cC7dD9eE1fF3gG5hH7iI9jJ1kK3lL5mM7nN9oO",
  },
  {
    id: "job-002",
    title: "Monte Carlo Simulation — European Option Pricing",
    description:
      "Run 10 million Monte Carlo paths for European call option pricing under Heston stochastic volatility model. Return convergence metrics, Greeks estimates, and confidence intervals.",
    customer_address: "0x8ba1f109551bD432803012645Ac136ddd64DBA72",
    resource_spec: {
      cpu_cores: 32,
      memory_gb: 128,
      storage_gb: 200,
      gpu_required: false,
      gpu_model: null,
      estimated_duration_secs: 7200,
    },
    reward_token: "ETH",
    reward_amount: ETH(2.8),
    escrow_amount: ETH(3.0),
    milestones: [
      { id: "ms-002-1", description: "Parameter validation & calibration", reward_pct: 20, status: "COMPLETED", proof_hash: "QmP1qR2sT3uV4wX5yZ6aB7cD8eF9gH0iJ1kL2mN3oP4q", completed_at: 1712100000 },
      { id: "ms-002-2", description: "Simulation execution (10M paths)", reward_pct: 50, status: "COMPLETED", proof_hash: "QmQ2rS3tU4vW5xY6zA7bC8dE9fG0hI1jK2lM3nO4pQ5r", completed_at: 1712110000 },
      { id: "ms-002-3", description: "Results computation & delivery", reward_pct: 30, status: "COMPLETED", proof_hash: "QmR3sT4uV5wX6yZ7aB8cD9eF0gH1iJ2kL3mN4oP5qR6s", completed_at: 1712120000 },
    ],
    status: "PROOF_SUBMITTED",
    created_at: 1712050000,
    assigned_provider: "0xfE4dC1b8A7960d2bB3cC4dD5eE6fF7aA8bB9cC0dD1",
    proof: {
      id: "proof-002",
      job_id: "job-002",
      sp1_proof_bytes: "0xabcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890",
      sp1_public_inputs: "0x0000000000000000000000000000000100000000000000000000000000989680000000000000000000000000000000000000000000000000000000000000001",
      submitted_at: 1712130000,
      verified: false,
      verifier_response: "Pending on-chain verification",
    },
    sp1_program_hash: "0x1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b",
    input_data_hash: "QmSN6vX4cB8dF2gH0jK6lM8nO2pQ4rS6tU8vW0xY2zA4bC6dE",
  },
  {
    id: "job-003",
    title: "ZK Circuit Witness Generation — Groth16 Proof",
    description:
      "Generate witnesses and Groth16 proofs for a zkSNARK circuit verifying private transaction validity. Circuit has ~2^20 constraints. Requires significant RAM for FFT operations.",
    customer_address: "0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045",
    resource_spec: {
      cpu_cores: 16,
      memory_gb: 256,
      storage_gb: 1000,
      gpu_required: false,
      gpu_model: null,
      estimated_duration_secs: 21600,
    },
    reward_token: "ETH",
    reward_amount: ETH(12.0),
    escrow_amount: ETH(13.0),
    milestones: [
      { id: "ms-003-1", description: "Circuit compilation & setup", reward_pct: 20, status: "COMPLETED", proof_hash: "QmA1bC2dE3fG4hI5jK6lM7nO8pQ9rS0tU1vW2xY3zA4b", completed_at: 1712200000 },
      { id: "ms-003-2", description: "Witness generation (Phase 1)", reward_pct: 30, status: "COMPLETED", proof_hash: "QmB2cD3eF4gH5iJ6kL7mN8oP9qR0sT1uV2wX3yZ4aC5b", completed_at: 1712220000 },
      { id: "ms-003-3", description: "Proof generation & verification", reward_pct: 30, status: "IN_PROGRESS", proof_hash: null, completed_at: null },
      { id: "ms-003-4", description: "Proof aggregation & submission", reward_pct: 20, status: "PENDING", proof_hash: null, completed_at: null },
    ],
    status: "RUNNING",
    created_at: 1712150000,
    assigned_provider: "0x5aAeb6053F3E94C9b9A09f33669435E7Ef1BeAed",
    proof: null,
    sp1_program_hash: "0x7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d",
    input_data_hash: "QmTN8vX6cD0eF4gH2jK8lN0nO4pQ6rS8tU0vW2xY4zA6bC8dE0fG",
  },
  {
    id: "job-004",
    title: "Protein Folding Simulation — AlphaFold2 Inference",
    description:
      "Run AlphaFold2 structure prediction on a batch of 200 SARS-CoV-2 variant protein sequences. Output PDB files with pLDDT confidence scores. Requires GPU acceleration.",
    customer_address: "0x742d35Cc6634C0532925a3b844Bc9e7595f2bD18",
    resource_spec: {
      cpu_cores: 16,
      memory_gb: 128,
      storage_gb: 800,
      gpu_required: true,
      gpu_model: "NVIDIA H100 80GB",
      estimated_duration_secs: 28800,
    },
    reward_token: "ETH",
    reward_amount: ETH(25.0),
    escrow_amount: ETH(26.0),
    milestones: [
      { id: "ms-004-1", description: "MSA generation & template search", reward_pct: 20, status: "COMPLETED", proof_hash: "QmC3dE4fG5hI6jK7lM8nO9pQ0rS1tU2vW3xY4zA5bD6c", completed_at: 1712300000 },
      { id: "ms-004-2", description: "Structure prediction (Batch 1: 1–100)", reward_pct: 30, status: "COMPLETED", proof_hash: "QmD4eF5gH6iJ7kL8mN9oP0qR1sT2uV3wX4yZ5aB6cE7d", completed_at: 1712350000 },
      { id: "ms-004-3", description: "Structure prediction (Batch 2: 101–200)", reward_pct: 30, status: "COMPLETED", proof_hash: "QmE5fG6hI7jK8lM9nO0pQ1rS2tU3vW4xY5zA6bC7dF8e", completed_at: 1712400000 },
      { id: "ms-004-4", description: "Quality assessment & PDB export", reward_pct: 20, status: "COMPLETED", proof_hash: "QmF6gH7iJ8kL9mN0oP1qR2sT3uV4wX5yZ6aB7cD8eG9f", completed_at: 1712450000 },
    ],
    status: "COMPLETED",
    created_at: 1712250000,
    assigned_provider: "0xa1B2c3D4e5F6a7B8c9D0e1F2a3B4c5D6e7F8a9B0",
    proof: {
      id: "proof-004",
      job_id: "job-004",
      sp1_proof_bytes: "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890",
      sp1_public_inputs: "0x000000000000000000000000000000c80000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001",
      submitted_at: 1712450000,
      verified: true,
      verifier_response: "Proof verified successfully on-chain. Transaction: 0xabc123...",
    },
    sp1_program_hash: "0x2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c",
    input_data_hash: "QmUN0vX8cD2eF6gH4jK0lM2nO6pQ8rS0tU2vW4xY6zA8bC0dE2fG4hI",
  },
  {
    id: "job-005",
    title: "DeFi MEV Analysis — Backtesting Engine",
    description:
      "Run comprehensive MEV extraction backtesting across Uniswap V3 pools for the past 12 months. Analyze sandwich attacks, arbitrage opportunities, and JIT liquidity strategies. Output statistical report.",
    customer_address: "0x8ba1f109551bD432803012645Ac136ddd64DBA72",
    resource_spec: {
      cpu_cores: 64,
      memory_gb: 512,
      storage_gb: 2000,
      gpu_required: false,
      gpu_model: null,
      estimated_duration_secs: 36000,
    },
    reward_token: "ETH",
    reward_amount: ETH(8.0),
    escrow_amount: ETH(9.0),
    milestones: [
      { id: "ms-005-1", description: "Historical data ingestion & indexing", reward_pct: 25, status: "COMPLETED", proof_hash: "QmG7hI8jK9lM0nO1pQ2rS3tU4vW5xY6zA7bC8dE9fH0g", completed_at: 1712500000 },
      { id: "ms-005-2", description: "MEV simulation across all pools", reward_pct: 40, status: "COMPLETED", proof_hash: "QmH8iJ9kL0mN1oP2qR3sT4uV5wX6yZ7aB8cD9eF0gI1h", completed_at: 1712560000 },
      { id: "ms-005-3", description: "Statistical report generation", reward_pct: 35, status: "IN_PROGRESS", proof_hash: null, completed_at: null },
    ],
    status: "VERIFIED",
    created_at: 1712400000,
    assigned_provider: "0xfE4dC1b8A7960d2bB3cC4dD5eE6fF7aA8bB9cC0dD1",
    proof: {
      id: "proof-005",
      job_id: "job-005",
      sp1_proof_bytes: "0x567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890ab",
      sp1_public_inputs: "0x0000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001",
      submitted_at: 1712600000,
      verified: true,
      verifier_response: "Proof verified on-chain. All 3 milestones confirmed. Tx: 0xdef456...",
    },
    sp1_program_hash: "0x3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d",
    input_data_hash: "QmVO1vX3cD5eF7gH1jK3lM5nO7pQ9rS1tU3vW5xY7zA9bC1dE3fG5hI7",
  },
  {
    id: "job-006",
    title: "Genomic Variant Calling — WGS Pipeline",
    description:
      "Run GATK best-practices variant calling pipeline on 50 whole-genome sequencing samples (30x coverage). Requires significant I/O throughput and temporary storage for intermediate BAM/CRAM files.",
    customer_address: "0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045",
    resource_spec: {
      cpu_cores: 48,
      memory_gb: 256,
      storage_gb: 5000,
      gpu_required: false,
      gpu_model: null,
      estimated_duration_secs: 43200,
    },
    reward_token: "ETH",
    reward_amount: ETH(18.5),
    escrow_amount: ETH(19.5),
    milestones: [
      { id: "ms-006-1", description: "FASTQ QC & alignment", reward_pct: 25, status: "PENDING", proof_hash: null, completed_at: null },
      { id: "ms-006-2", description: "Mark duplicates & base recalibration", reward_pct: 25, status: "PENDING", proof_hash: null, completed_at: null },
      { id: "ms-006-3", description: "Variant calling (HaplotypeCaller)", reward_pct: 30, status: "PENDING", proof_hash: null, completed_at: null },
      { id: "ms-006-4", description: "VQSR filtering & final VCF export", reward_pct: 20, status: "PENDING", proof_hash: null, completed_at: null },
    ],
    status: "POSTED",
    created_at: 1712650000,
    assigned_provider: null,
    proof: null,
    sp1_program_hash: "0x5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f",
    input_data_hash: "QmWP2vX4cD6eF8gH0jK2lM4nO6pQ8rS0tU2vW4xY6zA8bC0dE2fG4hI6jK",
  },
];

const defaultProviders: Provider[] = [
  {
    address: "0xa1B2c3D4e5F6a7B8c9D0e1F2a3B4c5D6e7F8a9B0",
    bonded_amount: ETH(50),
    reputation_score: 942,
    jobs_completed: 187,
    jobs_slashed: 2,
    sp1_vk_hash: "0xAbC123dEf456gHa789iBc012dEe345fFa678bCc901dEf234aBc567dEe890fFa123",
    status: "ACTIVE",
  },
  {
    address: "0xfE4dC1b8A7960d2bB3cC4dD5eE6fF7aA8bB9cC0dD1",
    bonded_amount: ETH(30),
    reputation_score: 876,
    jobs_completed: 134,
    jobs_slashed: 5,
    sp1_vk_hash: "0xBcD234eF567hIb890jCd123eFf456gGb789cDd012eFf345bCd678eFf901gGb234",
    status: "ACTIVE",
  },
  {
    address: "0x5aAeb6053F3E94C9b9A09f33669435E7Ef1BeAed",
    bonded_amount: ETH(15),
    reputation_score: 734,
    jobs_completed: 89,
    jobs_slashed: 3,
    sp1_vk_hash: "0xCdE345fG678iJc901kDe234fGg567hHc890dEe123fGg456cDe789fGg012hHc345",
    status: "ACTIVE",
  },
  {
    address: "0x1f9090aaE28b8a3dCeaDf281B0F12828e676c326",
    bonded_amount: ETH(5),
    reputation_score: 412,
    jobs_completed: 23,
    jobs_slashed: 1,
    sp1_vk_hash: "0xDeF456gH789jKd012lEf345gHh678iId901eFf234gHh567dEf890gHh123iId456",
    status: "INACTIVE",
  },
];

const defaultEscrows: Escrow[] = [
  { id: "esc-001", job_id: "job-001", total_amount: ETH(5.0), released_amount: ETH(1.75), refunded_amount: "0", status: "LOCKED" },
  { id: "esc-002", job_id: "job-002", total_amount: ETH(3.0), released_amount: ETH(3.0), refunded_amount: "0", status: "LOCKED" },
  { id: "esc-003", job_id: "job-003", total_amount: ETH(13.0), released_amount: ETH(6.5), refunded_amount: "0", status: "LOCKED" },
  { id: "esc-004", job_id: "job-004", total_amount: ETH(26.0), released_amount: ETH(26.0), refunded_amount: "0", status: "FULLY_RELEASED" },
  { id: "esc-005", job_id: "job-005", total_amount: ETH(9.0), released_amount: ETH(5.85), refunded_amount: "0", status: "PARTIAL_RELEASE" },
  { id: "esc-006", job_id: "job-006", total_amount: ETH(19.5), released_amount: "0", refunded_amount: "0", status: "LOCKED" },
];

interface AppState {
  jobs: Job[];
  providers: Provider[];
  escrows: Escrow[];
  addJob: (job: Job) => void;
  updateJobStatus: (jobId: string, status: Job["status"]) => void;
  addProof: (jobId: string, proof: Job["proof"]) => void;
  updateEscrow: (escrowId: string, updates: Partial<Escrow>) => void;
}

export const useStore = create<AppState>((set) => ({
  jobs: defaultJobs,
  providers: defaultProviders,
  escrows: defaultEscrows,
  addJob: (job) => set((s) => ({ jobs: [...s.jobs, job] })),
  updateJobStatus: (jobId, status) =>
    set((s) => ({
      jobs: s.jobs.map((j) => (j.id === jobId ? { ...j, status } : j)),
    })),
  addProof: (jobId, proof) =>
    set((s) => ({
      jobs: s.jobs.map((j) => (j.id === jobId ? { ...j, proof } : j)),
    })),
  updateEscrow: (escrowId, updates) =>
    set((s) => ({
      escrows: s.escrows.map((e) => (e.id === escrowId ? { ...e, ...updates } : e)),
    })),
}));
