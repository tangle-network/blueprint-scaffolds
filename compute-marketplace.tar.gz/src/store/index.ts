import { create } from 'zustand';
import type { Job, Provider, ProofSubmission, SlashingEvent, Escrow } from '../types';

interface MarketplaceState {
  jobs: Job[];
  providers: Provider[];
  proofs: ProofSubmission[];
  slashingEvents: SlashingEvent[];
  escrows: Escrow[];
  currentAccount: string | null;
  role: 'customer' | 'provider' | null;

  setJobs: (jobs: Job[]) => void;
  addJob: (job: Job) => void;
  updateJob: (id: string, updates: Partial<Job>) => void;
  setProviders: (providers: Provider[]) => void;
  addProvider: (provider: Provider) => void;
  updateProvider: (id: string, updates: Partial<Provider>) => void;
  addProof: (proof: ProofSubmission) => void;
  updateProof: (jobId: string, status: ProofSubmission['status']) => void;
  addSlashingEvent: (event: SlashingEvent) => void;
  setEscrow: (escrow: Escrow) => void;
  updateEscrow: (jobId: string, updates: Partial<Escrow>) => void;
  setCurrentAccount: (account: string | null) => void;
  setRole: (role: 'customer' | 'provider' | null) => void;
}

export const useStore = create<MarketplaceState>((set) => ({
  jobs: [],
  providers: [],
  proofs: [],
  slashingEvents: [],
  escrows: [],
  currentAccount: null,
  role: null,

  setJobs: (jobs) => set({ jobs }),
  addJob: (job) => set((s) => ({ jobs: [...s.jobs, job] })),
  updateJob: (id, updates) =>
    set((s) => ({
      jobs: s.jobs.map((j) => (j.id === id ? { ...j, ...updates } : j)),
    })),
  setProviders: (providers) => set({ providers }),
  addProvider: (provider) => set((s) => ({ providers: [...s.providers, provider] })),
  updateProvider: (id, updates) =>
    set((s) => ({
      providers: s.providers.map((p) => (p.id === id ? { ...p, ...updates } : p)),
    })),
  addProof: (proof) => set((s) => ({ proofs: [...s.proofs, proof] })),
  updateProof: (jobId, status) =>
    set((s) => ({
      proofs: s.proofs.map((p) => (p.jobId === jobId ? { ...p, status } : p)),
    })),
  addSlashingEvent: (event) =>
    set((s) => ({ slashingEvents: [...s.slashingEvents, event] })),
  setEscrow: (escrow) => set((s) => ({ escrows: [...s.escrows, escrow] })),
  updateEscrow: (jobId, updates) =>
    set((s) => ({
      escrows: s.escrows.map((e) => (e.jobId === jobId ? { ...e, ...updates } : e)),
    })),
  setCurrentAccount: (account) => set({ currentAccount: account }),
  setRole: (role) => set({ role }),
}));
