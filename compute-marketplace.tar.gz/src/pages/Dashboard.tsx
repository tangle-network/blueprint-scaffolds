import { useStore } from "@/store/useStore";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { StatusBadge } from "@/components/StatusBadge";
import { AddressDisplay } from "@/components/AddressDisplay";
import { formatEth, formatTimestamp, formatAddress } from "@/lib/utils";
import { Link } from "react-router-dom";
import { Briefcase, Server, Lock, ShieldCheck } from "lucide-react";

export default function Dashboard() {
  const { jobs, providers, escrows } = useStore();

  const totalEscrowed = escrows.reduce((sum, e) => sum + BigInt(e.total_amount), 0n);
  const proofsVerified = jobs.filter((j) => j.proof?.verified).length;
  const activeProviders = providers.filter((p) => p.status === "ACTIVE").length;

  const stats = [
    { title: "Total Jobs", value: jobs.length, icon: Briefcase, color: "text-blue-400" },
    { title: "Active Providers", value: activeProviders, icon: Server, color: "text-green-400" },
    { title: "Total Escrowed", value: formatEth(totalEscrowed.toString()), icon: Lock, color: "text-yellow-400" },
    { title: "Proofs Verified", value: proofsVerified, icon: ShieldCheck, color: "text-emerald-400" },
  ];

  const recentJobs = [...jobs].sort((a, b) => b.created_at - a.created_at).slice(0, 5);
  const sortedProviders = [...providers].sort((a, b) => b.reputation_score - a.reputation_score);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground mt-1">Overview of the SP1 Compute Marketplace</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s) => (
          <Card key={s.title}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">{s.title}</CardTitle>
              <s.icon className={`h-5 w-5 ${s.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{s.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Recent Jobs</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Title</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead className="text-right">Reward</TableHead>
                    <TableHead className="text-right">Posted</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentJobs.map((job) => (
                    <TableRow key={job.id}>
                      <TableCell>
                        <Link to={`/jobs/${job.id}`} className="font-medium hover:underline">
                          {job.title.length > 40 ? job.title.slice(0, 40) + "..." : job.title}
                        </Link>
                      </TableCell>
                      <TableCell><StatusBadge status={job.status} /></TableCell>
                      <TableCell><AddressDisplay address={job.customer_address} showCopy={false} /></TableCell>
                      <TableCell className="text-right font-mono text-sm">{formatEth(job.reward_amount)}</TableCell>
                      <TableCell className="text-right text-xs text-muted-foreground">{formatTimestamp(job.created_at)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Provider Leaderboard</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {sortedProviders.map((p, i) => (
                <div key={p.address} className="flex items-center gap-3">
                  <span className={`text-lg font-bold ${i === 0 ? "text-yellow-400" : i === 1 ? "text-gray-300" : i === 2 ? "text-amber-600" : "text-muted-foreground"}`}>
                    #{i + 1}
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm">{formatAddress(p.address)}</span>
                      <StatusBadge status={p.status} />
                    </div>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      Rep: {p.reputation_score}/1000 | {p.jobs_completed} jobs | Bond: {formatEth(p.bonded_amount)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
