import React from 'react'

export default function ProviderRegister() { return <div>ProviderRegister</div> }
