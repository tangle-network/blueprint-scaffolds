import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useStore } from '../store';
import { JobCard } from '../components/shared';

type Filter = 'all' | 'open' | 'in_progress' | 'completed' | 'disputed';

const CustomerDashboard: React.FC = () => {
  const { jobs, currentAccount } = useStore();
  const [filter, setFilter] = useState<Filter>('all');

  const myJobs = currentAccount
    ? jobs.filter((j) => j.customerId === currentAccount)
    : jobs;

  const filtered = filter === 'all' ? myJobs : myJobs.filter((j) => j.status === filter);

  const counts: Record<string, number> = { all: myJobs.length };
  for (const j of myJobs) {
    counts[j.status] = (counts[j.status] || 0) + 1;
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Customer Dashboard</h1>
          <p className="text-gray-500 mt-1">
            {myJobs.length} jobs posted &middot; {counts.open || 0} open
          </p>
        </div>
        <Link
          to="/customer/post"
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-lg font-medium transition-colors"
        >
          + New Job
        </Link>
      </div>

      <div className="flex gap-2 mb-6">
        {(['all', 'open', 'in_progress', 'completed', 'disputed'] as Filter[]).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
              filter === f
                ? 'bg-indigo-100 text-indigo-700'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            {f === 'all' ? 'All' : f.replace(/_/g, ' ')} ({f === 'all' ? myJobs.length : (counts[f] || 0)})
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-20">
          <p className="text-gray-400 text-lg mb-4">No jobs found</p>
          <Link to="/customer/post" className="text-indigo-600 hover:text-indigo-700 font-medium">
            Post your first compute job
          </Link>
        </div>
      ) : (
        <div className="grid gap-4">
          {filtered.map((job) => (
            <Link key={job.id} to={`/customer/job/${job.id}`}>
              <JobCard job={job} />
            </Link>
          ))}
        </div>
      )}
    </div>
  );
};

export default CustomerDashboard;
