import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store';
import type { Job, ResourceSpecs, Milestone } from '../types';
import { generateId } from '../utils';

type Step = 'details' | 'resources' | 'milestones' | 'review';

const STEPS: { key: Step; label: string }[] = [
  { key: 'details', label: 'Job Details' },
  { key: 'resources', label: 'Resource Specs' },
  { key: 'milestones', label: 'Milestones & Escrow' },
  { key: 'review', label: 'Review & Submit' },
];

const JobWizard: React.FC = () => {
  const navigate = useNavigate();
  const { addJob, setEscrow, currentAccount, setCurrentAccount } = useStore();

  const [step, setStep] = useState<Step>('details');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [sp1ProgramHash, setSp1ProgramHash] = useState('');
  const [inputArtifactHash, setInputArtifactHash] = useState('');
  const [storageType, setStorageType] = useState<'ipfs' | 'arweave'>('ipfs');
  const [tags, setTags] = useState('');
  const [reward, setReward] = useState('');
  const [deadline, setDeadline] = useState('');
  const [specs, setSpecs] = useState<ResourceSpecs>({
    cpuCores: 4,
    memoryGB: 16,
    storageGB: 100,
    gpuRequired: false,
    maxExecutionTimeSec: 3600,
  });
  const [milestones, setMilestones] = useState<Milestone[]>([
    { id: '1', description: 'Initial setup and validation', percentage: 25, amount: '', proofRequired: true, completed: false, artifactHash: '' },
    { id: '2', description: 'Main computation', percentage: 50, amount: '', proofRequired: true, completed: false, artifactHash: '' },
    { id: '3', description: 'Final delivery', percentage: 25, amount: '', proofRequired: true, completed: false, artifactHash: '' },
  ]);
  const [submitting, setSubmitting] = useState(false);

  const stepIdx = STEPS.findIndex((s) => s.key === step);

  const updateMilestone = (idx: number, field: keyof Milestone, value: string | boolean | number) => {
    setMilestones((prev) => prev.map((m, i) => (i === idx ? { ...m, [field]: value } : m)));
  };

  const addMilestone = () => {
    setMilestones((prev) => [
      ...prev,
      {
        id: String(prev.length + 1),
        description: '',
        percentage: 0,
        amount: '',
        proofRequired: true,
        completed: false,
        artifactHash: '',
      },
    ]);
  };

  const removeMilestone = (idx: number) => {
    setMilestones((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    if (!currentAccount) {
      setCurrentAccount('0x' + Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join(''));
    }
    const account = currentAccount || '0x' + Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    await new Promise((r) => setTimeout(r, 1200));

    const rewardWei = String(parseFloat(reward || '0.1') * 1e18);
    const job: Job = {
      id: generateId(),
      customerId: account,
      providerId: null,
      title,
      description,
      resourceSpecs: specs,
      status: 'open',
      reward: rewardWei,
      token: 'ETH',
      escrowAmount: rewardWei,
      milestones: milestones.map((m) => ({ ...m, amount: String((parseFloat(reward || '0.1') * m.percentage / 100) * 1e18) })),
      createdAt: Date.now(),
      deadline: deadline ? new Date(deadline).getTime() : Date.now() + 7 * 86400000,
      inputArtifactHash,
      outputArtifactHash: null,
      sp1ProgramHash,
      proofHash: null,
      proofStatus: null,
      contentAddressStorage: storageType,
      tags: tags.split(',').map((t) => t.trim()).filter(Boolean),
    };

    addJob(job);
    setEscrow({
      jobId: job.id,
      totalAmount: rewardWei,
      releasedAmount: '0',
      remainingAmount: rewardWei,
      milestones: job.milestones.map((m) => ({ id: m.id, amount: m.amount, released: false, releasedAt: null })),
      disputes: [],
    });
    setSubmitting(false);
    navigate(`/customer/job/${job.id}`);
  };

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Post Compute Job</h1>

      <div className="flex items-center mb-8">
        {STEPS.map((s, i) => (
          <React.Fragment key={s.key}>
            <button
              onClick={() => i < stepIdx && setStep(s.key)}
              className={`flex items-center gap-2 ${
                i <= stepIdx ? 'text-indigo-600' : 'text-gray-400'
              }`}
            >
              <span
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                  i < stepIdx
                    ? 'bg-indigo-600 text-white'
                    : i === stepIdx
                    ? 'bg-indigo-100 text-indigo-600 border-2 border-indigo-600'
                    : 'bg-gray-100 text-gray-400'
                }`}
              >
                {i + 1}
              </span>
              <span className="text-sm font-medium hidden sm:inline">{s.label}</span>
            </button>
            {i < STEPS.length - 1 && (
              <div className={`flex-1 h-0.5 mx-3 ${i < stepIdx ? 'bg-indigo-600' : 'bg-gray-200'}`} />
            )}
          </React.Fragment>
        ))}
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        {step === 'details' && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Job Title</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., Monte Carlo Simulation"
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={4}
                placeholder="Describe the computation task..."
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none resize-none"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">SP1 Program Hash</label>
                <input
                  type="text"
                  value={sp1ProgramHash}
                  onChange={(e) => setSp1ProgramHash(e.target.value)}
                  placeholder="0x..."
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none font-mono"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Input Artifact Hash</label>
                <input
                  type="text"
                  value={inputArtifactHash}
                  onChange={(e) => setInputArtifactHash(e.target.value)}
                  placeholder="Qm... / ar://"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none font-mono"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Storage Backend</label>
                <select
                  value={storageType}
                  onChange={(e) => setStorageType(e.target.value as 'ipfs' | 'arweave')}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                >
                  <option value="ipfs">IPFS</option>
                  <option value="arweave">Arweave</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tags (comma separated)</label>
                <input
                  type="text"
                  value={tags}
                  onChange={(e) => setTags(e.target.value)}
                  placeholder="ml, simulation, rust"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                />
              </div>
            </div>
          </div>
        )}

        {step === 'resources' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">CPU Cores</label>
                <input
                  type="number"
                  value={specs.cpuCores}
                  onChange={(e) => setSpecs({ ...specs, cpuCores: parseInt(e.target.value) || 0 })}
                  min={1}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Memory (GB)</label>
                <input
                  type="number"
                  value={specs.memoryGB}
                  onChange={(e) => setSpecs({ ...specs, memoryGB: parseInt(e.target.value) || 0 })}
                  min={1}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Storage (GB)</label>
                <input
                  type="number"
                  value={specs.storageGB}
                  onChange={(e) => setSpecs({ ...specs, storageGB: parseInt(e.target.value) || 0 })}
                  min={1}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Max Execution Time (sec)</label>
                <input
                  type="number"
                  value={specs.maxExecutionTimeSec}
                  onChange={(e) => setSpecs({ ...specs, maxExecutionTimeSec: parseInt(e.target.value) || 0 })}
                  min={60}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                />
              </div>
            </div>
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                id="gpuRequired"
                checked={specs.gpuRequired}
                onChange={(e) => setSpecs({ ...specs, gpuRequired: e.target.checked })}
                className="h-4 w-4 text-indigo-600 rounded border-gray-300"
              />
              <label htmlFor="gpuRequired" className="text-sm font-medium text-gray-700">GPU Required</label>
            </div>
            {specs.gpuRequired && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">GPU Model</label>
                <input
                  type="text"
                  value={specs.gpuModel || ''}
                  onChange={(e) => setSpecs({ ...specs, gpuModel: e.target.value })}
                  placeholder="e.g., A100, H100"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                />
              </div>
            )}
          </div>
        )}

        {step === 'milestones' && (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4 mb-2">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Total Reward (ETH)</label>
                <input
                  type="text"
                  value={reward}
                  onChange={(e) => setReward(e.target.value)}
                  placeholder="0.5"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Deadline</label>
                <input
                  type="date"
                  value={deadline}
                  onChange={(e) => setDeadline(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                />
              </div>
              <div className="flex items-end">
                <p className="text-sm text-gray-500">
                  Total: <strong>{reward || '0'} ETH</strong> escrowed
                </p>
              </div>
            </div>

            <div className="border-t border-gray-200 pt-4">
              <h3 className="text-sm font-semibold text-gray-900 mb-3">Milestones</h3>
              {milestones.map((m, idx) => (
                <div key={m.id} className="flex items-start gap-3 mb-3 p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1 grid grid-cols-3 gap-3">
                    <input
                      type="text"
                      value={m.description}
                      onChange={(e) => updateMilestone(idx, 'description', e.target.value)}
                      placeholder="Description"
                      className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                    />
                    <input
                      type="number"
                      value={m.percentage}
                      onChange={(e) => updateMilestone(idx, 'percentage', parseInt(e.target.value) || 0)}
                      placeholder="%"
                      min={0}
                      max={100}
                      className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                    />
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={m.proofRequired}
                        onChange={(e) => updateMilestone(idx, 'proofRequired', e.target.checked)}
                        className="h-4 w-4 text-indigo-600 rounded"
                      />
                      <span className="text-xs text-gray-500">SP1 Proof</span>
                    </div>
                  </div>
                  <button
                    onClick={() => removeMilestone(idx)}
                    className="text-red-400 hover:text-red-600 text-sm mt-2"
                  >
                    Remove
                  </button>
                </div>
              ))}
              <button
                onClick={addMilestone}
                className="text-indigo-600 hover:text-indigo-700 text-sm font-medium"
              >
                + Add Milestone
              </button>
              <p className="text-xs text-gray-400 mt-2">
                Total: {milestones.reduce((a, m) => a + m.percentage, 0)}% of escrow
              </p>
            </div>
          </div>
        )}

        {step === 'review' && (
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900">Job Summary</h3>
            <div className="bg-gray-50 rounded-lg p-4 space-y-2 text-sm">
              <p><strong>Title:</strong> {title || '(not set)'}</p>
              <p><strong>Description:</strong> {description || '(not set)'}</p>
              <p><strong>SP1 Program:</strong> <code className="text-xs">{sp1ProgramHash || '(not set)'}</code></p>
              <p><strong>Input Artifact:</strong> <code className="text-xs">{inputArtifactHash || '(not set)'}</code></p>
              <p><strong>Storage:</strong> {storageType.toUpperCase()}</p>
              <p><strong>Resources:</strong> {specs.cpuCores} CPU, {specs.memoryGB}GB RAM, {specs.storageGB}GB storage{specs.gpuRequired ? `, GPU: ${specs.gpuModel || 'required'}` : ''}</p>
              <p><strong>Reward:</strong> {reward || '0'} ETH</p>
              <p><strong>Milestones:</strong> {milestones.length} ({milestones.reduce((a, m) => a + m.percentage, 0)}% allocated)</p>
              <p><strong>Tags:</strong> {tags || '(none)'}</p>
            </div>

            {milestones.map((m, idx) => (
              <div key={m.id} className="flex items-center justify-between text-sm border-b border-gray-100 pb-2">
                <span>{m.description || `Milestone ${idx + 1}`}</span>
                <span className="text-gray-500">{m.percentage}% &middot; {m.proofRequired ? 'SP1 proof required' : 'No proof'}</span>
              </div>
            ))}
          </div>
        )}

        <div className="flex justify-between mt-6 pt-4 border-t border-gray-200">
          <button
            onClick={() => {
              const prev = STEPS[stepIdx - 1];
              if (prev) setStep(prev.key);
            }}
            disabled={stepIdx === 0}
            className="px-4 py-2 rounded-lg text-sm font-medium text-gray-600 hover:bg-gray-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            Back
          </button>
          {stepIdx < STEPS.length - 1 ? (
            <button
              onClick={() => {
                const next = STEPS[stepIdx + 1];
                if (next) setStep(next.key);
              }}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-lg text-sm font-medium transition-colors"
            >
              Next
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={submitting}
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2 rounded-lg text-sm font-medium transition-colors disabled:opacity-50"
            >
              {submitting ? 'Submitting...' : 'Submit Job & Fund Escrow'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default JobWizard;
