import React from 'react';
import { Link } from 'react-router-dom';
import { useStore } from '../store';

const STATS = [
  { label: 'Total Jobs', value: '1,247', change: '+12%' },
  { label: 'Active Providers', value: '89', change: '+5%' },
  { label: 'Total ETH Escrowed', value: '4,521', change: '+8%' },
  { label: 'Proofs Verified', value: '9,831', change: '+15%' },
];

const FEATURES = [
  {
    title: 'Post Compute Jobs',
    desc: 'Define resource specs, milestones, and rewards. Artifacts stored on IPFS/Arweave with content hashes in SP1 statements.',
    link: '/customer/post',
    cta: 'Create Job',
    color: 'bg-indigo-600 hover:bg-indigo-700',
  },
  {
    title: 'Become a Provider',
    desc: 'Bond stake, build reputation through verified computation. Accept jobs and submit SP1 zkVM proofs of correct execution.',
    link: '/provider/register',
    cta: 'Register',
    color: 'bg-emerald-600 hover:bg-emerald-700',
  },
  {
    title: 'Explore Marketplace',
    desc: 'Browse open jobs, track proof verification, monitor slashing events, and inspect escrow states.',
    link: '/explorer',
    cta: 'Explore',
    color: 'bg-purple-600 hover:bg-purple-700',
  },
];

const HOW_IT_WORKS = [
  { step: '1', title: 'Post Job', desc: 'Customer specifies compute requirements, uploads input data to IPFS/Arweave, funds escrow with milestones.' },
  { step: '2', title: 'Provider Accepts', desc: 'Provider bonds stake, downloads input artifacts, executes the SP1 program off-chain.' },
  { step: '3', title: 'Proof Generated', desc: 'SP1 zkVM generates a succinct proof of correct execution. Content hashes are embedded in the proof statement.' },
  { step: '4', title: 'Verified & Paid', desc: 'Proof verified on-chain. Milestone payments released from escrow. Invalid proofs trigger slashing.' },
];

const HomePage: React.FC = () => {
  const { jobs, providers } = useStore();

  return (
    <div>
      <section className="text-center py-16">
        <h1 className="text-5xl font-bold text-gray-900 mb-4">
          Verifiable Compute <span className="text-indigo-600">Marketplace</span>
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
          Decentralized computation powered by SP1 zkVM. Cryptographically proven results with trustless escrow and provider reputation.
        </p>
        <div className="flex justify-center gap-4">
          <Link
            to="/customer/post"
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-lg font-medium transition-colors"
          >
            Post a Job
          </Link>
          <Link
            to="/explorer"
            className="bg-white border border-gray-300 hover:border-gray-400 text-gray-700 px-6 py-3 rounded-lg font-medium transition-colors"
          >
            Browse Jobs
          </Link>
        </div>
      </section>

      <section className="grid grid-cols-4 gap-4 mb-16">
        {STATS.map((s) => (
          <div key={s.label} className="bg-white rounded-xl border border-gray-200 p-5 text-center">
            <p className="text-2xl font-bold text-gray-900">{s.value}</p>
            <p className="text-sm text-gray-500 mt-1">{s.label}</p>
            <p className="text-xs text-green-600 mt-1">{s.change}</p>
          </div>
        ))}
      </section>

      <section className="mb-16">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">How It Works</h2>
        <div className="grid grid-cols-4 gap-6">
          {HOW_IT_WORKS.map((item) => (
            <div key={item.step} className="relative">
              <div className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center text-lg font-bold mb-3">
                {item.step}
              </div>
              <h3 className="font-semibold text-gray-900 mb-1">{item.title}</h3>
              <p className="text-sm text-gray-600">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="grid grid-cols-3 gap-6 mb-16">
        {FEATURES.map((f) => (
          <div key={f.title} className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">{f.title}</h3>
            <p className="text-sm text-gray-600 mb-4">{f.desc}</p>
            <Link
              to={f.link}
              className={`${f.color} text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors inline-block`}
            >
              {f.cta}
            </Link>
          </div>
        ))}
      </section>

      {jobs.length > 0 && (
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Recent Jobs</h2>
          <p className="text-gray-500">{jobs.length} jobs in marketplace &middot; {providers.length} active providers</p>
        </section>
      )}
    </div>
  );
};

export default HomePage;
