export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

export function shortenAddress(addr: string): string {
  if (addr.length <= 12) return addr;
  return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
}

export function formatTokenAmount(wei: string): string {
  const val = BigInt(wei);
  const eth = val / BigInt(10 ** 14);
  return `${(Number(eth) / 10000).toFixed(4)}`;
}

export function classNames(...classes: (string | false | undefined | null)[]): string {
  return classes.filter(Boolean).join(' ');
}

export const STATUS_COLORS: Record<string, string> = {
  draft: 'bg-gray-100 text-gray-800',
  open: 'bg-blue-100 text-blue-800',
  assigned: 'bg-yellow-100 text-yellow-800',
  in_progress: 'bg-purple-100 text-purple-800',
  proof_submitted: 'bg-indigo-100 text-indigo-800',
  verified: 'bg-green-100 text-green-800',
  completed: 'bg-emerald-100 text-emerald-800',
  disputed: 'bg-red-100 text-red-800',
  cancelled: 'bg-gray-100 text-gray-600',
  slashed: 'bg-red-200 text-red-900',
};

export function ipfsGatewayUrl(hash: string): string {
  return `https://ipfs.io/ipfs/${hash}`;
}

export function arweaveUrl(hash: string): string {
  return `https://arweave.net/${hash}`;
}

export function simulateDelay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
