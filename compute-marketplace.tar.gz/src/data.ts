import type { Job, Provider } from './types';

export const providers: Provider[] = [
  {
    id: 'prov-01',
    name: 'Succinct Forge',
    region: 'us-east',
    bondedStakeUsd: 160000,
    reputation: 97,
    successRate: 99.1,
    activeJobs: 8,
    slashEvents: 0,
    specialties: ['ZK proving', 'GPU clusters', 'low-latency jobs'],
  },
  {
    id: 'prov-02',
    name: 'Orbit Compute',
    region: 'eu-west',
    bondedStakeUsd: 94000,
    reputation: 89,
    successRate: 95.4,
    activeJobs: 5,
    slashEvents: 1,
    specialties: ['ML inference', 'TEE fallback', 'batch execution'],
  },
  {
    id: 'prov-03',
    name: 'VeriMesh',
    region: 'ap-south',
    bondedStakeUsd: 121000,
    reputation: 92,
    successRate: 97.2,
    activeJobs: 4,
    slashEvents: 0,
    specialties: ['SP1 recursion', 'storage pinning', 'proof aggregation'],
  },
];

export const initialJobs: Job[] = [
  {
    id: 'job-4812',
    customer: 'Atlas Labs',
    title: 'Risk engine nightly netting run',
    description:
      'Execute an off-chain batch settlement engine and return a verifiable SP1 proof anchored to all market data artifacts.',
    status: 'Milestone Review',
    budgetUsd: 42000,
    selectedProviderId: 'prov-01',
    resourceSpec: {
      cpu: 64,
      memoryGb: 256,
      gpu: 'A100 x4',
      maxRuntimeHours: 3,
    },
    sp1Statement: {
      programVKey: 'sp1_vk_0x8ab31fbe',
      publicValuesCommitment: '0x44719fcca7ce4b0b',
      artifactRoot: 'bafybeif5u6riskengineartifacts',
      executionImage: 'ar://settlement-snapshot-2025-06-18',
    },
    artifacts: [
      {
        kind: 'IPFS',
        cid: 'bafybeif5u6riskengineartifacts',
        description: 'Input market snapshots and execution config',
      },
      {
        kind: 'Arweave',
        cid: 'ar://settlement-snapshot-2025-06-18',
        description: 'Immutable archive of netting result outputs',
      },
    ],
    milestones: [
      {
        id: 'm1',
        name: 'Data ingest and witness generation',
        payoutUsd: 12000,
        dueLabel: 'Day 2',
        escrowed: true,
        proofStatus: 'Verified',
      },
      {
        id: 'm2',
        name: 'SP1 execution proof submission',
        payoutUsd: 18000,
        dueLabel: 'Day 4',
        escrowed: true,
        proofStatus: 'Pending',
      },
      {
        id: 'm3',
        name: 'Final payout release',
        payoutUsd: 12000,
        dueLabel: 'Day 5',
        escrowed: false,
        proofStatus: 'Pending',
      },
    ],
  },
  {
    id: 'job-1937',
    customer: 'Helio Bio',
    title: 'Genome fold scoring pipeline',
    description:
      'Run a GPU-heavy scoring pipeline with artifact commitments included in the SP1 public values for downstream auditability.',
    status: 'Awaiting Proof',
    budgetUsd: 28000,
    selectedProviderId: 'prov-03',
    resourceSpec: {
      cpu: 96,
      memoryGb: 384,
      gpu: 'H100 x2',
      maxRuntimeHours: 6,
    },
    sp1Statement: {
      programVKey: 'sp1_vk_0x5cb42ee1',
      publicValuesCommitment: '0x293f000da3b19aa9',
      artifactRoot: 'bafybeibiofoldpipelineinputs',
      executionImage: 'ar://bio-scoring-run-1488',
    },
    artifacts: [
      {
        kind: 'IPFS',
        cid: 'bafybeibiofoldpipelineinputs',
        description: 'Model weights, inputs, and deterministic seed pack',
      },
      {
        kind: 'Arweave',
        cid: 'ar://bio-scoring-run-1488',
        description: 'Archived output matrix and signed execution receipt',
      },
    ],
    milestones: [
      {
        id: 'm1',
        name: 'Provision bonded provider',
        payoutUsd: 8000,
        dueLabel: 'Day 1',
        escrowed: true,
        proofStatus: 'Verified',
      },
      {
        id: 'm2',
        name: 'Submit final proof bundle',
        payoutUsd: 20000,
        dueLabel: 'Day 3',
        escrowed: true,
        proofStatus: 'Pending',
      },
    ],
  },
];
