import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { JobStatus, type Job, type Provider } from "@/types";
import { Activity, Wallet, Users, Clock, Star } from "lucide-react";

const mockJobs: Job[] = [
  {
    id: "job-001",
    title: "Neural Network Training - Image Classification",
    description: "Train a ResNet-50 model on ImageNet subset",
    customer: "0xA1B2...C3D4",
    provider: "Provider Alpha",
    status: JobStatus.Running,
    resourceSpecs: { cpuCores: 16, memoryGB: 64, storageGB: 500, gpuRequired: true, gpuModel: "NVIDIA A100", estimatedDuration: 7200 },
    escrowAmount: 12000,
    milestones: [],
    createdAt: Date.now() - 86400000,
    completedAt: null,
    sp1ProofVkey: "0xvkey...a1b2",
    artifactCid: "QmX7b...9kLp",
    resultCid: null,
    slashingAmount: null,
  },
  {
    id: "job-002",
    title: "Genomic Data Processing Pipeline",
    description: "Process 10TB of genomic sequencing data",
    customer: "0xD5E6...F7A8",
    provider: "Provider Beta",
    status: JobStatus.ProofSubmitted,
    resourceSpecs: { cpuCores: 32, memoryGB: 128, storageGB: 2000, gpuRequired: false, gpuModel: null, estimatedDuration: 14400 },
    escrowAmount: 8500,
    milestones: [],
    createdAt: Date.now() - 172800000,
    completedAt: null,
    sp1ProofVkey: "0xvkey...c3d4",
    artifactCid: "QmY8c...2mNq",
    resultCid: "QmZ9d...5oPr",
    slashingAmount: null,
  },
  {
    id: "job-003",
    title: "3D Rendering - Architectural Visualization",
    description: "Render photorealistic scenes for building project",
    customer: "0xB9C0...D1E2",
    provider: null,
    status: JobStatus.Posted,
    resourceSpecs: { cpuCores: 8, memoryGB: 32, storageGB: 100, gpuRequired: true, gpuModel: "NVIDIA RTX 4090", estimatedDuration: 3600 },
    escrowAmount: 5000,
    milestones: [],
    createdAt: Date.now() - 3600000,
    completedAt: null,
    sp1ProofVkey: "0xvkey...e5f6",
    artifactCid: "QmA1b...8cDe",
    resultCid: null,
    slashingAmount: null,
  },
  {
    id: "job-004",
    title: "Monte Carlo Simulation - Financial Risk",
    description: "Run 10M iterations of portfolio risk model",
    customer: "0xF3G4...H5I6",
    provider: "Provider Gamma",
    status: JobStatus.Completed,
    resourceSpecs: { cpuCores: 64, memoryGB: 256, storageGB: 500, gpuRequired: false, gpuModel: null, estimatedDuration: 28800 },
    escrowAmount: 15000,
    milestones: [],
    createdAt: Date.now() - 604800000,
    completedAt: Date.now() - 259200000,
    sp1ProofVkey: "0xvkey...g7h8",
    artifactCid: "QmB2c...9dEf",
    resultCid: "QmC3d...1eFg",
    slashingAmount: null,
  },
  {
    id: "job-005",
    title: "NLP Model Fine-tuning - Sentiment Analysis",
    description: "Fine-tune BERT on custom dataset for sentiment",
    customer: "0xJ7K8...L9M0",
    provider: "Provider Delta",
    status: JobStatus.Verified,
    resourceSpecs: { cpuCores: 16, memoryGB: 64, storageGB: 200, gpuRequired: true, gpuModel: "NVIDIA A100", estimatedDuration: 5400 },
    escrowAmount: 7800,
    milestones: [],
    createdAt: Date.now() - 432000000,
    completedAt: Date.now() - 172800000,
    sp1ProofVkey: "0xvkey...i9j0",
    artifactCid: "QmD4e...2fGh",
    resultCid: "QmE5f...3gHi",
    slashingAmount: null,
  },
  {
    id: "job-006",
    title: "Climate Simulation - Ocean Currents",
    description: "Multi-decade ocean current prediction model",
    customer: "0xN1O2...P3Q4",
    provider: "Provider Epsilon",
    status: JobStatus.Matched,
    resourceSpecs: { cpuCores: 32, memoryGB: 128, storageGB: 1000, gpuRequired: true, gpuModel: "NVIDIA H100", estimatedDuration: 43200 },
    escrowAmount: 25000,
    milestones: [],
    createdAt: Date.now() - 43200000,
    completedAt: null,
    sp1ProofVkey: "0xvkey...k1l2",
    artifactCid: "QmF6g...4hIj",
    resultCid: null,
    slashingAmount: null,
  },
  {
    id: "job-007",
    title: "Video Transcoding - 4K Batch Process",
    description: "Transcode 500 video files to H.265 format",
    customer: "0xR5S6...T7U8",
    provider: "Provider Zeta",
    status: JobStatus.Disputed,
    resourceSpecs: { cpuCores: 16, memoryGB: 32, storageGB: 2000, gpuRequired: true, gpuModel: "NVIDIA RTX 4080", estimatedDuration: 10800 },
    escrowAmount: 6200,
    milestones: [],
    createdAt: Date.now() - 345600000,
    completedAt: null,
    sp1ProofVkey: "0xvkey...m3n4",
    artifactCid: "QmG7h...5iJk",
    resultCid: "QmH8i...6jKl",
    slashingAmount: null,
  },
  {
    id: "job-008",
    title: "Database Migration & Validation",
    description: "Migrate 5TB PostgreSQL to distributed storage",
    customer: "0xV9W0...X1Y2",
    provider: "Provider Eta",
    status: JobStatus.Slashed,
    resourceSpecs: { cpuCores: 8, memoryGB: 64, storageGB: 5000, gpuRequired: false, gpuModel: null, estimatedDuration: 18000 },
    escrowAmount: 9400,
    milestones: [],
    createdAt: Date.now() - 691200000,
    completedAt: null,
    sp1ProofVkey: "0xvkey...o5p6",
    artifactCid: "QmI9j...7kLm",
    resultCid: null,
    slashingAmount: 9400,
  },
];

const mockProviders: Provider[] = [
  { id: "p-001", address: "0xAb1C...d2E3", reputation: 4.9, totalJobs: 156, successfulJobs: 153, bondedAmount: 52000, status: "Active", joinedAt: Date.now() - 15768000000 },
  { id: "p-002", address: "0xFg4H...i5J6", reputation: 4.7, totalJobs: 98, successfulJobs: 95, bondedAmount: 35000, status: "Active", joinedAt: Date.now() - 31536000000 },
  { id: "p-003", address: "0xKl7M...n8O9", reputation: 4.5, totalJobs: 72, successfulJobs: 68, bondedAmount: 28000, status: "Active", joinedAt: Date.now() - 26298000000 },
  { id: "p-004", address: "0xPq0R...s1T2", reputation: 4.3, totalJobs: 45, successfulJobs: 42, bondedAmount: 18000, status: "Active", joinedAt: Date.now() - 13149000000 },
  { id: "p-005", address: "0xUv3W...x4Y5", reputation: 4.1, totalJobs: 34, successfulJobs: 31, bondedAmount: 15000, status: "Offline", joinedAt: Date.now() - 7884000000 },
];

function statusBadgeVariant(status: JobStatus) {
  switch (status) {
    case JobStatus.Posted:
    case JobStatus.Matched:
      return "outline";
    case JobStatus.Running:
      return "default";
    case JobStatus.ProofSubmitted:
      return "secondary";
    case JobStatus.Verified:
    case JobStatus.Completed:
      return "default";
    case JobStatus.Slashed:
    case JobStatus.Disputed:
      return "destructive";
    case JobStatus.Cancelled:
      return "outline";
    default:
      return "outline";
  }
}

interface DashboardPageProps {
  onViewJob: (jobId: string) => void;
}

export default function DashboardPage({ onViewJob }: DashboardPageProps) {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Jobs</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <p className="text-xs text-muted-foreground">+3 from last week</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Escrow</CardTitle>
            <Wallet className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">47,820 CSPR</div>
            <p className="text-xs text-muted-foreground">Across 18 jobs</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Providers Online</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">38</div>
            <p className="text-xs text-muted-foreground">of 52 registered</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg. Verification Time</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4.2 min</div>
            <p className="text-xs text-muted-foreground">SP1 zkVM proofs</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Recent Jobs</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Job</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Provider</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Escrow</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockJobs.map((job) => (
                    <TableRow key={job.id}>
                      <TableCell className="font-medium">{job.title}</TableCell>
                      <TableCell className="text-muted-foreground">{job.customer}</TableCell>
                      <TableCell>{job.provider ?? "—"}</TableCell>
                      <TableCell>
                        <Badge variant={statusBadgeVariant(job.status)}>{job.status}</Badge>
                      </TableCell>
                      <TableCell>{job.escrowAmount.toLocaleString()} CSPR</TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm" onClick={() => onViewJob(job.id)}>
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Top Providers</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {mockProviders.map((provider) => (
                <div key={provider.id} className="flex items-center justify-between">
                  <div className="space-y-1">
                    <p className="text-sm font-medium leading-none">{provider.address}</p>
                    <p className="text-xs text-muted-foreground">{provider.totalJobs} jobs completed</p>
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-medium">{provider.reputation}</span>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
