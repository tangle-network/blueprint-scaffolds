import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Cpu, LayoutDashboard, PlusCircle, Briefcase, Server } from "lucide-react";
import { AddressDisplay } from "@/components/AddressDisplay";

const navItems = [
  { label: "Dashboard", href: "/", icon: LayoutDashboard },
  { label: "Post Job", href: "/post-job", icon: PlusCircle },
  { label: "Jobs", href: "/jobs", icon: Briefcase },
  { label: "Provider", href: "/provider", icon: Server },
];

export function Navbar() {
  const location = useLocation();

  return (
    <nav className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-40">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-8">
          <Link to="/" className="flex items-center gap-2 font-bold text-lg">
            <Cpu className="h-6 w-6 text-primary" />
            <span>SP1 Compute Market</span>
          </Link>
          <div className="hidden md:flex items-center gap-1">
            {navItems.map((item) => {
              const isActive = location.pathname === item.href;
              return (
                <Link key={item.href} to={item.href}>
                  <Button
                    variant={isActive ? "secondary" : "ghost"}
                    size="sm"
                    className="gap-2"
                  >
                    <item.icon className="h-4 w-4" />
                    {item.label}
                  </Button>
                </Link>
              );
            })}
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 rounded-md border px-3 py-1.5 text-sm">
            <div className="h-2 w-2 rounded-full bg-green-500" />
            <AddressDisplay address="0x742d35Cc6634C0532925a3b844Bc9e7595f2bD18" showCopy />
          </div>
        </div>
      </div>
    </nav>
  );
}
