import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { JobStatus, type Job } from "@/types";
import { Search } from "lucide-react";

const mockJobs: Job[] = [
  {
    id: "jl-001", title: "Neural Network Training - ImageNet", description: "Train ResNet-50 on ImageNet subset", customer: "0xA1B2...C3D4", provider: "Provider Alpha", status: JobStatus.Running,
    resourceSpecs: { cpuCores: 16, memoryGB: 64, storageGB: 500, gpuRequired: true, gpuModel: "NVIDIA A100", estimatedDuration: 7200 },
    escrowAmount: 12000, milestones: [], createdAt: Date.now() - 86400000, completedAt: null, sp1ProofVkey: "0xvkey...a1b2", artifactCid: "QmX7b...9kLp", resultCid: null, slashingAmount: null,
  },
  {
    id: "jl-002", title: "Genomic Data Processing", description: "Process 10TB genomic sequencing data", customer: "0xD5E6...F7A8", provider: "Provider Beta", status: JobStatus.ProofSubmitted,
    resourceSpecs: { cpuCores: 32, memoryGB: 128, storageGB: 2000, gpuRequired: false, gpuModel: null, estimatedDuration: 14400 },
    escrowAmount: 8500, milestones: [], createdAt: Date.now() - 172800000, completedAt: null, sp1ProofVkey: "0xvkey...c3d4", artifactCid: "QmY8c...2mNq", resultCid: "QmZ9d...5oPr", slashingAmount: null,
  },
  {
    id: "jl-003", title: "3D Rendering - Architecture Viz", description: "Photorealistic architectural renders", customer: "0xB9C0...D1E2", provider: null, status: JobStatus.Posted,
    resourceSpecs: { cpuCores: 8, memoryGB: 32, storageGB: 100, gpuRequired: true, gpuModel: "NVIDIA RTX 4090", estimatedDuration: 3600 },
    escrowAmount: 5000, milestones: [], createdAt: Date.now() - 3600000, completedAt: null, sp1ProofVkey: "0xvkey...e5f6", artifactCid: "QmA1b...8cDe", resultCid: null, slashingAmount: null,
  },
  {
    id: "jl-004", title: "Monte Carlo - Portfolio Risk", description: "10M iterations risk model", customer: "0xF3G4...H5I6", provider: "Provider Gamma", status: JobStatus.Completed,
    resourceSpecs: { cpuCores: 64, memoryGB: 256, storageGB: 500, gpuRequired: false, gpuModel: null, estimatedDuration: 28800 },
    escrowAmount: 15000, milestones: [], createdAt: Date.now() - 604800000, completedAt: Date.now() - 259200000, sp1ProofVkey: "0xvkey...g7h8", artifactCid: "QmB2c...9dEf", resultCid: "QmC3d...1eFg", slashingAmount: null,
  },
  {
    id: "jl-005", title: "NLP Fine-tuning - Sentiment", description: "BERT fine-tuning for sentiment analysis", customer: "0xJ7K8...L9M0", provider: "Provider Delta", status: JobStatus.Verified,
    resourceSpecs: { cpuCores: 16, memoryGB: 64, storageGB: 200, gpuRequired: true, gpuModel: "NVIDIA A100", estimatedDuration: 5400 },
    escrowAmount: 7800, milestones: [], createdAt: Date.now() - 432000000, completedAt: Date.now() - 172800000, sp1ProofVkey: "0xvkey...i9j0", artifactCid: "QmD4e...2fGh", resultCid: "QmE5f...3gHi", slashingAmount: null,
  },
  {
    id: "jl-006", title: "Climate Simulation - Ocean Currents", description: "Multi-decade ocean prediction", customer: "0xN1O2...P3Q4", provider: "Provider Epsilon", status: JobStatus.Running,
    resourceSpecs: { cpuCores: 32, memoryGB: 128, storageGB: 1000, gpuRequired: true, gpuModel: "NVIDIA H100", estimatedDuration: 43200 },
    escrowAmount: 25000, milestones: [], createdAt: Date.now() - 43200000, completedAt: null, sp1ProofVkey: "0xvkey...k1l2", artifactCid: "QmF6g...4hIj", resultCid: null, slashingAmount: null,
  },
  {
    id: "jl-007", title: "Video Transcoding - 4K Batch", description: "500 videos to H.265", customer: "0xR5S6...T7U8", provider: "Provider Zeta", status: JobStatus.Disputed,
    resourceSpecs: { cpuCores: 16, memoryGB: 32, storageGB: 2000, gpuRequired: true, gpuModel: "NVIDIA RTX 4080", estimatedDuration: 10800 },
    escrowAmount: 6200, milestones: [], createdAt: Date.now() - 345600000, completedAt: null, sp1ProofVkey: "0xvkey...m3n4", artifactCid: "QmG7h...5iJk", resultCid: "QmH8i...6jKl", slashingAmount: null,
  },
  {
    id: "jl-008", title: "Database Migration & Validation", description: "5TB PostgreSQL to distributed storage", customer: "0xV9W0...X1Y2", provider: "Provider Eta", status: JobStatus.Slashed,
    resourceSpecs: { cpuCores: 8, memoryGB: 64, storageGB: 5000, gpuRequired: false, gpuModel: null, estimatedDuration: 18000 },
    escrowAmount: 9400, milestones: [], createdAt: Date.now() - 691200000, completedAt: null, sp1ProofVkey: "0xvkey...o5p6", artifactCid: "QmI9j...7kLm", resultCid: null, slashingAmount: 9400,
  },
  {
    id: "jl-009", title: "Particle Physics Simulation", description: "CERN data analysis pipeline", customer: "0xZ3A4...B5C6", provider: "Provider Theta", status: JobStatus.Running,
    resourceSpecs: { cpuCores: 64, memoryGB: 256, storageGB: 3000, gpuRequired: true, gpuModel: "NVIDIA H100", estimatedDuration: 86400 },
    escrowAmount: 32000, milestones: [], createdAt: Date.now() - 259200000, completedAt: null, sp1ProofVkey: "0xvkey...q7r8", artifactCid: "QmJ0k...8lMn", resultCid: null, slashingAmount: null,
  },
  {
    id: "jl-010", title: "LLM Inference Batch Processing", description: "Run inference on 1M prompts", customer: "0xD7E8...F9G0", provider: null, status: JobStatus.Posted,
    resourceSpecs: { cpuCores: 32, memoryGB: 128, storageGB: 500, gpuRequired: true, gpuModel: "NVIDIA A100", estimatedDuration: 21600 },
    escrowAmount: 18500, milestones: [], createdAt: Date.now() - 7200000, completedAt: null, sp1ProofVkey: "0xvkey...s9t0", artifactCid: "QmK1l...9mNo", resultCid: null, slashingAmount: null,
  },
  {
    id: "jl-011", title: "Satellite Image Analysis", description: "Object detection on satellite imagery", customer: "0xH1I2...J3K4", provider: "Provider Iota", status: JobStatus.Matched,
    resourceSpecs: { cpuCores: 16, memoryGB: 64, storageGB: 1000, gpuRequired: true, gpuModel: "NVIDIA RTX 4090", estimatedDuration: 10800 },
    escrowAmount: 11000, milestones: [], createdAt: Date.now() - 14400000, completedAt: null, sp1ProofVkey: "0xvkey...u1v2", artifactCid: "QmL2m...0nOp", resultCid: null, slashingAmount: null,
  },
  {
    id: "jl-012", title: "Blockchain Event Indexing", description: "Index 3 years of contract events", customer: "0xL5M6...N7O8", provider: "Provider Kappa", status: JobStatus.ProofSubmitted,
    resourceSpecs: { cpuCores: 8, memoryGB: 32, storageGB: 2000, gpuRequired: false, gpuModel: null, estimatedDuration: 7200 },
    escrowAmount: 4500, milestones: [], createdAt: Date.now() - 518400000, completedAt: null, sp1ProofVkey: "0xvkey...w3x4", artifactCid: "QmM3n...1oPq", resultCid: "QmN4o...2pQr", slashingAmount: null,
  },
];

function statusBadgeVariant(status: JobStatus) {
  switch (status) {
    case JobStatus.Posted:
    case JobStatus.Matched:
      return "outline";
    case JobStatus.Running:
      return "default";
    case JobStatus.ProofSubmitted:
      return "secondary";
    case JobStatus.Verified:
    case JobStatus.Completed:
      return "default";
    case JobStatus.Slashed:
    case JobStatus.Disputed:
      return "destructive";
    case JobStatus.Cancelled:
      return "outline";
    default:
      return "outline";
  }
}

function formatTimeAgo(ts: number) {
  const diff = Date.now() - ts;
  const hours = Math.floor(diff / 3600000);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

function specSummary(specs: Job["resourceSpecs"]) {
  const parts = [`${specs.cpuCores} CPU`, `${specs.memoryGB}GB RAM`];
  if (specs.gpuRequired && specs.gpuModel) parts.push(specs.gpuModel);
  return parts.join(" · ");
}

interface JobListPageProps {
  onViewJob: (jobId: string) => void;
}

export default function JobListPage({ onViewJob }: JobListPageProps) {
  const [statusFilter, setStatusFilter] = useState<string>("All");
  const [search, setSearch] = useState("");

  const filtered = mockJobs.filter((job) => {
    const matchStatus = statusFilter === "All" || job.status === statusFilter;
    const matchSearch =
      search === "" ||
      job.title.toLowerCase().includes(search.toLowerCase()) ||
      job.description.toLowerCase().includes(search.toLowerCase());
    return matchStatus && matchSearch;
  });

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search jobs..."
                className="pl-8"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <div className="flex gap-2 flex-wrap">
              {["All", "Posted", "Running", "Verified"].map((s) => (
                <Button
                  key={s}
                  variant={statusFilter === s ? "default" : "outline"}
                  size="sm"
                  onClick={() => setStatusFilter(s)}
                >
                  {s}
                </Button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Available Jobs ({filtered.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Title</TableHead>
                <TableHead>Resources</TableHead>
                <TableHead>Escrow</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Posted</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((job) => (
                <TableRow key={job.id} className="cursor-pointer" onClick={() => onViewJob(job.id)}>
                  <TableCell>
                    <div>
                      <p className="font-medium">{job.title}</p>
                      <p className="text-xs text-muted-foreground">{job.customer}</p>
                    </div>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">{specSummary(job.resourceSpecs)}</TableCell>
                  <TableCell className="font-medium">{job.escrowAmount.toLocaleString()} CSPR</TableCell>
                  <TableCell>
                    <Badge variant={statusBadgeVariant(job.status)}>{job.status}</Badge>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">{formatTimeAgo(job.createdAt)}</TableCell>
                  <TableCell>
                    <Button variant="ghost" size="sm">View</Button>
                  </TableCell>
                </TableRow>
              ))}
              {filtered.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                    No jobs found matching your criteria.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
