import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatHash, formatTimestamp } from "@/lib/utils";
import type { Proof } from "@/types";
import { ShieldCheck, ShieldAlert, Clock } from "lucide-react";

interface ProofVerificationPanelProps {
  proof: Proof;
}

export function ProofVerificationPanel({ proof }: ProofVerificationPanelProps) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          {proof.verified ? (
            <ShieldCheck className="h-5 w-5 text-green-400" />
          ) : (
            <Clock className="h-5 w-5 text-yellow-400" />
          )}
          SP1 Proof
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Status:</span>
          {proof.verified ? (
            <Badge className="bg-green-500/20 text-green-400 border-green-500/30">Verified</Badge>
          ) : (
            <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">Pending Verification</Badge>
          )}
        </div>
        <div className="space-y-2 text-sm">
          <div>
            <span className="text-muted-foreground">Proof ID:</span>
            <p className="font-mono text-xs mt-0.5">{proof.id}</p>
          </div>
          <div>
            <span className="text-muted-foreground">SP1 Proof Bytes:</span>
            <p className="font-mono text-xs mt-0.5 break-all">{formatHash(proof.sp1_proof_bytes)}</p>
          </div>
          <div>
            <span className="text-muted-foreground">Public Inputs:</span>
            <p className="font-mono text-xs mt-0.5 break-all">{formatHash(proof.sp1_public_inputs)}</p>
          </div>
          <div>
            <span className="text-muted-foreground">Submitted:</span>
            <p className="text-xs mt-0.5">{formatTimestamp(proof.submitted_at)}</p>
          </div>
          <div>
            <span className="text-muted-foreground">Verifier Response:</span>
            <p className="text-xs mt-0.5">{proof.verifier_response}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
