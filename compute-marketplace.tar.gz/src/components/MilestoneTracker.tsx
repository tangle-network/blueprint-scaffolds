import { Check, Circle, Loader2 } from "lucide-react";
import type { Milestone } from "@/types";
import { formatHash, formatTimestamp } from "@/lib/utils";

interface MilestoneTrackerProps {
  milestones: Milestone[];
}

export function MilestoneTracker({ milestones }: MilestoneTrackerProps) {
  const completedCount = milestones.filter((m) => m.status === "COMPLETED").length;
  const pct = Math.round((completedCount / milestones.length) * 100);

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm font-medium">Milestones</span>
        <span className="text-sm text-muted-foreground">{completedCount}/{milestones.length} ({pct}%)</span>
      </div>
      <div className="w-full bg-secondary rounded-full h-2 mb-4">
        <div className="bg-primary h-2 rounded-full transition-all" style={{ width: `${pct}%` }} />
      </div>
      <div className="space-y-3">
        {milestones.map((m, i) => (
          <div key={m.id} className="flex items-start gap-3">
            <div className="mt-0.5">
              {m.status === "COMPLETED" ? (
                <Check className="h-5 w-5 text-green-400" />
              ) : m.status === "IN_PROGRESS" ? (
                <Loader2 className="h-5 w-5 text-yellow-400 animate-spin" />
              ) : (
                <Circle className="h-5 w-5 text-muted-foreground" />
              )}
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <span className={`text-sm ${m.status === "COMPLETED" ? "text-foreground" : "text-muted-foreground"}`}>
                  {i + 1}. {m.description}
                </span>
                <span className="text-xs text-muted-foreground">{m.reward_pct}%</span>
              </div>
              <div className="flex items-center gap-2 mt-0.5 text-xs text-muted-foreground">
                {m.status === "COMPLETED" && m.completed_at && (
                  <span>Completed {formatTimestamp(m.completed_at)}</span>
                )}
                {m.proof_hash && <span>Proof: {formatHash(m.proof_hash)}</span>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
