import { Copy, Check } from "lucide-react";
import { useState } from "react";
import { formatAddress } from "@/lib/utils";
import { Button } from "@/components/ui/button";

interface AddressDisplayProps {
  address: string;
  showCopy?: boolean;
}

export function AddressDisplay({ address, showCopy = true }: AddressDisplayProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <span className="inline-flex items-center gap-1.5 font-mono text-sm">
      <span className="text-foreground">{formatAddress(address)}</span>
      {showCopy && (
        <Button variant="ghost" size="icon" className="h-6 w-6" onClick={handleCopy}>
          {copied ? <Check className="h-3 w-3 text-green-400" /> : <Copy className="h-3 w-3 text-muted-foreground" />}
        </Button>
      )}
    </span>
  );
}
