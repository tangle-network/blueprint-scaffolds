export const shortenAddress = {} as any
