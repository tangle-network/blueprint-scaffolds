import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { JobStatus, type Job, type ResourceSpecs, type Milestone } from "@/types";
import { ChevronLeft, ChevronRight, Plus, Trash2 } from "lucide-react";

interface JobWizardPageProps {
  onNavigate: (page: string) => void;
}

export default function JobWizardPage({ onNavigate }: JobWizardPageProps) {
  const [step, setStep] = useState(1);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [cpuCores, setCpuCores] = useState("4");
  const [memoryGB, setMemoryGB] = useState("16");
  const [storageGB, setStorageGB] = useState("");
  const [gpuRequired, setGpuRequired] = useState(false);
  const [gpuModel, setGpuModel] = useState("");
  const [estimatedDuration, setEstimatedDuration] = useState("");
  const [milestones, setMilestones] = useState<Milestone[]>([
    { id: "ms-1", description: "", cid: null, reward: 0, completedAt: null, proofCid: null },
  ]);
  const [artifactCid, setArtifactCid] = useState("");
  const [sp1Vkey] = useState("0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(""));

  const totalSteps = 4;
  const progressPct = (step / totalSteps) * 100;

  const totalEscrow = milestones.reduce((sum, m) => sum + (m.reward || 0), 0);

  function addMilestone() {
    setMilestones([
      ...milestones,
      { id: `ms-${milestones.length + 1}`, description: "", cid: null, reward: 0, completedAt: null, proofCid: null },
    ]);
  }

  function removeMilestone(index: number) {
    if (milestones.length <= 1) return;
    setMilestones(milestones.filter((_, i) => i !== index));
  }

  function updateMilestone(index: number, field: "description" | "reward", value: string | number) {
    const updated = [...milestones];
    updated[index] = { ...updated[index], [field]: value };
    setMilestones(updated);
  }

  function validateStep(): boolean {
    switch (step) {
      case 1:
        return title.trim() !== "" && description.trim() !== "" && category !== "";
      case 2:
        return storageGB !== "" && estimatedDuration !== "";
      case 3:
        return milestones.every((m) => m.description.trim() !== "" && m.reward > 0);
      case 4:
        return true;
      default:
        return false;
    }
  }

  function nextStep() {
    if (validateStep() && step < totalSteps) setStep(step + 1);
  }

  function prevStep() {
    if (step > 1) setStep(step - 1);
  }

  function handleSubmit() {
    const newJob: Job = {
      id: `job-${Date.now()}`,
      title,
      description,
      customer: "0x1a2B...3c4D",
      provider: null,
      status: JobStatus.Posted,
      resourceSpecs: {
        cpuCores: parseInt(cpuCores),
        memoryGB: parseInt(memoryGB),
        storageGB: parseInt(storageGB),
        gpuRequired,
        gpuModel: gpuRequired ? gpuModel : null,
        estimatedDuration: parseInt(estimatedDuration),
      },
      escrowAmount: totalEscrow,
      milestones,
      createdAt: Date.now(),
      completedAt: null,
      sp1ProofVkey: sp1Vkey,
      artifactCid: artifactCid || null,
      resultCid: null,
      slashingAmount: null,
    };
    console.log("Job submitted:", newJob);
    onNavigate("dashboard");
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="space-y-2">
        <div className="flex justify-between text-sm text-muted-foreground">
          <span>Step {step} of {totalSteps}</span>
          <span>{Math.round(progressPct)}% complete</span>
        </div>
        <Progress value={progressPct} />
      </div>

      {step === 1 && (
        <Card>
          <CardHeader>
            <CardTitle>Basic Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Job Title *</Label>
              <Input id="title" placeholder="e.g., Neural Network Training - ImageNet Classification" value={title} onChange={(e) => setTitle(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description *</Label>
              <textarea
                id="description"
                className="flex min-h-[100px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                placeholder="Describe the compute job in detail..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Category *</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ml-training">ML Training</SelectItem>
                  <SelectItem value="data-processing">Data Processing</SelectItem>
                  <SelectItem value="simulation">Simulation</SelectItem>
                  <SelectItem value="rendering">Rendering</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>
      )}

      {step === 2 && (
        <Card>
          <CardHeader>
            <CardTitle>Resource Specifications</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>CPU Cores</Label>
                <Select value={cpuCores} onValueChange={setCpuCores}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[1, 2, 4, 8, 16, 32, 64].map((n) => (
                      <SelectItem key={n} value={String(n)}>{n} cores</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Memory (GB)</Label>
                <Select value={memoryGB} onValueChange={setMemoryGB}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[4, 8, 16, 32, 64, 128, 256].map((n) => (
                      <SelectItem key={n} value={String(n)}>{n} GB</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="storage">Storage (GB) *</Label>
                <Input id="storage" type="number" placeholder="e.g., 500" value={storageGB} onChange={(e) => setStorageGB(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="duration">Est. Duration (seconds) *</Label>
                <Input id="duration" type="number" placeholder="e.g., 3600" value={estimatedDuration} onChange={(e) => setEstimatedDuration(e.target.value)} />
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="gpu"
                  className="h-4 w-4 rounded border-input"
                  checked={gpuRequired}
                  onChange={(e) => setGpuRequired(e.target.checked)}
                />
                <Label htmlFor="gpu">GPU Required</Label>
              </div>
              {gpuRequired && (
                <div className="space-y-2">
                  <Label>GPU Model</Label>
                  <Select value={gpuModel} onValueChange={setGpuModel}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select GPU model" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="nvidia-a100">NVIDIA A100</SelectItem>
                      <SelectItem value="nvidia-h100">NVIDIA H100</SelectItem>
                      <SelectItem value="nvidia-rtx4090">NVIDIA RTX 4090</SelectItem>
                      <SelectItem value="nvidia-rtx4080">NVIDIA RTX 4080</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {step === 3 && (
        <Card>
          <CardHeader>
            <CardTitle>Milestones & Escrow</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              {milestones.map((ms, idx) => (
                <div key={ms.id} className="flex gap-3 items-end border rounded-lg p-3">
                  <div className="flex-1 space-y-1">
                    <Label className="text-xs text-muted-foreground">Milestone {idx + 1} Description</Label>
                    <Input
                      placeholder="e.g., Data preprocessing complete"
                      value={ms.description}
                      onChange={(e) => updateMilestone(idx, "description", e.target.value)}
                    />
                  </div>
                  <div className="w-32 space-y-1">
                    <Label className="text-xs text-muted-foreground">Reward (CSPR)</Label>
                    <Input
                      type="number"
                      placeholder="0"
                      value={ms.reward || ""}
                      onChange={(e) => updateMilestone(idx, "reward", parseInt(e.target.value) || 0)}
                    />
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => removeMilestone(idx)} disabled={milestones.length <= 1}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
            <Button variant="outline" size="sm" onClick={addMilestone}>
              <Plus className="h-4 w-4 mr-1" /> Add Milestone
            </Button>
            <div className="border-t pt-4">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Total Escrow</span>
                <span className="text-lg font-bold">{totalEscrow.toLocaleString()} CSPR</span>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="artifact-cid">Artifact CID (optional)</Label>
              <Input id="artifact-cid" placeholder="QmX7b...9kLp" value={artifactCid} onChange={(e) => setArtifactCid(e.target.value)} />
            </div>
          </CardContent>
        </Card>
      )}

      {step === 4 && (
        <Card>
          <CardHeader>
            <CardTitle>Review & Submit</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-muted-foreground">Title</p>
                <p className="font-medium">{title}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Category</p>
                <p className="font-medium">{category}</p>
              </div>
              <div className="col-span-2">
                <p className="text-muted-foreground">Description</p>
                <p className="font-medium">{description}</p>
              </div>
            </div>
            <div className="border-t pt-4 grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-muted-foreground">CPU Cores</p>
                <p className="font-medium">{cpuCores}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Memory</p>
                <p className="font-medium">{memoryGB} GB</p>
              </div>
              <div>
                <p className="text-muted-foreground">Storage</p>
                <p className="font-medium">{storageGB} GB</p>
              </div>
              <div>
                <p className="text-muted-foreground">GPU</p>
                <p className="font-medium">{gpuRequired ? gpuModel : "Not required"}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Est. Duration</p>
                <p className="font-medium">{estimatedDuration}s ({(parseInt(estimatedDuration) / 3600).toFixed(1)}h)</p>
              </div>
            </div>
            <div className="border-t pt-4">
              <p className="text-sm text-muted-foreground mb-2">Milestones ({milestones.length})</p>
              {milestones.map((ms, idx) => (
                <div key={ms.id} className="flex justify-between text-sm py-1">
                  <span>{idx + 1}. {ms.description}</span>
                  <span className="font-medium">{ms.reward.toLocaleString()} CSPR</span>
                </div>
              ))}
              <div className="flex justify-between text-sm font-bold border-t mt-2 pt-2">
                <span>Total Escrow</span>
                <span>{totalEscrow.toLocaleString()} CSPR</span>
              </div>
            </div>
            <div className="border-t pt-4">
              <p className="text-sm text-muted-foreground">SP1 Verification Key</p>
              <p className="text-xs font-mono bg-muted p-2 rounded mt-1 break-all">{sp1Vkey}</p>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="flex justify-between">
        <Button variant="outline" onClick={prevStep} disabled={step === 1}>
          <ChevronLeft className="h-4 w-4 mr-1" /> Back
        </Button>
        {step < totalSteps ? (
          <Button onClick={nextStep} disabled={!validateStep()}>
            Next <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        ) : (
          <Button onClick={handleSubmit}>
            Submit Job
          </Button>
        )}
      </div>
    </div>
  );
}
