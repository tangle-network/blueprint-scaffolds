import React from 'react';
import type { Job } from '../../types';
import { STATUS_COLORS, shortenAddress } from '../../utils';

interface Props {
  job: Job;
  onClick?: (job: Job) => void;
  compact?: boolean;
}

export const JobCard: React.FC<Props> = ({ job, onClick, compact }) => {
  const statusColor = STATUS_COLORS[job.status] || 'bg-gray-100 text-gray-800';

  return (
    <div
      onClick={() => onClick?.(job)}
      className={`bg-white border border-gray-200 rounded-xl p-5 hover:shadow-md transition-shadow ${
        onClick ? 'cursor-pointer' : ''
      }`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1 min-w-0">
          <h3 className="text-lg font-semibold text-gray-900 truncate">{job.title}</h3>
          {!compact && <p className="text-sm text-gray-500 mt-1 line-clamp-2">{job.description}</p>}
        </div>
        <span className={`ml-3 px-2.5 py-0.5 rounded-full text-xs font-medium whitespace-nowrap ${statusColor}`}>
          {job.status.replace(/_/g, ' ')}
        </span>
      </div>

      <div className="flex items-center gap-4 text-sm text-gray-600">
        <span>.reward: <strong>{job.reward} ETH</strong></span>
        {!compact && (
          <>
            <span>CPU: {job.resourceSpecs.cpuCores} cores</span>
            <span>RAM: {job.resourceSpecs.memoryGB}GB</span>
          </>
        )}
      </div>

      <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100 text-xs text-gray-400">
        <span>ID: {job.id.slice(0, 12)}...</span>
        <div className="flex items-center gap-3">
          {job.providerId && <span>Provider: {shortenAddress(job.providerId)}</span>}
          <span>{new Date(job.createdAt).toLocaleDateString()}</span>
        </div>
      </div>

      {job.milestones.length > 0 && (
        <div className="mt-3">
          <div className="flex gap-1">
            {job.milestones.map((m) => (
              <div
                key={m.id}
                className={`h-1.5 flex-1 rounded-full ${m.completed ? 'bg-indigo-500' : 'bg-gray-200'}`}
                title={m.description}
              />
            ))}
          </div>
          <p className="text-xs text-gray-400 mt-1">
            {job.milestones.filter((m) => m.completed).length}/{job.milestones.length} milestones
          </p>
        </div>
      )}
    </div>
  );
};
