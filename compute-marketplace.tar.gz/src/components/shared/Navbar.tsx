import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useStore } from '../store';
import { shortenAddress } from '../utils';

export const Navbar: React.FC = () => {
  const location = useLocation();
  const { currentAccount, role, setRole, setCurrentAccount } = useStore();

  const connectWallet = () => {
    const mockAddr = '0x' + Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    setCurrentAccount(mockAddr);
  };

  const isActive = (path: string) => location.pathname.startsWith(path);

  return (
    <nav className="bg-gray-900 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-8">
            <Link to="/" className="text-xl font-bold tracking-tight">
              SP1 <span className="text-indigo-400">Marketplace</span>
            </Link>
            <div className="flex gap-1">
              <Link
                to="/customer"
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive('/customer') ? 'bg-gray-800 text-white' : 'text-gray-300 hover:text-white hover:bg-gray-700'
                }`}
              >
                Customer
              </Link>
              <Link
                to="/provider"
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive('/provider') ? 'bg-gray-800 text-white' : 'text-gray-300 hover:text-white hover:bg-gray-700'
                }`}
              >
                Provider
              </Link>
              <Link
                to="/explorer"
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive('/explorer') ? 'bg-gray-800 text-white' : 'text-gray-300 hover:text-white hover:bg-gray-700'
                }`}
              >
                Explorer
              </Link>
            </div>
          </div>
          <div className="flex items-center gap-4">
            {currentAccount && (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setRole('customer')}
                  className={`px-2 py-1 rounded text-xs font-medium transition-colors ${
                    role === 'customer' ? 'bg-indigo-600 text-white' : 'bg-gray-700 text-gray-300 hover:text-white'
                  }`}
                >
                  Customer
                </button>
                <button
                  onClick={() => setRole('provider')}
                  className={`px-2 py-1 rounded text-xs font-medium transition-colors ${
                    role === 'provider' ? 'bg-emerald-600 text-white' : 'bg-gray-700 text-gray-300 hover:text-white'
                  }`}
                >
                  Provider
                </button>
              </div>
            )}
            {currentAccount ? (
              <span className="bg-gray-800 px-3 py-1.5 rounded-lg text-sm font-mono">
                {shortenAddress(currentAccount)}
              </span>
            ) : (
              <button
                onClick={connectWallet}
                className="bg-indigo-600 hover:bg-indigo-700 px-4 py-2 rounded-lg text-sm font-medium transition-colors"
              >
                Connect Wallet
              </button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};
