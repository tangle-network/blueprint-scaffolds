import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { StatusBadge } from "@/components/StatusBadge";
import { AddressDisplay } from "@/components/AddressDisplay";
import { formatEth, formatTimestamp } from "@/lib/utils";
import type { Job } from "@/types";
import { Cpu, MemoryStick, HardDrive } from "lucide-react";

interface JobCardProps {
  job: Job;
}

export function JobCard({ job }: JobCardProps) {
  return (
    <Link to={`/jobs/${job.id}`}>
      <Card className="hover:border-primary/50 transition-colors cursor-pointer">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <CardTitle className="text-base font-semibold leading-tight">{job.title}</CardTitle>
            <StatusBadge status={job.status} />
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{job.description}</p>
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1"><Cpu className="h-3 w-3" />{job.resource_spec.cpu_cores} cores</span>
              <span className="flex items-center gap-1"><MemoryStick className="h-3 w-3" />{job.resource_spec.memory_gb}GB</span>
              <span className="flex items-center gap-1"><HardDrive className="h-3 w-3" />{job.resource_spec.storage_gb}GB</span>
            </div>
            <span className="font-semibold text-primary">{formatEth(job.reward_amount)}</span>
          </div>
          <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
            <span>Customer: <AddressDisplay address={job.customer_address} showCopy={false} /></span>
            <span>{formatTimestamp(job.created_at)}</span>
          </div>
          {job.resource_spec.gpu_required && (
            <Badge variant="outline" className="mt-2 text-xs border-purple-500/30 text-purple-400">
              GPU: {job.resource_spec.gpu_model}
            </Badge>
          )}
        </CardContent>
      </Card>
    </Link>
  );
}
