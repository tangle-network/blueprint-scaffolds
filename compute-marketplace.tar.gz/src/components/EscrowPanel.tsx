import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/StatusBadge";
import { formatEth } from "@/lib/utils";
import type { Escrow } from "@/types";
import { Lock, Unlock, ArrowDownToLine, ArrowUpFromLine } from "lucide-react";

interface EscrowPanelProps {
  escrow: Escrow;
}

export function EscrowPanel({ escrow }: EscrowPanelProps) {
  const totalWei = BigInt(escrow.total_amount);
  const releasedWei = BigInt(escrow.released_amount);
  const refundedWei = BigInt(escrow.refunded_amount);
  const pct = totalWei > 0n ? Number((releasedWei * 100n) / totalWei) : 0;

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Lock className="h-4 w-4" /> Escrow
          </CardTitle>
          <StatusBadge status={escrow.status} />
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="space-y-1">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Total Locked</span>
            <span className="font-mono">{formatEth(escrow.total_amount)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Released</span>
            <span className="font-mono text-green-400">{formatEth(escrow.released_amount)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Refunded</span>
            <span className="font-mono text-muted-foreground">{formatEth(escrow.refunded_amount)}</span>
          </div>
        </div>
        <div className="w-full bg-secondary rounded-full h-2">
          <div className="bg-green-500 h-2 rounded-full transition-all" style={{ width: `${pct}%` }} />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="flex-1" disabled={escrow.status === "FULLY_RELEASED"}>
            <ArrowDownToLine className="h-3 w-3 mr-1" /> Release
          </Button>
          <Button variant="outline" size="sm" className="flex-1" disabled={escrow.status === "FULLY_RELEASED"}>
            <ArrowUpFromLine className="h-3 w-3 mr-1" /> Refund
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
