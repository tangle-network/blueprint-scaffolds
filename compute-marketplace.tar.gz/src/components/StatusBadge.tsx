import { Badge } from "@/components/ui/badge";
import { statusColorMap } from "@/lib/utils";

interface StatusBadgeProps {
  status: string;
}

export function StatusBadge({ status }: StatusBadgeProps) {
  const colorClass = statusColorMap[status] || "bg-gray-500/20 text-gray-400 border-gray-500/30";
  return (
    <Badge variant="outline" className={colorClass}>
      {status.replace(/_/g, " ")}
    </Badge>
  );
}
