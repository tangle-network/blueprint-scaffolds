import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import type { ResourceSpec } from "@/types";

interface ResourceSpecTableProps {
  spec: ResourceSpec;
}

export function ResourceSpecTable({ spec }: ResourceSpecTableProps) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Resource</TableHead>
          <TableHead className="text-right">Value</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        <TableRow><TableCell className="font-medium">CPU Cores</TableCell><TableCell className="text-right">{spec.cpu_cores}</TableCell></TableRow>
        <TableRow><TableCell className="font-medium">Memory</TableCell><TableCell className="text-right">{spec.memory_gb} GB</TableCell></TableRow>
        <TableRow><TableCell className="font-medium">Storage</TableCell><TableCell className="text-right">{spec.storage_gb} GB</TableCell></TableRow>
        <TableRow><TableCell className="font-medium">GPU Required</TableCell><TableCell className="text-right">{spec.gpu_required ? "Yes" : "No"}</TableCell></TableRow>
        {spec.gpu_required && spec.gpu_model && (
          <TableRow><TableCell className="font-medium">GPU Model</TableCell><TableCell className="text-right">{spec.gpu_model}</TableCell></TableRow>
        )}
        <TableRow><TableCell className="font-medium">Est. Duration</TableCell><TableCell className="text-right">{Math.round(spec.estimated_duration_secs / 3600)}h {(spec.estimated_duration_secs % 3600) / 60}m</TableCell></TableRow>
      </TableBody>
    </Table>
  );
}
