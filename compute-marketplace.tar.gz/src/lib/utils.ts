import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatEth(wei: string): string {
  const eth = Number(BigInt(wei)) / 1e18;
  return `${eth.toFixed(4)} ETH`;
}

export function formatAddress(address: string): string {
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

export function formatTimestamp(unix: number): string {
  return new Date(unix * 1000).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function formatHash(hash: string): string {
  if (hash.length <= 16) return hash;
  return `${hash.slice(0, 10)}...${hash.slice(-6)}`;
}

export const statusColorMap: Record<string, string> = {
  DRAFT: "bg-gray-500/20 text-gray-400 border-gray-500/30",
  POSTED: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  ASSIGNED: "bg-indigo-500/20 text-indigo-400 border-indigo-500/30",
  RUNNING: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  PROOF_SUBMITTED: "bg-orange-500/20 text-orange-400 border-orange-500/30",
  VERIFIED: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
  COMPLETED: "bg-green-500/20 text-green-400 border-green-500/30",
  DISPUTED: "bg-red-500/20 text-red-400 border-red-500/30",
  CANCELLED: "bg-gray-500/20 text-gray-500 border-gray-500/30",
  ACTIVE: "bg-green-500/20 text-green-400 border-green-500/30",
  INACTIVE: "bg-gray-500/20 text-gray-400 border-gray-500/30",
  SLASHED: "bg-red-500/20 text-red-400 border-red-500/30",
  LOCKED: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  PARTIAL_RELEASE: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  FULLY_RELEASED: "bg-green-500/20 text-green-400 border-green-500/30",
  REFUNDED: "bg-gray-500/20 text-gray-400 border-gray-500/30",
  PENDING: "bg-gray-500/20 text-gray-400 border-gray-500/30",
  IN_PROGRESS: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  FAILED: "bg-red-500/20 text-red-400 border-red-500/30",
};
