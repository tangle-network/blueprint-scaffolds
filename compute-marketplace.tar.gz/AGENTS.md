# AGENTS.md

## Goal

Build a decentralized compute marketplace for verifiable off-chain computation. Job submission, provider matching, result verification.

## Stack

- Family: `react-vite-ts`
- Layers: `capability:shadcn`, `capability:tailwind`, `capability:layout-dashboard`, `auth:none`, `payments:none`, `sdk:none`

## Architecture

- React SPA
- Vite build
- Client-side routing
- REST or tRPC for backend
- shadcn/ui components are pre-installed in src/components/ui/. Import directly: import { Button } from '@/components/ui/button'
- Add more components via: npx shadcn@latest add dialog sheet dropdown-menu
- The cn() utility in src/lib/utils.ts merges Tailwind classes. Use it in all custom components.
- Configure tsconfig.json paths: { '@/*': ['./src/*'] }
- Generate tailwind.config.ts from tailwind-config.json
- Add CSS variables from design-tokens.json to globals.css
- Use class-based dark mode with .dark class toggle
- Dashboard layout is pre-built. Customize nav items in src/config/nav.ts.
- Replace chart card placeholder data with real data sources.
- Sidebar collapses to icon-only on mobile (Sheet/Drawer pattern).
- Add new dashboard sections by extending the grid in dashboard-page.tsx.

## Entry Points

- `index.html`
- `src/main.ts`
- `src/App.ts`
- `vite.config.ts`

## Commands

- `npm install`
- `npm run dev`
- `node preview-server.mjs`

## Build Plan

Pages: /dashboard, /dashboard/analytics, /dashboard/settings
Components: SidebarLayout, ChartCard, KPICard, RecentActivity, NavConfig

## Design

DESIGN RULES (follow these when generating UI code):

General:
- Build polished, production-quality interfaces — not prototypes.
- Use consistent spacing (p-4, p-6, gap-4, gap-6). Avoid arbitrary values.
- Every interactive element needs hover and focus states.
- Support dark mode via the .dark class and CSS custom properties.
- Use subtle transitions (transition-colors, duration-150) on interactive elements.
- Prefer rounded-lg for cards and rounded-md for buttons and inputs.

shadcn/ui:
- 27 components pre-installed in src/components/ui/: Alert, Avatar, Badge, Breadcrumb, Button, Card, Checkbox, Command, Dialog, DropdownMenu, Form, Input, Label, Progress, ScrollArea, Select, Separator, Sheet, Sidebar, Skeleton, Switch, Table, Tabs, Textarea, Toast, Toggle, Tooltip.
- Import directly: import { Button } from "@/components/ui/button"
- Use the cn() utility from @/lib/utils for merging Tailwind classes.
- Never ship unstyled native HTML when a shadcn component exists.
- For Radix-powered versions, install @radix-ui/* and update the component.
- Follow the new-york style: tighter spacing, smaller radius, more refined.

Tailwind:
- Use the design token colors (bg-background, text-foreground, bg-card, etc.) — never hardcode hex values.
- Use the color scale for emphasis: text-muted-foreground for secondary text, bg-muted for subtle backgrounds.
- Responsive: mobile-first. Use sm:, md:, lg: breakpoints.

Quality bar:
- Every page should look intentionally designed, not like a code demo.
- Use proper empty states with illustrations or icons.
- Loading states: use Skeleton components, not spinners.
- Error states: use destructive variant Badge or Alert, not raw text.

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
