export type ProviderId = "pyth" | "switchboard" | "dia" | "chainlink";

export interface OracleProvider {
  id: ProviderId;
  name: string;
  reputation: number;
  stakeAmount: number;
  isActive: boolean;
  totalSubmissions: number;
  slashingEvents: number;
  weight: number;
}

export interface PricePoint {
  price: number;
  volume: number;
  timestamp: number;
  providerId: ProviderId;
  feedId: string;
}

export interface PriceFeed {
  id: string;
  name: string;
  pair: string;
  decimals: number;
  isActive: boolean;
  heartbeatIntervalMs: number;
  maxDeviationBps: number;
  lastUpdatedAt: number;
  lastPrice: number;
  providers: ProviderId[];
  circuitBreakerEnabled: boolean;
}

export interface AggregatedPrice {
  feedId: string;
  price: number;
  confidence: number;
  timestamp: number;
  sources: { providerId: ProviderId; price: number; weight: number; isOutlier: boolean }[];
  twap: number;
  vwap: number;
}

export interface CircuitBreakerState {
  feedId: string;
  isActive: boolean;
  triggeredAt: number | null;
  reason: string | null;
  maxPriceChangeBps: number;
  cooldownMs: number;
  autoReset: boolean;
}

export interface GovernanceAction {
  id: string;
  type: "add_feed" | "remove_feed" | "set_weight" | "set_bounds" | "slash_provider" | "update_heartbeat";
  description: string;
  proposer: string;
  votesFor: number;
  votesAgainst: number;
  status: "pending" | "passed" | "executed" | "rejected";
  createdAt: number;
  executeAfter: number;
}

export interface TWAPSnapshot {
  feedId: string;
  windowMs: number;
  prices: { price: number; timestamp: number }[];
  twap: number;
  vwap: number;
}

export type FeedConfig = Pick<PriceFeed, "id" | "name" | "pair" | "decimals" | "heartbeatIntervalMs" | "maxDeviationBps" | "circuitBreakerEnabled">;
