import { feeds, moveArtifacts, providerPolicies } from './data/mock';
import { buildSnapshot, providerHealth } from './lib/oracle';
import type { OracleFeed, ProviderPolicy } from './types';

const currency = (value: number, digits = 2) =>
  new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: digits,
  }).format(value);

const compact = (value: number) =>
  new Intl.NumberFormat('en-US', {
    notation: 'compact',
    maximumFractionDigits: 1,
  }).format(value);

function FeedCard({
  feed,
  policies,
}: {
  feed: OracleFeed;
  policies: ProviderPolicy[];
}) {
  const snapshot = buildSnapshot(feed, policies);

  return (
    <section className="panel feed-card">
      <div className="feed-header">
        <div>
          <p className="eyebrow">{feed.config.symbol}</p>
          <h2>{feed.config.displayName}</h2>
        </div>
        <div className={snapshot.circuitBroken ? 'badge alert' : 'badge ok'}>
          {snapshot.circuitBroken ? 'Circuit breaker armed' : 'Healthy'}
        </div>
      </div>

      <div className="metric-grid">
        <article>
          <span>Aggregate</span>
          <strong>{currency(snapshot.aggregatePrice, feed.config.symbol === 'BTC/USD' ? 2 : 3)}</strong>
        </article>
        <article>
          <span>Weighted median</span>
          <strong>{currency(snapshot.weightedMedian, feed.config.symbol === 'BTC/USD' ? 2 : 3)}</strong>
        </article>
        <article>
          <span>TWAP</span>
          <strong>{currency(snapshot.twap, feed.config.symbol === 'BTC/USD' ? 2 : 3)}</strong>
        </article>
        <article>
          <span>VWAP</span>
          <strong>{currency(snapshot.vwap, feed.config.symbol === 'BTC/USD' ? 2 : 3)}</strong>
        </article>
      </div>

      <div className="insight-row">
        <div>
          <span>Deviation vs TWAP</span>
          <strong>{snapshot.deviationBps.toFixed(1)} bps</strong>
        </div>
        <div>
          <span>Outliers</span>
          <strong>{snapshot.outliers.length ? snapshot.outliers.join(', ') : 'None'}</strong>
        </div>
        <div>
          <span>Stale</span>
          <strong>{snapshot.staleProviders.length ? snapshot.staleProviders.join(', ') : 'None'}</strong>
        </div>
      </div>

      <table>
        <thead>
          <tr>
            <th>Provider</th>
            <th>Price</th>
            <th>Weight</th>
            <th>Confidence</th>
            <th>Reputation</th>
            <th>Stake</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {feed.providers.map((provider) => (
            <tr key={`${feed.config.symbol}-${provider.provider}`}>
              <td>{provider.provider}</td>
              <td>{currency(provider.price, feed.config.symbol === 'BTC/USD' ? 2 : 3)}</td>
              <td>{provider.weight}%</td>
              <td>{provider.confidenceBps} bps</td>
              <td>{provider.reputation}</td>
              <td>{compact(provider.stakeApt)} APT</td>
              <td>{providerHealth(provider, snapshot.aggregatePrice)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {snapshot.slashCandidates.length > 0 ? (
        <p className="callout danger">
          Slash candidates: {snapshot.slashCandidates.join(', ')} exceed governance deviation bounds.
        </p>
      ) : (
        <p className="callout">No providers currently exceed the slashing threshold.</p>
      )}
    </section>
  );
}

export default function App() {
  return (
    <div className="app-shell">
      <header className="hero panel">
        <div>
          <p className="eyebrow">Aptos / Move Oracle Stack</p>
          <h1>Decentralized price aggregation with guard rails and governance.</h1>
          <p className="lede">
            Aggregates Pyth and Switchboard updates, rejects outliers, computes weighted median,
            TWAP, VWAP, heartbeat health, and slashing recommendations for misbehaving providers.
          </p>
        </div>
        <div className="hero-stats">
          <div>
            <span>Feeds monitored</span>
            <strong>{feeds.length}</strong>
          </div>
          <div>
            <span>Providers configured</span>
            <strong>{providerPolicies.length}</strong>
          </div>
          <div>
            <span>Move modules</span>
            <strong>{moveArtifacts.length}</strong>
          </div>
        </div>
      </header>

      <main className="content-grid">
        <div className="stack">
          {feeds.map((feed) => (
            <FeedCard key={feed.config.symbol} feed={feed} policies={providerPolicies} />
          ))}
        </div>

        <aside className="stack">
          <section className="panel">
            <p className="eyebrow">Admin Controls</p>
            <h2>Provider weights and bounds</h2>
            <table>
              <thead>
                <tr>
                  <th>Provider</th>
                  <th>Enabled</th>
                  <th>Weight</th>
                  <th>Min rep</th>
                  <th>Slash @</th>
                </tr>
              </thead>
              <tbody>
                {providerPolicies.map((policy) => (
                  <tr key={policy.provider}>
                    <td>{policy.provider}</td>
                    <td>{policy.enabled ? 'Yes' : 'No'}</td>
                    <td>{policy.targetWeight}%</td>
                    <td>{policy.minReputation}</td>
                    <td>{policy.slashThresholdBps} bps</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p className="callout">
              Governance can tune provider thresholds, heartbeat windows, and circuit breaker bounds
              before pushing the values on-chain.
            </p>
          </section>

          <section className="panel">
            <p className="eyebrow">On-chain Layout</p>
            <h2>Move package</h2>
            <ul className="artifact-list">
              {moveArtifacts.map((artifact) => (
                <li key={artifact}>{artifact}</li>
              ))}
            </ul>
            <p className="callout">
              The Move modules model feed configs, provider staking, price submissions, weighted
              median aggregation, and slashing hooks for bad data.
            </p>
          </section>

          <section className="panel">
            <p className="eyebrow">Risk Engine</p>
            <h2>Circuit breaker logic</h2>
            <div className="rules">
              <div>
                <strong>Outlier detection</strong>
                <span>Rejects provider readings beyond configurable basis-point bounds.</span>
              </div>
              <div>
                <strong>Staleness checks</strong>
                <span>Disables updates that miss heartbeat or max staleness windows.</span>
              </div>
              <div>
                <strong>Slashing</strong>
                <span>Flags providers that deviate from the aggregate above policy thresholds.</span>
              </div>
            </div>
          </section>
        </aside>
      </main>
    </div>
  );
}
