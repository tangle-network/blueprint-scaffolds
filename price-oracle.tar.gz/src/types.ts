export type ProviderName = 'Pyth' | 'Switchboard' | 'InternalGuard';

export interface ProviderReading {
  provider: ProviderName;
  price: number;
  confidenceBps: number;
  volume: number;
  weight: number;
  timestamp: string;
  reputation: number;
  stakeApt: number;
}

export interface HistoryPoint {
  timestamp: string;
  price: number;
  volume: number;
}

export interface FeedConfig {
  symbol: string;
  displayName: string;
  heartbeatSecs: number;
  maxStalenessSecs: number;
  outlierThresholdBps: number;
  circuitBreakerBps: number;
  minProviders: number;
}

export interface ProviderPolicy {
  provider: ProviderName;
  enabled: boolean;
  targetWeight: number;
  minReputation: number;
  slashThresholdBps: number;
}

export interface OracleFeed {
  config: FeedConfig;
  providers: ProviderReading[];
  history: HistoryPoint[];
}

export interface OracleSnapshot {
  aggregatePrice: number;
  weightedMedian: number;
  twap: number;
  vwap: number;
  deviationBps: number;
  staleProviders: ProviderName[];
  outliers: ProviderName[];
  circuitBroken: boolean;
  slashCandidates: ProviderName[];
}
