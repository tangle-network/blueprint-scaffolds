import type { OracleFeed, ProviderPolicy } from '../types';

const now = Date.now();
const minutesAgo = (minutes: number) => new Date(now - minutes * 60_000).toISOString();

export const providerPolicies: ProviderPolicy[] = [
  {
    provider: 'Pyth',
    enabled: true,
    targetWeight: 55,
    minReputation: 80,
    slashThresholdBps: 120,
  },
  {
    provider: 'Switchboard',
    enabled: true,
    targetWeight: 35,
    minReputation: 75,
    slashThresholdBps: 120,
  },
  {
    provider: 'InternalGuard',
    enabled: true,
    targetWeight: 10,
    minReputation: 70,
    slashThresholdBps: 180,
  },
];

export const feeds: OracleFeed[] = [
  {
    config: {
      symbol: 'BTC/USD',
      displayName: 'Bitcoin',
      heartbeatSecs: 30,
      maxStalenessSecs: 90,
      outlierThresholdBps: 90,
      circuitBreakerBps: 140,
      minProviders: 2,
    },
    providers: [
      {
        provider: 'Pyth',
        price: 64302.42,
        confidenceBps: 18,
        volume: 9800000,
        weight: 55,
        timestamp: minutesAgo(0.2),
        reputation: 96,
        stakeApt: 180000,
      },
      {
        provider: 'Switchboard',
        price: 64290.15,
        confidenceBps: 24,
        volume: 7600000,
        weight: 35,
        timestamp: minutesAgo(0.4),
        reputation: 91,
        stakeApt: 125000,
      },
      {
        provider: 'InternalGuard',
        price: 64780.8,
        confidenceBps: 52,
        volume: 900000,
        weight: 10,
        timestamp: minutesAgo(0.1),
        reputation: 83,
        stakeApt: 70000,
      },
    ],
    history: [
      { timestamp: minutesAgo(50), price: 64020.5, volume: 1300 },
      { timestamp: minutesAgo(40), price: 64110.1, volume: 1520 },
      { timestamp: minutesAgo(30), price: 64195.6, volume: 1640 },
      { timestamp: minutesAgo(20), price: 64250.2, volume: 1480 },
      { timestamp: minutesAgo(10), price: 64288.9, volume: 1725 },
      { timestamp: minutesAgo(0), price: 64302.4, volume: 1910 },
    ],
  },
  {
    config: {
      symbol: 'APT/USD',
      displayName: 'Aptos',
      heartbeatSecs: 20,
      maxStalenessSecs: 60,
      outlierThresholdBps: 110,
      circuitBreakerBps: 180,
      minProviders: 2,
    },
    providers: [
      {
        provider: 'Pyth',
        price: 9.14,
        confidenceBps: 22,
        volume: 2200000,
        weight: 50,
        timestamp: minutesAgo(0.1),
        reputation: 94,
        stakeApt: 180000,
      },
      {
        provider: 'Switchboard',
        price: 9.12,
        confidenceBps: 31,
        volume: 1750000,
        weight: 35,
        timestamp: minutesAgo(0.3),
        reputation: 89,
        stakeApt: 125000,
      },
      {
        provider: 'InternalGuard',
        price: 8.87,
        confidenceBps: 80,
        volume: 320000,
        weight: 15,
        timestamp: minutesAgo(1.6),
        reputation: 76,
        stakeApt: 70000,
      },
    ],
    history: [
      { timestamp: minutesAgo(50), price: 8.98, volume: 8400 },
      { timestamp: minutesAgo(40), price: 9.01, volume: 9020 },
      { timestamp: minutesAgo(30), price: 9.05, volume: 10180 },
      { timestamp: minutesAgo(20), price: 9.08, volume: 9600 },
      { timestamp: minutesAgo(10), price: 9.11, volume: 10440 },
      { timestamp: minutesAgo(0), price: 9.13, volume: 11150 },
    ],
  },
];

export const moveArtifacts = [
  'move/sources/oracle.move',
  'move/sources/governance.move',
  'move/Move.toml',
];
