import type { CircuitBreakerState, PriceFeed } from "@/types/oracle";

export function checkStaleness(feed: PriceFeed): { isStale: boolean; ageMs: number } {
  const ageMs = Date.now() - feed.lastUpdatedAt;
  return {
    isStale: ageMs > feed.heartbeatIntervalMs,
    ageMs,
  };
}

export function checkHeartbeat(
  feed: PriceFeed,
  lastUpdateTime: number
): { healthy: boolean; missedBeats: number; nextDueMs: number } {
  const now = Date.now();
  const elapsed = now - lastUpdateTime;
  const missedBeats = Math.floor(elapsed / feed.heartbeatIntervalMs);
  return {
    healthy: missedBeats === 0,
    missedBeats,
    nextDueMs: Math.max(0, feed.heartbeatIntervalMs - (elapsed % feed.heartbeatIntervalMs)),
  };
}

export function evaluateCircuitBreaker(
  state: CircuitBreakerState,
  oldPrice: number,
  newPrice: number
): CircuitBreakerState {
  if (!state.isActive) return state;

  if (oldPrice === 0) return state;

  const changeBps = Math.abs((newPrice - oldPrice) / oldPrice) * 10000;

  if (changeBps > state.maxPriceChangeBps) {
    return {
      ...state,
      triggeredAt: Date.now(),
      reason: `Price moved ${changeBps.toFixed(0)} bps (> ${state.maxPriceChangeBps} bps limit)`,
    };
  }

  return state;
}

export function shouldResetCircuitBreaker(state: CircuitBreakerState): boolean {
  if (!state.triggeredAt || !state.autoReset) return false;
  return Date.now() - state.triggeredAt > state.cooldownMs;
}

export function createDefaultCircuitBreaker(feedId: string): CircuitBreakerState {
  return {
    feedId,
    isActive: true,
    triggeredAt: null,
    reason: null,
    maxPriceChangeBps: 500,
    cooldownMs: 30 * 60 * 1000,
    autoReset: true,
  };
}
