import type { ProviderId, PricePoint, AggregatedPrice, OracleProvider } from "@/types/oracle";

export function weightedMedian(
  submissions: { providerId: ProviderId; price: number; weight: number }[]
): number {
  if (submissions.length === 0) return 0;
  if (submissions.length === 1) return submissions[0].price;

  const sorted = [...submissions].sort((a, b) => a.price - b.price);
  const totalWeight = sorted.reduce((sum, s) => sum + s.weight, 0);
  if (totalWeight === 0) return sorted[Math.floor(sorted.length / 2)].price;

  let cumulative = 0;
  for (const s of sorted) {
    cumulative += s.weight / totalWeight;
    if (cumulative >= 0.5) return s.price;
  }
  return sorted[sorted.length - 1].price;
}

export function detectOutliers(
  submissions: { providerId: ProviderId; price: number }[],
  medianPrice: number,
  maxDeviationBps: number
): Set<ProviderId> {
  const outliers = new Set<ProviderId>();
  for (const s of submissions) {
    if (medianPrice === 0) continue;
    const deviationBps = Math.abs((s.price - medianPrice) / medianPrice) * 10000;
    if (deviationBps > maxDeviationBps) {
      outliers.add(s.providerId);
    }
  }
  return outliers;
}

export function aggregatePrices(
  feedId: string,
  pricePoints: PricePoint[],
  providers: OracleProvider[],
  maxDeviationBps: number
): AggregatedPrice {
  const providerMap = new Map(providers.map((p) => [p.id, p]));
  const submissions = pricePoints.map((pp) => ({
    providerId: pp.providerId,
    price: pp.price,
    weight: providerMap.get(pp.providerId)?.weight ?? 1,
    volume: pp.volume,
    timestamp: pp.timestamp,
  }));

  const medianPrice = weightedMedian(submissions);
  const outlierSet = detectOutliers(submissions, medianPrice, maxDeviationBps);

  const validSubmissions = submissions.filter((s) => !outlierSet.has(s.providerId));
  const validWeighted = weightedMedian(validSubmissions);

  const sources = submissions.map((s) => ({
    providerId: s.providerId,
    price: s.price,
    weight: s.weight,
    isOutlier: outlierSet.has(s.providerId),
  }));

  const avgTimestamp =
    validSubmissions.reduce((sum, s) => sum + s.timestamp, 0) /
    (validSubmissions.length || 1);

  const confidence = validSubmissions.length / (submissions.length || 1);

  return {
    feedId,
    price: validWeighted,
    confidence,
    timestamp: avgTimestamp,
    sources,
    twap: validWeighted,
    vwap: validWeighted,
  };
}
