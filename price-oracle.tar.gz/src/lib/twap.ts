import type { TWAPSnapshot } from "@/types/oracle";

export function calculateTWAP(prices: { price: number; timestamp: number }[]): number {
  if (prices.length === 0) return 0;
  if (prices.length === 1) return prices[0].price;

  const sorted = [...prices].sort((a, b) => a.timestamp - b.timestamp);
  let twapNumerator = 0;
  let totalTime = 0;

  for (let i = 1; i < sorted.length; i++) {
    const dt = sorted[i].timestamp - sorted[i - 1].timestamp;
    const avgPrice = (sorted[i].price + sorted[i - 1].price) / 2;
    twapNumerator += avgPrice * dt;
    totalTime += dt;
  }

  return totalTime === 0 ? sorted[sorted.length - 1].price : twapNumerator / totalTime;
}

export function calculateVWAP(
  prices: { price: number; timestamp: number; volume: number }[]
): number {
  if (prices.length === 0) return 0;

  let totalVolume = 0;
  let weightedSum = 0;

  for (const p of prices) {
    weightedSum += p.price * p.volume;
    totalVolume += p.volume;
  }

  return totalVolume === 0 ? prices[prices.length - 1].price : weightedSum / totalVolume;
}

export function buildTWAPSnapshot(
  feedId: string,
  priceHistory: { price: number; timestamp: number; volume: number }[],
  windowMs: number
): TWAPSnapshot {
  const now = Date.now();
  const cutoff = now - windowMs;
  const windowed = priceHistory.filter((p) => p.timestamp >= cutoff);

  return {
    feedId,
    windowMs,
    prices: windowed.map((p) => ({ price: p.price, timestamp: p.timestamp })),
    twap: calculateTWAP(windowed),
    vwap: calculateVWAP(windowed),
  };
}
