export type FeedStatus = "active" | "stale" | "circuit_breaker" | "paused"

export interface ProviderPrice {
  provider: string
  providerName: string
  price: number
  confidence: number
  timestamp: number
  weight: number
}

export interface PriceFeed {
  feedId: number
  name: string
  symbol: string
  decimals: number
  aggregatedPrice: number
  twap: number
  vwap: number
  lastUpdateTime: number
  heartbeatInterval: number
  maxDeviationBps: number
  minProviders: number
  active: boolean
  status: FeedStatus
  providerPrices: ProviderPrice[]
  priceHistory: { time: number; price: number }[]
}

export interface ProviderInfo {
  address: string
  name: string
  stake: number
  reputation: number
  active: boolean
  slashCount: number
  feedCount: number
}

export interface CircuitBreakerInfo {
  feedId: number
  feedName: string
  triggered: boolean
  maxPriceChangeBps: number
  cooldownSeconds: number
  triggerCount: number
}

export interface OracleConfig {
  totalStake: number
  paused: boolean
  feedCount: number
  providerCount: number
}
