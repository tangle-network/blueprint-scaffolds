import type { PriceFeed, ProviderInfo, CircuitBreakerInfo, OracleConfig } from "./types"

const now = Math.floor(Date.now() / 1000)

export const mockPriceFeeds: PriceFeed[] = [
  {
    feedId: 0,
    name: "Bitcoin",
    symbol: "BTC/USD",
    decimals: 8,
    aggregatedPrice: 67432.18,
    twap: 67250.5,
    vwap: 67380.2,
    lastUpdateTime: now - 12,
    heartbeatInterval: 60,
    maxDeviationBps: 500,
    minProviders: 3,
    active: true,
    status: "active",
    providerPrices: [
      { provider: "0xpyth1", providerName: "Pyth Network", price: 67435.0, confidence: 0.99, timestamp: now - 10, weight: 100 },
      { provider: "0xswitch1", providerName: "Switchboard", price: 67428.5, confidence: 0.97, timestamp: now - 15, weight: 80 },
      { provider: "0xprovider3", providerName: "Supra", price: 67433.0, confidence: 0.95, timestamp: now - 8, weight: 60 },
      { provider: "0xprovider4", providerName: "API3", price: 67430.2, confidence: 0.93, timestamp: now - 20, weight: 50 },
    ],
    priceHistory: Array.from({ length: 24 }, (_, i) => ({
      time: now - (24 - i) * 3600,
      price: 67000 + Math.sin(i * 0.5) * 500 + Math.random() * 200,
    })),
  },
  {
    feedId: 1,
    name: "Ethereum",
    symbol: "ETH/USD",
    decimals: 8,
    aggregatedPrice: 3521.45,
    twap: 3510.2,
    vwap: 3518.8,
    lastUpdateTime: now - 8,
    heartbeatInterval: 60,
    maxDeviationBps: 500,
    minProviders: 3,
    active: true,
    status: "active",
    providerPrices: [
      { provider: "0xpyth1", providerName: "Pyth Network", price: 3522.0, confidence: 0.99, timestamp: now - 5, weight: 100 },
      { provider: "0xswitch1", providerName: "Switchboard", price: 3520.8, confidence: 0.97, timestamp: now - 10, weight: 80 },
      { provider: "0xprovider3", providerName: "Supra", price: 3521.5, confidence: 0.95, timestamp: now - 7, weight: 60 },
    ],
    priceHistory: Array.from({ length: 24 }, (_, i) => ({
      time: now - (24 - i) * 3600,
      price: 3490 + Math.sin(i * 0.4) * 40 + Math.random() * 15,
    })),
  },
  {
    feedId: 2,
    name: "Aptos",
    symbol: "APT/USD",
    decimals: 8,
    aggregatedPrice: 9.87,
    twap: 9.82,
    vwap: 9.85,
    lastUpdateTime: now - 3,
    heartbeatInterval: 60,
    maxDeviationBps: 500,
    minProviders: 3,
    active: true,
    status: "active",
    providerPrices: [
      { provider: "0xpyth1", providerName: "Pyth Network", price: 9.88, confidence: 0.98, timestamp: now - 2, weight: 100 },
      { provider: "0xswitch1", providerName: "Switchboard", price: 9.86, confidence: 0.96, timestamp: now - 5, weight: 80 },
      { provider: "0xprovider3", providerName: "Supra", price: 9.87, confidence: 0.94, timestamp: now - 4, weight: 60 },
    ],
    priceHistory: Array.from({ length: 24 }, (_, i) => ({
      time: now - (24 - i) * 3600,
      price: 9.5 + Math.sin(i * 0.6) * 0.4 + Math.random() * 0.1,
    })),
  },
  {
    feedId: 3,
    name: "USDC",
    symbol: "USDC/USD",
    decimals: 6,
    aggregatedPrice: 1.0001,
    twap: 1.0000,
    vwap: 1.0001,
    lastUpdateTime: now - 120,
    heartbeatInterval: 60,
    maxDeviationBps: 50,
    minProviders: 3,
    active: true,
    status: "stale",
    providerPrices: [
      { provider: "0xpyth1", providerName: "Pyth Network", price: 1.0001, confidence: 0.99, timestamp: now - 120, weight: 100 },
      { provider: "0xswitch1", providerName: "Switchboard", price: 1.0002, confidence: 0.98, timestamp: now - 130, weight: 80 },
    ],
    priceHistory: Array.from({ length: 24 }, (_, i) => ({
      time: now - (24 - i) * 3600,
      price: 0.9998 + Math.random() * 0.0005,
    })),
  },
  {
    feedId: 4,
    name: "Solana",
    symbol: "SOL/USD",
    decimals: 8,
    aggregatedPrice: 178.92,
    twap: 177.5,
    vwap: 178.1,
    lastUpdateTime: now - 5,
    heartbeatInterval: 60,
    maxDeviationBps: 500,
    minProviders: 3,
    active: true,
    status: "circuit_breaker",
    providerPrices: [
      { provider: "0xpyth1", providerName: "Pyth Network", price: 178.9, confidence: 0.98, timestamp: now - 4, weight: 100 },
      { provider: "0xswitch1", providerName: "Switchboard", price: 178.95, confidence: 0.97, timestamp: now - 6, weight: 80 },
      { provider: "0xprovider3", providerName: "Supra", price: 178.91, confidence: 0.95, timestamp: now - 5, weight: 60 },
    ],
    priceHistory: Array.from({ length: 24 }, (_, i) => ({
      time: now - (24 - i) * 3600,
      price: 175 + Math.sin(i * 0.3) * 5 + Math.random() * 2,
    })),
  },
]

export const mockProviders: ProviderInfo[] = [
  { address: "0xpyth1", name: "Pyth Network", stake: 50000, reputation: 98, active: true, slashCount: 0, feedCount: 5 },
  { address: "0xswitch1", name: "Switchboard", stake: 35000, reputation: 95, active: true, slashCount: 1, feedCount: 5 },
  { address: "0xprovider3", name: "Supra Oracle", stake: 25000, reputation: 92, active: true, slashCount: 0, feedCount: 4 },
  { address: "0xprovider4", name: "API3", stake: 20000, reputation: 88, active: true, slashCount: 1, feedCount: 2 },
  { address: "0xprovider5", name: "Bad Actor Corp", stake: 500, reputation: 12, active: false, slashCount: 4, feedCount: 0 },
]

export const mockCircuitBreakers: CircuitBreakerInfo[] = [
  { feedId: 0, feedName: "BTC/USD", triggered: false, maxPriceChangeBps: 500, cooldownSeconds: 300, triggerCount: 0 },
  { feedId: 1, feedName: "ETH/USD", triggered: false, maxPriceChangeBps: 500, cooldownSeconds: 300, triggerCount: 0 },
  { feedId: 2, feedName: "APT/USD", triggered: false, maxPriceChangeBps: 500, cooldownSeconds: 300, triggerCount: 0 },
  { feedId: 3, feedName: "USDC/USD", triggered: false, maxPriceChangeBps: 50, cooldownSeconds: 600, triggerCount: 2 },
  { feedId: 4, feedName: "SOL/USD", triggered: true, maxPriceChangeBps: 500, cooldownSeconds: 300, triggerCount: 1 },
]

export const mockOracleConfig: OracleConfig = {
  totalStake: 130500,
  paused: false,
  feedCount: 5,
  providerCount: 5,
}
