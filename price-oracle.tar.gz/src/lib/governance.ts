import type { OracleProvider, PricePoint } from "@/types/oracle";

export function calculateReputation(
  provider: OracleProvider,
  recentPrices: PricePoint[],
  aggregatedPrices: number[]
): number {
  let correctSubmissions = 0;
  let totalSubmissions = 0;

  for (const price of recentPrices) {
    if (price.providerId !== provider.id) continue;
    totalSubmissions++;
    const aggPrice = aggregatedPrices[totalSubmissions - 1] ?? price.price;
    if (aggPrice === 0) continue;
    const deviationBps = Math.abs((price.price - aggPrice) / aggPrice) * 10000;
    if (deviationBps < 200) {
      correctSubmissions++;
    }
  }

  if (totalSubmissions === 0) return provider.reputation;
  const accuracy = correctSubmissions / totalSubmissions;
  return Math.round(accuracy * 100);
}

export function calculateSlashingAmount(
  provider: OracleProvider,
  deviationBps: number
): number {
  if (deviationBps < 500) return 0;
  if (deviationBps < 1000) return provider.stakeAmount * 0.05;
  if (deviationBps < 2000) return provider.stakeAmount * 0.15;
  return provider.stakeAmount * 0.5;
}

export function updateProviderAfterSubmission(
  provider: OracleProvider,
  priceDeviatonBps: number
): { provider: OracleProvider; slashedAmount: number; wasSlashed: boolean } {
  const slashedAmount = calculateSlashingAmount(provider, priceDeviatonBps);
  const wasSlashed = slashedAmount > 0;

  return {
    provider: {
      ...provider,
      stakeAmount: provider.stakeAmount - slashedAmount,
      totalSubmissions: provider.totalSubmissions + 1,
      slashingEvents: wasSlashed ? provider.slashingEvents + 1 : provider.slashingEvents,
      reputation: wasSlashed
        ? Math.max(0, provider.reputation - 5)
        : Math.min(100, provider.reputation + 1),
      isActive: provider.stakeAmount - slashedAmount > 0,
    },
    slashedAmount,
    wasSlashed,
  };
}
