import type {
  FeedConfig,
  HistoryPoint,
  OracleFeed,
  OracleSnapshot,
  ProviderPolicy,
  ProviderReading,
} from '../types';

const bps = (value: number, reference: number) =>
  reference === 0 ? 0 : Math.abs((value - reference) / reference) * 10000;

const ageSecs = (timestamp: string) =>
  (Date.now() - new Date(timestamp).getTime()) / 1000;

const sortByPrice = (readings: ProviderReading[]) =>
  [...readings].sort((left, right) => left.price - right.price);

export function weightedMedian(readings: ProviderReading[]): number {
  const ordered = sortByPrice(readings);
  const totalWeight = ordered.reduce((sum, reading) => sum + reading.weight, 0);

  let cumulative = 0;
  for (const reading of ordered) {
    cumulative += reading.weight;
    if (cumulative >= totalWeight / 2) {
      return reading.price;
    }
  }

  return ordered[ordered.length - 1]?.price ?? 0;
}

export function detectOutliers(
  readings: ProviderReading[],
  anchorPrice: number,
  thresholdBps: number,
): ProviderReading[] {
  return readings.filter((reading) => bps(reading.price, anchorPrice) > thresholdBps);
}

export function computeTwap(history: HistoryPoint[]): number {
  if (history.length === 0) return 0;
  if (history.length === 1) return history[0].price;

  let weightedSum = 0;
  let totalDuration = 0;

  for (let index = 1; index < history.length; index += 1) {
    const previous = history[index - 1];
    const current = history[index];
    const duration =
      (new Date(current.timestamp).getTime() - new Date(previous.timestamp).getTime()) / 1000;
    weightedSum += previous.price * duration;
    totalDuration += duration;
  }

  return totalDuration === 0 ? history[history.length - 1].price : weightedSum / totalDuration;
}

export function computeVwap(history: HistoryPoint[]): number {
  const volumeTotal = history.reduce((sum, point) => sum + point.volume, 0);
  if (volumeTotal === 0) return history[history.length - 1]?.price ?? 0;

  const notional = history.reduce((sum, point) => sum + point.price * point.volume, 0);
  return notional / volumeTotal;
}

export function eligibleReadings(
  providers: ProviderReading[],
  config: FeedConfig,
  policies: ProviderPolicy[],
): ProviderReading[] {
  return providers.filter((reading) => {
    const policy = policies.find((candidate) => candidate.provider === reading.provider);
    if (!policy || !policy.enabled) return false;
    if (reading.reputation < policy.minReputation) return false;
    if (ageSecs(reading.timestamp) > config.maxStalenessSecs) return false;
    return true;
  });
}

export function buildSnapshot(feed: OracleFeed, policies: ProviderPolicy[]): OracleSnapshot {
  const allowed = eligibleReadings(feed.providers, feed.config, policies);
  const staleProviders = feed.providers
    .filter((reading) => ageSecs(reading.timestamp) > feed.config.maxStalenessSecs)
    .map((reading) => reading.provider);

  if (allowed.length === 0) {
    return {
      aggregatePrice: 0,
      weightedMedian: 0,
      twap: computeTwap(feed.history),
      vwap: computeVwap(feed.history),
      deviationBps: 0,
      staleProviders,
      outliers: [],
      circuitBroken: true,
      slashCandidates: [],
    };
  }

  const median = weightedMedian(allowed);
  const outlierReadings = detectOutliers(allowed, median, feed.config.outlierThresholdBps);
  const inliers = allowed.filter(
    (reading) => !outlierReadings.some((outlier) => outlier.provider === reading.provider),
  );
  const aggregateBase = inliers.length >= feed.config.minProviders ? inliers : allowed;
  const aggregate = weightedMedian(aggregateBase);
  const twap = computeTwap(feed.history);
  const vwap = computeVwap(feed.history);
  const deviationBps = bps(aggregate, twap);
  const circuitBroken = deviationBps > feed.config.circuitBreakerBps;
  const slashCandidates = allowed
    .filter((reading) => {
      const policy = policies.find((candidate) => candidate.provider === reading.provider);
      if (!policy) return false;
      return bps(reading.price, aggregate) > policy.slashThresholdBps;
    })
    .map((reading) => reading.provider);

  return {
    aggregatePrice: aggregate,
    weightedMedian: median,
    twap,
    vwap,
    deviationBps,
    staleProviders,
    outliers: outlierReadings.map((reading) => reading.provider),
    circuitBroken,
    slashCandidates,
  };
}

export function providerHealth(reading: ProviderReading, aggregatePrice: number): string {
  if (aggregatePrice === 0) return 'No aggregate';
  const deviation = bps(reading.price, aggregatePrice);
  if (deviation > 150) return 'Slash risk';
  if (deviation > 60) return 'Watch';
  return 'Healthy';
}
