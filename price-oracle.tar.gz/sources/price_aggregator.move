module oracle::price_aggregator {
    use std::vector;
    use aptos_framework::timestamp;
    use oracle::twap;
    use oracle::circuit_breaker;

    struct PriceFeed has store, copy, drop {
        feed_id: u64,
        name: vector<u8>,
        decimals: u8,
        prices: vector<ProviderPrice>,
        aggregated_price: u64,
        last_update_time: u64,
        heartbeat_interval: u64,
        max_deviation_bps: u64,
        min_providers: u8,
        active: bool,
    }

    struct ProviderPrice has store, copy, drop {
        provider: address,
        price: u64,
        confidence: u64,
        timestamp: u64,
        weight: u64,
    }

    struct Oracle has key {
        admin: address,
        feeds: vector<PriceFeed>,
        total_stake: u64,
        paused: bool,
    }

    struct ProviderInfo has store, copy, drop {
        addr: address,
        stake: u64,
        reputation: u64,
        active: bool,
        slash_count: u64,
    }

    struct Providers has key {
        admin: address,
        providers: vector<ProviderInfo>,
    }

    public entry fun initialize(account: &signer) {
        let addr = signer::address_of(account);
        move_to(account, Oracle {
            admin: addr,
            feeds: vector::empty(),
            total_stake: 0,
            paused: false,
        });
        move_to(account, Providers {
            admin: addr,
            providers: vector::empty(),
        });
    }

    public entry fun register_feed(
        account: &signer,
        name: vector<u8>,
        decimals: u8,
        heartbeat_interval: u64,
        max_deviation_bps: u64,
        min_providers: u8,
    ) acquires Oracle {
        let addr = signer::address_of(account);
        let oracle = borrow_global_mut<Oracle>(addr);
        assert!(addr == oracle.admin, 1);
        let feed_id = vector::length(&oracle.feeds);
        let feed = PriceFeed {
            feed_id,
            name,
            decimals,
            prices: vector::empty(),
            aggregated_price: 0,
            last_update_time: 0,
            heartbeat_interval,
            max_deviation_bps,
            min_providers,
            active: true,
        };
        vector::push_back(&mut oracle.feeds, feed);
    }

    public entry fun submit_price(
        account: &signer,
        feed_id: u64,
        price: u64,
        confidence: u64,
    ) acquires Oracle, Providers, twap::TwapStore, circuit_breaker::CircuitBreaker {
        let addr = signer::address_of(account);
        let now = timestamp::now_seconds();

        let oracle = borrow_global_mut<Oracle>(@oracle);
        assert!(!oracle.paused, 2);
        assert!(feed_id < vector::length(&oracle.feeds), 3);

        let provider_valid = false;
        let providers = borrow_global<Providers>(@oracle);
        let provider_len = vector::length(&providers.providers);
        let mut i = 0;
        while (i < provider_len) {
            let p = vector::borrow(&providers.providers, i);
            if (p.addr == addr && p.active) {
                provider_valid = true;
            };
            i = i + 1;
        };
        assert!(provider_valid, 4);

        let feed = vector::borrow_mut(&mut oracle.feeds, feed_id);
        assert!(feed.active, 5);

        let provider_price = ProviderPrice {
            provider: addr,
            price,
            confidence,
            timestamp: now,
            weight: 100,
        };

        let mut found = false;
        let price_len = vector::length(&feed.prices);
        let mut j = 0;
        while (j < price_len) {
            let pp = vector::borrow_mut(&mut feed.prices, j);
            if (pp.provider == addr) {
                pp.price = price;
                pp.confidence = confidence;
                pp.timestamp = now;
                found = true;
            };
            j = j + 1;
        };
        if (!found) {
            vector::push_back(&mut feed.prices, provider_price);
        };

        let aggregated = compute_weighted_median(&feed.prices);
        let prev_price = feed.aggregated_price;
        feed.aggregated_price = aggregated;
        feed.last_update_time = now;

        twap::record_price(feed_id, aggregated, now);
        circuit_breaker::check_and_trigger(feed_id, prev_price, aggregated);
    }

    public fun compute_weighted_median(prices: &vector<ProviderPrice>): u64 {
        let n = vector::length(prices);
        if (n == 0) { return 0 };
        if (n == 1) { return vector::borrow(prices, 0).price };

        let mut sorted = vector::empty();
        let mut i = 0;
        while (i < n) {
            vector::push_back(&mut sorted, *vector::borrow(prices, i));
            i = i + 1;
        };

        let mut swapped = true;
        while (swapped) {
            swapped = false;
            let mut j = 1;
            while (j < vector::length(&sorted)) {
                let a = vector::borrow(&sorted, j - 1);
                let b = vector::borrow(&sorted, j);
                if (a.price > b.price) {
                    let temp = *a;
                    let a_mut = vector::borrow_mut(&mut sorted, j - 1);
                    *a_mut = *b;
                    let b_mut = vector::borrow_mut(&mut sorted, j);
                    *b_mut = temp;
                    swapped = true;
                };
                j = j + 1;
            };
        };

        let total_weight: u64 = 0;
        let mut k = 0;
        while (k < vector::length(&sorted)) {
            total_weight = total_weight + vector::borrow(&sorted, k).weight;
            k = k + 1;
        };

        let target = total_weight / 2;
        let mut cumulative: u64 = 0;
        let mut m = 0;
        while (m < vector::length(&sorted)) {
            cumulative = cumulative + vector::borrow(&sorted, m).weight;
            if (cumulative >= target) {
                return vector::borrow(&sorted, m).price
            };
            m = m + 1;
        };
        vector::borrow(&sorted, 0).price
    }

    public fun is_stale(feed: &PriceFeed): bool {
        let now = timestamp::now_seconds();
        now - feed.last_update_time > feed.heartbeat_interval
    }

    public fun detect_outliers(feed: &PriceFeed, threshold_bps: u64): vector<address> {
        let mut outliers = vector::empty();
        let n = vector::length(&feed.prices);
        if (n == 0) { return outliers };

        let median = feed.aggregated_price;
        let mut i = 0;
        while (i < n) {
            let pp = vector::borrow(&feed.prices, i);
            let diff = if (pp.price > median) { pp.price - median } else { median - pp.price };
            let deviation_bps = (diff * 10000) / median;
            if (deviation_bps > threshold_bps) {
                vector::push_back(&mut outliers, pp.provider);
            };
            i = i + 1;
        };
        outliers
    }

    public entry fun register_provider(
        account: &signer,
        provider_addr: address,
        initial_stake: u64,
    ) acquires Oracle, Providers {
        let addr = signer::address_of(account);
        let oracle = borrow_global<Oracle>(@oracle);
        assert!(addr == oracle.admin, 1);

        let providers = borrow_global_mut<Providers>(@oracle);
        let info = ProviderInfo {
            addr: provider_addr,
            stake: initial_stake,
            reputation: 100,
            active: true,
            slash_count: 0,
        };
        vector::push_back(&mut providers.providers, info);
        let oracle_mut = borrow_global_mut<Oracle>(@oracle);
        oracle_mut.total_stake = oracle_mut.total_stake + initial_stake;
    }

    public entry fun slash_provider(
        account: &signer,
        provider_addr: address,
        amount: u64,
    ) acquires Oracle, Providers {
        let addr = signer::address_of(account);
        let oracle = borrow_global<Oracle>(@oracle);
        assert!(addr == oracle.admin, 1);

        let providers = borrow_global_mut<Providers>(@oracle);
        let n = vector::length(&providers.providers);
        let mut i = 0;
        while (i < n) {
            let p = vector::borrow_mut(&mut providers.providers, i);
            if (p.addr == provider_addr) {
                p.stake = p.stake - amount;
                p.slash_count = p.slash_count + 1;
                if (p.slash_count >= 3 || p.stake < 100) {
                    p.active = false;
                };
                p.reputation = if (p.reputation > 10) { p.reputation - 10 } else { 0 };
            };
            i = i + 1;
        };
        let oracle_mut = borrow_global_mut<Oracle>(@oracle);
        oracle_mut.total_stake = oracle_mut.total_stake - amount;
    }

    public entry fun set_feed_weights(
        account: &signer,
        feed_id: u64,
        provider_addr: address,
        weight: u64,
    ) acquires Oracle {
        let addr = signer::address_of(account);
        let oracle = borrow_global_mut<Oracle>(addr);
        assert!(addr == oracle.admin, 1);
        assert!(feed_id < vector::length(&oracle.feeds), 3);

        let feed = vector::borrow_mut(&mut oracle.feeds, feed_id);
        let n = vector::length(&feed.prices);
        let mut i = 0;
        while (i < n) {
            let pp = vector::borrow_mut(&mut feed.prices, i);
            if (pp.provider == provider_addr) {
                pp.weight = weight;
            };
            i = i + 1;
        };
    }

    public entry fun toggle_feed(account: &signer, feed_id: u64, active: bool) acquires Oracle {
        let addr = signer::address_of(account);
        let oracle = borrow_global_mut<Oracle>(addr);
        assert!(addr == oracle.admin, 1);
        assert!(feed_id < vector::length(&oracle.feeds), 3);
        let feed = vector::borrow_mut(&mut oracle.feeds, feed_id);
        feed.active = active;
    }

    public entry fun emergency_pause(account: &signer) acquires Oracle {
        let addr = signer::address_of(account);
        let oracle = borrow_global_mut<Oracle>(addr);
        assert!(addr == oracle.admin, 1);
        oracle.paused = true;
    }

    public entry fun emergency_unpause(account: &signer) acquires Oracle {
        let addr = signer::address_of(account);
        let oracle = borrow_global_mut<Oracle>(addr);
        assert!(addr == oracle.admin, 1);
        oracle.paused = false;
    }

    #[view]
    public fun get_aggregated_price(feed_id: u64): u64 acquires Oracle {
        let oracle = borrow_global<Oracle>(@oracle);
        assert!(feed_id < vector::length(&oracle.feeds), 3);
        let feed = vector::borrow(&oracle.feeds, feed_id);
        feed.aggregated_price
    }

    #[view]
    public fun get_feed_count(): u64 acquires Oracle {
        let oracle = borrow_global<Oracle>(@oracle);
        vector::length(&oracle.feeds)
    }

    #[view]
    public fun is_feed_stale(feed_id: u64): bool acquires Oracle {
        let oracle = borrow_global<Oracle>(@oracle);
        assert!(feed_id < vector::length(&oracle.feeds), 3);
        let feed = vector::borrow(&oracle.feeds, feed_id);
        is_stale(feed)
    }
}
