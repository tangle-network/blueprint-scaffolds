module oracle::circuit_breaker {
    use std::vector;

    struct FeedBreaker has store, copy, drop {
        feed_id: u64,
        triggered: bool,
        max_price_change_bps: u64,
        cooldown_seconds: u64,
        triggered_at: u64,
        trigger_count: u64,
    }

    struct CircuitBreaker has key {
        admin: address,
        breakers: vector<FeedBreaker>,
        global_halted: bool,
    }

    public entry fun initialize(account: &signer) {
        let addr = signer::address_of(account);
        move_to(account, CircuitBreaker {
            admin: addr,
            breakers: vector::empty(),
            global_halted: false,
        });
    }

    public entry fun register_breaker(
        account: &signer,
        feed_id: u64,
        max_price_change_bps: u64,
        cooldown_seconds: u64,
    ) acquires CircuitBreaker {
        let addr = signer::address_of(account);
        let cb = borrow_global_mut<CircuitBreaker>(addr);
        assert!(addr == cb.admin, 200);
        let breaker = FeedBreaker {
            feed_id,
            triggered: false,
            max_price_change_bps,
            cooldown_seconds,
            triggered_at: 0,
            trigger_count: 0,
        };
        vector::push_back(&mut cb.breakers, breaker);
    }

    public fun check_and_trigger(
        feed_id: u64,
        prev_price: u64,
        new_price: u64,
    ) acquires CircuitBreaker {
        let cb = borrow_global_mut<CircuitBreaker>(@oracle);
        if (cb.global_halted) { return };

        let n = vector::length(&cb.breakers);
        let mut i = 0;
        while (i < n) {
            let breaker = vector::borrow_mut(&mut cb.breakers, i);
            if (breaker.feed_id == feed_id) {
                if (breaker.triggered) {
                    return
                };
                if (prev_price == 0) { return };
                let diff = if (new_price > prev_price) {
                    new_price - prev_price
                } else {
                    prev_price - new_price
                };
                let change_bps = (diff * 10000) / prev_price;
                if (change_bps > breaker.max_price_change_bps) {
                    breaker.triggered = true;
                    breaker.triggered_at = 0;
                    breaker.trigger_count = breaker.trigger_count + 1;
                };
            };
            i = i + 1;
        };
    }

    public entry fun reset_breaker(account: &signer, feed_id: u64) acquires CircuitBreaker {
        let addr = signer::address_of(account);
        let cb = borrow_global_mut<CircuitBreaker>(addr);
        assert!(addr == cb.admin, 200);
        let n = vector::length(&cb.breakers);
        let mut i = 0;
        while (i < n) {
            let breaker = vector::borrow_mut(&mut cb.breakers, i);
            if (breaker.feed_id == feed_id) {
                breaker.triggered = false;
                breaker.triggered_at = 0;
            };
            i = i + 1;
        };
    }

    public entry fun update_breaker_config(
        account: &signer,
        feed_id: u64,
        max_price_change_bps: u64,
        cooldown_seconds: u64,
    ) acquires CircuitBreaker {
        let addr = signer::address_of(account);
        let cb = borrow_global_mut<CircuitBreaker>(addr);
        assert!(addr == cb.admin, 200);
        let n = vector::length(&cb.breakers);
        let mut i = 0;
        while (i < n) {
            let breaker = vector::borrow_mut(&mut cb.breakers, i);
            if (breaker.feed_id == feed_id) {
                breaker.max_price_change_bps = max_price_change_bps;
                breaker.cooldown_seconds = cooldown_seconds;
            };
            i = i + 1;
        };
    }

    public entry fun global_halt(account: &signer) acquires CircuitBreaker {
        let addr = signer::address_of(account);
        let cb = borrow_global_mut<CircuitBreaker>(addr);
        assert!(addr == cb.admin, 200);
        cb.global_halted = true;
    }

    public entry fun global_resume(account: &signer) acquires CircuitBreaker {
        let addr = signer::address_of(account);
        let cb = borrow_global_mut<CircuitBreaker>(addr);
        assert!(addr == cb.admin, 200);
        cb.global_halted = false;
    }

    #[view]
    public fun is_triggered(feed_id: u64): bool acquires CircuitBreaker {
        let cb = borrow_global<CircuitBreaker>(@oracle);
        if (cb.global_halted) { return true };
        let n = vector::length(&cb.breakers);
        let mut i = 0;
        while (i < n) {
            let breaker = vector::borrow(&cb.breakers, i);
            if (breaker.feed_id == feed_id) {
                return breaker.triggered
            };
            i = i + 1;
        };
        false
    }

    #[view]
    public fun is_global_halted(): bool acquires CircuitBreaker {
        let cb = borrow_global<CircuitBreaker>(@oracle);
        cb.global_halted
    }
}
