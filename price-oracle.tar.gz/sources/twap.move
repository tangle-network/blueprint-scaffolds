module oracle::twap {
    use std::vector;

    struct PriceEntry has store, copy, drop {
        price: u64,
        volume: u64,
        timestamp: u64,
    }

    struct FeedTwap has store {
        feed_id: u64,
        entries: vector<PriceEntry>,
        max_entries: u64,
        twap: u64,
        vwap: u64,
    }

    struct TwapStore has key {
        admin: address,
        feeds: vector<FeedTwap>,
    }

    public entry fun initialize(account: &signer) {
        let addr = signer::address_of(account);
        move_to(account, TwapStore {
            admin: addr,
            feeds: vector::empty(),
        });
    }

    public entry fun register_twap_feed(account: &signer, feed_id: u64, max_entries: u64) acquires TwapStore {
        let addr = signer::address_of(account);
        let store = borrow_global_mut<TwapStore>(addr);
        assert!(addr == store.admin, 100);
        let ft = FeedTwap {
            feed_id,
            entries: vector::empty(),
            max_entries,
            twap: 0,
            vwap: 0,
        };
        vector::push_back(&mut store.feeds, ft);
    }

    public fun record_price(feed_id: u64, price: u64, timestamp: u64) acquires TwapStore {
        let store = borrow_global_mut<TwapStore>(@oracle);
        let n = vector::length(&store.feeds);
        let mut i = 0;
        while (i < n) {
            let ft = vector::borrow_mut(&mut store.feeds, i);
            if (ft.feed_id == feed_id) {
                let entry = PriceEntry { price, volume: 1, timestamp };
                vector::push_back(&mut ft.entries, entry);
                if (vector::length(&ft.entries) > ft.max_entries) {
                    vector::remove(&mut ft.entries, 0);
                };
                ft.twap = compute_twap(&ft.entries);
                ft.vwap = compute_vwap(&ft.entries);
            };
            i = i + 1;
        };
    }

    public fun compute_twap(entries: &vector<PriceEntry>): u64 {
        let n = vector::length(entries);
        if (n == 0) { return 0 };
        if (n == 1) { return vector::borrow(entries, 0).price };

        let first_ts = vector::borrow(entries, 0).timestamp;
        let last_ts = vector::borrow(entries, n - 1).timestamp;
        let total_time = last_ts - first_ts;
        if (total_time == 0) { return vector::borrow(entries, n - 1).price };

        let mut weighted_sum: u64 = 0;
        let mut i = 1;
        while (i < n) {
            let prev = vector::borrow(entries, i - 1);
            let curr = vector::borrow(entries, i);
            let dt = curr.timestamp - prev.timestamp;
            let avg_price = (prev.price + curr.price) / 2;
            weighted_sum = weighted_sum + (avg_price * dt);
            i = i + 1;
        };
        weighted_sum / total_time
    }

    public fun compute_vwap(entries: &vector<PriceEntry>): u64 {
        let n = vector::length(entries);
        if (n == 0) { return 0 };

        let mut total_pv: u64 = 0;
        let mut total_vol: u64 = 0;
        let mut i = 0;
        while (i < n) {
            let e = vector::borrow(entries, i);
            total_pv = total_pv + (e.price * e.volume);
            total_vol = total_vol + e.volume;
            i = i + 1;
        };
        if (total_vol == 0) { return 0 };
        total_pv / total_vol
    }

    #[view]
    public fun get_twap(feed_id: u64): u64 acquires TwapStore {
        let store = borrow_global<TwapStore>(@oracle);
        let n = vector::length(&store.feeds);
        let mut i = 0;
        while (i < n) {
            let ft = vector::borrow(&store.feeds, i);
            if (ft.feed_id == feed_id) {
                return ft.twap
            };
            i = i + 1;
        };
        0
    }

    #[view]
    public fun get_vwap(feed_id: u64): u64 acquires TwapStore {
        let store = borrow_global<TwapStore>(@oracle);
        let n = vector::length(&store.feeds);
        let mut i = 0;
        while (i < n) {
            let ft = vector::borrow(&store.feeds, i);
            if (ft.feed_id == feed_id) {
                return ft.vwap
            };
            i = i + 1;
        };
        0
    }
}
