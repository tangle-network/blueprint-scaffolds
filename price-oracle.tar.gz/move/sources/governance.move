module oracle::governance {
    use std::signer;
    use std::string::String;
    use std::vector;

    const ENOT_ADMIN: u64 = 1;
    const ENO_STAKE: u64 = 2;

    struct ProviderStake has copy, drop, store {
        provider: String,
        staker: address,
        amount: u64,
        slash_count: u64,
    }

    struct Governance has key {
        admin: address,
        stakes: vector<ProviderStake>,
    }

    public entry fun init(admin: &signer) {
        move_to(admin, Governance {
            admin: signer::address_of(admin),
            stakes: vector::empty<ProviderStake>(),
        });
    }

    public entry fun stake(
        account: &signer,
        governance_addr: address,
        provider: String,
        amount: u64,
    ) acquires Governance {
        let governance = borrow_global_mut<Governance>(governance_addr);
        vector::push_back(&mut governance.stakes, ProviderStake {
            provider,
            staker: signer::address_of(account),
            amount,
            slash_count: 0,
        });
    }

    public entry fun slash_provider(
        admin: &signer,
        governance_addr: address,
        provider: String,
        slash_bps: u64,
    ) acquires Governance {
        let governance = borrow_global_mut<Governance>(governance_addr);
        assert!(governance.admin == signer::address_of(admin), ENOT_ADMIN);

        let index = 0;
        let found = false;
        while (index < vector::length(&governance.stakes)) {
            let stake = vector::borrow_mut(&mut governance.stakes, index);
            if (stake.provider == provider) {
                let penalty = (stake.amount * slash_bps) / 10000;
                assert!(stake.amount >= penalty, ENO_STAKE);
                stake.amount = stake.amount - penalty;
                stake.slash_count = stake.slash_count + 1;
                found = true;
            };
            index = index + 1;
        };

        assert!(found, ENO_STAKE);
    }
}
