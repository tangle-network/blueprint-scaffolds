module price-oracle::TreasuryVaultTests {
    use price-oracle::TreasuryVault;

    #[test(account = @price-oracle)]
    fun initializes_balance(account: signer) {
        TreasuryVault::initialize(&account);
        assert!(TreasuryVault::balance(@price-oracle) == 0, 0);
    }
}
