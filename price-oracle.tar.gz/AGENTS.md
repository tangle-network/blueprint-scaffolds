# AGENTS.md

## Goal

Build a decentralized price oracle on Aptos/Move. Multi-source aggregation, staleness checks, authorized updaters.

## Stack

- Family: `move-contracts`
- Layers: `capability:move-oracle`

## Entry Points

- `Move.toml`
- `sources/TreasuryVault.move`
- `tests/TreasuryVaultTests.move`

## Commands

- `aptos move test`
- `sui move test`

## Build Plan

Components: PriceFeed, OracleAggregator
Data models: PriceData, FeedSource
Integrations: Pyth Network, Switchboard

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
