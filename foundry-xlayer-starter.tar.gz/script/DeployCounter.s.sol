// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {Script, console} from "forge-std/Script.sol";
import {Counter} from "../src/Counter.sol";

contract DeployCounter is Script {
    function run() external returns (Counter) {
        uint256 deployerPrivateKey = vm.envUint("PRIVATE_KEY");
        uint256 initialCount = vm.envOr("INITIAL_COUNT", uint256(0));

        vm.startBroadcast(deployerPrivateKey);

        Counter counter = new Counter(initialCount);

        vm.stopBroadcast();

        console.log("Counter deployed to:", address(counter));
        console.log("Initial count:", initialCount);
        console.log("Network: X Layer (OKB-native L2, Polygon CDK)");

        return counter;
    }
}
