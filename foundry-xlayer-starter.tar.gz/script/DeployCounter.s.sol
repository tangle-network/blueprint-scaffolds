// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {Script} from "forge-std/Script.sol";
import {console2} from "forge-std/console2.sol";
import {Counter} from "../src/Counter.sol";

contract DeployCounter is Script {
    function run() external {
        uint256 deployerPrivateKey = vm.envUint("PRIVATE_KEY");
        uint256 initialCount = vm.envOr("INITIAL_COUNT", uint256(0));

        vm.startBroadcast(deployerPrivateKey);

        Counter counter = new Counter(initialCount);

        vm.stopBroadcast();

        console2.log("Counter deployed at:", address(counter));
        console2.log("Initial count:", counter.count());
        console2.log("Owner:", counter.owner());
        console2.log("");
        console2.log("Network: X Layer (OKX EVM L2, Polygon CDK)");
        console2.log("Native token: OKB (not ETH)");
        console2.log("Chain ID:", block.chainid);
    }
}
