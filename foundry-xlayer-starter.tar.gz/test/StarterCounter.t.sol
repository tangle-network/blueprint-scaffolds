// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import { StarterCounter } from "../src/StarterCounter.sol";

contract StarterCounterTest {
    StarterCounter internal counter;

    function setUp() public {
        counter = new StarterCounter();
    }

    function test_set_and_get() public {
        counter.set(42);
        assert(counter.get() == 42);
    }
}
