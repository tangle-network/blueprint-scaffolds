// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {Test} from "forge-std/Test.sol";
import {Counter} from "../src/Counter.sol";

contract CounterTest is Test {
    Counter public counter;
    address public owner;
    address public alice;

    function setUp() public {
        owner = address(this);
        alice = makeAddr("alice");
        counter = new Counter(42);
    }

    function test_InitialCount() public view {
        assertEq(counter.count(), 42);
        assertEq(counter.getCount(), 42);
    }

    function test_OwnerSet() public view {
        assertEq(counter.owner(), owner);
    }

    function test_Increment() public {
        vm.prank(alice);
        counter.increment();
        assertEq(counter.count(), 43);

        vm.prank(alice);
        counter.increment();
        assertEq(counter.count(), 44);
    }

    function testFuzz_Increment(uint8 increments) public {
        vm.startPrank(alice);
        for (uint256 i = 0; i < increments; i++) {
            counter.increment();
        }
        vm.stopPrank();
        assertEq(counter.count(), 42 + uint256(increments));
    }

    function test_Decrement() public {
        counter.decrement();
        assertEq(counter.count(), 41);
    }

    function test_RevertWhen_DecrementBelowZero() public {
        Counter freshCounter = new Counter(0);
        vm.prank(alice);
        vm.expectRevert("Counter: cannot decrement below zero");
        freshCounter.decrement();
    }

    function test_Reset() public {
        counter.reset(100);
        assertEq(counter.count(), 100);
    }

    function test_RevertWhen_ResetNotOwner() public {
        vm.prank(alice);
        vm.expectRevert();
        counter.reset(999);
    }

    function test_IncrementEvent() public {
        vm.prank(alice);
        vm.expectEmit(true, false, false, true);
        emit Counter.CountIncremented(43, alice);
        counter.increment();
    }

    function test_DecrementEvent() public {
        vm.expectEmit(true, false, false, true);
        emit Counter.CountDecremented(41, owner);
        counter.decrement();
    }

    function test_ResetEvent() public {
        vm.expectEmit(true, false, false, true);
        emit Counter.CountReset(42, owner);
        counter.reset(0);
    }
}
