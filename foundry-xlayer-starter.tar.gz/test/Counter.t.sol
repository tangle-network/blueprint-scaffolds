// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {Test, console} from "forge-std/Test.sol";
import {Counter} from "../src/Counter.sol";

contract CounterTest is Test {
    Counter public counter;
    address public owner;
    address public alice = makeAddr("alice");

    function setUp() public {
        owner = address(this);
        counter = new Counter(0);
    }

    function test_initialState() public view {
        assertEq(counter.count(), 0);
        assertEq(counter.owner(), owner);
    }

    function test_increment() public {
        counter.increment();
        assertEq(counter.count(), 1);

        counter.increment();
        assertEq(counter.count(), 2);
    }

    function test_decrement() public {
        counter.increment();
        counter.increment();
        counter.decrement();
        assertEq(counter.count(), 1);
    }

    function testFuzz_increment(uint256 times) public {
        times = bound(times, 1, 100);
        for (uint256 i = 0; i < times; i++) {
            counter.increment();
        }
        assertEq(counter.count(), times);
    }

    function test_reset() public {
        counter.increment();
        counter.increment();
        counter.reset();
        assertEq(counter.count(), 0);
    }

    function test_revert_resetNonOwner() public {
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(Counter.NotOwner.selector, alice, owner));
        counter.reset();
    }

    function test_emit_incrementEvent() public {
        vm.expectEmit(true, true, false, true);
        emit Counter.Incremented(1, address(this));
        counter.increment();
    }
}
