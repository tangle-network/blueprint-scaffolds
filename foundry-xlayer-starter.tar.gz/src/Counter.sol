// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

contract Counter {
    uint256 public count;
    address public owner;

    event CountIncremented(uint256 newCount, address indexed caller);
    event CountDecremented(uint256 newCount, address indexed caller);
    event CountReset(uint256 oldCount, address indexed caller);

    error NotOwner(address caller, address owner);

    modifier onlyOwner() {
        if (msg.sender != owner) revert NotOwner(msg.sender, owner);
        _;
    }

    constructor(uint256 initialCount) {
        count = initialCount;
        owner = msg.sender;
    }

    function increment() external {
        count += 1;
        emit CountIncremented(count, msg.sender);
    }

    function decrement() external {
        require(count > 0, "Counter: cannot decrement below zero");
        count -= 1;
        emit CountDecremented(count, msg.sender);
    }

    function reset(uint256 newCount) external onlyOwner {
        uint256 oldCount = count;
        count = newCount;
        emit CountReset(oldCount, msg.sender);
    }

    function getCount() external view returns (uint256) {
        return count;
    }
}
