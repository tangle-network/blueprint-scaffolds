// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

contract Counter {
    uint256 public count;
    address public owner;

    event Incremented(uint256 newCount, address indexed caller);
    event Decremented(uint256 newCount, address indexed caller);
    event Reset(address indexed caller);

    error NotOwner(address caller, address owner);

    modifier onlyOwner() {
        if (msg.sender != owner) revert NotOwner(msg.sender, owner);
        _;
    }

    constructor(uint256 initialCount) {
        count = initialCount;
        owner = msg.sender;
    }

    function increment() external {
        count += 1;
        emit Incremented(count, msg.sender);
    }

    function decrement() external {
        count -= 1;
        emit Decremented(count, msg.sender);
    }

    function reset() external onlyOwner {
        count = 0;
        emit Reset(msg.sender);
    }
}
