# AGENTS.md

## Goal

Deploy smart contracts to X Layer using Foundry. Basic ERC-20 token, deploy scripts, network configuration.

## Stack

- Family: `forge-contracts`
- Layers: 
- Partner: `xlayer`

## Architecture

- Foundry project
- Solidity contracts in src/
- Tests in test/
- Deploy scripts in script/

## Entry Points

- `src/StarterCounter.sol`
- `test/StarterCounter.t.sol`
- `script/Deploy.s.sol`

## Commands

- `forge build`
- `forge test`

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
