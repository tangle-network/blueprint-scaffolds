module move-nft-marketplace::TreasuryVaultTests {
    use move-nft-marketplace::TreasuryVault;

    #[test(account = @move-nft-marketplace)]
    fun initializes_balance(account: signer) {
        TreasuryVault::initialize(&account);
        assert!(TreasuryVault::balance(@move-nft-marketplace) == 0, 0);
    }
}
