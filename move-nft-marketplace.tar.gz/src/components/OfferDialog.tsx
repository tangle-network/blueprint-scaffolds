import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import type { NFTToken } from "@/lib/types";
import { formatApt } from "@/lib/utils";

interface OfferDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  token: NFTToken;
}

export default function OfferDialog({ open, onOpenChange, token }: OfferDialogProps) {
  const [amount, setAmount] = useState("");

  const octas = Math.round(Number(amount) * 100_000_000);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Make an Offer</DialogTitle>
          <DialogDescription>
            Submit an offer for {token.name}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="flex items-center gap-3 p-3 rounded-lg bg-muted">
            <img
              src={token.uri}
              alt={token.name}
              className="w-12 h-12 rounded object-cover"
            />
            <div>
              <p className="font-medium">{token.name}</p>
              <p className="text-sm text-muted-foreground">{token.collection}</p>
            </div>
          </div>

          <div>
            <label className="text-sm font-medium mb-1.5 block">Offer Amount (APT)</label>
            <Input
              type="number"
              min="0"
              step="0.01"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </div>

          {Number(amount) > 0 && (
            <div className="p-3 rounded-lg border">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Offer amount</span>
                <span className="font-medium">{formatApt(octas)}</span>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                If accepted, royalties ({token.royaltyPercentage / 100}%) will be deducted from the seller's proceeds.
              </p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            disabled={!amount || Number(amount) <= 0}
            onClick={() => onOpenChange(false)}
          >
            Submit Offer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
