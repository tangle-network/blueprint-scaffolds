import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { NFTToken } from "@/lib/types";

interface AuctionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  token: NFTToken;
}

export default function AuctionDialog({ open, onOpenChange, token }: AuctionDialogProps) {
  const [type, setType] = useState<"english" | "dutch">("english");
  const [startPrice, setStartPrice] = useState("");
  const [minPrice, setMinPrice] = useState("");
  const [duration, setDuration] = useState("24");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Create Auction</DialogTitle>
          <DialogDescription>
            Auction {token.name} on the marketplace
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="flex items-center gap-3 p-3 rounded-lg bg-muted">
            <img
              src={token.uri}
              alt={token.name}
              className="w-12 h-12 rounded object-cover"
            />
            <div>
              <p className="font-medium">{token.name}</p>
              <p className="text-sm text-muted-foreground">{token.collection}</p>
            </div>
          </div>

          <div className="flex gap-2">
            <Button
              variant={type === "english" ? "default" : "outline"}
              className="flex-1"
              onClick={() => setType("english")}
            >
              English
            </Button>
            <Button
              variant={type === "dutch" ? "default" : "outline"}
              className="flex-1"
              onClick={() => setType("dutch")}
            >
              Dutch
            </Button>
          </div>

          {type === "english" ? (
            <p className="text-sm text-muted-foreground">
              Price starts at the minimum and increases with each bid. Highest bidder wins when the auction ends.
            </p>
          ) : (
            <p className="text-sm text-muted-foreground">
              Price starts high and decreases over time until someone buys or the minimum price is reached.
            </p>
          )}

          <div>
            <label className="text-sm font-medium mb-1.5 block">
              {type === "english" ? "Starting Price (APT)" : "Starting Price (APT)"}
            </label>
            <Input
              type="number"
              min="0"
              step="0.01"
              placeholder="0.00"
              value={startPrice}
              onChange={(e) => setStartPrice(e.target.value)}
            />
          </div>

          {type === "dutch" && (
            <div>
              <label className="text-sm font-medium mb-1.5 block">Minimum Price (APT)</label>
              <Input
                type="number"
                min="0"
                step="0.01"
                placeholder="0.00"
                value={minPrice}
                onChange={(e) => setMinPrice(e.target.value)}
              />
            </div>
          )}

          <div>
            <label className="text-sm font-medium mb-1.5 block">Duration (hours)</label>
            <Input
              type="number"
              min="1"
              max="168"
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            disabled={!startPrice || Number(startPrice) <= 0}
            onClick={() => onOpenChange(false)}
          >
            Create {type === "english" ? "English" : "Dutch"} Auction
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
