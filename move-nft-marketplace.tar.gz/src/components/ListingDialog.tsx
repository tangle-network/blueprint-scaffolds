import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { NFTToken } from "@/lib/types";
import { formatApt } from "@/lib/utils";

interface ListingDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  token: NFTToken;
}

export default function ListingDialog({ open, onOpenChange, token }: ListingDialogProps) {
  const [price, setPrice] = useState("");

  const octas = Math.round(Number(price) * 100_000_000);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Create Fixed-Price Listing</DialogTitle>
          <DialogDescription>
            List {token.name} for sale at a fixed price
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="flex items-center gap-3 p-3 rounded-lg bg-muted">
            <img
              src={token.uri}
              alt={token.name}
              className="w-12 h-12 rounded object-cover"
            />
            <div>
              <p className="font-medium">{token.name}</p>
              <p className="text-sm text-muted-foreground">{token.collection}</p>
            </div>
          </div>

          <div>
            <label className="text-sm font-medium mb-1.5 block">Price (APT)</label>
            <Input
              type="number"
              min="0"
              step="0.01"
              placeholder="0.00"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
            />
          </div>

          {Number(price) > 0 && (
            <div className="space-y-2 p-3 rounded-lg border">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Royalty ({token.royaltyPercentage / 100}%)</span>
                <span>{formatApt(Math.round(octas * token.royaltyPercentage / 10000))}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">You receive</span>
                <span className="font-medium">
                  {formatApt(octas - Math.round(octas * token.royaltyPercentage / 10000))}
                </span>
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button disabled={!price || Number(price) <= 0} onClick={() => onOpenChange(false)}>
            Create Listing
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
