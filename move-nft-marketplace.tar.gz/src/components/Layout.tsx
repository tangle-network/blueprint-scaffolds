import { useState } from "react";
import { Link, useLocation, Outlet } from "react-router-dom";
import { useWallet } from "@/hooks/useWallet";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Wallet, Home, Grid3X3, User, Plus, Store, Gavel } from "lucide-react";

function WalletConnectDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { connect } = useWallet();

  const wallets = [
    { name: "Petra", icon: "🦹" },
    { name: "Martian", icon: "👽" },
    { name: "Pontem", icon: "🔗" },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Connect Wallet</DialogTitle>
          <DialogDescription>Choose a wallet to connect to the marketplace</DialogDescription>
        </DialogHeader>
        <div className="space-y-3 pt-2">
          {wallets.map((w) => (
            <Button
              key={w.name}
              variant="outline"
              className="w-full justify-start gap-3 h-14 text-base"
              onClick={async () => {
                await connect();
                onOpenChange(false);
              }}
            >
              <span className="text-2xl">{w.icon}</span>
              {w.name} Wallet
            </Button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function Layout() {
  const { connected, shortAddress, connecting, disconnect } = useWallet();
  const [walletDialogOpen, setWalletDialogOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { to: "/", label: "Home", icon: Home },
    { to: "/collections", label: "Collections", icon: Grid3X3 },
    { to: "/listings", label: "Listings", icon: Store },
    { to: "/auctions", label: "Auctions", icon: Gavel },
    { to: "/create", label: "Create", icon: Plus },
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-8">
            <Link to="/" className="flex items-center gap-2 text-xl font-bold">
              <Wallet className="h-6 w-6 text-primary" />
              <span>AptosNFT</span>
            </Link>
            <nav className="hidden md:flex items-center gap-1">
              {navLinks.map((link) => {
                const Icon = link.icon;
                const isActive = location.pathname === link.to;
                return (
                  <Link
                    key={link.to}
                    to={link.to}
                    className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      isActive
                        ? "bg-primary/10 text-primary"
                        : "text-muted-foreground hover:text-foreground hover:bg-accent"
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    {link.label}
                  </Link>
                );
              })}
            </nav>
          </div>
          <div className="flex items-center gap-3">
            {connected ? (
              <>
                <Link to="/profile">
                  <Badge variant="secondary" className="gap-1 px-3 py-1 text-sm cursor-pointer">
                    <User className="h-3 w-3" />
                    {shortAddress}
                  </Badge>
                </Link>
                <Button variant="ghost" size="sm" onClick={disconnect}>
                  Disconnect
                </Button>
              </>
            ) : (
              <Button
                onClick={() => setWalletDialogOpen(true)}
                disabled={connecting}
                className="gap-2"
              >
                <Wallet className="h-4 w-4" />
                {connecting ? "Connecting..." : "Connect Wallet"}
              </Button>
            )}
          </div>
        </div>
      </header>

      <nav className="md:hidden border-b">
        <div className="container mx-auto flex items-center gap-1 px-4 py-2 overflow-x-auto">
          {navLinks.map((link) => {
            const Icon = link.icon;
            const isActive = location.pathname === link.to;
            return (
              <Link
                key={link.to}
                to={link.to}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap transition-colors ${
                  isActive
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <Icon className="h-3 w-3" />
                {link.label}
              </Link>
            );
          })}
        </div>
      </nav>

      <main className="container mx-auto px-4 py-8">
        <Outlet />
      </main>

      <footer className="border-t mt-16">
        <div className="container mx-auto px-4 py-6 text-center text-sm text-muted-foreground">
          Aptos NFT Marketplace &mdash; Built with Move + React
        </div>
      </footer>

      <WalletConnectDialog open={walletDialogOpen} onOpenChange={setWalletDialogOpen} />
    </div>
  );
}
