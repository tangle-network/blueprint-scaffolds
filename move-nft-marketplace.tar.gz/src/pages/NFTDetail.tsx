import { useParams, Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useTokens, useListings, useAuctions, useOffers } from "@/hooks/useMarketplace";
import { useWallet } from "@/hooks/useWallet";
import ListingDialog from "@/components/ListingDialog";
import AuctionDialog from "@/components/AuctionDialog";
import OfferDialog from "@/components/OfferDialog";
import { formatApt, shortenAddress, formatCountdown } from "@/lib/utils";
import { ArrowLeft } from "lucide-react";
import { useState } from "react";

export default function NFTDetail() {
  const { id } = useParams<{ id: string }>();
  const { getToken } = useTokens();
  const { listings } = useListings();
  const { auctions } = useAuctions();
  const { offers } = useOffers();
  const { connected } = useWallet();
  const [listingOpen, setListingOpen] = useState(false);
  const [auctionOpen, setAuctionOpen] = useState(false);
  const [offerOpen, setOfferOpen] = useState(false);

  const token = getToken(id || "");
  if (!token) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold">Token not found</h2>
        <Link to="/">
          <Button variant="link" className="mt-2">Back to Home</Button>
        </Link>
      </div>
    );
  }

  const listing = listings.find((l) => l.tokenId === token.id && l.active);
  const auction = auctions.find((a) => a.tokenId === token.id && a.active);
  const tokenOffers = offers.filter((o) => o.tokenId === token.id && o.active);

  return (
    <div className="space-y-8">
      <Link to="/collections" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" />
        Back
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="aspect-square rounded-lg overflow-hidden bg-muted">
          <img src={token.uri} alt={token.name} className="w-full h-full object-cover" />
        </div>

        <div className="space-y-6">
          <div>
            <p className="text-sm text-muted-foreground">{token.collection}</p>
            <h1 className="text-3xl font-bold">{token.name}</h1>
            <p className="text-muted-foreground mt-2">{token.description}</p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Card>
              <CardHeader className="pb-1 pt-3 px-4">
                <CardTitle className="text-sm text-muted-foreground">Owner</CardTitle>
              </CardHeader>
              <CardContent className="pb-3 px-4">
                <span className="text-sm font-mono">{shortenAddress(token.owner)}</span>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-1 pt-3 px-4">
                <CardTitle className="text-sm text-muted-foreground">Royalty</CardTitle>
              </CardHeader>
              <CardContent className="pb-3 px-4">
                <span className="text-2xl font-bold">{token.royaltyPercentage / 100}%</span>
              </CardContent>
            </Card>
          </div>

          {listing && (
            <Card className="border-primary/50">
              <CardContent className="pt-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Fixed Price</p>
                    <p className="text-3xl font-bold text-primary">{formatApt(listing.price)}</p>
                  </div>
                  <Button size="lg">Buy Now</Button>
                </div>
              </CardContent>
            </Card>
          )}

          {auction && (
            <Card className="border-primary/50">
              <CardContent className="pt-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Badge variant="default" className="mb-2">
                      {auction.isEnglish ? "English Auction" : "Dutch Auction"}
                    </Badge>
                    <p className="text-3xl font-bold text-primary">
                      {formatApt(auction.currentPrice)}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Ends in: {formatCountdown(auction.endTime)}
                    </p>
                    {auction.highestBidder !== "0x0" && (
                      <p className="text-sm text-muted-foreground">
                        Highest bidder: {shortenAddress(auction.highestBidder)}
                      </p>
                    )}
                  </div>
                  <Button size="lg">Place Bid</Button>
                </div>
              </CardContent>
            </Card>
          )}

          {connected && !listing && !auction && (
            <div className="flex gap-3">
              <Button className="flex-1" onClick={() => setListingOpen(true)}>
                List for Sale
              </Button>
              <Button className="flex-1" variant="outline" onClick={() => setAuctionOpen(true)}>
                Create Auction
              </Button>
            </div>
          )}

          {connected && (
            <Button variant="secondary" className="w-full" onClick={() => setOfferOpen(true)}>
              Make an Offer
            </Button>
          )}

          <Tabs defaultValue="offers">
            <TabsList className="w-full">
              <TabsTrigger value="offers" className="flex-1">
                Offers ({tokenOffers.length})
              </TabsTrigger>
              <TabsTrigger value="details" className="flex-1">
                Details
              </TabsTrigger>
            </TabsList>
            <TabsContent value="offers" className="space-y-2 mt-4">
              {tokenOffers.length === 0 ? (
                <p className="text-center text-muted-foreground py-4">No offers yet</p>
              ) : (
                tokenOffers.map((offer) => (
                  <Card key={offer.id}>
                    <CardContent className="flex items-center justify-between py-3">
                      <div>
                        <p className="font-medium">{formatApt(offer.amount)}</p>
                        <p className="text-sm text-muted-foreground">
                          From: {shortenAddress(offer.offerer)}
                        </p>
                      </div>
                      <Button size="sm">Accept</Button>
                    </CardContent>
                  </Card>
                ))
              )}
            </TabsContent>
            <TabsContent value="details" className="mt-4">
              <Card>
                <CardContent className="pt-4 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Token ID</span>
                    <span className="font-mono text-sm">{token.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Collection</span>
                    <span>{token.collection}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Royalty</span>
                    <span>{token.royaltyPercentage / 100}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Owner</span>
                    <span className="font-mono text-sm">{shortenAddress(token.owner)}</span>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      <ListingDialog open={listingOpen} onOpenChange={setListingOpen} token={token} />
      <AuctionDialog open={auctionOpen} onOpenChange={setAuctionOpen} token={token} />
      <OfferDialog open={offerOpen} onOpenChange={setOfferOpen} token={token} />
    </div>
  );
}
