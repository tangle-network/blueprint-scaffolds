import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useWallet } from "@/hooks/useWallet";
import { Upload, Package } from "lucide-react";

export default function Create() {
  const { connected } = useWallet();
  const [colName, setColName] = useState("");
  const [colDesc, setColDesc] = useState("");
  const [colRoyalty, setColRoyalty] = useState("5");
  const [mintCount, setMintCount] = useState("1");
  const [mintBaseName, setMintBaseName] = useState("");

  if (!connected) {
    return (
      <div className="text-center py-16 space-y-4">
        <h2 className="text-2xl font-bold">Connect Your Wallet</h2>
        <p className="text-muted-foreground">Connect your wallet to create collections and mint NFTs</p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Create & Mint</h1>
        <p className="text-muted-foreground mt-1">
          Create collections and batch mint NFTs on Aptos
        </p>
      </div>

      <Tabs defaultValue="collection">
        <TabsList className="w-full">
          <TabsTrigger value="collection" className="flex-1">
            Create Collection
          </TabsTrigger>
          <TabsTrigger value="mint" className="flex-1">
            Batch Mint
          </TabsTrigger>
        </TabsList>

        <TabsContent value="collection" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="h-5 w-5 text-primary" />
                New Collection
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-1.5 block">Collection Name</label>
                <Input
                  placeholder="My NFT Collection"
                  value={colName}
                  onChange={(e) => setColName(e.target.value)}
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-1.5 block">Description</label>
                <Input
                  placeholder="A unique collection of..."
                  value={colDesc}
                  onChange={(e) => setColDesc(e.target.value)}
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-1.5 block">Royalty Percentage</label>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    min="0"
                    max="50"
                    step="0.5"
                    value={colRoyalty}
                    onChange={(e) => setColRoyalty(e.target.value)}
                    className="w-32"
                  />
                  <Badge variant="outline">{colRoyalty}% = {Number(colRoyalty) * 100} basis points</Badge>
                </div>
              </div>
              <Button className="w-full" disabled={!colName}>
                <Upload className="h-4 w-4 mr-2" />
                Create Collection
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="mint" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5 text-primary" />
                Batch Mint NFTs
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-1.5 block">Collection Name</label>
                <Input
                  placeholder="Select an existing collection"
                  value={colName}
                  onChange={(e) => setColName(e.target.value)}
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-1.5 block">Base Token Name</label>
                <Input
                  placeholder="Token name (will append #1, #2, etc.)"
                  value={mintBaseName}
                  onChange={(e) => setMintBaseName(e.target.value)}
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-1.5 block">Description</label>
                <Input
                  placeholder="Token description"
                  value={colDesc}
                  onChange={(e) => setColDesc(e.target.value)}
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-1.5 block">Number of Tokens</label>
                <Input
                  type="number"
                  min="1"
                  max="100"
                  value={mintCount}
                  onChange={(e) => setMintCount(e.target.value)}
                />
                <p className="text-sm text-muted-foreground mt-1">
                  Will mint {mintCount} token(s) with names: {mintBaseName || "Token"} #1 through {mintBaseName || "Token"} #{mintCount}
                </p>
              </div>
              <Button className="w-full" disabled={!colName || !mintBaseName}>
                <Upload className="h-4 w-4 mr-2" />
                Mint {mintCount} NFTs
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
