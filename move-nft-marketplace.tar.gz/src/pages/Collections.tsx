import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useCollections } from "@/hooks/useMarketplace";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";

export default function Collections() {
  const { collections } = useCollections();
  const [search, setSearch] = useState("");

  const filtered = collections.filter((c) =>
    c.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Collections</h1>
        <p className="text-muted-foreground mt-1">
          Browse all NFT collections on the marketplace
        </p>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search collections..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-10"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((col) => (
          <Link key={col.id} to={`/collection/${encodeURIComponent(col.name)}`}>
            <Card className="overflow-hidden hover:border-primary/50 transition-colors cursor-pointer group">
              <div className="aspect-video bg-muted overflow-hidden">
                <img
                  src={col.uri}
                  alt={col.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
              </div>
              <CardContent className="p-4">
                <h3 className="font-semibold text-lg">{col.name}</h3>
                <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                  {col.description}
                </p>
                <div className="flex items-center gap-2 mt-3">
                  <Badge variant="secondary">{col.totalSupply} items</Badge>
                  <Badge variant="outline">{col.royaltyPercentage / 100}% royalty</Badge>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          No collections found matching "{search}"
        </div>
      )}
    </div>
  );
}
