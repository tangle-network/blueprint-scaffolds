import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useListings } from "@/hooks/useMarketplace";
import { useAuctions } from "@/hooks/useMarketplace";
import { useCollections } from "@/hooks/useMarketplace";
import { formatApt, formatCountdown } from "@/lib/utils";
import { ArrowRight, TrendingUp, Gavel, Grid3X3, Store } from "lucide-react";

export default function Home() {
  const { listings } = useListings();
  const { auctions } = useAuctions();
  const { collections } = useCollections();

  return (
    <div className="space-y-12">
      <section className="text-center py-12">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">
          Discover, Collect & Trade
          <span className="text-primary"> NFTs on Aptos</span>
        </h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
          The premier NFT marketplace on Aptos. Buy, sell, and auction digital
          collectibles with full royalty enforcement.
        </p>
        <div className="flex items-center justify-center gap-4">
          <Link to="/collections">
            <Button size="lg" className="gap-2">
              <Grid3X3 className="h-5 w-5" />
              Browse Collections
            </Button>
          </Link>
          <Link to="/listings">
            <Button size="lg" variant="outline" className="gap-2">
              <Store className="h-5 w-5" />
              View Listings
            </Button>
          </Link>
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            <h2 className="text-2xl font-bold">Featured Listings</h2>
          </div>
          <Link to="/listings">
            <Button variant="ghost" className="gap-1">
              View All <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {listings.slice(0, 4).map((listing) => (
            <Link key={listing.id} to={`/nft/${listing.tokenId}`}>
              <Card className="overflow-hidden hover:border-primary/50 transition-colors cursor-pointer group">
                <div className="aspect-square bg-muted overflow-hidden">
                  <img
                    src={listing.token?.uri}
                    alt={listing.token?.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                </div>
                <CardContent className="p-4">
                  <p className="text-sm text-muted-foreground">{listing.token?.collection}</p>
                  <h3 className="font-semibold truncate">{listing.token?.name}</h3>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-lg font-bold text-primary">
                      {formatApt(listing.price)}
                    </span>
                    <Badge variant="secondary">Fixed Price</Badge>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Gavel className="h-5 w-5 text-primary" />
            <h2 className="text-2xl font-bold">Live Auctions</h2>
          </div>
          <Link to="/auctions">
            <Button variant="ghost" className="gap-1">
              View All <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {auctions.map((auction) => (
            <Link key={auction.id} to={`/nft/${auction.tokenId}`}>
              <Card className="overflow-hidden hover:border-primary/50 transition-colors cursor-pointer group">
                <div className="aspect-square bg-muted overflow-hidden">
                  <img
                    src={auction.token?.uri}
                    alt={auction.token?.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                </div>
                <CardContent className="p-4">
                  <p className="text-sm text-muted-foreground">{auction.token?.collection}</p>
                  <h3 className="font-semibold truncate">{auction.token?.name}</h3>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-lg font-bold text-primary">
                      {formatApt(auction.currentPrice)}
                    </span>
                    <Badge variant={auction.isEnglish ? "default" : "secondary"}>
                      {auction.isEnglish ? "English" : "Dutch"}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    Ends in: {formatCountdown(auction.endTime)}
                  </p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Top Collections</h2>
          <Link to="/collections">
            <Button variant="ghost" className="gap-1">
              View All <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {collections.slice(0, 6).map((col) => (
            <Link key={col.id} to={`/collection/${encodeURIComponent(col.name)}`}>
              <Card className="p-4 hover:border-primary/50 transition-colors cursor-pointer">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-lg overflow-hidden bg-muted">
                    <img src={col.uri} alt={col.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold truncate">{col.name}</h3>
                    <p className="text-sm text-muted-foreground">{col.totalSupply} items</p>
                    <Badge variant="outline" className="mt-1">
                      {col.royaltyPercentage / 100}% royalty
                    </Badge>
                  </div>
                </div>
              </Card>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
