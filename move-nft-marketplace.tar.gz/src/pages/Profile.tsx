import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useWallet } from "@/hooks/useWallet";
import { useProfile } from "@/hooks/useMarketplace";
import { shortenAddress, formatApt } from "@/lib/utils";
import { useTokens, useCollections, useListings, useAuctions } from "@/hooks/useMarketplace";
import { Store, Gavel, Grid3X3 } from "lucide-react";

export default function Profile() {
  const { connected, address } = useWallet();
  const { tokens } = useTokens();
  const { collections } = useCollections();
  const { listings } = useListings();
  const { auctions } = useAuctions();

  if (!connected || !address) {
    return (
      <div className="text-center py-16 space-y-4">
        <h2 className="text-2xl font-bold">Connect Your Wallet</h2>
        <p className="text-muted-foreground">Connect your wallet to view your profile</p>
        <Link to="/">
          <Button>Go Home</Button>
        </Link>
      </div>
    );
  }

  const myTokens = tokens.filter((t) => t.owner === address);
  const myCollections = collections.filter((c) => c.creator === address);
  const myListings = listings.filter((l) => l.seller === address);
  const myAuctions = auctions.filter((a) => a.seller === address);

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-4">
        <Avatar className="h-16 w-16">
          <AvatarFallback className="text-xl bg-primary/20 text-primary">
            {address.slice(2, 4).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        <div>
          <h1 className="text-2xl font-bold">My Profile</h1>
          <p className="font-mono text-muted-foreground">{shortenAddress(address)}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-4 text-center">
            <Grid3X3 className="h-6 w-6 mx-auto text-primary mb-1" />
            <p className="text-2xl font-bold">{myCollections.length}</p>
            <p className="text-sm text-muted-foreground">Collections</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 text-center">
            <p className="text-2xl font-bold">{myTokens.length}</p>
            <p className="text-sm text-muted-foreground">NFTs Owned</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 text-center">
            <Store className="h-6 w-6 mx-auto text-primary mb-1" />
            <p className="text-2xl font-bold">{myListings.length}</p>
            <p className="text-sm text-muted-foreground">Active Listings</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 text-center">
            <Gavel className="h-6 w-6 mx-auto text-primary mb-1" />
            <p className="text-2xl font-bold">{myAuctions.length}</p>
            <p className="text-sm text-muted-foreground">Active Auctions</p>
          </CardContent>
        </Card>
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">My NFTs</h2>
        {myTokens.length === 0 ? (
          <p className="text-muted-foreground text-center py-8">No NFTs owned yet</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {myTokens.map((token) => (
              <Link key={token.id} to={`/nft/${token.id}`}>
                <Card className="overflow-hidden hover:border-primary/50 transition-colors cursor-pointer group">
                  <div className="aspect-square bg-muted overflow-hidden">
                    <img src={token.uri} alt={token.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold truncate">{token.name}</h3>
                    <p className="text-sm text-muted-foreground">{token.collection}</p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">My Collections</h2>
        {myCollections.length === 0 ? (
          <p className="text-muted-foreground text-center py-8">No collections created yet</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {myCollections.map((col) => (
              <Link key={col.id} to={`/collection/${encodeURIComponent(col.name)}`}>
                <Card className="p-4 hover:border-primary/50 transition-colors cursor-pointer">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-lg overflow-hidden bg-muted">
                      <img src={col.uri} alt={col.name} className="w-full h-full object-cover" />
                    </div>
                    <div>
                      <h3 className="font-semibold">{col.name}</h3>
                      <Badge variant="outline">{col.totalSupply} items</Badge>
                    </div>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">My Active Listings</h2>
        {myListings.length === 0 ? (
          <p className="text-muted-foreground text-center py-8">No active listings</p>
        ) : (
          <div className="space-y-3">
            {myListings.filter((l) => l.active).map((listing) => (
              <Card key={listing.id}>
                <CardContent className="flex items-center justify-between py-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded bg-muted overflow-hidden">
                      <img src={listing.token?.uri} alt="" className="w-full h-full object-cover" />
                    </div>
                    <div>
                      <p className="font-medium">{listing.token?.name}</p>
                      <p className="text-sm text-muted-foreground">{formatApt(listing.price)}</p>
                    </div>
                  </div>
                  <Badge variant="secondary">Active</Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
