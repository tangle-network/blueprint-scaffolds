import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useListings } from "@/hooks/useMarketplace";
import { formatApt, shortenAddress } from "@/lib/utils";
import { useState } from "react";
import { Search } from "lucide-react";

export default function Listings() {
  const { listings } = useListings();
  const [search, setSearch] = useState("");

  const active = listings.filter(
    (l) =>
      l.active &&
      l.token &&
      (l.token.name.toLowerCase().includes(search.toLowerCase()) ||
        l.token.collection.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Fixed-Price Listings</h1>
        <p className="text-muted-foreground mt-1">Browse NFTs available for immediate purchase</p>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search listings..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-10"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {active.map((listing) => (
          <Link key={listing.id} to={`/nft/${listing.tokenId}`}>
            <Card className="overflow-hidden hover:border-primary/50 transition-colors cursor-pointer group">
              <div className="aspect-square bg-muted overflow-hidden">
                <img
                  src={listing.token?.uri}
                  alt={listing.token?.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
              </div>
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground">{listing.token?.collection}</p>
                <h3 className="font-semibold truncate">{listing.token?.name}</h3>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-lg font-bold text-primary">
                    {formatApt(listing.price)}
                  </span>
                  <Badge variant="secondary">Buy Now</Badge>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Seller: {shortenAddress(listing.seller)}
                </p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {active.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          {search ? `No listings matching "${search}"` : "No active listings"}
        </div>
      )}
    </div>
  );
}
