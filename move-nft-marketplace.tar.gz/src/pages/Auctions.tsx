import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuctions } from "@/hooks/useMarketplace";
import { formatApt, shortenAddress, formatCountdown } from "@/lib/utils";
import { useState } from "react";
import { Search } from "lucide-react";

export default function Auctions() {
  const { auctions } = useAuctions();
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "english" | "dutch">("all");

  const active = auctions.filter(
    (a) =>
      a.active &&
      a.token &&
      (filter === "all" || (filter === "english" ? a.isEnglish : !a.isEnglish)) &&
      (a.token.name.toLowerCase().includes(search.toLowerCase()) ||
        a.token.collection.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Live Auctions</h1>
        <p className="text-muted-foreground mt-1">Bid on English and Dutch auctions</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search auctions..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>
        <div className="flex gap-2">
          <Button
            variant={filter === "all" ? "default" : "outline"}
            size="sm"
            onClick={() => setFilter("all")}
          >
            All
          </Button>
          <Button
            variant={filter === "english" ? "default" : "outline"}
            size="sm"
            onClick={() => setFilter("english")}
          >
            English
          </Button>
          <Button
            variant={filter === "dutch" ? "default" : "outline"}
            size="sm"
            onClick={() => setFilter("dutch")}
          >
            Dutch
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {active.map((auction) => (
          <Link key={auction.id} to={`/nft/${auction.tokenId}`}>
            <Card className="overflow-hidden hover:border-primary/50 transition-colors cursor-pointer group">
              <div className="aspect-square bg-muted overflow-hidden relative">
                <img
                  src={auction.token?.uri}
                  alt={auction.token?.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <Badge
                  className="absolute top-3 right-3"
                  variant={auction.isEnglish ? "default" : "secondary"}
                >
                  {auction.isEnglish ? "English" : "Dutch"}
                </Badge>
              </div>
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground">{auction.token?.collection}</p>
                <h3 className="font-semibold truncate">{auction.token?.name}</h3>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-lg font-bold text-primary">
                    {formatApt(auction.currentPrice)}
                  </span>
                  <span className="text-sm text-muted-foreground">
                    {auction.isEnglish ? "Current Bid" : "Current Price"}
                  </span>
                </div>
                {auction.highestBidder !== "0x0" && (
                  <p className="text-xs text-muted-foreground mt-1">
                    Highest: {shortenAddress(auction.highestBidder)}
                  </p>
                )}
                <div className="mt-2 pt-2 border-t">
                  <p className="text-sm font-medium">
                    Ends: {formatCountdown(auction.endTime)}
                  </p>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {active.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          {search || filter !== "all" ? "No matching auctions" : "No active auctions"}
        </div>
      )}
    </div>
  );
}
