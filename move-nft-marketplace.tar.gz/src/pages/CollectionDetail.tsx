import { useParams, Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useCollections, useTokens } from "@/hooks/useMarketplace";
import { ArrowLeft } from "lucide-react";

export default function CollectionDetail() {
  const { name } = useParams<{ name: string }>();
  const { getCollection } = useCollections();
  const { tokens } = useTokens();
  const collection = getCollection(name || "");

  if (!collection) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold">Collection not found</h2>
        <Link to="/collections">
          <Button variant="link" className="mt-2">
            Back to Collections
          </Button>
        </Link>
      </div>
    );
  }

  const colTokens = tokens.filter((t) => t.collection === collection.name);

  return (
    <div className="space-y-8">
      <Link to="/collections" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" />
        Back to Collections
      </Link>

      <div className="flex flex-col md:flex-row gap-8">
        <div className="w-full md:w-80 aspect-square rounded-lg overflow-hidden bg-muted">
          <img src={collection.uri} alt={collection.name} className="w-full h-full object-cover" />
        </div>
        <div className="flex-1">
          <h1 className="text-3xl font-bold">{collection.name}</h1>
          <p className="text-muted-foreground mt-2">{collection.description}</p>
          <div className="flex flex-wrap gap-3 mt-4">
            <Card>
              <CardHeader className="pb-1 pt-3 px-4">
                <CardTitle className="text-sm text-muted-foreground">Items</CardTitle>
              </CardHeader>
              <CardContent className="pb-3 px-4">
                <span className="text-2xl font-bold">{collection.totalSupply}</span>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-1 pt-3 px-4">
                <CardTitle className="text-sm text-muted-foreground">Royalty</CardTitle>
              </CardHeader>
              <CardContent className="pb-3 px-4">
                <span className="text-2xl font-bold">{collection.royaltyPercentage / 100}%</span>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-1 pt-3 px-4">
                <CardTitle className="text-sm text-muted-foreground">Creator</CardTitle>
              </CardHeader>
              <CardContent className="pb-3 px-4">
                <span className="text-sm font-mono">{collection.creator.slice(0, 10)}...{collection.creator.slice(-6)}</span>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <div>
        <h2 className="text-2xl font-bold mb-4">Tokens in Collection</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {colTokens.map((token) => (
            <Link key={token.id} to={`/nft/${token.id}`}>
              <Card className="overflow-hidden hover:border-primary/50 transition-colors cursor-pointer group">
                <div className="aspect-square bg-muted overflow-hidden">
                  <img
                    src={token.uri}
                    alt={token.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                </div>
                <CardContent className="p-4">
                  <h3 className="font-semibold truncate">{token.name}</h3>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-sm text-muted-foreground">
                      Owner: {token.owner.slice(0, 6)}...
                    </span>
                    <Badge variant="outline">{token.royaltyPercentage / 100}%</Badge>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
        {colTokens.length === 0 && (
          <p className="text-center text-muted-foreground py-8">No tokens in this collection yet</p>
        )}
      </div>
    </div>
  );
}
