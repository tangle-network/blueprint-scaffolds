import React from "react";
import ReactDOM from "react-dom/client";
import { ConfigProvider, App as AntdApp } from "antd";
import { AptosWalletAdapterProvider } from "@aptos-labs/wallet-adapter-react";
import "@aptos-labs/wallet-adapter-ant-design/dist/index.css";
import "antd/dist/reset.css";
import { Network } from "@aptos-labs/ts-sdk";
import App from "./App";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <ConfigProvider
      theme={{
        token: {
          colorPrimary: "#1d4ed8",
          borderRadius: 16,
          colorBgBase: "#f5f1e8",
          colorTextBase: "#132238",
          fontFamily: '"Space Grotesk", "Segoe UI", sans-serif',
        },
      }}
    >
      <AntdApp>
        <AptosWalletAdapterProvider
          autoConnect
          dappConfig={{ network: Network.TESTNET }}
          onError={(error) => {
            console.error("Wallet adapter error", error);
          }}
        >
          <App />
        </AptosWalletAdapterProvider>
      </AntdApp>
    </ConfigProvider>
  </React.StrictMode>,
);
