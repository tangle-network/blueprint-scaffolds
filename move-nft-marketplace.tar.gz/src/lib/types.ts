export interface NFTToken {
  id: string;
  name: string;
  collection: string;
  description: string;
  uri: string;
  owner: string;
  royaltyPercentage: number;
}

export interface Collection {
  id: string;
  name: string;
  creator: string;
  description: string;
  uri: string;
  totalSupply: number;
  royaltyPercentage: number;
}

export interface Listing {
  id: string;
  tokenId: string;
  seller: string;
  price: number;
  active: boolean;
  token?: NFTToken;
}

export interface Auction {
  id: string;
  tokenId: string;
  seller: string;
  startPrice: number;
  currentPrice: number;
  minPrice: number;
  highestBidder: string;
  startTime: number;
  endTime: number;
  isEnglish: boolean;
  active: boolean;
  token?: NFTToken;
}

export interface Offer {
  id: string;
  tokenId: string;
  offerer: string;
  amount: number;
  active: boolean;
}

export interface UserProfile {
  address: string;
  collections: Collection[];
  tokens: NFTToken[];
  listings: Listing[];
  auctions: Auction[];
}

export type AuctionType = "english" | "dutch";
