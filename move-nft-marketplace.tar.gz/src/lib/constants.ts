export const MODULE_ADDRESS = "0x1";
export const MARKETPLACE_MODULE = `${MODULE_ADDRESS}::listing`;
export const AUCTION_MODULE = `${MODULE_ADDRESS}::auction`;
export const OFFER_MODULE = `${MODULE_ADDRESS}::offer`;
export const ROYALTY_MODULE = `${MODULE_ADDRESS}::royalty`;
export const BATCH_MINT_MODULE = `${MODULE_ADDRESS}::batch_mint`;
export const FEE_MODULE = `${MODULE_ADDRESS}::fee`;

export const APTOS_NETWORK = "testnet" as const;

export const MARKETPLACE_FEE_PERCENTAGE = 250;
export const DEFAULT_ROYALTY_PERCENTAGE = 500;
export const AUCTION_MIN_DURATION_HOURS = 1;
export const AUCTION_MAX_DURATION_HOURS = 168;

export const PLACEHOLDER_NFT_IMAGES = [
  "https://placehold.co/400x400/1e40af/ffffff?text=NFT+1",
  "https://placehold.co/400x400/7c3aed/ffffff?text=NFT+2",
  "https://placehold.co/400x400/059669/ffffff?text=NFT+3",
  "https://placehold.co/400x400/dc2626/ffffff?text=NFT+4",
  "https://placehold.co/400x400/ea580c/ffffff?text=NFT+5",
  "https://placehold.co/400x400/0891b2/ffffff?text=NFT+6",
];
