import { Aptos, AptosConfig, Network } from "@aptos-labs/ts-sdk";
import type { InputTransactionData } from "@aptos-labs/wallet-adapter-react";

const MODULE_ADDRESS =
  "0xc0de";

export const aptosClient = new Aptos(
  new AptosConfig({
    network: Network.TESTNET,
  }),
);

export const marketplaceModules = {
  listing: `${MODULE_ADDRESS}::listing`,
  auction: `${MODULE_ADDRESS}::auction`,
  royalty: `${MODULE_ADDRESS}::royalty_enforcement`,
  fees: `${MODULE_ADDRESS}::fee_distribution`,
} as const;

const baseEntry = (
  fn: `${string}::${string}::${string}`,
  functionArguments: Array<string | number | boolean>,
): InputTransactionData => ({
  data: {
    function: fn,
    typeArguments: [],
    functionArguments,
  },
});

export const txBuilders = {
  batchMint: (
    collectionName: string,
    baseUri: string,
    quantity: number,
    royaltyBps: number,
  ) =>
    baseEntry(`${marketplaceModules.royalty}::batch_mint_collection`, [
      collectionName,
      baseUri,
      quantity,
      royaltyBps,
    ]),
  createFixedListing: (tokenId: string, priceApt: number) =>
    baseEntry(`${marketplaceModules.listing}::create_fixed_price_listing`, [
      tokenId,
      priceApt,
    ]),
  createEnglishAuction: (
    tokenId: string,
    reserveApt: number,
    minIncrementApt: number,
    durationHours: number,
  ) =>
    baseEntry(`${marketplaceModules.auction}::create_english_auction`, [
      tokenId,
      reserveApt,
      minIncrementApt,
      durationHours,
    ]),
  createDutchAuction: (
    tokenId: string,
    startPriceApt: number,
    endPriceApt: number,
    durationHours: number,
  ) =>
    baseEntry(`${marketplaceModules.auction}::create_dutch_auction`, [
      tokenId,
      startPriceApt,
      endPriceApt,
      durationHours,
    ]),
  placeOffer: (tokenId: string, offerAmountApt: number, expiryHours: number) =>
    baseEntry(`${marketplaceModules.listing}::place_offer`, [
      tokenId,
      offerAmountApt,
      expiryHours,
    ]),
  acceptOffer: (offerId: string) =>
    baseEntry(`${marketplaceModules.listing}::accept_offer`, [offerId]),
  settleAuction: (tokenId: string) =>
    baseEntry(`${marketplaceModules.auction}::settle_auction`, [tokenId]),
  releaseEscrow: (tokenId: string) =>
    baseEntry(`${marketplaceModules.fees}::release_escrow`, [tokenId]),
};

export const shortenAddress = (value?: string | null) => {
  if (!value) {
    return "Wallet disconnected";
  }

  return `${value.slice(0, 6)}...${value.slice(-4)}`;
};
