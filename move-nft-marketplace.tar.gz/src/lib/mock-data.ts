import type { NFTToken, Collection, Listing, Auction, Offer, UserProfile } from "./types";
import { PLACEHOLDER_NFT_IMAGES } from "./constants";

const MOCK_CREATORS = [
  "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
  "0xabcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890",
  "0x9876543210fedcba9876543210fedcba9876543210fedcba9876543210fedcba",
];

export const mockCollections: Collection[] = [
  {
    id: "col-1",
    name: "Aptos Apes",
    creator: MOCK_CREATORS[0],
    description: "A collection of unique digital apes on the Aptos blockchain",
    uri: PLACEHOLDER_NFT_IMAGES[0],
    totalSupply: 100,
    royaltyPercentage: 500,
  },
  {
    id: "col-2",
    name: "Move Monkeys",
    creator: MOCK_CREATORS[1],
    description: "Playful monkeys crafted with Move",
    uri: PLACEHOLDER_NFT_IMAGES[1],
    totalSupply: 50,
    royaltyPercentage: 750,
  },
  {
    id: "col-3",
    name: "Aptos Punks",
    creator: MOCK_CREATORS[2],
    description: "Pixel-art punks for the Aptos ecosystem",
    uri: PLACEHOLDER_NFT_IMAGES[2],
    totalSupply: 200,
    royaltyPercentage: 250,
  },
  {
    id: "col-4",
    name: "Digital Dreams",
    creator: MOCK_CREATORS[0],
    description: "Abstract digital art exploring surreal landscapes",
    uri: PLACEHOLDER_NFT_IMAGES[3],
    totalSupply: 75,
    royaltyPercentage: 1000,
  },
  {
    id: "col-5",
    name: "Cosmic Cats",
    creator: MOCK_CREATORS[1],
    description: "Feline friends from across the cosmos",
    uri: PLACEHOLDER_NFT_IMAGES[4],
    totalSupply: 150,
    royaltyPercentage: 500,
  },
  {
    id: "col-6",
    name: "Aptos Explorers",
    creator: MOCK_CREATORS[2],
    description: "Space explorers charting new worlds on Aptos",
    uri: PLACEHOLDER_NFT_IMAGES[5],
    totalSupply: 60,
    royaltyPercentage: 300,
  },
];

export const mockTokens: NFTToken[] = mockCollections.flatMap((col, ci) =>
  Array.from({ length: 4 }, (_, i) => ({
    id: `token-${ci}-${i}`,
    name: `${col.name} #${i + 1}`,
    collection: col.name,
    description: `${col.name} token #${i + 1}`,
    uri: PLACEHOLDER_NFT_IMAGES[(ci + i) % PLACEHOLDER_NFT_IMAGES.length],
    owner: MOCK_CREATORS[(ci + i) % MOCK_CREATORS.length],
    royaltyPercentage: col.royaltyPercentage,
  }))
);

export const mockListings: Listing[] = [
  {
    id: "listing-1",
    tokenId: "token-0-0",
    seller: MOCK_CREATORS[0],
    price: 250000000,
    active: true,
    token: mockTokens[0],
  },
  {
    id: "listing-2",
    tokenId: "token-1-1",
    seller: MOCK_CREATORS[1],
    price: 500000000,
    active: true,
    token: mockTokens[5],
  },
  {
    id: "listing-3",
    tokenId: "token-2-2",
    seller: MOCK_CREATORS[2],
    price: 1200000000,
    active: true,
    token: mockTokens[10],
  },
  {
    id: "listing-4",
    tokenId: "token-3-0",
    seller: MOCK_CREATORS[0],
    price: 800000000,
    active: true,
    token: mockTokens[12],
  },
];

const now = Math.floor(Date.now() / 1000);

export const mockAuctions: Auction[] = [
  {
    id: "auction-1",
    tokenId: "token-0-1",
    seller: MOCK_CREATORS[0],
    startPrice: 100000000,
    currentPrice: 350000000,
    minPrice: 0,
    highestBidder: MOCK_CREATORS[1],
    startTime: now - 3600,
    endTime: now + 7200,
    isEnglish: true,
    active: true,
    token: mockTokens[1],
  },
  {
    id: "auction-2",
    tokenId: "token-1-0",
    seller: MOCK_CREATORS[1],
    startPrice: 1000000000,
    currentPrice: 400000000,
    minPrice: 100000000,
    startTime: now - 7200,
    endTime: now + 3600,
    isEnglish: false,
    active: true,
    highestBidder: "0x0",
    token: mockTokens[4],
  },
  {
    id: "auction-3",
    tokenId: "token-4-2",
    seller: MOCK_CREATORS[2],
    startPrice: 200000000,
    currentPrice: 750000000,
    minPrice: 0,
    highestBidder: MOCK_CREATORS[0],
    startTime: now - 1800,
    endTime: now + 5400,
    isEnglish: true,
    active: true,
    token: mockTokens[18],
  },
];

export const mockOffers: Offer[] = [
  {
    id: "offer-1",
    tokenId: "token-0-0",
    offerer: MOCK_CREATORS[1],
    amount: 200000000,
    active: true,
  },
  {
    id: "offer-2",
    tokenId: "token-2-1",
    offerer: MOCK_CREATORS[0],
    amount: 600000000,
    active: true,
  },
  {
    id: "offer-3",
    tokenId: "token-5-0",
    offerer: MOCK_CREATORS[2],
    amount: 150000000,
    active: true,
  },
];

export function getMockProfile(address: string): UserProfile {
  const tokens = mockTokens.filter(
    (t) => t.owner === address
  );
  const collections = mockCollections.filter(
    (c) => c.creator === address
  );
  const listings = mockListings.filter(
    (l) => l.seller === address
  );
  const auctions = mockAuctions.filter(
    (a) => a.seller === address
  );
  return { address, collections, tokens, listings, auctions };
}
