import type {
  AuctionSummary,
  CollectionSummary,
  MarketplaceStats,
  NftItem,
  Offer,
  ProfileSummary,
} from "../types";

export const collections: CollectionSummary[] = [
  {
    id: "chrono",
    name: "Chrono Drifters",
    creator: "0x8f3...71c",
    floorApt: 28,
    items: 128,
    volumeApt: 4832,
    royaltyBps: 750,
    featuredImage:
      "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=900&q=80",
    description:
      "Retro-futurist pilots with programmable royalties and escrow-backed trades.",
  },
  {
    id: "reef",
    name: "Aptos Reef",
    creator: "0xc4e...8aa",
    floorApt: 16,
    items: 300,
    volumeApt: 2910,
    royaltyBps: 500,
    featuredImage:
      "https://images.unsplash.com/photo-1516117172878-fd2c41f4a759?auto=format&fit=crop&w=900&q=80",
    description: "Oceanic generative art with batch mint drops and profile quests.",
  },
  {
    id: "monolith",
    name: "Monolith Circuit",
    creator: "0xa11...09d",
    floorApt: 42,
    items: 64,
    volumeApt: 7104,
    royaltyBps: 900,
    featuredImage:
      "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=900&q=80",
    description: "Rare machine relics trading through sealed offers and Dutch auctions.",
  },
];

export const featuredItems: NftItem[] = [
  {
    id: "drifter-011",
    name: "Drifter #011",
    artist: "Tala Vector",
    collection: "Chrono Drifters",
    collectionId: "chrono",
    image:
      "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=900&q=80",
    priceApt: 32,
    royaltyBps: 750,
    traits: [
      { label: "Hull", value: "Bronze" },
      { label: "Boost", value: "Pulse" },
      { label: "Crew", value: "Solo" },
    ],
    saleMode: "fixed",
    escrowed: true,
  },
  {
    id: "reef-188",
    name: "Reef #188",
    artist: "Nyra Bloom",
    collection: "Aptos Reef",
    collectionId: "reef",
    image:
      "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=900&q=80",
    priceApt: 19,
    royaltyBps: 500,
    traits: [
      { label: "Coral", value: "Opal" },
      { label: "Depth", value: "Abyss" },
      { label: "Glow", value: "Mint" },
    ],
    saleMode: "english",
    escrowed: true,
  },
  {
    id: "mono-022",
    name: "Monolith #022",
    artist: "Sable Forge",
    collection: "Monolith Circuit",
    collectionId: "monolith",
    image:
      "https://images.unsplash.com/photo-1510915228340-29c85a43dcfe?auto=format&fit=crop&w=900&q=80",
    priceApt: 54,
    royaltyBps: 900,
    traits: [
      { label: "Core", value: "Quantum" },
      { label: "Shield", value: "Ion" },
      { label: "Epoch", value: "V" },
    ],
    saleMode: "dutch",
    escrowed: true,
  },
];

export const auctions: AuctionSummary[] = [
  {
    itemId: "reef-188",
    saleMode: "english",
    reserveApt: 17,
    currentBidApt: 21.5,
    minIncrementApt: 0.75,
    endsInHours: 11,
  },
  {
    itemId: "mono-022",
    saleMode: "dutch",
    reserveApt: 36,
    startPriceApt: 64,
    endPriceApt: 40,
    endsInHours: 7,
  },
];

export const offers: Offer[] = [
  {
    id: "offer-1",
    itemId: "drifter-011",
    bidder: "0x5fd...90a",
    amountApt: 29.5,
    expiresInHours: 18,
  },
  {
    id: "offer-2",
    itemId: "mono-022",
    bidder: "0x91c...10f",
    amountApt: 51,
    expiresInHours: 5,
  },
];

export const profile: ProfileSummary = {
  handle: "@atelier-9",
  address: "0x4c7d54d4f68f7df091b711b58b95a6f73e8dc4a65fefcfe9cf8411f011c18f12",
  createdCollections: 3,
  ownedItems: 41,
  activeListings: 9,
  pendingOffers: 6,
};

export const stats: MarketplaceStats = {
  totalVolumeApt: 14846,
  escrowApt: 392,
  creatorPayoutApt: 1180,
  platformFeeBps: 250,
};
