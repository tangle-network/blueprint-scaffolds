export type SaleMode = "fixed" | "english" | "dutch";

export interface Trait {
  label: string;
  value: string;
}

export interface NftItem {
  id: string;
  name: string;
  artist: string;
  collection: string;
  collectionId: string;
  image: string;
  priceApt: number;
  royaltyBps: number;
  traits: Trait[];
  saleMode: SaleMode;
  escrowed: boolean;
}

export interface CollectionSummary {
  id: string;
  name: string;
  creator: string;
  floorApt: number;
  items: number;
  volumeApt: number;
  royaltyBps: number;
  featuredImage: string;
  description: string;
}

export interface Offer {
  id: string;
  itemId: string;
  bidder: string;
  amountApt: number;
  expiresInHours: number;
}

export interface AuctionSummary {
  itemId: string;
  saleMode: Extract<SaleMode, "english" | "dutch">;
  reserveApt: number;
  currentBidApt?: number;
  minIncrementApt?: number;
  startPriceApt?: number;
  endPriceApt?: number;
  endsInHours: number;
}

export interface ProfileSummary {
  handle: string;
  address: string;
  createdCollections: number;
  ownedItems: number;
  activeListings: number;
  pendingOffers: number;
}

export interface MarketplaceStats {
  totalVolumeApt: number;
  escrowApt: number;
  creatorPayoutApt: number;
  platformFeeBps: number;
}
