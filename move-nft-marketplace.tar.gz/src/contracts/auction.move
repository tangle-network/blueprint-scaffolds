module marketplace::auction {
    use std::signer;
    use aptos_framework::coin;
    use aptos_framework::aptos_coin::AptosCoin;
    use aptos_token_objects::token;
    use marketplace::royalty;

    struct AuctionType has copy, drop, store {
        is_english: bool,
    }

    struct Auction has key {
        token_id: token::TokenId,
        seller: address,
        start_price: u64,
        current_price: u64,
        min_price: u64,
        highest_bidder: address,
        start_time: u64,
        end_time: u64,
        is_english: bool,
        active: bool,
    }

    struct BidEvent has copy, drop, store {
        auction_addr: address,
        bidder: address,
        amount: u64,
    }

    public entry fun create_english_auction(
        seller: &signer,
        token_id: token::TokenId,
        start_price: u64,
        duration_ms: u64,
    ) {
        let seller_addr = signer::address_of(seller);
        let now = std::timestamp::now_seconds();
        move_to(seller, Auction {
            token_id,
            seller: seller_addr,
            start_price,
            current_price: start_price,
            min_price: 0,
            highest_bidder: @0x0,
            start_time: now,
            end_time: now + duration_ms,
            is_english: true,
            active: true,
        });
    }

    public entry fun create_dutch_auction(
        seller: &signer,
        token_id: token::TokenId,
        start_price: u64,
        min_price: u64,
        duration_ms: u64,
    ) {
        let seller_addr = signer::address_of(seller);
        let now = std::timestamp::now_seconds();
        move_to(seller, Auction {
            token_id,
            seller: seller_addr,
            start_price,
            current_price: start_price,
            min_price,
            highest_bidder: @0x0,
            start_time: now,
            end_time: now + duration_ms,
            is_english: false,
            active: true,
        });
    }

    public entry fun place_bid(
        bidder: &signer,
        auction_addr: address,
        amount: u64,
    ) acquires Auction {
        let bidder_addr = signer::address_of(bidder);
        let auction = borrow_global_mut<Auction>(auction_addr);

        assert!(auction.active, 0);
        assert!(auction.seller != bidder_addr, 1);

        if (auction.is_english) {
            assert!(amount > auction.current_price, 2);
            if (auction.highest_bidder != @0x0) {
                coin::transfer<AptosCoin>(bidder, auction.highest_bidder, amount);
            };
            auction.current_price = amount;
            auction.highest_bidder = bidder_addr;
        } else {
            assert!(amount >= auction.current_price, 3);
            auction.active = false;
            auction.highest_bidder = bidder_addr;
            let royalty_amount = royalty::distribute_royalty(auction.seller, bidder, amount);
            let seller_proceeds = amount - royalty_amount;
            if (seller_proceeds > 0) {
                coin::transfer<AptosCoin>(bidder, auction.seller, seller_proceeds);
            };
        };
    }

    public entry fun settle_auction(
        caller: &signer,
        auction_addr: address,
    ) acquires Auction {
        let auction = borrow_global_mut<Auction>(auction_addr);
        assert!(auction.active, 4);
        assert!(auction.is_english, 5);

        let now = std::timestamp::now_seconds();
        assert!(now >= auction.end_time, 6);

        if (auction.highest_bidder != @0x0) {
            let final_price = auction.current_price;
            let seller_addr = auction.seller;
            auction.active = false;
        } else {
            auction.active = false;
        };
    }

    public entry fun cancel_auction(seller: &signer) acquires Auction {
        let seller_addr = signer::address_of(seller);
        let auction = borrow_global_mut<Auction>(seller_addr);
        assert!(auction.active, 7);
        assert!(auction.seller == seller_addr, 8);
        assert!(auction.highest_bidder == @0x0, 9);
        auction.active = false;
    }

    public fun get_auction(addr: address): (
        token::TokenId, address, u64, u64, u64, address, u64, u64, bool, bool
    ) acquires Auction {
        let a = borrow_global<Auction>(addr);
        (
            a.token_id, a.seller, a.start_price, a.current_price, a.min_price,
            a.highest_bidder, a.start_time, a.end_time, a.is_english, a.active
        )
    }
}
