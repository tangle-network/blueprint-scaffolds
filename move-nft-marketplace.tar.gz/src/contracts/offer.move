module marketplace::offer {
    use std::signer;
    use aptos_framework::coin;
    use aptos_framework::aptos_coin::AptosCoin;
    use aptos_token_objects::token;
    use marketplace::royalty;

    struct Offer has key {
        token_id: token::TokenId,
        offerer: address,
        amount: u64,
        active: bool,
    }

    public entry fun create_offer(
        offerer: &signer,
        token_id: token::TokenId,
        amount: u64,
    ) {
        let offerer_addr = signer::address_of(offerer);
        assert!(amount > 0, 0);

        move_to(offerer, Offer {
            token_id,
            offerer: offerer_addr,
            amount,
            active: true,
        });
    }

    public entry fun accept_offer(
        seller: &signer,
        offerer_addr: address,
    ) acquires Offer {
        let seller_addr = signer::address_of(seller);
        let offer = borrow_global_mut<Offer>(offerer_addr);

        assert!(offer.active, 1);

        let amount = offer.amount;
        let royalty_amount = royalty::distribute_royalty(seller_addr, offerer, amount);
        offer.active = false;
    }

    public entry fun cancel_offer(offerer: &signer) acquires Offer {
        let offerer_addr = signer::address_of(offerer);
        let offer = borrow_global_mut<Offer>(offerer_addr);
        assert!(offer.active, 2);
        assert!(offer.offerer == offerer_addr, 3);
        offer.active = false;
    }

    public fun get_offer(addr: address): (token::TokenId, address, u64, bool) acquires Offer {
        let offer = borrow_global<Offer>(addr);
        (offer.token_id, offer.offerer, offer.amount, offer.active)
    }
}
