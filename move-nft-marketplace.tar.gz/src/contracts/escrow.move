module marketplace::escrow {
    use std::signer;
    use aptos_framework::coin;
    use aptos_framework::aptos_coin::AptosCoin;
    use aptos_token_objects::token;

    struct Escrow has key {
        token_id: token::TokenId,
        seller: address,
        price: u64,
        active: bool,
    }

    public entry fun create_escrow(
        seller: &signer,
        token_id: token::TokenId,
        price: u64,
    ) {
        let seller_addr = signer::address_of(seller);
        let escrow = Escrow {
            token_id,
            seller: seller_addr,
            price,
            active: true,
        };
        move_to(seller, escrow);
    }

    public entry fun cancel_escrow(seller: &signer) acquires Escrow {
        let seller_addr = signer::address_of(seller);
        let escrow = borrow_global_mut<Escrow>(seller_addr);
        assert!(escrow.active, 0);
        assert!(escrow.seller == seller_addr, 1);
        escrow.active = false;
    }

    public fun get_escrow_info(addr: address): (token::TokenId, address, u64, bool) acquires Escrow {
        let escrow = borrow_global<Escrow>(addr);
        (escrow.token_id, escrow.seller, escrow.price, escrow.active)
    }

    public fun is_active(addr: address): bool acquires Escrow {
        if (exists<Escrow>(addr)) {
            let escrow = borrow_global<Escrow>(addr);
            escrow.active
        } else {
            false
        }
    }
}
