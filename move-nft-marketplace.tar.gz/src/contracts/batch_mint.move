module marketplace::batch_mint {
    use std::signer;
    use std::string;
    use aptos_token_objects::token;

    public entry fun batch_mint(
        creator: &signer,
        collection: string::String,
        description: string::String,
        base_name: string::String,
        count: u64,
        royalty_numerator: u64,
        royalty_denominator: u64,
    ) {
        let i = 0;
        while (i < count) {
            let token_name = string::copy(&base_name);
            let suffix = to_string(i);
            string::append(&mut token_name, string::utf8(b" #"));
            string::append(&mut token_name, suffix);

            token::mint_token(
                creator,
                collection,
                token_name,
                description,
                royalty_numerator,
                royalty_denominator,
            );

            i = i + 1;
        };
    }

    fun to_string(n: u64): string::String {
        if (n == 0) {
            return string::utf8(b"0");
        };

        let digits = 0;
        let temp = n;
        while (temp > 0) {
            digits = digits + 1;
            temp = temp / 10;
        };

        let bytes = vector::empty<u8>();
        let i = digits;
        while (i > 0) {
            let divisor = 1;
            let j = 1;
            while (j < i) {
                divisor = divisor * 10;
                j = j + 1;
            };
            let digit = (n / divisor) % 10;
            vector::push_back(&mut bytes, 48 + (digit as u8));
            i = i - 1;
        };

        string::utf8(bytes)
    }
}
