module marketplace::listing {
    use std::signer;
    use std::string;
    use aptos_framework::coin;
    use aptos_framework::aptos_coin::AptosCoin;
    use aptos_token_objects::token;
    use marketplace::royalty;
    use marketplace::escrow;

    struct Listing has key {
        token_id: token::TokenId,
        seller: address,
        price: u64,
        active: bool,
    }

    struct ListingCreatedEvent has copy, drop, store {
        token_id: token::TokenId,
        seller: address,
        price: u64,
    }

    struct ListingSoldEvent has copy, drop, store {
        token_id: token::TokenId,
        seller: address,
        buyer: address,
        price: u64,
    }

    public entry fun create_listing(
        seller: &signer,
        token_id: token::TokenId,
        price: u64,
    ) {
        let seller_addr = signer::address_of(seller);
        assert!(price > 0, 0);
        assert!(!exists<Listing>(seller_addr), 1);

        move_to(seller, Listing {
            token_id,
            seller: seller_addr,
            price,
            active: true,
        });
    }

    public entry fun buy_listing(
        buyer: &signer,
        listing_addr: address,
    ) acquires Listing {
        let buyer_addr = signer::address_of(buyer);
        let listing = borrow_global_mut<Listing>(listing_addr);

        assert!(listing.active, 2);
        assert!(listing.seller != buyer_addr, 3);

        let price = listing.price;
        let seller_addr = listing.seller;

        let royalty_amount = royalty::distribute_royalty(seller_addr, buyer, price);
        let seller_proceeds = price - royalty_amount;

        if (seller_proceeds > 0) {
            coin::transfer<AptosCoin>(buyer, seller_addr, seller_proceeds);
        };

        listing.active = false;
    }

    public entry fun cancel_listing(seller: &signer) acquires Listing {
        let seller_addr = signer::address_of(seller);
        let listing = borrow_global_mut<Listing>(seller_addr);
        assert!(listing.active, 4);
        assert!(listing.seller == seller_addr, 5);
        listing.active = false;
    }

    public entry fun update_price(
        seller: &signer,
        new_price: u64,
    ) acquires Listing {
        let seller_addr = signer::address_of(seller);
        let listing = borrow_global_mut<Listing>(seller_addr);
        assert!(listing.active, 6);
        assert!(listing.seller == seller_addr, 7);
        assert!(new_price > 0, 8);
        listing.price = new_price;
    }

    public fun get_listing(addr: address): (token::TokenId, address, u64, bool) acquires Listing {
        let listing = borrow_global<Listing>(addr);
        (listing.token_id, listing.seller, listing.price, listing.active)
    }
}
