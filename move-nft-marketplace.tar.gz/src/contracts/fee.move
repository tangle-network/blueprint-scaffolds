module marketplace::fee {
    use std::signer;
    use aptos_framework::coin;
    use aptos_framework::aptos_coin::AptosCoin;

    struct FeeConfig has key {
        fee_percentage: u64,
        denominator: u64,
        fee_recipient: address,
        collected_fees: u64,
    }

    public entry fun initialize(
        admin: &signer,
        fee_percentage: u64,
        fee_recipient: address,
    ) {
        let admin_addr = signer::address_of(admin);
        move_to(admin, FeeConfig {
            fee_percentage,
            denominator: 10000,
            fee_recipient,
            collected_fees: 0,
        });
    }

    public fun calculate_fee(amount: u64): u64 acquires FeeConfig {
        let config = borrow_global<FeeConfig>(@marketplace);
        amount * config.fee_percentage / config.denominator
    }

    public fun collect_fee(payer: &signer, amount: u64): u64 acquires FeeConfig {
        let fee = calculate_fee(amount);
        let config = borrow_global_mut<FeeConfig>(@marketplace);
        if (fee > 0) {
            coin::transfer<AptosCoin>(payer, config.fee_recipient, fee);
            config.collected_fees = config.collected_fees + fee;
        };
        fee
    }

    public fun get_fee_config(): (u64, u64, address, u64) acquires FeeConfig {
        let config = borrow_global<FeeConfig>(@marketplace);
        (config.fee_percentage, config.denominator, config.fee_recipient, config.collected_fees)
    }
}
