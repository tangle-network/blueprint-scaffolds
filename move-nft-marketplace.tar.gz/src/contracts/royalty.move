module marketplace::royalty {
    use std::signer;
    use aptos_framework::coin;
    use aptos_framework::aptos_coin::AptosCoin;
    use aptos_token_objects::token;

    struct RoyaltyConfig has key {
        creator: address,
        royalty_percentage: u64,
        denominator: u64,
    }

    public entry fun setup_royalty(
        creator: &signer,
        percentage: u64,
    ) {
        let creator_addr = signer::address_of(creator);
        if (!exists<RoyaltyConfig>(creator_addr)) {
            move_to(creator, RoyaltyConfig {
                creator: creator_addr,
                royalty_percentage: percentage,
                denominator: 10000,
            });
        };
    }

    public fun calculate_royalty(creator_addr: address, sale_amount: u64): (u64, u64) acquires RoyaltyConfig {
        if (exists<RoyaltyConfig>(creator_addr)) {
            let config = borrow_global<RoyaltyConfig>(creator_addr);
            let royalty = sale_amount * config.royalty_percentage / config.denominator;
            (royalty, config.royalty_percentage)
        } else {
            (0, 0)
        }
    }

    public fun distribute_royalty(
        creator_addr: address,
        buyer: &signer,
        sale_amount: u64,
    ): u64 acquires RoyaltyConfig {
        let (royalty_amount, _) = calculate_royalty(creator_addr, sale_amount);
        if (royalty_amount > 0) {
            coin::transfer<AptosCoin>(buyer, creator_addr, royalty_amount);
        };
        royalty_amount
    }

    public fun get_royalty_percentage(creator_addr: address): u64 acquires RoyaltyConfig {
        if (exists<RoyaltyConfig>(creator_addr)) {
            let config = borrow_global<RoyaltyConfig>(creator_addr);
            config.royalty_percentage
        } else {
            0
        }
    }

    #[test]
    fun test_setup_and_calculate_royalty() {
        use aptos_framework::aptos_account;
        use aptos_framework::coin;

        let creator = @0x123;
        let buyer = @0x456;
        let (creator_signer, buyer_signer) = (account::create_signer_for_test(creator), account::create_signer_for_test(buyer));

        aptos_account::mint(&creator_signer, 100000000);
        aptos_account::mint(&buyer_signer, 100000000);

        setup_royalty(&creator_signer, 500);

        let (royalty, percentage) = calculate_royalty(creator, 1000000);
        assert!(royalty == 50000, 1);
        assert!(percentage == 500, 2);
    }
}
