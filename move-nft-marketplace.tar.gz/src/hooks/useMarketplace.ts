import { useState, useCallback } from "react";
import type { Listing, Auction, Offer, NFTToken, Collection } from "@/lib/types";
import {
  mockListings,
  mockAuctions,
  mockOffers,
  mockTokens,
  mockCollections,
  getMockProfile,
} from "@/lib/mock-data";
import type { UserProfile } from "@/lib/types";

export function useListings() {
  const [listings] = useState<Listing[]>(mockListings);
  return { listings };
}

export function useAuctions() {
  const [auctions] = useState<Auction[]>(mockAuctions);
  return { auctions };
}

export function useOffers() {
  const [offers] = useState<Offer[]>(mockOffers);
  return { offers };
}

export function useTokens() {
  const [tokens] = useState<NFTToken[]>(mockTokens);
  const getToken = useCallback(
    (id: string) => tokens.find((t) => t.id === id),
    [tokens]
  );
  return { tokens, getToken };
}

export function useCollections() {
  const [collections] = useState<Collection[]>(mockCollections);
  const getCollection = useCallback(
    (name: string) => collections.find((c) => c.name === name),
    [collections]
  );
  return { collections, getCollection };
}

export function useProfile(address: string | null) {
  const [profile] = useState<UserProfile | null>(
    address ? getMockProfile(address) : null
  );
  return { profile };
}
