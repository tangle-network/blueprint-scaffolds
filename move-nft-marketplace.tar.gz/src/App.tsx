import { Routes, Route } from "react-router-dom";
import Layout from "@/components/Layout";
import Home from "@/pages/Home";
import Collections from "@/pages/Collections";
import CollectionDetail from "@/pages/CollectionDetail";
import NFTDetail from "@/pages/NFTDetail";
import Profile from "@/pages/Profile";
import Create from "@/pages/Create";
import Listings from "@/pages/Listings";
import Auctions from "@/pages/Auctions";

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/collections" element={<Collections />} />
        <Route path="/collection/:name" element={<CollectionDetail />} />
        <Route path="/nft/:id" element={<NFTDetail />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/create" element={<Create />} />
        <Route path="/listings" element={<Listings />} />
        <Route path="/auctions" element={<Auctions />} />
      </Route>
    </Routes>
  );
}
