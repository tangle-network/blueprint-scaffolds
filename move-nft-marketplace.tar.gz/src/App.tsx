import { useMemo, useState } from "react";
import {
  App as AntdApp,
  Button,
  Card,
  Col,
  Divider,
  Form,
  Input,
  InputNumber,
  Layout,
  List,
  Progress,
  Row,
  Select,
  Space,
  Statistic,
  Table,
  Tag,
  Typography,
} from "antd";
import { WalletSelector } from "@aptos-labs/wallet-adapter-ant-design";
import { useWallet } from "@aptos-labs/wallet-adapter-react";
import {
  auctions,
  collections,
  featuredItems,
  offers,
  profile,
  stats,
} from "./data/mockData";
import { aptosClient, marketplaceModules, shortenAddress, txBuilders } from "./lib/aptos";
import type { NftItem, SaleMode } from "./types";

const { Header, Content } = Layout;
const { Title, Paragraph, Text } = Typography;

type TradeFormValues = {
  tokenId?: string;
  priceApt?: number;
  reserveApt?: number;
  minIncrementApt?: number;
  startPriceApt?: number;
  endPriceApt?: number;
  durationHours?: number;
  offerAmountApt?: number;
  offerExpiryHours?: number;
  collectionName?: string;
  baseUri?: string;
  quantity?: number;
  royaltyBps?: number;
};

const saleModePalette: Record<SaleMode, string> = {
  fixed: "blue",
  english: "green",
  dutch: "orange",
};

const collectionColumns = [
  {
    title: "Collection",
    dataIndex: "name",
    key: "name",
    render: (value: string, record: (typeof collections)[number]) => (
      <Space direction="vertical" size={0}>
        <Text strong>{value}</Text>
        <Text type="secondary">{record.description}</Text>
      </Space>
    ),
  },
  {
    title: "Creator",
    dataIndex: "creator",
    key: "creator",
  },
  {
    title: "Floor",
    dataIndex: "floorApt",
    key: "floorApt",
    render: (value: number) => `${value} APT`,
  },
  {
    title: "Royalty",
    dataIndex: "royaltyBps",
    key: "royaltyBps",
    render: (value: number) => `${(value / 100).toFixed(2)}%`,
  },
];

function HeroStats() {
  return (
    <Row gutter={[16, 16]}>
      <Col xs={24} sm={12} lg={6}>
        <Card className="stat-card">
          <Statistic title="Total Volume" value={stats.totalVolumeApt} suffix="APT" />
        </Card>
      </Col>
      <Col xs={24} sm={12} lg={6}>
        <Card className="stat-card">
          <Statistic title="Escrow Locked" value={stats.escrowApt} suffix="APT" />
        </Card>
      </Col>
      <Col xs={24} sm={12} lg={6}>
        <Card className="stat-card">
          <Statistic title="Creator Payouts" value={stats.creatorPayoutApt} suffix="APT" />
        </Card>
      </Col>
      <Col xs={24} sm={12} lg={6}>
        <Card className="stat-card">
          <Statistic
            title="Platform Fee"
            value={(stats.platformFeeBps / 100).toFixed(2)}
            suffix="%"
          />
        </Card>
      </Col>
    </Row>
  );
}

function NftCard({ item }: { item: NftItem }) {
  const auction = auctions.find((entry) => entry.itemId === item.id);

  return (
    <Card
      className="nft-card"
      cover={<img alt={item.name} className="nft-image" src={item.image} />}
    >
      <Space direction="vertical" size="middle" style={{ width: "100%" }}>
        <Space style={{ justifyContent: "space-between", width: "100%" }}>
          <div>
            <Text type="secondary">{item.collection}</Text>
            <Title level={4} style={{ margin: 0 }}>
              {item.name}
            </Title>
          </div>
          <Tag color={saleModePalette[item.saleMode]}>{item.saleMode}</Tag>
        </Space>
        <Space wrap>
          {item.traits.map((trait) => (
            <Tag key={`${item.id}-${trait.label}`}>{`${trait.label}: ${trait.value}`}</Tag>
          ))}
        </Space>
        <Row gutter={12}>
          <Col span={12}>
            <Text type="secondary">Price</Text>
            <div className="metric-line">{item.priceApt} APT</div>
          </Col>
          <Col span={12}>
            <Text type="secondary">Royalty</Text>
            <div className="metric-line">{(item.royaltyBps / 100).toFixed(2)}%</div>
          </Col>
        </Row>
        <Text type="secondary">
          {auction
            ? `Auction closes in ${auction.endsInHours}h with escrow and royalty routing enabled.`
            : "Instant settlement with escrow release and fee split on fulfillment."}
        </Text>
      </Space>
    </Card>
  );
}

function App() {
  const { message } = AntdApp.useApp();
  const { account, connected, network, signAndSubmitTransaction } = useWallet();
  const [busyAction, setBusyAction] = useState<string | null>(null);

  const profileCards = useMemo(
    () => [
      { label: "Collections", value: profile.createdCollections },
      { label: "Owned NFTs", value: profile.ownedItems },
      { label: "Listings", value: profile.activeListings },
      { label: "Offers", value: profile.pendingOffers },
    ],
    [],
  );

  const submitWalletAction = async (label: string, payload: ReturnType<typeof txBuilders.batchMint>) => {
    if (!connected) {
      message.warning("Connect Petra or Martian to submit Aptos transactions.");
      return;
    }

    try {
      setBusyAction(label);
      const response = await signAndSubmitTransaction(payload);
      await aptosClient.waitForTransaction({
        transactionHash: response.hash,
      });
      message.success(`${label} confirmed on ${network?.name ?? "Aptos testnet"}.`);
    } catch (error) {
      const description = error instanceof Error ? error.message : "Transaction failed";
      message.error(description);
    } finally {
      setBusyAction(null);
    }
  };

  const handleFixedListing = async (values: TradeFormValues) => {
    if (!values.tokenId || values.priceApt == null) {
      return;
    }

    await submitWalletAction(
      "Fixed-price listing",
      txBuilders.createFixedListing(values.tokenId, values.priceApt),
    );
  };

  const handleEnglishAuction = async (values: TradeFormValues) => {
    if (
      !values.tokenId ||
      values.reserveApt == null ||
      values.minIncrementApt == null ||
      values.durationHours == null
    ) {
      return;
    }

    await submitWalletAction(
      "English auction",
      txBuilders.createEnglishAuction(
        values.tokenId,
        values.reserveApt,
        values.minIncrementApt,
        values.durationHours,
      ),
    );
  };

  const handleDutchAuction = async (values: TradeFormValues) => {
    if (
      !values.tokenId ||
      values.startPriceApt == null ||
      values.endPriceApt == null ||
      values.durationHours == null
    ) {
      return;
    }

    await submitWalletAction(
      "Dutch auction",
      txBuilders.createDutchAuction(
        values.tokenId,
        values.startPriceApt,
        values.endPriceApt,
        values.durationHours,
      ),
    );
  };

  const handleOffer = async (values: TradeFormValues) => {
    if (!values.tokenId || values.offerAmountApt == null || values.offerExpiryHours == null) {
      return;
    }

    await submitWalletAction(
      "Offer placement",
      txBuilders.placeOffer(values.tokenId, values.offerAmountApt, values.offerExpiryHours),
    );
  };

  const handleBatchMint = async (values: TradeFormValues) => {
    if (
      !values.collectionName ||
      !values.baseUri ||
      values.quantity == null ||
      values.royaltyBps == null
    ) {
      return;
    }

    await submitWalletAction(
      "Batch mint",
      txBuilders.batchMint(
        values.collectionName,
        values.baseUri,
        values.quantity,
        values.royaltyBps,
      ),
    );
  };

  return (
    <Layout className="app-shell">
      <Header className="app-header">
        <div>
          <Text className="eyebrow">APTOS NFT MARKETPLACE</Text>
          <Title level={3} style={{ color: "#f8fbff", margin: 0 }}>
            Move-powered trading with royalties, auctions, offers, and escrow
          </Title>
        </div>
        <Space align="center" size="large">
          <div className="wallet-blurb">
            <Text className="wallet-label">Profile</Text>
            <Text className="wallet-value">{shortenAddress(account?.address?.toString())}</Text>
          </div>
          <WalletSelector />
        </Space>
      </Header>
      <Content className="app-content">
        <section className="hero-grid">
          <div className="hero-panel">
            <Text className="eyebrow">Protocol Surface</Text>
            <Title level={1} className="hero-title">
              Collections, listings, offers, English auctions, Dutch auctions, and escrow settlement.
            </Title>
            <Paragraph className="hero-copy">
              Frontend flows are wired to Move entry functions in the modules below, using wallet
              adapter support for Petra and Martian on Aptos testnet.
            </Paragraph>
            <Space wrap size="middle">
              <Tag className="module-chip">{marketplaceModules.royalty}</Tag>
              <Tag className="module-chip">{marketplaceModules.listing}</Tag>
              <Tag className="module-chip">{marketplaceModules.auction}</Tag>
              <Tag className="module-chip">{marketplaceModules.fees}</Tag>
            </Space>
            <Divider />
            <HeroStats />
          </div>
          <Card className="profile-panel">
            <Text className="eyebrow">User Profile</Text>
            <Title level={3}>{profile.handle}</Title>
            <Paragraph>{profile.address}</Paragraph>
            <Progress percent={78} strokeColor="#1d4ed8" trailColor="#dce7ff" />
            <Row gutter={[12, 12]}>
              {profileCards.map((card) => (
                <Col span={12} key={card.label}>
                  <Card size="small">
                    <Statistic title={card.label} value={card.value} />
                  </Card>
                </Col>
              ))}
            </Row>
            <Divider />
            <Text type="secondary">Connected network: {network?.name ?? "testnet"}</Text>
          </Card>
        </section>

        <Row gutter={[24, 24]}>
          <Col xs={24} xl={15}>
            <Card className="section-card" title="Collection Browser">
              <Table
                columns={collectionColumns}
                dataSource={collections}
                pagination={false}
                rowKey="id"
              />
            </Card>
          </Col>
          <Col xs={24} xl={9}>
            <Card className="section-card" title="Marketplace Offers">
              <List
                dataSource={offers}
                renderItem={(offer) => (
                  <List.Item
                    actions={[
                      <Button
                        key="accept"
                        type="link"
                        onClick={() => void submitWalletAction("Offer acceptance", txBuilders.acceptOffer(offer.id))}
                      >
                        Accept
                      </Button>,
                    ]}
                  >
                    <List.Item.Meta
                      title={`${offer.amountApt} APT for ${offer.itemId}`}
                      description={`${offer.bidder} · expires in ${offer.expiresInHours}h`}
                    />
                  </List.Item>
                )}
              />
            </Card>
          </Col>
        </Row>

        <section className="gallery-grid">
          {featuredItems.map((item) => (
            <NftCard item={item} key={item.id} />
          ))}
        </section>

        <Row gutter={[24, 24]}>
          <Col xs={24} lg={12}>
            <Card className="section-card" title="Trading Desk">
              <Space direction="vertical" size="large" style={{ width: "100%" }}>
                <Form layout="vertical" onFinish={handleFixedListing}>
                  <Title level={5}>Fixed-price listing</Title>
                  <Row gutter={12}>
                    <Col span={12}>
                      <Form.Item label="Token ID" name="tokenId" rules={[{ required: true }]}>
                        <Select
                          options={featuredItems.map((item) => ({
                            label: `${item.name} (${item.id})`,
                            value: item.id,
                          }))}
                        />
                      </Form.Item>
                    </Col>
                    <Col span={12}>
                      <Form.Item label="Price (APT)" name="priceApt" rules={[{ required: true }]}>
                        <InputNumber min={1} precision={2} style={{ width: "100%" }} />
                      </Form.Item>
                    </Col>
                  </Row>
                  <Button htmlType="submit" loading={busyAction === "Fixed-price listing"} type="primary">
                    Create listing
                  </Button>
                </Form>

                <Divider />

                <Form layout="vertical" onFinish={handleEnglishAuction}>
                  <Title level={5}>English auction</Title>
                  <Row gutter={12}>
                    <Col span={12}>
                      <Form.Item label="Token ID" name="tokenId" rules={[{ required: true }]}>
                        <Select
                          options={featuredItems.map((item) => ({
                            label: `${item.name} (${item.id})`,
                            value: item.id,
                          }))}
                        />
                      </Form.Item>
                    </Col>
                    <Col span={12}>
                      <Form.Item label="Reserve (APT)" name="reserveApt" rules={[{ required: true }]}>
                        <InputNumber min={1} precision={2} style={{ width: "100%" }} />
                      </Form.Item>
                    </Col>
                    <Col span={12}>
                      <Form.Item
                        label="Min increment"
                        name="minIncrementApt"
                        rules={[{ required: true }]}
                      >
                        <InputNumber min={0.1} precision={2} style={{ width: "100%" }} />
                      </Form.Item>
                    </Col>
                    <Col span={12}>
                      <Form.Item
                        label="Duration (hours)"
                        name="durationHours"
                        rules={[{ required: true }]}
                      >
                        <InputNumber min={1} precision={0} style={{ width: "100%" }} />
                      </Form.Item>
                    </Col>
                  </Row>
                  <Button htmlType="submit" loading={busyAction === "English auction"}>
                    Launch English auction
                  </Button>
                </Form>

                <Divider />

                <Form layout="vertical" onFinish={handleDutchAuction}>
                  <Title level={5}>Dutch auction</Title>
                  <Row gutter={12}>
                    <Col span={12}>
                      <Form.Item label="Token ID" name="tokenId" rules={[{ required: true }]}>
                        <Select
                          options={featuredItems.map((item) => ({
                            label: `${item.name} (${item.id})`,
                            value: item.id,
                          }))}
                        />
                      </Form.Item>
                    </Col>
                    <Col span={12}>
                      <Form.Item
                        label="Start price"
                        name="startPriceApt"
                        rules={[{ required: true }]}
                      >
                        <InputNumber min={1} precision={2} style={{ width: "100%" }} />
                      </Form.Item>
                    </Col>
                    <Col span={12}>
                      <Form.Item label="End price" name="endPriceApt" rules={[{ required: true }]}>
                        <InputNumber min={1} precision={2} style={{ width: "100%" }} />
                      </Form.Item>
                    </Col>
                    <Col span={12}>
                      <Form.Item
                        label="Duration (hours)"
                        name="durationHours"
                        rules={[{ required: true }]}
                      >
                        <InputNumber min={1} precision={0} style={{ width: "100%" }} />
                      </Form.Item>
                    </Col>
                  </Row>
                  <Button htmlType="submit" loading={busyAction === "Dutch auction"}>
                    Launch Dutch auction
                  </Button>
                </Form>

                <Divider />

                <Form layout="vertical" onFinish={handleOffer}>
                  <Title level={5}>Offer system</Title>
                  <Row gutter={12}>
                    <Col span={12}>
                      <Form.Item label="Token ID" name="tokenId" rules={[{ required: true }]}>
                        <Select
                          options={featuredItems.map((item) => ({
                            label: `${item.name} (${item.id})`,
                            value: item.id,
                          }))}
                        />
                      </Form.Item>
                    </Col>
                    <Col span={12}>
                      <Form.Item
                        label="Offer amount"
                        name="offerAmountApt"
                        rules={[{ required: true }]}
                      >
                        <InputNumber min={1} precision={2} style={{ width: "100%" }} />
                      </Form.Item>
                    </Col>
                    <Col span={24}>
                      <Form.Item
                        label="Offer expiry (hours)"
                        name="offerExpiryHours"
                        rules={[{ required: true }]}
                      >
                        <InputNumber min={1} precision={0} style={{ width: "100%" }} />
                      </Form.Item>
                    </Col>
                  </Row>
                  <Button htmlType="submit" loading={busyAction === "Offer placement"}>
                    Place escrowed offer
                  </Button>
                </Form>
              </Space>
            </Card>
          </Col>
          <Col xs={24} lg={12}>
            <Card className="section-card" title="Creator Console">
              <Form layout="vertical" onFinish={handleBatchMint}>
                <Title level={5}>Batch mint a collection</Title>
                <Form.Item label="Collection name" name="collectionName" rules={[{ required: true }]}>
                  <Input />
                </Form.Item>
                <Form.Item label="Base URI" name="baseUri" rules={[{ required: true }]}>
                  <Input />
                </Form.Item>
                <Row gutter={12}>
                  <Col span={12}>
                    <Form.Item label="Quantity" name="quantity" rules={[{ required: true }]}>
                      <InputNumber min={1} precision={0} style={{ width: "100%" }} />
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item label="Royalty (bps)" name="royaltyBps" rules={[{ required: true }]}>
                      <InputNumber min={0} max={2000} precision={0} style={{ width: "100%" }} />
                    </Form.Item>
                  </Col>
                </Row>
                <Button htmlType="submit" loading={busyAction === "Batch mint"} type="primary">
                  Mint collection batch
                </Button>
              </Form>

              <Divider />

              <Title level={5}>Settlement controls</Title>
              <Space wrap>
                {featuredItems.map((item) => (
                  <Button
                    key={`${item.id}-settle`}
                    onClick={() => void submitWalletAction("Auction settlement", txBuilders.settleAuction(item.id))}
                  >
                    Settle {item.id}
                  </Button>
                ))}
              </Space>
              <Divider />
              <Space wrap>
                {featuredItems.map((item) => (
                  <Button
                    key={`${item.id}-escrow`}
                    onClick={() => void submitWalletAction("Escrow release", txBuilders.releaseEscrow(item.id))}
                  >
                    Release escrow {item.id}
                  </Button>
                ))}
              </Space>
              <Divider />
              <List
                header={<Text strong>Move module coverage</Text>}
                dataSource={[
                  "listing.move: fixed-price listings, offers, seller escrow",
                  "auction.move: English and Dutch auctions, bid accounting",
                  "royalty_enforcement.move: collections, royalty policies, batch minting",
                  "fee_distribution.move: platform fees, creator payouts, escrow release",
                ]}
                renderItem={(entry) => <List.Item>{entry}</List.Item>}
              />
            </Card>
          </Col>
        </Row>
      </Content>
    </Layout>
  );
}

export default App;
