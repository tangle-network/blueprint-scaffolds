module marketplace::auction {
    use std::signer;
    use std::string::{Self, String};
    use std::table::{Self, Table};

    const E_AUCTION_EXISTS: u64 = 1;
    const E_AUCTION_NOT_FOUND: u64 = 2;
    const E_BID_TOO_LOW: u64 = 3;

    struct EnglishAuction has copy, drop, store {
        seller: address,
        reserve_price: u64,
        current_bid: u64,
        min_increment: u64,
        duration_hours: u64,
    }

    struct DutchAuction has copy, drop, store {
        seller: address,
        start_price: u64,
        end_price: u64,
        duration_hours: u64,
    }

    struct AuctionBook has key {
        english: Table<String, EnglishAuction>,
        dutch: Table<String, DutchAuction>,
    }

    public entry fun init(owner: &signer) {
        let owner_address = signer::address_of(owner);
        if (!exists<AuctionBook>(owner_address)) {
            move_to(
                owner,
                AuctionBook {
                    english: table::new<String, EnglishAuction>(),
                    dutch: table::new<String, DutchAuction>(),
                }
            );
        };
    }

    public entry fun create_english_auction(
        seller: &signer,
        token_id: String,
        reserve_price: u64,
        min_increment: u64,
        duration_hours: u64,
    ) acquires AuctionBook {
        let seller_address = signer::address_of(seller);
        if (!exists<AuctionBook>(seller_address)) {
            init(seller);
        };
        let book = borrow_global_mut<AuctionBook>(seller_address);
        assert!(!table::contains(&book.english, copy token_id), E_AUCTION_EXISTS);
        table::add(
            &mut book.english,
            copy token_id,
            EnglishAuction {
                seller: seller_address,
                reserve_price,
                current_bid: 0,
                min_increment,
                duration_hours,
            }
        );
    }

    public entry fun create_dutch_auction(
        seller: &signer,
        token_id: String,
        start_price: u64,
        end_price: u64,
        duration_hours: u64,
    ) acquires AuctionBook {
        let seller_address = signer::address_of(seller);
        if (!exists<AuctionBook>(seller_address)) {
            init(seller);
        };
        let book = borrow_global_mut<AuctionBook>(seller_address);
        assert!(!table::contains(&book.dutch, copy token_id), E_AUCTION_EXISTS);
        table::add(
            &mut book.dutch,
            copy token_id,
            DutchAuction {
                seller: seller_address,
                start_price,
                end_price,
                duration_hours,
            }
        );
    }

    public entry fun bid(
        bidder: &signer,
        seller: address,
        token_id: String,
        amount: u64,
    ) acquires AuctionBook {
        let _bidder_address = signer::address_of(bidder);
        let book = borrow_global_mut<AuctionBook>(seller);
        assert!(table::contains(&book.english, copy token_id), E_AUCTION_NOT_FOUND);
        let auction = table::borrow_mut(&mut book.english, token_id);
        assert!(
            amount >= auction.reserve_price &&
            amount >= auction.current_bid + auction.min_increment,
            E_BID_TOO_LOW
        );
        auction.current_bid = amount;
    }

    public entry fun settle_auction(
        owner: &signer,
        token_id: String,
    ) acquires AuctionBook {
        let owner_address = signer::address_of(owner);
        let book = borrow_global_mut<AuctionBook>(owner_address);
        if (table::contains(&book.english, copy token_id)) {
            let _auction = table::remove(&mut book.english, copy token_id);
        } else if (table::contains(&book.dutch, copy token_id)) {
            let _auction = table::remove(&mut book.dutch, copy token_id);
        } else {
            abort E_AUCTION_NOT_FOUND
        };
    }
}
