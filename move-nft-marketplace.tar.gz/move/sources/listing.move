module marketplace::listing {
    use std::option::{Self, Option};
    use std::signer;
    use std::string::{Self, String};
    use std::table::{Self, Table};

    const E_ALREADY_LISTED: u64 = 1;
    const E_NOT_LISTED: u64 = 2;
    const E_NOT_OWNER: u64 = 3;
    const E_OFFER_MISSING: u64 = 4;

    struct Listing has copy, drop, store {
        seller: address,
        price: u64,
        escrowed: bool,
    }

    struct Offer has copy, drop, store {
        bidder: address,
        amount: u64,
        expiry_hours: u64,
    }

    struct MarketplaceListings has key {
        listings: Table<String, Listing>,
        offers: Table<String, Offer>,
    }

    public entry fun init_market(owner: &signer) {
        let owner_address = signer::address_of(owner);
        if (!exists<MarketplaceListings>(owner_address)) {
            move_to(
                owner,
                MarketplaceListings {
                    listings: table::new<String, Listing>(),
                    offers: table::new<String, Offer>(),
                }
            );
        };
    }

    public entry fun create_fixed_price_listing(
        seller: &signer,
        token_id: String,
        price: u64,
    ) acquires MarketplaceListings {
        let seller_address = signer::address_of(seller);
        if (!exists<MarketplaceListings>(seller_address)) {
            init_market(seller);
        };

        let store = borrow_global_mut<MarketplaceListings>(seller_address);
        assert!(!table::contains(&store.listings, copy token_id), E_ALREADY_LISTED);
        table::add(
            &mut store.listings,
            copy token_id,
            Listing {
                seller: seller_address,
                price,
                escrowed: true,
            }
        );
    }

    public entry fun place_offer(
        bidder: &signer,
        token_id: String,
        amount: u64,
        expiry_hours: u64,
    ) acquires MarketplaceListings {
        let bidder_address = signer::address_of(bidder);
        if (!exists<MarketplaceListings>(bidder_address)) {
            init_market(bidder);
        };

        let store = borrow_global_mut<MarketplaceListings>(bidder_address);
        table::upsert(
            &mut store.offers,
            copy token_id,
            Offer {
                bidder: bidder_address,
                amount,
                expiry_hours,
            }
        );
    }

    public entry fun accept_offer(
        seller: &signer,
        offer_id: String,
    ) acquires MarketplaceListings {
        let seller_address = signer::address_of(seller);
        assert!(exists<MarketplaceListings>(seller_address), E_NOT_LISTED);
        let store = borrow_global_mut<MarketplaceListings>(seller_address);
        assert!(table::contains(&store.offers, copy offer_id), E_OFFER_MISSING);
        let _offer = table::remove(&mut store.offers, copy offer_id);
    }

    public fun is_escrowed(owner: address, token_id: String): bool acquires MarketplaceListings {
        if (!exists<MarketplaceListings>(owner)) {
            return false
        };
        let store = borrow_global<MarketplaceListings>(owner);
        if (!table::contains(&store.listings, copy token_id)) {
            return false
        };
        let listing = table::borrow(&store.listings, token_id);
        listing.escrowed
    }
}
