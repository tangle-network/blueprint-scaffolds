module marketplace::royalty_enforcement {
    use std::option;
    use std::signer;
    use std::string::{Self, String};
    use std::vector;

    const E_COLLECTION_EXISTS: u64 = 1;
    const E_COLLECTION_NOT_FOUND: u64 = 2;

    struct CollectionConfig has key, store {
        name: String,
        base_uri: String,
        royalty_bps: u64,
        total_supply: u64,
        minted: u64,
    }

    public entry fun create_collection(
        creator: &signer,
        name: String,
        base_uri: String,
        royalty_bps: u64,
        total_supply: u64,
    ) {
        let creator_address = signer::address_of(creator);
        assert!(!exists<CollectionConfig>(creator_address), E_COLLECTION_EXISTS);
        move_to(
            creator,
            CollectionConfig {
                name,
                base_uri,
                royalty_bps,
                total_supply,
                minted: 0,
            }
        );
    }

    public entry fun batch_mint_collection(
        creator: &signer,
        name: String,
        base_uri: String,
        quantity: u64,
        royalty_bps: u64,
    ) acquires CollectionConfig {
        let creator_address = signer::address_of(creator);
        if (!exists<CollectionConfig>(creator_address)) {
            create_collection(creator, name, base_uri, royalty_bps, quantity);
        };

        let collection = borrow_global_mut<CollectionConfig>(creator_address);
        assert!(collection.minted + quantity <= collection.total_supply, E_COLLECTION_NOT_FOUND);
        collection.minted = collection.minted + quantity;
    }

    public fun royalty_bps(creator: address): u64 acquires CollectionConfig {
        let collection = borrow_global<CollectionConfig>(creator);
        collection.royalty_bps
    }
}
