module marketplace::fee_distribution {
    use std::signer;
    use std::string::{Self, String};
    use std::table::{Self, Table};

    const E_ESCROW_NOT_FOUND: u64 = 1;

    struct EscrowPosition has copy, drop, store {
        token_id: String,
        amount: u64,
        creator_royalty_bps: u64,
        platform_fee_bps: u64,
    }

    struct EscrowBook has key {
        positions: Table<String, EscrowPosition>,
    }

    public entry fun init(account: &signer) {
        let owner = signer::address_of(account);
        if (!exists<EscrowBook>(owner)) {
            move_to(account, EscrowBook { positions: table::new<String, EscrowPosition>() });
        };
    }

    public entry fun record_sale(
        operator: &signer,
        token_id: String,
        amount: u64,
        creator_royalty_bps: u64,
        platform_fee_bps: u64,
    ) acquires EscrowBook {
        let owner = signer::address_of(operator);
        if (!exists<EscrowBook>(owner)) {
            init(operator);
        };
        let book = borrow_global_mut<EscrowBook>(owner);
        table::upsert(
            &mut book.positions,
            copy token_id,
            EscrowPosition {
                token_id,
                amount,
                creator_royalty_bps,
                platform_fee_bps,
            }
        );
    }

    public entry fun release_escrow(
        operator: &signer,
        token_id: String,
    ) acquires EscrowBook {
        let owner = signer::address_of(operator);
        let book = borrow_global_mut<EscrowBook>(owner);
        assert!(table::contains(&book.positions, copy token_id), E_ESCROW_NOT_FOUND);
        let _position = table::remove(&mut book.positions, token_id);
    }
}
