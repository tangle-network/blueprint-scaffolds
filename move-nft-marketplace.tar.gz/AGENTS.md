# AGENTS.md

## Goal

Build an NFT marketplace on Aptos using Move. Minting, listing, buying, collection management.

## Stack

- Family: `move-contracts`
- Layers: `capability:move-nft`

## Entry Points

- `Move.toml`
- `sources/TreasuryVault.move`
- `tests/TreasuryVaultTests.move`

## Commands

- `aptos move test`
- `sui move test`

## Build Plan

Components: CollectionManager, ListingModule, AuctionModule
Data models: Collection, Token, Listing, Bid
Integrations: Aptos Token V2 standard

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
