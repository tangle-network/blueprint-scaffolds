export const LENDING_POOL_ABI = [
  "function supply(address asset, uint256 amount, address onBehalfOf, uint16 referralCode) external",
  "function borrow(address asset, uint256 amount, uint256 interestRateMode, uint16 referralCode, address onBehalfOf) external",
  "function repay(address asset, uint256 amount, uint256 interestRateMode, address onBehalfOf) external returns (uint256)",
  "function withdraw(address asset, uint256 amount, address to) external returns (uint256)",
  "function liquidationCall(address collateralAsset, address debtAsset, address user, uint256 debtToCover, bool receiveAToken) external",
  "function getReserveData(address asset) external view returns (tuple(uint256 configuration, uint128 liquidityIndex, uint128 variableBorrowIndex, uint128 currentLiquidityRate, uint128 currentVariableBorrowRate, uint40 lastUpdateTimestamp, address aTokenAddress, address variableDebtTokenAddress, address interestRateStrategyAddress))",
  "function getUserAccountData(address user) external view returns (uint256 totalCollateralBase, uint256 totalDebtBase, uint256 availableBorrowsBase, uint256 currentLiquidationThreshold, uint256 ltv, uint256 healthFactor)",
  "function setUserEMode(uint8 categoryId) external",
  "function initReserve(address asset, address aTokenAddress, address variableDebtTokenAddress, address interestRateStrategyAddress, uint256 ltv, uint256 liquidationThreshold, uint256 liquidationBonus, uint256 reserveFactor) external",
  "event Supply(address indexed asset, address indexed user, uint256 amount)",
  "event Borrow(address indexed asset, address indexed user, uint256 amount)",
  "event Repay(address indexed asset, address indexed user, uint256 amount)",
  "event Withdraw(address indexed asset, address indexed user, uint256 amount)",
  "event LiquidationCall(address indexed collateral, address indexed debt, address indexed user, uint256 debtToCover)",
] as const

export const PRICE_ORACLE_ABI = [
  "function getAssetPrice(address asset) external view returns (uint256)",
  "function getAssetsPrices(address[] calldata assets) external view returns (uint256[] memory)",
  "function setAssetPrice(address asset, uint256 price) external",
  "function setAssetPrices(address[] calldata assets, uint256[] calldata prices) external",
  "event AssetPriceUpdated(address indexed asset, uint256 price)",
] as const

export const INTEREST_RATE_STRATEGY_ABI = [
  "function calculateInterestRates(uint256 availableLiquidity, uint256 totalVariableDebt, uint256 configuration) external view returns (uint256 currentBorrowRate, uint256 currentSupplyRate)",
] as const

export const FLASH_LOAN_ABI = [
  "function flashLoan(address receiverAddress, address[] calldata assets, uint256[] calldata amounts, uint256[] calldata interestRateModes, address onBehalfOf, bytes calldata params, uint16 referralCode) external",
  "event FlashLoan(address indexed target, address indexed initiator, address indexed asset, uint256 amount, uint256 premium)",
] as const

export const CREDIT_DELEGATION_ABI = [
  "function approveDelegation(address delegatee, uint256 amount, address asset) external",
  "function borrowWithDelegation(address asset, uint256 amount, uint256 interestRateMode, uint16 referralCode) external",
  "function delegationAllowance(address delegator, address delegatee, address asset) external view returns (uint256)",
  "event DelegationApproved(address indexed delegator, address indexed delegatee, address indexed asset, uint256 amount)",
  "event DelegatedBorrow(address indexed delegator, address indexed borrower, address indexed asset, uint256 amount)",
] as const

export const ISOLATED_POOL_ABI = [
  "function deposit(address asset, uint256 amount) external",
  "function borrow(address asset, uint256 amount) external",
  "function repay(address asset, uint256 amount) external",
  "function withdraw(address asset, uint256 amount) external",
  "function getPoolData() external view returns (uint256 totalCollateral, uint256 totalDebt, uint256 collateralFactor, uint256 borrowRate)",
  "event Deposit(address indexed user, address indexed asset, uint256 amount)",
  "event Borrow(address indexed user, address indexed asset, uint256 amount)",
] as const

export const ERC20_ABI = [
  "function approve(address spender, uint256 amount) external returns (bool)",
  "function allowance(address owner, address spender) external view returns (uint256)",
  "function balanceOf(address account) external view returns (uint256)",
  "function transfer(address to, uint256 amount) external returns (bool)",
  "function decimals() external view returns (uint8)",
  "function symbol() external view returns (string)",
] as const
