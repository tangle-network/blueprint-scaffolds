import { BrowserRouter, Routes, Route } from "react-router-dom"
import { Header } from "@/components/Header"
import DashboardPage from "@/pages/DashboardPage"
import MarketsPage from "@/pages/MarketsPage"
import PortfolioPage from "@/pages/PortfolioPage"
import AdvancedPage from "@/pages/AdvancedPage"

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-background text-foreground">
        <Header />

        <main className="container mx-auto px-4 py-6">
          <Routes>
            <Route path="/" element={<DashboardPage />} />
            <Route path="/markets" element={<MarketsPage />} />
            <Route path="/portfolio" element={<PortfolioPage />} />
            <Route path="/advanced" element={<AdvancedPage />} />
          </Routes>
        </main>

        <footer className="border-t border-border/50 mt-12">
          <div className="container mx-auto px-4 py-6 flex items-center justify-between text-sm text-muted-foreground">
            <span>LendX Protocol v1.0</span>
            <div className="flex gap-4">
              <span>Docs</span>
              <span>Governance</span>
              <span>Audit</span>
            </div>
          </div>
        </footer>
      </div>
    </BrowserRouter>
  )
}
