import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { EMODE_CATEGORIES, TOKENS, MARKET_DATA, type TokenSymbol } from "@/lib/constants"

export function EModePanel({ connected }: { connected: boolean }) {
  const [activeCategory, setActiveCategory] = useState<0 | 1>(0)

  const stablecoins: TokenSymbol[] = ["USDC", "DAI", "USDT"]

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg">E-Mode (Efficiency Mode)</CardTitle>
            <CardDescription>Higher LTV for correlated assets</CardDescription>
          </div>
          <Badge variant="outline">Advanced</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          {(Object.entries(EMODE_CATEGORIES) as [string, typeof EMODE_CATEGORIES[0]][]).map(([key, cat]) => (
            <button
              key={key}
              onClick={() => setActiveCategory(Number(key) as 0 | 1)}
              className={`p-4 rounded-lg border text-left transition-colors ${
                activeCategory === Number(key)
                  ? "border-primary bg-primary/10"
                  : "border-border hover:border-primary/50"
              }`}
            >
              <div className="font-medium">{cat.label || "None"}</div>
              {Number(key) !== 0 && (
                <div className="mt-2 space-y-1 text-sm text-muted-foreground">
                  <div>LTV: <span className="text-foreground">{cat.ltv}%</span></div>
                  <div>Liq. Threshold: <span className="text-foreground">{cat.liquidationThreshold}%</span></div>
                  <div>Liq. Bonus: <span className="text-foreground">{cat.liquidationBonus}%</span></div>
                </div>
              )}
            </button>
          ))}
        </div>

        {activeCategory === 1 && (
          <div className="bg-secondary/30 rounded-lg p-4">
            <h4 className="font-medium mb-3">Eligible Assets (Stablecoins)</h4>
            <div className="flex gap-3">
              {stablecoins.map((sym) => (
                <div key={sym} className="flex items-center gap-2 bg-secondary/50 rounded-lg px-3 py-2">
                  <span>{TOKENS[sym].icon}</span>
                  <div>
                    <div className="text-sm font-medium">{sym}</div>
                    <div className="text-xs text-muted-foreground">
                      LTV: {MARKET_DATA[sym].ltv}% &rarr; {EMODE_CATEGORIES[1].ltv}%
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <Button
          className="w-full"
          disabled={!connected || activeCategory === 0}
          onClick={() => alert(`Enable E-Mode: ${EMODE_CATEGORIES[activeCategory].label} (demo)`)}
        >
          {activeCategory === 0 ? "Select a Category" : `Enable ${EMODE_CATEGORIES[activeCategory].label} E-Mode`}
        </Button>
      </CardContent>
    </Card>
  )
}
