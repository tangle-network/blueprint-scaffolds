import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { formatUSD, formatAPY } from "@/lib/utils"

const POOLS = [
  { name: "ETH/USDC Vault", collateral: "ETH", borrow: "USDC", collateralFactor: 75, tvl: 12_400_000, borrowAPY: 0.0482 },
  { name: "WBTC/DAI Vault", collateral: "WBTC", borrow: "DAI", collateralFactor: 70, tvl: 5_800_000, borrowAPY: 0.0523 },
  { name: "ETH/USDT Vault", collateral: "ETH", borrow: "USDT", collateralFactor: 75, tvl: 8_200_000, borrowAPY: 0.0445 },
]

export function IsolatedPoolsPanel({ connected }: { connected: boolean }) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg">Isolated Pools</CardTitle>
            <CardDescription>Single collateral / single borrow pools with isolated risk</CardDescription>
          </div>
          <Badge variant="outline">Pools</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {POOLS.map((pool, i) => (
          <div key={i} className="bg-secondary/30 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-medium">{pool.name}</span>
              <Badge variant="secondary">CF: {pool.collateralFactor}%</Badge>
            </div>
            <div className="grid grid-cols-3 gap-3 text-sm">
              <div>
                <div className="text-muted-foreground">TVL</div>
                <div className="font-mono">{formatUSD(pool.tvl)}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Borrow APY</div>
                <div className="font-mono text-orange-400">{formatAPY(pool.borrowAPY)}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Risk</div>
                <div className="text-yellow-500">Isolated</div>
              </div>
            </div>
            <div className="flex gap-2">
              <Button size="sm" className="flex-1" disabled={!connected} onClick={() => alert(`Deposit to ${pool.name} (demo)`)}>
                Deposit
              </Button>
              <Button size="sm" variant="outline" className="flex-1" disabled={!connected} onClick={() => alert(`Borrow from ${pool.name} (demo)`)}>
                Borrow
              </Button>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
