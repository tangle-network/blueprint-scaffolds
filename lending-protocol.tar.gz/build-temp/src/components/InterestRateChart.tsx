import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { INTEREST_RATE_PARAMS } from "@/lib/constants"
import { generateUtilizationCurve } from "@/lib/protocols"

export function InterestRateChart() {
  const { optimalUtilization, baseBorrowRate, slope1, slope2 } = INTEREST_RATE_PARAMS
  const curve = generateUtilizationCurve(optimalUtilization, baseBorrowRate, slope1, slope2, 0.1)

  const width = 500
  const height = 280
  const padding = { top: 20, right: 20, bottom: 40, left: 50 }
  const plotW = width - padding.left - padding.right
  const plotH = height - padding.top - padding.bottom

  const maxRate = Math.max(...curve.map((d) => d.borrowRate))

  const scaleX = (u: number) => padding.left + u * plotW
  const scaleY = (rate: number) => padding.top + plotH - (rate / maxRate) * plotH

  const borrowPath = curve
    .map((d, i) => `${i === 0 ? "M" : "L"} ${scaleX(d.utilization).toFixed(1)} ${scaleY(d.borrowRate).toFixed(1)}`)
    .join(" ")

  const supplyPath = curve
    .map((d, i) => `${i === 0 ? "M" : "L"} ${scaleX(d.utilization).toFixed(1)} ${scaleY(d.supplyRate).toFixed(1)}`)
    .join(" ")

  const optimalX = scaleX(optimalUtilization)

  const xTicks = [0, 0.2, 0.4, 0.6, 0.8, 1.0]
  const yTicks = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8]

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Interest Rate Model</CardTitle>
        <CardDescription>Utilization-based variable rate with kink at {optimalUtilization * 100}%</CardDescription>
      </CardHeader>
      <CardContent>
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto">
          <line x1={padding.left} y1={padding.top} x2={padding.left} y2={padding.top + plotH} stroke="hsl(217, 33%, 17%)" />
          <line x1={padding.left} y1={padding.top + plotH} x2={padding.left + plotW} y2={padding.top + plotH} stroke="hsl(217, 33%, 17%)" />

          {xTicks.map((u) => (
            <g key={`x-${u}`}>
              <line x1={scaleX(u)} y1={padding.top} x2={scaleX(u)} y2={padding.top + plotH} stroke="hsl(217, 33%, 12%)" />
              <text x={scaleX(u)} y={height - 8} textAnchor="middle" fill="hsl(215, 20%, 65%)" fontSize="10">
                {(u * 100).toFixed(0)}%
              </text>
            </g>
          ))}

          {yTicks.map((r) => (
            <g key={`y-${r}`}>
              <line x1={padding.left} y1={scaleY(r)} x2={padding.left + plotW} y2={scaleY(r)} stroke="hsl(217, 33%, 12%)" />
              <text x={padding.left - 8} y={scaleY(r) + 4} textAnchor="end" fill="hsl(215, 20%, 65%)" fontSize="10">
                {(r * 100).toFixed(0)}%
              </text>
            </g>
          ))}

          <line x1={optimalX} y1={padding.top} x2={optimalX} y2={padding.top + plotH} stroke="hsl(217, 91%, 60%)" strokeDasharray="4 4" opacity="0.4" />

          <text x={optimalX} y={padding.top - 5} textAnchor="middle" fill="hsl(217, 91%, 60%)" fontSize="9">
            Optimal
          </text>

          <path d={borrowPath} fill="none" stroke="hsl(30, 90%, 55%)" strokeWidth="2.5" />
          <path d={supplyPath} fill="none" stroke="hsl(140, 70%, 50%)" strokeWidth="2.5" />

          <g transform={`translate(${width - 120}, ${padding.top + 10})`}>
            <rect x="0" y="0" width="100" height="40" rx="4" fill="hsl(222, 47%, 8%)" opacity="0.9" />
            <line x1="8" y1="14" x2="28" y2="14" stroke="hsl(30, 90%, 55%)" strokeWidth="2.5" />
            <text x="34" y="18" fill="hsl(30, 90%, 55%)" fontSize="10">Borrow</text>
            <line x1="8" y1="30" x2="28" y2="30" stroke="hsl(140, 70%, 50%)" strokeWidth="2.5" />
            <text x="34" y="34" fill="hsl(140, 70%, 50%)" fontSize="10">Supply</text>
          </g>

          <text x={width / 2} y={height - 2} textAnchor="middle" fill="hsl(215, 20%, 65%)" fontSize="10">
            Utilization Rate
          </text>
          <text x={8} y={height / 2} textAnchor="middle" fill="hsl(215, 20%, 65%)" fontSize="10" transform={`rotate(-90, 8, ${height / 2})`}>
            APY
          </text>
        </svg>
      </CardContent>
    </Card>
  )
}
