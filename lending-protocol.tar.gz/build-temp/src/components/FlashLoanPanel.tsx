import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { TOKENS, type TokenSymbol } from "@/lib/constants"

const tokenSymbols = Object.keys(TOKENS) as TokenSymbol[]

export function FlashLoanPanel({ connected }: { connected: boolean }) {
  const [asset, setAsset] = useState<TokenSymbol>("USDC")
  const [amount, setAmount] = useState("")

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg">Flash Loans</CardTitle>
            <CardDescription>Borrow and repay in a single transaction — 0.05% fee</CardDescription>
          </div>
          <Badge className="bg-purple-500/10 text-purple-400 border-purple-500/20">Instant</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <label className="text-sm text-muted-foreground mb-1.5 block">Asset</label>
          <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
            {tokenSymbols.map((sym) => (
              <button
                key={sym}
                onClick={() => setAsset(sym)}
                className={`flex items-center justify-center gap-1 px-3 py-2 rounded-lg border text-sm transition-colors ${
                  asset === sym ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"
                }`}
              >
                <span>{TOKENS[sym].icon}</span>
                {sym}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="text-sm text-muted-foreground mb-1.5 block">Amount</label>
          <Input
            type="number"
            placeholder="0.00"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="font-mono"
          />
        </div>

        <div className="bg-secondary/30 rounded-lg p-3 space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Fee (0.05%)</span>
            <span>{amount ? (parseFloat(amount) * 0.0005).toFixed(2) : "0.00"} {TOKENS[asset].symbol}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Total Repayment</span>
            <span>{amount ? (parseFloat(amount) * 1.0005).toFixed(2) : "0.00"} {TOKENS[asset].symbol}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Execution</span>
            <span>Single transaction</span>
          </div>
        </div>

        <Button
          className="w-full"
          disabled={!connected || !amount}
          onClick={() => alert(`Flash loan ${amount} ${TOKENS[asset].symbol} (demo)`)}
        >
          {!connected ? "Connect Wallet" : !amount ? "Enter Amount" : "Execute Flash Loan"}
        </Button>
      </CardContent>
    </Card>
  )
}
