import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { TOKENS, MARKET_DATA, type TokenSymbol } from "@/lib/constants"
import { formatNumber, formatUSD, formatAPY } from "@/lib/utils"

export function MarketOverview() {
  const tokenSymbols = Object.keys(TOKENS) as TokenSymbol[]

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Markets</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border/50 text-muted-foreground">
                <th className="text-left pb-3 font-medium">Asset</th>
                <th className="text-right pb-3 font-medium">Total Deposits</th>
                <th className="text-right pb-3 font-medium">Total Borrows</th>
                <th className="text-right pb-3 font-medium">Supply APY</th>
                <th className="text-right pb-3 font-medium">Borrow APY</th>
                <th className="text-right pb-3 font-medium">Utilization</th>
                <th className="text-right pb-3 font-medium">LTV</th>
              </tr>
            </thead>
            <tbody>
              {tokenSymbols.map((sym) => {
                const token = TOKENS[sym]
                const market = MARKET_DATA[sym]
                return (
                  <tr key={sym} className="border-b border-border/30 hover:bg-secondary/20 transition-colors">
                    <td className="py-3">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{token.icon}</span>
                        <div>
                          <div className="font-medium">{token.symbol}</div>
                          <div className="text-xs text-muted-foreground">{token.name}</div>
                        </div>
                      </div>
                    </td>
                    <td className="text-right py-3 font-mono">{formatUSD(market.totalDeposits)}</td>
                    <td className="text-right py-3 font-mono">{formatUSD(market.totalBorrows)}</td>
                    <td className="text-right py-3">
                      <span className="text-green-400 font-mono">{formatAPY(market.supplyAPY)}</span>
                    </td>
                    <td className="text-right py-3">
                      <span className="text-orange-400 font-mono">{formatAPY(market.borrowAPY)}</span>
                    </td>
                    <td className="text-right py-3">
                      <div className="flex items-center justify-end gap-2">
                        <Progress value={market.utilization * 100} className="w-16 h-2" />
                        <span className="font-mono text-xs">{(market.utilization * 100).toFixed(0)}%</span>
                      </div>
                    </td>
                    <td className="text-right py-3">
                      <Badge variant="secondary">{market.ltv}%</Badge>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  )
}
