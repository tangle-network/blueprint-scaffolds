import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { TOKENS, type TokenSymbol } from "@/lib/constants"
import { formatAddress } from "@/lib/utils"

export function CreditDelegationPanel({ connected }: { connected: boolean }) {
  const [delegatee, setDelegatee] = useState("")
  const [amount, setAmount] = useState("")
  const [asset, setAsset] = useState<TokenSymbol>("USDC")

  const delegations = [
    { delegatee: "0x3f8a...b2C4", asset: "USDC" as TokenSymbol, amount: 50000, used: 12000 },
    { delegatee: "0x7d1e...a9F3", asset: "DAI" as TokenSymbol, amount: 25000, used: 0 },
  ]

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg">Credit Delegation</CardTitle>
            <CardDescription>Delegate your borrowing power to trusted addresses</CardDescription>
          </div>
          <Badge variant="outline">Governance</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {delegations.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium">Active Delegations</h4>
            {delegations.map((d, i) => (
              <div key={i} className="bg-secondary/30 rounded-lg p-3 flex items-center justify-between text-sm">
                <div>
                  <div className="font-mono">{d.delegatee}</div>
                  <div className="text-muted-foreground">
                    {d.used.toLocaleString()} / {d.amount.toLocaleString()} {d.asset} used
                  </div>
                </div>
                <Badge variant="secondary">{TOKENS[d.asset].icon} {d.asset}</Badge>
              </div>
            ))}
          </div>
        )}

        <div className="border-t border-border/50 pt-4 space-y-3">
          <h4 className="text-sm font-medium">New Delegation</h4>
          <div>
            <label className="text-sm text-muted-foreground mb-1.5 block">Delegatee Address</label>
            <Input
              placeholder="0x..."
              value={delegatee}
              onChange={(e) => setDelegatee(e.target.value)}
              className="font-mono"
            />
          </div>
          <div>
            <label className="text-sm text-muted-foreground mb-1.5 block">Asset</label>
            <div className="flex gap-2">
              {(["USDC", "DAI", "USDT"] as TokenSymbol[]).map((sym) => (
                <button
                  key={sym}
                  onClick={() => setAsset(sym)}
                  className={`px-3 py-1.5 rounded-lg border text-sm ${
                    asset === sym ? "border-primary bg-primary/10" : "border-border"
                  }`}
                >
                  {TOKENS[sym].icon} {sym}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="text-sm text-muted-foreground mb-1.5 block">Amount</label>
            <Input
              type="number"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="font-mono"
            />
          </div>
          <Button
            className="w-full"
            disabled={!connected || !delegatee || !amount}
            onClick={() => alert(`Delegate ${amount} ${asset} to ${delegatee} (demo)`)}
          >
            Approve Delegation
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
