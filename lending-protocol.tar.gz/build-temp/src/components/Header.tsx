import { useState } from "react"
import { NavLink } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { formatAddress } from "@/lib/utils"

const NAV_ITEMS = [
  { to: "/", label: "Dashboard" },
  { to: "/markets", label: "Markets" },
  { to: "/portfolio", label: "Portfolio" },
  { to: "/advanced", label: "Advanced" },
]

export function Header() {
  const [connected, setConnected] = useState(false)
  const [account, setAccount] = useState<string | null>(null)

  const handleConnect = () => {
    setConnected(true)
    setAccount("0x742d35Cc6634C0532925a3b844Bc9e7595f2bD18")
  }

  return (
    <>
      <header className="border-b border-border/50 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center font-bold text-primary-foreground">
              Lx
            </div>
            <span className="text-xl font-bold tracking-tight">LendX Protocol</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-1 text-sm text-muted-foreground bg-secondary/50 rounded-full px-3 py-1">
              <div className="w-2 h-2 rounded-full bg-green-500" />
              Ethereum Mainnet
            </div>
            {connected && account ? (
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">{formatAddress(account)}</span>
                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-xs text-primary font-mono">
                  {account.slice(2, 4).toUpperCase()}
                </div>
              </div>
            ) : (
              <Button onClick={handleConnect} size="sm">
                Connect Wallet
              </Button>
            )}
          </div>
        </div>
      </header>

      <nav className="border-b border-border/50 bg-card/30">
        <div className="container mx-auto px-4">
          <div className="flex gap-1">
            {NAV_ITEMS.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === "/"}
                className={({ isActive }) =>
                  `px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                    isActive
                      ? "border-primary text-primary"
                      : "border-transparent text-muted-foreground hover:text-foreground"
                  }`
                }
              >
                {item.label}
              </NavLink>
            ))}
          </div>
        </div>
      </nav>
    </>
  )
}
