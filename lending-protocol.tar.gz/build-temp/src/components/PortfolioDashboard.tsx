import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MOCK_PORTFOLIO, TOKENS, MARKET_DATA, type TokenSymbol } from "@/lib/constants"
import { formatUSD, formatAPY, healthFactorStatus } from "@/lib/utils"

export function PortfolioDashboard({ connected }: { connected: boolean }) {
  if (!connected) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-muted-foreground">
          Connect your wallet to view your portfolio
        </CardContent>
      </Card>
    )
  }

  const hf = healthFactorStatus(MOCK_PORTFOLIO.healthFactor)

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-muted-foreground">Total Supplied</div>
            <div className="text-2xl font-bold font-mono text-green-400">
              {formatUSD(MOCK_PORTFOLIO.totalSupplyUSD)}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-muted-foreground">Total Borrowed</div>
            <div className="text-2xl font-bold font-mono text-orange-400">
              {formatUSD(MOCK_PORTFOLIO.totalBorrowUSD)}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-muted-foreground">Net Worth</div>
            <div className="text-2xl font-bold font-mono">{formatUSD(MOCK_PORTFOLIO.netWorth)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-muted-foreground">Health Factor</div>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold font-mono">{MOCK_PORTFOLIO.healthFactor.toFixed(2)}</span>
              <Badge variant="secondary" className={hf.color}>
                {hf.label}
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Your Positions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border/50 text-muted-foreground">
                  <th className="text-left pb-3 font-medium">Asset</th>
                  <th className="text-right pb-3 font-medium">Supplied</th>
                  <th className="text-right pb-3 font-medium">Borrowed</th>
                  <th className="text-center pb-3 font-medium">Collateral</th>
                  <th className="text-right pb-3 font-medium">Supply APY</th>
                  <th className="text-right pb-3 font-medium">Borrow APY</th>
                  <th className="text-right pb-3 font-medium">Net Value</th>
                </tr>
              </thead>
              <tbody>
                {MOCK_PORTFOLIO.positions.map((pos) => {
                  const token = TOKENS[pos.symbol]
                  const market = MARKET_DATA[pos.symbol]
                  const isPositive = pos.valueUSD >= 0
                  return (
                    <tr key={pos.symbol} className="border-b border-border/30">
                      <td className="py-3">
                        <div className="flex items-center gap-2">
                          <span className="text-lg">{token.icon}</span>
                          <span className="font-medium">{pos.symbol}</span>
                        </div>
                      </td>
                      <td className="text-right py-3 font-mono">
                        {pos.supplied > 0 ? pos.supplied.toLocaleString() : "-"}
                      </td>
                      <td className="text-right py-3 font-mono">
                        {pos.borrowed > 0 ? pos.borrowed.toLocaleString() : "-"}
                      </td>
                      <td className="text-center py-3">
                        {pos.collateral ? (
                          <Badge className="bg-green-500/10 text-green-400 border-green-500/20">ON</Badge>
                        ) : (
                          <span className="text-muted-foreground">OFF</span>
                        )}
                      </td>
                      <td className="text-right py-3 text-green-400 font-mono">{formatAPY(market.supplyAPY)}</td>
                      <td className="text-right py-3 text-orange-400 font-mono">
                        {pos.borrowed > 0 ? formatAPY(market.borrowAPY) : "-"}
                      </td>
                      <td className={`text-right py-3 font-mono font-medium ${isPositive ? "text-green-400" : "text-red-400"}`}>
                        {isPositive ? "+" : ""}{formatUSD(pos.valueUSD)}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
