import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { TOKENS, MARKET_DATA, type TokenSymbol } from "@/lib/constants"
import { formatAPY, formatUSD } from "@/lib/utils"

type Tab = "supply" | "borrow"

export function SupplyBorrowPanel({ connected }: { connected: boolean }) {
  const [tab, setTab] = useState<Tab>("supply")
  const [selectedToken, setSelectedToken] = useState<TokenSymbol>("ETH")
  const [amount, setAmount] = useState("")
  const tokenSymbols = Object.keys(TOKENS) as TokenSymbol[]
  const token = TOKENS[selectedToken]
  const market = MARKET_DATA[selectedToken]

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Supply & Borrow</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex rounded-lg bg-secondary/50 p-1">
          <button
            className={`flex-1 py-2 text-sm font-medium rounded-md transition-colors ${tab === "supply" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
            onClick={() => setTab("supply")}
          >
            Supply
          </button>
          <button
            className={`flex-1 py-2 text-sm font-medium rounded-md transition-colors ${tab === "borrow" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
            onClick={() => setTab("borrow")}
          >
            Borrow
          </button>
        </div>

        <div>
          <label className="text-sm text-muted-foreground mb-1.5 block">
            {tab === "supply" ? "Supply" : "Borrow"} Asset
          </label>
          <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
            {tokenSymbols.map((sym) => (
              <button
                key={sym}
                onClick={() => setSelectedToken(sym)}
                className={`flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg border text-sm transition-colors ${
                  selectedToken === sym
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border hover:border-primary/50"
                }`}
              >
                <span>{TOKENS[sym].icon}</span>
                {sym}
              </button>
            ))}
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-sm text-muted-foreground">Amount</label>
            <span className="text-xs text-muted-foreground">
              {tab === "supply" ? "Wallet:" : "Available:"}{" "}
              {tab === "supply" ? "12.5 ETH" : formatUSD(45_000)}
            </span>
          </div>
          <div className="relative">
            <Input
              type="number"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="pr-20 font-mono text-lg"
            />
            <button
              className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-primary font-medium px-2 py-1 rounded bg-primary/10 hover:bg-primary/20"
              onClick={() => setAmount(tab === "supply" ? "12.5" : "1000")}
            >
              MAX
            </button>
          </div>
        </div>

        <div className="bg-secondary/30 rounded-lg p-3 space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">{tab === "supply" ? "Supply" : "Borrow"} APY</span>
            <span className={tab === "supply" ? "text-green-400" : "text-orange-400"}>
              {formatAPY(tab === "supply" ? market.supplyAPY : market.borrowAPY)}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Utilization</span>
            <span>{(market.utilization * 100).toFixed(1)}%</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Collateral</span>
            <span>{market.canAsCollateral ? "Yes" : "No"}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">LTV</span>
            <span>{market.ltv}%</span>
          </div>
          {tab === "borrow" && (
            <div className="flex justify-between">
              <span className="text-muted-foreground">Liquidation Threshold</span>
              <span>{market.liquidationThreshold}%</span>
            </div>
          )}
        </div>

        <Button
          className="w-full"
          disabled={!connected || !amount}
          onClick={() => alert(`${tab === "supply" ? "Supply" : "Borrow"} ${amount} ${token.symbol} (demo)`)}
        >
          {!connected
            ? "Connect Wallet"
            : !amount
              ? "Enter Amount"
              : `${tab === "supply" ? "Supply" : "Borrow"} ${token.symbol}`}
        </Button>

        {tab === "borrow" && (
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Badge variant="outline" className="text-xs">
              Variable Rate
            </Badge>
            <span>Interest rate changes based on utilization</span>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
