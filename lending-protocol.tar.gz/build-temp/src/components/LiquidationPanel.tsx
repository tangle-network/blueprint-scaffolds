import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { TOKENS, MARKET_DATA, type TokenSymbol } from "@/lib/constants"
import { formatUSD, healthFactorStatus } from "@/lib/utils"

const MOCK_LIQUIDATIONS = [
  { borrower: "0x7a3f...e2D1", collateral: "ETH" as TokenSymbol, debt: "USDC" as TokenSymbol, debtAmount: 12500, healthFactor: 0.94, bonus: 5 },
  { borrower: "0x4b8c...f9A3", collateral: "WBTC" as TokenSymbol, debt: "DAI" as TokenSymbol, debtAmount: 8700, healthFactor: 0.87, bonus: 8 },
  { borrower: "0x9d2e...c4B7", collateral: "ETH" as TokenSymbol, debt: "USDT" as TokenSymbol, debtAmount: 34200, healthFactor: 0.78, bonus: 5 },
]

export function LiquidationPanel({ connected }: { connected: boolean }) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg">Liquidations</CardTitle>
            <CardDescription>Liquidate undercollateralized positions for a bonus</CardDescription>
          </div>
          <Badge variant="destructive">Liquidation</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          {MOCK_LIQUIDATIONS.map((liq, i) => {
            const hf = healthFactorStatus(liq.healthFactor)
            const collateralToken = TOKENS[liq.collateral]
            const debtToken = TOKENS[liq.debt]
            const collateralValue = liq.debtAmount * (1 + liq.bonus / 100)
            return (
              <div key={i} className="bg-secondary/30 rounded-lg p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-sm">{liq.borrower}</span>
                  <Badge className={`${hf.color} bg-red-500/10 border-red-500/20`}>
                    HF: {liq.healthFactor.toFixed(2)}
                  </Badge>
                </div>
                <div className="grid grid-cols-3 gap-3 text-sm">
                  <div>
                    <div className="text-muted-foreground">Collateral</div>
                    <div className="flex items-center gap-1">
                      {collateralToken.icon} {liq.collateral}
                    </div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Debt</div>
                    <div className="flex items-center gap-1">
                      {debtToken.icon} {formatUSD(liq.debtAmount)}
                    </div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Bonus</div>
                    <div className="text-green-400">+{liq.bonus}%</div>
                  </div>
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>Max seize: {formatUSD(collateralValue)}</span>
                  <Button
                    size="sm"
                    variant="destructive"
                    disabled={!connected}
                    onClick={() => alert(`Liquidate ${liq.borrower} (demo)`)}
                  >
                    Liquidate
                  </Button>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
