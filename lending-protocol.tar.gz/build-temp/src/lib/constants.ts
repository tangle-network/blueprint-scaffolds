export const TOKENS = {
  ETH: {
    symbol: "ETH",
    name: "Ethereum",
    decimals: 18,
    address: "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE",
    icon: "⟠",
    priceUSD: 3245.67,
  },
  USDC: {
    symbol: "USDC",
    name: "USD Coin",
    decimals: 6,
    address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
    icon: "💵",
    priceUSD: 1.0,
  },
  DAI: {
    symbol: "DAI",
    name: "Dai Stablecoin",
    decimals: 18,
    address: "0x6B175474E89094C44Da98b954EedeAC495271d0F",
    icon: "🔸",
    priceUSD: 1.0,
  },
  WBTC: {
    symbol: "WBTC",
    name: "Wrapped Bitcoin",
    decimals: 8,
    address: "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599",
    icon: "₿",
    priceUSD: 62450.89,
  },
  USDT: {
    symbol: "USDT",
    name: "Tether USD",
    decimals: 6,
    address: "0xdAC17F958D2ee523a2206206994597C13D831ec7",
    icon: "💲",
    priceUSD: 1.0,
  },
} as const

export type TokenSymbol = keyof typeof TOKENS

export const MARKET_DATA: Record<
  TokenSymbol,
  {
    totalDeposits: number
    totalBorrows: number
    supplyAPY: number
    borrowAPY: number
    utilization: number
    ltv: number
    liquidationThreshold: number
    liquidationBonus: number
    reserveFactor: number
    canAsCollateral: boolean
    canBorrow: boolean
    eModeCategory: number
  }
> = {
  ETH: {
    totalDeposits: 45_200_000,
    totalBorrows: 28_100_000,
    supplyAPY: 0.0324,
    borrowAPY: 0.0456,
    utilization: 0.62,
    ltv: 80,
    liquidationThreshold: 82.5,
    liquidationBonus: 105,
    reserveFactor: 10,
    canAsCollateral: true,
    canBorrow: true,
    eModeCategory: 0,
  },
  USDC: {
    totalDeposits: 125_800_000,
    totalBorrows: 89_300_000,
    supplyAPY: 0.0589,
    borrowAPY: 0.0712,
    utilization: 0.71,
    ltv: 85,
    liquidationThreshold: 88,
    liquidationBonus: 103,
    reserveFactor: 10,
    canAsCollateral: true,
    canBorrow: true,
    eModeCategory: 1,
  },
  DAI: {
    totalDeposits: 67_400_000,
    totalBorrows: 42_800_000,
    supplyAPY: 0.0467,
    borrowAPY: 0.0589,
    utilization: 0.635,
    ltv: 85,
    liquidationThreshold: 88,
    liquidationBonus: 103,
    reserveFactor: 10,
    canAsCollateral: true,
    canBorrow: true,
    eModeCategory: 1,
  },
  WBTC: {
    totalDeposits: 1_240_000,
    totalBorrows: 680_000,
    supplyAPY: 0.0198,
    borrowAPY: 0.0312,
    utilization: 0.55,
    ltv: 70,
    liquidationThreshold: 75,
    liquidationBonus: 108,
    reserveFactor: 20,
    canAsCollateral: true,
    canBorrow: true,
    eModeCategory: 0,
  },
  USDT: {
    totalDeposits: 98_600_000,
    totalBorrows: 71_200_000,
    supplyAPY: 0.0523,
    borrowAPY: 0.0634,
    utilization: 0.72,
    ltv: 85,
    liquidationThreshold: 88,
    liquidationBonus: 103,
    reserveFactor: 10,
    canAsCollateral: true,
    canBorrow: true,
    eModeCategory: 1,
  },
}

export const EMODE_CATEGORIES = {
  0: { label: "None", ltv: 0, liquidationThreshold: 0, liquidationBonus: 0 },
  1: {
    label: "Stablecoins",
    ltv: 97,
    liquidationThreshold: 97.5,
    liquidationBonus: 100.5,
  },
} as const

export const MOCK_PORTFOLIO = {
  totalSupplyUSD: 124_580.45,
  totalBorrowUSD: 42_320.18,
  healthFactor: 2.84,
  netWorth: 82_260.27,
  positions: [
    { symbol: "ETH" as TokenSymbol, supplied: 12.5, borrowed: 0, collateral: true, valueUSD: 40_570.88 },
    { symbol: "USDC" as TokenSymbol, supplied: 45_000, borrowed: 15_000, collateral: true, valueUSD: 30_000 },
    { symbol: "DAI" as TokenSymbol, supplied: 0, borrowed: 12_500, collateral: false, valueUSD: -12_500 },
    { symbol: "WBTC" as TokenSymbol, supplied: 0.35, borrowed: 0, collateral: true, valueUSD: 21_857.81 },
    { symbol: "USDT" as TokenSymbol, supplied: 25_000, borrowed: 14_820.18, collateral: true, valueUSD: 10_179.82 },
  ],
}

export const CHAINS = {
  1: { name: "Ethereum Mainnet", currency: "ETH" },
  5: { name: "Goerli Testnet", currency: "ETH" },
  11155111: { name: "Sepolia Testnet", currency: "ETH" },
} as const

export const INTEREST_RATE_PARAMS = {
  optimalUtilization: 0.8,
  baseBorrowRate: 0.02,
  slope1: 0.04,
  slope2: 0.75,
}
