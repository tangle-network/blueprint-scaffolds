export interface ReserveData {
  asset: string
  symbol: string
  decimals: number
  liquidityIndex: string
  variableBorrowIndex: string
  currentLiquidityRate: string
  currentVariableBorrowRate: string
  lastUpdateTimestamp: number
  aTokenAddress: string
  variableDebtTokenAddress: string
  interestRateStrategyAddress: string
}

export interface UserAccountData {
  totalCollateralBase: string
  totalDebtBase: string
  availableBorrowsBase: string
  currentLiquidationThreshold: string
  ltv: string
  healthFactor: string
}

export interface UserReserveData {
  scaledATokenBalance: string
  scaledVariableDebtBalance: string
  usageAsCollateralEnabled: boolean
}

export interface EModeCategory {
  ltv: number
  liquidationThreshold: number
  liquidationBonus: number
  label: string
}

export interface LiquidationOpportunity {
  borrower: string
  collateralAsset: string
  debtAsset: string
  debtAmount: number
  collateralSeized: number
  bonus: number
  healthFactor: number
}

export interface FlashLoanRequest {
  asset: string
  amount: number
  params: string
}

export interface CreditDelegation {
  delegator: string
  delegatee: string
  asset: string
  amount: number
  expiry: number
}

export interface IsolatedPool {
  name: string
  collateralAsset: string
  borrowAsset: string
  collateralFactor: number
  tvl: number
  borrowAPY: number
}

export function calculateUtilizationRate(totalDebt: number, totalLiquidity: number): number {
  if (totalLiquidity === 0) return 0
  return totalDebt / totalLiquidity
}

export function calculateBorrowRate(
  utilization: number,
  optimalUtilization: number,
  baseRate: number,
  slope1: number,
  slope2: number
): number {
  if (utilization < optimalUtilization) {
    return baseRate + (utilization * slope1) / optimalUtilization
  }
  const excessUtilization = utilization - optimalUtilization
  const maxExcess = 1 - optimalUtilization
  return baseRate + slope1 + (excessUtilization * slope2) / maxExcess
}

export function calculateSupplyRate(
  borrowRate: number,
  utilization: number,
  reserveFactor: number
): number {
  return (borrowRate * utilization * (1 - reserveFactor))
}

export function generateUtilizationCurve(
  optimalUtilization: number,
  baseRate: number,
  slope1: number,
  slope2: number,
  reserveFactor: number,
  points = 100
): { utilization: number; borrowRate: number; supplyRate: number }[] {
  const curve: { utilization: number; borrowRate: number; supplyRate: number }[] = []
  for (let i = 0; i <= points; i++) {
    const u = i / points
    const borrowRate = calculateBorrowRate(u, optimalUtilization, baseRate, slope1, slope2)
    const supplyRate = calculateSupplyRate(borrowRate, u, reserveFactor)
    curve.push({ utilization: u, borrowRate, supplyRate })
  }
  return curve
}
