export interface TokenInfo {
  symbol: string
  name: string
  decimals: number
  address: string
  icon: string
  priceUSD: number
}

export interface MarketData {
  totalDeposits: number
  totalBorrows: number
  supplyAPY: number
  borrowAPY: number
  utilization: number
  ltv: number
  liquidationThreshold: number
  liquidationBonus: number
  reserveFactor: number
  canAsCollateral: boolean
  canBorrow: boolean
  eModeCategory: number
}

export interface PortfolioPosition {
  symbol: string
  supplied: number
  borrowed: number
  collateral: boolean
  valueUSD: number
}

export interface PortfolioSummary {
  totalSupplyUSD: number
  totalBorrowUSD: number
  healthFactor: number
  netWorth: number
  positions: PortfolioPosition[]
}

export interface EModeCategoryInfo {
  label: string
  ltv: number
  liquidationThreshold: number
  liquidationBonus: number
}

export interface LiquidationOpportunity {
  borrower: string
  collateralAsset: string
  debtAsset: string
  debtAmount: number
  collateralSeized: number
  bonus: number
  healthFactor: number
}

export interface FlashLoanParams {
  asset: string
  amount: number
  fee: number
}

export interface CreditDelegationEntry {
  delegator: string
  delegatee: string
  asset: string
  amount: number
  used: number
  expiry: number
}

export interface IsolatedPoolInfo {
  name: string
  collateralAsset: string
  borrowAsset: string
  collateralFactor: number
  tvl: number
  borrowAPY: number
}

export interface InterestRateModel {
  optimalUtilization: number
  baseBorrowRate: number
  slope1: number
  slope2: number
}

export interface ReserveData {
  asset: string
  symbol: string
  decimals: number
  liquidityIndex: string
  variableBorrowIndex: string
  currentLiquidityRate: string
  currentVariableBorrowRate: string
  lastUpdateTimestamp: number
  aTokenAddress: string
  variableDebtTokenAddress: string
  interestRateStrategyAddress: string
}

export interface UserAccountData {
  totalCollateralBase: string
  totalDebtBase: string
  availableBorrowsBase: string
  currentLiquidationThreshold: string
  ltv: string
  healthFactor: string
}

export interface ChainInfo {
  name: string
  currency: string
}

export interface TransactionPayload {
  method: string
  args: string[]
  value?: string
}

export interface HealthFactorStatus {
  label: string
  color: string
}

export interface UtilizationPoint {
  utilization: number
  borrowRate: number
  supplyRate: number
}
