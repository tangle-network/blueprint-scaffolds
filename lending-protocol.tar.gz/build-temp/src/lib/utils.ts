import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatAddress(address: string): string {
  return `${address.slice(0, 6)}...${address.slice(-4)}`
}

export function formatNumber(value: number, decimals = 2): string {
  if (value >= 1_000_000_000) return `${(value / 1_000_000_000).toFixed(decimals)}B`
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(decimals)}M`
  if (value >= 1_000) return `${(value / 1_000).toFixed(decimals)}K`
  return value.toFixed(decimals)
}

export function formatUSD(value: number): string {
  return `$${formatNumber(value)}`
}

export function formatAPY(rate: number): string {
  return `${(rate * 100).toFixed(2)}%`
}

export function formatTokenAmount(value: bigint, decimals = 18, displayDecimals = 4): string {
  const divisor = BigInt(10 ** decimals)
  const whole = value / divisor
  const fraction = value % divisor
  const fractionStr = fraction.toString().padStart(decimals, '0').slice(0, displayDecimals)
  return `${whole}.${fractionStr}`
}

export function healthFactorStatus(hf: number): { label: string; color: string } {
  if (hf >= 3) return { label: "Safe", color: "text-green-500" }
  if (hf >= 2) return { label: "Healthy", color: "text-green-400" }
  if (hf >= 1.5) return { label: "Moderate", color: "text-yellow-500" }
  if (hf >= 1) return { label: "At Risk", color: "text-orange-500" }
  return { label: "Liquidatable", color: "text-red-500" }
}

export function calculateHealthFactor(
  totalCollateral: number,
  totalDebt: number,
  liquidationThreshold: number
): number {
  if (totalDebt === 0) return Infinity
  return (totalCollateral * liquidationThreshold) / totalDebt
}

export function secondsToReadable(seconds: number): string {
  const days = Math.floor(seconds / 86400)
  if (days > 0) return `${days}d`
  const hours = Math.floor(seconds / 3600)
  if (hours > 0) return `${hours}h`
  return `${Math.floor(seconds / 60)}m`
}
