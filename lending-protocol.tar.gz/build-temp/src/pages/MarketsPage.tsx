import { MarketOverview } from "@/components/MarketOverview"
import { InterestRateChart } from "@/components/InterestRateChart"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { TOKENS, MARKET_DATA, type TokenSymbol } from "@/lib/constants"
import { formatUSD, formatAPY } from "@/lib/utils"
import type { TokenInfo, MarketData } from "@/lib/types"

export default function MarketsPage() {
  const tokenSymbols = Object.keys(TOKENS) as TokenSymbol[]

  const topSupply = [...tokenSymbols].sort(
    (a, b) => MARKET_DATA[b].supplyAPY - MARKET_DATA[a].supplyAPY
  )
  const topBorrow = [...tokenSymbols].sort(
    (a, b) => MARKET_DATA[b].borrowAPY - MARKET_DATA[a].borrowAPY
  )

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              Top Supply Markets
              <Badge variant="secondary" className="text-green-400">Earn</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {topSupply.map((sym) => {
              const token = TOKENS[sym]
              const market = MARKET_DATA[sym]
              return (
                <div key={sym} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{token.icon}</span>
                    <div>
                      <div className="font-medium">{sym}</div>
                      <div className="text-xs text-muted-foreground">
                        Deposits: {formatUSD(market.totalDeposits)}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-mono text-green-400">{formatAPY(market.supplyAPY)}</div>
                    <div className="text-xs text-muted-foreground">
                      Util: {(market.utilization * 100).toFixed(0)}%
                    </div>
                  </div>
                </div>
              )
            })}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              Top Borrow Markets
              <Badge variant="secondary" className="text-orange-400">Borrow</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {topBorrow.map((sym) => {
              const token = TOKENS[sym]
              const market = MARKET_DATA[sym]
              return (
                <div key={sym} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{token.icon}</span>
                    <div>
                      <div className="font-medium">{sym}</div>
                      <div className="text-xs text-muted-foreground">
                        Borrows: {formatUSD(market.totalBorrows)}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-mono text-orange-400">{formatAPY(market.borrowAPY)}</div>
                    <div className="text-xs text-muted-foreground">
                      LTV: {market.ltv}%
                    </div>
                  </div>
                </div>
              )
            })}
          </CardContent>
        </Card>
      </div>

      <MarketOverview />
      <InterestRateChart />
    </div>
  )
}
