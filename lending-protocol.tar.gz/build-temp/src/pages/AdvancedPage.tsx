import { useState } from "react"
import { EModePanel } from "@/components/EModePanel"
import { LiquidationPanel } from "@/components/LiquidationPanel"
import { FlashLoanPanel } from "@/components/FlashLoanPanel"
import { CreditDelegationPanel } from "@/components/CreditDelegationPanel"
import { IsolatedPoolsPanel } from "@/components/IsolatedPoolsPanel"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export default function AdvancedPage() {
  const [connected] = useState(false)

  return (
    <div className="space-y-6">
      <Card className="border-primary/20 bg-primary/5">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <span className="text-2xl">⚠️</span>
            <div>
              <h3 className="font-semibold">Advanced DeFi Strategies</h3>
              <p className="text-sm text-muted-foreground mt-1">
                These features involve higher risk and are intended for experienced users.
                E-Mode increases capital efficiency for correlated assets, flash loans require
                atomic repayment, and credit delegation exposes you to counterparty risk.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-6">
          <EModePanel connected={connected} />
          <CreditDelegationPanel connected={connected} />
        </div>
        <div className="space-y-6">
          <LiquidationPanel connected={connected} />
          <FlashLoanPanel connected={connected} />
          <IsolatedPoolsPanel connected={connected} />
        </div>
      </div>
    </div>
  )
}
