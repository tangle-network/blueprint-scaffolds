import { useState } from "react"
import { SupplyBorrowPanel } from "@/components/SupplyBorrowPanel"
import { PortfolioDashboard } from "@/components/PortfolioDashboard"
import { InterestRateChart } from "@/components/InterestRateChart"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { TOKENS, MARKET_DATA, MOCK_PORTFOLIO, type TokenSymbol } from "@/lib/constants"
import { formatUSD, formatAPY, formatNumber } from "@/lib/utils"
import type { TokenInfo, MarketData } from "@/lib/types"

export default function DashboardPage() {
  const [connected] = useState(false)
  const tokenSymbols = Object.keys(TOKENS) as TokenSymbol[]

  const totalTVL = tokenSymbols.reduce(
    (sum, sym) => sum + MARKET_DATA[sym].totalDeposits,
    0
  )
  const totalBorrows = tokenSymbols.reduce(
    (sum, sym) => sum + MARKET_DATA[sym].totalBorrows,
    0
  )

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-muted-foreground">Total Value Locked</div>
            <div className="text-2xl font-bold font-mono">{formatUSD(totalTVL)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-muted-foreground">Total Borrows</div>
            <div className="text-2xl font-bold font-mono text-orange-400">{formatUSD(totalBorrows)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-muted-foreground">Markets</div>
            <div className="text-2xl font-bold">{tokenSymbols.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-muted-foreground">Top Supply APY</div>
            <div className="text-2xl font-bold font-mono text-green-400">
              {formatAPY(Math.max(...tokenSymbols.map((s) => MARKET_DATA[s].supplyAPY)))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <SupplyBorrowPanel connected={connected} />
          <InterestRateChart />
        </div>
        <div className="space-y-6">
          <PortfolioDashboard connected={connected} />
        </div>
      </div>
    </div>
  )
}
