import { useState } from "react"
import { PortfolioDashboard } from "@/components/PortfolioDashboard"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MOCK_PORTFOLIO, TOKENS, MARKET_DATA, type TokenSymbol } from "@/lib/constants"
import { formatUSD, formatAPY, healthFactorStatus } from "@/lib/utils"
import type { PortfolioPosition, PortfolioSummary, HealthFactorStatus } from "@/lib/types"

export default function PortfolioPage() {
  const [connected, setConnected] = useState(false)

  const handleConnect = () => setConnected(true)

  if (!connected) {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Your Portfolio</CardTitle>
            <CardDescription>Connect your wallet to view positions, health factor, and PnL</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center py-12 gap-4">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-2xl">
              📊
            </div>
            <p className="text-muted-foreground text-center max-w-md">
              Connect your wallet to view your lending positions, track your health factor,
              and manage your collateral across all markets.
            </p>
            <Button onClick={handleConnect}>Connect Wallet</Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  const hf = healthFactorStatus(MOCK_PORTFOLIO.healthFactor)
  const netAPY = MOCK_PORTFOLIO.positions.reduce((acc, pos) => {
    const market = MARKET_DATA[pos.symbol]
    const supplyEarnings = pos.supplied > 0
      ? (pos.supplied * (TOKENS[pos.symbol].priceUSD) * market.supplyAPY)
      : 0
    const borrowCost = pos.borrowed > 0
      ? (pos.borrowed * (TOKENS[pos.symbol].priceUSD) * market.borrowAPY)
      : 0
    return acc + supplyEarnings - borrowCost
  }, 0)

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-muted-foreground">Total Supplied</div>
            <div className="text-2xl font-bold font-mono text-green-400">
              {formatUSD(MOCK_PORTFOLIO.totalSupplyUSD)}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-muted-foreground">Total Borrowed</div>
            <div className="text-2xl font-bold font-mono text-orange-400">
              {formatUSD(MOCK_PORTFOLIO.totalBorrowUSD)}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-muted-foreground">Net Worth</div>
            <div className="text-2xl font-bold font-mono">{formatUSD(MOCK_PORTFOLIO.netWorth)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-muted-foreground">Health Factor</div>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold font-mono">{MOCK_PORTFOLIO.healthFactor.toFixed(2)}</span>
              <Badge variant="secondary" className={hf.color}>{hf.label}</Badge>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-muted-foreground">Est. Net APY</div>
            <div className="text-2xl font-bold font-mono text-green-400">
              {formatUSD(netAPY)}/yr
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Collateral Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {MOCK_PORTFOLIO.positions
              .filter((p) => p.collateral)
              .map((pos) => {
                const token = TOKENS[pos.symbol]
                const pct = (pos.valueUSD / MOCK_PORTFOLIO.totalSupplyUSD) * 100
                return (
                  <div key={pos.symbol} className="flex items-center gap-4">
                    <span className="text-lg w-8 text-center">{token.icon}</span>
                    <div className="flex-1">
                      <div className="flex justify-between text-sm mb-1">
                        <span className="font-medium">{pos.symbol}</span>
                        <span className="font-mono">{formatUSD(pos.valueUSD)}</span>
                      </div>
                      <div className="w-full bg-secondary rounded-full h-2">
                        <div
                          className="bg-primary rounded-full h-2 transition-all"
                          style={{ width: `${Math.min(pct, 100)}%` }}
                        />
                      </div>
                    </div>
                    <span className="text-sm text-muted-foreground w-12 text-right">{pct.toFixed(1)}%</span>
                  </div>
                )
              })}
          </div>
        </CardContent>
      </Card>

      <PortfolioDashboard connected={connected} />
    </div>
  )
}
