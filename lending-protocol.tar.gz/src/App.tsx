import { useState } from "react"
import { Header } from "@/components/Header"
import { MarketOverview } from "@/components/MarketOverview"
import { SupplyBorrowPanel } from "@/components/SupplyBorrowPanel"
import { PortfolioDashboard } from "@/components/PortfolioDashboard"
import { InterestRateChart } from "@/components/InterestRateChart"
import { EModePanel } from "@/components/EModePanel"
import { LiquidationPanel } from "@/components/LiquidationPanel"
import { FlashLoanPanel } from "@/components/FlashLoanPanel"
import { CreditDelegationPanel } from "@/components/CreditDelegationPanel"
import { IsolatedPoolsPanel } from "@/components/IsolatedPoolsPanel"

type Page = "dashboard" | "markets" | "portfolio" | "advanced"

const PAGES: { key: Page; label: string }[] = [
  { key: "dashboard", label: "Dashboard" },
  { key: "markets", label: "Markets" },
  { key: "portfolio", label: "Portfolio" },
  { key: "advanced", label: "Advanced" },
]

export default function App() {
  const [connected, setConnected] = useState(false)
  const [account, setAccount] = useState<string | null>(null)
  const [page, setPage] = useState<Page>("dashboard")

  const handleConnect = () => {
    setConnected(true)
    setAccount("0x742d35Cc6634C0532925a3b844Bc9e7595f2bD18")
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header connected={connected} onConnect={handleConnect} account={account} />

      <nav className="border-b border-border/50 bg-card/30">
        <div className="container mx-auto px-4">
          <div className="flex gap-1">
            {PAGES.map((p) => (
              <button
                key={p.key}
                onClick={() => setPage(p.key)}
                className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                  page === p.key
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-6 space-y-6">
        {page === "dashboard" && (
          <>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-6">
                <SupplyBorrowPanel connected={connected} />
                <InterestRateChart />
              </div>
              <div className="space-y-6">
                <PortfolioDashboard connected={connected} />
              </div>
            </div>
          </>
        )}

        {page === "markets" && (
          <>
            <MarketOverview />
            <InterestRateChart />
          </>
        )}

        {page === "portfolio" && (
          <PortfolioDashboard connected={connected} />
        )}

        {page === "advanced" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-6">
              <EModePanel connected={connected} />
              <CreditDelegationPanel connected={connected} />
            </div>
            <div className="space-y-6">
              <LiquidationPanel connected={connected} />
              <FlashLoanPanel connected={connected} />
              <IsolatedPoolsPanel connected={connected} />
            </div>
          </div>
        )}
      </main>

      <footer className="border-t border-border/50 mt-12">
        <div className="container mx-auto px-4 py-6 flex items-center justify-between text-sm text-muted-foreground">
          <span>LendX Protocol v1.0</span>
          <div className="flex gap-4">
            <span>Docs</span>
            <span>Governance</span>
            <span>Audit</span>
          </div>
        </div>
      </footer>
    </div>
  )
}
