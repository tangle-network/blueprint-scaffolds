import {
  borrowCapacityUsd,
  formatCompactUsd,
  formatPercent,
  healthFactor,
  markets,
  pools,
  position,
  supplyApy,
  totalBorrowedUsd,
  totalSuppliedUsd,
  utilizationRate,
  variableBorrowApy
} from "./data/protocol";

function App() {
  const suppliedUsd = totalSuppliedUsd(position);
  const borrowedUsd = totalBorrowedUsd(position);
  const capacityUsd = borrowCapacityUsd(position);
  const availableToBorrow = Math.max(capacityUsd - borrowedUsd, 0);
  const hf = healthFactor(position);

  const riskCards = [
    {
      label: "Supplied",
      value: formatCompactUsd(suppliedUsd),
      hint: "Across multi-asset collateral positions"
    },
    {
      label: "Borrowed",
      value: formatCompactUsd(borrowedUsd),
      hint: "Variable debt indexed per reserve"
    },
    {
      label: "Borrow Limit",
      value: formatCompactUsd(capacityUsd),
      hint: position.eModeEnabled ? "E-Mode boosts correlated collateral efficiency" : "Standard collateral mode"
    },
    {
      label: "Health Factor",
      value: Number.isFinite(hf) ? hf.toFixed(2) : "∞",
      hint: hf > 1.2 ? "Liquidation buffer healthy" : "Close to liquidation threshold"
    }
  ];

  return (
    <div className="app-shell">
      <header className="hero">
        <div className="hero-copy">
          <p className="eyebrow">Atlas Lend</p>
          <h1>Decentralized credit markets with risk-aware liquidity routing.</h1>
          <p className="hero-text">
            Supply assets, borrow against over-collateralized positions, enable correlated-asset E-Mode,
            delegate credit lines, and source instant liquidity through flash loans.
          </p>
          <div className="hero-actions">
            <button className="primary">Supply Collateral</button>
            <button className="secondary">Borrow Liquidity</button>
          </div>
        </div>
        <section className="hero-panel">
          <div className="panel-header">
            <span>Portfolio Overview</span>
            <strong>{position.eModeEnabled ? "E-Mode Enabled" : "Standard Mode"}</strong>
          </div>
          <div className="metrics-grid">
            {riskCards.map((card) => (
              <article className="metric-card" key={card.label}>
                <span>{card.label}</span>
                <strong>{card.value}</strong>
                <small>{card.hint}</small>
              </article>
            ))}
          </div>
        </section>
      </header>

      <main className="content-grid">
        <section className="section-card">
          <div className="section-heading">
            <div>
              <p className="section-kicker">Markets</p>
              <h2>Supply and borrow interface</h2>
            </div>
            <span className="badge">Utilization-based APY</span>
          </div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Asset</th>
                  <th>Price</th>
                  <th>Utilization</th>
                  <th>Supply APY</th>
                  <th>Borrow APY</th>
                  <th>Collateral</th>
                  <th>Flash Loan Fee</th>
                </tr>
              </thead>
              <tbody>
                {markets.map((market) => (
                  <tr key={market.symbol}>
                    <td>
                      <div className="asset-cell">
                        <strong>{market.symbol}</strong>
                        <span>{market.name}</span>
                      </div>
                    </td>
                    <td>{formatCompactUsd(market.price)}</td>
                    <td>{formatPercent(utilizationRate(market))}</td>
                    <td>{formatPercent(supplyApy(market))}</td>
                    <td>{formatPercent(variableBorrowApy(market))}</td>
                    <td>{formatPercent(market.collateralFactor)}</td>
                    <td>{formatPercent(market.flashLoanFee)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="section-card side-panel">
          <div className="section-heading">
            <div>
              <p className="section-kicker">Risk Engine</p>
              <h2>Borrowing power</h2>
            </div>
            <span className="badge success">{formatCompactUsd(availableToBorrow)} available</span>
          </div>
          <div className="stack-list">
            <article className="mini-card">
              <span>Credit Delegation</span>
              <strong>{formatCompactUsd(position.delegatedCredit)}</strong>
              <small>Delegate unused borrowing power to trusted vault managers.</small>
            </article>
            <article className="mini-card">
              <span>Liquidation Incentive</span>
              <strong>Up to 8.00%</strong>
              <small>Liquidators repay debt and receive discounted collateral when HF &lt; 1.</small>
            </article>
            <article className="mini-card">
              <span>Oracle Layer</span>
              <strong>Chainlink</strong>
              <small>Medianized price feeds with staleness checks secure collateral valuation.</small>
            </article>
          </div>
        </section>

        <section className="section-card">
          <div className="section-heading">
            <div>
              <p className="section-kicker">Pools</p>
              <h2>Cross-collateral and isolated markets</h2>
            </div>
            <span className="badge warning">Debt ceilings enforced</span>
          </div>
          <div className="pool-grid">
            {pools.map((pool) => (
              <article className="pool-card" key={pool.name}>
                <div className="pool-topline">
                  <h3>{pool.name}</h3>
                  <span className={pool.isolated ? "tag danger" : "tag"}>{pool.riskLabel}</span>
                </div>
                <p>{pool.description}</p>
                <div className="pool-assets">
                  {pool.assets.map((asset) => (
                    <span className="chip" key={asset}>
                      {asset}
                    </span>
                  ))}
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="section-card">
          <div className="section-heading">
            <div>
              <p className="section-kicker">Smart Contracts</p>
              <h2>On-chain architecture</h2>
            </div>
            <span className="badge">Solidity included</span>
          </div>
          <div className="architecture-list">
            <article>
              <h3>LendingPool</h3>
              <p>Manages deposits, borrows, liquidations, flash loans, E-Mode, and delegated credit accounting.</p>
            </article>
            <article>
              <h3>InterestRateStrategy</h3>
              <p>Computes utilization-aware variable borrowing curves with kinked rates and reserve spread.</p>
            </article>
            <article>
              <h3>ChainlinkOracle</h3>
              <p>Validates feed freshness and normalizes decimals before collateral and debt values are compared.</p>
            </article>
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;
