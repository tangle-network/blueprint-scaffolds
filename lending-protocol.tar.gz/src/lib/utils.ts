import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatNumber(value: number, decimals = 2): string {
  if (value >= 1e9) return `${(value / 1e9).toFixed(decimals)}B`
  if (value >= 1e6) return `${(value / 1e6).toFixed(decimals)}M`
  if (value >= 1e3) return `${(value / 1e3).toFixed(decimals)}K`
  return value.toFixed(decimals)
}

export function formatAddress(address: string): string {
  return `${address.slice(0, 6)}...${address.slice(-4)}`
}

export function formatUSD(value: number): string {
  return `$${formatNumber(value)}`
}

export function formatAPY(rate: number): string {
  return `${(rate * 100).toFixed(2)}%`
}

export function rayToWad(ray: bigint): bigint {
  return ray / BigInt(1e9)
}

export function wadToRay(wad: bigint): bigint {
  return wad * BigInt(1e9)
}

export const SECONDS_PER_YEAR = 31_536_000
export const RAY = BigInt(1e9) * BigInt(1e9)
export const WAD = BigInt(1e18)
export const HALF_RAY = RAY / BigInt(2)
export const HALF_WAD = WAD / BigInt(2)
