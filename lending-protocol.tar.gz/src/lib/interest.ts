import { SECONDS_PER_YEAR, RAY, HALF_RAY } from "./utils"

export function rayMul(a: bigint, b: bigint): bigint {
  if (a === BigInt(0) || b === BigInt(0)) return BigInt(0)
  return (a * b + HALF_RAY) / RAY
}

export function rayDiv(a: bigint, b: bigint): bigint {
  const halfB = b / BigInt(2)
  return (a * RAY + halfB) / b
}

export function rayPow(x: bigint, n: number): bigint {
  let z = x
  if (n === 0) return RAY
  for (let i = 1; i < n; i++) {
    z = rayMul(z, x)
  }
  return z
}

export function calculateLinearInterest(rate: bigint, currentTimestamp: number, lastTimestamp: number): bigint {
  const timeDelta = BigInt(Math.max(0, currentTimestamp - lastTimestamp))
  const timeDeltaSeconds = (timeDelta * RAY) / BigInt(SECONDS_PER_YEAR)
  const cumulative = RAY + rayMul(rate, timeDeltaSeconds)
  return cumulative
}

export function calculateCompoundedInterest(rate: bigint, currentTimestamp: number, lastTimestamp: number): bigint {
  const timeDelta = Math.max(0, currentTimestamp - lastTimestamp)
  if (timeDelta === 0) return RAY
  const secondsPerYear = BigInt(SECONDS_PER_YEAR)
  const timeDeltaBigint = BigInt(timeDelta)
  const ratePerSecond = rate / secondsPerYear
  const exponent = Number(timeDelta)
  if (exponent > 1000) {
    const expMinusOne = rayPow(ratePerSecond + RAY, exponent - 1)
    const expMinusTwo = rayMul(expMinusOne, ratePerSecond + RAY)
    return rayMul(ratePerSecond, expMinusOne) + rayMul(ratePerSecond, expMinusTwo) / BigInt(2) + expMinusTwo
  }
  return rayPow(ratePerSecond + RAY, exponent)
}

export function calculateUtilizationRate(totalBorrows: number, totalDeposits: number): number {
  if (totalDeposits === 0) return 0
  return totalBorrows / totalDeposits
}

export function calculateInterestRates(
  params: { optimalUtilizationRate: number; baseVariableBorrowRate: number; variableRateSlope1: number; variableRateSlope2: number },
  utilization: number,
  reserveFactor: number
): { supplyAPY: number; borrowAPY: number } {
  let borrowRate: number
  if (utilization <= params.optimalUtilizationRate) {
    borrowRate = params.baseVariableBorrowRate + (utilization / params.optimalUtilizationRate) * params.variableRateSlope1
  } else {
    const excessUtilization = utilization - params.optimalUtilizationRate
    const maxExcess = 1 - params.optimalUtilizationRate
    borrowRate = params.baseVariableBorrowRate + params.variableRateSlope1 + (excessUtilization / maxExcess) * params.variableRateSlope2
  }
  const supplyRate = borrowRate * utilization * (1 - reserveFactor)
  return { supplyAPY: supplyRate, borrowAPY: borrowRate }
}

export function calculateHealthFactor(
  totalCollateralUSD: number,
  totalBorrowsUSD: number,
  liquidationThreshold: number
): number {
  if (totalBorrowsUSD === 0) return Infinity
  const thresholdUSD = totalCollateralUSD * liquidationThreshold
  return thresholdUSD / totalBorrowsUSD
}

export function calculateLTV(totalCollateralUSD: number, totalBorrowsUSD: number): number {
  if (totalCollateralUSD === 0) return 0
  return totalBorrowsUSD / totalCollateralUSD
}

export function calculateMaxBorrow(
  totalCollateralUSD: number,
  currentBorrowsUSD: number,
  ltv: number
): number {
  return totalCollateralUSD * ltv - currentBorrowsUSD
}

export function calculateLiquidationIncentive(debtUSD: number, bonus: number): number {
  return debtUSD * (1 + bonus)
}

export function calculateFlashLoanPremium(amount: number, premiumRate: number, protocolFeeRate: number): {
  premium: number
  protocolFee: number
  totalRepay: number
} {
  const premium = amount * premiumRate
  const protocolFee = amount * protocolFeeRate
  return { premium, protocolFee, totalRepay: amount + premium }
}
