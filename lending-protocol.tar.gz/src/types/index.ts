export interface Asset {
  symbol: string
  name: string
  address: string
  decimals: number
  logoUrl: string
  priceUSD: number
  ltv: number
  liquidationThreshold: number
  liquidationBonus: number
  reserveFactor: number
  supplyCap: number
  borrowCap: number
  canBeCollateral: boolean
  canBeBorrowed: boolean
  eModeCategory: number
}

export interface ReserveData {
  asset: Asset
  totalDeposits: number
  totalBorrows: number
  availableLiquidity: number
  utilizationRate: number
  supplyAPY: number
  borrowAPY: number
  variableBorrowIndex: bigint
  liquidityIndex: bigint
  lastUpdateTimestamp: number
}

export interface UserReserveData {
  asset: Asset
  underlyingBalance: number
  aTokenBalance: number
  variableDebt: number
  usageAsCollateralEnabled: boolean
}

export interface UserSummary {
  totalCollateralUSD: number
  totalBorrowsUSD: number
  totalLiquidityUSD: number
  healthFactor: number
  ltv: number
  currentLiquidationThreshold: number
  reserves: UserReserveData[]
}

export interface EModeCategory {
  id: number
  label: string
  collateralColor: string
  borrowColor: string
  assets: string[]
  ltv: number
  liquidationThreshold: number
  liquidationBonus: number
}

export interface InterestRateParams {
  optimalUtilizationRate: number
  baseVariableBorrowRate: number
  variableRateSlope1: number
  variableRateSlope2: number
}

export interface FlashLoanParams {
  asset: string
  amount: number
  premium: number
  protocolFee: number
}

export interface CreditDelegation {
  from: string
  to: string
  asset: string
  amount: number
  interestRateMode: number
  expiry: number
}

export interface IsolatedPool {
  id: string
  name: string
  collateralAsset: Asset
  borrowAsset: Asset
  ltv: number
  liquidationThreshold: number
  totalDeposits: number
  totalBorrows: number
  supplyAPY: number
  borrowAPY: number
}

export interface LiquidationEvent {
  collateralAsset: string
  debtAsset: string
  borrower: string
  liquidator: string
  collateralAmount: number
  debtAmount: number
  bonus: number
  timestamp: number
}

export type TransactionStatus = "idle" | "pending" | "success" | "error"

export interface Transaction {
  hash?: string
  status: TransactionStatus
  action: "supply" | "withdraw" | "borrow" | "repay" | "liquidate" | "flashLoan" | "delegate"
  asset: string
  amount: number
  error?: string
}
