export type AssetKey = "ETH" | "WBTC" | "USDC" | "DAI" | "stETH";

export type AssetMarket = {
  symbol: AssetKey;
  name: string;
  price: number;
  supplied: number;
  borrowed: number;
  reserveFactor: number;
  baseRate: number;
  slope1: number;
  slope2: number;
  optimalUtilization: number;
  collateralFactor: number;
  liquidationThreshold: number;
  liquidationBonus: number;
  emodeCategory?: "ETH-Correlated" | "Stablecoins";
  isolated?: boolean;
  flashLoanFee: number;
};

export type Position = {
  supplied: Partial<Record<AssetKey, number>>;
  borrowed: Partial<Record<AssetKey, number>>;
  delegatedCredit: number;
  eModeEnabled: boolean;
};

export type Pool = {
  name: string;
  riskLabel: string;
  isolated: boolean;
  assets: AssetKey[];
  description: string;
};

export const markets: AssetMarket[] = [
  {
    symbol: "ETH",
    name: "Ether",
    price: 3520,
    supplied: 14500,
    borrowed: 9200,
    reserveFactor: 0.12,
    baseRate: 0.01,
    slope1: 0.08,
    slope2: 0.95,
    optimalUtilization: 0.8,
    collateralFactor: 0.8,
    liquidationThreshold: 0.84,
    liquidationBonus: 0.07,
    emodeCategory: "ETH-Correlated",
    flashLoanFee: 0.0009
  },
  {
    symbol: "WBTC",
    name: "Wrapped Bitcoin",
    price: 68250,
    supplied: 620,
    borrowed: 310,
    reserveFactor: 0.15,
    baseRate: 0.012,
    slope1: 0.07,
    slope2: 0.82,
    optimalUtilization: 0.72,
    collateralFactor: 0.75,
    liquidationThreshold: 0.8,
    liquidationBonus: 0.08,
    flashLoanFee: 0.0012
  },
  {
    symbol: "USDC",
    name: "USD Coin",
    price: 1,
    supplied: 11400000,
    borrowed: 9210000,
    reserveFactor: 0.08,
    baseRate: 0.02,
    slope1: 0.06,
    slope2: 0.7,
    optimalUtilization: 0.9,
    collateralFactor: 0.88,
    liquidationThreshold: 0.92,
    liquidationBonus: 0.045,
    emodeCategory: "Stablecoins",
    flashLoanFee: 0.0005
  },
  {
    symbol: "DAI",
    name: "Dai",
    price: 1,
    supplied: 8600000,
    borrowed: 6400000,
    reserveFactor: 0.1,
    baseRate: 0.021,
    slope1: 0.055,
    slope2: 0.68,
    optimalUtilization: 0.89,
    collateralFactor: 0.86,
    liquidationThreshold: 0.9,
    liquidationBonus: 0.05,
    emodeCategory: "Stablecoins",
    flashLoanFee: 0.0005
  },
  {
    symbol: "stETH",
    name: "Liquid Staked Ether",
    price: 3660,
    supplied: 9800,
    borrowed: 2800,
    reserveFactor: 0.14,
    baseRate: 0.009,
    slope1: 0.05,
    slope2: 0.55,
    optimalUtilization: 0.78,
    collateralFactor: 0.83,
    liquidationThreshold: 0.9,
    liquidationBonus: 0.06,
    emodeCategory: "ETH-Correlated",
    isolated: true,
    flashLoanFee: 0.001
  }
];

export const pools: Pool[] = [
  {
    name: "Core Liquidity Pool",
    riskLabel: "Cross-collateral",
    isolated: false,
    assets: ["ETH", "WBTC", "USDC", "DAI"],
    description: "General-purpose lending pool with diversified collateral and deep stablecoin liquidity."
  },
  {
    name: "Liquid Staking Isolated Pool",
    riskLabel: "Isolated",
    isolated: true,
    assets: ["stETH", "ETH", "USDC"],
    description: "Contains higher correlation and smart contract risk assets with isolated debt ceilings."
  }
];

export const position: Position = {
  supplied: {
    ETH: 3.4,
    USDC: 18000,
    stETH: 1.8
  },
  borrowed: {
    DAI: 9200,
    USDC: 3200
  },
  delegatedCredit: 25000,
  eModeEnabled: true
};

export function utilizationRate(market: AssetMarket): number {
  return market.supplied === 0 ? 0 : market.borrowed / market.supplied;
}

export function variableBorrowApy(market: AssetMarket): number {
  const utilization = utilizationRate(market);
  if (utilization <= market.optimalUtilization) {
    return market.baseRate + (utilization / market.optimalUtilization) * market.slope1;
  }

  const excess = (utilization - market.optimalUtilization) / (1 - market.optimalUtilization);
  return market.baseRate + market.slope1 + excess * market.slope2;
}

export function supplyApy(market: AssetMarket): number {
  const borrowRate = variableBorrowApy(market);
  return borrowRate * utilizationRate(market) * (1 - market.reserveFactor);
}

export function valueOf(symbol: AssetKey, amount: number): number {
  const asset = markets.find((market) => market.symbol === symbol);
  return asset ? asset.price * amount : 0;
}

export function totalSuppliedUsd(currentPosition: Position): number {
  return Object.entries(currentPosition.supplied).reduce((sum, [symbol, amount]) => {
    return sum + valueOf(symbol as AssetKey, amount ?? 0);
  }, 0);
}

export function totalBorrowedUsd(currentPosition: Position): number {
  return Object.entries(currentPosition.borrowed).reduce((sum, [symbol, amount]) => {
    return sum + valueOf(symbol as AssetKey, amount ?? 0);
  }, 0);
}

export function borrowCapacityUsd(currentPosition: Position): number {
  return Object.entries(currentPosition.supplied).reduce((sum, [symbol, amount]) => {
    const market = markets.find((item) => item.symbol === symbol);
    if (!market) {
      return sum;
    }

    const factor = currentPosition.eModeEnabled && market.emodeCategory ? market.liquidationThreshold : market.collateralFactor;
    return sum + (amount ?? 0) * market.price * factor;
  }, 0);
}

export function healthFactor(currentPosition: Position): number {
  const debt = totalBorrowedUsd(currentPosition);
  if (debt === 0) {
    return Infinity;
  }

  const thresholdValue = Object.entries(currentPosition.supplied).reduce((sum, [symbol, amount]) => {
    const market = markets.find((item) => item.symbol === symbol);
    return market ? sum + (amount ?? 0) * market.price * market.liquidationThreshold : sum;
  }, 0);

  return thresholdValue / debt;
}

export function formatCompactUsd(value: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    notation: value >= 100000 ? "compact" : "standard",
    maximumFractionDigits: value >= 1000 ? 1 : 2
  }).format(value);
}

export function formatPercent(value: number): string {
  return `${(value * 100).toFixed(2)}%`;
}
