import type {
  Asset,
  ReserveData,
  UserSummary,
  EModeCategory,
  IsolatedPool,
  InterestRateParams,
  LiquidationEvent,
  CreditDelegation,
} from "@/types"

export const ASSETS: Record<string, Asset> = {
  ETH: {
    symbol: "ETH", name: "Ethereum", address: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",
    decimals: 18, logoUrl: "⟠", priceUSD: 3450, ltv: 0.80,
    liquidationThreshold: 0.825, liquidationBonus: 0.05, reserveFactor: 0.10,
    supplyCap: 500000, borrowCap: 350000, canBeCollateral: true, canBeBorrowed: true, eModeCategory: 2,
  },
  WBTC: {
    symbol: "WBTC", name: "Wrapped Bitcoin", address: "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599",
    decimals: 8, logoUrl: "₿", priceUSD: 67200, ltv: 0.70,
    liquidationThreshold: 0.75, liquidationBonus: 0.065, reserveFactor: 0.20,
    supplyCap: 15000, borrowCap: 10000, canBeCollateral: true, canBeBorrowed: true, eModeCategory: 3,
  },
  USDC: {
    symbol: "USDC", name: "USD Coin", address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
    decimals: 6, logoUrl: "$", priceUSD: 1.00, ltv: 0.0,
    liquidationThreshold: 0.0, liquidationBonus: 0.0, reserveFactor: 0.10,
    supplyCap: 200000000, borrowCap: 150000000, canBeCollateral: false, canBeBorrowed: true, eModeCategory: 1,
  },
  USDT: {
    symbol: "USDT", name: "Tether USD", address: "0xdAC17F958D2ee523a2206206994597C13D831ec7",
    decimals: 6, logoUrl: "₮", priceUSD: 1.00, ltv: 0.0,
    liquidationThreshold: 0.0, liquidationBonus: 0.0, reserveFactor: 0.10,
    supplyCap: 150000000, borrowCap: 100000000, canBeCollateral: false, canBeBorrowed: true, eModeCategory: 1,
  },
  DAI: {
    symbol: "DAI", name: "Dai Stablecoin", address: "0x6B175474E89094C44Da98b954EedeAC495271d0F",
    decimals: 18, logoUrl: "◆", priceUSD: 1.00, ltv: 0.75,
    liquidationThreshold: 0.80, liquidationBonus: 0.05, reserveFactor: 0.10,
    supplyCap: 180000000, borrowCap: 120000000, canBeCollateral: true, canBeBorrowed: true, eModeCategory: 1,
  },
  LINK: {
    symbol: "LINK", name: "Chainlink", address: "0x514910771AF9Ca656af840dff83E8264EcF986CA",
    decimals: 18, logoUrl: "⬡", priceUSD: 18.50, ltv: 0.55,
    liquidationThreshold: 0.60, liquidationBonus: 0.08, reserveFactor: 0.20,
    supplyCap: 8000000, borrowCap: 5000000, canBeCollateral: true, canBeBorrowed: true, eModeCategory: 0,
  },
  AAVE: {
    symbol: "AAVE", name: "Aave Token", address: "0x7Fc66500c84A76Ad7e9c93437bFc5Ac33E2DDaE9",
    decimals: 18, logoUrl: "👻", priceUSD: 165, ltv: 0.50,
    liquidationThreshold: 0.65, liquidationBonus: 0.10, reserveFactor: 0.25,
    supplyCap: 2000000, borrowCap: 800000, canBeCollateral: true, canBeBorrowed: true, eModeCategory: 0,
  },
  UNI: {
    symbol: "UNI", name: "Uniswap", address: "0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984",
    decimals: 18, logoUrl: "🦄", priceUSD: 12.30, ltv: 0.50,
    liquidationThreshold: 0.60, liquidationBonus: 0.08, reserveFactor: 0.20,
    supplyCap: 5000000, borrowCap: 3000000, canBeCollateral: true, canBeBorrowed: true, eModeCategory: 0,
  },
}

export const INTEREST_RATE_PARAMS: Record<string, InterestRateParams> = {
  ETH: { optimalUtilizationRate: 0.45, baseVariableBorrowRate: 0, variableRateSlope1: 0.04, variableRateSlope2: 0.75 },
  WBTC: { optimalUtilizationRate: 0.45, baseVariableBorrowRate: 0, variableRateSlope1: 0.04, variableRateSlope2: 0.70 },
  USDC: { optimalUtilizationRate: 0.90, baseVariableBorrowRate: 0.04, variableRateSlope1: 0.04, variableRateSlope2: 0.75 },
  USDT: { optimalUtilizationRate: 0.90, baseVariableBorrowRate: 0.04, variableRateSlope1: 0.04, variableRateSlope2: 0.75 },
  DAI: { optimalUtilizationRate: 0.90, baseVariableBorrowRate: 0.04, variableRateSlope1: 0.04, variableRateSlope2: 0.75 },
  LINK: { optimalUtilizationRate: 0.45, baseVariableBorrowRate: 0, variableRateSlope1: 0.07, variableRateSlope2: 3.0 },
  AAVE: { optimalUtilizationRate: 0.45, baseVariableBorrowRate: 0, variableRateSlope1: 0.06, variableRateSlope2: 1.5 },
  UNI: { optimalUtilizationRate: 0.45, baseVariableBorrowRate: 0, variableRateSlope1: 0.07, variableRateSlope2: 2.5 },
}

function makeReserve(asset: Asset, deposits: number, borrows: number): ReserveData {
  const util = deposits > 0 ? borrows / deposits : 0
  const params = INTEREST_RATE_PARAMS[asset.symbol]
  const rates = calculateInterestRatesFromParams(params, util, asset.reserveFactor)
  return {
    asset, totalDeposits: deposits, totalBorrows: borrows,
    availableLiquidity: deposits - borrows, utilizationRate: util,
    supplyAPY: rates.supplyAPY, borrowAPY: rates.borrowAPY,
    variableBorrowIndex: BigInt("1000000000000000000000000000"),
    liquidityIndex: BigInt("1000000000000000000000000000"),
    lastUpdateTimestamp: Math.floor(Date.now() / 1000) - 3600,
  }
}

function calculateInterestRatesFromParams(
  params: InterestRateParams, utilization: number, reserveFactor: number
): { supplyAPY: number; borrowAPY: number } {
  let borrowRate: number
  if (utilization <= params.optimalUtilizationRate) {
    borrowRate = params.baseVariableBorrowRate + (utilization / Math.max(params.optimalUtilizationRate, 0.001)) * params.variableRateSlope1
  } else {
    const excess = utilization - params.optimalUtilizationRate
    const maxExcess = 1 - params.optimalUtilizationRate
    borrowRate = params.baseVariableBorrowRate + params.variableRateSlope1 + (excess / Math.max(maxExcess, 0.001)) * params.variableRateSlope2
  }
  const supplyRate = borrowRate * utilization * (1 - reserveFactor)
  return { supplyAPY: supplyRate, borrowAPY: borrowRate }
}

export const RESERVES: ReserveData[] = [
  makeReserve(ASSETS.ETH, 450000 * 3450, 280000 * 3450),
  makeReserve(ASSETS.WBTC, 12000 * 67200, 7500 * 67200),
  makeReserve(ASSETS.USDC, 185000000, 142000000),
  makeReserve(ASSETS.USDT, 125000000, 98000000),
  makeReserve(ASSETS.DAI, 95000000, 72000000),
  makeReserve(ASSETS.LINK, 5500000 * 18.5, 2800000 * 18.5),
  makeReserve(ASSETS.AAVE, 1200000 * 165, 650000 * 165),
  makeReserve(ASSETS.UNI, 3500000 * 12.3, 1800000 * 12.3),
]

export const E_MODE_CATEGORIES: EModeCategory[] = [
  {
    id: 1, label: "Stablecoins", collateralColor: "#4CAF50", borrowColor: "#2196F3",
    assets: ["USDC", "USDT", "DAI"], ltv: 0.97, liquidationThreshold: 0.975, liquidationBonus: 0.01,
  },
  {
    id: 2, label: "ETH Correlated", collateralColor: "#627EEA", borrowColor: "#627EEA",
    assets: ["ETH"], ltv: 0.93, liquidationThreshold: 0.95, liquidationBonus: 0.01,
  },
  {
    id: 3, label: "BTC Correlated", collateralColor: "#F7931A", borrowColor: "#F7931A",
    assets: ["WBTC"], ltv: 0.90, liquidationThreshold: 0.93, liquidationBonus: 0.02,
  },
]

export const ISOLATED_POOLS: IsolatedPool[] = [
  {
    id: "pool-1", name: "ETH → USDC", collateralAsset: ASSETS.ETH, borrowAsset: ASSETS.USDC,
    ltv: 0.75, liquidationThreshold: 0.80,
    totalDeposits: 50000 * 3450, totalBorrows: 32000 * 3450,
    supplyAPY: 0.0234, borrowAPY: 0.0456,
  },
  {
    id: "pool-2", name: "WBTC → DAI", collateralAsset: ASSETS.WBTC, borrowAsset: ASSETS.DAI,
    ltv: 0.65, liquidationThreshold: 0.70,
    totalDeposits: 3000 * 67200, totalBorrows: 1800 * 67200,
    supplyAPY: 0.0189, borrowAPY: 0.0398,
  },
  {
    id: "pool-3", name: "LINK → USDT", collateralAsset: ASSETS.LINK, borrowAsset: ASSETS.USDT,
    ltv: 0.50, liquidationThreshold: 0.55,
    totalDeposits: 800000 * 18.5, totalBorrows: 420000 * 18.5,
    supplyAPY: 0.0312, borrowAPY: 0.0567,
  },
]

export const MOCK_USER: UserSummary = {
  totalCollateralUSD: 84500,
  totalBorrowsUSD: 31200,
  totalLiquidityUSD: 84500,
  healthFactor: 2.14,
  ltv: 0.369,
  currentLiquidationThreshold: 0.80,
  reserves: [
    { asset: ASSETS.ETH, underlyingBalance: 15.5, aTokenBalance: 15.5, variableDebt: 0, usageAsCollateralEnabled: true },
    { asset: ASSETS.USDC, underlyingBalance: 25000, aTokenBalance: 25000, variableDebt: 0, usageAsCollateralEnabled: false },
    { asset: ASSETS.DAI, underlyingBalance: 8500, aTokenBalance: 8500, variableDebt: 0, usageAsCollateralEnabled: true },
    { asset: ASSETS.USDC, underlyingBalance: 0, aTokenBalance: 0, variableDebt: 22000, usageAsCollateralEnabled: false },
    { asset: ASSETS.USDT, underlyingBalance: 0, aTokenBalance: 0, variableDebt: 9200, usageAsCollateralEnabled: false },
  ],
}

export const CREDIT_DELEGATIONS: CreditDelegation[] = [
  { from: "0x1234...5678", to: "0xABCD...EF01", asset: "USDC", amount: 50000, interestRateMode: 2, expiry: 1735689600 },
  { from: "0x1234...5678", to: "0x9876...5432", asset: "DAI", amount: 25000, interestRateMode: 2, expiry: 1738368000 },
  { from: "0x5678...1234", to: "0xDEAD...BEEF", asset: "ETH", amount: 10, interestRateMode: 2, expiry: 1741046400 },
]

export const LIQUIDATION_EVENTS: LiquidationEvent[] = [
  { collateralAsset: "ETH", debtAsset: "USDC", borrower: "0xCAFE...BEEF", liquidator: "0xDEAD...FACE", collateralAmount: 2.45, debtAmount: 8400, bonus: 0.05, timestamp: Date.now() - 3600000 },
  { collateralAsset: "WBTC", debtAsset: "USDT", borrower: "0xFACE...CAFE", liquidator: "0x1337...ABCD", collateralAmount: 0.8, debtAmount: 52000, bonus: 0.065, timestamp: Date.now() - 7200000 },
  { collateralAsset: "LINK", debtAsset: "DAI", borrower: "0xBEEF...DEAD", liquidator: "0xCAFE...BABE", collateralAmount: 450, debtAmount: 7800, bonus: 0.08, timestamp: Date.now() - 14400000 },
]
