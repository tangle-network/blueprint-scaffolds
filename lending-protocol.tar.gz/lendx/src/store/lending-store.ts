import { create } from "zustand";
import type { Asset, UserPosition, Pool, EModeCategory, Transaction, LiquidationEvent } from "@/types";

const DEFAULT_ASSETS: Asset[] = [
  { symbol: "WETH", name: "Wrapped Ether", decimals: 18, price: 3245, supplyAPY: 1.24, borrowAPY: 3.52, totalSupply: 4_850_000_000, totalBorrow: 2_180_000_000, utilization: 44.95, collateralFactor: 82, liquidationThreshold: 80, canCollateral: true, canBorrow: true, eModeCategory: "ETH Correlated" },
  { symbol: "WBTC", name: "Wrapped Bitcoin", decimals: 8, price: 97400, supplyAPY: 0.31, borrowAPY: 2.14, totalSupply: 1_920_000_000, totalBorrow: 680_000_000, utilization: 35.42, collateralFactor: 70, liquidationThreshold: 70, canCollateral: true, canBorrow: true, eModeCategory: "ETH Correlated" },
  { symbol: "USDC", name: "USD Coin", decimals: 6, price: 1.0, supplyAPY: 4.12, borrowAPY: 6.24, totalSupply: 3_240_000_000, totalBorrow: 2_890_000_000, utilization: 89.20, collateralFactor: 80, liquidationThreshold: 80, canCollateral: true, canBorrow: true, eModeCategory: "Stablecoins" },
  { symbol: "USDT", name: "Tether", decimals: 6, price: 1.0, supplyAPY: 3.87, borrowAPY: 5.98, totalSupply: 2_100_000_000, totalBorrow: 1_820_000_000, utilization: 86.67, collateralFactor: 80, liquidationThreshold: 80, canCollateral: true, canBorrow: true, eModeCategory: "Stablecoins" },
  { symbol: "DAI", name: "Dai Stablecoin", decimals: 18, price: 1.0, supplyAPY: 3.65, borrowAPY: 5.71, totalSupply: 1_540_000_000, totalBorrow: 1_210_000_000, utilization: 78.57, collateralFactor: 77, liquidationThreshold: 77, canCollateral: true, canBorrow: true, eModeCategory: "Stablecoins" },
  { symbol: "LINK", name: "Chainlink", decimals: 18, price: 18.42, supplyAPY: 0.54, borrowAPY: 2.87, totalSupply: 420_000_000, totalBorrow: 145_000_000, utilization: 34.52, collateralFactor: 65, liquidationThreshold: 65, canCollateral: true, canBorrow: true, eModeCategory: "None" },
  { symbol: "AAVE", name: "Aave Token", decimals: 18, price: 285.6, supplyAPY: 0.0, borrowAPY: 0.0, totalSupply: 380_000_000, totalBorrow: 0, utilization: 0, collateralFactor: 66, liquidationThreshold: 66, canCollateral: true, canBorrow: true, eModeCategory: "None" },
  { symbol: "UNI", name: "Uniswap", decimals: 18, price: 12.87, supplyAPY: 0.78, borrowAPY: 3.12, totalSupply: 195_000_000, totalBorrow: 62_000_000, utilization: 31.79, collateralFactor: 60, liquidationThreshold: 60, canCollateral: true, canBorrow: true, eModeCategory: "None" },
  { symbol: "CRV", name: "Curve DAO", decimals: 18, price: 0.92, supplyAPY: 1.23, borrowAPY: 4.56, totalSupply: 89_000_000, totalBorrow: 41_000_000, utilization: 46.07, collateralFactor: 45, liquidationThreshold: 45, canCollateral: true, canBorrow: true, eModeCategory: "None" },
  { symbol: "stETH", name: "Lido Staked ETH", decimals: 18, price: 3241, supplyAPY: 2.89, borrowAPY: 0.0, totalSupply: 2_750_000_000, totalBorrow: 0, utilization: 0, collateralFactor: 72, liquidationThreshold: 72, canCollateral: true, canBorrow: false, eModeCategory: "ETH Correlated" },
  { symbol: "cbETH", name: "Coinbase Staked ETH", decimals: 18, price: 3512, supplyAPY: 1.56, borrowAPY: 0.42, totalSupply: 680_000_000, totalBorrow: 85_000_000, utilization: 12.50, collateralFactor: 70, liquidationThreshold: 70, canCollateral: true, canBorrow: true, eModeCategory: "ETH Correlated" },
  { symbol: "GHO", name: "GHO Stablecoin", decimals: 18, price: 0.998, supplyAPY: 0.0, borrowAPY: 4.80, totalSupply: 340_000_000, totalBorrow: 312_000_000, utilization: 91.76, collateralFactor: 0, liquidationThreshold: 0, canCollateral: false, canBorrow: true, eModeCategory: "Stablecoins" },
];

const DEFAULT_USER_POSITION: UserPosition = {
  supplied: [
    { symbol: "WETH", amount: 4.5, usdValue: 14602.5, isCollateral: true, apy: 1.24 },
    { symbol: "USDC", amount: 25000, usdValue: 25000, isCollateral: true, apy: 4.12 },
    { symbol: "WBTC", amount: 0.25, usdValue: 24350, isCollateral: true, apy: 0.31 },
    { symbol: "stETH", amount: 2.0, usdValue: 6482, isCollateral: true, apy: 2.89 },
  ],
  borrowed: [
    { symbol: "USDC", amount: 18000, usdValue: 18000, apy: 6.24 },
    { symbol: "USDT", amount: 5000, usdValue: 5000, apy: 5.98 },
  ],
  healthFactor: 2.34,
  netAPY: 1.87,
  totalSupplied: 70434.5,
  totalBorrowed: 23000,
  availableToBorrow: 35217.25,
  liquidationThreshold: 78.5,
  loanToValue: 67.2,
};

const DEFAULT_EMODE_CATEGORIES: EModeCategory[] = [
  { id: 1, label: "ETH Correlated", assets: ["WETH", "WBTC", "stETH", "cbETH"], collateralFactor: 90, liquidationThreshold: 93, borrowAPYMultiplier: 0.9 },
  { id: 2, label: "Stablecoins", assets: ["USDC", "USDT", "DAI", "GHO"], collateralFactor: 97, liquidationThreshold: 97, borrowAPYMultiplier: 1.0 },
];

const DEFAULT_POOL: Pool = {
  name: "Aave V3 Ethereum",
  assets: DEFAULT_ASSETS.map((a) => a.symbol),
  eModeEnabled: true,
  isolationMode: false,
  totalTVL: 18_595_000_000,
};

const DEFAULT_TRANSACTIONS: Transaction[] = [
  { id: "1", type: "supply", asset: "WETH", amount: 2.5, timestamp: Date.now() - 3600000, hash: "0xabc123def456789abc123def456789abc123def456789abc123def456789abcd", status: "completed" },
  { id: "2", type: "borrow", asset: "USDC", amount: 10000, timestamp: Date.now() - 7200000, hash: "0xdef456789abc123def456789abc123def456789abc123def456789abc123def4", status: "completed" },
  { id: "3", type: "supply", asset: "WBTC", amount: 0.15, timestamp: Date.now() - 14400000, hash: "0x789abc123def456789abc123def456789abc123def456789abc123def456789a", status: "completed" },
  { id: "4", type: "repay", asset: "USDC", amount: 5000, timestamp: Date.now() - 28800000, hash: "0x123def456789abc123def456789abc123def456789abc123def456789abc123d", status: "completed" },
  { id: "5", type: "borrow", asset: "USDT", amount: 5000, timestamp: Date.now() - 43200000, hash: "0x456789abc123def456789abc123def456789abc123def456789abc123def4567", status: "completed" },
  { id: "6", type: "supply", asset: "USDC", amount: 15000, timestamp: Date.now() - 86400000, hash: "0x89abc123def456789abc123def456789abc123def456789abc123def456789ab", status: "completed" },
];

const DEFAULT_LIQUIDATIONS: LiquidationEvent[] = [
  { id: "l1", borrower: "0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D", collateralSeized: "WETH", collateralSeizedAmount: 3.42, debtRepaid: "USDC", debtRepaidAmount: 8950, liquidator: "0x3fC91A3afd70395Cd496C647d5a6CC9D4B2b7FAD", bonus: 450, timestamp: Date.now() - 1800000, healthFactor: 0.94 },
  { id: "l2", borrower: "0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045", collateralSeized: "WBTC", collateralSeizedAmount: 0.18, debtRepaid: "USDT", debtRepaidAmount: 14200, liquidator: "0x56Eddb7aa87536c09CCc2793473599fD21A8b17F", bonus: 710, timestamp: Date.now() - 5400000, healthFactor: 0.87 },
  { id: "l3", borrower: "0x1f9090aaE28b8a3dCeaDf281B0F12828e676c326", collateralSeized: "stETH", collateralSeizedAmount: 5.12, debtRepaid: "DAI", debtRepaidAmount: 12800, liquidator: "0x4838B106FCe9647Bdf1E7877BF73cE8B0BAD5f97", bonus: 640, timestamp: Date.now() - 10800000, healthFactor: 0.91 },
  { id: "l4", borrower: "0xBE0eB53F46cd790Cd13851d5EFf43D12404d33E8", collateralSeized: "WETH", collateralSeizedAmount: 1.87, debtRepaid: "USDC", debtRepaidAmount: 5200, liquidator: "0x3fC91A3afd70395Cd496C647d5a6CC9D4B2b7FAD", bonus: 260, timestamp: Date.now() - 21600000, healthFactor: 0.82 },
  { id: "l5", borrower: "0x5777d92f208679DB4b9778590Fa3CAB3aC5eA219", collateralSeized: "LINK", collateralSeizedAmount: 1240, debtRepaid: "USDC", debtRepaidAmount: 18400, liquidator: "0x56Eddb7aa87536c09CCc2793473599fD21A8b17F", bonus: 920, timestamp: Date.now() - 43200000, healthFactor: 0.78 },
];

interface LendingStore {
  assets: Asset[];
  userPosition: UserPosition;
  selectedPool: Pool;
  eModeCategories: EModeCategory[];
  activeEModeCategory: number | null;
  transactions: Transaction[];
  liquidationEvents: LiquidationEvent[];
  searchQuery: string;
  sortField: string;
  sortDirection: "asc" | "desc";

  setSearchQuery: (q: string) => void;
  setSort: (field: string) => void;
  supply: (symbol: string, amount: number) => void;
  borrow: (symbol: string, amount: number) => void;
  repay: (symbol: string, amount: number) => void;
  withdraw: (symbol: string, amount: number) => void;
  toggleCollateral: (symbol: string) => void;
  enableEMode: (categoryId: number) => void;
  disableEMode: () => void;
}

export const useLendingStore = create<LendingStore>((set, get) => ({
  assets: DEFAULT_ASSETS,
  userPosition: DEFAULT_USER_POSITION,
  selectedPool: DEFAULT_POOL,
  eModeCategories: DEFAULT_EMODE_CATEGORIES,
  activeEModeCategory: null,
  transactions: DEFAULT_TRANSACTIONS,
  liquidationEvents: DEFAULT_LIQUIDATIONS,
  searchQuery: "",
  sortField: "totalSupply",
  sortDirection: "desc",

  setSearchQuery: (q) => set({ searchQuery: q }),

  setSort: (field) =>
    set((s) => ({
      sortField: field,
      sortDirection: s.sortField === field && s.sortDirection === "asc" ? "desc" : "asc",
    })),

  supply: (symbol, amount) =>
    set((s) => {
      const asset = s.assets.find((a) => a.symbol === symbol);
      if (!asset) return s;
      const existing = s.userPosition.supplied.find((a) => a.symbol === symbol);
      const newSupplied = existing
        ? s.userPosition.supplied.map((a) =>
            a.symbol === symbol
              ? { ...a, amount: a.amount + amount, usdValue: (a.amount + amount) * asset.price }
              : a
          )
        : [...s.userPosition.supplied, { symbol, amount, usdValue: amount * asset.price, isCollateral: asset.canCollateral, apy: asset.supplyAPY }];

      const totalSupplied = newSupplied.reduce((sum, a) => sum + a.usdValue, 0);
      const totalBorrowed = s.userPosition.borrowed.reduce((sum, a) => sum + a.usdValue, 0);
      const healthFactor = totalBorrowed > 0 ? (totalSupplied * s.userPosition.liquidationThreshold / 100) / totalBorrowed : 999;

      const tx: Transaction = {
        id: String(Date.now()),
        type: "supply",
        asset: symbol,
        amount,
        timestamp: Date.now(),
        hash: "0x" + Math.random().toString(16).slice(2) + Math.random().toString(16).slice(2),
        status: "completed",
      };

      return {
        userPosition: { ...s.userPosition, supplied: newSupplied, totalSupplied, healthFactor, availableToBorrow: totalSupplied * s.userPosition.loanToValue / 100 - totalBorrowed },
        transactions: [tx, ...s.transactions],
        assets: s.assets.map((a) => a.symbol === symbol ? { ...a, totalSupply: a.totalSupply + amount * a.price } : a),
      };
    }),

  borrow: (symbol, amount) =>
    set((s) => {
      const asset = s.assets.find((a) => a.symbol === symbol);
      if (!asset) return s;
      const existing = s.userPosition.borrowed.find((a) => a.symbol === symbol);
      const newBorrowed = existing
        ? s.userPosition.borrowed.map((a) => a.symbol === symbol ? { ...a, amount: a.amount + amount, usdValue: (a.amount + amount) * asset.price } : a)
        : [...s.userPosition.borrowed, { symbol, amount, usdValue: amount * asset.price, apy: asset.borrowAPY }];

      const totalSupplied = s.userPosition.supplied.reduce((sum, a) => sum + a.usdValue, 0);
      const totalBorrowed = newBorrowed.reduce((sum, a) => sum + a.usdValue, 0);
      const healthFactor = totalBorrowed > 0 ? (totalSupplied * s.userPosition.liquidationThreshold / 100) / totalBorrowed : 999;

      const tx: Transaction = {
        id: String(Date.now()),
        type: "borrow",
        asset: symbol,
        amount,
        timestamp: Date.now(),
        hash: "0x" + Math.random().toString(16).slice(2) + Math.random().toString(16).slice(2),
        status: "completed",
      };

      return {
        userPosition: { ...s.userPosition, borrowed: newBorrowed, totalBorrowed, healthFactor, availableToBorrow: totalSupplied * s.userPosition.loanToValue / 100 - totalBorrowed },
        transactions: [tx, ...s.transactions],
        assets: s.assets.map((a) => a.symbol === symbol ? { ...a, totalBorrow: a.totalBorrow + amount * a.price } : a),
      };
    }),

  repay: (symbol, amount) =>
    set((s) => {
      const asset = s.assets.find((a) => a.symbol === symbol);
      if (!asset) return s;
      const newBorrowed = s.userPosition.borrowed
        .map((a) => (a.symbol === symbol ? { ...a, amount: Math.max(0, a.amount - amount), usdValue: Math.max(0, a.amount - amount) * asset.price } : a))
        .filter((a) => a.amount > 0);

      const totalSupplied = s.userPosition.supplied.reduce((sum, a) => sum + a.usdValue, 0);
      const totalBorrowed = newBorrowed.reduce((sum, a) => sum + a.usdValue, 0);
      const healthFactor = totalBorrowed > 0 ? (totalSupplied * s.userPosition.liquidationThreshold / 100) / totalBorrowed : 999;

      const tx: Transaction = {
        id: String(Date.now()),
        type: "repay",
        asset: symbol,
        amount,
        timestamp: Date.now(),
        hash: "0x" + Math.random().toString(16).slice(2) + Math.random().toString(16).slice(2),
        status: "completed",
      };

      return {
        userPosition: { ...s.userPosition, borrowed: newBorrowed, totalBorrowed, healthFactor, availableToBorrow: totalSupplied * s.userPosition.loanToValue / 100 - totalBorrowed },
        transactions: [tx, ...s.transactions],
      };
    }),

  withdraw: (symbol, amount) =>
    set((s) => {
      const asset = s.assets.find((a) => a.symbol === symbol);
      if (!asset) return s;
      const newSupplied = s.userPosition.supplied
        .map((a) => (a.symbol === symbol ? { ...a, amount: Math.max(0, a.amount - amount), usdValue: Math.max(0, a.amount - amount) * asset.price } : a))
        .filter((a) => a.amount > 0);

      const totalSupplied = newSupplied.reduce((sum, a) => sum + a.usdValue, 0);
      const totalBorrowed = s.userPosition.borrowed.reduce((sum, a) => sum + a.usdValue, 0);
      const healthFactor = totalBorrowed > 0 ? (totalSupplied * s.userPosition.liquidationThreshold / 100) / totalBorrowed : 999;

      const tx: Transaction = {
        id: String(Date.now()),
        type: "withdraw",
        asset: symbol,
        amount,
        timestamp: Date.now(),
        hash: "0x" + Math.random().toString(16).slice(2) + Math.random().toString(16).slice(2),
        status: "completed",
      };

      return {
        userPosition: { ...s.userPosition, supplied: newSupplied, totalSupplied, healthFactor, availableToBorrow: totalSupplied * s.userPosition.loanToValue / 100 - totalBorrowed },
        transactions: [tx, ...s.transactions],
        assets: s.assets.map((a) => a.symbol === symbol ? { ...a, totalSupply: Math.max(0, a.totalSupply - amount * a.price) } : a),
      };
    }),

  toggleCollateral: (symbol) =>
    set((s) => ({
      userPosition: {
        ...s.userPosition,
        supplied: s.userPosition.supplied.map((a) => (a.symbol === symbol ? { ...a, isCollateral: !a.isCollateral } : a)),
      },
    })),

  enableEMode: (categoryId) => set({ activeEModeCategory: categoryId }),
  disableEMode: () => set({ activeEModeCategory: null }),
}));
