export interface Asset {
  symbol: string;
  name: string;
  decimals: number;
  price: number;
  supplyAPY: number;
  borrowAPY: number;
  totalSupply: number;
  totalBorrow: number;
  utilization: number;
  collateralFactor: number;
  liquidationThreshold: number;
  canCollateral: boolean;
  canBorrow: boolean;
  eModeCategory: string;
}

export interface SuppliedAsset {
  symbol: string;
  amount: number;
  usdValue: number;
  isCollateral: boolean;
  apy: number;
}

export interface BorrowedAsset {
  symbol: string;
  amount: number;
  usdValue: number;
  apy: number;
  stableRate?: number;
}

export interface UserPosition {
  supplied: SuppliedAsset[];
  borrowed: BorrowedAsset[];
  healthFactor: number;
  netAPY: number;
  totalSupplied: number;
  totalBorrowed: number;
  availableToBorrow: number;
  liquidationThreshold: number;
  loanToValue: number;
}

export interface Pool {
  name: string;
  assets: string[];
  eModeEnabled: boolean;
  isolationMode: boolean;
  totalTVL: number;
}

export interface EModeCategory {
  id: number;
  label: string;
  assets: string[];
  collateralFactor: number;
  liquidationThreshold: number;
  borrowAPYMultiplier: number;
}

export type TransactionType = "supply" | "borrow" | "repay" | "withdraw" | "liquidation";

export type TransactionStatus = "completed" | "pending" | "failed";

export interface Transaction {
  id: string;
  type: TransactionType;
  asset: string;
  amount: number;
  timestamp: number;
  hash: string;
  status: TransactionStatus;
}

export interface LiquidationEvent {
  id: string;
  borrower: string;
  collateralSeized: string;
  collateralSeizedAmount: number;
  debtRepaid: string;
  debtRepaidAmount: number;
  liquidator: string;
  bonus: number;
  timestamp: number;
  healthFactor: number;
}

export type SortField = "symbol" | "totalSupply" | "totalBorrow" | "supplyAPY" | "borrowAPY" | "utilization";

export type SortDirection = "asc" | "desc";

export interface SortConfig {
  field: SortField;
  direction: SortDirection;
}
