import { useLendingStore } from "@/store/lending-store";
import { formatUSD, formatAPY, formatNumber } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowUpRight, ArrowDownRight } from "lucide-react";
import type { Asset } from "@/types";

const TOKEN_ICONS: Record<string, string> = {
  WETH: "⟠", WBTC: "₿", USDC: "$", USDT: "₮", DAI: "◆",
  LINK: "⬡", AAVE: "◈", UNI: "🦄", CRV: "🔄", stETH: "♦",
  cbETH: "◆", GHO: "👻",
};

export function AssetRow({ asset, onSupply, onBorrow }: { asset: Asset; onSupply: (a: Asset) => void; onBorrow: (a: Asset) => void }) {
  const userPosition = useLendingStore((s) => s.userPosition);
  const isSupplied = userPosition.supplied.some((s) => s.symbol === asset.symbol);
  const isBorrowed = userPosition.borrowed.some((b) => b.symbol === asset.symbol);

  return (
    <tr className="border-b border-border hover:bg-card-hover/50 transition-colors">
      <td className="p-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-border-light flex items-center justify-center text-sm">
            {TOKEN_ICONS[asset.symbol] || "?"}
          </div>
          <div>
            <div className="font-medium text-white flex items-center gap-2">
              {asset.symbol}
              {isSupplied && <Badge variant="success" className="text-[10px] px-1.5 py-0">Supplied</Badge>}
              {isBorrowed && <Badge variant="warning" className="text-[10px] px-1.5 py-0">Borrowed</Badge>}
            </div>
            <div className="text-xs text-muted-foreground">{asset.name}</div>
          </div>
        </div>
      </td>
      <td className="p-4 text-right">
        <div className="font-medium">{formatUSD(asset.totalSupply)}</div>
        <div className="text-xs text-muted-foreground">{formatNumber(asset.totalSupply / asset.price, 0)} {asset.symbol}</div>
      </td>
      <td className="p-4 text-right">
        <div className="font-medium">{formatUSD(asset.totalBorrow)}</div>
        <div className="text-xs text-muted-foreground">{formatNumber(asset.totalBorrow / asset.price, 0)} {asset.symbol}</div>
      </td>
      <td className="p-4 text-right">
        <div className="text-primary font-medium">{formatAPY(asset.supplyAPY)}</div>
        <div className="flex items-center justify-end gap-1 text-xs text-muted-foreground">
          <ArrowUpRight className="w-3 h-3 text-primary" /> Supply
        </div>
      </td>
      <td className="p-4 text-right">
        <div className="text-danger font-medium">{formatAPY(asset.borrowAPY)}</div>
        <div className="flex items-center justify-end gap-1 text-xs text-muted-foreground">
          <ArrowDownRight className="w-3 h-3 text-danger" /> Borrow
        </div>
      </td>
      <td className="p-4 text-right text-muted-foreground">{asset.utilization.toFixed(1)}%</td>
      <td className="p-4">
        <div className="flex items-center gap-2 justify-end">
          <Button size="sm" variant="outline" onClick={() => onSupply(asset)}>Supply</Button>
          {asset.canBorrow && <Button size="sm" variant="secondary" onClick={() => onBorrow(asset)}>Borrow</Button>}
        </div>
      </td>
    </tr>
  );
}
