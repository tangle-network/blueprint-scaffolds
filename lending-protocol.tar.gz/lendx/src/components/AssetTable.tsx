import { useState, useMemo } from "react";
import { useLendingStore } from "@/store/lending-store";
import { AssetRow } from "./AssetRow";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Search, ArrowUpDown } from "lucide-react";
import type { Asset, SortField } from "@/types";

export function AssetTable({ onSupply, onBorrow }: { onSupply: (a: Asset) => void; onBorrow: (a: Asset) => void }) {
  const { assets, userPosition, searchQuery, setSearchQuery, sortField, sortDirection, setSort } = useLendingStore();
  const [tab, setTab] = useState("all");

  const suppliedSymbols = new Set(userPosition.supplied.map((s) => s.symbol));
  const borrowedSymbols = new Set(userPosition.borrowed.map((b) => b.symbol));

  const filtered = useMemo(() => {
    let list = assets;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      list = list.filter((a) => a.symbol.toLowerCase().includes(q) || a.name.toLowerCase().includes(q));
    }
    if (tab === "supplied") list = list.filter((a) => suppliedSymbols.has(a.symbol));
    if (tab === "borrowed") list = list.filter((a) => borrowedSymbols.has(a.symbol));

    return [...list].sort((a, b) => {
      const dir = sortDirection === "asc" ? 1 : -1;
      const field = sortField as SortField;
      if (field === "symbol") return dir * a.symbol.localeCompare(b.symbol);
      return dir * ((a[field] as number) - (b[field] as number));
    });
  }, [assets, searchQuery, tab, sortField, sortDirection, suppliedSymbols, borrowedSymbols]);

  const sortable = (label: string, field: SortField) => (
    <button className="flex items-center gap-1 hover:text-white transition-colors" onClick={() => setSort(field)}>
      {label} <ArrowUpDown className="w-3 h-3" />
    </button>
  );

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Protocol Markets</CardTitle>
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Search assets..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-9" />
          </div>
        </div>
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList>
            <TabsTrigger value="all">All Assets ({assets.length})</TabsTrigger>
            <TabsTrigger value="supplied">Supplied ({suppliedSymbols.size})</TabsTrigger>
            <TabsTrigger value="borrowed">Borrowed ({borrowedSymbols.size})</TabsTrigger>
          </TabsList>
        </Tabs>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-muted-foreground">
                <th className="p-4 text-left">{sortable("Asset", "symbol")}</th>
                <th className="p-4 text-right">{sortable("Total Supplied", "totalSupply")}</th>
                <th className="p-4 text-right">{sortable("Total Borrowed", "totalBorrow")}</th>
                <th className="p-4 text-right">{sortable("Supply APY", "supplyAPY")}</th>
                <th className="p-4 text-right">{sortable("Borrow APY", "borrowAPY")}</th>
                <th className="p-4 text-right">{sortable("Utilization", "utilization")}</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((asset) => (
                <AssetRow key={asset.symbol} asset={asset} onSupply={onSupply} onBorrow={onBorrow} />
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
