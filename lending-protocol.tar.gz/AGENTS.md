# DeFi Lending Protocol - Build Plan

## Project Structure

```
/home/agent/
├── package.json
├── tsconfig.json
├── tsconfig.node.json
├── vite.config.ts
├── tailwind.config.ts
├── postcss.config.js
├── components.json
├── index.html
├── AGENTS.md
├── contracts/
│   ├── LendingPool.sol
│   ├── InterestRateStrategy.sol
│   ├── PriceOracle.sol
│   ├── FlashLoan.sol
│   ├── CreditDelegation.sol
│   └── IsolatedPool.sol
├── src/
│   ├── main.tsx
│   ├── App.tsx
│   ├── index.css
│   ├── lib/
│   │   ├── utils.ts
│   │   ├── constants.ts
│   │   └── protocols.ts
│   ├── hooks/
│   │   ├── useLendingProtocol.ts
│   │   ├── useWallet.ts
│   │   └── useDebounce.ts
│   ├── contracts/
│   │   ├── abis.ts
│   │   └── addresses.ts
│   ├── components/
│   │   ├── ui/
│   │   │   ├── button.tsx
│   │   │   ├── card.tsx
│   │   │   ├── input.tsx
│   │   │   ├── badge.tsx
│   │   │   ├── progress.tsx
│   │   │   ├── select.tsx
│   │   │   ├── slider.tsx
│   │   │   ├── tabs.tsx
│   │   │   ├── dialog.tsx
│   │   │   ├── toast.tsx
│   │   │   └── separator.tsx
│   │   ├── Layout.tsx
│   │   ├── Header.tsx
│   │   ├── Sidebar.tsx
│   │   ├── AssetCard.tsx
│   │   ├── SupplyBorrowModal.tsx
│   │   ├── LiquidationPanel.tsx
│   │   ├── FlashLoanPanel.tsx
│   │   ├── CreditDelegationPanel.tsx
│   │   ├── EModePanel.tsx
│   │   ├── PoolSelector.tsx
│   │   ├── HealthFactorGauge.tsx
│   │   ├── InterestRateChart.tsx
│   │   ├── PortfolioOverview.tsx
│   │   └── TransactionToast.tsx
│   └── pages/
│       ├── Dashboard.tsx
│       ├── Markets.tsx
│       ├── Portfolio.tsx
│       ├── Liquidations.tsx
│       └── FlashLoans.tsx
```

## Pages

1. **Dashboard** - Portfolio overview, health factor, total supply/borrow, asset breakdown
2. **Markets** - All available markets with supply/borrow rates, TVL, utilization
3. **Portfolio** - User positions, collateral management, e-mode settings
4. **Liquidations** - Liquidation opportunities, execute liquidations
5. **FlashLoans** - Flash loan interface with custom logic

## Smart Contracts (Solidity)

- **LendingPool.sol** - Core pool: supply, borrow, repay, withdraw, liquidation
- **InterestRateStrategy.sol** - Utilization-based interest rate curves (kinked model)
- **PriceOracle.sol** - Chainlink oracle integration for price feeds
- **FlashLoan.sol** - Flash loan with callback pattern
- **CreditDelegation.sol** - Open debt allowances for credit delegation
- **IsolatedPool.sol** - Isolated risk pools with single collateral

## Build & Run

```bash
pnpm install
pnpm build
```
