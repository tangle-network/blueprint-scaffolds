// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IERC20 {
    function balanceOf(address account) external view returns (uint256);

    function transfer(address to, uint256 amount) external returns (bool);

    function transferFrom(address from, address to, uint256 amount) external returns (bool);
}

interface IFlashLoanReceiver {
    function executeOperation(address asset, uint256 amount, uint256 premium, address initiator, bytes calldata params)
        external
        returns (bool);
}

interface IPriceOracle {
    function getAssetPrice(address asset) external view returns (uint256);
}

interface IInterestRateStrategy {
    function calculateVariableBorrowRate(uint256 totalLiquidity, uint256 totalDebt) external view returns (uint256);
}

contract LendingPool {
    struct ReserveData {
        uint128 totalLiquidity;
        uint128 totalDebt;
        uint16 collateralFactorBps;
        uint16 liquidationThresholdBps;
        uint16 liquidationBonusBps;
        uint16 flashLoanFeeBps;
        uint32 eModeCategory;
        uint128 debtCeiling;
        bool active;
        bool isolated;
    }

    struct UserConfiguration {
        bool eModeEnabled;
        uint256 delegatedCredit;
    }

    uint256 public constant BPS = 10_000;
    address public immutable oracle;
    address public immutable interestRateStrategy;
    address public owner;

    mapping(address => ReserveData) public reserves;
    mapping(address => mapping(address => uint256)) public supplied;
    mapping(address => mapping(address => uint256)) public borrowed;
    mapping(address => UserConfiguration) public users;

    error NotOwner();
    error ReserveInactive();
    error InsufficientCollateral();
    error UnhealthyPosition();
    error FlashLoanNotRepaid();
    error InvalidAmount();

    event Supplied(address indexed user, address indexed asset, uint256 amount);
    event Borrowed(address indexed user, address indexed asset, uint256 amount);
    event Repaid(address indexed user, address indexed asset, uint256 amount);
    event Liquidated(address indexed user, address indexed collateralAsset, address indexed debtAsset, uint256 repaid);
    event FlashLoan(address indexed receiver, address indexed asset, uint256 amount, uint256 premium);

    constructor(address _oracle, address _interestRateStrategy) {
        oracle = _oracle;
        interestRateStrategy = _interestRateStrategy;
        owner = msg.sender;
    }

    modifier onlyOwner() {
        if (msg.sender != owner) revert NotOwner();
        _;
    }

    function configureReserve(address asset, ReserveData calldata config) external onlyOwner {
        reserves[asset] = config;
    }

    function setEMode(bool enabled) external {
        users[msg.sender].eModeEnabled = enabled;
    }

    function delegateCredit(address delegatee, uint256 amount) external {
        users[delegatee].delegatedCredit = amount;
    }

    function supply(address asset, uint256 amount) external {
        if (amount == 0) revert InvalidAmount();
        ReserveData storage reserve = reserves[asset];
        if (!reserve.active) revert ReserveInactive();

        IERC20(asset).transferFrom(msg.sender, address(this), amount);
        reserve.totalLiquidity += uint128(amount);
        supplied[msg.sender][asset] += amount;

        emit Supplied(msg.sender, asset, amount);
    }

    function borrow(address asset, uint256 amount) external {
        if (amount == 0) revert InvalidAmount();
        ReserveData storage reserve = reserves[asset];
        if (!reserve.active) revert ReserveInactive();
        if (!_isBorrowAllowed(msg.sender, asset, amount)) revert InsufficientCollateral();

        reserve.totalDebt += uint128(amount);
        borrowed[msg.sender][asset] += amount;
        IERC20(asset).transfer(msg.sender, amount);

        emit Borrowed(msg.sender, asset, amount);
    }

    function repay(address asset, uint256 amount) external {
        if (amount == 0) revert InvalidAmount();
        ReserveData storage reserve = reserves[asset];
        IERC20(asset).transferFrom(msg.sender, address(this), amount);

        uint256 debt = borrowed[msg.sender][asset];
        uint256 repaid = amount > debt ? debt : amount;
        reserve.totalDebt -= uint128(repaid);
        borrowed[msg.sender][asset] = debt - repaid;

        emit Repaid(msg.sender, asset, repaid);
    }

    function liquidationCall(address user, address debtAsset, address collateralAsset, uint256 debtToCover) external {
        if (healthFactor(user) >= 1e18) revert UnhealthyPosition();

        ReserveData storage collateralReserve = reserves[collateralAsset];
        uint256 debtPrice = IPriceOracle(oracle).getAssetPrice(debtAsset);
        uint256 collateralPrice = IPriceOracle(oracle).getAssetPrice(collateralAsset);

        IERC20(debtAsset).transferFrom(msg.sender, address(this), debtToCover);
        borrowed[user][debtAsset] -= debtToCover;
        reserves[debtAsset].totalDebt -= uint128(debtToCover);

        uint256 collateralAmount =
            (debtToCover * debtPrice * (BPS + collateralReserve.liquidationBonusBps)) / collateralPrice / BPS;
        supplied[user][collateralAsset] -= collateralAmount;
        IERC20(collateralAsset).transfer(msg.sender, collateralAmount);

        emit Liquidated(user, collateralAsset, debtAsset, debtToCover);
    }

    function flashLoan(address receiver, address asset, uint256 amount, bytes calldata params) external {
        ReserveData storage reserve = reserves[asset];
        if (!reserve.active) revert ReserveInactive();
        uint256 premium = (amount * reserve.flashLoanFeeBps) / BPS;
        uint256 balanceBefore = IERC20(asset).balanceOf(address(this));

        IERC20(asset).transfer(receiver, amount);
        bool success = IFlashLoanReceiver(receiver).executeOperation(asset, amount, premium, msg.sender, params);
        require(success, "CALLBACK_FAILED");

        uint256 balanceAfter = IERC20(asset).balanceOf(address(this));
        if (balanceAfter < balanceBefore + premium) revert FlashLoanNotRepaid();

        emit FlashLoan(receiver, asset, amount, premium);
    }

    function getVariableBorrowRate(address asset) external view returns (uint256) {
        ReserveData storage reserve = reserves[asset];
        return IInterestRateStrategy(interestRateStrategy).calculateVariableBorrowRate(
            reserve.totalLiquidity, reserve.totalDebt
        );
    }

    function healthFactor(address user) public view returns (uint256) {
        uint256 debtValue = _accountDebtValue(user);
        if (debtValue == 0) {
            return type(uint256).max;
        }

        uint256 collateralThresholdValue = _accountCollateralThresholdValue(user);
        return (collateralThresholdValue * 1e18) / debtValue;
    }

    function _isBorrowAllowed(address user, address asset, uint256 amount) internal view returns (bool) {
        uint256 collateralCapacity = _accountCollateralCapacity(user);
        uint256 newDebt = _accountDebtValue(user) + (amount * IPriceOracle(oracle).getAssetPrice(asset)) / 1e18;
        return collateralCapacity + users[user].delegatedCredit >= newDebt;
    }

    function _accountCollateralCapacity(address user) internal view returns (uint256) {
        return _weightedCollateralValue(user, false);
    }

    function _accountCollateralThresholdValue(address user) internal view returns (uint256) {
        return _weightedCollateralValue(user, true);
    }

    function _weightedCollateralValue(address user, bool useLiquidationThreshold) internal view returns (uint256 totalValue) {
        // Production systems track listed reserves explicitly; this minimal version focuses on accounting logic.
        address[5] memory assets = [
            address(0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE),
            address(0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599),
            address(0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48),
            address(0x6B175474E89094C44Da98b954EedeAC495271d0F),
            address(0xae7ab96520DE3A18E5e111B5EaAb095312D7fE84)
        ];

        for (uint256 i = 0; i < assets.length; i++) {
            address asset = assets[i];
            uint256 amount = supplied[user][asset];
            if (amount == 0) continue;

            ReserveData storage reserve = reserves[asset];
            uint256 price = IPriceOracle(oracle).getAssetPrice(asset);
            uint256 basisPoints =
                useLiquidationThreshold ? reserve.liquidationThresholdBps : reserve.collateralFactorBps;
            if (users[user].eModeEnabled && reserve.eModeCategory != 0) {
                basisPoints += 250;
            }
            totalValue += (amount * price * basisPoints) / BPS / 1e18;
        }
    }

    function _accountDebtValue(address user) internal view returns (uint256 totalValue) {
        address[5] memory assets = [
            address(0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE),
            address(0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599),
            address(0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48),
            address(0x6B175474E89094C44Da98b954EedeAC495271d0F),
            address(0xae7ab96520DE3A18E5e111B5EaAb095312D7fE84)
        ];

        for (uint256 i = 0; i < assets.length; i++) {
            address asset = assets[i];
            uint256 amount = borrowed[user][asset];
            if (amount == 0) continue;
            uint256 price = IPriceOracle(oracle).getAssetPrice(asset);
            totalValue += (amount * price) / 1e18;
        }
    }
}
