// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "./Interfaces.sol";

contract LendingPool is ILendingPool {
    struct ReserveConfiguration {
        uint256 ltv;
        uint256 liquidationThreshold;
        uint256 liquidationBonus;
        uint256 reserveFactor;
        bool isActive;
        bool isFrozen;
    }

    struct UserReserveData {
        uint256 scaledATokenBalance;
        uint256 scaledVariableDebtBalance;
        bool usageAsCollateralEnabled;
    }

    struct EModeCategory {
        uint256 ltv;
        uint256 liquidationThreshold;
        uint256 liquidationBonus;
        string label;
    }

    mapping(address => ReserveData) public reserves;
    mapping(address => ReserveConfiguration) public reserveConfig;
    mapping(address => mapping(address => UserReserveData)) public userReserveData;
    mapping(address => uint8) public userEModeCategory;
    mapping(uint8 => EModeCategory) public eModeCategories;

    address public owner;
    address public priceOracle;
    uint256 public constant HEALTH_FACTOR_LIQUIDATION_THRESHOLD = 1e18;
    uint256 public constant LTV_PRECISION = 100;
    uint256 public constant LIQUIDATION_CLOSE_FACTOR = 5000;

    event Supply(address indexed asset, address indexed user, uint256 amount);
    event Borrow(address indexed asset, address indexed user, uint256 amount);
    event Repay(address indexed asset, address indexed user, uint256 amount);
    event Withdraw(address indexed asset, address indexed user, uint256 amount);
    event LiquidationCall(address indexed collateral, address indexed debt, address indexed user, uint256 debtToCover);

    modifier onlyOwner() {
        require(msg.sender == owner, "Only owner");
        _;
    }

    constructor(address _priceOracle) {
        owner = msg.sender;
        priceOracle = _priceOracle;
        eModeCategories[0] = EModeCategory(0, 0, 0, "None");
        eModeCategories[1] = EModeCategory(9700, 9750, 10050, "Stablecoins");
    }

    function initReserve(
        address asset,
        address aTokenAddress,
        address variableDebtTokenAddress,
        address interestRateStrategyAddress,
        uint256 ltv,
        uint256 liquidationThreshold,
        uint256 liquidationBonus,
        uint256 reserveFactor
    ) external onlyOwner {
        reserves[asset] = ReserveData({
            configuration: 0,
            liquidityIndex: 1e27,
            variableBorrowIndex: 1e27,
            currentLiquidityRate: 0,
            currentVariableBorrowRate: 0,
            lastUpdateTimestamp: uint40(block.timestamp),
            aTokenAddress: aTokenAddress,
            variableDebtTokenAddress: variableDebtTokenAddress,
            interestRateStrategyAddress: interestRateStrategyAddress
        });
        reserveConfig[asset] = ReserveConfiguration({
            ltv: ltv,
            liquidationThreshold: liquidationThreshold,
            liquidationBonus: liquidationBonus,
            reserveFactor: reserveFactor,
            isActive: true,
            isFrozen: false
        });
    }

    function supply(address asset, uint256 amount, address onBehalfOf, uint16) external override {
        ReserveConfiguration storage config = reserveConfig[asset];
        require(config.isActive && !config.isFrozen, "Reserve not active");
        require(amount > 0, "Invalid amount");

        _updateState(asset);

        UserReserveData storage userData = userReserveData[asset][onBehalfOf];
        userData.scaledATokenBalance += amount;
        if (!userData.usageAsCollateralEnabled) {
            userData.usageAsCollateralEnabled = true;
        }

        emit Supply(asset, onBehalfOf, amount);
    }

    function borrow(address asset, uint256 amount, uint256, uint16, address onBehalfOf) external override {
        ReserveConfiguration storage config = reserveConfig[asset];
        require(config.isActive && !config.isFrozen, "Reserve not active");
        require(amount > 0, "Invalid amount");

        _updateState(asset);

        userReserveData[asset][onBehalfOf].scaledVariableDebtBalance += amount;

        (uint256 totalCollateral, uint256 totalDebt,,,, uint256 healthFactor) = getUserAccountData(onBehalfOf);
        require(healthFactor >= HEALTH_FACTOR_LIQUIDATION_THRESHOLD, "Insufficient collateral");

        emit Borrow(asset, onBehalfOf, amount);
    }

    function repay(address asset, uint256 amount, uint256, address onBehalfOf) external override returns (uint256) {
        _updateState(asset);
        UserReserveData storage userData = userReserveData[asset][onBehalfOf];
        uint256 debt = userData.scaledVariableDebtBalance;
        uint256 repayAmount = amount > debt ? debt : amount;
        userData.scaledVariableDebtBalance -= repayAmount;
        emit Repay(asset, onBehalfOf, repayAmount);
        return repayAmount;
    }

    function withdraw(address asset, uint256 amount, address to) external override returns (uint256) {
        _updateState(asset);
        UserReserveData storage userData = userReserveData[asset][msg.sender];
        uint256 balance = userData.scaledATokenBalance;
        uint256 withdrawAmount = amount > balance ? balance : amount;
        userData.scaledATokenBalance -= withdrawAmount;
        emit Withdraw(asset, to, withdrawAmount);
        return withdrawAmount;
    }

    function liquidationCall(
        address collateralAsset,
        address debtAsset,
        address user,
        uint256 debtToCover,
        bool
    ) external override {
        _updateState(debtAsset);
        (,,,,, uint256 healthFactor) = getUserAccountData(user);
        require(healthFactor < HEALTH_FACTOR_LIQUIDATION_THRESHOLD, "Position healthy");

        UserReserveData storage debtData = userReserveData[debtAsset][user];
        uint256 maxDebtCover = (debtData.scaledVariableDebtBalance * LIQUIDATION_CLOSE_FACTOR) / 10000;
        uint256 actualDebtCover = debtToCover > maxDebtCover ? maxDebtCover : debtToCover;
        debtData.scaledVariableDebtBalance -= actualDebtCover;

        ReserveConfiguration storage collConfig = reserveConfig[collateralAsset];
        uint256 bonus = collConfig.liquidationBonus;
        uint256 collateralSeized = (actualDebtCover * bonus) / 10000;

        UserReserveData storage collData = userReserveData[collateralAsset][user];
        collData.scaledATokenBalance -= collateralSeized;

        emit LiquidationCall(collateralAsset, debtAsset, user, actualDebtCover);
    }

    function getReserveData(address asset) external view override returns (ReserveData memory) {
        return reserves[asset];
    }

    function getUserAccountData(address user) public view override returns (
        uint256 totalCollateralBase,
        uint256 totalDebtBase,
        uint256 availableBorrowsBase,
        uint256 currentLiquidationThreshold,
        uint256 ltv,
        uint256 healthFactor
    ) {
        address[] memory assets = _getUserAssets(user);
        uint8 eMode = userEModeCategory[user];

        for (uint256 i = 0; i < assets.length; i++) {
            address asset = assets[i];
            UserReserveData memory userData = userReserveData[asset][user];
            uint256 price = IPriceOracle(priceOracle).getAssetPrice(asset);

            uint256 collateralBalance = userData.scaledATokenBalance;
            if (collateralBalance > 0 && userData.usageAsCollateralEnabled) {
                uint256 assetThreshold;
                uint256 assetLtv;
                if (eMode > 0) {
                    EModeCategory storage cat = eModeCategories[eMode];
                    assetLtv = cat.ltv;
                    assetThreshold = cat.liquidationThreshold;
                } else {
                    assetLtv = reserveConfig[asset].ltv;
                    assetThreshold = reserveConfig[asset].liquidationThreshold;
                }
                totalCollateralBase += (collateralBalance * price * assetLtv) / (10000 * 1e8);
                currentLiquidationThreshold += (collateralBalance * price * assetThreshold) / (10000 * 1e8);
            }

            uint256 debtBalance = userData.scaledVariableDebtBalance;
            if (debtBalance > 0) {
                totalDebtBase += (debtBalance * price) / 1e8;
            }
        }

        availableBorrowsBase = totalCollateralBase > totalDebtBase ? totalCollateralBase - totalDebtBase : 0;
        ltv = totalCollateralBase;

        if (totalDebtBase == 0) {
            healthFactor = type(uint256).max;
        } else {
            healthFactor = (currentLiquidationThreshold * 1e18) / totalDebtBase;
        }
    }

    function setUserEMode(uint8 categoryId) external {
        require(categoryId == 0 || eModeCategories[categoryId].ltv > 0, "Invalid e-mode");
        userEModeCategory[msg.sender] = categoryId;
    }

    function _updateState(address asset) internal {
        ReserveData storage reserve = reserves[asset];
        if (block.timestamp > reserve.lastUpdateTimestamp) {
            reserve.lastUpdateTimestamp = uint40(block.timestamp);
        }
    }

    function _getUserAssets(address) internal pure returns (address[] memory) {
        address[] memory assets = new address[](5);
        assets[0] = 0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE;
        return assets;
    }
}
