// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract InterestRateStrategy {
    uint256 public immutable optimalUtilizationRate;
    uint256 public immutable baseVariableBorrowRate;
    uint256 public immutable variableRateSlope1;
    uint256 public immutable variableRateSlope2;
    uint256 public constant RAY = 1e27;

    constructor(
        uint256 _optimalUtilizationRate,
        uint256 _baseVariableBorrowRate,
        uint256 _variableRateSlope1,
        uint256 _variableRateSlope2
    ) {
        optimalUtilizationRate = _optimalUtilizationRate;
        baseVariableBorrowRate = _baseVariableBorrowRate;
        variableRateSlope1 = _variableRateSlope1;
        variableRateSlope2 = _variableRateSlope2;
    }

    function calculateVariableBorrowRate(uint256 totalLiquidity, uint256 totalDebt) external view returns (uint256) {
        if (totalDebt == 0 || totalLiquidity == 0) {
            return baseVariableBorrowRate;
        }

        uint256 utilization = (totalDebt * RAY) / totalLiquidity;
        if (utilization <= optimalUtilizationRate) {
            return baseVariableBorrowRate + (utilization * variableRateSlope1) / optimalUtilizationRate;
        }

        uint256 excessUtilization = utilization - optimalUtilizationRate;
        uint256 excessRatio = (excessUtilization * RAY) / (RAY - optimalUtilizationRate);
        return baseVariableBorrowRate + variableRateSlope1 + (variableRateSlope2 * excessRatio) / RAY;
    }
}
