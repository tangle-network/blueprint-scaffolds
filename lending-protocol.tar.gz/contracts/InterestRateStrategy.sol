// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "./Interfaces.sol";

contract InterestRateStrategy is IInterestRateStrategy {
    uint256 public immutable OPTIMAL_UTILIZATION_RATE;
    uint256 public immutable BASE_VARIABLE_BORROW_RATE;
    uint256 public immutable VARIABLE_RATE_SLOPE1;
    uint256 public immutable VARIABLE_RATE_SLOPE2;
    uint256 public constant UTILIZATION_PRECISION = 1e4;

    constructor(
        uint256 optimalUtilizationRate,
        uint256 baseVariableBorrowRate,
        uint256 variableRateSlope1,
        uint256 variableRateSlope2
    ) {
        OPTIMAL_UTILIZATION_RATE = optimalUtilizationRate;
        BASE_VARIABLE_BORROW_RATE = baseVariableBorrowRate;
        VARIABLE_RATE_SLOPE1 = variableRateSlope1;
        VARIABLE_RATE_SLOPE2 = variableRateSlope2;
    }

    function calculateInterestRates(
        uint256 availableLiquidity,
        uint256 totalVariableDebt,
        uint256
    ) external view override returns (uint256 currentBorrowRate, uint256 currentSupplyRate) {
        if (totalVariableDebt == 0) {
            return (BASE_VARIABLE_BORROW_RATE, 0);
        }

        uint256 totalDebt = totalVariableDebt;
        uint256 totalLiquidity = availableLiquidity + totalDebt;
        uint256 utilizationRate = (totalDebt * UTILIZATION_PRECISION) / totalLiquidity;

        if (utilizationRate < OPTIMAL_UTILIZATION_RATE) {
            currentBorrowRate = BASE_VARIABLE_BORROW_RATE +
                ((utilizationRate * VARIABLE_RATE_SLOPE1) / OPTIMAL_UTILIZATION_RATE);
        } else {
            uint256 excessUtilization = utilizationRate - OPTIMAL_UTILIZATION_RATE;
            uint256 maxExcess = UTILIZATION_PRECISION - OPTIMAL_UTILIZATION_RATE;
            currentBorrowRate = BASE_VARIABLE_BORROW_RATE +
                VARIABLE_RATE_SLOPE1 +
                ((excessUtilization * VARIABLE_RATE_SLOPE2) / maxExcess);
        }

        uint256 borrowRate = currentBorrowRate;
        uint256 reserveFactor = 1000;
        currentSupplyRate = (borrowRate * utilizationRate * (10000 - reserveFactor)) / (10000 * UTILIZATION_PRECISION);
    }
}
