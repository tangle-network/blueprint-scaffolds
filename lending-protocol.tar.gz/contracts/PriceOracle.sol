// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "./Interfaces.sol";

contract PriceOracle is IPriceOracle {
    mapping(address => uint256) public assetPrices;
    address public owner;
    uint256 public constant PRICE_PRECISION = 1e8;

    event AssetPriceUpdated(address indexed asset, uint256 price);
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    modifier onlyOwner() {
        require(msg.sender == owner, "Only owner");
        _;
    }

    constructor() {
        owner = msg.sender;
    }

    function setAssetPrice(address asset, uint256 price) external onlyOwner {
        require(asset != address(0), "Invalid asset");
        require(price > 0, "Invalid price");
        assetPrices[asset] = price;
        emit AssetPriceUpdated(asset, price);
    }

    function setAssetPrices(address[] calldata assets, uint256[] calldata prices) external onlyOwner {
        require(assets.length == prices.length, "Length mismatch");
        for (uint256 i = 0; i < assets.length; i++) {
            assetPrices[assets[i]] = prices[i];
            emit AssetPriceUpdated(assets[i], prices[i]);
        }
    }

    function getAssetPrice(address asset) external view override returns (uint256) {
        uint256 price = assetPrices[asset];
        require(price > 0, "Price not set");
        return price;
    }

    function getAssetsPrices(address[] calldata assets) external view override returns (uint256[] memory) {
        uint256[] memory prices = new uint256[](assets.length);
        for (uint256 i = 0; i < assets.length; i++) {
            prices[i] = assetPrices[assets[i]];
            require(prices[i] > 0, "Price not set");
        }
        return prices;
    }
}
