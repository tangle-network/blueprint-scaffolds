// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface AggregatorV3Interface {
    function decimals() external view returns (uint8);

    function latestRoundData()
        external
        view
        returns (uint80, int256, uint256, uint256 updatedAt, uint80);
}

contract ChainlinkOracle {
    mapping(address => AggregatorV3Interface) public feeds;
    address public owner;
    uint256 public maxPriceAge = 1 hours;

    error NotOwner();
    error FeedNotConfigured();
    error InvalidPrice();
    error StalePrice();

    constructor() {
        owner = msg.sender;
    }

    modifier onlyOwner() {
        if (msg.sender != owner) revert NotOwner();
        _;
    }

    function setFeed(address asset, address feed) external onlyOwner {
        feeds[asset] = AggregatorV3Interface(feed);
    }

    function setMaxPriceAge(uint256 newMaxPriceAge) external onlyOwner {
        maxPriceAge = newMaxPriceAge;
    }

    function getAssetPrice(address asset) external view returns (uint256 normalizedPrice) {
        AggregatorV3Interface feed = feeds[asset];
        if (address(feed) == address(0)) revert FeedNotConfigured();

        (, int256 answer, , uint256 updatedAt, ) = feed.latestRoundData();
        if (answer <= 0) revert InvalidPrice();
        if (updatedAt + maxPriceAge < block.timestamp) revert StalePrice();

        uint8 decimals = feed.decimals();
        normalizedPrice = uint256(answer);
        if (decimals < 18) {
            normalizedPrice *= 10 ** (18 - decimals);
        } else if (decimals > 18) {
            normalizedPrice /= 10 ** (decimals - 18);
        }
    }
}
