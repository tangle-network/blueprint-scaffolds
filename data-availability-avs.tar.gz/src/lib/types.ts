export interface Operator {
  id: string
  address: string
  enclave: string
  stake: number
  status: 'active' | 'inactive' | 'slashed' | 'pending'
  lat: number
  lon: number
  region: string
  bandwidthMbps: number
  uptimePct: number
  blobsStored: number
  totalEarned: number
  registeredAt: number
  lastHeartbeat: number
  performanceScore: number
}

export interface BlobBatch {
  id: string
  batchHash: string
  rollupId: string
  rollupName: string
  dataSize: number
  encodedSize: number
  compressedSize: number
  numChunks: number
  quorumId: number
  confirmationThreshold: number
  confirmations: number
  kzgCommitment: string
  kzgProof: string
  status: 'confirmed' | 'pending' | 'finalizing' | 'expired' | 'failed'
  submittedAt: number
  expiresAt: number
  confirmationTime: number
  fee: number
  erasureCodingRatio: [number, number]
  samplingSuccessRate: number
}

export interface NetworkStats {
  totalOperators: number
  activeOperators: number
  totalStake: number
  totalBlobs: number
  totalDataStored: number
  avgConfirmationTime: number
  networkUptime: number
  currentEpoch: number
  blobsLast24h: number
  throughputMBps: number
  avgFeePerMB: number
  slashingEvents: number
}

export interface QuorumInfo {
  id: number
  name: string
  operators: number
  totalStake: number
  minStake: number
  status: 'active' | 'paused'
  agreementThreshold: number
  geographicSpread: string[]
}

export interface FraudProof {
  id: string
  blobId: string
  reporter: string
  operatorAddr: string
  type: 'invalid_encoding' | 'data_unavailable' | 'incorrect_commitment' | 'sampling_failure'
  status: 'pending' | 'verified' | 'disputed' | 'resolved' | 'rejected'
  evidence: string
  submittedAt: number
  resolvedAt?: number
  slashedAmount?: number
}

export interface SamplingResult {
  blobId: string
  totalSamples: number
  successfulSamples: number
  failedSamples: number
  lastSampledAt: number
  samplingPeriodMs: number
}

export interface CostEstimate {
  dataSizeMB: number
  redundancyLevel: number
  guaranteeWeeks: number
  baseCost: number
  redundancyCost: number
  guaranteeCost: number
  totalCost: number
  confirmationTimeEstimate: number
}

export interface RollupProfile {
  id: string
  name: string
  logo?: string
  totalBlobs: number
  totalDataMB: number
  avgBlobSizeKB: number
  monthlyCost: number
  lastBlobAt: number
  status: 'active' | 'inactive'
}

export interface DAServiceMetrics {
  epochNumber: number
  epochStart: number
  epochEnd: number
  blobsInEpoch: number
  avgConfirmationBlocks: number
  operatorParticipation: number
  fraudProofsFiled: number
  slashingEvents: number
  revenue: number
}

export interface ErasureCodingConfig {
  dataShards: number
  parityShards: number
  shardSizeBytes: number
  polynomialDegree: number
}

export interface KZGCommitment {
  commitment: string
  proof: string
  inputPoint: string
  evaluatedPoint: string
}

export interface CompressionResult {
  originalSize: number
  compressedSize: number
  algorithm: 'zstd' | 'lz4' | 'snappy'
  ratio: number
  durationMs: number
}

export type TimeRange = '1h' | '6h' | '24h' | '7d' | '30d'

export interface TimeSeriesPoint {
  timestamp: number
  value: number
}
