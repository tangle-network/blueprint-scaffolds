import type { ErasureCodingConfig, KZGCommitment, CompressionResult, CostEstimate } from './types'

export function computeErasureCodingConfig(dataSizeBytes: number, targetChunks: number = 32): ErasureCodingConfig {
  const dataShards = Math.ceil(targetChunks * (2 / 3))
  const parityShards = targetChunks - dataShards
  const shardSizeBytes = Math.ceil(dataSizeBytes / dataShards)
  return {
    dataShards,
    parityShards,
    shardSizeBytes,
    polynomialDegree: dataShards - 1,
  }
}

export function simulateErasureEncode(dataShards: number, parityShards: number): {
  originalChunks: string[]
  parityChunks: string[]
  totalChunks: number
  overheadPct: number
} {
  const originalChunks = Array.from({ length: dataShards }, (_, i) =>
    `chunk_${i}_${Math.random().toString(36).slice(2, 10)}`
  )
  const parityChunks = Array.from({ length: parityShards }, (_, i) =>
    `parity_${i}_${Math.random().toString(36).slice(2, 10)}`
  )
  return {
    originalChunks,
    parityChunks,
    totalChunks: dataShards + parityShards,
    overheadPct: (parityShards / dataShards) * 100,
  }
}

export function simulateKZGCommit(dataSizeBytes: number): KZGCommitment {
  const commitment = `0x${Array.from({ length: 48 }, () =>
    Math.floor(Math.random() * 16).toString(16)
  ).join('')}`
  const proof = `0x${Array.from({ length: 48 }, () =>
    Math.floor(Math.random() * 16).toString(16)
  ).join('')}`
  return {
    commitment,
    proof,
    inputPoint: `0x${Math.floor(Math.random() * 0xffffff).toString(16).padStart(6, '0')}`,
    evaluatedPoint: `0x${Math.floor(Math.random() * 0xffffff).toString(16).padStart(6, '0')}`,
  }
}

export function verifyKZGProof(_commitment: string, _proof: string, _inputPoint: string, _evaluatedPoint: string): boolean {
  return Math.random() > 0.01
}

export function simulateCompression(dataSizeBytes: number): CompressionResult {
  const algorithms: CompressionResult['algorithm'][] = ['zstd', 'lz4', 'snappy']
  const algorithm = algorithms[Math.floor(Math.random() * algorithms.length)]
  const ratioRanges: Record<string, [number, number]> = {
    zstd: [0.28, 0.45],
    lz4: [0.4, 0.6],
    snappy: [0.45, 0.65],
  }
  const [minR, maxR] = ratioRanges[algorithm]
  const ratio = minR + Math.random() * (maxR - minR)
  const compressedSize = Math.floor(dataSizeBytes * ratio)
  return {
    originalSize: dataSizeBytes,
    compressedSize,
    algorithm,
    ratio,
    durationMs: dataSizeBytes / (50 * 1024 * 1024) * 1000 + Math.random() * 5,
  }
}

export function simulateSampling(
  totalChunks: number,
  sampleCount: number,
  unavailableChunks: number
): {
  sampledChunks: number[]
  unavailable: number
  passed: boolean
  confidence: number
} {
  const sampledChunks = Array.from({ length: sampleCount }, () =>
    Math.floor(Math.random() * totalChunks)
  )
  const unavailable = sampledChunks.filter(() =>
    Math.random() < unavailableChunks / totalChunks
  ).length
  const passed = unavailable === 0
  const confidence = passed ? 1 - Math.pow(unavailableChunks / totalChunks, sampleCount) : 0
  return { sampledChunks, unavailable, passed, confidence }
}

export function calculateCostEstimate(
  dataSizeMB: number,
  redundancyLevel: number,
  guaranteeWeeks: number
): CostEstimate {
  const PRICE_PER_MB = 0.00023
  const REDUNDANCY_MULTIPLIER = 1 + (redundancyLevel - 1) * 0.15
  const GUARANTEE_WEEKLY_RATE = 0.005

  const baseCost = dataSizeMB * PRICE_PER_MB
  const redundancyCost = baseCost * (REDUNDANCY_MULTIPLIER - 1)
  const guaranteeCost = dataSizeMB * GUARANTEE_WEEKLY_RATE * guaranteeWeeks
  const totalCost = baseCost + redundancyCost + guaranteeCost
  const confirmationTimeEstimate = 8 + redundancyLevel * 2 + dataSizeMB * 0.01

  return {
    dataSizeMB,
    redundancyLevel,
    guaranteeWeeks,
    baseCost,
    redundancyCost,
    guaranteeCost,
    totalCost,
    confirmationTimeEstimate: Math.ceil(confirmationTimeEstimate * 1000),
  }
}

export function calculateOperatorReward(
  stake: number,
  uptimePct: number,
  bandwidthMbps: number,
  blobsStored: number,
  performanceScore: number
): number {
  const stakeWeight = 0.3
  const uptimeWeight = 0.25
  const bandwidthWeight = 0.2
  const blobsWeight = 0.15
  const perfWeight = 0.1

  const normalizedStake = Math.min(stake / 128, 1)
  const normalizedUptime = uptimePct / 100
  const normalizedBandwidth = Math.min(bandwidthMbps / 2000, 1)
  const normalizedBlobs = Math.min(blobsStored / 50000, 1)
  const normalizedPerf = performanceScore / 100

  const score =
    normalizedStake * stakeWeight +
    normalizedUptime * uptimeWeight +
    normalizedBandwidth * bandwidthWeight +
    normalizedBlobs * blobsWeight +
    normalizedPerf * perfWeight

  return 0.5 + score * 3.5
}

export function generateChunkAssignment(
  operatorCount: number,
  totalChunks: number,
  chunksPerOperator: number
): Map<number, number[]> {
  const assignment = new Map<number, number[]>()
  for (let op = 0; op < operatorCount; op++) {
    const chunks: number[] = []
    for (let c = 0; c < chunksPerOperator; c++) {
      chunks.push((op * chunksPerOperator + c) % totalChunks)
    }
    assignment.set(op, chunks)
  }
  return assignment
}

export function checkDataAvailability(
  quorumSize: number,
  responsiveOperators: number,
  thresholdPct: number
): { available: boolean; participationPct: number } {
  const participationPct = (responsiveOperators / quorumSize) * 100
  return {
    available: participationPct >= thresholdPct,
    participationPct,
  }
}

export const TWO_WEEKS_MS = 14 * 24 * 60 * 60 * 1000
export const MIN_STAKE_ETH = 32
export const SAMPLING_RATE = 30
export const CONFIRMATION_THRESHOLD_PCT = 67
export const MAX_BLOB_SIZE_BYTES = 2 * 1024 * 1024
export const ERASURE_CODING_RATIOS: [number, number][] = [
  [16, 24],
  [16, 32],
  [32, 48],
  [32, 64],
  [64, 96],
]
