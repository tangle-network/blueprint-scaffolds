import type {
  Operator,
  BlobBatch,
  NetworkStats,
  QuorumInfo,
  FraudProof,
  RollupProfile,
  DAServiceMetrics,
  TimeSeriesPoint,
  SamplingResult,
} from './types'

const REGIONS = [
  { name: 'US-East', lat: 39.0, lon: -77.5 },
  { name: 'US-West', lat: 37.4, lon: -122.1 },
  { name: 'EU-West', lat: 50.1, lon: -0.1 },
  { name: 'EU-Central', lat: 50.1, lon: 8.7 },
  { name: 'Asia-East', lat: 35.7, lon: 139.7 },
  { name: 'Asia-South', lat: 19.1, lon: 72.9 },
  { name: 'SA-East', lat: -23.5, lon: -46.6 },
  { name: 'AU-East', lat: -33.9, lon: 151.2 },
]

const ENCLAVES = ['SGX', 'TDX', 'SEV-SNP', 'TrustZone']

function randomHex(len: number): string {
  let s = '0x'
  for (let i = 0; i < len; i++) s += Math.floor(Math.random() * 16).toString(16)
  return s
}

function randomBetween(min: number, max: number): number {
  return min + Math.random() * (max - min)
}

function hoursAgo(h: number): number {
  return Date.now() - h * 3600000
}

export function generateOperators(count: number): Operator[] {
  return Array.from({ length: count }, (_, i) => {
    const region = REGIONS[i % REGIONS.length]
    const jitterLat = region.lat + randomBetween(-3, 3)
    const jitterLon = region.lon + randomBetween(-5, 5)
    const stake = 32 + Math.floor(randomBetween(0, 20)) * 32
    const statuses: Operator['status'][] = ['active', 'active', 'active', 'active', 'active', 'inactive', 'pending']
    return {
      id: `op-${i.toString().padStart(3, '0')}`,
      address: randomHex(40),
      enclave: ENCLAVES[Math.floor(Math.random() * ENCLAVES.length)],
      stake,
      status: statuses[Math.floor(Math.random() * statuses.length)],
      lat: jitterLat,
      lon: jitterLon,
      region: region.name,
      bandwidthMbps: 500 + Math.floor(randomBetween(0, 1500)),
      uptimePct: 95 + randomBetween(0, 5),
      blobsStored: Math.floor(randomBetween(100, 50000)),
      totalEarned: randomBetween(0.5, 12),
      registeredAt: hoursAgo(randomBetween(24, 4380)),
      lastHeartbeat: hoursAgo(randomBetween(0, 0.1)),
      performanceScore: 80 + Math.floor(randomBetween(0, 20)),
    }
  })
}

const ROLLUP_NAMES = [
  { id: 'rollup-001', name: 'Base' },
  { id: 'rollup-002', name: 'Arbitrum' },
  { id: 'rollup-003', name: 'Optimism' },
  { id: 'rollup-004', name: 'zkSync' },
  { id: 'rollup-005', name: 'StarkNet' },
  { id: 'rollup-006', name: 'Scroll' },
  { id: 'rollup-007', name: 'Linea' },
  { id: 'rollup-008', name: 'Manta' },
  { id: 'rollup-009', name: 'Mode' },
  { id: 'rollup-010', name: 'Blast' },
]

export function generateBlobs(count: number): BlobBatch[] {
  const statuses: BlobBatch['status'][] = ['confirmed', 'confirmed', 'confirmed', 'confirmed', 'pending', 'finalizing', 'expired']
  return Array.from({ length: count }, (_, i) => {
    const rollup = ROLLUP_NAMES[Math.floor(Math.random() * ROLLUP_NAMES.length)]
    const dataShards = 16 + Math.floor(randomBetween(0, 4)) * 8
    const parityShards = Math.floor(dataShards / 2)
    const rawSize = Math.floor(randomBetween(128, 2048)) * 1024
    const compressedSize = Math.floor(rawSize * randomBetween(0.3, 0.6))
    const encodedSize = rawSize * (1 + parityShards / dataShards)
    const status = statuses[Math.floor(Math.random() * statuses.length)]
    const submittedAt = hoursAgo(randomBetween(0.01, 168))
    return {
      id: `blob-${i.toString().padStart(5, '0')}`,
      batchHash: randomHex(64),
      rollupId: rollup.id,
      rollupName: rollup.name,
      dataSize: rawSize,
      encodedSize: Math.floor(encodedSize),
      compressedSize,
      numChunks: dataShards + parityShards,
      quorumId: Math.floor(randomBetween(0, 3)),
      confirmationThreshold: 67,
      confirmations: status === 'confirmed' ? 100 : Math.floor(randomBetween(30, 90)),
      kzgCommitment: randomHex(96),
      kzgProof: randomHex(48),
      status,
      submittedAt,
      expiresAt: submittedAt + 14 * 24 * 3600000,
      confirmationTime: status === 'confirmed' ? randomBetween(8000, 24000) : 0,
      fee: randomBetween(0.001, 0.05),
      erasureCodingRatio: [dataShards, dataShards + parityShards] as [number, number],
      samplingSuccessRate: randomBetween(0.96, 1.0),
    }
  })
}

export function generateNetworkStats(): NetworkStats {
  return {
    totalOperators: 128,
    activeOperators: 114,
    totalStake: 4608,
    totalBlobs: 184729,
    totalDataStored: 12.4 * 1024,
    avgConfirmationTime: 13200,
    networkUptime: 99.97,
    currentEpoch: 48921,
    blobsLast24h: 1284,
    throughputMBps: 42.7,
    avgFeePerMB: 0.00023,
    slashingEvents: 3,
  }
}

export function generateQuorums(): QuorumInfo[] {
  return [
    {
      id: 0,
      name: 'Primary DA Quorum',
      operators: 64,
      totalStake: 2048,
      minStake: 32,
      status: 'active',
      agreementThreshold: 67,
      geographicSpread: ['US-East', 'US-West', 'EU-West', 'EU-Central', 'Asia-East'],
    },
    {
      id: 1,
      name: 'Secondary DA Quorum',
      operators: 48,
      totalStake: 1536,
      minStake: 32,
      status: 'active',
      agreementThreshold: 60,
      geographicSpread: ['US-West', 'EU-Central', 'Asia-East', 'Asia-South', 'AU-East'],
    },
    {
      id: 2,
      name: 'Archive Quorum',
      operators: 16,
      totalStake: 1024,
      minStake: 64,
      status: 'active',
      agreementThreshold: 80,
      geographicSpread: ['US-East', 'EU-West', 'Asia-East', 'SA-East'],
    },
  ]
}

export function generateFraudProofs(): FraudProof[] {
  const types: FraudProof['type'][] = ['invalid_encoding', 'data_unavailable', 'incorrect_commitment', 'sampling_failure']
  const statuses: FraudProof['status'][] = ['pending', 'verified', 'disputed', 'resolved', 'rejected']
  return Array.from({ length: 12 }, (_, i) => ({
    id: `fp-${i.toString().padStart(3, '0')}`,
    blobId: `blob-${Math.floor(randomBetween(100, 999)).toString().padStart(5, '0')}`,
    reporter: randomHex(40),
    operatorAddr: randomHex(40),
    type: types[Math.floor(Math.random() * types.length)],
    status: statuses[Math.floor(Math.random() * statuses.length)],
    evidence: randomHex(128),
    submittedAt: hoursAgo(randomBetween(1, 720)),
    resolvedAt: Math.random() > 0.3 ? hoursAgo(randomBetween(0.5, 700)) : undefined,
    slashedAmount: Math.random() > 0.5 ? randomBetween(0.5, 4) : undefined,
  }))
}

export function generateRollupProfiles(): RollupProfile[] {
  return ROLLUP_NAMES.map((r, i) => ({
    id: r.id,
    name: r.name,
    totalBlobs: Math.floor(randomBetween(5000, 40000)),
    totalDataMB: randomBetween(500, 8000),
    avgBlobSizeKB: Math.floor(randomBetween(128, 1024)),
    monthlyCost: randomBetween(2, 45),
    lastBlobAt: hoursAgo(randomBetween(0.01, 48)),
    status: i < 8 ? 'active' as const : 'inactive' as const,
  }))
}

export function generateServiceMetrics(): DAServiceMetrics {
  return {
    epochNumber: 48921,
    epochStart: hoursAgo(6),
    epochEnd: hoursAgo(0),
    blobsInEpoch: Math.floor(randomBetween(200, 500)),
    avgConfirmationBlocks: 4.2,
    operatorParticipation: 89.3,
    fraudProofsFiled: 0,
    slashingEvents: 0,
    revenue: randomBetween(8, 25),
  }
}

export function generateThroughputTimeSeries(): TimeSeriesPoint[] {
  const points: TimeSeriesPoint[] = []
  const now = Date.now()
  for (let i = 180; i >= 0; i--) {
    points.push({
      timestamp: now - i * 480000,
      value: 30 + Math.random() * 30 + Math.sin(i / 12) * 8,
    })
  }
  return points
}

export function generateBlobCountTimeSeries(): TimeSeriesPoint[] {
  const points: TimeSeriesPoint[] = []
  const now = Date.now()
  for (let i = 180; i >= 0; i--) {
    points.push({
      timestamp: now - i * 480000,
      value: 40 + Math.random() * 30 + Math.sin(i / 8) * 15,
    })
  }
  return points
}

export function generateFeeTimeSeries(): TimeSeriesPoint[] {
  const points: TimeSeriesPoint[] = []
  const now = Date.now()
  for (let i = 180; i >= 0; i--) {
    points.push({
      timestamp: now - i * 480000,
      value: 0.00015 + Math.random() * 0.0002 + Math.sin(i / 20) * 0.00005,
    })
  }
  return points
}

export function generateSamplingResults(): SamplingResult[] {
  return Array.from({ length: 20 }, (_, i) => ({
    blobId: `blob-${(i * 97 + 500).toString().padStart(5, '0')}`,
    totalSamples: Math.floor(randomBetween(30, 120)),
    successfulSamples: 0,
    failedSamples: 0,
    lastSampledAt: hoursAgo(randomBetween(0, 48)),
    samplingPeriodMs: randomBetween(200, 2000),
  })).map(s => ({
    ...s,
    successfulSamples: Math.floor(s.totalSamples * randomBetween(0.95, 1.0)),
    failedSamples: s.totalSamples - Math.floor(s.totalSamples * randomBetween(0.95, 1.0)),
  }))
}
