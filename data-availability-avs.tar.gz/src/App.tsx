import { useMemo, useState } from 'react'
import {
  architecture,
  blobs,
  heroMetrics,
  operators,
  rewardLevers,
  type BlobRecord,
} from './data'

const formatCurrency = (value: number) =>
  new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 2,
  }).format(value)

function App() {
  const [dailyGb, setDailyGb] = useState(180)
  const [retentionDays, setRetentionDays] = useState(14)
  const [samplePct, setSamplePct] = useState(35)

  const totals = useMemo(() => {
    const compressedGb = dailyGb * 0.42
    const encodedGb = compressedGb * 1.8
    const monthlyStorage = encodedGb * retentionDays
    const monthlyCost = monthlyStorage * 0.72 + samplePct * 14

    return {
      compressedGb,
      encodedGb,
      monthlyStorage,
      monthlyCost,
    }
  }, [dailyGb, retentionDays, samplePct])

  return (
    <div className="app-shell">
      <header className="hero">
        <div className="hero-copy">
          <p className="eyebrow">EigenLayer Data Availability AVS</p>
          <h1>Erasure-coded rollup data with cryptoeconomic guarantees and operator-enforced persistence.</h1>
          <p className="lede">
            A reference AVS design for transaction data publication with KZG commitments, random sampling,
            fraud proofs, two-week retention, and performance-priced rewards for globally distributed operators.
          </p>
          <div className="hero-actions">
            <a href="#explorer" className="button button-primary">
              Explore blobs
            </a>
            <a href="#operator-stack" className="button button-secondary">
              Operator stack
            </a>
          </div>
        </div>
        <div className="hero-panel">
          <span className="panel-label">Live DA profile</span>
          <div className="hero-grid">
            {heroMetrics.map((metric) => (
              <article key={metric.label} className="metric-card">
                <span>{metric.label}</span>
                <strong>{metric.value}</strong>
                <p>{metric.detail}</p>
              </article>
            ))}
          </div>
        </div>
      </header>

      <main>
        <section className="section">
          <div className="section-heading">
            <p className="eyebrow">Availability pipeline</p>
            <h2>Designed for sequencers that need cheap publication without soft trust assumptions.</h2>
          </div>
          <div className="timeline">
            {architecture.map((event) => (
              <article key={event.title} className="timeline-card">
                <h3>{event.title}</h3>
                <p>{event.body}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="section split-layout">
          <div>
            <div className="section-heading">
              <p className="eyebrow">Network stats</p>
              <h2>Operators are admitted on stake, bandwidth, and regional balance.</h2>
            </div>
            <div className="stats-band">
              <div>
                <span>Total active operators</span>
                <strong>{operators.length}</strong>
              </div>
              <div>
                <span>Aggregate stake</span>
                <strong>{operators.reduce((sum, operator) => sum + operator.stakeEth, 0)} ETH</strong>
              </div>
              <div>
                <span>Total bandwidth</span>
                <strong>{operators.reduce((sum, operator) => sum + operator.bandwidthGbps, 0)} Gbps</strong>
              </div>
            </div>
            <div className="table-card">
              <table>
                <thead>
                  <tr>
                    <th>Operator</th>
                    <th>Region</th>
                    <th>Stake</th>
                    <th>Bandwidth</th>
                    <th>Availability</th>
                    <th>Reward</th>
                  </tr>
                </thead>
                <tbody>
                  {operators.map((operator) => (
                    <tr key={operator.id}>
                      <td>{operator.id}</td>
                      <td>{operator.region}</td>
                      <td>{operator.stakeEth} ETH</td>
                      <td>{operator.bandwidthGbps} Gbps</td>
                      <td>{operator.availability}%</td>
                      <td>{operator.rewardBoost}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <aside className="side-panel" id="operator-stack">
            <p className="eyebrow">Operator software</p>
            <h2>Go data node responsibilities</h2>
            <ul className="feature-list">
              <li>P2P shard gossip with content-addressed chunk retrieval and admission control.</li>
              <li>KZG commitment verification before persisting encoded fragments.</li>
              <li>Two-week retention scheduler with fraud-proof evidence export.</li>
              <li>Bandwidth accounting and uptime telemetry for reward distribution.</li>
            </ul>
            <div className="code-card">
              <span>Relevant paths</span>
              <code>operator/go.mod</code>
              <code>operator/cmd/datanode/main.go</code>
              <code>operator/internal/node/node.go</code>
            </div>
          </aside>
        </section>

        <section className="section split-layout" id="explorer">
          <div>
            <div className="section-heading">
              <p className="eyebrow">Data explorer</p>
              <h2>Committed blobs, KZG roots, coding overhead, and live sampling state.</h2>
            </div>
            <div className="blob-grid">
              {blobs.map((blob) => (
                <BlobCard key={blob.id} blob={blob} />
              ))}
            </div>
          </div>

          <div className="calculator">
            <div className="section-heading">
              <p className="eyebrow">Cost calculator</p>
              <h2>Estimate AVS economics</h2>
            </div>
            <label>
              Daily rollup data
              <input
                type="range"
                min="40"
                max="500"
                value={dailyGb}
                onChange={(event) => setDailyGb(Number(event.target.value))}
              />
              <span>{dailyGb} GB/day</span>
            </label>
            <label>
              Retention window
              <input
                type="range"
                min="7"
                max="21"
                value={retentionDays}
                onChange={(event) => setRetentionDays(Number(event.target.value))}
              />
              <span>{retentionDays} days</span>
            </label>
            <label>
              Random sampling coverage
              <input
                type="range"
                min="10"
                max="60"
                value={samplePct}
                onChange={(event) => setSamplePct(Number(event.target.value))}
              />
              <span>{samplePct}% of shards</span>
            </label>
            <div className="calc-results">
              <div>
                <span>Compressed ingress</span>
                <strong>{totals.compressedGb.toFixed(1)} GB/day</strong>
              </div>
              <div>
                <span>Encoded storage footprint</span>
                <strong>{totals.monthlyStorage.toFixed(1)} GB</strong>
              </div>
              <div>
                <span>Estimated monthly cost</span>
                <strong>{formatCurrency(totals.monthlyCost)}</strong>
              </div>
            </div>
          </div>
        </section>

        <section className="section">
          <div className="section-heading">
            <p className="eyebrow">Rewards and safety</p>
            <h2>Performance incentives are tied directly to DA quality, not just stake.</h2>
          </div>
          <div className="reward-grid">
            {rewardLevers.map((lever) => (
              <article key={lever} className="reward-card">
                <p>{lever}</p>
              </article>
            ))}
          </div>
        </section>
      </main>
    </div>
  )
}

function BlobCard({ blob }: { blob: BlobRecord }) {
  return (
    <article className="blob-card">
      <div className="blob-card-header">
        <span>{blob.rollup}</span>
        <strong>{blob.id}</strong>
      </div>
      <dl>
        <div>
          <dt>Blob size</dt>
          <dd>{blob.sizeKb} KB</dd>
        </div>
        <div>
          <dt>KZG root</dt>
          <dd>{blob.kzgRoot}</dd>
        </div>
        <div>
          <dt>Compression</dt>
          <dd>{blob.compressionRatio}</dd>
        </div>
        <div>
          <dt>Erasure coding</dt>
          <dd>{blob.erasureFactor}</dd>
        </div>
        <div>
          <dt>Sampling</dt>
          <dd>{blob.sampleRate}</dd>
        </div>
        <div>
          <dt>Status</dt>
          <dd>{blob.status}</dd>
        </div>
      </dl>
    </article>
  )
}

export default App
