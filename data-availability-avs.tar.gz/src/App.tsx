import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Layout from '@/components/Layout'
import NetworkStatsPage from '@/pages/NetworkStatsPage'
import DataExplorerPage from '@/pages/DataExplorerPage'
import CostCalculatorPage from '@/pages/CostCalculatorPage'
import FraudProofsPage from '@/pages/FraudProofsPage'
import ContractsPage from '@/pages/ContractsPage'
import OperatorNodePage from '@/pages/OperatorNodePage'

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route index element={<NetworkStatsPage />} />
          <Route path="explorer" element={<DataExplorerPage />} />
          <Route path="calculator" element={<CostCalculatorPage />} />
          <Route path="fraud-proofs" element={<FraudProofsPage />} />
          <Route path="contracts" element={<ContractsPage />} />
          <Route path="operator-node" element={<OperatorNodePage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}
