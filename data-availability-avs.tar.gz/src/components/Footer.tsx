import { Database, Github, ExternalLink } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-white/10 bg-background/50">
      <div className="mx-auto max-w-7xl px-4 py-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
          <div>
            <div className="flex items-center gap-2">
              <Database className="h-5 w-5 text-primary" />
              <span className="gradient-text text-lg font-bold">DataDA</span>
            </div>
            <p className="mt-2 text-sm text-muted-foreground">
              Data Availability AVS built on EigenLayer. Erasure-coded, distributed storage with KZG commitments and fraud proofs.
            </p>
          </div>
          <div>
            <h4 className="font-semibold">Protocol</h4>
            <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
              <li>32 ETH minimum stake</li>
              <li>14-day DA guarantee</li>
              <li>Reed-Solomon erasure coding</li>
              <li>KZG polynomial commitments</li>
              <li>Random sampling verification</li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold">Resources</h4>
            <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
              <li>
                <a href="#" className="flex items-center gap-1 hover:text-primary">
                  Documentation <ExternalLink className="h-3 w-3" />
                </a>
              </li>
              <li>
                <a href="#" className="flex items-center gap-1 hover:text-primary">
                  Operator Guide <ExternalLink className="h-3 w-3" />
                </a>
              </li>
              <li>
                <a href="#" className="flex items-center gap-1 hover:text-primary">
                  <Github className="h-3 w-3" /> GitHub
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-8 border-t border-white/10 pt-4 text-center text-xs text-muted-foreground">
          DataDA AVS &copy; 2026 — Built on EigenLayer
        </div>
      </div>
    </footer>
  );
}
