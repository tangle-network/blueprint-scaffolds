import { Link, useLocation } from "react-router-dom";
import { Database, BarChart3, Search, Calculator } from "lucide-react";

const navItems = [
  { to: "/", label: "Network Stats", icon: BarChart3 },
  { to: "/explorer", label: "Data Explorer", icon: Search },
  { to: "/calculator", label: "Cost Calculator", icon: Calculator },
];

export function Header() {
  const location = useLocation();

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4">
        <Link to="/" className="flex items-center gap-2">
          <Database className="h-6 w-6 text-primary" />
          <span className="gradient-text text-xl font-bold">DataDA</span>
          <span className="ml-1 rounded-full bg-primary/10 px-2 py-0.5 text-xs text-primary">AVS</span>
        </Link>
        <nav className="flex items-center gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.to;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                  isActive
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
                }`}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
