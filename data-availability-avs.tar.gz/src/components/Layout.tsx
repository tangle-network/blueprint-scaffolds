import { NavLink, Outlet } from 'react-router-dom'
import { Activity, Database, Calculator, Shield, FileCode, Server } from 'lucide-react'

const NAV_ITEMS = [
  { to: '/', label: 'Network Stats', icon: Activity },
  { to: '/explorer', label: 'Data Explorer', icon: Database },
  { to: '/calculator', label: 'Cost Calculator', icon: Calculator },
  { to: '/fraud-proofs', label: 'Fraud Proofs', icon: Shield },
  { to: '/contracts', label: 'Contracts', icon: FileCode },
  { to: '/operator-node', label: 'Operator Node', icon: Server },
]

export default function Layout() {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto flex h-14 items-center px-4">
          <div className="mr-8 flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <span className="text-sm font-bold text-primary-foreground">DA</span>
            </div>
            <span className="text-lg font-bold">EigenDA</span>
            <span className="ml-2 rounded bg-muted px-1.5 py-0.5 text-xs text-muted-foreground">
              AVS
            </span>
          </div>
          <nav className="flex items-center gap-1">
            {NAV_ITEMS.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                end={to === '/'}
                className={({ isActive }) =>
                  `flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-primary/10 text-primary'
                      : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground'
                  }`
                }
              >
                <Icon className="h-4 w-4" />
                {label}
              </NavLink>
            ))}
          </nav>
        </div>
      </header>
      <main className="container mx-auto px-4 py-6">
        <Outlet />
      </main>
    </div>
  )
}
