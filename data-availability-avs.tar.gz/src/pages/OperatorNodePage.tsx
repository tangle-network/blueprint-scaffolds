import React from 'react'

export default function OperatorNodePage() { return <div>OperatorNodePage</div> }
