import {
  Database,
  Users,
  HardDrive,
  Clock,
  TrendingUp,
  Shield,
  Zap,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  Globe,
  Activity,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  networkStats,
  operators,
  throughputData,
  stakeDistribution,
} from "@/data/mock";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  Legend,
} from "recharts";

const PIE_COLORS = ["#3b82f6", "#8b5cf6", "#06b6d4", "#f59e0b", "#10b981", "#6b7280"];

export function NetworkStats() {
  const metrics = [
    {
      label: "Total Stake",
      value: networkStats.totalStake,
      icon: Shield,
      change: "+4.2%",
      positive: true,
    },
    {
      label: "Active Operators",
      value: `${networkStats.activeOperators}/${networkStats.totalOperators}`,
      icon: Users,
      change: "+3",
      positive: true,
    },
    {
      label: "Blobs Stored",
      value: networkStats.totalBlobs.toLocaleString(),
      icon: Database,
      change: "+12,847",
      positive: true,
    },
    {
      label: "Data Stored",
      value: networkStats.totalDataStored,
      icon: HardDrive,
      change: "+2.1 TB",
      positive: true,
    },
    {
      label: "Avg Latency",
      value: `${networkStats.avgLatency} ms`,
      icon: Zap,
      change: "-3 ms",
      positive: true,
    },
    {
      label: "Network Uptime",
      value: `${networkStats.networkUptime}%`,
      icon: Activity,
      change: "+0.02%",
      positive: true,
    },
    {
      label: "Slashing Events",
      value: networkStats.slashingEvents.toString(),
      icon: AlertTriangle,
      change: "0 this week",
      positive: true,
    },
    {
      label: "Total Rewards",
      value: networkStats.totalRewards,
      icon: TrendingUp,
      change: "+8.4 ETH",
      positive: true,
    },
  ];

  return (
    <div className="mx-auto max-w-7xl space-y-6 px-4 py-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold gradient-text">Network Stats</h1>
          <p className="mt-1 text-muted-foreground">
            Real-time DataDA AVS network metrics &mdash;{" "}
            {networkStats.daGuarantee} guarantee
          </p>
        </div>
        <Badge variant="success" className="text-sm">
          <span className="mr-1 inline-block h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
          Live
        </Badge>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {metrics.map((m) => {
          const Icon = m.icon;
          return (
            <Card key={m.label} className="glass-card">
              <CardContent className="flex items-center gap-4 p-4">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <div className="min-w-0">
                  <p className="text-xs text-muted-foreground">{m.label}</p>
                  <p className="text-lg font-semibold">{m.value}</p>
                  <p className="flex items-center text-xs text-emerald-400">
                    {m.positive ? (
                      <ArrowUpRight className="mr-0.5 h-3 w-3" />
                    ) : (
                      <ArrowDownRight className="mr-0.5 h-3 w-3" />
                    )}
                    {m.change}
                  </p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-lg">Throughput (24h)</CardTitle>
            <CardDescription>Blobs submitted and MB/s throughput</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <AreaChart data={throughputData}>
                <defs>
                  <linearGradient id="gradBlobs" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="gradTP" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(217.2 32.6% 17.5%)" />
                <XAxis dataKey="time" stroke="#64748b" tick={{ fontSize: 12 }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 12 }} />
                <Tooltip
                  contentStyle={{
                    background: "hsl(222.2 84% 4.9%)",
                    border: "1px solid hsl(217.2 32.6% 17.5%)",
                    borderRadius: 8,
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="blobs"
                  stroke="#3b82f6"
                  fill="url(#gradBlobs)"
                  name="Blobs"
                />
                <Area
                  type="monotone"
                  dataKey="throughput"
                  stroke="#8b5cf6"
                  fill="url(#gradTP)"
                  name="MB/s"
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-lg">Stake Distribution by Region</CardTitle>
            <CardDescription>Geographic distribution of 2,048 ETH</CardDescription>
          </CardHeader>
          <CardContent className="flex items-center justify-center">
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie
                  data={stakeDistribution}
                  dataKey="stake"
                  nameKey="region"
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  innerRadius={60}
                  paddingAngle={2}
                  label={({ region, stake }) => `${region}: ${stake} ETH`}
                >
                  {stakeDistribution.map((_, i) => (
                    <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    background: "hsl(222.2 84% 4.9%)",
                    border: "1px solid hsl(217.2 32.6% 17.5%)",
                    borderRadius: 8,
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Globe className="h-5 w-5 text-primary" />
            Operators by Region
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={stakeDistribution}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(217.2 32.6% 17.5%)" />
              <XAxis dataKey="region" stroke="#64748b" tick={{ fontSize: 12 }} />
              <YAxis stroke="#64748b" tick={{ fontSize: 12 }} />
              <Tooltip
                contentStyle={{
                  background: "hsl(222.2 84% 4.9%)",
                  border: "1px solid hsl(217.2 32.6% 17.5%)",
                  borderRadius: 8,
                }}
              />
              <Legend />
              <Bar dataKey="stake" fill="#3b82f6" name="Stake (ETH)" radius={[4, 4, 0, 0]} />
              <Bar dataKey="operators" fill="#8b5cf6" name="Operators" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-lg">Registered Operators</CardTitle>
          <CardDescription>
            Performance-based rewards &mdash; 32 ETH minimum stake
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Address</TableHead>
                <TableHead>Location</TableHead>
                <TableHead>Stake</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Uptime</TableHead>
                <TableHead>Bandwidth</TableHead>
                <TableHead>Latency</TableHead>
                <TableHead>Blobs</TableHead>
                <TableHead>Reputation</TableHead>
                <TableHead>Earnings</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {operators.map((op) => (
                <TableRow key={op.id}>
                  <TableCell className="font-mono text-xs">{op.id}</TableCell>
                  <TableCell className="font-mono text-xs">{op.address}</TableCell>
                  <TableCell>{op.location}</TableCell>
                  <TableCell>{op.stake} ETH</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        op.status === "active"
                          ? "success"
                          : op.status === "slashed"
                          ? "destructive"
                          : "warning"
                      }
                    >
                      {op.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{op.uptime}%</TableCell>
                  <TableCell>{op.bandwidth}</TableCell>
                  <TableCell>{op.latency} ms</TableCell>
                  <TableCell>{op.blobsStored.toLocaleString()}</TableCell>
                  <TableCell>
                    <span
                      className={
                        op.reputation >= 95
                          ? "text-emerald-400"
                          : op.reputation >= 80
                          ? "text-yellow-400"
                          : "text-red-400"
                      }
                    >
                      {op.reputation}
                    </span>
                  </TableCell>
                  <TableCell>{op.earnings}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
