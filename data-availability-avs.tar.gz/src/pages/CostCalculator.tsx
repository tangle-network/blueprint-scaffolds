import { useState, useMemo } from "react";
import {
  Calculator as CalcIcon,
  Database,
  Clock,
  TrendingUp,
  DollarSign,
  BarChart3,
  ArrowRight,
  Info,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

const ETH_PRICE = 1800;
const GAS_PER_BYTE = 16;
const BLOB_GAS_PER_BYTE = 1;

interface CostBreakdown {
  dataDA: {
    storage: number;
    encoding: number;
    commitment: number;
    total: number;
  };
  ethCalldata: number;
  ethBlobs: number;
}

export function CostCalculator() {
  const [dataSizeMB, setDataSizeMB] = useState(256);
  const [durationDays, setDurationDays] = useState(14);
  const [blobsPerDay, setBlobsPerDay] = useState(100);

  const costs = useMemo<CostBreakdown>(() => {
    const bytes = dataSizeMB * 1024 * 1024;
    const compressedBytes = bytes * 0.35;

    const storageCost = (compressedBytes / (1024 * 1024)) * 0.0002 * durationDays;
    const encodingCost = (dataSizeMB * 0.00005) * blobsPerDay;
    const commitmentCost = blobsPerDay * 0.001;
    const dataDATotal = storageCost + encodingCost + commitmentCost;

    const ethCalldata = ((bytes * GAS_PER_BYTE) / 1e9) * 30 * blobsPerDay;
    const ethBlobs = ((compressedBytes * BLOB_GAS_PER_BYTE) / 1e9) * 15 * blobsPerDay;

    return {
      dataDA: {
        storage: storageCost,
        encoding: encodingCost,
        commitment: commitmentCost,
        total: dataDATotal,
      },
      ethCalldata,
      ethBlobs,
    };
  }, [dataSizeMB, durationDays, blobsPerDay]);

  const comparisonData = [
    {
      name: "DataDA AVS",
      cost: parseFloat(costs.dataDA.total.toFixed(4)),
      fill: "#3b82f6",
    },
    {
      name: "ETH Blobs",
      cost: parseFloat(costs.ethBlobs.toFixed(4)),
      fill: "#8b5cf6",
    },
    {
      name: "ETH Calldata",
      cost: parseFloat(costs.ethCalldata.toFixed(4)),
      fill: "#f59e0b",
    },
  ];

  const savings = {
    vsCalldata:
      costs.ethCalldata > 0
        ? ((1 - costs.dataDA.total / costs.ethCalldata) * 100).toFixed(1)
        : "0",
    vsBlobs:
      costs.ethBlobs > 0
        ? ((1 - costs.dataDA.total / costs.ethBlobs) * 100).toFixed(1)
        : "0",
  };

  return (
    <div className="mx-auto max-w-7xl space-y-6 px-4 py-8">
      <div>
        <h1 className="text-3xl font-bold gradient-text">Cost Calculator</h1>
        <p className="mt-1 text-muted-foreground">
          Estimate DA costs for your rollup on DataDA AVS vs alternatives
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="glass-card lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <CalcIcon className="h-5 w-5 text-primary" />
              Parameters
            </CardTitle>
            <CardDescription>Configure your DA requirements</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="mb-1 flex items-center gap-1 text-sm font-medium">
                <Database className="h-4 w-4 text-primary" />
                Blob Size (KB)
                <span className="ml-auto text-xs text-muted-foreground">
                  {dataSizeMB} KB
                </span>
              </label>
              <Input
                type="range"
                min={16}
                max={2048}
                step={16}
                value={dataSizeMB}
                onChange={(e) => setDataSizeMB(Number(e.target.value))}
                className="accent-primary p-0 h-2 border-0 bg-secondary rounded-full cursor-pointer"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>16 KB</span>
                <span>2048 KB</span>
              </div>
            </div>

            <div>
              <label className="mb-1 flex items-center gap-1 text-sm font-medium">
                <Clock className="h-4 w-4 text-primary" />
                DA Duration (days)
                <span className="ml-auto text-xs text-muted-foreground">
                  {durationDays} days
                </span>
              </label>
              <Input
                type="range"
                min={1}
                max={30}
                step={1}
                value={durationDays}
                onChange={(e) => setDurationDays(Number(e.target.value))}
                className="accent-primary p-0 h-2 border-0 bg-secondary rounded-full cursor-pointer"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>1 day</span>
                <span>30 days</span>
              </div>
            </div>

            <div>
              <label className="mb-1 flex items-center gap-1 text-sm font-medium">
                <TrendingUp className="h-4 w-4 text-primary" />
                Blobs per Day
                <span className="ml-auto text-xs text-muted-foreground">
                  {blobsPerDay}
                </span>
              </label>
              <Input
                type="range"
                min={1}
                max={1000}
                step={1}
                value={blobsPerDay}
                onChange={(e) => setBlobsPerDay(Number(e.target.value))}
                className="accent-primary p-0 h-2 border-0 bg-secondary rounded-full cursor-pointer"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>1</span>
                <span>1000</span>
              </div>
            </div>

            <div className="rounded-lg bg-secondary/50 p-3">
              <div className="flex items-center gap-1 text-xs font-medium text-primary">
                <Info className="h-3 w-3" />
                Included Features
              </div>
              <ul className="mt-1 space-y-0.5 text-xs text-muted-foreground">
                <li>Reed-Solomon erasure coding (RS 2,4)</li>
                <li>KZG polynomial commitments</li>
                <li>~3.5x compression</li>
                <li>Distributed storage ({durationDays}-day guarantee)</li>
                <li>Fraud proof verification</li>
                <li>Random sampling (30/epoch)</li>
              </ul>
            </div>

            <Button className="w-full" size="lg">
              Get Started <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </CardContent>
        </Card>

        <div className="space-y-6 lg:col-span-2">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <Card className="glass-card border-primary/20">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <DollarSign className="h-4 w-4 text-primary" />
                  DataDA Cost
                </div>
                <p className="mt-1 text-2xl font-bold text-primary">
                  ${costs.dataDA.total.toFixed(2)}
                </p>
                <p className="text-xs text-muted-foreground">
                  {(costs.dataDA.total / ETH_PRICE).toFixed(6)} ETH
                </p>
              </CardContent>
            </Card>
            <Card className="glass-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <BarChart3 className="h-4 w-4 text-yellow-400" />
                  vs ETH Calldata
                </div>
                <p className="mt-1 text-2xl font-bold text-yellow-400">
                  {savings.vsCalldata}% cheaper
                </p>
                <p className="text-xs text-muted-foreground">
                  ${costs.ethCalldata.toFixed(2)} equivalent
                </p>
              </CardContent>
            </Card>
            <Card className="glass-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <BarChart3 className="h-4 w-4 text-purple-400" />
                  vs ETH Blobs
                </div>
                <p className="mt-1 text-2xl font-bold text-purple-400">
                  {savings.vsBlobs}% cheaper
                </p>
                <p className="text-xs text-muted-foreground">
                  ${costs.ethBlobs.toFixed(2)} equivalent
                </p>
              </CardContent>
            </Card>
          </div>

          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-lg">Cost Comparison</CardTitle>
              <CardDescription>Monthly DA cost by provider (USD)</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={comparisonData} layout="vertical">
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="hsl(217.2 32.6% 17.5%)"
                  />
                  <XAxis
                    type="number"
                    stroke="#64748b"
                    tick={{ fontSize: 12 }}
                    tickFormatter={(v) => `$${v}`}
                  />
                  <YAxis
                    type="category"
                    dataKey="name"
                    stroke="#64748b"
                    tick={{ fontSize: 12 }}
                    width={100}
                  />
                  <Tooltip
                    contentStyle={{
                      background: "hsl(222.2 84% 4.9%)",
                      border: "1px solid hsl(217.2 32.6% 17.5%)",
                      borderRadius: 8,
                    }}
                    formatter={(value: number) => [`$${value.toFixed(4)}`, "Cost"]}
                  />
                  <Bar dataKey="cost" radius={[0, 4, 4, 0]}>
                    {comparisonData.map((entry, idx) => (
                      <Cell key={idx} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-lg">Cost Breakdown</CardTitle>
              <CardDescription>DataDA fee components</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  {
                    label: "Distributed Storage",
                    desc: `${dataSizeMB} KB × ${durationDays} days, ${costs.dataDA.storage < costs.dataDA.total ? '~3.5x compressed' : ''}`,
                    value: costs.dataDA.storage,
                    pct: costs.dataDA.total > 0 ? (costs.dataDA.storage / costs.dataDA.total) * 100 : 0,
                  },
                  {
                    label: "Erasure Coding",
                    desc: `RS(2,4) encoding × ${blobsPerDay} blobs/day`,
                    value: costs.dataDA.encoding,
                    pct: costs.dataDA.total > 0 ? (costs.dataDA.encoding / costs.dataDA.total) * 100 : 0,
                  },
                  {
                    label: "KZG Commitments",
                    desc: `${blobsPerDay} commitments/day`,
                    value: costs.dataDA.commitment,
                    pct: costs.dataDA.total > 0 ? (costs.dataDA.commitment / costs.dataDA.total) * 100 : 0,
                  },
                ].map((item) => (
                  <div key={item.label}>
                    <div className="flex items-center justify-between text-sm">
                      <div>
                        <span className="font-medium">{item.label}</span>
                        <span className="ml-2 text-xs text-muted-foreground">
                          {item.desc}
                        </span>
                      </div>
                      <span className="font-mono">${item.value.toFixed(4)}</span>
                    </div>
                    <div className="mt-1 h-1.5 w-full rounded-full bg-secondary overflow-hidden">
                      <div
                        className="h-full rounded-full bg-primary"
                        style={{ width: `${Math.max(item.pct, 2)}%` }}
                      />
                    </div>
                  </div>
                ))}

                <div className="mt-4 flex items-center justify-between border-t border-white/10 pt-3">
                  <span className="font-semibold">Total (30 days)</span>
                  <div className="text-right">
                    <span className="text-lg font-bold text-primary">
                      ${(costs.dataDA.total * (30 / durationDays)).toFixed(2)}
                    </span>
                    <p className="text-xs text-muted-foreground">
                      {(costs.dataDA.total * (30 / durationDays) / ETH_PRICE).toFixed(6)} ETH
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Card className="glass-card">
              <CardContent className="p-4">
                <h3 className="text-sm font-semibold text-emerald-400">
                  Per-Blob Cost
                </h3>
                <p className="mt-1 text-xl font-bold">
                  ${(costs.dataDA.total / blobsPerDay).toFixed(4)}
                </p>
                <p className="text-xs text-muted-foreground">
                  {(costs.dataDA.total / blobsPerDay / ETH_PRICE).toFixed(8)} ETH per blob
                </p>
              </CardContent>
            </Card>
            <Card className="glass-card">
              <CardContent className="p-4">
                <h3 className="text-sm font-semibold text-cyan-400">
                  Cost per GB-month
                </h3>
                <p className="mt-1 text-xl font-bold">
                  ${((costs.dataDA.total / (dataSizeMB / 1024)) * (30 / durationDays)).toFixed(2)}
                </p>
                <p className="text-xs text-muted-foreground">
                  Effective monthly rate per GB
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
