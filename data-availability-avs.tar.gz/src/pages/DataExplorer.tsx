import { useState, useMemo } from "react";
import {
  Search,
  Filter,
  ExternalLink,
  Copy,
  CheckCircle2,
  XCircle,
  AlertCircle,
  ChevronDown,
  ChevronUp,
  FileCode,
  ShieldCheck,
  Hash,
  Layers,
  Clock,
  HardDrive,
  Zap,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { blobs, operators } from "@/data/mock";
import type { Blob } from "@/data/mock";

const STATUS_ICON = {
  available: <CheckCircle2 className="h-4 w-4 text-emerald-400" />,
  expired: <XCircle className="h-4 w-4 text-muted-foreground" />,
  challenged: <AlertCircle className="h-4 w-4 text-yellow-400" />,
};

const STATUS_VARIANT: Record<Blob["status"], "success" | "secondary" | "warning"> = {
  available: "success",
  expired: "secondary",
  challenged: "warning",
};

export function DataExplorer() {
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState<Blob["status"] | "all">("all");
  const [filterRollup, setFilterRollup] = useState("all");
  const [expandedBlob, setExpandedBlob] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  const rollups = useMemo(() => [...new Set(blobs.map((b) => b.rollup))], []);

  const filtered = useMemo(() => {
    return blobs.filter((b) => {
      const matchSearch =
        search === "" ||
        b.id.toLowerCase().includes(search.toLowerCase()) ||
        b.txHash.toLowerCase().includes(search.toLowerCase()) ||
        b.commitment.toLowerCase().includes(search.toLowerCase()) ||
        b.rollup.toLowerCase().includes(search.toLowerCase());
      const matchStatus = filterStatus === "all" || b.status === filterStatus;
      const matchRollup = filterRollup === "all" || b.rollup === filterRollup;
      return matchSearch && matchStatus && matchRollup;
    });
  }, [search, filterStatus, filterRollup]);

  const copyId = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopied(id);
    setTimeout(() => setCopied(null), 1500);
  };

  const timeAgo = (ts: string) => {
    const diff = Date.now() - new Date(ts).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    return `${Math.floor(hrs / 24)}d ago`;
  };

  return (
    <div className="mx-auto max-w-7xl space-y-6 px-4 py-8">
      <div>
        <h1 className="text-3xl font-bold gradient-text">Data Explorer</h1>
        <p className="mt-1 text-muted-foreground">
          Browse and verify rollup blob data with KZG commitments
        </p>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search by blob ID, tx hash, commitment, rollup..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value as Blob["status"] | "all")}
            className="rounded-md border border-input bg-background px-3 py-2 text-sm"
          >
            <option value="all">All Status</option>
            <option value="available">Available</option>
            <option value="expired">Expired</option>
            <option value="challenged">Challenged</option>
          </select>
          <select
            value={filterRollup}
            onChange={(e) => setFilterRollup(e.target.value)}
            className="rounded-md border border-input bg-background px-3 py-2 text-sm"
          >
            <option value="all">All Rollups</option>
            {rollups.map((r) => (
              <option key={r} value={r}>
                {r}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card className="glass-card">
          <CardContent className="flex items-center gap-3 p-4">
            <CheckCircle2 className="h-8 w-8 text-emerald-400" />
            <div>
              <p className="text-2xl font-bold">{blobs.filter((b) => b.status === "available").length}</p>
              <p className="text-xs text-muted-foreground">Available</p>
            </div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="flex items-center gap-3 p-4">
            <XCircle className="h-8 w-8 text-muted-foreground" />
            <div>
              <p className="text-2xl font-bold">{blobs.filter((b) => b.status === "expired").length}</p>
              <p className="text-xs text-muted-foreground">Expired</p>
            </div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="flex items-center gap-3 p-4">
            <AlertCircle className="h-8 w-8 text-yellow-400" />
            <div>
              <p className="text-2xl font-bold">{blobs.filter((b) => b.status === "challenged").length}</p>
              <p className="text-xs text-muted-foreground">Challenged</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-lg">Blob Data</CardTitle>
          <CardDescription>
            {filtered.length} blob{filtered.length !== 1 ? "s" : ""} found
            &mdash; Reed-Solomon erasure coded with KZG commitments
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-8" />
                <TableHead>Blob ID</TableHead>
                <TableHead>Tx Hash</TableHead>
                <TableHead>Rollup</TableHead>
                <TableHead>Size</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Replicas</TableHead>
                <TableHead>Compression</TableHead>
                <TableHead>Time</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((blob) => {
                const isExpanded = expandedBlob === blob.id;
                const blockProgress =
                  ((blob.currentBlock - (blob.expiryBlock - 100000)) / 100000) * 100;
                return (
                  <>
                    <TableRow
                      key={blob.id}
                      className="cursor-pointer"
                      onClick={() => setExpandedBlob(isExpanded ? null : blob.id)}
                    >
                      <TableCell>
                        {isExpanded ? (
                          <ChevronUp className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <ChevronDown className="h-4 w-4 text-muted-foreground" />
                        )}
                      </TableCell>
                      <TableCell className="font-mono text-xs">
                        <div className="flex items-center gap-1">
                          {blob.id}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              copyId(blob.id);
                            }}
                            className="text-muted-foreground hover:text-foreground"
                          >
                            {copied === blob.id ? (
                              <CheckCircle2 className="h-3 w-3 text-emerald-400" />
                            ) : (
                              <Copy className="h-3 w-3" />
                            )}
                          </button>
                        </div>
                      </TableCell>
                      <TableCell className="font-mono text-xs">{blob.txHash}</TableCell>
                      <TableCell>{blob.rollup}</TableCell>
                      <TableCell>{blob.size}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          {STATUS_ICON[blob.status]}
                          <Badge variant={STATUS_VARIANT[blob.status]}>
                            {blob.status}
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell>{blob.replicas}</TableCell>
                      <TableCell>{blob.compressionRatio}x</TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {timeAgo(blob.timestamp)}
                      </TableCell>
                    </TableRow>
                    {isExpanded && (
                      <TableRow key={`${blob.id}-detail`}>
                        <TableCell colSpan={9} className="bg-white/[0.02]">
                          <div className="grid grid-cols-1 gap-4 p-4 sm:grid-cols-2 lg:grid-cols-3">
                            <div className="space-y-2">
                              <h4 className="flex items-center gap-1 text-sm font-semibold">
                                <Hash className="h-4 w-4 text-primary" />
                                Commitment
                              </h4>
                              <p className="break-all font-mono text-xs text-muted-foreground">
                                {blob.commitment}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                KZG polynomial commitment for verifiable data retrieval
                              </p>
                            </div>
                            <div className="space-y-2">
                              <h4 className="flex items-center gap-1 text-sm font-semibold">
                                <Layers className="h-4 w-4 text-primary" />
                                Encoding
                              </h4>
                              <p className="text-sm">{blob.encoding}</p>
                              <p className="text-xs text-muted-foreground">
                                Reed-Solomon erasure coding: data recoverable from any 2 of 4 shards
                              </p>
                            </div>
                            <div className="space-y-2">
                              <h4 className="flex items-center gap-1 text-sm font-semibold">
                                <Clock className="h-4 w-4 text-primary" />
                                DA Expiry
                              </h4>
                              <p className="text-sm">
                                Block {blob.expiryBlock.toLocaleString()}
                              </p>
                              <div className="h-2 w-full rounded-full bg-secondary overflow-hidden">
                                <div
                                  className="h-full rounded-full bg-primary"
                                  style={{ width: `${Math.min(blockProgress, 100)}%` }}
                                />
                              </div>
                              <p className="text-xs text-muted-foreground">
                                {(blob.expiryBlock - blob.currentBlock).toLocaleString()} blocks
                                remaining (~14 days)
                              </p>
                            </div>
                            <div className="space-y-2">
                              <h4 className="flex items-center gap-1 text-sm font-semibold">
                                <HardDrive className="h-4 w-4 text-primary" />
                                Storage
                              </h4>
                              <p className="text-sm">{blob.replicas} replicas across operators</p>
                              <p className="text-xs text-muted-foreground">
                                Distributed across {Math.min(blob.replicas, operators.filter((o) => o.status === "active").length)} active nodes
                              </p>
                            </div>
                            <div className="space-y-2">
                              <h4 className="flex items-center gap-1 text-sm font-semibold">
                                <Zap className="h-4 w-4 text-primary" />
                                Compression
                              </h4>
                              <p className="text-sm">{blob.compressionRatio}x ratio</p>
                              <p className="text-xs text-muted-foreground">
                                Original size → {blob.size} after {blob.compressionRatio}x compression
                              </p>
                            </div>
                            <div className="space-y-2">
                              <h4 className="flex items-center gap-1 text-sm font-semibold">
                                <ShieldCheck className="h-4 w-4 text-primary" />
                                Verification
                              </h4>
                              <p className="text-xs text-muted-foreground">
                                Random sampling: 30 challenges/epoch
                              </p>
                              <p className="text-xs text-muted-foreground">
                                Fraud proof window: 7 days
                              </p>
                              <Button variant="outline" size="sm" className="mt-1">
                                <FileCode className="mr-1 h-3 w-3" />
                                Verify Proof
                              </Button>
                            </div>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
