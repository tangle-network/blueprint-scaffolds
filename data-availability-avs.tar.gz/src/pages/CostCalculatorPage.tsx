import React from 'react'

export default function CostCalculatorPage() { return <div>CostCalculatorPage</div> }
