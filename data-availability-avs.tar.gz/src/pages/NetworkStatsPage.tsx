import React from 'react'

export default function NetworkStatsPage() { return <div>NetworkStatsPage</div> }
