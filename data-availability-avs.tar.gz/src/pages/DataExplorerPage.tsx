import React from 'react'

export default function DataExplorerPage() { return <div>DataExplorerPage</div> }
