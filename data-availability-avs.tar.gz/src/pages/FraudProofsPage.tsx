import React from 'react'

export default function FraudProofsPage() { return <div>FraudProofsPage</div> }
