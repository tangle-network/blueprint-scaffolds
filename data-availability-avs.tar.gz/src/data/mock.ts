export interface Operator {
  id: string;
  address: string;
  location: string;
  region: string;
  stake: number;
  status: "active" | "inactive" | "slashed";
  uptime: number;
  bandwidth: string;
  latency: number;
  blobsStored: number;
  reputation: number;
  earnings: string;
}

export interface Blob {
  id: string;
  txHash: string;
  size: string;
  timestamp: string;
  commitment: string;
  encoding: string;
  expiryBlock: number;
  currentBlock: number;
  rollup: string;
  status: "available" | "expired" | "challenged";
  replicas: number;
  compressionRatio: number;
}

export interface NetworkStats {
  totalStake: string;
  totalOperators: number;
  activeOperators: number;
  totalBlobs: number;
  totalDataStored: string;
  avgLatency: number;
  networkUptime: number;
  slashingEvents: number;
  totalRewards: string;
  daGuarantee: string;
}

export const networkStats: NetworkStats = {
  totalStake: "2,048 ETH",
  totalOperators: 64,
  activeOperators: 58,
  totalBlobs: 1_284_531,
  totalDataStored: "42.7 TB",
  avgLatency: 128,
  networkUptime: 99.97,
  slashingEvents: 3,
  totalRewards: "156.8 ETH",
  daGuarantee: "14 days",
};

export const operators: Operator[] = [
  { id: "op-001", address: "0x1a2B...3c4D", location: "Frankfurt, DE", region: "EU", stake: 64, status: "active", uptime: 99.99, bandwidth: "1.2 Gbps", latency: 42, blobsStored: 45_231, reputation: 98.5, earnings: "4.82 ETH" },
  { id: "op-002", address: "0x5e6F...7g8H", location: "Virginia, US", region: "NA", stake: 96, status: "active", uptime: 99.98, bandwidth: "2.1 Gbps", latency: 38, blobsStored: 52_847, reputation: 99.1, earnings: "7.23 ETH" },
  { id: "op-003", address: "0x9i0J...1k2L", location: "Tokyo, JP", region: "APAC", stake: 32, status: "active", uptime: 99.95, bandwidth: "980 Mbps", latency: 89, blobsStored: 31_456, reputation: 97.2, earnings: "2.41 ETH" },
  { id: "op-004", address: "0x3m4N...5o6P", location: "Singapore, SG", region: "APAC", stake: 128, status: "active", uptime: 99.99, bandwidth: "2.5 Gbps", latency: 67, blobsStored: 68_129, reputation: 99.8, earnings: "9.64 ETH" },
  { id: "op-005", address: "0x7q8R...9s0T", location: "London, UK", region: "EU", stake: 32, status: "inactive", uptime: 94.21, bandwidth: "450 Mbps", latency: 55, blobsStored: 12_341, reputation: 78.3, earnings: "0.91 ETH" },
  { id: "op-006", address: "0x1u2V...3w4X", location: "São Paulo, BR", region: "SA", stake: 64, status: "active", uptime: 99.92, bandwidth: "1.8 Gbps", latency: 142, blobsStored: 38_912, reputation: 96.7, earnings: "4.82 ETH" },
  { id: "op-007", address: "0x5y6Z...7a8B", location: "Toronto, CA", region: "NA", stake: 32, status: "active", uptime: 99.96, bandwidth: "1.1 Gbps", latency: 45, blobsStored: 29_743, reputation: 97.8, earnings: "2.41 ETH" },
  { id: "op-008", address: "0x9c0D...1e2F", location: "Mumbai, IN", region: "APAC", stake: 96, status: "slashed", uptime: 87.34, bandwidth: "750 Mbps", latency: 156, blobsStored: 8_421, reputation: 42.1, earnings: "0.12 ETH" },
  { id: "op-009", address: "0x3g4H...5i6J", location: "Amsterdam, NL", region: "EU", stake: 64, status: "active", uptime: 99.97, bandwidth: "1.9 Gbps", latency: 39, blobsStored: 44_567, reputation: 98.9, earnings: "4.82 ETH" },
  { id: "op-010", address: "0x7k8L...9m0N", location: "Sydney, AU", region: "APAC", stake: 32, status: "active", uptime: 99.94, bandwidth: "1.0 Gbps", latency: 178, blobsStored: 22_189, reputation: 96.1, earnings: "2.41 ETH" },
];

export const blobs: Blob[] = [
  { id: "blob-0x001a", txHash: "0xa1b2...c3d4", size: "128 KB", timestamp: "2026-04-05T10:23:41Z", commitment: "0xe5f6...g7h8", encoding: "RS(2,4)", expiryBlock: 21_450_000, currentBlock: 21_350_000, rollup: "Arbitrum", status: "available", replicas: 6, compressionRatio: 3.2 },
  { id: "blob-0x002b", txHash: "0xb2c3...d4e5", size: "256 KB", timestamp: "2026-04-05T10:21:18Z", commitment: "0xf6g7...h8i9", encoding: "RS(2,4)", expiryBlock: 21_450_000, currentBlock: 21_350_000, rollup: "Optimism", status: "available", replicas: 8, compressionRatio: 2.8 },
  { id: "blob-0x003c", txHash: "0xc3d4...e5f6", size: "64 KB", timestamp: "2026-04-05T10:19:55Z", commitment: "0xg7h8...i9j0", encoding: "RS(2,4)", expiryBlock: 21_450_000, currentBlock: 21_350_000, rollup: "Base", status: "available", replicas: 5, compressionRatio: 4.1 },
  { id: "blob-0x004d", txHash: "0xd4e5...f6g7", size: "512 KB", timestamp: "2026-04-05T10:17:32Z", commitment: "0xh8i9...j0k1", encoding: "RS(2,4)", expiryBlock: 21_440_000, currentBlock: 21_350_000, rollup: "zkSync", status: "available", replicas: 7, compressionRatio: 2.1 },
  { id: "blob-0x005e", txHash: "0xe5f6...g7h8", size: "192 KB", timestamp: "2026-04-05T10:15:09Z", commitment: "0xi9j0...k1l2", encoding: "RS(2,4)", expiryBlock: 21_430_000, currentBlock: 21_350_000, rollup: "StarkNet", status: "available", replicas: 6, compressionRatio: 3.5 },
  { id: "blob-0x006f", txHash: "0xf6g7...h8i9", size: "96 KB", timestamp: "2026-04-04T22:41:23Z", commitment: "0xj0k1...l2m3", encoding: "RS(2,4)", expiryBlock: 21_320_000, currentBlock: 21_350_000, rollup: "Arbitrum", status: "expired", replicas: 3, compressionRatio: 2.9 },
  { id: "blob-0x007g", txHash: "0xg7h8...i9j0", size: "320 KB", timestamp: "2026-04-05T09:58:41Z", commitment: "0xk1l2...m3n4", encoding: "RS(2,4)", expiryBlock: 21_450_000, currentBlock: 21_350_000, rollup: "Polygon zkEVM", status: "challenged", replicas: 4, compressionRatio: 2.4 },
  { id: "blob-0x008h", txHash: "0xh8i9...j0k1", size: "448 KB", timestamp: "2026-04-05T09:45:12Z", commitment: "0xl2m3...n4o5", encoding: "RS(2,4)", expiryBlock: 21_450_000, currentBlock: 21_350_000, rollup: "Optimism", status: "available", replicas: 9, compressionRatio: 3.0 },
  { id: "blob-0x009i", txHash: "0xi9j0...k1l2", size: "160 KB", timestamp: "2026-04-05T09:32:55Z", commitment: "0xm3n4...o5p6", encoding: "RS(2,4)", expiryBlock: 21_450_000, currentBlock: 21_350_000, rollup: "Base", status: "available", replicas: 7, compressionRatio: 3.7 },
  { id: "blob-0x010j", txHash: "0xj0k1...l2m3", size: "384 KB", timestamp: "2026-04-05T09:18:33Z", commitment: "0xn4o5...p6q7", encoding: "RS(2,4)", expiryBlock: 21_450_000, currentBlock: 21_350_000, rollup: "zkSync", status: "available", replicas: 6, compressionRatio: 2.3 },
];

export const throughputData = [
  { time: "00:00", blobs: 120, throughput: 2.4 },
  { time: "02:00", blobs: 98, throughput: 1.9 },
  { time: "04:00", blobs: 85, throughput: 1.7 },
  { time: "06:00", blobs: 145, throughput: 2.9 },
  { time: "08:00", blobs: 210, throughput: 4.2 },
  { time: "10:00", blobs: 280, throughput: 5.6 },
  { time: "12:00", blobs: 310, throughput: 6.2 },
  { time: "14:00", blobs: 295, throughput: 5.9 },
  { time: "16:00", blobs: 340, throughput: 6.8 },
  { time: "18:00", blobs: 270, throughput: 5.4 },
  { time: "20:00", blobs: 230, throughput: 4.6 },
  { time: "22:00", blobs: 180, throughput: 3.6 },
];

export const stakeDistribution = [
  { region: "NA", stake: 640, operators: 18 },
  { region: "EU", stake: 576, operators: 16 },
  { region: "APAC", stake: 512, operators: 14 },
  { region: "SA", stake: 192, operators: 6 },
  { region: "AF", stake: 128, operators: 4 },
  { region: "Other", stake: 96, operators: 6 },
];
