import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Layout } from "./components/Layout";
import { NetworkStats } from "./pages/NetworkStats";
import { DataExplorer } from "./pages/DataExplorer";
import { CostCalculator } from "./pages/CostCalculator";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<NetworkStats />} />
          <Route path="/explorer" element={<DataExplorer />} />
          <Route path="/calculator" element={<CostCalculator />} />
        </Route>
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);
