export type Metric = {
  label: string
  value: string
  detail: string
}

export type Operator = {
  id: string
  region: string
  stakeEth: number
  bandwidthGbps: number
  availability: number
  shardLoad: number
  rewardBoost: string
}

export type BlobRecord = {
  id: string
  rollup: string
  sizeKb: number
  compressionRatio: string
  kzgRoot: string
  erasureFactor: string
  sampleRate: string
  status: string
}

export type TimelineEvent = {
  title: string
  body: string
}

export const heroMetrics: Metric[] = [
  {
    label: 'Protected stake',
    value: '32 ETH min',
    detail: 'Every active operator is collateralized before receiving shards.',
  },
  {
    label: 'DA guarantee',
    value: '14 days',
    detail: 'Encoded chunks remain queryable for the full fraud-proof window.',
  },
  {
    label: 'Sampling latency',
    value: '< 900 ms',
    detail: 'Random sampling rounds complete before sequencer finalization windows.',
  },
  {
    label: 'Compression gain',
    value: '58%',
    detail: 'Rollup blobs are compressed before KZG commitment and shard fan-out.',
  },
]

export const operators: Operator[] = [
  {
    id: 'op-us-east-01',
    region: 'Virginia, US',
    stakeEth: 48,
    bandwidthGbps: 12,
    availability: 99.98,
    shardLoad: 22,
    rewardBoost: '+11%',
  },
  {
    id: 'op-eu-central-03',
    region: 'Frankfurt, DE',
    stakeEth: 64,
    bandwidthGbps: 10,
    availability: 99.94,
    shardLoad: 18,
    rewardBoost: '+9%',
  },
  {
    id: 'op-ap-south-02',
    region: 'Mumbai, IN',
    stakeEth: 40,
    bandwidthGbps: 8,
    availability: 99.87,
    shardLoad: 17,
    rewardBoost: '+6%',
  },
  {
    id: 'op-sa-east-04',
    region: 'Sao Paulo, BR',
    stakeEth: 36,
    bandwidthGbps: 7,
    availability: 99.79,
    shardLoad: 14,
    rewardBoost: '+4%',
  },
]

export const blobs: BlobRecord[] = [
  {
    id: 'blob-18af',
    rollup: 'Atlas zkEVM',
    sizeKb: 768,
    compressionRatio: '2.3x',
    kzgRoot: '0x94fd...aa21',
    erasureFactor: '1.8x',
    sampleRate: '36/64',
    status: 'Committed',
  },
  {
    id: 'blob-1902',
    rollup: 'Quartz Rollup',
    sizeKb: 512,
    compressionRatio: '1.9x',
    kzgRoot: '0x11cd...47be',
    erasureFactor: '2.0x',
    sampleRate: '40/64',
    status: 'Archived',
  },
  {
    id: 'blob-1907',
    rollup: 'Vector L3',
    sizeKb: 896,
    compressionRatio: '2.7x',
    kzgRoot: '0x7c2e...b913',
    erasureFactor: '1.6x',
    sampleRate: '48/96',
    status: 'Sampling',
  },
]

export const architecture: TimelineEvent[] = [
  {
    title: 'Compress and commit',
    body: 'Rollup transactions are compressed, chunked, and committed with a KZG polynomial root before broadcast.',
  },
  {
    title: 'Encode and distribute',
    body: 'Reed-Solomon erasure coding expands data into shards that are mapped across geographically diverse EigenLayer operators.',
  },
  {
    title: 'Sample and attest',
    body: 'Light clients request random shard samples while operators sign DA attestations tied to the commitment root.',
  },
  {
    title: 'Challenge with fraud proofs',
    body: 'Invalid commitments or missing shards trigger fraud proofs and slashable fault reports within the 2-week availability window.',
  },
]

export const rewardLevers: string[] = [
  'Base rewards increase with sustained shard availability and sample response time.',
  'Bandwidth commitments above 8 Gbps unlock preferred allocation for jumbo blobs.',
  'Operators spanning underrepresented regions receive a geographic diversity multiplier.',
  'Fraud-proof wins route penalties into an insurance reserve for affected rollups.',
]
