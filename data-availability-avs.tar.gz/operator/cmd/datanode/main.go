package main

import (
	"context"
	"log"
	"os"
	"os/signal"
	"syscall"

	"github.com/example/eigen-da-avs/operator/internal/node"
)

func main() {
	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()

	cfg := node.Config{
		NodeID:          "op-us-east-01",
		ListenAddress:   "/ip4/0.0.0.0/tcp/4101",
		StakeETH:        48,
		RetentionHours:  24 * 14,
		BandwidthGbps:   12,
		SamplingTargets: 32,
	}

	dataNode := node.New(cfg)
	if err := dataNode.Run(ctx); err != nil {
		log.Fatal(err)
	}
}
