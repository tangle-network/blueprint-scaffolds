module github.com/example/eigen-da-avs/operator

go 1.22
