package node

import (
	"context"
	"fmt"
	"log"
	"math/rand"
	"time"
)

type Config struct {
	NodeID          string
	ListenAddress   string
	StakeETH        uint64
	RetentionHours  int
	BandwidthGbps   uint64
	SamplingTargets int
}

type Node struct {
	cfg Config
}

func New(cfg Config) *Node {
	return &Node{cfg: cfg}
}

func (n *Node) Run(ctx context.Context) error {
	log.Printf("starting data node %s on %s", n.cfg.NodeID, n.cfg.ListenAddress)
	log.Printf("stake=%d eth bandwidth=%d gbps retention=%d hours", n.cfg.StakeETH, n.cfg.BandwidthGbps, n.cfg.RetentionHours)

	ticker := time.NewTicker(3 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			log.Printf("shutting down node %s", n.cfg.NodeID)
			return nil
		case <-ticker.C:
			log.Print(n.sampleReport())
		}
	}
}

func (n *Node) sampleReport() string {
	available := rand.Intn(n.cfg.SamplingTargets) + 1
	return fmt.Sprintf(
		"sample round complete: %d/%d shards available, kzg verification ok, fraud-proof export idle",
		available,
		n.cfg.SamplingTargets,
	)
}
