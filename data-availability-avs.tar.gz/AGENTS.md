# AGENTS.md

## Goal

Build a Data Availability AVS on EigenLayer for rollup transaction data. Data attestation, sampling, operator coordination.

## Stack

- Family: `eigenlayer-avs`
- Layers: 
- Partner: `eigenlayer`

## Entry Points

- `avs.config.json`
- `contracts/ServiceManager.sol`
- `operator/main.rs`

## Commands

- `node validate-avs.mjs`
- `forge build`
- `cargo check`

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
