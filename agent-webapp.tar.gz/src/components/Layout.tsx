import { useState } from "react"
import { Sidebar, type ViewType } from "@/components/Sidebar"
import { SessionList } from "@/components/SessionList"
import { ChatPanel } from "@/components/ChatPanel"
import { TaskList } from "@/components/TaskList"
import { WorkspacePanel } from "@/components/WorkspacePanel"
import { Separator } from "@/components/ui/separator"

export function Layout() {
  const [activeView, setActiveView] = useState<ViewType>("chat")
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [sessionPanelOpen, setSessionPanelOpen] = useState(true)

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar
        activeView={activeView}
        onViewChange={setActiveView}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
      />
      {activeView === "chat" && sessionPanelOpen && (
        <>
          <div className="w-72 shrink-0">
            <SessionList />
          </div>
          <Separator orientation="vertical" />
        </>
      )}
      <main className="flex-1 min-w-0">
        {activeView === "chat" && <ChatPanel />}
        {activeView === "tasks" && <TaskList />}
        {activeView === "workspace" && <WorkspacePanel />}
      </main>
    </div>
  )
}
