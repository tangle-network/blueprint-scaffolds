import { cn } from "@/lib/utils"
import { MessageSquare, ListTodo, FolderTree, Bot, PanelLeftClose, PanelLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip"

export type ViewType = "chat" | "tasks" | "workspace"

interface SidebarProps {
  activeView: ViewType
  onViewChange: (view: ViewType) => void
  collapsed: boolean
  onToggleCollapse: () => void
}

const navItems: { view: ViewType; icon: typeof MessageSquare; label: string }[] = [
  { view: "chat", icon: MessageSquare, label: "Chat" },
  { view: "tasks", icon: ListTodo, label: "Tasks" },
  { view: "workspace", icon: FolderTree, label: "Workspace" },
]

export function Sidebar({ activeView, onViewChange, collapsed, onToggleCollapse }: SidebarProps) {
  return (
    <TooltipProvider delayDuration={0}>
      <div
        className={cn(
          "flex h-full flex-col border-r bg-card transition-all duration-200",
          collapsed ? "w-14" : "w-56"
        )}
      >
        <div className={cn("flex items-center border-b px-3 py-3", collapsed ? "justify-center" : "gap-2")}>
          <Bot className="h-5 w-5 shrink-0 text-primary" />
          {!collapsed && <span className="text-sm font-bold">AI Agent</span>}
          <Button
            variant="ghost"
            size="icon"
            className={cn("ml-auto h-7 w-7 shrink-0", collapsed && "ml-0")}
            onClick={onToggleCollapse}
          >
            {collapsed ? <PanelLeft className="h-4 w-4" /> : <PanelLeftClose className="h-4 w-4" />}
          </Button>
        </div>
        <nav className="flex-1 space-y-1 p-2">
          {navItems.map((item) => {
            const Icon = item.icon
            const btn = (
              <button
                key={item.view}
                onClick={() => onViewChange(item.view)}
                className={cn(
                  "flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors hover:bg-accent",
                  activeView === item.view && "bg-accent font-medium",
                  collapsed && "justify-center px-0"
                )}
              >
                <Icon className={cn("h-4 w-4 shrink-0", activeView === item.view && "text-primary")} />
                {!collapsed && <span>{item.label}</span>}
              </button>
            )
            if (collapsed) {
              return (
                <Tooltip key={item.view}>
                  <TooltipTrigger asChild>{btn}</TooltipTrigger>
                  <TooltipContent side="right">{item.label}</TooltipContent>
                </Tooltip>
              )
            }
            return btn
          })}
        </nav>
        <Separator />
        <div className={cn("p-3 text-center", collapsed && "px-1")}>
          <div className={cn("text-[10px] text-muted-foreground", collapsed && "text-[8px]")}>
            {collapsed ? "v1" : "Agent v1.0.0"}
          </div>
        </div>
      </div>
    </TooltipProvider>
  )
}
