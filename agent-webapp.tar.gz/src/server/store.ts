import { randomUUID } from 'crypto';
import type { Session, ChatMessage, Artifact, TaskRun, TaskStep, ToolCall } from '../shared/types.js';

type StoreListener = (event: string, data: unknown) => void;

class SessionStore {
  private sessions: Map<string, Session> = new Map();
  private listeners: Set<StoreListener> = new Set();

  subscribe(listener: StoreListener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private emit(event: string, data: unknown) {
    for (const listener of this.listeners) {
      listener(event, data);
    }
  }

  createSession(title?: string): Session {
    const session: Session = {
      id: randomUUID(),
      title: title || 'New Session',
      messages: [],
      artifacts: [],
      taskRuns: [],
      status: 'active',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    this.sessions.set(session.id, session);
    this.emit('session.created', session);
    return session;
  }

  getSession(id: string): Session | undefined {
    return this.sessions.get(id);
  }

  getAllSessions(): Session[] {
    return Array.from(this.sessions.values()).sort((a, b) => b.updatedAt - a.updatedAt);
  }

  addMessage(sessionId: string, message: Omit<ChatMessage, 'id' | 'timestamp'>): ChatMessage {
    const session = this.sessions.get(sessionId);
    if (!session) throw new Error(`Session ${sessionId} not found`);
    const msg: ChatMessage = {
      ...message,
      id: randomUUID(),
      timestamp: Date.now(),
    };
    session.messages.push(msg);
    session.updatedAt = Date.now();
    if (session.messages.filter((m) => m.role === 'user').length === 1 && session.title === 'New Session') {
      session.title = message.content.slice(0, 60) + (message.content.length > 60 ? '...' : '');
    }
    this.emit('session.updated', session);
    return msg;
  }

  updateMessageToolCalls(sessionId: string, messageId: string, toolCalls: ToolCall[]) {
    const session = this.sessions.get(sessionId);
    if (!session) return;
    const msg = session.messages.find((m) => m.id === messageId);
    if (msg) {
      msg.toolCalls = toolCalls;
      session.updatedAt = Date.now();
      this.emit('session.updated', session);
    }
  }

  addArtifact(sessionId: string, artifact: Omit<Artifact, 'id' | 'sessionId' | 'createdAt'>): Artifact {
    const session = this.sessions.get(sessionId);
    if (!session) throw new Error(`Session ${sessionId} not found`);
    const art: Artifact = {
      ...artifact,
      id: randomUUID(),
      sessionId,
      createdAt: Date.now(),
    };
    session.artifacts.push(art);
    session.updatedAt = Date.now();
    this.emit('artifact.created', art);
    return art;
  }

  addTaskRun(sessionId: string, task: Omit<TaskRun, 'id' | 'sessionId' | 'createdAt'>): TaskRun {
    const session = this.sessions.get(sessionId);
    if (!session) throw new Error(`Session ${sessionId} not found`);
    const run: TaskRun = {
      ...task,
      id: randomUUID(),
      sessionId,
      createdAt: Date.now(),
    };
    session.taskRuns.push(run);
    session.updatedAt = Date.now();
    this.emit('task.created', run);
    return run;
  }

  updateTaskRun(sessionId: string, taskId: string, updates: Partial<TaskRun>): TaskRun | undefined {
    const session = this.sessions.get(sessionId);
    if (!session) return undefined;
    const task = session.taskRuns.find((t) => t.id === taskId);
    if (task) {
      Object.assign(task, updates);
      session.updatedAt = Date.now();
      this.emit('task.updated', task);
    }
    return task;
  }

  updateTaskStep(sessionId: string, taskId: string, stepId: string, updates: Partial<TaskStep>): TaskRun | undefined {
    const session = this.sessions.get(sessionId);
    if (!session) return undefined;
    const task = session.taskRuns.find((t) => t.id === taskId);
    if (!task) return undefined;
    const step = task.steps.find((s) => s.id === stepId);
    if (step) {
      Object.assign(step, updates);
      session.updatedAt = Date.now();
      this.emit('task.updated', task);
    }
    return task;
  }

  deleteSession(id: string): boolean {
    const deleted = this.sessions.delete(id);
    if (deleted) this.emit('session.deleted', { id });
    return deleted;
  }

  archiveSession(id: string): Session | undefined {
    const session = this.sessions.get(id);
    if (session) {
      session.status = 'archived';
      session.updatedAt = Date.now();
      this.emit('session.updated', session);
    }
    return session;
  }
}

export const store = new SessionStore();
