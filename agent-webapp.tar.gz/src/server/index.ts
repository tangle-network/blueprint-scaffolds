import express from 'express';
import cors from 'cors';
import { apiRouter } from './routes.js';
import { store } from './store.js';

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

app.use('/api', apiRouter);

app.use('/health', (_req, res) => {
  res.json({ status: 'ok', uptime: process.uptime(), sessions: store.getAllSessions().length });
});

app.listen(PORT, () => {
  console.log(`[Agent API] Server running on http://localhost:${PORT}`);
  console.log(`[Agent API] Health check: http://localhost:${PORT}/health`);
});

export { app };
