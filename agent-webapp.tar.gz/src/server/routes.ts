import { Router, type Request, type Response } from 'express';
import { store } from './store.js';
import { Agent, getAvailableTools } from './agent.js';
import { worker } from './worker.js';
import type { AgentEvent } from '../shared/types.js';

export const apiRouter = Router();

apiRouter.get('/sessions', (_req: Request, res: Response) => {
  const sessions = store.getAllSessions().map((s) => ({
    id: s.id,
    title: s.title,
    status: s.status,
    messageCount: s.messages.length,
    artifactCount: s.artifacts.length,
    taskCount: s.taskRuns.length,
    createdAt: s.createdAt,
    updatedAt: s.updatedAt,
  }));
  res.json({ sessions });
});

apiRouter.post('/sessions', (req: Request, res: Response) => {
  const { title } = req.body || {};
  const session = store.createSession(title);
  res.status(201).json({ session });
});

apiRouter.get('/sessions/:id', (req: Request, res: Response) => {
  const session = store.getSession(req.params.id);
  if (!session) return res.status(404).json({ error: 'Session not found' });
  res.json({ session });
});

apiRouter.delete('/sessions/:id', (req: Request, res: Response) => {
  const deleted = store.deleteSession(req.params.id);
  if (!deleted) return res.status(404).json({ error: 'Session not found' });
  res.json({ success: true });
});

apiRouter.post('/sessions/:id/archive', (req: Request, res: Response) => {
  const session = store.archiveSession(req.params.id);
  if (!session) return res.status(404).json({ error: 'Session not found' });
  res.json({ session });
});

apiRouter.post('/sessions/:id/messages', async (req: Request, res: Response) => {
  const { content, stream } = req.body || {};
  const sessionId = req.params.id;

  if (!content || typeof content !== 'string') {
    return res.status(400).json({ error: 'content is required' });
  }

  const session = store.getSession(sessionId);
  if (!session) return res.status(404).json({ error: 'Session not found' });

  if (stream) {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders();

    const emit = (event: AgentEvent) => {
      res.write(`data: ${JSON.stringify(event)}\n\n`);
    };

    const agent = new Agent(sessionId, emit);
    try {
      await agent.processMessage(content);
    } catch (err) {
      emit({ type: 'error', sessionId, data: { error: String(err) }, timestamp: Date.now() });
    }
    res.write(`data: ${JSON.stringify({ type: 'done', sessionId, data: {}, timestamp: Date.now() })}\n\n`);
    res.end();
  } else {
    const events: AgentEvent[] = [];
    const emit = (event: AgentEvent) => { events.push(event); };
    const agent = new Agent(sessionId, emit);
    try {
      await agent.processMessage(content);
      const updatedSession = store.getSession(sessionId);
      res.json({ session: updatedSession, events });
    } catch (err) {
      res.status(500).json({ error: String(err), events });
    }
  }
});

apiRouter.post('/sessions/:id/tasks', (req: Request, res: Response) => {
  const { type, payload } = req.body || {};
  const sessionId = req.params.id;
  const session = store.getSession(sessionId);
  if (!session) return res.status(404).json({ error: 'Session not found' });

  const job = worker.enqueue(sessionId, type || 'background_task', payload || {});
  res.status(201).json({ job });
});

apiRouter.get('/sessions/:id/tasks', (req: Request, res: Response) => {
  const session = store.getSession(req.params.id);
  if (!session) return res.status(404).json({ error: 'Session not found' });
  res.json({ tasks: session.taskRuns });
});

apiRouter.get('/sessions/:id/artifacts', (req: Request, res: Response) => {
  const session = store.getSession(req.params.id);
  if (!session) return res.status(404).json({ error: 'Session not found' });
  res.json({ artifacts: session.artifacts });
});

apiRouter.get('/sessions/:id/events', (req: Request, res: Response) => {
  const sessionId = req.params.id;
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();

  const keepAlive = setInterval(() => {
    res.write(`: keepalive\n\n`);
  }, 15000);

  const unsubscribe = store.subscribe((event: string, data: unknown) => {
    if (event === 'session.deleted') {
      const d = data as { id: string };
      if (d.id === sessionId) {
        res.write(`data: ${JSON.stringify({ type: 'session.deleted', sessionId, data: {}, timestamp: Date.now() })}\n\n`);
        res.end();
      }
      return;
    }
    const d = data as { sessionId?: string };
    if (d && d.sessionId === sessionId) {
      res.write(`data: ${JSON.stringify({ type: event, sessionId, data, timestamp: Date.now() })}\n\n`);
    }
  });

  res.write(`data: ${JSON.stringify({ type: 'connected', sessionId, data: {}, timestamp: Date.now() })}\n\n`);

  req.on('close', () => {
    clearInterval(keepAlive);
    unsubscribe();
  });
});

apiRouter.get('/tools', (_req: Request, res: Response) => {
  res.json({ tools: getAvailableTools() });
});

apiRouter.get('/worker/jobs', (_req: Request, res: Response) => {
  const allSessions = store.getAllSessions();
  const jobs = allSessions.flatMap((s) => worker.getJobs(s.id));
  res.json({ jobs });
});
