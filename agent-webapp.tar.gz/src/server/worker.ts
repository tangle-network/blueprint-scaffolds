import { randomUUID } from 'crypto';
import { store } from './store.js';
import type { TaskRun, TaskStep } from '../shared/types.js';

export interface WorkerJob {
  id: string;
  sessionId: string;
  type: 'background_task' | 'batch_analysis' | 'scheduled_run';
  payload: Record<string, unknown>;
  status: 'queued' | 'running' | 'completed' | 'failed';
  createdAt: number;
  startedAt?: number;
  completedAt?: number;
  result?: string;
  error?: string;
}

class AgentWorker {
  private queue: WorkerJob[] = [];
  private processing = false;
  private listeners: Set<(job: WorkerJob) => void> = new Set();

  subscribe(listener: (job: WorkerJob) => void) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify(job: WorkerJob) {
    for (const listener of this.listeners) {
      listener(job);
    }
  }

  enqueue(sessionId: string, type: WorkerJob['type'], payload: Record<string, unknown>): WorkerJob {
    const job: WorkerJob = {
      id: randomUUID(),
      sessionId,
      type,
      payload,
      status: 'queued',
      createdAt: Date.now(),
    };
    this.queue.push(job);
    this.processNext();
    return job;
  }

  getJobs(sessionId: string): WorkerJob[] {
    return this.queue.filter((j) => j.sessionId === sessionId);
  }

  getJob(id: string): WorkerJob | undefined {
    return this.queue.find((j) => j.id === id);
  }

  private async processNext() {
    if (this.processing) return;
    const job = this.queue.find((j) => j.status === 'queued');
    if (!job) return;

    this.processing = true;
    job.status = 'running';
    job.startedAt = Date.now();
    this.notify(job);

    try {
      const taskRun = store.addTaskRun(job.sessionId, {
        title: `Background: ${job.type}`,
        description: `Worker job ${job.id}`,
        status: 'running',
        steps: this.createSteps(job),
        startedAt: Date.now(),
      });

      for (let i = 0; i < taskRun.steps.length; i++) {
        const step = taskRun.steps[i];
        store.updateTaskStep(job.sessionId, taskRun.id, step.id, { status: 'running', startedAt: Date.now() });
        await this.simulateStep(job, step);
        store.updateTaskStep(job.sessionId, taskRun.id, step.id, { status: 'completed', completedAt: Date.now() });
      }

      store.updateTaskRun(job.sessionId, taskRun.id, {
        status: 'completed',
        completedAt: Date.now(),
        result: 'Background task completed successfully',
      });

      job.status = 'completed';
      job.completedAt = Date.now();
      job.result = 'Background task completed successfully';
    } catch (err) {
      job.status = 'failed';
      job.error = String(err);
      job.completedAt = Date.now();
    }

    this.processing = false;
    this.notify(job);
    this.processNext();
  }

  private createSteps(job: WorkerJob): TaskStep[] {
    const stepCount = 2 + Math.floor(Math.random() * 4);
    const stepNames = ['Initializing', 'Fetching data', 'Processing', 'Analyzing results', 'Generating output', 'Finalizing'];
    return Array.from({ length: stepCount }, (_, i) => ({
      id: `step_${randomUUID().slice(0, 8)}`,
      label: stepNames[i] || `Step ${i + 1}`,
      status: 'pending' as const,
    }));
  }

  private async simulateStep(_job: WorkerJob, _step: TaskStep): Promise<void> {
    await new Promise((resolve) => setTimeout(resolve, 500 + Math.random() * 1500));
  }
}

export const worker = new AgentWorker();
