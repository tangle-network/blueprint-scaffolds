import { randomUUID } from 'crypto';
import type { ToolCall } from '../shared/types.js';

export interface ToolDefinition {
  name: string;
  description: string;
  parameters: Record<string, { type: string; description: string; required?: boolean }>;
  execute: (args: Record<string, unknown>) => Promise<{ success: boolean; output: string; data?: unknown }>;
}

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export const tools: Record<string, ToolDefinition> = {
  web_search: {
    name: 'web_search',
    description: 'Search the web for information',
    parameters: {
      query: { type: 'string', description: 'Search query', required: true },
      max_results: { type: 'number', description: 'Max results to return' },
    },
    execute: async (args) => {
      await delay(800 + Math.random() * 1200);
      const query = String(args.query);
      const results = [
        { title: `${query} - Comprehensive Guide`, url: `https://example.com/guide/${encodeURIComponent(query)}`, snippet: `A thorough guide covering all aspects of ${query}. Learn the fundamentals, advanced techniques, and best practices.` },
        { title: `${query} Documentation`, url: `https://docs.example.com/${encodeURIComponent(query)}`, snippet: `Official documentation for ${query}. Includes API references, tutorials, and examples.` },
        { title: `Understanding ${query} in 2024`, url: `https://blog.example.com/${encodeURIComponent(query)}`, snippet: `Recent developments and insights about ${query} from industry experts.` },
      ];
      return { success: true, output: `Found ${results.length} results for "${query}"`, data: results };
    },
  },

  code_execute: {
    name: 'code_execute',
    description: 'Execute code and return the output',
    parameters: {
      language: { type: 'string', description: 'Programming language', required: true },
      code: { type: 'string', description: 'Code to execute', required: true },
    },
    execute: async (args) => {
      await delay(1000 + Math.random() * 1500);
      const language = String(args.language);
      const code = String(args.code);
      let output = '';
      if (language === 'python') {
        if (code.includes('print')) {
          const match = code.match(/print\(["'](.+?)["']\)/);
          output = match ? match[1] : 'Program executed successfully';
        } else {
          output = 'Code executed with exit code 0. No output.';
        }
      } else if (language === 'javascript' || language === 'typescript') {
        output = 'undefined (no explicit return)';
      } else {
        output = `Executed ${language} code successfully`;
      }
      return { success: true, output, data: { language, exitCode: 0, stdout: output, stderr: '' } };
    },
  },

  file_write: {
    name: 'file_write',
    description: 'Write content to a file',
    parameters: {
      path: { type: 'string', description: 'File path', required: true },
      content: { type: 'string', description: 'File content', required: true },
    },
    execute: async (args) => {
      await delay(400 + Math.random() * 600);
      const path = String(args.path);
      const size = String(args.content).length;
      return { success: true, output: `Wrote ${size} bytes to ${path}`, data: { path, size, hash: randomUUID().slice(0, 8) } };
    },
  },

  file_read: {
    name: 'file_read',
    description: 'Read content from a file',
    parameters: {
      path: { type: 'string', description: 'File path', required: true },
    },
    execute: async (args) => {
      await delay(300 + Math.random() * 400);
      return { success: true, output: `Read file: ${args.path}`, data: { path: args.path, content: `// contents of ${args.path}\n// this is simulated file content` } };
    },
  },

  shell_exec: {
    name: 'shell_exec',
    description: 'Execute a shell command',
    parameters: {
      command: { type: 'string', description: 'Shell command', required: true },
      cwd: { type: 'string', description: 'Working directory' },
    },
    execute: async (args) => {
      await delay(600 + Math.random() * 1000);
      const cmd = String(args.command);
      return { success: true, output: `$ ${cmd}\nCommand completed successfully`, data: { command: cmd, exitCode: 0, stdout: 'Done', stderr: '' } };
    },
  },

  data_analyze: {
    name: 'data_analyze',
    description: 'Analyze data and produce insights',
    parameters: {
      data: { type: 'string', description: 'Data to analyze', required: true },
      analysis_type: { type: 'string', description: 'Type of analysis' },
    },
    execute: async (args) => {
      await delay(1200 + Math.random() * 1800);
      return {
        success: true,
        output: 'Analysis complete. Found 3 key insights.',
        data: {
          insights: ['Trend shows 23% growth over period', 'Correlation coefficient: 0.87', 'Anomaly detected at index 42'],
          summary: `Analysis of provided data reveals consistent upward trends with strong positive correlations.`,
        },
      };
    },
  },
};

export function createToolCall(name: string, args: Record<string, unknown>): ToolCall {
  return {
    id: `call_${randomUUID().slice(0, 8)}`,
    name,
    arguments: args,
    status: 'pending',
  };
}

export async function executeTool(call: ToolCall): Promise<ToolCall> {
  const tool = tools[call.name];
  if (!tool) {
    return { ...call, status: 'error', error: `Unknown tool: ${call.name}`, completedAt: Date.now() };
  }
  const updated: ToolCall = { ...call, status: 'running', startedAt: Date.now() };
  try {
    const result = await tool.execute(call.arguments);
    return { ...updated, status: 'completed', result, completedAt: Date.now() };
  } catch (err) {
    return { ...updated, status: 'error', error: String(err), completedAt: Date.now() };
  }
}

export function getToolNames(): string[] {
  return Object.keys(tools);
}
