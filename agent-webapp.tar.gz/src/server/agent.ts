import { randomUUID } from 'crypto';
import { store } from './store.js';
import { createToolCall, executeTool, getToolNames } from './tools.js';
import type { AgentEvent, ChatMessage, ToolCall, TaskRun, TaskStep } from '../shared/types.js';

type EventCallback = (event: AgentEvent) => void;

const RESPONSES: Record<string, string[]> = {
  greeting: [
    "Hello! I'm your AI agent. I can search the web, execute code, read and write files, run shell commands, and analyze data. How can I help you today?",
    "Hey there! I have access to several tools including web search, code execution, file operations, and data analysis. What would you like to work on?",
  ],
  search: [
    "I'll search for that information right away. Let me run a web search to find what you need.",
    "Good question! Let me look that up for you using web search.",
  ],
  code: [
    "I'll write and execute that code for you. Let me set it up.",
    "Sure! Let me run that code and show you the output.",
  ],
  file: [
    "I'll handle the file operation for you now.",
    "Let me take care of that file operation.",
  ],
  analysis: [
    "I'll analyze that data thoroughly. Let me process it now.",
    "Great, let me run the analysis on that data.",
  ],
  general: [
    "That's an interesting question. Let me think about this and work through it step by step.",
    "I can help with that. Let me break this down and work through it.",
    "Absolutely, let me tackle that for you. I'll use the appropriate tools to get this done.",
    "Let me work on this systematically. I'll use the right combination of tools to help you.",
  ],
};

function pickRandom(arr: string[]): string {
  return arr[Math.floor(Math.random() * arr.length)];
}

function classifyMessage(msg: string): string {
  const lower = msg.toLowerCase();
  if (/^(hi|hello|hey|greetings)/i.test(lower)) return 'greeting';
  if (/\b(search|find|look up|google|browse)\b/i.test(lower)) return 'search';
  if (/\b(code|script|function|execute|run|program|python|javascript|typescript)\b/i.test(lower)) return 'code';
  if (/\b(file|read|write|create|save|load)\b/i.test(lower)) return 'file';
  if (/\b(analyz|data|stat|chart|graph|insight)\b/i.test(lower)) return 'analysis';
  return 'general';
}

function chooseTools(msg: string): { name: string; args: Record<string, unknown> }[] {
  const lower = msg.toLowerCase();
  const toolCalls: { name: string; args: Record<string, unknown> }[] = [];

  if (/\b(search|find|look up|google|what is|who is|how (to|do|does)|where|when|why)\b/i.test(lower)) {
    toolCalls.push({ name: 'web_search', args: { query: msg, max_results: 5 } });
  }
  if (/\b(write|create|save)\b.*\b(file|document)\b/i.test(lower)) {
    toolCalls.push({ name: 'file_write', args: { path: 'output.txt', content: `Generated content based on: ${msg}` } });
  }
  if (/\b(execute|run)\b.*\b(code|script|program)\b/i.test(lower)) {
    toolCalls.push({ name: 'code_execute', args: { language: 'python', code: 'print("Hello from agent!")' } });
  }
  if (/\b(analyz|insights?|stats?)\b/i.test(lower) && !toolCalls.some((t) => t.name === 'data_analyze')) {
    toolCalls.push({ name: 'data_analyze', args: { data: msg, analysis_type: 'general' } });
  }
  if (/\b(shell|terminal|command|bash)\b/i.test(lower)) {
    toolCalls.push({ name: 'shell_exec', args: { command: 'echo "Agent command executed"' } });
  }

  if (toolCalls.length === 0) {
    const rand = Math.random();
    if (rand < 0.4) {
      toolCalls.push({ name: 'web_search', args: { query: msg } });
    } else if (rand < 0.6) {
      toolCalls.push({ name: 'data_analyze', args: { data: msg } });
    } else if (rand < 0.8) {
      toolCalls.push({ name: 'code_execute', args: { language: 'python', code: `# Analysis for: ${msg}\nprint("Processing...")` } });
    } else {
      toolCalls.push({ name: 'shell_exec', args: { command: `echo "Processing: ${msg.slice(0, 50)}"` } });
    }
  }

  return toolCalls;
}

export class Agent {
  private sessionId: string;
  private emit: EventCallback;

  constructor(sessionId: string, emit: EventCallback) {
    this.sessionId = sessionId;
    this.emit = emit;
  }

  private sendEvent(type: AgentEvent['type'], data: Record<string, unknown>) {
    this.emit({ type, sessionId: this.sessionId, data, timestamp: Date.now() });
  }

  async processMessage(userContent: string): Promise<void> {
    const classification = classifyMessage(userContent);
    const introText = pickRandom(RESPONSES[classification] || RESPONSES.general);

    store.addMessage(this.sessionId, { role: 'user', content: userContent });

    const toolDefs = chooseTools(userContent);
    const toolCalls: ToolCall[] = toolDefs.map((t) => createToolCall(t.name, t.args));

    const assistantMsg = store.addMessage(this.sessionId, {
      role: 'assistant',
      content: '',
      toolCalls: toolCalls.map((tc) => ({ ...tc })),
      metadata: { model: 'agent-v1', duration: 0 },
    });

    this.sendEvent('message.start', { messageId: assistantMsg.id, content: introText });

    let fullContent = introText + '\n\n';
    let tokens = introText.split(/\s+/).length;

    const shouldCreateTask = toolCalls.length >= 2 || Math.random() > 0.4;
    let taskRun: TaskRun | undefined;

    if (shouldCreateTask) {
      taskRun = store.addTaskRun(this.sessionId, {
        title: `Task: ${userContent.slice(0, 50)}`,
        description: `Processing request: ${userContent}`,
        status: 'pending',
        steps: toolCalls.map((tc) => ({
          id: tc.id,
          label: `Run ${tc.name}`,
          status: 'pending' as const,
          toolCall: tc,
        })),
      });
      store.updateTaskRun(this.sessionId, taskRun.id, { status: 'running', startedAt: Date.now() });
      this.sendEvent('task.created', { task: taskRun });
    }

    for (let i = 0; i < toolCalls.length; i++) {
      const call = toolCalls[i];
      store.updateMessageToolCalls(this.sessionId, assistantMsg.id, toolCalls.map((tc) => ({ ...tc })));
      this.sendEvent('tool.call', { messageId: assistantMsg.id, toolCall: { ...call, status: 'running' }, index: i });

      if (taskRun) {
        store.updateTaskStep(this.sessionId, taskRun.id, call.id, { status: 'running', startedAt: Date.now() });
        this.sendEvent('task.step', { taskId: taskRun.id, stepId: call.id, status: 'running' });
      }

      const result = await executeTool(call);
      toolCalls[i] = result;

      const toolDesc = `\n**${result.name}** (${result.status})\n\`\`\`\n${result.result ? (typeof result.result === 'object' ? JSON.stringify(result.result, null, 2).slice(0, 500) : String(result.result)) : result.error || 'completed'}\n\`\`\`\n`;
      fullContent += toolDesc;
      tokens += toolDesc.split(/\s+/).length;

      store.updateMessageToolCalls(this.sessionId, assistantMsg.id, toolCalls.map((tc) => ({ ...tc })));
      this.sendEvent('tool.complete', { messageId: assistantMsg.id, toolCall: { ...result }, index: i });

      if (taskRun) {
        store.updateTaskStep(this.sessionId, taskRun.id, call.id, {
          status: result.status === 'completed' ? 'completed' : 'failed',
          output: typeof result.result === 'object' ? JSON.stringify(result.result) : String(result.result || result.error),
          completedAt: Date.now(),
        });
        this.sendEvent('task.step', { taskId: taskRun.id, stepId: call.id, status: result.status === 'completed' ? 'completed' : 'failed' });
      }

      if (result.name === 'file_write' && result.result && typeof result.result === 'object') {
        const rd = result.result as Record<string, unknown>;
        const artifact = store.addArtifact(this.sessionId, {
          type: 'code',
          name: String(rd.path || 'output.txt'),
          content: String(toolDefs[i].args.content || ''),
          language: 'text',
        });
        this.sendEvent('artifact.created', { artifact });
      }

      if (result.name === 'code_execute' && result.result && typeof result.result === 'object') {
        const rd = result.result as Record<string, unknown>;
        const artifact = store.addArtifact(this.sessionId, {
          type: 'code',
          name: `script_${i + 1}.${String(toolDefs[i].args.language || 'txt')}`,
          content: String(toolDefs[i].args.code || ''),
          language: String(toolDefs[i].args.language || 'text'),
        });
        this.sendEvent('artifact.created', { artifact });
      }
    }

    const conclusionTexts = [
      'I\'ve completed all the requested operations. Let me know if you need anything else!',
      'All done! The results are above. Feel free to ask follow-up questions.',
      'Task finished. Check the results above and let me know if you\'d like me to dig deeper.',
    ];
    fullContent += '\n' + pickRandom(conclusionTexts);
    tokens += conclusionTexts[0].split(/\s+/).length;

    const finalMsg = store.addMessage(this.sessionId, {
      role: 'assistant',
      content: fullContent,
      toolCalls: toolCalls,
      metadata: { model: 'agent-v1', tokens, duration: Date.now() - (assistantMsg.timestamp - 100) },
    });

    const firstAssistant = store.getSession(this.sessionId)?.messages.find((m) => m.id === assistantMsg.id);
    if (firstAssistant) {
      store.updateMessageToolCalls(this.sessionId, assistantMsg.id, toolCalls);
    }

    if (taskRun) {
      store.updateTaskRun(this.sessionId, taskRun.id, {
        status: 'completed',
        completedAt: Date.now(),
        result: 'All steps completed successfully',
      });
      this.sendEvent('task.updated', { task: store.getSession(this.sessionId)?.taskRuns.find((t) => t.id === taskRun!.id) });
    }

    this.sendEvent('message.complete', { messageId: finalMsg.id, content: fullContent });
  }
}

export function getAvailableTools() {
  return getToolNames().map((name) => ({
    name,
    description: tools[name as keyof typeof tools]?.description || '',
  }));
}

import { tools } from './tools.js';
