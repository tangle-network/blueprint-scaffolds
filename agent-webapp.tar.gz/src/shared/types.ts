export type MessageRole = 'user' | 'assistant' | 'system';

export interface ToolCall {
  id: string;
  name: string;
  arguments: Record<string, unknown>;
  status: 'pending' | 'running' | 'completed' | 'error';
  result?: unknown;
  error?: string;
  startedAt?: number;
  completedAt?: number;
}

export interface ChatMessage {
  id: string;
  role: MessageRole;
  content: string;
  toolCalls?: ToolCall[];
  timestamp: number;
  metadata?: {
    model?: string;
    tokens?: number;
    duration?: number;
  };
}

export type SessionStatus = 'active' | 'archived';
export type TaskStatus = 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';
export type TaskStepStatus = 'pending' | 'running' | 'completed' | 'failed';

export interface TaskStep {
  id: string;
  label: string;
  status: TaskStepStatus;
  toolCall?: ToolCall;
  output?: string;
  startedAt?: number;
  completedAt?: number;
}

export interface TaskRun {
  id: string;
  sessionId: string;
  title: string;
  description: string;
  status: TaskStatus;
  steps: TaskStep[];
  createdAt: number;
  startedAt?: number;
  completedAt?: number;
  result?: string;
  error?: string;
}

export interface Artifact {
  id: string;
  sessionId: string;
  type: 'text' | 'code' | 'image' | 'file' | 'html';
  name: string;
  content: string;
  language?: string;
  createdAt: number;
}

export interface Session {
  id: string;
  title: string;
  messages: ChatMessage[];
  artifacts: Artifact[];
  taskRuns: TaskRun[];
  status: SessionStatus;
  createdAt: number;
  updatedAt: number;
}

export interface AgentEvent {
  type:
    | 'session.created'
    | 'session.updated'
    | 'message.start'
    | 'message.delta'
    | 'message.complete'
    | 'tool.call'
    | 'tool.delta'
    | 'tool.complete'
    | 'task.created'
    | 'task.updated'
    | 'task.step'
    | 'artifact.created'
    | 'error';
  sessionId: string;
  data: Record<string, unknown>;
  timestamp: number;
}

export interface AgentConfig {
  model: string;
  temperature: number;
  maxTokens: number;
  systemPrompt: string;
}
