import type { Session, Message, TaskRun, WorkspaceFile, ToolCall } from "./types";
import { v4 as uuid } from "uuid";

const now = new Date().toISOString();

export function makeToolCall(overrides: Partial<ToolCall> = {}): ToolCall {
  return {
    id: uuid(),
    name: "read_file",
    arguments: { path: "/src/index.ts" },
    status: "completed",
    result: "// file contents here\nexport default main;",
    duration_ms: 234,
    ...overrides,
  };
}

export const mockSessions: Session[] = [
  {
    id: "sess-1",
    title: "Build authentication system",
    created_at: new Date(Date.now() - 86400000).toISOString(),
    updated_at: new Date(Date.now() - 3600000).toISOString(),
    message_count: 12,
  },
  {
    id: "sess-2",
    title: "Debug API routing issue",
    created_at: new Date(Date.now() - 172800000).toISOString(),
    updated_at: new Date(Date.now() - 86400000).toISOString(),
    message_count: 8,
  },
  {
    id: "sess-3",
    title: "Design database schema",
    created_at: new Date(Date.now() - 259200000).toISOString(),
    updated_at: new Date(Date.now() - 172800000).toISOString(),
    message_count: 15,
  },
  {
    id: "sess-4",
    title: "Write unit tests",
    created_at: new Date(Date.now() - 345600000).toISOString(),
    updated_at: new Date(Date.now() - 259200000).toISOString(),
    message_count: 6,
  },
];

export const mockMessages: Message[] = [
  {
    id: "msg-1",
    session_id: "sess-1",
    role: "user",
    content: "Can you build an authentication system with JWT tokens?",
    created_at: new Date(Date.now() - 7200000).toISOString(),
  },
  {
    id: "msg-2",
    session_id: "sess-1",
    role: "assistant",
    content:
      "I'll build a complete JWT authentication system. Let me start by examining the project structure and then implement the necessary files.",
    tool_calls: [
      makeToolCall({
        id: "tc-1",
        name: "list_files",
        arguments: { directory: "/src" },
        status: "completed",
        result: "src/\n  index.ts\n  auth/\n  middleware/\n  utils/",
        duration_ms: 120,
      }),
      makeToolCall({
        id: "tc-2",
        name: "read_file",
        arguments: { path: "/src/index.ts" },
        status: "completed",
        result: 'import express from "express";\nconst app = express();\napp.listen(3000);',
        duration_ms: 89,
      }),
      makeToolCall({
        id: "tc-3",
        name: "write_file",
        arguments: { path: "/src/auth/jwt.ts", content: "..." },
        status: "completed",
        result: "File written successfully",
        duration_ms: 156,
      }),
    ],
    artifacts: [
      {
        id: "art-1",
        type: "code",
        name: "jwt.ts",
        content: `import jwt from "jsonwebtoken";

const SECRET = process.env.JWT_SECRET || "dev-secret";

export function signToken(payload: object): string {
  return jwt.sign(payload, SECRET, { expiresIn: "24h" });
}

export function verifyToken(token: string): object | null {
  try {
    return jwt.verify(token, SECRET) as object;
  } catch {
    return null;
  }
}`,
        language: "typescript",
      },
    ],
    created_at: new Date(Date.now() - 7100000).toISOString(),
  },
  {
    id: "msg-3",
    session_id: "sess-1",
    role: "user",
    content: "Great, now add login and register endpoints.",
    created_at: new Date(Date.now() - 7000000).toISOString(),
  },
  {
    id: "msg-4",
    session_id: "sess-1",
    role: "assistant",
    content:
      "Here are the login and register endpoints with proper validation and error handling.",
    tool_calls: [
      makeToolCall({
        id: "tc-4",
        name: "write_file",
        arguments: { path: "/src/auth/routes.ts", content: "..." },
        status: "completed",
        result: "File written successfully",
        duration_ms: 210,
      }),
    ],
    artifacts: [
      {
        id: "art-2",
        type: "code",
        name: "routes.ts",
        content: `import { Router } from "express";
import { signToken } from "./jwt";
import bcrypt from "bcrypt";

const router = Router();

router.post("/register", async (req, res) => {
  const { email, password } = req.body;
  const hash = await bcrypt.hash(password, 10);
  const user = await createUser({ email, password: hash });
  const token = signToken({ id: user.id, email });
  res.json({ token, user: { id: user.id, email } });
});

router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  const user = await findByEmail(email);
  if (!user || !(await bcrypt.compare(password, user.password))) {
    return res.status(401).json({ error: "Invalid credentials" });
  }
  const token = signToken({ id: user.id, email });
  res.json({ token, user: { id: user.id, email } });
});

export default router;`,
        language: "typescript",
      },
    ],
    created_at: new Date(Date.now() - 6900000).toISOString(),
  },
];

export const mockTasks: TaskRun[] = [
  {
    id: "task-1",
    title: "Build REST API endpoints",
    status: "completed",
    progress: 100,
    created_at: new Date(Date.now() - 7200000).toISOString(),
    completed_at: new Date(Date.now() - 3600000).toISOString(),
    output: "Successfully created 8 API endpoints with full CRUD operations.",
    steps: [
      {
        id: "step-1",
        title: "Analyze existing codebase structure",
        status: "completed",
        tool_calls: [
          makeToolCall({ name: "list_files", arguments: { path: "/src" } }),
        ],
        output: "Found 12 source files across 4 directories.",
      },
      {
        id: "step-2",
        title: "Design API schema",
        status: "completed",
        output: "Defined 8 endpoints covering users, posts, and comments.",
      },
      {
        id: "step-3",
        title: "Implement route handlers",
        status: "completed",
        tool_calls: [
          makeToolCall({ name: "write_file", arguments: { path: "/src/routes/users.ts" } }),
          makeToolCall({ name: "write_file", arguments: { path: "/src/routes/posts.ts" } }),
          makeToolCall({ name: "write_file", arguments: { path: "/src/routes/comments.ts" } }),
        ],
        output: "Created 3 route files with 8 endpoints total.",
      },
      {
        id: "step-4",
        title: "Add validation middleware",
        status: "completed",
        output: "Added input validation to all POST/PUT endpoints.",
      },
    ],
  },
  {
    id: "task-2",
    title: "Write comprehensive test suite",
    status: "running",
    progress: 65,
    created_at: new Date(Date.now() - 1800000).toISOString(),
    steps: [
      {
        id: "step-5",
        title: "Set up test framework",
        status: "completed",
        output: "Configured Jest with TypeScript support.",
      },
      {
        id: "step-6",
        title: "Write unit tests for auth module",
        status: "completed",
        tool_calls: [
          makeToolCall({ name: "write_file", arguments: { path: "/tests/auth.test.ts" } }),
        ],
        output: "Created 12 test cases covering JWT and auth routes.",
      },
      {
        id: "step-7",
        title: "Write integration tests for API",
        status: "running",
        tool_calls: [
          makeToolCall({
            name: "write_file",
            status: "running",
            arguments: { path: "/tests/api.test.ts" },
            result: undefined,
          }),
        ],
      },
      {
        id: "step-8",
        title: "Generate coverage report",
        status: "pending",
      },
    ],
  },
  {
    id: "task-3",
    title: "Deploy to staging environment",
    status: "pending",
    progress: 0,
    created_at: new Date(Date.now() - 600000).toISOString(),
    steps: [
      {
        id: "step-9",
        title: "Build Docker image",
        status: "pending",
      },
      {
        id: "step-10",
        title: "Push to container registry",
        status: "pending",
      },
      {
        id: "step-11",
        title: "Update Kubernetes manifests",
        status: "pending",
      },
      {
        id: "step-12",
        title: "Deploy and verify",
        status: "pending",
      },
    ],
  },
  {
    id: "task-4",
    title: "Migrate database schema",
    status: "failed",
    progress: 40,
    created_at: new Date(Date.now() - 3600000).toISOString(),
    error: "Migration failed: column 'metadata' already exists in table 'users'",
    steps: [
      {
        id: "step-13",
        title: "Backup current database",
        status: "completed",
        output: "Backup created: db_backup_20240115.sql",
      },
      {
        id: "step-14",
        title: "Run migration scripts",
        status: "failed",
        error: "Migration failed: column 'metadata' already exists in table 'users'",
      },
      {
        id: "step-15",
        title: "Verify data integrity",
        status: "pending",
      },
    ],
  },
];

export const mockWorkspaceFiles: WorkspaceFile[] = [
  {
    id: "f-1",
    name: "src",
    path: "/src",
    type: "directory",
    size: 0,
    modified_at: now,
    children: [
      {
        id: "f-2",
        name: "index.ts",
        path: "/src/index.ts",
        type: "file",
        content: `import express from "express";\nimport cors from "cors";\nimport authRoutes from "./auth/routes";\n\nconst app = express();\napp.use(cors());\napp.use(express.json());\n\napp.use("/auth", authRoutes);\napp.get("/health", (req, res) => res.json({ status: "ok" }));\n\napp.listen(3000, () => console.log("Server running on port 3000"));`,
        language: "typescript",
        size: 312,
        modified_at: now,
      },
      {
        id: "f-3",
        name: "auth",
        path: "/src/auth",
        type: "directory",
        size: 0,
        modified_at: now,
        children: [
          {
            id: "f-4",
            name: "jwt.ts",
            path: "/src/auth/jwt.ts",
            type: "file",
            content: `import jwt from "jsonwebtoken";\n\nconst SECRET = process.env.JWT_SECRET || "dev-secret";\n\nexport function signToken(payload: object): string {\n  return jwt.sign(payload, SECRET, { expiresIn: "24h" });\n}\n\nexport function verifyToken(token: string): object | null {\n  try {\n    return jwt.verify(token, SECRET) as object;\n  } catch {\n    return null;\n  }\n}`,
            language: "typescript",
            size: 285,
            modified_at: now,
          },
          {
            id: "f-5",
            name: "routes.ts",
            path: "/src/auth/routes.ts",
            type: "file",
            content: `import { Router } from "express";\nimport { signToken } from "./jwt";\n\nconst router = Router();\n\nrouter.post("/register", async (req, res) => {\n  const { email, password } = req.body;\n  res.json({ message: "User registered" });\n});\n\nrouter.post("/login", async (req, res) => {\n  const { email, password } = req.body;\n  const token = signToken({ email });\n  res.json({ token });\n});\n\nexport default router;`,
            language: "typescript",
            size: 410,
            modified_at: now,
          },
        ],
      },
    ],
  },
  {
    id: "f-6",
    name: "package.json",
    path: "/package.json",
    type: "file",
    content: `{\n  "name": "my-app",\n  "version": "1.0.0",\n  "scripts": {\n    "dev": "tsx watch src/index.ts",\n    "build": "tsc",\n    "start": "node dist/index.js"\n  }\n}`,
    language: "json",
    size: 180,
    modified_at: now,
  },
  {
    id: "f-7",
    name: "tsconfig.json",
    path: "/tsconfig.json",
    type: "file",
    content: `{\n  "compilerOptions": {\n    "target": "ES2022",\n    "module": "ESNext",\n    "moduleResolution": "bundler",\n    "strict": true\n  }\n}`,
    language: "json",
    size: 145,
    modified_at: now,
  },
];

export const mockStreamEvents = [
  { type: "message", data: { role: "assistant", content: "Let me analyze your request and get started." } },
  { type: "tool_call", data: { id: "tc-stream-1", name: "read_file", arguments: { path: "/src/index.ts" }, status: "running" } },
  { type: "tool_result", data: { id: "tc-stream-1", result: "file contents...", status: "completed", duration_ms: 145 } },
  { type: "tool_call", data: { id: "tc-stream-2", name: "write_file", arguments: { path: "/src/output.ts", content: "export const result = 42;" }, status: "running" } },
  { type: "tool_result", data: { id: "tc-stream-2", result: "File written successfully", status: "completed", duration_ms: 98 } },
  { type: "artifact", data: { id: "art-s-1", type: "code", name: "output.ts", content: "export const result = 42;", language: "typescript" } },
  { type: "message", data: { role: "assistant", content: "I've analyzed the codebase and made the necessary changes. The new output module is ready." } },
  { type: "done", data: null },
];
