import { create } from "zustand";
import type { Session, Message, TaskRun, WorkspaceFile } from "./types";
import { mockSessions, mockMessages, mockTasks, mockWorkspaceFiles, mockStreamEvents } from "./mock-data";
import { v4 as uuid } from "uuid";

interface SessionStore {
  sessions: Session[];
  currentSessionId: string | null;
  messages: Message[];
  isStreaming: boolean;
  loadSessions: () => void;
  createSession: (title?: string) => string;
  selectSession: (id: string) => void;
  deleteSession: (id: string) => void;
  sendMessage: (content: string) => void;
  setIsStreaming: (v: boolean) => void;
}

export const useSessionStore = create<SessionStore>((set, get) => ({
  sessions: [],
  currentSessionId: null,
  messages: [],
  isStreaming: false,

  loadSessions: () => {
    set({ sessions: mockSessions });
  },

  createSession: (title?: string) => {
    const id = uuid();
    const session: Session = {
      id,
      title: title || "New Chat",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      message_count: 0,
    };
    set((s) => ({
      sessions: [session, ...s.sessions],
      currentSessionId: id,
      messages: [],
    }));
    return id;
  },

  selectSession: (id: string) => {
    if (id === "sess-1") {
      set({ currentSessionId: id, messages: mockMessages });
    } else {
      const msgs = mockMessages.map((m) => ({ ...m, session_id: id }));
      set({ currentSessionId: id, messages: msgs.length > 0 ? [msgs[0]] : [] });
    }
  },

  deleteSession: (id: string) => {
    set((s) => ({
      sessions: s.sessions.filter((sess) => sess.id !== id),
      currentSessionId: s.currentSessionId === id ? null : s.currentSessionId,
      messages: s.currentSessionId === id ? [] : s.messages,
    }));
  },

  sendMessage: (content: string) => {
    const state = get();
    const userMsg: Message = {
      id: uuid(),
      session_id: state.currentSessionId || "unknown",
      role: "user",
      content,
      created_at: new Date().toISOString(),
    };
    set({ messages: [...state.messages, userMsg], isStreaming: true });

    setTimeout(() => {
      const assistantMsg: Message = {
        id: uuid(),
        session_id: state.currentSessionId || "unknown",
        role: "assistant",
        content: "",
        tool_calls: [],
        created_at: new Date().toISOString(),
      };
      set((s) => ({ messages: [...s.messages, assistantMsg] }));

      let eventIdx = 0;
      const interval = setInterval(() => {
        const s = get();
        if (eventIdx >= mockStreamEvents.length) {
          clearInterval(interval);
          set({ isStreaming: false });
          return;
        }
        const event = mockStreamEvents[eventIdx];
        const msgs = [...s.messages];
        const last = msgs[msgs.length - 1];

        if (event.type === "message" && (event.data as { role: string }).role === "assistant") {
          last.content += (last.content ? " " : "") + (event.data as { content: string }).content;
        } else if (event.type === "tool_call") {
          if (!last.tool_calls) last.tool_calls = [];
          last.tool_calls.push(event.data as Message["tool_calls"]![0]);
        } else if (event.type === "tool_result") {
          const tc = last.tool_calls?.find((t) => t.id === (event.data as { id: string }).id);
          if (tc) {
            tc.status = "completed";
            tc.result = (event.data as { result: string }).result;
            tc.duration_ms = (event.data as { duration_ms: number }).duration_ms;
          }
        } else if (event.type === "artifact") {
          if (!last.artifacts) last.artifacts = [];
          last.artifacts.push(event.data as Message["artifacts"]![0]);
        } else if (event.type === "done") {
          clearInterval(interval);
          set({ isStreaming: false, messages: msgs });
          return;
        }

        msgs[msgs.length - 1] = { ...last };
        set({ messages: msgs });
        eventIdx++;
      }, 600);
    }, 400);
  },

  setIsStreaming: (v) => set({ isStreaming: v }),
}));

interface TaskStore {
  tasks: TaskRun[];
  loadTasks: () => void;
  createTask: (title: string, description: string) => void;
  cancelTask: (id: string) => void;
}

export const useTaskStore = create<TaskStore>((set) => ({
  tasks: [],

  loadTasks: () => {
    set({ tasks: mockTasks });
  },

  createTask: (title: string) => {
    const task: TaskRun = {
      id: uuid(),
      title,
      status: "running",
      progress: 0,
      steps: [
        { id: uuid(), title: "Initializing task...", status: "running" },
        { id: uuid(), title: "Planning execution", status: "pending" },
        { id: uuid(), title: "Executing steps", status: "pending" },
      ],
      created_at: new Date().toISOString(),
    };
    set((s) => ({ tasks: [task, ...s.tasks] }));
  },

  cancelTask: (id: string) => {
    set((s) => ({
      tasks: s.tasks.map((t) =>
        t.id === id ? { ...t, status: "cancelled" as const } : t
      ),
    }));
  },
}));

interface WorkspaceStore {
  files: WorkspaceFile[];
  selectedFile: WorkspaceFile | null;
  loadFiles: () => void;
  selectFile: (file: WorkspaceFile | null) => void;
}

export const useWorkspaceStore = create<WorkspaceStore>((set) => ({
  files: [],
  selectedFile: null,

  loadFiles: () => {
    set({ files: mockWorkspaceFiles });
  },

  selectFile: (file) => {
    set({ selectedFile: file });
  },
}));
