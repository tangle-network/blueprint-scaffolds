import type { Session, Message, TaskRun, WorkspaceFile, ChatRequest, TaskRequest, SSEEvent } from "./types";

const BASE = "/api";

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(err || `Request failed: ${res.status}`);
  }
  return res.json();
}

export const api = {
  sessions: {
    list: () => request<Session[]>("/sessions"),
    get: (id: string) => request<Session>(`/sessions/${id}`),
    create: (title?: string) =>
      request<Session>("/sessions", {
        method: "POST",
        body: JSON.stringify({ title: title || "New Chat" }),
      }),
    delete: (id: string) =>
      request<void>(`/sessions/${id}`, { method: "DELETE" }),
    messages: (id: string) => request<Message[]>(`/sessions/${id}/messages`),
  },

  chat: {
    send: (req: ChatRequest) =>
      request<Message>("/chat", {
        method: "POST",
        body: JSON.stringify(req),
      }),
    stream: (req: ChatRequest, onEvent: (event: SSEEvent) => void) => {
      const controller = new AbortController();
      fetch(`${BASE}/chat/stream`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(req),
        signal: controller.signal,
      }).then(async (res) => {
        const reader = res.body?.getReader();
        if (!reader) return;
        const decoder = new TextDecoder();
        let buffer = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() || "";
          for (const line of lines) {
            if (line.startsWith("data: ")) {
              try {
                const event: SSEEvent = JSON.parse(line.slice(6));
                onEvent(event);
              } catch {}
            }
          }
        }
        onEvent({ type: "done", data: null });
      });
      return () => controller.abort();
    },
  },

  tasks: {
    list: () => request<TaskRun[]>("/tasks"),
    get: (id: string) => request<TaskRun>(`/tasks/${id}`),
    create: (req: TaskRequest) =>
      request<TaskRun>("/tasks", {
        method: "POST",
        body: JSON.stringify(req),
      }),
    cancel: (id: string) =>
      request<void>(`/tasks/${id}/cancel`, { method: "POST" }),
  },

  workspace: {
    files: () => request<WorkspaceFile[]>("/workspace/files"),
    file: (path: string) => request<WorkspaceFile>(`/workspace/files/${encodeURIComponent(path)}`),
  },
};
