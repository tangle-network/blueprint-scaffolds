export interface Session {
  id: string;
  title: string;
  created_at: string;
  updated_at: string;
  message_count: number;
}

export interface Message {
  id: string;
  session_id: string;
  role: "user" | "assistant" | "system";
  content: string;
  tool_calls?: ToolCall[];
  artifacts?: Artifact[];
  created_at: string;
}

export interface ToolCall {
  id: string;
  name: string;
  arguments: Record<string, unknown>;
  result?: string;
  status: "pending" | "running" | "completed" | "error";
  started_at?: string;
  completed_at?: string;
  duration_ms?: number;
}

export interface Artifact {
  id: string;
  type: "file" | "image" | "code" | "html" | "markdown";
  name: string;
  content: string;
  language?: string;
}

export interface TaskRun {
  id: string;
  title: string;
  status: "pending" | "running" | "completed" | "failed" | "cancelled";
  progress: number;
  steps: TaskStep[];
  created_at: string;
  completed_at?: string;
  output?: string;
  error?: string;
}

export interface TaskStep {
  id: string;
  title: string;
  status: "pending" | "running" | "completed" | "failed" | "skipped";
  tool_calls?: ToolCall[];
  output?: string;
  error?: string;
}

export interface WorkspaceFile {
  id: string;
  name: string;
  path: string;
  type: "file" | "directory";
  content?: string;
  language?: string;
  size: number;
  modified_at: string;
  children?: WorkspaceFile[];
}

export interface SSEEvent {
  type: "message" | "tool_call" | "tool_result" | "task_update" | "artifact" | "done" | "error";
  data: unknown;
}

export interface ChatRequest {
  message: string;
  session_id?: string;
}

export interface TaskRequest {
  title: string;
  description: string;
}
