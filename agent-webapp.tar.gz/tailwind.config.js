/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/client/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: {
          primary: '#0a0a0f',
          secondary: '#12121a',
          tertiary: '#1a1a2e',
          hover: '#22223a',
        },
        accent: {
          DEFAULT: '#6c5ce7',
          hover: '#7f70f0',
          muted: '#4a3db5',
        },
        success: '#00b894',
        warning: '#fdcb6e',
        danger: '#e17055',
        text: {
          primary: '#e8e8f0',
          secondary: '#9898b0',
          muted: '#5a5a7a',
        },
        border: {
          DEFAULT: '#2a2a40',
          hover: '#3a3a55',
        },
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'fade-in': 'fadeIn 0.3s ease-out',
        'slide-up': 'slideUp 0.3s ease-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
    },
  },
  plugins: [],
};
