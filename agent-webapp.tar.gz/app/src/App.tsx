import { BrowserRouter, Routes, Route } from "react-router-dom"
import { AppShell } from "@/components/AppShell"
import DashboardPage from "@/pages/DashboardPage"
import ChatPage from "@/pages/ChatPage"
import TasksPage from "@/pages/TasksPage"
import WorkspacePage from "@/pages/WorkspacePage"
import ProjectsPage from "@/pages/ProjectsPage"
import AnalyticsPage from "@/pages/AnalyticsPage"
import SettingsPage from "@/pages/SettingsPage"

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<AppShell />}>
          <Route index element={<DashboardPage />} />
          <Route path="chat" element={<ChatPage />} />
          <Route path="tasks" element={<TasksPage />} />
          <Route path="workspace" element={<WorkspacePage />} />
          <Route path="projects" element={<ProjectsPage />} />
          <Route path="analytics" element={<AnalyticsPage />} />
          <Route path="settings" element={<SettingsPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}
