import type { WorkspaceFile } from "@/lib/types"
import { FileCode2, Copy } from "lucide-react"
import { useState } from "react"
import { Button } from "@/components/ui/button"

interface FileViewerProps {
  file: WorkspaceFile
}

export function FileViewer({ file }: FileViewerProps) {
  const [copied, setCopied] = useState(false)

  if (!file.content) {
    return (
      <div className="flex h-full items-center justify-center text-muted-foreground">
        <p className="text-sm">No file selected</p>
      </div>
    )
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(file.content || "")
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between border-b px-4 py-2">
        <div className="flex items-center gap-2">
          <FileCode2 className="h-4 w-4 text-primary" />
          <span className="text-sm font-medium">{file.path}</span>
          {file.language && (
            <span className="rounded bg-muted px-1.5 py-0.5 text-[10px] text-muted-foreground">
              {file.language}
            </span>
          )}
        </div>
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={handleCopy}>
          <Copy className={copied ? "text-green-500 h-3.5 w-3.5" : "h-3.5 w-3.5"} />
        </Button>
      </div>
      <div className="flex-1 overflow-auto">
        <pre className="p-4 text-xs leading-relaxed">
          <code>{file.content}</code>
        </pre>
      </div>
    </div>
  )
}
