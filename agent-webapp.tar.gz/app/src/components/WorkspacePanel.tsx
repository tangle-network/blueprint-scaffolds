import { useEffect } from "react"
import { useWorkspaceStore } from "@/lib/stores"
import { FileTree } from "@/components/FileTree"
import { FileViewer } from "@/components/FileViewer"
import { FolderTree } from "lucide-react"

export function WorkspacePanel() {
  const { files, selectedFile, loadFiles, selectFile } = useWorkspaceStore()

  useEffect(() => {
    if (files.length === 0) loadFiles()
  }, [files.length, loadFiles])

  return (
    <div className="flex h-full">
      <div className="w-60 shrink-0 border-r flex flex-col">
        <div className="flex items-center gap-2 border-b px-4 py-3">
          <FolderTree className="h-4 w-4" />
          <h2 className="text-sm font-semibold">Files</h2>
        </div>
        <div className="flex-1 overflow-auto">
          <FileTree
            files={files}
            selectedPath={selectedFile?.path ?? null}
            onSelect={selectFile}
          />
        </div>
      </div>
      <div className="flex-1">
        {selectedFile ? (
          <FileViewer file={selectedFile} />
        ) : (
          <div className="flex h-full items-center justify-center text-muted-foreground">
            <p className="text-sm">Select a file to preview</p>
          </div>
        )}
      </div>
    </div>
  )
}
