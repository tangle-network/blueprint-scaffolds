import { Outlet, NavLink, useLocation } from "react-router-dom"
import { cn } from "@/lib/utils"
import { Bot, LayoutDashboard, FolderKanban, BarChart3, Settings, MessageSquare, ListTodo, FolderTree } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip"
import { useState } from "react"

const navItems = [
  { to: "/", icon: LayoutDashboard, label: "Dashboard" },
  { to: "/chat", icon: MessageSquare, label: "Chat" },
  { to: "/tasks", icon: ListTodo, label: "Tasks" },
  { to: "/workspace", icon: FolderTree, label: "Workspace" },
  { to: "/projects", icon: FolderKanban, label: "Projects" },
  { to: "/analytics", icon: BarChart3, label: "Analytics" },
  { to: "/settings", icon: Settings, label: "Settings" },
]

export function AppShell() {
  const [collapsed, setCollapsed] = useState(false)
  const location = useLocation()

  return (
    <TooltipProvider delayDuration={0}>
      <div className="flex h-screen overflow-hidden bg-background">
        <div
          className={cn(
            "flex h-full flex-col border-r bg-card transition-all duration-200",
            collapsed ? "w-14" : "w-56"
          )}
        >
          <div className={cn("flex items-center border-b px-3 py-3", collapsed ? "justify-center" : "gap-2")}>
            <Bot className="h-5 w-5 shrink-0 text-primary" />
            {!collapsed && <span className="text-sm font-bold">AI Agent</span>}
            <Button
              variant="ghost"
              size="icon"
              className={cn("ml-auto h-7 w-7 shrink-0", collapsed && "ml-0")}
              onClick={() => setCollapsed(!collapsed)}
            >
              <span className="text-xs text-muted-foreground">{collapsed ? "»" : "«"}</span>
            </Button>
          </div>
          <nav className="flex-1 space-y-1 p-2">
            {navItems.map((item) => {
              const Icon = item.icon
              const isActive =
                item.to === "/"
                  ? location.pathname === "/"
                  : location.pathname.startsWith(item.to)
              const link = (
                <NavLink
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors hover:bg-accent",
                    isActive && "bg-accent font-medium",
                    collapsed && "justify-center px-0"
                  )}
                >
                  <Icon className={cn("h-4 w-4 shrink-0", isActive && "text-primary")} />
                  {!collapsed && <span>{item.label}</span>}
                </NavLink>
              )
              if (collapsed) {
                return (
                  <Tooltip key={item.to}>
                    <TooltipTrigger asChild>{link}</TooltipTrigger>
                    <TooltipContent side="right">{item.label}</TooltipContent>
                  </Tooltip>
                )
              }
              return link
            })}
          </nav>
          <div className={cn("border-t p-3 text-center", collapsed && "px-1")}>
            <div className={cn("text-[10px] text-muted-foreground", collapsed && "text-[8px]")}>
              {collapsed ? "v1" : "Agent v1.0.0"}
            </div>
          </div>
        </div>
        <main className="flex-1 min-w-0 overflow-hidden">
          <Outlet />
        </main>
      </div>
    </TooltipProvider>
  )
}
