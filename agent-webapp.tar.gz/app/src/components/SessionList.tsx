import { useEffect } from "react"
import { useSessionStore } from "@/lib/stores"
import { SessionItem } from "@/components/SessionItem"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { Plus, History } from "lucide-react"

export function SessionList() {
  const { sessions, currentSessionId, loadSessions, createSession, selectSession, deleteSession } = useSessionStore()

  useEffect(() => {
    if (sessions.length === 0) loadSessions()
  }, [sessions.length, loadSessions])

  return (
    <div className="flex h-full flex-col">
      <div className="p-3">
        <Button
          variant="outline"
          className="w-full justify-start gap-2"
          size="sm"
          onClick={() => createSession()}
        >
          <Plus className="h-4 w-4" />
          New Chat
        </Button>
      </div>
      <Separator />
      <div className="flex items-center gap-2 px-3 py-2">
        <History className="h-3.5 w-3.5 text-muted-foreground" />
        <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
          History
        </span>
      </div>
      <ScrollArea className="flex-1">
        <div className="space-y-0.5 px-2 pb-2">
          {sessions.map((session) => (
            <SessionItem
              key={session.id}
              session={session}
              isActive={session.id === currentSessionId}
              onSelect={() => selectSession(session.id)}
              onDelete={() => deleteSession(session.id)}
            />
          ))}
        </div>
      </ScrollArea>
    </div>
  )
}
