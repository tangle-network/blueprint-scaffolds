import type { WorkspaceFile } from "@/lib/types"
import { cn } from "@/lib/utils"
import { useState } from "react"
import { ChevronDown, ChevronRight, File, Folder, FolderOpen } from "lucide-react"

interface FileTreeProps {
  files: WorkspaceFile[]
  selectedPath: string | null
  onSelect: (file: WorkspaceFile) => void
}

export function FileTree({ files, selectedPath, onSelect }: FileTreeProps) {
  return (
    <div className="py-1">
      {files.map((file) => (
        <FileTreeNode
          key={file.id}
          file={file}
          depth={0}
          selectedPath={selectedPath}
          onSelect={onSelect}
        />
      ))}
    </div>
  )
}

function FileTreeNode({
  file,
  depth,
  selectedPath,
  onSelect,
}: {
  file: WorkspaceFile
  depth: number
  selectedPath: string | null
  onSelect: (file: WorkspaceFile) => void
}) {
  const [expanded, setExpanded] = useState(depth < 1)
  const isDir = file.type === "directory"
  const isSelected = file.path === selectedPath

  return (
    <div>
      <button
        onClick={() => {
          if (isDir) setExpanded(!expanded)
          else onSelect(file)
        }}
        className={cn(
          "flex w-full items-center gap-1.5 rounded-sm px-2 py-1 text-sm hover:bg-accent",
          isSelected && "bg-accent",
        )}
        style={{ paddingLeft: `${depth * 12 + 8}px` }}
      >
        {isDir ? (
          <>
            {expanded ? (
              <ChevronDown className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
            ) : (
              <ChevronRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
            )}
            {expanded ? (
              <FolderOpen className="h-4 w-4 shrink-0 text-primary" />
            ) : (
              <Folder className="h-4 w-4 shrink-0 text-primary" />
            )}
          </>
        ) : (
          <>
            <span className="w-3.5" />
            <File className="h-4 w-4 shrink-0 text-muted-foreground" />
          </>
        )}
        <span className="truncate">{file.name}</span>
        {!isDir && file.size > 0 && (
          <span className="ml-auto text-[10px] text-muted-foreground">
            {file.size > 1024 ? `${(file.size / 1024).toFixed(1)}k` : `${file.size}b`}
          </span>
        )}
      </button>
      {isDir && expanded && file.children && (
        <div>
          {file.children.map((child) => (
            <FileTreeNode
              key={child.id}
              file={child}
              depth={depth + 1}
              selectedPath={selectedPath}
              onSelect={onSelect}
            />
          ))}
        </div>
      )}
    </div>
  )
}
