import type { TaskRun } from "@/lib/types"
import { cn } from "@/lib/utils"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { TaskStepRow } from "@/components/TaskStepRow"
import { ChevronDown, ChevronRight, XCircle, Clock, CheckCircle2, Loader2, Ban } from "lucide-react"
import { useState } from "react"

interface TaskCardProps {
  task: TaskRun
  onCancel?: (id: string) => void
}

const statusBadge = {
  pending: { variant: "secondary" as const, icon: Clock, label: "Pending" },
  running: { variant: "default" as const, icon: Loader2, label: "Running" },
  completed: { variant: "secondary" as const, icon: CheckCircle2, label: "Completed" },
  failed: { variant: "destructive" as const, icon: XCircle, label: "Failed" },
  cancelled: { variant: "outline" as const, icon: Ban, label: "Cancelled" },
}

export function TaskCard({ task, onCancel }: TaskCardProps) {
  const [expanded, setExpanded] = useState(task.status === "running" || task.status === "failed")
  const cfg = statusBadge[task.status]
  const Icon = cfg.icon

  return (
    <Card>
      <CardHeader className="p-4 pb-2">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <button onClick={() => setExpanded(!expanded)} className="shrink-0">
              {expanded ? (
                <ChevronDown className="h-4 w-4 text-muted-foreground" />
              ) : (
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              )}
            </button>
            <CardTitle className="text-sm font-medium truncate">{task.title}</CardTitle>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {task.status === "running" && onCancel && (
              <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => onCancel(task.id)}>
                Cancel
              </Button>
            )}
            <Badge variant={cfg.variant} className="text-[10px] px-1.5 py-0">
              <Icon className={cn("mr-1 h-3 w-3", task.status === "running" && "animate-spin")} />
              {cfg.label}
            </Badge>
          </div>
        </div>
        <div className="mt-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
            <span>Progress</span>
            <span>{task.progress}%</span>
          </div>
          <Progress value={task.progress} className="h-1.5" />
        </div>
      </CardHeader>
      {expanded && (
        <CardContent className="px-4 pb-4 pt-0">
          <div className="divide-y">
            {task.steps.map((step) => (
              <TaskStepRow key={step.id} step={step} />
            ))}
          </div>
          {task.output && (
            <div className="mt-3 rounded-md bg-muted p-3 text-xs">{task.output}</div>
          )}
          {task.error && (
            <div className="mt-3 rounded-md bg-destructive/10 p-3 text-xs text-destructive">{task.error}</div>
          )}
        </CardContent>
      )}
    </Card>
  )
}
