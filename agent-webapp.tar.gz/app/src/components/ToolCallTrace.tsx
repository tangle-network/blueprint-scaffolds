import { useState } from "react"
import type { ToolCall } from "@/lib/types"
import { Badge } from "@/components/ui/badge"
import { ChevronDown, ChevronRight, Wrench, Loader2, CheckCircle2, XCircle, Clock } from "lucide-react"
import { cn } from "@/lib/utils"

interface ToolCallTraceProps {
  toolCall: ToolCall
}

const statusConfig = {
  pending: { icon: Clock, color: "text-muted-foreground", badge: "secondary" as const },
  running: { icon: Loader2, color: "text-blue-500", badge: "default" as const },
  completed: { icon: CheckCircle2, color: "text-green-500", badge: "secondary" as const },
  error: { icon: XCircle, color: "text-destructive", badge: "destructive" as const },
}

export function ToolCallTrace({ toolCall }: ToolCallTraceProps) {
  const [expanded, setExpanded] = useState(false)
  const cfg = statusConfig[toolCall.status]
  const Icon = cfg.icon

  return (
    <div className="tool-call-enter my-1.5 rounded-md border bg-muted/30">
      <button
        onClick={() => setExpanded(!expanded)}
        className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm hover:bg-muted/50"
      >
        {expanded ? (
          <ChevronDown className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
        ) : (
          <ChevronRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
        )}
        <Wrench className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
        <span className="font-mono text-xs font-medium">{toolCall.name}</span>
        {toolCall.duration_ms && (
          <span className="text-xs text-muted-foreground">{toolCall.duration_ms}ms</span>
        )}
        <Badge variant={cfg.badge} className="ml-auto text-[10px] px-1.5 py-0">
          <Icon className={cn("mr-1 h-3 w-3", cfg.color, toolCall.status === "running" && "animate-spin")} />
          {toolCall.status}
        </Badge>
      </button>
      {expanded && (
        <div className="border-t px-3 py-2 text-xs">
          <div className="mb-2">
            <span className="font-medium text-muted-foreground">Arguments:</span>
            <pre className="mt-1 overflow-x-auto rounded bg-muted p-2 text-[11px]">
              {JSON.stringify(toolCall.arguments, null, 2)}
            </pre>
          </div>
          {toolCall.result && (
            <div>
              <span className="font-medium text-muted-foreground">Result:</span>
              <pre className="mt-1 max-h-40 overflow-auto rounded bg-muted p-2 text-[11px]">
                {toolCall.result}
              </pre>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
