import type { TaskStep as TaskStepType } from "@/lib/types"
import { cn } from "@/lib/utils"
import { CheckCircle2, Circle, Loader2, XCircle, SkipForward } from "lucide-react"

interface TaskStepRowProps {
  step: TaskStepType
}

const stepIcons = {
  completed: CheckCircle2,
  running: Loader2,
  pending: Circle,
  failed: XCircle,
  skipped: SkipForward,
}

const stepColors = {
  completed: "text-green-500",
  running: "text-blue-500",
  pending: "text-muted-foreground",
  failed: "text-destructive",
  skipped: "text-muted-foreground",
}

export function TaskStepRow({ step }: TaskStepRowProps) {
  const Icon = stepIcons[step.status]
  return (
    <div className="flex items-start gap-3 py-2">
      <Icon className={cn("mt-0.5 h-4 w-4 shrink-0", stepColors[step.status], step.status === "running" && "animate-spin")} />
      <div className="min-w-0 flex-1">
        <div className="text-sm font-medium">{step.title}</div>
        {step.output && (
          <p className="mt-0.5 text-xs text-muted-foreground">{step.output}</p>
        )}
        {step.error && (
          <p className="mt-0.5 text-xs text-destructive">{step.error}</p>
        )}
        {step.tool_calls && step.tool_calls.length > 0 && (
          <div className="mt-1 text-xs text-muted-foreground">
            {step.tool_calls.length} tool call{step.tool_calls.length > 1 ? "s" : ""}
          </div>
        )}
      </div>
    </div>
  )
}
