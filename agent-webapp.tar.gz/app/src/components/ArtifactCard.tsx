import type { Artifact } from "@/lib/types"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { FileCode2, Image, FileText, Copy, ExternalLink } from "lucide-react"
import { useState } from "react"

interface ArtifactCardProps {
  artifact: Artifact
}

const typeIcons = {
  code: FileCode2,
  image: Image,
  file: FileText,
  html: FileCode2,
  markdown: FileText,
}

export function ArtifactCard({ artifact }: ArtifactCardProps) {
  const [copied, setCopied] = useState(false)
  const Icon = typeIcons[artifact.type]

  const handleCopy = () => {
    navigator.clipboard.writeText(artifact.content)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <Card className="my-2 overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between gap-2 p-3 pb-2">
        <div className="flex items-center gap-2">
          <Icon className="h-4 w-4 text-primary" />
          <CardTitle className="text-sm font-medium">{artifact.name}</CardTitle>
          {artifact.language && (
            <span className="rounded bg-muted px-1.5 py-0.5 text-[10px] text-muted-foreground">
              {artifact.language}
            </span>
          )}
        </div>
        <div className="flex gap-1">
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={handleCopy}>
            <Copy className={copied ? "text-green-500" : "h-3.5 w-3.5"} />
          </Button>
          {artifact.type === "html" && (
            <Button variant="ghost" size="icon" className="h-7 w-7">
              <ExternalLink className="h-3.5 w-3.5" />
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="p-3 pt-0">
        <pre className="max-h-60 overflow-auto rounded-md bg-muted p-3 text-xs">
          <code>{artifact.content}</code>
        </pre>
      </CardContent>
    </Card>
  )
}
