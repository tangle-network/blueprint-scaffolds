import { Link, useLocation } from "react-router-dom"
import { cn } from "@/lib/utils"
import {
  MessageSquare,
  ListTodo,
  FolderTree,
  LayoutDashboard,
  FolderKanban,
  BarChart3,
  Settings,
  Bot,
  PanelLeftClose,
  PanelLeft,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip"

interface SidebarProps {
  collapsed: boolean
  onToggleCollapse: () => void
}

const navItems = [
  { path: "/", icon: LayoutDashboard, label: "Dashboard" },
  { path: "/chat", icon: MessageSquare, label: "Chat" },
  { path: "/tasks", icon: ListTodo, label: "Tasks" },
  { path: "/workspace", icon: FolderTree, label: "Workspace" },
  { path: "/projects", icon: FolderKanban, label: "Projects" },
  { path: "/analytics", icon: BarChart3, label: "Analytics" },
  { path: "/settings", icon: Settings, label: "Settings" },
]

export function Sidebar({ collapsed, onToggleCollapse }: SidebarProps) {
  const location = useLocation()

  return (
    <TooltipProvider delayDuration={0}>
      <div
        className={cn(
          "flex h-full flex-col border-r bg-card transition-all duration-200",
          collapsed ? "w-14" : "w-56"
        )}
      >
        <div className={cn("flex items-center border-b px-3 py-3", collapsed ? "justify-center" : "gap-2")}>
          <Bot className="h-5 w-5 shrink-0 text-primary" />
          {!collapsed && <span className="text-sm font-bold">AI Agent</span>}
          <Button
            variant="ghost"
            size="icon"
            className={cn("ml-auto h-7 w-7 shrink-0", collapsed && "ml-0")}
            onClick={onToggleCollapse}
          >
            {collapsed ? <PanelLeft className="h-4 w-4" /> : <PanelLeftClose className="h-4 w-4" />}
          </Button>
        </div>
        <nav className="flex-1 space-y-1 p-2">
          {navItems.map((item) => {
            const Icon = item.icon
            const isActive = location.pathname === item.path
            const link = (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors hover:bg-accent",
                  isActive && "bg-accent font-medium",
                  collapsed && "justify-center px-0"
                )}
              >
                <Icon className={cn("h-4 w-4 shrink-0", isActive && "text-primary")} />
                {!collapsed && <span>{item.label}</span>}
              </Link>
            )
            if (collapsed) {
              return (
                <Tooltip key={item.path}>
                  <TooltipTrigger asChild>{link}</TooltipTrigger>
                  <TooltipContent side="right">{item.label}</TooltipContent>
                </Tooltip>
              )
            }
            return link
          })}
        </nav>
        <Separator />
        <div className={cn("p-3 text-center", collapsed && "px-1")}>
          <div className={cn("text-[10px] text-muted-foreground", collapsed && "text-[8px]")}>
            {collapsed ? "v1" : "Agent v1.0.0"}
          </div>
        </div>
      </div>
    </TooltipProvider>
  )
}
