import type { Message } from "@/lib/types"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { ToolCallTrace } from "@/components/ToolCallTrace"
import { ArtifactCard } from "@/components/ArtifactCard"
import { Bot, User as UserIcon } from "lucide-react"
import { cn } from "@/lib/utils"

interface MessageBubbleProps {
  message: Message
}

export function MessageBubble({ message }: MessageBubbleProps) {
  const isUser = message.role === "user"

  return (
    <div className={cn("flex gap-3 py-4", isUser ? "justify-end" : "")}>
      {!isUser && (
        <Avatar className="h-8 w-8 shrink-0">
          <AvatarFallback className="bg-primary text-primary-foreground">
            <Bot className="h-4 w-4" />
          </AvatarFallback>
        </Avatar>
      )}
      <div className={cn("max-w-[80%] space-y-2", isUser && "flex flex-col items-end")}>
        <div
          className={cn(
            "rounded-2xl px-4 py-2.5 text-sm",
            isUser
              ? "bg-primary text-primary-foreground"
              : "bg-muted"
          )}
        >
          {message.content || (
            <span className="inline-flex items-center gap-1 text-muted-foreground">
              <span className="animate-pulse-slow">Thinking</span>
              <span className="animate-pulse">...</span>
            </span>
          )}
        </div>
        {message.tool_calls?.map((tc) => (
          <ToolCallTrace key={tc.id} toolCall={tc} />
        ))}
        {message.artifacts?.map((art) => (
          <ArtifactCard key={art.id} artifact={art} />
        ))}
        <span className="text-[10px] text-muted-foreground">
          {new Date(message.created_at).toLocaleTimeString()}
        </span>
      </div>
      {isUser && (
        <Avatar className="h-8 w-8 shrink-0">
          <AvatarFallback className="bg-secondary">
            <UserIcon className="h-4 w-4" />
          </AvatarFallback>
        </Avatar>
      )}
    </div>
  )
}
