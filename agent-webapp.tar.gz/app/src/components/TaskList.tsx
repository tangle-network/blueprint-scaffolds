import { useEffect, useState } from "react"
import { useTaskStore } from "@/lib/stores"
import { TaskCard } from "@/components/TaskCard"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Plus, ListTodo, Loader2 } from "lucide-react"

export function TaskList() {
  const { tasks, loadTasks, createTask, cancelTask } = useTaskStore()
  const [showForm, setShowForm] = useState(false)
  const [title, setTitle] = useState("")
  const [desc, setDesc] = useState("")

  useEffect(() => {
    loadTasks()
  }, [loadTasks])

  const handleCreate = () => {
    if (!title.trim()) return
    createTask(title.trim(), desc.trim())
    setTitle("")
    setDesc("")
    setShowForm(false)
  }

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between border-b px-4 py-3">
        <div className="flex items-center gap-2">
          <ListTodo className="h-4 w-4" />
          <h2 className="text-sm font-semibold">Task Runs</h2>
          <span className="rounded-full bg-muted px-2 py-0.5 text-xs text-muted-foreground">{tasks.length}</span>
        </div>
        <Button variant="outline" size="sm" className="h-7 text-xs" onClick={() => setShowForm(!showForm)}>
          <Plus className="mr-1 h-3 w-3" />
          New Task
        </Button>
      </div>
      {showForm && (
        <div className="border-b p-4 space-y-2">
          <Input
            placeholder="Task title..."
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleCreate()}
          />
          <Input
            placeholder="Description (optional)..."
            value={desc}
            onChange={(e) => setDesc(e.target.value)}
          />
          <div className="flex gap-2">
            <Button size="sm" className="h-7 text-xs" onClick={handleCreate} disabled={!title.trim()}>
              Create
            </Button>
            <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setShowForm(false)}>
              Cancel
            </Button>
          </div>
        </div>
      )}
      <ScrollArea className="flex-1">
        <div className="space-y-3 p-4">
          {tasks.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
              <Loader2 className="mb-2 h-6 w-6 animate-spin" />
              <p className="text-sm">Loading tasks...</p>
            </div>
          ) : (
            tasks.map((task) => <TaskCard key={task.id} task={task} onCancel={cancelTask} />)
          )}
        </div>
      </ScrollArea>
    </div>
  )
}
