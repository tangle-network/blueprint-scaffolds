import { useEffect } from "react"
import { Separator } from "@/components/ui/separator"
import { ChatPanel } from "@/components/ChatPanel"
import { SessionList } from "@/components/SessionList"
import { useSessionStore } from "@/lib/stores"
import { ScrollArea } from "@/components/ui/scroll-area"

export default function ChatPage() {
  const { sessions, currentSessionId, loadSessions, createSession, selectSession, deleteSession } = useSessionStore()

  useEffect(() => {
    if (sessions.length === 0) loadSessions()
  }, [sessions.length, loadSessions])

  return (
    <div className="flex h-full">
      <div className="w-72 shrink-0 flex flex-col border-r">
        <div className="p-3">
          <button
            onClick={() => createSession()}
            className="flex w-full items-center justify-center gap-2 rounded-md border border-input bg-background px-4 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground"
          >
            + New Chat
          </button>
        </div>
        <Separator />
        <div className="flex items-center gap-2 px-3 py-2">
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">History</span>
        </div>
        <ScrollArea className="flex-1">
          <div className="space-y-0.5 px-2 pb-2">
            {sessions.map((session) => (
              <button
                key={session.id}
                onClick={() => selectSession(session.id)}
                className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm transition-colors hover:bg-accent ${session.id === currentSessionId ? "bg-accent" : ""}`}
              >
                <div className="min-w-0 flex-1">
                  <div className="truncate font-medium">{session.title}</div>
                  <div className="text-xs text-muted-foreground">{session.message_count} messages</div>
                </div>
                <button
                  onClick={(e) => { e.stopPropagation(); deleteSession(session.id) }}
                  className="shrink-0 rounded p-1 opacity-0 group-hover:opacity-100 hover:bg-destructive/10"
                >
                  <span className="text-xs text-muted-foreground">x</span>
                </button>
              </button>
            ))}
          </div>
        </ScrollArea>
      </div>
      <Separator orientation="vertical" />
      <div className="flex-1 min-w-0">
        <ChatPanel />
      </div>
    </div>
  )
}
