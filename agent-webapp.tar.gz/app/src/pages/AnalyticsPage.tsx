import { defaultAnalytics, defaultDeployments, defaultProjects } from "@/lib/default-data"
import type { MetricPoint } from "@/lib/types"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  Activity,
  Zap,
  Clock,
  Users,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
} from "lucide-react"
import { cn } from "@/lib/utils"

function formatNumber(n: number): string {
  if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`
  if (n >= 1000) return `${(n / 1000).toFixed(1)}K`
  return String(n)
}

function computeTrend(points: MetricPoint[]): { value: number; direction: "up" | "down" | "flat" } {
  if (points.length < 2) return { value: 0, direction: "flat" }
  const recent = points.slice(-7).reduce((s, p) => s + p.value, 0) / 7
  const prev = points.slice(-14, -7).reduce((s, p) => s + p.value, 0) / 7
  if (prev === 0) return { value: 0, direction: "flat" }
  const pct = ((recent - prev) / prev) * 100
  return { value: Math.abs(Math.round(pct)), direction: pct > 1 ? "up" : pct < -1 ? "down" : "flat" }
}

function MiniChart({ points, color = "stroke-primary" }: { points: MetricPoint[]; color?: string }) {
  if (points.length < 2) return null
  const max = Math.max(...points.map((p) => p.value))
  const min = Math.min(...points.map((p) => p.value))
  const range = max - min || 1
  const w = 200
  const h = 40
  const step = w / (points.length - 1)
  const pathD = points
    .map((p, i) => {
      const x = i * step
      const y = h - ((p.value - min) / range) * h * 0.8 - h * 0.1
      return `${i === 0 ? "M" : "L"} ${x.toFixed(1)} ${y.toFixed(1)}`
    })
    .join(" ")

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className={cn("w-full h-10", color)} fill="none">
      <path d={pathD} stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

const trendIcon = { up: ArrowUpRight, down: ArrowDownRight, flat: Minus }
const trendColor = { up: "text-green-500", down: "text-destructive", flat: "text-muted-foreground" }

function MetricCard({
  title,
  points,
  icon: Icon,
  format = formatNumber,
  invertTrend = false,
}: {
  title: string
  points: MetricPoint[]
  icon: typeof Activity
  format?: (n: number) => string
  invertTrend?: boolean
}) {
  const current = points[points.length - 1]?.value ?? 0
  const trend = computeTrend(points)
  const TrendIcon = trendIcon[trend.direction]
  const good = invertTrend ? trend.direction === "down" : trend.direction === "up"
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-medium text-muted-foreground">{title}</span>
          <Icon className="h-4 w-4 text-muted-foreground" />
        </div>
        <p className="text-2xl font-bold">{format(current)}</p>
        <div className="flex items-center gap-1 mt-1">
          <TrendIcon className={cn("h-3 w-3", good ? "text-green-500" : trend.direction === "flat" ? "text-muted-foreground" : "text-destructive")} />
          <span className={cn("text-xs", good ? "text-green-500" : trend.direction === "flat" ? "text-muted-foreground" : "text-destructive")}>
            {trend.value}%
          </span>
          <span className="text-xs text-muted-foreground">vs last week</span>
        </div>
        <div className="mt-3">
          <MiniChart points={points.slice(-14)} />
        </div>
      </CardContent>
    </Card>
  )
}

const successDeploys = defaultDeployments.filter((d) => d.status === "success")
const avgDuration = successDeploys.length > 0
  ? Math.round(successDeploys.reduce((s, d) => s + d.duration_ms, 0) / successDeploys.length / 1000)
  : 0

export default function AnalyticsPage() {
  const { requests_per_day, tokens_used, tasks_completed, active_users, avg_response_ms, error_rate } = defaultAnalytics

  return (
    <ScrollArea className="h-full">
      <div className="mx-auto max-w-6xl p-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Analytics</h1>
          <p className="text-sm text-muted-foreground">
            Usage metrics, performance data, and operational insights
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <MetricCard title="Requests / Day" points={requests_per_day} icon={Activity} />
          <MetricCard title="Tokens Used" points={tokens_used} icon={Zap} />
          <MetricCard title="Tasks Completed" points={tasks_completed} icon={BarChart3} />
          <MetricCard title="Active Users" points={active_users} icon={Users} />
          <MetricCard title="Avg Response Time" points={avg_response_ms} icon={Clock} format={(n) => `${n}ms`} invertTrend />
          <MetricCard title="Error Rate" points={error_rate} icon={AlertTriangle} format={(n) => `${n.toFixed(1)}%`} invertTrend />
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Requests Over Time</CardTitle>
              <CardDescription>Daily API request volume for the past 30 days</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-48">
                <MiniChart points={requests_per_day} color="stroke-primary" />
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-center">
                <div>
                  <p className="text-lg font-bold">{formatNumber(requests_per_day.reduce((s, p) => s + p.value, 0))}</p>
                  <p className="text-xs text-muted-foreground">Total (30d)</p>
                </div>
                <div>
                  <p className="text-lg font-bold">{formatNumber(requests_per_day[requests_per_day.length - 1]?.value ?? 0)}</p>
                  <p className="text-xs text-muted-foreground">Today</p>
                </div>
                <div>
                  <p className="text-lg font-bold">{formatNumber(Math.round(requests_per_day.reduce((s, p) => s + p.value, 0) / requests_per_day.length))}</p>
                  <p className="text-xs text-muted-foreground">Daily Avg</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Token Consumption</CardTitle>
              <CardDescription>Cumulative token usage trend over 30 days</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-48">
                <MiniChart points={tokens_used} color="stroke-purple-500" />
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-center">
                <div>
                  <p className="text-lg font-bold">{formatNumber(tokens_used.reduce((s, p) => s + p.value, 0))}</p>
                  <p className="text-xs text-muted-foreground">Total (30d)</p>
                </div>
                <div>
                  <p className="text-lg font-bold">{formatNumber(tokens_used[tokens_used.length - 1]?.value ?? 0)}</p>
                  <p className="text-xs text-muted-foreground">Today</p>
                </div>
                <div>
                  <p className="text-lg font-bold">{formatNumber(Math.round(tokens_used.reduce((s, p) => s + p.value, 0) / tokens_used.length))}</p>
                  <p className="text-xs text-muted-foreground">Daily Avg</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Deployment Summary</CardTitle>
            <CardDescription>Recent deployment activity across all projects</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
              <div className="rounded-lg border p-4 text-center">
                <p className="text-2xl font-bold">{defaultDeployments.length}</p>
                <p className="text-xs text-muted-foreground">Total Deploys</p>
              </div>
              <div className="rounded-lg border p-4 text-center">
                <p className="text-2xl font-bold text-green-500">{successDeploys.length}</p>
                <p className="text-xs text-muted-foreground">Successful</p>
              </div>
              <div className="rounded-lg border p-4 text-center">
                <p className="text-2xl font-bold text-destructive">
                  {defaultDeployments.filter((d) => d.status === "failed").length}
                </p>
                <p className="text-xs text-muted-foreground">Failed</p>
              </div>
              <div className="rounded-lg border p-4 text-center">
                <p className="text-2xl font-bold">{avgDuration}s</p>
                <p className="text-xs text-muted-foreground">Avg Duration</p>
              </div>
            </div>

            <div className="mt-6 space-y-2">
              {defaultDeployments.map((dep) => {
                const project = defaultProjects.find((p) => p.id === dep.project_id)
                return (
                  <div key={dep.id} className="flex items-center justify-between rounded-lg border p-3">
                    <div className="flex items-center gap-3">
                      <Badge variant="outline" className="text-[10px] shrink-0">{dep.environment}</Badge>
                      <div>
                        <p className="text-sm font-medium">{project?.name}</p>
                        <p className="text-xs text-muted-foreground">{dep.commit_message}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <Badge
                        variant={dep.status === "success" ? "secondary" : dep.status === "failed" ? "destructive" : "default"}
                        className="text-[10px]"
                      >
                        {dep.status}
                      </Badge>
                      <span className="text-xs text-muted-foreground w-16 text-right">
                        {dep.duration_ms > 0 ? `${(dep.duration_ms / 1000).toFixed(0)}s` : "—"}
                      </span>
                    </div>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </ScrollArea>
  )
}
