import { useState } from "react"
import type { Project } from "@/lib/types"
import { defaultProjects, defaultDeployments } from "@/lib/default-data"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import {
  FolderKanban,
  Search,
  GitBranch,
  Users,
  Star,
  AlertCircle,
  Clock,
  Rocket,
  ExternalLink,
  CheckCircle2,
  Loader2,
  XCircle,
  Archive,
} from "lucide-react"
import { cn } from "@/lib/utils"

const statusConfig: Record<Project["status"], { label: string; variant: "default" | "secondary" | "outline" | "destructive"; icon: typeof CheckCircle2 }> = {
  active: { label: "Active", variant: "default", icon: CheckCircle2 },
  draft: { label: "Draft", variant: "outline", icon: Clock },
  archived: { label: "Archived", variant: "secondary", icon: Archive },
}

const deployIcons = {
  success: CheckCircle2,
  failed: XCircle,
  building: Loader2,
  queued: Clock,
}

export default function ProjectsPage() {
  const [search, setSearch] = useState("")
  const [tab, setTab] = useState("all")

  const filtered = defaultProjects.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.description.toLowerCase().includes(search.toLowerCase()) ||
      p.language.toLowerCase().includes(search.toLowerCase())
    if (tab === "all") return matchesSearch
    return matchesSearch && p.status === tab
  })

  return (
    <ScrollArea className="h-full">
      <div className="mx-auto max-w-6xl p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Projects</h1>
            <p className="text-sm text-muted-foreground">
              Manage repositories and deployments across your organization
            </p>
          </div>
          <Button size="sm" className="gap-1.5">
            <FolderKanban className="h-3.5 w-3.5" />
            New Project
          </Button>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search projects..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          <Tabs value={tab} onValueChange={setTab}>
            <TabsList>
              <TabsTrigger value="all">All ({defaultProjects.length})</TabsTrigger>
              <TabsTrigger value="active">
                Active ({defaultProjects.filter((p) => p.status === "active").length})
              </TabsTrigger>
              <TabsTrigger value="draft">
                Draft ({defaultProjects.filter((p) => p.status === "draft").length})
              </TabsTrigger>
              <TabsTrigger value="archived">
                Archived ({defaultProjects.filter((p) => p.status === "archived").length})
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {filtered.map((project) => {
            const cfg = statusConfig[project.status]
            const StatusIcon = cfg.icon
            const deploys = defaultDeployments.filter((d) => d.project_id === project.id)
            const latestDeploy = deploys[0]

            return (
              <Card key={project.id} className="overflow-hidden">
                <CardHeader className="p-4 pb-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <CardTitle className="text-base">{project.name}</CardTitle>
                        <Badge variant={cfg.variant} className="text-[10px] px-1.5 py-0">
                          <StatusIcon className="mr-1 h-3 w-3" />
                          {cfg.label}
                        </Badge>
                      </div>
                      <CardDescription className="mt-1 line-clamp-2">
                        {project.description}
                      </CardDescription>
                    </div>
                    <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0">
                      <ExternalLink className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="px-4 pb-4 pt-0 space-y-3">
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary" className="text-[10px]">{project.language}</Badge>
                    <Badge variant="secondary" className="text-[10px]">{project.framework}</Badge>
                  </div>

                  <Separator />

                  <div className="grid grid-cols-4 gap-2 text-center">
                    <div>
                      <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground">
                        <Star className="h-3 w-3" />
                      </div>
                      <p className="text-sm font-semibold">{project.stars}</p>
                    </div>
                    <div>
                      <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground">
                        <GitBranch className="h-3 w-3" />
                      </div>
                      <p className="text-sm font-semibold">{project.branch_count}</p>
                    </div>
                    <div>
                      <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground">
                        <Users className="h-3 w-3" />
                      </div>
                      <p className="text-sm font-semibold">{project.contributor_count}</p>
                    </div>
                    <div>
                      <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground">
                        <AlertCircle className="h-3 w-3" />
                      </div>
                      <p className="text-sm font-semibold">{project.open_issues}</p>
                    </div>
                  </div>

                  {latestDeploy && (() => {
                    const DepIcon = deployIcons[latestDeploy.status]
                    return (
                      <>
                        <Separator />
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2 text-xs">
                            <Rocket className="h-3.5 w-3.5 text-muted-foreground" />
                            <span className="text-muted-foreground">Latest deploy:</span>
                            <DepIcon className={cn("h-3 w-3", latestDeploy.status === "building" && "animate-spin")} />
                            <span className="font-mono text-[10px]">{latestDeploy.commit_sha}</span>
                          </div>
                          <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                            {latestDeploy.environment}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground truncate">
                          {latestDeploy.commit_message}
                        </p>
                      </>
                    )
                  })()}

                  <div className="text-[10px] text-muted-foreground">
                    Created {new Date(project.created_at).toLocaleDateString()} · Updated{" "}
                    {new Date(project.updated_at).toLocaleDateString()}
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
            <FolderKanban className="h-12 w-12 mb-3" />
            <p className="text-sm font-medium">No projects found</p>
            <p className="text-xs">Try adjusting your search or filter</p>
          </div>
        )}
      </div>
    </ScrollArea>
  )
}
