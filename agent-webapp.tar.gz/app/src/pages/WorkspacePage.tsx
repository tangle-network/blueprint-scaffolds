import { WorkspacePanel } from "@/components/WorkspacePanel"

export default function WorkspacePage() {
  return <WorkspacePanel />
}
