import { Link } from "react-router-dom"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import {
  MessageSquare,
  ListTodo,
  FolderKanban,
  Rocket,
  Activity,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  Clock,
  ArrowUpRight,
  GitBranch,
  Users,
  Star,
  AlertTriangle,
  Zap,
} from "lucide-react"
import { defaultProjects, defaultDeployments, defaultActivity } from "@/lib/default-data"
import { cn } from "@/lib/utils"

const stats = [
  { label: "Active Sessions", value: "12", icon: MessageSquare, trend: "+3 this week", color: "text-blue-500" },
  { label: "Tasks Running", value: "3", icon: ListTodo, trend: "2 completed today", color: "text-green-500" },
  { label: "Projects", value: String(defaultProjects.filter((p) => p.status === "active").length), icon: FolderKanban, trend: "6 total", color: "text-purple-500" },
  { label: "Deployments Today", value: "4", icon: Rocket, trend: "1 building", color: "text-orange-500" },
]

const statusIcons = {
  success: CheckCircle2,
  warning: AlertTriangle,
  error: AlertCircle,
  info: Clock,
}

const statusColors = {
  success: "text-green-500",
  warning: "text-yellow-500",
  error: "text-destructive",
  info: "text-blue-500",
}

const deployStatusConfig = {
  success: { label: "Success", variant: "secondary" as const },
  failed: { label: "Failed", variant: "destructive" as const },
  building: { label: "Building", variant: "default" as const },
  queued: { label: "Queued", variant: "outline" as const },
}

export default function DashboardPage() {
  return (
    <ScrollArea className="h-full">
      <div className="mx-auto max-w-6xl p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Dashboard</h1>
            <p className="text-sm text-muted-foreground">Overview of your AI agent workspace</p>
          </div>
          <div className="flex gap-2">
            <Link to="/chat">
              <Button size="sm" className="gap-1.5">
                <Zap className="h-3.5 w-3.5" />
                New Chat
              </Button>
            </Link>
            <Link to="/projects">
              <Button variant="outline" size="sm" className="gap-1.5">
                <FolderKanban className="h-3.5 w-3.5" />
                Projects
              </Button>
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => {
            const Icon = stat.icon
            return (
              <Card key={stat.label}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">{stat.label}</p>
                      <p className="text-2xl font-bold">{stat.value}</p>
                    </div>
                    <div className={cn("rounded-full bg-muted p-2.5", stat.color)}>
                      <Icon className="h-5 w-5" />
                    </div>
                  </div>
                  <p className="mt-2 text-xs text-muted-foreground">{stat.trend}</p>
                </CardContent>
              </Card>
            )
          })}
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">Recent Deployments</CardTitle>
                <Rocket className="h-4 w-4 text-muted-foreground" />
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {defaultDeployments.slice(0, 5).map((dep, i) => {
                const cfg = deployStatusConfig[dep.status]
                const project = defaultProjects.find((p) => p.id === dep.project_id)
                return (
                  <div key={i}>
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium">{project?.name}</span>
                          <Badge variant={cfg.variant} className="text-[10px] px-1.5 py-0">
                            {cfg.label}
                          </Badge>
                          <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                            {dep.environment}
                          </Badge>
                        </div>
                        <p className="mt-0.5 truncate text-xs text-muted-foreground">
                          <span className="font-mono">{dep.commit_sha}</span> — {dep.commit_message}
                        </p>
                      </div>
                      <div className="flex items-center gap-1 text-[10px] text-muted-foreground shrink-0">
                        <GitBranch className="h-3 w-3" />
                        {dep.branch}
                      </div>
                    </div>
                    {i < defaultDeployments.length - 2 && <Separator className="mt-3" />}
                  </div>
                )
              })}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">Activity Feed</CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {defaultActivity.slice(0, 6).map((item, i) => {
                const Icon = statusIcons[item.status || "info"]
                const color = statusColors[item.status || "info"]
                return (
                  <div key={item.id}>
                    <div className="flex items-start gap-3">
                      <Icon className={cn("mt-0.5 h-4 w-4 shrink-0", color)} />
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium">{item.title}</p>
                        <p className="text-xs text-muted-foreground">{item.description}</p>
                        <p className="mt-0.5 text-[10px] text-muted-foreground">
                          {new Date(item.timestamp).toLocaleString()}
                        </p>
                      </div>
                    </div>
                    {i < 5 && <Separator className="mt-3" />}
                  </div>
                )
              })}
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-base">Active Projects</CardTitle>
                <CardDescription>Recently updated repositories</CardDescription>
              </div>
              <Link to="/projects">
                <Button variant="ghost" size="sm" className="gap-1 text-xs">
                  View All <ArrowUpRight className="h-3 w-3" />
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {defaultProjects
                .filter((p) => p.status === "active")
                .slice(0, 3)
                .map((project) => (
                  <div
                    key={project.id}
                    className="rounded-lg border p-4 transition-colors hover:bg-muted/50"
                  >
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-semibold">{project.name}</h3>
                      <Badge variant="secondary" className="text-[10px]">
                        {project.language}
                      </Badge>
                    </div>
                    <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">
                      {project.description}
                    </p>
                    <div className="mt-3 flex items-center gap-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Star className="h-3 w-3" /> {project.stars}
                      </span>
                      <span className="flex items-center gap-1">
                        <GitBranch className="h-3 w-3" /> {project.branch_count}
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="h-3 w-3" /> {project.contributor_count}
                      </span>
                    </div>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>

        <div className="flex items-center justify-between rounded-lg border bg-muted/30 p-4">
          <div className="flex items-center gap-3">
            <div className="rounded-full bg-green-500/10 p-2">
              <TrendingUp className="h-5 w-5 text-green-500" />
            </div>
            <div>
              <p className="text-sm font-medium">System Healthy</p>
              <p className="text-xs text-muted-foreground">
                All services operational — avg response time 340ms
              </p>
            </div>
          </div>
          <Link to="/analytics">
            <Button variant="outline" size="sm" className="gap-1 text-xs">
              View Analytics <ArrowUpRight className="h-3 w-3" />
            </Button>
          </Link>
        </div>
      </div>
    </ScrollArea>
  )
}
