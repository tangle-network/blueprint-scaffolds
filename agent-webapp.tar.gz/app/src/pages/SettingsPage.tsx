import { useState } from "react"
import { defaultSettings } from "@/lib/default-data"
import type { UserSettings } from "@/lib/types"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Settings as SettingsIcon,
  User,
  Bot,
  Bell,
  Shield,
  Palette,
  Save,
  CheckCircle2,
  Key,
  Thermometer,
} from "lucide-react"
import { cn } from "@/lib/utils"

export default function SettingsPage() {
  const [settings, setSettings] = useState<UserSettings>({ ...defaultSettings })
  const [saved, setSaved] = useState(false)

  const handleSave = () => {
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <ScrollArea className="h-full">
      <div className="mx-auto max-w-3xl p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Settings</h1>
            <p className="text-sm text-muted-foreground">Manage your preferences and configuration</p>
          </div>
          <Button size="sm" className="gap-1.5" onClick={handleSave}>
            {saved ? <CheckCircle2 className="h-3.5 w-3.5" /> : <Save className="h-3.5 w-3.5" />}
            {saved ? "Saved!" : "Save Changes"}
          </Button>
        </div>

        <Tabs defaultValue="general">
          <TabsList>
            <TabsTrigger value="general" className="gap-1.5">
              <User className="h-3.5 w-3.5" /> General
            </TabsTrigger>
            <TabsTrigger value="model" className="gap-1.5">
              <Bot className="h-3.5 w-3.5" /> Model
            </TabsTrigger>
            <TabsTrigger value="appearance" className="gap-1.5">
              <Palette className="h-3.5 w-3.5" /> Appearance
            </TabsTrigger>
            <TabsTrigger value="notifications" className="gap-1.5">
              <Bell className="h-3.5 w-3.5" /> Notifications
            </TabsTrigger>
          </TabsList>

          <TabsContent value="general" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Profile</CardTitle>
                <CardDescription>Your display name and email address</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Display Name</label>
                  <Input
                    value={settings.display_name}
                    onChange={(e) => setSettings({ ...settings, display_name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Email</label>
                  <Input
                    type="email"
                    value={settings.email}
                    onChange={(e) => setSettings({ ...settings, email: e.target.value })}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">API Configuration</CardTitle>
                <CardDescription>Manage your API key and connection status</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between rounded-lg border p-4">
                  <div className="flex items-center gap-3">
                    <div className={cn("rounded-full p-2", settings.api_key_configured ? "bg-green-500/10" : "bg-destructive/10")}>
                      <Key className={cn("h-4 w-4", settings.api_key_configured ? "text-green-500" : "text-destructive")} />
                    </div>
                    <div>
                      <p className="text-sm font-medium">API Key</p>
                      <p className="text-xs text-muted-foreground">
                        {settings.api_key_configured ? "Configured and active" : "Not configured"}
                      </p>
                    </div>
                  </div>
                  <Badge variant={settings.api_key_configured ? "default" : "destructive"} className="text-[10px]">
                    {settings.api_key_configured ? "Active" : "Missing"}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="model" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Default Model</CardTitle>
                <CardDescription>Choose the AI model used for new sessions</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Model</label>
                  <select
                    value={settings.default_model}
                    onChange={(e) => setSettings({ ...settings, default_model: e.target.value })}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <option value="gpt-4o">GPT-4o</option>
                    <option value="gpt-4o-mini">GPT-4o Mini</option>
                    <option value="claude-3.5-sonnet">Claude 3.5 Sonnet</option>
                    <option value="claude-3-haiku">Claude 3 Haiku</option>
                  </select>
                </div>

                <Separator />

                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-medium flex items-center gap-1.5">
                        <Thermometer className="h-3.5 w-3.5" /> Temperature
                      </label>
                      <span className="text-sm text-muted-foreground">{settings.temperature}</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="2"
                      step="0.1"
                      value={settings.temperature}
                      onChange={(e) => setSettings({ ...settings, temperature: parseFloat(e.target.value) })}
                      className="w-full accent-primary"
                    />
                    <div className="flex justify-between text-[10px] text-muted-foreground">
                      <span>Precise</span>
                      <span>Creative</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-medium">Max Tokens</label>
                      <span className="text-sm text-muted-foreground">{settings.max_tokens}</span>
                    </div>
                    <input
                      type="range"
                      min="256"
                      max="8192"
                      step="256"
                      value={settings.max_tokens}
                      onChange={(e) => setSettings({ ...settings, max_tokens: parseInt(e.target.value) })}
                      className="w-full accent-primary"
                    />
                    <div className="flex justify-between text-[10px] text-muted-foreground">
                      <span>256</span>
                      <span>8192</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Session Behavior</CardTitle>
                <CardDescription>Control how sessions and tool calls are handled</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Auto-save sessions</p>
                    <p className="text-xs text-muted-foreground">Automatically persist chat history</p>
                  </div>
                  <button
                    onClick={() => setSettings({ ...settings, auto_save_sessions: !settings.auto_save_sessions })}
                    className={cn(
                      "relative h-6 w-11 rounded-full transition-colors",
                      settings.auto_save_sessions ? "bg-primary" : "bg-muted"
                    )}
                  >
                    <span
                      className={cn(
                        "absolute top-0.5 h-5 w-5 rounded-full bg-white transition-transform",
                        settings.auto_save_sessions ? "translate-x-5.5" : "translate-x-0.5"
                      )}
                    />
                  </button>
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Show tool calls</p>
                    <p className="text-xs text-muted-foreground">Display tool call traces in chat</p>
                  </div>
                  <button
                    onClick={() => setSettings({ ...settings, show_tool_calls: !settings.show_tool_calls })}
                    className={cn(
                      "relative h-6 w-11 rounded-full transition-colors",
                      settings.show_tool_calls ? "bg-primary" : "bg-muted"
                    )}
                  >
                    <span
                      className={cn(
                        "absolute top-0.5 h-5 w-5 rounded-full bg-white transition-transform",
                        settings.show_tool_calls ? "translate-x-5.5" : "translate-x-0.5"
                      )}
                    />
                  </button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="appearance" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Theme</CardTitle>
                <CardDescription>Customize the application color scheme</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-3">
                  {(["light", "dark", "system"] as const).map((theme: "light" | "dark" | "system") => (
                    <button
                      key={theme}
                      onClick={() => setSettings({ ...settings, theme })}
                      className={cn(
                        "rounded-lg border-2 p-4 text-center transition-colors",
                        settings.theme === theme ? "border-primary bg-primary/5" : "border-transparent bg-muted hover:bg-muted/80"
                      )}
                    >
                      <p className="text-sm font-medium capitalize">{theme}</p>
                      <p className="text-[10px] text-muted-foreground mt-1">
                        {theme === "light" ? "Light background" : theme === "dark" ? "Dark background" : "Follow system"}
                      </p>
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notifications" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Notification Preferences</CardTitle>
                <CardDescription>Configure when and how you receive alerts</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Enable notifications</p>
                    <p className="text-xs text-muted-foreground">Receive alerts for task completions, errors, and deployments</p>
                  </div>
                  <button
                    onClick={() => setSettings({ ...settings, notifications_enabled: !settings.notifications_enabled })}
                    className={cn(
                      "relative h-6 w-11 rounded-full transition-colors",
                      settings.notifications_enabled ? "bg-primary" : "bg-muted"
                    )}
                  >
                    <span
                      className={cn(
                        "absolute top-0.5 h-5 w-5 rounded-full bg-white transition-transform",
                        settings.notifications_enabled ? "translate-x-5.5" : "translate-x-0.5"
                      )}
                    />
                  </button>
                </div>

                <Separator />

                <div className="space-y-3">
                  <h4 className="text-sm font-medium">Notification Types</h4>
                  {[
                    { label: "Task completed", desc: "When an AI task finishes execution" },
                    { label: "Deployment status", desc: "Build and deployment state changes" },
                    { label: "Error alerts", desc: "Critical errors and failures" },
                    { label: "Session updates", desc: "New messages in background sessions" },
                  ].map((item) => (
                    <div key={item.label} className="flex items-center justify-between rounded-lg border p-3">
                      <div>
                        <p className="text-sm">{item.label}</p>
                        <p className="text-xs text-muted-foreground">{item.desc}</p>
                      </div>
                      <Shield className="h-4 w-4 text-muted-foreground" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </ScrollArea>
  )
}
