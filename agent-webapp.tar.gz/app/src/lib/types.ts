export interface Session {
  id: string;
  title: string;
  created_at: string;
  updated_at: string;
  message_count: number;
}

export interface Message {
  id: string;
  session_id: string;
  role: "user" | "assistant" | "system";
  content: string;
  tool_calls?: ToolCall[];
  artifacts?: Artifact[];
  created_at: string;
}

export interface ToolCall {
  id: string;
  name: string;
  arguments: Record<string, unknown>;
  result?: string;
  status: "pending" | "running" | "completed" | "error";
  started_at?: string;
  completed_at?: string;
  duration_ms?: number;
}

export interface Artifact {
  id: string;
  type: "file" | "image" | "code" | "html" | "markdown";
  name: string;
  content: string;
  language?: string;
}

export interface TaskRun {
  id: string;
  title: string;
  status: "pending" | "running" | "completed" | "failed" | "cancelled";
  progress: number;
  steps: TaskStep[];
  created_at: string;
  completed_at?: string;
  output?: string;
  error?: string;
}

export interface TaskStep {
  id: string;
  title: string;
  status: "pending" | "running" | "completed" | "failed" | "skipped";
  tool_calls?: ToolCall[];
  output?: string;
  error?: string;
}

export interface WorkspaceFile {
  id: string;
  name: string;
  path: string;
  type: "file" | "directory";
  content?: string;
  language?: string;
  size: number;
  modified_at: string;
  children?: WorkspaceFile[];
}

export interface SSEEvent {
  type: "message" | "tool_call" | "tool_result" | "task_update" | "artifact" | "done" | "error";
  data: unknown;
}

export interface ChatRequest {
  message: string;
  session_id?: string;
}

export interface TaskRequest {
  title: string;
  description: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  status: "active" | "archived" | "draft";
  language: string;
  framework: string;
  last_deployed?: string;
  created_at: string;
  updated_at: string;
  stars: number;
  open_issues: number;
  branch_count: number;
  contributor_count: number;
  url: string;
}

export interface Deployment {
  id: string;
  project_id: string;
  environment: "production" | "staging" | "preview";
  status: "success" | "failed" | "building" | "queued";
  branch: string;
  commit_sha: string;
  commit_message: string;
  deployed_at: string;
  duration_ms: number;
  deployer: string;
}

export interface MetricPoint {
  timestamp: string;
  value: number;
}

export interface AnalyticsData {
  requests_per_day: MetricPoint[];
  tokens_used: MetricPoint[];
  tasks_completed: MetricPoint[];
  active_users: MetricPoint[];
  avg_response_ms: MetricPoint[];
  error_rate: MetricPoint[];
}

export interface ActivityItem {
  id: string;
  type: "deployment" | "task_completed" | "session_created" | "error" | "commit";
  title: string;
  description: string;
  timestamp: string;
  status?: "success" | "warning" | "error" | "info";
}

export interface UserSettings {
  display_name: string;
  email: string;
  avatar_url: string;
  theme: "light" | "dark" | "system";
  default_model: string;
  auto_save_sessions: boolean;
  show_tool_calls: boolean;
  max_tokens: number;
  temperature: number;
  api_key_configured: boolean;
  notifications_enabled: boolean;
}
