import { Link, useParams } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { ArrowLeft, Users, Layers, TrendingUp, Calendar, ExternalLink } from "lucide-react"
import { collections, nfts } from "@/lib/data"

export default function CollectionPage() {
  const { id } = useParams<{ id: string }>()
  const collection = collections.find((c) => c.id === id) ?? collections[0]
  const collectionNfts = nfts.filter((n) => n.collection.id === collection.id)

  return (
    <div className="space-y-8">
      <div className="relative rounded-xl overflow-hidden">
        <div className="h-48 md:h-64">
          <img src={collection.bannerUrl} alt={collection.name} className="w-full h-full object-cover" />
        </div>
        <div className="absolute -bottom-10 left-6">
          <Avatar className="h-24 w-24 border-4 border-background shadow-lg">
            <AvatarImage src={collection.logoUrl} />
            <AvatarFallback className="text-2xl">{collection.name[0]}</AvatarFallback>
          </Avatar>
        </div>
      </div>

      <div className="pt-10">
        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-3xl font-bold">{collection.name}</h1>
              {collection.verified && (
                <Badge className="h-6 w-6 p-0 flex items-center justify-center text-xs">✓</Badge>
              )}
            </div>
            <p className="text-muted-foreground mt-1">
              Created by{" "}
              <span className="text-primary font-medium">{collection.creator.displayName}</span>
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="gap-2">
              <ExternalLink className="h-4 w-4" />
              Share
            </Button>
            <Button size="sm" className="gap-2">
              <Users className="h-4 w-4" />
              Follow
            </Button>
          </div>
        </div>

        <p className="mt-4 text-muted-foreground max-w-2xl">{collection.description}</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-xs text-muted-foreground flex items-center justify-center gap-1">
              <Layers className="h-3 w-3" /> Items
            </p>
            <p className="text-xl font-bold">{collection.totalSupply.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-xs text-muted-foreground flex items-center justify-center gap-1">
              <Users className="h-3 w-3" /> Owners
            </p>
            <p className="text-xl font-bold">{collection.owners.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-xs text-muted-foreground flex items-center justify-center gap-1">
              <TrendingUp className="h-3 w-3" /> Floor Price
            </p>
            <p className="text-xl font-bold">{collection.floorPrice} ETH</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-xs text-muted-foreground flex items-center justify-center gap-1">
              <Calendar className="h-3 w-3" /> Volume
            </p>
            <p className="text-xl font-bold">{collection.totalVolume.toLocaleString()} ETH</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="items">
        <TabsList>
          <TabsTrigger value="items">Items ({collectionNfts.length})</TabsTrigger>
          <TabsTrigger value="activity">Activity</TabsTrigger>
          <TabsTrigger value="about">About</TabsTrigger>
        </TabsList>

        <TabsContent value="items">
          {collectionNfts.length === 0 ? (
            <div className="text-center py-16">
              <p className="text-muted-foreground">No items currently listed in this collection</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-4">
              {collectionNfts.map((nft) => (
                <Link key={nft.id} to={`/nft/${nft.id}`}>
                  <Card className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer group">
                    <div className="aspect-square bg-muted relative">
                      <img src={nft.imageUrl} alt={nft.name} className="w-full h-full object-cover" />
                      <div className="absolute top-2 right-2">
                        {nft.isAuction ? (
                          <Badge className="text-xs">Auction</Badge>
                        ) : (
                          <Badge variant="secondary" className="text-xs">Buy Now</Badge>
                        )}
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-semibold group-hover:text-primary transition-colors truncate">
                        {nft.name}
                      </h3>
                      <div className="flex items-center gap-2 mt-2">
                        <Avatar className="h-5 w-5">
                          <AvatarImage src={nft.owner.avatarUrl} />
                          <AvatarFallback>{nft.owner.displayName[0]}</AvatarFallback>
                        </Avatar>
                        <span className="text-xs text-muted-foreground">{nft.owner.displayName}</span>
                      </div>
                      <Separator className="my-3" />
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="text-xs text-muted-foreground">
                            {nft.isAuction ? "Current Bid" : "Price"}
                          </p>
                          <p className="font-bold">{nft.price} {nft.currency}</p>
                        </div>
                        {nft.lastSalePrice && (
                          <div className="text-right">
                            <p className="text-xs text-muted-foreground">Last Sale</p>
                            <p className="text-sm font-medium">{nft.lastSalePrice} {nft.currency}</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="activity">
          <Card>
            <CardContent className="p-0">
              <div className="p-4 text-center text-muted-foreground">
                <p>Activity feed for {collection.name}</p>
                <p className="text-sm mt-1">Recent sales, listings, and bids will appear here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="about">
          <Card>
            <CardHeader>
              <CardTitle>About {collection.name}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">{collection.description}</p>
              <Separator />
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Category</p>
                  <p className="font-medium capitalize">{collection.category}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Created</p>
                  <p className="font-medium">{new Date(collection.createdAt).toLocaleDateString()}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Creator</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Avatar className="h-5 w-5">
                      <AvatarImage src={collection.creator.avatarUrl} />
                      <AvatarFallback>{collection.creator.displayName[0]}</AvatarFallback>
                    </Avatar>
                    <p className="font-medium">{collection.creator.displayName}</p>
                  </div>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Blockchain</p>
                  <p className="font-medium">Ethereum</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div>
        <Link to="/explore">
          <Button variant="ghost" className="gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Explore
          </Button>
        </Link>
      </div>
    </div>
  )
}
