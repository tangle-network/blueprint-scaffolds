import { Link } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { ArrowRight, TrendingUp, Users, BarChart3, Gem } from "lucide-react"
import { collections, nfts, activities, platformStats } from "@/lib/data"
import { formatDistanceToNow } from "date-fns"

function StatCard({ icon: Icon, label, value, sub }: { icon: React.ElementType; label: string; value: string; sub: string }) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center gap-3">
          <div className="rounded-lg bg-primary/10 p-2">
            <Icon className="h-5 w-5 text-primary" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground">{label}</p>
            <p className="text-2xl font-bold">{value}</p>
            <p className="text-xs text-muted-foreground">{sub}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default function HomePage() {
  return (
    <div className="space-y-12">
      <section className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary/20 via-primary/5 to-background p-8 md:p-12">
        <div className="max-w-2xl space-y-6">
          <Badge variant="secondary" className="text-sm px-3 py-1">
            Featured Collection
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
            Discover, Collect & Sell Extraordinary NFTs
          </h1>
          <p className="text-lg text-muted-foreground max-w-lg">
            Nexus is the world&apos;s first and largest NFT marketplace. Browse collections, buy and sell NFTs, and join our thriving digital art community.
          </p>
          <div className="flex gap-3">
            <Link to="/explore">
              <Button size="lg" className="gap-2">
                Explore <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <Link to="/collection/c1">
              <Button size="lg" variant="outline">
                Top Collections
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <section>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard icon={TrendingUp} label="Total Volume" value={`${platformStats.totalVolume.toLocaleString()} ETH`} sub="All time" />
          <StatCard icon={BarChart3} label="Total Sales" value={platformStats.totalSales.toLocaleString()} sub="Transactions" />
          <StatCard icon={Users} label="Active Listings" value={platformStats.listedCount.toLocaleString()} sub="NFTs for sale" />
          <StatCard icon={Gem} label="Floor Price" value={`${platformStats.floorPrice} ETH`} sub="Market average" />
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Trending Collections</h2>
          <Link to="/collection/c1">
            <Button variant="ghost" className="gap-1">
              View All <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {collections.map((col) => (
            <Link key={col.id} to={`/collection/${col.id}`}>
              <Card className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer group">
                <div className="h-32 bg-muted relative">
                  <img src={col.bannerUrl} alt={col.name} className="w-full h-full object-cover" />
                </div>
                <CardContent className="p-4 relative">
                  <div className="absolute -top-6 left-4">
                    <Avatar className="h-12 w-12 border-2 border-background">
                      <AvatarImage src={col.logoUrl} />
                      <AvatarFallback>{col.name[0]}</AvatarFallback>
                    </Avatar>
                  </div>
                  <div className="pt-6">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold group-hover:text-primary transition-colors">{col.name}</h3>
                      {col.verified && (
                        <Badge variant="secondary" className="h-5 w-5 p-0 flex items-center justify-center text-[10px]">
                          ✓
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground capitalize">{col.category}</p>
                    <Separator className="my-3" />
                    <div className="flex justify-between text-sm">
                      <div>
                        <p className="text-muted-foreground text-xs">Floor</p>
                        <p className="font-medium">{col.floorPrice} ETH</p>
                      </div>
                      <div className="text-right">
                        <p className="text-muted-foreground text-xs">Volume</p>
                        <p className="font-medium">{col.totalVolume.toLocaleString()} ETH</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Notable NFTs</h2>
          <Link to="/explore">
            <Button variant="ghost" className="gap-1">
              View All <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {nfts.slice(0, 6).map((nft) => (
            <Link key={nft.id} to={`/nft/${nft.id}`}>
              <Card className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
                <div className="aspect-square bg-muted">
                  <img src={nft.imageUrl} alt={nft.name} className="w-full h-full object-cover" />
                </div>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <Avatar className="h-5 w-5">
                      <AvatarImage src={nft.collection.logoUrl} />
                      <AvatarFallback>{nft.collection.name[0]}</AvatarFallback>
                    </Avatar>
                    <span className="text-xs text-muted-foreground">{nft.collection.name}</span>
                  </div>
                  <h3 className="font-semibold">{nft.name}</h3>
                  <div className="flex justify-between items-center mt-2">
                    <div>
                      <p className="text-xs text-muted-foreground">{nft.isAuction ? "Current Bid" : "Price"}</p>
                      <p className="font-bold">{nft.price} {nft.currency}</p>
                    </div>
                    {nft.isAuction && <Badge variant="outline">Auction</Badge>}
                    {!nft.isAuction && <Badge variant="secondary">Buy Now</Badge>}
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-bold mb-6">Recent Activity</h2>
        <Card>
          <CardContent className="p-0">
            <div className="divide-y">
              {activities.map((activity) => (
                <div key={activity.id} className="flex items-center gap-4 p-4 hover:bg-muted/50 transition-colors">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={activity.from.avatarUrl} />
                    <AvatarFallback>{activity.from.displayName[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm">
                      <span className="font-medium">{activity.from.displayName}</span>
                      <span className="text-muted-foreground">
                        {" "}
                        {activity.type === "sale" && "sold"}
                        {activity.type === "bid" && "placed a bid on"}
                        {activity.type === "listing" && "listed"}
                        {activity.type === "transfer" && "transferred"}
                        {activity.type === "mint" && "minted"}
                      </span>
                      {" "}
                      <Link to={`/nft/${activity.nft.id}`} className="font-medium text-primary hover:underline truncate">
                        {activity.nft.name}
                      </Link>
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {formatDistanceToNow(new Date(activity.timestamp), { addSuffix: true })}
                    </p>
                  </div>
                  {activity.price && (
                    <div className="text-right">
                      <p className="font-bold text-sm">{activity.price} {activity.currency}</p>
                    </div>
                  )}
                  <Badge
                    variant={
                      activity.type === "sale" ? "default" :
                      activity.type === "bid" ? "secondary" :
                      activity.type === "listing" ? "outline" :
                      "secondary"
                    }
                  >
                    {activity.type}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  )
}
