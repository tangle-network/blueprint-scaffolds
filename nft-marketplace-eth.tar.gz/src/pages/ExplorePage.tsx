import { useState } from "react"
import { Link } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Search, SlidersHorizontal, Grid3X3, LayoutList } from "lucide-react"
import { nfts, collections } from "@/lib/data"
import type { CollectionCategory } from "@/lib/types"

const categories: { value: CollectionCategory | "all"; label: string }[] = [
  { value: "all", label: "All" },
  { value: "art", label: "Art" },
  { value: "gaming", label: "Gaming" },
  { value: "pfp", label: "PFP" },
  { value: "virtual-worlds", label: "Virtual Worlds" },
  { value: "photography", label: "Photography" },
  { value: "music", label: "Music" },
  { value: "collectibles", label: "Collectibles" },
]

export default function ExplorePage() {
  const [category, setCategory] = useState<CollectionCategory | "all">("all")
  const [search, setSearch] = useState("")

  const filteredNfts = nfts.filter((nft) => {
    const matchesCategory = category === "all" || nft.collection.category === category
    const matchesSearch = nft.name.toLowerCase().includes(search.toLowerCase()) ||
      nft.collection.name.toLowerCase().includes(search.toLowerCase())
    return matchesCategory && matchesSearch
  })

  const filteredCollections = collections.filter((col) => {
    const matchesCategory = category === "all" || col.category === category
    const matchesSearch = col.name.toLowerCase().includes(search.toLowerCase())
    return matchesCategory && matchesSearch
  })

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">Explore</h1>
        <p className="text-muted-foreground">Discover extraordinary NFTs across all collections</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by name, collection, or creator..."
            className="pl-9"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Button variant="outline" className="gap-2 shrink-0">
          <SlidersHorizontal className="h-4 w-4" />
          Filters
        </Button>
      </div>

      <div className="flex flex-wrap gap-2">
        {categories.map((cat) => (
          <Button
            key={cat.value}
            variant={category === cat.value ? "default" : "outline"}
            size="sm"
            onClick={() => setCategory(cat.value)}
          >
            {cat.label}
          </Button>
        ))}
      </div>

      <Tabs defaultValue="nfts">
        <div className="flex items-center justify-between">
          <TabsList>
            <TabsTrigger value="nfts">NFTs</TabsTrigger>
            <TabsTrigger value="collections">Collections</TabsTrigger>
          </TabsList>
          <div className="hidden sm:flex gap-1">
            <Button variant="ghost" size="icon"><Grid3X3 className="h-4 w-4" /></Button>
            <Button variant="ghost" size="icon"><LayoutList className="h-4 w-4" /></Button>
          </div>
        </div>

        <TabsContent value="nfts">
          {filteredNfts.length === 0 ? (
            <div className="text-center py-16">
              <p className="text-lg text-muted-foreground">No NFTs found matching your criteria</p>
              <Button variant="outline" className="mt-4" onClick={() => { setCategory("all"); setSearch("") }}>
                Clear Filters
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mt-6">
              {filteredNfts.map((nft) => (
                <Link key={nft.id} to={`/nft/${nft.id}`}>
                  <Card className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer group">
                    <div className="aspect-square bg-muted relative">
                      <img src={nft.imageUrl} alt={nft.name} className="w-full h-full object-cover" />
                      <div className="absolute top-2 right-2">
                        {nft.isAuction ? (
                          <Badge variant="default" className="text-xs">Auction</Badge>
                        ) : (
                          <Badge variant="secondary" className="text-xs">Buy Now</Badge>
                        )}
                      </div>
                      <div className="absolute bottom-2 left-2">
                        <Badge variant="outline" className="bg-background/80 text-xs">
                          #{nft.tokenId}
                        </Badge>
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-1">
                        <Avatar className="h-5 w-5">
                          <AvatarImage src={nft.collection.logoUrl} />
                          <AvatarFallback>{nft.collection.name[0]}</AvatarFallback>
                        </Avatar>
                        <span className="text-xs text-muted-foreground truncate">{nft.collection.name}</span>
                        {nft.collection.verified && (
                          <span className="text-primary text-xs">✓</span>
                        )}
                      </div>
                      <h3 className="font-semibold text-sm truncate group-hover:text-primary transition-colors">
                        {nft.name}
                      </h3>
                      <div className="flex justify-between items-end mt-3">
                        <div>
                          <p className="text-xs text-muted-foreground">
                            {nft.isAuction ? "Current Bid" : "Price"}
                          </p>
                          <p className="font-bold text-sm">{nft.price} {nft.currency}</p>
                        </div>
                        <Avatar className="h-6 w-6">
                          <AvatarImage src={nft.owner.avatarUrl} />
                          <AvatarFallback>{nft.owner.displayName[0]}</AvatarFallback>
                        </Avatar>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="collections">
          {filteredCollections.length === 0 ? (
            <div className="text-center py-16">
              <p className="text-lg text-muted-foreground">No collections found</p>
              <Button variant="outline" className="mt-4" onClick={() => { setCategory("all"); setSearch("") }}>
                Clear Filters
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mt-6">
              {filteredCollections.map((col) => (
                <Link key={col.id} to={`/collection/${col.id}`}>
                  <Card className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer group">
                    <div className="h-36 bg-muted relative">
                      <img src={col.bannerUrl} alt={col.name} className="w-full h-full object-cover" />
                      <div className="absolute -bottom-6 left-4">
                        <Avatar className="h-14 w-14 border-4 border-background">
                          <AvatarImage src={col.logoUrl} />
                          <AvatarFallback>{col.name[0]}</AvatarFallback>
                        </Avatar>
                      </div>
                    </div>
                    <CardContent className="pt-10 pb-4 px-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold group-hover:text-primary transition-colors">{col.name}</h3>
                            {col.verified && <span className="text-primary text-sm">✓</span>}
                          </div>
                          <p className="text-sm text-muted-foreground capitalize">{col.category} · {col.totalSupply.toLocaleString()} items</p>
                        </div>
                        <Badge variant="secondary" className="capitalize">{col.category}</Badge>
                      </div>
                      <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t">
                        <div>
                          <p className="text-xs text-muted-foreground">Floor</p>
                          <p className="font-semibold text-sm">{col.floorPrice} ETH</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Volume</p>
                          <p className="font-semibold text-sm">{col.totalVolume.toLocaleString()} ETH</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Owners</p>
                          <p className="font-semibold text-sm">{col.owners.toLocaleString()}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
