import { Link, useParams } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { ArrowLeft, Heart, Share2, ExternalLink, Clock, Shield, Tag } from "lucide-react"
import { nfts } from "@/lib/data"

export default function NFTDetailPage() {
  const { id } = useParams<{ id: string }>()
  const nft = nfts.find((n) => n.id === id) ?? nfts[0]

  return (
    <div className="space-y-8">
      <div>
        <Link to="/explore">
          <Button variant="ghost" size="sm" className="gap-1 mb-4">
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-4">
          <div className="rounded-xl overflow-hidden bg-muted">
            <img src={nft.imageUrl} alt={nft.name} className="w-full aspect-square object-cover" />
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="gap-2 flex-1">
              <Heart className="h-4 w-4" />
              Favorite
            </Button>
            <Button variant="outline" size="sm" className="gap-2 flex-1">
              <Share2 className="h-4 w-4" />
              Share
            </Button>
            <Button variant="outline" size="sm" className="gap-2 flex-1">
              <ExternalLink className="h-4 w-4" />
              Etherscan
            </Button>
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Avatar className="h-6 w-6">
                <AvatarImage src={nft.collection.logoUrl} />
                <AvatarFallback>{nft.collection.name[0]}</AvatarFallback>
              </Avatar>
              <Link to={`/collection/${nft.collection.id}`} className="text-sm text-primary hover:underline">
                {nft.collection.name}
              </Link>
              {nft.collection.verified && (
                <Badge variant="secondary" className="h-4 w-4 p-0 flex items-center justify-center text-[8px]">✓</Badge>
              )}
            </div>
            <h1 className="text-3xl font-bold">{nft.name}</h1>
            <p className="text-muted-foreground mt-2">{nft.description}</p>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Avatar className="h-8 w-8">
                <AvatarImage src={nft.owner.avatarUrl} />
                <AvatarFallback>{nft.owner.displayName[0]}</AvatarFallback>
              </Avatar>
              <div>
                <p className="text-xs text-muted-foreground">Owner</p>
                <p className="text-sm font-medium">{nft.owner.displayName}</p>
              </div>
            </div>
            <Separator orientation="vertical" className="h-10" />
            <div className="flex items-center gap-2">
              <Avatar className="h-8 w-8">
                <AvatarImage src={nft.creator.avatarUrl} />
                <AvatarFallback>{nft.creator.displayName[0]}</AvatarFallback>
              </Avatar>
              <div>
                <p className="text-xs text-muted-foreground">Creator</p>
                <p className="text-sm font-medium">{nft.creator.displayName}</p>
              </div>
            </div>
          </div>

          <Separator />

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    {nft.isAuction ? <Clock className="h-4 w-4" /> : <Tag className="h-4 w-4" />}
                    {nft.isAuction ? "Current Bid" : "Price"}
                  </div>
                  <p className="text-3xl font-bold mt-1">
                    {nft.isAuction ? (nft.highestBid ?? nft.price) : nft.price} {nft.currency}
                  </p>
                  {nft.lastSalePrice && (
                    <p className="text-sm text-muted-foreground mt-1">
                      Last sale: {nft.lastSalePrice} {nft.currency}
                    </p>
                  )}
                </div>
                <div className="text-right">
                  {nft.isAuction && nft.auctionEndsAt && (
                    <div className="mb-2">
                      <p className="text-xs text-muted-foreground">Ends in</p>
                      <p className="text-sm font-medium">
                        {new Date(nft.auctionEndsAt).toLocaleDateString()}
                      </p>
                    </div>
                  )}
                  <Button size="lg" className="gap-2">
                    {nft.isAuction ? "Place Bid" : "Buy Now"}
                  </Button>
                </div>
              </div>
              {nft.isAuction && nft.highestBidder && (
                <div className="mt-4 pt-4 border-t flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">Highest bidder:</span>
                  <Avatar className="h-5 w-5">
                    <AvatarImage src={nft.highestBidder.avatarUrl} />
                    <AvatarFallback>{nft.highestBidder.displayName[0]}</AvatarFallback>
                  </Avatar>
                  <span className="text-sm font-medium">{nft.highestBidder.displayName}</span>
                </div>
              )}
            </CardContent>
          </Card>

          <Tabs defaultValue="attributes">
            <TabsList>
              <TabsTrigger value="attributes">Attributes</TabsTrigger>
              <TabsTrigger value="details">Details</TabsTrigger>
            </TabsList>

            <TabsContent value="attributes">
              <div className="grid grid-cols-2 gap-3 mt-2">
                {nft.attributes.map((attr, i) => (
                  <Card key={i}>
                    <CardContent className="p-3">
                      <p className="text-xs text-primary font-medium">{attr.traitType}</p>
                      <p className="text-sm font-semibold mt-1">{attr.value}</p>
                      <p className="text-xs text-muted-foreground mt-1">{attr.rarity}% have this</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="details">
              <Card className="mt-2">
                <CardContent className="p-4 space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Contract Address</span>
                    <span className="text-sm font-mono">0x1a2b...ef12</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Token ID</span>
                    <span className="text-sm font-mono">{nft.tokenId}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Blockchain</span>
                    <span className="text-sm">Ethereum</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Token Standard</span>
                    <span className="text-sm">ERC-721</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Created</span>
                    <span className="text-sm">{new Date(nft.createdAt).toLocaleDateString()}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Rarity Rank</span>
                    <div className="flex items-center gap-1">
                      <Shield className="h-3 w-3 text-primary" />
                      <span className="text-sm font-medium">#{nft.rarity}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
