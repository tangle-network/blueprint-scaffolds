const RESERVOIR_API_KEY = import.meta.env.VITE_RESERVOIR_API_KEY || '';
const RESERVOIR_BASE = 'https://api.reservoir.tools';

async function reservoirFetch(endpoint: string, params: Record<string, string> = {}) {
  const url = new URL(`${RESERVOIR_BASE}${endpoint}`);
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (RESERVOIR_API_KEY) headers['x-api-key'] = RESERVOIR_API_KEY;
  const res = await fetch(url.toString(), { headers });
  if (!res.ok) throw new Error(`Reservoir API error: ${res.status}`);
  return res.json();
}

export async function getCollectionStats(collection: string) {
  return reservoirFetch('/collection/v4', { collection, includeTopBid: 'true' });
}

export async function getCollectionListings(collection: string, limit = 20) {
  return reservoirFetch('/listings/v4', { collection, limit: String(limit) });
}

export async function getCollectionOffers(collection: string, limit = 20) {
  return reservoirFetch('/offers/v3', { collection, limit: String(limit) });
}

export async function getTokens(contract: string, limit = 20) {
  return reservoirFetch('/tokens/v5', { contract, limit: String(limit) });
}

export async function getSalesActivity(collection: string, limit = 20) {
  return reservoirFetch('/sales/v3', { collection, limit: String(limit) });
}

export async function getFloorSweepListings(collection: string, maxPrice: string, count: number) {
  return reservoirFetch('/listings/v4', {
    collection,
    maxPrice,
    limit: String(count),
    sort: 'price',
    orderBy: 'asc',
  });
}
