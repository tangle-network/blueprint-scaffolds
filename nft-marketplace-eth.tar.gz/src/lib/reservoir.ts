import type { NFTAsset } from '../types';

export interface ReservoirOrder {
  id: string;
  source: 'reservoir';
  kind: 'listing' | 'offer';
  weiPrice: string;
  token: string;
}

export const reservoirEndpoint = 'https://api.reservoir.tools/orders/v5';

export const mapAssetToReservoirOrder = (asset: NFTAsset): ReservoirOrder => ({
  id: `axis-${asset.id}`,
  source: 'reservoir',
  kind: asset.saleType === 'Offer' ? 'offer' : 'listing',
  weiPrice: BigInt(Math.round(asset.price * 1e6)) * 1000000000000n + '',
  token: asset.tokenId,
});
