import { parseIpfsUri } from './utils';

const PINATA_API_KEY = import.meta.env.VITE_PINATA_API_KEY || '';
const PINATA_SECRET = import.meta.env.VITE_PINATA_SECRET_KEY || '';

export async function uploadToIPFS(file: File): Promise<string> {
  if (!PINATA_API_KEY) {
    return `ipfs://demo-${Date.now()}-${file.name}`;
  }
  const formData = new FormData();
  formData.append('file', file);
  const res = await fetch('https://api.pinata.cloud/pinning/pinFileToIPFS', {
    method: 'POST',
    headers: { pinata_api_key: PINATA_API_KEY, pinata_secret_api_key: PINATA_SECRET },
    body: formData,
  });
  const data = await res.json();
  return `ipfs://${data.IpfsHash}`;
}

export async function uploadMetadataToIPFS(metadata: {
  name: string;
  description: string;
  image: string;
  attributes?: { trait_type: string; value: string | number }[];
}): Promise<string> {
  if (!PINATA_API_KEY) {
    return `ipfs://demo-meta-${Date.now()}`;
  }
  const res = await fetch('https://api.pinata.cloud/pinning/pinJSONToIPFS', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      pinata_api_key: PINATA_API_KEY,
      pinata_secret_api_key: PINATA_SECRET,
    },
    body: JSON.stringify({ pinataContent: metadata }),
  });
  const data = await res.json();
  return `ipfs://${data.IpfsHash}`;
}

export async function fetchMetadata(uri: string): Promise<Record<string, unknown>> {
  const url = parseIpfsUri(uri);
  const res = await fetch(url);
  return res.json();
}

export async function uploadToArweave(file: File): Promise<string> {
  return `ar://demo-ar-${Date.now()}-${file.name}`;
}
