import type { StorageProvider } from '../types';

export interface MetadataPayload {
  name: string;
  description: string;
  image: string;
  attributes: Array<{ trait_type: string; value: string }>;
}

export const buildMetadataUri = (provider: StorageProvider, cid: string) =>
  provider === 'IPFS' ? `https://ipfs.io/ipfs/${cid}` : `https://arweave.net/${cid}`;

export const prepareLazyMintPayload = (
  provider: StorageProvider,
  cid: string,
  payload: MetadataPayload,
) => ({
  provider,
  cid,
  metadataUri: buildMetadataUri(provider, cid),
  payload,
  signedVoucherDomain: 'axis.market',
});
