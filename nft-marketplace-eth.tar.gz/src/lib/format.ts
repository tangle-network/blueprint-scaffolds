export const formatEth = (value: number) =>
  `${value.toLocaleString('en-US', {
    minimumFractionDigits: value < 10 ? 2 : 0,
    maximumFractionDigits: 2,
  })} ETH`;

export const formatUsd = (value: number, ethUsd = 3420) =>
  `$${(value * ethUsd).toLocaleString('en-US', {
    maximumFractionDigits: 0,
  })}`;

export const formatBps = (bps: number) => `${(bps / 100).toFixed(2)}%`;

export const shortenAddress = (value: string) =>
  value.length > 10 ? `${value.slice(0, 6)}...${value.slice(-4)}` : value;

export const formatDate = (value: string) =>
  new Date(value).toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  });
