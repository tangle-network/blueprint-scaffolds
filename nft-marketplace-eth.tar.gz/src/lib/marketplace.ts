import { assets, bundles, collections, offers } from '../data/mockData';
import type { Bundle, Collection, NFTAsset, Offer } from '../types';

export const getCollection = (collectionId: string): Collection | undefined =>
  collections.find((collection) => collection.id === collectionId);

export const getAssetOffers = (assetId: string): Offer[] =>
  offers.filter((offer) => offer.assetId === assetId);

export const getCollectionOffers = (collectionId: string): Offer[] =>
  offers.filter((offer) => offer.collectionId === collectionId);

export const getBundleAssets = (bundle: Bundle): NFTAsset[] =>
  bundle.assetIds
    .map((assetId) => assets.find((asset) => asset.id === assetId))
    .filter((asset): asset is NFTAsset => Boolean(asset));

export const getSweepTargets = (collectionId: string, limit: number) =>
  assets
    .filter((asset) => asset.collectionId === collectionId && asset.saleType !== 'Offer')
    .sort((left, right) => left.price - right.price)
    .slice(0, limit);

export const computeMarketplaceStats = () => {
  const totalVolume = collections.reduce((sum, collection) => sum + collection.volume, 0);
  const floorOpportunities = collections.reduce((sum, collection) => sum + collection.floor, 0);
  const activeListings = assets.filter((asset) => asset.saleType !== 'Offer').length;

  return {
    totalVolume,
    floorOpportunities,
    activeListings,
    activeOffers: offers.length,
    bundleCount: bundles.length,
    lazyMintCount: assets.filter((asset) => asset.lazyMinted).length,
  };
};
