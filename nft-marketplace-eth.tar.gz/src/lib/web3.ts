import { ethers } from 'ethers';

let provider: ethers.BrowserProvider | null = null;
let signer: ethers.JsonRpcSigner | null = null;

export async function getProvider(): Promise<ethers.BrowserProvider> {
  if (!provider && typeof window !== 'undefined' && window.ethereum) {
    provider = new ethers.BrowserProvider(window.ethereum);
  }
  if (!provider) throw new Error('No Ethereum provider found');
  return provider;
}

export async function getSigner(): Promise<ethers.JsonRpcSigner> {
  if (!signer) {
    const p = await getProvider();
    signer = await p.getSigner();
  }
  return signer;
}

export function getReadOnlyProvider(): ethers.JsonRpcProvider {
  return new ethers.JsonRpcProvider(import.meta.env.VITE_RPC_URL || 'https://mainnet.infura.io/v3/demo');
}

export const MARKETPLACE_ADDRESS = import.meta.env.VITE_MARKETPLACE_ADDRESS || '0x0000000000000000000000000000000000000001';
export const AUCTION_ADDRESS = import.meta.env.VITE_AUCTION_ADDRESS || '0x0000000000000000000000000000000000000002';
export const ROYALTY_ADDRESS = import.meta.env.VITE_ROYALTY_ADDRESS || '0x0000000000000000000000000000000000000003';
export const ESCROW_ADDRESS = import.meta.env.VITE_ESCROW_ADDRESS || '0x0000000000000000000000000000000000000004';

export const ERC721_ABI = [
  'function name() view returns (string)',
  'function symbol() view returns (string)',
  'function tokenURI(uint256 tokenId) view returns (string)',
  'function ownerOf(uint256 tokenId) view returns (address)',
  'function balanceOf(address owner) view returns (uint256)',
  'function isApprovedForAll(address owner, address operator) view returns (bool)',
  'function setApprovalForAll(address operator, bool approved)',
  'function safeTransferFrom(address from, address to, uint256 tokenId)',
];

export const MARKETPLACE_ABI = [
  'function listItem(address nftContract, uint256 tokenId, uint256 price, address currency, uint256 expiresAt) returns (uint256)',
  'function buyItem(uint256 listingId) payable',
  'function cancelListing(uint256 listingId)',
  'function updateListing(uint256 listingId, uint256 newPrice)',
  'function batchBuy(uint256[] calldata listingIds) payable',
  'function sweepFloor(address collection, uint256 maxPrice, uint256 maxCount) payable',
  'function makeOffer(address nftContract, uint256 tokenId, uint256 price, address currency, uint256 expiresAt) returns (uint256)',
  'function makeCollectionOffer(address collection, uint256 price, address currency, uint256 expiresAt) returns (uint256)',
  'function acceptOffer(uint256 offerId)',
  'function cancelOffer(uint256 offerId)',
  'function createBundle(address[] calldata nftContracts, uint256[] calldata tokenIds, uint256 price, address currency, uint256 expiresAt) returns (uint256)',
  'function buyBundle(uint256 bundleId) payable',
  'function lazyMintAndBuy(address nftContract, uint256 tokenId, string calldata uri, address creator, uint256 price, uint256 royaltyBps, bytes calldata signature) payable',
  'event ListItem(uint256 indexed listingId, address indexed seller, address nftContract, uint256 tokenId, uint256 price)',
  'event BuyItem(uint256 indexed listingId, address indexed buyer, uint256 price)',
  'event CancelListing(uint256 indexed listingId)',
  'event MakeOffer(uint256 indexed offerId, address indexed bidder, address nftContract, uint256 tokenId, uint256 price)',
];

export const AUCTION_ABI = [
  'function createEnglishAuction(address nftContract, uint256 tokenId, uint256 startPrice, uint256 endTime, uint256 minBidIncrement) returns (uint256)',
  'function createDutchAuction(address nftContract, uint256 tokenId, uint256 startPrice, uint256 endPrice, uint256 endTime) returns (uint256)',
  'function bid(uint256 auctionId) payable',
  'function settle(uint256 auctionId)',
  'function cancelAuction(uint256 auctionId)',
  'function getAuction(uint256 auctionId) view returns (tuple(address seller, address nftContract, uint256 tokenId, uint256 startPrice, uint256 endPrice, uint256 currentBid, address highestBidder, uint256 startTime, uint256 endTime, uint8 auctionType, uint8 status))',
  'function getCurrentPrice(uint256 auctionId) view returns (uint256)',
  'event AuctionCreated(uint256 indexed auctionId, address indexed seller, uint8 auctionType)',
  'event BidPlaced(uint256 indexed auctionId, address indexed bidder, uint256 amount)',
  'event AuctionSettled(uint256 indexed auctionId, address winner, uint256 finalPrice)',
];

export const ROYALTY_ABI = [
  'function registerRoyalty(address collection, address recipient, uint256 bps)',
  'function updateRoyalty(address collection, address recipient, uint256 bps)',
  'function getRoyalty(address collection) view returns (address recipient, uint256 bps)',
  'function calculateRoyalty(address collection, uint256 salePrice) view returns (address recipient, uint256 amount)',
  'event RoyaltyRegistered(address indexed collection, address recipient, uint256 bps)',
];

export const ESCROW_ABI = [
  'function deposit(address token, uint256 amount)',
  'function withdraw(address token, uint256 amount)',
  'function getBalance(address user, address token) view returns (uint256)',
  'function lockForAuction(uint256 auctionId, address nftContract, uint256 tokenId)',
  'function releaseToBuyer(uint256 auctionId, address buyer)',
  'event Deposited(address indexed user, address token, uint256 amount)',
  'event Withdrawn(address indexed user, address token, uint256 amount)',
];

export function getMarketplaceContract(signerOrProvider: ethers.Signer | ethers.Provider) {
  return new ethers.Contract(MARKETPLACE_ADDRESS, MARKETPLACE_ABI, signerOrProvider);
}

export function getAuctionContract(signerOrProvider: ethers.Signer | ethers.Provider) {
  return new ethers.Contract(AUCTION_ADDRESS, AUCTION_ABI, signerOrProvider);
}

export function getRoyaltyContract(signerOrProvider: ethers.Signer | ethers.Provider) {
  return new ethers.Contract(ROYALTY_ADDRESS, ROYALTY_ABI, signerOrProvider);
}

export function getEscrowContract(signerOrProvider: ethers.Signer | ethers.Provider) {
  return new ethers.Contract(ESCROW_ADDRESS, ESCROW_ABI, signerOrProvider);
}

export function getNFTContract(address: string, signerOrProvider: ethers.Signer | ethers.Provider) {
  return new ethers.Contract(address, ERC721_ABI, signerOrProvider);
}

declare global {
  interface Window {
    ethereum?: {
      isMetaMask?: boolean;
      request: (args: { method: string; params?: unknown[] }) => Promise<unknown>;
      on: (event: string, handler: (...args: unknown[]) => void) => void;
      removeListener: (event: string, handler: (...args: unknown[]) => void) => void;
    };
  }
}
