export interface User {
  id: string
  address: string
  displayName: string
  avatarUrl: string
  bio: string
  joinedAt: string
  verified: boolean
}

export interface Collection {
  id: string
  name: string
  description: string
  bannerUrl: string
  logoUrl: string
  creator: User
  floorPrice: number
  totalVolume: number
  totalSupply: number
  owners: number
  createdAt: string
  category: CollectionCategory
  verified: boolean
}

export type CollectionCategory =
  | "art"
  | "photography"
  | "gaming"
  | "music"
  | "virtual-worlds"
  | "pfp"
  | "collectibles"

export interface NFT {
  id: string
  name: string
  description: string
  imageUrl: string
  collection: Collection
  owner: User
  creator: User
  price: number
  lastSalePrice: number | null
  currency: string
  tokenId: string
  createdAt: string
  attributes: NFTAttribute[]
  rarity: number
  isAuction: boolean
  auctionEndsAt: string | null
  highestBid: number | null
  highestBidder: User | null
}

export interface NFTAttribute {
  traitType: string
  value: string
  rarity: number
}

export interface Listing {
  id: string
  nft: NFT
  seller: User
  price: number
  currency: string
  listedAt: string
  expiresAt: string
  type: "fixed" | "auction"
}

export interface Activity {
  id: string
  type: "sale" | "listing" | "bid" | "transfer" | "mint"
  nft: NFT
  from: User
  to: User
  price: number | null
  currency: string
  timestamp: string
  txHash: string
}

export interface Bid {
  id: string
  bidder: User
  amount: number
  currency: string
  placedAt: string
}

export interface Stats {
  totalVolume: number
  totalSales: number
  averagePrice: number
  floorPrice: number
  listedCount: number
}
