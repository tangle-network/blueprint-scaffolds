import { Gavel, Gem, Layers3, ShieldCheck, ShoppingCart, Sparkles } from 'lucide-react';
import { CreatorDashboard } from './components/CreatorDashboard';
import { GallerySection } from './components/GallerySection';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { MarketStats } from './components/MarketStats';
import { TradingDesk } from './components/TradingDesk';

const highlights = [
  {
    title: 'Fixed + Auction Liquidity',
    description: 'Run fixed-price, English, and Dutch sales from the same order book.',
    icon: Gavel,
  },
  {
    title: 'Sweep Floor Routing',
    description: 'Batch buy cheapest listings with royalty-aware settlement.',
    icon: ShoppingCart,
  },
  {
    title: 'Collection Offers',
    description: 'Post contract-backed offers across a full collection or selected traits.',
    icon: Layers3,
  },
  {
    title: 'Lazy Minting',
    description: 'Mint on purchase using signed vouchers and mirrored IPFS/Arweave metadata.',
    icon: Sparkles,
  },
  {
    title: 'Royalty Enforcement',
    description: 'Registry-backed royalties settle atomically through escrow.',
    icon: ShieldCheck,
  },
  {
    title: 'Bundle Sales',
    description: 'List and settle multiple NFTs in one transaction with creator splits preserved.',
    icon: Gem,
  },
];

export default function App() {
  return (
    <div className="app-shell">
      <Header />
      <main>
        <Hero />
        <MarketStats />

        <section className="feature-strip" aria-label="Marketplace capabilities">
          {highlights.map((item) => (
            <article className="feature-card" key={item.title}>
              <item.icon size={18} />
              <div>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </article>
          ))}
        </section>

        <GallerySection />
        <TradingDesk />
        <CreatorDashboard />
      </main>
    </div>
  );
}
