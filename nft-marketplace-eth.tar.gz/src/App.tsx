import { BrowserRouter, Routes, Route } from "react-router-dom"
import Navbar from "@/components/Navbar"
import HomePage from "@/pages/HomePage"
import ExplorePage from "@/pages/ExplorePage"
import CollectionPage from "@/pages/CollectionPage"
import NFTDetailPage from "@/pages/NFTDetailPage"

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-background text-foreground">
        <Navbar />
        <main className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/explore" element={<ExplorePage />} />
            <Route path="/collection/:id" element={<CollectionPage />} />
            <Route path="/nft/:id" element={<NFTDetailPage />} />
          </Routes>
        </main>
        <footer className="border-t mt-16">
          <div className="container mx-auto px-4 py-8">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="h-6 w-6 rounded bg-primary flex items-center justify-center">
                  <span className="text-primary-foreground font-bold text-xs">NFT</span>
                </div>
                <span className="font-semibold">Nexus Marketplace</span>
              </div>
              <p className="text-sm text-muted-foreground">
                The world&apos;s first and largest digital marketplace for crypto collectibles and non-fungible tokens.
              </p>
              <p className="text-sm text-muted-foreground">
                &copy; 2024 Nexus. All rights reserved.
              </p>
            </div>
          </div>
        </footer>
      </div>
    </BrowserRouter>
  )
}
