/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_RPC_URL: string;
  readonly VITE_MARKETPLACE_ADDRESS: string;
  readonly VITE_AUCTION_ADDRESS: string;
  readonly VITE_ROYALTY_ADDRESS: string;
  readonly VITE_ESCROW_ADDRESS: string;
  readonly VITE_PINATA_API_KEY: string;
  readonly VITE_PINATA_SECRET_KEY: string;
  readonly VITE_RESERVOIR_API_KEY: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
