export interface NFTItem {
  tokenId: string;
  contractAddress: string;
  name: string;
  description: string;
  image: string;
  owner: string;
  creator: string;
  collection: string;
  attributes: NFTAttribute[];
  tokenURI: string;
  royaltyBps: number;
}

export interface NFTAttribute {
  trait_type: string;
  value: string | number;
  display_type?: string;
}

export interface Collection {
  address: string;
  name: string;
  description: string;
  image: string;
  banner?: string;
  owner: string;
  floorPrice?: string;
  totalSupply: number;
  volume?: string;
  royaltyBps: number;
}

export interface Listing {
  id: string;
  nft: NFTItem;
  seller: string;
  price: string;
  currency: string;
  createdAt: number;
  expiresAt: number;
  status: ListingStatus;
}

export enum ListingStatus {
  Active = 'active',
  Cancelled = 'cancelled',
  Sold = 'sold',
  Expired = 'expired',
}

export interface Auction {
  id: string;
  nft: NFTItem;
  seller: string;
  type: AuctionType;
  startPrice: string;
  endPrice?: string;
  currentBid?: string;
  highestBidder?: string;
  startTime: number;
  endTime: number;
  minBidIncrement?: string;
  status: AuctionStatus;
}

export enum AuctionType {
  English = 'english',
  Dutch = 'dutch',
}

export enum AuctionStatus {
  Active = 'active',
  Ended = 'ended',
  Cancelled = 'cancelled',
}

export interface Offer {
  id: string;
  nft?: NFTItem;
  collection?: string;
  bidder: string;
  price: string;
  currency: string;
  expiresAt: number;
  status: OfferStatus;
  type: OfferType;
}

export enum OfferStatus {
  Active = 'active',
  Accepted = 'accepted',
  Cancelled = 'cancelled',
  Expired = 'expired',
}

export enum OfferType {
  Item = 'item',
  Collection = 'collection',
}

export interface BundleListing {
  id: string;
  nfts: NFTItem[];
  seller: string;
  price: string;
  currency: string;
  createdAt: number;
  expiresAt: number;
  status: ListingStatus;
}

export interface LazyMintEntry {
  tokenId: string;
  contractAddress: string;
  creator: string;
  uri: string;
  price: string;
  signature: string;
  royaltyBps: number;
}

export interface RoyaltyInfo {
  recipient: string;
  bps: number;
}

export interface Transaction {
  hash: string;
  from: string;
  to: string;
  value: string;
  type: string;
  timestamp: number;
}

export interface DashboardStats {
  totalVolume: string;
  totalSales: number;
  totalListings: number;
  floorPrice: string;
  uniqueOwners: number;
}

export type SortOption = 'price_asc' | 'price_desc' | 'recent' | 'ending_soon' | 'rarity';
