import { assets, bundles, collections, contracts } from '../data/mockData';
import { computeMarketplaceStats } from '../lib/marketplace';
import { formatBps, formatEth, shortenAddress } from '../lib/format';

export function MarketStats() {
  const stats = computeMarketplaceStats();

  return (
    <section className="stats-panel">
      <div className="stats-grid">
        <article>
          <span>Collection volume</span>
          <strong>{formatEth(stats.totalVolume)}</strong>
        </article>
        <article>
          <span>Active listings</span>
          <strong>{stats.activeListings}</strong>
        </article>
        <article>
          <span>Open offers</span>
          <strong>{stats.activeOffers}</strong>
        </article>
        <article>
          <span>Lazy mint drops</span>
          <strong>{stats.lazyMintCount}</strong>
        </article>
      </div>

      <div className="stat-columns">
        <div className="panel">
          <div className="section-heading">
            <h3>Contract stack</h3>
            <span>{contracts.length} deployed modules</span>
          </div>
          {contracts.map((contract) => (
            <div className="line-item" key={contract.name}>
              <div>
                <strong>{contract.name}</strong>
                <span>{shortenAddress(contract.address)}</span>
              </div>
              <p>{contract.responsibilities[0]}</p>
            </div>
          ))}
        </div>

        <div className="panel">
          <div className="section-heading">
            <h3>Collections</h3>
            <span>{collections.length} tracked sets</span>
          </div>
          {collections.map((collection) => (
            <div className="line-item" key={collection.id}>
              <div>
                <strong>{collection.name}</strong>
                <span>{formatBps(collection.royaltyBps)} royalties</span>
              </div>
              <p>
                Floor {formatEth(collection.floor)} • {collection.items} items • creator{' '}
                {shortenAddress(collection.creator)}
              </p>
            </div>
          ))}
        </div>

        <div className="panel">
          <div className="section-heading">
            <h3>Inventory mix</h3>
            <span>{assets.length + bundles.length} tradeable units</span>
          </div>
          <div className="pill-row">
            {['Fixed', 'English', 'Dutch', 'Offer', 'Bundle'].map((saleType) => (
              <span className="pill" key={saleType}>
                {saleType}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
