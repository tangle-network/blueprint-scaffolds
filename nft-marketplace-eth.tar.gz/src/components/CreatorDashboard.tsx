import { contracts, storageRecords } from '../data/mockData';
import { prepareLazyMintPayload } from '../lib/storage';

const voucher = prepareLazyMintPayload('IPFS', 'bafybeiclazybatch', {
  name: 'Vector Bloom Genesis Voucher',
  description: 'Signed lazy mint payload for creator-authorized primary sale.',
  image: 'ipfs://bafybeiclazybatch/image.png',
  attributes: [
    { trait_type: 'Edition', value: 'Genesis' },
    { trait_type: 'Drop', value: 'Spring' },
  ],
});

export function CreatorDashboard() {
  return (
    <section className="dashboard-grid" id="creator">
      <div className="section-copy">
        <span className="eyebrow">Creator Dashboard</span>
        <h2>Manage royalty enforcement, escrow, storage replication, and lazy mint vouchers.</h2>
      </div>

      <article className="panel">
        <div className="section-heading">
          <h3>Royalty + escrow controls</h3>
          <span>Settlement stack</span>
        </div>
        {contracts.map((contract) => (
          <div className="line-item" key={contract.name}>
            <div>
              <strong>{contract.name}</strong>
              <span>{contract.address}</span>
            </div>
            <p>{contract.responsibilities[1]}</p>
          </div>
        ))}
      </article>

      <article className="panel">
        <div className="section-heading">
          <h3>Storage mirrors</h3>
          <span>IPFS / Arweave</span>
        </div>
        {storageRecords.map((record) => (
          <div className="line-item" key={record.provider + record.cid}>
            <div>
              <strong>{record.provider}</strong>
              <span>{record.status}</span>
            </div>
            <p>{record.uri}</p>
          </div>
        ))}
      </article>

      <article className="panel">
        <div className="section-heading">
          <h3>Lazy mint voucher</h3>
          <span>{voucher.provider}</span>
        </div>
        <div className="voucher-card">
          <span>Metadata URI</span>
          <strong>{voucher.metadataUri}</strong>
          <span>Signed domain</span>
          <strong>{voucher.signedVoucherDomain}</strong>
        </div>
      </article>
    </section>
  );
}
