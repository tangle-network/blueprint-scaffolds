import { bundles, offers } from '../data/mockData';
import { formatDate, formatEth, formatUsd } from '../lib/format';
import {
  getAssetOffers,
  getBundleAssets,
  getCollection,
  getCollectionOffers,
  getSweepTargets,
} from '../lib/marketplace';
import { mapAssetToReservoirOrder, reservoirEndpoint } from '../lib/reservoir';

export function TradingDesk() {
  const sweepTargets = getSweepTargets('signal', 2);
  const collectionOffers = getCollectionOffers('signal');
  const bundle = bundles[0];
  const bundleAssets = getBundleAssets(bundle);
  const reservoirPreview = mapAssetToReservoirOrder(sweepTargets[0]);

  return (
    <section className="trading-panel" id="trading">
      <div className="section-copy">
        <span className="eyebrow">Trading UI</span>
        <h2>Execute single buys, bundle purchases, collection offers, and floor sweeps from one desk.</h2>
      </div>

      <div className="trading-grid">
        <article className="panel">
          <div className="section-heading">
            <h3>Sweep Floor</h3>
            <span>{getCollection('signal')?.name}</span>
          </div>
          {sweepTargets.map((asset) => (
            <div className="line-item" key={asset.id}>
              <div>
                <strong>{asset.name}</strong>
                <span>{asset.saleType}</span>
              </div>
              <p>
                {formatEth(asset.price)} / {formatUsd(asset.price)}
              </p>
            </div>
          ))}
          <div className="callout">
            <strong>Route preview</strong>
            <p>
              Reservoir order {reservoirPreview.id} mapped against {reservoirEndpoint} with royalty-aware settlement.
            </p>
          </div>
        </article>

        <article className="panel">
          <div className="section-heading">
            <h3>Collection Offers</h3>
            <span>{collectionOffers.length} active bids</span>
          </div>
          {collectionOffers.map((offer) => (
            <div className="line-item" key={offer.id}>
              <div>
                <strong>{offer.bidder}</strong>
                <span>{offer.quantity} tokens target</span>
              </div>
              <p>
                {formatEth(offer.amount)} until {formatDate(offer.expiresAt)}
              </p>
            </div>
          ))}
        </article>

        <article className="panel">
          <div className="section-heading">
            <h3>Bundle Sale</h3>
            <span>{bundle.label}</span>
          </div>
          {bundleAssets.map((asset) => (
            <div className="line-item" key={asset.id}>
              <div>
                <strong>{asset.name}</strong>
                <span>{getAssetOffers(asset.id).length} direct offers</span>
              </div>
              <p>{formatEth(asset.price)}</p>
            </div>
          ))}
          <div className="callout">
            <strong>{formatEth(bundle.listPrice)}</strong>
            <p>{bundle.discountPct}% discount versus individual asks.</p>
          </div>
        </article>

        <article className="panel">
          <div className="section-heading">
            <h3>Offer ladder</h3>
            <span>{offers.length} pending</span>
          </div>
          {offers.map((offer) => (
            <div className="line-item" key={offer.id}>
              <div>
                <strong>{offer.collectionId ?? offer.assetId}</strong>
                <span>{offer.quantity ? `${offer.quantity} units` : 'Single asset'}</span>
              </div>
              <p>{formatEth(offer.amount)}</p>
            </div>
          ))}
        </article>
      </div>
    </section>
  );
}
