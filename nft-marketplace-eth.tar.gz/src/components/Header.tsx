export function Header() {
  return (
    <header className="topbar">
      <div>
        <span className="eyebrow">Axis Market</span>
        <h1>Ethereum marketplace infrastructure for active NFT trading.</h1>
      </div>
      <nav className="topnav" aria-label="Primary">
        <a href="#gallery">Gallery</a>
        <a href="#trading">Trading UI</a>
        <a href="#creator">Creator Dashboard</a>
      </nav>
    </header>
  );
}
