import { assets } from '../data/mockData';
import { formatBps, formatEth } from '../lib/format';
import { getCollection } from '../lib/marketplace';

export function GallerySection() {
  return (
    <section className="section-grid" id="gallery">
      <div className="section-copy">
        <span className="eyebrow">Gallery</span>
        <h2>Trade across fixed-price listings, auctions, and offer-only inventory.</h2>
        <p>
          Each card exposes settlement style, royalties, and lazy mint status so buyers can move from discovery to execution without switching screens.
        </p>
      </div>

      <div className="gallery-grid">
        {assets.map((asset) => {
          const collection = getCollection(asset.collectionId);
          return (
            <article className="asset-card" key={asset.id}>
              <img src={asset.image} alt={asset.name} />
              <div className="asset-body">
                <div className="asset-header">
                  <div>
                    <span>{collection?.name}</span>
                    <h3>{asset.name}</h3>
                  </div>
                  <span className="pill">{asset.saleType}</span>
                </div>
                <div className="trait-row">
                  {asset.traits.map((trait) => (
                    <span key={trait.label + trait.value}>
                      {trait.label}: {trait.value}
                    </span>
                  ))}
                </div>
                <div className="asset-footer">
                  <div>
                    <span>Ask</span>
                    <strong>{formatEth(asset.price)}</strong>
                  </div>
                  <div>
                    <span>Royalty</span>
                    <strong>{formatBps(asset.royaltyBps)}</strong>
                  </div>
                  <div>
                    <span>Status</span>
                    <strong>{asset.lazyMinted ? 'Lazy mint' : 'Live token'}</strong>
                  </div>
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}
