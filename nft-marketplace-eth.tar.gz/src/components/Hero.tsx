import { ArrowUpRight, Database, Wallet } from 'lucide-react';

export function Hero() {
  return (
    <section className="hero-panel">
      <div className="hero-copy">
        <span className="eyebrow">Built for Ethereum</span>
        <h2>Listings, auctions, offers, sweep floor, lazy minting, and creator royalty compliance in one trading surface.</h2>
        <p>
          Axis Market combines a marketplace core, auction house, escrow vault, and royalty registry
          with mirrored IPFS/Arweave storage plus Reservoir order intake.
        </p>
        <div className="hero-actions">
          <button type="button">Launch Trading</button>
          <button type="button" className="secondary">
            View Contract Map
          </button>
        </div>
      </div>

      <div className="hero-grid">
        <article className="metric-card">
          <Wallet size={18} />
          <span>Wallet routing</span>
          <strong>Batch buy + escrow settlement</strong>
        </article>
        <article className="metric-card">
          <ArrowUpRight size={18} />
          <span>Auctions</span>
          <strong>English / Dutch execution rails</strong>
        </article>
        <article className="metric-card">
          <Database size={18} />
          <span>Storage</span>
          <strong>IPFS + Arweave mirrored metadata</strong>
        </article>
      </div>
    </section>
  );
}
