export type SaleType = 'Fixed' | 'English' | 'Dutch' | 'Offer' | 'Bundle';
export type StorageProvider = 'IPFS' | 'Arweave';

export interface Collection {
  id: string;
  name: string;
  creator: string;
  floor: number;
  volume: number;
  royaltyBps: number;
  items: number;
}

export interface Trait {
  label: string;
  value: string;
}

export interface NFTAsset {
  id: string;
  name: string;
  collectionId: string;
  image: string;
  tokenId: string;
  owner: string;
  price: number;
  reservePrice?: number;
  endsAt?: string;
  saleType: SaleType;
  rarityRank: number;
  traits: Trait[];
  lazyMinted?: boolean;
  royaltyBps: number;
}

export interface Offer {
  id: string;
  collectionId?: string;
  assetId?: string;
  bidder: string;
  amount: number;
  expiresAt: string;
  quantity?: number;
}

export interface Bundle {
  id: string;
  label: string;
  assetIds: string[];
  listPrice: number;
  discountPct: number;
}

export interface ContractModule {
  name: string;
  address: string;
  responsibilities: string[];
}

export interface StorageRecord {
  provider: StorageProvider;
  cid: string;
  uri: string;
  status: 'Pinned' | 'Verified' | 'Replicated';
}
