import type {
  Bundle,
  Collection,
  ContractModule,
  NFTAsset,
  Offer,
  StorageRecord,
} from '../types';

export const collections: Collection[] = [
  {
    id: 'signal',
    name: 'Signal/Noise',
    creator: '0x19A4...83b1',
    floor: 0.92,
    volume: 418,
    royaltyBps: 750,
    items: 2400,
  },
  {
    id: 'mono',
    name: 'Mono Relics',
    creator: '0x77d1...A2f8',
    floor: 1.36,
    volume: 286,
    royaltyBps: 500,
    items: 1000,
  },
  {
    id: 'vector',
    name: 'Vector Bloom',
    creator: '0xA013...C912',
    floor: 0.61,
    volume: 192,
    royaltyBps: 850,
    items: 1800,
  },
];

export const assets: NFTAsset[] = [
  {
    id: 'asset-001',
    name: 'Phase Runner #184',
    collectionId: 'signal',
    image:
      'https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?auto=format&fit=crop&w=900&q=80',
    tokenId: '184',
    owner: '0x8Ae1...9212',
    price: 1.08,
    saleType: 'Fixed',
    rarityRank: 14,
    traits: [
      { label: 'Palette', value: 'Amber' },
      { label: 'Frame', value: 'Noise Grid' },
    ],
    lazyMinted: false,
    royaltyBps: 750,
  },
  {
    id: 'asset-002',
    name: 'Mono Relic #022',
    collectionId: 'mono',
    image:
      'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=900&q=80',
    tokenId: '22',
    owner: '0x42B8...0f22',
    price: 2.4,
    reservePrice: 2.1,
    endsAt: '2025-01-12T20:00:00Z',
    saleType: 'English',
    rarityRank: 29,
    traits: [
      { label: 'Matter', value: 'Obsidian' },
      { label: 'Signal', value: 'Low' },
    ],
    lazyMinted: false,
    royaltyBps: 500,
  },
  {
    id: 'asset-003',
    name: 'Vector Bloom #771',
    collectionId: 'vector',
    image:
      'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?auto=format&fit=crop&w=900&q=80',
    tokenId: '771',
    owner: '0x0ff9...D12e',
    price: 1.74,
    reservePrice: 1.12,
    endsAt: '2025-01-10T12:00:00Z',
    saleType: 'Dutch',
    rarityRank: 11,
    traits: [
      { label: 'Petals', value: '8' },
      { label: 'Spectrum', value: 'Viridian' },
    ],
    lazyMinted: true,
    royaltyBps: 850,
  },
  {
    id: 'asset-004',
    name: 'Phase Runner #056',
    collectionId: 'signal',
    image:
      'https://images.unsplash.com/photo-1547891654-e66ed7ebb968?auto=format&fit=crop&w=900&q=80',
    tokenId: '56',
    owner: '0x9BA0...2C33',
    price: 0.88,
    saleType: 'Offer',
    rarityRank: 73,
    traits: [
      { label: 'Palette', value: 'Cerulean' },
      { label: 'Frame', value: 'Static' },
    ],
    lazyMinted: false,
    royaltyBps: 750,
  },
];

export const offers: Offer[] = [
  {
    id: 'offer-001',
    assetId: 'asset-001',
    bidder: '0xB91d...41A3',
    amount: 1.02,
    expiresAt: '2025-01-10T18:00:00Z',
  },
  {
    id: 'offer-002',
    collectionId: 'signal',
    bidder: '0x4f21...A0c4',
    amount: 0.95,
    quantity: 6,
    expiresAt: '2025-01-13T12:00:00Z',
  },
  {
    id: 'offer-003',
    collectionId: 'vector',
    bidder: '0xA88b...91c1',
    amount: 0.7,
    quantity: 10,
    expiresAt: '2025-01-15T09:30:00Z',
  },
];

export const bundles: Bundle[] = [
  {
    id: 'bundle-001',
    label: 'Signal Starter Pack',
    assetIds: ['asset-001', 'asset-004'],
    listPrice: 1.78,
    discountPct: 8,
  },
];

export const contracts: ContractModule[] = [
  {
    name: 'MarketplaceCore',
    address: '0xC0re...7120',
    responsibilities: [
      'Fixed-price listings and collection offers',
      'Batch buying and floor sweeping routes',
      'Bundle sale fulfillment and lazy mint execution',
    ],
  },
  {
    name: 'AuctionHouse',
    address: '0xAuct...4521',
    responsibilities: [
      'English auctions with reserve validation',
      'Dutch auction pricing curves',
      'Escrow-aware settlement hooks',
    ],
  },
  {
    name: 'RoyaltyRegistry',
    address: '0xR0yA...9121',
    responsibilities: [
      'Collection royalty overrides',
      'ERC-2981 fallback lookups',
      'Enforced payout splits during settlement',
    ],
  },
  {
    name: 'EscrowVault',
    address: '0xEscr...8112',
    responsibilities: [
      'Offer collateral and bid custody',
      'Refund handling for canceled orders',
      'Atomic release on matched trades',
    ],
  },
];

export const storageRecords: StorageRecord[] = [
  {
    provider: 'IPFS',
    cid: 'bafybeic2axisgallery',
    uri: 'ipfs://bafybeic2axisgallery',
    status: 'Pinned',
  },
  {
    provider: 'Arweave',
    cid: 'QmArweaveMirrorAxis',
    uri: 'ar://QmArweaveMirrorAxis',
    status: 'Replicated',
  },
  {
    provider: 'IPFS',
    cid: 'bafybeiclazybatch',
    uri: 'ipfs://bafybeiclazybatch',
    status: 'Verified',
  },
];
