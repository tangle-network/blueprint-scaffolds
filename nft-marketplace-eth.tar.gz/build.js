import { build } from 'vite'

build({
  configFile: './vite.config.ts',
}).then(() => console.log('Build complete')).catch(e => { console.error(e); process.exit(1) })
