// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IRoyaltyRegistry {
    function getRoyalty(address nftContract, uint256 tokenId, uint256 salePrice) external view returns (address recipient, uint256 amount);
}
