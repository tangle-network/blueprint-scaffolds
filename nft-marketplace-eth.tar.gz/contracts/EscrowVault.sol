// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract EscrowVault {
    mapping(bytes32 => uint256) public deposits;

    event Deposited(bytes32 indexed orderId, address indexed funder, uint256 amount);
    event Released(bytes32 indexed orderId, address indexed recipient, uint256 amount);

    function deposit(bytes32 orderId) external payable {
        deposits[orderId] += msg.value;
        emit Deposited(orderId, msg.sender, msg.value);
    }

    function release(bytes32 orderId, address payable recipient, uint256 amount) external {
        require(deposits[orderId] >= amount, "insufficient balance");
        deposits[orderId] -= amount;
        recipient.transfer(amount);
        emit Released(orderId, recipient, amount);
    }
}
