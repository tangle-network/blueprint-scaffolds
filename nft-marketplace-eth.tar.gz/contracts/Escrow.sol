// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IEscrow {
    function deposit(address from) external payable;
    function withdraw(address from, address to, uint256 amount) external;
    function balanceOf(address account) external view returns (uint256);
}

contract Escrow is IEscrow {
    mapping(address => uint256) public balances;
    address public marketplace;

    modifier onlyMarketplace() {
        require(msg.sender == marketplace, "Not marketplace");
        _;
    }

    constructor(address _marketplace) {
        marketplace = _marketplace;
    }

    function deposit(address from) external payable override onlyMarketplace {
        balances[from] += msg.value;
    }

    function withdraw(address from, address to, uint256 amount) external override onlyMarketplace {
        require(balances[from] >= amount, "Insufficient balance");
        balances[from] -= amount;
        (bool ok,) = payable(to).call{value: amount}("");
        require(ok, "Transfer failed");
    }

    function balanceOf(address account) external view override returns (uint256) {
        return balances[account];
    }

    receive() external payable {}
}
