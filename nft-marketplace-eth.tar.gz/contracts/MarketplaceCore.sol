// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IERC721Transfer {
    function safeTransferFrom(address from, address to, uint256 tokenId) external;
}

contract MarketplaceCore {
    struct Listing {
        address seller;
        address token;
        uint256 tokenId;
        uint256 price;
        bool lazyMint;
    }

    mapping(bytes32 => Listing) public listings;

    event ListingCreated(bytes32 indexed listingId, address indexed seller, address indexed token, uint256 tokenId, uint256 price);
    event ListingFilled(bytes32 indexed listingId, address indexed buyer, uint256 value);

    function createListing(address token, uint256 tokenId, uint256 price, bool lazyMint) external returns (bytes32 listingId) {
        listingId = keccak256(abi.encode(msg.sender, token, tokenId, price, block.timestamp));
        listings[listingId] = Listing(msg.sender, token, tokenId, price, lazyMint);
        emit ListingCreated(listingId, msg.sender, token, tokenId, price);
    }

    function buy(bytes32 listingId) external payable {
        Listing memory listing = listings[listingId];
        require(listing.seller != address(0), "listing missing");
        require(msg.value >= listing.price, "insufficient payment");

        delete listings[listingId];
        IERC721Transfer(listing.token).safeTransferFrom(listing.seller, msg.sender, listing.tokenId);
        payable(listing.seller).transfer(listing.price);

        emit ListingFilled(listingId, msg.sender, msg.value);
    }
}
