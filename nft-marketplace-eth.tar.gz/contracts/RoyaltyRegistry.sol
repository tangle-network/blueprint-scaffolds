// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract RoyaltyRegistry {
    struct RoyaltyConfig {
        address receiver;
        uint96 bps;
    }

    mapping(address => RoyaltyConfig) public royalties;

    event RoyaltySet(address indexed collection, address indexed receiver, uint96 bps);

    function setRoyalty(address collection, address receiver, uint96 bps) external {
        require(bps <= 1500, "royalty too high");
        royalties[collection] = RoyaltyConfig(receiver, bps);
        emit RoyaltySet(collection, receiver, bps);
    }

    function royaltyInfo(address collection, uint256 salePrice) external view returns (address receiver, uint256 amount) {
        RoyaltyConfig memory config = royalties[collection];
        receiver = config.receiver;
        amount = (salePrice * config.bps) / 10_000;
    }
}
