// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IRoyaltyRegistry {
    function getRoyalty(address nftContract, uint256 tokenId, uint256 salePrice) external view returns (address recipient, uint256 amount);
    function setRoyalty(address nftContract, address recipient, uint256 bps) external;
    function getRoyaltyBps(address nftContract) external view returns (uint256);
    function getRoyaltyRecipient(address nftContract) external view returns (address);
}

contract RoyaltyRegistry is IRoyaltyRegistry {
    uint256 public constant MAX_BPS = 5000;

    struct RoyaltyInfo {
        address recipient;
        uint256 bps;
        bool overrideDefault;
    }

    mapping(address => RoyaltyInfo) public royalties;
    mapping(address => mapping(uint256 => RoyaltyInfo)) public tokenRoyalties;
    mapping(address => bool) public registeredCollections;
    address public owner;

    event RoyaltySet(address indexed nftContract, address indexed recipient, uint256 bps);
    event TokenRoyaltySet(address indexed nftContract, uint256 indexed tokenId, address indexed recipient, uint256 bps);
    event CollectionRegistered(address indexed nftContract, address indexed creator);

    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }

    modifier onlyCollectionOwner(address nftContract) {
        require(
            registeredCollections[nftContract] == false || msg.sender == owner,
            "Already registered or not owner"
        );
        _;
    }

    constructor() {
        owner = msg.sender;
    }

    function registerCollection(address nftContract) external {
        registeredCollections[nftContract] = true;
        emit CollectionRegistered(nftContract, msg.sender);
    }

    function setRoyalty(address nftContract, address recipient, uint256 bps) external {
        require(bps <= MAX_BPS, "Royalty too high");
        require(recipient != address(0), "Invalid recipient");

        royalties[nftContract] = RoyaltyInfo({
            recipient: recipient,
            bps: bps,
            overrideDefault: true
        });

        emit RoyaltySet(nftContract, recipient, bps);
    }

    function setTokenRoyalty(address nftContract, uint256 tokenId, address recipient, uint256 bps) external {
        require(bps <= MAX_BPS, "Royalty too high");
        tokenRoyalties[nftContract][tokenId] = RoyaltyInfo({
            recipient: recipient,
            bps: bps,
            overrideDefault: true
        });
        emit TokenRoyaltySet(nftContract, tokenId, recipient, bps);
    }

    function getRoyalty(address nftContract, uint256 tokenId, uint256 salePrice) external view returns (address recipient, uint256 amount) {
        RoyaltyInfo storage tokenRoyalty = tokenRoyalties[nftContract][tokenId];
        if (tokenRoyalty.overrideDefault) {
            return (tokenRoyalty.recipient, (salePrice * tokenRoyalty.bps) / 10000);
        }

        RoyaltyInfo storage collectionRoyalty = royalties[nftContract];
        if (collectionRoyalty.overrideDefault) {
            return (collectionRoyalty.recipient, (salePrice * collectionRoyalty.bps) / 10000);
        }

        try IERC2981(nftContract).royaltyInfo(tokenId, salePrice) returns (address r, uint256 a) {
            if (a > (salePrice * MAX_BPS) / 10000) {
                return (address(0), 0);
            }
            return (r, a);
        } catch {
            return (address(0), 0);
        }
    }

    function getRoyaltyBps(address nftContract) external view returns (uint256) {
        return royalties[nftContract].bps;
    }

    function getRoyaltyRecipient(address nftContract) external view returns (address) {
        return royalties[nftContract].recipient;
    }
}

interface IERC2981 {
    function royaltyInfo(uint256 tokenId, uint256 salePrice) external view returns (address, uint256);
}
