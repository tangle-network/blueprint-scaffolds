// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IERC721} from "@openzeppelin/contracts/token/ERC721/IERC721.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {IRoyaltyRegistry} from "./IRoyaltyRegistry.sol";

enum AuctionType { English, Dutch }

struct Auction {
    address seller;
    address nftContract;
    uint256 tokenId;
    AuctionType auctionType;
    uint256 startPrice;
    uint256 endPrice;
    uint256 startTime;
    uint256 endTime;
    uint256 minBidIncrement;
    address highestBidder;
    uint256 highestBid;
    bool settled;
    bool active;
}

interface IAuctionHouse {
    event AuctionCreated(uint256 indexed auctionId, address indexed seller, AuctionType auctionType);
    event BidPlaced(uint256 indexed auctionId, address indexed bidder, uint256 amount);
    event AuctionSettled(uint256 indexed auctionId, address winner, uint256 finalPrice);
    event AuctionCancelled(uint256 indexed auctionId);
}

contract AuctionHouse is IAuctionHouse, ReentrancyGuard, Ownable {
    uint256 public constant BASIS_POINTS = 10000;
    uint256 public platformFeeBps = 250;
    address public platformFeeRecipient;
    IRoyaltyRegistry public royaltyRegistry;

    uint256 public nextAuctionId = 1;
    mapping(uint256 => Auction) public auctions;
    mapping(address => uint256) public pendingReturns;

    constructor(address _royaltyRegistry, address _feeRecipient) Ownable(msg.sender) {
        royaltyRegistry = IRoyaltyRegistry(_royaltyRegistry);
        platformFeeRecipient = _feeRecipient;
    }

    function createEnglishAuction(
        address nftContract,
        uint256 tokenId,
        uint256 startPrice,
        uint256 duration,
        uint256 minBidIncrement
    ) external nonReentrant returns (uint256) {
        IERC721(nftContract).transferFrom(msg.sender, address(this), tokenId);

        uint256 auctionId = nextAuctionId++;
        auctions[auctionId] = Auction({
            seller: msg.sender,
            nftContract: nftContract,
            tokenId: tokenId,
            auctionType: AuctionType.English,
            startPrice: startPrice,
            endPrice: 0,
            startTime: block.timestamp,
            endTime: block.timestamp + duration,
            minBidIncrement: minBidIncrement,
            highestBidder: address(0),
            highestBid: 0,
            settled: false,
            active: true
        });

        emit AuctionCreated(auctionId, msg.sender, AuctionType.English);
        return auctionId;
    }

    function createDutchAuction(
        address nftContract,
        uint256 tokenId,
        uint256 startPrice,
        uint256 endPrice,
        uint256 duration
    ) external nonReentrant returns (uint256) {
        require(startPrice > endPrice, "Start must > end");
        IERC721(nftContract).transferFrom(msg.sender, address(this), tokenId);

        uint256 auctionId = nextAuctionId++;
        auctions[auctionId] = Auction({
            seller: msg.sender,
            nftContract: nftContract,
            tokenId: tokenId,
            auctionType: AuctionType.Dutch,
            startPrice: startPrice,
            endPrice: endPrice,
            startTime: block.timestamp,
            endTime: block.timestamp + duration,
            minBidIncrement: 0,
            highestBidder: address(0),
            highestBid: 0,
            settled: false,
            active: true
        });

        emit AuctionCreated(auctionId, msg.sender, AuctionType.Dutch);
        return auctionId;
    }

    function bid(uint256 auctionId) external payable nonReentrant {
        Auction storage auction = auctions[auctionId];
        require(auction.active, "Not active");
        require(!auction.settled, "Already settled");

        if (auction.auctionType == AuctionType.English) {
            require(block.timestamp >= auction.startTime, "Not started");
            require(block.timestamp < auction.endTime, "Ended");
            uint256 minBid = auction.highestBid == 0
                ? auction.startPrice
                : auction.highestBid + auction.minBidIncrement;
            require(msg.value >= minBid, "Bid too low");

            if (auction.highestBidder != address(0)) {
                pendingReturns[auction.highestBidder] += auction.highestBid;
            }
            auction.highestBidder = msg.sender;
            auction.highestBid = msg.value;
        } else {
            require(block.timestamp >= auction.startTime, "Not started");
            uint256 currentPrice = getCurrentDutchPrice(auctionId);
            require(msg.value >= currentPrice, "Bid below current price");
            auction.highestBidder = msg.sender;
            auction.highestBid = currentPrice;
            auction.active = false;

            _settleAuction(auctionId);

            if (msg.value > currentPrice) {
                pendingReturns[msg.sender] += msg.value - currentPrice;
            }
        }

        emit BidPlaced(auctionId, msg.sender, msg.value);
    }

    function settleAuction(uint256 auctionId) external nonReentrant {
        Auction storage auction = auctions[auctionId];
        require(auction.active, "Not active");
        require(!auction.settled, "Settled");
        require(block.timestamp >= auction.endTime, "Not ended");
        require(auction.highestBidder != address(0), "No bids");

        auction.active = false;
        _settleAuction(auctionId);
    }

    function cancelAuction(uint256 auctionId) external {
        Auction storage auction = auctions[auctionId];
        require(auction.seller == msg.sender, "Not seller");
        require(auction.highestBidder == address(0), "Has bids");
        require(auction.active, "Not active");

        auction.active = false;
        IERC721(auction.nftContract).transferFrom(address(this), msg.sender, auction.tokenId);
        emit AuctionCancelled(auctionId);
    }

    function withdrawPending() external nonReentrant {
        uint256 amount = pendingReturns[msg.sender];
        require(amount > 0, "Nothing to withdraw");
        pendingReturns[msg.sender] = 0;
        (bool ok,) = payable(msg.sender).call{value: amount}("");
        require(ok, "Transfer failed");
    }

    function getCurrentDutchPrice(uint256 auctionId) public view returns (uint256) {
        Auction storage auction = auctions[auctionId];
        require(auction.auctionType == AuctionType.Dutch, "Not Dutch");

        if (block.timestamp <= auction.startTime) return auction.startPrice;
        if (block.timestamp >= auction.endTime) return auction.endPrice;

        uint256 elapsed = block.timestamp - auction.startTime;
        uint256 duration = auction.endTime - auction.startTime;
        uint256 priceDrop = ((auction.startPrice - auction.endPrice) * elapsed) / duration;
        return auction.startPrice - priceDrop;
    }

    function _settleAuction(uint256 auctionId) internal {
        Auction storage auction = auctions[auctionId];
        auction.settled = true;

        (address royaltyRecipient, uint256 royaltyAmount) = royaltyRegistry.getRoyalty(
            auction.nftContract, auction.tokenId, auction.highestBid
        );
        uint256 platformFee = (auction.highestBid * platformFeeBps) / BASIS_POINTS;

        IERC721(auction.nftContract).transferFrom(address(this), auction.highestBidder, auction.tokenId);

        if (royaltyAmount > 0) {
            (bool r,) = payable(royaltyRecipient).call{value: royaltyAmount}("");
            require(r, "Royalty failed");
        }
        (bool p,) = payable(platformFeeRecipient).call{value: platformFee}("");
        require(p, "Platform fee failed");

        uint256 sellerProceeds = auction.highestBid - royaltyAmount - platformFee;
        (bool s,) = payable(auction.seller).call{value: sellerProceeds}("");
        require(s, "Seller payment failed");

        emit AuctionSettled(auctionId, auction.highestBidder, auction.highestBid);
    }

    function setPlatformFee(uint256 bps) external onlyOwner {
        require(bps <= 1000, "Max 10%");
        platformFeeBps = bps;
    }

    receive() external payable {}
}
