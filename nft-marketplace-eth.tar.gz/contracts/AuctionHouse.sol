// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract AuctionHouse {
    struct Auction {
        address seller;
        uint256 reservePrice;
        uint256 startPrice;
        uint256 endPrice;
        uint64 startTime;
        uint64 endTime;
        bool dutch;
    }

    mapping(bytes32 => Auction) public auctions;
    mapping(bytes32 => address) public highestBidder;
    mapping(bytes32 => uint256) public highestBid;

    event AuctionCreated(bytes32 indexed auctionId, address indexed seller, bool dutch);
    event BidPlaced(bytes32 indexed auctionId, address indexed bidder, uint256 amount);

    function createAuction(Auction calldata auction) external returns (bytes32 auctionId) {
        auctionId = keccak256(abi.encode(msg.sender, auction.startTime, auction.endTime, block.timestamp));
        auctions[auctionId] = auction;
        emit AuctionCreated(auctionId, msg.sender, auction.dutch);
    }

    function placeBid(bytes32 auctionId) external payable {
        Auction memory auction = auctions[auctionId];
        require(!auction.dutch, "use dutch execution");
        require(block.timestamp < auction.endTime, "auction ended");
        require(msg.value > highestBid[auctionId], "bid too low");

        highestBid[auctionId] = msg.value;
        highestBidder[auctionId] = msg.sender;
        emit BidPlaced(auctionId, msg.sender, msg.value);
    }
}
