// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IERC721} from "@openzeppelin/contracts/token/ERC721/IERC721.sol";
import {IERC1155} from "@openzeppelin/contracts/token/ERC1155/IERC1155.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC165} from "@openzeppelin/contracts/utils/introspection/IERC165.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {ERC2981} from "@openzeppelin/contracts/token/common/ERC2981.sol";
import {IRoyaltyRegistry} from "./IRoyaltyRegistry.sol";
import {IEscrow} from "./IEscrow.sol";

struct Listing {
    address seller;
    address nftContract;
    uint256 tokenId;
    uint256 price;
    bool isERC1155;
    uint256 quantity;
    uint256 expiresAt;
    bool active;
}

struct Offer {
    address offeror;
    address nftContract;
    uint256 tokenId;
    uint256 amount;
    uint256 expiresAt;
    bool active;
}

struct CollectionOffer {
    address offeror;
    address nftContract;
    uint256 amount;
    uint256 expiresAt;
    bool active;
}

struct BundleListing {
    address seller;
    address[] nftContracts;
    uint256[] tokenIds;
    uint256 price;
    uint256 expiresAt;
    bool active;
}

interface IMarketplace {
    event Listed(uint256 indexed listingId, address indexed seller, address nftContract, uint256 tokenId, uint256 price);
    event Sold(uint256 indexed listingId, address indexed buyer, uint256 price);
    event ListingCancelled(uint256 indexed listingId);
    event ListingUpdated(uint256 indexed listingId, uint256 newPrice);
    event OfferMade(uint256 indexed offerId, address indexed offeror, address nftContract, uint256 tokenId, uint256 amount);
    event OfferAccepted(uint256 indexed offerId, address indexed seller);
    event OfferCancelled(uint256 indexed offerId);
    event CollectionOfferMade(uint256 indexed offerId, address indexed offeror, address nftContract, uint256 amount);
    event CollectionOfferAccepted(uint256 indexed offerId, address indexed seller, uint256 tokenId);
    event BundleListed(uint256 indexed bundleId, address indexed seller, uint256 price);
    event BundleSold(uint256 indexed bundleId, address indexed buyer);
    event BatchPurchased(address indexed buyer, uint256[] listingIds, uint256 totalPrice);
    event FloorSwept(address indexed buyer, address nftContract, uint256 count, uint256 totalPrice);
}

contract NFTMarketplace is IMarketplace, ReentrancyGuard, Ownable {
    uint256 public constant BASIS_POINTS = 10000;
    uint256 public platformFeeBps = 250;
    address public platformFeeRecipient;
    IRoyaltyRegistry public royaltyRegistry;
    IEscrow public escrow;

    uint256 public nextListingId = 1;
    uint256 public nextOfferId = 1;
    uint256 public nextCollectionOfferId = 1;
    uint256 public nextBundleId = 1;

    mapping(uint256 => Listing) public listings;
    mapping(uint256 => Offer) public offers;
    mapping(uint256 => CollectionOffer) public collectionOffers;
    mapping(uint256 => BundleListing) public bundles;
    mapping(address => mapping(uint256 => uint256)) public nftToListing;

    constructor(address _royaltyRegistry, address _escrow, address _feeRecipient) Ownable(msg.sender) {
        royaltyRegistry = IRoyaltyRegistry(_royaltyRegistry);
        escrow = IEscrow(_escrow);
        platformFeeRecipient = _feeRecipient;
    }

    function listNft(
        address nftContract,
        uint256 tokenId,
        uint256 price,
        bool isERC1155,
        uint256 quantity,
        uint256 duration
    ) external nonReentrant returns (uint256) {
        require(price > 0, "Price must be > 0");
        require(quantity > 0, "Quantity must be > 0");

        if (isERC1155) {
            IERC1155(nftContract).safeTransferFrom(msg.sender, address(escrow), tokenId, quantity, "");
        } else {
            IERC721(nftContract).transferFrom(msg.sender, address(escrow), tokenId);
        }

        uint256 listingId = nextListingId++;
        listings[listingId] = Listing({
            seller: msg.sender,
            nftContract: nftContract,
            tokenId: tokenId,
            price: price,
            isERC1155: isERC1155,
            quantity: quantity,
            expiresAt: block.timestamp + duration,
            active: true
        });
        nftToListing[nftContract][tokenId] = listingId;

        emit Listed(listingId, msg.sender, nftContract, tokenId, price);
        return listingId;
    }

    function buyNft(uint256 listingId) external payable nonReentrant {
        Listing storage listing = listings[listingId];
        _validateListing(listing, listingId);
        require(msg.value >= listing.price, "Insufficient payment");

        listing.active = false;
        _payout(listing.nftContract, listing.tokenId, listing.seller, msg.value);

        if (listing.isERC1155) {
            IERC1155(listing.nftContract).safeTransferFrom(address(escrow), msg.sender, listing.tokenId, 1, "");
            listing.quantity -= 1;
            if (listing.quantity > 0) {
                listing.active = true;
            }
        } else {
            IERC721(listing.nftContract).transferFrom(address(escrow), msg.sender, listing.tokenId);
        }

        emit Sold(listingId, msg.sender, msg.value);
    }

    function batchBuy(uint256[] calldata listingIds) external payable nonReentrant {
        uint256 totalCost;
        for (uint256 i = 0; i < listingIds.length; i++) {
            Listing storage listing = listings[listingIds[i]];
            _validateListing(listing, listingIds[i]);
            totalCost += listing.price;
        }
        require(msg.value >= totalCost, "Insufficient payment for batch");

        for (uint256 i = 0; i < listingIds.length; i++) {
            Listing storage listing = listings[listingIds[i]];
            uint256 price = listing.price;

            listing.active = false;
            _payout(listing.nftContract, listing.tokenId, listing.seller, price);

            if (listing.isERC1155) {
                IERC1155(listing.nftContract).safeTransferFrom(address(escrow), msg.sender, listing.tokenId, 1, "");
                listing.quantity -= 1;
                if (listing.quantity > 0) listing.active = true;
            } else {
                IERC721(listing.nftContract).transferFrom(address(escrow), msg.sender, listing.tokenId);
            }

            emit Sold(listingIds[i], msg.sender, price);
        }

        if (msg.value > totalCost) {
            (bool ok,) = payable(msg.sender).call{value: msg.value - totalCost}("");
            require(ok, "Refund failed");
        }

        emit BatchPurchased(msg.sender, listingIds, totalCost);
    }

    function sweepFloor(address nftContract, uint256 maxPrice, uint256 maxCount) external payable nonReentrant {
        uint256 swept;
        uint256 spent;
        uint256 listingId = 1;

        while (swept < maxCount && listingId < nextListingId) {
            Listing storage listing = listings[listingId];
            if (listing.active && listing.nftContract == nftContract && listing.price <= maxPrice) {
                if (spent + listing.price > msg.value) break;

                listing.active = false;
                _payout(listing.nftContract, listing.tokenId, listing.seller, listing.price);

                if (listing.isERC1155) {
                    IERC1155(listing.nftContract).safeTransferFrom(address(escrow), msg.sender, listing.tokenId, 1, "");
                    listing.quantity -= 1;
                    if (listing.quantity > 0) listing.active = true;
                } else {
                    IERC721(listing.nftContract).transferFrom(address(escrow), msg.sender, listing.tokenId);
                }

                swept++;
                spent += listing.price;
                emit Sold(listingId, msg.sender, listing.price);
            }
            listingId++;
        }

        if (msg.value > spent) {
            (bool ok,) = payable(msg.sender).call{value: msg.value - spent}("");
            require(ok, "Refund failed");
        }

        emit FloorSwept(msg.sender, nftContract, swept, spent);
    }

    function makeOffer(address nftContract, uint256 tokenId, uint256 duration) external payable returns (uint256) {
        require(msg.value > 0, "Offer must include ETH");
        uint256 offerId = nextOfferId++;
        offers[offerId] = Offer({
            offeror: msg.sender,
            nftContract: nftContract,
            tokenId: tokenId,
            amount: msg.value,
            expiresAt: block.timestamp + duration,
            active: true
        });
        escrow.deposit{value: msg.value}(msg.sender);
        emit OfferMade(offerId, msg.sender, nftContract, tokenId, msg.value);
        return offerId;
    }

    function acceptOffer(uint256 offerId) external nonReentrant {
        Offer storage offer = offers[offerId];
        require(offer.active, "Offer not active");
        require(block.timestamp < offer.expiresAt, "Offer expired");

        IERC721(offer.nftContract).transferFrom(msg.sender, offer.offeror, offer.tokenId);
        offer.active = false;

        _payout(offer.nftContract, offer.tokenId, msg.sender, offer.amount);
        escrow.withdraw(offer.offeror, msg.sender, offer.amount);

        emit OfferAccepted(offerId, msg.sender);
    }

    function makeCollectionOffer(address nftContract, uint256 duration) external payable returns (uint256) {
        require(msg.value > 0, "Offer must include ETH");
        uint256 offerId = nextCollectionOfferId++;
        collectionOffers[offerId] = CollectionOffer({
            offeror: msg.sender,
            nftContract: nftContract,
            amount: msg.value,
            expiresAt: block.timestamp + duration,
            active: true
        });
        escrow.deposit{value: msg.value}(msg.sender);
        emit CollectionOfferMade(offerId, msg.sender, nftContract, msg.value);
        return offerId;
    }

    function acceptCollectionOffer(uint256 offerId, uint256 tokenId) external nonReentrant {
        CollectionOffer storage offer = collectionOffers[offerId];
        require(offer.active, "Offer not active");
        require(block.timestamp < offer.expiresAt, "Offer expired");

        IERC721(offer.nftContract).transferFrom(msg.sender, offer.offeror, tokenId);
        offer.active = false;

        _payout(offer.nftContract, tokenId, msg.sender, offer.amount);
        escrow.withdraw(offer.offeror, msg.sender, offer.amount);

        emit CollectionOfferAccepted(offerId, msg.sender, tokenId);
    }

    function createBundle(
        address[] calldata nftContracts,
        uint256[] calldata tokenIds,
        uint256 price,
        uint256 duration
    ) external nonReentrant returns (uint256) {
        require(nftContracts.length == tokenIds.length, "Length mismatch");
        require(nftContracts.length > 1, "Need >1 NFT");
        require(price > 0, "Price must be > 0");

        for (uint256 i = 0; i < nftContracts.length; i++) {
            IERC721(nftContracts[i]).transferFrom(msg.sender, address(escrow), tokenIds[i]);
        }

        uint256 bundleId = nextBundleId++;
        bundles[bundleId] = BundleListing({
            seller: msg.sender,
            nftContracts: nftContracts,
            tokenIds: tokenIds,
            price: price,
            expiresAt: block.timestamp + duration,
            active: true
        });

        emit BundleListed(bundleId, msg.sender, price);
        return bundleId;
    }

    function buyBundle(uint256 bundleId) external payable nonReentrant {
        BundleListing storage bundle = bundles[bundleId];
        require(bundle.active, "Bundle not active");
        require(block.timestamp < bundle.expiresAt, "Bundle expired");
        require(msg.value >= bundle.price, "Insufficient payment");

        bundle.active = false;
        for (uint256 i = 0; i < bundle.nftContracts.length; i++) {
            IERC721(bundle.nftContracts[i]).transferFrom(address(escrow), msg.sender, bundle.tokenIds[i]);
        }

        _payout(bundle.nftContracts[0], bundle.tokenIds[0], bundle.seller, msg.value);
        emit BundleSold(bundleId, msg.sender);
    }

    function cancelListing(uint256 listingId) external {
        Listing storage listing = listings[listingId];
        require(listing.seller == msg.sender, "Not seller");
        require(listing.active, "Not active");
        listing.active = false;
        if (!listing.isERC1155) {
            IERC721(listing.nftContract).transferFrom(address(escrow), msg.sender, listing.tokenId);
        } else {
            IERC1155(listing.nftContract).safeTransferFrom(address(escrow), msg.sender, listing.tokenId, listing.quantity, "");
        }
        emit ListingCancelled(listingId);
    }

    function cancelOffer(uint256 offerId) external {
        Offer storage offer = offers[offerId];
        require(offer.offeror == msg.sender, "Not offeror");
        require(offer.active, "Not active");
        offer.active = false;
        escrow.withdraw(msg.sender, msg.sender, offer.amount);
        emit OfferCancelled(offerId);
    }

    function updateListingPrice(uint256 listingId, uint256 newPrice) external {
        Listing storage listing = listings[listingId];
        require(listing.seller == msg.sender, "Not seller");
        require(listing.active, "Not active");
        listing.price = newPrice;
        emit ListingUpdated(listingId, newPrice);
    }

    function _validateListing(Listing storage listing, uint256 listingId) internal view {
        require(listing.active, "Not active");
        require(listing.listingId == listingId || listing.seller != address(0), "Invalid listing");
        require(block.timestamp < listing.expiresAt, "Listing expired");
    }

    function _payout(address nftContract, uint256 tokenId, address seller, uint256 salePrice) internal {
        (address royaltyRecipient, uint256 royaltyAmount) = royaltyRegistry.getRoyalty(nftContract, tokenId, salePrice);
        uint256 platformFee = (salePrice * platformFeeBps) / BASIS_POINTS;

        if (royaltyAmount > 0) {
            (bool r,) = payable(royaltyRecipient).call{value: royaltyAmount}("");
            require(r, "Royalty payment failed");
        }
        (bool p,) = payable(platformFeeRecipient).call{value: platformFee}("");
        require(p, "Platform fee failed");

        uint256 sellerProceeds = salePrice - royaltyAmount - platformFee;
        (bool s,) = payable(seller).call{value: sellerProceeds}("");
        require(s, "Seller payment failed");
    }

    function setPlatformFee(uint256 bps) external onlyOwner {
        require(bps <= 1000, "Max 10%");
        platformFeeBps = bps;
    }

    receive() external payable {}
}
