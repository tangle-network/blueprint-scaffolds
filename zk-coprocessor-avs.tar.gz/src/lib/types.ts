export interface Operator {
  id: string
  address: string
  stake: number
  status: "active" | "inactive" | "slashed" | "pending"
  registeredAt: string
  tasksCompleted: number
  proofsGenerated: number
  reputation: number
  blsPublicKey: string
}

export interface Task {
  id: string
  type: "computation" | "aggregation" | "verification"
  status: "queued" | "executing" | "proving" | "aggregating" | "completed" | "failed"
  requester: string
  inputHash: string
  outputHash: string | null
  proofType: "risc-zero" | "sp1"
  submittedAt: string
  completedAt: string | null
  computeTime: number | null
  proofSize: string | null
  gasUsed: number | null
}

export interface Proof {
  id: string
  taskId: string
  type: "risc-zero" | "sp1" | "bls-aggregate"
  status: "generating" | "verified" | "failed" | "aggregated"
  prover: string
  submittedAt: string
  verifiedAt: string | null
  verificationGas: number
  size: string
  receiptRoot: string
}

export interface SlashingEvent {
  id: string
  operatorId: string
  operatorAddress: string
  reason: "invalid_proof" | "missed_attestation" | "double_sign" | "downtime"
  amount: number
  timestamp: string
  evidence: string
  status: "pending" | "executed" | "disputed" | "resolved"
  taskId: string | null
}

export interface Reward {
  id: string
  operatorId: string
  operatorAddress: string
  amount: number
  epoch: number
  timestamp: string
  type: "task_reward" | "stake_reward" | "attestation_reward"
  claimed: boolean
}

export interface AggregationState {
  quorumThreshold: number
  totalOperators: number
  signedOperators: number
  aggregateSignature: string
  epoch: number
}

export interface NetworkStats {
  totalOperators: number
  activeOperators: number
  totalStake: number
  totalTasksCompleted: number
  totalProofsGenerated: number
  avgProvingTime: number
  currentEpoch: number
  quorumPercentage: number
}
