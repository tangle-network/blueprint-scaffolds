export type Metric = {
  label: string;
  value: string;
  note: string;
};

export type Stage = {
  title: string;
  summary: string;
  details: string[];
};

export type Operator = {
  name: string;
  status: "Active" | "Syncing" | "Challenged";
  stake: string;
  proofSystem: string;
  lastTask: string;
};

export type ContractModule = {
  title: string;
  description: string;
  functions: string[];
};

export type CodeSnippet = {
  title: string;
  language: string;
  content: string;
};
