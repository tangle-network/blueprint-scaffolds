import type {
  CodeSnippet,
  ContractModule,
  Metric,
  Operator,
  Stage
} from "./types";

export const metrics: Metric[] = [
  {
    label: "Quorum threshold",
    value: "67%",
    note: "Weighted by delegated ETH stake for task attestations."
  },
  {
    label: "Minimum operator stake",
    value: "32 ETH",
    note: "Required for AVS registration and BLS participation."
  },
  {
    label: "Proof systems",
    value: "RISC Zero / SP1",
    note: "Selectable proving backend for deterministic off-chain jobs."
  },
  {
    label: "Settlement latency",
    value: "< 2 blocks",
    note: "Aggregator posts result and proof bundle after quorum is reached."
  }
];

export const pipeline: Stage[] = [
  {
    title: "1. Request intake",
    summary:
      "Consumer contracts submit computation tasks to the AVS task manager.",
    details: [
      "Task payload includes program ID, public inputs, callback target, and fee budget.",
      "Tasks are indexed for all registered operators through EigenLayer middleware."
    ]
  },
  {
    title: "2. Off-chain execution",
    summary:
      "Operators execute deterministic workloads in isolated workers before proving.",
    details: [
      "Execution runtimes support heavy analytics, ML inference, and state transforms.",
      "Task receipts are hashed into the BLS attestation domain for aggregation."
    ]
  },
  {
    title: "3. ZK proof generation",
    summary:
      "Each operator runs a RISC Zero or SP1 proving pipeline over the same trace.",
    details: [
      "Proof artifacts contain image IDs, journals, and public outputs for on-chain verification.",
      "Invalid proofs are slashable faults and can be challenged by the AVS verifier."
    ]
  },
  {
    title: "4. Aggregation and callback",
    summary:
      "The aggregator combines BLS signatures once 67% stake quorum signs the result.",
    details: [
      "Aggregated attestations and proof commitments are submitted to settlement contracts.",
      "The requesting contract receives the verified output through a callback interface."
    ]
  }
];

export const operators: Operator[] = [
  {
    name: "atlas-01",
    status: "Active",
    stake: "84 ETH",
    proofSystem: "RISC Zero",
    lastTask: "Matrix risk batch #1842"
  },
  {
    name: "vector-07",
    status: "Active",
    stake: "52 ETH",
    proofSystem: "SP1",
    lastTask: "Fraud graph expansion #1844"
  },
  {
    name: "quartz-12",
    status: "Syncing",
    stake: "40 ETH",
    proofSystem: "RISC Zero",
    lastTask: "L2 state reconciliation #1841"
  },
  {
    name: "delta-21",
    status: "Challenged",
    stake: "32 ETH",
    proofSystem: "SP1",
    lastTask: "Invalid proof dispute #1837"
  }
];

export const contracts: ContractModule[] = [
  {
    title: "TaskManager.sol",
    description:
      "Accepts computation requests, escrows fees, and dispatches task commitments to operators.",
    functions: [
      "requestComputation(bytes32 programId, bytes input, address callback)",
      "recordQuorum(uint256 taskId, bytes32 resultRoot, bytes quorumSig)"
    ]
  },
  {
    title: "ProofVerifier.sol",
    description:
      "Verifies RISC Zero/SP1 receipts, enforces slashable faults, and stores result commitments.",
    functions: [
      "verifyReceipt(uint256 taskId, bytes proof, bytes publicValues)",
      "challengeResult(uint256 taskId, bytes fraudProof)"
    ]
  },
  {
    title: "StakeRegistry.sol",
    description:
      "Tracks registered EigenLayer operators, delegated stake, rewards, and minimum 32 ETH participation.",
    functions: [
      "registerOperator(bytes blsPubkey)",
      "slashOperator(address operator, uint256 amount)",
      "distributeRewards(uint256 epoch)"
    ]
  }
];

export const snippets: CodeSnippet[] = [
  {
    title: "Rust operator loop",
    language: "rust",
    content: `pub async fn handle_task(task: Task, prover: &dyn Prover) -> Result<Bundle> {
    let execution = execute_program(&task.program_id, &task.input).await?;
    let proof = prover.prove(&execution).await?;
    let digest = bls_domain_hash(task.id, &execution.output);
    let signature = aggregate_ready_signature(digest)?;
    Ok(Bundle { execution, proof, signature })
}`
  },
  {
    title: "Solidity callback settlement",
    language: "solidity",
    content: `function finalizeTask(
    uint256 taskId,
    bytes calldata proof,
    bytes calldata aggregateSignature
) external {
    require(_reachedStakeQuorum(taskId, aggregateSignature), "quorum");
    require(verifier.verifyReceipt(taskId, proof, tasks[taskId].publicValues), "proof");
    IResultCallback(tasks[taskId].callback).handleResult(taskId, tasks[taskId].result);
}`
  }
];
