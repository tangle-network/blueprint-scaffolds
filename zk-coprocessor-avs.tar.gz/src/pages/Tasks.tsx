import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ListTodo,
  Cpu,
  Loader2,
  ShieldCheck,
  Layers,
  CheckCircle2,
  XCircle,
  Clock,
  Play,
} from "lucide-react"
import { tasks } from "@/data/mock"
import type { Task } from "@/lib/types"
import { useState } from "react"

const statusIcon: Record<Task["status"], React.ElementType> = {
  queued: Clock,
  executing: Play,
  proving: Loader2,
  aggregating: Layers,
  completed: CheckCircle2,
  failed: XCircle,
}

const statusVariant: Record<Task["status"], "default" | "secondary" | "success" | "destructive" | "warning" | "outline"> = {
  queued: "outline",
  executing: "default",
  proving: "warning",
  aggregating: "secondary",
  completed: "success",
  failed: "destructive",
}

const pipelineSteps: Task["status"][] = [
  "queued",
  "executing",
  "proving",
  "aggregating",
  "completed",
]

function TaskCard({ task }: { task: Task }) {
  const Icon = statusIcon[task.status]
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10">
              <Icon className={`h-4 w-4 text-primary ${task.status === "proving" ? "animate-spin" : ""}`} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-sm font-bold">{task.id}</span>
                <Badge variant={statusVariant[task.status]}>{task.status}</Badge>
                <Badge variant="outline" className="text-xs">
                  {task.proofType}
                </Badge>
              </div>
              <div className="mt-1 text-xs text-muted-foreground">
                Requester: {task.requester} — Type: {task.type}
              </div>
            </div>
          </div>
          <div className="text-right text-xs text-muted-foreground">
            <div>{new Date(task.submittedAt).toLocaleString()}</div>
            {task.completedAt && (
              <div>Completed: {new Date(task.completedAt).toLocaleString()}</div>
            )}
          </div>
        </div>

        <Separator className="my-3" />

        <div className="grid grid-cols-2 gap-3 text-sm md:grid-cols-4">
          <div>
            <div className="text-xs text-muted-foreground">Input Hash</div>
            <div className="font-mono text-xs truncate">{task.inputHash}</div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground">Output Hash</div>
            <div className="font-mono text-xs truncate">
              {task.outputHash || "—"}
            </div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground">Compute Time</div>
            <div className="text-xs font-medium">
              {task.computeTime ? `${(task.computeTime / 1000).toFixed(1)}s` : "—"}
            </div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground">Gas / Proof</div>
            <div className="text-xs font-medium">
              {task.gasUsed ? `${task.gasUsed.toLocaleString()} gas` : "—"}{" "}
              {task.proofSize ? `(${task.proofSize})` : ""}
            </div>
          </div>
        </div>

        {task.status !== "failed" && (
          <div className="mt-3">
            <div className="mb-1 flex items-center justify-between text-xs text-muted-foreground">
              <span>Pipeline Progress</span>
              <span>
                Step {pipelineSteps.indexOf(task.status) + 1}/{pipelineSteps.length}
              </span>
            </div>
            <div className="flex gap-1">
              {pipelineSteps.map((step, i) => {
                const currentIdx = pipelineSteps.indexOf(task.status)
                const isActive = i === currentIdx
                const isDone = i < currentIdx
                return (
                  <div
                    key={step}
                    className={`h-2 flex-1 rounded-full ${
                      isDone
                        ? "bg-green-500"
                        : isActive
                        ? "bg-primary"
                        : "bg-secondary"
                    }`}
                  />
                )
              })}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

export default function Tasks() {
  const [tab, setTab] = useState("all")
  const filtered =
    tab === "all"
      ? tasks
      : tab === "active"
      ? tasks.filter((t) => !["completed", "failed"].includes(t.status))
      : tasks.filter((t) => t.status === tab)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Tasks</h1>
          <p className="text-muted-foreground">
            Off-chain computation task pipeline and status
          </p>
        </div>
        <Button className="gap-2">
          <Cpu className="h-4 w-4" />
          Submit Task
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-6">
        {pipelineSteps.map((step) => {
          const Icon = statusIcon[step]
          const count = tasks.filter((t) => t.status === step).length
          return (
            <Card key={step}>
              <CardContent className="pt-4 pb-4 text-center">
                <Icon className="mx-auto mb-1 h-5 w-5 text-primary" />
                <div className="text-lg font-bold">{count}</div>
                <div className="text-xs capitalize text-muted-foreground">{step}</div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="all">All ({tasks.length})</TabsTrigger>
          <TabsTrigger value="active">
            Active ({tasks.filter((t) => !["completed", "failed"].includes(t.status)).length})
          </TabsTrigger>
          <TabsTrigger value="completed">
            Completed ({tasks.filter((t) => t.status === "completed").length})
          </TabsTrigger>
          <TabsTrigger value="failed">
            Failed ({tasks.filter((t) => t.status === "failed").length})
          </TabsTrigger>
        </TabsList>
        <TabsContent value={tab} className="mt-4 space-y-3">
          {filtered.map((task) => (
            <TaskCard key={task.id} task={task} />
          ))}
          {filtered.length === 0 && (
            <div className="py-8 text-center text-muted-foreground">
              No tasks in this category.
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
