import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import {
  Users,
  Shield,
  Cpu,
  FileCheck,
  Clock,
  Layers,
  TrendingUp,
  Activity,
} from "lucide-react"
import { networkStats, aggregationState, operators, tasks, proofs } from "@/data/mock"

function StatCard({
  title,
  value,
  subtitle,
  icon: Icon,
}: {
  title: string
  value: string | number
  subtitle: string
  icon: React.ElementType
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground">{subtitle}</p>
      </CardContent>
    </Card>
  )
}

export default function Dashboard() {
  const activeTasks = tasks.filter((t) => !["completed", "failed"].includes(t.status))
  const recentCompleted = tasks.filter((t) => t.status === "completed").slice(-3)
  const quorumPct =
    (aggregationState.signedOperators / aggregationState.totalOperators) * 100

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground">
          ZK Coprocessor AVS — EigenLayer Network Overview
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Active Operators"
          value={networkStats.activeOperators}
          subtitle={`${networkStats.totalOperators} total registered`}
          icon={Users}
        />
        <StatCard
          title="Total Stake"
          value={`${networkStats.totalStake} ETH`}
          subtitle="Across all operators"
          icon={Shield}
        />
        <StatCard
          title="Tasks Completed"
          value={networkStats.totalTasksCompleted.toLocaleString()}
          subtitle={`${activeTasks.length} currently active`}
          icon={Cpu}
        />
        <StatCard
          title="Proofs Generated"
          value={networkStats.totalProofsGenerated.toLocaleString()}
          subtitle={`Avg ${((networkStats.avgProvingTime as number) / 1000).toFixed(1)}s proving time`}
          icon={FileCheck}
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Activity className="h-5 w-5 text-primary" />
              BLS Aggregation — Epoch {aggregationState.epoch}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between text-sm">
              <span>Quorum Progress</span>
              <span className="font-medium">
                {aggregationState.signedOperators}/{aggregationState.totalOperators} operators
              </span>
            </div>
            <Progress value={quorumPct} />
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>Threshold: {aggregationState.quorumThreshold}%</span>
              <Badge variant={quorumPct >= aggregationState.quorumThreshold ? "success" : "warning"}>
                {quorumPct >= aggregationState.quorumThreshold ? "Quorum Reached" : "Awaiting Signatures"}
              </Badge>
            </div>
            <Separator />
            <div className="space-y-1 text-xs text-muted-foreground">
              <div className="flex justify-between">
                <span>Aggregate Signature</span>
                <span className="font-mono">{aggregationState.aggregateSignature}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Layers className="h-5 w-5 text-primary" />
              Network Metrics
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm">Current Epoch</span>
              <Badge variant="secondary">{networkStats.currentEpoch}</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Quorum Percentage</span>
              <span className="text-sm font-medium">{networkStats.quorumPercentage}%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Avg Proving Time</span>
              <span className="text-sm font-medium">
                {((networkStats.avgProvingTime as number) / 1000).toFixed(1)}s
              </span>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <span className="text-sm">Operator Status Breakdown</span>
            </div>
            <div className="grid grid-cols-4 gap-2 text-center text-xs">
              <div className="rounded-md bg-green-600/10 p-2">
                <div className="font-bold text-green-400">
                  {operators.filter((o) => o.status === "active").length}
                </div>
                <div className="text-muted-foreground">Active</div>
              </div>
              <div className="rounded-md bg-yellow-600/10 p-2">
                <div className="font-bold text-yellow-400">
                  {operators.filter((o) => o.status === "pending").length}
                </div>
                <div className="text-muted-foreground">Pending</div>
              </div>
              <div className="rounded-md bg-red-600/10 p-2">
                <div className="font-bold text-red-400">
                  {operators.filter((o) => o.status === "slashed").length}
                </div>
                <div className="text-muted-foreground">Slashed</div>
              </div>
              <div className="rounded-md bg-gray-600/10 p-2">
                <div className="font-bold text-gray-400">
                  {operators.filter((o) => o.status === "inactive").length}
                </div>
                <div className="text-muted-foreground">Inactive</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <TrendingUp className="h-5 w-5 text-primary" />
            Recent Completed Tasks
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recentCompleted.map((task) => (
              <div
                key={task.id}
                className="flex items-center justify-between rounded-md border p-3"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-green-600/10">
                    <FileCheck className="h-4 w-4 text-green-400" />
                  </div>
                  <div>
                    <div className="text-sm font-medium">{task.id}</div>
                    <div className="text-xs text-muted-foreground">
                      {task.proofType} — {task.computeTime ? `${(task.computeTime / 1000).toFixed(1)}s` : "N/A"}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <Badge variant="success">Completed</Badge>
                  <div className="text-xs text-muted-foreground mt-1">
                    {task.proofSize} proof — {task.gasUsed?.toLocaleString()} gas
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm font-medium">
              <Clock className="h-4 w-4 text-primary" />
              Proof Types
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>RISC Zero</span>
                <span className="font-medium">
                  {proofs.filter((p) => p.type === "risc-zero").length}
                </span>
              </div>
              <div className="flex justify-between">
                <span>SP1</span>
                <span className="font-medium">
                  {proofs.filter((p) => p.type === "sp1").length}
                </span>
              </div>
              <div className="flex justify-between">
                <span>BLS Aggregate</span>
                <span className="font-medium">
                  {proofs.filter((p) => p.type === "bls-aggregate").length}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm font-medium">
              <Activity className="h-4 w-4 text-primary" />
              Task Pipeline
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              {["queued", "executing", "proving", "aggregating", "completed", "failed"].map(
                (status) => (
                  <div key={status} className="flex justify-between">
                    <span className="capitalize">{status}</span>
                    <span className="font-medium">
                      {tasks.filter((t) => t.status === status).length}
                    </span>
                  </div>
                )
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm font-medium">
              <Shield className="h-4 w-4 text-primary" />
              Stake Distribution
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {operators
                .filter((o) => o.status === "active")
                .sort((a, b) => b.stake - a.stake)
                .map((op) => (
                  <div key={op.id} className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span className="font-mono text-xs">{op.address}</span>
                      <span className="font-medium">{op.stake} ETH</span>
                    </div>
                    <Progress
                      value={(op.stake / 96) * 100}
                      className="h-2"
                    />
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
