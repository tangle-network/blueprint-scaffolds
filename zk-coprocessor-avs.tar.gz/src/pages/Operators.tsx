import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import { Users, Search, UserPlus, Shield, TrendingUp, AlertTriangle } from "lucide-react"
import { operators } from "@/data/mock"
import type { Operator } from "@/lib/types"
import { useState } from "react"

const statusVariant: Record<Operator["status"], "success" | "warning" | "destructive" | "secondary"> = {
  active: "success",
  pending: "warning",
  slashed: "destructive",
  inactive: "secondary",
}

function OperatorRow({ op }: { op: Operator }) {
  return (
    <div className="flex items-center justify-between rounded-lg border p-4 transition-colors hover:bg-accent/50">
      <div className="flex items-center gap-4">
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
          <Users className="h-5 w-5 text-primary" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-mono text-sm font-medium">{op.address}</span>
            <Badge variant={statusVariant[op.status]}>{op.status}</Badge>
          </div>
          <div className="text-xs text-muted-foreground">
            ID: {op.id} — BLS: {op.blsPublicKey}
          </div>
        </div>
      </div>
      <div className="flex items-center gap-6 text-sm">
        <div className="text-center">
          <div className="font-bold">{op.stake} ETH</div>
          <div className="text-xs text-muted-foreground">Stake</div>
        </div>
        <div className="text-center">
          <div className="font-bold">{op.tasksCompleted.toLocaleString()}</div>
          <div className="text-xs text-muted-foreground">Tasks</div>
        </div>
        <div className="text-center">
          <div className="font-bold">{op.proofsGenerated.toLocaleString()}</div>
          <div className="text-xs text-muted-foreground">Proofs</div>
        </div>
        <div className="text-center">
          <div className="font-bold">{op.reputation}%</div>
          <div className="text-xs text-muted-foreground">Reputation</div>
        </div>
        <div className="text-center">
          <div className="text-xs text-muted-foreground">
            {new Date(op.registeredAt).toLocaleDateString()}
          </div>
          <div className="text-xs text-muted-foreground">Registered</div>
        </div>
      </div>
    </div>
  )
}

export default function Operators() {
  const [search, setSearch] = useState("")
  const filtered = operators.filter(
    (op) =>
      op.address.toLowerCase().includes(search.toLowerCase()) ||
      op.id.toLowerCase().includes(search.toLowerCase()) ||
      op.status.includes(search.toLowerCase())
  )

  const totalStake = operators.reduce((s, o) => s + o.stake, 0)
  const avgReputation =
    operators.reduce((s, o) => s + o.reputation, 0) / operators.length

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Operators</h1>
          <p className="text-muted-foreground">
            Manage EigenLayer operator registrations and stake
          </p>
        </div>
        <Button className="gap-2">
          <UserPlus className="h-4 w-4" />
          Register Operator
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Total</span>
            </div>
            <div className="mt-1 text-2xl font-bold">{operators.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Shield className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Total Stake</span>
            </div>
            <div className="mt-1 text-2xl font-bold">{totalStake} ETH</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Avg Reputation</span>
            </div>
            <div className="mt-1 text-2xl font-bold">{avgReputation.toFixed(1)}%</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Slashed</span>
            </div>
            <div className="mt-1 text-2xl font-bold">
              {operators.filter((o) => o.status === "slashed").length}
            </div>
          </CardContent>
        </Card>
      </div>

      <Separator />

      <div className="flex items-center gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search operators by address, ID, or status..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <div className="space-y-3">
        {filtered.map((op) => (
          <OperatorRow key={op.id} op={op} />
        ))}
        {filtered.length === 0 && (
          <div className="py-8 text-center text-muted-foreground">
            No operators found matching your search.
          </div>
        )}
      </div>
    </div>
  )
}
