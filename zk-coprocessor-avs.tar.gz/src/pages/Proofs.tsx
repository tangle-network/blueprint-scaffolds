import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ShieldCheck,
  CheckCircle2,
  Loader2,
  XCircle,
  Layers,
  FileCheck,
  Clock,
  Cpu,
} from "lucide-react"
import { proofs } from "@/data/mock"
import type { Proof } from "@/lib/types"
import { useState } from "react"

const statusIcon: Record<Proof["status"], React.ElementType> = {
  generating: Loader2,
  verified: CheckCircle2,
  failed: XCircle,
  aggregated: Layers,
}

const statusVariant: Record<Proof["status"], "default" | "success" | "destructive" | "secondary"> = {
  generating: "default",
  verified: "success",
  failed: "destructive",
  aggregated: "secondary",
}

function ProofCard({ proof }: { proof: Proof }) {
  const Icon = statusIcon[proof.status]
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10">
              <Icon
                className={`h-4 w-4 text-primary ${
                  proof.status === "generating" ? "animate-spin" : ""
                }`}
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-sm font-bold">{proof.id}</span>
                <Badge variant={statusVariant[proof.status]}>{proof.status}</Badge>
                <Badge variant="outline" className="text-xs">
                  {proof.type}
                </Badge>
              </div>
              <div className="mt-1 text-xs text-muted-foreground">
                Prover: {proof.prover} — Task: {proof.taskId}
              </div>
            </div>
          </div>
          <div className="text-right text-xs text-muted-foreground">
            <div>Submitted: {new Date(proof.submittedAt).toLocaleString()}</div>
            {proof.verifiedAt && (
              <div>Verified: {new Date(proof.verifiedAt).toLocaleString()}</div>
            )}
          </div>
        </div>

        <Separator className="my-3" />

        <div className="grid grid-cols-2 gap-3 text-sm md:grid-cols-4">
          <div>
            <div className="text-xs text-muted-foreground">Proof Size</div>
            <div className="text-xs font-medium">{proof.size}</div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground">Verification Gas</div>
            <div className="text-xs font-medium">
              {proof.verificationGas > 0
                ? `${proof.verificationGas.toLocaleString()} gas`
                : "—"}
            </div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground">Receipt Root</div>
            <div className="font-mono text-xs truncate">
              {proof.receiptRoot || "—"}
            </div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground">Proof System</div>
            <div className="text-xs font-medium capitalize">
              {proof.type.replace("-", " ")}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default function Proofs() {
  const [tab, setTab] = useState("all")
  const filtered =
    tab === "all"
      ? proofs
      : proofs.filter((p) => p.status === tab)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Proofs</h1>
        <p className="text-muted-foreground">
          ZK proof generation, verification, and BLS aggregation
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <FileCheck className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Total</span>
            </div>
            <div className="mt-1 text-2xl font-bold">{proofs.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-green-400" />
              <span className="text-sm text-muted-foreground">Verified</span>
            </div>
            <div className="mt-1 text-2xl font-bold">
              {proofs.filter((p) => p.status === "verified").length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Loader2 className="h-4 w-4 text-primary" />
              <span className="text-sm text-muted-foreground">Generating</span>
            </div>
            <div className="mt-1 text-2xl font-bold">
              {proofs.filter((p) => p.status === "generating").length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Layers className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Aggregated</span>
            </div>
            <div className="mt-1 text-2xl font-bold">
              {proofs.filter((p) => p.status === "aggregated").length}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="all">All ({proofs.length})</TabsTrigger>
          <TabsTrigger value="verified">
            Verified ({proofs.filter((p) => p.status === "verified").length})
          </TabsTrigger>
          <TabsTrigger value="generating">
            Generating ({proofs.filter((p) => p.status === "generating").length})
          </TabsTrigger>
          <TabsTrigger value="failed">
            Failed ({proofs.filter((p) => p.status === "failed").length})
          </TabsTrigger>
        </TabsList>
        <TabsContent value={tab} className="mt-4 space-y-3">
          {filtered.map((proof) => (
            <ProofCard key={proof.id} proof={proof} />
          ))}
          {filtered.length === 0 && (
            <div className="py-8 text-center text-muted-foreground">
              No proofs in this category.
            </div>
          )}
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <ShieldCheck className="h-5 w-5 text-primary" />
            Proof Pipeline
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <div className="flex items-center gap-1 rounded-md bg-secondary px-3 py-1.5">
              <Clock className="h-3 w-3" />
              <span>Task Received</span>
            </div>
            <span>→</span>
            <div className="flex items-center gap-1 rounded-md bg-secondary px-3 py-1.5">
              <Cpu className="h-3 w-3" />
              <span>Execute</span>
            </div>
            <span>→</span>
            <div className="flex items-center gap-1 rounded-md bg-primary/20 px-3 py-1.5 text-primary">
              <Loader2 className="h-3 w-3" />
              <span>Generate Proof</span>
            </div>
            <span>→</span>
            <div className="flex items-center gap-1 rounded-md bg-secondary px-3 py-1.5">
              <Layers className="h-3 w-3" />
              <span>BLS Aggregate</span>
            </div>
            <span>→</span>
            <div className="flex items-center gap-1 rounded-md bg-green-600/20 px-3 py-1.5 text-green-400">
              <ShieldCheck className="h-3 w-3" />
              <span>On-chain Verify</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
