import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  AlertTriangle,
  Shield,
  Gavel,
  AlertCircle,
  Clock,
  CheckCircle2,
  HelpCircle,
} from "lucide-react"
import { slashingEvents } from "@/data/mock"
import type { SlashingEvent } from "@/lib/types"

const reasonVariant: Record<
  SlashingEvent["reason"],
  "destructive" | "warning" | "default" | "secondary"
> = {
  invalid_proof: "destructive",
  missed_attestation: "warning",
  double_sign: "destructive",
  downtime: "warning",
}

const statusIcon: Record<SlashingEvent["status"], React.ElementType> = {
  pending: Clock,
  executed: CheckCircle2,
  disputed: HelpCircle,
  resolved: CheckCircle2,
}

const statusVariant: Record<SlashingEvent["status"], "default" | "success" | "warning" | "secondary"> = {
  pending: "default",
  executed: "success",
  disputed: "warning",
  resolved: "secondary",
}

export default function Slashing() {
  const totalSlashed = slashingEvents.reduce((s, e) => s + e.amount, 0)
  const uniqueOperators = new Set(slashingEvents.map((e) => e.operatorId)).size

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Slashing</h1>
        <p className="text-muted-foreground">
          EigenLayer slashing events for invalid proofs and operator misconduct
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-destructive" />
              <span className="text-sm text-muted-foreground">Total Events</span>
            </div>
            <div className="mt-1 text-2xl font-bold">{slashingEvents.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Shield className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Total Slashed</span>
            </div>
            <div className="mt-1 text-2xl font-bold">{totalSlashed} ETH</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Affected Operators</span>
            </div>
            <div className="mt-1 text-2xl font-bold">{uniqueOperators}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Gavel className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Disputed</span>
            </div>
            <div className="mt-1 text-2xl font-bold">
              {slashingEvents.filter((e) => e.status === "disputed").length}
            </div>
          </CardContent>
        </Card>
      </div>

      <Separator />

      <div className="space-y-3">
        {slashingEvents.map((event) => {
          const StatusIcon = statusIcon[event.status]
          return (
            <Card key={event.id}>
              <CardContent className="pt-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-full bg-destructive/10">
                      <AlertTriangle className="h-4 w-4 text-destructive" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sm font-bold">{event.id}</span>
                        <Badge variant={reasonVariant[event.reason]}>
                          {event.reason.replace("_", " ")}
                        </Badge>
                        <Badge variant={statusVariant[event.status]}>
                          <StatusIcon className="mr-1 h-3 w-3" />
                          {event.status}
                        </Badge>
                      </div>
                      <div className="mt-1 text-xs text-muted-foreground">
                        Operator: {event.operatorAddress} — {event.operatorId}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-destructive">
                      -{event.amount} ETH
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {new Date(event.timestamp).toLocaleString()}
                    </div>
                  </div>
                </div>
                <Separator className="my-3" />
                <div className="text-sm">
                  <div className="text-xs text-muted-foreground">Evidence</div>
                  <div className="text-sm">{event.evidence}</div>
                </div>
                {event.taskId && (
                  <div className="mt-2 text-xs text-muted-foreground">
                    Related Task: <span className="font-mono">{event.taskId}</span>
                  </div>
                )}
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
