import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Coins,
  Gift,
  CheckCircle2,
  Clock,
  TrendingUp,
  Users,
} from "lucide-react"
import { rewards } from "@/data/mock"
import type { Reward } from "@/lib/types"
import { useState } from "react"

const typeLabel: Record<Reward["type"], string> = {
  task_reward: "Task Reward",
  stake_reward: "Stake Reward",
  attestation_reward: "Attestation Reward",
}

export default function Rewards() {
  const [tab, setTab] = useState("all")
  const filtered =
    tab === "all"
      ? rewards
      : tab === "claimed"
      ? rewards.filter((r) => r.claimed)
      : rewards.filter((r) => !r.claimed)

  const totalDistributed = rewards.reduce((s, r) => s + r.amount, 0)
  const totalClaimed = rewards.filter((r) => r.claimed).reduce((s, r) => s + r.amount, 0)
  const totalUnclaimed = totalDistributed - totalClaimed

  const byType = rewards.reduce(
    (acc, r) => {
      acc[r.type] = (acc[r.type] || 0) + r.amount
      return acc
    },
    {} as Record<string, number>
  )

  const byOperator = rewards.reduce(
    (acc, r) => {
      if (!acc[r.operatorId]) acc[r.operatorId] = { address: r.operatorAddress, total: 0, claimed: 0 }
      acc[r.operatorId].total += r.amount
      if (r.claimed) acc[r.operatorId].claimed += r.amount
      return acc
    },
    {} as Record<string, { address: string; total: number; claimed: number }>
  )

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Rewards</h1>
        <p className="text-muted-foreground">
          Operator reward distribution and claiming status
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Coins className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Total Distributed</span>
            </div>
            <div className="mt-1 text-2xl font-bold">{totalDistributed.toFixed(2)} ETH</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-green-400" />
              <span className="text-sm text-muted-foreground">Claimed</span>
            </div>
            <div className="mt-1 text-2xl font-bold text-green-400">
              {totalClaimed.toFixed(2)} ETH
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-yellow-400" />
              <span className="text-sm text-muted-foreground">Unclaimed</span>
            </div>
            <div className="mt-1 text-2xl font-bold text-yellow-400">
              {totalUnclaimed.toFixed(2)} ETH
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Unique Operators</span>
            </div>
            <div className="mt-1 text-2xl font-bold">{Object.keys(byOperator).length}</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Gift className="h-5 w-5 text-primary" />
              Rewards by Type
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {Object.entries(byType).map(([type, amount]) => (
              <div key={type} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{typeLabel[type as Reward["type"]] || type}</span>
                </div>
                <span className="font-medium">{amount.toFixed(2)} ETH</span>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Users className="h-5 w-5 text-primary" />
              Rewards by Operator
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {Object.entries(byOperator).map(([opId, data]) => (
              <div key={opId} className="space-y-1">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-mono text-xs">{data.address}</span>
                  <span className="font-medium">{data.total.toFixed(2)} ETH</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span>
                    Claimed: {data.claimed.toFixed(2)} / {data.total.toFixed(2)} ETH
                  </span>
                  <span>({((data.claimed / data.total) * 100).toFixed(0)}%)</span>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-secondary">
                  <div
                    className="h-full bg-green-500 transition-all"
                    style={{ width: `${(data.claimed / data.total) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Separator />

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="all">All ({rewards.length})</TabsTrigger>
          <TabsTrigger value="claimed">
            Claimed ({rewards.filter((r) => r.claimed).length})
          </TabsTrigger>
          <TabsTrigger value="unclaimed">
            Unclaimed ({rewards.filter((r) => !r.claimed).length})
          </TabsTrigger>
        </TabsList>
        <TabsContent value={tab} className="mt-4">
          <div className="space-y-2">
            {filtered.map((reward) => (
              <div
                key={reward.id}
                className="flex items-center justify-between rounded-lg border p-3"
              >
                <div className="flex items-center gap-3">
                  <Coins className="h-4 w-4 text-primary" />
                  <div>
                    <div className="flex items-center gap-2 text-sm">
                      <span className="font-mono">{reward.id}</span>
                      <Badge variant="outline">{typeLabel[reward.type]}</Badge>
                      <Badge variant={reward.claimed ? "success" : "warning"}>
                        {reward.claimed ? "Claimed" : "Unclaimed"}
                      </Badge>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {reward.operatorAddress} — Epoch {reward.epoch}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold">{reward.amount} ETH</div>
                  <div className="text-xs text-muted-foreground">
                    {new Date(reward.timestamp).toLocaleDateString()}
                  </div>
                </div>
              </div>
            ))}
            {filtered.length === 0 && (
              <div className="py-8 text-center text-muted-foreground">
                No rewards in this category.
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
