export type OperatorStatus = 'active' | 'inactive' | 'slashed' | 'pending'

export interface Operator {
  id: string
  address: string
  stake: string
  status: OperatorStatus
  tasksCompleted: number
  tasksFailed: number
  registeredAt: number
  lastActiveAt: number
  blsPublicKey: string
  proofCount: number
  reputation: number
}

export type TaskStatus = 'pending' | 'assigned' | 'computing' | 'proving' | 'verified' | 'failed' | 'disputed'

export type ProofSystem = 'risc-zero' | 'sp1' | 'cairo'

export interface ComputationTask {
  id: string
  requester: string
  programHash: string
  inputHash: string
  outputHash: string
  proofSystem: ProofSystem
  status: TaskStatus
  assignedOperators: string[]
  createdAt: number
  completedAt: number | null
  proofHash: string | null
  quorumThreshold: number
  signatureCount: number
  gasUsed: string
  reward: string
  description: string
}

export interface ZKProof {
  id: string
  taskId: string
  operator: string
  proofSystem: ProofSystem
  proofData: string
  publicInputs: string
  verified: boolean
  submittedAt: number
  verifiedAt: number | null
  verifierAddress: string
  journal: string
  cycleCount: number
}

export interface AggregatedSignature {
  id: string
  taskId: string
  operatorIds: string[]
  signature: string
  thresholdMet: boolean
  participantCount: number
  totalOperators: number
  quorumPercentage: number
  createdAt: number
}

export interface SlashingEvent {
  id: string
  operator: string
  operatorStakeBefore: string
  amountSlashed: string
  reason: string
  taskId: string | null
  proofHash: string | null
  timestamp: number
  reporter: string
  resolved: boolean
}

export interface RewardDistribution {
  id: string
  operator: string
  amount: string
  taskId: string | null
  timestamp: number
  cumulativeRewards: string
  type: 'task_completion' | 'proof_verification' | 'staking'
}

export interface NetworkStats {
  totalOperators: number
  activeOperators: number
  totalStake: string
  totalTasksCompleted: number
  totalProofsVerified: number
  averageProvingTime: number
  quorumThreshold: number
  slashingRate: number
  totalRewardsDistributed: string
}
