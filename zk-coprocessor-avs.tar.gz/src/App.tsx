import {
  Activity,
  BadgeCheck,
  Binary,
  Blocks,
  Coins,
  Cpu,
  Scale,
  ShieldAlert
} from "lucide-react";
import { contracts, metrics, operators, pipeline, snippets } from "./data";

const statusTone: Record<string, string> = {
  Active: "is-active",
  Syncing: "is-syncing",
  Challenged: "is-challenged"
};

export default function App() {
  return (
    <div className="shell">
      <header className="hero">
        <div className="hero__copy">
          <p className="eyebrow">EigenLayer AVS / ZK Coprocessor</p>
          <h1>Verifiable off-chain compute with stake-backed proof settlement.</h1>
          <p className="hero__lede">
            This operator dashboard models an AVS that executes heavy workloads
            off-chain, generates ZK proofs with RISC Zero or SP1, aggregates BLS
            signatures, and settles only after a 67% stake quorum.
          </p>
          <div className="hero__actions">
            <a href="#pipeline" className="button button--primary">
              Review pipeline
            </a>
            <a href="#operators" className="button button--ghost">
              Inspect operators
            </a>
          </div>
        </div>
        <div className="hero__panel">
          <div className="signal">
            <span className="signal__label">Live quorum</span>
            <strong>71.4%</strong>
            <span className="signal__meta">4 / 5 active operators signed</span>
          </div>
          <div className="signal-grid">
            <article>
              <BadgeCheck size={18} />
              <span>Proof receipts verified</span>
              <strong>128</strong>
            </article>
            <article>
              <ShieldAlert size={18} />
              <span>Slash events this epoch</span>
              <strong>1</strong>
            </article>
            <article>
              <Coins size={18} />
              <span>Rewards pending</span>
              <strong>42.6 ETH</strong>
            </article>
            <article>
              <Cpu size={18} />
              <span>Avg proving time</span>
              <strong>94 sec</strong>
            </article>
          </div>
        </div>
      </header>

      <main>
        <section className="metrics">
          {metrics.map((metric) => (
            <article className="metric-card" key={metric.label}>
              <p>{metric.label}</p>
              <strong>{metric.value}</strong>
              <span>{metric.note}</span>
            </article>
          ))}
        </section>

        <section className="section" id="pipeline">
          <div className="section__heading">
            <span className="section__tag">
              <Binary size={16} />
              Proof pipeline
            </span>
            <h2>Execution, proving, aggregation, settlement.</h2>
          </div>
          <div className="timeline">
            {pipeline.map((stage) => (
              <article className="timeline-card" key={stage.title}>
                <h3>{stage.title}</h3>
                <p>{stage.summary}</p>
                <ul>
                  {stage.details.map((detail) => (
                    <li key={detail}>{detail}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </section>

        <section className="section section--split">
          <div className="stack">
            <div className="section__heading">
              <span className="section__tag">
                <Blocks size={16} />
                On-chain modules
              </span>
              <h2>Contracts enforcing registration, proofs, slashing, rewards.</h2>
            </div>
            <div className="contract-grid">
              {contracts.map((contract) => (
                <article className="contract-card" key={contract.title}>
                  <h3>{contract.title}</h3>
                  <p>{contract.description}</p>
                  <ul>
                    {contract.functions.map((fn) => (
                      <li key={fn}>{fn}</li>
                    ))}
                  </ul>
                </article>
              ))}
            </div>
          </div>

          <aside className="side-panel">
            <div className="section__heading">
              <span className="section__tag">
                <Scale size={16} />
                EigenLayer policy
              </span>
              <h2>Stake, quorum, and slash conditions.</h2>
            </div>
            <div className="policy-list">
              <article>
                <h3>Operator admission</h3>
                <p>
                  Operators register with a BLS public key and at least 32 ETH
                  restaked into the AVS.
                </p>
              </article>
              <article>
                <h3>Fault handling</h3>
                <p>
                  Invalid proofs, equivocation, or unavailable task execution can
                  trigger challenge windows and stake slashing.
                </p>
              </article>
              <article>
                <h3>Reward distribution</h3>
                <p>
                  Fees and AVS incentives are distributed per epoch in proportion
                  to stake weight and successful task participation.
                </p>
              </article>
            </div>
          </aside>
        </section>

        <section className="section" id="operators">
          <div className="section__heading">
            <span className="section__tag">
              <Activity size={16} />
              Operator set
            </span>
            <h2>Current nodes participating in quorum formation.</h2>
          </div>
          <div className="operator-table">
            <div className="operator-table__head">
              <span>Operator</span>
              <span>Status</span>
              <span>Delegated stake</span>
              <span>Proof backend</span>
              <span>Recent task</span>
            </div>
            {operators.map((operator) => (
              <div className="operator-row" key={operator.name}>
                <strong>{operator.name}</strong>
                <span className={`pill ${statusTone[operator.status]}`}>
                  {operator.status}
                </span>
                <span>{operator.stake}</span>
                <span>{operator.proofSystem}</span>
                <span>{operator.lastTask}</span>
              </div>
            ))}
          </div>
        </section>

        <section className="section section--split">
          <div className="stack">
            <div className="section__heading">
              <span className="section__tag">
                <Cpu size={16} />
                Operator software
              </span>
              <h2>Reference node responsibilities.</h2>
            </div>
            <div className="responsibility-grid">
              <article>
                <h3>Task executor</h3>
                <p>
                  Pulls task commitments from the AVS, reconstructs inputs, and
                  runs deterministic workloads inside a sandboxed runtime.
                </p>
              </article>
              <article>
                <h3>Proof worker</h3>
                <p>
                  Invokes RISC Zero or SP1 prover backends, persists receipts,
                  and exposes challenge evidence for invalid states.
                </p>
              </article>
              <article>
                <h3>BLS attestor</h3>
                <p>
                  Signs result digests and forwards partial signatures to the
                  aggregator after local verification completes.
                </p>
              </article>
            </div>
          </div>

          <div className="stack">
            <div className="section__heading">
              <span className="section__tag">
                <Binary size={16} />
                Reference snippets
              </span>
              <h2>Execution loop and settlement callback examples.</h2>
            </div>
            <div className="snippet-grid">
              {snippets.map((snippet) => (
                <article className="snippet-card" key={snippet.title}>
                  <div className="snippet-card__header">
                    <h3>{snippet.title}</h3>
                    <span>{snippet.language}</span>
                  </div>
                  <pre>
                    <code>{snippet.content}</code>
                  </pre>
                </article>
              ))}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
