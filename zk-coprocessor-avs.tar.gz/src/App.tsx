import { Routes, Route, NavLink, Outlet } from "react-router-dom"
import {
  LayoutDashboard,
  Users,
  ListTodo,
  ShieldCheck,
  AlertTriangle,
  Coins,
  Zap,
} from "lucide-react"
import { cn } from "@/lib/utils"

const navItems = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard },
  { to: "/operators", label: "Operators", icon: Users },
  { to: "/tasks", label: "Tasks", icon: ListTodo },
  { to: "/proofs", label: "Proofs", icon: ShieldCheck },
  { to: "/slashing", label: "Slashing", icon: AlertTriangle },
  { to: "/rewards", label: "Rewards", icon: Coins },
]

function Sidebar() {
  return (
    <aside className="fixed left-0 top-0 z-40 h-screen w-64 border-r bg-card">
      <div className="flex h-16 items-center gap-2 border-b px-6">
        <Zap className="h-6 w-6 text-primary" />
        <div>
          <h1 className="text-sm font-bold leading-tight">ZK Coprocessor</h1>
          <p className="text-xs text-muted-foreground">EigenLayer AVS</p>
        </div>
      </div>
      <nav className="flex flex-col gap-1 p-4">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === "/"}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                isActive
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              )
            }
          >
            <item.icon className="h-4 w-4" />
            {item.label}
          </NavLink>
        ))}
      </nav>
    </aside>
  )
}

function Layout() {
  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main className="ml-64 p-6">
        <Outlet />
      </main>
    </div>
  )
}

import DashboardPage from "./pages/Dashboard"
import OperatorsPage from "./pages/Operators"
import TasksPage from "./pages/Tasks"
import ProofsPage from "./pages/Proofs"
import SlashingPage from "./pages/Slashing"
import RewardsPage from "./pages/Rewards"

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<DashboardPage />} />
        <Route path="operators" element={<OperatorsPage />} />
        <Route path="tasks" element={<TasksPage />} />
        <Route path="proofs" element={<ProofsPage />} />
        <Route path="slashing" element={<SlashingPage />} />
        <Route path="rewards" element={<RewardsPage />} />
      </Route>
    </Routes>
  )
}
