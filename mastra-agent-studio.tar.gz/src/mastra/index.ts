import { Mastra } from "@mastra/core/mastra";
import { supportAgent } from "./agents/support-agent";
import { researchAgent } from "./agents/research-agent";
import { opsAgent } from "./agents/ops-agent";
import { supportWorkflow } from "./workflows/support-workflow";

export const mastra = new Mastra({
  agents: { supportAgent, researchAgent, opsAgent },
  workflows: { supportWorkflow },
});
