import { createStep, createWorkflow } from "@mastra/core/workflows";
import { z } from "zod";

const triageStep = createStep({
  id: "triage",
  description: "Triage the incoming support request",
  execute: async ({ inputData }) => {
    const msg = (inputData as any).customerMessage?.toLowerCase() || "";
    let category = "general";
    let severity = "low";
    let requiresEscalation = false;

    if (msg.includes("billing") || msg.includes("payment") || msg.includes("charge")) {
      category = "billing";
      severity = "medium";
    } else if (msg.includes("down") || msg.includes("outage") || msg.includes("cannot access")) {
      category = "incident";
      severity = "critical";
      requiresEscalation = true;
    } else if (msg.includes("bug") || msg.includes("error") || msg.includes("broken")) {
      category = "bug";
      severity = "high";
    } else if (msg.includes("feature") || msg.includes("request")) {
      category = "feature-request";
      severity = "low";
    }

    return {
      category,
      severity,
      summary: `Support request categorized as ${category} with ${severity} severity`,
      requiresEscalation,
      suggestedAction: requiresEscalation ? "escalate" : "auto-respond",
    };
  },
});

const searchKnowledgeStep = createStep({
  id: "search-knowledge",
  description: "Search knowledge base for relevant solutions",
  execute: async () => {
    return {
      found: true,
      articles: [
        { title: "Common Authentication Issues", relevance: 0.92 },
        { title: "API Rate Limiting Guide", relevance: 0.78 },
      ],
      suggestedResponse: "Based on our knowledge base, please try the following steps...",
    };
  },
});

const respondStep = createStep({
  id: "respond",
  description: "Generate and send response to customer",
  execute: async () => {
    const ticketId = `TKT-${Date.now().toString(36).toUpperCase()}`;
    return {
      responseSent: true,
      ticketId,
      responsePreview: `Thank you for contacting CloudStream support. We've reviewed your request and created ticket ${ticketId}. Our team will follow up shortly.`,
    };
  },
});

const escalateStep = createStep({
  id: "escalate",
  description: "Escalate critical issues to engineering",
  execute: async () => {
    const escalationId = `ESC-${Date.now().toString(36).toUpperCase()}`;
    return {
      escalationId,
      channel: "#ops-alerts",
      assignedTeam: "engineering-oncall",
    };
  },
});

export const supportWorkflow = createWorkflow({
  id: "support-workflow",
  inputSchema: z.object({
    customerMessage: z.string(),
    customerEmail: z.string().optional(),
    priority: z.enum(["critical", "high", "medium", "low"]).optional(),
  }),
  outputSchema: z.object({
    responseSent: z.boolean(),
    ticketId: z.string(),
    responsePreview: z.string(),
  }),
  steps: [triageStep, searchKnowledgeStep, respondStep, escalateStep],
});

supportWorkflow
  .then(triageStep)
  .branch([
    [
      async (ctx) => {
        const triage = (ctx as any)?.triage;
        return triage?.requiresEscalation === true;
      },
      escalateStep,
    ],
  ])
  .then(searchKnowledgeStep)
  .then(respondStep);

supportWorkflow.commit();
