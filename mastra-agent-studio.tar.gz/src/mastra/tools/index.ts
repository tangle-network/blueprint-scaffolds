import { createTool } from "@mastra/core/tools";
import { z } from "zod";

export const createTicketTool = createTool({
  id: "create-ticket",
  description: "Create a support ticket with severity, category, and description",
  inputSchema: z.object({
    title: z.string().describe("Ticket title"),
    description: z.string().describe("Detailed description of the issue"),
    severity: z.enum(["critical", "high", "medium", "low"]).describe("Issue severity level"),
    category: z.enum(["bug", "feature-request", "billing", "technical", "account"]).describe("Ticket category"),
    customerId: z.string().optional().describe("Customer ID if available"),
  }),
  outputSchema: z.object({
    ticketId: z.string(),
    status: z.string(),
    message: z.string(),
  }),
  execute: async ({ context }) => {
    const ticketId = `TKT-${Date.now().toString(36).toUpperCase()}`;
    return {
      ticketId,
      status: "created",
      message: `Ticket ${ticketId} created with severity ${context.severity} in category ${context.category}`,
    };
  },
});

export const escalateTool = createTool({
  id: "escalate",
  description: "Escalate an issue to the engineering team with context",
  inputSchema: z.object({
    ticketId: z.string().describe("The ticket to escalate"),
    reason: z.string().describe("Reason for escalation"),
    urgency: z.enum(["immediate", "within-hour", "within-day"]).describe("How quickly the team needs to respond"),
    affectedUsers: z.number().optional().describe("Estimated number of affected users"),
  }),
  outputSchema: z.object({
    escalationId: z.string(),
    channel: z.string(),
    message: z.string(),
  }),
  execute: async ({ context }) => {
    const escalationId = `ESC-${Date.now().toString(36).toUpperCase()}`;
    return {
      escalationId,
      channel: "#ops-alerts",
      message: `Escalation ${escalationId} created for ticket ${context.ticketId}. Reason: ${context.reason}. Urgency: ${context.urgency}. Affected users: ${context.affectedUsers || "unknown"}`,
    };
  },
});

export const knowledgeSearchTool = createTool({
  id: "knowledge-search",
  description: "Search the knowledge base for relevant articles and solutions",
  inputSchema: z.object({
    query: z.string().describe("Search query"),
    category: z.string().optional().describe("Optional category filter"),
    maxResults: z.number().optional().describe("Maximum results to return"),
  }),
  outputSchema: z.object({
    results: z.array(z.object({
      title: z.string(),
      content: z.string(),
      relevance: z.number(),
      category: z.string(),
    })),
    totalFound: z.number(),
  }),
  execute: async ({ context }) => {
    const maxResults = context.maxResults || 5;
    return {
      results: [
        {
          title: "Common Authentication Issues",
          content: "If users cannot log in, check SSO configuration, token expiry settings, and session management policies.",
          relevance: 0.92,
          category: "authentication",
        },
        {
          title: "API Rate Limiting Guide",
          content: "Rate limits are applied per API key. Free tier: 100 req/min, Pro tier: 1000 req/min, Enterprise: custom.",
          relevance: 0.78,
          category: "api",
        },
        {
          title: "Database Connection Troubleshooting",
          content: "Verify connection string, check firewall rules, ensure IP allowlisting includes our CIDR ranges.",
          relevance: 0.65,
          category: "infrastructure",
        },
      ].slice(0, maxResults),
      totalFound: 3,
    };
  },
});

export const webSearchTool = createTool({
  id: "web-search",
  description: "Search the web for current information on a topic",
  inputSchema: z.object({
    query: z.string().describe("Search query"),
    depth: z.enum(["quick", "thorough", "deep"]).optional().describe("Search depth"),
  }),
  outputSchema: z.object({
    results: z.array(z.object({
      title: z.string(),
      url: z.string(),
      snippet: z.string(),
      date: z.string(),
    })),
    queryUsed: z.string(),
  }),
  execute: async ({ context }) => {
    return {
      results: [
        { title: "Latest Industry Trends Report 2026", url: "https://example.com/trends-2026", snippet: "Comprehensive analysis of current market trends...", date: "2026-03-28" },
        { title: "Technology Landscape Overview", url: "https://example.com/tech-landscape", snippet: "Deep dive into the technology ecosystem...", date: "2026-03-15" },
      ],
      queryUsed: context.query,
    };
  },
});

export const summarizeTool = createTool({
  id: "summarize",
  description: "Summarize a block of text into key points",
  inputSchema: z.object({
    text: z.string().describe("Text to summarize"),
    maxLength: z.number().optional().describe("Maximum summary length"),
    format: z.enum(["paragraph", "bullet-points", "executive"]).optional(),
  }),
  outputSchema: z.object({
    summary: z.string(),
    keyPoints: z.array(z.string()),
    wordCount: z.number(),
  }),
  execute: async ({ context }) => {
    return {
      summary: context.text.slice(0, context.maxLength || 500),
      keyPoints: ["Key finding 1 from the research", "Key finding 2 from the research", "Key finding 3 from the research"],
      wordCount: context.text.split(" ").length,
    };
  },
});

export const citeSourcesTool = createTool({
  id: "cite-sources",
  description: "Format and validate source citations",
  inputSchema: z.object({
    sources: z.array(z.object({
      title: z.string(),
      url: z.string().optional(),
      author: z.string().optional(),
      date: z.string().optional(),
    })),
    style: z.enum(["apa", "mla", "chicago"]).optional(),
  }),
  outputSchema: z.object({
    citations: z.array(z.string()),
    formatted: z.string(),
  }),
  execute: async ({ context }) => {
    const citations = context.sources.map((s, i) => {
      const author = s.author || "Unknown Author";
      const date = s.date || "n.d.";
      const title = s.title;
      return `[${i + 1}] ${author}. "${title}". ${date}. ${s.url || ""}`;
    });
    return {
      citations,
      formatted: citations.join("\n"),
    };
  },
});

export const runDiagnosticsTool = createTool({
  id: "run-diagnostics",
  description: "Run system diagnostics on specified services",
  inputSchema: z.object({
    service: z.enum(["api", "database", "cache", "queue", "storage", "cdn"]).describe("Service to diagnose"),
    verbose: z.boolean().optional().describe("Include verbose output"),
  }),
  outputSchema: z.object({
    service: z.string(),
    status: z.enum(["healthy", "degraded", "down"]),
    latencyMs: z.number(),
    details: z.string(),
    timestamp: z.string(),
  }),
  execute: async ({ context }) => {
    const latencies: Record<string, number> = { api: 45, database: 12, cache: 3, queue: 28, storage: 156, cdn: 22 };
    return {
      service: context.service,
      status: "healthy" as const,
      latencyMs: latencies[context.service] || 50,
      details: `${context.service} service is operating normally. All endpoints responding within SLA.`,
      timestamp: new Date().toISOString(),
    };
  },
});

export const deployTool = createTool({
  id: "deploy",
  description: "Trigger a deployment for a specified service",
  inputSchema: z.object({
    service: z.string().describe("Service name to deploy"),
    environment: z.enum(["staging", "production"]).describe("Target environment"),
    version: z.string().describe("Version or commit hash to deploy"),
    rollback: z.boolean().optional().describe("Whether this is a rollback deployment"),
  }),
  outputSchema: z.object({
    deploymentId: z.string(),
    status: z.string(),
    message: z.string(),
    estimatedTime: z.string(),
  }),
  execute: async ({ context }) => {
    const deploymentId = `DEP-${Date.now().toString(36).toUpperCase()}`;
    return {
      deploymentId,
      status: "initiated",
      message: `Deployment of ${context.service}@${context.version} to ${context.environment} has been initiated.${context.rollback ? " (ROLLBACK)" : ""}`,
      estimatedTime: "3-5 minutes",
    };
  },
});

export const notifySlackTool = createTool({
  id: "notify-slack",
  description: "Send a notification to a Slack channel",
  inputSchema: z.object({
    channel: z.string().describe("Slack channel name"),
    message: z.string().describe("Message to send"),
    severity: z.enum(["info", "warning", "critical"]).optional().describe("Message severity"),
    mention: z.array(z.string()).optional().describe("Users or groups to mention"),
  }),
  outputSchema: z.object({
    messageId: z.string(),
    channel: z.string(),
    sentAt: z.string(),
  }),
  execute: async ({ context }) => {
    return {
      messageId: `msg-${Date.now().toString(36)}`,
      channel: context.channel,
      sentAt: new Date().toISOString(),
    };
  },
});

export const checkStatusTool = createTool({
  id: "check-status",
  description: "Check the status of a service or deployment",
  inputSchema: z.object({
    target: z.string().describe("Service name or deployment ID"),
    type: z.enum(["service", "deployment", "incident"]).describe("Type of status to check"),
  }),
  outputSchema: z.object({
    target: z.string(),
    status: z.string(),
    uptime: z.string(),
    lastIncident: z.string().optional(),
    details: z.string(),
  }),
  execute: async ({ context }) => {
    return {
      target: context.target,
      status: "operational",
      uptime: "99.97%",
      lastIncident: "2026-03-20T14:30:00Z",
      details: `${context.target} is running normally. No active incidents.`,
    };
  },
});
