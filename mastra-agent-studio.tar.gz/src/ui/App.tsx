import { useEffect, useState } from "react";
import type { DashboardPayload, SupportRunInput, SupportRunRecord } from "../shared/types";

const defaultInput: SupportRunInput = {
  requester: "Avery from ACME",
  customerTier: "enterprise",
  channel: "email",
  prompt:
    "Our SSO login is failing for all EU users after an IdP certificate rotation. We need an urgent update because payroll closes in two hours."
};

export function App() {
  const [dashboard, setDashboard] = useState<DashboardPayload | null>(null);
  const [input, setInput] = useState<SupportRunInput>(defaultInput);
  const [activeRun, setActiveRun] = useState<SupportRunRecord | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    void fetch("/api/dashboard")
      .then(async (response) => response.json())
      .then((payload: DashboardPayload) => {
        setDashboard(payload);
        setActiveRun(payload.recentRuns[0] ?? null);
      })
      .catch((fetchError) => {
        setError(fetchError instanceof Error ? fetchError.message : "Failed to load dashboard");
      });
  }, []);

  async function submitPrompt() {
    setSubmitting(true);
    setError(null);

    try {
      const response = await fetch("/api/runs", {
        method: "POST",
        headers: {
          "content-type": "application/json"
        },
        body: JSON.stringify(input)
      });

      if (!response.ok) {
        const payload = (await response.json()) as { error?: string };
        throw new Error(payload.error ?? "Workflow failed");
      }

      const record = (await response.json()) as SupportRunRecord;
      setActiveRun(record);
      setDashboard((current) =>
        current
          ? {
              ...current,
              recentRuns: [record, ...current.recentRuns].slice(0, 12)
            }
          : current
      );
    } catch (submitError) {
      setError(submitError instanceof Error ? submitError.message : "Failed to run workflow");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main className="shell">
      <section className="hero">
        <div>
          <p className="eyebrow">Mastra Agent Studio</p>
          <h1>{dashboard?.title ?? "Support Operations Control Room"}</h1>
          <p className="lede">{dashboard?.subtitle ?? "Loading runtime context..."}</p>
        </div>
        <div className="stat-band">
          <article>
            <span>Agents</span>
            <strong>{dashboard?.agents.length ?? 0}</strong>
          </article>
          <article>
            <span>Tools</span>
            <strong>{dashboard?.tools.length ?? 0}</strong>
          </article>
          <article>
            <span>Recent traces</span>
            <strong>{dashboard?.recentRuns.length ?? 0}</strong>
          </article>
        </div>
      </section>

      <section className="grid">
        <div className="panel prompt-panel">
          <header className="panel-header">
            <h2>Prompt Studio</h2>
            <p>Run the support workflow end-to-end against a realistic ticket.</p>
          </header>

          <label>
            Requester
            <input
              value={input.requester}
              onChange={(event) => setInput((current) => ({ ...current, requester: event.target.value }))}
            />
          </label>

          <div className="split">
            <label>
              Tier
              <select
                value={input.customerTier}
                onChange={(event) =>
                  setInput((current) => ({
                    ...current,
                    customerTier: event.target.value as SupportRunInput["customerTier"]
                  }))
                }
              >
                <option value="free">Free</option>
                <option value="business">Business</option>
                <option value="enterprise">Enterprise</option>
              </select>
            </label>
            <label>
              Channel
              <select
                value={input.channel}
                onChange={(event) =>
                  setInput((current) => ({
                    ...current,
                    channel: event.target.value as SupportRunInput["channel"]
                  }))
                }
              >
                <option value="email">Email</option>
                <option value="chat">Chat</option>
                <option value="slack">Slack</option>
              </select>
            </label>
          </div>

          <label>
            Prompt
            <textarea
              rows={8}
              value={input.prompt}
              onChange={(event) => setInput((current) => ({ ...current, prompt: event.target.value }))}
            />
          </label>

          <button className="action" disabled={submitting} onClick={() => void submitPrompt()}>
            {submitting ? "Running workflow..." : "Run support workflow"}
          </button>

          {error ? <p className="error">{error}</p> : null}
        </div>

        <div className="panel traces-panel">
          <header className="panel-header">
            <h2>Traces</h2>
            <p>Execution runs, agent handoffs, and scored workflow outputs.</p>
          </header>

          <div className="trace-list">
            {(dashboard?.recentRuns ?? []).map((run) => (
              <button key={run.id} className="trace-item" onClick={() => setActiveRun(run)}>
                <span>{run.triage.severity}</span>
                <strong>{run.input.requester}</strong>
                <small>{run.id}</small>
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="grid lower-grid">
        <div className="panel output-panel">
          <header className="panel-header">
            <h2>Output</h2>
            <p>Internal triage, research notes, and customer-safe response.</p>
          </header>

          {activeRun ? (
            <div className="stack">
              <article className="callout">
                <span>Queue</span>
                <strong>{activeRun.triage.queue}</strong>
                <small>
                  {activeRun.triage.severity} priority · {activeRun.triage.slaHours}h SLA
                </small>
              </article>

              <section>
                <h3>Triage Summary</h3>
                <p>{activeRun.triage.summary}</p>
              </section>

              <section>
                <h3>Research</h3>
                <ul>
                  {activeRun.research.findings.map((finding) => (
                    <li key={finding}>{finding}</li>
                  ))}
                </ul>
              </section>

              <section>
                <h3>Internal Plan</h3>
                <p>{activeRun.output.internalPlan}</p>
              </section>

              <section>
                <h3>Customer Reply</h3>
                <pre>{activeRun.output.customerReply}</pre>
              </section>

              <section>
                <h3>Evaluations</h3>
                <div className="eval-grid">
                  {activeRun.evaluations.map((evaluation) => (
                    <article key={evaluation.label}>
                      <strong>{evaluation.label}</strong>
                      <span>{evaluation.score.toFixed(2)}</span>
                      <p>{evaluation.reason}</p>
                    </article>
                  ))}
                </div>
              </section>
            </div>
          ) : (
            <p className="empty">Run the workflow to inspect a trace.</p>
          )}
        </div>

        <div className="panel side-panel">
          <header className="panel-header">
            <h2>Runtime</h2>
            <p>Registered agents, tools, and scheduled automation.</p>
          </header>

          <section>
            <h3>Agents</h3>
            <div className="chips">
              {(dashboard?.agents ?? []).map((agent) => (
                <article key={agent.id} className="mini-card">
                  <strong>{agent.name}</strong>
                  <p>{agent.role}</p>
                  <small>{agent.memory}</small>
                </article>
              ))}
            </div>
          </section>

          <section>
            <h3>Scheduled Jobs</h3>
            <div className="stack">
              {(dashboard?.jobs ?? []).map((job) => (
                <article key={job.id} className="mini-card">
                  <strong>{job.label}</strong>
                  <p>{job.summary}</p>
                  <small>
                    {job.cadence} · {job.status}
                  </small>
                </article>
              ))}
            </div>
          </section>

          <section>
            <h3>Tool Registry</h3>
            <div className="stack">
              {(dashboard?.tools ?? []).map((tool) => (
                <article key={tool.id} className="mini-card">
                  <strong>{tool.id}</strong>
                  <p>{tool.description}</p>
                  <small>{tool.category}</small>
                </article>
              ))}
            </div>
          </section>
        </div>
      </section>
    </main>
  );
}
