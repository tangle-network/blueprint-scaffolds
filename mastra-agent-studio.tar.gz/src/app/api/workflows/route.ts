import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    workflows: [
      {
        id: "support-workflow",
        name: "Support Pipeline",
        status: "active",
        steps: ["triage", "search-knowledge", "respond", "escalate"],
        totalRuns: 89,
        successRate: 0.94,
      },
    ],
  });
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { customerMessage } = body;

    const msg = (customerMessage || "").toLowerCase();
    let category = "general";
    let severity = "low";
    let escalated = false;

    if (msg.includes("billing") || msg.includes("payment")) {
      category = "billing";
      severity = "medium";
    } else if (msg.includes("down") || msg.includes("outage")) {
      category = "incident";
      severity = "critical";
      escalated = true;
    } else if (msg.includes("bug") || msg.includes("error")) {
      category = "bug";
      severity = "high";
    }

    const ticketId = `TKT-${Date.now().toString(36).toUpperCase()}`;

    return NextResponse.json({
      status: "completed",
      result: {
        triage: { category, severity, requiresEscalation: escalated },
        response: { ticketId, responseSent: true, responsePreview: `Thank you for contacting CloudStream support. We've categorized your issue as ${category} with ${severity} severity. Ticket ${ticketId} has been created.` },
        ...(escalated ? { escalation: { escalationId: `ESC-${Date.now().toString(36).toUpperCase()}`, channel: "#ops-alerts" } } : {}),
      },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return NextResponse.json({ error: "Workflow execution failed" }, { status: 500 });
  }
}
