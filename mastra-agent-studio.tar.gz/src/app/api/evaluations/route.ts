import { NextResponse } from "next/server";

export async function GET() {
  const evaluations = [
    { id: "ev-001", agentName: "supportAgent", testName: "Billing inquiry triage", score: 0.95, status: "passed", timestamp: "2026-04-07T18:00:00Z" },
    { id: "ev-002", agentName: "supportAgent", testName: "Critical outage escalation", score: 0.88, status: "passed", timestamp: "2026-04-07T17:45:00Z" },
    { id: "ev-003", agentName: "researchAgent", testName: "Source citation accuracy", score: 0.72, status: "passed", timestamp: "2026-04-07T17:30:00Z" },
    { id: "ev-004", agentName: "opsAgent", testName: "Diagnostic command accuracy", score: 0.45, status: "failed", timestamp: "2026-04-07T17:15:00Z" },
  ];

  return NextResponse.json({ evaluations, total: evaluations.length });
}
