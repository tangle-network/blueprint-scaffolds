import { NextResponse } from "next/server";

export async function GET() {
  const traces = [
    { id: "tr-001", agentName: "supportAgent", toolName: "createTicket", status: "success", durationMs: 342, tokensUsed: 156, timestamp: "2026-04-07T18:30:00Z" },
    { id: "tr-002", agentName: "researchAgent", toolName: "webSearch", status: "success", durationMs: 1823, tokensUsed: 412, timestamp: "2026-04-07T18:25:00Z" },
    { id: "tr-003", agentName: "opsAgent", toolName: "runDiagnostics", status: "success", durationMs: 156, tokensUsed: 89, timestamp: "2026-04-07T18:18:00Z" },
    { id: "tr-004", agentName: "supportAgent", toolName: "escalate", status: "error", durationMs: 89, tokensUsed: 67, timestamp: "2026-04-07T18:12:00Z" },
    { id: "tr-005", agentName: "researchAgent", toolName: "summarize", status: "success", durationMs: 567, tokensUsed: 234, timestamp: "2026-04-07T18:05:00Z" },
  ];

  return NextResponse.json({ traces, total: traces.length });
}
