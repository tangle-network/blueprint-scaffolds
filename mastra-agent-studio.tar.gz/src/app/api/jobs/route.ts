import { NextResponse } from "next/server";

export async function GET() {
  const jobs = [
    { id: "job-001", name: "Hourly Health Check", agentName: "opsAgent", schedule: "0 * * * *", status: "active", lastRun: "2026-04-07T18:00:00Z", nextRun: "2026-04-07T19:00:00Z", successRate: 0.98, totalRuns: 1247 },
    { id: "job-002", name: "Daily Support Digest", agentName: "supportAgent", schedule: "0 9 * * *", status: "active", lastRun: "2026-04-07T09:00:00Z", nextRun: "2026-04-08T09:00:00Z", successRate: 1.0, totalRuns: 89 },
    { id: "job-003", name: "Weekly Competitor Report", agentName: "researchAgent", schedule: "0 8 * * 1", status: "paused", lastRun: "2026-04-01T08:00:00Z", nextRun: null, successRate: 0.85, totalRuns: 12 },
    { id: "job-004", name: "SLA Compliance Monitor", agentName: "opsAgent", schedule: "*/15 * * * *", status: "active", lastRun: "2026-04-07T18:15:00Z", nextRun: "2026-04-07T18:30:00Z", successRate: 0.99, totalRuns: 4320 },
    { id: "job-005", name: "Monthly KB Refresh", agentName: "researchAgent", schedule: "0 2 1 * *", status: "error", lastRun: "2026-04-01T02:00:00Z", nextRun: "2026-05-01T02:00:00Z", successRate: 0.6, totalRuns: 5 },
  ];

  return NextResponse.json({ jobs, total: jobs.length });
}
