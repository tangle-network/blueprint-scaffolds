import { NextResponse } from "next/server";

export async function GET() {
  const agents = [
    {
      name: "supportAgent",
      model: "gpt-4o-mini",
      status: "active",
      tools: ["createTicket", "escalate", "knowledgeSearch"],
      description: "Expert customer support agent for CloudStream SaaS platform",
    },
    {
      name: "researchAgent",
      model: "gpt-4o-mini",
      status: "active",
      tools: ["webSearch", "summarize", "citeSources"],
      description: "Deep research agent for technology and market analysis",
    },
    {
      name: "opsAgent",
      model: "gpt-4o-mini",
      status: "active",
      tools: ["runDiagnostics", "deploy", "notifySlack", "checkStatus"],
      description: "Internal operations agent for infrastructure management",
    },
  ];

  return NextResponse.json({ agents });
}
