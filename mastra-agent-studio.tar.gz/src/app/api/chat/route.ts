import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { messages, agent } = body;

    const agentResponses: Record<string, string> = {
      supportAgent: "I've analyzed your request. Let me search our knowledge base and create a ticket for this issue. Based on similar cases, here's what I recommend:\n\n1. First, try clearing your browser cache and cookies\n2. If the issue persists, check your API key configuration\n3. For billing issues, I've created a ticket and routed it to our billing team\n\nYour ticket ID will be generated shortly.",
      researchAgent: "I've conducted a thorough analysis on your topic. Here's what I found:\n\n**Executive Summary:** The market is showing strong growth in AI agent frameworks, with several key trends emerging.\n\n**Key Findings:**\n- Multi-agent orchestration is becoming standard\n- Tool composition patterns are maturing\n- Vector memory integration is a key differentiator\n\n**Confidence Rating:** High",
      opsAgent: "System diagnostic complete. Here's the current status:\n\n- API: Healthy (45ms latency)\n- Database: Healthy (12ms latency)\n- Cache: Healthy (3ms latency)\n- Queue: Healthy (28ms latency)\n\nAll services operating within SLA. No action needed at this time.",
    };

    const response = agentResponses[agent as string] || agentResponses.supportAgent;

    return NextResponse.json({
      response,
      agent: agent || "supportAgent",
      toolCalls: agent === "supportAgent"
        ? ["knowledgeSearch", "createTicket"]
        : agent === "researchAgent"
          ? ["webSearch", "summarize"]
          : ["runDiagnostics"],
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return NextResponse.json({ error: "Failed to process chat request" }, { status: 500 });
  }
}
