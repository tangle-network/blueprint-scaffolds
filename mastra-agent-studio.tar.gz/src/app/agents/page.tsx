"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Bot, Wrench, FileText } from "lucide-react";

const agentData = [
  {
    name: "supportAgent",
    description: "Expert customer support agent for CloudStream SaaS platform. Handles triage, ticketing, knowledge search, and escalation.",
    model: "gpt-4o-mini",
    status: "active",
    tools: [
      { name: "createTicket", description: "Create support tickets with severity & category" },
      { name: "escalate", description: "Escalate issues to the engineering team" },
      { name: "knowledgeSearch", description: "Search knowledge base for solutions" },
    ],
    instructions: [
      "Triage incoming support requests by severity",
      "Search knowledge base before answering technical questions",
      "Create tickets for engineering follow-up",
      "Escalate critical issues immediately",
      "Always acknowledge customer frustration empathetically",
    ],
  },
  {
    name: "researchAgent",
    description: "Deep research agent specialized in technology and market analysis. Conducts web searches, summarizes findings, and cites sources.",
    model: "gpt-4o-mini",
    status: "active",
    tools: [
      { name: "webSearch", description: "Search the web for current information" },
      { name: "summarize", description: "Summarize text into key points" },
      { name: "citeSources", description: "Format and validate source citations" },
    ],
    instructions: [
      "Conduct thorough research on given topics",
      "Cross-reference information from multiple sources",
      "Prioritize primary sources and recent data",
      "Rate confidence level for each finding",
      "Output structured reports with executive summary",
    ],
  },
  {
    name: "opsAgent",
    description: "Internal operations agent for CloudStream infrastructure. Handles monitoring, diagnostics, deployment, and team notifications.",
    model: "gpt-4o-mini",
    status: "active",
    tools: [
      { name: "runDiagnostics", description: "Run system diagnostics on services" },
      { name: "deploy", description: "Trigger service deployments" },
      { name: "notifySlack", description: "Send Slack channel notifications" },
      { name: "checkStatus", description: "Check service or deployment status" },
    ],
    instructions: [
      "Monitor system health and respond to alerts",
      "Run diagnostics before suggesting changes",
      "Never deploy to production without confirmation",
      "Notify #ops-alerts for critical issues",
      "Provide rollback plans for any deployment",
    ],
  },
];

export default function AgentsPage() {
  const [selectedAgent, setSelectedAgent] = useState(0);
  const agent = agentData[selectedAgent];

  return (
    <div className="p-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">Agents</h1>
        <p className="text-muted-foreground mt-1">Manage and inspect your AI agents</p>
      </div>

      <div className="flex gap-2 mb-6">
        {agentData.map((a, i) => (
          <Button
            key={a.name}
            variant={selectedAgent === i ? "default" : "outline"}
            onClick={() => setSelectedAgent(i)}
            className="gap-2"
          >
            <Bot className="h-4 w-4" />
            {a.name}
          </Button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Bot className="h-5 w-5 text-primary" />
                {agent.name}
              </CardTitle>
              <Badge variant="outline">{agent.status}</Badge>
            </div>
            <CardDescription>{agent.description}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-semibold mb-2 flex items-center gap-2">
                  <FileText className="h-4 w-4" /> Instructions
                </h3>
                <ul className="space-y-1">
                  {agent.instructions.map((inst, i) => (
                    <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                      <span className="text-primary mt-1">&#8226;</span>
                      {inst}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h3 className="text-sm font-semibold mb-2">Model</h3>
                <Badge variant="secondary">{agent.model}</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Wrench className="h-4 w-4" />
              Tools ({agent.tools.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {agent.tools.map((tool) => (
                <div key={tool.name} className="rounded-md border p-3">
                  <p className="font-medium text-sm">{tool.name}</p>
                  <p className="text-xs text-muted-foreground mt-1">{tool.description}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
