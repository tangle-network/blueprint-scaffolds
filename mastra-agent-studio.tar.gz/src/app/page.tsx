"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const stats = [
  { label: "Active Agents", value: "3", sub: "support, research, ops" },
  { label: "Registered Tools", value: "11", sub: "across all agents" },
  { label: "Workflows", value: "1", sub: "support pipeline" },
  { label: "Traces (24h)", value: "142", sub: "+12% from yesterday" },
];

const recentTraces = [
  { id: "t-001", agent: "supportAgent", action: "createTicket", status: "success", time: "2 min ago" },
  { id: "t-002", agent: "researchAgent", action: "webSearch", status: "success", time: "5 min ago" },
  { id: "t-003", agent: "opsAgent", action: "runDiagnostics", status: "success", time: "12 min ago" },
  { id: "t-004", agent: "supportAgent", action: "escalate", status: "warning", time: "18 min ago" },
  { id: "t-005", agent: "researchAgent", action: "summarize", status: "success", time: "25 min ago" },
];

const agents = [
  { name: "supportAgent", status: "active", model: "gpt-4o-mini", tools: 3 },
  { name: "researchAgent", status: "active", model: "gpt-4o-mini", tools: 3 },
  { name: "opsAgent", status: "active", model: "gpt-4o-mini", tools: 4 },
];

function StatusDot({ status }: { status: string }) {
  const color =
    status === "active" || status === "success"
      ? "bg-green-500"
      : status === "warning"
        ? "bg-yellow-500"
        : "bg-red-500";
  return <span className={`inline-block h-2 w-2 rounded-full ${color}`} />;
}

export default function DashboardPage() {
  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground mt-1">
          Overview of your Mastra agent infrastructure
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map((stat) => (
          <Card key={stat.label}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {stat.label}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground mt-1">{stat.sub}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Agent Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {agents.map((a) => (
                <div
                  key={a.name}
                  className="flex items-center justify-between rounded-md border p-3"
                >
                  <div className="flex items-center gap-3">
                    <StatusDot status={a.status} />
                    <div>
                      <p className="font-medium text-sm">{a.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {a.model} &middot; {a.tools} tools
                      </p>
                    </div>
                  </div>
                  <Badge variant="outline">{a.status}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Traces</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentTraces.map((t) => (
                <div
                  key={t.id}
                  className="flex items-center justify-between rounded-md border p-3"
                >
                  <div className="flex items-center gap-3">
                    <StatusDot status={t.status} />
                    <div>
                      <p className="font-medium text-sm">
                        {t.agent}/{t.action}
                      </p>
                      <p className="text-xs text-muted-foreground">{t.time}</p>
                    </div>
                  </div>
                  <Badge variant={t.status === "warning" ? "destructive" : "secondary"}>
                    {t.status}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
