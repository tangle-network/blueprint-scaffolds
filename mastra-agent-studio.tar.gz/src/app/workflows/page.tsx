"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { GitBranch, Play, Clock, CheckCircle2, AlertTriangle, ArrowRight } from "lucide-react";

const workflowSteps = [
  { id: "triage", name: "Triage", description: "Classify incoming request by severity & category", type: "auto" },
  { id: "search-knowledge", name: "Search Knowledge", description: "Find relevant solutions in KB", type: "auto" },
  { id: "respond", name: "Respond", description: "Generate & send response to customer", type: "auto" },
  { id: "escalate", name: "Escalate", description: "Escalate critical issues to engineering", type: "conditional" },
];

const mockRuns = [
  { id: "run-001", status: "completed", startedAt: "2026-04-07T18:30:00Z", duration: "2.3s", steps: 4 },
  { id: "run-002", status: "completed", startedAt: "2026-04-07T18:15:00Z", duration: "1.8s", steps: 3 },
  { id: "run-003", status: "failed", startedAt: "2026-04-07T17:50:00Z", duration: "0.4s", steps: 2 },
  { id: "run-004", status: "completed", startedAt: "2026-04-07T17:30:00Z", duration: "3.1s", steps: 4 },
  { id: "run-005", status: "completed", startedAt: "2026-04-07T16:45:00Z", duration: "1.5s", steps: 3 },
];

function StepIcon({ type }: { type: string }) {
  if (type === "conditional") return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
  return <CheckCircle2 className="h-4 w-4 text-green-500" />;
}

export default function WorkflowsPage() {
  const [testInput, setTestInput] = useState("");
  const [runResult, setRunResult] = useState<string | null>(null);
  const [running, setRunning] = useState(false);

  const handleRunWorkflow = async () => {
    if (!testInput.trim()) return;
    setRunning(true);
    setRunResult(null);
    try {
      const res = await fetch("/api/workflows", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ customerMessage: testInput }),
      });
      const data = await res.json();
      setRunResult(JSON.stringify(data, null, 2));
    } catch {
      setRunResult("Error: Workflow execution failed");
    } finally {
      setRunning(false);
    }
  };

  return (
    <div className="p-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">Workflows</h1>
        <p className="text-muted-foreground mt-1">Manage and monitor automated agent workflows</p>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <GitBranch className="h-5 w-5 text-primary" />
            Support Workflow Pipeline
          </CardTitle>
          <CardDescription>
            Automated customer support pipeline: triage → knowledge search → respond/escalate
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-2 overflow-x-auto pb-2">
            {workflowSteps.map((step, i) => (
              <div key={step.id} className="flex items-center gap-2">
                <div className="flex items-center gap-3 rounded-lg border p-3 min-w-[180px]">
                  <StepIcon type={step.type} />
                  <div>
                    <p className="font-medium text-sm">{step.name}</p>
                    <p className="text-xs text-muted-foreground">{step.description}</p>
                  </div>
                </div>
                {i < workflowSteps.length - 1 && (
                  <ArrowRight className="h-4 w-4 text-muted-foreground shrink-0" />
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Play className="h-4 w-4" />
              Test Workflow
            </CardTitle>
            <CardDescription>Run the support workflow with a sample customer message</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              value={testInput}
              onChange={(e) => setTestInput(e.target.value)}
              placeholder="Enter a customer support message... (e.g. 'My service is down and I can't access my dashboard')"
              className="min-h-[100px]"
            />
            <Button onClick={handleRunWorkflow} disabled={running || !testInput.trim()}>
              {running ? "Running..." : "Run Workflow"}
            </Button>
            {runResult && (
              <pre className="bg-muted rounded-md p-4 text-xs overflow-auto max-h-64">
                {runResult}
              </pre>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Recent Runs
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {mockRuns.map((run) => (
                <div key={run.id} className="flex items-center justify-between rounded-md border p-3">
                  <div>
                    <p className="font-mono text-sm">{run.id}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(run.startedAt).toLocaleString()} · {run.steps} steps
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">{run.duration}</span>
                    <Badge variant={run.status === "completed" ? "default" : "destructive"}>
                      {run.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
