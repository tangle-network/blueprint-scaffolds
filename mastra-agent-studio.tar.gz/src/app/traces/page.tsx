"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Activity } from "lucide-react";

interface Trace {
  id: string;
  agentName: string;
  toolName: string;
  status: "success" | "error" | "running";
  durationMs: number;
  tokensUsed: number;
  timestamp: string;
  input: string;
  output: string;
}

const mockTraces: Trace[] = [
  { id: "tr-001", agentName: "supportAgent", toolName: "createTicket", status: "success", durationMs: 342, tokensUsed: 156, timestamp: "2026-04-07T18:30:00Z", input: "Customer reports login failure", output: '{"ticketId":"TKT-M3F2N1","status":"created"}' },
  { id: "tr-002", agentName: "researchAgent", toolName: "webSearch", status: "success", durationMs: 1823, tokensUsed: 412, timestamp: "2026-04-07T18:25:00Z", input: "AI agent frameworks 2026 comparison", output: '{"results":[...],"queryUsed":"AI agent frameworks 2026 comparison"}' },
  { id: "tr-003", agentName: "opsAgent", toolName: "runDiagnostics", status: "success", durationMs: 156, tokensUsed: 89, timestamp: "2026-04-07T18:18:00Z", input: "Check API service health", output: '{"service":"api","status":"healthy","latencyMs":45}' },
  { id: "tr-004", agentName: "supportAgent", toolName: "escalate", status: "error", durationMs: 89, tokensUsed: 67, timestamp: "2026-04-07T18:12:00Z", input: "Multi-user outage reported", output: '{"error":"Slack integration timeout"}' },
  { id: "tr-005", agentName: "researchAgent", toolName: "summarize", status: "success", durationMs: 567, tokensUsed: 234, timestamp: "2026-04-07T18:05:00Z", input: "Long research document about market trends...", output: '{"summary":"Key trends include...","keyPoints":[...]}' },
  { id: "tr-006", agentName: "opsAgent", toolName: "deploy", status: "success", durationMs: 234, tokensUsed: 178, timestamp: "2026-04-07T17:58:00Z", input: "Deploy api-gateway v2.3.1 to staging", output: '{"deploymentId":"DEP-K4H7M2","status":"initiated"}' },
  { id: "tr-007", agentName: "supportAgent", toolName: "knowledgeSearch", status: "success", durationMs: 78, tokensUsed: 45, timestamp: "2026-04-07T17:50:00Z", input: "How to reset 2FA", output: '{"results":[{"title":"2FA Reset Guide","relevance":0.95}]}' },
  { id: "tr-008", agentName: "opsAgent", toolName: "checkStatus", status: "running", durationMs: 0, tokensUsed: 0, timestamp: "2026-04-07T17:45:00Z", input: "Check deployment DEP-K4H7M2", output: "..." },
];

export default function TracesPage() {
  const [filterAgent, setFilterAgent] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const filtered = mockTraces.filter((t) => {
    if (filterAgent !== "all" && t.agentName !== filterAgent) return false;
    if (filterStatus !== "all" && t.status !== filterStatus) return false;
    return true;
  });

  return (
    <div className="p-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">Traces</h1>
        <p className="text-muted-foreground mt-1">Monitor agent executions and tool invocations</p>
      </div>

      <div className="flex gap-4 mb-6">
        <Select
          value={filterAgent}
          onChange={(e) => setFilterAgent(e.target.value)}
          className="w-48"
        >
          <option value="all">All Agents</option>
          <option value="supportAgent">supportAgent</option>
          <option value="researchAgent">researchAgent</option>
          <option value="opsAgent">opsAgent</option>
        </Select>
        <Select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="w-40"
        >
          <option value="all">All Status</option>
          <option value="success">Success</option>
          <option value="error">Error</option>
          <option value="running">Running</option>
        </Select>
        <div className="flex-1" />
        <Button variant="outline">Export CSV</Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Activity className="h-4 w-4" />
            Execution Traces ({filtered.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Agent</TableHead>
                <TableHead>Tool</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Duration</TableHead>
                <TableHead>Tokens</TableHead>
                <TableHead>Time</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((trace) => (
                <>
                  <TableRow
                    key={trace.id}
                    className="cursor-pointer"
                    onClick={() => setExpandedId(expandedId === trace.id ? null : trace.id)}
                  >
                    <TableCell className="font-mono text-xs">{trace.id}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">{trace.agentName}</Badge>
                    </TableCell>
                    <TableCell className="font-mono text-sm">{trace.toolName}</TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          trace.status === "success"
                            ? "default"
                            : trace.status === "error"
                              ? "destructive"
                              : "outline"
                        }
                      >
                        {trace.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm">
                      {trace.status === "running" ? "—" : `${trace.durationMs}ms`}
                    </TableCell>
                    <TableCell className="text-sm">
                      {trace.status === "running" ? "—" : trace.tokensUsed}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {new Date(trace.timestamp).toLocaleTimeString()}
                    </TableCell>
                  </TableRow>
                  {expandedId === trace.id && (
                    <TableRow key={`${trace.id}-detail`}>
                      <TableCell colSpan={7} className="bg-muted/30">
                        <div className="grid grid-cols-2 gap-4 py-2">
                          <div>
                            <p className="text-xs font-semibold mb-1">Input</p>
                            <pre className="text-xs bg-background rounded p-2 overflow-auto max-h-32">
                              {trace.input}
                            </pre>
                          </div>
                          <div>
                            <p className="text-xs font-semibold mb-1">Output</p>
                            <pre className="text-xs bg-background rounded p-2 overflow-auto max-h-32">
                              {trace.output}
                            </pre>
                          </div>
                        </div>
                      </TableCell>
                    </TableRow>
                  )}
                </>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
