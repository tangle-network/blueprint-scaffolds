"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, Play, Pause, RotateCcw, Plus } from "lucide-react";

interface ScheduledJob {
  id: string;
  name: string;
  agentName: string;
  schedule: string;
  status: "active" | "paused" | "error";
  lastRun: string;
  nextRun: string;
  successRate: number;
  totalRuns: number;
}

const mockJobs: ScheduledJob[] = [
  {
    id: "job-001",
    name: "Hourly Health Check",
    agentName: "opsAgent",
    schedule: "0 * * * *",
    status: "active",
    lastRun: "2026-04-07T18:00:00Z",
    nextRun: "2026-04-07T19:00:00Z",
    successRate: 0.98,
    totalRuns: 1247,
  },
  {
    id: "job-002",
    name: "Daily Support Digest",
    agentName: "supportAgent",
    schedule: "0 9 * * *",
    status: "active",
    lastRun: "2026-04-07T09:00:00Z",
    nextRun: "2026-04-08T09:00:00Z",
    successRate: 1.0,
    totalRuns: 89,
  },
  {
    id: "job-003",
    name: "Weekly Competitor Report",
    agentName: "researchAgent",
    schedule: "0 8 * * 1",
    status: "paused",
    lastRun: "2026-04-01T08:00:00Z",
    nextRun: "—",
    successRate: 0.85,
    totalRuns: 12,
  },
  {
    id: "job-004",
    name: "SLA Compliance Monitor",
    agentName: "opsAgent",
    schedule: "*/15 * * * *",
    status: "active",
    lastRun: "2026-04-07T18:15:00Z",
    nextRun: "2026-04-07T18:30:00Z",
    successRate: 0.99,
    totalRuns: 4320,
  },
  {
    id: "job-005",
    name: "Monthly Knowledge Base Refresh",
    agentName: "researchAgent",
    schedule: "0 2 1 * *",
    status: "error",
    lastRun: "2026-04-01T02:00:00Z",
    nextRun: "2026-05-01T02:00:00Z",
    successRate: 0.6,
    totalRuns: 5,
  },
];

function StatusBadge({ status }: { status: string }) {
  const variant = status === "active" ? "default" : status === "paused" ? "secondary" : "destructive";
  return <Badge variant={variant}>{status}</Badge>;
}

export default function JobsPage() {
  return (
    <div className="p-8">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Scheduled Jobs</h1>
          <p className="text-muted-foreground mt-1">Manage recurring agent tasks and automations</p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          New Job
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Active Jobs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {mockJobs.filter((j) => j.status === "active").length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Runs (30d)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">5,673</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Avg Success Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">96.4%</div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-3">
        {mockJobs.map((job) => (
          <Card key={job.id}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <StatusBadge status={job.status} />
                    <div>
                      <p className="font-medium">{job.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {job.agentName} &middot; cron: <code className="bg-muted px-1 rounded">{job.schedule}</code>
                      </p>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-6 text-sm">
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">Success Rate</p>
                    <p className="font-medium">{(job.successRate * 100).toFixed(0)}%</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">Total Runs</p>
                    <p className="font-medium">{job.totalRuns.toLocaleString()}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">Next Run</p>
                    <p className="font-medium text-xs">
                      {job.nextRun === "—" ? "—" : new Date(job.nextRun).toLocaleString()}
                    </p>
                  </div>
                  <div className="flex gap-1">
                    {job.status === "active" ? (
                      <Button variant="ghost" size="sm">
                        <Pause className="h-4 w-4" />
                      </Button>
                    ) : (
                      <Button variant="ghost" size="sm">
                        <Play className="h-4 w-4" />
                      </Button>
                    )}
                    <Button variant="ghost" size="sm">
                      <RotateCcw className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
