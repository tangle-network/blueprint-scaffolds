"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

interface Message {
  role: "user" | "assistant";
  content: string;
  toolCalls?: string[];
}

const agentOptions = [
  { value: "supportAgent", label: "Support Agent", desc: "Customer support triage & ticketing" },
  { value: "researchAgent", label: "Research Agent", desc: "Deep research & market analysis" },
  { value: "opsAgent", label: "Ops Agent", desc: "Infrastructure monitoring & deploy" },
];

export default function PlaygroundPage() {
  const [selectedAgent, setSelectedAgent] = useState("supportAgent");
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSend = async () => {
    if (!input.trim()) return;
    const userMsg: Message = { role: "user", content: input };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: [{ role: "user", content: input }], agent: selectedAgent }),
      });
      const data = await res.json();
      const assistantMsg: Message = {
        role: "assistant",
        content: data.response || data.error || "No response",
        toolCalls: data.toolCalls,
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } catch {
      setMessages((prev) => [...prev, { role: "assistant", content: "Error: Failed to get response" }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-8 h-full flex flex-col">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">Playground</h1>
        <p className="text-muted-foreground mt-1">Test agents interactively with real prompts</p>
      </div>

      <div className="mb-4">
        <label className="text-sm font-medium mb-2 block">Select Agent</label>
        <Select
          value={selectedAgent}
          onChange={(e) => setSelectedAgent(e.target.value)}
        >
          {agentOptions.map((a) => (
            <option key={a.value} value={a.value}>
              {a.label} — {a.desc}
            </option>
          ))}
        </Select>
      </div>

      <Card className="flex-1 flex flex-col min-h-0">
        <CardHeader className="border-b">
          <CardTitle className="text-base flex items-center gap-2">
            Chat
            <Badge variant="secondary">{selectedAgent}</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1 overflow-auto p-4 space-y-4">
          {messages.length === 0 && (
            <div className="text-center text-muted-foreground py-12">
              Select an agent and send a message to start interacting.
            </div>
          )}
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[80%] rounded-lg px-4 py-3 text-sm ${
                  msg.role === "user"
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground"
                }`}
              >
                <div className="whitespace-pre-wrap">{msg.content}</div>
                {msg.toolCalls && msg.toolCalls.length > 0 && (
                  <div className="mt-2 flex gap-1 flex-wrap">
                    {msg.toolCalls.map((tc, j) => (
                      <Badge key={j} variant="outline" className="text-xs">
                        {tc}
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
          {loading && (
            <div className="text-muted-foreground text-sm animate-pulse">Agent is thinking...</div>
          )}
        </CardContent>
      </Card>

      <div className="mt-4 flex gap-2">
        <Textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type your message..."
          className="flex-1 min-h-[60px] max-h-[120px]"
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              handleSend();
            }
          }}
        />
        <Button onClick={handleSend} disabled={loading || !input.trim()}>
          Send
        </Button>
      </div>
    </div>
  );
}
