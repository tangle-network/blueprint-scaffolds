"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select } from "@/components/ui/select";
import { ClipboardCheck, TrendingUp, AlertCircle } from "lucide-react";

interface EvalRun {
  id: string;
  agentName: string;
  testName: string;
  score: number;
  status: "passed" | "failed" | "running";
  input: string;
  expected: string;
  actual: string;
  timestamp: string;
}

const mockEvals: EvalRun[] = [
  { id: "ev-001", agentName: "supportAgent", testName: "Billing inquiry triage", score: 0.95, status: "passed", input: "I was charged twice for my subscription", expected: "Category: billing, Severity: medium", actual: "Category: billing, Severity: medium, Ticket: TKT-A1B2C3", timestamp: "2026-04-07T18:00:00Z" },
  { id: "ev-002", agentName: "supportAgent", testName: "Critical outage escalation", score: 0.88, status: "passed", input: "Service is completely down, all users affected", expected: "Escalation to engineering", actual: "Escalated to #ops-alerts, ESC-D4E5F6", timestamp: "2026-04-07T17:45:00Z" },
  { id: "ev-003", agentName: "researchAgent", testName: "Source citation accuracy", score: 0.72, status: "passed", input: "Research AI agent market trends 2026", expected: "Citations with 3+ sources", actual: "Citations: 2 sources, format: APA", timestamp: "2026-04-07T17:30:00Z" },
  { id: "ev-004", agentName: "opsAgent", testName: "Diagnostic command accuracy", score: 0.45, status: "failed", input: "API latency is elevated", expected: "Run diagnostics on API service", actual: "Checked CDN status instead", timestamp: "2026-04-07T17:15:00Z" },
  { id: "ev-005", agentName: "supportAgent", testName: "Feature request routing", score: 0.91, status: "passed", input: "Can you add dark mode to the dashboard?", expected: "Category: feature-request, Ticket created", actual: "Category: feature-request, Ticket: TKT-G7H8I9", timestamp: "2026-04-07T16:50:00Z" },
  { id: "ev-006", agentName: "opsAgent", testName: "Deployment safety check", score: 0.0, status: "running", input: "Deploy to production immediately", expected: "Request confirmation before prod deploy", actual: "...", timestamp: "2026-04-07T16:30:00Z" },
];

const avgScores = [
  { agent: "supportAgent", score: 0.91, runs: 3 },
  { agent: "researchAgent", score: 0.72, runs: 1 },
  { agent: "opsAgent", score: 0.23, runs: 2 },
];

export default function EvaluationsPage() {
  const [filterAgent, setFilterAgent] = useState("all");

  const filtered = mockEvals.filter((e) => filterAgent === "all" || e.agentName === filterAgent);

  return (
    <div className="p-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">Evaluations</h1>
        <p className="text-muted-foreground mt-1">Agent quality assessment and benchmarking</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {avgScores.map((s) => (
          <Card key={s.agent}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">{s.agent}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                <span className="text-2xl font-bold">{(s.score * 100).toFixed(0)}%</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">{s.runs} eval runs</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mb-4">
        <Select
          value={filterAgent}
          onChange={(e) => setFilterAgent(e.target.value)}
          className="w-48"
        >
          <option value="all">All Agents</option>
          <option value="supportAgent">supportAgent</option>
          <option value="researchAgent">researchAgent</option>
          <option value="opsAgent">opsAgent</option>
        </Select>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <ClipboardCheck className="h-4 w-4" />
            Evaluation Results ({filtered.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {filtered.map((ev) => (
              <div key={ev.id} className="rounded-lg border p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">{ev.agentName}</Badge>
                    <span className="font-medium text-sm">{ev.testName}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge
                      variant={
                        ev.status === "passed"
                          ? "default"
                          : ev.status === "failed"
                            ? "destructive"
                            : "outline"
                      }
                    >
                      {ev.status}
                    </Badge>
                    {ev.status !== "running" && (
                      <span className="text-sm font-mono">
                        {(ev.score * 100).toFixed(0)}%
                      </span>
                    )}
                  </div>
                </div>
                {ev.status !== "running" && (
                  <div className="grid grid-cols-2 gap-3 mt-3">
                    <div>
                      <p className="text-xs font-semibold text-muted-foreground mb-1">Input</p>
                      <p className="text-xs bg-muted rounded p-2">{ev.input}</p>
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-muted-foreground mb-1">Expected → Actual</p>
                      <div className="text-xs bg-muted rounded p-2">
                        <p className="text-green-400">Expected: {ev.expected}</p>
                        <p className="text-muted-foreground mt-1">Actual: {ev.actual}</p>
                      </div>
                    </div>
                  </div>
                )}
                <p className="text-xs text-muted-foreground mt-2">
                  {new Date(ev.timestamp).toLocaleString()}
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
