import type { JobRecord, SupportRunRecord } from "../../shared/types.js";

export const recentRuns: SupportRunRecord[] = [];

export const scheduledJobs: JobRecord[] = [
  {
    id: "hourly-backlog-scan",
    label: "Hourly Backlog Scan",
    cadence: "Every 60 minutes",
    lastRunAt: null,
    status: "idle",
    summary: "Summarizes stale tickets and high-priority clusters."
  },
  {
    id: "nightly-eval-rollup",
    label: "Nightly Eval Rollup",
    cadence: "Every 24 hours",
    lastRunAt: null,
    status: "idle",
    summary: "Reviews support run quality and flags low-scoring traces."
  }
];

export function addRun(record: SupportRunRecord) {
  recentRuns.unshift(record);
  if (recentRuns.length > 12) recentRuns.length = 12;
}

export function updateJob(id: string, patch: Partial<JobRecord>) {
  const job = scheduledJobs.find((entry) => entry.id === id);
  if (!job) return;
  Object.assign(job, patch);
}
