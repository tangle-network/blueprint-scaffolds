import path from "node:path";
import { Agent } from "@mastra/core/agent";
import { Mastra } from "@mastra/core";
import { createScorer } from "@mastra/core/evals";
import { createTool } from "@mastra/core/tools";
import { createWorkflow, createStep } from "@mastra/core/workflows";
import { LibSQLStore, LibSQLVector } from "@mastra/libsql";
import { Memory } from "@mastra/memory";
import { z } from "zod";
import {
  deriveQueue,
  extractLabels,
  lookupSlaHours,
  scoreSeverity,
  searchPlaybooks
} from "./support-domain.js";
import type { EvaluationResult, SupportRunInput, SupportRunRecord, ToolSummary } from "../../shared/types.js";

const dataFile = path.resolve(process.cwd(), "data", "mastra.db");
const storage = new LibSQLStore({
  id: "studio-storage",
  url: `file:${dataFile}`
});

const vector = new LibSQLVector({
  id: "studio-vector",
  url: `file:${dataFile}`
});

const memoryMode = process.env.OPENAI_API_KEY ? "vector-enabled" : "transcript-only";

const supportInputSchema = z.object({
  prompt: z.string(),
  customerTier: z.enum(["free", "business", "enterprise"]),
  channel: z.enum(["email", "chat", "slack"]),
  requester: z.string()
});

const normalizedInputSchema = supportInputSchema.extend({
  timestamp: z.string()
});

const triageOutputSchema = supportInputSchema.extend({
  summary: z.string(),
  severity: z.enum(["low", "medium", "high", "critical"]),
  queue: z.string(),
  slaHours: z.number(),
  labels: z.array(z.string())
});

const researchOutputSchema = z.object({
  triage: triageOutputSchema,
  findings: z.array(z.string()),
  sources: z.array(z.string()),
  memoryHits: z.array(z.string())
});

const responseOutputSchema = researchOutputSchema.extend({
  internalPlan: z.string(),
  customerReply: z.string(),
  nextAction: z.string()
});

function createSupportMemory() {
  return new Memory({
    storage,
    vector: process.env.OPENAI_API_KEY ? vector : false,
    embedder: process.env.OPENAI_API_KEY ? "openai/text-embedding-3-small" : undefined,
    options: {
      semanticRecall: process.env.OPENAI_API_KEY
        ? {
            topK: 3,
            messageRange: 2
          }
        : false
    }
  });
}

export const toolRegistry = {
  classifyTicket: createTool({
    id: "classify-ticket",
    description: "Assign severity, queue, and support labels for a support request.",
    inputSchema: z.object({
      prompt: z.string(),
      customerTier: z.enum(["free", "business", "enterprise"])
    }),
    execute: async ({ prompt, customerTier }) => {
      const severity = scoreSeverity(prompt);
      return {
        severity,
        queue: deriveQueue(prompt),
        slaHours: lookupSlaHours(severity, customerTier),
        labels: extractLabels(prompt)
      };
    }
  }),
  searchKnowledge: createTool({
    id: "search-knowledge",
    description: "Search support playbooks and vector memory for relevant operational guidance.",
    inputSchema: z.object({
      prompt: z.string()
    }),
    execute: async ({ prompt }) => {
      const articles = searchPlaybooks(prompt);
      return {
        findings: articles.map((article) => article.body),
        sources: articles.map((article) => article.title),
        escalationQueues: articles.map((article) => article.escalationQueue)
      };
    }
  }),
  composeEscalation: createTool({
    id: "compose-escalation",
    description: "Create a crisp internal action plan and next owner for the ticket.",
    inputSchema: z.object({
      severity: z.enum(["low", "medium", "high", "critical"]),
      queue: z.string(),
      findings: z.array(z.string())
    }),
    execute: async ({ severity, queue, findings }) => ({
      nextAction:
        severity === "critical"
          ? `Page ${queue} immediately and attach impacted tenant evidence.`
          : `Route to ${queue} with the supporting notes and keep ownership with support until acknowledged.`,
      internalPlan: [
        `Severity: ${severity}.`,
        `Queue: ${queue}.`,
        findings[0] ?? "No direct playbook match was found; request more diagnostics."
      ].join(" ")
    })
  })
};

export const toolCatalog: ToolSummary[] = [
  {
    id: "classify-ticket",
    description: toolRegistry.classifyTicket.description,
    category: "triage"
  },
  {
    id: "search-knowledge",
    description: toolRegistry.searchKnowledge.description,
    category: "research"
  },
  {
    id: "compose-escalation",
    description: toolRegistry.composeEscalation.description,
    category: "operations"
  }
];

async function runTool<TInput, TOutput>(
  tool: {
    execute?: unknown;
  },
  input: TInput
): Promise<TOutput> {
  const execute = tool.execute as ((inputData: TInput, ...args: any[]) => Promise<TOutput> | TOutput) | undefined;

  if (!execute) {
    throw new Error("Tool is missing an execute handler.");
  }

  return await execute(input);
}

function getModel() {
  return "openai/gpt-4.1-mini";
}

export const triageAgent = new Agent({
  id: "triage-agent",
  name: "Support Triage Agent",
  description: "Converts a raw support request into an operational summary for queues and urgency.",
  instructions:
    "You are a support triage lead. Write concise internal triage notes, list the likely impact, and flag missing diagnostics.",
  model: getModel(),
  memory: createSupportMemory(),
  tools: {
    classifyTicket: toolRegistry.classifyTicket
  }
});

export const researchAgent = new Agent({
  id: "research-agent",
  name: "Policy Research Agent",
  description: "Finds the most relevant support playbook guidance and likely escalation path.",
  instructions:
    "You review support playbooks and prior context. Summarize the best operational guidance and note escalation criteria.",
  model: getModel(),
  memory: createSupportMemory(),
  tools: {
    searchKnowledge: toolRegistry.searchKnowledge
  }
});

export const responseAgent = new Agent({
  id: "response-agent",
  name: "Resolution Agent",
  description: "Turns the triage and research context into an internal plan and a customer-safe reply.",
  instructions:
    "Draft an empathetic but operationally precise support response. Separate internal actions from the customer-facing update.",
  model: getModel(),
  memory: createSupportMemory(),
  tools: {
    composeEscalation: toolRegistry.composeEscalation
  }
});

const normalizeInputStep = createStep({
  id: "normalize-input",
  inputSchema: supportInputSchema,
  outputSchema: normalizedInputSchema,
  execute: async ({ inputData }) => ({
    ...inputData,
    timestamp: new Date().toISOString()
  })
});

const triageStep = createStep({
  id: "triage-ticket",
  inputSchema: normalizedInputSchema,
  outputSchema: triageOutputSchema,
  execute: async ({ inputData }) => {
    const classification = await runTool<
      { prompt: string; customerTier: "free" | "business" | "enterprise" },
      { severity: "low" | "medium" | "high" | "critical"; queue: string; slaHours: number; labels: string[] }
    >(toolRegistry.classifyTicket, {
      prompt: inputData.prompt,
      customerTier: inputData.customerTier
    });

    const fallbackSummary = [
      `Requester ${inputData.requester} contacted support via ${inputData.channel}.`,
      `Severity is ${classification.severity} and the recommended queue is ${classification.queue}.`,
      "Capture affected tenant, timestamps, and business impact before handoff."
    ].join(" ");

    let summary = fallbackSummary;
    if (process.env.OPENAI_API_KEY) {
      const result = await triageAgent.generate(
        `Customer tier: ${inputData.customerTier}\nChannel: ${inputData.channel}\nRequest: ${inputData.prompt}`
      );
      summary = result.text || fallbackSummary;
    }

    return {
      ...inputData,
      ...classification,
      summary
    };
  }
});

const researchStep = createStep({
  id: "research-guidance",
  inputSchema: triageOutputSchema,
  outputSchema: researchOutputSchema,
  execute: async ({ inputData }) => {
    const kb = await runTool<
      { prompt: string },
      { findings: string[]; sources: string[]; escalationQueues: string[] }
    >(toolRegistry.searchKnowledge, {
      prompt: inputData.prompt
    });

    let findings = kb.findings;
    if (process.env.OPENAI_API_KEY) {
      const result = await researchAgent.generate(
        `Ticket summary: ${inputData.summary}\nSeverity: ${inputData.severity}\nKnowledge hits:\n${kb.findings.join("\n")}`
      );
      if (result.text) {
        findings = [result.text, ...kb.findings].slice(0, 3);
      }
    }

    return {
      triage: inputData,
      findings,
      sources: kb.sources,
      memoryHits: kb.findings.slice(0, 2)
    };
  }
});

const responseStep = createStep({
  id: "draft-response",
  inputSchema: researchOutputSchema,
  outputSchema: responseOutputSchema,
  execute: async ({ inputData }) => {
    const operations = await runTool<
      { severity: "low" | "medium" | "high" | "critical"; queue: string; findings: string[] },
      { nextAction: string; internalPlan: string }
    >(toolRegistry.composeEscalation, {
      severity: inputData.triage.severity,
      queue: inputData.triage.queue,
      findings: inputData.findings
    });

    const fallbackReply = [
      `Hi ${inputData.triage.requester},`,
      "Thanks for reporting this. We have triaged the issue and started the next investigation step.",
      `Current priority: ${inputData.triage.severity}. We will update you within ${inputData.triage.slaHours} hours or sooner if the status changes.`,
      "Please reply with any additional timestamps, affected users, or screenshots."
    ].join("\n\n");

    let customerReply = fallbackReply;
    if (process.env.OPENAI_API_KEY) {
      const result = await responseAgent.generate(
        `Triage summary: ${inputData.triage.summary}\nResearch findings:\n${inputData.findings.join("\n")}\nDraft an internal action plan and a customer-ready response.`
      );
      if (result.text) {
        customerReply = result.text;
      }
    }

    return {
      ...inputData,
      internalPlan: operations.internalPlan,
      nextAction: operations.nextAction,
      customerReply
    };
  }
});

export const supportWorkflow = createWorkflow({
  id: "support-ops-workflow",
  description: "Production-like support workflow for triage, research, and customer response generation.",
  inputSchema: supportInputSchema,
  outputSchema: responseOutputSchema
})
  .then(normalizeInputStep)
  .then(triageStep)
  .then(researchStep)
  .then(responseStep)
  .commit();

type SupportQualityInput = {
  prompt: string;
  customerTier: "free" | "business" | "enterprise";
};

type SupportQualityOutput = {
  internalPlan: string;
  customerReply: string;
  nextAction: string;
  severity: "low" | "medium" | "high" | "critical";
  sources: string[];
};

type PolicyFitInput = {
  prompt: string;
};

type PolicyFitOutput = {
  severity: "low" | "medium" | "high" | "critical";
  nextAction: string;
};

export const supportQualityScorer = createScorer<SupportQualityInput, SupportQualityOutput>({
  id: "support-quality",
  description: "Scores whether the workflow output contains the basics needed for a support handoff."
})
  .generateScore(({ run }) => {
    const output = run.output;
    let score = 0;
    if (output.internalPlan.length > 60) score += 0.35;
    if (output.customerReply.includes("update")) score += 0.2;
    if (output.nextAction.length > 20) score += 0.25;
    if (output.sources.length > 0) score += 0.2;
    return Number(score.toFixed(2));
  })
  .generateReason(({ run, score }) =>
    score >= 0.8
      ? `Complete handoff with ${run.output.sources.length} supporting source references.`
      : "Output is missing either operational detail, customer guidance, or support evidence."
  );

export const policyFitScorer = createScorer<PolicyFitInput, PolicyFitOutput>({
  id: "policy-fit",
  description: "Scores whether the response matches expected escalation discipline."
})
  .generateScore(({ run }) => {
    const output = run.output;
    if (output.severity === "critical" && /page/i.test(output.nextAction)) return 1;
    if (output.severity !== "critical" && /route/i.test(output.nextAction)) return 0.9;
    return 0.5;
  })
  .generateReason(({ run }) =>
    `Next action "${run.output.nextAction}" was reviewed against the ${run.output.severity} severity path.`
  );

export const mastra = new Mastra({
  agents: {
    triageAgent,
    researchAgent,
    responseAgent
  },
  workflows: {
    supportWorkflow
  },
  tools: toolRegistry,
  scorers: {
    supportQuality: supportQualityScorer,
    policyFit: policyFitScorer
  },
  vectors: {
    supportMemory: vector
  },
  storage,
  memory: {
    supportMemory: createSupportMemory()
  }
});

export const agentSummaries = [
  {
    id: "triage-agent",
    name: "Support Triage Agent",
    role: "Urgency assignment, queue routing, and incident framing.",
    tools: ["classify-ticket"],
    memory: memoryMode
  },
  {
    id: "research-agent",
    name: "Policy Research Agent",
    role: "Playbook retrieval and support-history recall.",
    tools: ["search-knowledge"],
    memory: memoryMode
  },
  {
    id: "response-agent",
    name: "Resolution Agent",
    role: "Internal plan and customer-ready response drafting.",
    tools: ["compose-escalation"],
    memory: memoryMode
  }
] as const;

export async function runSupportWorkflow(input: SupportRunInput): Promise<SupportRunRecord> {
  const run = await supportWorkflow.createRun();
  const result = await run.start({ inputData: input });
  if (result.status !== "success") {
    throw new Error(`Support workflow did not complete successfully: ${result.status}`);
  }
  const output = result.result;

  const evaluations: EvaluationResult[] = [];
  const supportQuality = await supportQualityScorer.run({
    input: {
      prompt: input.prompt,
      customerTier: input.customerTier
    },
    output: {
      internalPlan: output.internalPlan,
      customerReply: output.customerReply,
      nextAction: output.nextAction,
      severity: output.triage.severity,
      sources: output.sources
    }
  });
  evaluations.push({
    label: "Support Quality",
    score: supportQuality.score,
    reason: supportQuality.reason ?? ""
  });

  const policyFit = await policyFitScorer.run({
    input: { prompt: input.prompt },
    output: {
      severity: output.triage.severity,
      nextAction: output.nextAction
    }
  });
  evaluations.push({
    label: "Policy Fit",
    score: policyFit.score,
    reason: policyFit.reason ?? ""
  });

  return {
    id: run.runId,
    traceId: run.runId,
    startedAt: new Date().toISOString(),
    workflowId: supportWorkflow.id,
    input,
    triage: {
      severity: output.triage.severity,
      queue: output.triage.queue,
      slaHours: output.triage.slaHours,
      labels: output.triage.labels,
      summary: output.triage.summary
    },
    research: {
      findings: output.findings,
      sources: output.sources,
      memoryHits: output.memoryHits
    },
    output: {
      internalPlan: output.internalPlan,
      customerReply: output.customerReply,
      nextAction: output.nextAction
    },
    evaluations
  };
}
