import { playbooks } from "../data/playbooks.js";

type Severity = "low" | "medium" | "high" | "critical";
type Tier = "free" | "business" | "enterprise";

export function scoreSeverity(prompt: string): Severity {
  const text = prompt.toLowerCase();

  if (/(outage|security|breach|data loss|cannot access|down)/.test(text)) {
    return "critical";
  }
  if (/(refund|invoice|sso|login|blocked|timeout|urgent)/.test(text)) {
    return "high";
  }
  if (/(question|how do i|clarify|change)/.test(text)) {
    return "low";
  }
  return "medium";
}

export function deriveQueue(prompt: string): string {
  const text = prompt.toLowerCase();

  if (/(invoice|refund|charge|billing)/.test(text)) return "finance-ops";
  if (/(sso|login|okta|auth)/.test(text)) return "identity-platform";
  if (/(export|report|csv|data)/.test(text)) return "data-platform";
  if (/(api|429|rate)/.test(text)) return "developer-success";
  return "customer-support";
}

export function lookupSlaHours(severity: Severity, tier: Tier): number {
  const matrix: Record<Severity, Record<Tier, number>> = {
    critical: { free: 12, business: 4, enterprise: 1 },
    high: { free: 24, business: 8, enterprise: 2 },
    medium: { free: 48, business: 16, enterprise: 6 },
    low: { free: 72, business: 24, enterprise: 8 }
  };

  return matrix[severity][tier];
}

export function extractLabels(prompt: string): string[] {
  const text = prompt.toLowerCase();
  const labels = new Set<string>();

  for (const token of ["billing", "auth", "export", "api", "enterprise", "refund", "incident"]) {
    if (text.includes(token)) labels.add(token);
  }

  if (/(cannot|broken|fail|error|urgent)/.test(text)) labels.add("needs-attention");
  return Array.from(labels);
}

export function searchPlaybooks(prompt: string) {
  const text = prompt.toLowerCase();

  return playbooks
    .map((article) => {
      const hits = article.tags.filter((tag) => text.includes(tag)).length;
      return { article, hits };
    })
    .filter(({ hits }) => hits > 0)
    .sort((left, right) => right.hits - left.hits)
    .slice(0, 3)
    .map(({ article }) => article);
}
