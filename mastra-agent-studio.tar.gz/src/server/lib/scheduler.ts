import { scheduledJobs, recentRuns, updateJob } from "./state.js";

export function startScheduler() {
  const hourMs = 60 * 60 * 1000;
  const dayMs = 24 * hourMs;

  const backlogTimer = setInterval(() => {
    const criticalRuns = recentRuns.filter((run) => run.triage.severity === "critical").length;
    updateJob("hourly-backlog-scan", {
      status: "running",
      lastRunAt: new Date().toISOString()
    });
    updateJob("hourly-backlog-scan", {
      status: "completed",
      summary: `Recent runs reviewed: ${recentRuns.length}. Critical items detected: ${criticalRuns}.`
    });
  }, hourMs);

  const evalTimer = setInterval(() => {
    const scores = recentRuns.flatMap((run) => run.evaluations.map((evaluation) => evaluation.score));
    const averageScore =
      scores.length === 0 ? 0 : scores.reduce((sum, value) => sum + value, 0) / scores.length;

    updateJob("nightly-eval-rollup", {
      status: "running",
      lastRunAt: new Date().toISOString()
    });
    updateJob("nightly-eval-rollup", {
      status: "completed",
      summary: `Average evaluation score across recent traces: ${averageScore.toFixed(2)}.`
    });
  }, dayMs);

  return () => {
    clearInterval(backlogTimer);
    clearInterval(evalTimer);
  };
}

export function getJobs() {
  return scheduledJobs;
}
