export type PlaybookArticle = {
  id: string;
  title: string;
  tags: string[];
  body: string;
  escalationQueue: string;
};

export const playbooks: PlaybookArticle[] = [
  {
    id: "billing-dispute",
    title: "Billing Dispute Resolution",
    tags: ["billing", "invoice", "refund", "charge"],
    escalationQueue: "finance-ops",
    body:
      "For billing disputes, confirm account owner identity, gather invoice IDs, verify contract tier, and acknowledge a two-business-day investigation SLA. Offer a provisional credit only when duplicate charges are confirmed."
  },
  {
    id: "sso-outage",
    title: "SSO Login Outage",
    tags: ["sso", "login", "auth", "outage", "okta"],
    escalationQueue: "identity-platform",
    body:
      "For SSO issues affecting multiple users, collect IdP, tenant slug, first failure timestamp, and impacted regions. Escalate immediately if enterprise customers cannot access production. Share status-page guidance and ask for recent SAML metadata changes."
  },
  {
    id: "data-export",
    title: "Large Export Requests",
    tags: ["export", "csv", "reporting", "data"],
    escalationQueue: "data-platform",
    body:
      "For exports timing out, recommend asynchronous export generation, provide the expected completion window, and ask for report filters. Escalate when the export exceeds 30 minutes on enterprise accounts or blocks compliance reporting."
  },
  {
    id: "api-throttle",
    title: "API Throttling Guidance",
    tags: ["api", "rate-limit", "429", "throttle"],
    escalationQueue: "developer-success",
    body:
      "When customers hit rate limits, explain burst and sustained limits, suggest request smoothing, and recommend backoff headers. Escalate only if the observed rate is below contract limits or the retry-after header is missing."
  }
];
