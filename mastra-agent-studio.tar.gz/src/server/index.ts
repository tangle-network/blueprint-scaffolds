import "dotenv/config";
import express from "express";
import cors from "cors";
import { z } from "zod";
import { agentSummaries, runSupportWorkflow, toolCatalog } from "./lib/mastra.js";
import { addRun, recentRuns } from "./lib/state.js";
import { getJobs, startScheduler } from "./lib/scheduler.js";
import type { DashboardPayload, SupportRunInput } from "../shared/types.js";

const app = express();
const port = Number(process.env.PORT ?? 4111);

app.use(cors());
app.use(express.json());

const stopScheduler = startScheduler();
process.on("SIGINT", stopScheduler);
process.on("SIGTERM", stopScheduler);

const runInputSchema = z.object({
  prompt: z.string().min(10),
  customerTier: z.enum(["free", "business", "enterprise"]),
  channel: z.enum(["email", "chat", "slack"]),
  requester: z.string().min(2)
});

app.get("/api/dashboard", (_request, response) => {
  const payload: DashboardPayload = {
    title: "Mastra Agent Studio",
    subtitle:
      "A support operations cockpit with multi-agent orchestration, tool routing, vector-ready memory, scheduled jobs, and evaluations.",
    agents: agentSummaries.map((agent) => ({ ...agent, tools: [...agent.tools] })),
    tools: toolCatalog,
    jobs: getJobs(),
    recentRuns
  };

  response.json(payload);
});

app.post("/api/runs", async (request, response) => {
  const parsed = runInputSchema.safeParse(request.body);
  if (!parsed.success) {
    response.status(400).json({
      error: "Invalid payload",
      issues: parsed.error.issues
    });
    return;
  }

  try {
    const record = await runSupportWorkflow(parsed.data as SupportRunInput);
    addRun(record);
    response.status(201).json(record);
  } catch (error) {
    response.status(500).json({
      error: error instanceof Error ? error.message : "Unknown workflow error"
    });
  }
});

app.get("/health", (_request, response) => {
  response.json({
    ok: true,
    runs: recentRuns.length,
    jobs: getJobs().length
  });
});

app.listen(port, () => {
  console.log(`Mastra Agent Studio API listening on http://localhost:${port}`);
});
