export type StudioAgentSummary = {
  id: string;
  name: string;
  role: string;
  tools: string[];
  memory: "vector-enabled" | "transcript-only";
};

export type ToolSummary = {
  id: string;
  description: string;
  category: "triage" | "research" | "response" | "operations";
};

export type EvaluationResult = {
  label: string;
  score: number;
  reason: string;
};

export type SupportRunInput = {
  prompt: string;
  customerTier: "free" | "business" | "enterprise";
  channel: "email" | "chat" | "slack";
  requester: string;
};

export type SupportRunRecord = {
  id: string;
  traceId: string;
  startedAt: string;
  workflowId: string;
  input: SupportRunInput;
  triage: {
    severity: "low" | "medium" | "high" | "critical";
    queue: string;
    slaHours: number;
    labels: string[];
    summary: string;
  };
  research: {
    findings: string[];
    sources: string[];
    memoryHits: string[];
  };
  output: {
    internalPlan: string;
    customerReply: string;
    nextAction: string;
  };
  evaluations: EvaluationResult[];
};

export type JobRecord = {
  id: string;
  label: string;
  cadence: string;
  lastRunAt: string | null;
  status: "idle" | "running" | "completed";
  summary: string;
};

export type DashboardPayload = {
  title: string;
  subtitle: string;
  agents: StudioAgentSummary[];
  tools: ToolSummary[];
  jobs: JobRecord[];
  recentRuns: SupportRunRecord[];
};
