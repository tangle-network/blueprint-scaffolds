"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  MessageSquare,
  Bot,
  Activity,
  GitBranch,
  ClipboardCheck,
  Clock,
  Zap,
} from "lucide-react";

const navItems = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/playground", label: "Playground", icon: MessageSquare },
  { href: "/agents", label: "Agents", icon: Bot },
  { href: "/traces", label: "Traces", icon: Activity },
  { href: "/workflows", label: "Workflows", icon: GitBranch },
  { href: "/evaluations", label: "Evaluations", icon: ClipboardCheck },
  { href: "/jobs", label: "Scheduled Jobs", icon: Clock },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-64 border-r bg-sidebar p-4 flex flex-col gap-1">
      <div className="flex items-center gap-2 px-3 py-4 mb-2">
        <Zap className="h-6 w-6 text-primary" />
        <span className="text-lg font-bold text-foreground">Agent Studio</span>
      </div>
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = pathname === item.href;
        return (
          <Link
            key={item.href}
            href={item.href}
            className={`flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors ${
              isActive
                ? "bg-sidebar-active text-white"
                : "text-sidebar-foreground hover:bg-sidebar-hover"
            }`}
          >
            <Icon className="h-4 w-4" />
            {item.label}
          </Link>
        );
      })}
    </aside>
  );
}
