# AGENTS.md

## Goal

Build a Mastra-based agent studio in TypeScript. Agent configuration, tool management, workflow builder, execution monitoring.

## Stack

- Family: `agent-service-ts`
- Layers: `capability:agent-mastra`, `database:sqlite`, `sdk:none`, `auth:none`, `payments:none`, `queue:none`

## Architecture

- Agent control loop: plan → act → reflect
- Tool registration
- Memory/state management
- HTTP health endpoint

## Entry Points

- `agent.mjs`
- `agent.config.json`

## Commands

- `node agent.mjs`

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
