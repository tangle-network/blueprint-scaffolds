use std::collections::HashMap;

use crate::error::DexError;
use crate::pool::{PoolKind, PoolState};
use crate::types::PoolId;

#[derive(Default)]
pub struct PoolFactory {
    pools: HashMap<PoolId, PoolState>,
    nonce: u64,
}

impl PoolFactory {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn create_pool(
        &mut self,
        kind: PoolKind,
        token_a: &str,
        token_b: &str,
        reserve_a: f64,
        reserve_b: f64,
        fee_bps: u16,
        weights: Vec<f64>,
        amplification: Option<f64>,
    ) -> Result<PoolId, DexError> {
        if token_a == token_b {
            return Err(DexError::InvalidTokenPair);
        }

        self.nonce += 1;
        let id = format!("{:?}-{}-{}-{}", kind, token_a, token_b, self.nonce).to_lowercase();

        if self.pools.contains_key(&id) {
            return Err(DexError::PoolAlreadyExists);
        }

        let pool = PoolState::new(
            id.clone(),
            kind,
            token_a,
            token_b,
            reserve_a,
            reserve_b,
            fee_bps,
            weights,
            amplification,
        )?;

        self.pools.insert(id.clone(), pool);
        Ok(id)
    }

    pub fn create_concentrated_pool(
        &mut self,
        token_a: &str,
        token_b: &str,
        reserve_a: f64,
        reserve_b: f64,
        fee_bps: u16,
        price_lower: f64,
        price_upper: f64,
    ) -> Result<PoolId, DexError> {
        let id = self.create_pool(
            PoolKind::ConcentratedLiquidity,
            token_a,
            token_b,
            reserve_a,
            reserve_b,
            fee_bps,
            vec![0.5, 0.5],
            None,
        )?;

        if let Some(pool) = self.pools.get_mut(&id) {
            *pool = pool.clone().with_range(price_lower, price_upper);
        }

        Ok(id)
    }

    pub fn get_pool(&self, pool_id: &str) -> Result<&PoolState, DexError> {
        self.pools.get(pool_id).ok_or(DexError::PoolNotFound)
    }

    pub fn get_pool_mut(&mut self, pool_id: &str) -> Result<&mut PoolState, DexError> {
        self.pools.get_mut(pool_id).ok_or(DexError::PoolNotFound)
    }

    pub fn list_pools(&self) -> Vec<&PoolState> {
        self.pools.values().collect()
    }
}
