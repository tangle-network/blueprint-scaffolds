use crate::error::DexError;
use crate::factory::PoolFactory;
use crate::oracle::PriceOracle;
use crate::types::PoolId;

#[derive(Clone, Debug)]
pub struct SwapStep {
    pub pool_id: PoolId,
    pub token_in: String,
    pub token_out: String,
}

impl SwapStep {
    pub fn new(pool_id: PoolId, token_in: impl Into<String>, token_out: impl Into<String>) -> Self {
        Self {
            pool_id,
            token_in: token_in.into(),
            token_out: token_out.into(),
        }
    }
}

#[derive(Clone, Debug)]
pub struct RoutePlan {
    pub amount_in: f64,
    pub amount_out: f64,
    pub price_impact_bps: u32,
    pub hops: usize,
}

#[derive(Clone, Debug)]
pub struct LimitOrder {
    pub owner: String,
    pub token_in: String,
    pub token_out: String,
    pub amount_in: f64,
    pub target_price: f64,
}

#[derive(Clone, Debug)]
pub struct TwapExecutionReport {
    pub slices: usize,
    pub slice_size: f64,
    pub expected_output: f64,
}

#[derive(Clone, Debug)]
pub struct FlashLoanQuote {
    pub amount: f64,
    pub fee: f64,
    pub pool_id: PoolId,
}

#[derive(Default)]
pub struct SwapRouter {
    pub limit_orders: Vec<LimitOrder>,
}

impl SwapRouter {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn quote_route(
        &self,
        factory: &PoolFactory,
        steps: &[SwapStep],
        amount_in: f64,
    ) -> Result<RoutePlan, DexError> {
        if amount_in <= 0.0 {
            return Err(DexError::InvalidAmount);
        }

        let mut running_amount = amount_in;
        let starting_amount = amount_in;

        for step in steps {
            let pool = factory.get_pool(&step.pool_id)?;
            running_amount = pool.quote_out(&step.token_in, &step.token_out, running_amount)?;
        }

        let impact_ratio =
            ((starting_amount - running_amount).abs() / starting_amount.max(1.0) * 10_000.0) as u32;

        Ok(RoutePlan {
            amount_in,
            amount_out: running_amount,
            price_impact_bps: impact_ratio,
            hops: steps.len(),
        })
    }

    pub fn execute_route(
        &mut self,
        factory: &mut PoolFactory,
        oracle: &mut PriceOracle,
        steps: Vec<SwapStep>,
        amount_in: f64,
        max_slippage_pct: f64,
        oracle_lookback: usize,
    ) -> Result<RoutePlan, DexError> {
        let quote = self.quote_route(factory, &steps, amount_in)?;

        let mut running_amount = amount_in;
        for step in &steps {
            let twap = oracle.twap(&step.token_in, &step.token_out, oracle_lookback)?;
            let pool = factory.get_pool(&step.pool_id)?;
            let quoted_spot = pool.spot_price(&step.token_in, &step.token_out)?;
            let deviation = ((quoted_spot - twap) / twap).abs();
            if deviation > max_slippage_pct {
                return Err(DexError::SlippageExceeded);
            }
            let pool = factory.get_pool_mut(&step.pool_id)?;
            running_amount = pool.apply_swap(&step.token_in, &step.token_out, running_amount)?;
        }

        Ok(RoutePlan {
            amount_in,
            amount_out: running_amount,
            price_impact_bps: quote.price_impact_bps,
            hops: steps.len(),
        })
    }

    pub fn place_limit_order(&mut self, order: LimitOrder) {
        self.limit_orders.push(order);
    }

    pub fn execute_limit_orders(
        &mut self,
        oracle: &PriceOracle,
    ) -> Result<Vec<LimitOrder>, DexError> {
        let mut executed = Vec::new();
        let mut remaining = Vec::new();

        for order in self.limit_orders.drain(..) {
            let latest = oracle.latest_price(&order.token_in, &order.token_out)?;
            if latest >= order.target_price {
                executed.push(order);
            } else {
                remaining.push(order);
            }
        }

        self.limit_orders = remaining;
        Ok(executed)
    }

    pub fn plan_twap(
        &self,
        oracle: &PriceOracle,
        token_in: &str,
        token_out: &str,
        total_amount: f64,
        slices: usize,
    ) -> Result<TwapExecutionReport, DexError> {
        if total_amount <= 0.0 || slices == 0 {
            return Err(DexError::InvalidAmount);
        }

        let reference_price = oracle.twap(token_in, token_out, slices)?;
        let slice_size = total_amount / slices as f64;
        Ok(TwapExecutionReport {
            slices,
            slice_size,
            expected_output: total_amount * reference_price,
        })
    }

    pub fn quote_flash_loan(
        &self,
        factory: &PoolFactory,
        pool_id: &str,
        token: &str,
        amount: f64,
    ) -> Result<FlashLoanQuote, DexError> {
        let pool = factory.get_pool(pool_id)?;
        let capacity = pool.flash_loan_capacity(token)?;
        if amount > capacity {
            return Err(DexError::FlashLoanNotAvailable);
        }

        let fee = amount * 0.0008;
        Ok(FlashLoanQuote {
            amount,
            fee,
            pool_id: pool_id.to_string(),
        })
    }
}
