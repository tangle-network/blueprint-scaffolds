use std::collections::{HashMap, VecDeque};

use crate::error::DexError;

#[derive(Clone, Debug)]
pub struct OracleObservation {
    pub timestamp: u64,
    pub price: f64,
}

pub struct PriceOracle {
    max_observations: usize,
    feeds: HashMap<String, VecDeque<OracleObservation>>,
}

impl PriceOracle {
    pub fn new(max_observations: usize) -> Self {
        Self {
            max_observations,
            feeds: HashMap::new(),
        }
    }

    pub fn record_price(
        &mut self,
        token_in: &str,
        token_out: &str,
        price: f64,
        timestamp: u64,
    ) -> Result<(), DexError> {
        if price <= 0.0 {
            return Err(DexError::InvalidAmount);
        }

        let feed = self
            .feeds
            .entry(Self::feed_key(token_in, token_out))
            .or_default();
        if feed.len() == self.max_observations {
            feed.pop_front();
        }
        feed.push_back(OracleObservation { timestamp, price });
        Ok(())
    }

    pub fn latest_price(&self, token_in: &str, token_out: &str) -> Result<f64, DexError> {
        self.feeds
            .get(&Self::feed_key(token_in, token_out))
            .and_then(|feed| feed.back())
            .map(|observation| observation.price)
            .ok_or(DexError::OracleUnavailable)
    }

    pub fn twap(&self, token_in: &str, token_out: &str, lookback: usize) -> Result<f64, DexError> {
        let feed = self
            .feeds
            .get(&Self::feed_key(token_in, token_out))
            .ok_or(DexError::OracleUnavailable)?;

        let samples: Vec<&OracleObservation> = feed.iter().rev().take(lookback.max(1)).collect();
        if samples.is_empty() {
            return Err(DexError::OracleUnavailable);
        }

        let weighted_sum: f64 = samples
            .iter()
            .enumerate()
            .map(|(index, observation)| observation.price * (samples.len() - index) as f64)
            .sum();
        let divisor = (samples.len() * (samples.len() + 1) / 2) as f64;
        Ok(weighted_sum / divisor)
    }

    fn feed_key(token_in: &str, token_out: &str) -> String {
        format!("{}:{}", token_in, token_out)
    }
}
