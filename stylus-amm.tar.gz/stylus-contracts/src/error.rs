use std::error::Error;
use std::fmt::{Display, Formatter};

#[derive(Debug, Clone, PartialEq)]
pub enum DexError {
    InvalidTokenPair,
    PoolAlreadyExists,
    PoolNotFound,
    InsufficientLiquidity,
    InvalidAmount,
    InvalidWeighting,
    SlippageExceeded,
    OracleUnavailable,
    LimitOrderNotTriggerable,
    FlashLoanNotAvailable,
}

impl Display for DexError {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        let message = match self {
            DexError::InvalidTokenPair => "invalid token pair",
            DexError::PoolAlreadyExists => "pool already exists",
            DexError::PoolNotFound => "pool not found",
            DexError::InsufficientLiquidity => "insufficient liquidity",
            DexError::InvalidAmount => "invalid amount",
            DexError::InvalidWeighting => "invalid weighting",
            DexError::SlippageExceeded => "slippage exceeded",
            DexError::OracleUnavailable => "oracle unavailable",
            DexError::LimitOrderNotTriggerable => "limit order not triggerable",
            DexError::FlashLoanNotAvailable => "flash loan not available",
        };

        f.write_str(message)
    }
}

impl Error for DexError {}
