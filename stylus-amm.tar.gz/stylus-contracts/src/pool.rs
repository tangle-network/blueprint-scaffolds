use crate::error::DexError;
use crate::types::PoolId;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum PoolKind {
    ConstantProduct,
    StableSwap,
    ConcentratedLiquidity,
    Weighted,
}

#[derive(Clone, Debug)]
pub struct PoolState {
    pub id: PoolId,
    pub kind: PoolKind,
    pub token_a: String,
    pub token_b: String,
    pub reserve_a: f64,
    pub reserve_b: f64,
    pub fee_bps: u16,
    pub amplification: Option<f64>,
    pub weights: Vec<f64>,
    pub price_lower: Option<f64>,
    pub price_upper: Option<f64>,
}

impl PoolState {
    pub fn new(
        id: PoolId,
        kind: PoolKind,
        token_a: impl Into<String>,
        token_b: impl Into<String>,
        reserve_a: f64,
        reserve_b: f64,
        fee_bps: u16,
        weights: Vec<f64>,
        amplification: Option<f64>,
    ) -> Result<Self, DexError> {
        if reserve_a <= 0.0 || reserve_b <= 0.0 {
            return Err(DexError::InvalidAmount);
        }

        if matches!(kind, PoolKind::Weighted) {
            let weight_sum: f64 = weights.iter().sum();
            if weights.len() != 2 || (weight_sum - 1.0).abs() > 0.0001 {
                return Err(DexError::InvalidWeighting);
            }
        }

        Ok(Self {
            id,
            kind,
            token_a: token_a.into(),
            token_b: token_b.into(),
            reserve_a,
            reserve_b,
            fee_bps,
            amplification,
            weights,
            price_lower: None,
            price_upper: None,
        })
    }

    pub fn with_range(mut self, price_lower: f64, price_upper: f64) -> Self {
        self.price_lower = Some(price_lower);
        self.price_upper = Some(price_upper);
        self
    }

    pub fn supports_pair(&self, token_in: &str, token_out: &str) -> bool {
        (self.token_a == token_in && self.token_b == token_out)
            || (self.token_b == token_in && self.token_a == token_out)
    }

    pub fn spot_price(&self, token_in: &str, token_out: &str) -> Result<f64, DexError> {
        if self.token_a == token_in && self.token_b == token_out {
            Ok(self.reserve_b / self.reserve_a)
        } else if self.token_b == token_in && self.token_a == token_out {
            Ok(self.reserve_a / self.reserve_b)
        } else {
            Err(DexError::InvalidTokenPair)
        }
    }

    pub fn quote_out(
        &self,
        token_in: &str,
        token_out: &str,
        amount_in: f64,
    ) -> Result<f64, DexError> {
        if amount_in <= 0.0 {
            return Err(DexError::InvalidAmount);
        }

        if !self.supports_pair(token_in, token_out) {
            return Err(DexError::InvalidTokenPair);
        }

        let fee_multiplier = 1.0 - f64::from(self.fee_bps) / 10_000.0;
        let amount_in_after_fee = amount_in * fee_multiplier;

        match self.kind {
            PoolKind::ConstantProduct => self.constant_product_quote(token_in, amount_in_after_fee),
            PoolKind::StableSwap => self.stable_swap_quote(token_in, amount_in_after_fee),
            PoolKind::ConcentratedLiquidity => {
                self.concentrated_liquidity_quote(token_in, amount_in_after_fee)
            }
            PoolKind::Weighted => self.weighted_quote(token_in, amount_in_after_fee),
        }
    }

    pub fn apply_swap(
        &mut self,
        token_in: &str,
        token_out: &str,
        amount_in: f64,
    ) -> Result<f64, DexError> {
        let amount_out = self.quote_out(token_in, token_out, amount_in)?;
        if self.token_a == token_in && self.token_b == token_out {
            self.reserve_a += amount_in;
            self.reserve_b -= amount_out;
        } else if self.token_b == token_in && self.token_a == token_out {
            self.reserve_b += amount_in;
            self.reserve_a -= amount_out;
        }

        if self.reserve_a <= 0.0 || self.reserve_b <= 0.0 {
            return Err(DexError::InsufficientLiquidity);
        }

        Ok(amount_out)
    }

    pub fn flash_loan_capacity(&self, token: &str) -> Result<f64, DexError> {
        if token == self.token_a {
            Ok(self.reserve_a * 0.35)
        } else if token == self.token_b {
            Ok(self.reserve_b * 0.35)
        } else {
            Err(DexError::InvalidTokenPair)
        }
    }

    fn ordered_reserves(&self, token_in: &str) -> Result<(f64, f64), DexError> {
        if self.token_a == token_in {
            Ok((self.reserve_a, self.reserve_b))
        } else if self.token_b == token_in {
            Ok((self.reserve_b, self.reserve_a))
        } else {
            Err(DexError::InvalidTokenPair)
        }
    }

    fn constant_product_quote(
        &self,
        token_in: &str,
        amount_in_after_fee: f64,
    ) -> Result<f64, DexError> {
        let (reserve_in, reserve_out) = self.ordered_reserves(token_in)?;
        let output = (reserve_out * amount_in_after_fee) / (reserve_in + amount_in_after_fee);
        if output >= reserve_out {
            return Err(DexError::InsufficientLiquidity);
        }
        Ok(output)
    }

    fn stable_swap_quote(&self, token_in: &str, amount_in_after_fee: f64) -> Result<f64, DexError> {
        let (reserve_in, reserve_out) = self.ordered_reserves(token_in)?;
        let amplification = self.amplification.unwrap_or(80.0);
        let price_bias =
            1.0 - (amount_in_after_fee / (reserve_in + reserve_out)).min(0.2) / amplification;
        let output = amount_in_after_fee * reserve_out / reserve_in * price_bias;
        if output >= reserve_out {
            return Err(DexError::InsufficientLiquidity);
        }
        Ok(output)
    }

    fn concentrated_liquidity_quote(
        &self,
        token_in: &str,
        amount_in_after_fee: f64,
    ) -> Result<f64, DexError> {
        let base_quote = self.constant_product_quote(token_in, amount_in_after_fee)?;
        let current_price = self.spot_price(
            token_in,
            if self.token_a == token_in {
                &self.token_b
            } else {
                &self.token_a
            },
        )?;
        let concentrated_boost = match (self.price_lower, self.price_upper) {
            (Some(lower), Some(upper)) if current_price >= lower && current_price <= upper => 1.08,
            _ => 0.96,
        };
        Ok(base_quote * concentrated_boost)
    }

    fn weighted_quote(&self, token_in: &str, amount_in_after_fee: f64) -> Result<f64, DexError> {
        let (reserve_in, reserve_out) = self.ordered_reserves(token_in)?;
        let (weight_in, weight_out) = if self.token_a == token_in {
            (self.weights[0], self.weights[1])
        } else {
            (self.weights[1], self.weights[0])
        };
        let ratio = reserve_in / (reserve_in + amount_in_after_fee);
        let power = weight_in / weight_out;
        let output = reserve_out * (1.0 - ratio.powf(power));
        if output >= reserve_out {
            return Err(DexError::InsufficientLiquidity);
        }
        Ok(output)
    }
}
