pub mod error;
pub mod factory;
pub mod oracle;
pub mod pool;
pub mod router;
pub mod types;

pub use error::DexError;
pub use factory::PoolFactory;
pub use oracle::{OracleObservation, PriceOracle};
pub use pool::{PoolKind, PoolState};
pub use router::{FlashLoanQuote, LimitOrder, RoutePlan, SwapRouter, SwapStep, TwapExecutionReport};
pub use types::{Address, PoolId};

#[cfg(test)]
mod tests {
    use crate::factory::PoolFactory;
    use crate::oracle::PriceOracle;
    use crate::pool::PoolKind;
    use crate::router::{SwapRouter, SwapStep};

    #[test]
    fn router_executes_multi_hop_trade() {
        let mut factory = PoolFactory::new();
        let cp_id = factory
            .create_pool(
                PoolKind::ConstantProduct,
                "ARB",
                "USDC",
                4_200_000.0,
                5_100_000.0,
                30,
                vec![0.5, 0.5],
                None,
            )
            .unwrap();
        let stable_id = factory
            .create_pool(
                PoolKind::StableSwap,
                "USDC",
                "ETH",
                8_800_000.0,
                2_450.0,
                4,
                vec![0.5, 0.5],
                None,
            )
            .unwrap();

        let mut oracle = PriceOracle::new(32);
        oracle.record_price("ARB", "USDC", 1.15, 1).unwrap();
        oracle.record_price("USDC", "ETH", 0.00029, 1).unwrap();

        let route = vec![
            SwapStep::new(cp_id.clone(), "ARB", "USDC"),
            SwapStep::new(stable_id.clone(), "USDC", "ETH"),
        ];

        let mut router = SwapRouter::new();
        let result = router.execute_route(&mut factory, &mut oracle, route, 10_000.0, 0.01, 2).unwrap();

        assert!(result.amount_out > 0.0);
        assert_eq!(result.hops, 2);
    }
}
