export interface Token {
  symbol: string;
  name: string;
  address: string;
  decimals: number;
}

export interface Pool {
  address: string;
  tokenA: Token;
  tokenB: Token;
  feeBps: number;
  poolType: PoolType;
  reserveA: bigint;
  reserveB: bigint;
  lpTokenAddress: string;
  tvlUsd: number;
}

export enum PoolType {
  ConstantProduct = 0,
  StableSwap = 1,
  ConcentratedLiquidity = 2,
  Weighted = 3,
}

export interface SwapQuote {
  amountIn: bigint;
  amountOut: bigint;
  priceImpact: number;
  fee: bigint;
  route: RouteHop[];
  estimatedGas: bigint;
}

export interface RouteHop {
  poolAddress: string;
  tokenIn: Token;
  tokenOut: Token;
  portion: number;
}
