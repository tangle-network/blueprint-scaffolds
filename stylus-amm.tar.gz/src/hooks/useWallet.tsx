import { createContext, useContext, useState, useCallback, type ReactNode } from "react";
import { TOKENS, getTokenPrice } from "../utils/amm";
import type { Token } from "../types";

interface WalletState {
  address: string | null;
  chainId: number | null;
  connected: boolean;
  connecting: boolean;
  balances: Record<string, bigint>;
  connect: () => Promise<void>;
  disconnect: () => void;
}

const WalletContext = createContext<WalletState>({
  address: null,
  chainId: null,
  connected: false,
  connecting: false,
  balances: {},
  connect: async () => {},
  disconnect: () => {},
});

export function useWallet() {
  return useContext(WalletContext);
}

function generateMockAddress(): string {
  const chars = "0123456789abcdef";
  let addr = "0x";
  for (let i = 0; i < 40; i++) addr += chars[Math.floor(Math.random() * 16)];
  return addr;
}

function generateMockBalances(): Record<string, bigint> {
  const balances: Record<string, bigint> = {};
  Object.values(TOKENS).forEach((token: Token) => {
    const usdValue = Math.random() * 10000;
    const price = getTokenPrice(token.symbol);
    balances[token.address] = BigInt(Math.floor((usdValue / price) * 10 ** token.decimals));
  });
  return balances;
}

export function WalletProvider({ children }: { children: ReactNode }) {
  const [address, setAddress] = useState<string | null>(null);
  const [chainId, setChainId] = useState<number | null>(null);
  const [connected, setConnected] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [balances, setBalances] = useState<Record<string, bigint>>({});

  const connect = useCallback(async () => {
    setConnecting(true);
    await new Promise((r) => setTimeout(r, 800));
    const addr = generateMockAddress();
    setAddress(addr);
    setChainId(42161);
    setConnected(true);
    setConnecting(generateMockBalances());
    setConnecting(false);
  }, []);

  const disconnect = useCallback(() => {
    setAddress(null);
    setChainId(null);
    setConnected(false);
    setBalances({});
  }, []);

  return (
    <WalletContext.Provider value={{ address, chainId, connected, connecting, balances, connect, disconnect }}>
      {children}
    </WalletContext.Provider>
  );
}
