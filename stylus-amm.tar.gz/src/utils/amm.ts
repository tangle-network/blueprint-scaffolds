import { PoolType, type Token, type Pool, type SwapQuote, type RouteHop } from "../types";

export const TOKENS: Record<string, Token> = {
  ETH: { symbol: "ETH", name: "Ether", address: "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE", decimals: 18 },
  USDC: { symbol: "USDC", name: "USD Coin", address: "0xaf88d065e77c8cC2239327C5EDb3A432268e5831", decimals: 6 },
  USDT: { symbol: "USDT", name: "Tether USD", address: "0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9", decimals: 6 },
  ARB: { symbol: "ARB", name: "Arbitrum", address: "0x912CE59144191C1204E64559FE8253a0e49E6548", decimals: 18 },
  WBTC: { symbol: "WBTC", name: "Wrapped Bitcoin", address: "0x2f2a2543B76B447Abf85393c1aC9e8a2F6B6d817", decimals: 8 },
  LINK: { symbol: "LINK", name: "Chainlink", address: "0xf97f4df75117a78c1A5a0DBb814Af92458539771", decimals: 18 },
  GMX: { symbol: "GMX", name: "GMX", address: "0xfc5A1A6EB076a2C7aD06eD22C90d7E710E35ad0a", decimals: 18 },
  RDNT: { symbol: "RDNT", name: "Radiant", address: "0x3082CC23568eA640225c2467653dB90e9250AaA0", decimals: 18 },
};

const PRICES: Record<string, number> = {
  ETH: 3500, USDC: 1, USDT: 1, ARB: 1.2, WBTC: 98000, LINK: 18, GMX: 42, RDNT: 0.35,
};

export const getTokenPrice = (s: string) => PRICES[s] ?? 1;

export const formatAmount = (wei: bigint, decimals: number, dp = 4): string => {
  const v = Number(wei) / 10 ** decimals;
  if (v === 0) return "0";
  if (v < 0.0001) return "<0.0001";
  return v.toFixed(dp);
};

export const parseAmount = (val: string, decimals: number): bigint => {
  if (!val || val === ".") return 0n;
  const parts = val.split(".");
  const whole = parts[0] || "0";
  const frac = (parts[1] || "").padEnd(decimals, "0").slice(0, decimals);
  return BigInt(whole) * 10n ** BigInt(decimals) + BigInt(frac);
};

function constantProduct(rIn: bigint, rOut: bigint, aIn: bigint, feeBps: number) {
  const fee = (aIn * BigInt(feeBps)) / 10000n;
  const a = aIn - fee;
  return { amountOut: (a * rOut) / (rIn + a), fee };
}

function stableSwap(rIn: bigint, rOut: bigint, aIn: bigint, feeBps: number) {
  const fee = (aIn * BigInt(feeBps)) / 10000n;
  const a = aIn - fee;
  const d = rIn + rOut;
  const ann = 1000n;
  const c = (rOut * d) / (ann * rIn + d - a);
  const out = rOut - c;
  return { amountOut: out > 0n ? out : 0n, fee };
}

function weightedSwap(rIn: bigint, rOut: bigint, aIn: bigint, feeBps: number) {
  const fee = (aIn * BigInt(feeBps)) / 10000n;
  const a = aIn - fee;
  const ratio = Number(a) / Number(rIn);
  const out = rOut - (rOut * BigInt(Math.round((1 / (1 + ratio)) * 1e18))) / 10n ** 18n;
  return { amountOut: out > 0n ? out : 0n, fee };
}

function priceImpact(aIn: bigint, aOut: bigint, rIn: bigint, rOut: bigint): number {
  const spot = Number(rOut) / Number(rIn);
  const exec = Number(aOut) / Number(aIn);
  if (spot === 0) return 0;
  return Math.max(0, ((spot - exec) / spot) * 100);
}

const FEE: Record<number, number> = { 0: 30, 1: 4, 2: 5, 3: 30 };

function mkPool(a: string, b: string, pt: PoolType, tvlA: number, tvlB: number): Pool {
  const tA = TOKENS[a], tB = TOKENS[b];
  const rA = BigInt(Math.floor((tvlA / getTokenPrice(a)) * 10 ** tA.decimals));
  const rB = BigInt(Math.floor((tvlB / getTokenPrice(b)) * 10 ** tB.decimals));
  const addr = `0x${a.toLowerCase()}${b.toLowerCase()}${pt}`.slice(0, 42).padEnd(42, "0");
  return { address: addr, tokenA: tA, tokenB: tB, feeBps: FEE[pt], poolType: pt, reserveA: rA, reserveB: rB, lpTokenAddress: `0xLP${addr.slice(4)}`, tvlUsd: tvlA + tvlB };
}

export const POOLS: Pool[] = [
  mkPool("ETH", "USDC", PoolType.ConstantProduct, 5e6, 5e6),
  mkPool("ETH", "USDT", PoolType.ConstantProduct, 3e6, 3e6),
  mkPool("USDC", "USDT", PoolType.StableSwap, 8e6, 8e6),
  mkPool("ETH", "ARB", PoolType.ConstantProduct, 2e6, 2e6),
  mkPool("ETH", "WBTC", PoolType.Weighted, 1.5e6, 1.5e6),
  mkPool("ARB", "USDC", PoolType.ConcentratedLiquidity, 1e6, 1e6),
  mkPool("LINK", "ETH", PoolType.ConstantProduct, 8e5, 8e5),
  mkPool("GMX", "ETH", PoolType.ConstantProduct, 6e5, 6e5),
  mkPool("RDNT", "ETH", PoolType.ConstantProduct, 4e5, 4e5),
  mkPool("WBTC", "USDC", PoolType.ConstantProduct, 3e6, 3e6),
];

function findPools(tIn: Token, tOut: Token) {
  return POOLS.filter(p =>
    (p.tokenA.address === tIn.address && p.tokenB.address === tOut.address) ||
    (p.tokenB.address === tIn.address && p.tokenA.address === tOut.address)
  );
}

function reserves(p: Pool, tIn: Token) {
  return p.tokenA.address === tIn.address
    ? { rIn: p.reserveA, rOut: p.reserveB }
    : { rIn: p.reserveB, rOut: p.reserveA };
}

export function getQuote(tIn: Token, tOut: Token, amountIn: bigint, pt?: PoolType): SwapQuote | null {
  let pools = findPools(tIn, tOut);
  let pool = pt !== undefined ? pools.find(p => p.poolType === pt) : pools[0];
  if (!pool) return null;
  const { rIn, rOut } = reserves(pool, tIn);
  const res = pool.poolType === PoolType.StableSwap
    ? stableSwap(rIn, rOut, amountIn, pool.feeBps)
    : pool.poolType === PoolType.Weighted
    ? weightedSwap(rIn, rOut, amountIn, pool.feeBps)
    : constantProduct(rIn, rOut, amountIn, pool.feeBps);
  const route: RouteHop[] = [{ poolAddress: pool.address, tokenIn: tIn, tokenOut: tOut, portion: 100 }];
  return { amountIn, amountOut: res.amountOut, priceImpact: priceImpact(amountIn, res.amountOut, rIn, rOut), fee: res.fee, route, estimatedGas: 120000n };
}

export function getMultiHopQuote(tIn: Token, tOut: Token, amountIn: bigint): SwapQuote | null {
  const direct = getQuote(tIn, tOut, amountIn);
  if (direct) return direct;
  const hops = Object.values(TOKENS).filter(t => t.address !== tIn.address && t.address !== tOut.address);
  let best: SwapQuote | null = null;
  for (const hop of hops) {
    const q1 = getQuote(tIn, hop, amountIn);
    if (!q1) continue;
    const q2 = getQuote(hop, tOut, q1.amountOut);
    if (!q2) continue;
    if (!best || q2.amountOut > best.amountOut) {
      best = { amountIn, amountOut: q2.amountOut, priceImpact: q1.priceImpact + q2.priceImpact, fee: q1.fee + q2.fee, route: [...q1.route, ...q2.route], estimatedGas: 240000n };
    }
  }
  return best;
}
