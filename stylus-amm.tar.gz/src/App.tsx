import { useMemo, useState } from 'react';

type PoolType = 'Constant Product' | 'Stable Swap' | 'Concentrated' | 'Weighted';

type Token = {
  symbol: string;
  name: string;
  price: number;
};

type Pool = {
  id: string;
  pair: string;
  tvl: string;
  apr: string;
  depth: number;
  feeBps: number;
  type: PoolType;
};

type RouteHop = {
  pool: string;
  tokenIn: string;
  tokenOut: string;
  feeBps: number;
};

const tokens: Token[] = [
  { symbol: 'ARB', name: 'Arbitrum', price: 1.14 },
  { symbol: 'USDC', name: 'USD Coin', price: 1 },
  { symbol: 'ETH', name: 'Ether', price: 3520 },
  { symbol: 'wstETH', name: 'Wrapped stETH', price: 4088 }
];

const pools: Pool[] = [
  { id: 'cp-eth-arb', pair: 'ETH / ARB', tvl: '$42.8M', apr: '18.4%', depth: 42000000, feeBps: 30, type: 'Constant Product' },
  { id: 'stable-usdc-usdt', pair: 'USDC / USDT', tvl: '$63.1M', apr: '9.2%', depth: 63100000, feeBps: 4, type: 'Stable Swap' },
  { id: 'cl-eth-usdc', pair: 'ETH / USDC', tvl: '$118.6M', apr: '24.9%', depth: 118600000, feeBps: 5, type: 'Concentrated' },
  { id: 'weighted-lst', pair: 'wstETH / ETH', tvl: '$27.4M', apr: '12.7%', depth: 27400000, feeBps: 12, type: 'Weighted' }
];

const routeTemplate: RouteHop[] = [
  { pool: 'cl-eth-usdc', tokenIn: 'ARB', tokenOut: 'USDC', feeBps: 5 },
  { pool: 'stable-usdc-usdt', tokenIn: 'USDC', tokenOut: 'ETH', feeBps: 4 }
];

const formatCurrency = (value: number) =>
  new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: value < 1 ? 4 : 2
  }).format(value);

const formatCompact = (value: number) =>
  new Intl.NumberFormat('en-US', {
    notation: 'compact',
    maximumFractionDigits: 2
  }).format(value);

const quoteSwap = (amountIn: number, fromPrice: number, toPrice: number, feeBps: number, hops: number) => {
  const grossOut = (amountIn * fromPrice) / toPrice;
  const feeMultiplier = Math.pow(1 - feeBps / 10000, hops);
  return grossOut * feeMultiplier;
};

function App() {
  const [fromSymbol, setFromSymbol] = useState('ARB');
  const [toSymbol, setToSymbol] = useState('ETH');
  const [amountIn, setAmountIn] = useState('1250');
  const [slippage, setSlippage] = useState('0.30');
  const [twapSlices, setTwapSlices] = useState(6);

  const fromToken = tokens.find((token) => token.symbol === fromSymbol) ?? tokens[0];
  const toToken = tokens.find((token) => token.symbol === toSymbol) ?? tokens[2];
  const parsedAmount = Number(amountIn) || 0;
  const parsedSlippage = Number(slippage) || 0;

  const quote = useMemo(() => {
    const bestPool = pools.reduce((currentBest, pool) => (pool.feeBps < currentBest.feeBps ? pool : currentBest), pools[0]);
    const hops = fromSymbol === 'ARB' && toSymbol === 'ETH' ? 2 : 1;
    const amountOut = quoteSwap(parsedAmount, fromToken.price, toToken.price, bestPool.feeBps, hops);
    const minReceived = amountOut * (1 - parsedSlippage / 100);
    const impact = Math.min(2.4, (parsedAmount * fromToken.price) / Math.max(bestPool.depth, 1) * 1000);
    return {
      bestPool,
      amountOut,
      minReceived,
      impact,
      executionPrice: amountOut > 0 ? (parsedAmount * fromToken.price) / amountOut : 0,
      routingHops: hops
    };
  }, [fromSymbol, fromToken.price, parsedAmount, parsedSlippage, toSymbol, toToken.price]);

  const totalValue = parsedAmount * fromToken.price;
  const twapChunk = twapSlices > 0 ? parsedAmount / twapSlices : 0;

  return (
    <div className="app-shell">
      <div className="ambient ambient-left" />
      <div className="ambient ambient-right" />
      <header className="hero">
        <div>
          <div className="eyebrow">Arbitrum Stylus AMM</div>
          <h1>StylusFlow powers low-cost routing across four pool primitives.</h1>
          <p>
            Swap through constant product, stable swap, concentrated liquidity, and weighted pools with
            TWAP execution, native limit orders, and flash-loan-aware routing.
          </p>
        </div>
        <div className="hero-stats">
          <article>
            <span>Gas profile</span>
            <strong>10-100x lower</strong>
            <small>Rust execution compiled for Stylus</small>
          </article>
          <article>
            <span>Available liquidity</span>
            <strong>$251.9M</strong>
            <small>Aggregated across active vaults</small>
          </article>
          <article>
            <span>Routing speed</span>
            <strong>&lt; 40ms</strong>
            <small>Path scoring with oracle-aware quotes</small>
          </article>
        </div>
      </header>

      <main className="dashboard-grid">
        <section className="panel swap-panel">
          <div className="panel-head">
            <div>
              <span className="eyebrow">Swap Router</span>
              <h2>Multi-hop swap execution</h2>
            </div>
            <span className="badge">Best route in {quote.routingHops} hop{quote.routingHops > 1 ? 's' : ''}</span>
          </div>

          <label className="field">
            <span>Sell</span>
            <div className="token-row">
              <input value={amountIn} onChange={(event) => setAmountIn(event.target.value)} inputMode="decimal" />
              <select value={fromSymbol} onChange={(event) => setFromSymbol(event.target.value)}>
                {tokens.map((token) => (
                  <option key={token.symbol} value={token.symbol}>
                    {token.symbol}
                  </option>
                ))}
              </select>
            </div>
            <small>{fromToken.name} spot {formatCurrency(fromToken.price)}</small>
          </label>

          <label className="field">
            <span>Buy</span>
            <div className="token-row">
              <output>{quote.amountOut.toFixed(toSymbol === 'USDC' ? 2 : 6)}</output>
              <select value={toSymbol} onChange={(event) => setToSymbol(event.target.value)}>
                {tokens.map((token) => (
                  <option key={token.symbol} value={token.symbol}>
                    {token.symbol}
                  </option>
                ))}
              </select>
            </div>
            <small>{toToken.name} spot {formatCurrency(toToken.price)}</small>
          </label>

          <div className="meta-grid">
            <div>
              <span>Execution price</span>
              <strong>{formatCurrency(quote.executionPrice || 0)}</strong>
            </div>
            <div>
              <span>Min received</span>
              <strong>{quote.minReceived.toFixed(6)} {toSymbol}</strong>
            </div>
            <div>
              <span>Price impact</span>
              <strong>{quote.impact.toFixed(3)}%</strong>
            </div>
            <div>
              <span>Route fee</span>
              <strong>{quote.bestPool.feeBps} bps</strong>
            </div>
          </div>

          <label className="slider-row">
            <span>Slippage tolerance</span>
            <input type="range" min="0.1" max="2" step="0.05" value={slippage} onChange={(event) => setSlippage(event.target.value)} />
            <strong>{parsedSlippage.toFixed(2)}%</strong>
          </label>

          <button className="primary-button">Swap {fromSymbol} for {toSymbol}</button>
        </section>

        <section className="panel">
          <div className="panel-head">
            <div>
              <span className="eyebrow">Execution Tools</span>
              <h2>TWAP and limit orders</h2>
            </div>
            <span className="badge">Oracle guarded</span>
          </div>

          <div className="strategy-card">
            <div>
              <span>TWAP order size</span>
              <strong>{twapChunk.toFixed(2)} {fromSymbol} / slice</strong>
            </div>
            <input type="range" min="2" max="12" step="1" value={twapSlices} onChange={(event) => setTwapSlices(Number(event.target.value))} />
            <small>{twapSlices} slices over 30 minutes with oracle deviation checks.</small>
          </div>

          <div className="order-book">
            <article>
              <span>Limit buy</span>
              <strong>ETH at $3,460</strong>
              <small>Size 18.4 ETH - trigger armed</small>
            </article>
            <article>
              <span>Limit sell</span>
              <strong>ARB at $1.22</strong>
              <small>Size 42,000 ARB - resting</small>
            </article>
            <article>
              <span>Flash loan capacity</span>
              <strong>{formatCompact(18500000)} USDC</strong>
              <small>0.08% fee via weighted treasury pool</small>
            </article>
          </div>

          <div className="route-card">
            <h3>Suggested route</h3>
            {routeTemplate.map((hop) => (
              <div className="route-hop" key={hop.pool}>
                <span>{hop.tokenIn} → {hop.tokenOut}</span>
                <strong>{hop.pool}</strong>
                <small>{hop.feeBps} bps</small>
              </div>
            ))}
          </div>
        </section>

        <section className="panel pools-panel">
          <div className="panel-head">
            <div>
              <span className="eyebrow">Liquidity</span>
              <h2>Pool inventory</h2>
            </div>
            <span className="badge">4 pool models</span>
          </div>

          <div className="pool-list">
            {pools.map((pool) => (
              <article key={pool.id} className="pool-card">
                <div>
                  <span>{pool.type}</span>
                  <h3>{pool.pair}</h3>
                </div>
                <div className="pool-metrics">
                  <div>
                    <span>TVL</span>
                    <strong>{pool.tvl}</strong>
                  </div>
                  <div>
                    <span>APR</span>
                    <strong>{pool.apr}</strong>
                  </div>
                  <div>
                    <span>Fee</span>
                    <strong>{pool.feeBps} bps</strong>
                  </div>
                </div>
                <button className="secondary-button">Add liquidity</button>
              </article>
            ))}
          </div>
        </section>

        <section className="panel">
          <div className="panel-head">
            <div>
              <span className="eyebrow">Position Manager</span>
              <h2>Liquidity strategy</h2>
            </div>
            <span className="badge">Stylus vaults</span>
          </div>

          <div className="liquidity-forms">
            <label className="field compact-field">
              <span>Deposit value</span>
              <input value={totalValue.toFixed(2)} readOnly />
            </label>
            <label className="field compact-field">
              <span>Target range</span>
              <input value="3,380 - 3,710 USDC" readOnly />
            </label>
            <label className="field compact-field">
              <span>Fee tier</span>
              <input value="0.05% concentrated" readOnly />
            </label>
            <label className="field compact-field">
              <span>Rebalance cadence</span>
              <input value="Every 4 hours" readOnly />
            </label>
          </div>

          <div className="insight-banner">
            <strong>Oracle insight:</strong> ETH/USDC 8-point TWAP is 0.41% above spot, favoring passive range liquidity over aggressive market sells.
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;
