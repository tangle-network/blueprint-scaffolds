import type { Token, Pool, RouteHop, PoolType } from "./types";

interface Edge {
  poolAddress: string;
  poolType: PoolType;
  from: string;
  to: string;
  weight: number;
}

export function findBestRoute(
  tokenIn: Token,
  tokenOut: Token,
  amountIn: bigint,
  pools: Pool[],
  maxHops: number = 3
): RouteHop[] {
  const graph = buildGraph(pools);
  const paths = findAllPaths(graph, tokenIn.address, tokenOut.address, maxHops);

  if (paths.length === 0) return [];

  let bestPath: Edge[] = [];
  let bestOutput = 0n;

  for (const path of paths) {
    let currentAmount = amountIn;
    let valid = true;
    for (const edge of path) {
      const pool = pools.find((p) => p.address === edge.poolAddress);
      if (!pool) { valid = false; break; }
      const isForward = pool.token0.address === edge.from;
      const reserveIn = isForward ? pool.reserve0 : pool.reserve1;
      const reserveOut = isForward ? pool.reserve1 : pool.reserve0;
      const feeNumerator = BigInt(10000 - pool.fee);
      const amountInWithFee = currentAmount * feeNumerator;
      const numerator = amountInWithFee * reserveOut;
      const denominator = reserveIn * 10000n + amountInWithFee;
      currentAmount = numerator / denominator;
      if (currentAmount <= 0n) { valid = false; break; }
    }
    if (valid && currentAmount > bestOutput) {
      bestOutput = currentAmount;
      bestPath = path;
    }
  }

  return bestPath.map((edge) => ({
    poolAddress: edge.poolAddress,
    poolType: edge.poolType,
    tokenIn: pools.find((p) => p.address === edge.poolAddress)!.token0.address === edge.from
      ? pools.find((p) => p.address === edge.poolAddress)!.token0
      : pools.find((p) => p.address === edge.poolAddress)!.token1,
    tokenOut: pools.find((p) => p.address === edge.poolAddress)!.token0.address === edge.to
      ? pools.find((p) => p.address === edge.poolAddress)!.token0
      : pools.find((p) => p.address === edge.poolAddress)!.token1,
    portion: 1,
  }));
}

function buildGraph(pools: Pool[]): Edge[] {
  const edges: Edge[] = [];
  for (const pool of pools) {
    edges.push({
      poolAddress: pool.address,
      poolType: pool.type,
      from: pool.token0.address,
      to: pool.token1.address,
      weight: pool.fee,
    });
    edges.push({
      poolAddress: pool.address,
      poolType: pool.type,
      from: pool.token1.address,
      to: pool.token0.address,
      weight: pool.fee,
    });
  }
  return edges;
}

function findAllPaths(
  graph: Edge[],
  start: string,
  end: string,
  maxHops: number
): Edge[][] {
  const results: Edge[][] = [];
  const visited = new Set<string>();

  function dfs(current: string, path: Edge[]) {
    if (current === end) {
      results.push([...path]);
      return;
    }
    if (path.length >= maxHops) return;

    for (const edge of graph) {
      if (edge.from === current && !visited.has(edge.poolAddress)) {
        visited.add(edge.poolAddress);
        path.push(edge);
        dfs(edge.to, path);
        path.pop();
        visited.delete(edge.poolAddress);
      }
    }
  }

  dfs(start, []);
  return results.sort((a, b) => a.length - b.length);
}

export function splitRoute(
  amountIn: bigint,
  routes: RouteHop[][],
  _pools: Pool[]
): { hops: RouteHop[]; portion: number }[] {
  const n = routes.length;
  if (n === 0) return [];
  return routes.map((hops, i) => ({
    hops,
    portion: i === 0 ? 1 : 0,
  }));
}
