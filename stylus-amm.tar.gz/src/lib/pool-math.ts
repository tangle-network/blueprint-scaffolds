import type { Pool, PoolType, SwapQuote, RouteHop } from "./types";

const MINIMUM_LIQUIDITY = 1000n;

export function getAmountOut(
  amountIn: bigint,
  reserveIn: bigint,
  reserveOut: bigint,
  feeBps: number
): bigint {
  if (amountIn <= 0n) return 0n;
  if (reserveIn <= 0n || reserveOut <= 0n) return 0n;
  const feeNumerator = BigInt(10000 - feeBps);
  const amountInWithFee = amountIn * feeNumerator;
  const numerator = amountInWithFee * reserveOut;
  const denominator = reserveIn * 10000n + amountInWithFee;
  return numerator / denominator;
}

export function getPriceImpact(
  amountIn: bigint,
  amountOut: bigint,
  reserveIn: bigint,
  reserveOut: bigint
): number {
  if (reserveIn === 0n || reserveOut === 0n) return 0;
  const spotPrice = Number(reserveOut) / Number(reserveIn);
  const executionPrice = Number(amountOut) / Number(amountIn);
  if (spotPrice === 0) return 0;
  return Math.abs(spotPrice - executionPrice) / spotPrice;
}

export function constantProductQuote(
  amountIn: bigint,
  pool: Pool
): { amountOut: bigint; priceImpact: number } {
  const amountOut = getAmountOut(amountIn, pool.reserve0, pool.reserve1, pool.fee);
  const priceImpact = getPriceImpact(amountIn, amountOut, pool.reserve0, pool.reserve1);
  return { amountOut, priceImpact };
}

export function stableSwapQuote(
  amountIn: bigint,
  pool: Pool
): { amountOut: bigint; priceImpact: number } {
  const ampFactor = pool.ampFactor ?? 100;
  const A = BigInt(ampFactor);
  const x = pool.reserve0;
  const y = pool.reserve1;
  const n = 2n;
  const An = A * n;
  const feeBps = pool.fee;

  if (x <= 0n || y <= 0n || amountIn <= 0n) {
    return { amountOut: 0n, priceImpact: 0 };
  }

  const D = computeD(x, y, An);
  const xNew = x + amountIn;
  const yNew = computeY(xNew, D, An);
  const dy = y - yNew;
  const fee = (dy * BigInt(feeBps)) / 10000n;
  const amountOut = dy - fee;
  const spotPrice = Number(y) / Number(x);
  const execPrice = Number(amountOut) / Number(amountIn);
  const priceImpact = spotPrice > 0 ? Math.abs(spotPrice - execPrice) / spotPrice : 0;

  return { amountOut, priceImpact };
}

function computeD(x: bigint, y: bigint, An: bigint): bigint {
  const S = x + y;
  if (S === 0n) return 0n;
  let D = S;
  for (let i = 0; i < 256; i++) {
    const D_P = (D * D) / (x * 2n) + (D * D) / (y * 2n);
    const Dprev = D;
    D = ((An * S + D_P * 2n) * D) / ((An - 1n) * D + D_P * 3n);
    if (D > Dprev) {
      if (D - Dprev <= 1n) break;
    } else {
      if (Dprev - D <= 1n) break;
    }
  }
  return D;
}

function computeY(xNew: bigint, D: bigint, An: bigint): bigint {
  const c = (D * D * D) / (xNew * 4n);
  let y = D;
  for (let i = 0; i < 256; i++) {
    const yPrev = y;
    y = (y * y + c) / (y * 2n + D / An - D);
    if (y > yPrev) {
      if (y - yPrev <= 1n) break;
    } else {
      if (yPrev - y <= 1n) break;
    }
  }
  return y;
}

export function concentratedLiquidityQuote(
  amountIn: bigint,
  pool: Pool
): { amountOut: bigint; priceImpact: number } {
  const amountOut = getAmountOut(amountIn, pool.reserve0, pool.reserve1, pool.fee);
  const priceImpact = getPriceImpact(amountIn, amountOut, pool.reserve0, pool.reserve1);
  return { amountOut, priceImpact };
}

export function weightedPoolQuote(
  amountIn: bigint,
  pool: Pool
): { amountOut: bigint; priceImpact: number } {
  const w0 = pool.weight0 ?? 50;
  const w1 = pool.weight1 ?? 50;
  const balanceIn = Number(pool.reserve0);
  const balanceOut = Number(pool.reserve1);
  const amtIn = Number(amountIn);
  if (balanceIn <= 0 || balanceOut <= 0 || amtIn <= 0) {
    return { amountOut: 0n, priceImpact: 0 };
  }
  const feeMultiplier = 1 - pool.fee / 10000;
  const amtInAfterFee = amtIn * feeMultiplier;
  const weightRatio = w1 / w0;
  const base = balanceIn / (balanceIn + amtInAfterFee);
  const amountOut = balanceOut * (1 - Math.pow(base, weightRatio));
  const amountOutBigint = BigInt(Math.floor(amountOut));
  const spotPrice = (balanceOut / balanceIn) * (w0 / w1);
  const execPrice = amountOut / amtIn;
  const priceImpact = spotPrice > 0 ? Math.abs(spotPrice - execPrice) / spotPrice : 0;
  return { amountOut: amountOutBigint, priceImpact };
}

export function quoteSwap(amountIn: bigint, pool: Pool): { amountOut: bigint; priceImpact: number } {
  switch (pool.type) {
    case "stable_swap":
      return stableSwapQuote(amountIn, pool);
    case "concentrated":
      return concentratedLiquidityQuote(amountIn, pool);
    case "weighted":
      return weightedPoolQuote(amountIn, pool);
    case "constant_product":
    default:
      return constantProductQuote(amountIn, pool);
  }
}

export function calculateLiquidityAmounts(
  amount0Desired: bigint,
  amount1Desired: bigint,
  reserve0: bigint,
  reserve1: bigint
): { amount0: bigint; amount1: bigint } {
  if (reserve0 === 0n && reserve1 === 0n) {
    return { amount0: amount0Desired, amount1: amount1Desired };
  }
  const amount1Optimal = (amount0Desired * reserve1) / reserve0;
  if (amount1Optimal <= amount1Desired) {
    return { amount0: amount0Desired, amount1: amount1Optimal };
  }
  const amount0Optimal = (amount1Desired * reserve0) / reserve1;
  return { amount0: amount0Optimal, amount1: amount1Desired };
}

export function calculateLPTokenAmount(
  amount0: bigint,
  amount1: bigint,
  reserve0: bigint,
  reserve1: bigint,
  totalSupply: bigint
): bigint {
  if (totalSupply === 0n) {
    return (sqrt(amount0 * amount1) - MINIMUM_LIQUIDITY);
  }
  const lp0 = (amount0 * totalSupply) / reserve0;
  const lp1 = (amount1 * totalSupply) / reserve1;
  return lp0 < lp1 ? lp0 : lp1;
}

export function calculateRemoveLiquidityAmounts(
  lpAmount: bigint,
  totalSupply: bigint,
  reserve0: bigint,
  reserve1: bigint
): { amount0: bigint; amount1: bigint } {
  const amount0 = (lpAmount * reserve0) / totalSupply;
  const amount1 = (lpAmount * reserve1) / totalSupply;
  return { amount0, amount1 };
}

function sqrt(value: bigint): bigint {
  if (value < 0n) return 0n;
  if (value < 2n) return value;
  let x = value / 2n;
  let y = (x + value / x) / 2n;
  while (y < x) {
    x = y;
    y = (x + value / x) / 2n;
  }
  return x;
}
