export const CHAIN_ID = 42161;

export const RPC_URL = "https://arb1.arbitrum.io/rpc";

export const ZERO_ADDRESS = "0x0000000000000000000000000000000000000000";

export const CONTRACTS = {
  poolFactory: "0x0000000000000000000000000000000000000001" as const,
  swapRouter: "0x0000000000000000000000000000000000000002" as const,
  priceOracle: "0x0000000000000000000000000000000000000003" as const,
  limitOrderBook: "0x0000000000000000000000000000000000000004" as const,
  flashLoan: "0x0000000000000000000000000000000000000005" as const,
};

export const DEFAULT_TOKENS = [
  {
    address: "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE",
    symbol: "ETH",
    name: "Ether",
    decimals: 18,
  },
  {
    address: "0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1",
    symbol: "USDC",
    name: "USD Coin",
    decimals: 6,
  },
  {
    address: "0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9",
    symbol: "USDT",
    name: "Tether USD",
    decimals: 6,
  },
  {
    address: "0x912CE59144191C1204E64559FE8253a0e49E6548",
    symbol: "ARB",
    name: "Arbitrum",
    decimals: 18,
  },
  {
    address: "0xf97f4df75117a78c1A5a0DBb814Af92458539761",
    symbol: "WSTETH",
    name: "Wrapped Liquid Staked Ether 2.0",
    decimals: 18,
  },
  {
    address: "0x2f2a2543B76A4166549F7aaB2e75Bef0aefC5B0f",
    symbol: "WBTC",
    name: "Wrapped BTC",
    decimals: 8,
  },
];

export const FEE_TIERS = [
  { value: 100, label: "0.01%", category: "stable" },
  { value: 500, label: "0.05%", category: "stable" },
  { value: 3000, label: "0.30%", category: "standard" },
  { value: 10000, label: "1.00%", category: "exotic" },
];

export const SLIPPAGE_OPTIONS = [0.1, 0.5, 1.0];
export const DEFAULT_SLIPPAGE = 0.5;
export const DEADLINE_MINUTES = 30;
