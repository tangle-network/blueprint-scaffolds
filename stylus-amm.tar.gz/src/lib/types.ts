export type PoolType = "constant_product" | "stable_swap" | "concentrated" | "weighted";

export interface Token {
  address: string;
  symbol: string;
  name: string;
  decimals: number;
  logoURI?: string;
}

export interface Pool {
  address: string;
  type: PoolType;
  token0: Token;
  token1: Token;
  reserve0: bigint;
  reserve1: bigint;
  fee: number;
  tvl: number;
  volume24h: number;
  feeTier: number;
  weight0?: number;
  weight1?: number;
  ampFactor?: number;
  tickSpacing?: number;
  currentTick?: number;
}

export interface SwapQuote {
  inputAmount: bigint;
  outputAmount: bigint;
  priceImpact: number;
  fee: bigint;
  path: RouteHop[];
  effectivePrice: number;
  minimumReceived: bigint;
}

export interface RouteHop {
  poolAddress: string;
  poolType: PoolType;
  tokenIn: Token;
  tokenOut: Token;
  portion: number;
}

export interface LiquidityPosition {
  id: string;
  pool: Pool;
  lpTokenAmount: bigint;
  token0Amount: bigint;
  token1Amount: bigint;
  sharePercent: number;
  unclaimedFees: bigint;
  tickLower?: number;
  tickUpper?: number;
}

export interface LimitOrder {
  id: string;
  maker: string;
  tokenIn: Token;
  tokenOut: Token;
  amountIn: bigint;
  amountOut: bigint;
  price: number;
  filled: number;
  status: "open" | "partially_filled" | "filled" | "cancelled";
  createdAt: number;
  expiresAt?: number;
}

export interface FlashLoanRequest {
  token: Token;
  amount: bigint;
  fee: bigint;
}

export interface TWAPExecution {
  id: string;
  tokenIn: Token;
  tokenOut: Token;
  totalAmount: bigint;
  executedAmount: bigint;
  remainingAmount: bigint;
  intervals: number;
  completedIntervals: number;
  startTime: number;
  endTime: number;
  status: "pending" | "running" | "completed" | "cancelled";
}

export interface PoolStats {
  address: string;
  tvl: number;
  volume24h: number;
  volume7d: number;
  fee24h: number;
  apr: number;
  txCount24h: number;
}

export interface OraclePrice {
  token: Token;
  price: number;
  timestamp: number;
  confidence: number;
}

export const POOL_TYPE_LABELS: Record<PoolType, string> = {
  constant_product: "Constant Product",
  stable_swap: "Stable Swap",
  concentrated: "Concentrated Liquidity",
  weighted: "Weighted Pool",
};
