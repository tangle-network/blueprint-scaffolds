import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatAddress(address: string): string {
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

export function formatNumber(num: number, decimals = 2): string {
  if (num >= 1_000_000) return `${(num / 1_000_000).toFixed(decimals)}M`;
  if (num >= 1_000) return `${(num / 1_000).toFixed(decimals)}K`;
  return num.toFixed(decimals);
}

export function formatPercent(num: number): string {
  return `${(num * 100).toFixed(2)}%`;
}

export function bigintToDecimal(val: bigint, decimals: number): number {
  const divisor = BigInt(10 ** decimals);
  const whole = val / divisor;
  const frac = val % divisor;
  return Number(whole) + Number(frac) / Number(divisor);
}

export function decimalToBigint(val: number, decimals: number): bigint {
  const multiplier = 10 ** decimals;
  return BigInt(Math.floor(val * multiplier));
}
