export const POOL_FACTORY_ABI = [
  "function createPool(address tokenA, address tokenB, uint8 poolType, uint24 feeBps) external returns (address)",
  "function getPool(address tokenA, address tokenB, uint8 poolType) external view returns (address)",
  "function allPools(uint256 index) external view returns (address)",
  "function allPoolsLength() external view returns (uint256)",
  "event PoolCreated(address indexed pool, address indexed tokenA, address indexed tokenB, uint8 poolType, uint24 feeBps)",
];

export const SWAP_ROUTER_ABI = [
  "function exactInputSingle((address tokenIn, address tokenOut, uint24 feeBps, address recipient, uint256 deadline, uint256 amountIn, uint256 amountOutMinimum, uint160 sqrtPriceLimitX96) params) external payable returns (uint256 amountOut)",
  "function exactInput((bytes path, address recipient, uint256 deadline, uint256 amountIn, uint256 amountOutMinimum) params) external payable returns (uint256 amountOut)",
  "function exactOutput((bytes path, address recipient, uint256 deadline, uint256 amountOut, uint256 amountInMaximum) params) external payable returns (uint256 amountIn)",
  "function multicall(uint256 deadline, bytes[] data) external payable returns (bytes[] results)",
];

export const POOL_ABI = [
  "function swap(uint256 amount0Out, uint256 amount1Out, address to, bytes data) external",
  "function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast)",
  "function token0() external view returns (address)",
  "function token1() external view returns (address)",
  "function feeBps() external view returns (uint24)",
  "function poolType() external view returns (uint8)",
  "function mint(address to) external returns (uint256 liquidity)",
  "function burn(address to) external returns (uint256 amount0, uint256 amount1)",
  "function collect(address recipient) external returns (uint256 amount0, uint256 amount1)",
];

export const ORACLE_ABI = [
  "function consult(address pool, uint256 period) external view returns (uint256 priceCumulative, uint256 elapsed)",
  "function update(address pool) external",
  "function getTimeWeightedAveragePrice(address pool, uint256 period) external view returns (uint256)",
  "function lastObservation(address pool) external view returns (uint256 timestamp, uint256 price)",
];

export const FLASH_LOAN_ABI = [
  "function flashLoan(address token, uint256 amount, bytes callbackData) external",
  "function flashLoanMulti(address[] tokens, uint256[] amounts, bytes callbackData) external",
];

export const LIMIT_ORDER_ABI = [
  "function createOrder(address tokenIn, address tokenOut, uint256 amountIn, uint256 minAmountOut, uint256 deadline) external returns (uint256 orderId)",
  "function cancelOrder(uint256 orderId) external",
  "function executeOrder(uint256 orderId) external",
  "function getOrder(uint256 orderId) external view returns (tuple(address owner, address tokenIn, address tokenOut, uint256 amountIn, uint256 minAmountOut, uint256 deadline, bool executed, bool cancelled))",
];

export const TWAP_ABI = [
  "function createTWAP(address tokenIn, address tokenOut, uint256 totalAmountIn, uint256 startTime, uint256 endTime, uint16 numIntervals) external returns (uint256 twapId)",
  "function cancelTWAP(uint256 twapId) external",
  "function executeTWAPSlice(uint256 twapId) external",
  "function getTWAP(uint256 twapId) external view returns (tuple(address owner, address tokenIn, address tokenOut, uint256 totalAmountIn, uint256 totalAmountOut, uint256 executedAmountIn, uint256 executedAmountOut, uint256 startTime, uint256 endTime, uint16 numIntervals, uint16 completedIntervals, bool isActive))",
];

export const ERC20_ABI = [
  "function name() external view returns (string)",
  "function symbol() external view returns (string)",
  "function decimals() external view returns (uint8)",
  "function totalSupply() external view returns (uint256)",
  "function balanceOf(address account) external view returns (uint256)",
  "function transfer(address to, uint256 amount) external returns (bool)",
  "function allowance(address owner, address spender) external returns (uint256)",
  "function approve(address spender, uint256 amount) external returns (bool)",
];

export const CONTRACTS = {
  poolFactory: "0x0000000000000000000000000000000000000001" as const,
  swapRouter: "0x0000000000000000000000000000000000000002" as const,
  oracle: "0x0000000000000000000000000000000000000003" as const,
  flashLoan: "0x0000000000000000000000000000000000000004" as const,
  limitOrders: "0x0000000000000000000000000000000000000005" as const,
  twap: "0x0000000000000000000000000000000000000006" as const,
};
