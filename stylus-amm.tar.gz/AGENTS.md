# StylusDEX - Arbitrum Stylus AMM DEX

## Architecture

### Smart Contracts (Rust/Stylus)
- `contracts/pool-factory/` - Factory contract for creating pools
- `contracts/swap-router/` - Router for multi-hop swaps and limit orders
- `contracts/price-oracle/` - TWAP oracle for price feeds

### Pool Types
1. Constant Product (x*y=k) - Standard Uniswap V2 style
2. Stable Swap - Curve-style for correlated assets
3. Concentrated Liquidity - Uniswap V3 style with tick ranges
4. Weighted Pools - Balancer-style with custom weights

### Frontend (Vite + React)
- Swap interface with route preview
- Liquidity management (add/remove)
- Pool explorer with stats
- Limit order book
- Flash loan interface
- TWAP execution panel

## Pages
- `/` - Swap page (default)
- `/liquidity` - Add/remove liquidity
- `/pools` - Pool explorer
- `/limit-orders` - Limit order management
- `/flash-loans` - Flash loan interface

## Components
- `src/components/ui/` - shadcn/ui primitives
- `src/components/swap/` - Swap interface components
- `src/components/liquidity/` - Liquidity management
- `src/components/layout/` - App shell (navbar, sidebar, footer)

## API/Contracts
- `src/lib/contracts/` - ABI definitions and contract interfaces
- `src/lib/pool-math.ts` - AMM math (constant product, stable, concentrated, weighted)
- `src/lib/router.ts` - Multi-hop pathfinding
- `src/hooks/` - React hooks for wallet, pools, swaps, oracle

## Build
```bash
pnpm install && pnpm build
```
