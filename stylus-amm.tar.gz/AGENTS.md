# AGENTS.md

## Goal

Build a high-performance AMM DEX using Arbitrum Stylus (Rust) for 10-100x gas savings. Constant-product AMM, liquidity provision, swap routing.

## Stack

- Family: `stylus-contracts`
- Layers: 
- Partner: `arbitrum`

## Entry Points

- `src/lib.rs`
- `Cargo.toml`
- `stylus.json`

## Commands

- `cargo test`
- `cargo check`

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
