import type {
  BuilderAction,
  ContractModule,
  PendingTransaction,
  Signer,
  TimelineEvent,
  TransferPolicy,
  TreasuryStats
} from "./types";

export const treasuryStats: TreasuryStats = {
  totalValue: "$18.4M",
  monthlyVolume: "$6.2M",
  activeVaults: 14,
  queuedTransactions: 9
};

export const policies: TransferPolicy[] = [
  {
    label: "Ops wallet",
    threshold: "2 of 4",
    delay: "0 min",
    scope: "Payroll, vendors, subscriptions"
  },
  {
    label: "Core treasury",
    threshold: "4 of 7",
    delay: "12 hrs",
    scope: "Stablecoin reserves, ETH strategy"
  },
  {
    label: "Protocol upgrades",
    threshold: "5 of 8",
    delay: "48 hrs",
    scope: "Arbitrary contract calls, upgrade payloads"
  }
];

export const pendingTransactions: PendingTransaction[] = [
  {
    id: "TX-1042",
    title: "Distribute ETH grants",
    kind: "ETH",
    destination: "0x91A7...3F2d",
    amount: "142 ETH",
    createdAt: "8 min ago",
    eta: "Ready now",
    confirmations: 3,
    required: 5,
    proposer: "Ops Council",
    risk: "Medium"
  },
  {
    id: "TX-1043",
    title: "Transfer 500k USDC to market maker",
    kind: "ERC-20",
    destination: "0x55d2...Ac91",
    amount: "500,000 USDC",
    createdAt: "21 min ago",
    eta: "11h 39m remaining",
    confirmations: 4,
    required: 4,
    proposer: "Treasury Lead",
    risk: "Low"
  },
  {
    id: "TX-1044",
    title: "Move NFT collateral to cold vault",
    kind: "NFT",
    destination: "0x6B2E...1120",
    amount: "8 NFTs",
    createdAt: "1 hr ago",
    eta: "47h 05m remaining",
    confirmations: 5,
    required: 6,
    proposer: "Risk Committee",
    risk: "High"
  }
];

export const signers: Signer[] = [
  {
    name: "Mina R.",
    address: "0x8c44...1a91",
    role: "Treasury Admin",
    permissions: ["Manage signers", "Execute transfers", "Configure policy"],
    dailyLimit: "$250k",
    status: "Active"
  },
  {
    name: "Jordan L.",
    address: "0xb083...cf10",
    role: "Protocol Signer",
    permissions: ["Execute transfers", "Configure policy"],
    dailyLimit: "$1M",
    status: "Active"
  },
  {
    name: "Avery T.",
    address: "0x34ad...91f0",
    role: "Recovery Guardian",
    permissions: ["Emergency recovery"],
    dailyLimit: "N/A",
    status: "Recovery guardian"
  },
  {
    name: "Sam P.",
    address: "0xd921...0c22",
    role: "Operations",
    permissions: ["Execute transfers"],
    dailyLimit: "$75k",
    status: "Pending rotation"
  }
];

export const timeline: TimelineEvent[] = [
  {
    time: "09:40 UTC",
    title: "Recovery module armed",
    description: "Guardian quorum enabled with 72 hour social recovery period.",
    status: "Recovered"
  },
  {
    time: "08:15 UTC",
    title: "USDC rebalance queued",
    description: "Policy engine applied 12 hour delay due to transfer size.",
    status: "Queued"
  },
  {
    time: "Yesterday",
    title: "Arbitrum bridge execution",
    description: "4 of 4 required signatures collected and executed.",
    status: "Executed"
  },
  {
    time: "Yesterday",
    title: "Signer removal blocked",
    description: "Attempt rejected because role minimum would have been violated.",
    status: "Rejected"
  }
];

export const modules: ContractModule[] = [
  {
    name: "Wallet Factory",
    summary: "Deploys deterministic treasury vaults with signer and policy presets.",
    capabilities: ["CREATE2 deployment", "Module registration", "Owner bootstrap"]
  },
  {
    name: "MultiSig Wallet",
    summary: "Manages proposals, signatures, execution, and arbitrary call batching.",
    capabilities: ["M-of-N approvals", "ETH/ERC-20/NFT moves", "Contract execution"]
  },
  {
    name: "Policy Engine",
    summary: "Applies timelocks, spending ceilings, and permission gates per action.",
    capabilities: ["Delay windows", "Daily spend limits", "Role enforcement"]
  },
  {
    name: "Recovery Module",
    summary: "Supports guardian-led recovery and signer rotation with cooldowns.",
    capabilities: ["Guardian quorum", "Recovery delay", "Signer replacement"]
  }
];

export const builderActions: BuilderAction[] = [
  {
    name: "ETH transfer",
    description: "Send native ETH from the treasury to any beneficiary.",
    defaultDelay: "Instant under ops policy"
  },
  {
    name: "ERC-20 payout",
    description: "Move stablecoins or governance tokens with limit-aware approvals.",
    defaultDelay: "12 hours above $250k"
  },
  {
    name: "NFT custody move",
    description: "Transfer ERC-721 or ERC-1155 assets to another vault or delegate.",
    defaultDelay: "48 hours"
  },
  {
    name: "Contract interaction",
    description: "Encode arbitrary calldata for protocol actions and upgrades.",
    defaultDelay: "48 hours and elevated quorum"
  }
];
