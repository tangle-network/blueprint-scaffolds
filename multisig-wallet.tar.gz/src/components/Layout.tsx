import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { useWallet } from "@/lib/store";
import { formatAddress } from "@/lib/helpers";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  ArrowLeftRight,
  PenTool,
  History,
  Settings,
  Wallet,
  Shield,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip";

const navItems = [
  { to: "/", icon: LayoutDashboard, label: "Dashboard" },
  { to: "/transactions/new", icon: ArrowLeftRight, label: "New Transaction" },
  { to: "/signatures", icon: PenTool, label: "Signatures" },
  { to: "/history", icon: History, label: "History" },
  { to: "/settings", icon: Settings, label: "Settings" },
];

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();
  const { wallet, isConnected, connect, disconnect } = useWallet();

  return (
    <TooltipProvider delayDuration={0}>
      <aside
        className={cn(
          "flex flex-col h-screen bg-card border-r transition-all duration-300",
          collapsed ? "w-16" : "w-64"
        )}
      >
        <div className="flex items-center gap-2 p-4 h-16">
          <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-primary">
            <Shield className="h-5 w-5 text-primary-foreground" />
          </div>
          {!collapsed && (
            <div className="flex flex-col">
              <span className="font-bold text-sm">MultiSig Wallet</span>
              <span className="text-xs text-muted-foreground">{formatAddress(wallet.address)}</span>
            </div>
          )}
        </div>

        <Separator />

        <nav className="flex-1 py-2">
          {navItems.map((item) => {
            const isActive = location.pathname === item.to;
            const link = (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex items-center gap-3 mx-2 px-3 py-2 rounded-md text-sm transition-colors",
                  isActive
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                )}
              >
                <item.icon className="h-5 w-5 shrink-0" />
                {!collapsed && <span>{item.label}</span>}
              </Link>
            );

            if (collapsed) {
              return (
                <Tooltip key={item.to}>
                  <TooltipTrigger asChild>{link}</TooltipTrigger>
                  <TooltipContent side="right">{item.label}</TooltipContent>
                </Tooltip>
              );
            }
            return link;
          })}
        </nav>

        <Separator />

        <div className="p-3">
          {!collapsed && (
            <div className="flex items-center gap-2 mb-3 p-2 rounded-md bg-muted">
              <Wallet className="h-4 w-4 text-muted-foreground shrink-0" />
              <div className="flex flex-col min-w-0">
                <span className="text-xs font-medium truncate">{wallet.name}</span>
                <span className="text-xs text-muted-foreground truncate">{wallet.policy.requiredSignatures}-of-{wallet.policy.totalSigners}</span>
              </div>
            </div>
          )}
          <Button
            variant={isConnected ? "outline" : "default"}
            size={collapsed ? "icon" : "default"}
            className="w-full"
            onClick={isConnected ? disconnect : connect}
          >
            {isConnected ? (collapsed ? "Lock" : "Disconnect") : (collapsed ? "Conn" : "Connect Wallet")}
          </Button>
        </div>

        <div className="p-2 border-t">
          <Button
            variant="ghost"
            size="icon"
            className="w-full"
            onClick={() => setCollapsed(!collapsed)}
          >
            {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </Button>
        </div>
      </aside>
    </TooltipProvider>
  );
}

export function Header({ title, description }: { title: string; description?: string }) {
  const { wallet } = useWallet();
  return (
    <header className="flex items-center justify-between h-16 px-6 border-b bg-background">
      <div>
        <h1 className="text-xl font-semibold">{title}</h1>
        {description && <p className="text-sm text-muted-foreground">{description}</p>}
      </div>
      <div className="flex items-center gap-3">
        <span className="text-sm text-muted-foreground">
          Balance: <span className="font-medium text-foreground">{wallet.balance} ETH</span>
        </span>
        <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
          <span className="text-xs font-bold text-primary-foreground">
            {wallet.signers[0]?.name.charAt(0) || "U"}
          </span>
        </div>
      </div>
    </header>
  );
}

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <main className="flex-1 overflow-auto">{children}</main>
    </div>
  );
}
