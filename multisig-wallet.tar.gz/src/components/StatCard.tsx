import type { ReactNode } from "react";

interface StatCardProps {
  label: string;
  value: string | number;
  detail: string;
  icon: ReactNode;
}

export function StatCard({ label, value, detail, icon }: StatCardProps) {
  return (
    <article className="panel stat-card">
      <div className="stat-card__header">
        <span>{label}</span>
        <span className="stat-card__icon">{icon}</span>
      </div>
      <strong>{value}</strong>
      <p>{detail}</p>
    </article>
  );
}
