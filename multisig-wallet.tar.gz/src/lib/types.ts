export type WalletRole = "owner" | "admin" | "signer" | "viewer";

export type TransactionType = "eth_transfer" | "erc20_transfer" | "nft_transfer" | "contract_interaction";

export type TransactionStatus = "pending" | "awaiting_signatures" | "time_locked" | "executed" | "failed" | "cancelled";

export type TimeLockStatus = "none" | "locked" | "unlocked";

export interface Signer {
  address: string;
  name: string;
  role: WalletRole;
  joinedAt: number;
  isActive: boolean;
}

export interface Transaction {
  id: string;
  type: TransactionType;
  status: TransactionStatus;
  to: string;
  value: string;
  tokenAddress?: string;
  tokenId?: string;
  data?: string;
  description: string;
  createdBy: string;
  createdAt: number;
  executeAfter: number | null;
  executedAt: number | null;
  executedBy: string | null;
  signatures: Signature[];
  requiredSignatures: number;
  nonce: number;
  spendingLimitCategory?: string;
}

export interface Signature {
  signer: string;
  signedAt: number;
  approved: boolean;
}

export interface SpendingLimit {
  id: string;
  category: string;
  limitWei: string;
  periodSeconds: number;
  spentWei: string;
  periodStart: number;
  isActive: boolean;
  requiresApprovalAbove: string;
}

export interface WalletPolicy {
  id: string;
  walletAddress: string;
  name: string;
  requiredSignatures: number;
  totalSigners: number;
  timeLockSeconds: number;
  spendingLimits: SpendingLimit[];
  maxDailySpend: string;
  maxTransactionSize: string;
  allowContractInteraction: boolean;
  allowNFTTransfer: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface WalletInfo {
  address: string;
  name: string;
  description: string;
  balance: string;
  tokenBalances: TokenBalance[];
  signers: Signer[];
  policy: WalletPolicy;
  createdAt: number;
  transactionCount: number;
  pendingTransactionCount: number;
}

export interface TokenBalance {
  symbol: string;
  name: string;
  address: string;
  balance: string;
  decimals: number;
  icon?: string;
}

export interface WalletFormData {
  name: string;
  description: string;
  signers: string[];
  requiredSignatures: number;
  timeLockSeconds: number;
  maxDailySpend: string;
  maxTransactionSize: string;
}

export interface TransactionFormData {
  type: TransactionType;
  to: string;
  value: string;
  tokenAddress?: string;
  tokenId?: string;
  data?: string;
  description: string;
  timeLockSeconds: number;
}
