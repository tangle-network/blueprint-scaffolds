export const MULTISIG_WALLET_ABI = [
  "function submitTransaction(address to, uint256 value, bytes data) returns (uint256)",
  "function confirmTransaction(uint256 txId)",
  "function revokeConfirmation(uint256 txId)",
  "function executeTransaction(uint256 txId)",
  "function cancelTransaction(uint256 txId)",
  "function addSigner(address signer, string name, uint8 role)",
  "function removeSigner(address signer)",
  "function replaceSigner(address oldSigner, address newSigner)",
  "function updatePolicy(uint256 requiredConfirmations, uint256 timeLockSeconds, uint256 maxDailySpend, uint256 maxTxSize)",
  "function addSpendingLimit(string category, uint256 limit, uint256 period, uint256 threshold)",
  "function removeSpendingLimit(uint256 limitId)",
  "function getTransactionCount() view returns (uint256)",
  "function getTransaction(uint256 txId) view returns (tuple(address to, uint256 value, bytes data, bool executed, uint256 numConfirmations))",
  "function getSigners() view returns (tuple(address addr, string name, uint8 role, bool isActive)[])",
  "function getPolicy() view returns (tuple(uint256 required, uint256 total, uint256 timelock, uint256 dailyLimit, uint256 txLimit))",
  "function isConfirmed(uint256 txId, address signer) view returns (bool)",
  "function isSigner(address account) view returns (bool)",
  "function getSpentToday() view returns (uint256)",
  "event Submission(uint256 indexed txId)",
  "event Confirmation(uint256 indexed txId, address indexed signer)",
  "event Revocation(uint256 indexed txId, address indexed signer)",
  "event Execution(uint256 indexed txId)",
  "event ExecutionFailure(uint256 indexed txId)",
  "event Cancellation(uint256 indexed txId)",
  "event SignerAddition(address indexed signer)",
  "event SignerRemoval(address indexed signer)",
  "event PolicyUpdate(uint256 required, uint256 timelock)",
];

export const WALLET_FACTORY_ABI = [
  "function createWallet(string name, address[] signers, uint256 requiredConfirmations, uint256 timelock, uint256 maxDailySpend, uint256 maxTxSize) returns (address)",
  "function getWallets(address owner) view returns (address[])",
  "function walletCount() view returns (uint256)",
  "event WalletCreated(address indexed wallet, address indexed creator, string name)",
];

export const ERC20_ABI = [
  "function transfer(address to, uint256 amount) returns (bool)",
  "function balanceOf(address account) view returns (uint256)",
  "function decimals() view returns (uint8)",
  "function symbol() view returns (string)",
  "function name() view returns (string)",
  "function allowance(address owner, address spender) view returns (uint256)",
  "function approve(address spender, uint256 amount) returns (bool)",
];

export const ERC721_ABI = [
  "function transferFrom(address from, address to, uint256 tokenId)",
  "function safeTransferFrom(address from, address to, uint256 tokenId)",
  "function ownerOf(uint256 tokenId) view returns (address)",
  "function balanceOf(address owner) view returns (uint256)",
  "function tokenURI(uint256 tokenId) view returns (string)",
];

export const MULTISIG_WALLET_BYTECODE = "0x608060405234801561001057600080fd5b50";
export const WALLET_FACTORY_BYTECODE = "0x608060405234801561001057600080fd5b50";
