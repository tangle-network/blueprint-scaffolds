import {
  createContext,
  useContext,
  useState,
  useCallback,
  type ReactNode,
} from "react";
import type {
  WalletInfo,
  Transaction,
  Signer,
  WalletPolicy,
  SpendingLimit,
  TransactionFormData,
  WalletFormData,
  TransactionStatus,
  Signature,
} from "./types";

const NOW = Date.now();

const mockSigners: Signer[] = [
  { address: "0x1234567890abcdef1234567890abcdef12345678", name: "Alice (You)", role: "owner", joinedAt: NOW - 86400000 * 30, isActive: true },
  { address: "0xabcdef1234567890abcdef1234567890abcdef12", name: "Bob", role: "admin", joinedAt: NOW - 86400000 * 28, isActive: true },
  { address: "0x9876543210fedcba9876543210fedcba98765432", name: "Charlie", role: "signer", joinedAt: NOW - 86400000 * 20, isActive: true },
  { address: "0xdeadbeefdeadbeefdeadbeefdeadbeefdeadbeef", name: "Diana", role: "signer", joinedAt: NOW - 86400000 * 15, isActive: true },
  { address: "0xcafecafecafecafecafecafecafecafecafecafe", name: "Eve", role: "viewer", joinedAt: NOW - 86400000 * 10, isActive: true },
];

const mockSpendingLimits: SpendingLimit[] = [
  { id: "sl-1", category: "General", limitWei: "5000000000000000000", periodSeconds: 86400, spentWei: "1200000000000000000", periodStart: NOW - 43200000, isActive: true, requiresApprovalAbove: "1000000000000000000" },
  { id: "sl-2", category: "Infrastructure", limitWei: "10000000000000000000", periodSeconds: 604800, spentWei: "3500000000000000000", periodStart: NOW - 259200000, isActive: true, requiresApprovalAbove: "2000000000000000000" },
  { id: "sl-3", category: "Marketing", limitWei: "20000000000000000000", periodSeconds: 2592000, spentWei: "8000000000000000000", periodStart: NOW - 1296000000, isActive: true, requiresApprovalAbove: "5000000000000000000" },
];

const mockPolicy: WalletPolicy = {
  id: "pol-1",
  walletAddress: "0x742d35Cc6634C0532925a3b844Bc9e7595f2bD28",
  name: "Team Treasury Policy",
  requiredSignatures: 3,
  totalSigners: 5,
  timeLockSeconds: 86400,
  spendingLimits: mockSpendingLimits,
  maxDailySpend: "10000000000000000000",
  maxTransactionSize: "5000000000000000000",
  allowContractInteraction: true,
  allowNFTTransfer: true,
  createdAt: NOW - 86400000 * 30,
  updatedAt: NOW - 86400000 * 2,
};

const mockTransactions: Transaction[] = [
  {
    id: "tx-1",
    type: "eth_transfer",
    status: "awaiting_signatures",
    to: "0x9876543210fedcba9876543210fedcba98765432",
    value: "2500000000000000000",
    description: "Pay infrastructure provider for Q4 servers",
    createdBy: mockSigners[0].address,
    createdAt: NOW - 3600000,
    executeAfter: NOW + 82800000,
    executedAt: null,
    executedBy: null,
    signatures: [
      { signer: mockSigners[0].address, signedAt: NOW - 3500000, approved: true },
      { signer: mockSigners[1].address, signedAt: NOW - 3000000, approved: true },
    ],
    requiredSignatures: 3,
    nonce: 42,
    spendingLimitCategory: "Infrastructure",
  },
  {
    id: "tx-2",
    type: "erc20_transfer",
    status: "time_locked",
    to: "0xabcdef1234567890abcdef1234567890abcdef12",
    value: "1000000000",
    tokenAddress: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
    description: "USDC payment for marketing services",
    createdBy: mockSigners[1].address,
    createdAt: NOW - 7200000,
    executeAfter: NOW + 79200000,
    executedAt: null,
    executedBy: null,
    signatures: [
      { signer: mockSigners[0].address, signedAt: NOW - 7000000, approved: true },
      { signer: mockSigners[1].address, signedAt: NOW - 6800000, approved: true },
      { signer: mockSigners[2].address, signedAt: NOW - 6500000, approved: true },
    ],
    requiredSignatures: 3,
    nonce: 43,
    spendingLimitCategory: "Marketing",
  },
  {
    id: "tx-3",
    type: "contract_interaction",
    status: "pending",
    to: "0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D",
    value: "0",
    data: "0x38ed1739000000000000000000000000000000000000000000000000000b5e620e5ff800000000000000000000000000000000000000000000000422ca8b0a00a4250000000000000000000000000000000000000000000000000000000000000000000a0",
    description: "Swap 0.5 ETH for USDC on Uniswap",
    createdBy: mockSigners[2].address,
    createdAt: NOW - 1800000,
    executeAfter: null,
    executedAt: null,
    executedBy: null,
    signatures: [
      { signer: mockSigners[2].address, signedAt: NOW - 1700000, approved: true },
    ],
    requiredSignatures: 3,
    nonce: 44,
  },
  {
    id: "tx-4",
    type: "nft_transfer",
    status: "executed",
    to: "0xdeadbeefdeadbeefdeadbeefdeadbeefdeadbeef",
    value: "0",
    tokenAddress: "0xBC4CA029A1e65936a90E3f02ee0E20c402Be2E42",
    tokenId: "1234",
    description: "Transfer BAYC #1234 to partner wallet",
    createdBy: mockSigners[0].address,
    createdAt: NOW - 86400000 * 3,
    executeAfter: NOW - 86400000 * 2,
    executedAt: NOW - 86400000 * 2 + 3600000,
    executedBy: mockSigners[1].address,
    signatures: [
      { signer: mockSigners[0].address, signedAt: NOW - 86400000 * 3 + 1000, approved: true },
      { signer: mockSigners[1].address, signedAt: NOW - 86400000 * 3 + 2000, approved: true },
      { signer: mockSigners[2].address, signedAt: NOW - 86400000 * 3 + 3000, approved: true },
    ],
    requiredSignatures: 3,
    nonce: 40,
  },
  {
    id: "tx-5",
    type: "eth_transfer",
    status: "executed",
    to: "0xcafecafecafecafecafecafecafecafecafecafe",
    value: "1500000000000000000",
    description: "Monthly contributor payment",
    createdBy: mockSigners[1].address,
    createdAt: NOW - 86400000 * 7,
    executeAfter: NOW - 86400000 * 6,
    executedAt: NOW - 86400000 * 6 + 7200000,
    executedBy: mockSigners[0].address,
    signatures: [
      { signer: mockSigners[1].address, signedAt: NOW - 86400000 * 7 + 1000, approved: true },
      { signer: mockSigners[0].address, signedAt: NOW - 86400000 * 7 + 2000, approved: true },
      { signer: mockSigners[3].address, signedAt: NOW - 86400000 * 7 + 3000, approved: true },
      { signer: mockSigners[2].address, signedAt: NOW - 86400000 * 7 + 4000, approved: true },
    ],
    requiredSignatures: 3,
    nonce: 38,
    spendingLimitCategory: "General",
  },
  {
    id: "tx-6",
    type: "eth_transfer",
    status: "failed",
    to: "0x1111111111111111111111111111111111111111",
    value: "10000000000000000000",
    description: "Large transfer that exceeded daily limit",
    createdBy: mockSigners[2].address,
    createdAt: NOW - 86400000 * 5,
    executeAfter: null,
    executedAt: NOW - 86400000 * 5 + 86400000,
    executedBy: null,
    signatures: [
      { signer: mockSigners[2].address, signedAt: NOW - 86400000 * 5 + 1000, approved: true },
      { signer: mockSigners[0].address, signedAt: NOW - 86400000 * 5 + 2000, approved: true },
      { signer: mockSigners[1].address, signedAt: NOW - 86400000 * 5 + 3000, approved: true },
    ],
    requiredSignatures: 3,
    nonce: 39,
  },
  {
    id: "tx-7",
    type: "erc20_transfer",
    status: "cancelled",
    to: "0x2222222222222222222222222222222222222222",
    value: "5000000000",
    tokenAddress: "0x6B175474E89094C44Da98b954EedeAC495271d0F",
    description: "DAI payment - cancelled by proposer",
    createdBy: mockSigners[3].address,
    createdAt: NOW - 86400000 * 4,
    executeAfter: null,
    executedAt: null,
    executedBy: null,
    signatures: [
      { signer: mockSigners[3].address, signedAt: NOW - 86400000 * 4 + 1000, approved: true },
    ],
    requiredSignatures: 3,
    nonce: 41,
  },
];

const mockWallet: WalletInfo = {
  address: "0x742d35Cc6634C0532925a3b844Bc9e7595f2bD28",
  name: "Team Treasury",
  description: "Main multi-sig wallet for the DAO treasury",
  balance: "47.8523",
  tokenBalances: [
    { symbol: "ETH", name: "Ether", address: "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE", balance: "47.8523", decimals: 18 },
    { symbol: "USDC", name: "USD Coin", address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48", balance: "125,430.50", decimals: 6 },
    { symbol: "USDT", name: "Tether USD", address: "0xdAC17F958D2ee523a2206206994597C13D831ec7", balance: "50,000.00", decimals: 6 },
    { symbol: "DAI", name: "Dai Stablecoin", address: "0x6B175474E89094C44Da98b954EedeAC495271d0F", balance: "32,150.75", decimals: 18 },
    { symbol: "WETH", name: "Wrapped Ether", address: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2", balance: "12.5000", decimals: 18 },
  ],
  signers: mockSigners,
  policy: mockPolicy,
  createdAt: NOW - 86400000 * 30,
  transactionCount: 156,
  pendingTransactionCount: 3,
};

interface WalletState {
  wallet: WalletInfo;
  transactions: Transaction[];
  currentAddress: string;
  isConnected: boolean;
}

interface WalletActions {
  createTransaction: (data: TransactionFormData) => void;
  signTransaction: (txId: string) => void;
  executeTransaction: (txId: string) => void;
  cancelTransaction: (txId: string) => void;
  addSigner: (address: string, name: string, role: Signer["role"]) => void;
  removeSigner: (address: string) => void;
  updatePolicy: (policy: Partial<WalletPolicy>) => void;
  addSpendingLimit: (limit: SpendingLimit) => void;
  removeSpendingLimit: (limitId: string) => void;
  connect: () => void;
  disconnect: () => void;
  createWallet: (data: WalletFormData) => void;
  getTransactionsByStatus: (status: TransactionStatus) => Transaction[];
  getPendingTransactions: () => Transaction[];
}

type WalletContextType = WalletState & WalletActions;

const WalletContext = createContext<WalletContextType | null>(null);

export function WalletProvider({ children }: { children: ReactNode }) {
  const [wallet, setWallet] = useState<WalletInfo>(mockWallet);
  const [transactions, setTransactions] = useState<Transaction[]>(mockTransactions);
  const [isConnected, setIsConnected] = useState(false);

  const connect = useCallback(() => setIsConnected(true), []);
  const disconnect = useCallback(() => setIsConnected(false), []);

  const createTransaction = useCallback((data: TransactionFormData) => {
    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      type: data.type,
      status: "pending",
      to: data.to,
      value: data.value,
      tokenAddress: data.tokenAddress,
      tokenId: data.tokenId,
      data: data.data,
      description: data.description,
      createdBy: mockSigners[0].address,
      createdAt: Date.now(),
      executeAfter: data.timeLockSeconds > 0 ? Date.now() + data.timeLockSeconds * 1000 : null,
      executedAt: null,
      executedBy: null,
      signatures: [{ signer: mockSigners[0].address, signedAt: Date.now(), approved: true }],
      requiredSignatures: wallet.policy.requiredSignatures,
      nonce: wallet.transactionCount + 1,
    };
    setTransactions((prev) => [newTx, ...prev]);
    setWallet((prev) => ({
      ...prev,
      transactionCount: prev.transactionCount + 1,
      pendingTransactionCount: prev.pendingTransactionCount + 1,
    }));
  }, [wallet.policy.requiredSignatures, wallet.transactionCount]);

  const signTransaction = useCallback((txId: string) => {
    setTransactions((prev) =>
      prev.map((tx) => {
        if (tx.id !== txId) return tx;
        const newSig: Signature = {
          signer: mockSigners[0].address,
          signedAt: Date.now(),
          approved: true,
        };
        const sigs = [...tx.signatures, newSig];
        const hasAllSigs = sigs.length >= tx.requiredSignatures;
        return {
          ...tx,
          signatures: sigs,
          status: hasAllSigs ? "awaiting_signatures" : tx.status === "pending" ? "awaiting_signatures" : tx.status,
        };
      })
    );
  }, []);

  const executeTransaction = useCallback((txId: string) => {
    setTransactions((prev) =>
      prev.map((tx) =>
        tx.id === txId
          ? { ...tx, status: "executed" as const, executedAt: Date.now(), executedBy: mockSigners[0].address }
          : tx
      )
    );
    setWallet((prev) => ({
      ...prev,
      pendingTransactionCount: Math.max(0, prev.pendingTransactionCount - 1),
    }));
  }, []);

  const cancelTransaction = useCallback((txId: string) => {
    setTransactions((prev) =>
      prev.map((tx) =>
        tx.id === txId ? { ...tx, status: "cancelled" as const } : tx
      )
    );
    setWallet((prev) => ({
      ...prev,
      pendingTransactionCount: Math.max(0, prev.pendingTransactionCount - 1),
    }));
  }, []);

  const addSigner = useCallback((address: string, name: string, role: Signer["role"]) => {
    const newSigner: Signer = {
      address,
      name,
      role,
      joinedAt: Date.now(),
      isActive: true,
    };
    setWallet((prev) => ({
      ...prev,
      signers: [...prev.signers, newSigner],
      policy: { ...prev.policy, totalSigners: prev.policy.totalSigners + 1 },
    }));
  }, []);

  const removeSigner = useCallback((address: string) => {
    setWallet((prev) => ({
      ...prev,
      signers: prev.signers.filter((s) => s.address !== address),
      policy: { ...prev.policy, totalSigners: Math.max(1, prev.policy.totalSigners - 1) },
    }));
  }, []);

  const updatePolicy = useCallback((updates: Partial<WalletPolicy>) => {
    setWallet((prev) => ({
      ...prev,
      policy: { ...prev.policy, ...updates, updatedAt: Date.now() },
    }));
  }, []);

  const addSpendingLimit = useCallback((limit: SpendingLimit) => {
    setWallet((prev) => ({
      ...prev,
      policy: {
        ...prev.policy,
        spendingLimits: [...prev.policy.spendingLimits, limit],
      },
    }));
  }, []);

  const removeSpendingLimit = useCallback((limitId: string) => {
    setWallet((prev) => ({
      ...prev,
      policy: {
        ...prev.policy,
        spendingLimits: prev.policy.spendingLimits.filter((l) => l.id !== limitId),
      },
    }));
  }, []);

  const createWallet = useCallback((data: WalletFormData) => {
    const newWallet: WalletInfo = {
      ...mockWallet,
      name: data.name,
      description: data.description,
      address: `0x${Math.random().toString(16).slice(2, 42).padEnd(40, "0")}`,
      signers: data.signers.map((addr, i) => ({
        address: addr,
        name: i === 0 ? "You (Owner)" : `Signer ${i + 1}`,
        role: i === 0 ? "owner" as const : "signer" as const,
        joinedAt: Date.now(),
        isActive: true,
      })),
      policy: {
        ...mockPolicy,
        requiredSignatures: data.requiredSignatures,
        timeLockSeconds: data.timeLockSeconds,
        maxDailySpend: data.maxDailySpend,
        maxTransactionSize: data.maxTransactionSize,
      },
      transactionCount: 0,
      pendingTransactionCount: 0,
      createdAt: Date.now(),
    };
    setWallet(newWallet);
    setTransactions([]);
  }, []);

  const getTransactionsByStatus = useCallback(
    (status: TransactionStatus) => transactions.filter((tx) => tx.status === status),
    [transactions]
  );

  const getPendingTransactions = useCallback(
    () => transactions.filter((tx) => ["pending", "awaiting_signatures", "time_locked"].includes(tx.status)),
    [transactions]
  );

  return (
    <WalletContext.Provider
      value={{
        wallet,
        transactions,
        currentAddress: mockSigners[0].address,
        isConnected,
        connect,
        disconnect,
        createTransaction,
        signTransaction,
        executeTransaction,
        cancelTransaction,
        addSigner,
        removeSigner,
        updatePolicy,
        addSpendingLimit,
        removeSpendingLimit,
        createWallet,
        getTransactionsByStatus,
        getPendingTransactions,
      }}
    >
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  const ctx = useContext(WalletContext);
  if (!ctx) throw new Error("useWallet must be used within WalletProvider");
  return ctx;
}
