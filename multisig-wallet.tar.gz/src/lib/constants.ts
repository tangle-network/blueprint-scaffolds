export const ETH_ADDRESS = "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE";

export const SUPPORTED_TOKENS = [
  { symbol: "ETH", name: "Ether", address: ETH_ADDRESS, decimals: 18 },
  { symbol: "USDC", name: "USD Coin", address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48", decimals: 6 },
  { symbol: "USDT", name: "Tether USD", address: "0xdAC17F958D2ee523a2206206994597C13D831ec7", decimals: 6 },
  { symbol: "DAI", name: "Dai Stablecoin", address: "0x6B175474E89094C44Da98b954EedeAC495271d0F", decimals: 18 },
  { symbol: "WETH", name: "Wrapped Ether", address: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2", decimals: 18 },
];

export const TIMELOCK_OPTIONS = [
  { label: "No time lock", value: 0 },
  { label: "1 hour", value: 3600 },
  { label: "6 hours", value: 21600 },
  { label: "12 hours", value: 43200 },
  { label: "24 hours", value: 86400 },
  { label: "48 hours", value: 172800 },
  { label: "7 days", value: 604800 },
];

export const ROLE_LABELS: Record<string, string> = {
  owner: "Owner",
  admin: "Admin",
  signer: "Signer",
  viewer: "Viewer",
};

export const STATUS_COLORS: Record<string, string> = {
  pending: "bg-yellow-500",
  awaiting_signatures: "bg-blue-500",
  time_locked: "bg-orange-500",
  executed: "bg-green-500",
  failed: "bg-red-500",
  cancelled: "bg-gray-500",
};

export const STATUS_LABELS: Record<string, string> = {
  pending: "Pending",
  awaiting_signatures: "Awaiting Signatures",
  time_locked: "Time Locked",
  executed: "Executed",
  failed: "Failed",
  cancelled: "Cancelled",
};

export const TX_TYPE_LABELS: Record<string, string> = {
  eth_transfer: "ETH Transfer",
  erc20_transfer: "Token Transfer",
  nft_transfer: "NFT Transfer",
  contract_interaction: "Contract Interaction",
};

export const SPENDING_PERIODS = [
  { label: "Daily", value: 86400 },
  { label: "Weekly", value: 604800 },
  { label: "Monthly", value: 2592000 },
];
