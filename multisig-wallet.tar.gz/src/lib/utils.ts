import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatAddress(addr: string): string {
  if (!addr) return ""
  return `${addr.slice(0, 6)}...${addr.slice(-4)}`
}

export function formatEth(wei: string): string {
  const eth = BigInt(wei) / BigInt(1e14)
  return (Number(eth) / 10000).toFixed(4)
}

export function shortenHash(hash: string): string {
  if (!hash) return ""
  return `${hash.slice(0, 10)}...${hash.slice(-8)}`
}
