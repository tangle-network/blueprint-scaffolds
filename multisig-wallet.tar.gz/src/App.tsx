import { BrowserRouter, Routes, Route } from "react-router-dom";
import { WalletProvider } from "@/lib/store";
import { Layout } from "@/components/Layout";
import Dashboard from "@/pages/Dashboard";
import NewTransaction from "@/pages/NewTransaction";
import Signatures from "@/pages/Signatures";
import History from "@/pages/History";
import Settings from "@/pages/Settings";

export default function App() {
  return (
    <WalletProvider>
      <BrowserRouter>
        <Layout>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/transactions/new" element={<NewTransaction />} />
            <Route path="/signatures" element={<Signatures />} />
            <Route path="/history" element={<History />} />
            <Route path="/settings" element={<Settings />} />
          </Routes>
        </Layout>
      </BrowserRouter>
    </WalletProvider>
  );
}
