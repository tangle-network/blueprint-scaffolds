import {
  ArrowRight,
  BadgeCheck,
  Blocks,
  Clock3,
  Coins,
  FileCode2,
  Shield,
  Users
} from "lucide-react";
import { SectionTitle } from "./components/SectionTitle";
import { StatCard } from "./components/StatCard";
import {
  builderActions,
  modules,
  pendingTransactions,
  policies,
  signers,
  timeline,
  treasuryStats
} from "./data";

const statusClassNames = {
  Active: "is-active",
  "Pending rotation": "is-pending",
  "Recovery guardian": "is-guardian",
  Executed: "is-active",
  Queued: "is-pending",
  Rejected: "is-danger",
  Recovered: "is-guardian",
  Low: "is-active",
  Medium: "is-pending",
  High: "is-danger"
} as const;

export default function App() {
  return (
    <div className="app-shell">
      <header className="hero panel">
        <div className="hero__copy">
          <span className="eyebrow">DAO Treasury Control Plane</span>
          <h1>Operate a modular multi-signature wallet with policy-enforced execution.</h1>
          <p>
            Manage signer quorum, queue time-locked transactions, cap daily
            outflows, and maintain a complete audit trail for treasury actions.
          </p>
          <div className="hero__actions">
            <button type="button" className="button button--primary">
              Create wallet
            </button>
            <button type="button" className="button button--secondary">
              Open transaction builder
            </button>
          </div>
        </div>
        <div className="hero__visual">
          <div className="hero__card">
            <span>Core Treasury</span>
            <strong>4 / 7 signatures</strong>
            <p>Policy engine applies 12 hour delay above $250k and 48 hour delay for contract calls.</p>
          </div>
          <div className="hero__grid">
            <span>ETH</span>
            <span>USDC</span>
            <span>NFTs</span>
            <span>Calls</span>
          </div>
        </div>
      </header>

      <main className="main-grid">
        <section className="stats-grid">
          <StatCard
            label="Treasury value"
            value={treasuryStats.totalValue}
            detail="Across ETH, stables, and NFT collateral"
            icon={<Coins size={18} />}
          />
          <StatCard
            label="Monthly throughput"
            value={treasuryStats.monthlyVolume}
            detail="Policy-screened movement over the last 30 days"
            icon={<ArrowRight size={18} />}
          />
          <StatCard
            label="Active vaults"
            value={treasuryStats.activeVaults}
            detail="Factory-deployed wallets sharing common controls"
            icon={<Blocks size={18} />}
          />
          <StatCard
            label="Queued actions"
            value={treasuryStats.queuedTransactions}
            detail="Waiting on signatures or timelock expiry"
            icon={<Clock3 size={18} />}
          />
        </section>

        <section className="panel">
          <SectionTitle
            eyebrow="Builder"
            title="Transaction builder"
            description="Compose transfers or arbitrary calls, preview policy impact, and route requests into signature collection."
          />
          <div className="builder-layout">
            <div className="builder-list">
              {builderActions.map((action) => (
                <article key={action.name} className="builder-card">
                  <div>
                    <h3>{action.name}</h3>
                    <p>{action.description}</p>
                  </div>
                  <span>{action.defaultDelay}</span>
                </article>
              ))}
            </div>
            <form className="builder-form">
              <label>
                Vault
                <select defaultValue="Core Treasury">
                  <option>Core Treasury</option>
                  <option>Ops Wallet</option>
                  <option>NFT Reserve</option>
                </select>
              </label>
              <label>
                Action type
                <select defaultValue="ERC-20 payout">
                  <option>ETH transfer</option>
                  <option>ERC-20 payout</option>
                  <option>NFT custody move</option>
                  <option>Contract interaction</option>
                </select>
              </label>
              <label>
                Destination / target
                <input defaultValue="0x55d2...Ac91" />
              </label>
              <label>
                Amount / calldata
                <textarea
                  rows={5}
                  defaultValue="500000 USDC with calldata 0xa9059cbb..."
                />
              </label>
              <div className="policy-preview">
                <div>
                  <span>Required signatures</span>
                  <strong>4 of 7</strong>
                </div>
                <div>
                  <span>Applied timelock</span>
                  <strong>12 hours</strong>
                </div>
                <div>
                  <span>Daily limit impact</span>
                  <strong>82% consumed</strong>
                </div>
              </div>
              <button type="button" className="button button--primary">
                Queue transaction
              </button>
            </form>
          </div>
        </section>

        <section className="panel">
          <SectionTitle
            eyebrow="Signatures"
            title="Pending queue"
            description="Track quorum, risk tier, and timelock status before execution."
          />
          <div className="transaction-list">
            {pendingTransactions.map((transaction) => (
              <article key={transaction.id} className="transaction-card">
                <div className="transaction-card__top">
                  <div>
                    <span className="transaction-id">{transaction.id}</span>
                    <h3>{transaction.title}</h3>
                  </div>
                  <span className={`badge ${statusClassNames[transaction.risk]}`}>
                    {transaction.risk} risk
                  </span>
                </div>
                <dl>
                  <div>
                    <dt>Type</dt>
                    <dd>{transaction.kind}</dd>
                  </div>
                  <div>
                    <dt>Amount</dt>
                    <dd>{transaction.amount}</dd>
                  </div>
                  <div>
                    <dt>Destination</dt>
                    <dd>{transaction.destination}</dd>
                  </div>
                  <div>
                    <dt>ETA</dt>
                    <dd>{transaction.eta}</dd>
                  </div>
                </dl>
                <div className="transaction-card__footer">
                  <span>
                    {transaction.confirmations}/{transaction.required} signatures by{" "}
                    {transaction.proposer}
                  </span>
                  <span>{transaction.createdAt}</span>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="panel">
          <SectionTitle
            eyebrow="Governance"
            title="Signer matrix"
            description="Role-based permissions, signer rotation, and guardian recovery states."
          />
          <div className="signer-table">
            {signers.map((signer) => (
              <article key={signer.address} className="signer-row">
                <div>
                  <h3>{signer.name}</h3>
                  <p>
                    {signer.role} • {signer.address}
                  </p>
                </div>
                <div className="signer-row__permissions">
                  {signer.permissions.map((permission) => (
                    <span key={permission} className="tag">
                      {permission}
                    </span>
                  ))}
                </div>
                <div>
                  <p>{signer.dailyLimit}</p>
                  <span className={`badge ${statusClassNames[signer.status]}`}>
                    {signer.status}
                  </span>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="panel panel--split">
          <div>
            <SectionTitle
              eyebrow="Policies"
              title="Quorum and timelock profiles"
              description="Different treasury actions can route through distinct policy sets."
            />
            <div className="policy-list">
              {policies.map((policy) => (
                <article key={policy.label} className="policy-card">
                  <div>
                    <h3>{policy.label}</h3>
                    <p>{policy.scope}</p>
                  </div>
                  <strong>{policy.threshold}</strong>
                  <span>{policy.delay}</span>
                </article>
              ))}
            </div>
          </div>
          <div>
            <SectionTitle
              eyebrow="Audit"
              title="History and recovery"
              description="Immutable event timeline for treasury operators and external reviewers."
            />
            <div className="timeline">
              {timeline.map((event) => (
                <article key={`${event.time}-${event.title}`} className="timeline-item">
                  <div className={`timeline-dot ${statusClassNames[event.status]}`} />
                  <div>
                    <span>{event.time}</span>
                    <h3>{event.title}</h3>
                    <p>{event.description}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="panel">
          <SectionTitle
            eyebrow="Architecture"
            title="Contract modules"
            description="The frontend maps directly to wallet, policy, factory, and recovery modules."
          />
          <div className="module-grid">
            {modules.map((module) => (
              <article key={module.name} className="module-card">
                <div className="module-card__header">
                  <FileCode2 size={18} />
                  <h3>{module.name}</h3>
                </div>
                <p>{module.summary}</p>
                <ul>
                  {module.capabilities.map((capability) => (
                    <li key={capability}>
                      <BadgeCheck size={14} />
                      <span>{capability}</span>
                    </li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </section>
      </main>

      <footer className="footer">
        <div>
          <Shield size={18} />
          <span>Deterministic deployments, policy-gated execution, guardian recovery.</span>
        </div>
        <div>
          <Users size={18} />
          <span>Designed for teams, protocols, and DAO treasuries.</span>
        </div>
      </footer>
    </div>
  );
}
