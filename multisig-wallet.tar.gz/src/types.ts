export type AssetKind = "ETH" | "ERC-20" | "NFT" | "Contract";

export type PermissionScope =
  | "Manage signers"
  | "Execute transfers"
  | "Configure policy"
  | "Emergency recovery";

export interface TreasuryStats {
  totalValue: string;
  monthlyVolume: string;
  activeVaults: number;
  queuedTransactions: number;
}

export interface TransferPolicy {
  label: string;
  threshold: string;
  delay: string;
  scope: string;
}

export interface PendingTransaction {
  id: string;
  title: string;
  kind: AssetKind;
  destination: string;
  amount: string;
  createdAt: string;
  eta: string;
  confirmations: number;
  required: number;
  proposer: string;
  risk: "Low" | "Medium" | "High";
}

export interface Signer {
  name: string;
  address: string;
  role: string;
  permissions: PermissionScope[];
  dailyLimit: string;
  status: "Active" | "Pending rotation" | "Recovery guardian";
}

export interface TimelineEvent {
  time: string;
  title: string;
  description: string;
  status: "Executed" | "Queued" | "Rejected" | "Recovered";
}

export interface ContractModule {
  name: string;
  summary: string;
  capabilities: string[];
}

export interface BuilderAction {
  name: string;
  description: string;
  defaultDelay: string;
}
