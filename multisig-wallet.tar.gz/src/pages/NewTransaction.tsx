import { useState } from "react";
import { useWallet } from "@/lib/store";
import { Header } from "@/components/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { SUPPORTED_TOKENS, TIMELOCK_OPTIONS, SPENDING_PERIODS } from "@/lib/constants";
import { isValidAddress } from "@/lib/helpers";
import { ArrowUpRight, Send, FileCode, Image, Coins, AlertCircle, CheckCircle2 } from "lucide-react";
import type { TransactionType, TransactionFormData } from "@/lib/types";

function EthTransferForm({ onSubmit }: { onSubmit: (data: TransactionFormData) => void }) {
  const [to, setTo] = useState("");
  const [value, setValue] = useState("");
  const [description, setDescription] = useState("");
  const [timelock, setTimelock] = useState("0");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!isValidAddress(to)) e.to = "Invalid Ethereum address";
    if (!value || Number(value) <= 0) e.value = "Amount must be greater than 0";
    if (!description.trim()) e.description = "Description is required";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    onSubmit({
      type: "eth_transfer",
      to,
      value: (Number(value) * 1e18).toString(),
      description,
      timeLockSeconds: Number(timelock),
    });
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Recipient Address</Label>
        <Input placeholder="0x..." value={to} onChange={(e) => setTo(e.target.value)} />
        {errors.to && <p className="text-xs text-destructive flex items-center gap-1"><AlertCircle className="h-3 w-3" />{errors.to}</p>}
      </div>
      <div className="space-y-2">
        <Label>Amount (ETH)</Label>
        <Input type="number" placeholder="0.0" value={value} onChange={(e) => setValue(e.target.value)} />
        {errors.value && <p className="text-xs text-destructive flex items-center gap-1"><AlertCircle className="h-3 w-3" />{errors.value}</p>}
      </div>
      <div className="space-y-2">
        <Label>Description</Label>
        <Input placeholder="Purpose of this transaction" value={description} onChange={(e) => setDescription(e.target.value)} />
        {errors.description && <p className="text-xs text-destructive flex items-center gap-1"><AlertCircle className="h-3 w-3" />{errors.description}</p>}
      </div>
      <div className="space-y-2">
        <Label>Time Lock</Label>
        <Select value={timelock} onValueChange={setTimelock}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            {TIMELOCK_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={String(opt.value)}>{opt.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <Button onClick={handleSubmit} className="w-full">
        <Send className="h-4 w-4 mr-2" /> Create ETH Transfer
      </Button>
    </div>
  );
}

function Erc20TransferForm({ onSubmit }: { onSubmit: (data: TransactionFormData) => void }) {
  const [to, setTo] = useState("");
  const [value, setValue] = useState("");
  const [tokenAddress, setTokenAddress] = useState(SUPPORTED_TOKENS[1].address);
  const [description, setDescription] = useState("");
  const [timelock, setTimelock] = useState("0");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!isValidAddress(to)) e.to = "Invalid Ethereum address";
    if (!value || Number(value) <= 0) e.value = "Amount must be greater than 0";
    if (!description.trim()) e.description = "Description is required";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    const token = SUPPORTED_TOKENS.find((t) => t.address === tokenAddress);
    const rawValue = (Number(value) * Math.pow(10, token?.decimals || 18)).toString();
    onSubmit({ type: "erc20_transfer", to, value: rawValue, tokenAddress, description, timeLockSeconds: Number(timelock) });
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Token</Label>
        <Select value={tokenAddress} onValueChange={setTokenAddress}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            {SUPPORTED_TOKENS.filter((t) => t.symbol !== "ETH").map((token) => (
              <SelectItem key={token.address} value={token.address}>{token.symbol} — {token.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-2">
        <Label>Recipient Address</Label>
        <Input placeholder="0x..." value={to} onChange={(e) => setTo(e.target.value)} />
        {errors.to && <p className="text-xs text-destructive flex items-center gap-1"><AlertCircle className="h-3 w-3" />{errors.to}</p>}
      </div>
      <div className="space-y-2">
        <Label>Amount</Label>
        <Input type="number" placeholder="0.0" value={value} onChange={(e) => setValue(e.target.value)} />
        {errors.value && <p className="text-xs text-destructive flex items-center gap-1"><AlertCircle className="h-3 w-3" />{errors.value}</p>}
      </div>
      <div className="space-y-2">
        <Label>Description</Label>
        <Input placeholder="Purpose of this transaction" value={description} onChange={(e) => setDescription(e.target.value)} />
      </div>
      <div className="space-y-2">
        <Label>Time Lock</Label>
        <Select value={timelock} onValueChange={setTimelock}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            {TIMELOCK_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={String(opt.value)}>{opt.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <Button onClick={handleSubmit} className="w-full">
        <Coins className="h-4 w-4 mr-2" /> Create Token Transfer
      </Button>
    </div>
  );
}

function NftTransferForm({ onSubmit }: { onSubmit: (data: TransactionFormData) => void }) {
  const [to, setTo] = useState("");
  const [tokenAddress, setTokenAddress] = useState("");
  const [tokenId, setTokenId] = useState("");
  const [description, setDescription] = useState("");
  const [timelock, setTimelock] = useState("0");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!isValidAddress(to)) e.to = "Invalid Ethereum address";
    if (!isValidAddress(tokenAddress)) e.tokenAddress = "Invalid NFT contract address";
    if (!tokenId.trim()) e.tokenId = "Token ID is required";
    if (!description.trim()) e.description = "Description is required";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    onSubmit({ type: "nft_transfer", to, value: "0", tokenAddress, tokenId, description, timeLockSeconds: Number(timelock) });
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>NFT Contract Address</Label>
        <Input placeholder="0x..." value={tokenAddress} onChange={(e) => setTokenAddress(e.target.value)} />
        {errors.tokenAddress && <p className="text-xs text-destructive flex items-center gap-1"><AlertCircle className="h-3 w-3" />{errors.tokenAddress}</p>}
      </div>
      <div className="space-y-2">
        <Label>Token ID</Label>
        <Input placeholder="1234" value={tokenId} onChange={(e) => setTokenId(e.target.value)} />
        {errors.tokenId && <p className="text-xs text-destructive flex items-center gap-1"><AlertCircle className="h-3 w-3" />{errors.tokenId}</p>}
      </div>
      <div className="space-y-2">
        <Label>Recipient Address</Label>
        <Input placeholder="0x..." value={to} onChange={(e) => setTo(e.target.value)} />
        {errors.to && <p className="text-xs text-destructive flex items-center gap-1"><AlertCircle className="h-3 w-3" />{errors.to}</p>}
      </div>
      <div className="space-y-2">
        <Label>Description</Label>
        <Input placeholder="Purpose of this transfer" value={description} onChange={(e) => setDescription(e.target.value)} />
      </div>
      <div className="space-y-2">
        <Label>Time Lock</Label>
        <Select value={timelock} onValueChange={setTimelock}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            {TIMELOCK_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={String(opt.value)}>{opt.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <Button onClick={handleSubmit} className="w-full">
        <Image className="h-4 w-4 mr-2" /> Create NFT Transfer
      </Button>
    </div>
  );
}

function ContractInteractionForm({ onSubmit }: { onSubmit: (data: TransactionFormData) => void }) {
  const [to, setTo] = useState("");
  const [value, setValue] = useState("");
  const [data, setData] = useState("");
  const [description, setDescription] = useState("");
  const [timelock, setTimelock] = useState("0");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!isValidAddress(to)) e.to = "Invalid contract address";
    if (!data.trim() || !data.startsWith("0x")) e.data = "Calldata must start with 0x";
    if (!description.trim()) e.description = "Description is required";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    onSubmit({ type: "contract_interaction", to, value: (Number(value || 0) * 1e18).toString(), data, description, timeLockSeconds: Number(timelock) });
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Contract Address</Label>
        <Input placeholder="0x..." value={to} onChange={(e) => setTo(e.target.value)} />
        {errors.to && <p className="text-xs text-destructive flex items-center gap-1"><AlertCircle className="h-3 w-3" />{errors.to}</p>}
      </div>
      <div className="space-y-2">
        <Label>ETH Value (optional)</Label>
        <Input type="number" placeholder="0.0" value={value} onChange={(e) => setValue(e.target.value)} />
      </div>
      <div className="space-y-2">
        <Label>Calldata</Label>
        <textarea
          className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring font-mono"
          placeholder="0x..."
          value={data}
          onChange={(e) => setData(e.target.value)}
        />
        {errors.data && <p className="text-xs text-destructive flex items-center gap-1"><AlertCircle className="h-3 w-3" />{errors.data}</p>}
      </div>
      <div className="space-y-2">
        <Label>Description</Label>
        <Input placeholder="What does this call do?" value={description} onChange={(e) => setDescription(e.target.value)} />
      </div>
      <div className="space-y-2">
        <Label>Time Lock</Label>
        <Select value={timelock} onValueChange={setTimelock}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            {TIMELOCK_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={String(opt.value)}>{opt.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <Button onClick={handleSubmit} className="w-full">
        <FileCode className="h-4 w-4 mr-2" /> Create Contract Interaction
      </Button>
    </div>
  );
}

export default function NewTransaction() {
  const { createTransaction, wallet } = useWallet();
  const [success, setSuccess] = useState(false);

  const handleSubmit = (data: TransactionFormData) => {
    createTransaction(data);
    setSuccess(true);
    setTimeout(() => setSuccess(false), 3000);
  };

  return (
    <div>
      <Header title="New Transaction" description="Create a new transaction proposal" />
      <div className="p-6 max-w-2xl mx-auto">
        {success && (
          <div className="mb-4 p-4 rounded-md bg-green-50 border border-green-200 flex items-center gap-2">
            <CheckCircle2 className="h-5 w-5 text-green-600" />
            <span className="text-green-800">Transaction submitted! Collecting {wallet.policy.requiredSignatures} signatures.</span>
          </div>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Transaction Builder</CardTitle>
            <CardDescription>
              Requires {wallet.policy.requiredSignatures}-of-{wallet.policy.totalSigners} signatures to execute
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="eth">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="eth"><ArrowUpRight className="h-4 w-4 mr-1" />ETH</TabsTrigger>
                <TabsTrigger value="erc20"><Coins className="h-4 w-4 mr-1" />Token</TabsTrigger>
                <TabsTrigger value="nft"><Image className="h-4 w-4 mr-1" />NFT</TabsTrigger>
                <TabsTrigger value="contract"><FileCode className="h-4 w-4 mr-1" />Contract</TabsTrigger>
              </TabsList>
              <TabsContent value="eth" className="mt-4"><EthTransferForm onSubmit={handleSubmit} /></TabsContent>
              <TabsContent value="erc20" className="mt-4"><Erc20TransferForm onSubmit={handleSubmit} /></TabsContent>
              <TabsContent value="nft" className="mt-4"><NftTransferForm onSubmit={handleSubmit} /></TabsContent>
              <TabsContent value="contract" className="mt-4"><ContractInteractionForm onSubmit={handleSubmit} /></TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="text-base">Policy Constraints</CardTitle>
          </CardHeader>
          <CardContent className="text-sm space-y-2 text-muted-foreground">
            <div className="flex justify-between">
              <span>Required Signatures</span>
              <span className="font-medium text-foreground">{wallet.policy.requiredSignatures} of {wallet.policy.totalSigners}</span>
            </div>
            <Separator />
            <div className="flex justify-between">
              <span>Max Transaction Size</span>
              <span className="font-medium text-foreground">{(Number(wallet.policy.maxTransactionSize) / 1e18).toFixed(2)} ETH</span>
            </div>
            <Separator />
            <div className="flex justify-between">
              <span>Max Daily Spend</span>
              <span className="font-medium text-foreground">{(Number(wallet.policy.maxDailySpend) / 1e18).toFixed(2)} ETH</span>
            </div>
            <Separator />
            <div className="flex justify-between">
              <span>Contract Interaction</span>
              <span className="font-medium text-foreground">{wallet.policy.allowContractInteraction ? "Allowed" : "Disabled"}</span>
            </div>
            <Separator />
            <div className="flex justify-between">
              <span>NFT Transfers</span>
              <span className="font-medium text-foreground">{wallet.policy.allowNFTTransfer ? "Allowed" : "Disabled"}</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
