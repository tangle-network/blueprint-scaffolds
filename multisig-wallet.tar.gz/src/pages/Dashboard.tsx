import { useWallet } from "@/lib/store";
import { Header } from "@/components/Layout";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { STATUS_COLORS, STATUS_LABELS, TX_TYPE_LABELS } from "@/lib/constants";
import { formatEthValue, formatRelativeTime, formatAddress } from "@/lib/helpers";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Wallet,
  ArrowUpRight,
  ArrowDownLeft,
  Clock,
  Users,
  Shield,
  AlertCircle,
  CheckCircle2,
  XCircle,
  Timer,
} from "lucide-react";
import type { Transaction } from "@/lib/types";

function StatCard({ title, value, icon: Icon, description }: { title: string; value: string | number; icon: React.ElementType; description: string }) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground">{description}</p>
      </CardContent>
    </Card>
  );
}

function StatusBadge({ status }: { status: Transaction["status"] }) {
  return (
    <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium">
      <span className={`h-2 w-2 rounded-full ${STATUS_COLORS[status]}`} />
      {STATUS_LABELS[status]}
    </span>
  );
}

function PendingTransactionRow({ tx }: { tx: Transaction }) {
  const { signTransaction } = useWallet();
  const alreadySigned = tx.signatures.some((s) => s.signer === "0x1234567890abcdef1234567890abcdef12345678");
  const sigProgress = (tx.signatures.length / tx.requiredSignatures) * 100;

  return (
    <div className="flex items-center justify-between py-3 border-b last:border-0">
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-sm font-medium truncate">{tx.description}</span>
          <StatusBadge status={tx.status} />
        </div>
        <div className="flex items-center gap-4 text-xs text-muted-foreground">
          <span>{TX_TYPE_LABELS[tx.type]}</span>
          <span>{formatEthValue(tx.value)} ETH</span>
          <span>To: {formatAddress(tx.to)}</span>
          <span>{formatRelativeTime(tx.createdAt)}</span>
        </div>
        <div className="flex items-center gap-2 mt-2">
          <Progress value={sigProgress} className="h-2 flex-1" />
          <span className="text-xs text-muted-foreground whitespace-nowrap">
            {tx.signatures.length}/{tx.requiredSignatures}
          </span>
        </div>
      </div>
      <div className="flex gap-2 ml-4">
        {!alreadySigned && (
          <Button size="sm" onClick={() => signTransaction(tx.id)}>
            Sign
          </Button>
        )}
        {alreadySigned && (
          <span className="text-xs text-green-600 flex items-center gap-1">
            <CheckCircle2 className="h-3 w-3" /> Signed
          </span>
        )}
      </div>
    </div>
  );
}

function SpendingLimitCard({ limit }: { limit: { category: string; limitWei: string; spentWei: string; periodSeconds: number } }) {
  const spent = Number(limit.spentWei) / 1e18;
  const total = Number(limit.limitWei) / 1e18;
  const pct = total > 0 ? (spent / total) * 100 : 0;
  const periods: Record<number, string> = { 86400: "Daily", 604800: "Weekly", 2592000: "Monthly" };

  return (
    <div className="space-y-2">
      <div className="flex justify-between text-sm">
        <span className="font-medium">{limit.category}</span>
        <span className="text-muted-foreground">
          {spent.toFixed(2)} / {total.toFixed(2)} ETH ({periods[limit.periodSeconds] || "Custom"})
        </span>
      </div>
      <Progress value={pct} className="h-2" />
    </div>
  );
}

export default function Dashboard() {
  const { wallet, transactions } = useWallet();
  const pending = transactions.filter((t) => ["pending", "awaiting_signatures", "time_locked"].includes(t.status));
  const executed = transactions.filter((t) => t.status === "executed");
  const failed = transactions.filter((t) => t.status === "failed");
  const totalValueExecuted = executed.reduce((sum, t) => sum + Number(t.value) / 1e18, 0);

  return (
    <div>
      <Header title="Dashboard" description={`${wallet.name} — ${wallet.policy.requiredSigners}-of-${wallet.policy.totalSigners} multi-sig`} />
      <div className="p-6 space-y-6">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <StatCard title="ETH Balance" value={`${wallet.balance} ETH`} icon={Wallet} description="Current treasury balance" />
          <StatCard title="Pending Transactions" value={pending.length} icon={Clock} description="Awaiting signatures or timelock" />
          <StatCard title="Total Executed" value={executed.length} icon={CheckCircle2} description={`${totalValueExecuted.toFixed(4)} ETH total`} />
          <StatCard title="Signers" value={`${wallet.policy.totalSigners} active`} icon={Users} description={`${wallet.policy.requiredSignatures} required to approve`} />
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Pending Transactions</CardTitle>
                  <CardDescription>Transactions requiring attention</CardDescription>
                </div>
                <Link to="/transactions/new">
                  <Button size="sm">New Transaction</Button>
                </Link>
              </CardHeader>
              <CardContent>
                {pending.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <CheckCircle2 className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p>No pending transactions</p>
                  </div>
                ) : (
                  pending.slice(0, 5).map((tx) => <PendingTransactionRow key={tx.id} tx={tx} />)
                )}
                {pending.length > 5 && (
                  <Link to="/signatures">
                    <Button variant="ghost" className="w-full mt-2">View all {pending.length} pending</Button>
                  </Link>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Token Balances</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {wallet.tokenBalances.map((token) => (
                  <div key={token.symbol} className="flex justify-between text-sm">
                    <span className="font-medium">{token.symbol}</span>
                    <span className="text-muted-foreground">{token.balance}</span>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Spending Limits</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {wallet.policy.spendingLimits.map((limit) => (
                  <SpendingLimitCard key={limit.id} limit={limit} />
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {transactions.slice(0, 4).map((tx) => (
                  <div key={tx.id} className="flex items-center gap-2 text-sm">
                    {tx.status === "executed" ? (
                      <CheckCircle2 className="h-4 w-4 text-green-500 shrink-0" />
                    ) : tx.status === "failed" ? (
                      <XCircle className="h-4 w-4 text-red-500 shrink-0" />
                    ) : (
                      <Timer className="h-4 w-4 text-yellow-500 shrink-0" />
                    )}
                    <span className="truncate flex-1">{tx.description}</span>
                    <span className="text-muted-foreground text-xs whitespace-nowrap">{formatRelativeTime(tx.createdAt)}</span>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
