import { useState } from "react";
import { useWallet } from "@/lib/store";
import { Header } from "@/components/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { ROLE_LABELS, SPENDING_PERIODS, STATUS_COLORS } from "@/lib/constants";
import { formatAddress, formatTimestamp, isValidAddress } from "@/lib/helpers";
import {
  Users,
  Shield,
  CreditCard,
  Plus,
  Trash2,
  UserPlus,
  UserMinus,
  AlertCircle,
  CheckCircle2,
  Key,
  Lock,
} from "lucide-react";
import type { Signer, WalletRole, SpendingLimit } from "@/lib/types";

function SignersTab() {
  const { wallet, addSigner, removeSigner } = useWallet();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newAddress, setNewAddress] = useState("");
  const [newName, setNewName] = useState("");
  const [newRole, setNewRole] = useState<string>("signer");
  const [error, setError] = useState("");

  const handleAddSigner = () => {
    if (!isValidAddress(newAddress)) {
      setError("Invalid Ethereum address");
      return;
    }
    if (!newName.trim()) {
      setError("Name is required");
      return;
    }
    addSigner(newAddress, newName.trim(), newRole as WalletRole);
    setNewAddress("");
    setNewName("");
    setNewRole("signer");
    setError("");
    setDialogOpen(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-medium">Signers</h3>
          <p className="text-sm text-muted-foreground">
            {wallet.policy.requiredSignatures}-of-{wallet.policy.totalSigners} multi-signature configuration
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button><UserPlus className="h-4 w-4 mr-2" /> Add Signer</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Signer</DialogTitle>
              <DialogDescription>Add a new signer to the multi-sig wallet</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Ethereum Address</Label>
                <Input placeholder="0x..." value={newAddress} onChange={(e) => { setNewAddress(e.target.value); setError(""); }} />
              </div>
              <div className="space-y-2">
                <Label>Name</Label>
                <Input placeholder="Signer name" value={newName} onChange={(e) => { setNewName(e.target.value); setError(""); }} />
              </div>
              <div className="space-y-2">
                <Label>Role</Label>
                <Select value={newRole} onValueChange={setNewRole}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="owner">Owner</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                    <SelectItem value="signer">Signer</SelectItem>
                    <SelectItem value="viewer">Viewer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {error && <p className="text-xs text-destructive flex items-center gap-1"><AlertCircle className="h-3 w-3" />{error}</p>}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleAddSigner}>Add Signer</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardContent className="p-0">
          {wallet.signers.map((signer) => (
            <div key={signer.address} className="flex items-center justify-between py-3 px-4 border-b last:border-0">
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-full bg-primary flex items-center justify-center">
                  <span className="text-xs font-bold text-primary-foreground">{signer.name.charAt(0)}</span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">{signer.name}</span>
                    <span className="text-xs px-1.5 py-0.5 rounded bg-muted">{ROLE_LABELS[signer.role]}</span>
                  </div>
                  <span className="text-xs text-muted-foreground font-mono">{formatAddress(signer.address)}</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">Joined {formatTimestamp(signer.joinedAt)}</span>
                {signer.role !== "owner" && (
                  <Button variant="ghost" size="icon" onClick={() => removeSigner(signer.address)}>
                    <UserMinus className="h-4 w-4 text-destructive" />
                  </Button>
                )}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}

function PolicyTab() {
  const { wallet, updatePolicy } = useWallet();
  const policy = wallet.policy;
  const [required, setRequired] = useState(String(policy.requiredSignatures));
  const [timelock, setTimelock] = useState(String(policy.timeLockSeconds));
  const [maxDaily, setMaxDaily] = useState(String(Number(policy.maxDailySpend) / 1e18));
  const [maxTx, setMaxTx] = useState(String(Number(policy.maxTransactionSize) / 1e18));
  const [allowContract, setAllowContract] = useState(policy.allowContractInteraction);
  const [allowNFT, setAllowNFT] = useState(policy.allowNFTTransfer);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    updatePolicy({
      requiredSignatures: Number(required),
      timeLockSeconds: Number(timelock),
      maxDailySpend: (Number(maxDaily) * 1e18).toString(),
      maxTransactionSize: (Number(maxTx) * 1e18).toString(),
      allowContractInteraction: allowContract,
      allowNFTTransfer: allowNFT,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium">Wallet Policy</h3>
        <p className="text-sm text-muted-foreground">Configure multi-sig rules and constraints</p>
      </div>

      {saved && (
        <div className="p-3 rounded-md bg-green-50 border border-green-200 flex items-center gap-2">
          <CheckCircle2 className="h-4 w-4 text-green-600" />
          <span className="text-sm text-green-800">Policy updated successfully</span>
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Signature Requirements</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Required Signatures (M-of-N)</Label>
            <div className="flex items-center gap-4">
              <Input type="number" min={1} max={wallet.policy.totalSigners} value={required} onChange={(e) => setRequired(e.target.value)} className="w-24" />
              <span className="text-sm text-muted-foreground">of {wallet.policy.totalSigners} signers</span>
            </div>
            <p className="text-xs text-muted-foreground">How many signatures needed to execute a transaction</p>
          </div>
          <Separator />
          <div className="space-y-2">
            <Label>Default Time Lock (seconds)</Label>
            <Input type="number" value={timelock} onChange={(e) => setTimelock(e.target.value)} />
            <p className="text-xs text-muted-foreground">Delay between last signature and execution. 0 = no lock.</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Spending Limits</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>Max Daily Spend (ETH)</Label>
              <Input type="number" value={maxDaily} onChange={(e) => setMaxDaily(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Max Transaction Size (ETH)</Label>
              <Input type="number" value={maxTx} onChange={(e) => setMaxTx(e.target.value)} />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Permissions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Contract Interaction</p>
              <p className="text-xs text-muted-foreground">Allow transactions to arbitrary contracts</p>
            </div>
            <Switch checked={allowContract} onCheckedChange={setAllowContract} />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">NFT Transfers</p>
              <p className="text-xs text-muted-foreground">Allow ERC-721 token transfers</p>
            </div>
            <Switch checked={allowNFT} onCheckedChange={setAllowNFT} />
          </div>
        </CardContent>
      </Card>

      <Button onClick={handleSave} className="w-full max-w-xs">Save Policy Changes</Button>
    </div>
  );
}

function SpendingLimitsTab() {
  const { wallet, addSpendingLimit, removeSpendingLimit } = useWallet();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [category, setCategory] = useState("");
  const [limitEth, setLimitEth] = useState("");
  const [period, setPeriod] = useState("86400");
  const [threshold, setThreshold] = useState("");
  const [error, setError] = useState("");

  const handleAdd = () => {
    if (!category.trim()) { setError("Category is required"); return; }
    if (!limitEth || Number(limitEth) <= 0) { setError("Limit must be greater than 0"); return; }
    const limit: SpendingLimit = {
      id: `sl-${Date.now()}`,
      category: category.trim(),
      limitWei: (Number(limitEth) * 1e18).toString(),
      periodSeconds: Number(period),
      spentWei: "0",
      periodStart: Date.now(),
      isActive: true,
      requiresApprovalAbove: (Number(threshold || 0) * 1e18).toString(),
    };
    addSpendingLimit(limit);
    setCategory("");
    setLimitEth("");
    setPeriod("86400");
    setThreshold("");
    setError("");
    setDialogOpen(false);
  };

  const periods: Record<number, string> = { 86400: "Daily", 604800: "Weekly", 2592000: "Monthly" };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-medium">Spending Limits</h3>
          <p className="text-sm text-muted-foreground">Category-based spending controls</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="h-4 w-4 mr-2" /> Add Limit</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Spending Limit</DialogTitle>
              <DialogDescription>Create a new spending category with limits</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Category Name</Label>
                <Input placeholder="e.g. Infrastructure" value={category} onChange={(e) => { setCategory(e.target.value); setError(""); }} />
              </div>
              <div className="space-y-2">
                <Label>Spending Limit (ETH)</Label>
                <Input type="number" placeholder="0.0" value={limitEth} onChange={(e) => { setLimitEth(e.target.value); setError(""); }} />
              </div>
              <div className="space-y-2">
                <Label>Period</Label>
                <Select value={period} onValueChange={setPeriod}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {SPENDING_PERIODS.map((p) => (
                      <SelectItem key={p.value} value={String(p.value)}>{p.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Requires Approval Above (ETH)</Label>
                <Input type="number" placeholder="0.0" value={threshold} onChange={(e) => setThreshold(e.target.value)} />
              </div>
              {error && <p className="text-xs text-destructive flex items-center gap-1"><AlertCircle className="h-3 w-3" />{error}</p>}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleAdd}>Add Limit</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {wallet.policy.spendingLimits.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center text-muted-foreground">
            <CreditCard className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p>No spending limits configured</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {wallet.policy.spendingLimits.map((limit) => {
            const spent = Number(limit.spentWei) / 1e18;
            const total = Number(limit.limitWei) / 1e18;
            const pct = total > 0 ? (spent / total) * 100 : 0;
            return (
              <Card key={limit.id}>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-base">{limit.category}</CardTitle>
                  <Button variant="ghost" size="icon" onClick={() => removeSpendingLimit(limit.id)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{periods[limit.periodSeconds] || "Custom"} limit</span>
                    <span className="font-medium">{spent.toFixed(2)} / {total.toFixed(2)} ETH</span>
                  </div>
                  <Progress value={pct} className="h-2" />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{pct.toFixed(1)}% used</span>
                    <span>Approval above: {(Number(limit.requiresApprovalAbove) / 1e18).toFixed(2)} ETH</span>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

function RecoveryTab() {
  const { wallet } = useWallet();

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium">Recovery & Security</h3>
        <p className="text-sm text-muted-foreground">Wallet recovery and security settings</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2"><Key className="h-4 w-4" /> Signer Recovery</CardTitle>
          <CardDescription>Replace a compromised or lost signer key</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            To replace a signer, a transaction must be proposed with the new signer address and approved by the required number of existing signers.
            This ensures no single party can unilaterally change the signer set.
          </p>
          <div className="rounded-md border p-4 bg-muted/50">
            <h4 className="text-sm font-medium mb-2">Recovery Process</h4>
            <ol className="text-sm text-muted-foreground space-y-1 list-decimal list-inside">
              <li>Propose a signer replacement transaction</li>
              <li>Collect {wallet.policy.requiredSignatures} signatures from existing signers</li>
              <li>Wait for time-lock period ({wallet.policy.timeLockSeconds / 3600}h)</li>
              <li>Execute the replacement on-chain</li>
            </ol>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2"><Lock className="h-4 w-4" /> Emergency Lock</CardTitle>
          <CardDescription>Emergency procedures for compromised wallets</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            In case of emergency, any owner or admin can pause the wallet. This prevents all transaction executions until the wallet is unpaused by a majority of signers.
          </p>
          <Button variant="destructive">Emergency Pause Wallet</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Wallet Info</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Contract Address</span>
            <span className="font-mono">{formatAddress(wallet.address)}</span>
          </div>
          <Separator />
          <div className="flex justify-between">
            <span className="text-muted-foreground">Configuration</span>
            <span>{wallet.policy.requiredSignatures}-of-{wallet.policy.totalSigners}</span>
          </div>
          <Separator />
          <div className="flex justify-between">
            <span className="text-muted-foreground">Created</span>
            <span>{formatTimestamp(wallet.createdAt)}</span>
          </div>
          <Separator />
          <div className="flex justify-between">
            <span className="text-muted-foreground">Total Transactions</span>
            <span>{wallet.transactionCount}</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function Settings() {
  return (
    <div>
      <Header title="Settings" description="Manage wallet configuration, signers, and policies" />
      <div className="p-6 max-w-4xl mx-auto">
        <Tabs defaultValue="signers">
          <TabsList>
            <TabsTrigger value="signers"><Users className="h-4 w-4 mr-1" />Signers</TabsTrigger>
            <TabsTrigger value="policy"><Shield className="h-4 w-4 mr-1" />Policy</TabsTrigger>
            <TabsTrigger value="limits"><CreditCard className="h-4 w-4 mr-1" />Limits</TabsTrigger>
            <TabsTrigger value="recovery"><Key className="h-4 w-4 mr-1" />Recovery</TabsTrigger>
          </TabsList>
          <TabsContent value="signers" className="mt-6"><SignersTab /></TabsContent>
          <TabsContent value="policy" className="mt-6"><PolicyTab /></TabsContent>
          <TabsContent value="limits" className="mt-6"><SpendingLimitsTab /></TabsContent>
          <TabsContent value="recovery" className="mt-6"><RecoveryTab /></TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
