import { useState } from "react";
import { useWallet } from "@/lib/store";
import { Header } from "@/components/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { STATUS_COLORS, STATUS_LABELS, TX_TYPE_LABELS } from "@/lib/constants";
import { formatEthValue, formatAddress, formatTimestamp, formatRelativeTime } from "@/lib/helpers";
import {
  CheckCircle2,
  XCircle,
  Clock,
  Timer,
  Search,
  ArrowUpRight,
  ArrowDownLeft,
  Filter,
  ExternalLink,
} from "lucide-react";
import type { Transaction, TransactionStatus } from "@/lib/types";

function StatusIcon({ status }: { status: Transaction["status"] }) {
  switch (status) {
    case "pending": return <Clock className="h-4 w-4 text-yellow-500" />;
    case "awaiting_signatures": return <Timer className="h-4 w-4 text-blue-500" />;
    case "time_locked": return <Timer className="h-4 w-4 text-orange-500" />;
    case "executed": return <CheckCircle2 className="h-4 w-4 text-green-500" />;
    case "failed": return <XCircle className="h-4 w-4 text-red-500" />;
    case "cancelled": return <XCircle className="h-4 w-4 text-gray-500" />;
  }
}

function TransactionRow({ tx }: { tx: Transaction }) {
  return (
    <div className="flex items-center gap-4 py-3 px-4 border-b last:border-0 hover:bg-muted/50 transition-colors">
      <div className="shrink-0">
        <StatusIcon status={tx.status} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-0.5">
          <span className="text-sm font-medium truncate">{tx.description}</span>
        </div>
        <div className="flex items-center gap-3 text-xs text-muted-foreground">
          <span>{TX_TYPE_LABELS[tx.type]}</span>
          <span>{formatEthValue(tx.value)} ETH</span>
          <span>To: {formatAddress(tx.to)}</span>
          <span>#{tx.nonce}</span>
        </div>
      </div>
      <div className="shrink-0 flex items-center gap-3">
        <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium`}>
          <span className={`h-2 w-2 rounded-full ${STATUS_COLORS[tx.status]}`} />
          {STATUS_LABELS[tx.status]}
        </span>
        <span className="text-xs text-muted-foreground whitespace-nowrap">{formatRelativeTime(tx.createdAt)}</span>
      </div>
    </div>
  );
}

export default function History() {
  const { transactions } = useWallet();
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState<string>("all");

  const filterTxs = (txs: Transaction[]) => {
    return txs.filter((tx) => {
      const matchesSearch =
        search === "" ||
        tx.description.toLowerCase().includes(search.toLowerCase()) ||
        tx.to.toLowerCase().includes(search.toLowerCase()) ||
        tx.id.toLowerCase().includes(search.toLowerCase());
      const matchesStatus = filterStatus === "all" || tx.status === filterStatus;
      return matchesSearch && matchesStatus;
    });
  };

  const executed = filterTxs(transactions.filter((t) => t.status === "executed"));
  const failed = filterTxs(transactions.filter((t) => t.status === "failed"));
  const cancelled = filterTxs(transactions.filter((t) => t.status === "cancelled"));
  const all = filterTxs(transactions);

  return (
    <div>
      <Header title="Transaction History" description="Complete audit trail of all transactions" />
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search transactions..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          <div className="flex gap-2">
            {(["all", "executed", "failed", "cancelled"] as const).map((s) => (
              <Button
                key={s}
                variant={filterStatus === s ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterStatus(s)}
              >
                {s === "all" ? "All" : STATUS_LABELS[s]}
              </Button>
            ))}
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold">{transactions.length}</div>
              <p className="text-xs text-muted-foreground">Total Transactions</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-green-600">{transactions.filter((t) => t.status === "executed").length}</div>
              <p className="text-xs text-muted-foreground">Executed</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-red-600">{transactions.filter((t) => t.status === "failed").length}</div>
              <p className="text-xs text-muted-foreground">Failed</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-gray-600">{transactions.filter((t) => t.status === "cancelled").length}</div>
              <p className="text-xs text-muted-foreground">Cancelled</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Transaction Log</CardTitle>
            <CardDescription>Full history of all wallet transactions</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            {all.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <Clock className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No transactions found</p>
              </div>
            ) : (
              all.map((tx) => <TransactionRow key={tx.id} tx={tx} />)
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Audit Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-3">
                <h4 className="text-sm font-medium">Volume by Type</h4>
                {(["eth_transfer", "erc20_transfer", "nft_transfer", "contract_interaction"] as const).map((type) => {
                  const count = transactions.filter((t) => t.type === type).length;
                  const volume = transactions
                    .filter((t) => t.type === type && t.status === "executed")
                    .reduce((sum, t) => sum + Number(t.value) / 1e18, 0);
                  return (
                    <div key={type} className="flex justify-between text-sm">
                      <span>{TX_TYPE_LABELS[type]}</span>
                      <span className="text-muted-foreground">{count} txs ({volume.toFixed(4)} ETH)</span>
                    </div>
                  );
                })}
              </div>
              <div className="space-y-3">
                <h4 className="text-sm font-medium">Status Breakdown</h4>
                {(["executed", "failed", "cancelled"] as const).map((status) => (
                  <div key={status} className="flex justify-between text-sm">
                    <span className="flex items-center gap-2">
                      <span className={`h-2 w-2 rounded-full ${STATUS_COLORS[status]}`} />
                      {STATUS_LABELS[status]}
                    </span>
                    <span className="text-muted-foreground">{transactions.filter((t) => t.status === status).length}</span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
