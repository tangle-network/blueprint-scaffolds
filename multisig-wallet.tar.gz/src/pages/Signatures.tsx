import { useWallet } from "@/lib/store";
import { Header } from "@/components/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { STATUS_COLORS, STATUS_LABELS, TX_TYPE_LABELS, ROLE_LABELS } from "@/lib/constants";
import { formatEthValue, formatAddress, formatTimestamp, getTimeLockRemaining, formatRelativeTime } from "@/lib/helpers";
import {
  CheckCircle2,
  Clock,
  Lock,
  AlertTriangle,
  XCircle,
  Play,
  X,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { useState } from "react";
import type { Transaction } from "@/lib/types";

function StatusIcon({ status }: { status: Transaction["status"] }) {
  switch (status) {
    case "pending": return <Clock className="h-5 w-5 text-yellow-500" />;
    case "awaiting_signatures": return <AlertTriangle className="h-5 w-5 text-blue-500" />;
    case "time_locked": return <Lock className="h-5 w-5 text-orange-500" />;
    case "executed": return <CheckCircle2 className="h-5 w-5 text-green-500" />;
    case "failed": return <XCircle className="h-5 w-5 text-red-500" />;
    case "cancelled": return <X className="h-5 w-5 text-gray-500" />;
  }
}

function SignatureCard({ tx }: { tx: Transaction }) {
  const { signTransaction, executeTransaction, cancelTransaction, wallet, currentAddress } = useWallet();
  const [expanded, setExpanded] = useState(false);
  const alreadySigned = tx.signatures.some((s) => s.signer === currentAddress);
  const sigProgress = (tx.signatures.length / tx.requiredSignatures) * 100;
  const canExecute = tx.signatures.length >= tx.requiredSignatures && tx.status !== "executed";
  const timelockRemaining = getTimeLockRemaining(tx.executeAfter);
  const isLocked = tx.executeAfter && tx.executeAfter > Date.now();

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-3">
            <StatusIcon status={tx.status} />
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="font-medium">{tx.description}</span>
                <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${STATUS_COLORS[tx.status]} text-white`}>
                  {STATUS_LABELS[tx.status]}
                </span>
              </div>
              <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground">
                <span>{TX_TYPE_LABELS[tx.type]}</span>
                <span>{formatEthValue(tx.value)} {tx.type === "eth_transfer" ? "ETH" : ""}</span>
                <span>To: {formatAddress(tx.to)}</span>
                <span>Nonce: #{tx.nonce}</span>
                <span>{formatRelativeTime(tx.createdAt)}</span>
              </div>
              {tx.spendingLimitCategory && (
                <span className="text-xs bg-muted px-2 py-0.5 rounded mt-1 inline-block">{tx.spendingLimitCategory}</span>
              )}
              {isLocked && timelockRemaining && (
                <div className="flex items-center gap-1 mt-1 text-xs text-orange-600">
                  <Lock className="h-3 w-3" /> {timelockRemaining}
                </div>
              )}
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setExpanded(!expanded)}>
            {expanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </Button>
        </div>

        <div className="flex items-center gap-3 mt-3">
          <Progress value={sigProgress} className="h-2 flex-1" />
          <span className="text-sm text-muted-foreground whitespace-nowrap">
            {tx.signatures.length}/{tx.requiredSignatures} signatures
          </span>
        </div>

        <div className="flex gap-2 mt-3">
          {!alreadySigned && tx.status !== "executed" && tx.status !== "cancelled" && (
            <Button size="sm" onClick={() => signTransaction(tx.id)}>
              Sign Transaction
            </Button>
          )}
          {alreadySigned && tx.status !== "executed" && tx.status !== "cancelled" && (
            <span className="text-sm text-green-600 flex items-center gap-1">
              <CheckCircle2 className="h-4 w-4" /> You have signed
            </span>
          )}
          {canExecute && !isLocked && (
            <Button size="sm" variant="default" onClick={() => executeTransaction(tx.id)}>
              <Play className="h-4 w-4 mr-1" /> Execute
            </Button>
          )}
          {(tx.status === "pending" || tx.status === "awaiting_signatures") && (
            <Button size="sm" variant="destructive" onClick={() => cancelTransaction(tx.id)}>
              <X className="h-4 w-4 mr-1" /> Cancel
            </Button>
          )}
        </div>

        {expanded && (
          <>
            <Separator className="my-3" />
            <div className="space-y-3">
              <div>
                <h4 className="text-sm font-medium mb-2">Signature Details</h4>
                <div className="space-y-2">
                  {wallet.signers.map((signer) => {
                    const sig = tx.signatures.find((s) => s.signer === signer.address);
                    return (
                      <div key={signer.address} className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          <div className={`h-2 w-2 rounded-full ${sig ? "bg-green-500" : "bg-gray-300"}`} />
                          <span>{signer.name}</span>
                          <span className="text-xs text-muted-foreground">({ROLE_LABELS[signer.role]})</span>
                        </div>
                        <div>
                          {sig ? (
                            <span className="text-xs text-green-600">Signed {formatRelativeTime(sig.signedAt)}</span>
                          ) : (
                            <span className="text-xs text-muted-foreground">Pending</span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
              <Separator />
              <div className="text-xs text-muted-foreground space-y-1">
                <div className="flex justify-between">
                  <span>Created</span>
                  <span>{formatTimestamp(tx.createdAt)}</span>
                </div>
                {tx.executeAfter && (
                  <div className="flex justify-between">
                    <span>Execute After</span>
                    <span>{formatTimestamp(tx.executeAfter)}</span>
                  </div>
                )}
                {tx.executedAt && (
                  <div className="flex justify-between">
                    <span>Executed</span>
                    <span>{formatTimestamp(tx.executedAt)}</span>
                  </div>
                )}
                {tx.tokenAddress && (
                  <div className="flex justify-between">
                    <span>Token Contract</span>
                    <span className="font-mono">{formatAddress(tx.tokenAddress)}</span>
                  </div>
                )}
                {tx.tokenId && (
                  <div className="flex justify-between">
                    <span>Token ID</span>
                    <span>#{tx.tokenId}</span>
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

export default function Signatures() {
  const { getPendingTransactions, getTransactionsByStatus } = useWallet();
  const pending = getPendingTransactions();
  const awaiting = getTransactionsByStatus("awaiting_signatures");
  const timeLocked = getTransactionsByStatus("time_locked");

  return (
    <div>
      <Header title="Signature Collection" description="Review and sign pending transactions" />
      <div className="p-6 space-y-6 max-w-3xl mx-auto">
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold">{pending.length}</div>
              <p className="text-xs text-muted-foreground">Total Pending</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">{awaiting.length}</div>
              <p className="text-xs text-muted-foreground">Awaiting Signatures</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600">{timeLocked.length}</div>
              <p className="text-xs text-muted-foreground">Time Locked</p>
            </CardContent>
          </Card>
        </div>

        {pending.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <CheckCircle2 className="h-12 w-12 mx-auto mb-3 text-green-500 opacity-50" />
              <h3 className="text-lg font-medium mb-1">All caught up!</h3>
              <p className="text-muted-foreground">No transactions pending your signature.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {pending.map((tx) => (
              <SignatureCard key={tx.id} tx={tx} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
