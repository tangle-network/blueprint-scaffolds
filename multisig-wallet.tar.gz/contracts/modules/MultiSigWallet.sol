// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {PolicyEngine} from "./PolicyEngine.sol";
import {RecoveryModule} from "./RecoveryModule.sol";

interface IERC20 {
    function transfer(address to, uint256 amount) external returns (bool);
}

interface IERC721 {
    function safeTransferFrom(address from, address to, uint256 tokenId) external;
}

contract MultiSigWallet {
    enum ActionType {
        TransferETH,
        TransferERC20,
        TransferNFT,
        ContractCall,
        UpdateSigner
    }

    struct Transaction {
        address target;
        uint256 value;
        bytes data;
        ActionType actionType;
        uint256 executeAfter;
        bool executed;
        uint256 confirmations;
    }

    mapping(address => bool) public isSigner;
    mapping(bytes32 => Transaction) public transactions;
    mapping(bytes32 => mapping(address => bool)) public approvedBy;
    uint256 public signerCount;
    uint256 public threshold;
    PolicyEngine public immutable policyEngine;
    RecoveryModule public immutable recoveryModule;

    event TransactionProposed(bytes32 indexed txId, address indexed proposer, address indexed target, uint256 value);
    event TransactionConfirmed(bytes32 indexed txId, address indexed signer, uint256 confirmations);
    event TransactionExecuted(bytes32 indexed txId);
    event SignerUpdated(address indexed signer, bool approved);

    modifier onlySigner() {
        require(isSigner[msg.sender], "NOT_SIGNER");
        _;
    }

    constructor(
        address[] memory signers,
        uint256 signerThreshold,
        address policy,
        address recovery
    ) {
        require(signers.length > 0, "NO_SIGNERS");
        require(signerThreshold > 0 && signerThreshold <= signers.length, "BAD_THRESHOLD");
        for (uint256 i = 0; i < signers.length; i++) {
            isSigner[signers[i]] = true;
        }
        signerCount = signers.length;
        threshold = signerThreshold;
        policyEngine = PolicyEngine(policy);
        recoveryModule = RecoveryModule(recovery);
    }

    receive() external payable {}

    function propose(
        address target,
        uint256 value,
        bytes calldata data,
        ActionType actionType
    ) external onlySigner returns (bytes32 txId) {
        bytes4 selector = data.length >= 4 ? bytes4(data[:4]) : bytes4(0);
        bool isContractCall = actionType == ActionType.ContractCall;
        uint256 delay = policyEngine.validate(selector, value, isContractCall);
        txId = keccak256(abi.encode(target, value, data, actionType, block.timestamp, address(this)));
        transactions[txId] = Transaction({
            target: target,
            value: value,
            data: data,
            actionType: actionType,
            executeAfter: block.timestamp + delay,
            executed: false,
            confirmations: 0
        });
        emit TransactionProposed(txId, msg.sender, target, value);
    }

    function confirm(bytes32 txId) external onlySigner {
        Transaction storage txn = transactions[txId];
        require(txn.target != address(0), "UNKNOWN_TX");
        require(!txn.executed, "EXECUTED");
        require(!approvedBy[txId][msg.sender], "ALREADY_CONFIRMED");
        approvedBy[txId][msg.sender] = true;
        txn.confirmations += 1;
        emit TransactionConfirmed(txId, msg.sender, txn.confirmations);
    }

    function execute(bytes32 txId) external onlySigner {
        Transaction storage txn = transactions[txId];
        require(txn.target != address(0), "UNKNOWN_TX");
        require(!txn.executed, "EXECUTED");
        require(txn.confirmations >= threshold, "INSUFFICIENT_CONFIRMATIONS");
        require(block.timestamp >= txn.executeAfter, "TIMELOCKED");
        txn.executed = true;

        if (txn.actionType == ActionType.TransferERC20) {
            (address token, address to, uint256 amount) = abi.decode(txn.data, (address, address, uint256));
            require(IERC20(token).transfer(to, amount), "ERC20_FAILED");
        } else if (txn.actionType == ActionType.TransferNFT) {
            (address token, address to, uint256 tokenId) = abi.decode(txn.data, (address, address, uint256));
            IERC721(token).safeTransferFrom(address(this), to, tokenId);
        } else {
            (bool ok,) = txn.target.call{value: txn.value}(txn.data);
            require(ok, "CALL_FAILED");
        }

        emit TransactionExecuted(txId);
    }

    function addSigner(address signer) external {
        require(msg.sender == address(this), "ONLY_WALLET");
        require(!isSigner[signer], "SIGNER_EXISTS");
        isSigner[signer] = true;
        signerCount += 1;
        emit SignerUpdated(signer, true);
    }

    function removeSigner(address signer, address[] calldata guardianApprovals) external {
        require(msg.sender == address(this), "ONLY_WALLET");
        require(isSigner[signer], "UNKNOWN_SIGNER");
        require(signerCount - 1 >= threshold, "THRESHOLD_TOO_HIGH");
        bool recovered = recoveryModule.validateRecovery(guardianApprovals);
        require(recovered, "RECOVERY_NOT_APPROVED");
        isSigner[signer] = false;
        signerCount -= 1;
        recoveryModule.emitRecovery(signer, guardianApprovals.length);
        emit SignerUpdated(signer, false);
    }
}
