// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract RecoveryModule {
    mapping(address => bool) public isGuardian;
    uint256 public guardianThreshold;
    address public wallet;

    event WalletSet(address indexed walletAddress);
    event RecoveryTriggered(address indexed replacementSigner, uint256 approvals);

    modifier onlyWallet() {
        require(msg.sender == wallet, "NOT_WALLET");
        _;
    }

    constructor(address[] memory guardians, uint256 threshold) {
        require(threshold > 0 && threshold <= guardians.length, "BAD_THRESHOLD");
        guardianThreshold = threshold;
        for (uint256 i = 0; i < guardians.length; i++) {
            isGuardian[guardians[i]] = true;
        }
    }

    function setWallet(address walletAddress) external {
        require(wallet == address(0), "WALLET_SET");
        wallet = walletAddress;
        emit WalletSet(walletAddress);
    }

    function validateRecovery(address[] calldata approvals) external view onlyWallet returns (bool) {
        uint256 count;
        for (uint256 i = 0; i < approvals.length; i++) {
            if (isGuardian[approvals[i]]) {
                count++;
            }
        }
        return count >= guardianThreshold;
    }

    function emitRecovery(address replacementSigner, uint256 approvals) external onlyWallet {
        emit RecoveryTriggered(replacementSigner, approvals);
    }
}
