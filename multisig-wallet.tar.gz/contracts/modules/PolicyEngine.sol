// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract PolicyEngine {
    struct Policy {
        uint256 dailyLimit;
        uint256 timelock;
        bool contractCallsAllowed;
    }

    address public owner;
    mapping(bytes4 => Policy) public policies;

    event PolicyUpdated(bytes4 indexed selector, uint256 dailyLimit, uint256 timelock, bool contractCallsAllowed);
    event OwnershipTransferred(address indexed nextOwner);

    modifier onlyOwner() {
        require(msg.sender == owner, "NOT_OWNER");
        _;
    }

    constructor() {
        owner = msg.sender;
    }

    function transferOwnership(address nextOwner) external onlyOwner {
        require(nextOwner != address(0), "ZERO_OWNER");
        owner = nextOwner;
        emit OwnershipTransferred(nextOwner);
    }

    function setPolicy(bytes4 selector, uint256 dailyLimit, uint256 timelock, bool contractCallsAllowed) external onlyOwner {
        policies[selector] = Policy({
            dailyLimit: dailyLimit,
            timelock: timelock,
            contractCallsAllowed: contractCallsAllowed
        });
        emit PolicyUpdated(selector, dailyLimit, timelock, contractCallsAllowed);
    }

    function validate(bytes4 selector, uint256 amount, bool isContractCall) external view returns (uint256 delay) {
        Policy memory policy = policies[selector];
        if (policy.dailyLimit != 0) {
            require(amount <= policy.dailyLimit, "DAILY_LIMIT_EXCEEDED");
        }
        if (isContractCall) {
            require(policy.contractCallsAllowed, "CALL_BLOCKED");
        }
        return policy.timelock;
    }
}
