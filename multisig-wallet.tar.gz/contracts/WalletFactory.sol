// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {MultiSigWallet} from "./modules/MultiSigWallet.sol";
import {PolicyEngine} from "./modules/PolicyEngine.sol";
import {RecoveryModule} from "./modules/RecoveryModule.sol";

contract WalletFactory {
    event WalletCreated(address indexed wallet, address indexed policy, address indexed recovery, bytes32 salt);

    function createWallet(
        address[] calldata signers,
        uint256 threshold,
        address[] calldata guardians,
        uint256 guardianThreshold,
        bytes32 salt
    ) external returns (address wallet, address policy, address recovery) {
        PolicyEngine engine = new PolicyEngine{salt: salt}();
        RecoveryModule recoveryModule = new RecoveryModule{salt: keccak256(abi.encodePacked(salt, "RECOVERY"))}(
            guardians,
            guardianThreshold
        );
        MultiSigWallet instance = new MultiSigWallet{salt: keccak256(abi.encodePacked(salt, "WALLET"))}(
            signers,
            threshold,
            address(engine),
            address(recoveryModule)
        );

        engine.transferOwnership(address(instance));
        recoveryModule.setWallet(address(instance));

        emit WalletCreated(address(instance), address(engine), address(recoveryModule), salt);
        return (address(instance), address(engine), address(recoveryModule));
    }
}
