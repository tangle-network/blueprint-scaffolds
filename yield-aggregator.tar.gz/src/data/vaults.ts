import type { PortfolioPosition, Vault } from "../lib/types";

export const vaults: Vault[] = [
  {
    id: "atlas-usdc",
    name: "Atlas USDC Reserve",
    symbol: "aUSDC",
    type: "Single Asset",
    risk: "Conservative",
    chain: "Arbitrum",
    protocols: ["Aave", "Compound"],
    assets: ["USDC"],
    tvl: 18400000,
    tvlCap: 25000000,
    userCapacity: 920000,
    baseApy: 4.4,
    rewardApy: 1.2,
    healthScore: 96,
    gasPerHarvestUsd: 24,
    harvestEveryHours: 8,
    batchWindowMinutes: 45,
    mevProtected: true,
    emergencyWithdrawalReady: true,
    autoCompound: true,
    strategyNotes: "Routes idle stablecoins across Aave and Compound with threshold-based rebalances."
  },
  {
    id: "atlas-crveth",
    name: "Curve ETH/stETH Relay",
    symbol: "cETH",
    type: "LP Farming",
    risk: "Balanced",
    chain: "Ethereum",
    protocols: ["Curve", "Convex"],
    assets: ["ETH", "stETH", "CRV", "CVX"],
    tvl: 32700000,
    tvlCap: 40000000,
    userCapacity: 1300000,
    baseApy: 7.1,
    rewardApy: 6.4,
    healthScore: 88,
    gasPerHarvestUsd: 61,
    harvestEveryHours: 6,
    batchWindowMinutes: 60,
    mevProtected: true,
    emergencyWithdrawalReady: true,
    autoCompound: true,
    strategyNotes: "Auto-harvests CRV and CVX, then compounds via protected stable routing windows."
  },
  {
    id: "atlas-looped-eth",
    name: "Looped ETH Accelerator",
    symbol: "lETH",
    type: "Leveraged",
    risk: "Aggressive",
    chain: "Base",
    protocols: ["Aave", "Compound"],
    assets: ["WETH", "cbETH"],
    tvl: 9800000,
    tvlCap: 12000000,
    userCapacity: 410000,
    baseApy: 5.7,
    rewardApy: 2.9,
    leverage: 2.8,
    healthScore: 74,
    gasPerHarvestUsd: 43,
    harvestEveryHours: 4,
    batchWindowMinutes: 30,
    mevProtected: false,
    emergencyWithdrawalReady: true,
    autoCompound: true,
    strategyNotes: "Leverages ETH collateral with dynamic deleveraging triggers and TVL throttles."
  },
  {
    id: "atlas-dn-btc",
    name: "Delta Neutral BTC Basis",
    symbol: "dnBTC",
    type: "Delta Neutral",
    risk: "Balanced",
    chain: "Arbitrum",
    protocols: ["Curve", "Aave"],
    assets: ["WBTC", "tBTC", "USDC"],
    tvl: 14500000,
    tvlCap: 18000000,
    userCapacity: 640000,
    baseApy: 8.3,
    rewardApy: 3.5,
    leverage: 1.4,
    healthScore: 91,
    gasPerHarvestUsd: 37,
    harvestEveryHours: 12,
    batchWindowMinutes: 90,
    mevProtected: true,
    emergencyWithdrawalReady: false,
    autoCompound: true,
    strategyNotes: "Maintains hedge neutrality by pairing Curve LP exposure with borrow-side delta offsets."
  }
];

export const portfolioPositions: PortfolioPosition[] = [
  {
    vaultId: "atlas-usdc",
    depositedUsd: 42000,
    shareOfVault: 0.23,
    pendingRewardsUsd: 1280
  },
  {
    vaultId: "atlas-crveth",
    depositedUsd: 28500,
    shareOfVault: 0.09,
    pendingRewardsUsd: 1940
  },
  {
    vaultId: "atlas-dn-btc",
    depositedUsd: 15750,
    shareOfVault: 0.11,
    pendingRewardsUsd: 860
  }
];
