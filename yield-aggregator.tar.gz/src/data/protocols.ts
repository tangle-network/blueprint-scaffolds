import type { ProtocolIntegration } from "../lib/types";

export const protocolIntegrations: ProtocolIntegration[] = [
  {
    name: "Aave",
    category: "Lending",
    chain: "Arbitrum",
    baseApr: 4.2,
    rewardApr: 1.4,
    utilization: 72,
    auditStatus: "Battle Tested",
    mevProtection: "Flashbots"
  },
  {
    name: "Compound",
    category: "Lending",
    chain: "Ethereum",
    baseApr: 3.8,
    rewardApr: 0.9,
    utilization: 66,
    auditStatus: "Battle Tested",
    mevProtection: "Private RPC"
  },
  {
    name: "Curve",
    category: "Stable Swap",
    chain: "Base",
    baseApr: 6.1,
    rewardApr: 2.3,
    utilization: 81,
    auditStatus: "Battle Tested",
    mevProtection: "CoW Swap"
  },
  {
    name: "Convex",
    category: "Boosted Rewards",
    chain: "Ethereum",
    baseApr: 4.9,
    rewardApr: 5.1,
    utilization: 77,
    auditStatus: "Monitored",
    mevProtection: "Flashbots"
  }
];
