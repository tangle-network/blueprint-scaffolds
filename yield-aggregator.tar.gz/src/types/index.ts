export type VaultType = "single_asset" | "lp_farming" | "leveraged" | "delta_neutral";

export type Protocol = "aave" | "compound" | "curve" | "convex";

export type VaultStatus = "active" | "paused" | "withdraw_only" | "closed";

export interface Vault {
  id: string;
  name: string;
  type: VaultType;
  protocol: Protocol;
  asset: string;
  assetSymbol: string;
  assetDecimals: number;
  tvl: number;
  tvlCap: number;
  apy: number;
  baseApy: number;
  rewardApy: number;
  status: VaultStatus;
  autoHarvest: boolean;
  mevProtected: boolean;
  gasOptimized: boolean;
  emergencyWithdraw: boolean;
  lastHarvest: number;
  strategy: string;
  riskLevel: "low" | "medium" | "high";
}

export interface UserPosition {
  vaultId: string;
  deposited: number;
  shares: number;
  earned: number;
  depositedUsd: number;
  earnedUsd: number;
  depositDate: number;
}

export interface PortfolioSummary {
  totalDeposited: number;
  totalEarned: number;
  totalValue: number;
  weightedApy: number;
  positions: UserPosition[];
}

export interface APYHistoryPoint {
  date: string;
  apy: number;
  timestamp: number;
}

export interface GasEstimate {
  deposit: number;
  withdraw: number;
  harvest: number;
  compound: number;
}

export interface ProtocolInfo {
  name: string;
  icon: string;
  color: string;
  vaults: number;
  totalTvl: number;
}
