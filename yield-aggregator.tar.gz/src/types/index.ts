export type VaultType = 'single-asset' | 'lp-farming' | 'leveraged' | 'delta-neutral'
export type Protocol = 'aave' | 'compound' | 'curve' | 'convex'
export type RiskLevel = 'low' | 'medium' | 'high' | 'extreme'
export type VaultStatus = 'active' | 'paused' | 'withdrawn' | 'deprecated'
export type HarvestStatus = 'idle' | 'pending' | 'harvesting' | 'compounding' | 'completed' | 'failed'

export interface Vault {
  id: string
  name: string
  type: VaultType
  protocol: Protocol
  status: VaultStatus
  riskLevel: RiskLevel
  asset: string
  assetSymbol: string
  assetIcon: string
  decimals: number
  tvl: number
  tvlCap: number
  apy: number
  apyBase: number
  apyReward: number
  feePerformance: number
  feeWithdrawal: number
  lastHarvest: number
  harvestInterval: number
  autoCompound: boolean
  mevProtected: boolean
  gasOptimized: boolean
  strategyAddress: string
  vaultAddress: string
  createdAt: number
  description: string
}

export interface UserPosition {
  vaultId: string
  depositAmount: number
  depositValue: number
  currentAmount: number
  currentValue: number
  earnedAmount: number
  earnedValue: number
  depositDate: number
  lastCompoundDate: number
  shares: number
}

export interface PortfolioSummary {
  totalDeposited: number
  totalCurrentValue: number
  totalEarnings: number
  totalEarningsPercent: number
  dailyEarnings: number
  weeklyEarnings: number
  monthlyEarnings: number
  positions: UserPosition[]
}

export interface HarvestEvent {
  id: string
  vaultId: string
  status: HarvestStatus
  txHash: string
  profitUsd: number
  gasUsed: number
  gasCostUsd: number
  timestamp: number
  batchOperations: string[]
}

export interface APYHistoryPoint {
  timestamp: number
  apy: number
  tvl: number
}

export interface StrategyAllocation {
  protocol: Protocol
  allocation: number
  pool: string
  apy: number
}

export interface EmergencyWithdrawalRequest {
  vaultId: string
  amount: number
  requestedAt: number
  estimatedCompletion: number
  penaltyBps: number
  status: 'pending' | 'processing' | 'completed' | 'failed'
}

export interface GasOptimization {
  batchId: string
  operationsCount: number
  estimatedGasSaved: number
  estimatedGasSavedUsd: number
  operations: string[]
}

export interface MEVProtection {
  enabled: boolean
  privateRelay: string
  maxSlippageBps: number
  deadlineSeconds: number
}

export const PROTOCOL_COLORS: Record<Protocol, string> = {
  aave: '#B6509E',
  compound: '#00D395',
  curve: '#0000FF',
  convex: '#3A82F7',
}

export const PROTOCOL_NAMES: Record<Protocol, string> = {
  aave: 'Aave V3',
  compound: 'Compound V3',
  curve: 'Curve Finance',
  convex: 'Convex Finance',
}

export const VAULT_TYPE_LABELS: Record<VaultType, string> = {
  'single-asset': 'Single Asset',
  'lp-farming': 'LP Farming',
  'leveraged': 'Leveraged Strategy',
  'delta-neutral': 'Delta Neutral',
}

export const RISK_COLORS: Record<RiskLevel, string> = {
  low: 'text-emerald-400',
  medium: 'text-amber-400',
  high: 'text-orange-400',
  extreme: 'text-red-400',
}

export const RISK_BG: Record<RiskLevel, string> = {
  low: 'bg-emerald-500/20 text-emerald-400',
  medium: 'bg-amber-500/20 text-amber-400',
  high: 'bg-orange-500/20 text-orange-400',
  extreme: 'bg-red-500/20 text-red-400',
}
