import { Routes, Route } from "react-router-dom";
import { Layout } from "@/components/Layout";
import { Dashboard } from "@/pages/Dashboard";
import { VaultBrowser } from "@/pages/VaultBrowser";
import { VaultDetail } from "@/pages/VaultDetail";
import { Portfolio } from "@/pages/Portfolio";
import { APYComparison } from "@/pages/APYComparison";

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/vaults" element={<VaultBrowser />} />
        <Route path="/vaults/:id" element={<VaultDetail />} />
        <Route path="/portfolio" element={<Portfolio />} />
        <Route path="/compare" element={<APYComparison />} />
      </Route>
    </Routes>
  );
}
