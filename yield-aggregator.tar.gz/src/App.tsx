import { useMemo, useState } from "react";
import { ControlCenter } from "./components/ControlCenter";
import { Hero } from "./components/Hero";
import { APYComparison } from "./components/APYComparison";
import { PortfolioTracker } from "./components/PortfolioTracker";
import { ProtocolGrid } from "./components/ProtocolGrid";
import { SectionHeading } from "./components/SectionHeading";
import { VaultCard } from "./components/VaultCard";
import { portfolioPositions, vaults } from "./data/vaults";
import { protocolIntegrations } from "./data/protocols";
import { getProtocolComposite, getVaultMetrics } from "./lib/optimizer";

function App() {
  const [selectedVaultId, setSelectedVaultId] = useState(vaults[0].id);
  const selectedVault = vaults.find((vault) => vault.id === selectedVaultId) ?? vaults[0];

  const overview = useMemo(() => {
    const protocolComposite = getProtocolComposite(protocolIntegrations);
    const bestApy = Math.max(...vaults.map((vault) => getVaultMetrics(vault).optimizedApy));
    const totalTvl = vaults.reduce((sum, vault) => sum + vault.tvl, 0);

    return {
      bestApy,
      totalTvl,
      protectedVolume: totalTvl * 0.74,
      protocolComposite
    };
  }, []);

  return (
    <div className="app-shell">
      <div className="ambient ambient-left" />
      <div className="ambient ambient-right" />
      <main className="page">
        <Hero
          totalTvl={overview.totalTvl}
          bestApy={overview.bestApy}
          protectedVolume={overview.protectedVolume}
        />

        <section className="dashboard-grid">
          <div className="panel">
            <SectionHeading
              eyebrow="Vault Browser"
              title="Strategy-aware vault routing"
              description="Compare single asset, LP, leveraged, and delta-neutral vaults using net yield, cap pressure, and execution risk."
            />
            <div className="vault-list">
              {vaults.map((vault) => (
                <VaultCard
                  key={vault.id}
                  vault={vault}
                  isActive={selectedVaultId === vault.id}
                  onSelect={setSelectedVaultId}
                />
              ))}
            </div>
          </div>

          <ControlCenter vault={selectedVault} />
        </section>

        <section className="two-column">
          <div className="panel">
            <SectionHeading
              eyebrow="APY Comparison"
              title="Net yield after gas and routing effects"
              description="Optimizer scores include compounding lift, batch gas savings, and MEV-protection assumptions."
            />
            <APYComparison vaults={vaults} />
          </div>

          <div className="panel">
            <SectionHeading
              eyebrow="Protocol Coverage"
              title="Integrated liquidity venues"
              description={`Composite base APR ${overview.protocolComposite.baseApr.toFixed(
                1
              )}% with ${overview.protocolComposite.rewardApr.toFixed(1)}% rewards across active adapters.`}
            />
            <ProtocolGrid protocols={protocolIntegrations} />
          </div>
        </section>

        <section className="panel">
          <SectionHeading
            eyebrow="Portfolio Tracker"
            title="Position-level monitoring"
            description="Track deposits, pending rewards, and emergency readiness across aggregated positions."
          />
          <PortfolioTracker vaults={vaults} positions={portfolioPositions} />
        </section>
      </main>
    </div>
  );
}

export default App;
