export const ERC20_ABI = [
  'function approve(address spender, uint256 amount) external returns (bool)',
  'function allowance(address owner, address spender) external view returns (uint256)',
  'function balanceOf(address account) external view returns (uint256)',
  'function transfer(address to, uint256 amount) external returns (bool)',
  'function decimals() external view returns (uint8)',
  'function symbol() external view returns (string)',
] as const

export const VAULT_ABI = [
  'function deposit(uint256 amount) external',
  'function withdraw(uint256 shares) external',
  'function emergencyWithdraw() external',
  'function harvest() external',
  'function compound() external',
  'function balanceOf(address account) external view returns (uint256)',
  'function totalSupply() external view returns (uint256)',
  'function totalAssets() external view returns (uint256)',
  'function convertToAssets(uint256 shares) external view returns (uint256)',
  'function convertToShares(uint256 assets) external view returns (uint256)',
  'function tvlCap() external view returns (uint256)',
  'function performanceFee() external view returns (uint256)',
  'function withdrawalFee() external view returns (uint256)',
  'function lastHarvestTimestamp() external view returns (uint256)',
  'function harvestInterval() external view returns (uint256)',
  'function autoCompoundEnabled() external view returns (bool)',
  'function mevProtectionEnabled() external view returns (bool)',
  'function paused() external view returns (bool)',
  'event Deposit(address indexed user, uint256 amount, uint256 shares)',
  'event Withdraw(address indexed user, uint256 amount, uint256 shares)',
  'event Harvest(address indexed caller, uint256 profit, uint256 loss)',
  'event Compound(address indexed caller, uint256 amount)',
  'event EmergencyWithdraw(address indexed user, uint256 amount)',
] as const

export const STRATEGY_ABI = [
  'function harvest() external returns (uint256)',
  'function compound() external returns (uint256)',
  'function estimatedTotalAssets() external view returns (uint256)',
  'function tend() external',
  'function migrate(address newStrategy) external',
  'function delegatedAssets() external view returns (uint256)',
  'function emergencyExit() external view returns (bool)',
  'function isActive() external view returns (bool)',
  'function name() external view returns (string)',
] as const

export const HARVEST_BATCHER_ABI = [
  'function batchHarvest(address[] calldata vaults) external',
  'function batchCompound(address[] calldata vaults) external',
  'function estimateBatchGas(address[] calldata vaults) external view returns (uint256)',
  'function maxBatchSize() external view returns (uint256)',
] as const

export const MEV_PROTECT_ABI = [
  'function protectedSwap(address tokenIn, address tokenOut, uint256 amountIn, uint256 minAmountOut, uint256 deadline) external returns (uint256)',
  'function getExpectedOutput(address tokenIn, address tokenOut, uint256 amountIn) external view returns (uint256)',
] as const
