import { useState, useEffect } from "react";
import type { APYHistoryPoint } from "@/types";
import { getAPYHistory } from "@/lib/data";

export function useYield(vaultId: string | undefined) {
  const [history, setHistory] = useState<APYHistoryPoint[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!vaultId) return;
    setLoading(true);
    const data = getAPYHistory(vaultId);
    setHistory(data);
    setLoading(false);
  }, [vaultId]);

  return { history, loading };
}
