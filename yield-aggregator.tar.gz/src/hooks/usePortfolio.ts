import { useState, useEffect } from "react";
import type { PortfolioSummary, UserPosition } from "@/types";
import { getPortfolioSummary, getUserPositions, getVaultById } from "@/lib/data";

export function usePortfolio() {
  const [summary, setSummary] = useState<PortfolioSummary>({
    totalDeposited: 0,
    totalEarned: 0,
    totalValue: 0,
    weightedApy: 0,
    positions: [],
  });
  const [positions, setPositions] = useState<UserPosition[]>([]);

  useEffect(() => {
    setSummary(getPortfolioSummary());
    const pos = getUserPositions().map((p) => ({
      ...p,
      vault: getVaultById(p.vaultId),
    }));
    setPositions(pos as (UserPosition & { vault: ReturnType<typeof getVaultById> })[]);
  }, []);

  return { summary, positions };
}
