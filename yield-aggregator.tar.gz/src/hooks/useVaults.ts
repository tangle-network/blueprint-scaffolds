import { useState, useEffect, useMemo } from "react";
import type { Vault, VaultType, Protocol } from "@/types";
import { getVaults } from "@/lib/data";

export function useVaults() {
  const [vaults, setVaults] = useState<Vault[]>([]);
  const [typeFilter, setTypeFilter] = useState<VaultType | "all">("all");
  const [protocolFilter, setProtocolFilter] = useState<Protocol | "all">("all");
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState<"apy" | "tvl" | "name">("apy");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");

  useEffect(() => {
    setVaults(getVaults());
  }, []);

  const filtered = useMemo(() => {
    let result = vaults;
    if (typeFilter !== "all") result = result.filter((v) => v.type === typeFilter);
    if (protocolFilter !== "all") result = result.filter((v) => v.protocol === protocolFilter);
    if (search) {
      const q = search.toLowerCase();
      result = result.filter(
        (v) => v.name.toLowerCase().includes(q) || v.assetSymbol.toLowerCase().includes(q)
      );
    }
    result = [...result].sort((a, b) => {
      let cmp = 0;
      if (sortBy === "apy") cmp = a.apy - b.apy;
      else if (sortBy === "tvl") cmp = a.tvl - b.tvl;
      else cmp = a.name.localeCompare(b.name);
      return sortDir === "desc" ? -cmp : cmp;
    });
    return result;
  }, [vaults, typeFilter, protocolFilter, search, sortBy, sortDir]);

  return { vaults: filtered, typeFilter, setTypeFilter, protocolFilter, setProtocolFilter, search, setSearch, sortBy, setSortBy, sortDir, setSortDir };
}
