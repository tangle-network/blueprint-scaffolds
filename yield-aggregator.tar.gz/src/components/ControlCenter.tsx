import { formatCompactUsd, formatPercent, formatUsd } from "../lib/format";
import { getVaultMetrics } from "../lib/optimizer";
import type { Vault } from "../lib/types";

interface ControlCenterProps {
  vault: Vault;
}

export function ControlCenter({ vault }: ControlCenterProps) {
  const metrics = getVaultMetrics(vault);

  return (
    <section className="control-panel">
      <div className="control-panel-header">
        <div>
          <span className="eyebrow">Strategy Control</span>
          <h2>{vault.name}</h2>
          <p>{vault.strategyNotes}</p>
        </div>
        <div className="header-pill">{vault.assets.join(" · ")}</div>
      </div>
      <div className="control-stats">
        <article>
          <span>Current TVL</span>
          <strong>{formatCompactUsd(vault.tvl)}</strong>
          <small>{formatPercent(metrics.capUsage)} of cap utilized</small>
        </article>
        <article>
          <span>User capacity</span>
          <strong>{formatCompactUsd(vault.userCapacity)}</strong>
          <small>Admission control before cap throttling</small>
        </article>
        <article>
          <span>Health buffer</span>
          <strong>{formatPercent(metrics.safetyBuffer)}</strong>
          <small>{vault.leverage ? `${vault.leverage.toFixed(1)}x leverage active` : "Unlevered vault"}</small>
        </article>
        <article>
          <span>Harvest gas budget</span>
          <strong>{formatUsd(metrics.annualGasCost)}</strong>
          <small>{metrics.harvestsPerYear.toFixed(0)} batched harvests per year</small>
        </article>
      </div>
      <div className="control-rail">
        <div>
          <span>Auto-harvest & compound</span>
          <strong>{vault.autoCompound ? "Enabled" : "Disabled"}</strong>
        </div>
        <div>
          <span>MEV protection</span>
          <strong>{vault.mevProtected ? "Private execution" : "Upgrade recommended"}</strong>
        </div>
        <div>
          <span>Emergency withdrawal</span>
          <strong>{vault.emergencyWithdrawalReady ? "Ready" : "Cooldown path active"}</strong>
        </div>
      </div>
    </section>
  );
}
