import clsx from "clsx";
import { AlertTriangle, ArrowUpRight, Shield, Timer } from "lucide-react";
import { formatCompactUsd, formatPercent, formatUsd } from "../lib/format";
import { getVaultMetrics } from "../lib/optimizer";
import type { Vault } from "../lib/types";

interface VaultCardProps {
  vault: Vault;
  isActive: boolean;
  onSelect: (vaultId: string) => void;
}

export function VaultCard({ vault, isActive, onSelect }: VaultCardProps) {
  const metrics = getVaultMetrics(vault);

  return (
    <button className={clsx("vault-card", isActive && "active")} onClick={() => onSelect(vault.id)}>
      <div className="vault-card-top">
        <div>
          <span className="vault-symbol">{vault.symbol}</span>
          <h3>{vault.name}</h3>
        </div>
        <span className={clsx("risk-pill", vault.risk.toLowerCase())}>{vault.risk}</span>
      </div>
      <div className="vault-type-row">
        <span>{vault.type}</span>
        <span>{vault.chain}</span>
      </div>
      <div className="vault-grid">
        <div>
          <span>Optimized APY</span>
          <strong>{formatPercent(metrics.optimizedApy)}</strong>
        </div>
        <div>
          <span>TVL / Cap</span>
          <strong>
            {formatCompactUsd(vault.tvl)} / {formatCompactUsd(vault.tvlCap)}
          </strong>
        </div>
        <div>
          <span>Harvest cadence</span>
          <strong>Every {vault.harvestEveryHours}h</strong>
        </div>
        <div>
          <span>Batch gas</span>
          <strong>{formatUsd(metrics.annualGasCost)}</strong>
        </div>
      </div>
      <div className="vault-badges">
        <span>
          <Shield size={14} />
          {vault.mevProtected ? "MEV shielded" : "Public routing"}
        </span>
        <span>
          <Timer size={14} />
          {vault.batchWindowMinutes} min batch
        </span>
        <span>
          {vault.emergencyWithdrawalReady ? <ArrowUpRight size={14} /> : <AlertTriangle size={14} />}
          {vault.emergencyWithdrawalReady ? "Emergency exit ready" : "Exit queued"}
        </span>
      </div>
    </button>
  );
}
