import type { Vault } from "@/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { ProtocolBadge, RiskBadge, VaultTypeBadge } from "@/components/Badges";
import { formatCurrency, formatPercent, timeAgo } from "@/lib/utils";
import { TrendingUp, Clock, Shield, Zap, Swords } from "lucide-react";
import { Link } from "react-router-dom";

export function VaultCard({ vault }: { vault: Vault }) {
  const tvlPct = Math.round((vault.tvl / vault.tvlCap) * 100);
  return (
    <Link to={`/vaults/${vault.id}`}>
      <Card className="hover:border-primary/50 transition-colors cursor-pointer h-full">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="text-base">{vault.name}</CardTitle>
              <div className="flex items-center gap-2 mt-1">
                <ProtocolBadge protocol={vault.protocol} />
                <VaultTypeBadge type={vault.type} />
              </div>
            </div>
            <RiskBadge risk={vault.riskLevel} />
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">APY</span>
            <span className="text-lg font-bold text-primary flex items-center gap-1">
              <TrendingUp className="h-4 w-4" />
              {formatPercent(vault.apy)}
            </span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">TVL</span>
            <span className="font-medium">{formatCurrency(vault.tvl)}</span>
          </div>
          <div className="space-y-1">
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Capacity</span>
              <span>{tvlPct}%</span>
            </div>
            <Progress value={tvlPct} className="h-1.5" />
          </div>
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Clock className="h-3 w-3" />
            <span>Harvested {timeAgo(vault.lastHarvest)}</span>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {vault.autoHarvest && (
              <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                <Zap className="h-2.5 w-2.5 mr-0.5" />
                Auto-compound
              </Badge>
            )}
            {vault.mevProtected && (
              <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                <Shield className="h-2.5 w-2.5 mr-0.5" />
                MEV Protected
              </Badge>
            )}
            {vault.gasOptimized && (
              <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                <Zap className="h-2.5 w-2.5 mr-0.5" />
                Gas Optimized
              </Badge>
            )}
            {vault.emergencyWithdraw && (
              <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                <Swords className="h-2.5 w-2.5 mr-0.5" />
                Emergency Exit
              </Badge>
            )}
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
