import { formatPercent } from "../lib/format";
import { getVaultMetrics } from "../lib/optimizer";
import type { Vault } from "../lib/types";

interface APYComparisonProps {
  vaults: Vault[];
}

export function APYComparison({ vaults }: APYComparisonProps) {
  const sortedVaults = [...vaults].sort(
    (left, right) => getVaultMetrics(right).optimizedApy - getVaultMetrics(left).optimizedApy
  );

  return (
    <div className="comparison-table">
      {sortedVaults.map((vault) => {
        const metrics = getVaultMetrics(vault);
        const width = Math.min(metrics.optimizedApy * 6.5, 100);

        return (
          <div className="comparison-row" key={vault.id}>
            <div>
              <strong>{vault.name}</strong>
              <span>
                {vault.type} · {vault.protocols.join(" / ")}
              </span>
            </div>
            <div className="apy-bar-wrap">
              <div className="apy-bar" style={{ width: `${width}%` }} />
            </div>
            <strong>{formatPercent(metrics.optimizedApy)}</strong>
          </div>
        );
      })}
    </div>
  );
}
