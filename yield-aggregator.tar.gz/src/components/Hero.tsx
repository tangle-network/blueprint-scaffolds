import { ShieldCheck, TrendingUp, Zap } from "lucide-react";
import { formatCompactUsd, formatPercent } from "../lib/format";

interface HeroProps {
  totalTvl: number;
  bestApy: number;
  protectedVolume: number;
}

export function Hero({ totalTvl, bestApy, protectedVolume }: HeroProps) {
  return (
    <section className="hero-panel">
      <div className="hero-copy">
        <span className="eyebrow">Atlas Yield Router</span>
        <h1>Automated DeFi optimization for vaults that cannot afford idle capital.</h1>
        <p>
          Single-asset, LP farming, leveraged, and delta-neutral vaults with auto-compounding,
          gas-aware batching, MEV-protected swaps, TVL caps, and emergency exits.
        </p>
      </div>
      <div className="hero-metrics">
        <article>
          <ShieldCheck size={20} />
          <span>Protected flow</span>
          <strong>{formatCompactUsd(protectedVolume)}</strong>
        </article>
        <article>
          <TrendingUp size={20} />
          <span>Best optimized APY</span>
          <strong>{formatPercent(bestApy)}</strong>
        </article>
        <article>
          <Zap size={20} />
          <span>Total TVL managed</span>
          <strong>{formatCompactUsd(totalTvl)}</strong>
        </article>
      </div>
    </section>
  );
}
