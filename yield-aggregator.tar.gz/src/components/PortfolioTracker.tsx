import { formatPercent, formatUsd } from "../lib/format";
import { getPortfolioSummary, getVaultMetrics } from "../lib/optimizer";
import type { PortfolioPosition, Vault } from "../lib/types";

interface PortfolioTrackerProps {
  vaults: Vault[];
  positions: PortfolioPosition[];
}

export function PortfolioTracker({ vaults, positions }: PortfolioTrackerProps) {
  const summary = getPortfolioSummary(vaults, positions);

  return (
    <div className="portfolio-grid">
      <div className="portfolio-summary">
        <span className="eyebrow">Portfolio</span>
        <h3>{formatUsd(summary.depositedUsd)} deployed</h3>
        <p>
          Pending rewards {formatUsd(summary.pendingRewardsUsd)} with projected annualized yield of{" "}
          {formatUsd(summary.projectedAnnualYieldUsd)}.
        </p>
        <div className="summary-chip-row">
          <span>{summary.emergencyReadyCount} vaults exit-ready</span>
          <span>{positions.length} active allocations</span>
        </div>
      </div>
      <div className="portfolio-positions">
        {positions.map((position) => {
          const vault = vaults.find((item) => item.id === position.vaultId);
          if (!vault) {
            return null;
          }

          const metrics = getVaultMetrics(vault);

          return (
            <article key={position.vaultId} className="position-card">
              <div>
                <strong>{vault.symbol}</strong>
                <span>{vault.name}</span>
              </div>
              <div>
                <span>Deposited</span>
                <strong>{formatUsd(position.depositedUsd)}</strong>
              </div>
              <div>
                <span>Optimized APY</span>
                <strong>{formatPercent(metrics.optimizedApy)}</strong>
              </div>
              <div>
                <span>Vault share</span>
                <strong>{formatPercent(position.shareOfVault)}</strong>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
