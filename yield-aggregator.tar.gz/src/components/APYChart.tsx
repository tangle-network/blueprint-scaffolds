import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from "recharts";
import type { APYHistoryPoint } from "@/types";

export function APYChart({ data, height = 300 }: { data: APYHistoryPoint[]; height?: number }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={data} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
        <defs>
          <linearGradient id="apyGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="hsl(142,76%,36%)" stopOpacity={0.3} />
            <stop offset="95%" stopColor="hsl(142,76%,36%)" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(240,3.7%,15.9%)" />
        <XAxis
          dataKey="date"
          tick={{ fontSize: 11, fill: "hsl(240,5%,64.9%)" }}
          tickFormatter={(v: string) => v.slice(5)}
        />
        <YAxis
          tick={{ fontSize: 11, fill: "hsl(240,5%,64.9%)" }}
          tickFormatter={(v: number) => `${v.toFixed(1)}%`}
          domain={["auto", "auto"]}
        />
        <Tooltip
          contentStyle={{
            backgroundColor: "hsl(240,10%,3.9%)",
            border: "1px solid hsl(240,3.7%,15.9%)",
            borderRadius: "6px",
            fontSize: 12,
          }}
          formatter={(value: number) => [`${value.toFixed(2)}%`, "APY"]}
        />
        <Area
          type="monotone"
          dataKey="apy"
          stroke="hsl(142,76%,36%)"
          fill="url(#apyGradient)"
          strokeWidth={2}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function MultiAPYChart({
  datasets,
  height = 400,
}: {
  datasets: { name: string; data: APYHistoryPoint[]; color: string }[];
  height?: number;
}) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(240,3.7%,15.9%)" />
        <XAxis
          dataKey="date"
          tick={{ fontSize: 11, fill: "hsl(240,5%,64.9%)" }}
          tickFormatter={(v: string) => v.slice(5)}
        />
        <YAxis
          tick={{ fontSize: 11, fill: "hsl(240,5%,64.9%)" }}
          tickFormatter={(v: number) => `${v.toFixed(1)}%`}
          domain={["auto", "auto"]}
        />
        <Tooltip
          contentStyle={{
            backgroundColor: "hsl(240,10%,3.9%)",
            border: "1px solid hsl(240,3.7%,15.9%)",
            borderRadius: "6px",
            fontSize: 12,
          }}
          formatter={(value: number, name: string) => [`${value.toFixed(2)}%`, name]}
        />
        {datasets.map((ds) => (
          <Line
            key={ds.name}
            data={ds.data}
            type="monotone"
            dataKey="apy"
            name={ds.name}
            stroke={ds.color}
            strokeWidth={2}
            dot={false}
          />
        ))}
      </LineChart>
    </ResponsiveContainer>
  );
}
