import type { Vault, UserPosition } from "@/types";
import { getVaultById } from "@/lib/data";
import { formatCurrency, formatPercent } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ProtocolBadge, RiskBadge } from "@/components/Badges";
import { TrendingUp, ArrowUpRight } from "lucide-react";
import { Link } from "react-router-dom";

export function PositionRow({ position }: { position: UserPosition }) {
  const vault = getVaultById(position.vaultId);
  if (!vault) return null;

  const pnlPct = ((position.earnedUsd / position.depositedUsd) * 100).toFixed(2);

  return (
    <Link to={`/vaults/${vault.id}`}>
      <Card className="hover:border-primary/50 transition-colors cursor-pointer mb-3">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="text-left">
                <div className="font-medium text-sm flex items-center gap-2">
                  {vault.name}
                  <ProtocolBadge protocol={vault.protocol} />
                  <RiskBadge risk={vault.riskLevel} />
                </div>
                <div className="text-xs text-muted-foreground mt-1">
                  Deposited: {formatCurrency(position.depositedUsd)} {vault.assetSymbol}
                </div>
              </div>
            </div>
            <div className="text-right flex items-center gap-4">
              <div>
                <div className="text-sm font-medium text-primary flex items-center gap-1">
                  <TrendingUp className="h-3.5 w-3.5" />
                  {formatCurrency(position.earnedUsd)}
                </div>
                <div className="text-xs text-muted-foreground">
                  +{pnlPct}% return
                </div>
              </div>
              <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}

export function PortfolioOverview({
  summary,
}: {
  summary: { totalDeposited: number; totalEarned: number; totalValue: number; weightedApy: number };
}) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
      <Card>
        <CardContent className="p-4">
          <div className="text-sm text-muted-foreground">Total Deposited</div>
          <div className="text-2xl font-bold">{formatCurrency(summary.totalDeposited)}</div>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="p-4">
          <div className="text-sm text-muted-foreground">Total Earned</div>
          <div className="text-2xl font-bold text-primary">{formatCurrency(summary.totalEarned)}</div>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="p-4">
          <div className="text-sm text-muted-foreground">Portfolio Value</div>
          <div className="text-2xl font-bold">{formatCurrency(summary.totalValue)}</div>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="p-4">
          <div className="text-sm text-muted-foreground">Weighted APY</div>
          <div className="text-2xl font-bold text-primary">{formatPercent(summary.weightedApy)}</div>
        </CardContent>
      </Card>
    </div>
  );
}
