import { getProtocolInfo } from "@/lib/data";
import type { Protocol } from "@/types";
import { cn } from "@/lib/utils";

const protocolNames: Record<Protocol, string> = {
  aave: "Aave",
  compound: "Compound",
  curve: "Curve",
  convex: "Convex",
};

export function ProtocolBadge({ protocol }: { protocol: Protocol }) {
  const info = getProtocolInfo(protocol);
  return (
    <span
      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium"
      style={{
        backgroundColor: `${info?.color ?? "#666"}20`,
        color: info?.color ?? "#999",
      }}
    >
      <span
        className="w-3 h-3 rounded-full flex items-center justify-center text-[8px] font-bold"
        style={{ backgroundColor: info?.color ?? "#666", color: "#fff" }}
      >
        {info?.icon}
      </span>
      {protocolNames[protocol]}
    </span>
  );
}

const riskColors = {
  low: "text-green-400 bg-green-400/10",
  medium: "text-yellow-400 bg-yellow-400/10",
  high: "text-red-400 bg-red-400/10",
};

export function RiskBadge({ risk }: { risk: "low" | "medium" | "high" }) {
  return (
    <span className={cn("px-2 py-0.5 rounded-full text-xs font-medium capitalize", riskColors[risk])}>
      {risk} risk
    </span>
  );
}

const typeLabels: Record<string, string> = {
  single_asset: "Single Asset",
  lp_farming: "LP Farming",
  leveraged: "Leveraged",
  delta_neutral: "Delta-Neutral",
};

export function VaultTypeBadge({ type }: { type: string }) {
  return (
    <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-secondary text-secondary-foreground">
      {typeLabels[type] ?? type}
    </span>
  );
}
