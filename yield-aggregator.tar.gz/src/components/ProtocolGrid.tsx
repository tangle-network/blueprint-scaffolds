import { formatPercent } from "../lib/format";
import type { ProtocolIntegration } from "../lib/types";

interface ProtocolGridProps {
  protocols: ProtocolIntegration[];
}

export function ProtocolGrid({ protocols }: ProtocolGridProps) {
  return (
    <div className="protocol-grid">
      {protocols.map((protocol) => (
        <article className="protocol-card" key={protocol.name}>
          <div className="protocol-card-top">
            <div>
              <span className="eyebrow">{protocol.category}</span>
              <h3>{protocol.name}</h3>
            </div>
            <span>{protocol.chain}</span>
          </div>
          <div className="protocol-stats">
            <div>
              <span>Base APR</span>
              <strong>{formatPercent(protocol.baseApr)}</strong>
            </div>
            <div>
              <span>Reward APR</span>
              <strong>{formatPercent(protocol.rewardApr)}</strong>
            </div>
            <div>
              <span>Utilization</span>
              <strong>{formatPercent(protocol.utilization)}</strong>
            </div>
            <div>
              <span>Routing</span>
              <strong>{protocol.mevProtection}</strong>
            </div>
          </div>
        </article>
      ))}
    </div>
  );
}
