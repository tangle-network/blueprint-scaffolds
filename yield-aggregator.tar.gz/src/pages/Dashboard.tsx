import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { VaultCard } from "@/components/VaultCard";
import { PortfolioOverview } from "@/components/PortfolioComponents";
import { usePortfolio } from "@/hooks/usePortfolio";
import { useVaults } from "@/hooks/useVaults";
import { getProtocols, getTotalTVL } from "@/lib/data";
import { formatCurrency, formatPercent } from "@/lib/utils";
import { TrendingUp, DollarSign, Vault, Activity, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

export function Dashboard() {
  const { summary } = usePortfolio();
  const { vaults } = useVaults();
  const protocols = getProtocols();
  const totalTVL = getTotalTVL();
  const topVaults = [...vaults].sort((a, b) => b.apy - a.apy).slice(0, 4);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground mt-1">DeFi yield optimization overview</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <DollarSign className="h-5 w-5 text-primary" />
            </div>
            <div>
              <div className="text-sm text-muted-foreground">Total TVL</div>
              <div className="text-xl font-bold">{formatCurrency(totalTVL)}</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Vault className="h-5 w-5 text-primary" />
            </div>
            <div>
              <div className="text-sm text-muted-foreground">Active Vaults</div>
              <div className="text-xl font-bold">{vaults.length}</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <TrendingUp className="h-5 w-5 text-primary" />
            </div>
            <div>
              <div className="text-sm text-muted-foreground">Avg APY</div>
              <div className="text-xl font-bold">
                {formatPercent(vaults.reduce((s, v) => s + v.apy, 0) / vaults.length)}
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Activity className="h-5 w-5 text-primary" />
            </div>
            <div>
              <div className="text-sm text-muted-foreground">Protocols</div>
              <div className="text-xl font-bold">{protocols.length}</div>
            </div>
          </CardContent>
        </Card>
      </div>

      <PortfolioOverview summary={summary} />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg">Protocols</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {protocols.map((p) => (
                <div key={p.name} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white"
                      style={{ backgroundColor: p.color }}
                    >
                      {p.icon}
                    </div>
                    <div>
                      <div className="text-sm font-medium">{p.name}</div>
                      <div className="text-xs text-muted-foreground">{p.vaults} vaults</div>
                    </div>
                  </div>
                  <span className="text-sm font-medium">{formatCurrency(p.totalTvl)}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg">Top Yield Vaults</CardTitle>
            <Link to="/vaults" className="text-sm text-primary flex items-center gap-1 hover:underline">
              View all <ArrowRight className="h-3 w-3" />
            </Link>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {topVaults.map((v) => (
                <Link key={v.id} to={`/vaults/${v.id}`} className="block">
                  <div className="flex items-center justify-between py-2 hover:bg-accent/50 rounded px-2 -mx-2 transition-colors">
                    <div>
                      <div className="text-sm font-medium">{v.name}</div>
                      <div className="text-xs text-muted-foreground">{v.assetSymbol}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-bold text-primary">{formatPercent(v.apy)}</div>
                      <div className="text-xs text-muted-foreground">{formatCurrency(v.tvl)}</div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
