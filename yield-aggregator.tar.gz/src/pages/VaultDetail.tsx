import { useParams, Link } from "react-router-dom";
import { getVaultById, getUserPositions } from "@/lib/data";
import { useYield } from "@/hooks/useYield";
import { APYChart } from "@/components/APYChart";
import { ProtocolBadge, RiskBadge, VaultTypeBadge } from "@/components/Badges";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { formatCurrency, formatPercent, timeAgo } from "@/lib/utils";
import {
  TrendingUp,
  ArrowLeft,
  Clock,
  Shield,
  Zap,
  Swords,
  AlertTriangle,
  PieChart,
  Wallet,
} from "lucide-react";

export function VaultDetail() {
  const { id } = useParams<{ id: string }>();
  const vault = getVaultById(id ?? "");
  const { history } = useYield(vault?.id);
  const positions = getUserPositions();
  const userPosition = positions.find((p) => p.vaultId === vault?.id);

  if (!vault) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold">Vault not found</h2>
        <Link to="/vaults" className="text-primary hover:underline mt-2 inline-block">
          Back to vaults
        </Link>
      </div>
    );
  }

  const tvlPct = Math.round((vault.tvl / vault.tvlCap) * 100);

  return (
    <div className="space-y-6">
      <Link to="/vaults" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" />
        Back to vaults
      </Link>

      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold">{vault.name}</h1>
          <div className="flex items-center gap-2 mt-2">
            <ProtocolBadge protocol={vault.protocol} />
            <VaultTypeBadge type={vault.type} />
            <RiskBadge risk={vault.riskLevel} />
          </div>
        </div>
        <div className="text-right">
          <div className="text-sm text-muted-foreground">Current APY</div>
          <div className="text-4xl font-bold text-primary flex items-center gap-2">
            <TrendingUp className="h-8 w-8" />
            {formatPercent(vault.apy)}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">APY History (30d)</CardTitle>
            </CardHeader>
            <CardContent>
              <APYChart data={history} height={300} />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Strategy</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-muted-foreground">{vault.strategy}</p>
              <Separator />
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-sm text-muted-foreground">Base APY</div>
                  <div className="text-lg font-medium">{formatPercent(vault.baseApy)}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Reward APY</div>
                  <div className="text-lg font-medium text-primary">{formatPercent(vault.rewardApy)}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Features</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                {vault.autoHarvest && (
                  <div className="flex items-center gap-2 text-sm">
                    <Zap className="h-4 w-4 text-primary" />
                    Auto-compound enabled
                  </div>
                )}
                {vault.mevProtected && (
                  <div className="flex items-center gap-2 text-sm">
                    <Shield className="h-4 w-4 text-primary" />
                    MEV-protected swaps
                  </div>
                )}
                {vault.gasOptimized && (
                  <div className="flex items-center gap-2 text-sm">
                    <Zap className="h-4 w-4 text-primary" />
                    Gas-optimized batching
                  </div>
                )}
                {vault.emergencyWithdraw && (
                  <div className="flex items-center gap-2 text-sm">
                    <Swords className="h-4 w-4 text-primary" />
                    Emergency withdrawal
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Vault Info</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">TVL</span>
                <span className="font-medium">{formatCurrency(vault.tvl)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">TVL Cap</span>
                <span className="font-medium">{formatCurrency(vault.tvlCap)}</span>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Capacity</span>
                  <span>{tvlPct}%</span>
                </div>
                <Progress value={tvlPct} className="h-2" />
              </div>
              <Separator />
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Asset</span>
                <span className="font-medium">{vault.assetSymbol}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Status</span>
                <Badge variant={vault.status === "active" ? "default" : "secondary"}>
                  {vault.status}
                </Badge>
              </div>
              <div className="flex items-center gap-1 text-sm">
                <Clock className="h-3.5 w-3.5 text-muted-foreground" />
                <span className="text-muted-foreground">Last harvest: {timeAgo(vault.lastHarvest)}</span>
              </div>
            </CardContent>
          </Card>

          {userPosition ? (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Wallet className="h-5 w-5" />
                  Your Position
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Deposited</span>
                  <span className="font-medium">{formatCurrency(userPosition.depositedUsd)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Earned</span>
                  <span className="font-medium text-primary">{formatCurrency(userPosition.earnedUsd)}</span>
                </div>
                <Separator />
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Return</span>
                  <span className="font-medium text-primary">
                    +{((userPosition.earnedUsd / userPosition.depositedUsd) * 100).toFixed(2)}%
                  </span>
                </div>
                <div className="flex gap-2 mt-4">
                  <Button className="flex-1">Deposit</Button>
                  <Button variant="outline" className="flex-1">Withdraw</Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="p-6 text-center space-y-4">
                <PieChart className="h-12 w-12 text-muted-foreground mx-auto" />
                <p className="text-sm text-muted-foreground">You have no position in this vault</p>
                <Button className="w-full">Deposit {vault.assetSymbol}</Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
