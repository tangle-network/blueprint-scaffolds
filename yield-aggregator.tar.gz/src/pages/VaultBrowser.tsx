import { useVaults } from "@/hooks/useVaults";
import { VaultCard } from "@/components/VaultCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, SlidersHorizontal, LayoutGrid, List } from "lucide-react";
import type { VaultType, Protocol } from "@/types";

const vaultTypes: { value: VaultType | "all"; label: string }[] = [
  { value: "all", label: "All Types" },
  { value: "single_asset", label: "Single Asset" },
  { value: "lp_farming", label: "LP Farming" },
  { value: "leveraged", label: "Leveraged" },
  { value: "delta_neutral", label: "Delta-Neutral" },
];

const protocols: { value: Protocol | "all"; label: string }[] = [
  { value: "all", label: "All Protocols" },
  { value: "aave", label: "Aave" },
  { value: "compound", label: "Compound" },
  { value: "curve", label: "Curve" },
  { value: "convex", label: "Convex" },
];

export function VaultBrowser() {
  const {
    vaults,
    typeFilter,
    setTypeFilter,
    protocolFilter,
    setProtocolFilter,
    search,
    setSearch,
    sortBy,
    setSortBy,
    sortDir,
    setSortDir,
  } = useVaults();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Vault Browser</h1>
        <p className="text-muted-foreground mt-1">
          Explore and compare {vaults.length} yield strategies
        </p>
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search vaults..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>
            <Tabs value={typeFilter} onValueChange={(v) => setTypeFilter(v as VaultType | "all")}>
              <TabsList>
                {vaultTypes.map((t) => (
                  <TabsTrigger key={t.value} value={t.value}>
                    {t.label}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
            <Select value={protocolFilter} onValueChange={(v) => setProtocolFilter(v as Protocol | "all")}>
              <SelectTrigger className="w-[160px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {protocols.map((p) => (
                  <SelectItem key={p.value} value={p.value}>
                    {p.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={(v) => setSortBy(v as "apy" | "tvl" | "name")}>
              <SelectTrigger className="w-[130px]">
                <SlidersHorizontal className="h-4 w-4 mr-1" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="apy">Sort by APY</SelectItem>
                <SelectItem value="tvl">Sort by TVL</SelectItem>
                <SelectItem value="name">Sort by Name</SelectItem>
              </SelectContent>
            </Select>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSortDir(sortDir === "asc" ? "desc" : "asc")}
            >
              {sortDir === "desc" ? "↓" : "↑"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {vaults.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center text-muted-foreground">
            No vaults found matching your filters.
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {vaults.map((vault) => (
            <VaultCard key={vault.id} vault={vault} />
          ))}
        </div>
      )}
    </div>
  );
}
