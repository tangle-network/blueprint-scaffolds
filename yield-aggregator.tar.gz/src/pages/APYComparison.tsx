import { useState } from "react";
import { getVaults, getAPYHistory, getProtocols } from "@/lib/data";
import { MultiAPYChart } from "@/components/APYChart";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ProtocolBadge, VaultTypeBadge } from "@/components/Badges";
import { formatCurrency, formatPercent } from "@/lib/utils";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import type { Vault } from "@/types";

const CHART_COLORS = ["#B6509E", "#00D395", "#0000FF", "#3A82F7", "#FF6B6B", "#FFD93D", "#6BCB77", "#845EC2", "#D65DB1", "#FF6F91", "#FFC75F", "#F9F871"];

export function APYComparison() {
  const allVaults = getVaults();
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set(allVaults.slice(0, 5).map((v) => v.id)));

  const toggleVault = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        if (next.size > 1) next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const selectedVaults = allVaults.filter((v) => selectedIds.has(v.id));

  const chartDatasets = selectedVaults.map((v, i) => ({
    name: v.name,
    data: getAPYHistory(v.id),
    color: CHART_COLORS[i % CHART_COLORS.length],
  }));

  const barData = selectedVaults.map((v) => ({
    name: v.name.length > 15 ? v.name.slice(0, 15) + "..." : v.name,
    baseApy: v.baseApy,
    rewardApy: v.rewardApy,
    totalApy: v.apy,
    fullName: v.name,
  }));

  const allBarData = allVaults
    .sort((a, b) => b.apy - a.apy)
    .map((v) => ({
      name: v.name.length > 20 ? v.name.slice(0, 20) + "..." : v.name,
      apy: v.apy,
      tvl: v.tvl,
      id: v.id,
      selected: selectedIds.has(v.id),
    }));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">APY Comparison</h1>
        <p className="text-muted-foreground mt-1">Compare yields across vaults and protocols</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">APY Trends ({selectedVaults.length} vaults)</CardTitle>
            </CardHeader>
            <CardContent>
              <MultiAPYChart datasets={chartDatasets} height={350} />
              <div className="flex flex-wrap gap-3 mt-4">
                {selectedVaults.map((v, i) => (
                  <div key={v.id} className="flex items-center gap-1.5 text-sm">
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: CHART_COLORS[i % CHART_COLORS.length] }}
                    />
                    <span>{v.name}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">APY Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={barData} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(240,3.7%,15.9%)" />
                  <XAxis
                    dataKey="name"
                    tick={{ fontSize: 10, fill: "hsl(240,5%,64.9%)" }}
                    angle={-20}
                    textAnchor="end"
                    height={60}
                  />
                  <YAxis
                    tick={{ fontSize: 11, fill: "hsl(240,5%,64.9%)" }}
                    tickFormatter={(v: number) => `${v.toFixed(0)}%`}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(240,10%,3.9%)",
                      border: "1px solid hsl(240,3.7%,15.9%)",
                      borderRadius: "6px",
                      fontSize: 12,
                    }}
                    formatter={(value: number, name: string) => [`${value.toFixed(2)}%`, name]}
                    labelFormatter={(label: string) => barData.find((d) => d.name === label)?.fullName ?? label}
                  />
                  <Bar dataKey="baseApy" name="Base APY" stackId="a" fill="#3A82F7" radius={[0, 0, 0, 0]} />
                  <Bar dataKey="rewardApy" name="Reward APY" stackId="a" fill="#00D395" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Select Vaults</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 max-h-[600px] overflow-y-auto">
              {allVaults.map((v) => (
                <button
                  key={v.id}
                  onClick={() => toggleVault(v.id)}
                  className={`w-full text-left p-2 rounded-md border transition-colors text-sm ${
                    selectedIds.has(v.id)
                      ? "border-primary bg-primary/5"
                      : "border-border hover:border-primary/30"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-medium truncate flex-1">{v.name}</span>
                    <span className="text-primary font-bold ml-2">{formatPercent(v.apy)}</span>
                  </div>
                  <div className="flex items-center gap-1 mt-1">
                    <ProtocolBadge protocol={v.protocol} />
                  </div>
                </button>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">All Vaults Ranked</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={allBarData} layout="vertical" margin={{ top: 0, right: 20, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(240,3.7%,15.9%)" />
                  <XAxis
                    type="number"
                    tick={{ fontSize: 10, fill: "hsl(240,5%,64.9%)" }}
                    tickFormatter={(v: number) => `${v}%`}
                  />
                  <YAxis
                    type="category"
                    dataKey="name"
                    width={120}
                    tick={{ fontSize: 9, fill: "hsl(240,5%,64.9%)" }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(240,10%,3.9%)",
                      border: "1px solid hsl(240,3.7%,15.9%)",
                      borderRadius: "6px",
                      fontSize: 11,
                    }}
                    formatter={(value: number) => [`${value.toFixed(2)}%`, "APY"]}
                  />
                  <Bar dataKey="apy" radius={[0, 4, 4, 0]}>
                    {allBarData.map((entry, i) => (
                      <Cell
                        key={i}
                        fill={entry.selected ? "#00D395" : "#3A82F7"}
                        opacity={entry.selected ? 1 : 0.4}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
