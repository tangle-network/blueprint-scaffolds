import { usePortfolio } from "@/hooks/usePortfolio";
import { PortfolioOverview, PositionRow } from "@/components/PortfolioComponents";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";
import { getUserPositions, getVaultById } from "@/lib/data";
import { formatCurrency } from "@/lib/utils";
import { TrendingUp, Clock } from "lucide-react";

const COLORS = ["#B6509E", "#00D395", "#3A82F7", "#FF6B6B", "#FFD93D", "#6BCB77"];

export function Portfolio() {
  const { summary, positions } = usePortfolio();

  const allocationData = positions
    .map((p) => {
      const vault = getVaultById(p.vaultId);
      return {
        name: vault?.name ?? p.vaultId,
        value: p.depositedUsd,
      };
    })
    .sort((a, b) => b.value - a.value);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Portfolio</h1>
        <p className="text-muted-foreground mt-1">Track your DeFi positions and earnings</p>
      </div>

      <PortfolioOverview summary={summary} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Positions ({positions.length})</CardTitle>
            </CardHeader>
            <CardContent>
              {positions.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  No active positions. Start by depositing into a vault.
                </div>
              ) : (
                positions.map((pos) => (
                  <PositionRow
                    key={pos.vaultId}
                    position={pos}
                  />
                ))
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Allocation</CardTitle>
            </CardHeader>
            <CardContent>
              {allocationData.length > 0 ? (
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={allocationData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={90}
                      paddingAngle={2}
                      dataKey="value"
                    >
                      {allocationData.map((_, i) => (
                        <Cell key={i} fill={COLORS[i % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(value: number) => formatCurrency(value)}
                      contentStyle={{
                        backgroundColor: "hsl(240,10%,3.9%)",
                        border: "1px solid hsl(240,3.7%,15.9%)",
                        borderRadius: "6px",
                        fontSize: 12,
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="text-center py-8 text-muted-foreground text-sm">
                  No positions to display
                </div>
              )}
              <div className="space-y-2 mt-2">
                {allocationData.map((item, i) => (
                  <div key={item.name} className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: COLORS[i % COLORS.length] }}
                      />
                      <span className="text-muted-foreground truncate max-w-[150px]">{item.name}</span>
                    </div>
                    <span className="font-medium">{formatCurrency(item.value)}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Active Positions</span>
                <span className="font-medium">{positions.length}</span>
              </div>
              <Separator />
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Total P&L</span>
                <span className="font-medium text-primary flex items-center gap-1">
                  <TrendingUp className="h-3.5 w-3.5" />
                  {formatCurrency(summary.totalEarned)}
                </span>
              </div>
              <Separator />
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Portfolio ROI</span>
                <span className="font-medium text-primary">
                  {summary.totalDeposited > 0
                    ? `${((summary.totalEarned / summary.totalDeposited) * 100).toFixed(2)}%`
                    : "0%"}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
