import type { Vault, UserPosition, APYHistoryPoint, ProtocolInfo, PortfolioSummary } from "@/types";

const PROTOCOLS: Record<string, ProtocolInfo> = {
  aave: { name: "Aave", icon: "A", color: "#B6509E", vaults: 4, totalTvl: 2_400_000_000 },
  compound: { name: "Compound", icon: "C", color: "#00D395", vaults: 3, totalTvl: 1_800_000_000 },
  curve: { name: "Curve", icon: "C", color: "#0000FF", vaults: 5, totalTvl: 3_200_000_000 },
  convex: { name: "Convex", icon: "X", color: "#3A82F7", vaults: 4, totalTvl: 2_100_000_000 },
};

export function getProtocols(): ProtocolInfo[] {
  return Object.values(PROTOCOLS);
}

export function getProtocolInfo(id: string): ProtocolInfo | undefined {
  return PROTOCOLS[id];
}

const MOCK_VAULTS: Vault[] = [
  {
    id: "aave-usdc",
    name: "Aave USDC Lending",
    type: "single_asset",
    protocol: "aave",
    asset: "USD Coin",
    assetSymbol: "USDC",
    assetDecimals: 6,
    tvl: 450_000_000,
    tvlCap: 1_000_000_000,
    apy: 5.23,
    baseApy: 3.8,
    rewardApy: 1.43,
    status: "active",
    autoHarvest: true,
    mevProtected: true,
    gasOptimized: true,
    emergencyWithdraw: true,
    lastHarvest: Math.floor(Date.now() / 1000) - 3600,
    strategy: "Supply USDC to Aave V3, auto-compound rewards to maximize yield",
    riskLevel: "low",
  },
  {
    id: "aave-eth",
    name: "Aave ETH Lending",
    type: "single_asset",
    protocol: "aave",
    asset: "Ethereum",
    assetSymbol: "ETH",
    assetDecimals: 18,
    tvl: 320_000_000,
    tvlCap: 500_000_000,
    apy: 3.12,
    baseApy: 2.1,
    rewardApy: 1.02,
    status: "active",
    autoHarvest: true,
    mevProtected: true,
    gasOptimized: true,
    emergencyWithdraw: true,
    lastHarvest: Math.floor(Date.now() / 1000) - 1800,
    strategy: "Supply ETH to Aave V3, harvest AAVE rewards and compound",
    riskLevel: "low",
  },
  {
    id: "compound-dai",
    name: "Compound DAI Supply",
    type: "single_asset",
    protocol: "compound",
    asset: "Dai",
    assetSymbol: "DAI",
    assetDecimals: 18,
    tvl: 280_000_000,
    tvlCap: 600_000_000,
    apy: 4.87,
    baseApy: 3.5,
    rewardApy: 1.37,
    status: "active",
    autoHarvest: true,
    mevProtected: true,
    gasOptimized: false,
    emergencyWithdraw: true,
    lastHarvest: Math.floor(Date.now() / 1000) - 7200,
    strategy: "Supply DAI to Compound V3, auto-claim COMP and sell to DAI",
    riskLevel: "low",
  },
  {
    id: "compound-usdt",
    name: "Compound USDT Supply",
    type: "single_asset",
    protocol: "compound",
    asset: "Tether",
    assetSymbol: "USDT",
    assetDecimals: 6,
    tvl: 190_000_000,
    tvlCap: 400_000_000,
    apy: 4.45,
    baseApy: 3.2,
    rewardApy: 1.25,
    status: "active",
    autoHarvest: true,
    mevProtected: false,
    gasOptimized: true,
    emergencyWithdraw: true,
    lastHarvest: Math.floor(Date.now() / 1000) - 5400,
    strategy: "Supply USDT to Compound V3, compound COMP rewards",
    riskLevel: "low",
  },
  {
    id: "curve-3pool",
    name: "Curve 3pool LP",
    type: "lp_farming",
    protocol: "curve",
    asset: "Curve 3pool LP",
    assetSymbol: "3CRV",
    assetDecimals: 18,
    tvl: 890_000_000,
    tvlCap: 2_000_000_000,
    apy: 6.78,
    baseApy: 2.4,
    rewardApy: 4.38,
    status: "active",
    autoHarvest: true,
    mevProtected: true,
    gasOptimized: true,
    emergencyWithdraw: true,
    lastHarvest: Math.floor(Date.now() / 1000) - 900,
    strategy: "Provide liquidity to Curve 3pool, stake LP in gauge, harvest CRV",
    riskLevel: "medium",
  },
  {
    id: "curve-steth",
    name: "Curve stETH/ETH LP",
    type: "lp_farming",
    protocol: "curve",
    asset: "Curve stETH LP",
    assetSymbol: "steCRV",
    assetDecimals: 18,
    tvl: 670_000_000,
    tvlCap: 1_000_000_000,
    apy: 7.45,
    baseApy: 3.1,
    rewardApy: 4.35,
    status: "active",
    autoHarvest: true,
    mevProtected: true,
    gasOptimized: true,
    emergencyWithdraw: true,
    lastHarvest: Math.floor(Date.now() / 1000) - 2400,
    strategy: "Provide liquidity to stETH/ETH pool, stake in gauge, compound CRV + LDO",
    riskLevel: "medium",
  },
  {
    id: "convex-3pool",
    name: "Convex 3pool Boosted",
    type: "lp_farming",
    protocol: "convex",
    asset: "Curve 3pool LP",
    assetSymbol: "3CRV",
    assetDecimals: 18,
    tvl: 540_000_000,
    tvlCap: 1_500_000_000,
    apy: 8.12,
    baseApy: 2.4,
    rewardApy: 5.72,
    status: "active",
    autoHarvest: true,
    mevProtected: true,
    gasOptimized: true,
    emergencyWithdraw: true,
    lastHarvest: Math.floor(Date.now() / 1000) - 1200,
    strategy: "Deposit 3CRV into Convex, earn boosted CRV + CVX rewards",
    riskLevel: "medium",
  },
  {
    id: "convex-frax",
    name: "Convex FRAX/USDC LP",
    type: "lp_farming",
    protocol: "convex",
    asset: "Curve FRAX/USDC LP",
    assetSymbol: "FRAX3CRV",
    assetDecimals: 18,
    tvl: 310_000_000,
    tvlCap: 800_000_000,
    apy: 9.34,
    baseApy: 3.8,
    rewardApy: 5.54,
    status: "active",
    autoHarvest: true,
    mevProtected: true,
    gasOptimized: true,
    emergencyWithdraw: true,
    lastHarvest: Math.floor(Date.now() / 1000) - 600,
    strategy: "Deposit FRAX3CRV into Convex for boosted yield",
    riskLevel: "medium",
  },
  {
    id: "aave-leveraged-eth",
    name: "Leveraged ETH Long",
    type: "leveraged",
    protocol: "aave",
    asset: "Ethereum",
    assetSymbol: "ETH",
    assetDecimals: 18,
    tvl: 120_000_000,
    tvlCap: 250_000_000,
    apy: 15.67,
    baseApy: 12.5,
    rewardApy: 3.17,
    status: "active",
    autoHarvest: true,
    mevProtected: true,
    gasOptimized: true,
    emergencyWithdraw: true,
    lastHarvest: Math.floor(Date.now() / 1000) - 3000,
    strategy: "Loop ETH: supply ETH, borrow USDC, buy more ETH, repeat up to 3x leverage",
    riskLevel: "high",
  },
  {
    id: "compound-leveraged-dai",
    name: "Leveraged DAI Carry",
    type: "leveraged",
    protocol: "compound",
    asset: "Dai",
    assetSymbol: "DAI",
    assetDecimals: 18,
    tvl: 85_000_000,
    tvlCap: 200_000_000,
    apy: 12.34,
    baseApy: 9.8,
    rewardApy: 2.54,
    status: "active",
    autoHarvest: true,
    mevProtected: true,
    gasOptimized: false,
    emergencyWithdraw: true,
    lastHarvest: Math.floor(Date.now() / 1000) - 4500,
    strategy: "Supply DAI, borrow against position, reinvest at higher yield venues",
    riskLevel: "high",
  },
  {
    id: "curve-delta-neutral",
    name: "Delta-Neutral ETH/stETH",
    type: "delta_neutral",
    protocol: "curve",
    asset: "Ethereum",
    assetSymbol: "ETH",
    assetDecimals: 18,
    tvl: 230_000_000,
    tvlCap: 500_000_000,
    apy: 4.89,
    baseApy: 3.2,
    rewardApy: 1.69,
    status: "active",
    autoHarvest: true,
    mevProtected: true,
    gasOptimized: true,
    emergencyWithdraw: true,
    lastHarvest: Math.floor(Date.now() / 1000) - 1800,
    strategy: "Long stETH, short ETH to maintain delta neutrality, earn funding + staking yield",
    riskLevel: "low",
  },
  {
    id: "convex-delta-neutral",
    name: "Delta-Neutral Stablecoin",
    type: "delta_neutral",
    protocol: "convex",
    asset: "USD Coin",
    assetSymbol: "USDC",
    assetDecimals: 6,
    tvl: 175_000_000,
    tvlCap: 400_000_000,
    apy: 5.56,
    baseApy: 4.1,
    rewardApy: 1.46,
    status: "active",
    autoHarvest: true,
    mevProtected: true,
    gasOptimized: true,
    emergencyWithdraw: true,
    lastHarvest: Math.floor(Date.now() / 1000) - 2100,
    strategy: "Stablecoin delta-neutral via convex boosted positions with hedged exposure",
    riskLevel: "low",
  },
];

export function getVaults(): Vault[] {
  return MOCK_VAULTS;
}

export function getVaultById(id: string): Vault | undefined {
  return MOCK_VAULTS.find((v) => v.id === id);
}

export function getVaultsByProtocol(protocol: string): Vault[] {
  return MOCK_VAULTS.filter((v) => v.protocol === protocol);
}

export function getVaultsByType(type: string): Vault[] {
  return MOCK_VAULTS.filter((v) => v.type === type);
}

const MOCK_POSITIONS: UserPosition[] = [
  { vaultId: "aave-usdc", deposited: 25000, shares: 24850.12, earned: 1245.67, depositedUsd: 25000, earnedUsd: 1245.67, depositDate: Math.floor(Date.now() / 1000) - 86400 * 30 },
  { vaultId: "curve-3pool", deposited: 50000, shares: 49200.5, earned: 4230.12, depositedUsd: 50000, earnedUsd: 4230.12, depositDate: Math.floor(Date.now() / 1000) - 86400 * 60 },
  { vaultId: "convex-3pool", deposited: 30000, shares: 29750.0, earned: 1890.45, depositedUsd: 30000, earnedUsd: 1890.45, depositDate: Math.floor(Date.now() / 1000) - 86400 * 45 },
  { vaultId: "aave-leveraged-eth", deposited: 10, shares: 9.85, earned: 0.82, depositedUsd: 32000, earnedUsd: 2624.0, depositDate: Math.floor(Date.now() / 1000) - 86400 * 20 },
  { vaultId: "curve-delta-neutral", deposited: 40000, shares: 39600.75, earned: 1560.0, depositedUsd: 40000, earnedUsd: 1560.0, depositDate: Math.floor(Date.now() / 1000) - 86400 * 90 },
];

export function getUserPositions(): UserPosition[] {
  return MOCK_POSITIONS;
}

export function getPortfolioSummary(): PortfolioSummary {
  const positions = getUserPositions();
  const totalDeposited = positions.reduce((s, p) => s + p.depositedUsd, 0);
  const totalEarned = positions.reduce((s, p) => s + p.earnedUsd, 0);
  const vaults = getVaults();
  const weightedApy = positions.reduce((s, p) => {
    const vault = vaults.find((v) => v.id === p.vaultId);
    if (!vault) return s;
    return s + (vault.apy * p.depositedUsd) / totalDeposited;
  }, 0);
  return {
    totalDeposited,
    totalEarned,
    totalValue: totalDeposited + totalEarned,
    weightedApy,
    positions,
  };
}

export function getAPYHistory(vaultId: string): APYHistoryPoint[] {
  const now = Date.now();
  const points: APYHistoryPoint[] = [];
  const baseApy = MOCK_VAULTS.find((v) => v.id === vaultId)?.apy ?? 5;
  for (let i = 29; i >= 0; i--) {
    const date = new Date(now - i * 86400000);
    const variance = (Math.sin(i * 0.5) * 0.5 + Math.random() * 0.3) * baseApy;
    points.push({
      date: date.toISOString().split("T")[0],
      apy: Math.max(0.1, baseApy + variance),
      timestamp: Math.floor(date.getTime() / 1000),
    });
  }
  return points;
}

export function getTotalTVL(): number {
  return MOCK_VAULTS.reduce((s, v) => s + v.tvl, 0);
}
