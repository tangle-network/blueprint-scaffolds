export type VaultType =
  | "Single Asset"
  | "LP Farming"
  | "Leveraged"
  | "Delta Neutral";

export type RiskLevel = "Conservative" | "Balanced" | "Aggressive";

export type ProtocolName = "Aave" | "Compound" | "Curve" | "Convex";

export interface ProtocolIntegration {
  name: ProtocolName;
  category: "Lending" | "Stable Swap" | "Boosted Rewards";
  chain: "Ethereum" | "Arbitrum" | "Base";
  baseApr: number;
  rewardApr: number;
  utilization: number;
  auditStatus: "Battle Tested" | "Monitored";
  mevProtection: "Private RPC" | "CoW Swap" | "Flashbots";
}

export interface Vault {
  id: string;
  name: string;
  symbol: string;
  type: VaultType;
  risk: RiskLevel;
  chain: "Ethereum" | "Arbitrum" | "Base";
  protocols: ProtocolName[];
  assets: string[];
  tvl: number;
  tvlCap: number;
  userCapacity: number;
  baseApy: number;
  rewardApy: number;
  leverage?: number;
  healthScore: number;
  gasPerHarvestUsd: number;
  harvestEveryHours: number;
  batchWindowMinutes: number;
  mevProtected: boolean;
  emergencyWithdrawalReady: boolean;
  autoCompound: boolean;
  strategyNotes: string;
}

export interface VaultMetrics {
  netApy: number;
  optimizedApy: number;
  capUsage: number;
  annualGasCost: number;
  harvestsPerYear: number;
  safetyBuffer: number;
}

export interface PortfolioPosition {
  vaultId: string;
  depositedUsd: number;
  shareOfVault: number;
  pendingRewardsUsd: number;
}
