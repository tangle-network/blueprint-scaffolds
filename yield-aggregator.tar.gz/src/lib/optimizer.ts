import type { PortfolioPosition, ProtocolIntegration, Vault, VaultMetrics } from "./types";

const COMPOUNDING_ALPHA = 0.82;
const BATCHING_DISCOUNT = 0.68;
const MEV_DISCOUNT = 0.55;

export function getVaultMetrics(vault: Vault): VaultMetrics {
  const grossApy = vault.baseApy + vault.rewardApy;
  const harvestsPerYear = 8760 / vault.harvestEveryHours;
  const annualGasCost = vault.gasPerHarvestUsd * harvestsPerYear * BATCHING_DISCOUNT;
  const gasDrag = Math.min(annualGasCost / Math.max(vault.tvl, 1) * 100, 1.8);
  const compoundingLift = vault.autoCompound ? grossApy * (vault.harvestEveryHours / 24) * 0.018 : 0;
  const mevPenalty = vault.mevProtected ? 0 : vault.rewardApy * 0.18 * MEV_DISCOUNT;
  const optimizedApy = grossApy + compoundingLift * COMPOUNDING_ALPHA - gasDrag - mevPenalty;

  return {
    netApy: grossApy - gasDrag,
    optimizedApy,
    capUsage: (vault.tvl / vault.tvlCap) * 100,
    annualGasCost,
    harvestsPerYear,
    safetyBuffer: Math.max(0, vault.healthScore - (vault.leverage ?? 1) * 8)
  };
}

export function getProtocolComposite(protocols: ProtocolIntegration[]) {
  return protocols.reduce(
    (acc, protocol) => {
      acc.baseApr += protocol.baseApr;
      acc.rewardApr += protocol.rewardApr;
      acc.utilization += protocol.utilization;
      return acc;
    },
    { baseApr: 0, rewardApr: 0, utilization: 0 }
  );
}

export function getPortfolioSummary(vaults: Vault[], positions: PortfolioPosition[]) {
  return positions.reduce(
    (acc, position) => {
      const vault = vaults.find((item) => item.id === position.vaultId);
      if (!vault) {
        return acc;
      }

      const metrics = getVaultMetrics(vault);
      acc.depositedUsd += position.depositedUsd;
      acc.pendingRewardsUsd += position.pendingRewardsUsd;
      acc.projectedAnnualYieldUsd += position.depositedUsd * (metrics.optimizedApy / 100);
      acc.emergencyReadyCount += vault.emergencyWithdrawalReady ? 1 : 0;
      return acc;
    },
    {
      depositedUsd: 0,
      pendingRewardsUsd: 0,
      projectedAnnualYieldUsd: 0,
      emergencyReadyCount: 0
    }
  );
}
