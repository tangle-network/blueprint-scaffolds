# X Layer NFT — ERC721 with Gasless Minting

## Overview

ERC721 NFT collection deployed on **X Layer** (chain ID 196) with a TypeScript client that mints gaslessly via **ERC-4337** account abstraction.

## Smart Contract (Solidity / Foundry)

### Contract: `XLayerNFT`

| Feature | Detail |
|---|---|
| Standard | ERC-721 (OpenZeppelin v5) |
| Token URI | `ipfs://<CID>/{tokenId}.json` |
| Mint | `mint(address to)` — payable, enforces `maxSupply` and `mintPrice` |
| Owner | `setBaseURI()`, `withdraw()` |

### Deploy

```bash
# .env
PRIVATE_KEY=0x...
NFT_NAME="X Layer Collection"
NFT_SYMBOL="XLNFT"
NFT_BASE_URI="ipfs://QmYourIPFSCID/"
NFT_MAX_SUPPLY=1000
NFT_MINT_PRICE=10000000000000000  # 0.01 OKB

forge script script/DeployXLayerNFT.s.sol --rpc-url xlayer --broadcast
```

### Test

```bash
forge test -vvv
```

## TypeScript Gasless Minting Client

Uses **permissionless.js** + **viem** to submit a UserOperation through an ERC-4337 bundler + paymaster, so the end user signs with their EOA key but pays **zero OKB for gas**.

### Setup

```bash
cp .env.example .env   # fill in values
npm install
```

### Run

```bash
npx tsx ts-client/mint.ts
```

### Environment Variables

| Variable | Description |
|---|---|
| `PRIVATE_KEY` | EOA private key (smart account owner) |
| `NFT_ADDRESS` | Deployed XLayerNFT contract address |
| `BUNDLER_URL` | ERC-4337 bundler RPC (e.g. Pimlico) |
| `PAYMASTER_URL` | Paymaster RPC that sponsors gas |
| `RPC_URL` | X Layer RPC (default: `https://rpc.xlayer.tech`) |
| `MINT_PRICE` | Mint price in wei (default: 0) |

## Project Structure

```
├── foundry.toml              # Foundry config
├── remappings.txt            # Solidity import remappings
├── src/
│   └── XLayerNFT.sol         # ERC721 contract
├── script/
│   └── DeployXLayerNFT.s.sol # Deploy script
├── test/
│   └── XLayerNFT.t.sol       # Forge tests
├── ts-client/
│   └── mint.ts               # Gasless minting client
├── package.json
└── tsconfig.json
```
