// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import "forge-std/Test.sol";
import "../src/XLayerNFT.sol";

contract XLayerNFTTest is Test {
    XLayerNFT public nft;
    address public owner = address(0x1);
    address public minter = address(0x2);

    string constant NAME = "X Layer Collection";
    string constant SYMBOL = "XLNFT";
    string constant BASE_URI = "ipfs://QmExampleCID/";
    uint256 constant MAX_SUPPLY = 1000;
    uint256 constant MINT_PRICE = 0.01 ether;

    function setUp() public {
        vm.prank(owner);
        nft = new XLayerNFT(NAME, SYMBOL, BASE_URI, MAX_SUPPLY, MINT_PRICE);
    }

    function test_constructor() public view {
        assertEq(nft.name(), NAME);
        assertEq(nft.symbol(), SYMBOL);
        assertEq(nft.maxSupply(), MAX_SUPPLY);
        assertEq(nft.mintPrice(), MINT_PRICE);
    }

    function test_mint() public {
        vm.prank(minter);
        vm.deal(minter, 1 ether);
        uint256 tokenId = nft.mint{value: MINT_PRICE}(minter);

        assertEq(tokenId, 1);
        assertEq(nft.ownerOf(1), minter);
        assertEq(nft.totalMinted(), 1);
    }

    function test_tokenURI() public {
        vm.prank(minter);
        vm.deal(minter, 1 ether);
        nft.mint{value: MINT_PRICE}(minter);

        assertEq(nft.tokenURI(1), string(abi.encodePacked(BASE_URI, "1.json")));
    }

    function test_mint_reverts_insufficient_payment() public {
        vm.prank(minter);
        vm.deal(minter, 1 ether);
        vm.expectRevert("Insufficient payment");
        nft.mint{value: 0}(minter);
    }

    function test_mint_reverts_max_supply() public {
        XLayerNFT smallNft;
        vm.prank(owner);
        smallNft = new XLayerNFT(NAME, SYMBOL, BASE_URI, 2, MINT_PRICE);

        vm.deal(minter, 1 ether);
        vm.startPrank(minter);
        smallNft.mint{value: MINT_PRICE}(minter);
        smallNft.mint{value: MINT_PRICE}(minter);

        vm.expectRevert("Max supply reached");
        smallNft.mint{value: MINT_PRICE}(minter);
        vm.stopPrank();
    }

    function test_setBaseURI() public {
        vm.prank(owner);
        nft.setBaseURI("ipfs://NewCID/");

        vm.prank(minter);
        vm.deal(minter, 1 ether);
        nft.mint{value: MINT_PRICE}(minter);

        assertEq(nft.tokenURI(1), "ipfs://NewCID/1.json");
    }

    function test_withdraw() public {
        vm.deal(minter, 1 ether);
        vm.prank(minter);
        nft.mint{value: MINT_PRICE}(minter);

        uint256 ownerBalBefore = owner.balance;
        vm.prank(owner);
        nft.withdraw();
        assertEq(owner.balance, ownerBalBefore + MINT_PRICE);
    }

    function test_sequential_token_ids() public {
        vm.deal(minter, 10 ether);
        vm.startPrank(minter);
        for (uint256 i = 1; i <= 5; i++) {
            uint256 tid = nft.mint{value: MINT_PRICE}(minter);
            assertEq(tid, i);
        }
        vm.stopPrank();
        assertEq(nft.totalMinted(), 5);
    }
}
