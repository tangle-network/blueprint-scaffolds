import { strict as assert } from "node:assert";

assert.equal("StarterToken".length > 0, true);
