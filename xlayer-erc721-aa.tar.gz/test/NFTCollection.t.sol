// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "forge-std/Test.sol";
import "../src/NFTCollection.sol";

contract NFTCollectionTest is Test {
    NFTCollection public nft;
    address public owner = address(0x1);
    address public minter = address(0x2);

    function setUp() public {
        vm.prank(owner);
        nft = new NFTCollection("TestNFT", "TNFT", "ipfs://QmTest/", 100, 0);
    }

    function test_FreeMint() public {
        vm.prank(minter);
        uint256 tokenId = nft.freeMint(minter);
        assertEq(tokenId, 1);
        assertEq(nft.ownerOf(1), minter);
    }

    function test_TokenURI() public {
        vm.prank(minter);
        nft.freeMint(minter);
        assertEq(nft.tokenURI(1), "ipfs://QmTest/1");
    }

    function test_MaxSupply() public {
        vm.prank(owner);
        NFTCollection small = new NFTCollection("S", "S", "ipfs://Qm/", 2, 0);
        vm.prank(minter);
        small.freeMint(minter);
        vm.prank(minter);
        small.freeMint(minter);
        vm.prank(minter);
        vm.expectRevert("Max supply reached");
        small.freeMint(minter);
    }

    function test_SetBaseURI() public {
        vm.prank(owner);
        nft.setBaseURI("ipfs://QmNew/");
        vm.prank(minter);
        nft.freeMint(minter);
        assertEq(nft.tokenURI(1), "ipfs://QmNew/1");
    }

    function test_RevertNonOwnerSetBaseURI() public {
        vm.prank(minter);
        vm.expectRevert();
        nft.setBaseURI("ipfs://hack/");
    }
}
