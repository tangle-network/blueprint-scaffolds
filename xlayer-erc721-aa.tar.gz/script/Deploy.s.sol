// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "forge-std/Script.sol";
import "../src/NFTCollection.sol";

contract DeployNFTCollection is Script {
    function run() external {
        string memory name = vm.envString("NFT_NAME");
        string memory symbol = vm.envString("NFT_SYMBOL");
        string memory baseURI = vm.envString("IPFS_BASE_URI");
        uint256 maxSupply = vm.envUint("MAX_SUPPLY");
        uint256 mintPrice = vm.envUint("MINT_PRICE");

        uint256 deployerKey = vm.envUint("PRIVATE_KEY");

        vm.startBroadcast(deployerKey);

        NFTCollection nft = new NFTCollection(
            name,
            symbol,
            baseURI,
            maxSupply,
            mintPrice
        );

        console.log("NFTCollection deployed at:", address(nft));

        vm.stopBroadcast();
    }
}
