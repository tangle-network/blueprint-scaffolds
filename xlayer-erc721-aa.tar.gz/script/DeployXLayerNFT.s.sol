// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import "forge-std/Script.sol";
import "../src/XLayerNFT.sol";

contract DeployXLayerNFT is Script {
    function run() external returns (XLayerNFT) {
        string memory name = vm.envString("NFT_NAME");
        string memory symbol = vm.envString("NFT_SYMBOL");
        string memory baseURI = vm.envString("NFT_BASE_URI");
        uint256 maxSupply = vm.envUint("NFT_MAX_SUPPLY");
        uint256 mintPrice = vm.envUint("NFT_MINT_PRICE");

        uint256 deployerKey = vm.envUint("PRIVATE_KEY");

        vm.startBroadcast(deployerKey);

        XLayerNFT nft = new XLayerNFT(
            name,
            symbol,
            baseURI,
            maxSupply,
            mintPrice
        );

        vm.stopBroadcast();

        return nft;
    }
}
