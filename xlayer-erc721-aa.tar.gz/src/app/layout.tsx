import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "X Layer NFT Collection",
  description: "Gasless ERC-721 NFT minting on X Layer via ERC-4337",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen antialiased">{children}</body>
    </html>
  );
}
