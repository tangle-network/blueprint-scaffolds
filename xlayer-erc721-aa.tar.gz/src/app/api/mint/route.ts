import { NextRequest, NextResponse } from "next/server";
import { submitGaslessMint } from "@/lib/mint";
import { type Hex } from "viem";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      nftAddress,
      recipient,
      quantity,
      bundlerUrl,
      paymasterUrl,
      privateKey,
      useTestnet,
    } = body;

    if (!nftAddress || !recipient || !quantity || !bundlerUrl || !paymasterUrl) {
      return NextResponse.json(
        { error: "Missing required fields: nftAddress, recipient, quantity, bundlerUrl, paymasterUrl" },
        { status: 400 }
      );
    }

    if (!privateKey) {
      return NextResponse.json(
        { error: "Missing privateKey for signing" },
        { status: 400 }
      );
    }

    const result = await submitGaslessMint({
      nftAddress: nftAddress as Hex,
      recipient: recipient as Hex,
      quantity: Number(quantity),
      bundlerUrl: bundlerUrl as string,
      paymasterUrl: paymasterUrl as string,
      privateKey: privateKey as Hex,
      useTestnet: Boolean(useTestnet),
    });

    if (!result.success) {
      return NextResponse.json(
        { error: result.error },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      txHash: result.txHash,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Internal server error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
