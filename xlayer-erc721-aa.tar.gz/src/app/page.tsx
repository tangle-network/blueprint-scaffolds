"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";

type MintStatus = "idle" | "loading" | "success" | "error";

export default function Home() {
  const [nftAddress, setNftAddress] = useState("");
  const [recipient, setRecipient] = useState("");
  const [quantity, setQuantity] = useState("1");
  const [bundlerUrl, setBundlerUrl] = useState("https://api.pimlico.io/v2/196/rpc");
  const [paymasterUrl, setPaymasterUrl] = useState("https://api.pimlico.io/v2/196/rpc");
  const [privateKey, setPrivateKey] = useState("");
  const [useTestnet, setUseTestnet] = useState(false);
  const [status, setStatus] = useState<MintStatus>("idle");
  const [txHash, setTxHash] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  async function handleMint() {
    setStatus("loading");
    setErrorMsg("");
    setTxHash("");

    try {
      const res = await fetch("/api/mint", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nftAddress,
          recipient,
          quantity: Number(quantity),
          bundlerUrl,
          paymasterUrl,
          privateKey,
          useTestnet,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setStatus("error");
        setErrorMsg(data.error || "Mint failed");
        return;
      }

      setStatus("success");
      setTxHash(data.txHash);
    } catch (err: unknown) {
      setStatus("error");
      setErrorMsg(err instanceof Error ? err.message : "Unknown error");
    }
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-4">
      <div className="w-full max-w-lg space-y-6">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">
            X Layer NFT Collection
          </h1>
          <p className="text-muted-foreground">
            Gasless ERC-721 NFT minting via ERC-4337 account abstraction
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Gasless Mint</CardTitle>
            <CardDescription>
              Mint NFTs without holding OKB for gas. The paymaster sponsors
              your transaction through an ERC-4337 bundler.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">NFT Contract Address</label>
              <Input
                placeholder="0x..."
                value={nftAddress}
                onChange={(e) => setNftAddress(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Recipient Address</label>
              <Input
                placeholder="0x..."
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Quantity</label>
              <Input
                type="number"
                min="1"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Bundler RPC URL</label>
              <Input
                placeholder="https://api.pimlico.io/v2/196/rpc"
                value={bundlerUrl}
                onChange={(e) => setBundlerUrl(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Paymaster RPC URL</label>
              <Input
                placeholder="https://api.pimlico.io/v2/196/rpc"
                value={paymasterUrl}
                onChange={(e) => setPaymasterUrl(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Private Key (signing)</label>
              <Input
                type="password"
                placeholder="0x..."
                value={privateKey}
                onChange={(e) => setPrivateKey(e.target.value)}
              />
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="testnet"
                checked={useTestnet}
                onChange={(e) => setUseTestnet(e.target.checked)}
                className="rounded border-gray-600"
              />
              <label htmlFor="testnet" className="text-sm">
                Use X Layer Testnet (chain 195)
              </label>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col gap-3">
            <Button
              className="w-full"
              onClick={handleMint}
              disabled={status === "loading"}
            >
              {status === "loading" ? "Submitting..." : "Gasless Mint"}
            </Button>

            {status === "success" && txHash && (
              <div className="w-full rounded-md bg-green-900/30 border border-green-800 p-3 text-sm">
                <p className="font-medium text-green-400">Transaction submitted!</p>
                <p className="text-green-300/80 break-all mt-1">TX: {txHash}</p>
              </div>
            )}

            {status === "error" && errorMsg && (
              <div className="w-full rounded-md bg-red-900/30 border border-red-800 p-3 text-sm">
                <p className="font-medium text-red-400">Error</p>
                <p className="text-red-300/80 break-all mt-1">{errorMsg}</p>
              </div>
            )}
          </CardFooter>
        </Card>

        <div className="text-center text-xs text-muted-foreground">
          <p>Built with Foundry + Next.js + permissionless.js + viem</p>
          <p className="mt-1">ERC-4337 Account Abstraction on X Layer</p>
        </div>
      </div>
    </main>
  );
}
