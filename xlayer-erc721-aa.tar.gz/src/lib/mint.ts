import { createSmartAccountClient } from "permissionless/clients";
import { createPimlicoClient } from "permissionless/clients/pimlico";
import { toSimpleSmartAccount } from "permissionless/accounts";
import {
  createPublicClient,
  encodeFunctionData,
  http,
  type Hex,
} from "viem";
import { privateKeyToAccount } from "viem/accounts";
import { entryPoint07Address } from "viem/account-abstraction";
import { XLayerNFT_ABI } from "./abi";

export const XLAYER_CHAIN = {
  id: 196,
  name: "X Layer",
  nativeCurrency: { name: "OKB", symbol: "OKB", decimals: 18 },
  rpcUrls: {
    default: { http: ["https://rpc.xlayer.tech"] },
  },
  blockExplorers: {
    default: { name: "X Layer Explorer", url: "https://www.oklink.com/xlayer" },
  },
} as const;

export const XLAYER_TESTNET_CHAIN = {
  id: 195,
  name: "X Layer Testnet",
  nativeCurrency: { name: "OKB", symbol: "OKB", decimals: 18 },
  rpcUrls: {
    default: { http: ["https://testrpc.xlayer.tech"] },
  },
  blockExplorers: {
    default: {
      name: "X Layer Testnet Explorer",
      url: "https://www.oklink.com/xlayer-test",
    },
  },
} as const;

export interface GaslessMintParams {
  nftAddress: Hex;
  recipient: Hex;
  quantity: number;
  bundlerUrl: string;
  paymasterUrl: string;
  privateKey: Hex;
  useTestnet?: boolean;
}

export interface GaslessMintResult {
  success: boolean;
  txHash?: Hex;
  userOpHash?: Hex;
  error?: string;
}

export async function submitGaslessMint(
  params: GaslessMintParams
): Promise<GaslessMintResult> {
  const {
    nftAddress,
    recipient,
    quantity,
    bundlerUrl,
    paymasterUrl,
    privateKey,
    useTestnet = false,
  } = params;

  const chain = useTestnet ? XLAYER_TESTNET_CHAIN : XLAYER_CHAIN;

  try {
    const publicClient = createPublicClient({
      chain,
      transport: http(),
    });

    const owner = privateKeyToAccount(privateKey);

    const smartAccount = await toSimpleSmartAccount({
      client: publicClient,
      owner,
    } as Parameters<typeof toSimpleSmartAccount>[0]);

    const paymasterClient = createPimlicoClient({
      transport: http(paymasterUrl),
      entryPoint: {
        address: entryPoint07Address,
        version: "0.7",
      },
    });

    const smartAccountClient = createSmartAccountClient({
      account: smartAccount,
      chain,
      bundlerTransport: http(bundlerUrl),
      paymaster: {
        getPaymasterData: (p) => paymasterClient.getPaymasterData(p),
        getPaymasterStubData: (p) => paymasterClient.getPaymasterStubData(p),
      },
      client: publicClient,
    });

    const gaslessMintData = encodeFunctionData({
      abi: XLayerNFT_ABI,
      functionName: "gaslessMint",
      args: [recipient, BigInt(quantity)],
    });

    const txHash = await smartAccountClient.sendTransaction({
      to: nftAddress,
      data: gaslessMintData,
      value: BigInt(0),
    });

    return { success: true, txHash };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    return { success: false, error: message };
  }
}
