import "dotenv/config";
import { createSmartAccountClient } from "permissionless";
import { toSimpleSmartAccount } from "permissionless/accounts";
import {
    createPublicClient,
    http,
    encodeFunctionData,
    type Hex,
} from "viem";
import { privateKeyToAccount } from "viem/accounts";
import {
    entryPoint07Address,
    createBundlerClient,
} from "viem/account-abstraction";

const XLAYER_CHAIN = {
    id: 196,
    name: "X Layer",
    nativeCurrency: { name: "OKB", symbol: "OKB", decimals: 18 },
    rpcUrls: {
        default: { http: ["https://rpc.xlayer.tech"] },
    },
} as const;

const NFT_ABI = [
    {
        name: "freeMint",
        type: "function",
        stateMutability: "nonpayable",
        inputs: [{ name: "to", type: "address" }],
        outputs: [{ name: "", type: "uint256" }],
    },
] as const;

async function main() {
    const rpcUrl = process.env.RPC_URL ?? "https://rpc.xlayer.tech";
    const bundlerUrl =
        process.env.BUNDLER_URL ?? "https://api.pimlico.io/v2/196/rpc";
    const contractAddress = process.env.NFT_CONTRACT_ADDRESS as Hex;
    const minterKey = process.env.MINTER_PRIVATE_KEY as Hex;

    if (!contractAddress) {
        throw new Error("NFT_CONTRACT_ADDRESS is required in .env");
    }
    if (!minterKey) {
        throw new Error("MINTER_PRIVATE_KEY is required in .env");
    }

    const owner = privateKeyToAccount(minterKey);

    const publicClient = createPublicClient({
        chain: XLAYER_CHAIN,
        transport: http(rpcUrl),
    });

    const smartAccount = await toSimpleSmartAccount({
        client: publicClient,
        owner,
        entryPoint: {
            address: entryPoint07Address,
            version: "0.7",
        },
    });

    const bundlerClient = createBundlerClient({
        account: smartAccount,
        chain: XLAYER_CHAIN,
        transport: http(bundlerUrl),
        entryPoint: {
            address: entryPoint07Address,
            version: "0.7",
        },
    });

    const smartAccountClient = createSmartAccountClient({
        account: smartAccount,
        chain: XLAYER_CHAIN,
        bundlerTransport: http(bundlerUrl),
        client: publicClient,
        paymaster: true,
    });

    console.log("Smart account address:", smartAccount.address);

    const mintData = encodeFunctionData({
        abi: NFT_ABI,
        functionName: "freeMint",
        args: [smartAccount.address as Hex],
    });

    console.log("Submitting gasless mint via ERC-4337 bundler...");

    const userOpHash = await smartAccountClient.sendUserOperation({
        calls: [
            {
                to: contractAddress,
                data: mintData,
                value: 0n,
            },
        ],
    });

    console.log("UserOp hash:", userOpHash);

    const receipt = await bundlerClient.waitForUserOperationReceipt({
        hash: userOpHash,
    });

    console.log(
        "Status:",
        receipt.success ? "SUCCESS" : "FAILED"
    );
    console.log("Tx hash:", receipt.receipt.transactionHash);
    console.log("Block:", receipt.receipt.blockNumber.toString());
}

main().catch((err: unknown) => {
    console.error("Mint failed:", err);
    process.exit(1);
});
