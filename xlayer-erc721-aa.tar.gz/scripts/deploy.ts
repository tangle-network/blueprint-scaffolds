console.log("Deploy StarterToken with Hardhat");
