import { createPublicClient, createWalletClient, http, parseEther, formatEther } from "viem";
import { privateKeyToAccount } from "viem/accounts";
import { defineChain } from "viem";

const xlayer = defineChain({
  id: 196,
  name: "X Layer",
  nativeCurrency: { name: "OKB", symbol: "OKB", decimals: 18 },
  rpcUrls: {
    default: { http: ["https://rpc.xlayer.tech"] },
  },
});

async function main() {
  const privateKey = process.env.PRIVATE_KEY as `0x${string}`;
  if (!privateKey) {
    throw new Error("PRIVATE_KEY environment variable is required");
  }

  const account = privateKeyToAccount(privateKey);

  const publicClient = createPublicClient({
    chain: xlayer,
    transport: http(),
  });

  const walletClient = createWalletClient({
    account,
    chain: xlayer,
    transport: http(),
  });

  const nftAddress = (process.env.NFT_CONTRACT_ADDRESS || "0x0000000000000000000000000000000000000000") as `0x${string}`;

  const abi = [
    {
      name: "safeMint",
      type: "function",
      stateMutability: "nonpayable",
      inputs: [{ name: "to", type: "address" }],
      outputs: [],
    },
    {
      name: "balanceOf",
      type: "function",
      stateMutability: "view",
      inputs: [{ name: "owner", type: "address" }],
      outputs: [{ name: "", type: "uint256" }],
    },
  ] as const;

  const balance = await publicClient.readContract({
    address: nftAddress,
    abi,
    functionName: "balanceOf",
    args: [account.address],
  });

  console.log(`Current NFT balance: ${balance}`);

  const { request } = await publicClient.simulateContract({
    address: nftAddress,
    abi,
    functionName: "safeMint",
    args: [account.address],
    account,
  });

  const txHash = await walletClient.writeContract(request);
  console.log(`Mint transaction sent: ${txHash}`);

  const receipt = await publicClient.waitForTransactionReceipt({ hash: txHash });
  console.log(`Transaction confirmed in block ${receipt.blockNumber}`);

  const newBalance = await publicClient.readContract({
    address: nftAddress,
    abi,
    functionName: "balanceOf",
    args: [account.address],
  });

  console.log(`New NFT balance: ${newBalance}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
