# AGENTS.md

## Goal

Deploy an ERC-721 NFT collection with account abstraction on X Layer. Gasless minting, batch operations.

## Stack

- Family: `hardhat-contracts`
- Layers: 
- Partner: `xlayer`

## Architecture

- Hardhat TypeScript
- Contracts in contracts/
- Deploy tasks
- Hardhat config with network settings

## Entry Points

- `hardhat.config.ts`
- `contracts/StarterToken.sol`
- `scripts/deploy.ts`

## Commands

- `npm run test`
- `npm run deploy`

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
