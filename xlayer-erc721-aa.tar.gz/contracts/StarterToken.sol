// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract StarterToken {
    string public constant NAME = "StarterToken";
}
