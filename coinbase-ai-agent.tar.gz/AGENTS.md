# AI Trading Agent — Build Plan

## Tech Stack
- **Frontend**: Vite + React 18 + TypeScript + Tailwind CSS + shadcn/ui
- **Backend**: Python + FastAPI + Coinbase CDP AgentKit
- **AI**: OpenAI / Anthropic LLM integration
- **Network**: Base / Ethereum

## Pages
| Route | Page | Components |
|---|---|---|
| `/` | Dashboard | PortfolioSummary, AgentStatusCard, RecentActivity, PerformanceChart |
| `/trading` | Trading | TradePanel, OrderBook, TradingPairsList |
| `/settings` | Settings | AgentConfigForm, RiskSettingsForm |
| `/history` | History | TransactionTable, Filters |

## API Routes (backend)
| Method | Path | Description |
|---|---|---|
| GET | `/api/agent/status` | Agent status and PnL |
| POST | `/api/agent/start` | Start agent |
| POST | `/api/agent/stop` | Stop agent |
| GET | `/api/portfolio` | Portfolio balances |
| POST | `/api/trade` | Execute trade |
| GET | `/api/trades` | Trade history |
| GET | `/api/config` | Agent configuration |
| PUT | `/api/config` | Update configuration |

## Components (src/components/)
- `ui/` — shadcn/ui primitives (card, button, input, select, badge, table, tabs, switch, progress, label)
- `layout/Sidebar.tsx` — Navigation sidebar
- `layout/Header.tsx` — Top header with agent status indicator
- `dashboard/PortfolioSummary.tsx` — Total value + 24h change
- `dashboard/AgentStatusCard.tsx` — Agent running/paused status
- `dashboard/RecentActivity.tsx` — Activity feed
- `dashboard/PerformanceChart.tsx` — Portfolio value chart
- `trading/TradePanel.tsx` — Buy/sell/swap form
- `trading/TradingPairsList.tsx` — Available pairs
- `settings/AgentConfigForm.tsx` — LLM & wallet config
- `settings/RiskSettingsForm.tsx` — Risk management controls

## Build Commands
```bash
npm install
npm run build
```

## Backend (Python)
```bash
pip install fastapi uvicorn coinbase-agentkit openai anthropic
cd backend && python main.py
```
