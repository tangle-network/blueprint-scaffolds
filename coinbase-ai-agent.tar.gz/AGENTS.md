# AGENTS.md

Create an AI trading agent using Coinbase AI AgentKit for automated DeFi operations. Automated token trading on DEX, portfolio management and rebalancing, risk management controls.

## What's here

This project was scaffolded by starter-foundry. The user's prompt drove the choices below — read their prompt first, it takes priority over everything in this file.

- **Family:** `agent-service-ts`
- **Layers:** `framework:agent-service-ts`, `capability:agent-trading`, `capability:exchange-coinbase`, `database:sqlite`, `sdk:coinbase-cdp`, `auth:none`, `payments:none`, `queue:none`
- **Partner:** `coinbase`

### Architecture notes
- Agent control loop: plan → act → reflect
- Tool registration
- Memory/state management
- HTTP health endpoint
- Wrap root layout with <OnchainKitProvider chain={base} apiKey={...}>.
- Use <WalletDefault /> for instant connect button (Smart Wallet enabled).
- Use <TransactionDefault /> for one-click transactions.
- <Identity> resolves ENS/Basenames and shows avatar + name.
- Server-side: use CDP SDK for wallet creation, signing, and faucet.

## Getting started

```bash
node agent.mjs
```

Key files: `agent.mjs`, `agent.config.json`

## Suggested build plan

These are starting points — adapt them to the user's actual needs.

- **API routes:** /api/strategy, /api/positions, /api/risk
- **Components:** StrategyConfig, PositionTable, PnLChart, RiskDashboard, OnchainKitProvider, Identity, WalletDefault, TransactionDefault, SwapDefault
- **Data models:** Position, Order, Signal, RiskLimit
- **Integrations:** Exchange API (from exchange config), Market data WebSocket, Coinbase OnchainKit, CDP Server Wallet, Base chain

## How to use this scaffold

This is a starting point, not a contract. You own every file.

- **Customize freely.** Replace components, change the layout, swap the color scheme — whatever fits the user's product.
- **The scaffold saves you setup time** — Tailwind, shadcn/ui, path aliases, and framework config are ready. Don't redo them.
- **Check `.starter-foundry/compose-report.json`** if you want to see which layer wrote which file.
- **Update this file** as the project evolves. Delete sections that no longer apply.
