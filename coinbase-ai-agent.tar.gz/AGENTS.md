# AGENTS.md

## Goal

Create an AI trading agent using Coinbase AI AgentKit for automated DeFi operations. Automated token trading on DEX, portfolio management and rebalancing, risk management controls.

## Stack

- Family: `agent-service-ts`
- Layers: `capability:agent-trading`, `capability:exchange-coinbase`, `database:sqlite`, `sdk:coinbase-cdp`, `auth:none`, `payments:none`, `queue:none`
- Partner: `coinbase`

## Architecture

- Agent control loop: plan → act → reflect
- Tool registration
- Memory/state management
- HTTP health endpoint
- Wrap root layout with <OnchainKitProvider chain={base} apiKey={...}>.
- Use <WalletDefault /> for instant connect button (Smart Wallet enabled).
- Use <TransactionDefault /> for one-click transactions.
- <Identity> resolves ENS/Basenames and shows avatar + name.
- Server-side: use CDP SDK for wallet creation, signing, and faucet.

## Entry Points

- `agent.mjs`
- `agent.config.json`

## Commands

- `node agent.mjs`

## Build Plan

API routes: /api/strategy, /api/positions, /api/risk
Components: StrategyConfig, PositionTable, PnLChart, RiskDashboard, OnchainKitProvider, Identity, WalletDefault, TransactionDefault, SwapDefault
Data models: Position, Order, Signal, RiskLimit
Integrations: Exchange API (from exchange config), Market data WebSocket, Coinbase OnchainKit, CDP Server Wallet, Base chain

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
