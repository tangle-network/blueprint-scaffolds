import { useState, useEffect, useCallback } from "react";
import { api } from "@/services/api";
import type { PortfolioSummary, AgentStatus, Trade, ActivityLog, ChartDataPoint, AgentConfig, TradingPair } from "@/types";

export function usePortfolio() {
  const [data, setData] = useState<PortfolioSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(() => {
    setLoading(true);
    setTimeout(() => {
      setData(api.getPortfolio());
      setLoading(false);
    }, 300);
  }, []);
  useEffect(() => { refresh(); }, [refresh]);
  return { data, loading, refresh };
}

export function useAgentStatus() {
  const [data, setData] = useState<AgentStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(() => {
    setLoading(true);
    setTimeout(() => {
      setData(api.getAgentStatus());
      setLoading(false);
    }, 200);
  }, []);
  useEffect(() => { refresh(); }, [refresh]);

  const start = useCallback(async () => {
    const status = await api.startAgent();
    setData(status);
  }, []);

  const stop = useCallback(async () => {
    const status = await api.stopAgent();
    setData(status);
  }, []);

  return { data, loading, refresh, start, stop };
}

export function useTrades() {
  const [data, setData] = useState<Trade[]>([]);
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(() => {
    setLoading(true);
    setTimeout(() => {
      setData(api.getTrades());
      setLoading(false);
    }, 300);
  }, []);
  useEffect(() => { refresh(); }, [refresh]);
  return { data, loading, refresh };
}

export function useActivity() {
  const [data, setData] = useState<ActivityLog[]>([]);
  const refresh = useCallback(() => {
    setData(api.getActivity());
  }, []);
  useEffect(() => { refresh(); }, [refresh]);
  return { data, refresh };
}

export function useChartData() {
  const [data, setData] = useState<ChartDataPoint[]>([]);
  const refresh = useCallback(() => {
    setData(api.getChartData());
  }, []);
  useEffect(() => { refresh(); }, [refresh]);
  return { data, refresh };
}

export function useConfig() {
  const [data, setData] = useState<AgentConfig | null>(null);
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(() => {
    setLoading(true);
    setData(api.getConfig());
    setLoading(false);
  }, []);
  useEffect(() => { refresh(); }, [refresh]);

  const save = useCallback(async (config: AgentConfig) => {
    const updated = await api.updateConfig(config);
    setData(updated);
  }, []);

  return { data, loading, save };
}

export function useTradingPairs() {
  const [data, setData] = useState<TradingPair[]>([]);
  const refresh = useCallback(() => {
    setData(api.getTradingPairs());
  }, []);
  useEffect(() => { refresh(); }, [refresh]);
  return { data, refresh };
}
