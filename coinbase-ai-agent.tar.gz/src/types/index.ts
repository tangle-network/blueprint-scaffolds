export interface TokenBalance {
  symbol: string;
  name: string;
  balance: number;
  valueUsd: number;
  change24h: number;
  address: string;
  decimals: number;
}

export interface PortfolioSummary {
  totalValue: number;
  totalChange24h: number;
  totalChangePercent24h: number;
  tokens: TokenBalance[];
}

export interface TradeOrder {
  id: string;
  type: "buy" | "sell" | "swap";
  fromToken: string;
  toToken: string;
  fromAmount: number;
  toAmount: number;
  price: number;
  status: "pending" | "executing" | "completed" | "failed";
  timestamp: string;
  txHash?: string;
}

export interface AgentConfig {
  id: string;
  name: string;
  status: "active" | "paused" | "stopped";
  walletAddress: string;
  network: "base" | "ethereum";
  strategy: string;
  maxTradeSize: number;
  dailyLimit: number;
  stopLoss: number;
  takeProfit: number;
  allowedTokens: string[];
  autoRebalance: boolean;
  rebalanceThreshold: number;
  model: "gpt-4" | "claude-3.5";
  createdAt: string;
}

export interface AgentActivity {
  id: string;
  agentId: string;
  type: "trade" | "rebalance" | "alert" | "config_change" | "ai_decision";
  title: string;
  description: string;
  timestamp: string;
  data?: Record<string, unknown>;
}

export interface RiskMetrics {
  maxDrawdown: number;
  sharpeRatio: number;
  winRate: number;
  totalTrades: number;
  profitableTrades: number;
  avgTradeSize: number;
  dailyVolume: number;
  riskScore: number;
}

export interface TradingPair {
  from: string;
  to: string;
  price: number;
  change24h: number;
  volume24h: number;
}

export type AgentStatus = "active" | "paused" | "stopped";
