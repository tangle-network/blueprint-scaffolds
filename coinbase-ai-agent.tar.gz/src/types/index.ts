export interface TokenBalance {
  symbol: string;
  name: string;
  balance: number;
  value: number;
  price: number;
  change24h: number;
  icon: string;
}

export interface PortfolioSummary {
  totalValue: number;
  totalChange24h: number;
  totalChangePercent24h: number;
  tokens: TokenBalance[];
}

export interface AgentStatus {
  id: string;
  name: string;
  status: "running" | "paused" | "stopped" | "error";
  strategy: string;
  walletAddress: string;
  network: string;
  startedAt: string;
  lastAction: string;
  tradesToday: number;
  pnl24h: number;
  pnlPercent24h: number;
}

export interface Trade {
  id: string;
  type: "buy" | "sell" | "swap";
  fromToken: string;
  toToken: string;
  fromAmount: number;
  toAmount: number;
  price: number;
  timestamp: string;
  status: "pending" | "completed" | "failed";
  txHash: string;
  agentAction: boolean;
}

export interface TradingPair {
  from: string;
  to: string;
  rate: number;
  volume24h: number;
  change24h: number;
}

export interface RiskSettings {
  maxPositionSize: number;
  maxDailyLoss: number;
  maxDailyTrades: number;
  stopLossPercent: number;
  takeProfitPercent: number;
  allowedTokens: string[];
  slippageTolerance: number;
  autoRebalance: boolean;
  rebalanceThreshold: number;
}

export interface AgentConfig {
  name: string;
  strategy: "conservative" | "balanced" | "aggressive";
  llmProvider: "openai" | "anthropic";
  llmModel: string;
  apiKey: string;
  network: "base" | "ethereum";
  walletPrivateKey: string;
  riskSettings: RiskSettings;
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  type: "trade" | "rebalance" | "alert" | "config" | "system";
  message: string;
  details?: string;
}

export interface ChartDataPoint {
  time: string;
  value: number;
}
