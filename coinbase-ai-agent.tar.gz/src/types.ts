export interface AgentConfig {
  wallet_address: string;
  network: string;
  ai_model: string;
  max_trade_amount_usd: number;
  daily_limit_usd: number;
  stop_loss_pct: number;
  take_profit_pct: number;
  auto_trade_enabled: boolean;
  allowed_tokens: string[];
}

export interface TokenBalance {
  symbol: string;
  name: string;
  balance: number;
  value_usd: number;
  price_usd: number;
  change_24h: number;
}

export interface Portfolio {
  total_value_usd: number;
  change_24h: number;
  change_24h_usd: number;
  balances: TokenBalance[];
}

export interface Trade {
  id: string;
  timestamp: string;
  type: "buy" | "sell" | "swap";
  from_token: string;
  to_token: string;
  from_amount: number;
  to_amount: number;
  value_usd: number;
  status: "pending" | "completed" | "failed";
  tx_hash: string;
  reason: string;
}

export interface AgentActivity {
  id: string;
  timestamp: string;
  type: "trade" | "analysis" | "rebalance" | "alert" | "config";
  message: string;
  details?: Record<string, unknown>;
}

export interface AgentStatus {
  is_running: boolean;
  uptime_seconds: number;
  total_trades: number;
  total_pnl_usd: number;
  win_rate: number;
  last_trade_timestamp: string | null;
  current_strategy: string;
}

export interface RiskMetrics {
  current_exposure_usd: number;
  max_exposure_usd: number;
  daily_pnl_usd: number;
  daily_trade_count: number;
  max_daily_trades: number;
  portfolio_risk_score: number;
  is_circuit_breaker_active: boolean;
}

export interface TradeRequest {
  from_token: string;
  to_token: string;
  amount: number;
  reason?: string;
}

export const TOKEN_LIST = [
  { symbol: "ETH", name: "Ethereum", address: "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE" },
  { symbol: "USDC", name: "USD Coin", address: "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913" },
  { symbol: "WETH", name: "Wrapped Ether", address: "0x4200000000000000000000000000000000000006" },
  { symbol: "cbBTC", name: "Coinbase BTC", address: "0xcbB7C0000aB88B473b1f5aFd9ef808440eed33Bf" },
  { symbol: "USDbC", name: "USD Base Coin", address: "0xd9aAEc86B65D86f6A7B5B1b0c42FFA531710b6CA" },
  { symbol: "DAI", name: "Dai Stablecoin", address: "0x50c5725949A6F0c72E6C4a641F24049A917DB0Cb" },
];
