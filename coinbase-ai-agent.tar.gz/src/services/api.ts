import type {
  PortfolioSummary,
  AgentStatus,
  Trade,
  TradingPair,
  AgentConfig,
  ActivityLog,
  ChartDataPoint,
} from "@/types";

const API_BASE = "/api";

async function fetchApi<T>(path: string, init?: RequestInit): Promise<T> {
  try {
    const res = await fetch(`${API_BASE}${path}`, {
      headers: { "Content-Type": "application/json" },
      ...init,
    });
    if (res.ok) return res.json();
  } catch {}
  throw new Error("API unavailable");
}

function generatePortfolioData(): PortfolioSummary {
  return {
    totalValue: 48256.73,
    totalChange24h: 1234.56,
    totalChangePercent24h: 2.62,
    tokens: [
      { symbol: "ETH", name: "Ethereum", balance: 8.5, value: 29750.0, price: 3500.0, change24h: 3.2, icon: "⟠" },
      { symbol: "USDC", name: "USD Coin", balance: 10000, value: 10000.0, price: 1.0, change24h: 0.01, icon: "💲" },
      { symbol: "WBTC", name: "Wrapped Bitcoin", balance: 0.12, value: 7656.0, price: 63800.0, change24h: 1.8, icon: "₿" },
      { symbol: "BASE", name: "Base", balance: 1500, value: 850.73, price: 0.567, change24h: -1.2, icon: "🔵" },
    ],
  };
}

function generateAgentStatus(): AgentStatus {
  return {
    id: "agent-001",
    name: "Alpha Agent",
    status: "running",
    strategy: "balanced",
    walletAddress: "0x742d35Cc6634C0532925a3b844Bc9e7595f2bD38",
    network: "base",
    startedAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    lastAction: new Date(Date.now() - 120000).toISOString(),
    tradesToday: 5,
    pnl24h: 342.18,
    pnlPercent24h: 0.71,
  };
}

function generateTrades(): Trade[] {
  const now = Date.now();
  return [
    { id: "t1", type: "buy", fromToken: "USDC", toToken: "ETH", fromAmount: 1500, toAmount: 0.4286, price: 3500, timestamp: new Date(now - 300000).toISOString(), status: "completed", txHash: "0xabc123", agentAction: true },
    { id: "t2", type: "sell", fromToken: "ETH", toToken: "USDC", fromAmount: 0.5, toAmount: 1750, price: 3500, timestamp: new Date(now - 900000).toISOString(), status: "completed", txHash: "0xdef456", agentAction: true },
    { id: "t3", type: "swap", fromToken: "USDC", toToken: "WBTC", fromAmount: 2000, toAmount: 0.0313, price: 63800, timestamp: new Date(now - 1800000).toISOString(), status: "completed", txHash: "0xghi789", agentAction: false },
    { id: "t4", type: "buy", fromToken: "USDC", toToken: "BASE", fromAmount: 500, toAmount: 881.83, price: 0.567, timestamp: new Date(now - 3600000).toISOString(), status: "completed", txHash: "0xjkl012", agentAction: true },
    { id: "t5", type: "sell", fromToken: "BASE", toToken: "USDC", fromAmount: 200, toAmount: 113.4, price: 0.567, timestamp: new Date(now - 7200000).toISOString(), status: "completed", txHash: "0xmno345", agentAction: true },
    { id: "t6", type: "buy", fromToken: "USDC", toToken: "ETH", fromAmount: 2000, toAmount: 0.5714, price: 3500, timestamp: new Date(now - 14400000).toISOString(), status: "completed", txHash: "0xpqr678", agentAction: false },
    { id: "t7", type: "swap", fromToken: "ETH", toToken: "WBTC", fromAmount: 0.3, toAmount: 0.0165, price: 63636, timestamp: new Date(now - 28800000).toISOString(), status: "completed", txHash: "0xstu901", agentAction: true },
    { id: "t8", type: "buy", fromToken: "USDC", toToken: "ETH", fromAmount: 3000, toAmount: 0.8571, price: 3500, timestamp: new Date(now - 43200000).toISOString(), status: "pending", txHash: "0xvwx234", agentAction: true },
  ];
}

function generateTradingPairs(): TradingPair[] {
  return [
    { from: "ETH", to: "USDC", rate: 3500.0, volume24h: 12500000, change24h: 3.2 },
    { from: "WBTC", to: "USDC", rate: 63800.0, volume24h: 8900000, change24h: 1.8 },
    { from: "BASE", to: "USDC", rate: 0.567, volume24h: 3200000, change24h: -1.2 },
    { from: "ETH", to: "WBTC", rate: 0.0549, volume24h: 2100000, change24h: 2.1 },
    { from: "BASE", to: "ETH", rate: 0.000162, volume24h: 1500000, change24h: -4.3 },
  ];
}

function generateActivity(): ActivityLog[] {
  const now = Date.now();
  return [
    { id: "a1", timestamp: new Date(now - 120000).toISOString(), type: "trade", message: "Bought 0.4286 ETH for 1,500 USDC", details: "Agent executed buy order" },
    { id: "a2", timestamp: new Date(now - 900000).toISOString(), type: "trade", message: "Sold 0.5 ETH for 1,750 USDC", details: "Take profit triggered" },
    { id: "a3", timestamp: new Date(now - 1800000).toISOString(), type: "rebalance", message: "Portfolio rebalanced: increased WBTC allocation", details: "Threshold exceeded: 5% drift" },
    { id: "a4", timestamp: new Date(now - 3600000).toISOString(), type: "trade", message: "Bought 881.83 BASE for 500 USDC", details: "Diversification strategy" },
    { id: "a5", timestamp: new Date(now - 7200000).toISOString(), type: "alert", message: "ETH price reached $3,500 target", details: "Price alert triggered" },
    { id: "a6", timestamp: new Date(now - 14400000).toISOString(), type: "config", message: "Agent strategy updated to balanced", details: "User configuration change" },
    { id: "a7", timestamp: new Date(now - 28800000).toISOString(), type: "system", message: "Agent restarted successfully", details: "Scheduled maintenance" },
  ];
}

function generateChartData(): ChartDataPoint[] {
  const points: ChartDataPoint[] = [];
  const now = Date.now();
  let value = 45000;
  for (let i = 30; i >= 0; i--) {
    value += (Math.random() - 0.45) * 800;
    points.push({
      time: new Date(now - i * 86400000).toISOString().split("T")[0],
      value: Math.round(value * 100) / 100,
    });
  }
  return points;
}

const defaultConfig: AgentConfig = {
  name: "Alpha Agent",
  strategy: "balanced",
  llmProvider: "openai",
  llmModel: "gpt-4",
  apiKey: "",
  network: "base",
  walletPrivateKey: "",
  riskSettings: {
    maxPositionSize: 5000,
    maxDailyLoss: 500,
    maxDailyTrades: 20,
    stopLossPercent: 5,
    takeProfitPercent: 10,
    allowedTokens: ["ETH", "USDC", "WBTC", "BASE"],
    slippageTolerance: 0.5,
    autoRebalance: true,
    rebalanceThreshold: 5,
  },
};

export const api = {
  getPortfolio: (): PortfolioSummary => generatePortfolioData(),
  getAgentStatus: (): AgentStatus => generateAgentStatus(),
  getTrades: (): Trade[] => generateTrades(),
  getTradingPairs: (): TradingPair[] => generateTradingPairs(),
  getActivity: (): ActivityLog[] => generateActivity(),
  getChartData: (): ChartDataPoint[] => generateChartData(),
  getConfig: (): AgentConfig => ({ ...defaultConfig }),
  startAgent: async (): Promise<AgentStatus> => generateAgentStatus(),
  stopAgent: async (): Promise<AgentStatus> => ({ ...generateAgentStatus(), status: "stopped" }),
  executeTrade: async (trade: { fromToken: string; toToken: string; amount: number; type: "buy" | "sell" | "swap" }): Promise<Trade> => ({
    id: `t${Date.now()}`,
    ...trade,
    toAmount: trade.amount * 0.99,
    price: 0,
    timestamp: new Date().toISOString(),
    status: "pending",
    txHash: `0x${Math.random().toString(16).slice(2, 10)}`,
    agentAction: false,
  }),
  updateConfig: async (config: AgentConfig): Promise<AgentConfig> => config,
};
