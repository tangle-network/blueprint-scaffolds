import {
  AgentConfig,
  AgentStatus,
  Portfolio,
  Trade,
  AgentActivity,
  RiskMetrics,
  TradeRequest,
} from "../types";

const API_BASE = "/api";

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.detail || `API error ${res.status}`);
  }
  return res.json();
}

export const api = {
  getAgentStatus: () => request<AgentStatus>("/agent/status"),

  getAgentConfig: () => request<AgentConfig>("/agent/config"),

  updateAgentConfig: (config: Partial<AgentConfig>) =>
    request<AgentConfig>("/agent/config", {
      method: "PUT",
      body: JSON.stringify(config),
    }),

  startAgent: () => request<{ status: string }>("/agent/start", { method: "POST" }),

  stopAgent: () => request<{ status: string }>("/agent/stop", { method: "POST" }),

  getPortfolio: () => request<Portfolio>("/portfolio"),

  getTrades: (limit = 50) => request<Trade[]>(`/trades?limit=${limit}`),

  executeTrade: (trade: TradeRequest) =>
    request<Trade>("/trades/execute", {
      method: "POST",
      body: JSON.stringify(trade),
    }),

  getActivities: (limit = 100) =>
    request<AgentActivity[]>(`/activities?limit=${limit}`),

  getRiskMetrics: () => request<RiskMetrics>("/risk"),

  triggerRebalance: () =>
    request<{ message: string }>("/portfolio/rebalance", { method: "POST" }),
};
