import React from "react";
import { LayoutDashboard, LineChart, Settings, Shield, Activity, Bot } from "lucide-react";

export type Page = "dashboard" | "trading" | "portfolio" | "risk" | "settings";

interface Props {
  currentPage: Page;
  onNavigate: (page: Page) => void;
  isRunning: boolean;
}

const navItems: { page: Page; icon: React.ReactNode; label: string }[] = [
  { page: "dashboard", icon: <LayoutDashboard />, label: "Dashboard" },
  { page: "trading", icon: <LineChart />, label: "Trading" },
  { page: "portfolio", icon: <Bot />, label: "Portfolio" },
  { page: "risk", icon: <Shield />, label: "Risk Management" },
  { page: "settings", icon: <Settings />, label: "Settings" },
];

export default function Sidebar({ currentPage, onNavigate, isRunning }: Props) {
  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        <h1>
          <Activity size={22} />
          <span>AI</span> Trading Agent
        </h1>
        <div style={{ marginTop: 8, fontSize: 12, color: "var(--text-muted)", display: "flex", alignItems: "center" }}>
          <span className={`status-dot ${isRunning ? "running" : "stopped"}`} />
          {isRunning ? "Agent Running" : "Agent Stopped"}
        </div>
      </div>
      <nav className="sidebar-nav">
        {navItems.map(({ page, icon, label }) => (
          <button
            key={page}
            className={`nav-item ${currentPage === page ? "active" : ""}`}
            onClick={() => onNavigate(page)}
          >
            {icon}
            {label}
          </button>
        ))}
      </nav>
    </aside>
  );
}
