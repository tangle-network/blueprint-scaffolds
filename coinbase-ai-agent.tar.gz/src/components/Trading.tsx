import { useState } from "react";
import { useTrades } from "../hooks/useData";
import { api } from "../services/api";
import { TOKEN_LIST, TradeRequest } from "../types";
import { ArrowRight, RefreshCw, X } from "lucide-react";

function formatUSD(n: number) {
  return "$" + n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export default function Trading() {
  const { trades, refresh } = useTrades(50);
  const [showForm, setShowForm] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState<TradeRequest>({ from_token: "USDC", to_token: "WETH", amount: 100 });

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      await api.executeTrade(form);
      setShowForm(false);
      refresh();
    } catch (err) {
      alert(err instanceof Error ? err.message : "Trade failed");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div>
      <div className="page-header">
        <h2>Trading</h2>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="btn" onClick={refresh}>
            <RefreshCw size={14} /> Refresh
          </button>
          <button className="btn btn-primary" onClick={() => setShowForm(true)}>
            New Trade
          </button>
        </div>
      </div>

      <div className="card">
        <div className="card-header">
          <h3>Trade History</h3>
          <span style={{ fontSize: 13, color: "var(--text-muted)" }}>{trades.length} trades</span>
        </div>
        {trades.length === 0 ? (
          <div className="empty-state">No trades executed yet. Start the agent or execute a manual trade.</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Time</th>
                <th>Type</th>
                <th>From</th>
                <th>To</th>
                <th>Amount</th>
                <th>Value</th>
                <th>Status</th>
                <th>Reason</th>
              </tr>
            </thead>
            <tbody>
              {trades.map((t) => (
                <tr key={t.id}>
                  <td style={{ fontSize: 12, color: "var(--text-muted)" }}>
                    {new Date(t.timestamp).toLocaleString()}
                  </td>
                  <td><span className={`badge badge-${t.type}`}>{t.type}</span></td>
                  <td>{t.from_amount.toFixed(4)} {t.from_token}</td>
                  <td>{t.to_amount.toFixed(4)} {t.to_token}</td>
                  <td>{formatUSD(t.value_usd)}</td>
                  <td><span className={`badge badge-${t.status}`}>{t.status}</span></td>
                  <td style={{ fontSize: 12, maxWidth: 200, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                    {t.reason}
                  </td>
                  <td style={{ fontSize: 11, fontFamily: "monospace", color: "var(--text-muted)" }}>
                    {t.tx_hash ? t.tx_hash.slice(0, 10) + "..." : "—"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {showForm && (
        <div className="trade-form-overlay" onClick={() => setShowForm(false)}>
          <div className="trade-form-modal" onClick={(e) => e.stopPropagation()}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <h3>Execute Trade</h3>
              <button className="btn btn-sm" onClick={() => setShowForm(false)}><X size={14} /></button>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>From Token</label>
                <select value={form.from_token} onChange={(e) => setForm({ ...form, from_token: e.target.value })}>
                  {TOKEN_LIST.map((t) => <option key={t.symbol} value={t.symbol}>{t.symbol}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label>To Token</label>
                <select value={form.to_token} onChange={(e) => setForm({ ...form, to_token: e.target.value })}>
                  {TOKEN_LIST.map((t) => <option key={t.symbol} value={t.symbol}>{t.symbol}</option>)}
                </select>
              </div>
            </div>

            <div className="form-group">
              <label>Amount ({form.from_token})</label>
              <input
                type="number"
                value={form.amount}
                onChange={(e) => setForm({ ...form, amount: parseFloat(e.target.value) || 0 })}
                min={0}
                step="any"
              />
            </div>

            <div className="form-group">
              <label>Reason (optional)</label>
              <input
                type="text"
                value={form.reason || ""}
                onChange={(e) => setForm({ ...form, reason: e.target.value })}
                placeholder="Manual trade"
              />
            </div>

            <div style={{ background: "var(--bg-tertiary)", padding: 12, borderRadius: 8, marginBottom: 12, display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontWeight: 600 }}>{form.from_token}</span>
              <ArrowRight size={16} style={{ color: "var(--text-muted)" }} />
              <span style={{ fontWeight: 600 }}>{form.to_token}</span>
              <span style={{ marginLeft: "auto", color: "var(--text-muted)", fontSize: 13 }}>
                {form.amount} {form.from_token}
              </span>
            </div>

            <div className="trade-form-actions">
              <button className="btn" onClick={() => setShowForm(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleSubmit} disabled={submitting || form.amount <= 0}>
                {submitting ? "Executing..." : "Execute Trade"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
