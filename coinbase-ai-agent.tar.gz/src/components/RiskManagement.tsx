import { useRiskMetrics } from "../hooks/useData";
import { api } from "../services/api";
import { useAgentConfig } from "../hooks/useData";
import { Shield, AlertTriangle, RefreshCw, Activity, TrendingUp, BarChart3, DollarSign, Zap } from "lucide-react";

function formatUSD(n: number) {
  return "$" + n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export default function RiskManagement() {
  const { metrics, loading, refresh } = useRiskMetrics();
  const { config } = useAgentConfig();

  if (loading && !metrics) {
    return <div className="loading-spinner" />;
  }

  const riskScore = metrics?.portfolio_risk_score ?? 0;
  const riskLevel = riskScore < 30 ? "low" : riskScore < 70 ? "medium" : "high";
  const riskLabel = riskScore < 30 ? "Low Risk" : riskScore < 70 ? "Medium Risk" : "High Risk";
  const exposurePct = metrics ? (metrics.current_exposure_usd / metrics.max_exposure_usd) * 100 : 0;
  const dailyTradePct = metrics ? (metrics.daily_trade_count / metrics.max_daily_trades) * 100 : 0;

  return (
    <div>
      <div className="page-header">
        <h2>Risk Management</h2>
        <button className="btn" onClick={refresh}>
          <RefreshCw size={14} /> Refresh
        </button>
      </div>

      {metrics?.is_circuit_breaker_active && (
        <div className="circuit-breaker">
          <AlertTriangle size={18} />
          Circuit breaker is active — automated trading has been paused due to risk limits being exceeded.
        </div>
      )}

      <div className="stats-grid">
        <div className="stat-card">
          <div className="label"><Shield size={12} style={{ display: "inline", verticalAlign: "middle" }} /> Risk Score</div>
          <div className="value" style={{ color: riskLevel === "low" ? "var(--accent-green)" : riskLevel === "medium" ? "var(--accent-yellow)" : "var(--accent-red)" }}>
            {(riskScore * 100).toFixed(0)}
          </div>
          <div className="risk-meter">
            <div className={`risk-meter-fill risk-${riskLevel}`} style={{ width: `${riskScore * 100}%` }} />
          </div>
          <div style={{ fontSize: 12, color: "var(--text-muted)", marginTop: 4 }}>{riskLabel}</div>
        </div>
        <div className="stat-card">
          <div className="label"><DollarSign size={12} style={{ display: "inline", verticalAlign: "middle" }} /> Exposure</div>
          <div className="value">{metrics ? formatUSD(metrics.current_exposure_usd) : "—"}</div>
          <div style={{ fontSize: 12, color: "var(--text-muted)", marginTop: 4 }}>
            Max: {metrics ? formatUSD(metrics.max_exposure_usd) : "—"} ({exposurePct.toFixed(0)}% used)
          </div>
          <div className="risk-meter">
            <div className={`risk-meter-fill ${exposurePct > 80 ? "risk-high" : exposurePct > 50 ? "risk-medium" : "risk-low"}`} style={{ width: `${Math.min(exposurePct, 100)}%` }} />
          </div>
        </div>
        <div className="stat-card">
          <div className="label"><Activity size={12} style={{ display: "inline", verticalAlign: "middle" }} /> Daily Trades</div>
          <div className="value">{metrics?.daily_trade_count ?? 0} / {metrics?.max_daily_trades ?? "—"}</div>
          <div className="risk-meter">
            <div className={`risk-meter-fill ${dailyTradePct > 80 ? "risk-high" : dailyTradePct > 50 ? "risk-medium" : "risk-low"}`} style={{ width: `${Math.min(dailyTradePct, 100)}%` }} />
          </div>
        </div>
        <div className="stat-card">
          <div className="label"><TrendingUp size={12} style={{ display: "inline", verticalAlign: "middle" }} /> Daily P&L</div>
          <div className="value" style={{ color: metrics && metrics.daily_pnl_usd >= 0 ? "var(--accent-green)" : "var(--accent-red)" }}>
            {metrics ? formatUSD(metrics.daily_pnl_usd) : "—"}
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-header">
          <h3><BarChart3 size={16} style={{ display: "inline", verticalAlign: "middle", marginRight: 6 }} />Active Risk Rules</h3>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
          <div style={{ background: "var(--bg-tertiary)", padding: 16, borderRadius: 8 }}>
            <div style={{ fontSize: 13, color: "var(--text-muted)", marginBottom: 4 }}>Max Trade Amount</div>
            <div style={{ fontSize: 18, fontWeight: 700 }}>{config ? formatUSD(config.max_trade_amount_usd) : "—"}</div>
          </div>
          <div style={{ background: "var(--bg-tertiary)", padding: 16, borderRadius: 8 }}>
            <div style={{ fontSize: 13, color: "var(--text-muted)", marginBottom: 4 }}>Daily Limit</div>
            <div style={{ fontSize: 18, fontWeight: 700 }}>{config ? formatUSD(config.daily_limit_usd) : "—"}</div>
          </div>
          <div style={{ background: "var(--bg-tertiary)", padding: 16, borderRadius: 8 }}>
            <div style={{ fontSize: 13, color: "var(--text-muted)", marginBottom: 4 }}>Stop Loss</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: "var(--accent-red)" }}>{config ? `${config.stop_loss_pct}%` : "—"}</div>
          </div>
          <div style={{ background: "var(--bg-tertiary)", padding: 16, borderRadius: 8 }}>
            <div style={{ fontSize: 13, color: "var(--text-muted)", marginBottom: 4 }}>Take Profit</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: "var(--accent-green)" }}>{config ? `${config.take_profit_pct}%` : "—"}</div>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-header">
          <h3><Zap size={16} style={{ display: "inline", verticalAlign: "middle", marginRight: 6 }} />Circuit Breaker</h3>
        </div>
        <p style={{ fontSize: 14, color: "var(--text-secondary)", marginBottom: 12 }}>
          The circuit breaker automatically pauses trading when risk limits are exceeded. This includes daily loss limits,
          maximum exposure thresholds, and maximum trade frequency limits.
        </p>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontSize: 14, fontWeight: 600 }}>Status:</span>
          {metrics?.is_circuit_breaker_active ? (
            <span className="badge badge-failed">ACTIVE — Trading Paused</span>
          ) : (
            <span className="badge badge-completed">INACTIVE — Trading Enabled</span>
          )}
        </div>
      </div>
    </div>
  );
}
