import { useAgentStatus, usePortfolio, useTrades, useActivities } from "../hooks/useData";
import { TrendingUp, TrendingDown, BarChart3, Activity, DollarSign, Zap } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { useMemo } from "react";

function formatUSD(n: number) {
  return "$" + n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function formatTime(iso: string) {
  return new Date(iso).toLocaleTimeString();
}

export default function Dashboard() {
  const { status } = useAgentStatus();
  const { portfolio } = usePortfolio();
  const { trades } = useTrades(10);
  const { activities } = useActivities(10);

  const chartData = useMemo(() => {
    const pts = [];
    const now = Date.now();
    let val = portfolio?.total_value_usd ?? 10000;
    for (let i = 23; i >= 0; i--) {
      val = val * (1 + (Math.random() - 0.48) * 0.02);
      pts.push({
        time: new Date(now - i * 3600000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        value: Math.round(val * 100) / 100,
      });
    }
    if (portfolio) pts[pts.length - 1].value = portfolio.total_value_usd;
    return pts;
  }, [portfolio?.total_value_usd]);

  return (
    <div>
      <div className="page-header">
        <h2>Dashboard</h2>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <span style={{ fontSize: 13, color: "var(--text-muted)" }}>
            Strategy: {status?.current_strategy || "—"}
          </span>
        </div>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <div className="label">Portfolio Value</div>
          <div className="value">{portfolio ? formatUSD(portfolio.total_value_usd) : "—"}</div>
          <div className={`change ${portfolio && portfolio.change_24h >= 0 ? "positive" : "negative"}`}>
            {portfolio && portfolio.change_24h >= 0 ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
            {portfolio ? `${Math.abs(portfolio.change_24h).toFixed(2)}% (24h)` : ""}
          </div>
        </div>
        <div className="stat-card">
          <div className="label">Total P&L</div>
          <div className="value" style={{ color: status && status.total_pnl_usd >= 0 ? "var(--accent-green)" : "var(--accent-red)" }}>
            {status ? formatUSD(status.total_pnl_usd) : "—"}
          </div>
          <div className="change positive">
            <BarChart3 size={14} /> Win rate: {status ? (status.win_rate * 100).toFixed(1) + "%" : "—"}
          </div>
        </div>
        <div className="stat-card">
          <div className="label">Total Trades</div>
          <div className="value">{status?.total_trades ?? "—"}</div>
          <div className="change">
            <Activity size={14} /> {status?.last_trade_timestamp ? "Last: " + formatTime(status.last_trade_timestamp) : "No trades yet"}
          </div>
        </div>
        <div className="stat-card">
          <div className="label">Agent Uptime</div>
          <div className="value">{status ? formatDuration(status.uptime_seconds) : "—"}</div>
          <div className="change">
            <Zap size={14} /> {status?.is_running ? "Active" : "Stopped"}
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-header">
          <h3>Portfolio Value (24h)</h3>
          <DollarSign size={18} style={{ color: "var(--text-muted)" }} />
        </div>
        <div className="chart-container">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#4f8cff" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#4f8cff" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#2a2d3a" />
              <XAxis dataKey="time" tick={{ fill: "#5a5e72", fontSize: 11 }} />
              <YAxis tick={{ fill: "#5a5e72", fontSize: 11 }} tickFormatter={(v: number) => "$" + (v / 1000).toFixed(1) + "k"} />
              <Tooltip
                contentStyle={{ background: "#1a1d27", border: "1px solid #2a2d3a", borderRadius: 8, color: "#e8eaed" }}
                formatter={(value: number) => [formatUSD(value), "Value"]}
              />
              <Area type="monotone" dataKey="value" stroke="#4f8cff" fill="url(#colorValue)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        <div className="card">
          <div className="card-header">
            <h3>Recent Trades</h3>
          </div>
          {trades.length === 0 ? (
            <div className="empty-state">No trades yet</div>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Type</th>
                  <th>Pair</th>
                  <th>Value</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {trades.slice(0, 5).map((t) => (
                  <tr key={t.id}>
                    <td><span className={`badge badge-${t.type}`}>{t.type}</span></td>
                    <td>{t.from_token} → {t.to_token}</td>
                    <td>{formatUSD(t.value_usd)}</td>
                    <td><span className={`badge badge-${t.status}`}>{t.status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="card">
          <div className="card-header">
            <h3>Agent Activity</h3>
          </div>
          <div className="activity-list">
            {activities.length === 0 ? (
              <div className="empty-state">No activity yet</div>
            ) : (
              activities.slice(0, 6).map((a) => (
                <div className="activity-item" key={a.id}>
                  <div className={`activity-icon ${a.type}`}>
                    <Activity size={16} />
                  </div>
                  <div className="activity-content">
                    <div className="activity-message">{a.message}</div>
                    <div className="activity-time">{new Date(a.timestamp).toLocaleString()}</div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function formatDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m`;
}
