import { usePortfolio } from "../hooks/useData";
import { api } from "../services/api";
import { TrendingUp, TrendingDown, RefreshCw, Shuffle } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";

const COLORS = ["#4f8cff", "#34d399", "#a78bfa", "#fbbf24", "#f87171", "#fb923c"];

function formatUSD(n: number) {
  return "$" + n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export default function Portfolio() {
  const { portfolio, loading, refresh } = usePortfolio();

  if (loading && !portfolio) {
    return <div className="loading-spinner" />;
  }

  const pieData = portfolio
    ? portfolio.balances
        .filter((b) => b.value_usd > 0)
        .map((b) => ({ name: b.symbol, value: b.value_usd }))
    : [];

  const handleRebalance = async () => {
    try {
      await api.triggerRebalance();
      refresh();
    } catch (err) {
      alert(err instanceof Error ? err.message : "Rebalance failed");
    }
  };

  return (
    <div>
      <div className="page-header">
        <h2>Portfolio</h2>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="btn" onClick={refresh}>
            <RefreshCw size={14} /> Refresh
          </button>
          <button className="btn btn-primary" onClick={handleRebalance}>
            <Shuffle size={14} /> Rebalance
          </button>
        </div>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <div className="label">Total Value</div>
          <div className="value">{portfolio ? formatUSD(portfolio.total_value_usd) : "—"}</div>
          <div className={`change ${portfolio && portfolio.change_24h >= 0 ? "positive" : "negative"}`}>
            {portfolio && portfolio.change_24h >= 0 ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
            {portfolio ? `${portfolio.change_24h_usd >= 0 ? "+" : ""}${formatUSD(portfolio.change_24h_usd)} (24h)` : ""}
          </div>
        </div>
        <div className="stat-card">
          <div className="label">Assets</div>
          <div className="value">{portfolio?.balances.length ?? 0}</div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        <div className="card">
          <div className="card-header">
            <h3>Allocation</h3>
          </div>
          {pieData.length === 0 ? (
            <div className="empty-state">No assets</div>
          ) : (
            <>
              <div style={{ height: 250 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={2}>
                      {pieData.map((_, i) => (
                        <Cell key={i} fill={COLORS[i % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{ background: "#1a1d27", border: "1px solid #2a2d3a", borderRadius: 8, color: "#e8eaed" }}
                      formatter={(value: number) => [formatUSD(value), "Value"]}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 12, justifyContent: "center", marginTop: 8 }}>
                {pieData.map((d, i) => (
                  <div key={d.name} style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13 }}>
                    <div style={{ width: 10, height: 10, borderRadius: 2, background: COLORS[i % COLORS.length] }} />
                    <span>{d.name}</span>
                    <span style={{ color: "var(--text-muted)" }}>
                      {portfolio ? ((d.value / portfolio.total_value_usd) * 100).toFixed(1) : 0}%
                    </span>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>

        <div className="card">
          <div className="card-header">
            <h3>Token Balances</h3>
          </div>
          {portfolio && portfolio.balances.length > 0 ? (
            portfolio.balances.filter((b) => b.value_usd > 0).map((b) => (
              <div className="token-row" key={b.symbol}>
                <div className="token-info">
                  <div className="token-symbol">{b.symbol.slice(0, 2)}</div>
                  <div>
                    <div className="token-name">{b.symbol}</div>
                    <div className="token-fullname">{b.name}</div>
                  </div>
                </div>
                <div className="token-value">
                  <div className="token-balance">{b.balance.toFixed(4)} {b.symbol}</div>
                  <div className="token-usd">
                    {formatUSD(b.value_usd)}
                    <span style={{ marginLeft: 8, color: b.change_24h >= 0 ? "var(--accent-green)" : "var(--accent-red)" }}>
                      {b.change_24h >= 0 ? "+" : ""}{b.change_24h.toFixed(2)}%
                    </span>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="empty-state">No token balances</div>
          )}
        </div>
      </div>
    </div>
  );
}
