# Solana Prediction Market — Build Plan

## Architecture
- **Frontend**: Vite + React + TypeScript + TailwindCSS + shadcn/ui
- **Chain**: Anchor program on Solana (IDL types mirrored in frontend)
- **Oracle**: Pyth/Switchboard price feed integration

## Market Types
1. **Binary** — Yes/No outcomes
2. **Scalar** — Range [min, max] with continuous outcome
3. **Categorical** — Multiple discrete outcomes

## Pages
| Route | Page | Description |
|---|---|---|
| `/` | MarketBrowser | Browse/filter all markets |
| `/market/:id` | TradingInterface | Order book + AMM trading |
| `/positions` | PositionManagement | User's open positions |
| `/leaderboard` | Leaderboard | Top traders by PnL |
| `/create` | MarketCreation | Create binary/scalar/categorical market |

## Components
- `Layout.tsx` — Sidebar nav + wallet button
- `WalletProvider.tsx` — Solana wallet context
- `MarketCard.tsx` — Market preview card
- `OrderBook.tsx` — Bid/ask order book display
- `TradeForm.tsx` — Buy/sell form
- `AMMSwap.tsx` — AMM-based swap interface
- `PositionTable.tsx` — Positions table
- `ResolutionPanel.tsx` — Optimistic resolution + disputes
- `OracleFeed.tsx` — Oracle price display
- `CreateMarketWizard.tsx` — Multi-step market creation

## Hooks
- `useWallet.ts` — Wallet connection state
- `useMarkets.ts` — Fetch/filter markets
- `useOrders.ts` — Order book data
- `usePositions.ts` — User positions
- `useOracle.ts` — Pyth/Switchboard price feeds
- `useLeaderboard.ts` — Leaderboard data

## UI Components (shadcn/ui)
- button, card, input, label, progress, tabs, select, separator, dialog, toast, badge, dropdown-menu
