import { FC } from "react";
import { AppProvider, useApp } from "./hooks/useApp";
import { truncateAddress, resolutionStateLabel, marketBadgeClass, timeUntil, formatLamports, getOutcomePrice } from "./utils";

const MarketsView: FC = () => {
  const { markets, loading, createMarket, connected, walletAddress, connect } = useApp();

  if (!connected) {
    return (
      <div className="connect-prompt">
        <h2>Connect your wallet to get started</h2>
        <button className="wallet-btn" onClick={connect}>Connect Wallet</button>
      </div>
    );
  }

  return (
    <div>
      <h2 className="section-title">Markets</h2>
      {loading && <p>Loading...</p>}
      <div className="markets-grid">
        {markets.map((ms) => {
          const m = ms.market;
          return (
            <div className="market-card" key={m.publicKey}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <h3>{m.title}</h3>
                <span className={`status-badge ${marketBadgeClass(m)}`}>{resolutionStateLabel(m.resolutionState)}</span>
              </div>
              <p>{m.description}</p>
              <div className="market-meta">
                <span>Ends: {timeUntil(m.endTime)}</span>
                <span>Volume: {formatLamports(m.totalVolume)} USDC</span>
              </div>
              <div className="outcomes">
                {m.outcomes.map((outcome: string, i: number) => (
                  <button key={i} className={`outcome-btn ${i === 0 ? "yes" : "no"}`}>
                    {outcome} ({(getOutcomePrice(m, i) * 100).toFixed(0)}%)
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

const AppContent: FC = () => {
  const { connected, connect, disconnect, walletAddress } = useApp();

  return (
    <div>
      <header>
        <h1>Solana Prediction Market</h1>
        <button className="wallet-btn" onClick={connected ? disconnect : connect}>
          {connected && walletAddress ? truncateAddress(walletAddress) : "Connect Wallet"}
        </button>
      </header>
      <div className="container">
        <MarketsView />
      </div>
    </div>
  );
};

const App: FC = () => {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
};

export default App;
