import { useState } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { MarketBrowser } from './components/MarketBrowser';
import { MarketDetail } from './components/MarketDetail';
import { TradingInterface } from './components/TradingInterface';
import { PositionManager } from './components/PositionManager';
import { Leaderboard } from './components/Leaderboard';
import { CreateMarket } from './components/CreateMarket';
import type { Market } from './types';

type Tab = 'markets' | 'positions' | 'leaderboard' | 'create';

export function App() {
  const [tab, setTab] = useState<Tab>('markets');
  const [detailMarket, setDetailMarket] = useState<Market | null>(null);

  const handleSelectMarket = (m: Market) => {
    setDetailMarket(m);
  };

  const handleBack = () => {
    setDetailMarket(null);
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Header />
      <div style={{ display: 'flex', flex: 1 }}>
        <Sidebar tab={tab} onTabChange={(t) => { setTab(t as Tab); setDetailMarket(null); }} />
        <main style={{ flex: 1, padding: '24px', overflow: 'auto' }}>
          {tab === 'markets' && !detailMarket && (
            <MarketBrowser onSelectMarket={handleSelectMarket} />
          )}
          {tab === 'markets' && detailMarket && (
            <div className="grid" style={{ gridTemplateColumns: '1fr 380px', gap: 24 }}>
              <MarketDetail market={detailMarket} onBack={handleBack} />
              <TradingInterface market={detailMarket} />
            </div>
          )}
          {tab === 'positions' && <PositionManager />}
          {tab === 'leaderboard' && <Leaderboard />}
          {tab === 'create' && <CreateMarket />}
        </main>
      </div>
    </div>
  );
}
