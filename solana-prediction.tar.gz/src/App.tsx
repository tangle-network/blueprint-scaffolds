import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./components/Layout";
import MarketBrowser from "./pages/MarketBrowser";
import TradingInterface from "./pages/TradingInterface";
import PositionManagement from "./pages/PositionManagement";
import Leaderboard from "./pages/Leaderboard";
import MarketCreation from "./pages/MarketCreation";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<MarketBrowser />} />
          <Route path="/market/:id" element={<TradingInterface />} />
          <Route path="/positions" element={<PositionManagement />} />
          <Route path="/leaderboard" element={<Leaderboard />} />
          <Route path="/create" element={<MarketCreation />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
