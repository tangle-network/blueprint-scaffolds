import React from 'react';
import ReactDOM from 'react-dom/client';
import { App } from './App';
import { ConnectionProvider } from './contexts/ConnectionContext';
import { MarketProvider } from './contexts/MarketContext';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ConnectionProvider>
      <MarketProvider>
        <App />
      </MarketProvider>
    </ConnectionProvider>
  </React.StrictMode>
);
