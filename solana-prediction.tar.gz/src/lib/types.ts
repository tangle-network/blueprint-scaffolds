export type MarketType = "binary" | "scalar" | "categorical";

export type MarketStatus = "open" | "closed" | "resolved" | "disputed";

export type OrderSide = "buy" | "sell";

export type OrderStatus = "open" | "filled" | "cancelled";

export type OracleSource = "pyth" | "switchboard";

export interface Market {
  id: string;
  title: string;
  description: string;
  type: MarketType;
  status: MarketStatus;
  creator: string;
  createdAt: number;
  endTime: number;
  outcomes: string[];
  outcomePrices: number[];
  volume: number;
  liquidity: number;
  oracleSource: OracleSource;
  oracleFeed: string;
  scalarMin?: number;
  scalarMax?: number;
  resolutionOutcome?: string;
  resolutionValue?: number;
  disputeCount: number;
  category: string;
}

export interface OrderBookEntry {
  price: number;
  quantity: number;
  total: number;
}

export interface OrderBook {
  marketId: string;
  bids: OrderBookEntry[];
  asks: OrderBookEntry[];
  spread: number;
  midPrice: number;
}

export interface Order {
  id: string;
  marketId: string;
  side: OrderSide;
  outcome: string;
  price: number;
  quantity: number;
  filledQuantity: number;
  owner: string;
  createdAt: number;
  status: OrderStatus;
}

export interface Position {
  id: string;
  marketId: string;
  marketTitle: string;
  outcome: string;
  quantity: number;
  avgPrice: number;
  currentPrice: number;
  pnl: number;
  pnlPercent: number;
  marketType: MarketType;
  value: number;
}

export interface OraclePrice {
  feed: string;
  source: OracleSource;
  price: number;
  confidence: number;
  updatedAt: number;
}

export interface LeaderboardEntry {
  rank: number;
  address: string;
  pnl: number;
  volume: number;
  marketsTraded: number;
  winRate: number;
  totalTrades: number;
}

export interface TradeResult {
  success: boolean;
  txSignature?: string;
  error?: string;
}

export interface CreateMarketParams {
  title: string;
  description: string;
  type: MarketType;
  outcomes: string[];
  endTime: number;
  oracleSource: OracleSource;
  oracleFeed: string;
  scalarMin?: number;
  scalarMax?: number;
  category: string;
  initialLiquidity: number;
}

export interface WalletState {
  connected: boolean;
  address: string | null;
  balance: number;
}
