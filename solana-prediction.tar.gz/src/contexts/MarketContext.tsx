import React, { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import type { Market, Position, Trade, LeaderboardEntry } from '../types';

interface MarketState {
  markets: Market[];
  positions: Position[];
  trades: Trade[];
  leaderboard: LeaderboardEntry[];
  selectedMarket: Market | null;
  selectMarket: (m: Market | null) => void;
  executeTrade: (marketId: string, outcomeId: number, side: 'buy' | 'sell', amount: number, price: number) => void;
  createMarket: (market: Omit<Market, 'id' | 'status' | 'totalVolume' | 'liquidity' | 'outcomes'> & { outcomes: string[] }) => void;
  resolveMarket: (marketId: string, outcomeId: number) => void;
  disputeResolution: (marketId: string) => void;
}

const MarketContext = createContext<MarketState | null>(null);

const DEMO_MARKETS: Market[] = [
  {
    id: 'm1',
    title: 'Will BTC exceed $150k by end of 2026?',
    description: 'Binary market resolving YES if Bitcoin price exceeds $150,000 USD on any major exchange before Dec 31 2026 23:59 UTC.',
    marketType: 'binary',
    status: 'active',
    outcomes: [
      { id: 0, label: 'Yes', probability: 0.62, volume: 125000 },
      { id: 1, label: 'No', probability: 0.38, volume: 78000 },
    ],
    resolutionSource: 'Pyth BTC/USD Price Feed',
    endDate: Date.now() + 180 * 86400000,
    totalVolume: 203000,
    liquidity: 45000,
    creator: '7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU',
    oracleType: 'pyth',
  },
  {
    id: 'm2',
    title: 'ETH price at end of Q2 2026',
    description: 'Scalar market resolving to the ETH/USD price on June 30 2026 23:59 UTC.',
    marketType: 'scalar',
    status: 'active',
    outcomes: [
      { id: 0, label: '< $2,000', probability: 0.08, volume: 12000 },
      { id: 1, label: '$2,000 - $3,000', probability: 0.22, volume: 34000 },
      { id: 2, label: '$3,000 - $4,000', probability: 0.35, volume: 56000 },
      { id: 3, label: '$4,000 - $5,000', probability: 0.25, volume: 41000 },
      { id: 4, label: '> $5,000', probability: 0.10, volume: 16000 },
    ],
    resolutionSource: 'Switchboard ETH/USD Feed',
    endDate: Date.now() + 90 * 86400000,
    totalVolume: 159000,
    liquidity: 32000,
    creator: '9xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU',
    scalarMin: 1000,
    scalarMax: 6000,
    oracleType: 'switchboard',
  },
  {
    id: 'm3',
    title: 'Which L1 will have highest TVL in 2026?',
    description: 'Categorical market resolving to the L1 blockchain with the highest Total Value Locked as reported by DeFi Llama on Dec 31 2026.',
    marketType: 'categorical',
    status: 'active',
    outcomes: [
      { id: 0, label: 'Ethereum', probability: 0.55, volume: 95000 },
      { id: 1, label: 'Solana', probability: 0.25, volume: 43000 },
      { id: 2, label: 'BNB Chain', probability: 0.08, volume: 14000 },
      { id: 3, label: 'Avalanche', probability: 0.05, volume: 8000 },
      { id: 4, label: 'Other', probability: 0.07, volume: 12000 },
    ],
    resolutionSource: 'DeFi Llama TVL Aggregator',
    endDate: Date.now() + 270 * 86400000,
    totalVolume: 172000,
    liquidity: 28000,
    creator: '5xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU',
    oracleType: 'manual',
  },
  {
    id: 'm4',
    title: 'Will Solana ETF be approved by SEC in 2026?',
    description: 'Binary market resolving YES if the US SEC approves a Solana spot ETF before Dec 31 2026.',
    marketType: 'binary',
    status: 'active',
    outcomes: [
      { id: 0, label: 'Yes', probability: 0.41, volume: 67000 },
      { id: 1, label: 'No', probability: 0.59, volume: 96000 },
    ],
    resolutionSource: 'SEC Official Filings',
    endDate: Date.now() + 250 * 86400000,
    totalVolume: 163000,
    liquidity: 38000,
    creator: '3xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU',
    oracleType: 'manual',
  },
  {
    id: 'm5',
    title: 'Fed interest rate after June 2026 FOMC',
    description: 'Categorical market resolving to the federal funds target rate range after the June 2026 FOMC meeting.',
    marketType: 'categorical',
    status: 'pending_resolution',
    outcomes: [
      { id: 0, label: '< 3.00%', probability: 0.12, volume: 18000 },
      { id: 1, label: '3.00% - 4.00%', probability: 0.45, volume: 72000 },
      { id: 2, label: '4.00% - 5.00%', probability: 0.33, volume: 52000 },
      { id: 3, label: '> 5.00%', probability: 0.10, volume: 15000 },
    ],
    resolutionSource: 'Federal Reserve Press Release',
    endDate: Date.now() - 2 * 86400000,
    totalVolume: 157000,
    liquidity: 41000,
    creator: '1xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU',
    oracleType: 'pyth',
  },
  {
    id: 'm6',
    title: 'SOL price at end of 2026 Q1',
    description: 'Scalar market resolving to SOL/USD price on March 31 2026.',
    marketType: 'scalar',
    status: 'disputed',
    outcomes: [
      { id: 0, label: '< $100', probability: 0.05, volume: 8000 },
      { id: 1, label: '$100 - $150', probability: 0.20, volume: 32000 },
      { id: 2, label: '$150 - $200', probability: 0.40, volume: 64000 },
      { id: 3, label: '$200 - $300', probability: 0.28, volume: 45000 },
      { id: 4, label: '> $300', probability: 0.07, volume: 11000 },
    ],
    resolutionSource: 'Pyth SOL/USD Price Feed',
    endDate: Date.now() - 5 * 86400000,
    totalVolume: 160000,
    liquidity: 35000,
    creator: '2xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU',
    resolutionValue: 187.42,
    resolvedOutcome: 2,
    disputeDeadline: Date.now() + 3 * 86400000,
    scalarMin: 50,
    scalarMax: 400,
    oracleType: 'pyth',
  },
];

const DEMO_POSITIONS: Position[] = [
  { marketId: 'm1', outcomeId: 0, outcomeLabel: 'Yes', shares: 500, avgPrice: 0.58, marketTitle: 'Will BTC exceed $150k by end of 2026?' },
  { marketId: 'm2', outcomeId: 2, outcomeLabel: '$3,000 - $4,000', shares: 300, avgPrice: 0.32, marketTitle: 'ETH price at end of Q2 2026' },
  { marketId: 'm3', outcomeId: 1, outcomeLabel: 'Solana', shares: 1000, avgPrice: 0.22, marketTitle: 'Which L1 will have highest TVL in 2026?' },
  { marketId: 'm4', outcomeId: 0, outcomeLabel: 'Yes', shares: 250, avgPrice: 0.38, marketTitle: 'Will Solana ETF be approved by SEC in 2026?' },
];

const DEMO_TRADES: Trade[] = [
  { id: 't1', marketId: 'm1', outcomeId: 0, side: 'buy', price: 0.58, amount: 500, timestamp: Date.now() - 86400000 },
  { id: 't2', marketId: 'm1', outcomeId: 0, side: 'buy', price: 0.60, amount: 200, timestamp: Date.now() - 43200000 },
  { id: 't3', marketId: 'm2', outcomeId: 2, side: 'buy', price: 0.32, amount: 300, timestamp: Date.now() - 172800000 },
  { id: 't4', marketId: 'm3', outcomeId: 1, side: 'buy', price: 0.22, amount: 1000, timestamp: Date.now() - 259200000 },
  { id: 't5', marketId: 'm4', outcomeId: 0, side: 'buy', price: 0.38, amount: 250, timestamp: Date.now() - 345600000 },
];

const DEMO_LEADERBOARD: LeaderboardEntry[] = [
  { rank: 1, address: '7xKXtg2...AsU', pnl: 45230, volume: 312000, marketsTraded: 28, winRate: 0.78 },
  { rank: 2, address: '9xKXtg2...AsU', pnl: 38100, volume: 287000, marketsTraded: 34, winRate: 0.74 },
  { rank: 3, address: '5xKXtg2...AsU', pnl: 29750, volume: 195000, marketsTraded: 22, winRate: 0.72 },
  { rank: 4, address: '3xKXtg2...AsU', pnl: 22400, volume: 178000, marketsTraded: 19, winRate: 0.68 },
  { rank: 5, address: '1xKXtg2...AsU', pnl: 18600, volume: 142000, marketsTraded: 15, winRate: 0.67 },
  { rank: 6, address: '2xKXtg2...AsU', pnl: 15200, volume: 128000, marketsTraded: 21, winRate: 0.62 },
  { rank: 7, address: '4xKXtg2...AsU', pnl: 11800, volume: 95000, marketsTraded: 12, winRate: 0.58 },
  { rank: 8, address: '6xKXtg2...AsU', pnl: 8900, volume: 82000, marketsTraded: 10, winRate: 0.55 },
];

export function MarketProvider({ children }: { children: ReactNode }) {
  const [markets, setMarkets] = useState<Market[]>(DEMO_MARKETS);
  const [positions, setPositions] = useState<Position[]>(DEMO_POSITIONS);
  const [trades, setTrades] = useState<Trade[]>(DEMO_TRADES);
  const [leaderboard] = useState<LeaderboardEntry[]>(DEMO_LEADERBOARD);
  const [selectedMarket, setSelectedMarket] = useState<Market | null>(null);

  const selectMarket = useCallback((m: Market | null) => {
    setSelectedMarket(m);
  }, []);

  const executeTrade = useCallback(
    (marketId: string, outcomeId: number, side: 'buy' | 'sell', amount: number, price: number) => {
      const trade: Trade = {
        id: `t${Date.now()}`,
        marketId,
        outcomeId,
        side,
        price,
        amount,
        timestamp: Date.now(),
      };
      setTrades((prev) => [trade, ...prev]);

      setMarkets((prev) =>
        prev.map((m) => {
          if (m.id !== marketId) return m;
          return {
            ...m,
            totalVolume: m.totalVolume + amount * price,
            outcomes: m.outcomes.map((o) => {
              if (o.id !== outcomeId) return o;
              const delta = side === 'buy' ? 0.02 : -0.02;
              return { ...o, probability: Math.min(0.99, Math.max(0.01, o.probability + delta)), volume: o.volume + amount * price };
            }),
          };
        })
      );

      if (side === 'buy') {
        setPositions((prev) => {
          const existing = prev.find((p) => p.marketId === marketId && p.outcomeId === outcomeId);
          const market = markets.find((m) => m.id === marketId);
          const outcome = market?.outcomes.find((o) => o.id === outcomeId);
          if (existing) {
            const totalShares = existing.shares + amount;
            const newAvg = (existing.avgPrice * existing.shares + price * amount) / totalShares;
            return prev.map((p) =>
              p.marketId === marketId && p.outcomeId === outcomeId ? { ...p, shares: totalShares, avgPrice: newAvg } : p
            );
          }
          if (!market || !outcome) return prev;
          return [
            ...prev,
            { marketId, outcomeId, outcomeLabel: outcome.label, shares: amount, avgPrice: price, marketTitle: market.title },
          ];
        });
      } else {
        setPositions((prev) =>
          prev
            .map((p) =>
              p.marketId === marketId && p.outcomeId === outcomeId ? { ...p, shares: p.shares - amount } : p
            )
            .filter((p) => p.shares > 0)
        );
      }
    },
    [markets]
  );

  const createMarket = useCallback(
    (input: Omit<Market, 'id' | 'status' | 'totalVolume' | 'liquidity' | 'outcomes'> & { outcomes: string[] }) => {
      const m: Market = {
        ...input,
        id: `m${Date.now()}`,
        status: 'active',
        totalVolume: 0,
        liquidity: 0,
        outcomes: input.outcomes.map((label, i) => ({
          id: i,
          label,
          probability: 1 / input.outcomes.length,
          volume: 0,
        })),
      };
      setMarkets((prev) => [m, ...prev]);
    },
    []
  );

  const resolveMarket = useCallback((marketId: string, outcomeId: number) => {
    setMarkets((prev) =>
      prev.map((m) => {
        if (m.id !== marketId) return m;
        return { ...m, status: 'pending_resolution' as const, resolvedOutcome: outcomeId };
      })
    );
  }, []);

  const disputeResolution = useCallback((marketId: string) => {
    setMarkets((prev) =>
      prev.map((m) => {
        if (m.id !== marketId) return m;
        return { ...m, status: 'disputed' as const, disputeDeadline: Date.now() + 3 * 86400000 };
      })
    );
  }, []);

  return (
    <MarketContext.Provider
      value={{ markets, positions, trades, leaderboard, selectedMarket, selectMarket, executeTrade, createMarket, resolveMarket, disputeResolution }}
    >
      {children}
    </MarketContext.Provider>
  );
}

export function useMarket() {
  const ctx = useContext(MarketContext);
  if (!ctx) throw new Error('useMarket must be used within MarketProvider');
  return ctx;
}
