import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import { Connection, clusterApiUrl } from '@solana/web3.js';

interface ConnectionState {
  connection: Connection;
  endpoint: string;
  setEndpoint: (ep: string) => void;
}

const ConnectionContext = createContext<ConnectionState | null>(null);

const ENDPOINTS: Record<string, string> = {
  devnet: clusterApiUrl('devnet'),
  testnet: clusterApiUrl('testnet'),
  mainnet: clusterApiUrl('mainnet-beta'),
  localnet: 'http://127.0.0.1:8899',
};

export function ConnectionProvider({ children }: { children: ReactNode }) {
  const [endpoint, setEndpointStr] = useState('devnet');

  const connection = new Connection(
    ENDPOINTS[endpoint] || ENDPOINTS.devnet,
    'confirmed'
  );

  const setEndpoint = useCallback((ep: string) => {
    setEndpointStr(ep);
  }, []);

  return (
    <ConnectionContext.Provider value={{ connection, endpoint, setEndpoint }}>
      {children}
    </ConnectionContext.Provider>
  );
}

export function useConnection() {
  const ctx = useContext(ConnectionContext);
  if (!ctx) throw new Error('useConnection must be used within ConnectionProvider');
  return ctx;
}
