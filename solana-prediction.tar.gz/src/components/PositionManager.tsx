import React from 'react'

export function PositionManager(props: Record<string, any>) { return <div>{props.children}</div> }
