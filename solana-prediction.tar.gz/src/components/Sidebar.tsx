interface SidebarProps {
  tab: string;
  onTabChange: (tab: string) => void;
}

const NAV_ITEMS = [
  { id: 'markets', label: 'Markets', icon: '📊' },
  { id: 'positions', label: 'Positions', icon: '💼' },
  { id: 'leaderboard', label: 'Leaderboard', icon: '🏆' },
  { id: 'create', label: 'Create Market', icon: '➕' },
];

export function Sidebar({ tab, onTabChange }: SidebarProps) {
  return (
    <nav style={{
      width: 220,
      background: 'var(--bg-secondary)',
      borderRight: '1px solid var(--border)',
      padding: '16px 12px',
      display: 'flex',
      flexDirection: 'column',
      gap: 4,
    }}>
      {NAV_ITEMS.map((item) => (
        <button
          key={item.id}
          onClick={() => onTabChange(item.id)}
          className={tab === item.id ? 'btn-outline active' : 'btn-outline'}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            width: '100%',
            textAlign: 'left',
            padding: '12px 14px',
            borderRadius: 8,
          }}
        >
          <span>{item.icon}</span>
          <span>{item.label}</span>
        </button>
      ))}
      <div style={{ flex: 1 }} />
      <div className="card text-xs text-muted" style={{ padding: 12 }}>
        <div className="flex-between mb-8">
          <span>Network</span>
          <span className="text-accent">Solana</span>
        </div>
        <div className="flex-between mb-8">
          <span>Program</span>
          <span className="font-mono">v0.1.0</span>
        </div>
        <div className="flex-between">
          <span>Markets</span>
          <span className="text-green">Live</span>
        </div>
      </div>
    </nav>
  );
}
