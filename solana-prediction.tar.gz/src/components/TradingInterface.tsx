import React from 'react'

export function TradingInterface(props: Record<string, any>) { return <div>{props.children}</div> }
