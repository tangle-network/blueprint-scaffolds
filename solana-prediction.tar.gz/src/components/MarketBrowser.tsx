import { useState } from 'react';
import { useMarket } from '../contexts/MarketContext';
import type { Market, MarketType, MarketStatus } from '../types';

interface MarketBrowserProps {
  onSelectMarket: (m: Market) => void;
}

const TYPE_FILTERS: { value: MarketType | 'all'; label: string }[] = [
  { value: 'all', label: 'All' },
  { value: 'binary', label: 'Binary' },
  { value: 'scalar', label: 'Scalar' },
  { value: 'categorical', label: 'Categorical' },
];

const STATUS_FILTERS: { value: MarketStatus | 'all'; label: string }[] = [
  { value: 'all', label: 'All' },
  { value: 'active', label: 'Active' },
  { value: 'pending_resolution', label: 'Pending' },
  { value: 'disputed', label: 'Disputed' },
  { value: 'resolved', label: 'Resolved' },
];

function MarketCard({ market, onClick }: { market: Market; onClick: () => void }) {
  const statusColor: Record<string, string> = {
    active: 'var(--green)',
    closed: 'var(--text-secondary)',
    pending_resolution: 'var(--yellow)',
    disputed: 'var(--red)',
    resolved: 'var(--accent)',
  };

  const typeLabel: Record<string, string> = {
    binary: 'Binary',
    scalar: 'Scalar',
    categorical: 'Categorical',
  };

  return (
    <div
      className="card"
      style={{ cursor: 'pointer', transition: 'border-color 0.2s' }}
      onClick={onClick}
      onMouseEnter={(e) => (e.currentTarget.style.borderColor = 'var(--accent)')}
      onMouseLeave={(e) => (e.currentTarget.style.borderColor = 'var(--border)')}
    >
      <div className="flex-between mb-8">
        <span
          className="text-xs font-bold"
          style={{
            background: 'rgba(99,102,241,0.15)',
            color: 'var(--accent)',
            padding: '3px 8px',
            borderRadius: 4,
          }}
        >
          {typeLabel[market.marketType]}
        </span>
        <span className="text-xs flex gap-8" style={{ gap: 8 }}>
          <span style={{ color: statusColor[market.status] }}>● {market.status.replace('_', ' ')}</span>
        </span>
      </div>
      <h3 style={{ fontSize: 16, fontWeight: 600, marginBottom: 8, lineHeight: 1.4 }}>{market.title}</h3>
      <p className="text-sm text-muted mb-16" style={{ lineHeight: 1.5 }}>{market.description.slice(0, 120)}...</p>

      <div style={{ display: 'flex', gap: 6, marginBottom: 12 }}>
        {market.outcomes.slice(0, 4).map((o) => (
          <div
            key={o.id}
            style={{
              flex: o.probability,
              height: 6,
              background: o.id === 0 ? 'var(--green)' : o.id === 1 ? 'var(--red)' : 'var(--accent)',
              borderRadius: 3,
              opacity: 0.8,
            }}
          />
        ))}
      </div>

      <div className="flex-between text-xs text-muted">
        <span>Vol: ${(market.totalVolume / 1000).toFixed(0)}K</span>
        <span>Liq: ${(market.liquidity / 1000).toFixed(0)}K</span>
        <span>Oracle: {market.oracleType}</span>
        <span>{new Date(market.endDate).toLocaleDateString()}</span>
      </div>
    </div>
  );
}

export function MarketBrowser({ onSelectMarket }: MarketBrowserProps) {
  const { markets } = useMarket();
  const [typeFilter, setTypeFilter] = useState<MarketType | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<MarketStatus | 'all'>('all');
  const [search, setSearch] = useState('');

  const filtered = markets.filter((m) => {
    if (typeFilter !== 'all' && m.marketType !== typeFilter) return false;
    if (statusFilter !== 'all' && m.status !== statusFilter) return false;
    if (search && !m.title.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  return (
    <div>
      <div className="flex-between mb-24">
        <h2 style={{ fontSize: 24, fontWeight: 700 }}>Prediction Markets</h2>
        <span className="text-muted text-sm">{filtered.length} markets</span>
      </div>

      <div className="flex gap-12 mb-16" style={{ flexWrap: 'wrap' }}>
        <input
          placeholder="Search markets..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ width: 300 }}
        />
        <div className="flex gap-8">
          {TYPE_FILTERS.map((f) => (
            <button
              key={f.value}
              className={typeFilter === f.value ? 'btn-outline active' : 'btn-outline'}
              onClick={() => setTypeFilter(f.value)}
              style={{ padding: '8px 14px', fontSize: 12 }}
            >
              {f.label}
            </button>
          ))}
        </div>
        <div className="flex gap-8">
          {STATUS_FILTERS.map((f) => (
            <button
              key={f.value}
              className={statusFilter === f.value ? 'btn-outline active' : 'btn-outline'}
              onClick={() => setStatusFilter(f.value)}
              style={{ padding: '8px 14px', fontSize: 12 }}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))' }}>
        {filtered.map((m) => (
          <MarketCard key={m.id} market={m} onClick={() => onSelectMarket(m)} />
        ))}
      </div>
      {filtered.length === 0 && (
        <div className="card text-center text-muted mt-24" style={{ padding: 40 }}>
          No markets match your filters.
        </div>
      )}
    </div>
  );
}
