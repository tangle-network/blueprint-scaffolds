import React from 'react'

export function Leaderboard(props: Record<string, any>) { return <div>{props.children}</div> }
