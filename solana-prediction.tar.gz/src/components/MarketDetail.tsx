import { useMarket } from '../contexts/MarketContext';
import type { Market } from '../types';

interface MarketDetailProps {
  market: Market;
  onBack: () => void;
}

function ProbabilityBar({ outcomes }: { outcomes: Market['outcomes'] }) {
  const colors = ['#22c55e', '#ef4444', '#6366f1', '#eab308', '#f97316', '#06b6d4', '#ec4899'];
  return (
    <div style={{ display: 'flex', height: 32, borderRadius: 8, overflow: 'hidden', marginBottom: 16 }}>
      {outcomes.map((o, i) => (
        <div
          key={o.id}
          style={{
            width: `${o.probability * 100}%`,
            background: colors[i % colors.length],
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: 11,
            fontWeight: 700,
            color: 'white',
            minWidth: o.probability > 0.05 ? 40 : 0,
          }}
        >
          {o.probability > 0.05 ? `${(o.probability * 100).toFixed(0)}%` : ''}
        </div>
      ))}
    </div>
  );
}

function OrderBookSim({ market }: { market: Market }) {
  const topOutcome = market.outcomes[0];
  const spread = 0.03;
  const asks = Array.from({ length: 6 }, (_, i) => ({
    price: topOutcome.probability + spread * (i + 1),
    size: Math.floor(Math.random() * 500 + 100),
  })).reverse();
  const bids = Array.from({ length: 6 }, (_, i) => ({
    price: topOutcome.probability - spread * (i + 1),
    size: Math.floor(Math.random() * 500 + 100),
  }));

  return (
    <div style={{ fontSize: 12, fontFamily: 'monospace' }}>
      <div className="flex-between text-muted text-xs mb-8">
        <span>Price</span>
        <span>Size</span>
      </div>
      {asks.map((a, i) => (
        <div key={`a${i}`} className="flex-between" style={{ padding: '2px 0' }}>
          <span className="text-red">{a.price.toFixed(3)}</span>
          <span>{a.size}</span>
        </div>
      ))}
      <div style={{ padding: '6px 0', borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)', textAlign: 'center', fontWeight: 700, color: 'var(--accent)' }}>
        {topOutcome.probability.toFixed(3)}
      </div>
      {bids.map((b, i) => (
        <div key={`b${i}`} className="flex-between" style={{ padding: '2px 0' }}>
          <span className="text-green">{b.price.toFixed(3)}</span>
          <span>{b.size}</span>
        </div>
      ))}
    </div>
  );
}

export function MarketDetail({ market, onBack }: MarketDetailProps) {
  const { resolveMarket, disputeResolution } = useMarket();

  const statusBadge = (status: string) => {
    const colors: Record<string, string> = {
      active: 'var(--green)',
      closed: 'var(--text-secondary)',
      pending_resolution: 'var(--yellow)',
      disputed: 'var(--red)',
      resolved: 'var(--accent)',
    };
    return (
      <span style={{ color: colors[status] || 'var(--text-secondary)', fontWeight: 600 }}>
        ● {status.replace('_', ' ').toUpperCase()}
      </span>
    );
  };

  return (
    <div>
      <button className="btn-outline mb-16" onClick={onBack} style={{ padding: '6px 14px', fontSize: 12 }}>
        ← Back to Markets
      </button>

      <div className="card mb-16">
        <div className="flex-between mb-8">
          <span className="text-xs text-accent font-bold">{market.marketType.toUpperCase()}</span>
          {statusBadge(market.status)}
        </div>
        <h2 style={{ fontSize: 22, fontWeight: 700, marginBottom: 12 }}>{market.title}</h2>
        <p className="text-sm text-muted mb-16" style={{ lineHeight: 1.6 }}>{market.description}</p>

        <ProbabilityBar outcomes={market.outcomes} />

        <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))' }}>
          {market.outcomes.map((o) => (
            <div key={o.id} className="card" style={{ padding: 12, textAlign: 'center' }}>
              <div className="text-xs text-muted mb-8">{o.label}</div>
              <div className="font-bold" style={{ fontSize: 18, color: 'var(--accent)' }}>
                {(o.probability * 100).toFixed(1)}%
              </div>
              <div className="text-xs text-muted mt-8">Vol: ${(o.volume / 1000).toFixed(1)}K</div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid" style={{ gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <div className="card">
          <h4 className="font-bold mb-16">Order Book</h4>
          <OrderBookSim market={market} />
        </div>

        <div className="card">
          <h4 className="font-bold mb-16">Market Info</h4>
          <div style={{ fontSize: 13 }}>
            <div className="flex-between mb-8">
              <span className="text-muted">End Date</span>
              <span>{new Date(market.endDate).toLocaleDateString()}</span>
            </div>
            <div className="flex-between mb-8">
              <span className="text-muted">Total Volume</span>
              <span>${(market.totalVolume / 1000).toFixed(1)}K</span>
            </div>
            <div className="flex-between mb-8">
              <span className="text-muted">Liquidity</span>
              <span>${(market.liquidity / 1000).toFixed(1)}K</span>
            </div>
            <div className="flex-between mb-8">
              <span className="text-muted">Oracle</span>
              <span className="text-accent">{market.oracleType}</span>
            </div>
            <div className="flex-between mb-8">
              <span className="text-muted">Resolution</span>
              <span className="text-sm">{market.resolutionSource}</span>
            </div>
            <div className="flex-between mb-8">
              <span className="text-muted">Creator</span>
              <span className="font-mono text-xs">{market.creator.slice(0, 12)}...</span>
            </div>
            {market.resolutionValue !== undefined && (
              <div className="flex-between mb-8">
                <span className="text-muted">Resolution Value</span>
                <span className="text-yellow font-bold">{market.resolutionValue}</span>
              </div>
            )}
            {market.disputeDeadline && (
              <div className="flex-between mb-8">
                <span className="text-muted">Dispute Deadline</span>
                <span className="text-red">{new Date(market.disputeDeadline).toLocaleDateString()}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="card mt-16">
        <h4 className="font-bold mb-16">Resolution Actions</h4>
        <div className="flex gap-12">
          {market.status === 'active' && (
            <button className="btn-primary" onClick={() => resolveMarket(market.id, 0)}>
              Submit Resolution (Optimistic)
            </button>
          )}
          {market.status === 'pending_resolution' && (
            <button className="btn-red" onClick={() => disputeResolution(market.id)}>
              File Dispute
            </button>
          )}
          {market.status === 'disputed' && (
            <div className="text-sm text-muted">
              Market is under dispute. Awaiting arbitration from oracle committee.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
