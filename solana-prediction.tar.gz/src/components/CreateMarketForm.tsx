import { FC, useState } from "react";
import { Market } from "../types";

interface CreateMarketFormProps {
  onCreate: (market: Market) => void;
}

export const CreateMarketForm: FC<CreateMarketFormProps> = ({ onCreate }) => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [outcomes, setOutcomes] = useState("Yes,No");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const outcomeList = outcomes.split(",").map((s) => s.trim()).filter(Boolean);
    if (!title || outcomeList.length < 2) return;

    onCreate({
      publicKey: Math.random().toString(36).slice(2),
      authority: "",
      title,
      description,
      marketType: "Binary",
      outcomes: outcomeList,
      endTime: Math.floor(Date.now() / 1000) + 86400 * 7,
      oracleConfig: { oracleType: "Manual", oracleAddress: "", confidenceThreshold: 0, stalenessThreshold: 0 },
      resolutionState: { active: {} },
      feeBps: 100,
      liquidityPool: "",
      totalVolume: 0,
      yesSharesMint: "",
      noSharesMint: "",
      createdAt: Math.floor(Date.now() / 1000),
      resolvedOutcome: null,
      scalarRange: null,
      bump: 0,
    });

    setTitle("");
    setDescription("");
    setOutcomes("Yes,No");
  };

  return (
    <form
      onSubmit={handleSubmit}
      style={{ background: "#141414", border: "1px solid #222", borderRadius: 12, padding: 20, marginBottom: 20 }}
    >
      <div style={{ marginBottom: 12 }}>
        <label style={{ display: "block", fontSize: "0.85rem", color: "#888", marginBottom: 4 }}>Title</label>
        <input value={title} onChange={(e) => setTitle(e.target.value)} style={{ width: "100%", padding: 8, borderRadius: 6, border: "1px solid #333", background: "#1a1a1a", color: "#e0e0e0" }} placeholder="Will X happen by Y date?" />
      </div>
      <div style={{ marginBottom: 12 }}>
        <label style={{ display: "block", fontSize: "0.85rem", color: "#888", marginBottom: 4 }}>Description</label>
        <textarea value={description} onChange={(e) => setDescription(e.target.value)} style={{ width: "100%", padding: 8, borderRadius: 6, border: "1px solid #333", background: "#1a1a1a", color: "#e0e0e0", minHeight: 60 }} placeholder="Describe the market conditions..." />
      </div>
      <div style={{ marginBottom: 12 }}>
        <label style={{ display: "block", fontSize: "0.85rem", color: "#888", marginBottom: 4 }}>Outcomes (comma-separated)</label>
        <input value={outcomes} onChange={(e) => setOutcomes(e.target.value)} style={{ width: "100%", padding: 8, borderRadius: 6, border: "1px solid #333", background: "#1a1a1a", color: "#e0e0e0" }} />
      </div>
      <button className="wallet-btn" type="submit">Create Market</button>
    </form>
  );
};
