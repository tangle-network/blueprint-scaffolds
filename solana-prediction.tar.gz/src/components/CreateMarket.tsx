import React from 'react'

export function CreateMarket(props: Record<string, any>) { return <div>{props.children}</div> }
