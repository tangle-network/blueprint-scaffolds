import { useConnection } from '../contexts/ConnectionContext';

export function Header() {
  const { endpoint, setEndpoint } = useConnection();

  return (
    <header style={{
      background: 'var(--bg-secondary)',
      borderBottom: '1px solid var(--border)',
      padding: '12px 24px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
    }}>
      <div className="flex gap-16">
        <h1 style={{ fontSize: 20, fontWeight: 800, letterSpacing: -0.5 }}>
          <span className="text-accent">Solana</span> Predict
        </h1>
        <span className="text-xs text-muted" style={{ alignSelf: 'flex-end', marginBottom: 2 }}>
          Prediction Markets on Solana
        </span>
      </div>
      <div className="flex gap-12">
        <select
          value={endpoint}
          onChange={(e) => setEndpoint(e.target.value)}
          style={{ width: 'auto', fontSize: 12, padding: '6px 10px' }}
        >
          <option value="devnet">Devnet</option>
          <option value="testnet">Testnet</option>
          <option value="mainnet">Mainnet</option>
          <option value="localnet">Localnet</option>
        </select>
        <div className="card" style={{ padding: '6px 12px', fontSize: 12, display: 'flex', gap: 8 }}>
          <span className="text-muted">Status:</span>
          <span className="text-green">Connected</span>
        </div>
      </div>
    </header>
  );
}
