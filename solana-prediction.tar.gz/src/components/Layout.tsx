import { NavLink, Outlet } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import {
  BarChart3,
  Briefcase,
  Trophy,
  PlusCircle,
  Wallet,
  TrendingUp,
} from "lucide-react";
import { useState } from "react";

const NAV_ITEMS = [
  { to: "/", label: "Markets", icon: BarChart3 },
  { to: "/positions", label: "Positions", icon: Briefcase },
  { to: "/leaderboard", label: "Leaderboard", icon: Trophy },
  { to: "/create", label: "Create Market", icon: PlusCircle },
];

export default function Layout() {
  const [connected, setConnected] = useState(false);
  const [walletAddr] = useState("7xKp...B8Ck");

  return (
    <div className="flex min-h-screen bg-background">
      <aside className="flex w-64 flex-col border-r bg-card">
        <div className="flex items-center gap-2 px-6 py-5">
          <TrendingUp className="h-6 w-6 text-primary" />
          <h1 className="text-lg font-bold tracking-tight">SolPredict</h1>
        </div>
        <Separator />
        <nav className="flex-1 space-y-1 px-3 py-4">
          {NAV_ITEMS.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              end={to === "/"}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                  isActive
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                }`
              }
            >
              <Icon className="h-4 w-4" />
              {label}
            </NavLink>
          ))}
        </nav>
        <Separator />
        <div className="p-4">
          <Button
            variant={connected ? "outline" : "default"}
            className="w-full gap-2"
            onClick={() => setConnected(!connected)}
          >
            <Wallet className="h-4 w-4" />
            {connected ? (
              <span className="flex items-center gap-2">
                {walletAddr}
                <Badge variant="secondary" className="text-xs">
                  24.5 SOL
                </Badge>
              </span>
            ) : (
              "Connect Wallet"
            )}
          </Button>
        </div>
      </aside>
      <main className="flex-1 overflow-auto">
        <Outlet />
      </main>
    </div>
  );
}
