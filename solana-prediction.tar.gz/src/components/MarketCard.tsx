import { Link } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import type { Market } from "@/lib/types";
import { formatUsd, formatCountdown } from "@/lib/data";
import { Clock, BarChart3 } from "lucide-react";

const STATUS_COLORS: Record<string, string> = {
  open: "default",
  closed: "secondary",
  resolved: "outline",
  disputed: "destructive",
};

const TYPE_BADGE_VARIANT: Record<string, "default" | "secondary" | "outline"> = {
  binary: "default",
  scalar: "secondary",
  categorical: "outline",
};

interface MarketCardProps {
  market: Market;
}

export default function MarketCard({ market }: MarketCardProps) {
  const topOutcome =
    market.type === "binary"
      ? market.outcomes[0]
      : market.type === "categorical"
        ? market.outcomes[market.outcomePrices.indexOf(Math.max(...market.outcomePrices))]
        : undefined;

  const topPrice =
    market.type === "scalar" ? market.outcomePrices[0] : Math.max(...market.outcomePrices);

  return (
    <Link to={`/market/${market.id}`}>
      <Card className="transition-colors hover:border-primary/50 hover:shadow-md">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-2">
            <CardTitle className="text-base leading-snug">{market.title}</CardTitle>
            <Badge
              variant={
                STATUS_COLORS[market.status] as "default" | "secondary" | "outline" | "destructive"
              }
            >
              {market.status}
            </Badge>
          </div>
          <CardDescription className="line-clamp-2">{market.description}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3 pb-3">
          {market.type === "binary" && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium text-primary">Yes</span>
                <span className="font-mono">{(market.outcomePrices[0]! * 100).toFixed(1)}%</span>
              </div>
              <Progress value={market.outcomePrices[0]! * 100} className="h-2" />
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium text-destructive">No</span>
                <span className="font-mono">{(market.outcomePrices[1]! * 100).toFixed(1)}%</span>
              </div>
            </div>
          )}
          {market.type === "scalar" && (
            <div className="space-y-1">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Predicted Price</span>
                <span className="font-mono text-lg font-bold">${market.outcomePrices[0]}</span>
              </div>
              <Progress
                value={
                  ((market.outcomePrices[0]! - (market.scalarMin ?? 0)) /
                    ((market.scalarMax ?? 100) - (market.scalarMin ?? 0))) *
                  100
                }
                className="h-2"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>${market.scalarMin}</span>
                <span>${market.scalarMax}</span>
              </div>
            </div>
          )}
          {market.type === "categorical" && (
            <div className="space-y-1.5">
              {market.outcomes.map((outcome, i) => (
                <div key={outcome} className="flex items-center gap-2">
                  <div
                    className="h-2 rounded-full bg-primary"
                    style={{ width: `${Math.max(market.outcomePrices[i]! * 100, 4)}%` }}
                  />
                  <span className="text-xs text-muted-foreground">
                    {outcome} {(market.outcomePrices[i]! * 100).toFixed(0)}%
                  </span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
        <CardFooter className="flex items-center justify-between text-xs text-muted-foreground">
          <div className="flex items-center gap-1">
            <BarChart3 className="h-3 w-3" />
            <span>{formatUsd(market.volume)} vol</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            <span>{formatCountdown(market.endTime)}</span>
          </div>
          <Badge variant={TYPE_BADGE_VARIANT[market.type]}>{market.type}</Badge>
        </CardFooter>
      </Card>
    </Link>
  );
}
