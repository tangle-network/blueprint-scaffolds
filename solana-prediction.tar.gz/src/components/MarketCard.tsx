import { FC } from "react";
import { Market } from "../types";

interface MarketCardProps {
  market: Market;
}

export const MarketCard: FC<MarketCardProps> = ({ market }) => {
  const isActive = "active" in market.resolutionState;
  const statusClass = isActive ? "status-active" : "status-resolved";

  return (
    <div className="market-card">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h3>{market.title}</h3>
        <span className={`status-badge ${statusClass}`}>
          {isActive ? "Active" : "Resolved"}
        </span>
      </div>
      <p>{market.description}</p>
      <div className="market-meta">
        <span>Ends: {new Date(market.endTime * 1000).toLocaleDateString()}</span>
        <span>Volume: {(market.totalVolume / 1e6).toFixed(2)} USDC</span>
      </div>
      <div className="outcomes">
        {market.outcomes.map((outcome: string, i: number) => (
          <button key={i} className={`outcome-btn ${i === 0 ? "yes" : "no"}`}>
            {outcome}
          </button>
        ))}
      </div>
    </div>
  );
};
