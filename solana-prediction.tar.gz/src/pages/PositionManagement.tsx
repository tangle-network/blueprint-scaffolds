import { useMemo, useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Link } from "react-router-dom";
import { DEFAULT_POSITIONS, DEFAULT_ORDERS, formatUsd } from "@/lib/data";
import type { Position, Order } from "@/lib/types";
import {
  TrendingUp,
  TrendingDown,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react";

function PositionRow({ position }: { position: Position }) {
  const isPositive = position.pnl >= 0;
  return (
    <tr className="border-b last:border-0 hover:bg-muted/50 transition-colors">
      <td className="py-3 pr-4">
        <Link
          to={`/market/${position.marketId}`}
          className="font-medium hover:text-primary transition-colors"
        >
          {position.marketTitle}
        </Link>
      </td>
      <td className="py-3 pr-4">
        <Badge variant="outline">{position.outcome}</Badge>
      </td>
      <td className="py-3 pr-4 font-mono text-sm">{position.quantity}</td>
      <td className="py-3 pr-4 font-mono text-sm">${position.avgPrice.toFixed(2)}</td>
      <td className="py-3 pr-4 font-mono text-sm">${position.currentPrice.toFixed(2)}</td>
      <td className="py-3 pr-4 font-mono text-sm font-medium">
        <span className={isPositive ? "text-green-500" : "text-red-500"}>
          {isPositive ? "+" : ""}
          {formatUsd(position.pnl)}
        </span>
      </td>
      <td className="py-3 pr-4 font-mono text-sm">
        <span
          className={`flex items-center gap-0.5 ${isPositive ? "text-green-500" : "text-red-500"}`}
        >
          {isPositive ? (
            <ArrowUpRight className="h-3 w-3" />
          ) : (
            <ArrowDownRight className="h-3 w-3" />
          )}
          {position.pnlPercent.toFixed(2)}%
        </span>
      </td>
      <td className="py-3 font-mono text-sm">{formatUsd(position.value)}</td>
    </tr>
  );
}

function OrderRow({ order }: { order: Order }) {
  const statusColor: Record<string, string> = {
    open: "default",
    filled: "secondary",
    cancelled: "outline",
  };
  return (
    <tr className="border-b last:border-0 hover:bg-muted/50 transition-colors">
      <td className="py-3 pr-4">
        <Link
          to={`/market/${order.marketId}`}
          className="font-medium hover:text-primary transition-colors"
        >
          {order.marketId}
        </Link>
      </td>
      <td className="py-3 pr-4">
        <Badge
          variant={
            order.side === "buy"
              ? "default"
              : "destructive"
          }
          className="text-xs"
        >
          {order.side.toUpperCase()}
        </Badge>
      </td>
      <td className="py-3 pr-4 text-sm">{order.outcome}</td>
      <td className="py-3 pr-4 font-mono text-sm">${order.price.toFixed(2)}</td>
      <td className="py-3 pr-4 font-mono text-sm">{order.quantity}</td>
      <td className="py-3 pr-4 font-mono text-sm">
        {order.filledQuantity}/{order.quantity}
      </td>
      <td className="py-3">
        <Badge variant={statusColor[order.status] as "default" | "secondary" | "outline"}>
          {order.status}
        </Badge>
      </td>
    </tr>
  );
}

export default function PositionManagement() {
  const positions = DEFAULT_POSITIONS;
  const orders = DEFAULT_ORDERS;

  const summary = useMemo(() => {
    const totalValue = positions.reduce((s, p) => s + p.value, 0);
    const totalPnl = positions.reduce((s, p) => s + p.pnl, 0);
    const avgPnl =
      positions.length > 0
        ? positions.reduce((s, p) => s + p.pnlPercent, 0) / positions.length
        : 0;
    return { totalValue, totalPnl, avgPnl };
  }, [positions]);

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">My Positions</h1>
        <p className="text-sm text-muted-foreground">
          Track and manage your open positions and orders
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="pt-4">
            <div className="text-xs text-muted-foreground">Portfolio Value</div>
            <div className="text-2xl font-bold font-mono">
              {formatUsd(summary.totalValue)}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="text-xs text-muted-foreground">Unrealized PnL</div>
            <div
              className={`text-2xl font-bold font-mono ${summary.totalPnl >= 0 ? "text-green-500" : "text-red-500"}`}
            >
              {summary.totalPnl >= 0 ? "+" : ""}
              {formatUsd(summary.totalPnl)}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="text-xs text-muted-foreground">Avg Return</div>
            <div
              className={`text-2xl font-bold font-mono ${summary.avgPnl >= 0 ? "text-green-500" : "text-red-500"}`}
            >
              {summary.avgPnl >= 0 ? "+" : ""}
              {summary.avgPnl.toFixed(2)}%
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="positions">
        <TabsList>
          <TabsTrigger value="positions">
            Positions ({positions.length})
          </TabsTrigger>
          <TabsTrigger value="orders">
            Orders ({orders.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="positions">
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b text-left text-muted-foreground">
                      <th className="p-3 font-medium">Market</th>
                      <th className="p-3 font-medium">Outcome</th>
                      <th className="p-3 font-medium">Shares</th>
                      <th className="p-3 font-medium">Avg Price</th>
                      <th className="p-3 font-medium">Current</th>
                      <th className="p-3 font-medium">PnL</th>
                      <th className="p-3 font-medium">Return</th>
                      <th className="p-3 font-medium">Value</th>
                    </tr>
                  </thead>
                  <tbody className="px-4">
                    {positions.map((pos) => (
                      <PositionRow key={pos.id} position={pos} />
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="orders">
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b text-left text-muted-foreground">
                      <th className="p-3 font-medium">Market</th>
                      <th className="p-3 font-medium">Side</th>
                      <th className="p-3 font-medium">Outcome</th>
                      <th className="p-3 font-medium">Price</th>
                      <th className="p-3 font-medium">Qty</th>
                      <th className="p-3 font-medium">Filled</th>
                      <th className="p-3 font-medium">Status</th>
                    </tr>
                  </thead>
                  <tbody className="px-4">
                    {orders.map((ord) => (
                      <OrderRow key={ord.id} order={ord} />
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
