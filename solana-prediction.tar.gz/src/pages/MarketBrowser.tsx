import { useState, useMemo } from "react";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Search } from "lucide-react";
import MarketCard from "@/components/MarketCard";
import { DEFAULT_MARKETS, CATEGORIES } from "@/lib/data";
import type { MarketStatus, MarketType } from "@/lib/types";

export default function MarketBrowser() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [status, setStatus] = useState<string>("all");
  const [type, setType] = useState<string>("all");

  const filtered = useMemo(() => {
    return DEFAULT_MARKETS.filter((m) => {
      if (search && !m.title.toLowerCase().includes(search.toLowerCase())) return false;
      if (category !== "All" && m.category !== category) return false;
      if (status !== "all" && m.status !== status) return false;
      if (type !== "all" && m.type !== type) return false;
      return true;
    });
  }, [search, category, status, type]);

  const stats = useMemo(() => {
    const totalVolume = DEFAULT_MARKETS.reduce((s, m) => s + m.volume, 0);
    const openCount = DEFAULT_MARKETS.filter((m) => m.status === "open").length;
    return { totalVolume, openCount, total: DEFAULT_MARKETS.length };
  }, []);

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Prediction Markets</h1>
          <p className="text-sm text-muted-foreground">
            {stats.openCount} active markets &middot; {stats.total} total
          </p>
        </div>
        <div className="flex items-center gap-4 text-sm">
          <Badge variant="outline" className="px-3 py-1 text-xs">
            Total Volume: ${(stats.totalVolume / 1_000_000).toFixed(1)}M
          </Badge>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search markets..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            {CATEGORIES.map((c) => (
              <SelectItem key={c} value={c}>
                {c}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-[130px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="open">Open</SelectItem>
            <SelectItem value="closed">Closed</SelectItem>
            <SelectItem value="resolved">Resolved</SelectItem>
            <SelectItem value="disputed">Disputed</SelectItem>
          </SelectContent>
        </Select>
        <Select value={type} onValueChange={setType}>
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder="Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="binary">Binary</SelectItem>
            <SelectItem value="scalar">Scalar</SelectItem>
            <SelectItem value="categorical">Categorical</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {filtered.length === 0 ? (
        <div className="py-16 text-center text-muted-foreground">
          No markets found matching your filters.
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((market) => (
            <MarketCard key={market.id} market={market} />
          ))}
        </div>
      )}
    </div>
  );
}
