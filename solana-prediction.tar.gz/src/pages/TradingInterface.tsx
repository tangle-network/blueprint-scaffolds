import { useParams, Link } from "react-router-dom";
import { useMemo, useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ArrowLeft,
  TrendingUp,
  TrendingDown,
  Clock,
  BarChart3,
  Droplets,
  Radio,
  AlertTriangle,
} from "lucide-react";
import {
  DEFAULT_MARKETS,
  DEFAULT_ORDER_BOOKS,
  DEFAULT_ORACLE_PRICES,
  formatUsd,
  formatCountdown,
  formatDate,
  formatAddress,
} from "@/lib/data";

export default function TradingInterface() {
  const { id } = useParams<{ id: string }>();
  const [side, setSide] = useState<"buy" | "sell">("buy");
  const [outcome, setOutcome] = useState("Yes");
  const [price, setPrice] = useState("");
  const [quantity, setQuantity] = useState("");

  const market = useMemo(
    () => DEFAULT_MARKETS.find((m) => m.id === id),
    [id],
  );

  const orderBook = useMemo(
    () => (market ? DEFAULT_ORDER_BOOKS[market.id] : undefined),
    [market],
  );

  const oracle = useMemo(
    () =>
      market
        ? DEFAULT_ORACLE_PRICES.find((o) => o.feed === market.oracleFeed)
        : undefined,
    [market],
  );

  if (!market) {
    return (
      <div className="flex flex-col items-center justify-center gap-4 p-16">
        <p className="text-lg text-muted-foreground">Market not found</p>
        <Link to="/">
          <Button variant="outline">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Markets
          </Button>
        </Link>
      </div>
    );
  }

  const totalPnl = 45.0;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-4">
        <Link to="/">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <h1 className="text-xl font-bold">{market.title}</h1>
            <Badge
              variant={
                market.status === "open"
                  ? "default"
                  : market.status === "resolved"
                    ? "outline"
                    : "secondary"
              }
            >
              {market.status}
            </Badge>
            <Badge variant="outline">{market.type}</Badge>
          </div>
          <p className="mt-1 text-sm text-muted-foreground">{market.description}</p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-4">
            <div className="text-xs text-muted-foreground">Volume</div>
            <div className="text-lg font-bold">{formatUsd(market.volume)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="text-xs text-muted-foreground">Liquidity</div>
            <div className="text-lg font-bold">{formatUsd(market.liquidity)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="text-xs text-muted-foreground">Ends</div>
            <div className="text-lg font-bold">{formatCountdown(market.endTime)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="text-xs text-muted-foreground">Disputes</div>
            <div className="text-lg font-bold flex items-center gap-1">
              {market.disputeCount}
              {market.disputeCount > 0 && (
                <AlertTriangle className="h-4 w-4 text-yellow-500" />
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-4">
          <Tabs defaultValue="orderbook">
            <TabsList>
              <TabsTrigger value="orderbook">Order Book</TabsTrigger>
              <TabsTrigger value="amm">AMM Swap</TabsTrigger>
              <TabsTrigger value="resolution">Resolution</TabsTrigger>
            </TabsList>

            <TabsContent value="orderbook" className="space-y-4">
              {orderBook ? (
                <Card>
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base">Order Book</CardTitle>
                      <div className="text-sm text-muted-foreground">
                        Spread:{" "}
                        <span className="font-mono">
                          {market.type === "scalar"
                            ? `$${orderBook.spread.toFixed(1)}`
                            : `${(orderBook.spread * 100).toFixed(1)}¢`}
                        </span>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="mb-2 text-xs font-semibold text-green-500">
                          Bids (Buy)
                        </div>
                        <div className="space-y-0.5 text-xs font-mono">
                          <div className="grid grid-cols-3 text-muted-foreground pb-1">
                            <span>Price</span>
                            <span className="text-right">Qty</span>
                            <span className="text-right">Total</span>
                          </div>
                          {orderBook.bids.map((bid, i) => (
                            <div
                              key={i}
                              className="grid grid-cols-3 py-0.5 text-green-400"
                            >
                              <span>
                                {market.type === "scalar"
                                  ? `$${bid.price.toFixed(1)}`
                                  : `${(bid.price * 100).toFixed(1)}¢`}
                              </span>
                              <span className="text-right">{bid.quantity.toLocaleString()}</span>
                              <span className="text-right">{bid.total.toLocaleString()}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                      <div>
                        <div className="mb-2 text-xs font-semibold text-red-500">
                          Asks (Sell)
                        </div>
                        <div className="space-y-0.5 text-xs font-mono">
                          <div className="grid grid-cols-3 text-muted-foreground pb-1">
                            <span>Price</span>
                            <span className="text-right">Qty</span>
                            <span className="text-right">Total</span>
                          </div>
                          {orderBook.asks.map((ask, i) => (
                            <div
                              key={i}
                              className="grid grid-cols-3 py-0.5 text-red-400"
                            >
                              <span>
                                {market.type === "scalar"
                                  ? `$${ask.price.toFixed(1)}`
                                  : `${(ask.price * 100).toFixed(1)}¢`}
                              </span>
                              <span className="text-right">{ask.quantity.toLocaleString()}</span>
                              <span className="text-right">{ask.total.toLocaleString()}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardContent className="py-8 text-center text-muted-foreground">
                    No order book data available for this market.
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="amm">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">AMM Pool</CardTitle>
                  <CardDescription>
                    Swap tokens via the automated market maker pool
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="rounded-lg border p-3 text-center">
                      <div className="text-xs text-muted-foreground">Yes Tokens</div>
                      <div className="text-lg font-bold font-mono">
                        {market.type === "scalar"
                          ? "$185.00"
                          : `${(market.outcomePrices[0]! * 100).toFixed(1)}%`}
                      </div>
                    </div>
                    <div className="rounded-lg border p-3 text-center">
                      <div className="text-xs text-muted-foreground">No Tokens</div>
                      <div className="text-lg font-bold font-mono">
                        {market.type === "scalar"
                          ? "$15.00"
                          : `${((1 - market.outcomePrices[0]!) * 100).toFixed(1)}%`}
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Pool Liquidity</Label>
                    <Progress value={72} className="h-3" />
                    <div className="text-xs text-muted-foreground">
                      {formatUsd(market.liquidity)} total
                    </div>
                  </div>
                  <div className="rounded-lg bg-muted/50 p-4 space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Fee</span>
                      <span>0.3%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Price Impact</span>
                      <span>~0.1%</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between font-medium">
                      <span>Estimated Output</span>
                      <span>--</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="resolution">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Resolution & Disputes</CardTitle>
                  <CardDescription>
                    Market resolution status and dispute information
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="rounded-lg border p-3">
                      <div className="text-xs text-muted-foreground">Oracle Source</div>
                      <div className="flex items-center gap-1 font-medium">
                        <Radio className="h-4 w-4" />
                        {market.oracleSource === "pyth" ? "Pyth Network" : "Switchboard"}
                      </div>
                    </div>
                    <div className="rounded-lg border p-3">
                      <div className="text-xs text-muted-foreground">End Date</div>
                      <div className="font-medium">{formatDate(market.endTime)}</div>
                    </div>
                  </div>
                  {market.resolutionOutcome && (
                    <div className="rounded-lg border border-primary/50 bg-primary/5 p-4">
                      <div className="text-sm font-medium">Resolved Outcome</div>
                      <div className="mt-1 text-lg font-bold text-primary">
                        {market.resolutionOutcome}
                      </div>
                    </div>
                  )}
                  {market.disputeCount > 0 && (
                    <div className="rounded-lg border border-yellow-500/50 bg-yellow-500/5 p-4">
                      <div className="flex items-center gap-2 text-sm font-medium text-yellow-500">
                        <AlertTriangle className="h-4 w-4" />
                        {market.disputeCount} dispute{market.disputeCount > 1 ? "s" : ""} filed
                      </div>
                      <p className="mt-1 text-xs text-muted-foreground">
                        Resolution is under review. Bonded disputers stake SOL to challenge the
                        proposed outcome.
                      </p>
                    </div>
                  )}
                  {oracle && (
                    <div className="rounded-lg border p-4 space-y-2">
                      <div className="text-sm font-medium">Live Oracle Feed</div>
                      <div className="font-mono text-2xl font-bold">${oracle.price.toLocaleString()}</div>
                      <div className="text-xs text-muted-foreground">
                        Confidence: &plusmn;{oracle.confidence} &middot; Updated{" "}
                        {Math.floor((Date.now() - oracle.updatedAt) / 1000)}s ago
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Place Order</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-2">
                <Button
                  variant={side === "buy" ? "default" : "outline"}
                  className={side === "buy" ? "bg-green-600 hover:bg-green-700" : ""}
                  onClick={() => setSide("buy")}
                >
                  <TrendingUp className="mr-1 h-4 w-4" />
                  Buy
                </Button>
                <Button
                  variant={side === "sell" ? "default" : "outline"}
                  className={side === "sell" ? "bg-red-600 hover:bg-red-700" : ""}
                  onClick={() => setSide("sell")}
                >
                  <TrendingDown className="mr-1 h-4 w-4" />
                  Sell
                </Button>
              </div>

              {market.type !== "scalar" && (
                <div className="space-y-1.5">
                  <Label>Outcome</Label>
                  <Select value={outcome} onValueChange={setOutcome}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {market.outcomes.map((o) => (
                        <SelectItem key={o} value={o}>
                          {o}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="space-y-1.5">
                <Label>
                  Price{" "}
                  {market.type === "scalar" ? "(USD)" : "(cents)"}
                </Label>
                <Input
                  type="number"
                  step="any"
                  placeholder={market.type === "scalar" ? "185.00" : "67"}
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                />
              </div>

              <div className="space-y-1.5">
                <Label>Quantity (shares)</Label>
                <Input
                  type="number"
                  step="any"
                  placeholder="100"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                />
              </div>

              <Separator />

              <div className="space-y-1 text-sm">
                <div className="flex justify-between text-muted-foreground">
                  <span>Est. Cost</span>
                  <span className="font-mono">
                    {price && quantity
                      ? `$${(parseFloat(price) * parseFloat(quantity)).toFixed(2)}`
                      : "--"}
                  </span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Fee (0.3%)</span>
                  <span className="font-mono">
                    {price && quantity
                      ? `$${(parseFloat(price) * parseFloat(quantity) * 0.003).toFixed(2)}`
                      : "--"}
                  </span>
                </div>
              </div>

              <Button className="w-full" size="lg">
                {side === "buy" ? "Buy" : "Sell"}{" "}
                {market.type === "scalar" ? "Position" : outcome || "Shares"}
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Market Info</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Creator</span>
                <span className="font-mono">{formatAddress(market.creator)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Created</span>
                <span>{formatDate(market.createdAt)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Category</span>
                <Badge variant="secondary">{market.category}</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Oracle</span>
                <span className="capitalize">{market.oracleSource}</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
