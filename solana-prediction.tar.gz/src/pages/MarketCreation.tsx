import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import {
  CATEGORIES,
} from "@/lib/data";
import type { MarketType, OracleSource } from "@/lib/types";
import { CheckCircle2, ChevronRight, Plus, X } from "lucide-react";

const STEPS = ["Type & Category", "Details", "Oracle & Resolution", "Review"];

export default function MarketCreation() {
  const { toast } = useToast();
  const [step, setStep] = useState(0);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [marketType, setMarketType] = useState<MarketType>("binary");
  const [category, setCategory] = useState("");
  const [outcomes, setOutcomes] = useState<string[]>(["Yes", "No"]);
  const [newOutcome, setNewOutcome] = useState("");
  const [endTime, setEndTime] = useState("");
  const [oracleSource, setOracleSource] = useState<OracleSource>("pyth");
  const [oracleFeed, setOracleFeed] = useState("");
  const [scalarMin, setScalarMin] = useState("");
  const [scalarMax, setScalarMax] = useState("");
  const [initialLiquidity, setInitialLiquidity] = useState("100");

  const addOutcome = () => {
    if (newOutcome.trim() && outcomes.length < 10) {
      setOutcomes([...outcomes, newOutcome.trim()]);
      setNewOutcome("");
    }
  };

  const removeOutcome = (index: number) => {
    if (outcomes.length > 2) {
      setOutcomes(outcomes.filter((_, i) => i !== index));
    }
  };

  const handleCreate = () => {
    toast({
      title: "Market Created!",
      description: `"${title}" has been submitted to the Solana blockchain.`,
    });
  };

  const canAdvance = (): boolean => {
    switch (step) {
      case 0:
        return marketType !== undefined && category !== "";
      case 1:
        return (
          title.trim().length > 0 &&
          description.trim().length > 0 &&
          outcomes.length >= 2 &&
          outcomes.every((o) => o.trim().length > 0) &&
          endTime !== ""
        );
      case 2:
        return oracleFeed.trim().length > 0;
      default:
        return true;
    }
  };

  return (
    <div className="mx-auto max-w-3xl p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Create Market</h1>
        <p className="text-sm text-muted-foreground">
          Launch a new prediction market on Solana
        </p>
      </div>

      <div className="flex items-center gap-2">
        {STEPS.map((label, i) => (
          <div key={label} className="flex items-center gap-2">
            <div
              className={`flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold ${
                i < step
                  ? "bg-primary text-primary-foreground"
                  : i === step
                    ? "border-2 border-primary text-primary"
                    : "border border-muted-foreground/30 text-muted-foreground"
              }`}
            >
              {i < step ? <CheckCircle2 className="h-5 w-5" /> : i + 1}
            </div>
            <span
              className={`text-sm hidden sm:inline ${
                i === step ? "font-medium" : "text-muted-foreground"
              }`}
            >
              {label}
            </span>
            {i < STEPS.length - 1 && (
              <ChevronRight className="h-4 w-4 text-muted-foreground mx-1" />
            )}
          </div>
        ))}
      </div>

      <Card>
        {step === 0 && (
          <>
            <CardHeader>
              <CardTitle>Market Type & Category</CardTitle>
              <CardDescription>
                Choose the type of prediction market and its category
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <Label>Market Type</Label>
                <div className="grid grid-cols-3 gap-3">
                  {(["binary", "scalar", "categorical"] as MarketType[]).map((t) => (
                    <button
                      key={t}
                      onClick={() => {
                        setMarketType(t);
                        if (t === "binary") setOutcomes(["Yes", "No"]);
                        else if (t === "scalar") setOutcomes(["Price"]);
                        else if (outcomes.length < 2)
                          setOutcomes(["Option A", "Option B"]);
                      }}
                      className={`rounded-lg border p-4 text-center transition-colors ${
                        marketType === t
                          ? "border-primary bg-primary/10 text-primary"
                          : "hover:border-primary/50"
                      }`}
                    >
                      <div className="font-semibold capitalize">{t}</div>
                      <div className="mt-1 text-xs text-muted-foreground">
                        {t === "binary" && "Yes/No outcome"}
                        {t === "scalar" && "Continuous range"}
                        {t === "categorical" && "Multiple options"}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <Label>Category</Label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.filter((c) => c !== "All").map((c) => (
                      <SelectItem key={c} value={c}>
                        {c}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </>
        )}

        {step === 1 && (
          <>
            <CardHeader>
              <CardTitle>Market Details</CardTitle>
              <CardDescription>
                Define the market question, outcomes, and timing
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Market Question</Label>
                <Input
                  placeholder="e.g. Will BTC exceed $150,000 by end of 2026?"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <textarea
                  className="flex min-h-[100px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                  placeholder="Detailed resolution criteria and rules..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </div>

              {marketType !== "scalar" && (
                <div className="space-y-2">
                  <Label>Outcomes</Label>
                  <div className="flex flex-wrap gap-2">
                    {outcomes.map((o, i) => (
                      <Badge key={i} variant="secondary" className="gap-1 px-3 py-1">
                        {o}
                        {outcomes.length > 2 && (
                          <button onClick={() => removeOutcome(i)}>
                            <X className="h-3 w-3" />
                          </button>
                        )}
                      </Badge>
                    ))}
                  </div>
                  {outcomes.length < 10 && (
                    <div className="flex gap-2">
                      <Input
                        placeholder="Add outcome..."
                        value={newOutcome}
                        onChange={(e) => setNewOutcome(e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && addOutcome()}
                      />
                      <Button variant="outline" size="icon" onClick={addOutcome}>
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </div>
              )}

              {marketType === "scalar" && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Minimum Value</Label>
                    <Input
                      type="number"
                      placeholder="0"
                      value={scalarMin}
                      onChange={(e) => setScalarMin(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Maximum Value</Label>
                    <Input
                      type="number"
                      placeholder="1000"
                      value={scalarMax}
                      onChange={(e) => setScalarMax(e.target.value)}
                    />
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label>Resolution Date</Label>
                <Input
                  type="datetime-local"
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                />
              </div>
            </CardContent>
          </>
        )}

        {step === 2 && (
          <>
            <CardHeader>
              <CardTitle>Oracle & Liquidity</CardTitle>
              <CardDescription>
                Configure the price oracle and initial liquidity
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Oracle Source</Label>
                <div className="grid grid-cols-2 gap-3">
                  {(["pyth", "switchboard"] as OracleSource[]).map((src) => (
                    <button
                      key={src}
                      onClick={() => setOracleSource(src)}
                      className={`rounded-lg border p-4 text-center transition-colors ${
                        oracleSource === src
                          ? "border-primary bg-primary/10 text-primary"
                          : "hover:border-primary/50"
                      }`}
                    >
                      <div className="font-semibold capitalize">{src}</div>
                      <div className="mt-1 text-xs text-muted-foreground">
                        {src === "pyth" ? "Pyth Network" : "Switchboard"} price feed
                      </div>
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <Label>Oracle Feed Address</Label>
                <Input
                  placeholder="0x... or Switchboard aggregator address"
                  value={oracleFeed}
                  onChange={(e) => setOracleFeed(e.target.value)}
                  className="font-mono text-sm"
                />
              </div>
              <div className="space-y-2">
                <Label>Initial Liquidity (SOL)</Label>
                <Input
                  type="number"
                  placeholder="100"
                  value={initialLiquidity}
                  onChange={(e) => setInitialLiquidity(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                  Minimum 10 SOL required to seed the AMM pool
                </p>
              </div>
            </CardContent>
          </>
        )}

        {step === 3 && (
          <>
            <CardHeader>
              <CardTitle>Review & Submit</CardTitle>
              <CardDescription>
                Confirm all details before creating your market
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-lg border p-4 space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Type</span>
                  <Badge>{marketType}</Badge>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Category</span>
                  <Badge variant="secondary">{category || "—"}</Badge>
                </div>
                <Separator />
                <div>
                  <div className="text-sm text-muted-foreground">Question</div>
                  <div className="font-medium">{title || "—"}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Description</div>
                  <div className="text-sm">{description || "—"}</div>
                </div>
                <Separator />
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Outcomes</span>
                  <div className="flex gap-1">
                    {outcomes.map((o) => (
                      <Badge key={o} variant="outline" className="text-xs">
                        {o}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Oracle</span>
                  <span className="capitalize">{oracleSource}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Initial Liquidity</span>
                  <span className="font-mono">{initialLiquidity} SOL</span>
                </div>
              </div>

              <div className="rounded-lg border border-yellow-500/50 bg-yellow-500/5 p-3 text-sm">
                <strong>Deposit Required:</strong> {initialLiquidity} SOL will be deducted from
                your wallet to seed the market pool. This is non-refundable.
              </div>
            </CardContent>
          </>
        )}

        <div className="flex justify-between p-6 pt-0">
          <Button
            variant="outline"
            onClick={() => setStep(Math.max(0, step - 1))}
            disabled={step === 0}
          >
            Back
          </Button>
          {step < STEPS.length - 1 ? (
            <Button
              onClick={() => setStep(step + 1)}
              disabled={!canAdvance()}
            >
              Next
            </Button>
          ) : (
            <Button onClick={handleCreate} disabled={!canAdvance()}>
              Create Market
            </Button>
          )}
        </div>
      </Card>
    </div>
  );
}
