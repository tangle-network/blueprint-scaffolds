import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DEFAULT_LEADERBOARD, formatUsd, formatAddress } from "@/lib/data";
import { Trophy, Medal, TrendingUp } from "lucide-react";
import { Separator } from "@/components/ui/separator";

const RANK_STYLES: Record<number, string> = {
  1: "text-yellow-500",
  2: "text-gray-400",
  3: "text-amber-600",
};

const RANK_ICONS: Record<number, React.ReactNode> = {
  1: <Trophy className="h-5 w-5 text-yellow-500" />,
  2: <Medal className="h-5 w-5 text-gray-400" />,
  3: <Medal className="h-5 w-5 text-amber-600" />,
};

export default function Leaderboard() {
  const entries = DEFAULT_LEADERBOARD;

  const topTrader = entries[0];

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Leaderboard</h1>
        <p className="text-sm text-muted-foreground">
          Top traders ranked by realized profit and loss
        </p>
      </div>

      {topTrader && (
        <Card className="border-primary/30 bg-primary/5">
          <CardContent className="flex items-center gap-6 pt-6">
            <Trophy className="h-12 w-12 text-yellow-500" />
            <div className="flex-1">
              <div className="text-sm text-muted-foreground">#1 Trader</div>
              <div className="font-mono text-lg font-bold">
                {formatAddress(topTrader.address)}
              </div>
              <div className="mt-1 flex items-center gap-4 text-sm">
                <span className="text-green-500 font-medium">
                  +{formatUsd(topTrader.pnl)} PnL
                </span>
                <span className="text-muted-foreground">
                  {topTrader.winRate}% win rate
                </span>
                <span className="text-muted-foreground">
                  {topTrader.marketsTraded} markets
                </span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold font-mono text-green-500">
                +{formatUsd(topTrader.pnl)}
              </div>
              <div className="text-xs text-muted-foreground">Total PnL</div>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-base">All Traders</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-left text-muted-foreground">
                  <th className="p-3 font-medium w-16">Rank</th>
                  <th className="p-3 font-medium">Address</th>
                  <th className="p-3 font-medium text-right">PnL</th>
                  <th className="p-3 font-medium text-right">Volume</th>
                  <th className="p-3 font-medium text-right">Win Rate</th>
                  <th className="p-3 font-medium text-right">Markets</th>
                  <th className="p-3 font-medium text-right">Trades</th>
                </tr>
              </thead>
              <tbody>
                {entries.map((entry) => (
                  <tr
                    key={entry.address}
                    className={`border-b last:border-0 transition-colors hover:bg-muted/50 ${entry.rank <= 3 ? "bg-muted/20" : ""}`}
                  >
                    <td className="p-3">
                      <div className="flex items-center gap-1">
                        {RANK_ICONS[entry.rank] ?? (
                          <span className="font-mono text-muted-foreground">
                            {entry.rank}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="p-3 font-mono text-sm">{formatAddress(entry.address)}</td>
                    <td className="p-3 text-right">
                      <span
                        className={`font-mono font-medium ${entry.pnl >= 0 ? "text-green-500" : "text-red-500"}`}
                      >
                        {entry.pnl >= 0 ? "+" : ""}
                        {formatUsd(entry.pnl)}
                      </span>
                    </td>
                    <td className="p-3 text-right font-mono text-sm">
                      {formatUsd(entry.volume)}
                    </td>
                    <td className="p-3 text-right">
                      <Badge
                        variant={entry.winRate >= 70 ? "default" : entry.winRate >= 60 ? "secondary" : "outline"}
                      >
                        {entry.winRate}%
                      </Badge>
                    </td>
                    <td className="p-3 text-right font-mono text-sm">
                      {entry.marketsTraded}
                    </td>
                    <td className="p-3 text-right font-mono text-sm">
                      {entry.totalTrades}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
