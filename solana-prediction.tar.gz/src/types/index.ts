export type MarketType = 'binary' | 'scalar' | 'categorical';

export type MarketStatus =
  | 'active'
  | 'closed'
  | 'pending_resolution'
  | 'disputed'
  | 'resolved';

export interface MarketOutcome {
  id: number;
  label: string;
  probability: number;
  volume: number;
}

export interface Market {
  id: string;
  title: string;
  description: string;
  marketType: MarketType;
  status: MarketStatus;
  outcomes: MarketOutcome[];
  resolutionSource: string;
  endDate: number;
  totalVolume: number;
  liquidity: number;
  creator: string;
  resolutionValue?: number;
  resolvedOutcome?: number;
  scalarMin?: number;
  scalarMax?: number;
  disputeDeadline?: number;
  oracleType: 'pyth' | 'switchboard' | 'manual';
}

export interface Position {
  marketId: string;
  outcomeId: number;
  outcomeLabel: string;
  shares: number;
  avgPrice: number;
  marketTitle: string;
}

export interface Trade {
  id: string;
  marketId: string;
  outcomeId: number;
  side: 'buy' | 'sell';
  price: number;
  amount: number;
  timestamp: number;
}

export interface LeaderboardEntry {
  rank: number;
  address: string;
  pnl: number;
  volume: number;
  marketsTraded: number;
  winRate: number;
}
