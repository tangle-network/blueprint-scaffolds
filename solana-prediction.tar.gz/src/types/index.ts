export type MarketType = "Binary" | "Scalar" | "Categorical";
export type OracleType = "Pyth" | "Switchboard" | "Manual";
export type OrderSide = "Buy" | "Sell";
export type OrderType = "Limit" | "Market";

export interface OracleConfig {
  oracleType: OracleType;
  oracleAddress: string;
  confidenceThreshold: number;
  stalenessThreshold: number;
}

export type ResolutionState =
  | { active: {} }
  | { pendingResolution: { proposedOutcome: number; proposer: string; bond: number; proposedAt: number } }
  | { disputed: { proposedOutcome: number; proposer: string; disputer: string; bondTotal: number; disputedAt: number } }
  | { resolved: { outcome: number; resolvedAt: number } };

export interface Market {
  publicKey: string;
  authority: string;
  title: string;
  description: string;
  marketType: MarketType;
  outcomes: string[];
  endTime: number;
  oracleConfig: OracleConfig;
  resolutionState: ResolutionState;
  feeBps: number;
  liquidityPool: string;
  totalVolume: number;
  yesSharesMint: string;
  noSharesMint: string;
  createdAt: number;
  resolvedOutcome: number | null;
  scalarRange: [number, number] | null;
  bump: number;
}

export interface Order {
  publicKey: string;
  market: string;
  owner: string;
  side: OrderSide;
  outcome: number;
  price: number;
  amount: number;
  filledAmount: number;
  orderType: OrderType;
  createdAt: number;
  bump: number;
}

export interface Position {
  publicKey: string;
  owner: string;
  market: string;
  outcome: number;
  amount: number;
  avgPrice: number;
  claimed: boolean;
  bump: number;
}

export interface OrderParams {
  side: OrderSide;
  outcome: number;
  price: number;
  amount: number;
  orderType: OrderType;
}

export interface LeaderboardEntry {
  wallet: string;
  pnl: number;
  marketsWon: number;
  totalMarkets: number;
  volume: number;
}

export interface MarketSummary {
  market: Market;
  yesPrice: number;
  noPrice: number;
  orderBookDepth: number;
}
