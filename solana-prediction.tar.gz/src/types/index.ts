export type MarketType = "binary" | "scalar" | "categorical";

export type MarketStatus = "open" | "closed" | "resolved" | "disputed";

export interface Market {
  id: string;
  title: string;
  description: string;
  type: MarketType;
  status: MarketStatus;
  creator: string;
  createdAt: number;
  endTime: number;
  outcomes: string[];
  outcomePrices: number[];
  volume: number;
  liquidity: number;
  oracleSource: "pyth" | "switchboard";
  oracleFeed: string;
  scalarMin?: number;
  scalarMax?: number;
  resolutionOutcome?: string;
  resolutionValue?: number;
  disputeCount: number;
  category: string;
}

export interface Order {
  id: string;
  marketId: string;
  side: "buy" | "sell";
  outcome: string;
  price: number;
  quantity: number;
  filledQuantity: number;
  owner: string;
  createdAt: number;
  status: "open" | "filled" | "cancelled";
}

export interface Position {
  id: string;
  marketId: string;
  marketTitle: string;
  outcome: string;
  quantity: number;
  avgPrice: number;
  currentPrice: number;
  pnl: number;
  marketType: MarketType;
}

export interface OraclePrice {
  feed: string;
  source: "pyth" | "switchboard";
  price: number;
  confidence: number;
  updatedAt: number;
}

export interface LeaderboardEntry {
  rank: number;
  address: string;
  pnl: number;
  volume: number;
  marketsTraded: number;
  winRate: number;
}

export interface TradeResult {
  success: boolean;
  txSignature?: string;
  error?: string;
}

export interface CreateMarketParams {
  title: string;
  description: string;
  type: MarketType;
  outcomes: string[];
  endTime: number;
  oracleSource: "pyth" | "switchboard";
  oracleFeed: string;
  scalarMin?: number;
  scalarMax?: number;
  category: string;
  initialLiquidity: number;
}
