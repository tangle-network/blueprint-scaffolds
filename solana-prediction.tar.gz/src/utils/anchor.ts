import { useMemo } from "react";
import { PublicKey } from "@solana/web3.js";
import { Program, AnchorProvider, Idl, setProvider, BN } from "@coral-xyz/anchor";
import { Connection } from "@solana/web3.js";

const PROGRAM_ID = new PublicKey("Pred1ct1onMarket11111111111111111111111111");
const USDC_MINT = new PublicKey("EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v");

const IDL = {
  version: "0.1.0",
  name: "prediction_market",
  instructions: [],
  accounts: [],
  events: [],
  errors: [],
  types: [],
} as unknown as Idl;

export function useProgram() {
  return useMemo(() => {
    const connection = new Connection("https://api.devnet.solana.com", "confirmed");
    const mockWallet = {
      publicKey: null as PublicKey | null,
      signTransaction: async () => { throw new Error("Not connected"); },
      signAllTransactions: async () => { throw new Error("Not connected"); },
    };
    const provider = new AnchorProvider(connection, mockWallet as any, AnchorProvider.defaultOptions());
    setProvider(provider);
    const program = new Program(IDL as Idl, provider);
    return { program, provider, connection };
  }, []);
}

export { PROGRAM_ID, USDC_MINT };

export async function findMarketAddress(
  authority: PublicKey,
  title: string
): Promise<[PublicKey, number]> {
  return PublicKey.findProgramAddressSync(
    [Buffer.from("market"), authority.toBuffer(), Buffer.from(title)],
    PROGRAM_ID
  );
}

export async function findOrderAddress(
  market: PublicKey,
  trader: PublicKey,
  timestamp: BN
): Promise<[PublicKey, number]> {
  return PublicKey.findProgramAddressSync(
    [
      Buffer.from("order"),
      market.toBuffer(),
      trader.toBuffer(),
      timestamp.toArrayLike(Buffer, "le", 8),
    ],
    PROGRAM_ID
  );
}

export async function findPositionAddress(
  market: PublicKey,
  owner: PublicKey,
  outcome: number
): Promise<[PublicKey, number]> {
  return PublicKey.findProgramAddressSync(
    [
      Buffer.from("position"),
      market.toBuffer(),
      owner.toBuffer(),
      new BN(outcome).toArrayLike(Buffer, "le", 2),
    ],
    PROGRAM_ID
  );
}

export function lamportsToUsdc(lamports: BN | number): number {
  const val = typeof lamports === "number" ? lamports : lamports.toNumber();
  return val / 1_000_000;
}

export function usdcToLamports(usdc: number): BN {
  return new BN(Math.floor(usdc * 1_000_000));
}

export function priceToPercent(price: BN | number): number {
  const val = typeof price === "number" ? price : price.toNumber();
  return (val / 1_000_000) * 100;
}

export function formatAddress(address: string | PublicKey): string {
  const str = typeof address === "string" ? address : address.toBase58();
  return `${str.slice(0, 4)}...${str.slice(-4)}`;
}

export function formatTimestamp(ts: BN | number): string {
  const val = typeof ts === "number" ? ts : ts.toNumber();
  return new Date(val * 1000).toLocaleDateString("en-US", {
    month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit",
  });
}

export function timeRemaining(endTime: BN | number): string {
  const end = typeof endTime === "number" ? endTime : endTime.toNumber();
  const now = Math.floor(Date.now() / 1000);
  const diff = end - now;
  if (diff <= 0) return "Ended";
  const days = Math.floor(diff / 86400);
  const hours = Math.floor((diff % 86400) / 3600);
  if (days > 0) return `${days}d ${hours}h`;
  const minutes = Math.floor((diff % 3600) / 60);
  return `${hours}h ${minutes}m`;
}
