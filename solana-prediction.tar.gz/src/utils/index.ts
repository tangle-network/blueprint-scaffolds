import { MarketType, OracleType, OrderSide, OrderType, Market, ResolutionState } from "../types";

export function marketTypeFromEnum(val: { [key: string]: {} }): MarketType {
  if ("binary" in val || "Binary" in val) return "Binary";
  if ("scalar" in val || "Scalar" in val) return "Scalar";
  return "Categorical";
}

export function oracleTypeFromEnum(val: { [key: string]: {} }): OracleType {
  if ("pyth" in val || "Pyth" in val) return "Pyth";
  if ("switchboard" in val || "Switchboard" in val) return "Switchboard";
  return "Manual";
}

export function orderSideFromEnum(val: { [key: string]: {} }): OrderSide {
  if ("buy" in val || "Buy" in val) return "Buy";
  return "Sell";
}

export function orderTypeFromEnum(val: { [key: string]: {} }): OrderType {
  if ("limit" in val || "Limit" in val) return "Limit";
  return "Market";
}

export function formatLamports(lamports: number): string {
  return (lamports / 1_000_000).toFixed(2);
}

export function formatPrice(price: number): string {
  return (price / 10_000).toFixed(2);
}

export function formatTimestamp(ts: number): string {
  return new Date(ts * 1000).toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function timeUntil(endTime: number): string {
  const now = Math.floor(Date.now() / 1000);
  const diff = endTime - now;
  if (diff <= 0) return "Ended";
  const days = Math.floor(diff / 86400);
  const hours = Math.floor((diff % 86400) / 3600);
  const mins = Math.floor((diff % 3600) / 60);
  if (days > 0) return `${days}d ${hours}h`;
  if (hours > 0) return `${hours}h ${mins}m`;
  return `${mins}m`;
}

export function resolutionStateLabel(state: ResolutionState): string {
  if ("active" in state) return "Active";
  if ("pendingResolution" in state) return "Pending Resolution";
  if ("disputed" in state) return "Disputed";
  if ("resolved" in state) return "Resolved";
  return "Unknown";
}

export function getOutcomePrice(market: Market, outcomeIndex: number): number {
  if (market.resolvedOutcome !== null) {
    return market.resolvedOutcome === outcomeIndex ? 1.0 : 0.0;
  }
  const endDiff = market.endTime - Math.floor(Date.now() / 1000);
  if (endDiff > 86400) return 0.5;
  return 0.5 + (Math.random() * 0.1 - 0.05);
}

export function truncateAddress(address: string): string {
  if (address.length <= 12) return address;
  return `${address.slice(0, 4)}...${address.slice(-4)}`;
}

export function marketBadgeClass(market: Market): string {
  if ("active" in market.resolutionState) return "badge-active";
  if ("pendingResolution" in market.resolutionState) return "badge-pending";
  if ("disputed" in market.resolutionState) return "badge-disputed";
  return "badge-resolved";
}

export function calculatePnl(position: { amount: number; avgPrice: number }, currentPrice: number): number {
  return (currentPrice - position.avgPrice) * position.amount;
}
