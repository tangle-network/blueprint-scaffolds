import { useState, useEffect, useCallback, createContext, useContext, type ReactNode } from "react";
import { Market, Order, Position, MarketSummary, LeaderboardEntry, OrderParams } from "../types";
import { getOutcomePrice, formatLamports } from "../utils";

interface AppState {
  connected: boolean;
  walletAddress: string | null;
  markets: MarketSummary[];
  positions: Position[];
  orders: Order[];
  leaderboard: LeaderboardEntry[];
  loading: boolean;
  connect: () => Promise<void>;
  disconnect: () => void;
  createMarket: (params: CreateMarketParams) => Promise<string>;
  placeOrder: (marketAddress: string, order: OrderParams) => Promise<string>;
  cancelOrder: (orderAddress: string) => Promise<string>;
  resolveMarket: (marketAddress: string, outcome: number) => Promise<string>;
  disputeResolution: (marketAddress: string) => Promise<string>;
  claimWinnings: (marketAddress: string) => Promise<string>;
  refreshMarkets: () => Promise<void>;
  refreshPositions: () => Promise<void>;
}

interface CreateMarketParams {
  title: string;
  description: string;
  marketType: string;
  outcomes: string[];
  endTime: number;
  oracleType: string;
  oracleAddress: string;
  feeBps: number;
}

const AppContext = createContext<AppState | null>(null);

export function useApp(): AppState {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}

export { AppContext };

const MOCK_MARKETS: MarketSummary[] = [
  makeMockMarket("Will BTC exceed $100k by 2026?", "Binary", ["Yes", "No"], 0.72, 1000000),
  makeMockMarket("ETH price at end of Q2 2026", "Scalar", ["Below $3k", "$3k-$5k", "Above $5k"], 0.45, 2500000),
  makeMockMarket("Next US Presidential winner", "Categorical", ["Candidate A", "Candidate B", "Candidate C", "Other"], 0.35, 5000000),
  makeMockMarket("Will Solana reach $500?", "Binary", ["Yes", "No"], 0.58, 1800000),
  makeMockMarket("Fed rate decision June 2026", "Categorical", ["Hold", "Cut 25bps", "Cut 50bps", "Hike"], 0.62, 3200000),
  makeMockMarket("NASDAQ close above 20000?", "Binary", ["Yes", "No"], 0.41, 900000),
  makeMockMarket("Total DeFi TVL by EOY", "Scalar", ["Below $100B", "$100B-$200B", "Above $200B"], 0.55, 1500000),
  makeMockMarket("Will GPT-5 launch before July?", "Binary", ["Yes", "No"], 0.83, 7500000),
];

function makeMockMarket(
  title: string,
  type: string,
  outcomes: string[],
  yesPrice: number,
  volume: number
): MarketSummary {
  const pk = Math.random().toString(36).slice(2, 44).padEnd(44, "0");
  return {
    market: {
      publicKey: pk,
      authority: "AuTh11111111111111111111111111111111111111",
      title,
      description: `Prediction market for: ${title}`,
      marketType: type as any,
      outcomes,
      endTime: Math.floor(Date.now() / 1000) + 86400 * 30,
      oracleConfig: {
        oracleType: "Pyth",
        oracleAddress: "Oracle1111111111111111111111111111111111111",
        confidenceThreshold: 100,
        stalenessThreshold: 300,
      },
      resolutionState: { active: {} },
      feeBps: 30,
      liquidityPool: "Pool111111111111111111111111111111111111111",
      totalVolume: volume,
      yesSharesMint: "YesMint1111111111111111111111111111111111111",
      noSharesMint: "NoMint11111111111111111111111111111111111111",
      createdAt: Math.floor(Date.now() / 1000) - 86400 * 5,
      resolvedOutcome: null,
      scalarRange: null,
      bump: 255,
    },
    yesPrice,
    noPrice: 1 - yesPrice,
    orderBookDepth: Math.floor(volume * 0.3),
  };
}

const MOCK_LEADERBOARD: LeaderboardEntry[] = [
  { wallet: "Trader11111111111111111111111111111111111111", pnl: 125000, marketsWon: 14, totalMarkets: 18, volume: 2400000 },
  { wallet: "Trader22222222222222222222222222222222222222", pnl: 89000, marketsWon: 11, totalMarkets: 15, volume: 1800000 },
  { wallet: "Trader33333333333333333333333333333333333333", pnl: 67000, marketsWon: 9, totalMarkets: 12, volume: 1200000 },
  { wallet: "Trader44444444444444444444444444444444444444", pnl: 45000, marketsWon: 7, totalMarkets: 10, volume: 900000 },
  { wallet: "Trader55555555555555555555555555555555555555", pnl: 32000, marketsWon: 6, totalMarkets: 8, volume: 750000 },
  { wallet: "Trader66666666666666666666666666666666666666", pnl: 18000, marketsWon: 5, totalMarkets: 9, volume: 600000 },
  { wallet: "Trader77777777777777777777777777777777777777", pnl: 5000, marketsWon: 3, totalMarkets: 7, volume: 400000 },
  { wallet: "Trader88888888888888888888888888888888888888", pnl: -8000, marketsWon: 2, totalMarkets: 6, volume: 350000 },
];

export function AppProvider({ children }: { children: ReactNode }) {
  const [connected, setConnected] = useState(false);
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [markets, setMarkets] = useState<MarketSummary[]>([]);
  const [positions, setPositions] = useState<Position[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(false);

  const refreshMarkets = useCallback(async () => {
    setLoading(true);
    await new Promise((r) => setTimeout(r, 300));
    setMarkets(MOCK_MARKETS);
    setLoading(false);
  }, []);

  const refreshPositions = useCallback(async () => {
    if (!walletAddress) return;
    setLoading(true);
    await new Promise((r) => setTimeout(r, 200));
    if (connected) {
      setPositions([
        {
          publicKey: "Pos111111111111111111111111111111111111111",
          owner: walletAddress,
          market: MOCK_MARKETS[0].market.publicKey,
          outcome: 0,
          amount: 500000,
          avgPrice: 650000,
          claimed: false,
          bump: 255,
        },
        {
          publicKey: "Pos222222222222222222222222222222222222222",
          owner: walletAddress,
          market: MOCK_MARKETS[2].market.publicKey,
          outcome: 1,
          amount: 300000,
          avgPrice: 350000,
          claimed: false,
          bump: 255,
        },
      ]);
    }
    setLoading(false);
  }, [walletAddress, connected]);

  useEffect(() => {
    refreshMarkets();
    setLeaderboard(MOCK_LEADERBOARD);
  }, [refreshMarkets]);

  useEffect(() => {
    refreshPositions();
  }, [refreshPositions]);

  const connect = useCallback(async () => {
    if (typeof window !== "undefined" && (window as any).solana) {
      try {
        const resp = await (window as any).solana.connect();
        setWalletAddress(resp.publicKey.toString());
        setConnected(true);
      } catch {
        setWalletAddress("Demo1111111111111111111111111111111111111");
        setConnected(true);
      }
    } else {
      setWalletAddress("Demo1111111111111111111111111111111111111");
      setConnected(true);
    }
  }, []);

  const disconnect = useCallback(() => {
    setConnected(false);
    setWalletAddress(null);
    setPositions([]);
    setOrders([]);
  }, []);

  const createMarket = useCallback(
    async (params: CreateMarketParams): Promise<string> => {
      setLoading(true);
      await new Promise((r) => setTimeout(r, 1000));
      const newMarket = makeMockMarket(
        params.title,
        params.marketType,
        params.outcomes,
        0.5,
        0
      );
      setMarkets((prev) => [newMarket, ...prev]);
      setLoading(false);
      return newMarket.market.publicKey;
    },
    []
  );

  const placeOrder = useCallback(
    async (marketAddress: string, order: OrderParams): Promise<string> => {
      setLoading(true);
      await new Promise((r) => setTimeout(r, 800));
      const orderAddr = "Order" + Math.random().toString(36).slice(2, 32).padEnd(40, "0");
      const newOrder: Order = {
        publicKey: orderAddr,
        market: marketAddress,
        owner: walletAddress || "",
        side: order.side,
        outcome: order.outcome,
        price: order.price,
        amount: order.amount,
        filledAmount: 0,
        orderType: order.orderType,
        createdAt: Math.floor(Date.now() / 1000),
        bump: 255,
      };
      setOrders((prev) => [...prev, newOrder]);
      setLoading(false);
      return orderAddr;
    },
    [walletAddress]
  );

  const cancelOrder = useCallback(async (orderAddress: string): Promise<string> => {
    setLoading(true);
    await new Promise((r) => setTimeout(r, 500));
    setOrders((prev) => prev.filter((o) => o.publicKey !== orderAddress));
    setLoading(false);
    return orderAddress;
  }, []);

  const resolveMarket = useCallback(async (_: string, outcome: number): Promise<string> => {
    setLoading(true);
    await new Promise((r) => setTimeout(r, 1000));
    setMarkets((prev) =>
      prev.map((ms) => ({
        ...ms,
        market: {
          ...ms.market,
          resolutionState: { pendingResolution: { proposedOutcome: outcome, proposer: walletAddress || "", bond: 0, proposedAt: Date.now() / 1000 } },
        },
      }))
    );
    setLoading(false);
    return "resolved";
  }, [walletAddress]);

  const disputeResolution = useCallback(async (_: string): Promise<string> => {
    setLoading(true);
    await new Promise((r) => setTimeout(r, 800));
    setLoading(false);
    return "disputed";
  }, []);

  const claimWinnings = useCallback(async (_: string): Promise<string> => {
    setLoading(true);
    await new Promise((r) => setTimeout(r, 600));
    setPositions((prev) => prev.map((p) => ({ ...p, claimed: true })));
    setLoading(false);
    return "claimed";
  }, []);

  return (
    <AppContext.Provider
      value={{
        connected,
        walletAddress,
        markets,
        positions,
        orders,
        leaderboard,
        loading,
        connect,
        disconnect,
        createMarket,
        placeOrder,
        cancelOrder,
        resolveMarket,
        disputeResolution,
        claimWinnings,
        refreshMarkets,
        refreshPositions,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}
