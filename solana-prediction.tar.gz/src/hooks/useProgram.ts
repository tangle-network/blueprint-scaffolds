import { useState, useEffect, useCallback } from "react";
import { Market, Order, Position, LeaderboardEntry } from "../types";

export function useMarkets() {
  const [markets, setMarkets] = useState<Market[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchMarkets = useCallback(async () => {
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchMarkets();
  }, [fetchMarkets]);

  return { markets, loading, refetch: fetchMarkets };
}

export function usePositions(_walletAddress: string | null) {
  const [positions, setPositions] = useState<Position[]>([]);
  return { positions, loading: false };
}

export function useOrders(_walletAddress: string | null) {
  const [orders, setOrders] = useState<Order[]>([]);
  return { orders, loading: false };
}

export function useLeaderboard() {
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  return { entries, loading: false };
}
