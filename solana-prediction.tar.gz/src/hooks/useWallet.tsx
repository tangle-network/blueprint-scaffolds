import { createContext, useContext, useState, useCallback, FC, ReactNode } from "react";
import { Connection } from "@solana/web3.js";

interface WalletContextState {
  connected: boolean;
  publicKey: string | null;
  connect: () => void;
  disconnect: () => void;
  connection: Connection | null;
}

const WalletContext = createContext<WalletContextState>({
  connected: false,
  publicKey: null,
  connect: () => {},
  disconnect: () => {},
  connection: null,
});

export const useWallet = () => useContext(WalletContext);

export const ConnectionProvider: FC<{ endpoint: string; children: ReactNode }> = ({
  endpoint,
  children,
}) => {
  const [connection] = useState(() => new Connection(endpoint, "confirmed"));
  return (
    <WalletContext.Provider value={{ connected: false, publicKey: null, connect: () => {}, disconnect: () => {}, connection }}>
      {children}
    </WalletContext.Provider>
  );
};

export const WalletProvider: FC<{ children: ReactNode }> = ({ children }) => {
  const [publicKey, setPublicKey] = useState<string | null>(null);
  const connected = publicKey !== null;

  const connect = useCallback(() => {
    const pk = "Demo" + Math.random().toString(36).slice(2, 10) + "...example";
    setPublicKey(pk);
  }, []);

  const disconnect = useCallback(() => {
    setPublicKey(null);
  }, []);

  return (
    <WalletContext.Provider
      value={{ connected, publicKey, connect, disconnect, connection: null }}
    >
      {children}
    </WalletContext.Provider>
  );
};
