use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Transfer};
use std::mem::size_of;

declare_id!("Pred1ct1onMarket11111111111111111111111111");

pub mod errors;
pub mod state;
pub mod instructions;

pub use errors::*;
pub use state::*;
pub use instructions::*;

#[program]
pub mod prediction_market {
    use super::*;

    pub fn initialize_market(
        ctx: Context<InitializeMarket>,
        title: String,
        description: String,
        market_type: MarketType,
        outcomes: Vec<String>,
        end_time: i64,
        oracle_config: OracleConfig,
        fee_bps: u16,
    ) -> Result<()> {
        instructions::initialize_market(
            ctx,
            title,
            description,
            market_type,
            outcomes,
            end_time,
            oracle_config,
            fee_bps,
        )
    }

    pub fn place_order(ctx: Context<PlaceOrder>, order: OrderParams) -> Result<()> {
        instructions::place_order(ctx, order)
    }

    pub fn cancel_order(ctx: Context<CancelOrder>) -> Result<()> {
        instructions::cancel_order(ctx)
    }

    pub fn match_orders(ctx: Context<MatchOrders>) -> Result<()> {
        instructions::match_orders(ctx)
    }

    pub fn resolve_market(ctx: Context<ResolveMarket>, proposed_outcome: u16) -> Result<()> {
        instructions::resolve_market(ctx, proposed_outcome)
    }

    pub fn dispute_resolution(ctx: Context<DisputeResolution>) -> Result<()> {
        instructions::dispute_resolution(ctx)
    }

    pub fn finalize_resolution(ctx: Context<FinalizeResolution>) -> Result<()> {
        instructions::finalize_resolution(ctx)
    }

    pub fn claim_winnings(ctx: Context<ClaimWinnings>) -> Result<()> {
        instructions::claim_winnings(ctx)
    }

    pub fn deposit_liquidity(ctx: Context<DepositLiquidity>, amount: u64) -> Result<()> {
        instructions::deposit_liquidity(ctx, amount)
    }
}
