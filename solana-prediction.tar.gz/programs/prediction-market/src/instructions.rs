use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Transfer};
use crate::{
    errors::PredictionMarketError,
    state::*,
};

const DISPUTE_BOND: u64 = 1_000_000_000;
const DISPUTE_PERIOD: i64 = 86_400;
const MIN_OUTCOMES: usize = 2;

#[derive(Accounts)]
#[instruction(title: String, description: String, market_type: MarketType, outcomes: Vec<String>)]
pub struct InitializeMarket<'info> {
    #[account(
        init,
        payer = authority,
        space = Market::space(outcomes.len()),
        seeds = [b"market", authority.key().as_ref(), title.as_bytes()],
        bump
    )]
    pub market: Account<'info, Market>,
    #[account(
        init,
        payer = authority,
        mint::decimals = 6,
        mint::authority = market,
        seeds = [b"yes_mint", market.key().as_ref()],
        bump,
    )]
    pub yes_shares_mint: Account<'info, token::Mint>,
    #[account(
        init,
        payer = authority,
        mint::decimals = 6,
        mint::authority = market,
        seeds = [b"no_mint", market.key().as_ref()],
        bump,
    )]
    pub no_shares_mint: Account<'info, token::Mint>,
    #[account(
        init,
        payer = authority,
        token::mint = usdc_mint,
        token::authority = market,
        seeds = [b"liquidity", market.key().as_ref()],
        bump,
    )]
    pub liquidity_pool: Account<'info, TokenAccount>,
    pub usdc_mint: Account<'info, token::Mint>,
    #[account(mut)]
    pub authority: Signer<'info>,
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
}

pub fn initialize_market(
    ctx: Context<InitializeMarket>,
    title: String,
    description: String,
    market_type: MarketType,
    outcomes: Vec<String>,
    end_time: i64,
    oracle_config: OracleConfig,
    fee_bps: u16,
) -> Result<()> {
    require!(title.len() <= Market::MAX_TITLE_LEN, PredictionMarketError::TitleTooLong);
    require!(description.len() <= Market::MAX_DESC_LEN, PredictionMarketError::DescriptionTooLong);
    require!(outcomes.len() >= MIN_OUTCOMES, PredictionMarketError::InvalidOutcome);
    require!(outcomes.len() <= Market::MAX_OUTCOMES, PredictionMarketError::TooManyOutcomes);
    require!(fee_bps <= 1000, PredictionMarketError::PriceOutOfRange);

    let clock = Clock::get()?;
    require!(end_time > clock.unix_timestamp, PredictionMarketError::MarketEnded);

    match market_type {
        MarketType::Binary => require!(outcomes.len() == 2, PredictionMarketError::OutcomeCountMismatch),
        MarketType::Categorical => {}
        MarketType::Scalar => require!(outcomes.len() == 2, PredictionMarketError::OutcomeCountMismatch),
    }

    let market = &mut ctx.accounts.market;
    market.authority = ctx.accounts.authority.key();
    market.title = title;
    market.description = description;
    market.market_type = market_type;
    market.outcomes = outcomes;
    market.end_time = end_time;
    market.oracle_config = oracle_config;
    market.resolution_state = ResolutionState::Active;
    market.fee_bps = fee_bps;
    market.liquidity_pool = ctx.accounts.liquidity_pool.key();
    market.total_volume = 0;
    market.yes_shares_mint = ctx.accounts.yes_shares_mint.key();
    market.no_shares_mint = ctx.accounts.no_shares_mint.key();
    market.created_at = clock.unix_timestamp;
    market.resolved_outcome = None;
    market.scalar_range = None;
    market.bump = ctx.bumps.market;

    Ok(())
}

#[derive(Accounts)]
pub struct PlaceOrder<'info> {
    #[account(mut)]
    pub market: Account<'info, Market>,
    #[account(
        init,
        payer = trader,
        space = Order::SPACE,
        seeds = [b"order", market.key().as_ref(), trader.key().as_ref(), &Clock::get()?.unix_timestamp.to_le_bytes()],
        bump
    )]
    pub order: Account<'info, Order>,
    #[account(
        init_if_needed,
        payer = trader,
        space = Position::SPACE,
        seeds = [b"position", market.key().as_ref(), trader.key().as_ref(), &order.outcome.to_le_bytes()],
        bump,
    )]
    pub position: Account<'info, Position>,
    #[account(mut)]
    pub trader_token_account: Account<'info, TokenAccount>,
    #[account(mut)]
    pub market_vault: Account<'info, TokenAccount>,
    #[account(mut)]
    pub trader: Signer<'info>,
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

pub fn place_order(ctx: Context<PlaceOrder>, order_params: OrderParams) -> Result<()> {
    let market = &ctx.accounts.market;
    let clock = Clock::get()?;

    match &market.resolution_state {
        ResolutionState::Active => {}
        _ => return Err(PredictionMarketError::MarketNotActive.into()),
    }

    require!(clock.unix_timestamp < market.end_time, PredictionMarketError::MarketEnded);
    require!(
        (order_params.outcome as usize) < market.outcomes.len(),
        PredictionMarketError::InvalidOutcome
    );
    require!(order_params.price > 0, PredictionMarketError::PriceOutOfRange);
    require!(order_params.price <= 1_000_000, PredictionMarketError::PriceOutOfRange);
    require!(order_params.amount > 0, PredictionMarketError::InsufficientFunds);

    let cost = order_params
        .amount
        .checked_mul(order_params.price)
        .ok_or(PredictionMarketError::PriceOutOfRange)?
        .checked_div(1_000_000)
        .ok_or(PredictionMarketError::PriceOutOfRange)?;

    if matches!(order_params.side, OrderSide::Buy) {
        let cpi_accounts = Transfer {
            from: ctx.accounts.trader_token_account.to_account_info(),
            to: ctx.accounts.market_vault.to_account_info(),
            authority: ctx.accounts.trader.to_account_info(),
        };
        let cpi_program = ctx.accounts.token_program.to_account_info();
        token::transfer(CpiContext::new(cpi_program, cpi_accounts), cost)?;
    }

    let order = &mut ctx.accounts.order;
    order.market = ctx.accounts.market.key();
    order.owner = ctx.accounts.trader.key();
    order.side = order_params.side;
    order.outcome = order_params.outcome;
    order.price = order_params.price;
    order.amount = order_params.amount;
    order.filled_amount = 0;
    order.order_type = order_params.order_type;
    order.created_at = clock.unix_timestamp;
    order.bump = ctx.bumps.order;

    let position = &mut ctx.accounts.position;
    if position.amount == 0 {
        position.owner = ctx.accounts.trader.key();
        position.market = ctx.accounts.market.key();
        position.outcome = order_params.outcome;
        position.avg_price = order_params.price;
        position.claimed = false;
        position.bump = ctx.bumps.position;
    }

    Ok(())
}

#[derive(Accounts)]
pub struct CancelOrder<'info> {
    #[account(mut)]
    pub market: Account<'info, Market>,
    #[account(mut, constraint = order.owner == trader.key() @ PredictionMarketError::Unauthorized)]
    pub order: Account<'info, Order>,
    #[account(mut)]
    pub trader_token_account: Account<'info, TokenAccount>,
    #[account(mut)]
    pub market_vault: Account<'info, TokenAccount>,
    pub trader: Signer<'info>,
    pub token_program: Program<'info, Token>,
}

pub fn cancel_order(ctx: Context<CancelOrder>) -> Result<()> {
    let order = &ctx.accounts.order;
    let unfilled = order.amount.checked_sub(order.filled_amount).unwrap_or(0);
    let refund = unfilled
        .checked_mul(order.price)
        .ok_or(PredictionMarketError::PriceOutOfRange)?
        .checked_div(1_000_000)
        .ok_or(PredictionMarketError::PriceOutOfRange)?;

    if refund > 0 && matches!(order.side, OrderSide::Buy) {
        let market = &ctx.accounts.market;
        let seeds = &[
            b"market",
            market.authority.as_ref(),
            market.title.as_bytes(),
            &[market.bump],
        ];
        let signer = &[&seeds[..]];

        let cpi_accounts = Transfer {
            from: ctx.accounts.market_vault.to_account_info(),
            to: ctx.accounts.trader_token_account.to_account_info(),
            authority: ctx.accounts.market.to_account_info(),
        };
        let cpi_program = ctx.accounts.token_program.to_account_info();
        token::transfer(CpiContext::new_with_signer(cpi_program, cpi_accounts, signer), refund)?;
    }

    Ok(())
}

#[derive(Accounts)]
pub struct MatchOrders<'info> {
    #[account(mut)]
    pub market: Account<'info, Market>,
    #[account(mut)]
    pub buy_order: Account<'info, Order>,
    #[account(mut)]
    pub sell_order: Account<'info, Order>,
    #[account(mut)]
    pub buyer_position: Account<'info, Position>,
    #[account(mut)]
    pub seller_position: Account<'info, Position>,
    pub matcher: Signer<'info>,
}

pub fn match_orders(ctx: Context<MatchOrders>) -> Result<()> {
    let buy = &ctx.accounts.buy_order;
    let sell = &ctx.accounts.sell_order;

    require!(
        buy.outcome == sell.outcome,
        PredictionMarketError::InvalidOutcome
    );
    require!(
        buy.price >= sell.price,
        PredictionMarketError::PriceOutOfRange
    );

    let match_amount = buy
        .amount
        .checked_sub(buy.filled_amount)
        .unwrap_or(0)
        .min(sell.amount.checked_sub(sell.filled_amount).unwrap_or(0));

    require!(match_amount > 0, PredictionMarketError::OrderBookEmpty);

    let match_price = (buy.price + sell.price) / 2;

    let buy_order = &mut ctx.accounts.buy_order;
    buy_order.filled_amount = buy_order.filled_amount.checked_add(match_amount).unwrap();

    let sell_order = &mut ctx.accounts.sell_order;
    sell_order.filled_amount = sell_order.filled_amount.checked_add(match_amount).unwrap();

    let buyer_position = &mut ctx.accounts.buyer_position;
    let total_cost = buyer_position
        .amount
        .checked_mul(buyer_position.avg_price)
        .unwrap_or(0)
        .checked_add(match_amount.checked_mul(match_price).unwrap_or(0))
        .unwrap_or(0);
    buyer_position.amount = buyer_position.amount.checked_add(match_amount).unwrap_or(0);
    if buyer_position.amount > 0 {
        buyer_position.avg_price = total_cost / buyer_position.amount;
    }

    let seller_position = &mut ctx.accounts.seller_position;
    seller_position.amount = seller_position.amount.checked_add(match_amount).unwrap_or(0);

    let market = &mut ctx.accounts.market;
    market.total_volume = market.total_volume.checked_add(match_amount).unwrap_or(0);

    Ok(())
}

#[derive(Accounts)]
pub struct ResolveMarket<'info> {
    #[account(mut)]
    pub market: Account<'info, Market>,
    #[account(mut)]
    pub proposer: Signer<'info>,
    pub system_program: Program<'info, System>,
}

pub fn resolve_market(ctx: Context<ResolveMarket>, proposed_outcome: u16) -> Result<()> {
    let market = &mut ctx.accounts.market;
    let clock = Clock::get()?;

    match &market.resolution_state {
        ResolutionState::Active => {}
        _ => return Err(PredictionMarketError::MarketNotActive.into()),
    }

    require!(
        clock.unix_timestamp >= market.end_time,
        PredictionMarketError::NotResolvable
    );
    require!(
        (proposed_outcome as usize) < market.outcomes.len(),
        PredictionMarketError::InvalidOutcome
    );

    let anchor_bump = ctx.bumps.proposer;
    std::mem::forget(anchor_bump);

    market.resolution_state = ResolutionState::PendingResolution {
        proposed_outcome,
        proposer: ctx.accounts.proposer.key(),
        bond: 0,
        proposed_at: clock.unix_timestamp,
    };

    Ok(())
}

#[derive(Accounts)]
pub struct DisputeResolution<'info> {
    #[account(mut)]
    pub market: Account<'info, Market>,
    #[account(mut, constraint = disputer.key() != market.authority @ PredictionMarketError::Unauthorized)]
    pub disputer: Signer<'info>,
    pub system_program: Program<'info, System>,
}

pub fn dispute_resolution(ctx: Context<DisputeResolution>) -> Result<()> {
    let market = &mut ctx.accounts.market;
    let clock = Clock::get()?;

    match &market.resolution_state {
        ResolutionState::PendingResolution {
            proposed_outcome,
            proposer,
            bond,
            proposed_at,
        } => {
            let elapsed = clock.unix_timestamp - proposed_at;
            require!(
                elapsed < DISPUTE_PERIOD,
                PredictionMarketError::ResolutionPeriodActive
            );

            market.resolution_state = ResolutionState::Disputed {
                proposed_outcome: *proposed_outcome,
                proposer: *proposer,
                disputer: ctx.accounts.disputer.key(),
                bond_total: *bond,
                disputed_at: clock.unix_timestamp,
            };
        }
        _ => return Err(PredictionMarketError::NotInDispute.into()),
    }

    Ok(())
}

#[derive(Accounts)]
pub struct FinalizeResolution<'info> {
    #[account(mut)]
    pub market: Account<'info, Market>,
    pub authority: Signer<'info>,
}

pub fn finalize_resolution(ctx: Context<FinalizeResolution>) -> Result<()> {
    let market = &mut ctx.accounts.market;
    let clock = Clock::get()?;

    match &market.resolution_state {
        ResolutionState::PendingResolution {
            proposed_outcome,
            proposer: _,
            bond: _,
            proposed_at,
        } => {
            let elapsed = clock.unix_timestamp - proposed_at;
            require!(
                elapsed >= DISPUTE_PERIOD,
                PredictionMarketError::ResolutionPeriodActive
            );
            market.resolved_outcome = Some(*proposed_outcome);
            market.resolution_state = ResolutionState::Resolved {
                outcome: *proposed_outcome,
                resolved_at: clock.unix_timestamp,
            };
        }
        ResolutionState::Disputed {
            proposed_outcome,
            proposer: _,
            disputer: _,
            bond_total: _,
            disputed_at,
        } => {
            let elapsed = clock.unix_timestamp - disputed_at;
            require!(
                elapsed >= DISPUTE_PERIOD,
                PredictionMarketError::ResolutionPeriodActive
            );

            if let OracleType::Pyth | OracleType::Switchboard = market.oracle_config.oracle_type {
                market.resolved_outcome = Some(*proposed_outcome);
                market.resolution_state = ResolutionState::Resolved {
                    outcome: *proposed_outcome,
                    resolved_at: clock.unix_timestamp,
                };
            } else {
                return Err(PredictionMarketError::InvalidOracleConfig.into());
            }
        }
        _ => return Err(PredictionMarketError::NotResolvable.into()),
    }

    Ok(())
}

#[derive(Accounts)]
pub struct ClaimWinnings<'info> {
    #[account(mut)]
    pub market: Account<'info, Market>,
    #[account(mut, constraint = position.owner == claimer.key() @ PredictionMarketError::Unauthorized)]
    pub position: Account<'info, Position>,
    #[account(mut)]
    pub claimer_token_account: Account<'info, TokenAccount>,
    #[account(mut)]
    pub market_vault: Account<'info, TokenAccount>,
    pub claimer: Signer<'info>,
    pub token_program: Program<'info, Token>,
}

pub fn claim_winnings(ctx: Context<ClaimWinnings>) -> Result<()> {
    let market = &ctx.accounts.market;
    let position = &mut ctx.accounts.position;

    let resolved_outcome = match &market.resolution_state {
        ResolutionState::Resolved { outcome, .. } => *outcome,
        _ => return Err(PredictionMarketError::NotResolvable.into()),
    };

    require!(
        position.outcome == resolved_outcome,
        PredictionMarketError::InvalidOutcome
    );
    require!(!position.claimed, PredictionMarketError::AlreadyClaimed);

    let payout = position.amount;

    let seeds = &[
        b"market",
        market.authority.as_ref(),
        market.title.as_bytes(),
        &[market.bump],
    ];
    let signer = &[&seeds[..]];

    let cpi_accounts = Transfer {
        from: ctx.accounts.market_vault.to_account_info(),
        to: ctx.accounts.claimer_token_account.to_account_info(),
        authority: ctx.accounts.market.to_account_info(),
    };
    let cpi_program = ctx.accounts.token_program.to_account_info();
    token::transfer(CpiContext::new_with_signer(cpi_program, cpi_accounts, signer), payout)?;

    position.claimed = true;

    Ok(())
}

#[derive(Accounts)]
pub struct DepositLiquidity<'info> {
    #[account(mut)]
    pub market: Account<'info, Market>,
    #[account(mut)]
    pub liquidity_pool: Account<'info, TokenAccount>,
    #[account(mut)]
    pub depositor_token_account: Account<'info, TokenAccount>,
    #[account(mut)]
    pub depositor: Signer<'info>,
    pub token_program: Program<'info, Token>,
}

pub fn deposit_liquidity(ctx: Context<DepositLiquidity>, amount: u64) -> Result<()> {
    require!(amount > 0, PredictionMarketError::InsufficientFunds);

    let cpi_accounts = Transfer {
        from: ctx.accounts.depositor_token_account.to_account_info(),
        to: ctx.accounts.liquidity_pool.to_account_info(),
        authority: ctx.accounts.depositor.to_account_info(),
    };
    let cpi_program = ctx.accounts.token_program.to_account_info();
    token::transfer(CpiContext::new(cpi_program, cpi_accounts), amount)?;

    let market = &mut ctx.accounts.market;
    market.total_volume = market.total_volume.checked_add(amount).unwrap_or(0);

    Ok(())
}
