use anchor_lang::prelude::*;

#[error_code]
pub enum PredictionMarketError {
    #[msg("Market has already ended")]
    MarketEnded,
    #[msg("Market is not active")]
    MarketNotActive,
    #[msg("Invalid outcome index")]
    InvalidOutcome,
    #[msg("Insufficient funds")]
    InsufficientFunds,
    #[msg("Order not found")]
    OrderNotFound,
    #[msg("Not authorized")]
    Unauthorized,
    #[msg("Market not resolvable yet")]
    NotResolvable,
    #[msg("Resolution period has not ended")]
    ResolutionPeriodActive,
    #[msg("Market is not in dispute state")]
    NotInDispute,
    #[msg("Already claimed")]
    AlreadyClaimed,
    #[msg("Invalid market type for this operation")]
    InvalidMarketType,
    #[msg("Outcome count mismatch")]
    OutcomeCountMismatch,
    #[msg("Invalid oracle configuration")]
    InvalidOracleConfig,
    #[msg("Price out of range")]
    PriceOutOfRange,
    #[msg("Order book is empty")]
    OrderBookEmpty,
    #[msg("Scalar value out of bounds")]
    ScalarOutOfBounds,
    #[msg("Title too long")]
    TitleTooLong,
    #[msg("Description too long")]
    DescriptionTooLong,
    #[msg("Too many outcomes")]
    TooManyOutcomes,
    #[msg("Dispute bond insufficient")]
    DisputeBondInsufficient,
}
