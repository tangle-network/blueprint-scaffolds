use anchor_lang::prelude::*;

#[account]
pub struct Market {
    pub authority: Pubkey,
    pub title: String,
    pub description: String,
    pub market_type: MarketType,
    pub outcomes: Vec<String>,
    pub end_time: i64,
    pub oracle_config: OracleConfig,
    pub resolution_state: ResolutionState,
    pub fee_bps: u16,
    pub liquidity_pool: Pubkey,
    pub total_volume: u64,
    pub yes_shares_mint: Pubkey,
    pub no_shares_mint: Pubkey,
    pub created_at: i64,
    pub resolved_outcome: Option<u16>,
    pub scalar_range: Option<(u64, u64)>,
    pub bump: u8,
}

impl Market {
    pub const MAX_TITLE_LEN: usize = 128;
    pub const MAX_DESC_LEN: usize = 1024;
    pub const MAX_OUTCOMES: usize = 16;

    pub fn space(outcome_count: usize) -> usize {
        8 +
        32 +
        (4 + Self::MAX_TITLE_LEN) +
        (4 + Self::MAX_DESC_LEN) +
        (1 + 1) +
        (4 + outcome_count * (4 + 64)) +
        8 +
        OracleConfig::SPACE +
        ResolutionState::SPACE +
        2 +
        32 +
        8 +
        32 +
        32 +
        8 +
        (1 + 2) +
        (1 + 8 + 8) +
        1
    }
}

#[account]
pub struct Order {
    pub market: Pubkey,
    pub owner: Pubkey,
    pub side: OrderSide,
    pub outcome: u16,
    pub price: u64,
    pub amount: u64,
    pub filled_amount: u64,
    pub order_type: OrderType,
    pub created_at: i64,
    pub bump: u8,
}

impl Order {
    pub const SPACE: usize = 8 + 32 + 32 + 1 + 2 + 8 + 8 + 8 + 1 + 8 + 1;
}

#[account]
pub struct Position {
    pub owner: Pubkey,
    pub market: Pubkey,
    pub outcome: u16,
    pub amount: u64,
    pub avg_price: u64,
    pub claimed: bool,
    pub bump: u8,
}

impl Position {
    pub const SPACE: usize = 8 + 32 + 32 + 2 + 8 + 8 + 1 + 1;
}

#[account]
pub struct LiquidityProvider {
    pub provider: Pubkey,
    pub market: Pubkey,
    pub shares: u64,
    pub bump: u8,
}

impl LiquidityProvider {
    pub const SPACE: usize = 8 + 32 + 32 + 8 + 1;
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq, Eq)]
pub enum MarketType {
    Binary,
    Scalar,
    Categorical,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub struct OracleConfig {
    pub oracle_type: OracleType,
    pub oracle_address: Pubkey,
    pub confidence_threshold: u64,
    pub staleness_threshold: i64,
}

impl OracleConfig {
    pub const SPACE: usize = 1 + 32 + 8 + 8;
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq, Eq)]
pub enum OracleType {
    Pyth,
    Switchboard,
    Manual,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq, Eq)]
pub enum ResolutionState {
    Active,
    PendingResolution { proposed_outcome: u16, proposer: Pubkey, bond: u64, proposed_at: i64 },
    Disputed { proposed_outcome: u16, proposer: Pubkey, disputer: Pubkey, bond_total: u64, disputed_at: i64 },
    Resolved { outcome: u16, resolved_at: i64 },
}

impl ResolutionState {
    pub const SPACE: usize = 1 + 2 + 32 * 3 + 8 * 3 + 8;
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq, Eq)]
pub enum OrderSide {
    Buy,
    Sell,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq, Eq)]
pub enum OrderType {
    Limit,
    Market,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub struct OrderParams {
    pub side: OrderSide,
    pub outcome: u16,
    pub price: u64,
    pub amount: u64,
    pub order_type: OrderType,
}
