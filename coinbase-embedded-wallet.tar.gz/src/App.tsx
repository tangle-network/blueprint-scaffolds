import { useEffect, useMemo, useState } from 'react'
import {
  CHAIN_OPTIONS,
  type ChainKey,
  DEFAULT_CHAIN,
  formatEth,
  getNativeBalance,
  getTxHistoryLink,
  isValidAddress,
  signArbitraryMessage,
  switchEip155Chain,
  type TxRow,
} from './lib/chains'
import {
  createProvider,
  ensureConnected,
  getAddress,
  resetConnection,
  sendNative,
} from './lib/wallet'

export default function App() {
  const [chainKey, setChainKey] = useState<ChainKey>(DEFAULT_CHAIN)
  const chain = CHAIN_OPTIONS[chainKey]

  const [status, setStatus] = useState<string>('Ready')
  const [address, setAddress] = useState<string | null>(null)
  const [nativeBalance, setNativeBalance] = useState<string>('0')
  const [sendTo, setSendTo] = useState<string>('')
  const [sendAmountEth, setSendAmountEth] = useState<string>('0.001')
  const [messageToSign, setMessageToSign] = useState<string>(
    'Hello from Embedded Wallets demo',
  )
  const [signature, setSignature] = useState<string>('')
  const [txs, setTxs] = useState<TxRow[]>([])
  const [busy, setBusy] = useState(false)

  const provider = useMemo(() => createProvider(), [])

  async function refresh() {
    const addr = await getAddress(provider)
    setAddress(addr)
    if (!addr) {
      setNativeBalance('0')
      setTxs([])
      return
    }

    const bal = await getNativeBalance(provider, chain, addr)
    setNativeBalance(formatEth(bal))
    setTxs([
      {
        title: 'View history',
        href: getTxHistoryLink(chain, addr),
        subtitle: `${chain.name} explorer`,
      },
    ])
  }

  useEffect(() => {
    // On load: attempt to read existing session.
    refresh().catch((e) => setStatus(`Init error: ${String(e)}`))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    // When chain changes, re-fetch balance; if connected, also request chain switch.
    ;(async () => {
      try {
        const addr = await getAddress(provider)
        if (addr) {
          await switchEip155Chain(provider, chain)
        }
        await refresh()
      } catch (e) {
        setStatus(`Chain refresh error: ${String(e)}`)
      }
    })()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chainKey])

  async function onConnect() {
    setBusy(true)
    setStatus('Connecting (email/social via embedded wallet)...')
    try {
      await ensureConnected(provider, chain)
      setStatus('Connected')
      await refresh()
    } catch (e) {
      setStatus(`Connect error: ${String(e)}`)
    } finally {
      setBusy(false)
    }
  }

  async function onDisconnect() {
    setBusy(true)
    try {
      await resetConnection(provider)
      setAddress(null)
      setNativeBalance('0')
      setTxs([])
      setSignature('')
      setStatus('Disconnected')
    } catch (e) {
      setStatus(`Disconnect error: ${String(e)}`)
    } finally {
      setBusy(false)
    }
  }

  async function onSend() {
    setBusy(true)
    setStatus('Preparing transaction...')
    try {
      if (!address) throw new Error('Connect first')
      if (!isValidAddress(sendTo)) throw new Error('Invalid recipient address')
      if (!Number.isFinite(Number(sendAmountEth)) || Number(sendAmountEth) <= 0)
        throw new Error('Invalid amount')

      await ensureConnected(provider, chain)
      await switchEip155Chain(provider, chain)
      const txHash = await sendNative(provider, chain, sendTo, sendAmountEth)
      setStatus(`Sent: ${txHash}`)
      await refresh()
    } catch (e) {
      setStatus(`Send error: ${String(e)}`)
    } finally {
      setBusy(false)
    }
  }

  async function onSignMessage() {
    setBusy(true)
    setStatus('Signing message...')
    try {
      if (!address) throw new Error('Connect first')
      await ensureConnected(provider, chain)
      await switchEip155Chain(provider, chain)
      const sig = await signArbitraryMessage(provider, messageToSign)
      setSignature(sig)
      setStatus('Message signed')
    } catch (e) {
      setStatus(`Sign error: ${String(e)}`)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="page">
      <header className="header">
        <div className="brand">
          <div className="brandMark" aria-hidden="true" />
          <div>
            <div className="brandTitle">Embedded Wallets Multi-chain</div>
            <div className="brandSub">
              Email/social onboarding, Ethereum/Base/Polygon
            </div>
          </div>
        </div>

        <div className="headerRight">
          <label className="select">
            <span>Chain</span>
            <select
              value={chainKey}
              onChange={(e) => setChainKey(e.target.value as ChainKey)}
              disabled={busy}
            >
              {Object.entries(CHAIN_OPTIONS).map(([k, c]) => (
                <option value={k} key={k}>
                  {c.name}
                </option>
              ))}
            </select>
          </label>

          <div className="pill" title={status}>
            {status}
          </div>
        </div>
      </header>

      <main className="grid">
        <section className="card">
          <h2>Wallet</h2>
          <div className="kv">
            <div className="k">Address</div>
            <div className="v mono">
              {address ?? 'Not connected'}
              {address ? (
                <a
                  className="link"
                  href={getTxHistoryLink(chain, address)}
                  target="_blank"
                  rel="noreferrer"
                >
                  Explorer
                </a>
              ) : null}
            </div>
          </div>
          <div className="kv">
            <div className="k">Native balance</div>
            <div className="v">
              <span className="mono">{nativeBalance}</span>
              <span className="muted"> {chain.nativeSymbol}</span>
            </div>
          </div>

          <div className="row">
            <button className="btn" onClick={onConnect} disabled={busy}>
              One-click create/login
            </button>
            <button className="btnSecondary" onClick={onDisconnect} disabled={busy}>
              Disconnect
            </button>
            <button className="btnGhost" onClick={() => refresh()} disabled={busy}>
              Refresh
            </button>
          </div>

          <div className="note">
            This demo uses Coinbase Wallet SDK provider APIs. Embedded wallet UX is
            controlled by your Coinbase project configuration.
          </div>
        </section>

        <section className="card">
          <h2>Send / Receive</h2>
          <div className="form">
            <label>
              <span>Send to</span>
              <input
                className="input"
                value={sendTo}
                onChange={(e) => setSendTo(e.target.value.trim())}
                placeholder="0x..."
                disabled={busy}
              />
            </label>

            <label>
              <span>Amount ({chain.nativeSymbol})</span>
              <input
                className="input"
                value={sendAmountEth}
                onChange={(e) => setSendAmountEth(e.target.value)}
                inputMode="decimal"
                disabled={busy}
              />
            </label>
          </div>

          <div className="row">
            <button className="btn" onClick={onSend} disabled={busy || !address}>
              Send
            </button>
            <button
              className="btnGhost"
              onClick={() => {
                if (!address) return
                navigator.clipboard.writeText(address).catch(() => {})
                setStatus('Copied address')
              }}
              disabled={!address}
            >
              Copy receive address
            </button>
          </div>

          <div className="note">
            For tokens (ERC-20), extend `lib/erc20.ts` and wire into the UI.
          </div>
        </section>

        <section className="card">
          <h2>Sign</h2>
          <label>
            <span>Message</span>
            <textarea
              className="textarea"
              value={messageToSign}
              onChange={(e) => setMessageToSign(e.target.value)}
              disabled={busy}
            />
          </label>
          <div className="row">
            <button
              className="btn"
              onClick={onSignMessage}
              disabled={busy || !address}
            >
              Sign message
            </button>
          </div>
          {signature ? (
            <div className="sig mono" title={signature}>
              {signature}
            </div>
          ) : (
            <div className="muted">No signature yet.</div>
          )}
        </section>

        <section className="card">
          <h2>Transaction history</h2>
          <div className="muted">
            Wallet SDK provider does not expose a universal tx-history API; we
            deep-link to explorers per chain.
          </div>

          <div className="txList">
            {txs.length === 0 ? (
              <div className="muted">Connect to view history links.</div>
            ) : (
              txs.map((t) => (
                <a
                  className="txRow"
                  href={t.href}
                  target="_blank"
                  rel="noreferrer"
                  key={t.href}
                >
                  <div>
                    <div className="txTitle">{t.title}</div>
                    <div className="txSub">{t.subtitle}</div>
                  </div>
                  <div className="arrow" aria-hidden="true">
                    -&gt;
                  </div>
                </a>
              ))
            )}
          </div>
        </section>
      </main>

      <footer className="footer">
        <div className="muted">
          Set `VITE_COINBASE_APP_NAME` and `VITE_COINBASE_APP_LOGO_URL` in
          `.env` to customize branding.
        </div>
      </footer>
    </div>
  )
}
