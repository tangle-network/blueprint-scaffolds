import { Routes, Route, Navigate } from "react-router-dom";
import { useAccount } from "wagmi";
import { Navbar } from "@/components/Navbar";
import { LoginPage } from "@/pages/LoginPage";
import { DashboardPage } from "@/pages/DashboardPage";
import { SendPage } from "@/pages/SendPage";
import { ReceivePage } from "@/pages/ReceivePage";
import { HistoryPage } from "@/pages/HistoryPage";

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isConnected } = useAccount();
  if (!isConnected) return <Navigate to="/" replace />;
  return <>{children}</>;
}

export default function App() {
  const { isConnected } = useAccount();

  return (
    <div className="min-h-screen bg-background">
      {isConnected && <Navbar />}
      <Routes>
        <Route path="/" element={isConnected ? <Navigate to="/dashboard" replace /> : <LoginPage />} />
        <Route path="/dashboard" element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
        <Route path="/send" element={<ProtectedRoute><SendPage /></ProtectedRoute>} />
        <Route path="/receive" element={<ProtectedRoute><ReceivePage /></ProtectedRoute>} />
        <Route path="/history" element={<ProtectedRoute><HistoryPage /></ProtectedRoute>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </div>
  );
}
