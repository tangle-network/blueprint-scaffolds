import { useAccount, useSwitchChain } from "wagmi";
import { base, mainnet, polygon } from "wagmi/chains";
import { CHAIN_METADATA } from "@/lib/chains";
import { Button } from "@/components/ui/button";
import { ChevronDown } from "lucide-react";
import { useState, useRef, useEffect } from "react";

const supportedChains = [mainnet, base, polygon];

export function ChainSelector() {
  const { isConnected } = useAccount();
  const { switchChain, isPending } = useSwitchChain();
  const chainId = useAccount().chainId;
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  if (!isConnected) return null;

  const current = CHAIN_METADATA[chainId ?? mainnet.id];

  return (
    <div className="relative" ref={ref}>
      <Button
        variant="outline"
        size="sm"
        className="gap-2 min-w-[140px]"
        onClick={() => setOpen(!open)}
        disabled={isPending}
      >
        <span>{current?.icon}</span>
        <span>{current?.name}</span>
        <ChevronDown className="h-3 w-3 ml-auto" />
      </Button>
      {open && (
        <div className="absolute top-full mt-1 left-0 z-50 bg-popover border rounded-md shadow-md w-full min-w-[180px]">
          {supportedChains.map((chain) => {
            const meta = CHAIN_METADATA[chain.id];
            return (
              <button
                key={chain.id}
                className={`w-full text-left px-3 py-2 text-sm hover:bg-accent flex items-center gap-2 ${
                  chain.id === chainId ? "bg-accent" : ""
                }`}
                onClick={() => {
                  switchChain({ chainId: chain.id });
                  setOpen(false);
                }}
                disabled={isPending}
              >
                <span>{meta.icon}</span>
                <span>{meta.name}</span>
                {chain.id === chainId && (
                  <span className="ml-auto text-xs text-muted-foreground">Active</span>
                )}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
