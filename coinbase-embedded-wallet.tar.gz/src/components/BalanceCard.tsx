import { useAccount, useBalance, useChainId } from "wagmi";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CHAIN_METADATA } from "@/lib/chains";
import { Loader2 } from "lucide-react";

export function BalanceCard() {
  const { address, isConnected } = useAccount();
  const chainId = useChainId();
  const chain = CHAIN_METADATA[chainId];

  const { data: balance, isLoading } = useBalance({
    address,
    chainId,
  });

  if (!isConnected) return null;

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          Balance on {chain?.icon} {chain?.name}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex items-center gap-2">
            <Loader2 className="h-4 w-4 animate-spin" />
            <span className="text-sm">Loading...</span>
          </div>
        ) : (
          <div>
            <p className="text-3xl font-bold">
              {balance
                ? `${Number(balance.formatted).toFixed(4)} ${balance.symbol}`
                : "0.0000"}
            </p>
            <p className="text-xs text-muted-foreground mt-1 font-mono">
              {address?.slice(0, 10)}...{address?.slice(-8)}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
