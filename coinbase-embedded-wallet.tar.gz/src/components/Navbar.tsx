import { useAccount, useDisconnect, useChainId } from "wagmi";
import { Link, useLocation } from "react-router-dom";
import { Wallet, LogOut, Menu, X, LayoutDashboard, Send, Download, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { CHAIN_METADATA } from "@/lib/chains";

export function Navbar() {
  const { address, isConnected } = useAccount();
  const { disconnect } = useDisconnect();
  const chainId = useChainId();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const chain = CHAIN_METADATA[chainId];

  const navLinks = [
    { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { to: "/send", label: "Send", icon: Send },
    { to: "/receive", label: "Receive", icon: Download },
    { to: "/history", label: "History", icon: Clock },
  ];

  return (
    <nav className="border-b bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <Link to={isConnected ? "/dashboard" : "/"} className="flex items-center gap-2">
            <Wallet className="h-6 w-6 text-primary" />
            <span className="text-lg font-bold">Web3 Wallet</span>
          </Link>

          {isConnected && (
            <>
              <div className="hidden md:flex items-center gap-1">
                {navLinks.map((link) => (
                  <Link key={link.to} to={link.to}>
                    <Button
                      variant={location.pathname === link.to ? "secondary" : "ghost"}
                      size="sm"
                      className="gap-2"
                    >
                      <link.icon className="h-4 w-4" />
                      {link.label}
                    </Button>
                  </Link>
                ))}
              </div>

              <div className="hidden md:flex items-center gap-3">
                {chain && (
                  <span className="text-sm px-2 py-1 rounded-md bg-muted">
                    {chain.icon} {chain.name}
                  </span>
                )}
                <span className="text-sm font-mono">
                  {address?.slice(0, 6)}...{address?.slice(-4)}
                </span>
                <Button variant="outline" size="sm" onClick={() => disconnect()}>
                  <LogOut className="h-4 w-4 mr-1" />
                  Disconnect
                </Button>
              </div>

              <Button
                variant="ghost"
                size="icon"
                className="md:hidden"
                onClick={() => setMobileOpen(!mobileOpen)}
              >
                {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </Button>
            </>
          )}
        </div>

        {isConnected && mobileOpen && (
          <div className="md:hidden pb-4 space-y-2">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                onClick={() => setMobileOpen(false)}
              >
                <Button
                  variant={location.pathname === link.to ? "secondary" : "ghost"}
                  className="w-full justify-start gap-2"
                >
                  <link.icon className="h-4 w-4" />
                  {link.label}
                </Button>
              </Link>
            ))}
            <div className="pt-2 border-t">
              <span className="text-sm font-mono block mb-2">
                {address?.slice(0, 6)}...{address?.slice(-4)}
              </span>
              <Button variant="outline" size="sm" className="w-full" onClick={() => disconnect()}>
                <LogOut className="h-4 w-4 mr-1" />
                Disconnect
              </Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
