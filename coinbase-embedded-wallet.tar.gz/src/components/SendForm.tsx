import { useState } from "react";
import { useAccount, useSendTransaction, useChainId } from "wagmi";
import { parseEther, type Address } from "viem";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Send as SendIcon, Loader2, CheckCircle, AlertCircle } from "lucide-react";
import { CHAIN_METADATA } from "@/lib/chains";

export function SendForm() {
  const { address, isConnected } = useAccount();
  const chainId = useChainId();
  const chain = CHAIN_METADATA[chainId];
  const [to, setTo] = useState("");
  const [amount, setAmount] = useState("");
  const [status, setStatus] = useState<"idle" | "success" | "error">("idle");

  const { sendTransaction, isPending, data: hash } = useSendTransaction();

  if (!isConnected) return null;

  const handleSend = () => {
    if (!to || !amount) return;
    setStatus("idle");

    sendTransaction(
      {
        to: to as Address,
        value: parseEther(amount),
      },
      {
        onSuccess: () => {
          setStatus("success");
          setTo("");
          setAmount("");
        },
        onError: () => {
          setStatus("error");
        },
      }
    );
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <SendIcon className="h-5 w-5" />
          Send {chain?.symbol}
        </CardTitle>
        <CardDescription>
          Send tokens on {chain?.icon} {chain?.name}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <label className="text-sm font-medium">Recipient Address</label>
          <Input
            placeholder="0x..."
            value={to}
            onChange={(e) => setTo(e.target.value)}
            disabled={isPending}
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium">Amount ({chain?.symbol})</label>
          <Input
            type="number"
            step="0.0001"
            min="0"
            placeholder="0.0"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            disabled={isPending}
          />
        </div>

        <Button
          className="w-full"
          onClick={handleSend}
          disabled={isPending || !to || !amount}
        >
          {isPending ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Confirming...
            </>
          ) : (
            <>
              <SendIcon className="h-4 w-4 mr-2" />
              Send {amount || "0"} {chain?.symbol}
            </>
          )}
        </Button>

        {status === "success" && hash && (
          <div className="flex items-center gap-2 text-sm text-green-600 bg-green-50 p-3 rounded-md">
            <CheckCircle className="h-4 w-4 flex-shrink-0" />
            <span>Transaction sent! Hash: {hash.slice(0, 10)}...{hash.slice(-8)}</span>
          </div>
        )}

        {status === "error" && (
          <div className="flex items-center gap-2 text-sm text-destructive bg-destructive/10 p-3 rounded-md">
            <AlertCircle className="h-4 w-4 flex-shrink-0" />
            <span>Transaction failed. Please try again.</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
