import { useAccount, useChainId } from "wagmi";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowUpRight, ArrowDownLeft, ExternalLink } from "lucide-react";
import { CHAIN_METADATA } from "@/lib/chains";
import { useEffect, useState } from "react";

interface Transaction {
  hash: string;
  from: string;
  to: string;
  value: string;
  timestamp: number;
  type: "send" | "receive";
}

export function TransactionHistory() {
  const { address } = useAccount();
  const chainId = useChainId();
  const chain = CHAIN_METADATA[chainId];
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!address) return;

    setLoading(true);
    const stored = localStorage.getItem(`txs-${address}-${chainId}`);
    if (stored) {
      try {
        setTransactions(JSON.parse(stored));
      } catch {
        setTransactions([]);
      }
    } else {
      setTransactions([]);
    }
    setLoading(false);
  }, [address, chainId]);

  const getExplorerUrl = (hash: string) => {
    const explorers: Record<number, string> = {
      1: "https://etherscan.io",
      8453: "https://basescan.org",
      137: "https://polygonscan.com",
    };
    return `${explorers[chainId] || explorers[1]}/tx/${hash}`;
  };

  if (!address) return null;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <span>{chain?.icon}</span>
          Transactions on {chain?.name}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <p className="text-sm text-muted-foreground text-center py-8">Loading transactions...</p>
        ) : transactions.length === 0 ? (
          <div className="text-center py-12 space-y-2">
            <p className="text-sm text-muted-foreground">No transactions yet</p>
            <p className="text-xs text-muted-foreground">
              Send or receive tokens to see your transaction history here.
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {transactions.map((tx) => (
              <a
                key={tx.hash}
                href={getExplorerUrl(tx.hash)}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between p-3 rounded-md hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`h-8 w-8 rounded-full flex items-center justify-center ${
                      tx.type === "send" ? "bg-red-100 text-red-600" : "bg-green-100 text-green-600"
                    }`}
                  >
                    {tx.type === "send" ? (
                      <ArrowUpRight className="h-4 w-4" />
                    ) : (
                      <ArrowDownLeft className="h-4 w-4" />
                    )}
                  </div>
                  <div>
                    <p className="text-sm font-medium">
                      {tx.type === "send" ? "Sent" : "Received"}
                    </p>
                    <p className="text-xs text-muted-foreground font-mono">
                      {tx.type === "send"
                        ? `To: ${tx.to.slice(0, 6)}...${tx.to.slice(-4)}`
                        : `From: ${tx.from.slice(0, 6)}...${tx.from.slice(-4)}`}
                    </p>
                  </div>
                </div>
                <div className="text-right flex items-center gap-2">
                  <div>
                    <p
                      className={`text-sm font-medium ${
                        tx.type === "send" ? "text-red-600" : "text-green-600"
                      }`}
                    >
                      {tx.type === "send" ? "-" : "+"}
                      {tx.value} {chain?.symbol}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(tx.timestamp).toLocaleDateString()}
                    </p>
                  </div>
                  <ExternalLink className="h-3 w-3 text-muted-foreground" />
                </div>
              </a>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
