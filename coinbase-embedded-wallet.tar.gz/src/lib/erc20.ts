import { ethers } from 'ethers'

// Minimal ERC-20 ABI for balance + transfer.
const ERC20_ABI = [
  'function balanceOf(address) view returns (uint256)',
  'function decimals() view returns (uint8)',
  'function symbol() view returns (string)',
  'function transfer(address to, uint256 amount) returns (bool)',
]

export type Erc20Token = {
  address: string
}

export async function readErc20Balance(
  rpcUrl: string,
  token: Erc20Token,
  owner: string,
): Promise<{ symbol: string; decimals: number; raw: bigint }>
{
  const rpc = new ethers.JsonRpcProvider(rpcUrl)
  const c = new ethers.Contract(token.address, ERC20_ABI, rpc)
  const [symbol, decimals, raw] = await Promise.all([
    c.symbol() as Promise<string>,
    c.decimals() as Promise<number>,
    c.balanceOf(owner) as Promise<bigint>,
  ])
  return { symbol, decimals, raw }
}
