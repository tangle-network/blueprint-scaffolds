export interface Transaction {
  hash: string;
  from: string;
  to: string;
  value: string;
  chainId: number;
  chainName: string;
  tokenSymbol: string;
  timestamp: number;
  status: "pending" | "confirmed" | "failed";
  type: "send" | "receive";
}

const STORAGE_KEY = "wallet_transactions";

export function getStoredTransactions(address: string): Transaction[] {
  try {
    const raw = localStorage.getItem(`${STORAGE_KEY}_${address.toLowerCase()}`);
    if (!raw) return [];
    return JSON.parse(raw) as Transaction[];
  } catch {
    return [];
  }
}

export function storeTransaction(address: string, tx: Transaction): void {
  const existing = getStoredTransactions(address);
  const updated = [tx, ...existing].slice(0, 100);
  localStorage.setItem(
    `${STORAGE_KEY}_${address.toLowerCase()}`,
    JSON.stringify(updated)
  );
}

export function updateTransactionStatus(
  address: string,
  txHash: string,
  status: Transaction["status"]
): void {
  const txs = getStoredTransactions(address);
  const idx = txs.findIndex((t) => t.hash === txHash);
  if (idx !== -1) {
    txs[idx].status = status;
    localStorage.setItem(
      `${STORAGE_KEY}_${address.toLowerCase()}`,
      JSON.stringify(txs)
    );
  }
}
