import CoinbaseWalletSDK from '@coinbase/wallet-sdk'
import { ethers } from 'ethers'
import type { ChainConfig } from './chains'
import type { EIP1193Provider } from './chains'

const APP_NAME = import.meta.env.VITE_COINBASE_APP_NAME ?? 'Embedded Wallets Demo'
const APP_LOGO_URL = import.meta.env.VITE_COINBASE_APP_LOGO_URL ?? ''

// NOTE: Coinbase Wallet SDK 4.x supports multiple transport modes.
// Embedded-wallet UX is configured on the Coinbase side; here we create
// an EIP-1193 provider and use standard request() methods.
export function createProvider(): EIP1193Provider {
  const sdk = new CoinbaseWalletSDK({
    appName: APP_NAME,
    appLogoUrl: APP_LOGO_URL,
  })

  // Using any network here; chain is switched via wallet_switchEthereumChain.
  const provider = sdk.makeWeb3Provider()
  return provider as unknown as EIP1193Provider
}

export async function ensureConnected(
  provider: EIP1193Provider,
  chain: ChainConfig,
): Promise<string> {
  const accounts = (await provider.request({
    method: 'eth_requestAccounts',
  })) as string[]

  const addr = accounts?.[0]
  if (!addr) throw new Error('No accounts returned')

  // Attempt to switch to selected chain after connecting.
  const chainIdHex = ethers.toBeHex(chain.chainId)
  try {
    await provider.request({
      method: 'wallet_switchEthereumChain',
      params: [{ chainId: chainIdHex }],
    })
  } catch {
    // Some wallets require explicit add call.
    await provider.request({
      method: 'wallet_addEthereumChain',
      params: [
        {
          chainId: chainIdHex,
          chainName: chain.name,
          rpcUrls: [chain.rpcUrl],
          blockExplorerUrls: [chain.blockExplorerUrl],
          nativeCurrency: {
            name: chain.nativeSymbol,
            symbol: chain.nativeSymbol,
            decimals: 18,
          },
        },
      ],
    })
  }

  return addr
}

export async function getAddress(provider: EIP1193Provider): Promise<string | null> {
  const accounts = (await provider.request({ method: 'eth_accounts' })) as string[]
  return accounts?.[0] ?? null
}

export async function resetConnection(provider: EIP1193Provider): Promise<void> {
  // Most providers support wallet_disconnect; Coinbase may use close.
  // We'll try both.
  try {
    await provider.request({ method: 'wallet_disconnect' })
  } catch {
    // ignore
  }

  const maybe = provider as unknown as { close?: () => void; disconnect?: () => void }
  try {
    maybe.disconnect?.()
  } catch {
    // ignore
  }
  try {
    maybe.close?.()
  } catch {
    // ignore
  }
}

export async function sendNative(
  provider: EIP1193Provider,
  chain: ChainConfig,
  to: string,
  amountEth: string,
): Promise<string> {
  const accounts = (await provider.request({ method: 'eth_accounts' })) as string[]
  const from = accounts?.[0]
  if (!from) throw new Error('No account connected')

  const valueHex = ethers.toBeHex(ethers.parseEther(amountEth))
  const chainIdHex = ethers.toBeHex(chain.chainId)

  const tx = {
    from,
    to,
    value: valueHex,
    chainId: chainIdHex,
  }
  const txHash = (await provider.request({
    method: 'eth_sendTransaction',
    params: [tx],
  })) as string
  return txHash
}
