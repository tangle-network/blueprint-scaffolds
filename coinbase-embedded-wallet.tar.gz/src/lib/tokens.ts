import type { SupportedChainId } from "./chains";
import { base, polygon } from "viem/chains";

export interface Token {
  symbol: string;
  name: string;
  decimals: number;
  address?: `0x${string}`;
  logoUrl?: string;
}

export interface TokenBalance extends Token {
  balance: bigint;
  formatted: string;
  chainId: SupportedChainId;
}

export const NATIVE_TOKENS: Record<SupportedChainId, Token> = {
  1: { symbol: "ETH", name: "Ether", decimals: 18 },
  [base.id]: { symbol: "ETH", name: "Ether", decimals: 18 },
  [polygon.id]: { symbol: "MATIC", name: "MATIC", decimals: 18 },
};

export const ERC20_TOKENS: Record<SupportedChainId, Token[]> = {
  1: [
    { symbol: "USDC", name: "USD Coin", decimals: 6, address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48" },
    { symbol: "USDT", name: "Tether", decimals: 6, address: "0xdAC17F958D2ee523a2206206994597C13D831ec7" },
    { symbol: "DAI", name: "Dai Stablecoin", decimals: 18, address: "0x6B175474E89094C44Da98b954EedeAC495271d0F" },
  ],
  [base.id]: [
    { symbol: "USDC", name: "USD Coin", decimals: 6, address: "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913" },
    { symbol: "DAI", name: "Dai Stablecoin", decimals: 18, address: "0x50c5725949A6F0c72E6C4a641F24049A917DB0Cb" },
  ],
  [polygon.id]: [
    { symbol: "USDC", name: "USD Coin (PoS)", decimals: 6, address: "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174" },
    { symbol: "USDT", name: "Tether (PoS)", decimals: 6, address: "0xc2132D05D31c914a87C6611C10748AEb04B58e8F" },
  ],
};

export const ERC20_ABI = [
  {
    constant: true,
    inputs: [{ name: "_owner", type: "address" }],
    name: "balanceOf",
    outputs: [{ name: "balance", type: "uint256" }],
    type: "function",
  },
  {
    constant: false,
    inputs: [
      { name: "_to", type: "address" },
      { name: "_value", type: "uint256" },
    ],
    name: "transfer",
    outputs: [{ name: "", type: "bool" }],
    type: "function",
  },
  {
    constant: true,
    inputs: [],
    name: "decimals",
    outputs: [{ name: "", type: "uint8" }],
    type: "function",
  },
] as const;
