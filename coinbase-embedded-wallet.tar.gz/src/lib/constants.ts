export const APP_NAME = "Web3 Wallet";
export const COINBASE_PROJECT_ID = "your-project-id-here";
export const WALLETCONNECT_PROJECT_ID = "your-walletconnect-project-id";
