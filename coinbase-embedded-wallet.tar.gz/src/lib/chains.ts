import { ethers } from 'ethers'

export type ChainConfig = {
  key: ChainKey
  name: string
  chainId: number
  rpcUrl: string
  blockExplorerUrl: string
  nativeSymbol: string
}

export type ChainKey = 'ethereum' | 'base' | 'polygon'

export const CHAIN_OPTIONS: Record<ChainKey, ChainConfig> = {
  ethereum: {
    key: 'ethereum',
    name: 'Ethereum',
    chainId: 1,
    rpcUrl: 'https://cloudflare-eth.com',
    blockExplorerUrl: 'https://etherscan.io',
    nativeSymbol: 'ETH',
  },
  base: {
    key: 'base',
    name: 'Base',
    chainId: 8453,
    rpcUrl: 'https://mainnet.base.org',
    blockExplorerUrl: 'https://basescan.org',
    nativeSymbol: 'ETH',
  },
  polygon: {
    key: 'polygon',
    name: 'Polygon',
    chainId: 137,
    rpcUrl: 'https://polygon-rpc.com',
    blockExplorerUrl: 'https://polygonscan.com',
    nativeSymbol: 'POL',
  },
}

export const DEFAULT_CHAIN: ChainKey = 'base'

export function formatEth(value: bigint): string {
  return ethers.formatEther(value)
}

export function isValidAddress(addr: string): boolean {
  try {
    return ethers.isAddress(addr)
  } catch {
    return false
  }
}

export async function getNativeBalance(
  provider: EIP1193Provider,
  chain: ChainConfig,
  address: string,
): Promise<bigint> {
  const rpc = new ethers.JsonRpcProvider(chain.rpcUrl)
  return rpc.getBalance(address)
}

export async function switchEip155Chain(
  provider: EIP1193Provider,
  chain: ChainConfig,
): Promise<void> {
  // Some wallet providers require chain addition. We'll attempt switch, then add.
  const chainIdHex = ethers.toBeHex(chain.chainId)
  try {
    await provider.request({ method: 'wallet_switchEthereumChain', params: [{ chainId: chainIdHex }] })
  } catch (e: unknown) {
    const msg = String(e)
    const needsAdd = msg.includes('4902') || msg.toLowerCase().includes('unrecognized chain')
    if (!needsAdd) throw e
    await provider.request({
      method: 'wallet_addEthereumChain',
      params: [
        {
          chainId: chainIdHex,
          chainName: chain.name,
          nativeCurrency: {
            name: chain.nativeSymbol,
            symbol: chain.nativeSymbol,
            decimals: 18,
          },
          rpcUrls: [chain.rpcUrl],
          blockExplorerUrls: [chain.blockExplorerUrl],
        },
      ],
    })
  }
}

export async function signArbitraryMessage(
  provider: EIP1193Provider,
  message: string,
): Promise<string> {
  const accounts = (await provider.request({ method: 'eth_accounts' })) as string[]
  const from = accounts?.[0]
  if (!from) throw new Error('No account connected')
  // personal_sign expects params: [message, address]
  return (await provider.request({ method: 'personal_sign', params: [message, from] })) as string
}

export function getTxHistoryLink(chain: ChainConfig, address: string): string {
  const base = chain.blockExplorerUrl.replace(/\/$/, '')
  return `${base}/address/${address}`
}

export type TxRow = {
  title: string
  subtitle: string
  href: string
}

export type EIP1193Provider = {
  request: (args: { method: string; params?: unknown[] | object }) => Promise<unknown>
}
