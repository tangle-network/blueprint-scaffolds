import { defineChain } from "viem";
import { http } from "wagmi";
import { base, mainnet, polygon } from "wagmi/chains";

const chains = [mainnet, base, polygon] as const;

export { chains };

export const CHAIN_METADATA: Record<
  number,
  { name: string; symbol: string; icon: string; color: string }
> = {
  [mainnet.id]: {
    name: "Ethereum",
    symbol: "ETH",
    icon: "⟠",
    color: "from-blue-600 to-blue-400",
  },
  [base.id]: {
    name: "Base",
    symbol: "ETH",
    icon: "🔵",
    color: "from-blue-500 to-blue-300",
  },
  [polygon.id]: {
    name: "Polygon",
    symbol: "MATIC",
    icon: "🟣",
    color: "from-purple-600 to-purple-400",
  },
};

export function getChainConfig(chainId: number) {
  return CHAIN_METADATA[chainId] ?? CHAIN_METADATA[mainnet.id];
}

export { mainnet, base, polygon };
