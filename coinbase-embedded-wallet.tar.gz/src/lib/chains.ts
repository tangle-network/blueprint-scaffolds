import { type Chain } from "viem";
import { base, polygon } from "viem/chains";

export const ethereum: Chain = {
  id: 1,
  name: "Ethereum",
  nativeCurrency: { name: "Ether", symbol: "ETH", decimals: 18 },
  rpcUrls: {
    default: { http: ["https://eth.llamarpc.com"] },
  },
  blockExplorers: {
    default: { name: "Etherscan", url: "https://etherscan.io" },
  },
};

export const SUPPORTED_CHAINS = [ethereum, base, polygon] as const;

export type SupportedChainId = (typeof SUPPORTED_CHAINS)[number]["id"];

export const CHAIN_METADATA: Record<
  SupportedChainId,
  { label: string; icon: string; color: string; explorerUrl: string }
> = {
  [ethereum.id]: {
    label: "Ethereum",
    icon: "⟠",
    color: "#627EEA",
    explorerUrl: "https://etherscan.io",
  },
  [base.id]: {
    label: "Base",
    icon: "🔵",
    color: "#0052FF",
    explorerUrl: "https://basescan.org",
  },
  [polygon.id]: {
    label: "Polygon",
    icon: "🟣",
    color: "#8247E5",
    explorerUrl: "https://polygonscan.com",
  },
};

export function getChainById(id: number): Chain {
  return SUPPORTED_CHAINS.find((c) => c.id === id) ?? ethereum;
}

export function getExplorerTxUrl(chainId: SupportedChainId, txHash: string): string {
  const meta = CHAIN_METADATA[chainId];
  return `${meta.explorerUrl}/tx/${txHash}`;
}

export function getExplorerAddressUrl(chainId: SupportedChainId, address: string): string {
  const meta = CHAIN_METADATA[chainId];
  return `${meta.explorerUrl}/address/${address}`;
}
