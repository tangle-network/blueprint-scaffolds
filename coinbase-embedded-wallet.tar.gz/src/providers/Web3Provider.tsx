import { type ReactNode } from "react";
import { WagmiProvider, createConfig } from "wagmi";
import { coinbaseWallet } from "wagmi/connectors";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { http } from "wagmi";
import { base, mainnet, polygon } from "wagmi/chains";

const queryClient = new QueryClient();

const config = createConfig({
  chains: [mainnet, base, polygon],
  connectors: [
    coinbaseWallet({
      appName: "Web3 Wallet",
      preference: "smartWalletOnly",
    }),
  ],
  transports: {
    [mainnet.id]: http(),
    [base.id]: http(),
    [polygon.id]: http(),
  },
});

export { config };

export function Web3Provider({ children }: { children: ReactNode }) {
  return (
    <WagmiProvider config={config}>
      <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
    </WagmiProvider>
  );
}
