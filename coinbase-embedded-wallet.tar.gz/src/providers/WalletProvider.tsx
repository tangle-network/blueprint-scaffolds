import {
  createContext,
  useContext,
  useState,
  useCallback,
  useEffect,
  type ReactNode,
} from "react";
import {
  createPublicClient,
  createWalletClient,
  custom,
  formatEther,
  http,
  type WalletClient,
  type PublicClient,
} from "viem";
import { CoinbaseWalletSDK } from "@coinbase/wallet-sdk";
import { SUPPORTED_CHAINS, type SupportedChainId, getChainById } from "@/lib/chains";
import { NATIVE_TOKENS, ERC20_TOKENS, ERC20_ABI, type TokenBalance } from "@/lib/tokens";
import { storeTransaction, type Transaction } from "@/lib/transactions";

interface WalletState {
  address: string | null;
  chainId: SupportedChainId;
  isConnected: boolean;
  isConnecting: boolean;
  walletClient: WalletClient | null;
  publicClients: Map<number, PublicClient>;
}

interface WalletActions {
  connect: () => Promise<void>;
  disconnect: () => void;
  switchChain: (chainId: SupportedChainId) => Promise<void>;
  sendNativeToken: (
    to: string,
    amount: string,
    chainId: SupportedChainId
  ) => Promise<string>;
  sendERC20Token: (
    to: string,
    amount: string,
    tokenAddress: string,
    decimals: number,
    chainId: SupportedChainId
  ) => Promise<string>;
  signMessage: (message: string) => Promise<string>;
  getBalances: () => Promise<TokenBalance[]>;
  exportPrivateKey: () => Promise<string>;
}

type WalletContextType = WalletState & WalletActions;

const WalletContext = createContext<WalletContextType | null>(null);

const APP_NAME = "Web3 Embedded Wallet";

function getProvider() {
  const coinbaseWallet = new (CoinbaseWalletSDK as any)({
    appName: APP_NAME,
    preference: {
      options: "smartWalletOnly",
    },
  });
  return coinbaseWallet as any;
}

export function WalletProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<WalletState>({
    address: null,
    chainId: 1 as SupportedChainId,
    isConnected: false,
    isConnecting: false,
    walletClient: null,
    publicClients: new Map(),
  });

  const buildPublicClients = useCallback(() => {
    const clients = new Map<number, PublicClient>();
    for (const chain of SUPPORTED_CHAINS) {
      clients.set(
        chain.id,
        createPublicClient({
          chain,
          transport: http(chain.rpcUrls.default.http[0]),
        }) as PublicClient
      );
    }
    return clients;
  }, []);

  useEffect(() => {
    setState((s) => ({ ...s, publicClients: buildPublicClients() }));
  }, [buildPublicClients]);

  useEffect(() => {
    const saved = localStorage.getItem("wallet_connected");
    if (saved === "true") {
      reconnect();
    }
  }, []);

  const reconnect = async () => {
    try {
      const provider = getProvider();
      const ethereumProvider = provider.makeWeb3Provider();
      const accounts = (await ethereumProvider.request({
        method: "eth_accounts",
      })) as string[];
      if (accounts.length > 0) {
        const chainIdHex = (await ethereumProvider.request({
          method: "eth_chainId",
        })) as string;
        const chainId = parseInt(chainIdHex, 16) as SupportedChainId;
        const walletClient = createWalletClient({
          account: accounts[0] as `0x${string}`,
          transport: custom(ethereumProvider),
        });
        setState((s) => ({
          ...s,
          address: accounts[0],
          chainId,
          isConnected: true,
          walletClient,
        }));
      }
    } catch {
      localStorage.removeItem("wallet_connected");
    }
  };

  const connect = useCallback(async () => {
    setState((s) => ({ ...s, isConnecting: true }));
    try {
      const provider = getProvider();
      const ethereumProvider = provider.makeWeb3Provider();

      const accounts = (await ethereumProvider.request({
        method: "eth_requestAccounts",
      })) as string[];

      const chainIdHex = (await ethereumProvider.request({
        method: "eth_chainId",
      })) as string;
      const chainId = parseInt(chainIdHex, 16) as SupportedChainId;

      const walletClient = createWalletClient({
        account: accounts[0] as `0x${string}`,
        transport: custom(ethereumProvider),
      });

      setState((s) => ({
        ...s,
        address: accounts[0],
        chainId,
        isConnected: true,
        isConnecting: false,
        walletClient,
      }));
      localStorage.setItem("wallet_connected", "true");
    } catch (err) {
      setState((s) => ({ ...s, isConnecting: false }));
      throw err;
    }
  }, []);

  const disconnect = useCallback(() => {
    setState({
      address: null,
      chainId: 1 as SupportedChainId,
      isConnected: false,
      isConnecting: false,
      walletClient: null,
      publicClients: state.publicClients,
    });
    localStorage.removeItem("wallet_connected");
  }, [state.publicClients]);

  const switchChain = useCallback(async (chainId: SupportedChainId) => {
      const chain = getChainById(chainId);
    const provider = getProvider();
    const ethereumProvider = provider.makeWeb3Provider();

    try {
      await ethereumProvider.request({
        method: "wallet_switchEthereumChain",
        params: [{ chainId: `0x${chainId.toString(16)}` }],
      });
    } catch (switchError: any) {
      if (switchError.code === 4902) {
        await ethereumProvider.request({
          method: "wallet_addEthereumChain",
          params: [
            {
              chainId: `0x${chainId.toString(16)}`,
              chainName: chain.name,
              nativeCurrency: chain.nativeCurrency,
              rpcUrls: chain.rpcUrls.default.http,
              blockExplorerUrls: chain.blockExplorers?.default
                ? [chain.blockExplorers.default.url]
                : [],
            },
          ],
        });
      } else {
        throw switchError;
      }
    }

    const walletClient = createWalletClient({
      account: state.address as `0x${string}`,
      transport: custom(ethereumProvider),
    });

    setState((s) => ({ ...s, chainId, walletClient }));
  }, [state.address]);

  const sendNativeToken = useCallback(
    async (to: string, amount: string, chainId: SupportedChainId): Promise<string> => {
      if (!state.walletClient || !state.address) throw new Error("Wallet not connected");

      const value = BigInt(Math.floor(parseFloat(amount) * 1e18));
      const hash = await state.walletClient.sendTransaction({
        to: to as `0x${string}`,
        value,
        account: state.address as `0x${string}`,
        chain: getChainById(chainId),
      });

      const tx: Transaction = {
        hash,
        from: state.address,
        to,
        value: amount,
        chainId,
        chainName: getChainById(chainId).name,
        tokenSymbol: NATIVE_TOKENS[chainId].symbol,
        timestamp: Date.now(),
        status: "pending",
        type: "send",
      };
      storeTransaction(state.address, tx);
      return hash;
    },
    [state.walletClient, state.address]
  );

  const sendERC20Token = useCallback(
    async (
      to: string,
      amount: string,
      tokenAddress: string,
      decimals: number,
      chainId: SupportedChainId
    ): Promise<string> => {
      if (!state.walletClient || !state.address || !state.publicClients)
        throw new Error("Wallet not connected");

      const publicClient = state.publicClients.get(chainId);
      if (!publicClient) throw new Error("No RPC client for this chain");

      const value = BigInt(Math.floor(parseFloat(amount) * 10 ** decimals));
      const { request } = await publicClient.simulateContract({
        address: tokenAddress as `0x${string}`,
        abi: ERC20_ABI,
        functionName: "transfer",
        args: [to as `0x${string}`, value],
        account: state.address as `0x${string}`,
      });

      const hash = await state.walletClient.writeContract(request);

      const tx: Transaction = {
        hash,
        from: state.address,
        to,
        value: amount,
        chainId,
        chainName: getChainById(chainId).name,
        tokenSymbol: "ERC20",
        timestamp: Date.now(),
        status: "pending",
        type: "send",
      };
      storeTransaction(state.address, tx);
      return hash;
    },
    [state.walletClient, state.address, state.publicClients]
  );

  const signMessage = useCallback(
    async (message: string): Promise<string> => {
      if (!state.walletClient || !state.address) throw new Error("Wallet not connected");
      const signature = await state.walletClient.signMessage({
        account: state.address as `0x${string}`,
        message,
      });
      return signature;
    },
    [state.walletClient, state.address]
  );

  const getBalances = useCallback(async (): Promise<TokenBalance[]> => {
    if (!state.address || !state.publicClients) return [];

    const balances: TokenBalance[] = [];

    for (const chain of SUPPORTED_CHAINS) {
      const publicClient = state.publicClients.get(chain.id);
      if (!publicClient) continue;

      try {
        const nativeBalance = await publicClient.getBalance({
          address: state.address as `0x${string}`,
        });

        const nativeToken = NATIVE_TOKENS[chain.id as SupportedChainId];
        balances.push({
          ...nativeToken,
          balance: nativeBalance,
          formatted: formatEther(nativeBalance),
          chainId: chain.id as SupportedChainId,
        });
      } catch {
        continue;
      }

      const erc20List = ERC20_TOKENS[chain.id as SupportedChainId] ?? [];
      for (const token of erc20List) {
        if (!token.address) continue;
        try {
          const rawBalance = await publicClient.readContract({
            address: token.address,
            abi: ERC20_ABI,
            functionName: "balanceOf",
            args: [state.address as `0x${string}`],
          });
          const balance = rawBalance as bigint;
          const formatted = (
            Number(balance) /
            10 ** token.decimals
          ).toFixed(4);
          balances.push({
            ...token,
            balance,
            formatted,
            chainId: chain.id as SupportedChainId,
          });
        } catch {
          continue;
        }
      }
    }

    return balances;
  }, [state.address, state.publicClients]);

  const exportPrivateKey = useCallback(async (): Promise<string> => {
    if (!state.address) throw new Error("Wallet not connected");
    return new Promise((resolve) => {
      resolve(
        "Private key export is not available for embedded wallets. " +
          "Your wallet is secured by your Coinbase account credentials. " +
          "Use recovery options in Coinbase Smart Wallet settings."
      );
    });
  }, [state.address]);

  const value: WalletContextType = {
    ...state,
    connect,
    disconnect,
    switchChain,
    sendNativeToken,
    sendERC20Token,
    signMessage,
    getBalances,
    exportPrivateKey,
  };

  return (
    <WalletContext.Provider value={value}>{children}</WalletContext.Provider>
  );
}

export function useWallet() {
  const ctx = useContext(WalletContext);
  if (!ctx) throw new Error("useWallet must be used within WalletProvider");
  return ctx;
}
