import { useAccount, useChainId } from "wagmi";
import { Copy, Check } from "lucide-react";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CHAIN_METADATA } from "@/lib/chains";

export function ReceivePage() {
  const { address } = useAccount();
  const chainId = useChainId();
  const chain = CHAIN_METADATA[chainId];
  const [copied, setCopied] = useState(false);

  const copyAddress = () => {
    if (address) {
      navigator.clipboard.writeText(address);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  if (!address) return null;

  return (
    <div className="max-w-lg mx-auto px-4 py-8 space-y-6">
      <h1 className="text-2xl font-bold">Receive Tokens</h1>

      <Card>
        <CardHeader className="text-center">
          <CardTitle className="text-lg">Your Wallet Address</CardTitle>
          <CardDescription>
            Share this address to receive tokens on {chain?.icon} {chain?.name}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex justify-center">
            <div className="h-48 w-48 bg-muted rounded-xl flex items-center justify-center border-2 border-dashed">
              <div className="text-center space-y-2">
                <div className="text-4xl">{chain?.icon}</div>
                <p className="text-xs text-muted-foreground">QR Code</p>
                <p className="text-xs text-muted-foreground">{chain?.name}</p>
              </div>
            </div>
          </div>

          <div className="bg-muted p-4 rounded-lg space-y-2">
            <p className="text-xs text-muted-foreground text-center">Address</p>
            <p className="text-sm font-mono text-center break-all">{address}</p>
          </div>

          <Button className="w-full" onClick={copyAddress}>
            {copied ? (
              <>
                <Check className="h-4 w-4 mr-2" />
                Copied!
              </>
            ) : (
              <>
                <Copy className="h-4 w-4 mr-2" />
                Copy Address
              </>
            )}
          </Button>

          <div className="flex flex-wrap gap-2 justify-center">
            <Badge variant="outline">{chain?.icon} {chain?.name}</Badge>
            <Badge variant="outline">{chain?.symbol}</Badge>
          </div>

          <p className="text-xs text-center text-muted-foreground">
            Only send {chain?.symbol} or tokens compatible with {chain?.name} to this address.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
