import { TransactionHistory } from "@/components/TransactionHistory";
import { ChainSelector } from "@/components/ChainSelector";

export function HistoryPage() {
  return (
    <div className="max-w-2xl mx-auto px-4 py-8 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Transaction History</h1>
        <ChainSelector />
      </div>
      <TransactionHistory />
    </div>
  );
}
