import { useConnect } from "wagmi";
import { Wallet, Mail, Shield, Zap, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

export function LoginPage() {
  const { connectors, connect, isPending } = useConnect();

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-muted p-4">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center space-y-2">
          <div className="flex justify-center">
            <div className="h-16 w-16 rounded-2xl bg-primary flex items-center justify-center">
              <Wallet className="h-8 w-8 text-primary-foreground" />
            </div>
          </div>
          <h1 className="text-3xl font-bold">Web3 Wallet</h1>
          <p className="text-muted-foreground">
            Create an instant wallet with your email. No seed phrases required.
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-xl">Get Started</CardTitle>
            <CardDescription>
              Sign in with your email or social account to create a secure embedded wallet
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {connectors.map((connector) => (
              <Button
                key={connector.uid}
                className="w-full h-12 text-base gap-2"
                onClick={() => connect({ connector })}
                disabled={isPending}
              >
                {isPending ? (
                  <span>Connecting...</span>
                ) : (
                  <>
                    <Mail className="h-5 w-5" />
                    Continue with {connector.name}
                    <ArrowRight className="h-4 w-4 ml-auto" />
                  </>
                )}
              </Button>
            ))}
          </CardContent>
        </Card>

        <div className="grid grid-cols-3 gap-4 text-center">
          <div className="space-y-1">
            <div className="flex justify-center">
              <Zap className="h-5 w-5 text-primary" />
            </div>
            <p className="text-xs text-muted-foreground">Instant Setup</p>
          </div>
          <div className="space-y-1">
            <div className="flex justify-center">
              <Shield className="h-5 w-5 text-primary" />
            </div>
            <p className="text-xs text-muted-foreground">Secure & Private</p>
          </div>
          <div className="space-y-1">
            <div className="flex justify-center">
              <Wallet className="h-5 w-5 text-primary" />
            </div>
            <p className="text-xs text-muted-foreground">Multi-Chain</p>
          </div>
        </div>
      </div>
    </div>
  );
}
