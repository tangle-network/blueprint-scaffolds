import { SendForm } from "@/components/SendForm";
import { ChainSelector } from "@/components/ChainSelector";

export function SendPage() {
  return (
    <div className="max-w-lg mx-auto px-4 py-8 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Send Tokens</h1>
        <ChainSelector />
      </div>
      <SendForm />
    </div>
  );
}
