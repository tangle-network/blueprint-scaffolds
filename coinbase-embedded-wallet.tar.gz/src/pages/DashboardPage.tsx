import { useAccount, useBalance, useChainId } from "wagmi";
import { Link } from "react-router-dom";
import { Send, Download, Clock, Wallet } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BalanceCard } from "@/components/BalanceCard";
import { ChainSelector } from "@/components/ChainSelector";
import { CHAIN_METADATA } from "@/lib/chains";
import { base, mainnet, polygon } from "wagmi/chains";

export function DashboardPage() {
  const { address } = useAccount();
  const chainId = useChainId();

  const allChains = [mainnet, base, polygon];

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-sm text-muted-foreground font-mono mt-1">
            {address?.slice(0, 10)}...{address?.slice(-8)}
          </p>
        </div>
        <ChainSelector />
      </div>

      <BalanceCard />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Link to="/send">
          <Button variant="outline" className="w-full h-auto py-4 flex-col gap-2">
            <Send className="h-5 w-5" />
            <span className="text-xs">Send</span>
          </Button>
        </Link>
        <Link to="/receive">
          <Button variant="outline" className="w-full h-auto py-4 flex-col gap-2">
            <Download className="h-5 w-5" />
            <span className="text-xs">Receive</span>
          </Button>
        </Link>
        <Link to="/history">
          <Button variant="outline" className="w-full h-auto py-4 flex-col gap-2">
            <Clock className="h-5 w-5" />
            <span className="text-xs">History</span>
          </Button>
        </Link>
        <Link to="/dashboard">
          <Button variant="outline" className="w-full h-auto py-4 flex-col gap-2">
            <Wallet className="h-5 w-5" />
            <span className="text-xs">Portfolio</span>
          </Button>
        </Link>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Balances Across Chains</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {allChains.map((chain) => (
            <ChainBalanceRow key={chain.id} chainId={chain.id} isActive={chain.id === chainId} />
          ))}
        </CardContent>
      </Card>
    </div>
  );
}

function ChainBalanceRow({ chainId, isActive }: { chainId: number; isActive: boolean }) {
  const { address } = useAccount();
  const meta = CHAIN_METADATA[chainId];
  const { data: balance, isLoading } = useBalance({ address, chainId });

  return (
    <div className="flex items-center justify-between py-2 px-3 rounded-md hover:bg-muted/50">
      <div className="flex items-center gap-3">
        <span className="text-lg">{meta.icon}</span>
        <div>
          <p className="text-sm font-medium">{meta.name}</p>
          <p className="text-xs text-muted-foreground">{meta.symbol}</p>
        </div>
        {isActive && <Badge variant="secondary" className="text-xs">Active</Badge>}
      </div>
      <div className="text-right">
        {isLoading ? (
          <span className="text-sm text-muted-foreground">...</span>
        ) : (
          <p className="text-sm font-medium">
            {balance ? `${Number(balance.formatted).toFixed(4)} ${balance.symbol}` : `0.0000 ${meta.symbol}`}
          </p>
        )}
      </div>
    </div>
  );
}
