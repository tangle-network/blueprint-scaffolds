/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        dark: { 900: '#0a0b0f', 800: '#12131a', 700: '#1a1b26', 600: '#24253a' },
        accent: { DEFAULT: '#6c5ce7', light: '#a29bfe' },
        success: '#00cec9',
        danger: '#ff6b6b'
      }
    }
  },
  plugins: []
}
