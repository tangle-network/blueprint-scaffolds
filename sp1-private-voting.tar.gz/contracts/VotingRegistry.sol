// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IVotingRegistry {
    function registerVoter(address voter, bytes calldata eligibilityProof) external;
    function isRegistered(address voter) external view returns (bool);
    function getVotingPower(address voter) external view returns (uint256);
    function setEligibilityCriteria(
        address tokenContract,
        uint256 minBalance,
        bool isNFT
    ) external;
    function getEligibilityCriteria() external view returns (
        address tokenContract,
        uint256 minBalance,
        bool isNFT
    );
}

contract VotingRegistry is IVotingRegistry {
    address public owner;
    address public tokenContract;
    uint256 public minBalance;
    bool public isNFTEligibility;

    struct VoterInfo {
        bool isRegistered;
        uint256 votingPower;
        bool hasEligibilityProof;
        uint256 registeredAt;
    }

    mapping(address => VoterInfo) public voters;
    address[] public voterList;

    event VoterRegistered(address indexed voter, uint256 votingPower);
    event EligibilityCriteriaUpdated(address tokenContract, uint256 minBalance, bool isNFT);

    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }

    constructor() {
        owner = msg.sender;
    }

    function registerVoter(address voter, bytes calldata) external override {
        require(!voters[voter].isRegistered, "Already registered");
        voters[voter] = VoterInfo({
            isRegistered: true,
            votingPower: 100,
            hasEligibilityProof: true,
            registeredAt: block.timestamp
        });
        voterList.push(voter);
        emit VoterRegistered(voter, 100);
    }

    function isRegistered(address voter) external view override returns (bool) {
        return voters[voter].isRegistered;
    }

    function getVotingPower(address voter) external view override returns (uint256) {
        return voters[voter].votingPower;
    }

    function setEligibilityCriteria(
        address _tokenContract,
        uint256 _minBalance,
        bool _isNFT
    ) external override onlyOwner {
        tokenContract = _tokenContract;
        minBalance = _minBalance;
        isNFTEligibility = _isNFT;
        emit EligibilityCriteriaUpdated(_tokenContract, _minBalance, _isNFT);
    }

    function getEligibilityCriteria() external view override returns (
        address,
        uint256,
        bool
    ) {
        return (tokenContract, minBalance, isNFTEligibility);
    }

    function getVoterCount() external view returns (uint256) {
        return voterList.length;
    }
}
