// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IResultVerification {
    function submitResult(
        bytes32 proposalId,
        uint256 yesVotes,
        uint256 noVotes,
        bytes calldata tallyProof
    ) external;
    function getResult(bytes32 proposalId) external view returns (
        uint256 yesVotes,
        uint256 noVotes,
        uint256 totalVotes,
        bool isVerified
    );
    function isResultVerified(bytes32 proposalId) external view returns (bool);
}

contract ResultVerification is IResultVerification {
    address public owner;
    address public ballotContract;

    struct VotingResult {
        uint256 yesVotes;
        uint256 noVotes;
        uint256 totalVotes;
        bool isVerified;
        bytes tallyProof;
        uint256 submittedAt;
    }

    mapping(bytes32 => VotingResult) public results;

    event ResultSubmitted(
        bytes32 indexed proposalId,
        uint256 yesVotes,
        uint256 noVotes,
        bool verified
    );
    event ResultVerified(bytes32 indexed proposalId);

    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }

    constructor(address _ballotContract) {
        owner = msg.sender;
        ballotContract = _ballotContract;
    }

    function submitResult(
        bytes32 proposalId,
        uint256 yesVotes,
        uint256 noVotes,
        bytes calldata tallyProof
    ) external override onlyOwner {
        require(!results[proposalId].isVerified, "Result already submitted");
        results[proposalId] = VotingResult({
            yesVotes: yesVotes,
            noVotes: noVotes,
            totalVotes: yesVotes + noVotes,
            isVerified: true,
            tallyProof: tallyProof,
            submittedAt: block.timestamp
        });
        emit ResultSubmitted(proposalId, yesVotes, noVotes, true);
        emit ResultVerified(proposalId);
    }

    function getResult(bytes32 proposalId) external view override returns (
        uint256 yesVotes,
        uint256 noVotes,
        uint256 totalVotes,
        bool isVerified
    ) {
        VotingResult storage r = results[proposalId];
        return (r.yesVotes, r.noVotes, r.totalVotes, r.isVerified);
    }

    function isResultVerified(bytes32 proposalId) external view override returns (bool) {
        return results[proposalId].isVerified;
    }

    function getTallyProof(bytes32 proposalId) external view returns (bytes memory) {
        return results[proposalId].tallyProof;
    }
}
