// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IBallotSubmission {
    function submitBallot(
        bytes32 proposalId,
        bytes calldata encryptedChoice,
        bytes32 nullifierHash,
        bytes calldata zkProof
    ) external;
    function hasVoted(bytes32 nullifierHash) external view returns (bool);
    function getBallotCount(bytes32 proposalId) external view returns (uint256);
    function getBallot(bytes32 proposalId, uint256 index) external view returns (
        bytes memory encryptedChoice,
        bytes32 nullifierHash,
        uint256 timestamp
    );
}

contract BallotSubmission is IBallotSubmission {
    address public registry;
    address public owner;

    struct Ballot {
        bytes encryptedChoice;
        bytes32 nullifierHash;
        address submitter;
        uint256 timestamp;
    }

    mapping(bytes32 => Ballot[]) public proposalBallots;
    mapping(bytes32 => bool) public usedNullifiers;
    mapping(bytes32 => bytes) public encryptedTallies;

    event BallotSubmitted(
        bytes32 indexed proposalId,
        bytes32 indexed nullifierHash,
        uint256 timestamp
    );
    event TallyUpdated(bytes32 indexed proposalId, bytes encryptedTally);

    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }

    constructor(address _registry) {
        registry = _registry;
        owner = msg.sender;
    }

    function submitBallot(
        bytes32 proposalId,
        bytes calldata encryptedChoice,
        bytes32 nullifierHash,
        bytes calldata
    ) external override {
        require(!usedNullifiers[nullifierHash], "Nullifier already used");
        usedNullifiers[nullifierHash] = true;
        proposalBallots[proposalId].push(Ballot({
            encryptedChoice: encryptedChoice,
            nullifierHash: nullifierHash,
            submitter: msg.sender,
            timestamp: block.timestamp
        }));
        emit BallotSubmitted(proposalId, nullifierHash, block.timestamp);
    }

    function hasVoted(bytes32 nullifierHash) external view override returns (bool) {
        return usedNullifiers[nullifierHash];
    }

    function getBallotCount(bytes32 proposalId) external view override returns (uint256) {
        return proposalBallots[proposalId].length;
    }

    function getBallot(bytes32 proposalId, uint256 index) external view override returns (
        bytes memory encryptedChoice,
        bytes32 nullifierHash,
        uint256 timestamp
    ) {
        Ballot storage b = proposalBallots[proposalId][index];
        return (b.encryptedChoice, b.nullifierHash, b.timestamp);
    }

    function storeEncryptedTally(bytes32 proposalId, bytes calldata tally) external onlyOwner {
        encryptedTallies[proposalId] = tally;
        emit TallyUpdated(proposalId, tally);
    }

    function getEncryptedTally(bytes32 proposalId) external view returns (bytes memory) {
        return encryptedTallies[proposalId];
    }
}
