// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./VotingRegistry.sol";
import "./BallotSubmission.sol";
import "./ResultVerification.sol";

contract DelegationManager {
    address public owner;
    VotingRegistry public registry;

    struct Delegation {
        address delegator;
        address delegatee;
        bytes32 proposalId;
        bool isActive;
        uint256 createdAt;
        uint256 revokedAt;
    }

    mapping(bytes32 => Delegation[]) public proposalDelegations;
    mapping(address => mapping(bytes32 => address)) public activeDelegation;
    mapping(address => uint256) public delegatedPower;

    event DelegationCreated(
        address indexed delegator,
        address indexed delegatee,
        bytes32 indexed proposalId
    );
    event DelegationRevoked(
        address indexed delegator,
        bytes32 indexed proposalId
    );

    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }

    constructor(address _registry) {
        owner = msg.sender;
        registry = VotingRegistry(_registry);
    }

    function delegate(
        address delegatee,
        bytes32 proposalId
    ) external {
        require(msg.sender != delegatee, "Cannot delegate to self");
        require(registry.isRegistered(msg.sender), "Not registered");
        require(registry.isRegistered(delegatee), "Delegatee not registered");
        require(activeDelegation[msg.sender][proposalId] == address(0), "Already delegated");

        activeDelegation[msg.sender][proposalId] = delegatee;
        uint256 power = registry.getVotingPower(msg.sender);
        delegatedPower[delegatee] += power;

        proposalDelegations[proposalId].push(Delegation({
            delegator: msg.sender,
            delegatee: delegatee,
            proposalId: proposalId,
            isActive: true,
            createdAt: block.timestamp,
            revokedAt: 0
        }));

        emit DelegationCreated(msg.sender, delegatee, proposalId);
    }

    function revokeDelegation(bytes32 proposalId) external {
        address currentDelegatee = activeDelegation[msg.sender][proposalId];
        require(currentDelegatee != address(0), "No active delegation");

        activeDelegation[msg.sender][proposalId] = address(0);
        uint256 power = registry.getVotingPower(msg.sender);
        delegatedPower[currentDelegatee] -= power;

        Delegation[] storage delegations = proposalDelegations[proposalId];
        for (uint256 i = delegations.length; i > 0; i--) {
            if (delegations[i - 1].delegator == msg.sender && delegations[i - 1].isActive) {
                delegations[i - 1].isActive = false;
                delegations[i - 1].revokedAt = block.timestamp;
                break;
            }
        }

        emit DelegationRevoked(msg.sender, proposalId);
    }

    function getEffectiveVotingPower(address voter, bytes32 proposalId) external view returns (uint256) {
        uint256 basePower = registry.getVotingPower(voter);
        uint256 incomingPower = delegatedPower[voter];
        if (activeDelegation[voter][proposalId] != address(0)) {
            return 0;
        }
        return basePower + incomingPower;
    }

    function getDelegationsForProposal(bytes32 proposalId) external view returns (Delegation[] memory) {
        return proposalDelegations[proposalId];
    }
}
