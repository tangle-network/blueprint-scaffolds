# SP1 Private Voting System — Build Plan

## Architecture

Private governance voting on SP1 with encrypted ballots, ZK eligibility proofs, homomorphic tallying, and verifiable counting.

## Pages
- `/` — Dashboard: overview of active proposals, voter stats
- `/proposals/create` — ProposalCreation: create new governance proposals
- `/vote/:id` — PrivateVoting: encrypted ballot submission with ZK eligibility proof
- `/delegation` — DelegationManagement: delegate/undelegate voting power
- `/results/:id` — Results: homomorphic tally decryption, verifiable counting

## Components
- `src/components/ui/` — shadcn/ui primitives (button, card, dialog, input, label, progress, select, separator, switch, tabs, textarea)
- `src/components/ProposalCard.tsx` — renders a proposal summary
- `src/components/BallotForm.tsx` — encrypted vote choice form
- `src/components/EligibilityProof.tsx` — ZK proof generation/display
- `src/components/VoteReceipt.tsx` — verifiable vote receipt
- `src/components/Navbar.tsx` — top navigation
- `src/components/Layout.tsx` — layout wrapper with navbar

## Crypto Modules (src/crypto/)
- `src/crypto/encryption.ts` — ElGamal encryption for ballot encryption/decryption
- `src/crypto/zk-proof.ts` — ZK proof of token/NFT holder eligibility (simulated)
- `src/crypto/homomorphic.ts` — additive homomorphic tally operations
- `src/crypto/keys.ts` — key generation and management

## Contract Simulation (src/contracts/)
- `src/contracts/voting-registry.ts` — proposal CRUD, eligibility criteria
- `src/contracts/ballot-submission.ts` — encrypted ballot storage, duplicate prevention
- `src/contracts/result-verification.ts` — tally decryption, result verification, SP1 proof

## State
- React context for global voting state (proposals, user identity, ballots)

## API Routes (simulated)
- All contract interactions are simulated client-side via the contract modules
- No backend server — pure frontend with localStorage persistence

## Build
- `tsc -b && vite build`
