export type VoteChoice = "for" | "against" | "abstain"

export type ProposalState = "active" | "pending" | "closed"

export type ZKProofStatus = "idle" | "generating" | "complete" | "error"

export interface Voter {
  address: string
  tokenBalance: number
  veGovBalance: number
  nftIds: string[]
  delegatorCount: number
  delegatedPower: number
  hasVoted: Record<string, boolean>
}

export interface Proposal {
  id: string
  title: string
  description: string
  proposer: string
  state: ProposalState
  createdAt: number
  deadline: number
  totalVotes: number
  forVotes: number
  againstVotes: number
  abstainVotes: number
  participationRate: number
  quorum: number
  eligibility: string
  executionHash: string
}

export interface Ballot {
  id: string
  proposalId: string
  ciphertext: string
  nullifier: string
  zkProof: string
  timestamp: number
}

export interface EligibilityProof {
  status: ZKProofStatus
  merkleRoot: string
  proofSteps: string[]
  proofSize: string
  verificationKey: string
  publicInputs: string[]
}

export interface TallyResult {
  proposalId: string
  decryptedFor: number
  decryptedAgainst: number
  decryptedAbstain: number
  totalVoters: number
  nullifierCount: number
  homomorphicSumValid: boolean
  sp1ProofVerified: boolean
  verificationSteps: VerificationStep[]
}

export interface VerificationStep {
  name: string
  status: "pending" | "running" | "complete" | "failed"
  detail: string
}

export interface Delegation {
  id: string
  delegator: string
  delegate: string
  amount: number
  timestamp: number
  active: boolean
}

export interface VotingSession {
  id: string
  proposalId: string
  startedAt: number
  endsAt: number
  encryptionPublicKey: string
  tallyAuthority: string
}

export interface TokenBalance {
  gov: number
  veGov: number
  totalVotingPower: number
}

export interface NFTOwnership {
  tokenId: string
  collection: string
  name: string
}
