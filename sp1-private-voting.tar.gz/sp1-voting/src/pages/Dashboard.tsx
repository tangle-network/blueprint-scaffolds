import { useVotingStore } from "@/store/voting-store"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import {
  Vote,
  Coins,
  Users,
  Clock,
  ShieldCheck,
  TrendingUp,
  FileText,
  Hexagon,
} from "lucide-react"

function StatCard({
  title,
  value,
  subtitle,
  icon: Icon,
  variant = "default",
}: {
  title: string
  value: string
  subtitle: string
  icon: React.ComponentType<{ className?: string }>
  variant?: "default" | "primary"
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className={`h-4 w-4 ${variant === "primary" ? "text-primary" : "text-muted-foreground"}`} />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground">{subtitle}</p>
      </CardContent>
    </Card>
  )
}

export default function Dashboard() {
  const { voter, proposals, tokenBalance, delegations, tallyResults } = useVotingStore()

  const activeProposals = proposals.filter((p) => p.state === "active")
  const closedProposals = proposals.filter((p) => p.state === "closed")
  const pendingProposals = proposals.filter((p) => p.state === "pending")
  const incomingDelegations = delegations.filter(
    (d) => d.delegate === voter.address && d.active
  )
  const totalDelegated = incomingDelegations.reduce((s, d) => s + d.amount, 0)
  const nearestDeadline = activeProposals.sort(
    (a, b) => a.deadline - b.deadline
  )[0]

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Governance Dashboard</h2>
        <p className="text-muted-foreground">
          SP1 Private Voting — your governance overview
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Active Proposals"
          value={String(activeProposals.length)}
          subtitle={`${pendingProposals.length} pending, ${closedProposals.length} closed`}
          icon={FileText}
          variant="primary"
        />
        <StatCard
          title="Token Balance"
          value={`${tokenBalance.gov.toLocaleString()} GOV`}
          subtitle={`${tokenBalance.veGov} veGOV locked`}
          icon={Coins}
        />
        <StatCard
          title="Delegated Power"
          value={`${totalDelegated.toLocaleString()} GOV`}
          subtitle={`${incomingDelegations.length} delegators`}
          icon={Users}
        />
        <StatCard
          title="Total Voting Power"
          value={`${tokenBalance.totalVotingPower.toLocaleString()} GOV`}
          subtitle={`${((tokenBalance.totalVotingPower / 53800) * 100).toFixed(1)}% of quorum`}
          icon={TrendingUp}
        />
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-yellow-500" />
              Upcoming Deadlines
            </CardTitle>
            <CardDescription>Active proposals ending soon</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {activeProposals.map((p) => {
              const daysLeft = Math.max(
                0,
                Math.ceil((p.deadline - Date.now()) / 86400000)
              )
              const timeProgress = Math.min(
                100,
                ((Date.now() - p.createdAt) / (p.deadline - p.createdAt)) * 100
              )
              return (
                <div key={p.id} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium truncate max-w-[260px]">
                      {p.title}
                    </span>
                    <Badge variant={daysLeft <= 2 ? "destructive" : "secondary"}>
                      {daysLeft}d left
                    </Badge>
                  </div>
                  <Progress value={timeProgress} className="h-2" />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{p.participationRate}% participation</span>
                    <span>
                      {p.totalVotes.toLocaleString()} / {p.quorum.toLocaleString()} votes
                    </span>
                  </div>
                </div>
              )
            })}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-primary" />
              Voting Activity
            </CardTitle>
            <CardDescription>Your recent governance participation</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {proposals.map((p) => {
              const hasVoted = voter.hasVoted[p.id]
              return (
                <div
                  key={p.id}
                  className="flex items-center justify-between rounded-md border p-3"
                >
                  <div className="space-y-1">
                    <p className="text-sm font-medium truncate max-w-[240px]">
                      {p.title}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {p.state === "closed"
                        ? "Finalized"
                        : hasVoted
                        ? "Vote submitted"
                        : "Awaiting your vote"}
                    </p>
                  </div>
                  <Badge
                    variant={
                      hasVoted
                        ? "success"
                        : p.state === "active"
                        ? "warning"
                        : "secondary"
                    }
                  >
                    {hasVoted ? "Voted" : p.state === "active" ? "Pending" : "Closed"}
                  </Badge>
                </div>
              )
            })}
          </CardContent>
        </Card>
      </div>

      <Separator />

      <div>
        <h3 className="mb-4 text-lg font-semibold flex items-center gap-2">
          <Hexagon className="h-5 w-5 text-primary" />
          NFT Credentials
        </h3>
        <div className="grid gap-4 md:grid-cols-2">
          {useVotingStore.getState().nftOwnership.map((nft) => (
            <Card key={nft.tokenId}>
              <CardContent className="flex items-center gap-4 pt-6">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <Hexagon className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="font-medium">{nft.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {nft.collection} — ID: {nft.tokenId}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
