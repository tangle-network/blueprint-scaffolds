import { useState } from "react"
import { useVotingStore } from "@/store/voting-store"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { Lock, Clock, User, ChevronRight } from "lucide-react"
import type { ProposalState } from "@/types/voting"

export default function Proposals() {
  const { proposals, voter } = useVotingStore()
  const [filter, setFilter] = useState<"all" | ProposalState>("all")

  const filtered = filter === "all" ? proposals : proposals.filter((p) => p.state === filter)

  const stateBadge = (state: ProposalState) => {
    const map: Record<ProposalState, "success" | "warning" | "secondary"> = {
      active: "success",
      pending: "warning",
      closed: "secondary",
    }
    return map[state]
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Proposals</h2>
          <p className="text-muted-foreground">
            Browse and filter governance proposals
          </p>
        </div>
        <Select value={filter} onValueChange={(v) => setFilter(v as typeof filter)}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filter" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Proposals</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="closed">Closed</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-4">
        {filtered.map((proposal) => {
          const daysLeft = Math.max(
            0,
            Math.ceil((proposal.deadline - Date.now()) / 86400000)
          )
          const hasVoted = voter.hasVoted[proposal.id]
          const quorumProgress = Math.min(
            100,
            (proposal.totalVotes / proposal.quorum) * 100
          )
          const forPercent =
            proposal.totalVotes > 0
              ? ((proposal.forVotes / proposal.totalVotes) * 100).toFixed(1)
              : "0"

          return (
            <Card key={proposal.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2">
                      <CardTitle className="text-base">{proposal.title}</CardTitle>
                      <Badge variant={stateBadge(proposal.state)}>
                        {proposal.state}
                      </Badge>
                      {hasVoted && (
                        <Badge variant="outline" className="text-primary border-primary">
                          Voted
                        </Badge>
                      )}
                    </div>
                    <CardDescription className="max-w-2xl">
                      {proposal.description}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <User className="h-3 w-3" /> Proposer
                    </p>
                    <p className="text-xs font-mono">
                      {proposal.proposer.slice(0, 10)}...{proposal.proposer.slice(-8)}
                    </p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="h-3 w-3" /> Deadline
                    </p>
                    <p className="text-xs">
                      {proposal.state === "closed"
                        ? "Ended"
                        : `${daysLeft} days remaining`}
                    </p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Eligibility</p>
                    <p className="text-xs">{proposal.eligibility}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Quorum</p>
                    <p className="text-xs">
                      {proposal.totalVotes.toLocaleString()} / {proposal.quorum.toLocaleString()}
                    </p>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Participation: {proposal.participationRate}%</span>
                    <span>Quorum: {quorumProgress.toFixed(1)}%</span>
                  </div>
                  <Progress value={quorumProgress} className="h-2" />
                </div>

                <div className="flex items-center justify-between rounded-md bg-muted/50 p-3">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1">
                      <Lock className="h-3 w-3 text-muted-foreground" />
                      <span className="text-xs text-muted-foreground">
                        Tally: Encrypted
                      </span>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {proposal.totalVotes.toLocaleString()} encrypted ballots
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-xs">
                    <span className="text-green-400">
                      For: {forPercent}% (est.)
                    </span>
                    <span className="text-red-400">
                      Against: {(100 - parseFloat(forPercent)).toFixed(1)}% (est.)
                    </span>
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button variant="ghost" size="sm" className="gap-1">
                    View Details <ChevronRight className="h-3 w-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {filtered.length === 0 && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <p className="text-muted-foreground">No proposals match this filter.</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
