import { BrowserRouter, Routes, Route, NavLink } from "react-router-dom"
import { LayoutDashboard, FileText, Vote, Users, ShieldCheck, Hexagon } from "lucide-react"
import Dashboard from "@/pages/Dashboard"
import Proposals from "@/pages/Proposals"
import SubmitVote from "@/pages/SubmitVote"
import Delegations from "@/pages/Delegations"
import ResultsVerification from "@/pages/ResultsVerification"
import { cn } from "@/lib/utils"
import { Separator } from "@/components/ui/separator"

const NAV_ITEMS = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard },
  { to: "/proposals", label: "Proposals", icon: FileText },
  { to: "/vote", label: "Submit Vote", icon: Vote },
  { to: "/delegations", label: "Delegations", icon: Users },
  { to: "/results", label: "Results Verification", icon: ShieldCheck },
]

function Sidebar() {
  return (
    <aside className="flex h-screen w-64 flex-col border-r bg-card">
      <div className="flex items-center gap-3 px-6 py-5">
        <Hexagon className="h-7 w-7 text-primary" />
        <div>
          <h1 className="text-lg font-bold tracking-tight">SP1 Governance</h1>
          <p className="text-xs text-muted-foreground">Private Voting</p>
        </div>
      </div>
      <Separator />
      <nav className="flex-1 space-y-1 px-3 py-4">
        {NAV_ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === "/"}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                isActive
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              )
            }
          >
            <item.icon className="h-4 w-4" />
            {item.label}
          </NavLink>
        ))}
      </nav>
      <Separator />
      <div className="px-4 py-3">
        <p className="text-xs text-muted-foreground truncate">
          0x7a3F...A0b1
        </p>
        <p className="text-xs text-muted-foreground">8,327.7 GOV power</p>
      </div>
    </aside>
  )
}

function App() {
  return (
    <BrowserRouter>
      <div className="flex h-screen overflow-hidden">
        <Sidebar />
        <main className="flex-1 overflow-y-auto bg-background p-6">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/proposals" element={<Proposals />} />
            <Route path="/vote" element={<SubmitVote />} />
            <Route path="/delegations" element={<Delegations />} />
            <Route path="/results" element={<ResultsVerification />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  )
}

export default App
