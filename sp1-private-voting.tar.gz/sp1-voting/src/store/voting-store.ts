import { create } from "zustand"
import type {
  Voter,
  Proposal,
  Ballot,
  EligibilityProof,
  TallyResult,
  Delegation,
  VotingSession,
  TokenBalance,
  NFTOwnership,
  VoteChoice,
  ZKProofStatus,
  VerificationStep,
} from "@/types/voting"

interface VotingStore {
  voter: Voter
  proposals: Proposal[]
  ballots: Ballot[]
  delegations: Delegation[]
  sessions: VotingSession[]
  tokenBalance: TokenBalance
  nftOwnership: NFTOwnership[]
  eligibilityProofs: Record<string, EligibilityProof>
  tallyResults: Record<string, TallyResult>
  selectedProposal: string | null
  selectedVote: VoteChoice | null
  isEncrypting: boolean
  proofGenerationStep: number

  setSelectedProposal: (id: string | null) => void
  setSelectedVote: (choice: VoteChoice | null) => void
  setIsEncrypting: (v: boolean) => void
  setProofGenerationStep: (n: number) => void
  startProofGeneration: (proposalId: string) => void
  submitBallot: (proposalId: string, choice: VoteChoice) => void
  addDelegation: (delegate: string, amount: number) => void
  revokeDelegation: (id: string) => void
  castVote: (proposalId: string) => void
}

const PROPOSALS: Proposal[] = [
  {
    id: "sip-42",
    title: "SIP-42: Increase ETH Liquidation Threshold to 85%",
    description:
      "Proposal to raise the ETH collateral liquidation threshold from 80% to 85%, allowing borrowers greater capital efficiency while maintaining protocol solvency through enhanced SP1-based risk monitoring.",
    proposer: "0x7a3F8b2C1dE9456aB8c3F2e1D4a5B6c7E8f9A0b1",
    state: "active",
    createdAt: Date.now() - 3 * 86400000,
    deadline: Date.now() + 4 * 86400000,
    totalVotes: 18420,
    forVotes: 12105,
    againstVotes: 5230,
    abstainVotes: 1085,
    participationRate: 34.2,
    quorum: 25000,
    eligibility: "GOV token holders with ≥ 100 GOV",
    executionHash: "0xabcd1234ef567890abcd1234ef567890abcd1234ef567890abcd1234ef567890",
  },
  {
    id: "sip-43",
    title: "SIP-43: Add USDC as Collateral Type",
    description:
      "Enable USDC (Circle) as a whitelisted collateral asset with a 75% LTV ratio and 90% liquidation threshold. Requires integration with Chainlink USDC/ETH price feed and SP1 proof of reserve attestation.",
    proposer: "0x2B4c6D8eF0A1234b5678C9dE0f1234aB567890cD",
    state: "active",
    createdAt: Date.now() - 1 * 86400000,
    deadline: Date.now() + 6 * 86400000,
    totalVotes: 8930,
    forVotes: 7240,
    againstVotes: 1190,
    abstainVotes: 500,
    participationRate: 16.6,
    quorum: 25000,
    eligibility: "veGOV holders with ≥ 6-month lock",
    executionHash: "0x1234abcd5678ef901234abcd5678ef901234abcd5678ef901234abcd5678ef90",
  },
  {
    id: "sip-44",
    title: "SIP-44: Implement Flash Loan Governance Defense",
    description:
      "Deploy a 48-hour governance delay on proposals affecting critical protocol parameters. Uses SP1 to verify that voting power has been held for the minimum duration, preventing flash loan governance attacks.",
    proposer: "0x9F8e7D6c5B4a3210FEDCBA9876543210AbCdEf01",
    state: "active",
    createdAt: Date.now() - 5 * 86400000,
    deadline: Date.now() + 2 * 86400000,
    totalVotes: 22100,
    forVotes: 19890,
    againstVotes: 1560,
    abstainVotes: 650,
    participationRate: 41.1,
    quorum: 25000,
    eligibility: "GOV + veGOV holders",
    executionHash: "0x5678ef901234abcd5678ef901234abcd5678ef901234abcd5678ef901234abcd",
  },
  {
    id: "sip-45",
    title: "SIP-45: Reduce Protocol Treasury Allocation to 5%",
    description:
      "Redirect 3% of protocol revenue currently allocated to the treasury toward a community grants program managed by a 5-of-7 multisig. SP1 proof ensures transparent fund tracking and quarterly reporting.",
    proposer: "0x4A5b6C7d8E9f0123ABcDeF4567890123AbCdEf45",
    state: "pending",
    createdAt: Date.now() - 0.5 * 86400000,
    deadline: Date.now() + 7 * 86400000,
    totalVotes: 3200,
    forVotes: 2100,
    againstVotes: 800,
    abstainVotes: 300,
    participationRate: 5.9,
    quorum: 25000,
    eligibility: "GOV NFT holders (Genesis or Council)",
    executionHash: "0xef901234abcd5678ef901234abcd5678ef901234abcd5678ef901234abcd5678",
  },
  {
    id: "sip-41",
    title: "SIP-41: Migrate Oracle Infrastructure to Pyth Network",
    description:
      "Transition from Chainlink to Pyth Network for all price feeds, reducing latency from 60s to 400ms. SP1 proof validates price data integrity and provides fallback circuit breaker logic.",
    proposer: "0x1D2E3f4A5b6C7d8E9f012345AbcDEf67890aBcDe",
    state: "closed",
    createdAt: Date.now() - 10 * 86400000,
    deadline: Date.now() - 3 * 86400000,
    totalVotes: 31500,
    forVotes: 28350,
    againstVotes: 2100,
    abstainVotes: 1050,
    participationRate: 58.5,
    quorum: 25000,
    eligibility: "All GOV, veGOV, and NFT holders",
    executionHash: "0xabcd5678ef901234abcd5678ef901234abcd5678ef901234abcd5678ef901234",
  },
]

const DELEGATIONS: Delegation[] = [
  {
    id: "del-1",
    delegator: "0x3A4b5C6d7E8f9012AbCdEf3456789012aBcDeF56",
    delegate: "0x7a3F8b2C1dE9456aB8c3F2e1D4a5B6c7E8f9A0b1",
    amount: 4500,
    timestamp: Date.now() - 14 * 86400000,
    active: true,
  },
  {
    id: "del-2",
    delegator: "0x5C6d7E8f9012AbCdEf3456789012aBcDeF567890",
    delegate: "0x7a3F8b2C1dE9456aB8c3F2e1D4a5B6c7E8f9A0b1",
    amount: 2200,
    timestamp: Date.now() - 7 * 86400000,
    active: true,
  },
  {
    id: "del-3",
    delegator: "0x7a3F8b2C1dE9456aB8c3F2e1D4a5B6c7E8f9A0b1",
    delegate: "0x9F8e7D6c5B4a3210FEDCBA9876543210AbCdEf01",
    amount: 1620,
    timestamp: Date.now() - 30 * 86400000,
    active: true,
  },
]

const VOTER: Voter = {
  address: "0x7a3F8b2C1dE9456aB8c3F2e1D4a5B6c7E8f9A0b1",
  tokenBalance: 1247.5,
  veGovBalance: 380.2,
  nftIds: ["genesis-0042", "council-0117"],
  delegatorCount: 2,
  delegatedPower: 6700,
  hasVoted: {
    "sip-41": true,
    "sip-44": true,
  },
}

const TOKEN_BALANCE: TokenBalance = {
  gov: 1247.5,
  veGov: 380.2,
  totalVotingPower: 8327.7,
}

const NFTS: NFTOwnership[] = [
  {
    tokenId: "genesis-0042",
    collection: "SP1 Governance Genesis",
    name: "Genesis Voter #42",
  },
  {
    tokenId: "council-0117",
    collection: "SP1 Council Pass",
    name: "Council Member #117",
  },
]

const SESSIONS: VotingSession[] = PROPOSALS.filter((p) => p.state === "active").map(
  (p) => ({
    id: `session-${p.id}`,
    proposalId: p.id,
    startedAt: p.createdAt,
    endsAt: p.deadline,
    encryptionPublicKey: `0xPubK_${p.id}_${Math.random().toString(16).slice(2, 10)}`,
    tallyAuthority: "0xAuTh0R1Ty999888777666555444333222111000",
  })
)

const TALLY_RESULTS: Record<string, TallyResult> = {
  "sip-41": {
    proposalId: "sip-41",
    decryptedFor: 28350,
    decryptedAgainst: 2100,
    decryptedAbstain: 1050,
    totalVoters: 12847,
    nullifierCount: 12847,
    homomorphicSumValid: true,
    sp1ProofVerified: true,
    verificationSteps: [
      { name: "Nullifier uniqueness check", status: "complete", detail: "12,847 nullifiers verified — zero duplicates detected" },
      { name: "Homomorphic sum validation", status: "complete", detail: "E(Σ votes) = Σ E(vote_i) — additive homomorphism confirmed" },
      { name: "Decryption authority signature", status: "complete", detail: "Threshold signature (3-of-5) verified on decrypted tally" },
      { name: "SP1 RISC-V proof verification", status: "complete", detail: "Groth16 proof verified — 2.4MB proof, ~130ms verification" },
    ],
  },
  "sip-44": {
    proposalId: "sip-44",
    decryptedFor: 0,
    decryptedAgainst: 0,
    decryptedAbstain: 0,
    totalVoters: 0,
    nullifierCount: 0,
    homomorphicSumValid: false,
    sp1ProofVerified: false,
    verificationSteps: [
      { name: "Nullifier uniqueness check", status: "pending", detail: "Awaiting voting period end" },
      { name: "Homomorphic sum validation", status: "pending", detail: "Awaiting decryption phase" },
      { name: "Decryption authority signature", status: "pending", detail: "Awaiting threshold signature" },
      { name: "SP1 RISC-V proof verification", status: "pending", detail: "Awaiting proof submission" },
    ],
  },
}

const PROOF_STEPS = [
  "Computing Merkle proof of token ownership...",
  "Building inclusion proof for GOV balance ≥ 100...",
  "Generating SP1 RISC-V zkVM execution trace...",
  "Executing Fiat-Shamir heuristic for non-interactive proof...",
  "Compiling Groth16 SNARK from RISC-V trace...",
  "Proof size: 2.4MB — Finalizing public inputs...",
]

export const useVotingStore = create<VotingStore>((set, get) => ({
  voter: VOTER,
  proposals: PROPOSALS,
  ballots: [],
  delegations: DELEGATIONS,
  sessions: SESSIONS,
  tokenBalance: TOKEN_BALANCE,
  nftOwnership: NFTS,
  eligibilityProofs: {},
  tallyResults: TALLY_RESULTS,
  selectedProposal: null,
  selectedVote: null,
  isEncrypting: false,
  proofGenerationStep: 0,

  setSelectedProposal: (id) => set({ selectedProposal: id }),
  setSelectedVote: (choice) => set({ selectedVote: choice }),
  setIsEncrypting: (v) => set({ isEncrypting: v }),
  setProofGenerationStep: (n) => set({ proofGenerationStep: n }),

  startProofGeneration: (proposalId) => {
    const steps = PROOF_STEPS
    set({
      eligibilityProofs: {
        ...get().eligibilityProofs,
        [proposalId]: {
          status: "generating" as ZKProofStatus,
          merkleRoot: "0xMrkl" + Math.random().toString(16).slice(2, 66),
          proofSteps: [],
          proofSize: "0 KB",
          verificationKey: "0xVk_" + proposalId,
          publicInputs: [],
        },
      },
      proofGenerationStep: 0,
    })

    let step = 0
    const interval = setInterval(() => {
      step++
      if (step <= steps.length) {
        const currentProofs = get().eligibilityProofs
        const current = currentProofs[proposalId]
        if (!current) {
          clearInterval(interval)
          return
        }
        set({
          proofGenerationStep: step,
          eligibilityProofs: {
            ...currentProofs,
            [proposalId]: {
              ...current,
              proofSteps: steps.slice(0, step),
              proofSize: step >= 6 ? "2.4MB" : `${(step * 0.4).toFixed(1)}MB`,
            },
          },
        })
      } else {
        clearInterval(interval)
        const currentProofs = get().eligibilityProofs
        const current = currentProofs[proposalId]
        if (current) {
          set({
            eligibilityProofs: {
              ...currentProofs,
              [proposalId]: {
                ...current,
                status: "complete" as ZKProofStatus,
                proofSize: "2.4MB",
                publicInputs: [
                  "0x" + Math.random().toString(16).slice(2, 66),
                  "0x" + Math.random().toString(16).slice(2, 66),
                  "0x" + Math.random().toString(16).slice(2, 66),
                ],
              },
            },
          })
        }
      }
    }, 800)
  },

  submitBallot: (proposalId, choice) => {
    const ballot: Ballot = {
      id: `ballot-${Date.now()}`,
      proposalId,
      ciphertext: `0xCt_${Math.random().toString(16).slice(2, 34)}...${Math.random().toString(16).slice(2, 34)}`,
      nullifier: `0xNul_${Math.random().toString(16).slice(2, 34)}`,
      zkProof: `0xZkp_${Math.random().toString(16).slice(2, 34)}`,
      timestamp: Date.now(),
    }
    set((state) => ({
      ballots: [...state.ballots, ballot],
      voter: {
        ...state.voter,
        hasVoted: { ...state.voter.hasVoted, [proposalId]: true },
      },
      isEncrypting: false,
      selectedProposal: null,
      selectedVote: null,
      proofGenerationStep: 0,
    }))
  },

  addDelegation: (delegate, amount) => {
    const del: Delegation = {
      id: `del-${Date.now()}`,
      delegator: VOTER.address,
      delegate,
      amount,
      timestamp: Date.now(),
      active: true,
    }
    set((state) => ({
      delegations: [...state.delegations, del],
      voter: {
        ...state.voter,
        delegatedPower: state.voter.delegatedPower - amount,
      },
      tokenBalance: {
        ...state.tokenBalance,
        totalVotingPower: state.tokenBalance.totalVotingPower - amount,
      },
    }))
  },

  revokeDelegation: (id) => {
    set((state) => {
      const target = state.delegations.find((d) => d.id === id)
      if (!target) return state
      return {
        delegations: state.delegations.map((d) =>
          d.id === id ? { ...d, active: false } : d
        ),
        voter: {
          ...state.voter,
          delegatedPower:
            target.delegator === VOTER.address
              ? state.voter.delegatedPower
              : state.voter.delegatedPower + target.amount,
        },
      }
    })
  },

  castVote: (proposalId) => {
    set((state) => ({
      voter: {
        ...state.voter,
        hasVoted: { ...state.voter.hasVoted, [proposalId]: true },
      },
    }))
  },
}))
