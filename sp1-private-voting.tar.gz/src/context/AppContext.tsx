import { createContext, useContext, useState, type ReactNode } from 'react'

export interface Voter {
  address: string
  tokenBalance: number
  nftIds: string[]
  isRegistered: boolean
  delegatedTo: string | null
  delegatedFrom: string[]
}

export interface Proposal {
  id: string
  title: string
  description: string
  options: string[]
  createdAt: number
  endsAt: number
  status: 'active' | 'closed' | 'pending'
  encryptedTally: string
  totalVotes: number
  zkProofHash: string
}

export interface AppState {
  connected: boolean
  account: string
  voter: Voter | null
  proposals: Proposal[]
  connectWallet: () => void
  disconnectWallet: () => void
  addProposal: (p: Proposal) => void
  registerVoter: () => void
}

const AppContext = createContext<AppState | null>(null)

export function AppProvider({ children }: { children: ReactNode }) {
  const [connected, setConnected] = useState(false)
  const [account, setAccount] = useState('')
  const [voter, setVoter] = useState<Voter | null>(null)
  const [proposals, setProposals] = useState<Proposal[]>([
    {
      id: '1',
      title: 'Protocol Fee Adjustment',
      description: 'Adjust swap fees from 0.3% to 0.25% to increase competitiveness.',
      options: ['For', 'Against', 'Abstain'],
      createdAt: Date.now() - 86400000,
      endsAt: Date.now() + 172800000,
      status: 'active',
      encryptedTally: '',
      totalVotes: 0,
      zkProofHash: ''
    },
    {
      id: '2',
      title: 'Treasury Diversification',
      description: 'Allocate 15% of treasury to stablecoin holdings for risk mitigation.',
      options: ['Approve', 'Reject'],
      createdAt: Date.now() - 172800000,
      endsAt: Date.now() - 86400000,
      status: 'closed',
      encryptedTally: '0x7f3a...b2c1',
      totalVotes: 847,
      zkProofHash: '0xabc123...def456'
    }
  ])

  const connectWallet = () => {
    const addr = '0x' + Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join('')
    setConnected(true)
    setAccount(addr)
    setVoter({
      address: addr,
      tokenBalance: 1250,
      nftIds: ['0x001', '0x002'],
      isRegistered: false,
      delegatedTo: null,
      delegatedFrom: []
    })
  }

  const disconnectWallet = () => {
    setConnected(false)
    setAccount('')
    setVoter(null)
  }

  const addProposal = (p: Proposal) => setProposals(prev => [p, ...prev])

  const registerVoter = () => {
    if (voter) setVoter({ ...voter, isRegistered: true })
  }

  return (
    <AppContext.Provider value={{ connected, account, voter, proposals, connectWallet, disconnectWallet, addProposal, registerVoter }}>
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be inside AppProvider')
  return ctx
}
