export interface KeyPair {
  publicKey: bigint;
  privateKey: bigint;
}

export interface SerializedKeyPair {
  publicKey: string;
  privateKey: string;
}

const PRIME = BigInt(
  "0xFFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3BE39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF6955817183995497CEA956AE515D2261898FA051015728E5A8AACAA68FFFFFFFFFFFFFFFF"
);

const GENERATOR = BigInt(2);

function modPow(base: bigint, exp: bigint, mod: bigint): bigint {
  let result = BigInt(1);
  base = base % mod;
  while (exp > BigInt(0)) {
    if (exp % BigInt(2) === BigInt(1)) {
      result = (result * base) % mod;
    }
    exp = exp >> BigInt(1);
    base = (base * base) % mod;
  }
  return result;
}

export function generateKeyPair(): KeyPair {
  const privateKey =
    BigInt(
      "0x" +
        Array.from(crypto.getRandomValues(new Uint8Array(32)))
          .map((b) => b.toString(16).padStart(2, "0"))
          .join("")
    ) % (PRIME - BigInt(1));
  const publicKey = modPow(GENERATOR, privateKey, PRIME);
  return { publicKey, privateKey };
}

export function serializeKeyPair(kp: KeyPair): SerializedKeyPair {
  return {
    publicKey: kp.publicKey.toString(16),
    privateKey: kp.privateKey.toString(16),
  };
}

export function deserializeKeyPair(skp: SerializedKeyPair): KeyPair {
  return {
    publicKey: BigInt("0x" + skp.publicKey),
    privateKey: BigInt("0x" + skp.privateKey),
  };
}

export { PRIME, GENERATOR, modPow };
