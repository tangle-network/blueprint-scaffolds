import { type ElGamalCiphertext, homomorphicAdd, decrypt } from "./encryption";
import { type KeyPair } from "./keys";

export interface TallyResult {
  optionIndex: number;
  label: string;
  count: number;
  percentage: number;
}

export function tallyVotes(
  encryptedBallots: ElGamalCiphertext[],
  options: string[],
  privateKey: bigint
): TallyResult[] {
  if (encryptedBallots.length === 0) {
    return options.map((label, i) => ({
      optionIndex: i,
      label,
      count: 0,
      percentage: 0,
    }));
  }

  const encryptedPerOption: ElGamalCiphertext[][] = options.map(() => []);

  for (const ballot of encryptedBallots) {
    const choice = decrypt(privateKey, ballot);
    const idx = Number(choice);
    if (idx >= 0 && idx < options.length) {
      encryptedPerOption[idx].push(ballot);
    }
  }

  const homomorphicTallies: ElGamalCiphertext[] = [];
  for (const optionBallots of encryptedPerOption) {
    if (optionBallots.length === 0) {
      homomorphicTallies.push({ c1: "1", c2: "1" });
    } else {
      let tally = optionBallots[0];
      for (let i = 1; i < optionBallots.length; i++) {
        tally = homomorphicAdd(tally, optionBallots[i]);
      }
      homomorphicTallies.push(tally);
    }
  }

  const counts = homomorphicTallies.map((tally) => {
    if (tally.c1 === "1" && tally.c2 === "1") return 0;
    return Number(decrypt(privateKey, tally));
  });

  const totalVotes = counts.reduce((a, b) => a + b, 0);

  return options.map((label, i) => ({
    optionIndex: i,
    label,
    count: counts[i],
    percentage: totalVotes > 0 ? Math.round((counts[i] / totalVotes) * 10000) / 100 : 0,
  }));
}

export function generateSP1Proof(
  tallyResults: TallyResult[],
  proposalId: string
): string {
  const data = JSON.stringify(tallyResults) + proposalId;
  let hash = BigInt(0);
  for (let i = 0; i < data.length; i++) {
    const char = BigInt(data.charCodeAt(i));
    hash = ((hash << BigInt(5)) - hash + char) & BigInt("0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF");
  }
  return "sp1_proof_" + hash.toString(16).padStart(64, "0");
}

export function verifySP1Proof(
  proof: string,
  tallyResults: TallyResult[],
  proposalId: string
): boolean {
  const expectedProof = generateSP1Proof(tallyResults, proposalId);
  return proof === expectedProof;
}
