export interface ZKEligibilityProof {
  proofId: string;
  merkleRoot: string;
  nullifier: string;
  proofBytes: string;
  verified: boolean;
  timestamp: number;
}

export interface EligibilityCriteria {
  type: "token" | "nft";
  contractAddress: string;
  minBalance?: number;
  tokenId?: number;
}

export function generateEligibilityProof(
  userId: string,
  criteria: EligibilityCriteria
): ZKEligibilityProof {
  const proofId = generateHash(userId + criteria.contractAddress + Date.now().toString());
  const nullifier = generateHash(userId + "nullifier" + criteria.contractAddress);
  const merkleRoot = generateHash(
    "merkle_root_" + criteria.contractAddress + criteria.type
  );
  const proofBytes = generateHash(
    proofId + nullifier + merkleRoot + "zk_snark_proof"
  );

  return {
    proofId,
    merkleRoot,
    nullifier,
    proofBytes,
    verified: true,
    timestamp: Date.now(),
  };
}

export function verifyEligibilityProof(proof: ZKEligibilityProof): boolean {
  if (!proof.proofId || !proof.nullifier || !proof.merkleRoot) {
    return false;
  }
  const age = Date.now() - proof.timestamp;
  if (age > 3600000) {
    return false;
  }
  return proof.verified;
}

export function checkNullifierUsed(
  nullifier: string,
  usedNullifiers: string[]
): boolean {
  return usedNullifiers.includes(nullifier);
}

function generateHash(input: string): string {
  let hash = BigInt(0);
  for (let i = 0; i < input.length; i++) {
    const char = BigInt(input.charCodeAt(i));
    hash = ((hash << BigInt(5)) - hash + char) & BigInt("0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF");
  }
  return hash.toString(16).padStart(64, "0");
}
