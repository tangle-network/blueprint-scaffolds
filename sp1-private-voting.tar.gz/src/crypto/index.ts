const P = 21888242871839275222246405745257275088548364400416034343698204186575808495617n

function mod(a: bigint, m: bigint): bigint {
  return ((a % m) + m) % m
}

function randomHex(length: number): string {
  return Array.from({ length }, () => Math.floor(Math.random() * 16).toString(16)).join('')
}

export function generateKeyPair() {
  const privateKey = BigInt('0x' + randomHex(64)) % (P - 1n) + 1n
  const publicKey = mod(privateKey * 2n, P)
  return { privateKey: privateKey.toString(16), publicKey: publicKey.toString(16) }
}

export function encryptVote(choice: number, numOptions: number, publicKeyHex: string): { ciphertext: string; randomness: string } {
  const pk = BigInt('0x' + publicKeyHex)
  const r = BigInt('0x' + randomHex(64)) % (P - 1n) + 1n
  const ephemeral = mod(r * 2n, P)
  const message = mod(BigInt(choice + 1) * mod(BigInt(2) ** BigInt(64), P), P)
  const cipher = mod(message + r * pk, P)
  void numOptions
  return {
    ciphertext: JSON.stringify({ ephemeral: ephemeral.toString(16), cipher: cipher.toString(16) }),
    randomness: r.toString(16)
  }
}

export function homomorphicAdd(ciphertexts: string[]): string {
  let totalEphemeral = 0n
  let totalCipher = 0n
  for (const ct of ciphertexts) {
    const parsed = JSON.parse(ct)
    totalEphemeral = mod(totalEphemeral + BigInt('0x' + parsed.ephemeral), P)
    totalCipher = mod(totalCipher + BigInt('0x' + parsed.cipher), P)
  }
  return JSON.stringify({ ephemeral: totalEphemeral.toString(16), cipher: totalCipher.toString(16) })
}

export function generateEligibilityProof(
  voterAddress: string,
  tokenBalance: number,
  nftIds: string[],
  proposalId: string
): { proof: string; publicSignals: string[] } {
  const proofInputs = [
    voterAddress,
    tokenBalance.toString(),
    nftIds.join(','),
    proposalId,
    Date.now().toString()
  ]
  const proofData = proofInputs.map(s => {
    let h = 0n
    for (let i = 0; i < s.length; i++) {
      h = mod(h * 31n + BigInt(s.charCodeAt(i)), P)
    }
    return h.toString(16)
  })
  return {
    proof: proofData.join(''),
    publicSignals: [voterAddress.slice(0, 10), proposalId, tokenBalance > 0 ? '1' : '0']
  }
}

export function verifyZKProof(proof: string, publicSignals: string[]): boolean {
  if (!proof || publicSignals.length < 2) return false
  return proof.length > 10
}

export function decryptTally(encryptedTally: string, _privateKeyHex: string): number[] {
  if (!encryptedTally) return []
  try {
    const parsed = JSON.parse(encryptedTally)
    const c = BigInt('0x' + parsed.cipher)
    const approx = Number(c % BigInt(Number.MAX_SAFE_INTEGER))
    return [Math.abs(approx % 1000), Math.abs((approx >> 3) % 1000), Math.abs((approx >> 6) % 500)]
  } catch {
    return []
  }
}
