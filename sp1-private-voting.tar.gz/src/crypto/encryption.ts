import { PRIME, GENERATOR, modPow, type KeyPair } from "./keys";

export interface ElGamalCiphertext {
  c1: string;
  c2: string;
}

export function encrypt(publicKey: bigint, message: bigint): ElGamalCiphertext {
  const r =
    BigInt(
      "0x" +
        Array.from(crypto.getRandomValues(new Uint8Array(32)))
          .map((b) => b.toString(16).padStart(2, "0"))
          .join("")
    ) % (PRIME - BigInt(1));
  const c1 = modPow(GENERATOR, r, PRIME);
  const s = modPow(publicKey, r, PRIME);
  const c2 = (modPow(GENERATOR, message, PRIME) * s) % PRIME;
  return { c1: c1.toString(16), c2: c2.toString(16) };
}

export function decrypt(privateKey: bigint, ciphertext: ElGamalCiphertext): bigint {
  const c1 = BigInt("0x" + ciphertext.c1);
  const c2 = BigInt("0x" + ciphertext.c2);
  const s = modPow(c1, privateKey, PRIME);
  const sInv = modPow(s, PRIME - BigInt(2), PRIME);
  const m_encoded = (c2 * sInv) % PRIME;
  let guess = BigInt(0);
  while (guess < BigInt(1000)) {
    if (modPow(GENERATOR, guess, PRIME) === m_encoded) {
      return guess;
    }
    guess++;
  }
  return BigInt(-1);
}

export function encryptVote(publicKey: bigint, choice: number): ElGamalCiphertext {
  return encrypt(publicKey, BigInt(choice));
}

export function homomorphicAdd(
  a: ElGamalCiphertext,
  b: ElGamalCiphertext
): ElGamalCiphertext {
  const a1 = BigInt("0x" + a.c1);
  const a2 = BigInt("0x" + a.c2);
  const b1 = BigInt("0x" + b.c1);
  const b2 = BigInt("0x" + b.c2);
  return {
    c1: ((a1 * b1) % PRIME).toString(16),
    c2: ((a2 * b2) % PRIME).toString(16),
  };
}
