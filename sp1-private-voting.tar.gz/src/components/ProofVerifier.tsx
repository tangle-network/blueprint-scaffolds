import { useState } from 'react'
import { useApp } from '../context/AppContext'
import { verifyZKProof } from '../crypto'
import { CONTRACT_ADDRESSES } from '../contracts'

export function ProofVerifier({ onBack }: { onBack: () => void }) {
  const { proposals } = useApp()
  const [selectedProposalId, setSelectedProposalId] = useState('')
  const [customProof, setCustomProof] = useState('')
  const [customSignals, setCustomSignals] = useState('')
  const [verifying, setVerifying] = useState(false)
  const [result, setResult] = useState<{ valid: boolean; details: string } | null>(null)

  const handleVerify = () => {
    setVerifying(true)
    setTimeout(() => {
      const signals = customSignals ? customSignals.split(',').map(s => s.trim()) : ['0x1234', '1']
      const proof = customProof || proposals.find(p => p.id === selectedProposalId)?.zkProofHash || ''
      const valid = verifyZKProof(proof, signals)
      setResult({
        valid,
        details: valid
          ? 'SP1 proof verified successfully. The tally computation is correct and all eligibility checks passed.'
          : 'Proof verification failed. The proof may be invalid or malformed.'
      })
      setVerifying(false)
    }, 2000)
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-white">Verify Proofs</h2>
        <button onClick={onBack} className="text-gray-400 hover:text-white text-sm">&larr; Back</button>
      </div>

      <div className="glass p-6 space-y-4">
        <h3 className="font-semibold text-white">SP1 Proof Verification</h3>
        <p className="text-gray-400 text-sm">
          Verify zero-knowledge proofs for eligibility and tally correctness. All verification is done against the ResultVerification contract.
        </p>

        <div>
          <label className="text-sm text-gray-400 block mb-1">Select Proposal</label>
          <select className="input-field" value={selectedProposalId} onChange={e => setSelectedProposalId(e.target.value)}>
            <option value="">-- Select --</option>
            {proposals.map(p => (
              <option key={p.id} value={p.id}>{p.title}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="text-sm text-gray-400 block mb-1">Proof (hex)</label>
          <textarea className="input-field font-mono text-xs min-h-[80px]" value={customProof} onChange={e => setCustomProof(e.target.value)} placeholder="0x... (leave empty to use proposal proof)" />
        </div>

        <div>
          <label className="text-sm text-gray-400 block mb-1">Public Signals (comma-separated)</label>
          <input className="input-field font-mono text-sm" value={customSignals} onChange={e => setCustomSignals(e.target.value)} placeholder="0x1234, 1, proposal_id" />
        </div>

        <div className="glass p-3 text-xs text-gray-500 space-y-1">
          <div><strong>Contract:</strong> ResultVerification</div>
          <div><strong>Address:</strong> <span className="font-mono text-accent">{CONTRACT_ADDRESSES.resultVerification}</span></div>
          <div><strong>Verifier:</strong> SP1 Groth16 / PLONK</div>
        </div>

        <button onClick={handleVerify} disabled={verifying || (!selectedProposalId && !customProof)} className="btn-primary w-full">
          {verifying ? 'Verifying Proof...' : 'Verify Proof'}
        </button>
      </div>

      {result && (
        <div className={`glass p-6 ${result.valid ? 'border-green-600/50' : 'border-red-600/50'}`}>
          <div className="flex items-center gap-3">
            <span className="text-3xl">{result.valid ? '&#9989;' : '&#10060;'}</span>
            <div>
              <h3 className={`font-bold ${result.valid ? 'text-green-400' : 'text-red-400'}`}>
                {result.valid ? 'Proof Valid' : 'Proof Invalid'}
              </h3>
              <p className="text-gray-400 text-sm mt-1">{result.details}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
