import { useState } from 'react'
import { useApp } from '../context/AppContext'
import { generateKeyPair, encryptVote, generateEligibilityProof } from '../crypto'

export function VotingBooth({ onBack }: { onBack: () => void }) {
  const { connected, voter, proposals } = useApp()
  const [selectedProposal, setSelectedProposal] = useState<string | null>(null)
  const [selectedOption, setSelectedOption] = useState<number | null>(null)
  const [step, setStep] = useState<'select' | 'prove' | 'encrypt' | 'submit' | 'done'>('select')
  const [proofData, setProofData] = useState<{ proof: string; publicSignals: string[] } | null>(null)
  const [ciphertext, setCiphertext] = useState<string>('')
  const [generating, setGenerating] = useState(false)

  const activeProposals = proposals.filter(p => p.status === 'active')
  const proposal = proposals.find(p => p.id === selectedProposal)

  if (!connected) {
    return (
      <div className="text-center py-20 text-gray-400">
        Connect your wallet to vote.
        <button onClick={onBack} className="block mx-auto mt-4 text-accent hover:underline">Back</button>
      </div>
    )
  }

  const handleProve = () => {
    if (!voter || !proposal) return
    setGenerating(true)
    setStep('prove')
    setTimeout(() => {
      const proof = generateEligibilityProof(voter.address, voter.tokenBalance, voter.nftIds, proposal.id)
      setProofData(proof)
      setGenerating(false)
      setStep('encrypt')
    }, 2000)
  }

  const handleEncrypt = () => {
    if (!proposal || selectedOption === null) return
    setGenerating(true)
    setTimeout(() => {
      const kp = generateKeyPair()
      const enc = encryptVote(selectedOption, proposal.options.length, kp.publicKey)
      setCiphertext(enc.ciphertext)
      setGenerating(false)
      setStep('submit')
    }, 1500)
  }

  const handleSubmit = () => {
    setGenerating(true)
    setTimeout(() => {
      setGenerating(false)
      setStep('done')
    }, 2000)
  }

  if (step === 'done') {
    return (
      <div className="glass p-8 text-center max-w-lg mx-auto">
        <div className="text-4xl mb-4">&#128718;</div>
        <h2 className="text-xl font-bold text-white">Vote Submitted</h2>
        <p className="text-gray-400 text-sm mt-2">Your encrypted ballot has been submitted. Your vote choice remains private.</p>
        <div className="glass p-3 mt-4 text-left text-xs font-mono text-gray-500 break-all">
          <div><strong>Ballot Hash:</strong> 0x{Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}</div>
          <div className="mt-1"><strong>Proof:</strong> {proofData?.proof.slice(0, 32)}...</div>
        </div>
        <button onClick={onBack} className="btn-primary mt-6">Back to Dashboard</button>
      </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-white">Private Voting Booth</h2>
        <button onClick={onBack} className="text-gray-400 hover:text-white text-sm">&larr; Back</button>
      </div>

      <div className="flex gap-2 text-xs">
        {['Select', 'Prove', 'Encrypt', 'Submit'].map((s, i) => {
          const stepOrder = ['select', 'prove', 'encrypt', 'submit']
          const activeIdx = stepOrder.indexOf(step)
          return (
            <div key={s} className={`flex-1 py-2 text-center rounded ${i <= activeIdx ? 'bg-accent text-white' : 'bg-dark-700 text-gray-500'}`}>
              {s}
            </div>
          )
        })}
      </div>

      {step === 'select' && (
        <div className="glass p-6 space-y-4">
          <h3 className="font-semibold text-white">Select a Proposal</h3>
          {activeProposals.map(p => (
            <div key={p.id} onClick={() => { setSelectedProposal(p.id); setStep('prove') }} className={`glass p-4 cursor-pointer hover:border-accent/50 transition ${selectedProposal === p.id ? 'border-accent' : ''}`}>
              <div className="font-semibold text-white">{p.title}</div>
              <div className="text-gray-400 text-sm mt-1">{p.description}</div>
              <div className="flex gap-2 mt-2">
                {p.options.map((o, i) => (
                  <span key={i} className="text-xs bg-dark-600 px-2 py-0.5 rounded">{o}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {step === 'prove' && proposal && (
        <div className="glass p-6 space-y-4">
          <h3 className="font-semibold text-white">Step 1: Generate ZK Eligibility Proof</h3>
          <p className="text-gray-400 text-sm">Prove you hold the required tokens/NFTs without revealing your identity or balance.</p>

          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="glass p-3">
              <div className="text-gray-500 text-xs">Token Balance</div>
              <div className="text-white">{voter?.tokenBalance} GOV</div>
            </div>
            <div className="glass p-3">
              <div className="text-gray-500 text-xs">NFTs Held</div>
              <div className="text-white">{voter?.nftIds.length ?? 0}</div>
            </div>
          </div>

          <div className="glass p-3 text-xs text-gray-500">
            <div>SP1 Program: <span className="text-accent">eligibility_verifier</span></div>
            <div>Inputs: address hash, token_balance &gt; 0, nft_count &gt; 0</div>
            <div>Output: membership proof (no balance revealed)</div>
          </div>

          <button onClick={handleProve} disabled={generating} className="btn-primary w-full">
            {generating ? 'Generating SP1 Proof...' : 'Generate ZK Proof'}
          </button>
        </div>
      )}

      {step === 'encrypt' && proposal && proofData && (
        <div className="glass p-6 space-y-4">
          <h3 className="font-semibold text-white">Step 2: Encrypt Your Vote</h3>

          <div className="glass p-3 text-xs font-mono text-green-400 break-all mb-3">
            Proof generated: {proofData.proof.slice(0, 40)}...
            <br />Signals: [{proofData.publicSignals.join(', ')}]
          </div>

          <p className="text-gray-400 text-sm">Select your choice. It will be encrypted using ElGamal before submission.</p>
          <div className="space-y-2">
            {proposal.options.map((opt, i) => (
              <button key={i} onClick={() => setSelectedOption(i)} className={`w-full text-left glass p-3 transition ${selectedOption === i ? 'border-accent bg-accent/10' : 'hover:border-accent/30'}`}>
                <span className="text-white">{opt}</span>
              </button>
            ))}
          </div>

          <button onClick={handleEncrypt} disabled={generating || selectedOption === null} className="btn-primary w-full">
            {generating ? 'Encrypting Ballot...' : 'Encrypt Vote'}
          </button>
        </div>
      )}

      {step === 'submit' && proposal && ciphertext && (
        <div className="glass p-6 space-y-4">
          <h3 className="font-semibold text-white">Step 3: Submit Encrypted Ballot</h3>

          <div className="glass p-3 text-xs text-gray-500 space-y-1">
            <div><strong>Proposal:</strong> {proposal.title}</div>
            <div><strong>Your Choice:</strong> (encrypted)</div>
            <div><strong>Ciphertext:</strong> <span className="break-all">{ciphertext.slice(0, 80)}...</span></div>
          </div>

          <p className="text-gray-400 text-sm">
            Your encrypted ballot will be submitted to the BallotSubmission contract. The homomorphic tally will count your vote without revealing your choice.
          </p>

          <button onClick={handleSubmit} disabled={generating} className="btn-primary w-full">
            {generating ? 'Submitting to Chain...' : 'Submit Ballot'}
          </button>
        </div>
      )}
    </div>
  )
}
