import { useState } from 'react'
import { useApp } from '../context/AppContext'

export function ProposalCreation({ onBack }: { onBack: () => void }) {
  const { addProposal } = useApp()
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [options, setOptions] = useState(['For', 'Against', 'Abstain'])
  const [duration, setDuration] = useState('72')
  const [submitting, setSubmitting] = useState(false)
  const [created, setCreated] = useState(false)

  const addOption = () => setOptions(prev => [...prev, ''])
  const removeOption = (idx: number) => setOptions(prev => prev.filter((_, i) => i !== idx))
  const updateOption = (idx: number, val: string) => setOptions(prev => prev.map((o, i) => i === idx ? val : o))

  const handleSubmit = () => {
    if (!title || options.some(o => !o.trim())) return
    setSubmitting(true)
    setTimeout(() => {
      addProposal({
        id: Date.now().toString(),
        title,
        description,
        options: options.filter(o => o.trim()),
        createdAt: Date.now(),
        endsAt: Date.now() + parseInt(duration) * 3600000,
        status: 'active',
        encryptedTally: '',
        totalVotes: 0,
        zkProofHash: ''
      })
      setSubmitting(false)
      setCreated(true)
    }, 1500)
  }

  if (created) {
    return (
      <div className="glass p-8 text-center max-w-lg mx-auto">
        <div className="text-4xl mb-4">&#9989;</div>
        <h2 className="text-xl font-bold text-white">Proposal Created</h2>
        <p className="text-gray-400 text-sm mt-2">Your proposal has been submitted to the voting registry contract and is now active.</p>
        <button onClick={onBack} className="btn-primary mt-6">Back to Dashboard</button>
      </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-white">Create Proposal</h2>
        <button onClick={onBack} className="text-gray-400 hover:text-white text-sm">&larr; Back</button>
      </div>

      <div className="glass p-6 space-y-5">
        <div>
          <label className="text-sm text-gray-400 block mb-1">Title</label>
          <input className="input-field" value={title} onChange={e => setTitle(e.target.value)} placeholder="Protocol Fee Adjustment" />
        </div>

        <div>
          <label className="text-sm text-gray-400 block mb-1">Description</label>
          <textarea className="input-field min-h-[100px]" value={description} onChange={e => setDescription(e.target.value)} placeholder="Describe the proposal..." />
        </div>

        <div>
          <label className="text-sm text-gray-400 block mb-1">Voting Options</label>
          <div className="space-y-2">
            {options.map((opt, i) => (
              <div key={i} className="flex gap-2">
                <input className="input-field flex-1" value={opt} onChange={e => updateOption(i, e.target.value)} placeholder={`Option ${i + 1}`} />
                {options.length > 2 && (
                  <button onClick={() => removeOption(i)} className="text-danger text-sm px-2 hover:underline">Remove</button>
                )}
              </div>
            ))}
          </div>
          <button onClick={addOption} className="text-accent text-sm mt-2 hover:underline">+ Add Option</button>
        </div>

        <div>
          <label className="text-sm text-gray-400 block mb-1">Duration (hours)</label>
          <select className="input-field" value={duration} onChange={e => setDuration(e.target.value)}>
            <option value="24">24 hours</option>
            <option value="48">48 hours</option>
            <option value="72">72 hours</option>
            <option value="168">1 week</option>
          </select>
        </div>

        <div className="pt-2">
          <button onClick={handleSubmit} disabled={submitting || !title || options.some(o => !o.trim())} className="btn-primary w-full">
            {submitting ? 'Submitting to Registry...' : 'Create Proposal'}
          </button>
        </div>
      </div>
    </div>
  )
}
