import { useState } from 'react'
import { useApp } from '../context/AppContext'

export function DelegationPanel({ onBack }: { onBack: () => void }) {
  const { connected, voter } = useApp()
  const [delegateAddress, setDelegateAddress] = useState('')
  const [delegations] = useState([
    { to: '0xabc1...def2', proposal: 'Protocol Fee Adjustment', active: true },
    { to: '0x7890...1234', proposal: 'Treasury Diversification', active: false }
  ])
  const [submitting, setSubmitting] = useState(false)
  const [delegated, setDelegated] = useState(false)

  if (!connected) {
    return (
      <div className="text-center py-20 text-gray-400">
        Connect your wallet to manage delegations.
        <button onClick={onBack} className="block mx-auto mt-4 text-accent hover:underline">Back</button>
      </div>
    )
  }

  const handleDelegate = () => {
    if (!delegateAddress.trim()) return
    setSubmitting(true)
    setTimeout(() => {
      setSubmitting(false)
      setDelegated(true)
    }, 1500)
  }

  if (delegated) {
    return (
      <div className="glass p-8 text-center max-w-lg mx-auto">
        <div className="text-4xl mb-4">&#129309;</div>
        <h2 className="text-xl font-bold text-white">Vote Delegated</h2>
        <p className="text-gray-400 text-sm mt-2">Your voting power has been delegated. You can revoke at any time.</p>
        <button onClick={onBack} className="btn-primary mt-6">Back to Dashboard</button>
      </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-white">Vote Delegation</h2>
        <button onClick={onBack} className="text-gray-400 hover:text-white text-sm">&larr; Back</button>
      </div>

      <div className="glass p-6 space-y-4">
        <h3 className="font-semibold text-white">Delegate Voting Power</h3>
        <p className="text-gray-400 text-sm">
          Delegate your vote to a trusted representative. Your tokens/NFTs still belong to you, but the delegate can vote on your behalf.
        </p>

        <div className="grid grid-cols-2 gap-3 text-sm">
          <div className="glass p-3">
            <div className="text-gray-500 text-xs">Your Voting Power</div>
            <div className="text-white">{voter?.tokenBalance ?? 0} GOV</div>
          </div>
          <div className="glass p-3">
            <div className="text-gray-500 text-xs">Delegated To</div>
            <div className="text-white">{voter?.delegatedTo ?? 'None'}</div>
          </div>
        </div>

        <div>
          <label className="text-sm text-gray-400 block mb-1">Delegate Address</label>
          <input className="input-field font-mono text-sm" value={delegateAddress} onChange={e => setDelegateAddress(e.target.value)} placeholder="0x..." />
        </div>

        <button onClick={handleDelegate} disabled={submitting || !delegateAddress.trim()} className="btn-primary w-full">
          {submitting ? 'Delegating...' : 'Delegate Vote'}
        </button>
      </div>

      <div className="glass p-6">
        <h3 className="font-semibold text-white mb-3">Delegation History</h3>
        <div className="space-y-2">
          {delegations.map((d, i) => (
            <div key={i} className="flex items-center justify-between glass p-3">
              <div>
                <div className="text-sm text-white font-mono">{d.to}</div>
                <div className="text-xs text-gray-500">{d.proposal}</div>
              </div>
              <div className="flex items-center gap-2">
                <span className={`text-xs px-2 py-0.5 rounded-full ${d.active ? 'bg-green-900/40 text-green-400' : 'bg-gray-700 text-gray-400'}`}>
                  {d.active ? 'Active' : 'Revoked'}
                </span>
                {d.active && <button className="text-xs text-danger hover:underline">Revoke</button>}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
