import { useApp } from '../context/AppContext'

export function Dashboard({ onNavigate }: { onNavigate: (v: any) => void }) {
  const { connected, voter, proposals } = useApp()

  const activeCount = proposals.filter(p => p.status === 'active').length
  const closedCount = proposals.filter(p => p.status === 'closed').length

  if (!connected) {
    return (
      <div className="flex flex-col items-center justify-center py-32 gap-6">
        <div className="text-6xl">&#128718;</div>
        <h2 className="text-3xl font-bold text-white">SP1 Private Voting</h2>
        <p className="text-gray-400 max-w-md text-center">
          Zero-knowledge governance with encrypted ballots, homomorphic tallying, and verifiable on-chain results powered by Succinct SP1.
        </p>
        <div className="glass p-6 max-w-lg w-full mt-4 space-y-3 text-sm text-gray-300">
          <div className="flex items-center gap-3"><span className="text-accent text-lg">&#128274;</span> Encrypted ballots via ElGamal</div>
          <div className="flex items-center gap-3"><span className="text-accent text-lg">&#128270;</span> ZK eligibility proofs (ERC-20 / ERC-721)</div>
          <div className="flex items-center gap-3"><span className="text-accent text-lg">&#128202;</span> Homomorphic vote tallying</div>
          <div className="flex items-center gap-3"><span className="text-accent text-lg">&#9989;</span> SP1 verifiable counting</div>
        </div>
        <p className="text-gray-500 text-sm mt-2">Connect your wallet to get started.</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard label="Token Balance" value={`${voter?.tokenBalance ?? 0} GOV`} />
        <StatCard label="NFTs Held" value={`${voter?.nftIds.length ?? 0}`} />
        <StatCard label="Active Proposals" value={`${activeCount}`} />
        <StatCard label="Completed" value={`${closedCount}`} />
      </div>

      {voter && !voter.isRegistered && (
        <div className="glass p-4 border-yellow-600/50 flex items-center justify-between">
          <span className="text-yellow-400 text-sm">You are not registered to vote. Register to participate in governance.</span>
          <button className="btn-primary text-sm" onClick={() => onNavigate('dashboard')}>Register Now</button>
        </div>
      )}

      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-white">Proposals</h2>
        <button onClick={() => onNavigate('create')} className="btn-primary text-sm">+ New Proposal</button>
      </div>

      <div className="space-y-3">
        {proposals.map(p => (
          <div key={p.id} className="glass p-5 hover:border-accent/50 transition cursor-pointer" onClick={() => onNavigate(p.status === 'active' ? 'vote' : 'results')}>
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-semibold text-white">{p.title}</h3>
                <p className="text-gray-400 text-sm mt-1">{p.description}</p>
                <div className="flex gap-2 mt-3">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${p.status === 'active' ? 'bg-green-900/40 text-green-400' : 'bg-gray-700 text-gray-400'}`}>
                    {p.status}
                  </span>
                  <span className="text-xs text-gray-500">{p.options.length} options</span>
                  {p.totalVotes > 0 && <span className="text-xs text-gray-500">{p.totalVotes} votes</span>}
                </div>
              </div>
              <span className="text-accent text-xl">&rarr;</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function StatCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="glass p-4">
      <div className="text-xs text-gray-500 uppercase tracking-wider">{label}</div>
      <div className="text-xl font-bold text-white mt-1">{value}</div>
    </div>
  )
}
