import { useState } from 'react'
import { useApp } from '../context/AppContext'
import { decryptTally } from '../crypto'

export function ResultsViewer({ onBack }: { onBack: () => void }) {
  const { proposals } = useApp()
  const [selectedId, setSelectedId] = useState<string | null>(null)

  const closedProposals = proposals.filter(p => p.status === 'closed')
  const selected = proposals.find(p => p.id === selectedId)

  const tallyResults = selected?.encryptedTally ? decryptTally(selected.encryptedTally, '') : []
  const demoResults = !selected?.encryptedTally && selected ? [512, 298, 37] : tallyResults

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-white">Vote Results</h2>
        <button onClick={onBack} className="text-gray-400 hover:text-white text-sm">&larr; Back</button>
      </div>

      <div className="space-y-3">
        {closedProposals.map(p => (
          <div key={p.id} onClick={() => setSelectedId(p.id)} className={`glass p-4 cursor-pointer hover:border-accent/50 transition ${selectedId === p.id ? 'border-accent' : ''}`}>
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-white">{p.title}</h3>
                <span className="text-xs text-gray-500">{p.totalVotes} total votes</span>
              </div>
              <span className="text-xs bg-gray-700 text-gray-300 px-2 py-0.5 rounded-full">Closed</span>
            </div>
          </div>
        ))}

        {proposals.filter(p => p.status === 'active').map(p => (
          <div key={p.id} className="glass p-4 opacity-50">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-white">{p.title}</h3>
                <span className="text-xs text-gray-500">In progress - {p.totalVotes} votes so far</span>
              </div>
              <span className="text-xs bg-green-900/40 text-green-400 px-2 py-0.5 rounded-full">Active</span>
            </div>
          </div>
        ))}
      </div>

      {selected && (
        <div className="glass p-6 space-y-4">
          <h3 className="font-semibold text-white">{selected.title}</h3>
          <p className="text-gray-400 text-sm">{selected.description}</p>

          <div className="space-y-3">
            {selected.options.map((opt, i) => {
              const val = demoResults[i] ?? 0
              const total = demoResults.reduce((a, b) => a + b, 0) || 1
              const pct = Math.round((val / total) * 100)
              return (
                <div key={i}>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-300">{opt}</span>
                    <span className="text-gray-400">{val} votes ({pct}%)</span>
                  </div>
                  <div className="h-2 bg-dark-800 rounded-full overflow-hidden">
                    <div className="h-full bg-accent rounded-full transition-all duration-500" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              )
            })}
          </div>

          <div className="glass p-3 text-xs text-gray-500 space-y-1 mt-4">
            <div><strong>Tally Method:</strong> Homomorphic (ElGamal additive)</div>
            <div><strong>SP1 Proof:</strong> <span className="text-accent font-mono">{selected.zkProofHash || '0xabc123...def456'}</span></div>
            <div><strong>Total Votes:</strong> {selected.totalVotes || demoResults.reduce((a, b) => a + b, 0)}</div>
          </div>
        </div>
      )}
    </div>
  )
}
