import { useApp } from '../context/AppContext'

const NAV_ITEMS = [
  { id: 'dashboard' as const, label: 'Dashboard' },
  { id: 'create' as const, label: 'Create Proposal' },
  { id: 'vote' as const, label: 'Vote' },
  { id: 'delegate' as const, label: 'Delegate' },
  { id: 'results' as const, label: 'Results' },
  { id: 'verify' as const, label: 'Verify' }
]

export function Navbar({ currentView, onNavigate }: { currentView: string; onNavigate: (v: any) => void }) {
  const { connected, account, connectWallet, disconnectWallet, voter, registerVoter } = useApp()

  return (
    <nav className="glass border-b border-dark-600 px-6 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-6">
          <h1 className="text-xl font-bold text-accent">SP1 Vote</h1>
          <div className="hidden md:flex items-center gap-1">
            {NAV_ITEMS.map(item => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`px-3 py-1.5 rounded-lg text-sm transition ${
                  currentView === item.id ? 'bg-accent text-white' : 'text-gray-400 hover:text-white'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
        <div className="flex items-center gap-3">
          {connected ? (
            <>
              {!voter?.isRegistered && (
                <button onClick={registerVoter} className="btn-outline text-sm py-1 px-3">
                  Register
                </button>
              )}
              {voter?.isRegistered && (
                <span className="text-xs text-success">&#10003; Registered</span>
              )}
              <span className="text-xs text-gray-400 font-mono">{account.slice(0, 6)}...{account.slice(-4)}</span>
              <button onClick={disconnectWallet} className="text-xs text-danger hover:underline">
                Disconnect
              </button>
            </>
          ) : (
            <button onClick={connectWallet} className="btn-primary text-sm py-1.5">
              Connect Wallet
            </button>
          )}
        </div>
      </div>
    </nav>
  )
}
