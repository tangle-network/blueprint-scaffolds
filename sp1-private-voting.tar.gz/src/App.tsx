import { useState } from "react";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";

interface Proposal {
  id: number;
  title: string;
  description: string;
  status: "active" | "closed" | "pending";
  createdAt: string;
  endTime: string;
  forVotes: number;
  againstVotes: number;
  totalEligible: number;
  encryptionPubKey: string;
}

interface Voter {
  address: string;
  isEligible: boolean;
  hasVoted: boolean;
  delegatedTo: string | null;
  tokenBalance: number;
  nftHoldings: number;
}

interface VoteRecord {
  proposalId: number;
  encryptedBallot: string;
  zkProofHash: string;
  timestamp: string;
}

interface Delegation {
  from: string;
  to: string;
  scope: "all" | "protocol-specific";
  expiresAt: string;
}

const INITIAL_PROPOSALS: Proposal[] = [
  {
    id: 1,
    title: "SP1 Prover Network Fee Reduction",
    description:
      "Reduce verifier fees from 0.005 ETH to 0.003 ETH per proof. This proposal adjusts the prover network economics to reflect decreased operational costs following the v2.3 optimization cycle, making zero-knowledge proof verification more accessible for rollups and applications building on SP1.",
    status: "active",
    createdAt: "2026-03-01T10:00:00Z",
    endTime: "2026-04-15T23:59:59Z",
    forVotes: 124500,
    againstVotes: 67200,
    totalEligible: 450000,
    encryptionPubKey:
      "0x04b7a3c1d8e9f2a4b6c5d7e8f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6",
  },
  {
    id: 2,
    title: "zkVM Circuit Upgrade v2.4",
    description:
      "Migrate to RISC-V extended instruction set. Upgrades the SP1 zkVM circuit to support the full RISC-V extended ISA, enabling native execution of complex programs including cryptographic primitives and eliminating the need for hand-written assembly in guest programs.",
    status: "active",
    createdAt: "2026-03-10T08:00:00Z",
    endTime: "2026-04-20T23:59:59Z",
    forVotes: 89300,
    againstVotes: 23100,
    totalEligible: 450000,
    encryptionPubKey:
      "0x04e8f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e",
  },
  {
    id: 3,
    title: "Treasury Diversification",
    description:
      "Swap 50K SP1 for USDC via Uniswap V3. Diversify the protocol treasury to ensure operational runway and reduce exposure to native token volatility. The swap will be executed as a TWAP order over 7 days to minimize market impact.",
    status: "closed",
    createdAt: "2026-02-01T12:00:00Z",
    endTime: "2026-03-01T23:59:59Z",
    forVotes: 201300,
    againstVotes: 48700,
    totalEligible: 450000,
    encryptionPubKey:
      "0x04a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6",
  },
  {
    id: 4,
    title: "Governance Parameter Update",
    description:
      "Increase quorum from 4% to 7%. Adjust governance participation requirements to ensure that protocol changes reflect meaningful community consensus. The increased quorum threshold takes effect after a 30-day grace period following proposal passage.",
    status: "pending",
    createdAt: "2026-04-05T09:00:00Z",
    endTime: "2026-05-05T23:59:59Z",
    forVotes: 0,
    againstVotes: 0,
    totalEligible: 450000,
    encryptionPubKey:
      "0x04f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2",
  },
];

const INITIAL_VOTER: Voter = {
  address: "0x7a3B...4e2F",
  isEligible: true,
  hasVoted: false,
  delegatedTo: null,
  tokenBalance: 3250,
  nftHoldings: 2,
};

const INITIAL_DELEGATIONS: Delegation[] = [
  {
    from: "0x7a3B...4e2F",
    to: "0x8dE4...9aF2",
    scope: "all",
    expiresAt: "2026-06-01T00:00:00Z",
  },
  {
    from: "0x5c1A...7bD3",
    to: "0x7a3B...4e2F",
    scope: "protocol-specific",
    expiresAt: "2026-03-15T00:00:00Z",
  },
];

const RECENT_ACTIVITY = [
  {
    text: "0x3fA2...1bC4 submitted encrypted ballot on Proposal #1",
    time: "2 min ago",
  },
  {
    text: "Delegation: 0x8dE4...9aF2 → 0x7a3B...4e2F",
    time: "8 min ago",
  },
  {
    text: "0x2bE7...6cD1 verified tally for Proposal #3",
    time: "15 min ago",
  },
  {
    text: "ZK proof generated for 0x9aF3...2eB8 eligibility check",
    time: "22 min ago",
  },
  {
    text: "Proposal #4 created by 0x4dC6...1aE5",
    time: "1 hr ago",
  },
];

function StatusBadge({ status }: { status: Proposal["status"] }) {
  const variant =
    status === "active"
      ? "bg-green-500/20 text-green-400 border-green-500/30"
      : status === "closed"
        ? "bg-gray-500/20 text-gray-400 border-gray-500/30"
        : "bg-yellow-500/20 text-yellow-400 border-yellow-500/30";
  return (
    <span
      className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold ${variant}`}
    >
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
}

function formatNumber(n: number): string {
  return n.toLocaleString();
}

function getTimeRemaining(endTime: string): string {
  const end = new Date(endTime).getTime();
  const now = Date.now();
  const diff = end - now;
  if (diff <= 0) return "Ended";
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  if (days > 0) return `${days}d ${hours}h remaining`;
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  return `${hours}h ${minutes}m remaining`;
}

export default function App() {
  const [proposals] = useState<Proposal[]>(INITIAL_PROPOSALS);
  const [voter, setVoter] = useState<Voter>(INITIAL_VOTER);
  const [voteRecords, setVoteRecords] = useState<VoteRecord[]>([]);
  const [delegations] = useState<Delegation[]>(INITIAL_DELEGATIONS);

  const [selectedProposalId, setSelectedProposalId] = useState<string>("1");
  const [voteChoice, setVoteChoice] = useState<"for" | "against" | null>(null);
  const [zkProofEnabled, setZkProofEnabled] = useState(false);
  const [zkProofHash, setZkProofHash] = useState<string | null>(null);
  const [isVoting, setIsVoting] = useState(false);
  const [voteProgress, setVoteProgress] = useState(0);
  const [encryptedBallot, setEncryptedBallot] = useState<string | null>(null);

  const [delegateAddress, setDelegateAddress] = useState("");
  const [delegateScope, setDelegateScope] = useState<string>("all");
  const [allowRedelegation, setAllowRedelegation] = useState(false);

  const [verifyProposalId, setVerifyProposalId] = useState("");
  const [verifySteps, setVerifySteps] = useState<string[]>([]);
  const [isVerifying, setIsVerifying] = useState(false);
  const [verifiedResults, setVerifiedResults] = useState<{
    forVotes: number;
    againstVotes: number;
    proofHash: string;
  } | null>(null);

  const [newProposalTitle, setNewProposalTitle] = useState("");
  const [newProposalDescription, setNewProposalDescription] = useState("");

  const selectedProposal = proposals.find(
    (p) => p.id === parseInt(selectedProposalId)
  );

  function handleGenerateZkProof(enabled: boolean) {
    setZkProofEnabled(enabled);
    if (enabled) {
      setTimeout(() => {
        setZkProofHash(
          "0xab3c7d2e4f1a8b9c0d6e5f3a7b2c8d4e1f6a9b3c7d0e2f5a8b1c4d7e0f3a6b9"
        );
      }, 1200);
    } else {
      setZkProofHash(null);
    }
  }

  function handleSubmitVote() {
    if (!voteChoice || !zkProofHash) return;
    setIsVoting(true);
    setVoteProgress(0);

    const interval = setInterval(() => {
      setVoteProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          const ballot =
            "0x" +
            Array.from({ length: 64 }, () =>
              Math.floor(Math.random() * 16).toString(16)
            ).join("");
          setEncryptedBallot(ballot);
          setVoteRecords((prev) => [
            ...prev,
            {
              proposalId: parseInt(selectedProposalId),
              encryptedBallot: ballot,
              zkProofHash: zkProofHash,
              timestamp: new Date().toISOString(),
            },
          ]);
          setVoter((prev) => ({ ...prev, hasVoted: true }));
          setIsVoting(false);
          return 100;
        }
        return prev + 10;
      });
    }, 300);
  }

  function handleVerifyTally() {
    setIsVerifying(true);
    setVerifiedResults(null);
    const steps = [
      "Loading encrypted ballots from proposal #" + verifyProposalId + "...",
      "Running homomorphic decryption via SP1...",
      "Generating ZK proof of correct tally...",
      "Verification complete ✓",
    ];

    steps.forEach((step, i) => {
      setTimeout(() => {
        setVerifySteps((prev) => [...prev, step]);
        if (i === steps.length - 1) {
          const proposal = proposals.find(
            (p) => p.id === parseInt(verifyProposalId)
          );
          setVerifiedResults({
            forVotes: proposal?.forVotes ?? 0,
            againstVotes: proposal?.againstVotes ?? 0,
            proofHash:
              "0xzk" +
              Array.from({ length: 62 }, () =>
                Math.floor(Math.random() * 16).toString(16)
              ).join(""),
          });
          setIsVerifying(false);
        }
      }, (i + 1) * 1000);
    });
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border">
        <div className="container mx-auto flex items-center justify-between px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-bold text-sm">
              SP1
            </div>
            <h1 className="text-xl font-bold">SP1 Private Governance</h1>
          </div>
          <div className="flex items-center gap-4">
            <Badge variant="outline" className="font-mono text-xs">
              {voter.address}
            </Badge>
            <Badge
              variant="outline"
              className="text-xs"
            >
              {formatNumber(voter.tokenBalance)} SP1-GOV
            </Badge>
            <Badge
              variant="outline"
              className={
                voter.isEligible
                  ? "border-green-500/30 text-green-400"
                  : "border-red-500/30 text-red-400"
              }
            >
              {voter.isEligible ? "Eligible" : "Not Eligible"}
            </Badge>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <Tabs defaultValue="dashboard" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="proposals">Proposals</TabsTrigger>
            <TabsTrigger value="vote">Vote</TabsTrigger>
            <TabsTrigger value="delegation">Delegation</TabsTrigger>
            <TabsTrigger value="verification">Verification</TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Total Proposals</CardDescription>
                  <CardTitle className="text-3xl">
                    {proposals.length}
                  </CardTitle>
                </CardHeader>
                <CardFooter>
                  <p className="text-xs text-muted-foreground">
                    Across all governance cycles
                  </p>
                </CardFooter>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Active Proposals</CardDescription>
                  <CardTitle className="text-3xl text-green-400">
                    {proposals.filter((p) => p.status === "active").length}
                  </CardTitle>
                </CardHeader>
                <CardFooter>
                  <p className="text-xs text-muted-foreground">
                    Accepting encrypted ballots now
                  </p>
                </CardFooter>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Total Voters</CardDescription>
                  <CardTitle className="text-3xl">12,847</CardTitle>
                </CardHeader>
                <CardFooter>
                  <p className="text-xs text-muted-foreground">
                    Unique eligible addresses
                  </p>
                </CardFooter>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Participation Rate</CardDescription>
                  <CardTitle className="text-3xl">34.2%</CardTitle>
                </CardHeader>
                <CardFooter>
                  <Progress value={34.2} className="h-2" />
                </CardFooter>
              </Card>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>
                    Latest governance events on SP1
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {RECENT_ACTIVITY.map((event, i) => (
                    <div key={i} className="flex justify-between items-start">
                      <p className="text-sm font-mono">{event.text}</p>
                      <span className="text-xs text-muted-foreground whitespace-nowrap ml-2">
                        {event.time}
                      </span>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Protocol Stats</CardTitle>
                  <CardDescription>
                    SP1 network and governance metrics
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">
                      SP1 Verifier Count
                    </span>
                    <span className="text-sm font-semibold">2,847</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">
                      Total Proofs Submitted
                    </span>
                    <span className="text-sm font-semibold">4,218,392</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">
                      Governance Token Supply
                    </span>
                    <span className="text-sm font-semibold">10M SP1-GOV</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">
                      Encrypted Ballots Cast
                    </span>
                    <span className="text-sm font-semibold">
                      {voteRecords.length}
                    </span>
                  </div>
                  <Separator />
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">
                      Your Voting Power
                    </span>
                    <span className="text-sm font-semibold">
                      {formatNumber(voter.tokenBalance)} + {formatNumber(voter.nftHoldings)} NFTs
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Proposals Tab */}
          <TabsContent value="proposals" className="space-y-6 mt-6">
            {proposals.map((proposal) => {
              const totalVotes = proposal.forVotes + proposal.againstVotes;
              const forPct =
                totalVotes > 0 ? (proposal.forVotes / proposal.totalEligible) * 100 : 0;
              const againstPct =
                totalVotes > 0 ? (proposal.againstVotes / proposal.totalEligible) * 100 : 0;

              return (
                <Card key={proposal.id}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <CardTitle className="text-lg">
                          #{proposal.id} — {proposal.title}
                        </CardTitle>
                        <CardDescription className="line-clamp-2">
                          {proposal.description}
                        </CardDescription>
                      </div>
                      <StatusBadge status={proposal.status} />
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-green-400">
                          For: {formatNumber(proposal.forVotes)}
                        </span>
                        <span className="text-muted-foreground">
                          {forPct.toFixed(1)}% of eligible
                        </span>
                      </div>
                      <Progress value={forPct} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-red-400">
                          Against: {formatNumber(proposal.againstVotes)}
                        </span>
                        <span className="text-muted-foreground">
                          {againstPct.toFixed(1)}% of eligible
                        </span>
                      </div>
                      <Progress value={againstPct} className="h-2" />
                    </div>
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>
                        Created:{" "}
                        {new Date(proposal.createdAt).toLocaleDateString()}
                      </span>
                      <span>{getTimeRemaining(proposal.endTime)}</span>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" className="w-full">
                          View Details
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-lg">
                        <DialogHeader>
                          <DialogTitle>
                            #{proposal.id} — {proposal.title}
                          </DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4 mt-2">
                          <p className="text-sm text-muted-foreground">
                            {proposal.description}
                          </p>
                          <Separator />
                          <div className="space-y-2">
                            <h4 className="text-sm font-semibold">
                              Encrypted Vote Breakdown
                            </h4>
                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-1">
                                <p className="text-sm text-green-400">
                                  For: {formatNumber(proposal.forVotes)}
                                </p>
                                <Progress
                                  value={forPct}
                                  className="h-2"
                                />
                              </div>
                              <div className="space-y-1">
                                <p className="text-sm text-red-400">
                                  Against:{" "}
                                  {formatNumber(proposal.againstVotes)}
                                </p>
                                <Progress
                                  value={againstPct}
                                  className="h-2"
                                />
                              </div>
                            </div>
                          </div>
                          <Separator />
                          <div className="space-y-2">
                            <h4 className="text-sm font-semibold">
                              ZK Verification Status
                            </h4>
                            <div className="flex items-center gap-2">
                              <span className="text-green-400 text-sm">
                                ✓ Tally verified on-chain
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-green-400 text-sm">
                                ✓ Homomorphic decryption proof validated
                              </span>
                            </div>
                            <div className="text-xs font-mono text-muted-foreground">
                              Encryption pubkey:{" "}
                              {proposal.encryptionPubKey.slice(0, 42)}...
                            </div>
                          </div>
                          <Separator />
                          <div className="text-xs text-muted-foreground space-y-1">
                            <p>
                              Total eligible voters:{" "}
                              {formatNumber(proposal.totalEligible)}
                            </p>
                            <p>
                              Total votes cast:{" "}
                              {formatNumber(totalVotes)}
                            </p>
                            <p>
                              Participation:{" "}
                              {totalVotes > 0
                                ? (
                                    (totalVotes / proposal.totalEligible) *
                                    100
                                  ).toFixed(1)
                                : 0}
                              %
                            </p>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </CardFooter>
                </Card>
              );
            })}

            <Card>
              <CardHeader>
                <CardTitle>Create New Proposal</CardTitle>
                <CardDescription>
                  Submit a new governance proposal for community vote
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="proposal-title">Title</Label>
                  <Input
                    id="proposal-title"
                    placeholder="Enter proposal title..."
                    value={newProposalTitle}
                    onChange={(e) => setNewProposalTitle(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="proposal-desc">Description</Label>
                  <Textarea
                    id="proposal-desc"
                    placeholder="Describe the proposal in detail..."
                    value={newProposalDescription}
                    onChange={(e) => setNewProposalDescription(e.target.value)}
                    rows={4}
                  />
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full">Submit Proposal</Button>
              </CardFooter>
            </Card>
          </TabsContent>

          {/* Vote Tab */}
          <TabsContent value="vote" className="space-y-6 mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Submit Encrypted Ballot</CardTitle>
                <CardDescription>
                  Cast your vote with zero-knowledge eligibility verification
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label>Select Proposal</Label>
                  <Select
                    value={selectedProposalId}
                    onValueChange={(val) => {
                      setSelectedProposalId(val);
                      setVoteChoice(null);
                      setEncryptedBallot(null);
                      setVoteProgress(0);
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a proposal" />
                    </SelectTrigger>
                    <SelectContent>
                      {proposals
                        .filter((p) => p.status === "active")
                        .map((p) => (
                          <SelectItem key={p.id} value={String(p.id)}>
                            #{p.id} — {p.title}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedProposal && (
                  <>
                    <Separator />
                    <div className="space-y-3">
                      <Label>Eligibility Verification</Label>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">
                          Generate ZK proof of token/NFT holdings
                        </span>
                        <Switch
                          checked={zkProofEnabled}
                          onCheckedChange={handleGenerateZkProof}
                        />
                      </div>
                      {zkProofEnabled && !zkProofHash && (
                        <p className="text-xs text-yellow-400 animate-pulse">
                          Verifying NFT holdings via SP1 zkVM...
                        </p>
                      )}
                      {zkProofHash && (
                        <div className="space-y-1">
                          <p className="text-xs text-green-400">
                            ✓ Proof generated: {zkProofHash.slice(0, 18)}...
                            {zkProofHash.slice(-8)}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            Verified {voter.nftHoldings} NFT holdings and{" "}
                            {formatNumber(voter.tokenBalance)} token balance
                          </p>
                        </div>
                      )}
                    </div>

                    <Separator />
                    <div className="space-y-2">
                      <Label>Your Encrypted Ballot</Label>
                      <Input
                        readOnly
                        value={
                          encryptedBallot
                            ? `${encryptedBallot.slice(0, 34)}...${encryptedBallot.slice(-8)}`
                            : "Ballot will be encrypted after vote submission"
                        }
                        className="font-mono text-xs"
                      />
                    </div>

                    <Separator />
                    <div className="space-y-2">
                      <Label>Vote Choice</Label>
                      <div className="flex gap-3">
                        <Button
                          variant={
                            voteChoice === "for" ? "default" : "outline"
                          }
                          className="flex-1"
                          onClick={() => setVoteChoice("for")}
                          disabled={voter.hasVoted || selectedProposal.status !== "active"}
                        >
                          For
                        </Button>
                        <Button
                          variant={
                            voteChoice === "against" ? "destructive" : "outline"
                          }
                          className="flex-1"
                          onClick={() => setVoteChoice("against")}
                          disabled={voter.hasVoted || selectedProposal.status !== "active"}
                        >
                          Against
                        </Button>
                      </div>
                    </div>

                    {isVoting && (
                      <div className="space-y-2">
                        <p className="text-sm text-muted-foreground">
                          Encrypting & submitting to SP1 verifier...
                        </p>
                        <Progress value={voteProgress} className="h-2" />
                      </div>
                    )}

                    {encryptedBallot && (
                      <div className="rounded-lg border border-green-500/30 bg-green-500/10 p-4 space-y-2">
                        <p className="text-sm font-semibold text-green-400">
                          ✓ Vote Submitted Successfully
                        </p>
                        <p className="text-xs font-mono text-muted-foreground">
                          Encrypted ballot: {encryptedBallot.slice(0, 34)}...
                          {encryptedBallot.slice(-8)}
                        </p>
                        <p className="text-xs font-mono text-muted-foreground">
                          ZK proof: {zkProofHash!.slice(0, 18)}...
                          {zkProofHash!.slice(-8)}
                        </p>
                      </div>
                    )}

                    <Button
                      className="w-full"
                      onClick={handleSubmitVote}
                      disabled={
                        !voteChoice ||
                        !zkProofHash ||
                        isVoting ||
                        voter.hasVoted
                      }
                    >
                      {voter.hasVoted
                        ? "Already Voted"
                        : isVoting
                          ? "Submitting..."
                          : "Submit Encrypted Vote"}
                    </Button>
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Delegation Tab */}
          <TabsContent value="delegation" className="space-y-6 mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Current Delegations</CardTitle>
                <CardDescription>
                  Your active and incoming voting power delegations
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {delegations.map((delegation, i) => {
                  const isExpired =
                    new Date(delegation.expiresAt).getTime() < Date.now();
                  return (
                    <div
                      key={i}
                      className="flex items-center justify-between rounded-lg border p-4"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-mono">
                            {delegation.from}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            →
                          </span>
                          <span className="text-sm font-mono">
                            {delegation.to}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-xs">
                            {delegation.scope === "all"
                              ? "All Proposals"
                              : "Protocol-Specific"}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            Expires:{" "}
                            {new Date(
                              delegation.expiresAt
                            ).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                      {isExpired && (
                        <Badge
                          variant="outline"
                          className="border-red-500/30 text-red-400"
                        >
                          Expired
                        </Badge>
                      )}
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Delegate Voting Power</CardTitle>
                <CardDescription>
                  Delegate your SP1-GOV tokens to a trusted representative
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="delegate-address">Delegate Address</Label>
                  <Input
                    id="delegate-address"
                    placeholder="0x..."
                    value={delegateAddress}
                    onChange={(e) => setDelegateAddress(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Delegation Scope</Label>
                  <Select
                    value={delegateScope}
                    onValueChange={setDelegateScope}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">
                        All Proposals
                      </SelectItem>
                      <SelectItem value="protocol-specific">
                        Protocol-Specific Only
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Allow Re-delegation</Label>
                    <p className="text-xs text-muted-foreground">
                      Permit your delegate to further delegate your votes
                    </p>
                  </div>
                  <Switch
                    checked={allowRedelegation}
                    onCheckedChange={setAllowRedelegation}
                  />
                </div>
                <Separator />
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">
                    Your voting power to delegate
                  </span>
                  <span className="font-semibold">
                    {formatNumber(voter.tokenBalance)} SP1-GOV
                  </span>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full" disabled={!delegateAddress}>
                  Delegate Voting Power
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          {/* Verification Tab */}
          <TabsContent value="verification" className="space-y-6 mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Verify Tally Results</CardTitle>
                <CardDescription>
                  Independently verify the homomorphic tally and ZK proof for
                  any proposal
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex gap-3">
                  <div className="flex-1">
                    <Label htmlFor="verify-id" className="mb-2 block">
                      Proposal ID
                    </Label>
                    <Input
                      id="verify-id"
                      placeholder="Enter proposal ID (e.g. 1)"
                      value={verifyProposalId}
                      onChange={(e) => {
                        setVerifyProposalId(e.target.value);
                        setVerifySteps([]);
                        setVerifiedResults(null);
                      }}
                    />
                  </div>
                  <div className="flex items-end">
                    <Button
                      onClick={handleVerifyTally}
                      disabled={!verifyProposalId || isVerifying}
                    >
                      {isVerifying ? "Verifying..." : "Verify Tally"}
                    </Button>
                  </div>
                </div>

                {verifySteps.length > 0 && (
                  <>
                    <Separator />
                    <div className="space-y-3">
                      <Label>Verification Progress</Label>
                      {verifySteps.map((step, i) => (
                        <div
                          key={i}
                          className="flex items-center gap-3 text-sm"
                        >
                          {step.includes("✓") ? (
                            <span className="text-green-400">✓</span>
                          ) : (
                            <span className="text-yellow-400">⟳</span>
                          )}
                          <span
                            className={
                              step.includes("✓")
                                ? "text-green-400"
                                : "text-muted-foreground"
                            }
                          >
                            {step}
                          </span>
                        </div>
                      ))}
                    </div>
                  </>
                )}

                {verifiedResults && (
                  <>
                    <Separator />
                    <div className="rounded-lg border border-green-500/30 bg-green-500/10 p-4 space-y-3">
                      <h4 className="text-sm font-semibold text-green-400">
                        Verified Results
                      </h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-xs text-muted-foreground">
                            For Votes
                          </p>
                          <p className="text-lg font-bold text-green-400">
                            {formatNumber(verifiedResults.forVotes)}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">
                            Against Votes
                          </p>
                          <p className="text-lg font-bold text-red-400">
                            {formatNumber(verifiedResults.againstVotes)}
                          </p>
                        </div>
                      </div>
                      <Separator />
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground">
                          SP1 Proof Hash
                        </p>
                        <p className="text-xs font-mono">
                          {verifiedResults.proofHash.slice(0, 42)}...
                          {verifiedResults.proofHash.slice(-8)}
                        </p>
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            {voteRecords.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Your Vote Receipts</CardTitle>
                  <CardDescription>
                    Verifiable receipts for your submitted ballots
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {voteRecords.map((record, i) => (
                    <div
                      key={i}
                      className="rounded-lg border p-3 space-y-1"
                    >
                      <div className="flex justify-between text-sm">
                        <span>Proposal #{record.proposalId}</span>
                        <span className="text-xs text-muted-foreground">
                          {new Date(record.timestamp).toLocaleString()}
                        </span>
                      </div>
                      <p className="text-xs font-mono text-muted-foreground">
                        Ballot: {record.encryptedBallot.slice(0, 34)}...
                        {record.encryptedBallot.slice(-8)}
                      </p>
                      <p className="text-xs font-mono text-muted-foreground">
                        ZK Proof: {record.zkProofHash.slice(0, 18)}...
                        {record.zkProofHash.slice(-8)}
                      </p>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
