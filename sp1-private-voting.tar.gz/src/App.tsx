import { useState } from 'react'
import { AppProvider } from './context/AppContext'
import { Navbar } from './components/Navbar'
import { Dashboard } from './components/Dashboard'
import { ProposalCreation } from './components/ProposalCreation'
import { VotingBooth } from './components/VotingBooth'
import { DelegationPanel } from './components/DelegationPanel'
import { ResultsViewer } from './components/ResultsViewer'
import { ProofVerifier } from './components/ProofVerifier'

type View = 'dashboard' | 'create' | 'vote' | 'delegate' | 'results' | 'verify'

export default function App() {
  const [view, setView] = useState<View>('dashboard')

  return (
    <AppProvider>
      <div className="min-h-screen flex flex-col">
        <Navbar currentView={view} onNavigate={setView} />
        <main className="flex-1 max-w-7xl mx-auto w-full px-4 py-6">
          {view === 'dashboard' && <Dashboard onNavigate={setView} />}
          {view === 'create' && <ProposalCreation onBack={() => setView('dashboard')} />}
          {view === 'vote' && <VotingBooth onBack={() => setView('dashboard')} />}
          {view === 'delegate' && <DelegationPanel onBack={() => setView('dashboard')} />}
          {view === 'results' && <ResultsViewer onBack={() => setView('dashboard')} />}
          {view === 'verify' && <ProofVerifier onBack={() => setView('dashboard')} />}
        </main>
      </div>
    </AppProvider>
  )
}
