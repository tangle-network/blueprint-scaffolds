const P256_N =
  0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551n;

function mod(a: bigint, m: bigint): bigint {
  return ((a % m) + m) % m;
}

function modPow(base: bigint, exp: bigint, m: bigint): bigint {
  let result = 1n;
  base = mod(base, m);
  while (exp > 0n) {
    if (exp & 1n) result = mod(result * base, m);
    exp >>= 1n;
    base = mod(base * base, m);
  }
  return result;
}

function generateRandomBigInt(bytes: number = 32): bigint {
  const arr = new Uint8Array(bytes);
  crypto.getRandomValues(arr);
  let hex = "0x";
  for (const b of arr) hex += b.toString(16).padStart(2, "0");
  return BigInt(hex);
}

export function generateKeypair(): { privateKey: bigint; publicKey: bigint } {
  const privateKey = mod(generateRandomBigInt(), P256_N - 1n) + 1n;
  const Gx = 0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296n;
  const publicKey = mod(privateKey * Gx, P256_N);
  return { privateKey, publicKey };
}

export function encryptVote(
  choice: number,
  publicKey: bigint
): { ciphertext: string; nonce: string } {
  const m = BigInt(choice);
  const r = mod(generateRandomBigInt(), P256_N - 1n) + 1n;
  const sharedSecret = mod(r * publicKey, P256_N);
  const c1 = mod(r * 0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296n, P256_N);
  const c2 = mod(m * sharedSecret, P256_N);
  return {
    ciphertext: `${c1.toString(16)}:${c2.toString(16)}`,
    nonce: r.toString(16),
  };
}

export function homomorphicAdd(
  ct1: string,
  ct2: string
): string {
  const [c1a, c2a] = ct1.split(":").map((s) => BigInt("0x" + s));
  const [c1b, c2b] = ct2.split(":").map((s) => BigInt("0x" + s));
  const c1 = mod(c1a + c1b, P256_N);
  const c2 = mod(c2a + c2b, P256_N);
  return `${c1.toString(16)}:${c2.toString(16)}`;
}

export function decryptTally(
  ciphertext: string,
  privateKey: bigint
): number {
  const [c1Hex, c2Hex] = ciphertext.split(":");
  const c1 = BigInt("0x" + c1Hex);
  const c2 = BigInt("0x" + c2Hex);
  const shared = mod(c1 * privateKey, P256_N);
  const sharedInv = modPow(shared, P256_N - 2n, P256_N);
  const plaintext = mod(c2 * sharedInv, P256_N);
  return Number(plaintext);
}

export function generateNullifier(
  voterAddress: string,
  proposalId: string
): string {
  const data = new TextEncoder().encode(`${voterAddress}:${proposalId}`);
  const hash = computeHash(data);
  return hash;
}

function computeHash(data: Uint8Array): string {
  let h1 = 0xdeadbeef;
  let h2 = 0x41c6ce57;
  for (let i = 0; i < data.length; i++) {
    h1 = Math.imul(h1 ^ data[i], 2654435761);
    h2 = Math.imul(h2 ^ data[i], 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507);
  h1 ^= Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507);
  h2 ^= Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16).padStart(16, "0");
}
