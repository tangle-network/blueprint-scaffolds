export interface Ballot {
  proposalId: string;
  encryptedChoice: Uint8Array;
  nullifier: string;
  zkProof: ZKProof;
  timestamp: number;
}

export interface ZKProof {
  a: [string, string];
  b: [[string, string], [string, string]];
  c: [string, string];
  publicSignals: string[];
}

export interface EncryptedBallot {
  proposalId: string;
  ciphertext: string;
  ephemeralKey: string;
  nullifierHash: string;
}

export interface TallyResult {
  proposalId: string;
  yesVotes: number;
  noVotes: number;
  totalVotes: number;
  proof: ZKProof;
}

export interface Proposal {
  id: string;
  title: string;
  description: string;
  creator: string;
  createdAt: number;
  votingStarts: number;
  votingEnds: number;
  status: "pending" | "active" | "closed";
  eligibleTokenId?: string;
  eligibleNftCollection?: string;
  minTokensRequired: string;
  tally?: TallyResult;
}

export interface VoterDelegation {
  delegator: string;
  delegatee: string;
  proposalId: string;
  revokedAt?: number;
}

export interface Voter {
  address: string;
  isRegistered: boolean;
  delegationsGiven: VoterDelegation[];
  delegationsReceived: VoterDelegation[];
  votingPower: string;
  hasEligibilityProof: boolean;
}

export interface EligibilityCriteria {
  type: "token" | "nft";
  contractAddress: string;
  minBalance: string;
  tokenId?: string;
}

export const ELIGIBILITY_TYPE = {
  TOKEN: "token" as const,
  NFT: "nft" as const,
};

export const PROPOSAL_STATUS = {
  PENDING: "pending" as const,
  ACTIVE: "active" as const,
  CLOSED: "closed" as const,
};
