export const VOTING_REGISTRY_ABI = [
  {
    type: "function",
    name: "registerVoter",
    inputs: [
      { name: "voter", type: "address" },
      { name: "eligibilityProof", type: "bytes" },
    ],
    outputs: [],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "isRegistered",
    inputs: [{ name: "voter", type: "address" }],
    outputs: [{ name: "", type: "bool" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "getVotingPower",
    inputs: [{ name: "voter", type: "address" }],
    outputs: [{ name: "", type: "uint256" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "setEligibilityCriteria",
    inputs: [
      { name: "tokenContract", type: "address" },
      { name: "minBalance", type: "uint256" },
      { name: "isNFT", type: "bool" },
    ],
    outputs: [],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "getEligibilityCriteria",
    inputs: [],
    outputs: [
      { name: "tokenContract", type: "address" },
      { name: "minBalance", type: "uint256" },
      { name: "isNFT", type: "bool" },
    ],
    stateMutability: "view",
  },
] as const;

export const BALLOT_SUBMISSION_ABI = [
  {
    type: "function",
    name: "submitBallot",
    inputs: [
      { name: "proposalId", type: "bytes32" },
      { name: "encryptedChoice", type: "bytes" },
      { name: "nullifierHash", type: "bytes32" },
      { name: "zkProof", type: "bytes" },
    ],
    outputs: [],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "hasVoted",
    inputs: [{ name: "nullifierHash", type: "bytes32" }],
    outputs: [{ name: "", type: "bool" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "getBallotCount",
    inputs: [{ name: "proposalId", type: "bytes32" }],
    outputs: [{ name: "", type: "uint256" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "getBallot",
    inputs: [
      { name: "proposalId", type: "bytes32" },
      { name: "index", type: "uint256" },
    ],
    outputs: [
      { name: "encryptedChoice", type: "bytes" },
      { name: "nullifierHash", type: "bytes32" },
      { name: "timestamp", type: "uint256" },
    ],
    stateMutability: "view",
  },
] as const;

export const RESULT_VERIFICATION_ABI = [
  {
    type: "function",
    name: "submitResult",
    inputs: [
      { name: "proposalId", type: "bytes32" },
      { name: "yesVotes", type: "uint256" },
      { name: "noVotes", type: "uint256" },
      { name: "tallyProof", type: "bytes" },
    ],
    outputs: [],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "getResult",
    inputs: [{ name: "proposalId", type: "bytes32" }],
    outputs: [
      { name: "yesVotes", type: "uint256" },
      { name: "noVotes", type: "uint256" },
      { name: "totalVotes", type: "uint256" },
      { name: "isVerified", type: "bool" },
    ],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "isResultVerified",
    inputs: [{ name: "proposalId", type: "bytes32" }],
    outputs: [{ name: "", type: "bool" }],
    stateMutability: "view",
  },
] as const;

export const DELEGATION_MANAGER_ABI = [
  {
    type: "function",
    name: "delegate",
    inputs: [
      { name: "delegatee", type: "address" },
      { name: "proposalId", type: "bytes32" },
    ],
    outputs: [],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "revokeDelegation",
    inputs: [{ name: "proposalId", type: "bytes32" }],
    outputs: [],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "getEffectiveVotingPower",
    inputs: [
      { name: "voter", type: "address" },
      { name: "proposalId", type: "bytes32" },
    ],
    outputs: [{ name: "", type: "uint256" }],
    stateMutability: "view",
  },
] as const;

export const CONTRACT_ADDRESSES = {
  votingRegistry: "0x5FbDB2315678afecb367f032d93F642f64180aa3",
  ballotSubmission: "0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512",
  resultVerification: "0x9fE46736679d2D9a65F0992F2272dE9f3c7fa6e0",
  delegationManager: "0xCf7Ed3AccA5a467e9e704C703E8D87F634fB0Fc9",
} as const;
