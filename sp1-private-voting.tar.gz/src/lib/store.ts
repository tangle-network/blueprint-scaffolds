import type {
  Proposal,
  TallyResult,
  EncryptedBallot,
  Voter,
  VoterDelegation,
  ZKProof,
} from "./types";

const STORAGE_PREFIX = "pv_sp1_";

function store<T>(key: string, value: T): void {
  try {
    localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(value));
  } catch {}
}

function load<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(STORAGE_PREFIX + key);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function makeId(): string {
  return Array.from(crypto.getRandomValues(new Uint8Array(16)))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

const DEMO_PROPOSALS: Proposal[] = [
  {
    id: "prop_001",
    title: "Increase Protocol Treasury Allocation",
    description:
      "Proposal to increase treasury allocation from 10% to 15% of protocol revenue for community grants and development funding.",
    creator: "0x742d35Cc6634C0532925a3b844Bc9e7595f2bD38",
    createdAt: Date.now() - 86400000 * 3,
    votingStarts: Date.now() - 86400000 * 2,
    votingEnds: Date.now() + 86400000 * 5,
    status: "active",
    eligibleTokenId: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
    minTokensRequired: "100",
  },
  {
    id: "prop_002",
    title: "Add New Collateral Type - wETH",
    description:
      "Enable wrapped ETH as a collateral type in the lending protocol with 75% LTV ratio and 85% liquidation threshold.",
    creator: "0x8ba1f109551bD432803012645Ac136ddd64DBA72",
    createdAt: Date.now() - 86400000 * 7,
    votingStarts: Date.now() - 86400000 * 5,
    votingEnds: Date.now() - 86400000 * 1,
    status: "closed",
    minTokensRequired: "50",
    tally: {
      proposalId: "prop_002",
      yesVotes: 1842,
      noVotes: 371,
      totalVotes: 2213,
      proof: {
        a: ["0x1a2b", "0x3c4d"],
        b: [["0x5e6f", "0x7a8b"], ["0x9c0d", "0x1e2f"]],
        c: ["0x3a4b", "0x5c6d"],
        publicSignals: ["0xprop002", "0xtally", "0x732", "0x173"],
      },
    },
  },
  {
    id: "prop_003",
    title: "Protocol Fee Reduction Q2 2026",
    description:
      "Reduce trading fees from 0.3% to 0.2% for the next quarter to increase volume and market share.",
    creator: "0xdD2FD4581271e230360230F9337D5c0430Bf44C0",
    createdAt: Date.now() - 86400000,
    votingStarts: Date.now() + 86400000 * 2,
    votingEnds: Date.now() + 86400000 * 9,
    status: "pending",
    eligibleNftCollection: "0xBC4CA0EdA7647A8aB7C2061c2E118A18a936f13D",
    minTokensRequired: "1",
  },
];

const DEMO_BALLOTS: Record<string, EncryptedBallot[]> = {
  prop_001: [],
  prop_002: [],
  prop_003: [],
};

export class VotingStore {
  private proposals: Proposal[];
  private ballots: Record<string, EncryptedBallot[]>;
  private voters: Record<string, Voter>;
  private delegations: VoterDelegation[];
  private encryptionPublicKey: bigint | null = null;

  constructor() {
    this.proposals = load<Proposal[]>("proposals") || [...DEMO_PROPOSALS];
    this.ballots = load<Record<string, EncryptedBallot[]>>("ballots") || {
      ...DEMO_BALLOTS,
    };
    this.voters = load<Record<string, Voter>>("voters") || {};
    this.delegations = load<VoterDelegation[]>("delegations") || [];
  }

  getProposals(): Proposal[] {
    return this.proposals;
  }

  getProposal(id: string): Proposal | undefined {
    return this.proposals.find((p) => p.id === id);
  }

  createProposal(
    title: string,
    description: string,
    creator: string,
    votingDurationDays: number,
    eligibilityType: "token" | "nft",
    contractAddress: string,
    minTokens: string
  ): Proposal {
    const proposal: Proposal = {
      id: "prop_" + makeId().substring(0, 8),
      title,
      description,
      creator,
      createdAt: Date.now(),
      votingStarts: Date.now() + 86400000,
      votingEnds: Date.now() + 86400000 * (votingDurationDays + 1),
      status: "pending",
      minTokensRequired: minTokens,
    };
    if (eligibilityType === "token") {
      proposal.eligibleTokenId = contractAddress;
    } else {
      proposal.eligibleNftCollection = contractAddress;
    }
    this.proposals.unshift(proposal);
    this.persist();
    return proposal;
  }

  activateProposal(id: string): void {
    const p = this.getProposal(id);
    if (p && p.status === "pending") {
      p.status = "active";
      p.votingStarts = Date.now();
      this.persist();
    }
  }

  closeProposal(id: string, tally: TallyResult): void {
    const p = this.getProposal(id);
    if (p && p.status === "active") {
      p.status = "closed";
      p.tally = tally;
      this.persist();
    }
  }

  submitBallot(
    proposalId: string,
    encryptedChoice: string,
    nullifierHash: string,
    _zkProof: ZKProof
  ): EncryptedBallot {
    if (!this.ballots[proposalId]) {
      this.ballots[proposalId] = [];
    }
    const ballot: EncryptedBallot = {
      proposalId,
      ciphertext: encryptedChoice,
      ephemeralKey: makeId(),
      nullifierHash,
    };
    this.ballots[proposalId].push(ballot);
    this.persist();
    return ballot;
  }

  getBallots(proposalId: string): EncryptedBallot[] {
    return this.ballots[proposalId] || [];
  }

  hasNullifierBeenUsed(nullifierHash: string): boolean {
    for (const key of Object.keys(this.ballots)) {
      if (this.ballots[key].some((b) => b.nullifierHash === nullifierHash)) {
        return true;
      }
    }
    return false;
  }

  getVoter(address: string): Voter {
    if (!this.voters[address]) {
      this.voters[address] = {
        address,
        isRegistered: false,
        delegationsGiven: [],
        delegationsReceived: [],
        votingPower: "0",
        hasEligibilityProof: false,
      };
    }
    return this.voters[address];
  }

  registerVoter(address: string): Voter {
    this.voters[address] = {
      address,
      isRegistered: true,
      delegationsGiven: [],
      delegationsReceived: [],
      votingPower: "100",
      hasEligibilityProof: true,
    };
    this.persist();
    return this.voters[address];
  }

  addDelegation(delegation: VoterDelegation): void {
    this.delegations.push(delegation);
    const voter = this.getVoter(delegation.delegator);
    voter.delegationsGiven.push(delegation);
    const delegatee = this.getVoter(delegation.delegatee);
    delegatee.delegationsReceived.push(delegation);
    this.persist();
  }

  revokeDelegation(delegator: string, proposalId: string): void {
    const idx = this.delegations.findIndex(
      (d) =>
        d.delegator === delegator &&
        d.proposalId === proposalId &&
        !d.revokedAt
    );
    if (idx >= 0) {
      this.delegations[idx].revokedAt = Date.now();
    }
    this.persist();
  }

  getDelegations(address: string): {
    given: VoterDelegation[];
    received: VoterDelegation[];
  } {
    return {
      given: this.delegations.filter(
        (d) => d.delegator === address && !d.revokedAt
      ),
      received: this.delegations.filter(
        (d) => d.delegatee === address && !d.revokedAt
      ),
    };
  }

  setEncryptionPublicKey(pk: bigint): void {
    this.encryptionPublicKey = pk;
  }

  getEncryptionPublicKey(): bigint | null {
    return this.encryptionPublicKey;
  }

  private persist(): void {
    store("proposals", this.proposals);
    store("ballots", this.ballots);
    store("voters", this.voters);
    store("delegations", this.delegations);
  }
}

let _instance: VotingStore | null = null;

export function getVotingStore(): VotingStore {
  if (!_instance) {
    _instance = new VotingStore();
  }
  return _instance;
}
