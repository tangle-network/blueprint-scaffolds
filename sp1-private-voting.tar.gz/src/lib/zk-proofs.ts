import type { ZKProof, EligibilityCriteria } from "./types";

export interface SP1ProofInput {
  voterAddress: string;
  merkleRoot: string;
  merkleProof: string[];
  eligibility: EligibilityCriteria;
  nullifier: string;
}

export interface SP1ProofOutput {
  proof: ZKProof;
  publicSignals: string[];
}

export async function generateEligibilityProof(
  input: SP1ProofInput
): Promise<SP1ProofOutput> {
  await simulateWork(800);

  const proof: ZKProof = {
    a: [
      `0x${hashStr(input.voterAddress + "a0").padStart(64, "0")}`,
      `0x${hashStr(input.voterAddress + "a1").padStart(64, "0")}`,
    ],
    b: [
      [
        `0x${hashStr(input.merkleRoot + "b00").padStart(64, "0")}`,
        `0x${hashStr(input.merkleRoot + "b01").padStart(64, "0")}`,
      ],
      [
        `0x${hashStr(input.nullifier + "b10").padStart(64, "0")}`,
        `0x${hashStr(input.nullifier + "b11").padStart(64, "0")}`,
      ],
    ],
    c: [
      `0x${hashStr(input.voterAddress + input.nullifier + "c0").padStart(64, "0")}`,
      `0x${hashStr(input.voterAddress + input.nullifier + "c1").padStart(64, "0")}`,
    ],
    publicSignals: [
      input.merkleRoot,
      input.nullifier,
      `0x${hashStr(input.voterAddress).padStart(64, "0")}`,
      input.eligibility.type === "nft" ? "0x1" : "0x0",
    ],
  };

  return { proof, publicSignals: proof.publicSignals };
}

export async function verifyProof(
  proof: ZKProof,
  _expectedPublicSignals: string[]
): Promise<boolean> {
  await simulateWork(400);
  return proof.a.length === 2 && proof.b.length === 2 && proof.c.length === 2;
}

export async function generateTallyProof(
  proposalId: string,
  encryptedTally: string,
  yesVotes: number,
  noVotes: number
): Promise<SP1ProofOutput> {
  await simulateWork(600);
  const proof: ZKProof = {
    a: [
      `0x${hashStr(proposalId + "tally_a0").padStart(64, "0")}`,
      `0x${hashStr(proposalId + "tally_a1").padStart(64, "0")}`,
    ],
    b: [
      [
        `0x${hashStr(encryptedTally + "tb00").padStart(64, "0")}`,
        `0x${hashStr(encryptedTally + "tb01").padStart(64, "0")}`,
      ],
      [
        `0x${hashStr(yesVotes + "" + noVotes).padStart(64, "0")}`,
        `0x${hashStr(proposalId + "tb11").padStart(64, "0")}`,
      ],
    ],
    c: [
      `0x${hashStr(yesVotes + ":" + noVotes + ":tally").padStart(64, "0")}`,
      `0x${hashStr(proposalId + ":tally_c1").padStart(64, "0")}`,
    ],
    publicSignals: [
      proposalId,
      encryptedTally.substring(0, 16),
      `0x${yesVotes.toString(16).padStart(64, "0")}`,
      `0x${noVotes.toString(16).padStart(64, "0")}`,
    ],
  };
  return { proof, publicSignals: proof.publicSignals };
}

function hashStr(input: string): string {
  let h = 0x811c9dc5;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(16);
}

function simulateWork(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
