import { useState, useEffect, useCallback } from "react";
import type { Proposal } from "../lib/types";
import { getVotingStore } from "../lib/store";

export function useProposals() {
  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(() => {
    setLoading(true);
    const store = getVotingStore();
    setProposals(store.getProposals());
    setLoading(false);
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const createProposal = useCallback(
    (
      title: string,
      description: string,
      creator: string,
      durationDays: number,
      eligibilityType: "token" | "nft",
      contractAddress: string,
      minTokens: string
    ) => {
      const store = getVotingStore();
      store.createProposal(
        title,
        description,
        creator,
        durationDays,
        eligibilityType,
        contractAddress,
        minTokens
      );
      refresh();
    },
    [refresh]
  );

  return { proposals, loading, createProposal, refresh };
}
