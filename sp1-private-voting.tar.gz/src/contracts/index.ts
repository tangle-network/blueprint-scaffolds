export const VOTING_REGISTRY_ABI = [
  'function registerVoter(address voter) external',
  'function isRegistered(address voter) external view returns (bool)',
  'function getTokenBalance(address voter) external view returns (uint256)',
  'function getNFTIds(address voter) external view returns (uint256[])',
  'function verifyEligibility(address voter, uint256 proposalId) external view returns (bool)',
  'event VoterRegistered(address indexed voter, uint256 timestamp)'
]

export const BALLOT_SUBMISSION_ABI = [
  'function submitBallot(uint256 proposalId, bytes calldata encryptedBallot, bytes calldata zkProof) external',
  'function getBallotCount(uint256 proposalId) external view returns (uint256)',
  'function hasVoted(uint256 proposalId, address voter) external view returns (bool)',
  'function delegateVote(address delegatee, uint256 proposalId) external',
  'function revokeDelegation(address delegatee, uint256 proposalId) external',
  'event BallotSubmitted(uint256 indexed proposalId, bytes32 ballotHash, uint256 timestamp)',
  'event VoteDelegated(address indexed from, address indexed to, uint256 proposalId)'
]

export const RESULT_VERIFICATION_ABI = [
  'function submitTallyResult(uint256 proposalId, bytes calldata encryptedTally, bytes calldata sp1Proof) external',
  'function verifyResult(uint256 proposalId) external view returns (bool)',
  'function getTallyResult(uint256 proposalId) external view returns (uint256[] memory)',
  'function getSP1ProofHash(uint256 proposalId) external view returns (bytes32)',
  'event TallyVerified(uint256 indexed proposalId, bytes32 proofHash, uint256[] results)'
]

export const VOTING_REGISTRY_BYTECODE = '0x608060405234801561001057600080fd5b50610123806100206000396000f3fe6080604052600436106100385760003560e01c8063545fe1c7146100375780638da5cb5b14610059578063f85157471461008a575b005b34801561004457600080fd5b506100576100533660046100c2565b61009c565b005b34801561006657600080fd5b507f00000000000000000000000000000000000000000000000000000000000000006040516001600160a01b03909116815260200160405180910390f35b34801561009657600080fd5b506100576100ab565b005b600080825160208401845afa9392505050565b600080fd5b600080fd5b600080fd'

export const BALLOT_SUBMISSION_BYTECODE = '0x608060405234801561001057600080fd5b50610123806100206000396000f3fe6080604052600436106100385760003560e01c8063a4b0c9d814610037578063c1d5e9f114610059578063e2b2e6c71461008a575b005b34801561004457600080fd5b506100576100533660046100c2565b61009c565b005b34801561006657600080fd5b507f00000000000000000000000000000000000000000000000000000000000000006040516001600160a01b03909116815260200160405180910390f35b34801561009657600080fd5b506100576100ab565b005b600080825160208401845afa9392505050565b600080fd'

export const RESULT_VERIFICATION_BYTECODE = '0x608060405234801561001057600080fd5b50610123806100206000396000f3fe6080604052600436106100385760003560e01c8063b7f3a2c114610037578063d4e8d9f214610059578063f1a2b3c41461008a575b005b34801561004457600080fd5b506100576100533660046100c2565b61009c565b005b34801561006657600080fd5b507f00000000000000000000000000000000000000000000000000000000000000006040516001600160a01b03909116815260200160405180910390f35b34801561009657600080fd5b506100576100ab565b005b600080825160208401845afa9392505050565b600080fd'

export const CONTRACT_ADDRESSES = {
  votingRegistry: '0x1234567890abcdef1234567890abcdef12345678',
  ballotSubmission: '0xabcdef1234567890abcdef1234567890abcdef12',
  resultVerification: '0x567890abcdef1234567890abcdef1234567890ab'
}
