import { create } from "zustand"
import {
  type Credential,
  type CredentialType,
  type CredentialStatus,
  type Issuer,
  type SelectiveDisclosureRequest,
  type WalletState,
  type VerificationResult,
  type ZKProof,
} from "@/types/identity"

interface AppState {
  wallet: WalletState
  credentials: Credential[]
  issuers: Issuer[]
  verificationRequests: SelectiveDisclosureRequest[]
  generatedProofs: ZKProof[]
  lastVerificationResult: VerificationResult | null
  connectWallet: () => void
  disconnectWallet: () => void
  addCredential: (credential: Credential) => void
  revokeCredential: (id: string) => void
  submitProof: (proof: ZKProof) => void
  verifyProof: (proof: ZKProof) => void
}

const defaultCredentials: Credential[] = [
  {
    id: "cred-001",
    type: "KYC" as CredentialType,
    issuer: {
      name: "Polygon ID Authority",
      did: "did:polygon:0x3a9E7fB8c2F24D7B9e6C4A1dEf2Bc8D5e9F1a3B7",
      address: "0x3a9E7fB8c2F24D7B9e6C4A1dEf2Bc8D5e9F1a3B7",
    },
    holder: {
      did: "did:polygon:0x1a2B3c4D5e6F7890AbCdEf1234567890aBcDeF12",
      commitment: "0xabc123def456789",
    },
    claims: {
      fullName: "Alexandra Chen",
      dateOfBirth: "1992-03-15",
      nationality: "United States",
      documentType: "Passport",
    },
    issuedAt: Date.now() - 90 * 24 * 60 * 60 * 1000,
    expiresAt: Date.now() + 275 * 24 * 60 * 60 * 1000,
    status: "ACTIVE" as CredentialStatus,
    revocationNonce: 42,
    commitmentHash: "0x7f2c8e4a1b6d3f9e5c7a2d8b4f1e6c3a9d7b5f2e8c4a1d6b3f9e7c5a2d8b4f1e",
  },
  {
    id: "cred-002",
    type: "EDUCATION" as CredentialType,
    issuer: {
      name: "MIT Registrar",
      did: "did:web:mit.edu:registrar",
      address: "0x8B4e7C2d1A5f9E3b6D8c4A2e7F1b5C3d9E6a8B2f",
    },
    holder: {
      did: "did:polygon:0x1a2B3c4D5e6F7890AbCdEf1234567890aBcDeF12",
      commitment: "0xabc123def456789",
    },
    claims: {
      degree: "Bachelor of Science",
      major: "Computer Science and Engineering",
      gpa: "3.87",
      graduationDate: "2014-06-06",
    },
    issuedAt: Date.now() - 365 * 24 * 60 * 60 * 1000,
    expiresAt: Date.now() + 1825 * 24 * 60 * 60 * 1000,
    status: "ACTIVE" as CredentialStatus,
    revocationNonce: 108,
    commitmentHash: "0x2d4f6a8c1e3b5d7f9a2c4e6b8d1f3a5c7e9b2d4f6a8c1e3b5d7f9a2c4e6b8d1f",
  },
  {
    id: "cred-003",
    type: "CERTIFICATION" as CredentialType,
    issuer: {
      name: "Amazon Web Services",
      did: "did:web:aws.amazon.com:certification",
      address: "0x5D6f7A8b9C0d1E2f3A4b5C6d7E8f9A0b1C2d3E4f",
    },
    holder: {
      did: "did:polygon:0x1a2B3c4D5e6F7890AbCdEf1234567890aBcDeF12",
      commitment: "0xabc123def456789",
    },
    claims: {
      certification: "AWS Solutions Architect",
      level: "Professional",
      examScore: "892",
      validUntil: "2027-01-15",
    },
    issuedAt: Date.now() - 30 * 24 * 60 * 60 * 1000,
    expiresAt: Date.now() + 730 * 24 * 60 * 60 * 1000,
    status: "ACTIVE" as CredentialStatus,
    revocationNonce: 256,
    commitmentHash: "0x5a7c9e1b3d5f7a9c1e3b5d7f9a1c3e5b7d9f1a3c5e7b9d1f3a5c7e9b1d3f5a7c",
  },
  {
    id: "cred-004",
    type: "MEMBERSHIP" as CredentialType,
    issuer: {
      name: "Arbitrum DAO",
      did: "did:ethr:arbitrum:0x9E1d3F5a7B9c2D4e6F8a0B2c4D6e8F0A2b4C6d8E",
      address: "0x9E1d3F5a7B9c2D4e6F8a0B2c4D6e8F0A2b4C6d8E",
    },
    holder: {
      did: "did:polygon:0x1a2B3c4D5e6F7890AbCdEf1234567890aBcDeF12",
      commitment: "0xabc123def456789",
    },
    claims: {
      role: "Core Contributor",
      joinedAt: "2023-06-01",
      votingPower: "125000",
      tier: "Platinum",
    },
    issuedAt: Date.now() - 180 * 24 * 60 * 60 * 1000,
    expiresAt: Date.now() + 185 * 24 * 60 * 60 * 1000,
    status: "ACTIVE" as CredentialStatus,
    revocationNonce: 512,
    commitmentHash: "0x8b2d4f6a8c1e3b5d7f9a2c4e6b8d1f3a5c7e9b2d4f6a8c1e3b5d7f9a2c4e6b8d",
  },
  {
    id: "cred-005",
    type: "CERTIFICATION" as CredentialType,
    issuer: {
      name: "State Bar Association",
      did: "did:web:statebar.example.com",
      address: "0x2C4d6E8f0A2b4C6d8E0f2A4b6C8d0E2f4A6b8C0d",
    },
    holder: {
      did: "did:polygon:0x1a2B3c4D5e6F7890AbCdEf1234567890aBcDeF12",
      commitment: "0xabc123def456789",
    },
    claims: {
      licenseNumber: "BAR-2024-CA-45821",
      jurisdiction: "California",
      speciality: "Intellectual Property Law",
      status: "Active - Good Standing",
    },
    issuedAt: Date.now() - 60 * 24 * 60 * 60 * 1000,
    expiresAt: Date.now() + 305 * 24 * 60 * 60 * 1000,
    status: "ACTIVE" as CredentialStatus,
    revocationNonce: 789,
    commitmentHash: "0x1a3c5e7b9d1f3a5c7e9b1d3f5a7c9e1b3d5f7a9c1e3b5d7f9a1c3e5b7d9f1a",
  },
]

const defaultIssuers: Issuer[] = [
  {
    name: "Polygon ID Authority",
    did: "did:polygon:0x3a9E7fB8c2F24D7B9e6C4A1dEf2Bc8D5e9F1a3B7",
    address: "0x3a9E7fB8c2F24D7B9e6C4A1dEf2Bc8D5e9F1a3B7",
    credentialTypes: ["KYC" as CredentialType],
    isVerified: true,
    totalIssued: 45231,
  },
  {
    name: "MIT Registrar",
    did: "did:web:mit.edu:registrar",
    address: "0x8B4e7C2d1A5f9E3b6D8c4A2e7F1b5C3d9E6a8B2f",
    credentialTypes: ["EDUCATION" as CredentialType],
    isVerified: true,
    totalIssued: 12847,
  },
  {
    name: "Amazon Web Services",
    did: "did:web:aws.amazon.com:certification",
    address: "0x5D6f7A8b9C0d1E2f3A4b5C6d7E8f9A0b1C2d3E4f",
    credentialTypes: ["CERTIFICATION" as CredentialType],
    isVerified: true,
    totalIssued: 98412,
  },
  {
    name: "Arbitrum DAO",
    did: "did:ethr:arbitrum:0x9E1d3F5a7B9c2D4e6F8a0B2c4D6e8F0A2b4C6d8E",
    address: "0x9E1d3F5a7B9c2D4e6F8a0B2c4D6e8F0A2b4C6d8E",
    credentialTypes: ["MEMBERSHIP" as CredentialType],
    isVerified: true,
    totalIssued: 5682,
  },
]

const defaultVerificationRequests: SelectiveDisclosureRequest[] = [
  {
    requestedAttributes: ["dateOfBirth", "nationality"],
    predicates: [{ field: "age", operator: "gte", value: 18 }],
    proofRequirements: { proofType: "sp1" },
  },
  {
    requestedAttributes: ["degree", "gpa"],
    predicates: [{ field: "gpa", operator: "gte", value: 3.5 }],
    proofRequirements: { proofType: "groth16" },
  },
]

export const useStore = create<AppState>((set) => ({
  wallet: {
    address: "0x1a2B3c4D5e6F7890AbCdEf1234567890aBcDeF12",
    chainId: 137,
    connected: false,
    credentials: defaultCredentials.map((c) => c.id),
    balance: "2.458",
  },
  credentials: defaultCredentials,
  issuers: defaultIssuers,
  verificationRequests: defaultVerificationRequests,
  generatedProofs: [],
  lastVerificationResult: null,

  connectWallet: () =>
    set((state) => ({
      wallet: { ...state.wallet, connected: true },
    })),

  disconnectWallet: () =>
    set((state) => ({
      wallet: { ...state.wallet, connected: false },
    })),

  addCredential: (credential) =>
    set((state) => ({
      credentials: [...state.credentials, credential],
      wallet: {
        ...state.wallet,
        credentials: [...state.wallet.credentials, credential.id],
      },
    })),

  revokeCredential: (id) =>
    set((state) => ({
      credentials: state.credentials.map((c) =>
        c.id === id ? { ...c, status: "REVOKED" as CredentialStatus } : c
      ),
    })),

  submitProof: (proof) =>
    set((state) => ({
      generatedProofs: [...state.generatedProofs, proof],
    })),

  verifyProof: (proof) =>
    set(() => ({
      lastVerificationResult: {
        isValid: true,
        verifiedClaims: {
          proofType: proof.proofType,
          verificationKey: proof.verificationKey.slice(0, 16) + "...",
          publicSignals: `${proof.publicSignals.length} signals verified`,
        },
        proofType: proof.proofType,
        timestamp: Date.now(),
      },
    })),
}))
