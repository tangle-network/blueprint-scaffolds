import type { Credential, CredentialType, Issuer } from '../types';
import { computeAttributeCommitment } from '../crypto';

const STORAGE_KEY = 'zk-identity-state';

interface AppState {
  credentials: Credential[];
  issuers: Issuer[];
  revokedIds: string[];
}

function loadState(): AppState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return { credentials: [], issuers: [], revokedIds: [] };
}

function saveState(state: AppState) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

export function storeCredential(credential: Credential): void {
  const state = loadState();
  state.credentials.push(credential);
  saveState(state);
}

export function getCredentials(): Credential[] {
  return loadState().credentials.filter(
    (c) => !loadState().revokedIds.includes(c.id)
  );
}

export function getAllCredentials(): Credential[] {
  return loadState().credentials;
}

export function revokeCredential(credentialId: string, reason: string): void {
  const state = loadState();
  state.revokedIds.push(credentialId);
  const cred = state.credentials.find((c) => c.id === credentialId);
  if (cred) cred.revoked = true;
  saveState(state);
}

export function isRevoked(credentialId: string): boolean {
  return loadState().revokedIds.includes(credentialId);
}

export function registerIssuer(issuer: Issuer): void {
  const state = loadState();
  const exists = state.issuers.find((i) => i.address === issuer.address);
  if (!exists) state.issuers.push(issuer);
  saveState(state);
}

export function getIssuers(): Issuer[] {
  return loadState().issuers;
}

export function issueCredential(
  issuer: Issuer,
  subjectAddress: string,
  credentialType: CredentialType,
  attributes: Record<string, string>,
  expiresInDays: number
): Credential {
  const blinding = BigInt(
    '0x' +
      Array.from(crypto.getRandomValues(new Uint8Array(32)))
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('')
  );

  const commitment = computeAttributeCommitment(attributes, blinding);
  const id =
    'cred_' +
    Array.from(crypto.getRandomValues(new Uint8Array(16)))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');

  const credential: Credential = {
    id,
    issuer: issuer.address,
    subject: subjectAddress,
    commitment: commitment.toString(),
    credentialType,
    attributes,
    issuedAt: Date.now(),
    expiresAt: Date.now() + expiresInDays * 86400000,
    revoked: false,
    merkleProof: [],
  };

  storeCredential(credential);
  return credential;
}

export function getCredentialsBySubject(subject: string): Credential[] {
  return getCredentials().filter((c) => c.subject === subject);
}

export function getCredentialsByIssuer(issuer: string): Credential[] {
  return getAllCredentials().filter((c) => c.issuer === issuer);
}
