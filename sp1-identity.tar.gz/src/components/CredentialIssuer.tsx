import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CredentialType, CREDENTIAL_TYPE_NAMES } from '../types';

const BADGE_CLASS: Record<CredentialType, string> = {
  [CredentialType.KYC]: 'badge-kyc',
  [CredentialType.EDUCATION]: 'badge-education',
  [CredentialType.CERTIFICATION]: 'badge-certification',
  [CredentialType.MEMBERSHIP]: 'badge-membership',
};

const CREDENTIAL_ATTRIBUTES: Record<CredentialType, string[]> = {
  [CredentialType.KYC]: ['fullName', 'dateOfBirth', 'nationality', 'idNumber'],
  [CredentialType.EDUCATION]: ['institution', 'degree', 'fieldOfStudy', 'graduationYear'],
  [CredentialType.CERTIFICATION]: ['certName', 'issuingBody', 'validFrom', 'validUntil'],
  [CredentialType.MEMBERSHIP]: ['organization', 'membershipLevel', 'memberSince', 'status'],
};

export default function CredentialIssuer() {
  const { identity, issueCredential, refreshCredentials } = useApp();
  const [credentialType, setCredentialType] = useState<CredentialType>(CredentialType.KYC);
  const [subject, setSubject] = useState('');
  const [attributes, setAttributes] = useState<Record<string, string>>({});
  const [expiresInDays, setExpiresInDays] = useState('365');
  const [issued, setIssued] = useState(false);

  if (!identity) {
    return (
      <div className="card">
        <h3>Issue Credential</h3>
        <div className="empty-state">
          <p>Connect your wallet to issue credentials</p>
        </div>
      </div>
    );
  }

  const handleIssue = () => {
    if (!subject) return;
    const filledAttrs: Record<string, string> = {};
    for (const key of CREDENTIAL_ATTRIBUTES[credentialType]) {
      if (attributes[key]) filledAttrs[key] = attributes[key];
    }
    issueCredential(subject, credentialType, filledAttrs, parseInt(expiresInDays) || 365);
    setIssued(true);
    setAttributes({});
    setSubject('');
    refreshCredentials();
    setTimeout(() => setIssued(false), 3000);
  };

  return (
    <div className="card fade-in">
      <h3>Issue Credential</h3>

      {issued && (
        <div className="verification-result valid" style={{ marginBottom: 16 }}>
          Credential issued successfully!
        </div>
      )}

      <div className="input-group">
        <label>Subject Address</label>
        <input
          placeholder="0x..."
          value={subject}
          onChange={e => setSubject(e.target.value)}
        />
      </div>

      <div className="input-group">
        <label>Credential Type</label>
        <select value={credentialType} onChange={e => setCredentialType(Number(e.target.value))}>
          {Object.entries(CREDENTIAL_TYPE_NAMES).map(([value, name]) => (
            <option key={value} value={value}>{name}</option>
          ))}
        </select>
      </div>

      <div className="input-group">
        <label>Expires In (days)</label>
        <input
          type="number"
          value={expiresInDays}
          onChange={e => setExpiresInDays(e.target.value)}
        />
      </div>

      {CREDENTIAL_ATTRIBUTES[credentialType].map(attr => (
        <div className="input-group" key={attr}>
          <label>{attr}</label>
          <input
            placeholder={`Enter ${attr}`}
            value={attributes[attr] ?? ''}
            onChange={e => setAttributes(prev => ({ ...prev, [attr]: e.target.value }))}
          />
        </div>
      ))}

      <button className="btn btn-primary mt-2" onClick={handleIssue} disabled={!subject}>
        Issue Credential
      </button>
    </div>
  );
}
