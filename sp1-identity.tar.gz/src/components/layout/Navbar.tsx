import { Link, useLocation } from "react-router-dom"
import { Shield, Wallet } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useStore } from "@/store/useStore"

const navLinks = [
  { to: "/", label: "Dashboard" },
  { to: "/credentials", label: "Credentials" },
  { to: "/verify", label: "Verify" },
  { to: "/issuers", label: "Issuers" },
]

export function Navbar() {
  const location = useLocation()
  const { wallet, connectWallet, disconnectWallet } = useStore()

  const truncatedAddress = wallet.connected
    ? `${wallet.address.slice(0, 6)}...${wallet.address.slice(-4)}`
    : null

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-6">
          <Link to="/" className="flex items-center gap-2">
            <Shield className="h-6 w-6 text-primary" />
            <span className="text-lg font-bold tracking-tight">
              ZK Identity
            </span>
            <span className="hidden sm:inline-block rounded-md bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">
              SP1
            </span>
          </Link>
          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  location.pathname === link.to
                    ? "bg-accent text-accent-foreground"
                    : "text-muted-foreground hover:text-foreground hover:bg-accent/50"
                }`}
              >
                {link.label}
              </Link>
            ))}
          </nav>
        </div>

        <div className="flex items-center gap-2">
          {wallet.connected ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="gap-2">
                  <Wallet className="h-4 w-4 text-green-500" />
                  <span className="font-mono text-xs">{truncatedAddress}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-mono">{wallet.address}</p>
                    <p className="text-xs text-muted-foreground">
                      Chain: {wallet.chainId} | Balance: {wallet.balance} MATIC
                    </p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  {wallet.credentials.length} Credentials
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={disconnectWallet}>
                  Disconnect Wallet
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button onClick={connectWallet} size="sm" className="gap-2">
              <Wallet className="h-4 w-4" />
              Connect Wallet
            </Button>
          )}
        </div>
      </div>
    </header>
  )
}
