import { Link, useLocation } from "react-router-dom"
import { Shield, FileCheck, Scan, Users, Settings } from "lucide-react"
import { cn } from "@/lib/utils"

const sidebarLinks = [
  { to: "/", label: "Dashboard", icon: Shield },
  { to: "/credentials", label: "Credentials", icon: FileCheck },
  { to: "/verify", label: "Verify", icon: Scan },
  { to: "/issuers", label: "Issuers", icon: Users },
  { to: "/settings", label: "Settings", icon: Settings },
]

export function Sidebar() {
  const location = useLocation()

  return (
    <aside className="hidden lg:flex h-[calc(100vh-4rem)] w-64 flex-col border-r bg-background">
      <nav className="flex-1 space-y-1 p-4">
        {sidebarLinks.map((link) => {
          const isActive =
            link.to === "/"
              ? location.pathname === "/"
              : location.pathname.startsWith(link.to)
          return (
            <Link
              key={link.to}
              to={link.to}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                isActive
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:bg-accent hover:text-foreground"
              )}
            >
              <link.icon className={cn("h-5 w-5", isActive && "text-primary")} />
              {link.label}
            </Link>
          )
        })}
      </nav>
      <div className="p-4 border-t">
        <div className="rounded-lg bg-muted/50 p-3">
          <p className="text-xs font-medium text-muted-foreground">
            ZK Identity SP1
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Privacy-preserving credentials powered by Succinct SP1
          </p>
        </div>
      </div>
    </aside>
  )
}
