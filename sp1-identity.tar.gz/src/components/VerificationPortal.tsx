import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CREDENTIAL_TYPE_NAMES } from '../types';
import type { SelectiveDisclosure, VerificationResult } from '../types';

export default function VerificationPortal() {
  const { credentials, generateProof, verifyProof } = useApp();
  const [selectedCred, setSelectedCred] = useState('');
  const [verifier, setVerifier] = useState('0xA11ce...Verifier');
  const [selectedAttrs, setSelectedAttrs] = useState<Set<string>>(new Set());
  const [disclosure, setDisclosure] = useState<SelectiveDisclosure | null>(null);
  const [verificationResult, setVerificationResult] = useState<VerificationResult | null>(null);

  const credential = credentials.find(c => c.id === selectedCred);

  const toggleAttr = (attr: string) => {
    const next = new Set(selectedAttrs);
    if (next.has(attr)) next.delete(attr);
    else next.add(attr);
    setSelectedAttrs(next);
  };

  const handleGenerate = () => {
    if (!selectedCred || selectedAttrs.size === 0) return;
    const proof = generateProof(selectedCred, Array.from(selectedAttrs), verifier);
    if (proof) {
      setDisclosure(proof);
      setVerificationResult(null);
    }
  };

  const handleVerify = () => {
    if (!disclosure) return;
    const result = verifyProof(disclosure);
    setVerificationResult(result);
  };

  const validCredentials = credentials.filter(c => !c.revoked);

  return (
    <div className="card fade-in">
      <h3>ZK Verification Portal</h3>

      <div className="input-group">
        <label>Select Credential</label>
        <select value={selectedCred} onChange={e => { setSelectedCred(e.target.value); setSelectedAttrs(new Set()); setDisclosure(null); }}>
          <option value="">Choose a credential...</option>
          {validCredentials.map(c => (
            <option key={c.id} value={c.id}>
              {CREDENTIAL_TYPE_NAMES[c.credentialType]} — {c.id.slice(0, 16)}...
            </option>
          ))}
        </select>
      </div>

      {credential && (
        <div className="mb-2">
          <label style={{ fontSize: 13, color: 'var(--text-secondary)', display: 'block', marginBottom: 8 }}>
            Select attributes to reveal (Selective Disclosure)
          </label>
          <div className="row" style={{ flexWrap: 'wrap' }}>
            {Object.keys(credential.attributes).map(attr => (
              <button
                key={attr}
                className={`btn btn-sm ${selectedAttrs.has(attr) ? 'btn-primary' : 'btn-secondary'}`}
                onClick={() => toggleAttr(attr)}
              >
                {attr}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="input-group">
        <label>Verifier Address</label>
        <input value={verifier} onChange={e => setVerifier(e.target.value)} />
      </div>

      <div className="row mt-1">
        <button
          className="btn btn-primary"
          onClick={handleGenerate}
          disabled={!selectedCred || selectedAttrs.size === 0}
        >
          Generate ZK Proof
        </button>
        <button
          className="btn btn-success"
          onClick={handleVerify}
          disabled={!disclosure}
        >
          Verify Proof
        </button>
      </div>

      {disclosure && (
        <div className="mt-2">
          <h4 style={{ fontSize: 14, color: 'var(--accent-light)', marginBottom: 8 }}>Generated Proof</h4>
          <div className="proof-display">
            <div><strong>Proof:</strong> {disclosure.proof}</div>
            <div className="mt-1"><strong>Nullifier:</strong> {disclosure.publicSignals[1]}</div>
            <div className="mt-1"><strong>Revealed Hash:</strong> {disclosure.publicSignals[2]}</div>
            <div className="mt-1"><strong>Predicates Satisfied:</strong> {disclosure.publicSignals[3]}</div>
          </div>
        </div>
      )}

      {verificationResult && (
        <div className={`verification-result ${verificationResult.valid ? 'valid' : 'invalid'} mt-2`}>
          <strong>{verificationResult.valid ? 'VERIFIED' : 'VERIFICATION FAILED'}</strong>
          <div className="mt-1" style={{ fontSize: 13 }}>
            Predicates satisfied: {verificationResult.satisfiesPredicates ? 'Yes' : 'No'} |
            Not revoked: {verificationResult.notRevoked ? 'Yes' : 'No'}
          </div>
        </div>
      )}
    </div>
  );
}
