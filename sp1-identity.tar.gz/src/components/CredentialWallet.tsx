import { useApp } from '../context/AppContext';
import { CredentialType, CREDENTIAL_TYPE_NAMES } from '../types';

const BADGE_CLASS: Record<CredentialType, string> = {
  [CredentialType.KYC]: 'badge-kyc',
  [CredentialType.EDUCATION]: 'badge-education',
  [CredentialType.CERTIFICATION]: 'badge-certification',
  [CredentialType.MEMBERSHIP]: 'badge-membership',
};

export default function CredentialWallet() {
  const { credentials, revokeCredential } = useApp();

  if (credentials.length === 0) {
    return (
      <div className="card">
        <h3>My Credentials</h3>
        <div className="empty-state">
          <p>No credentials yet</p>
          <p style={{ fontSize: 13 }}>Issue or receive a credential to get started</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <h3 className="section-title">My Credentials ({credentials.length})</h3>
      <div className="grid">
        {credentials.map(cred => (
          <div key={cred.id} className="card fade-in">
            <div className="row" style={{ justifyContent: 'space-between' }}>
              <span className={`badge ${BADGE_CLASS[cred.credentialType]}`}>
                {CREDENTIAL_TYPE_NAMES[cred.credentialType]}
              </span>
              {cred.revoked && (
                <span className="badge" style={{ background: '#e1705530', color: 'var(--danger)' }}>
                  REVOKED
                </span>
              )}
            </div>

            <div className="mt-1" style={{ fontSize: 12, color: 'var(--text-secondary)', fontFamily: 'monospace' }}>
              ID: {cred.id.slice(0, 20)}...
            </div>
            <div style={{ fontSize: 12, color: 'var(--text-secondary)', fontFamily: 'monospace' }}>
              Commitment: {cred.commitment.slice(0, 14)}...
            </div>

            <div className="credential-attrs">
              {Object.entries(cred.attributes).map(([key, value]) => (
                <div key={key} className="attr-tag">
                  {key}: <span>{value}</span>
                </div>
              ))}
            </div>

            <div className="row mt-2" style={{ justifyContent: 'space-between' }}>
              <span style={{ fontSize: 11, color: 'var(--text-secondary)' }}>
                Expires: {new Date(cred.expiresAt).toLocaleDateString()}
              </span>
              {!cred.revoked && (
                <button
                  className="btn btn-danger btn-sm"
                  onClick={() => revokeCredential(cred.id)}
                >
                  Revoke
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
