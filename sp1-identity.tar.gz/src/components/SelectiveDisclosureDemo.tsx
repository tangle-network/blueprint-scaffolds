import { useState } from 'react';
import { useApp } from '../context/AppContext';
import type { SelectiveDisclosure } from '../types';
import { CREDENTIAL_TYPE_NAMES, CredentialType } from '../types';

const CREDENTIAL_ATTRIBUTES: Record<CredentialType, string[]> = {
  [CredentialType.KYC]: ['fullName', 'dateOfBirth', 'nationality', 'idNumber'],
  [CredentialType.EDUCATION]: ['institution', 'degree', 'fieldOfStudy', 'graduationYear'],
  [CredentialType.CERTIFICATION]: ['certName', 'issuingBody', 'validFrom', 'validUntil'],
  [CredentialType.MEMBERSHIP]: ['organization', 'membershipLevel', 'memberSince', 'status'],
};

const AGE_FIELDS = ['dateOfBirth', 'graduationYear', 'memberSince'];

export default function SelectiveDisclosureDemo() {
  const { credentials, generateProof, verifyProof } = useApp();
  const [ageThreshold, setAgeThreshold] = useState('18');
  const [selectedCredId, setSelectedCredId] = useState('');
  const [ageProof, setAgeProof] = useState<SelectiveDisclosure | null>(null);
  const [verified, setVerified] = useState<boolean | null>(null);

  const credential = credentials.find(c => c.id === selectedCredId);
  const ageField = credential
    ? Object.keys(credential.attributes).find(k => AGE_FIELDS.includes(k))
    : null;

  const handleAgeProof = () => {
    if (!selectedCredId || !ageField) return;
    const proof = generateProof(selectedCredId, [ageField], '0xVerifier...AgeCheck');
    if (proof) {
      setAgeProof(proof);
      setVerified(null);
    }
  };

  const handleVerify = () => {
    if (!ageProof) return;
    const result = verifyProof(ageProof);
    setVerified(result.valid);
  };

  const validCredentials = credentials.filter(c => !c.revoked);

  return (
    <div className="card fade-in">
      <h3>Selective Disclosure — Age Verification</h3>
      <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginBottom: 16 }}>
        Prove age &gt; {ageThreshold} without revealing your date of birth or other attributes.
      </p>

      <div className="input-group">
        <label>Select Credential</label>
        <select value={selectedCredId} onChange={e => { setSelectedCredId(e.target.value); setAgeProof(null); setVerified(null); }}>
          <option value="">Choose...</option>
          {validCredentials.map(c => (
            <option key={c.id} value={c.id}>
              {CREDENTIAL_TYPE_NAMES[c.credentialType]}
            </option>
          ))}
        </select>
      </div>

      <div className="input-group">
        <label>Age Threshold</label>
        <input type="number" value={ageThreshold} onChange={e => setAgeThreshold(e.target.value)} />
      </div>

      <div className="row mt-1">
        <button className="btn btn-primary" onClick={handleAgeProof} disabled={!selectedCredId || !ageField}>
          Generate Age Proof
        </button>
        <button className="btn btn-success" onClick={handleVerify} disabled={!ageProof}>
          Verify
        </button>
      </div>

      {ageProof && (
        <div className="mt-2">
          <div className="proof-display">
            <strong>ZK Age Proof:</strong>
            <div className="mt-1">Commitment: {ageProof.publicSignals[0]?.slice(0, 20)}...</div>
            <div>Nullifier: {ageProof.publicSignals[1]?.slice(0, 20)}...</div>
            <div>Revealed: only "{ageField}" — other attributes hidden</div>
            <div>Predicates met: {ageProof.publicSignals[3]}</div>
          </div>
        </div>
      )}

      {verified !== null && (
        <div className={`verification-result ${verified ? 'valid' : 'invalid'} mt-2`}>
          {verified
            ? `Age >= ${ageThreshold} VERIFIED — no other data exposed`
            : `Age >= ${ageThreshold} COULD NOT be verified`}
        </div>
      )}
    </div>
  );
}
