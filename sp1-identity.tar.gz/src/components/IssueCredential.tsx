import React, { useState } from 'react';
import { ethers } from 'ethers';
import { useContracts } from '../hooks/useContracts';
import { useWallet } from '../hooks/useWallet';
import { CredentialType, CREDENTIAL_TYPE_LABELS } from '../types';
import { AttributeMerkleTree, computePedersenCommitment } from '../utils/crypto';

const CRED_TYPES: CredentialType[] = ['KYC', 'Education', 'Certification', 'Membership'];

const ATTRIBUTE_TEMPLATES: Record<CredentialType, string[]> = {
  KYC: ['fullName', 'dateOfBirth', 'nationality', 'idNumber'],
  Education: ['institution', 'degree', 'graduationYear', 'gpa'],
  Certification: ['certName', 'issuingOrg', 'issueDate', 'expiryDate'],
  Membership: ['organization', 'memberId', 'tier', 'sinceDate'],
};

export const IssueCredential: React.FC = () => {
  const { wallet, signer } = useWallet();
  const { credentialRegistry } = useContracts(signer, wallet.chainId);

  const [subject, setSubject] = useState('');
  const [credType, setCredType] = useState<CredentialType>('KYC');
  const [attributes, setAttributes] = useState<Record<string, string>>({});
  const [expiryDays, setExpiryDays] = useState('365');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ credentialId: string; commitment: string } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const currentFields = ATTRIBUTE_TEMPLATES[credType];

  const handleAttributeChange = (field: string, value: string) => {
    setAttributes((prev) => ({ ...prev, [field]: value }));
  };

  const handleIssue = async () => {
    if (!credentialRegistry || !wallet.address) return;
    if (!ethers.isAddress(subject)) {
      setError('Invalid subject address');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const filledAttrs: Record<string, string> = {};
      for (const field of currentFields) {
        const val = attributes[field];
        if (!val || val.trim() === '') {
          setError(`Missing attribute: ${field}`);
          setLoading(false);
          return;
        }
        filledAttrs[field] = val;
      }

      const blindingFactor = `bf_${Date.now()}_${Math.random().toString(36).slice(2)}`;
      const { commitment } = computePedersenCommitment(filledAttrs, blindingFactor);

      const tree = new AttributeMerkleTree();
      for (const [key, value] of Object.entries(filledAttrs)) {
        tree.addAttribute(key, value);
      }
      const merkleRoot = tree.getRoot();

      const expiresAt = Math.floor(Date.now() / 1000) + parseInt(expiryDays) * 86400;
      const credTypeIndex = CRED_TYPES.indexOf(credType);

      const tx = await credentialRegistry.issueCredential(
        subject,
        credTypeIndex,
        '0x' + commitment.toString(16).padStart(64, '0'),
        '0x' + merkleRoot.toString(16).padStart(64, '0'),
        expiresAt
      );
      await tx.wait();

      const receipt = await tx.wait();
      const event = receipt.logs
        .map((log: unknown) => {
          try {
            return credentialRegistry.interface.parseLog(log as { topics: string[]; data: string });
          } catch {
            return null;
          }
        })
        .find((e: unknown) => e !== null);

      const credentialId = event?.args?.credentialId ?? ethers.id(JSON.stringify(filledAttrs) + Date.now());

      setResult({
        credentialId: typeof credentialId === 'string' ? credentialId : ethers.id('mock'),
        commitment: commitment.toString(16),
      });
      setAttributes({});
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to issue credential');
    } finally {
      setLoading(false);
    }
  };

  if (!wallet.connected) {
    return (
      <div className="bg-white rounded-xl shadow-sm border p-6 text-center text-gray-500">
        Connect your wallet to issue credentials.
      </div>
    );
  }

  if (!wallet.isIssuer) {
    return (
      <div className="bg-white rounded-xl shadow-sm border p-6 text-center text-gray-500">
        You are not registered as an issuer. Contact an admin to register.
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border p-6 space-y-6">
      <h2 className="text-xl font-bold text-gray-900">Issue Credential</h2>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Subject Address</label>
        <input
          type="text"
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          placeholder="0x..."
          className="w-full border rounded-lg px-3 py-2 text-sm font-mono focus:ring-2 focus:ring-zk-500 focus:border-transparent"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Credential Type</label>
        <select
          value={credType}
          onChange={(e) => {
            setCredType(e.target.value as CredentialType);
            setAttributes({});
          }}
          className="w-full border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-zk-500"
        >
          {CRED_TYPES.map((t) => (
            <option key={t} value={t}>
              {CREDENTIAL_TYPE_LABELS[t]}
            </option>
          ))}
        </select>
      </div>

      <div className="space-y-3">
        <label className="block text-sm font-medium text-gray-700">Attributes</label>
        {currentFields.map((field) => (
          <div key={field}>
            <label className="block text-xs text-gray-500 mb-1">{field}</label>
            <input
              type="text"
              value={attributes[field] ?? ''}
              onChange={(e) => handleAttributeChange(field, e.target.value)}
              placeholder={`Enter ${field}`}
              className="w-full border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-zk-500 focus:border-transparent"
            />
          </div>
        ))}
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Validity (days)</label>
        <input
          type="number"
          value={expiryDays}
          onChange={(e) => setExpiryDays(e.target.value)}
          min="1"
          className="w-full border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-zk-500"
        />
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg p-3">
          {error}
        </div>
      )}

      {result && (
        <div className="bg-green-50 border border-green-200 text-green-700 text-sm rounded-lg p-3 space-y-1">
          <p className="font-medium">Credential issued successfully!</p>
          <p className="font-mono text-xs break-all">ID: {result.credentialId}</p>
          <p className="font-mono text-xs break-all">Commitment: 0x{result.commitment}</p>
        </div>
      )}

      <button
        onClick={handleIssue}
        disabled={loading}
        className="w-full bg-zk-600 hover:bg-zk-700 disabled:opacity-50 text-white font-medium py-2.5 rounded-lg transition-colors"
      >
        {loading ? 'Issuing...' : 'Issue Credential'}
      </button>
    </div>
  );
};
