import { type Credential, CredentialType, CredentialStatus } from "@/types/identity"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Clock, Hash } from "lucide-react"

const typeColors: Record<CredentialType, string> = {
  [CredentialType.KYC]: "bg-blue-600 text-white border-transparent",
  [CredentialType.EDUCATION]: "bg-green-600 text-white border-transparent",
  [CredentialType.CERTIFICATION]: "bg-purple-600 text-white border-transparent",
  [CredentialType.MEMBERSHIP]: "bg-orange-600 text-white border-transparent",
}

const statusColors: Record<CredentialStatus, "success" | "destructive" | "warning" | "secondary"> = {
  [CredentialStatus.ACTIVE]: "success",
  [CredentialStatus.REVOKED]: "destructive",
  [CredentialStatus.EXPIRED]: "warning",
  [CredentialStatus.PENDING]: "secondary",
}

function formatExpiry(expiresAt: number): string {
  const now = Date.now()
  const diff = expiresAt - now
  if (diff <= 0) return "Expired"
  const days = Math.floor(diff / (24 * 60 * 60 * 1000))
  if (days > 365) return `${Math.floor(days / 365)}y ${days % 365}d`
  return `${days}d`
}

function formatKey(key: string): string {
  return key.replace(/([A-Z])/g, " $1").replace(/^./, (s) => s.toUpperCase())
}

export function CredentialCard({ credential }: { credential: Credential }) {
  const typeBadgeClass = typeColors[credential.type]
  const statusVariant = statusColors[credential.status]

  return (
    <Card className="hover:border-primary/50 transition-colors">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <CardTitle className="text-base">{credential.issuer.name}</CardTitle>
            <CardDescription className="font-mono text-xs">
              {credential.issuer.did.slice(0, 40)}...
            </CardDescription>
          </div>
          <div className="flex flex-col gap-2">
            <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${typeBadgeClass}`}>
              {credential.type}
            </span>
            <Badge variant={statusVariant}>{credential.status}</Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <Separator />
        <div className="space-y-2">
          {Object.entries(credential.claims).map(([key, value]) => (
            <div key={key} className="flex justify-between text-sm">
              <span className="text-muted-foreground">{formatKey(key)}</span>
              <span className="font-medium text-right max-w-[60%] truncate">{value}</span>
            </div>
          ))}
        </div>
        <Separator />
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            <span>Expires in {formatExpiry(credential.expiresAt)}</span>
          </div>
          <div className="flex items-center gap-1">
            <Hash className="h-3 w-3" />
            <span className="font-mono">
              {credential.commitmentHash.slice(0, 10)}...{credential.commitmentHash.slice(-6)}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
