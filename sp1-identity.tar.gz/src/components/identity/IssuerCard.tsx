import { type Issuer, CredentialType } from "@/types/identity"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { CheckCircle2, FileCheck, Hash } from "lucide-react"

const typeBadgeColors: Record<string, string> = {
  [CredentialType.KYC]: "bg-blue-600/20 text-blue-400 border-blue-600/30",
  [CredentialType.EDUCATION]: "bg-green-600/20 text-green-400 border-green-600/30",
  [CredentialType.CERTIFICATION]: "bg-purple-600/20 text-purple-400 border-purple-600/30",
  [CredentialType.MEMBERSHIP]: "bg-orange-600/20 text-orange-400 border-orange-600/30",
}

export function IssuerCard({ issuer }: { issuer: Issuer }) {
  return (
    <Card className="hover:border-primary/50 transition-colors">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
              <Hash className="h-5 w-5 text-primary" />
            </div>
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                {issuer.name}
                {issuer.isVerified && (
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                )}
              </CardTitle>
              <p className="text-xs font-mono text-muted-foreground mt-0.5">
                {issuer.did.slice(0, 42)}...
              </p>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <Separator />
        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
            Supported Credentials
          </p>
          <div className="flex flex-wrap gap-2">
            {issuer.credentialTypes.map((type) => (
              <span
                key={type}
                className={`inline-flex items-center rounded-md border px-2 py-0.5 text-xs font-medium ${typeBadgeColors[type]}`}
              >
                <FileCheck className="h-3 w-3 mr-1" />
                {type}
              </span>
            ))}
          </div>
        </div>
        <Separator />
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Total Issued</span>
          <Badge variant="secondary">
            {issuer.totalIssued.toLocaleString()}
          </Badge>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Status</span>
          <Badge variant="success">
            {issuer.isVerified ? "Verified" : "Unverified"}
          </Badge>
        </div>
      </CardContent>
    </Card>
  )
}
