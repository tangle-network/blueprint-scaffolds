import { useState } from "react"
import { useStore } from "@/store/useStore"
import { type ZKProof, type Predicate } from "@/types/identity"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { Zap, Plus, Trash2, Loader2 } from "lucide-react"

export function ZKProofGenerator() {
  const { credentials, submitProof } = useStore()
  const [open, setOpen] = useState(false)
  const [selectedCredId, setSelectedCredId] = useState("")
  const [revealedAttrs, setRevealedAttrs] = useState<Record<string, boolean>>({})
  const [predicates, setPredicates] = useState<Predicate[]>([])
  const [proofType, setProofType] = useState<"groth16" | "sp1">("sp1")
  const [generating, setGenerating] = useState(false)
  const [progress, setProgress] = useState(0)

  const selectedCred = credentials.find((c) => c.id === selectedCredId)

  const handleSelectCredential = (id: string) => {
    setSelectedCredId(id)
    const cred = credentials.find((c) => c.id === id)
    if (cred) {
      const attrs: Record<string, boolean> = {}
      Object.keys(cred.claims).forEach((k) => {
        attrs[k] = false
      })
      setRevealedAttrs(attrs)
    }
  }

  const toggleAttr = (key: string) => {
    setRevealedAttrs((prev) => ({ ...prev, [key]: !prev[key] }))
  }

  const addPredicate = () => {
    setPredicates((prev) => [...prev, { field: "", operator: "gte", value: "" }])
  }

  const removePredicate = (index: number) => {
    setPredicates((prev) => prev.filter((_, i) => i !== index))
  }

  const updatePredicate = (index: number, partial: Partial<Predicate>) => {
    setPredicates((prev) =>
      prev.map((p, i) => (i === index ? { ...p, ...partial } : p))
    )
  }

  const estimatedTime = proofType === "sp1" ? "~8-12s" : "~3-5s"

  const handleGenerate = async () => {
    if (!selectedCred) return
    setGenerating(true)
    setProgress(0)

    const steps = proofType === "sp1" ? 10 : 6
    for (let i = 0; i <= steps; i++) {
      await new Promise((r) => setTimeout(r, 500))
      setProgress((i / steps) * 100)
    }

    const proof: ZKProof = {
      proof: `0x${Array.from({ length: 64 }, () =>
        Math.floor(Math.random() * 16).toString(16)
      ).join("")}`,
      publicSignals: Object.entries(revealedAttrs)
        .filter(([, v]) => v)
        .map(([k]) => `${k}:revealed`),
      verificationKey: selectedCred.commitmentHash.slice(0, 32),
      proofType,
    }

    submitProof(proof)
    setGenerating(false)
    setProgress(0)
    setOpen(false)
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2">
          <Zap className="h-4 w-4" />
          Generate ZK Proof
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Generate Zero-Knowledge Proof</DialogTitle>
          <DialogDescription>
            Create a selective disclosure proof that reveals only specific
            attributes while keeping the rest private.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <label className="text-sm font-medium">Select Credential</label>
            <Select value={selectedCredId} onValueChange={handleSelectCredential}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a credential..." />
              </SelectTrigger>
              <SelectContent>
                {credentials
                  .filter((c) => c.status === "ACTIVE")
                  .map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.type} - {c.issuer.name}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>

          {selectedCred && (
            <>
              <div className="space-y-2">
                <label className="text-sm font-medium">
                  Attributes to Reveal
                </label>
                <div className="space-y-2 rounded-lg border p-3">
                  {Object.entries(revealedAttrs).map(([key, revealed]) => (
                    <div
                      key={key}
                      className="flex items-center justify-between"
                    >
                      <span className="text-sm">{key}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground">
                          {revealed ? "Revealed" : "Hidden"}
                        </span>
                        <Switch
                          checked={revealed}
                          onCheckedChange={() => toggleAttr(key)}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Predicates</label>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={addPredicate}
                    className="h-7 gap-1 text-xs"
                  >
                    <Plus className="h-3 w-3" />
                    Add
                  </Button>
                </div>
                {predicates.map((pred, i) => (
                  <div key={i} className="flex gap-2 items-end">
                    <Input
                      placeholder="Field"
                      value={pred.field}
                      onChange={(e) =>
                        updatePredicate(i, { field: e.target.value })
                      }
                      className="flex-1"
                    />
                    <Select
                      value={pred.operator}
                      onValueChange={(v) =>
                        updatePredicate(i, {
                          operator: v as Predicate["operator"],
                        })
                      }
                    >
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="eq">=</SelectItem>
                        <SelectItem value="gt">&gt;</SelectItem>
                        <SelectItem value="gte">&ge;</SelectItem>
                        <SelectItem value="lt">&lt;</SelectItem>
                        <SelectItem value="lte">&le;</SelectItem>
                        <SelectItem value="neq">&ne;</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input
                      placeholder="Value"
                      value={String(pred.value)}
                      onChange={(e) =>
                        updatePredicate(i, { value: e.target.value })
                      }
                      className="w-28"
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removePredicate(i)}
                      className="h-10 w-10 shrink-0"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>

              <Separator />

              <div className="space-y-2">
                <label className="text-sm font-medium">Proof Type</label>
                <div className="flex gap-2">
                  <Button
                    variant={proofType === "sp1" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setProofType("sp1")}
                  >
                    SP1 (Succinct)
                  </Button>
                  <Button
                    variant={proofType === "groth16" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setProofType("groth16")}
                  >
                    Groth16
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Estimated generation time: {estimatedTime}
                </p>
              </div>
            </>
          )}

          {generating && (
            <div className="space-y-2">
              <Progress value={progress} className="h-2" />
              <p className="text-xs text-center text-muted-foreground">
                Generating {proofType.toUpperCase()} proof... {Math.round(progress)}%
              </p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => setOpen(false)}
            disabled={generating}
          >
            Cancel
          </Button>
          <Button
            onClick={handleGenerate}
            disabled={!selectedCred || generating}
            className="gap-2"
          >
            {generating ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Zap className="h-4 w-4" />
                Generate Proof
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
