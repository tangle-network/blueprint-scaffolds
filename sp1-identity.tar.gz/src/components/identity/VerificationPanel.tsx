import { useState } from "react"
import { useStore } from "@/store/useStore"
import { type ZKProof } from "@/types/identity"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { CheckCircle2, XCircle, Shield, Fuel } from "lucide-react"

export function VerificationPanel() {
  const { lastVerificationResult, verifyProof } = useStore()
  const [proofJson, setProofJson] = useState("")

  const handleVerify = () => {
    try {
      const parsed = JSON.parse(proofJson) as ZKProof
      verifyProof(parsed)
    } catch {
      const mockProof: ZKProof = {
        proof: `0x${Array.from({ length: 64 }, () =>
          Math.floor(Math.random() * 16).toString(16)
        ).join("")}`,
        publicSignals: ["age_gte_18: true", "nationality: verified"],
        verificationKey: "0x7f2c8e4a1b6d3f9e5c7a2d8b4f1e6c3a",
        proofType: "sp1",
      }
      verifyProof(mockProof)
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-primary" />
            Proof Verification
          </CardTitle>
          <CardDescription>
            Paste a ZK proof JSON to verify its validity on-chain. Supports SP1
            and Groth16 proof formats.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Proof JSON</label>
            <textarea
              className="flex min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 font-mono"
              placeholder='{"proof":"0x...","publicSignals":[],"verificationKey":"0x...","proofType":"sp1"}'
              value={proofJson}
              onChange={(e) => setProofJson(e.target.value)}
            />
          </div>
          <Button onClick={handleVerify} className="w-full">
            Verify Proof
          </Button>
        </CardContent>
      </Card>

      {lastVerificationResult && (
        <Card
          className={
            lastVerificationResult.isValid
              ? "border-green-500/50"
              : "border-red-500/50"
          }
        >
          <CardHeader>
            <div className="flex items-center gap-3">
              {lastVerificationResult.isValid ? (
                <CheckCircle2 className="h-8 w-8 text-green-500" />
              ) : (
                <XCircle className="h-8 w-8 text-red-500" />
              )}
              <div>
                <CardTitle>
                  {lastVerificationResult.isValid
                    ? "Proof Verified"
                    : "Verification Failed"}
                </CardTitle>
                <CardDescription>
                  {lastVerificationResult.proofType.toUpperCase()} proof
                  verified at{" "}
                  {new Date(lastVerificationResult.timestamp).toLocaleString()}
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <Separator />
            <div className="space-y-3">
              <h4 className="text-sm font-medium">Verified Claims</h4>
              {Object.entries(lastVerificationResult.verifiedClaims).map(
                ([key, value]) => (
                  <div
                    key={key}
                    className="flex items-center justify-between rounded-lg bg-muted/50 px-3 py-2"
                  >
                    <span className="text-sm text-muted-foreground">{key}</span>
                    <span className="text-sm font-medium font-mono">{value}</span>
                  </div>
                )
              )}
            </div>
            <Separator />
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <Fuel className="h-4 w-4 text-muted-foreground" />
                <span className="text-muted-foreground">Gas Cost</span>
              </div>
              <Badge variant="secondary">
                {lastVerificationResult.proofType === "sp1"
                  ? "~350,000 gas"
                  : "~210,000 gas"}
              </Badge>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">
                SP1 Verification Key Hash
              </span>
              <span className="font-mono text-xs">
                0x4a7b2c1d...8e3f
              </span>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
