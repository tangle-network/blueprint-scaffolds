import { useApp } from '../context/AppContext';

export default function WalletConnect() {
  const { identity, isConnecting, connectWallet, disconnectWallet } = useApp();

  if (identity) {
    return (
      <div className="wallet-info">
        <span className="status-dot connected" />
        <span className="wallet-address">
          {identity.address.slice(0, 6)}...{identity.address.slice(-4)}
        </span>
        <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
          Commitment: {identity.commitment.slice(0, 10)}...
        </span>
        <button className="btn btn-secondary btn-sm" onClick={disconnectWallet}>
          Disconnect
        </button>
      </div>
    );
  }

  return (
    <button className="btn btn-primary" onClick={connectWallet} disabled={isConnecting}>
      {isConnecting ? 'Connecting...' : 'Connect Wallet'}
    </button>
  );
}
