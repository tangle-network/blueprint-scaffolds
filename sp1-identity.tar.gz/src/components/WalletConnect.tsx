import React from 'react';
import { useWallet } from '../hooks/useWallet';

export const WalletConnect: React.FC = () => {
  const { wallet, connect, disconnect, loading, error } = useWallet();

  return (
    <div className="flex items-center gap-4">
      {wallet.connected ? (
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-zk-50 border border-zk-200 rounded-lg px-3 py-2">
            <div className="w-2 h-2 rounded-full bg-green-500" />
            <span className="text-sm font-mono text-zk-800">
              {wallet.address?.slice(0, 6)}...{wallet.address?.slice(-4)}
            </span>
          </div>
          {wallet.isIssuer && (
            <span className="text-xs font-medium bg-green-100 text-green-800 px-2 py-1 rounded">
              Issuer
            </span>
          )}
          {wallet.isAdmin && (
            <span className="text-xs font-medium bg-amber-100 text-amber-800 px-2 py-1 rounded">
              Admin
            </span>
          )}
          <button
            onClick={disconnect}
            className="text-sm text-gray-500 hover:text-gray-700 underline"
          >
            Disconnect
          </button>
        </div>
      ) : (
        <div className="flex items-center gap-3">
          <button
            onClick={connect}
            disabled={loading}
            className="bg-zk-600 hover:bg-zk-700 disabled:opacity-50 text-white font-medium px-4 py-2 rounded-lg transition-colors"
          >
            {loading ? 'Connecting...' : 'Connect Wallet'}
          </button>
          {error && <span className="text-sm text-red-600">{error}</span>}
        </div>
      )}
    </div>
  );
};
