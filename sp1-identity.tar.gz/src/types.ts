export type CredentialType = 'KYC' | 'Education' | 'Certification' | 'Membership';

export type CredentialStatus = 'Active' | 'Revoked' | 'Expired';

export type IssuerStatus = 'None' | 'Active' | 'Suspended' | 'Revoked';

export interface Issuer {
  address: string;
  name: string;
  did: string;
  status: IssuerStatus;
  registeredAt: number;
  credentialCount: number;
}

export interface Credential {
  credentialId: string;
  issuer: string;
  subject: string;
  credType: CredentialType;
  status: CredentialStatus;
  commitment: string;
  merkleRoot: string;
  issuedAt: number;
  expiresAt: number;
}

export interface ZKProof {
  proofBytes: string;
  publicValues: string;
  proofType: 'age' | 'selectiveDisclosure' | 'membership';
}

export interface ProofVerification {
  verified: boolean;
  verifiedAt: number;
  proofHash: string;
}

export interface WalletState {
  address: string | null;
  chainId: number | null;
  connected: boolean;
  isIssuer: boolean;
  isAdmin: boolean;
}

export const CREDENTIAL_TYPE_LABELS: Record<CredentialType, string> = {
  KYC: 'KYC Attestation',
  Education: 'Education',
  Certification: 'Certification',
  Membership: 'Membership',
};

export const CREDENTIAL_TYPE_COLORS: Record<CredentialType, string> = {
  KYC: 'bg-blue-100 text-blue-800',
  Education: 'bg-green-100 text-green-800',
  Certification: 'bg-purple-100 text-purple-800',
  Membership: 'bg-orange-100 text-orange-800',
};

export const CREDENTIAL_TYPE_ICONS: Record<CredentialType, string> = {
  KYC: '🪪',
  Education: '🎓',
  Certification: '📜',
  Membership: '🏛️',
};
