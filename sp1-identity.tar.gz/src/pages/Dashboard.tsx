import { Link } from "react-router-dom"
import { useStore } from "@/store/useStore"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import {
  Shield,
  FileCheck,
  Users,
  Zap,
  ArrowUpRight,
  Wallet,
  Activity,
  Clock,
} from "lucide-react"

const activityLog = [
  { id: "1", action: "Credential verified", credentialType: "KYC", timestamp: Date.now() - 120000, status: "success" as const },
  { id: "2", action: "Proof generated", credentialType: "EDUCATION", timestamp: Date.now() - 3600000, status: "success" as const },
  { id: "3", action: "Credential issued", credentialType: "CERTIFICATION", timestamp: Date.now() - 7200000, status: "success" as const },
  { id: "4", action: "Proof submitted", credentialType: "MEMBERSHIP", timestamp: Date.now() - 14400000, status: "pending" as const },
  { id: "5", action: "Verification request", credentialType: "KYC", timestamp: Date.now() - 28800000, status: "success" as const },
]

function formatTimeAgo(timestamp: number): string {
  const diff = Date.now() - timestamp
  const minutes = Math.floor(diff / 60000)
  if (minutes < 60) return `${minutes}m ago`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `${hours}h ago`
  return `${Math.floor(hours / 24)}d ago`
}

export default function Dashboard() {
  const { wallet, credentials, issuers, connectWallet, disconnectWallet } = useStore()

  const activeCredentials = credentials.filter((c) => c.status === "ACTIVE").length
  const totalIssuers = issuers.length
  const verifiedIssuers = issuers.filter((i) => i.isVerified).length
  const proofCount = useStore.getState().generatedProofs.length

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">
            Zero-knowledge identity management overview
          </p>
        </div>
        <div className="flex items-center gap-3">
          {wallet.connected ? (
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 rounded-lg border bg-secondary px-3 py-2">
                <Wallet className="h-4 w-4 text-primary" />
                <span className="text-sm font-mono">
                  {wallet.address.slice(0, 6)}...{wallet.address.slice(-4)}
                </span>
                <Badge variant="success" className="text-[10px]">
                  Polygon
                </Badge>
              </div>
              <Button variant="outline" size="sm" onClick={disconnectWallet}>
                Disconnect
              </Button>
            </div>
          ) : (
            <Button onClick={connectWallet}>
              <Wallet className="mr-2 h-4 w-4" />
              Connect Wallet
            </Button>
          )}
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Credentials</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeCredentials}</div>
            <p className="text-xs text-muted-foreground">
              of {credentials.length} total credentials
            </p>
            <Progress value={(activeCredentials / credentials.length) * 100} className="mt-3 h-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Verified Issuers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{verifiedIssuers}</div>
            <p className="text-xs text-muted-foreground">
              of {totalIssuers} registered issuers
            </p>
            <Progress value={(verifiedIssuers / totalIssuers) * 100} className="mt-3 h-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">ZK Proofs Generated</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{proofCount}</div>
            <p className="text-xs text-muted-foreground">
              SP1 & Groth16 proofs
            </p>
            <Progress value={proofCount > 0 ? 75 : 0} className="mt-3 h-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Wallet Balance</CardTitle>
            <FileCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{wallet.balance} MATIC</div>
            <p className="text-xs text-muted-foreground">
              Chain ID: {wallet.chainId}
            </p>
            <Progress value={49} className="mt-3 h-2" />
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Recent Activity
            </CardTitle>
            <CardDescription>Latest identity operations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {activityLog.map((entry, i) => (
                <div key={entry.id}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div
                        className={`h-2 w-2 rounded-full ${
                          entry.status === "success"
                            ? "bg-green-500"
                            : entry.status === "pending"
                            ? "bg-yellow-500"
                            : "bg-red-500"
                        }`}
                      />
                      <div>
                        <p className="text-sm font-medium">{entry.action}</p>
                        <p className="text-xs text-muted-foreground">
                          {entry.credentialType}
                        </p>
                      </div>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {formatTimeAgo(entry.timestamp)}
                    </span>
                  </div>
                  {i < activityLog.length - 1 && <Separator className="mt-4" />}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Credential Summary
            </CardTitle>
            <CardDescription>Breakdown by type</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {(["KYC", "EDUCATION", "CERTIFICATION", "MEMBERSHIP"] as const).map((type) => {
                const count = credentials.filter((c) => c.type === type).length
                return (
                  <div key={type} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Badge
                        variant={
                          type === "KYC"
                            ? "default"
                            : type === "EDUCATION"
                            ? "secondary"
                            : type === "CERTIFICATION"
                            ? "outline"
                            : "warning"
                        }
                      >
                        {type}
                      </Badge>
                      <span className="text-sm">
                        {count} credential{count !== 1 ? "s" : ""}
                      </span>
                    </div>
                    <Progress value={(count / credentials.length) * 100} className="h-2 w-24" />
                  </div>
                )
              })}
            </div>
            <Separator className="my-4" />
            <Link to="/credentials">
              <Button variant="ghost" className="w-full">
                View All Credentials
                <ArrowUpRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
