import { VerificationPanel } from "@/components/identity/VerificationPanel"
import { ZKProofGenerator } from "@/components/identity/ZKProofGenerator"

export default function Verify() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">
            Proof Verification
          </h1>
          <p className="text-muted-foreground">
            Verify zero-knowledge proofs and validate credential attestations
            on-chain
          </p>
        </div>
        <ZKProofGenerator />
      </div>
      <VerificationPanel />
    </div>
  )
}
