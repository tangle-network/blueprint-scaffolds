import { useState } from "react"
import { useStore } from "@/store/useStore"
import type { ZKProof, VerificationResult } from "@/types/identity"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import {
  Zap,
  Shield,
  CheckCircle,
  XCircle,
  Clock,
  Eye,
  EyeOff,
  Copy,
  FileCheck,
  Loader2,
} from "lucide-react"

const mockProof: ZKProof = {
  proof: "0x1a2b3c4d5e6f7890abcdef1234567890abcdef1234567890abcdef1234567890",
  publicSignals: [
    "0x0000000000000000000000000000000000000000000000000000000000000012",
    "0x0000000000000000000000000000000000000000000000000000000000000001",
  ],
  verificationKey: "0xvk_abcd1234ef567890abcd1234ef567890abcd1234ef567890abcd1234ef567890",
  proofType: "sp1",
}

export default function Proofs() {
  const { credentials, generatedProofs, verificationRequests, submitProof, verifyProof, lastVerificationResult } = useStore()
  const [selectedCredential, setSelectedCredential] = useState<string | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const [disclosedAttributes, setDisclosedAttributes] = useState<Record<string, boolean>>({})

  const activeCredentials = credentials.filter((c) => c.status === "ACTIVE")

  const handleGenerateProof = () => {
    setIsGenerating(true)
    setTimeout(() => {
      submitProof(mockProof)
      setIsGenerating(false)
    }, 2000)
  }

  const handleVerify = () => {
    verifyProof(mockProof)
  }

  const selectedCred = credentials.find((c) => c.id === selectedCredential)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">ZK Proofs</h1>
        <p className="text-muted-foreground">
          Generate and verify zero-knowledge proofs for selective disclosure
        </p>
      </div>

      <Tabs defaultValue="generate">
        <TabsList>
          <TabsTrigger value="generate">
            <Zap className="mr-2 h-4 w-4" />
            Generate
          </TabsTrigger>
          <TabsTrigger value="verify">
            <Shield className="mr-2 h-4 w-4" />
            Verify
          </TabsTrigger>
          <TabsTrigger value="history">
            <Clock className="mr-2 h-4 w-4" />
            History ({generatedProofs.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="generate" className="mt-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Select Credential</CardTitle>
                <CardDescription>Choose a credential to generate a proof for</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {activeCredentials.map((cred) => (
                  <div
                    key={cred.id}
                    onClick={() => {
                      setSelectedCredential(cred.id)
                      const attrs: Record<string, boolean> = {}
                      Object.keys(cred.claims).forEach((k) => {
                        attrs[k] = false
                      })
                      setDisclosedAttributes(attrs)
                    }}
                    className={`flex cursor-pointer items-center justify-between rounded-lg border p-3 transition-colors ${
                      selectedCredential === cred.id
                        ? "border-primary bg-primary/5"
                        : "hover:bg-accent"
                    }`}
                  >
                    <div>
                      <p className="text-sm font-medium">{cred.issuer.name}</p>
                      <p className="text-xs text-muted-foreground">{cred.type}</p>
                    </div>
                    <Badge variant="outline">{cred.id}</Badge>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Selective Disclosure</CardTitle>
                <CardDescription>
                  Choose which attributes to reveal in the proof
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {selectedCred ? (
                  <>
                    {Object.entries(selectedCred.claims).map(([key, value]) => (
                      <div key={key} className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Switch
                            id={key}
                            checked={disclosedAttributes[key] || false}
                            onCheckedChange={(checked: boolean) =>
                              setDisclosedAttributes((prev) => ({
                                ...prev,
                                [key]: checked,
                              }))
                            }
                          />
                          <Label htmlFor={key} className="cursor-pointer">
                            {key.replace(/([A-Z])/g, " $1").trim()}
                          </Label>
                        </div>
                        <div className="flex items-center gap-2">
                          {disclosedAttributes[key] ? (
                            <Eye className="h-4 w-4 text-green-500" />
                          ) : (
                            <EyeOff className="h-4 w-4 text-muted-foreground" />
                          )}
                          <span className="text-xs text-muted-foreground max-w-24 truncate">
                            {disclosedAttributes[key] ? value : "••••••"}
                          </span>
                        </div>
                      </div>
                    ))}

                    <Separator />

                    <div className="space-y-2">
                      <p className="text-sm font-medium">Proof Configuration</p>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Proof System</span>
                        <Badge>SP1 (RISC-V zkVM)</Badge>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Predicates</span>
                        <Badge variant="outline">
                          {verificationRequests.length} active
                        </Badge>
                      </div>
                    </div>

                    <Button
                      className="w-full"
                      onClick={handleGenerateProof}
                      disabled={isGenerating}
                    >
                      {isGenerating ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Generating Proof...
                        </>
                      ) : (
                        <>
                          <Zap className="mr-2 h-4 w-4" />
                          Generate ZK Proof
                        </>
                      )}
                    </Button>
                  </>
                ) : (
                  <div className="flex flex-col items-center justify-center py-8 text-center">
                    <FileCheck className="h-10 w-10 text-muted-foreground mb-3" />
                    <p className="text-sm text-muted-foreground">
                      Select a credential to configure disclosure
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="verify" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Proof Verification
              </CardTitle>
              <CardDescription>
                Verify a zero-knowledge proof against the on-chain verifier
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-lg border bg-muted/50 p-4 font-mono text-xs space-y-1">
                <p className="text-muted-foreground">Proof:</p>
                <p className="break-all">{mockProof.proof}</p>
                <p className="text-muted-foreground mt-2">Public Signals:</p>
                {mockProof.publicSignals.map((s, i) => (
                  <p key={i} className="break-all">{s}</p>
                ))}
                <p className="text-muted-foreground mt-2">Verification Key:</p>
                <p className="break-all">{mockProof.verificationKey}</p>
              </div>

              <Button onClick={handleVerify} className="w-full">
                <Shield className="mr-2 h-4 w-4" />
                Verify Proof On-Chain
              </Button>

              {lastVerificationResult && (
                <div className="space-y-3">
                  <Separator />
                  <div className="flex items-center gap-2">
                    {lastVerificationResult.isValid ? (
                      <CheckCircle className="h-5 w-5 text-green-500" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-500" />
                    )}
                    <span className="font-medium">
                      {lastVerificationResult.isValid ? "Proof Verified Successfully" : "Verification Failed"}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    {Object.entries(lastVerificationResult.verifiedClaims).map(
                      ([key, value]) => (
                        <div key={key} className="rounded-lg border p-3">
                          <p className="text-xs text-muted-foreground">{key}</p>
                          <p className="text-sm font-medium">{value}</p>
                        </div>
                      )
                    )}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="mt-4">
          {generatedProofs.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Clock className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-lg font-medium">No proofs generated yet</p>
                <p className="text-sm text-muted-foreground">
                  Generate your first ZK proof from the Generate tab
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {generatedProofs.map((proof: ZKProof, index: number) => (
                <Card key={index}>
                  <CardContent className="flex items-center justify-between p-4">
                    <div className="flex items-center gap-4">
                      <div className="rounded-lg bg-primary/10 p-2">
                        <Zap className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">
                          {proof.proofType.toUpperCase()} Proof #{index + 1}
                        </p>
                        <p className="text-xs text-muted-foreground font-mono">
                          {proof.proof.slice(0, 24)}...
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge variant="success">Verified</Badge>
                      <Button variant="ghost" size="icon">
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
