import { useState } from "react"
import { useStore } from "@/store/useStore"
import { CredentialType, CredentialStatus } from "@/types/identity"
import type { Credential } from "@/types/identity"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Shield,
  Search,
  GraduationCap,
  Award,
  Users,
  FileCheck,
  AlertTriangle,
  Clock,
  Copy,
  ExternalLink,
} from "lucide-react"

function typeIcon(type: CredentialType) {
  switch (type) {
    case CredentialType.KYC:
      return <Shield className="h-5 w-5" />
    case CredentialType.EDUCATION:
      return <GraduationCap className="h-5 w-5" />
    case CredentialType.CERTIFICATION:
      return <Award className="h-5 w-5" />
    case CredentialType.MEMBERSHIP:
      return <Users className="h-5 w-5" />
  }
}

function statusVariant(status: CredentialStatus) {
  switch (status) {
    case CredentialStatus.ACTIVE:
      return "success" as const
    case CredentialStatus.REVOKED:
      return "destructive" as const
    case CredentialStatus.EXPIRED:
      return "warning" as const
    case CredentialStatus.PENDING:
      return "secondary" as const
  }
}

function formatDate(ts: number): string {
  return new Date(ts).toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  })
}

function CredentialCard({ credential }: { credential: Credential }) {
  const { revokeCredential } = useStore()
  const isExpired = credential.expiresAt < Date.now()

  return (
    <Card className="transition-all hover:shadow-md">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="rounded-lg bg-primary/10 p-2 text-primary">
              {typeIcon(credential.type)}
            </div>
            <div>
              <CardTitle className="text-base">{credential.issuer.name}</CardTitle>
              <CardDescription className="text-xs font-mono">
                {credential.id}
              </CardDescription>
            </div>
          </div>
          <Badge variant={statusVariant(credential.status)}>
            {credential.status}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          {Object.entries(credential.claims).map(([key, value]) => (
            <div key={key} className="space-y-1">
              <p className="text-xs text-muted-foreground capitalize">
                {key.replace(/([A-Z])/g, " $1").trim()}
              </p>
              <p className="text-sm font-medium truncate" title={value}>
                {value}
              </p>
            </div>
          ))}
        </div>

        <Separator />

        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            Issued {formatDate(credential.issuedAt)}
          </div>
          <div className="flex items-center gap-1">
            {isExpired ? (
              <AlertTriangle className="h-3 w-3 text-yellow-500" />
            ) : (
              <FileCheck className="h-3 w-3 text-green-500" />
            )}
            {isExpired ? "Expired" : `Expires ${formatDate(credential.expiresAt)}`}
          </div>
        </div>

        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <span className="truncate font-mono">{credential.commitmentHash.slice(0, 32)}...</span>
          <Button variant="ghost" size="icon" className="h-6 w-6">
            <Copy className="h-3 w-3" />
          </Button>
        </div>

        {credential.status === CredentialStatus.ACTIVE && (
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="flex-1">
              <ExternalLink className="mr-1 h-3 w-3" />
              Generate Proof
            </Button>
            <Button
              variant="destructive"
              size="sm"
              onClick={() => revokeCredential(credential.id)}
            >
              Revoke
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

export default function Credentials() {
  const { credentials } = useStore()
  const [search, setSearch] = useState("")
  const [activeTab, setActiveTab] = useState("all")

  const filtered = credentials.filter((c: Credential) => {
    const matchesSearch =
      search === "" ||
      c.issuer.name.toLowerCase().includes(search.toLowerCase()) ||
      c.type.toLowerCase().includes(search.toLowerCase()) ||
      Object.values(c.claims).some((v: string) =>
        v.toLowerCase().includes(search.toLowerCase())
      )

    const matchesTab =
      activeTab === "all" ||
      (activeTab === "active" && c.status === CredentialStatus.ACTIVE) ||
      (activeTab === "expired" && c.status === CredentialStatus.EXPIRED) ||
      (activeTab === "revoked" && c.status === CredentialStatus.REVOKED) ||
      c.type === activeTab.toUpperCase()

    return matchesSearch && matchesTab
  })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Credentials</h1>
        <p className="text-muted-foreground">
          Manage your verifiable credentials and zero-knowledge attestations
        </p>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search by issuer, type, or claim value..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>
        <Button>
          <FileCheck className="mr-2 h-4 w-4" />
          Import Credential
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="all">
            All ({credentials.length})
          </TabsTrigger>
          <TabsTrigger value="active">
            Active ({credentials.filter((c: Credential) => c.status === CredentialStatus.ACTIVE).length})
          </TabsTrigger>
          <TabsTrigger value="KYC">KYC</TabsTrigger>
          <TabsTrigger value="EDUCATION">Education</TabsTrigger>
          <TabsTrigger value="CERTIFICATION">Certifications</TabsTrigger>
          <TabsTrigger value="MEMBERSHIP">Memberships</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-4">
          {filtered.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Shield className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-lg font-medium">No credentials found</p>
                <p className="text-sm text-muted-foreground">
                  Try adjusting your search or filter criteria
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filtered.map((credential: Credential) => (
                <CredentialCard key={credential.id} credential={credential} />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
