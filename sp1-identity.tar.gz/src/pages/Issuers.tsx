import { useStore } from "@/store/useStore"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import {
  Users,
  CheckCircle,
  Shield,
  ExternalLink,
  Copy,
  FileCheck,
  Globe,
} from "lucide-react"

export default function Issuers() {
  const { issuers } = useStore()

  const totalIssued = issuers.reduce((sum: number, i: { totalIssued: number }) => sum + i.totalIssued, 0)
  const verifiedCount = issuers.filter((i: { isVerified: boolean }) => i.isVerified).length

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Trusted Issuers</h1>
          <p className="text-muted-foreground">
            Verified credential issuers on the ZK identity network
          </p>
        </div>
        <Button>
          <Users className="mr-2 h-4 w-4" />
          Register Issuer
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Issuers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{issuers.length}</div>
            <p className="text-xs text-muted-foreground">
              Registered on the network
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Verified Issuers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{verifiedCount}</div>
            <p className="text-xs text-muted-foreground">
              {Math.round((verifiedCount / issuers.length) * 100)}% verification rate
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Credentials Issued</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalIssued.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              Across all issuers
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-4">
        {issuers.map((issuer) => (
          <Card key={issuer.did} className="transition-all hover:shadow-md">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-4">
                  <div className="rounded-lg bg-primary/10 p-3">
                    <Globe className="h-6 w-6 text-primary" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <h3 className="text-lg font-semibold">{issuer.name}</h3>
                      {issuer.isVerified && (
                        <Badge variant="success" className="gap-1">
                          <CheckCircle className="h-3 w-3" />
                          Verified
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Shield className="h-3 w-3" />
                      <span className="font-mono text-xs">{issuer.did}</span>
                      <Button variant="ghost" size="icon" className="h-5 w-5">
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <span className="font-mono text-xs">{issuer.address}</span>
                    </div>
                    <div className="flex items-center gap-2 pt-1">
                      {issuer.credentialTypes.map((type) => (
                        <Badge key={type} variant="outline">
                          <FileCheck className="mr-1 h-3 w-3" />
                          {type}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="text-right space-y-3">
                  <div>
                    <p className="text-2xl font-bold">{issuer.totalIssued.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">credentials issued</p>
                  </div>
                  <Button variant="outline" size="sm">
                    <ExternalLink className="mr-1 h-3 w-3" />
                    View On-Chain
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Separator />

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Issuer Registry</CardTitle>
          <CardDescription>
            The issuer registry smart contract manages verified credential issuers on Polygon
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Contract Address</span>
              <span className="font-mono">0x742d35Cc6634C0532925a3b844Bc9e7595f2bD38</span>
            </div>
            <Separator />
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Network</span>
              <Badge>Polygon Mainnet</Badge>
            </div>
            <Separator />
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Registry Version</span>
              <span>v2.1.0</span>
            </div>
            <Separator />
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Last Updated</span>
              <span>{new Date(Date.now() - 3600000).toLocaleString()}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
