import { useState, useCallback, useEffect } from 'react';
import { ethers, BrowserProvider, JsonRpcSigner } from 'ethers';
import { WalletState } from '../types';

declare global {
  interface Window {
    ethereum?: {
      isMetaMask?: boolean;
      request: (args: { method: string; params?: unknown[] }) => Promise<unknown>;
      on: (event: string, handler: (...args: unknown[]) => void) => void;
      removeListener: (event: string, handler: (...args: unknown[]) => void) => void;
    };
  }
}

export function useWallet() {
  const [wallet, setWallet] = useState<WalletState>({
    address: null,
    chainId: null,
    connected: false,
    isIssuer: false,
    isAdmin: false,
  });
  const [provider, setProvider] = useState<BrowserProvider | null>(null);
  const [signer, setSigner] = useState<JsonRpcSigner | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const connect = useCallback(async () => {
    if (!window.ethereum) {
      setError('MetaMask not detected. Please install MetaMask.');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const accounts = (await window.ethereum.request({
        method: 'eth_requestAccounts',
      })) as string[];
      if (accounts.length === 0) throw new Error('No accounts found');
      const browserProvider = new BrowserProvider(window.ethereum);
      const network = await browserProvider.getNetwork();
      const browserSigner = await browserProvider.getSigner();
      setProvider(browserProvider);
      setSigner(browserSigner);
      setWallet({
        address: accounts[0],
        chainId: Number(network.chainId),
        connected: true,
        isIssuer: false,
        isAdmin: false,
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to connect wallet');
    } finally {
      setLoading(false);
    }
  }, []);

  const disconnect = useCallback(() => {
    setWallet({ address: null, chainId: null, connected: false, isIssuer: false, isAdmin: false });
    setProvider(null);
    setSigner(null);
  }, []);

  const checkIssuerStatus = useCallback(async (signer: JsonRpcSigner) => {
    try {
      const { CONTRACT_ADDRESSES, ISSUER_MANAGER_ABI } = await import('../utils/contracts');
      const network = await signer.provider.getNetwork();
      const addresses = CONTRACT_ADDRESSES[String(network.chainId)];
      if (!addresses) return;
      const issuerMgr = new ethers.Contract(addresses.issuerManager, ISSUER_MANAGER_ABI, signer);
      const address = await signer.getAddress();
      const admin = await issuerMgr.admin();
      const isActive = await issuerMgr.isActiveIssuer(address);
      setWallet((prev) => ({
        ...prev,
        isIssuer: isActive,
        isAdmin: admin.toLowerCase() === address.toLowerCase(),
      }));
    } catch {
      // contracts not deployed on this network
    }
  }, []);

  useEffect(() => {
    if (signer) checkIssuerStatus(signer);
  }, [signer, checkIssuerStatus]);

  useEffect(() => {
    if (!window.ethereum) return;
    const handleAccountsChanged = (...args: unknown[]) => {
      const accounts = args[0] as string[];
      if (accounts.length === 0) disconnect();
      else connect();
    };
    const handleChainChanged = () => window.location.reload();
    window.ethereum.on('accountsChanged', handleAccountsChanged);
    window.ethereum.on('chainChanged', handleChainChanged);
    return () => {
      window.ethereum?.removeListener('accountsChanged', handleAccountsChanged);
      window.ethereum?.removeListener('chainChanged', handleChainChanged);
    };
  }, [connect, disconnect]);

  return { wallet, provider, signer, error, loading, connect, disconnect };
}
