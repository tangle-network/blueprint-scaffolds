import { useMemo } from 'react';
import { ethers, Contract } from 'ethers';
import { JsonRpcSigner } from 'ethers';
import {
  ISSUER_MANAGER_ABI,
  CREDENTIAL_REGISTRY_ABI,
  ZK_VERIFIER_ABI,
  CONTRACT_ADDRESSES,
} from '../utils/contracts';

export function useContracts(signer: JsonRpcSigner | null, chainId: number | null) {
  return useMemo(() => {
    if (!signer || !chainId) {
      return { issuerManager: null, credentialRegistry: null, zkVerifier: null };
    }
    const addresses = CONTRACT_ADDRESSES[String(chainId)];
    if (!addresses) {
      return { issuerManager: null, credentialRegistry: null, zkVerifier: null };
    }
    return {
      issuerManager: new Contract(addresses.issuerManager, ISSUER_MANAGER_ABI, signer),
      credentialRegistry: new Contract(
        addresses.credentialRegistry,
        CREDENTIAL_REGISTRY_ABI,
        signer
      ),
      zkVerifier: new Contract(addresses.zkVerifier, ZK_VERIFIER_ABI, signer),
    };
  }, [signer, chainId]);
}
