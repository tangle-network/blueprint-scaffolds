import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom"
import { Navbar } from "@/components/layout/Navbar"
import { Sidebar } from "@/components/layout/Sidebar"
import Dashboard from "@/pages/Dashboard"
import Credentials from "@/pages/Credentials"
import Verify from "@/pages/Verify"
import Proofs from "@/pages/Proofs"
import Issuers from "@/pages/Issuers"

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex">
          <Sidebar />
          <main className="flex-1 overflow-auto">
            <div className="container max-w-6xl mx-auto p-6">
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/credentials" element={<Credentials />} />
                <Route path="/verify" element={<Verify />} />
                <Route path="/proofs" element={<Proofs />} />
                <Route path="/issuers" element={<Issuers />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </div>
          </main>
        </div>
      </div>
    </BrowserRouter>
  )
}
