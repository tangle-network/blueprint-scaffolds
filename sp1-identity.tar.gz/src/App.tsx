import { useState } from 'react';
import { useApp } from './context/AppContext';
import WalletConnect from './components/WalletConnect';
import CredentialIssuer from './components/CredentialIssuer';
import CredentialWallet from './components/CredentialWallet';
import VerificationPortal from './components/VerificationPortal';
import SelectiveDisclosureDemo from './components/SelectiveDisclosureDemo';

type Tab = 'wallet' | 'issue' | 'verify' | 'disclosure';

export default function App() {
  const { identity } = useApp();
  const [tab, setTab] = useState<Tab>('wallet');

  const tabs: { key: Tab; label: string }[] = [
    { key: 'wallet', label: 'Wallet' },
    { key: 'issue', label: 'Issue' },
    { key: 'verify', label: 'Verify' },
    { key: 'disclosure', label: 'Selective Disclosure' },
  ];

  return (
    <div className="app">
      <div className="header">
        <div>
          <h1>ZK Identity — SP1</h1>
          <div className="subtitle">Privacy-preserving credential system</div>
        </div>
        <WalletConnect />
      </div>

      {identity && (
        <>
          <div className="tabs">
            {tabs.map(t => (
              <button
                key={t.key}
                className={`tab ${tab === t.key ? 'active' : ''}`}
                onClick={() => setTab(t.key)}
              >
                {t.label}
              </button>
            ))}
          </div>

          {tab === 'wallet' && <CredentialWallet />}
          {tab === 'issue' && <CredentialIssuer />}
          {tab === 'verify' && <VerificationPortal />}
          {tab === 'disclosure' && <SelectiveDisclosureDemo />}
        </>
      )}

      {!identity && (
        <div className="empty-state">
          <p style={{ fontSize: 18, marginBottom: 8 }}>Welcome to ZK Identity</p>
          <p>Connect your wallet to manage privacy-preserving credentials</p>
        </div>
      )}
    </div>
  );
}
