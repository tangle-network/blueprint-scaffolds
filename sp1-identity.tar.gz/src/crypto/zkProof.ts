import type {
  Credential,
  SelectiveDisclosure,
  ProofRequest,
  Predicate,
  CredentialType,
} from '../types';
import { generateNullifier, poseidonHash } from './identity';

export function checkPredicate(attribute: number, predicate: Predicate): boolean {
  switch (predicate.operator) {
    case 'gt':
      return attribute > predicate.value;
    case 'gte':
      return attribute >= predicate.value;
    case 'lt':
      return attribute < predicate.value;
    case 'lte':
      return attribute <= predicate.value;
    case 'eq':
      return attribute === predicate.value;
    case 'neq':
      return attribute !== predicate.value;
    default:
      return false;
  }
}

export function generateSelectiveDisclosure(
  credential: Credential,
  proofRequest: ProofRequest,
  revealedAttributes: Record<string, string>,
  secretBlinding: bigint
): SelectiveDisclosure {
  const nullifier = generateNullifier(credential.id, proofRequest.verifier);

  const revealedHash = Object.entries(revealedAttributes)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([, v]) => BigInt(v))
    .reduce((acc, val) => poseidonHash([acc, val]), BigInt(0));

  const proofInput = [
    BigInt(credential.commitment),
    nullifier,
    revealedHash,
    secretBlinding,
    BigInt(Date.now()),
  ];

  const proofHash = proofInput.reduce(
    (acc, val) => poseidonHash([acc, val]),
    BigInt(0)
  );

  const satisfiesPredicates = proofRequest.predicate.every((pred) => {
    const attrValue = revealedAttributes[pred.attribute];
    return attrValue !== undefined && checkPredicate(Number(attrValue), pred);
  });

  return {
    proof: proofHash.toString(),
    publicSignals: [
      credential.commitment,
      nullifier.toString(),
      revealedHash.toString(),
      String(satisfiesPredicates),
    ],
    revealedAttributes: Object.keys(revealedAttributes),
    credentialType: credential.credentialType,
    verifier: proofRequest.verifier,
    timestamp: Date.now(),
  };
}

export function verifySelectiveDisclosure(
  disclosure: SelectiveDisclosure,
  expectedRoot: string,
  credentialNotRevoked: boolean
): boolean {
  if (!credentialNotRevoked) return false;
  if (disclosure.publicSignals.length < 4) return false;
  const satisfiesPredicates = disclosure.publicSignals[3] === 'true';
  return satisfiesPredicates;
}

export function generateAgeProof(
  credential: Credential,
  ageAttribute: string,
  threshold: number,
  verifier: string
): SelectiveDisclosure {
  const proofRequest: ProofRequest = {
    credentialType: credential.credentialType,
    requiredAttributes: [],
    predicate: [
      {
        attribute: ageAttribute,
        operator: 'gte',
        value: threshold,
      },
    ],
    verifier,
    nonce: crypto.randomUUID(),
  };

  const ageValue = credential.attributes[ageAttribute];
  if (!ageValue) throw new Error(`Attribute ${ageAttribute} not found`);

  return generateSelectiveDisclosure(
    credential,
    proofRequest,
    { [ageAttribute]: ageValue },
    BigInt(ethersHexRandom(32))
  );
}

function ethersHexRandom(bytes: number): string {
  const arr = new Uint8Array(bytes);
  crypto.getRandomValues(arr);
  return Array.from(arr)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}
