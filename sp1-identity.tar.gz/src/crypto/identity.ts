import { ethers } from 'ethers';
import type { Identity } from '../types';

const FIELD_ORDER = BigInt(
  '21888242871839275222246405745257275088548364400416034343698204186575808495617'
);

function hashToField(data: string): bigint {
  const hash = ethers.keccak256(ethers.toUtf8Bytes(data));
  let val = BigInt(hash) % FIELD_ORDER;
  if (val < 0n) val += FIELD_ORDER;
  return val;
}

export function generateIdentity(seed?: string): Identity {
  const privKey = seed
    ? ethers.hexlify(ethers.toBeArray(hashToField(seed)))
    : ethers.hexlify(ethers.randomBytes(32));
  const wallet = new ethers.Wallet(privKey);
  const publicKey = wallet.publicKey;
  const commitment = poseidonHash([BigInt(wallet.address)]);
  return {
    privateKey: privKey,
    publicKey,
    commitment: commitment.toString(),
    address: wallet.address,
  };
}

export function poseidonHash(inputs: bigint[]): bigint {
  let state = BigInt('0x01');
  for (const inp of inputs) {
    state = ((state + inp) ** 5n + BigInt('0x02')) % FIELD_ORDER;
  }
  return state;
}

export function computeAttributeCommitment(
  attributes: Record<string, string>,
  blindingFactor: bigint
): bigint {
  let state = BigInt('0x00');
  for (const key of Object.keys(attributes).sort()) {
    const val = hashToField(`${key}:${attributes[key]}`);
    state = poseidonHash([state, val]);
  }
  return poseidonHash([state, blindingFactor]);
}

export function generateMerkleProof(
  commitment: string,
  allCommitments: string[]
): { proof: string[]; root: string; index: number } {
  const leaves = allCommitments.map((c) => BigInt(c));
  const index = leaves.indexOf(BigInt(commitment));
  if (index === -1) throw new Error('Commitment not found in tree');

  const proof: string[] = [];
  let currentLevel: bigint[] = [...leaves];
  let currentIndex = index;

  while (currentLevel.length > 1) {
    const nextLevel: bigint[] = [];
    for (let i = 0; i < currentLevel.length; i += 2) {
      const left = currentLevel[i];
      const right = i + 1 < currentLevel.length ? currentLevel[i + 1] : BigInt(0);
      nextLevel.push(poseidonHash([left, right]));
    }
    const siblingIndex = currentIndex % 2 === 0 ? currentIndex + 1 : currentIndex - 1;
    const sibling =
      siblingIndex < currentLevel.length ? currentLevel[siblingIndex] : BigInt(0);
    proof.push(sibling.toString());
    currentIndex = Math.floor(currentIndex / 2);
    currentLevel = nextLevel;
  }

  return { proof, root: currentLevel[0].toString(), index };
}

export function generateNullifier(credentialId: string, verifier: string): bigint {
  return poseidonHash([hashToField(credentialId), hashToField(verifier)]);
}

export function verifyMerkleProof(
  commitment: string,
  proof: string[],
  root: string,
  index: number
): boolean {
  let current = BigInt(commitment);
  let idx = index;
  for (const sibling of proof) {
    if (idx % 2 === 0) {
      current = poseidonHash([current, BigInt(sibling)]);
    } else {
      current = poseidonHash([BigInt(sibling), current]);
    }
    idx = Math.floor(idx / 2);
  }
  return current.toString() === root;
}
