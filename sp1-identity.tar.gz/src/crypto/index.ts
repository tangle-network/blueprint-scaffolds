export { generateIdentity, computeAttributeCommitment, generateMerkleProof, verifyMerkleProof, generateNullifier, poseidonHash } from './identity';
export { generateSelectiveDisclosure, verifySelectiveDisclosure, generateAgeProof, checkPredicate } from './zkProof';
