export interface Identity {
  privateKey: string;
  publicKey: string;
  commitment: string;
  address: string;
}

export interface Credential {
  id: string;
  issuer: string;
  subject: string;
  commitment: string;
  credentialType: CredentialType;
  attributes: Record<string, string>;
  issuedAt: number;
  expiresAt: number;
  revoked: boolean;
  merkleProof: string[];
}

export enum CredentialType {
  KYC = 0,
  EDUCATION = 1,
  CERTIFICATION = 2,
  MEMBERSHIP = 3,
}

export interface SelectiveDisclosure {
  proof: string;
  publicSignals: string[];
  revealedAttributes: string[];
  credentialType: CredentialType;
  verifier: string;
  timestamp: number;
}

export interface Issuer {
  address: string;
  name: string;
  did: string;
  credentialTypes: CredentialType[];
  active: boolean;
  registeredAt: number;
}

export interface RevocationStatus {
  isRevoked: boolean;
  revocationDate: number;
  reason: string;
}

export interface ProofRequest {
  credentialType: CredentialType;
  requiredAttributes: string[];
  predicate: Predicate[];
  verifier: string;
  nonce: string;
}

export interface Predicate {
  attribute: string;
  operator: 'gt' | 'gte' | 'lt' | 'lte' | 'eq' | 'neq';
  value: number;
}

export interface VerificationResult {
  valid: boolean;
  credentialType: CredentialType;
  satisfiesPredicates: boolean;
  notRevoked: boolean;
  timestamp: number;
}

export const CREDENTIAL_TYPE_NAMES: Record<CredentialType, string> = {
  [CredentialType.KYC]: 'KYC Attestation',
  [CredentialType.EDUCATION]: 'Education',
  [CredentialType.CERTIFICATION]: 'Certification',
  [CredentialType.MEMBERSHIP]: 'Membership',
};
