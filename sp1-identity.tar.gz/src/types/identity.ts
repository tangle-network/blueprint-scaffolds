export enum CredentialType {
  KYC = "KYC",
  EDUCATION = "EDUCATION",
  CERTIFICATION = "CERTIFICATION",
  MEMBERSHIP = "MEMBERSHIP",
}

export enum CredentialStatus {
  ACTIVE = "ACTIVE",
  REVOKED = "REVOKED",
  EXPIRED = "EXPIRED",
  PENDING = "PENDING",
}

export interface ZKProof {
  proof: string
  publicSignals: string[]
  verificationKey: string
  proofType: "groth16" | "sp1"
}

export interface CredentialIssuer {
  name: string
  did: string
  address: string
}

export interface CredentialHolder {
  did: string
  commitment: string
}

export interface Credential {
  id: string
  type: CredentialType
  issuer: CredentialIssuer
  holder: CredentialHolder
  claims: Record<string, string>
  issuedAt: number
  expiresAt: number
  status: CredentialStatus
  revocationNonce: number
  commitmentHash: string
}

export interface Predicate {
  field: string
  operator: "eq" | "gt" | "gte" | "lt" | "lte" | "neq"
  value: number | string
}

export interface SelectiveDisclosureRequest {
  requestedAttributes: string[]
  predicates: Predicate[]
  proofRequirements: {
    proofType: "groth16" | "sp1"
    maxAge?: number
  }
}

export interface Issuer {
  name: string
  did: string
  address: string
  credentialTypes: CredentialType[]
  isVerified: boolean
  totalIssued: number
}

export interface VerificationResult {
  isValid: boolean
  verifiedClaims: Record<string, string>
  proofType: "groth16" | "sp1"
  timestamp: number
}

export interface WalletState {
  address: string
  chainId: number
  connected: boolean
  credentials: string[]
  balance: string
}
