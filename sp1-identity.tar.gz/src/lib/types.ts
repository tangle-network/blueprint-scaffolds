export type {
  ZKProof,
  CredentialIssuer,
  CredentialHolder,
  Credential,
  Predicate,
  SelectiveDisclosureRequest,
  Issuer,
  VerificationResult,
  WalletState,
} from "@/types/identity"

export {
  CredentialType,
  CredentialStatus,
} from "@/types/identity"

export interface NavItem {
  label: string
  path: string
  icon: string
}

export interface StatCard {
  title: string
  value: string | number
  description: string
  trend?: "up" | "down" | "neutral"
  trendValue?: string
}

export interface ProofGenerationRequest {
  credentialId: string
  disclosureRequest: import("@/types/identity").SelectiveDisclosureRequest
}

export interface ActivityLogEntry {
  id: string
  action: string
  credentialType: string
  timestamp: number
  status: "success" | "pending" | "failed"
}
