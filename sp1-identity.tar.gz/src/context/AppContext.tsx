import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import type { Identity, Credential, SelectiveDisclosure, VerificationResult, CredentialType } from '../types';
import { generateIdentity, generateSelectiveDisclosure } from '../crypto';
import * as store from '../store';

interface AppState {
  identity: Identity | null;
  credentials: Credential[];
  isConnecting: boolean;
}

interface AppContextType extends AppState {
  connectWallet: () => void;
  disconnectWallet: () => void;
  issueCredential: (
    subject: string,
    credentialType: CredentialType,
    attributes: Record<string, string>,
    expiresInDays: number,
  ) => Credential;
  revokeCredential: (credentialId: string) => void;
  generateProof: (
    credentialId: string,
    revealedAttributes: string[],
    verifier: string,
  ) => SelectiveDisclosure | null;
  verifyProof: (disclosure: SelectiveDisclosure) => VerificationResult;
  refreshCredentials: () => void;
}

const AppContext = createContext<AppContextType | null>(null);

function randomHex(bytes: number): string {
  return '0x' + Array.from(crypto.getRandomValues(new Uint8Array(bytes))).map(b => b.toString(16).padStart(2, '0')).join('');
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>({
    identity: null,
    credentials: [],
    isConnecting: false,
  });

  const connectWallet = useCallback(() => {
    setState(s => ({ ...s, isConnecting: true }));
    setTimeout(() => {
      const identity = generateIdentity();
      const credentials = store.getCredentialsBySubject(identity.address);
      setState({ identity, credentials, isConnecting: false });
    }, 800);
  }, []);

  const disconnectWallet = useCallback(() => {
    setState({ identity: null, credentials: [], isConnecting: false });
  }, []);

  const issueCredential = useCallback(
    (
      subject: string,
      credentialType: CredentialType,
      attributes: Record<string, string>,
      expiresInDays: number,
    ): Credential => {
      const issuers = store.getIssuers();
      const issuer = issuers[0] ?? {
        address: state.identity?.address ?? '0x0000000000000000000000000000000000000001',
        name: 'Default Issuer',
        did: 'did:zkid:default',
        credentialTypes: [0, 1, 2, 3] as CredentialType[],
        active: true,
        registeredAt: Date.now(),
      };
      const credential = store.issueCredential(issuer, subject, credentialType, attributes, expiresInDays);
      setState(s => ({
        ...s,
        credentials: store.getCredentialsBySubject(s.identity?.address ?? ''),
      }));
      return credential;
    },
    [state.identity],
  );

  const revokeCredential = useCallback((credentialId: string) => {
    store.revokeCredential(credentialId, 'Revoked by issuer');
    setState(s => ({
      ...s,
      credentials: store.getCredentialsBySubject(s.identity?.address ?? ''),
    }));
  }, []);

  const generateProof = useCallback(
    (credentialId: string, revealedAttributes: string[], verifier: string): SelectiveDisclosure | null => {
      const credential = store.getAllCredentials().find(c => c.id === credentialId);
      if (!credential) return null;
      const revealed: Record<string, string> = {};
      for (const attr of revealedAttributes) {
        if (credential.attributes[attr] !== undefined) {
          revealed[attr] = credential.attributes[attr];
        }
      }
      const blinding = BigInt(randomHex(32));
      return generateSelectiveDisclosure(
        credential,
        {
          credentialType: credential.credentialType,
          requiredAttributes: revealedAttributes,
          predicate: [],
          verifier,
          nonce: crypto.randomUUID(),
        },
        revealed,
        blinding,
      );
    },
    [],
  );

  const verifyProof = useCallback(
    (disclosure: SelectiveDisclosure): VerificationResult => ({
      valid: disclosure.proof.length > 0,
      credentialType: disclosure.credentialType,
      satisfiesPredicates: disclosure.publicSignals[3] === 'true',
      notRevoked: true,
      timestamp: Date.now(),
    }),
    [],
  );

  const refreshCredentials = useCallback(() => {
    setState(s => ({
      ...s,
      credentials: store.getCredentialsBySubject(s.identity?.address ?? ''),
    }));
  }, []);

  return (
    <AppContext.Provider
      value={{
        ...state,
        connectWallet,
        disconnectWallet,
        issueCredential,
        revokeCredential,
        generateProof,
        verifyProof,
        refreshCredentials,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp(): AppContextType {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
