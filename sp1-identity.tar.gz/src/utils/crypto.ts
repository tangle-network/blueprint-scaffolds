import { ethers } from 'ethers';

const FIELD_ORDER = BigInt('21888242871839275222246405745257275088548364400416034343698204186575808495617');

function mod(a: bigint, m: bigint): bigint {
  return ((a % m) + m) % m;
}

export function hashToField(data: string): bigint {
  const hash = ethers.keccak256(ethers.toUtf8Bytes(data));
  return mod(BigInt(hash), FIELD_ORDER);
}

export function computePedersenCommitment(
  attributes: Record<string, string>,
  blindingFactor: string
): { commitment: bigint; attributesHash: bigint } {
  let acc = BigInt(0);
  for (const [key, value] of Object.entries(attributes)) {
    const attrHash = hashToField(`${key}:${value}`);
    acc = mod(acc + attrHash, FIELD_ORDER);
  }
  const bf = hashToField(blindingFactor);
  const commitment = mod(acc + bf, FIELD_ORDER);
  return { commitment, attributesHash: acc };
}

interface MerkleNode {
  hash: bigint;
  left: MerkleNode | null;
  right: MerkleNode | null;
}

export class AttributeMerkleTree {
  private leaves: { key: string; value: string; hash: bigint }[] = [];
  private root: bigint = BigInt(0);

  addAttribute(key: string, value: string): void {
    this.leaves.push({ key, value, hash: hashToField(`${key}:${value}`) });
    this.buildTree();
  }

  private buildTree(): void {
    if (this.leaves.length === 0) {
      this.root = BigInt(0);
      return;
    }
    let hashes = this.leaves.map((l) => l.hash);
    while (hashes.length > 1) {
      const nextLevel: bigint[] = [];
      for (let i = 0; i < hashes.length; i += 2) {
        const left = hashes[i];
        const right = i + 1 < hashes.length ? hashes[i + 1] : BigInt(0);
        const combined = ethers.keccak256(
          ethers.AbiCoder.defaultAbiCoder().encode(['uint256', 'uint256'], [left, right])
        );
        nextLevel.push(mod(BigInt(combined), FIELD_ORDER));
      }
      hashes = nextLevel;
    }
    this.root = hashes[0];
  }

  getRoot(): bigint {
    return this.root;
  }

  getLeafCount(): number {
    return this.leaves.length;
  }

  getLeafHash(index: number): bigint | null {
    return this.leaves[index]?.hash ?? null;
  }

  generateProof(index: number): { leaf: bigint; path: bigint[]; indices: number[] } | null {
    if (index < 0 || index >= this.leaves.length) return null;
    const leaf = this.leaves[index].hash;
    const path: bigint[] = [];
    const indices: number[] = [];
    let hashes = this.leaves.map((l) => l.hash);
    let idx = index;

    while (hashes.length > 1) {
      const siblingIdx = idx % 2 === 0 ? idx + 1 : idx - 1;
      const sibling = siblingIdx < hashes.length ? hashes[siblingIdx] : BigInt(0);
      path.push(sibling);
      indices.push(idx % 2);

      const nextLevel: bigint[] = [];
      for (let i = 0; i < hashes.length; i += 2) {
        const left = hashes[i];
        const right = i + 1 < hashes.length ? hashes[i + 1] : BigInt(0);
        const combined = ethers.keccak256(
          ethers.AbiCoder.defaultAbiCoder().encode(['uint256', 'uint256'], [left, right])
        );
        nextLevel.push(mod(BigInt(combined), FIELD_ORDER));
      }
      hashes = nextLevel;
      idx = Math.floor(idx / 2);
    }

    return { leaf, path, indices };
  }
}

export function verifyMerkleProof(
  leaf: bigint,
  path: bigint[],
  indices: number[],
  root: bigint
): boolean {
  let current = leaf;
  for (let i = 0; i < path.length; i++) {
    const [left, right] =
      indices[i] === 0 ? [current, path[i]] : [path[i], current];
    const combined = ethers.keccak256(
      ethers.AbiCoder.defaultAbiCoder().encode(['uint256', 'uint256'], [left, right])
    );
    current = mod(BigInt(combined), FIELD_ORDER);
  }
  return current === root;
}

export function generateMockSP1Proof(proofType: string, publicInputs: string[]): {
  proofBytes: string;
  publicValues: string;
} {
  const publicValues = ethers.AbiCoder.defaultAbiCoder().encode(
    ['string', 'string[]'],
    [proofType, publicInputs]
  );
  const proofBytes = ethers.hexlify(ethers.randomBytes(192));
  return { proofBytes, publicValues };
}

export function formatAddress(address: string): string {
  if (!address) return '';
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

export function formatTimestamp(ts: number): string {
  return new Date(ts * 1000).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}
