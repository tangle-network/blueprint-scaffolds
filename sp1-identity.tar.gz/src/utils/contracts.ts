export const ISSUER_MANAGER_ABI = [
  'function admin() view returns (address)',
  'function registerIssuer(address _issuer, string _name, string _did) external',
  'function suspendIssuer(address _issuer) external',
  'function revokeIssuer(address _issuer) external',
  'function reactivateIssuer(address _issuer) external',
  'function isActiveIssuer(address _issuer) view returns (bool)',
  'function getIssuerCount() view returns (uint256)',
  'function getAllIssuers() view returns (address[] addresses, string[] names, string[] dids, uint8[] statuses)',
  'event IssuerRegistered(address indexed issuer, string name, string did)',
  'event IssuerSuspended(address indexed issuer)',
  'event IssuerRevoked(address indexed issuer)',
];

export const CREDENTIAL_REGISTRY_ABI = [
  'function issuerManager() view returns (address)',
  'function totalCredentials() view returns (uint256)',
  'function issueCredential(address _subject, uint8 _credType, bytes32 _commitment, bytes32 _merkleRoot, uint256 _expiresAt) external returns (bytes32)',
  'function revokeCredential(bytes32 _credentialId, string _reason) external',
  'function verifyCredential(bytes32 _credentialId) view returns (bool isValid, address issuer, address subject, uint8 credType, uint8 status, uint256 issuedAt, uint256 expiresAt)',
  'function getSubjectCredentials(address _subject) view returns (bytes32[])',
  'function getIssuerCredentials(address _issuer) view returns (bytes32[])',
  'function getCredential(bytes32 _credentialId) view returns (tuple(bytes32 credentialId, address issuer, address subject, uint8 credType, uint8 status, bytes32 commitment, bytes32 merkleRoot, uint256 issuedAt, uint256 expiresAt, bool exists))',
  'function isRevoked(bytes32 _credentialId) view returns (bool)',
  'event CredentialIssued(bytes32 indexed credentialId, address indexed issuer, address indexed subject, uint8 credType, bytes32 commitment, uint256 expiresAt)',
  'event CredentialRevoked(bytes32 indexed credentialId, uint256 revokedAt, string reason)',
];

export const ZK_VERIFIER_ABI = [
  'function sp1Verifier() view returns (address)',
  'function ageVerificationVKey() view returns (bytes32)',
  'function selectiveDisclosureVKey() view returns (bytes32)',
  'function membershipVKey() view returns (bytes32)',
  'function setVerificationKeys(bytes32 _ageVKey, bytes32 _selectiveDisclosureVKey, bytes32 _membershipVKey) external',
  'function verifyAge(bytes _publicValues, bytes _proofBytes) external returns (bool)',
  'function verifySelectiveDisclosure(bytes _publicValues, bytes _proofBytes) external returns (bool)',
  'function verifyMembership(bytes _publicValues, bytes _proofBytes) external returns (bool)',
  'function isProofVerified(bytes32 _proofHash) view returns (bool)',
  'function getUserProofs(address _user) view returns (bytes32[])',
  'event AgeVerified(address indexed prover, bool result, uint256 timestamp)',
  'event SelectiveDisclosureVerified(address indexed prover, bytes32 disclosedRoot, uint256 timestamp)',
  'event MembershipVerified(address indexed prover, bytes32 orgId, uint256 timestamp)',
];

export const CONTRACT_ADDRESSES: Record<string, { issuerManager: string; credentialRegistry: string; zkVerifier: string }> = {
  '31337': {
    issuerManager: '0x5FbDB2315678afecb367f032d93F642f64180aa3',
    credentialRegistry: '0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512',
    zkVerifier: '0x9fE46736679d2D9a65F0992F2272dE9f360cB22f',
  },
};
