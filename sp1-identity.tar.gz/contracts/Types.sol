// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

struct Credential {
    bytes32 commitment;
    address issuer;
    address subject;
    bytes32 schemaHash;
    uint256 issuedAt;
    uint256 expiresAt;
    bool revoked;
    bytes32 credentialTypeHash;
}

struct Issuer {
    address issuerAddress;
    string name;
    string did;
    bytes32 publicKeyHash;
    bool active;
    uint256 registeredAt;
    uint256 credentialCount;
}

struct Proof {
    bytes32[2] a;
    bytes32[2][2] b;
    bytes32[2] c;
    bytes32[] publicInputs;
}

enum CredentialType {
    KYC,
    EDUCATION,
    CERTIFICATION,
    MEMBERSHIP
}

struct SelectiveDisclosureRequest {
    bytes32 commitment;
    bytes32 attributeProof;
    uint256 minValue;
    uint256 maxValue;
    bytes32 schemaHash;
}

struct RevocationList {
    mapping(bytes32 => bool) revoked;
    bytes32[] revokedCommitments;
}
