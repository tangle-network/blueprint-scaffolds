// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract IssuerManager {
    address public admin;

    enum IssuerStatus { None, Active, Suspended, Revoked }

    struct Issuer {
        address issuerAddress;
        string name;
        string did;
        IssuerStatus status;
        uint256 registeredAt;
        uint256 credentialCount;
    }

    mapping(address => Issuer) public issuers;
    address[] public issuerList;

    event IssuerRegistered(address indexed issuer, string name, string did);
    event IssuerSuspended(address indexed issuer);
    event IssuerRevoked(address indexed issuer);
    event IssuerReactivated(address indexed issuer);

    modifier onlyAdmin() {
        require(msg.sender == admin, "Not admin");
        _;
    }

    modifier onlyActiveIssuer() {
        require(issuers[msg.sender].status == IssuerStatus.Active, "Not active issuer");
        _;
    }

    constructor() {
        admin = msg.sender;
    }

    function registerIssuer(address _issuer, string calldata _name, string calldata _did) external onlyAdmin {
        require(issuers[_issuer].status == IssuerStatus.None, "Already registered");
        issuers[_issuer] = Issuer({
            issuerAddress: _issuer,
            name: _name,
            did: _did,
            status: IssuerStatus.Active,
            registeredAt: block.timestamp,
            credentialCount: 0
        });
        issuerList.push(_issuer);
        emit IssuerRegistered(_issuer, _name, _did);
    }

    function suspendIssuer(address _issuer) external onlyAdmin {
        require(issuers[_issuer].status == IssuerStatus.Active, "Not active");
        issuers[_issuer].status = IssuerStatus.Suspended;
        emit IssuerSuspended(_issuer);
    }

    function revokeIssuer(address _issuer) external onlyAdmin {
        require(issuers[_issuer].status != IssuerStatus.None, "Not registered");
        issuers[_issuer].status = IssuerStatus.Revoked;
        emit IssuerRevoked(_issuer);
    }

    function reactivateIssuer(address _issuer) external onlyAdmin {
        require(issuers[_issuer].status == IssuerStatus.Suspended, "Not suspended");
        issuers[_issuer].status = IssuerStatus.Active;
        emit IssuerReactivated(_issuer);
    }

    function incrementCredentialCount(address _issuer) external {
        require(issuers[_issuer].status == IssuerStatus.Active, "Not active issuer");
        issuers[_issuer].credentialCount++;
    }

    function isActiveIssuer(address _issuer) external view returns (bool) {
        return issuers[_issuer].status == IssuerStatus.Active;
    }

    function getIssuerCount() external view returns (uint256) {
        return issuerList.length;
    }

    function getAllIssuers() external view returns (
        address[] memory addresses,
        string[] memory names,
        string[] memory dids,
        IssuerStatus[] memory statuses
    ) {
        uint256 len = issuerList.length;
        addresses = new address[](len);
        names = new string[](len);
        dids = new string[](len);
        statuses = new IssuerStatus[](len);
        for (uint256 i = 0; i < len; i++) {
            Issuer storage iss = issuers[issuerList[i]];
            addresses[i] = iss.issuerAddress;
            names[i] = iss.name;
            dids[i] = iss.did;
            statuses[i] = iss.status;
        }
    }
}
