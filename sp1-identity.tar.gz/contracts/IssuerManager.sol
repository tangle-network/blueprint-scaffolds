// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./Types.sol";

contract IssuerManager {
    mapping(address => Issuer) public issuers;
    address[] public issuerList;
    address public owner;

    event IssuerRegistered(address indexed issuer, string name, string did);
    event IssuerDeactivated(address indexed issuer);
    event IssuerReactivated(address indexed issuer);

    modifier onlyOwner() {
        require(msg.sender == owner, "Only owner");
        _;
    }

    modifier onlyActiveIssuer() {
        require(issuers[msg.sender].active, "Not active issuer");
        _;
    }

    constructor() {
        owner = msg.sender;
    }

    function registerIssuer(
        address _issuer,
        string calldata _name,
        string calldata _did,
        bytes32 _publicKeyHash
    ) external onlyOwner {
        require(issuers[_issuer].issuerAddress == address(0), "Already registered");

        issuers[_issuer] = Issuer({
            issuerAddress: _issuer,
            name: _name,
            did: _did,
            publicKeyHash: _publicKeyHash,
            active: true,
            registeredAt: block.timestamp,
            credentialCount: 0
        });

        issuerList.push(_issuer);
        emit IssuerRegistered(_issuer, _name, _did);
    }

    function deactivateIssuer(address _issuer) external onlyOwner {
        require(issuers[_issuer].active, "Not active");
        issuers[_issuer].active = false;
        emit IssuerDeactivated(_issuer);
    }

    function reactivateIssuer(address _issuer) external onlyOwner {
        require(!issuers[_issuer].active, "Already active");
        issuers[_issuer].active = true;
        emit IssuerReactivated(_issuer);
    }

    function isIssuerActive(address _issuer) external view returns (bool) {
        return issuers[_issuer].active;
    }

    function getIssuerCount() external view returns (uint256) {
        return issuerList.length;
    }

    function getIssuer(address _issuer)
        external
        view
        returns (
            string memory name,
            string memory did,
            bytes32 publicKeyHash,
            bool active,
            uint256 registeredAt,
            uint256 credentialCount
        )
    {
        Issuer storage i = issuers[_issuer];
        return (i.name, i.did, i.publicKeyHash, i.active, i.registeredAt, i.credentialCount);
    }
}
