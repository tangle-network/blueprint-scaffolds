// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./IssuerManager.sol";

contract CredentialRegistry {
    IssuerManager public issuerManager;

    enum CredentialType { KYC, Education, Certification, Membership }
    enum CredentialStatus { Active, Revoked, Expired }

    struct Credential {
        bytes32 credentialId;
        address issuer;
        address subject;
        CredentialType credType;
        CredentialStatus status;
        bytes32 commitment;          // Pedersen commitment to attributes
        bytes32 merkleRoot;          // Root of attribute Merkle tree
        uint256 issuedAt;
        uint256 expiresAt;
        bool exists;
    }

    struct RevocationInfo {
        bool isRevoked;
        uint256 revokedAt;
        string reason;
    }

    mapping(bytes32 => Credential) public credentials;
    mapping(bytes32 => RevocationInfo) public revocations;
    mapping(address => bytes32[]) public subjectCredentials;
    mapping(address => bytes32[]) public issuerCredentials;

    bytes32[] public allCredentialIds;

    uint256 public totalCredentials;

    event CredentialIssued(
        bytes32 indexed credentialId,
        address indexed issuer,
        address indexed subject,
        CredentialType credType,
        bytes32 commitment,
        uint256 expiresAt
    );

    event CredentialRevoked(bytes32 indexed credentialId, uint256 revokedAt, string reason);
    event CredentialVerified(bytes32 indexed credentialId, bool isValid);

    constructor(address _issuerManager) {
        issuerManager = IssuerManager(_issuerManager);
    }

    function issueCredential(
        address _subject,
        CredentialType _credType,
        bytes32 _commitment,
        bytes32 _merkleRoot,
        uint256 _expiresAt
    ) external returns (bytes32) {
        require(issuerManager.isActiveIssuer(msg.sender), "Not authorized issuer");
        require(_subject != address(0), "Invalid subject");
        require(_expiresAt > block.timestamp, "Must expire in future");

        bytes32 credId = keccak256(abi.encodePacked(
            msg.sender,
            _subject,
            _credType,
            _commitment,
            block.timestamp
        ));

        require(!credentials[credId].exists, "Credential already exists");

        Credential memory cred = Credential({
            credentialId: credId,
            issuer: msg.sender,
            subject: _subject,
            credType: _credType,
            status: CredentialStatus.Active,
            commitment: _commitment,
            merkleRoot: _merkleRoot,
            issuedAt: block.timestamp,
            expiresAt: _expiresAt,
            exists: true
        });

        credentials[credId] = cred;
        subjectCredentials[_subject].push(credId);
        issuerCredentials[msg.sender].push(credId);
        allCredentialIds.push(credId);
        totalCredentials++;

        issuerManager.incrementCredentialCount(msg.sender);

        emit CredentialIssued(credId, msg.sender, _subject, _credType, _commitment, _expiresAt);
        return credId;
    }

    function revokeCredential(bytes32 _credentialId, string calldata _reason) external {
        Credential storage cred = credentials[_credentialId];
        require(cred.exists, "Credential does not exist");
        require(cred.issuer == msg.sender, "Not credential issuer");
        require(cred.status == CredentialStatus.Active, "Not active");

        cred.status = CredentialStatus.Revoked;
        revocations[_credentialId] = RevocationInfo({
            isRevoked: true,
            revokedAt: block.timestamp,
            reason: _reason
        });

        emit CredentialRevoked(_credentialId, block.timestamp, _reason);
    }

    function verifyCredential(bytes32 _credentialId) external view returns (
        bool isValid,
        address issuer,
        address subject,
        CredentialType credType,
        CredentialStatus status,
        uint256 issuedAt,
        uint256 expiresAt
    ) {
        Credential storage cred = credentials[_credentialId];
        require(cred.exists, "Credential does not exist");

        isValid = cred.status == CredentialStatus.Active
            && cred.expiresAt > block.timestamp
            && issuerManager.isActiveIssuer(cred.issuer);

        issuer = cred.issuer;
        subject = cred.subject;
        credType = cred.credType;
        status = cred.status;
        issuedAt = cred.issuedAt;
        expiresAt = cred.expiresAt;
    }

    function getSubjectCredentials(address _subject) external view returns (bytes32[] memory) {
        return subjectCredentials[_subject];
    }

    function getIssuerCredentials(address _issuer) external view returns (bytes32[] memory) {
        return issuerCredentials[_issuer];
    }

    function getCredential(bytes32 _credentialId) external view returns (Credential memory) {
        require(credentials[_credentialId].exists, "Credential does not exist");
        return credentials[_credentialId];
    }

    function isRevoked(bytes32 _credentialId) external view returns (bool) {
        return revocations[_credentialId].isRevoked;
    }
}
