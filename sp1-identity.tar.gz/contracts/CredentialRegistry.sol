// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./Types.sol";
import "./IssuerManager.sol";

contract CredentialRegistry {
    IssuerManager public issuerManager;

    mapping(bytes32 => Credential) public credentials;
    mapping(address => bytes32[]) public subjectCredentials;
    mapping(address => bytes32[]) public issuerCredentials;
    mapping(bytes32 => bool) public revokedCommitments;
    bytes32[] public allCredentialIds;

    event CredentialIssued(
        bytes32 indexed credentialId,
        address indexed issuer,
        address indexed subject,
        bytes32 schemaHash,
        CredentialType credentialType
    );
    event CredentialRevoked(bytes32 indexed credentialId, address indexed issuer);
    event CredentialVerified(bytes32 indexed credentialId, bool valid);

    modifier onlyActiveIssuer() {
        require(issuerManager.isIssuerActive(msg.sender), "Not active issuer");
        _;
    }

    constructor(address _issuerManager) {
        issuerManager = IssuerManager(_issuerManager);
    }

    function issueCredential(
        bytes32 _credentialId,
        bytes32 _commitment,
        address _subject,
        bytes32 _schemaHash,
        uint256 _expiresAt,
        CredentialType _credentialType
    ) external onlyActiveIssuer {
        require(credentials[_credentialId].commitment == bytes32(0), "Already exists");
        require(_subject != address(0), "Invalid subject");

        credentials[_credentialId] = Credential({
            commitment: _commitment,
            issuer: msg.sender,
            subject: _subject,
            schemaHash: _schemaHash,
            issuedAt: block.timestamp,
            expiresAt: _expiresAt,
            revoked: false,
            credentialTypeHash: keccak256(abi.encodePacked(_credentialType))
        });

        subjectCredentials[_subject].push(_credentialId);
        issuerCredentials[msg.sender].push(_credentialId);
        allCredentialIds.push(_credentialId);

        emit CredentialIssued(_credentialId, msg.sender, _subject, _schemaHash, _credentialType);
    }

    function revokeCredential(bytes32 _credentialId) external {
        Credential storage cred = credentials[_credentialId];
        require(cred.issuer == msg.sender, "Not issuer");
        require(!cred.revoked, "Already revoked");

        cred.revoked = true;
        revokedCommitments[cred.commitment] = true;

        emit CredentialRevoked(_credentialId, msg.sender);
    }

    function verifyCredential(bytes32 _credentialId) external view returns (
        bool isValid,
        address issuer,
        address subject,
        uint256 issuedAt,
        uint256 expiresAt,
        bool revoked
    ) {
        Credential storage cred = credentials[_credentialId];
        isValid = cred.commitment != bytes32(0)
            && !cred.revoked
            && block.timestamp <= cred.expiresAt
            && issuerManager.isIssuerActive(cred.issuer);
        return (isValid, cred.issuer, cred.subject, cred.issuedAt, cred.expiresAt, cred.revoked);
    }

    function isCommitmentRevoked(bytes32 _commitment) external view returns (bool) {
        return revokedCommitments[_commitment];
    }

    function getSubjectCredentials(address _subject) external view returns (bytes32[] memory) {
        return subjectCredentials[_subject];
    }

    function getIssuerCredentials(address _issuer) external view returns (bytes32[] memory) {
        return issuerCredentials[_issuer];
    }

    function getCredentialCount() external view returns (uint256) {
        return allCredentialIds.length;
    }

    function batchVerifyCredentials(bytes32[] calldata _credentialIds)
        external
        view
        returns (bool[] memory results)
    {
        results = new bool[](_credentialIds.length);
        for (uint256 i = 0; i < _credentialIds.length; i++) {
            Credential storage cred = credentials[_credentialIds[i]];
            results[i] = cred.commitment != bytes32(0)
                && !cred.revoked
                && block.timestamp <= cred.expiresAt
                && issuerManager.isIssuerActive(cred.issuer);
        }
        return results;
    }
}
