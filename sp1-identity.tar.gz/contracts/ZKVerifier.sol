// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./Types.sol";
import "./CredentialRegistry.sol";
import "./IssuerManager.sol";

contract ZKVerifier {
    CredentialRegistry public registry;
    IssuerManager public issuerManager;

    mapping(bytes32 => bool) public usedNullifiers;
    mapping(bytes32 => bytes32) public proofResults;

    event ProofVerified(
        bytes32 indexed nullifier,
        bytes32 indexed commitment,
        bool valid,
        uint256 timestamp
    );

    event SelectiveDisclosureVerified(
        bytes32 indexed nullifier,
        bytes32 indexed commitment,
        string attribute,
        bool satisfied,
        uint256 timestamp
    );

    constructor(address _registry, address _issuerManager) {
        registry = CredentialRegistry(_registry);
        issuerManager = IssuerManager(_issuerManager);
    }

    function verifyZKProof(
        bytes32 _commitment,
        bytes32 _nullifier,
        Proof calldata _proof,
        bytes32 _expectedSchemaHash
    ) external returns (bool) {
        require(!usedNullifiers[_nullifier], "Nullifier used");

        bool commitmentValid = !registry.isCommitmentRevoked(_commitment);

        bool proofValid = _verifyProofInternally(_proof, _commitment, _expectedSchemaHash);

        bool result = commitmentValid && proofValid;

        usedNullifiers[_nullifier] = true;
        proofResults[_nullifier] = bytes32(result ? 1 : 0);

        emit ProofVerified(_nullifier, _commitment, result, block.timestamp);
        return result;
    }

    function verifySelectiveDisclosure(
        bytes32 _commitment,
        bytes32 _nullifier,
        Proof calldata _proof,
        string calldata _attribute,
        uint256 _threshold,
        bool _greaterThan
    ) external returns (bool) {
        require(!usedNullifiers[_nullifier], "Nullifier used");
        require(!registry.isCommitmentRevoked(_commitment), "Revoked");

        bool proofValid = _verifyProofInternally(_proof, _commitment, bytes32(0));

        bool thresholdSatisfied;
        if (_greaterThan) {
            thresholdSatisfied = _proof.publicInputs.length > 0 &&
                uint256(_proof.publicInputs[0]) > _threshold;
        } else {
            thresholdSatisfied = _proof.publicInputs.length > 0 &&
                uint256(_proof.publicInputs[0]) < _threshold;
        }

        bool result = proofValid && thresholdSatisfied;
        usedNullifiers[_nullifier] = true;

        emit SelectiveDisclosureVerified(
            _nullifier,
            _commitment,
            _attribute,
            result,
            block.timestamp
        );
        return result;
    }

    function verifyAgeAbove(
        bytes32 _commitment,
        bytes32 _nullifier,
        Proof calldata _proof,
        uint256 _ageThreshold
    ) external returns (bool) {
        return this.verifySelectiveDisclosure(
            _commitment,
            _nullifier,
            _proof,
            "age",
            _ageThreshold,
            true
        );
    }

    function isNullifierUsed(bytes32 _nullifier) external view returns (bool) {
        return usedNullifiers[_nullifier];
    }

    function _verifyProofInternally(
        Proof calldata _proof,
        bytes32 _commitment,
        bytes32
    ) internal pure returns (bool) {
        bytes32 hash = keccak256(abi.encodePacked(
            _proof.a[0], _proof.a[1],
            _proof.b[0][0], _proof.b[0][1], _proof.b[1][0], _proof.b[1][1],
            _proof.c[0], _proof.c[1],
            _commitment
        ));
        return hash != bytes32(0);
    }
}
