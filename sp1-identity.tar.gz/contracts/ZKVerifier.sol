// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface ISP1Verifier {
    function verifyProof(
        bytes calldata programVKey,
        bytes calldata publicValues,
        bytes calldata proofBytes
    ) external view returns (bool);
}

contract ZKVerifier {
    ISP1Verifier public sp1Verifier;

    bytes32 public ageVerificationVKey;
    bytes32 public selectiveDisclosureVKey;
    bytes32 public membershipVKey;

    struct ProofResult {
        bool verified;
        uint256 verifiedAt;
        bytes32 proofHash;
    }

    mapping(bytes32 => ProofResult) public verifiedProofs;
    mapping(address => bytes32[]) public userProofs;

    event AgeVerified(address indexed prover, bool result, uint256 timestamp);
    event SelectiveDisclosureVerified(address indexed prover, bytes32 disclosedRoot, uint256 timestamp);
    event MembershipVerified(address indexed prover, bytes32 orgId, uint256 timestamp);
    event ProofSubmitted(bytes32 indexed proofHash, address indexed prover, uint256 timestamp);

    constructor(address _sp1Verifier) {
        sp1Verifier = ISP1Verifier(_sp1Verifier);
    }

    function setVerificationKeys(
        bytes32 _ageVKey,
        bytes32 _selectiveDisclosureVKey,
        bytes32 _membershipVKey
    ) external {
        ageVerificationVKey = _ageVKey;
        selectiveDisclosureVKey = _selectiveDisclosureVKey;
        membershipVKey = _membershipVKey;
    }

    function verifyAge(
        bytes calldata _publicValues,
        bytes calldata _proofBytes
    ) external returns (bool) {
        require(ageVerificationVKey != bytes32(0), "Age vkey not set");

        bytes memory vkeyBytes = abi.encodePacked(ageVerificationVKey);
        bool valid = sp1Verifier.verifyProof(vkeyBytes, _publicValues, _proofBytes);

        if (valid) {
            bytes32 proofHash = keccak256(abi.encodePacked(_publicValues, _proofBytes));
            verifiedProofs[proofHash] = ProofResult({
                verified: true,
                verifiedAt: block.timestamp,
                proofHash: proofHash
            });
            userProofs[msg.sender].push(proofHash);
            emit AgeVerified(msg.sender, true, block.timestamp);
            emit ProofSubmitted(proofHash, msg.sender, block.timestamp);
        }

        return valid;
    }

    function verifySelectiveDisclosure(
        bytes calldata _publicValues,
        bytes calldata _proofBytes
    ) external returns (bool) {
        require(selectiveDisclosureVKey != bytes32(0), "Selective disclosure vkey not set");

        bytes memory vkeyBytes = abi.encodePacked(selectiveDisclosureVKey);
        bool valid = sp1Verifier.verifyProof(vkeyBytes, _publicValues, _proofBytes);

        if (valid) {
            bytes32 proofHash = keccak256(abi.encodePacked(_publicValues, _proofBytes));
            verifiedProofs[proofHash] = ProofResult({
                verified: true,
                verifiedAt: block.timestamp,
                proofHash: proofHash
            });
            userProofs[msg.sender].push(proofHash);
            emit SelectiveDisclosureVerified(msg.sender, bytes32(_publicValues[:32]), block.timestamp);
            emit ProofSubmitted(proofHash, msg.sender, block.timestamp);
        }

        return valid;
    }

    function verifyMembership(
        bytes calldata _publicValues,
        bytes calldata _proofBytes
    ) external returns (bool) {
        require(membershipVKey != bytes32(0), "Membership vkey not set");

        bytes memory vkeyBytes = abi.encodePacked(membershipVKey);
        bool valid = sp1Verifier.verifyProof(vkeyBytes, _publicValues, _proofBytes);

        if (valid) {
            bytes32 proofHash = keccak256(abi.encodePacked(_publicValues, _proofBytes));
            verifiedProofs[proofHash] = ProofResult({
                verified: true,
                verifiedAt: block.timestamp,
                proofHash: proofHash
            });
            userProofs[msg.sender].push(proofHash);
            emit MembershipVerified(msg.sender, bytes32(_publicValues[:32]), block.timestamp);
            emit ProofSubmitted(proofHash, msg.sender, block.timestamp);
        }

        return valid;
    }

    function isProofVerified(bytes32 _proofHash) external view returns (bool) {
        return verifiedProofs[_proofHash].verified;
    }

    function getUserProofs(address _user) external view returns (bytes32[] memory) {
        return userProofs[_user];
    }
}
