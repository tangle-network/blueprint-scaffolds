import { HardhatUserConfig } from "hardhat/config";
import "@nomicfoundation/hardhat-toolbox";
import "@cofhe/hardhat-plugin";

const config: HardhatUserConfig = {
  solidity: "0.8.20",
  networks: {
    fhenix: {
      url: "https://api.nitrogen.fhenix.zone",
      chainId: 8008148,
      accounts: process.env.PRIVATE_KEY ? [process.env.PRIVATE_KEY] : [],
    },
  },
};

export default config;
