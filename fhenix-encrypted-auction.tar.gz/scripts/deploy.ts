import { ethers } from "hardhat";

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying contracts with account:", deployer.address);

  const balance = await ethers.provider.getBalance(deployer.address);
  console.log("Account balance:", ethers.formatEther(balance));

  const SealedAuction = await ethers.getContractFactory("SealedAuction");
  const auction = await SealedAuction.deploy();
  await auction.waitForDeployment();

  const address = await auction.getAddress();
  console.log("SealedAuction deployed to:", address);

  // Create a demo auction
  const tx = await auction.createAuction(
    "Fhenix Demo Token",
    "FDT",
    ethers.parseEther("1000000"),
    ethers.parseEther("0.01"),
    3600 // 1 hour
  );
  await tx.wait();
  console.log("Demo auction created with ID: 0");

  console.log("\n--- Deployment Summary ---");
  console.log("SealedAuction:", address);
  console.log("Network:", (await ethers.provider.getNetwork()).name);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
