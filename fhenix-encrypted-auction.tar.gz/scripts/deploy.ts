import hre from "hardhat";

const { ethers } = hre;

async function main() {
  const [deployer] = await ethers.getSigners();
  const now = Math.floor(Date.now() / 1000);
  const reservePrice = ethers.parseEther("0.25");
  const minDeposit = ethers.parseEther("0.25");
  const maxDeposit = ethers.parseEther("5");
  const tokenSupply = ethers.parseUnits("1000000", 18);
  const tokensForSale = ethers.parseUnits("250000", 18);

  if (
    reservePrice > BigInt("18446744073709551615") ||
    minDeposit > BigInt("18446744073709551615") ||
    maxDeposit > BigInt("18446744073709551615")
  ) {
    throw new Error("Configured ETH values exceed uint64 capacity");
  }

  const tokenFactory = await ethers.getContractFactory("LaunchToken");
  const token = await tokenFactory.deploy("Encrypted Launch Token", "ELT", deployer.address);
  await token.waitForDeployment();
  await (await token.mint(deployer.address, tokenSupply)).wait();

  const auctionFactory = await ethers.getContractFactory("EncryptedLaunchpadAuction");
  const auction = await auctionFactory.deploy(
    {
      metadataURI: "ipfs://encrypted-launchpad/sample-auction",
      reservePrice,
      minDeposit,
      maxDeposit,
      tokensForSale,
      startTime: BigInt(now + 60),
      endTime: BigInt(now + 60 * 60),
      token: await token.getAddress()
    },
    deployer.address
  );
  await auction.waitForDeployment();
  await (await token.transfer(await auction.getAddress(), tokensForSale)).wait();

  console.log(
    JSON.stringify(
      {
        network: await ethers.provider.getNetwork(),
        deployer: deployer.address,
        token: await token.getAddress(),
        auction: await auction.getAddress()
      },
      null,
      2
    )
  );
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
