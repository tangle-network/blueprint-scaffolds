import { ethers } from "hardhat";

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying contracts with:", deployer.address);

  const MockToken = await ethers.getContractFactory("MockToken");
  const token = await MockToken.deploy(ethers.parseEther("1000000"));
  await token.waitForDeployment();
  console.log("MockToken deployed to:", await token.getAddress());

  const SealedAuction = await ethers.getContractFactory("SealedAuction");
  const auction = await SealedAuction.deploy();
  await auction.waitForDeployment();
  console.log("SealedAuction deployed to:", await auction.getAddress());

  const AuctionFactory = await ethers.getContractFactory("AuctionFactory");
  const factory = await AuctionFactory.deploy();
  await factory.waitForDeployment();
  console.log("AuctionFactory deployed to:", await factory.getAddress());

  console.log("\n--- Deployment Summary ---");
  console.log("MockToken:", await token.getAddress());
  console.log("SealedAuction:", await auction.getAddress());
  console.log("AuctionFactory:", await factory.getAddress());
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
