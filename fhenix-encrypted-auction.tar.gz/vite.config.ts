import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import wasm from "vite-plugin-wasm";
import topLevelAwait from "vite-plugin-top-level-await";

export default defineConfig({
  plugins: [react(), wasm(), topLevelAwait()],
  build: {
    outDir: "frontend-dist"
  },
  server: {
    port: 5173
  },
  optimizeDeps: {
    esbuildOptions: {
      target: "es2022"
    },
    exclude: ["fhenixjs"]
  }
});
