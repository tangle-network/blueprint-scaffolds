import { FormEvent, useEffect, useMemo, useState } from "react";
import { BrowserProvider, Contract, formatEther, parseEther } from "ethers";
import { FhenixClientSync } from "../node_modules/fhenixjs/dist/fhenix.esm.js";
import auctionArtifact from "../artifacts/contracts/EncryptedLaunchpadAuction.sol/EncryptedLaunchpadAuction.json";
import { DEFAULT_AUCTION_ADDRESS } from "./config";

type AuctionSnapshot = {
  token: string;
  metadataURI: string;
  reservePrice: bigint;
  minDeposit: bigint;
  maxDeposit: bigint;
  tokensForSale: bigint;
  startTime: bigint;
  endTime: bigint;
  settled: boolean;
  winner: string;
  clearingPrice: bigint;
  winningBid: bigint;
  bidderCount: bigint;
};

const emptySnapshot: AuctionSnapshot = {
  token: DEFAULT_AUCTION_ADDRESS,
  metadataURI: "",
  reservePrice: 0n,
  minDeposit: 0n,
  maxDeposit: 0n,
  tokensForSale: 0n,
  startTime: 0n,
  endTime: 0n,
  settled: false,
  winner: DEFAULT_AUCTION_ADDRESS,
  clearingPrice: 0n,
  winningBid: 0n,
  bidderCount: 0n
};

export default function App() {
  const [provider, setProvider] = useState<BrowserProvider | null>(null);
  const [fhenix, setFhenix] = useState<FhenixClientSync | null>(null);
  const [account, setAccount] = useState<string>("");
  const [auctionAddress, setAuctionAddress] = useState<string>(DEFAULT_AUCTION_ADDRESS);
  const [snapshot, setSnapshot] = useState<AuctionSnapshot>(emptySnapshot);
  const [bidAmount, setBidAmount] = useState("1.0");
  const [depositAmount, setDepositAmount] = useState("1.0");
  const [status, setStatus] = useState("Connect a wallet to start.");

  const auction = useMemo(() => {
    if (!provider || !auctionAddress || auctionAddress === DEFAULT_AUCTION_ADDRESS) {
      return null;
    }
    return new Contract(auctionAddress, auctionArtifact.abi, provider);
  }, [provider, auctionAddress]);

  useEffect(() => {
    const ethereum = (window as Window & { ethereum?: object }).ethereum;
    if (!ethereum) {
      setStatus("No injected wallet found. Use MetaMask or another EIP-1193 wallet.");
      return;
    }

    const nextProvider = new BrowserProvider(ethereum);
    setProvider(nextProvider);

    FhenixClientSync.create({ provider: ethereum, securityZones: [0] })
      .then(setFhenix)
      .catch((error: unknown) => {
        console.error(error);
        setStatus("Wallet connected, but Fhenix client initialization failed.");
      });
  }, []);

  async function connectWallet() {
    if (!provider) return;
    const accounts = await provider.send("eth_requestAccounts", []);
    const nextAccount = String(accounts[0] ?? "");
    setAccount(nextAccount);
    setStatus(`Connected ${nextAccount}`);
  }

  async function refreshAuction() {
    if (!auction) return;
    const [auctionConfig, settled, winner, clearingPrice, winningBid, bidderCount] = await Promise.all([
      auction.auction(),
      auction.settled(),
      auction.winner(),
      auction.clearingPrice(),
      auction.winningBid(),
      auction.getBidderCount()
    ]);

    setSnapshot({
      token: auctionConfig.token,
      metadataURI: auctionConfig.metadataURI,
      reservePrice: auctionConfig.reservePrice,
      minDeposit: auctionConfig.minDeposit,
      maxDeposit: auctionConfig.maxDeposit,
      tokensForSale: auctionConfig.tokensForSale,
      startTime: auctionConfig.startTime,
      endTime: auctionConfig.endTime,
      settled,
      winner,
      clearingPrice,
      winningBid,
      bidderCount
    });
    setStatus("Auction state refreshed.");
  }

  async function submitBid(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!provider || !auction || !fhenix) return;

    const signer = await provider.getSigner();
    const bidWei = parseEther(bidAmount);
    const depositWei = parseEther(depositAmount);
    const encryptedBid = fhenix.encrypt_uint64(bidWei.toString());

    setStatus("Submitting encrypted bid...");
    const tx = await auction.connect(signer).submitBid(
      {
        data: encryptedBid.data,
        securityZone: encryptedBid.securityZone
      },
      { value: depositWei }
    );
    await tx.wait();
    setStatus("Encrypted bid submitted.");
    await refreshAuction();
  }

  async function settleAuction() {
    if (!provider || !auction) return;
    const signer = await provider.getSigner();
    setStatus("Settling auction...");
    const tx = await auction.connect(signer).settleAuction();
    await tx.wait();
    setStatus("Auction settled.");
    await refreshAuction();
  }

  async function claimRefund() {
    if (!provider || !auction) return;
    const signer = await provider.getSigner();
    setStatus("Claiming refund...");
    const tx = await auction.connect(signer).claimRefund();
    await tx.wait();
    setStatus("Refund claimed.");
    await refreshAuction();
  }

  return (
    <main className="shell">
      <section className="hero">
        <div>
          <p className="eyebrow">FHENIX Encrypted Launchpad</p>
          <h1>Sealed bids. Visible settlement. No price leakage before close.</h1>
          <p className="lede">
            Bids are encrypted with <code>fhenix.js</code>, validated on-chain against deposits,
            and settled as a sealed-bid token sale after the deadline.
          </p>
        </div>
        <div className="status-card">
          <button onClick={connectWallet} type="button">
            {account ? "Wallet Connected" : "Connect Wallet"}
          </button>
          <p>{status}</p>
        </div>
      </section>

      <section className="panel grid">
        <label>
          Auction address
          <input
            value={auctionAddress}
            onChange={(event) => setAuctionAddress(event.target.value)}
            placeholder="0x..."
          />
        </label>
        <button onClick={refreshAuction} type="button">
          Load Auction
        </button>
      </section>

      <section className="panel stats">
        <article>
          <span>Reserve</span>
          <strong>{formatDisplay(snapshot.reservePrice)}</strong>
        </article>
        <article>
          <span>Sale Lot</span>
          <strong>{snapshot.tokensForSale.toString()}</strong>
        </article>
        <article>
          <span>Bidders</span>
          <strong>{snapshot.bidderCount.toString()}</strong>
        </article>
        <article>
          <span>Settled</span>
          <strong>{snapshot.settled ? "Yes" : "No"}</strong>
        </article>
        <article>
          <span>Winner</span>
          <strong className="mono">{truncateAddress(snapshot.winner)}</strong>
        </article>
        <article>
          <span>Clearing Price</span>
          <strong>{formatDisplay(snapshot.clearingPrice)}</strong>
        </article>
      </section>

      <section className="panel split">
        <form onSubmit={submitBid}>
          <h2>Submit encrypted bid</h2>
          <label>
            Secret bid amount (ETH)
            <input value={bidAmount} onChange={(event) => setBidAmount(event.target.value)} />
          </label>
          <label>
            Public deposit cap (ETH)
            <input value={depositAmount} onChange={(event) => setDepositAmount(event.target.value)} />
          </label>
          <button type="submit">Encrypt and Bid</button>
        </form>

        <div className="actions">
          <h2>Settlement</h2>
          <p>
            Settlement picks the highest valid sealed bid, sets the clearing price to the second
            highest valid bid, sends the token inventory to the winner, and lets participants claim
            ETH refunds.
          </p>
          <button onClick={settleAuction} type="button">
            Settle Auction
          </button>
          <button onClick={claimRefund} type="button">
            Claim Refund
          </button>
        </div>
      </section>
    </main>
  );
}

function formatDisplay(value: bigint) {
  if (value === 0n) return "0";
  return `${formatEther(value)} ETH`;
}

function truncateAddress(value: string) {
  if (!value || value === DEFAULT_AUCTION_ADDRESS) return "Not settled";
  return `${value.slice(0, 6)}...${value.slice(-4)}`;
}
