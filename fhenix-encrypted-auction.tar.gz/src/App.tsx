import { useState, useCallback } from "react";
import { Web3Provider, useWeb3, useAuctions } from "@/hooks/useWeb3";
import { Header } from "@/components/Header";
import { AuctionCard } from "@/components/AuctionCard";
import { CreateAuctionDialog } from "@/components/CreateAuctionDialog";
import { PlaceBidDialog } from "@/components/PlaceBidDialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, RefreshCw, Lock, Shield, Eye } from "lucide-react";

function AuctionDashboard() {
  const { auctionContract, isConnected } = useWeb3();
  const { auctions, loading, refetch } = useAuctions();
  const [createOpen, setCreateOpen] = useState(false);
  const [bidOpen, setBidOpen] = useState(false);
  const [selectedAuction, setSelectedAuction] = useState<number>(0);
  const [selectedMinBid, setSelectedMinBid] = useState(0);

  const handleBid = useCallback((auctionId: number) => {
    const auction = auctions[auctionId];
    setSelectedAuction(auctionId);
    setSelectedMinBid(auction?.minimumBid ?? 0);
    setBidOpen(true);
  }, [auctions]);

  const handleSettle = useCallback(async (auctionId: number) => {
    if (!auctionContract) return;
    try {
      const tx = await auctionContract.settleAuction(auctionId);
      await tx.wait();
      refetch();
    } catch (err) {
      console.error("Failed to settle:", err);
    }
  }, [auctionContract, refetch]);

  const handleClaim = useCallback(async (auctionId: number) => {
    if (!auctionContract) return;
    try {
      const tx = await auctionContract.claimTokens(auctionId);
      await tx.wait();
      refetch();
    } catch (err) {
      console.error("Failed to claim:", err);
    }
  }, [auctionContract, refetch]);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Token Auction Launchpad</h2>
            <p className="text-muted-foreground">
              Sealed-bid auctions with FHE encrypted bids on Fhenix
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={refetch} disabled={loading}>
              <RefreshCw className={`mr-2 h-4 w-4 ${loading ? "animate-spin" : ""}`} />
              Refresh
            </Button>
            <Button onClick={() => setCreateOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              New Auction
            </Button>
          </div>
        </div>

        <div className="mb-8 grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Auctions</CardTitle>
              <Lock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{auctions.length}</div>
              <p className="text-xs text-muted-foreground">FHE-sealed auctions created</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Auctions</CardTitle>
              <Shield className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {auctions.filter((a) => !a.settled && Date.now() / 1000 < Number(a.endTime)).length}
              </div>
              <p className="text-xs text-muted-foreground">Accepting encrypted bids</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Settled</CardTitle>
              <Eye className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {auctions.filter((a) => a.settled).length}
              </div>
              <p className="text-xs text-muted-foreground">Bids revealed, winners determined</p>
            </CardContent>
          </Card>
        </div>

        {auctions.length === 0 && !loading ? (
          <Card className="flex flex-col items-center justify-center py-12">
            <Lock className="mb-4 h-12 w-12 text-muted-foreground/50" />
            <h3 className="text-lg font-semibold">No auctions yet</h3>
            <p className="mb-4 text-sm text-muted-foreground">
              Create your first FHE-sealed auction to get started.
            </p>
            <Button onClick={() => setCreateOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Create Auction
            </Button>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {auctions.map((auction, idx) => (
              <AuctionCard
                key={idx}
                auction={auction}
                auctionId={idx}
                onBid={handleBid}
                onSettle={handleSettle}
                onClaim={handleClaim}
              />
            ))}
          </div>
        )}

        <CreateAuctionDialog
          open={createOpen}
          onOpenChange={setCreateOpen}
          onSuccess={refetch}
        />

        <PlaceBidDialog
          open={bidOpen}
          onOpenChange={setBidOpen}
          auctionId={selectedAuction}
          minimumBid={selectedMinBid}
          onSuccess={refetch}
        />
      </main>
    </div>
  );
}

export default function App() {
  return (
    <Web3Provider>
      <AuctionDashboard />
    </Web3Provider>
  );
}
