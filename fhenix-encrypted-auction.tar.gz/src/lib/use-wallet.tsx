"use client";

import { useState, useEffect, useCallback, createContext, useContext, type ReactNode } from "react";
import { BrowserProvider } from "ethers";

interface WalletContextValue {
  provider: BrowserProvider | null;
  address: string | null;
  chainId: number | null;
  connecting: boolean;
  connect: () => Promise<void>;
  disconnect: () => void;
}

const WalletContext = createContext<WalletContextValue>({
  provider: null,
  address: null,
  chainId: null,
  connecting: false,
  connect: async () => {},
  disconnect: () => {},
});

export function WalletProvider({ children }: { children: ReactNode }) {
  const [provider, setProvider] = useState<BrowserProvider | null>(null);
  const [address, setAddress] = useState<string | null>(null);
  const [chainId, setChainId] = useState<number | null>(null);
  const [connecting, setConnecting] = useState(false);

  const connect = useCallback(async () => {
    if (typeof window === "undefined" || !(window as unknown as Record<string, unknown>).ethereum) {
      alert("Please install MetaMask to use this application");
      return;
    }
    setConnecting(true);
    try {
      const ethereum = (window as unknown as Record<string, unknown>).ethereum as {
        request: (args: { method: string; params?: unknown[] }) => Promise<unknown>;
        on: (event: string, handler: (...args: unknown[]) => void) => void;
      };
      await ethereum.request({ method: "eth_requestAccounts" });
      const bp = new BrowserProvider(ethereum as unknown as never);
      const network = await bp.getNetwork();
      const accounts = await bp.listAccounts();
      setProvider(bp);
      setAddress(accounts[0]?.address ?? null);
      setChainId(Number(network.chainId));

      ethereum.on("accountsChanged", (...args: unknown[]) => {
        const accs = args[0] as string[];
        setAddress(accs[0] ?? null);
      });
      ethereum.on("chainChanged", () => window.location.reload());
    } catch (err) {
      console.error("Wallet connect failed:", err);
    } finally {
      setConnecting(false);
    }
  }, []);

  const disconnect = useCallback(() => {
    setProvider(null);
    setAddress(null);
    setChainId(null);
  }, []);

  useEffect(() => {
    if (typeof window === "undefined" || !(window as unknown as Record<string, unknown>).ethereum) return;
    const ethereum = (window as unknown as Record<string, unknown>).ethereum as {
      request: (args: { method: string }) => Promise<unknown>;
    };
    ethereum.request({ method: "eth_accounts" }).then((accounts) => {
      const accs = accounts as string[];
      if (accs.length > 0) connect();
    });
  }, [connect]);

  return (
    <WalletContext.Provider value={{ provider, address, chainId, connecting, connect, disconnect }}>
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  return useContext(WalletContext);
}
