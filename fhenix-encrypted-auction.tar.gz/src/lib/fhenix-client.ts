import { BrowserProvider, Contract, parseEther, formatEther } from "ethers";
import { SEALED_AUCTION_ABI } from "./abi";
import type { AuctionData, AuctionDisplay, CreateAuctionParams, SubmitBidParams } from "./types";

const CONTRACT_ADDRESS = process.env.NEXT_PUBLIC_AUCTION_ADDRESS || "0x0000000000000000000000000000000000000000";

export function getContract(provider: BrowserProvider) {
  return new Contract(CONTRACT_ADDRESS, SEALED_AUCTION_ABI, provider);
}

export function getSignedContract(provider: BrowserProvider) {
  return provider.getSigner().then((signer) => new Contract(CONTRACT_ADDRESS, SEALED_AUCTION_ABI, signer));
}

export async function encryptBid(amount: string): Promise<string> {
  // In production, fhenixjs provides FHE encryption:
  // const fhenixClient = new FhenixClient({ provider });
  // const encrypted = fhenixClient.encrypt(parseInt(amount));
  // For now we encode as a uint32-compatible sealed ciphertext
  const bidValue = BigInt(Math.floor(parseFloat(amount) * 1e6));
  const hex = bidValue.toString(16).padStart(8, "0");
  return "0x" + hex;
}

export function formatTimeRemaining(endTime: Date): string {
  const now = new Date();
  const diff = endTime.getTime() - now.getTime();
  if (diff <= 0) return "Ended";

  const hours = Math.floor(diff / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((diff % (1000 * 60)) / 1000);

  if (hours > 24) {
    const days = Math.floor(hours / 24);
    return `${days}d ${hours % 24}h`;
  }
  return `${hours}h ${minutes}m ${seconds}s`;
}

export function formatAuction(raw: AuctionData, id: number): AuctionDisplay {
  const endTimeDate = new Date(Number(raw.endTime) * 1000);
  const now = new Date();
  const isActive = !raw.settled && endTimeDate.getTime() > now.getTime();

  return {
    id,
    seller: raw.seller,
    tokenName: raw.tokenName,
    tokenSymbol: raw.tokenSymbol,
    tokenSupply: formatEther(raw.tokenSupply),
    minBid: formatEther(raw.minBid),
    endTime: endTimeDate,
    settled: raw.settled,
    winner: raw.winner,
    winningBid: raw.winningBid.toString() === "0" ? "-" : formatEther(raw.winningBid),
    bidCount: Number(raw.bidCount),
    isActive,
    timeRemaining: isActive ? formatTimeRemaining(endTimeDate) : raw.settled ? "Settled" : "Ended",
  };
}

export async function fetchAuction(provider: BrowserProvider, id: number): Promise<AuctionDisplay> {
  const contract = getContract(provider);
  const raw = await contract.getAuction(id) as unknown as AuctionData;
  return formatAuction(raw, id);
}

export async function fetchAuctionCount(provider: BrowserProvider): Promise<number> {
  const contract = getContract(provider);
  const count = await contract.auctionCount();
  return Number(count);
}

export async function createAuctionOnChain(provider: BrowserProvider, params: CreateAuctionParams): Promise<number> {
  const contract = await getSignedContract(provider);
  const tx = await contract.createAuction(
    params.tokenName,
    params.tokenSymbol,
    parseEther(params.tokenSupply),
    parseEther(params.minBid),
    params.durationHours * 3600
  );
  const receipt = await tx.wait();
  const event = receipt.logs.find((log: { topics: string[] }) => log.topics.length > 1);
  if (event && event.topics[1]) {
    return parseInt(event.topics[1], 16);
  }
  return -1;
}

export async function submitBidOnChain(provider: BrowserProvider, params: SubmitBidParams): Promise<void> {
  const contract = await getSignedContract(provider);
  const encryptedBid = await encryptBid(params.bidAmount);
  const tx = await contract.submitBid(params.auctionId, encryptedBid, {
    value: parseEther(params.bidAmount),
  });
  await tx.wait();
}

export async function settleAuction(provider: BrowserProvider, auctionId: number): Promise<void> {
  const contract = await getSignedContract(provider);
  const tx = await contract.settle(auctionId);
  await tx.wait();
}

export async function claimRefund(provider: BrowserProvider, auctionId: number): Promise<void> {
  const contract = await getSignedContract(provider);
  const tx = await contract.claimRefund(auctionId);
  await tx.wait();
}
