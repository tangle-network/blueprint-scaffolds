export interface AuctionData {
  seller: string;
  tokenName: string;
  tokenSymbol: string;
  tokenSupply: bigint;
  minBid: bigint;
  endTime: bigint;
  settled: boolean;
  winner: string;
  winningBid: bigint;
  bidCount: bigint;
}

export interface AuctionDisplay {
  id: number;
  seller: string;
  tokenName: string;
  tokenSymbol: string;
  tokenSupply: string;
  minBid: string;
  endTime: Date;
  settled: boolean;
  winner: string;
  winningBid: string;
  bidCount: number;
  isActive: boolean;
  timeRemaining: string;
}

export type AuctionStatus = "active" | "ended" | "settled";

export interface CreateAuctionParams {
  tokenName: string;
  tokenSymbol: string;
  tokenSupply: string;
  minBid: string;
  durationHours: number;
}

export interface SubmitBidParams {
  auctionId: number;
  bidAmount: string;
}
