"use client";

import { useState, useEffect, useCallback } from "react";
import { BrowserProvider } from "ethers";
import { fetchAuction, fetchAuctionCount } from "./fhenix-client";
import type { AuctionDisplay } from "./types";

export function useAuctions(provider: BrowserProvider | null) {
  const [auctions, setAuctions] = useState<AuctionDisplay[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    if (!provider) {
      setAuctions([]);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const count = await fetchAuctionCount(provider);
      const fetched: AuctionDisplay[] = [];
      for (let i = 0; i < count; i++) {
        try {
          const auction = await fetchAuction(provider, i);
          fetched.push(auction);
        } catch {
          // Skip auctions that fail to load
        }
      }
      setAuctions(fetched);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to fetch auctions");
    } finally {
      setLoading(false);
    }
  }, [provider]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  // Poll for time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setAuctions((prev) =>
        prev.map((a) => {
          if (!a.isActive) return a;
          const now = new Date();
          const diff = a.endTime.getTime() - now.getTime();
          const isActive = diff > 0;
          return {
            ...a,
            isActive,
            timeRemaining: isActive ? formatTimeLeft(a.endTime) : "Ended",
          };
        })
      );
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return { auctions, loading, error, refresh };
}

function formatTimeLeft(endTime: Date): string {
  const diff = endTime.getTime() - Date.now();
  if (diff <= 0) return "Ended";
  const h = Math.floor(diff / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  const s = Math.floor((diff % 60000) / 1000);
  if (h > 24) return `${Math.floor(h / 24)}d ${h % 24}h`;
  return `${h}h ${m}m ${s}s`;
}
