import { ethers } from "ethers";

export function encryptBid(amount: number): string {
  const hexValue = ethers.zeroPadValue(ethers.toBeHex(amount), 32);
  return hexValue;
}

export function createEncryptedBid32(amount: number): string {
  return ethers.zeroPadValue(ethers.toBeHex(amount), 32);
}

export function formatAddress(address: string): string {
  if (!address || address === ethers.ZeroAddress) return "—";
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

export function formatTokenAmount(amount: bigint): string {
  return ethers.formatEther(amount);
}

export function formatTimestamp(timestamp: bigint): string {
  return new Date(Number(timestamp) * 1000).toLocaleString();
}

export function getAuctionStatus(
  endTime: bigint,
  settled: boolean,
  bidCount: bigint
): "active" | "ended" | "settled" | "no-bids" {
  if (settled) return "settled";
  if (bidCount === 0n && Date.now() / 1000 > Number(endTime)) return "no-bids";
  if (Date.now() / 1000 > Number(endTime)) return "ended";
  return "active";
}

export function getTimeRemaining(endTime: bigint): string {
  const remaining = Number(endTime) - Math.floor(Date.now() / 1000);
  if (remaining <= 0) return "Ended";
  const hours = Math.floor(remaining / 3600);
  const minutes = Math.floor((remaining % 3600) / 60);
  const seconds = remaining % 60;
  if (hours > 0) return `${hours}h ${minutes}m ${seconds}s`;
  if (minutes > 0) return `${minutes}m ${seconds}s`;
  return `${seconds}s`;
}
