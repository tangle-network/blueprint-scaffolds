import { useState, useEffect, useCallback, createContext, useContext, createElement, type ReactNode } from "react";
import { ethers, BrowserProvider, Contract, JsonRpcProvider } from "ethers";
import { SEALED_AUCTION_ABI, AUCTION_FACTORY_ABI, type AuctionData } from "@/contracts/abis";

const SEALED_AUCTION_ADDRESS = "0x5FbDB2315678afecb367f032d93F642f64180aa3";
const AUCTION_FACTORY_ADDRESS = "0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512";

interface Web3ContextType {
  provider: JsonRpcProvider | null;
  signer: ethers.JsonRpcSigner | null;
  address: string | null;
  auctionContract: Contract | null;
  factoryContract: Contract | null;
  connect: () => Promise<void>;
  isConnected: boolean;
  chainId: number | null;
}

const Web3Context = createContext<Web3ContextType>({
  provider: null,
  signer: null,
  address: null,
  auctionContract: null,
  factoryContract: null,
  connect: async () => {},
  isConnected: false,
  chainId: null,
});

export function Web3Provider({ children }: { children: ReactNode }) {
  const [provider, setProvider] = useState<JsonRpcProvider | null>(null);
  const [signer, setSigner] = useState<ethers.JsonRpcSigner | null>(null);
  const [address, setAddress] = useState<string | null>(null);
  const [chainId, setChainId] = useState<number | null>(null);

  const connect = useCallback(async () => {
    if (typeof window !== "undefined" && typeof (window as any).ethereum !== "undefined") {
      try {
        const browserProvider = new BrowserProvider((window as any).ethereum);
        const accounts = await browserProvider.send("eth_requestAccounts", []);
        const web3Signer = await browserProvider.getSigner();
        const network = await browserProvider.getNetwork();

        setProvider(browserProvider as unknown as JsonRpcProvider);
        setSigner(web3Signer);
        setAddress(accounts[0]);
        setChainId(Number(network.chainId));
      } catch (err) {
        console.error("Failed to connect wallet:", err);
      }
    } else {
      const fallbackProvider = new JsonRpcProvider("http://127.0.0.1:8545");
      setProvider(fallbackProvider);
      setChainId(31337);
    }
  }, []);

  useEffect(() => {
    if (typeof window !== "undefined" && typeof (window as any).ethereum !== "undefined") {
      const browserProvider = new BrowserProvider((window as any).ethereum);
      setProvider(browserProvider as unknown as JsonRpcProvider);

      (window as any).ethereum.on("accountsChanged", (accounts: string[]) => {
        setAddress(accounts[0] || null);
      });
      (window as any).ethereum.on("chainChanged", () => {
        window.location.reload();
      });
    } else {
      const fallbackProvider = new JsonRpcProvider("http://127.0.0.1:8545");
      setProvider(fallbackProvider);
      setChainId(31337);
    }
  }, []);

  const readOnlyAuction = provider
    ? new Contract(SEALED_AUCTION_ADDRESS, SEALED_AUCTION_ABI, provider)
    : null;

  const readOnlyFactory = provider
    ? new Contract(AUCTION_FACTORY_ADDRESS, AUCTION_FACTORY_ABI, provider)
    : null;

  const value: Web3ContextType = {
    provider,
    signer,
    address,
    isConnected: !!signer && !!address,
    auctionContract: signer
      ? new Contract(SEALED_AUCTION_ADDRESS, SEALED_AUCTION_ABI, signer)
      : readOnlyAuction,
    factoryContract: signer
      ? new Contract(AUCTION_FACTORY_ADDRESS, AUCTION_FACTORY_ABI, signer)
      : readOnlyFactory,
    connect,
    chainId,
  };

  return createElement(Web3Context.Provider, { value }, children);
}

export function useWeb3() {
  return useContext(Web3Context);
}

export function useAuctions() {
  const { auctionContract } = useWeb3();
  const [auctions, setAuctions] = useState<AuctionData[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchAuctions = useCallback(async () => {
    if (!auctionContract) return;
    setLoading(true);
    try {
      const count = await auctionContract.auctionCount();
      const total = Number(count);
      const fetched: AuctionData[] = [];
      for (let i = 0; i < total; i++) {
        const data = await auctionContract.getAuction(i);
        fetched.push({
          creator: data.creator,
          tokenAddress: data.tokenAddress,
          tokenAmount: data.tokenAmount,
          minimumBid: Number(data.minimumBid),
          startTime: data.startTime,
          endTime: data.endTime,
          settled: data.settled,
          winner: data.winner,
          winningBid: Number(data.winningBid),
          bidCount: data.bidCount,
        });
      }
      setAuctions(fetched);
    } catch (err) {
      console.error("Failed to fetch auctions:", err);
    } finally {
      setLoading(false);
    }
  }, [auctionContract]);

  useEffect(() => {
    fetchAuctions();
    const interval = setInterval(fetchAuctions, 15000);
    return () => clearInterval(interval);
  }, [fetchAuctions]);

  return { auctions, loading, refetch: fetchAuctions };
}

export function useAuction(auctionId: number) {
  const { auctionContract } = useWeb3();
  const [auction, setAuction] = useState<AuctionData | null>(null);
  const [loading, setLoading] = useState(false);

  const fetchAuction = useCallback(async () => {
    if (!auctionContract || auctionId < 0) return;
    setLoading(true);
    try {
      const data = await auctionContract.getAuction(auctionId);
      setAuction({
        creator: data.creator,
        tokenAddress: data.tokenAddress,
        tokenAmount: data.tokenAmount,
        minimumBid: Number(data.minimumBid),
        startTime: data.startTime,
        endTime: data.endTime,
        settled: data.settled,
        winner: data.winner,
        winningBid: Number(data.winningBid),
        bidCount: data.bidCount,
      });
    } catch (err) {
      console.error("Failed to fetch auction:", err);
    } finally {
      setLoading(false);
    }
  }, [auctionContract, auctionId]);

  useEffect(() => {
    fetchAuction();
  }, [fetchAuction]);

  return { auction, loading, refetch: fetchAuction };
}
