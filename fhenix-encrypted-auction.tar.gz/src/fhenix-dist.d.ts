declare module "../node_modules/fhenixjs/dist/fhenix.esm.js" {
  export * from "fhenixjs";
}
