import { useState } from "react";
import { useWeb3 } from "@/hooks/useWeb3";
import { encryptBid } from "@/lib/fhenix";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Lock, Shield } from "lucide-react";

interface PlaceBidDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  auctionId: number;
  minimumBid: number;
  onSuccess: () => void;
}

export function PlaceBidDialog({ open, onOpenChange, auctionId, minimumBid, onSuccess }: PlaceBidDialogProps) {
  const { auctionContract } = useWeb3();
  const [bidAmount, setBidAmount] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!auctionContract || !bidAmount) return;
    setLoading(true);
    try {
      const encrypted = encryptBid(Number(bidAmount));
      const tx = await auctionContract.placeBid(auctionId, encrypted);
      await tx.wait();
      setBidAmount("");
      onOpenChange(false);
      onSuccess();
    } catch (err) {
      console.error("Failed to place bid:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Place Encrypted Bid</DialogTitle>
          <DialogDescription>
            Your bid will be encrypted using Fully Homomorphic Encryption (FHE). No one can see your bid amount until the auction settles.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="flex items-center gap-2 rounded-lg border border-primary/20 bg-primary/5 p-3 text-sm">
            <Shield className="h-4 w-4 text-primary" />
            <span>FHE encryption ensures your bid is completely private during the auction.</span>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="bidAmount">Bid Amount</Label>
            <Input
              id="bidAmount"
              type="number"
              placeholder={`Min: ${minimumBid}`}
              value={bidAmount}
              onChange={(e) => setBidAmount(e.target.value)}
            />
            <p className="text-xs text-muted-foreground">
              Minimum bid: {minimumBid}
            </p>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={loading || !bidAmount}>
            <Lock className="mr-2 h-4 w-4" />
            {loading ? "Encrypting & Submitting..." : "Submit Encrypted Bid"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
