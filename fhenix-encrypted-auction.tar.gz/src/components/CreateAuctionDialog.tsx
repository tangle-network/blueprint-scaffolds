import { useState } from "react";
import { useWeb3 } from "@/hooks/useWeb3";
import { encryptBid } from "@/lib/fhenix";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Lock } from "lucide-react";

interface CreateAuctionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

export function CreateAuctionDialog({ open, onOpenChange, onSuccess }: CreateAuctionDialogProps) {
  const { auctionContract } = useWeb3();
  const [tokenAddress, setTokenAddress] = useState("");
  const [tokenAmount, setTokenAmount] = useState("");
  const [minimumBid, setMinimumBid] = useState("");
  const [duration, setDuration] = useState("3600");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!auctionContract || !tokenAddress || !tokenAmount || !minimumBid || !duration) return;
    setLoading(true);
    try {
      const tx = await auctionContract.createAuction(
        tokenAddress,
        BigInt(tokenAmount),
        Number(minimumBid),
        Number(duration)
      );
      await tx.wait();
      setTokenAddress("");
      setTokenAmount("");
      setMinimumBid("");
      setDuration("3600");
      onOpenChange(false);
      onSuccess();
    } catch (err) {
      console.error("Failed to create auction:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Create New Auction</DialogTitle>
          <DialogDescription>
            Launch a new sealed-bid auction. All bids will be encrypted using FHE via Fhenix.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="tokenAddress">Token Address</Label>
            <Input
              id="tokenAddress"
              placeholder="0x..."
              value={tokenAddress}
              onChange={(e) => setTokenAddress(e.target.value)}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="tokenAmount">Token Amount (wei)</Label>
            <Input
              id="tokenAmount"
              type="number"
              placeholder="10000000000000000000000"
              value={tokenAmount}
              onChange={(e) => setTokenAmount(e.target.value)}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="minimumBid">Minimum Bid</Label>
            <Input
              id="minimumBid"
              type="number"
              placeholder="100"
              value={minimumBid}
              onChange={(e) => setMinimumBid(e.target.value)}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="duration">Duration (seconds)</Label>
            <Input
              id="duration"
              type="number"
              placeholder="3600"
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={loading}>
            <Lock className="mr-2 h-4 w-4" />
            {loading ? "Creating..." : "Create Auction"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
