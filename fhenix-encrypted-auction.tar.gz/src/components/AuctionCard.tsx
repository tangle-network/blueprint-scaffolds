import { type AuctionData } from "@/contracts/abis";
import { getAuctionStatus, getTimeRemaining, formatTokenAmount, formatAddress } from "@/lib/fhenix";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, Users, Trophy, Coins, Lock } from "lucide-react";
import { useEffect, useState } from "react";

interface AuctionCardProps {
  auction: AuctionData;
  auctionId: number;
  onBid: (auctionId: number) => void;
  onSettle: (auctionId: number) => void;
  onClaim: (auctionId: number) => void;
}

export function AuctionCard({ auction, auctionId, onBid, onSettle, onClaim }: AuctionCardProps) {
  const [timeRemaining, setTimeRemaining] = useState("");
  const status = getAuctionStatus(auction.endTime, auction.settled, auction.bidCount);

  useEffect(() => {
    const update = () => setTimeRemaining(getTimeRemaining(auction.endTime));
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, [auction.endTime]);

  const statusColor: Record<string, string> = {
    active: "bg-green-500/10 text-green-600 border-green-200",
    ended: "bg-yellow-500/10 text-yellow-600 border-yellow-200",
    settled: "bg-blue-500/10 text-blue-600 border-blue-200",
    "no-bids": "bg-red-500/10 text-red-600 border-red-200",
  };

  return (
    <Card className="transition-shadow hover:shadow-md">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Auction #{auctionId}</CardTitle>
          <Badge className={statusColor[status]} variant="outline">
            {status === "active" ? "Live" : status === "settled" ? "Settled" : status === "ended" ? "Pending Settlement" : "No Bids"}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Coins className="h-4 w-4" />
            <span>Token: {formatAddress(auction.tokenAddress)}</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <span className="font-medium">{formatTokenAmount(auction.tokenAmount)} tokens</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Lock className="h-4 w-4" />
            <span>Min Bid: {auction.minimumBid}</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Users className="h-4 w-4" />
            <span>{Number(auction.bidCount)} bid{Number(auction.bidCount) !== 1 ? "s" : ""}</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Clock className="h-4 w-4" />
            <span>{timeRemaining}</span>
          </div>
          {auction.settled && (
            <div className="flex items-center gap-2 text-muted-foreground">
              <Trophy className="h-4 w-4" />
              <span>Winner: {formatAddress(auction.winner)}</span>
            </div>
          )}
        </div>
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <Lock className="h-3 w-3" />
          <span>All bids encrypted via FHE — amounts hidden until settlement</span>
        </div>
      </CardContent>
      <CardFooter className="flex gap-2">
        {status === "active" && (
          <Button onClick={() => onBid(auctionId)} className="flex-1">
            <Lock className="mr-2 h-4 w-4" />
            Place Encrypted Bid
          </Button>
        )}
        {status === "ended" && (
          <Button onClick={() => onSettle(auctionId)} className="flex-1" variant="default">
            Settle Auction
          </Button>
        )}
        {status === "settled" && (
          <Button onClick={() => onClaim(auctionId)} className="flex-1" variant="secondary">
            Claim Tokens
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}
