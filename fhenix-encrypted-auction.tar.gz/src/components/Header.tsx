import { useWeb3 } from "@/hooks/useWeb3";
import { Button } from "@/components/ui/button";
import { Shield } from "lucide-react";

export function Header() {
  const { address, isConnected, connect } = useWeb3();

  return (
    <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <Shield className="h-6 w-6 text-primary" />
          <h1 className="text-xl font-bold">FHE Auction Launchpad</h1>
          <span className="ml-2 rounded-full bg-primary/10 px-2 py-0.5 text-xs text-primary">
            Fhenix Powered
          </span>
        </div>
        <div className="flex items-center gap-4">
          {isConnected ? (
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-green-500" />
              <span className="text-sm text-muted-foreground">
                {address ? `${address.slice(0, 6)}...${address.slice(-4)}` : ""}
              </span>
            </div>
          ) : (
            <Button onClick={connect} variant="outline">
              Connect Wallet
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
