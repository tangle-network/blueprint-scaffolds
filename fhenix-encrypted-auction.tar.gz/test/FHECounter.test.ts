import { expect } from "chai";
import hre from "hardhat";
import { CofheClient } from "cofhejs";

describe("FHECounter", function () {
  let counter: any;
  let client: CofheClient;
  let owner: any;

  beforeEach(async function () {
    [owner] = await hre.ethers.getSigners();
    client = await CofheClient.create({ provider: hre.ethers.provider });

    const Counter = await hre.ethers.getContractFactory("FHECounter");
    counter = await Counter.deploy();
    await counter.waitForDeployment();
  });

  it("should increment with encrypted amount", async function () {
    const encrypted = await client.encrypt_uint32(5);
    await counter.increment(encrypted);
  });
});
