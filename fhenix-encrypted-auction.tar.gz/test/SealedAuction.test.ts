import { expect } from "chai";
import { ethers } from "hardhat";
import { HardhatEthersSigner } from "@nomicfoundation/hardhat-ethers/signers";

describe("SealedAuction", function () {
  let auction: any;
  let token: any;
  let owner: HardhatEthersSigner;
  let bidder1: HardhatEthersSigner;
  let bidder2: HardhatEthersSigner;

  const AUCTION_DURATION = 3600;
  const MINIMUM_BID = 100;
  const TOKEN_AMOUNT = ethers.parseEther("10000");

  beforeEach(async function () {
    [owner, bidder1, bidder2] = await ethers.getSigners();

    const MockToken = await ethers.getContractFactory("MockToken");
    token = await MockToken.deploy(ethers.parseEther("1000000"));
    await token.waitForDeployment();

    const SealedAuction = await ethers.getContractFactory("SealedAuction");
    auction = await SealedAuction.deploy();
    await auction.waitForDeployment();
  });

  describe("Auction Creation", function () {
    it("should create an auction", async function () {
      const tx = await auction.createAuction(
        await token.getAddress(),
        TOKEN_AMOUNT,
        MINIMUM_BID,
        AUCTION_DURATION
      );

      await expect(tx)
        .to.emit(auction, "AuctionCreated")
        .withArgs(0, owner.address, await token.getAddress(), TOKEN_AMOUNT, MINIMUM_BID, (await ethers.provider.getBlock("latest"))!.timestamp + AUCTION_DURATION + 1);
    });

    it("should revert if duration is 0", async function () {
      await expect(
        auction.createAuction(await token.getAddress(), TOKEN_AMOUNT, MINIMUM_BID, 0)
      ).to.be.revertedWith("Duration must be > 0");
    });

    it("should revert if token amount is 0", async function () {
      await expect(
        auction.createAuction(await token.getAddress(), 0, MINIMUM_BID, AUCTION_DURATION)
      ).to.be.revertedWith("Token amount must be > 0");
    });

    it("should increment auction count", async function () {
      await auction.createAuction(await token.getAddress(), TOKEN_AMOUNT, MINIMUM_BID, AUCTION_DURATION);
      expect(await auction.auctionCount()).to.equal(1);
    });
  });

  describe("Bid Submission", function () {
    beforeEach(async function () {
      await auction.createAuction(
        await token.getAddress(),
        TOKEN_AMOUNT,
        MINIMUM_BID,
        AUCTION_DURATION
      );
    });

    it("should place an encrypted bid", async function () {
      const encryptedBid = ethers.zeroPadValue(ethers.toBeHex(150), 32);
      const tx = await auction.connect(bidder1).placeBid(0, encryptedBid);
      await expect(tx).to.emit(auction, "BidPlaced").withArgs(0, bidder1.address, 0);
    });

    it("should prevent double bidding", async function () {
      const encryptedBid = ethers.zeroPadValue(ethers.toBeHex(150), 32);
      await auction.connect(bidder1).placeBid(0, encryptedBid);
      await expect(
        auction.connect(bidder1).placeBid(0, encryptedBid)
      ).to.be.revertedWith("Already placed a bid");
    });
  });

  describe("Auction Settlement", function () {
    beforeEach(async function () {
      await auction.createAuction(
        await token.getAddress(),
        TOKEN_AMOUNT,
        MINIMUM_BID,
        AUCTION_DURATION
      );

      const bid1 = ethers.zeroPadValue(ethers.toBeHex(150), 32);
      const bid2 = ethers.zeroPadValue(ethers.toBeHex(200), 32);
      await auction.connect(bidder1).placeBid(0, bid1);
      await auction.connect(bidder2).placeBid(0, bid2);
    });

    it("should not settle before auction ends", async function () {
      await expect(auction.settleAuction(0)).to.be.revertedWith("Auction not ended");
    });

    it("should settle after auction ends and determine winner", async function () {
      await ethers.provider.send("evm_increaseTime", [AUCTION_DURATION + 1]);
      await ethers.provider.send("evm_mine");

      const tx = await auction.settleAuction(0);
      await expect(tx).to.emit(auction, "AuctionSettled");

      const auctionData = await auction.getAuction(0);
      expect(auctionData.settled).to.be.true;
      expect(auctionData.winner).to.not.equal(ethers.ZeroAddress);
    });

    it("should not settle twice", async function () {
      await ethers.provider.send("evm_increaseTime", [AUCTION_DURATION + 1]);
      await ethers.provider.send("evm_mine");

      await auction.settleAuction(0);
      await expect(auction.settleAuction(0)).to.be.revertedWith("Already settled");
    });
  });

  describe("Refund", function () {
    beforeEach(async function () {
      await auction.createAuction(
        await token.getAddress(),
        TOKEN_AMOUNT,
        MINIMUM_BID,
        AUCTION_DURATION
      );

      const bid1 = ethers.zeroPadValue(ethers.toBeHex(150), 32);
      const bid2 = ethers.zeroPadValue(ethers.toBeHex(200), 32);
      await auction.connect(bidder1).placeBid(0, bid1);
      await auction.connect(bidder2).placeBid(0, bid2);

      await ethers.provider.send("evm_increaseTime", [AUCTION_DURATION + 1]);
      await ethers.provider.send("evm_mine");
      await auction.settleAuction(0);
    });

    it("should allow non-winner to claim refund", async function () {
      const auctionData = await auction.getAuction(0);
      const loserBidIndex = auctionData.winner === bidder1.address ? 0 : 1;
      const loser = auctionData.winner === bidder1.address ? bidder2 : bidder1;

      const tx = await auction.connect(loser).claimRefund(0, loserBidIndex);
      await expect(tx).to.emit(auction, "RefundClaimed");
    });
  });
});
