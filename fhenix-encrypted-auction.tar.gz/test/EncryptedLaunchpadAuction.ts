import { expect } from "chai";
import hre from "hardhat";

const { ethers } = hre;

describe("EncryptedLaunchpadAuction", function () {
  it("deploys the auction and token sale inventory", async function () {
    const [owner] = await ethers.getSigners();
    const tokenFactory = await ethers.getContractFactory("LaunchToken");
    const token = await tokenFactory.deploy("Encrypted Launch Token", "ELT", owner.address);
    await token.waitForDeployment();

    const auctionFactory = await ethers.getContractFactory("EncryptedLaunchpadAuction");
    const now = (await ethers.provider.getBlock("latest"))!.timestamp;
    const auction = await auctionFactory.deploy(
      {
        metadataURI: "ipfs://encrypted-launchpad/test",
        reservePrice: 1_000_000n,
        minDeposit: 1_000_000n,
        maxDeposit: 10_000_000n,
        tokensForSale: ethers.parseUnits("1000", 18),
        startTime: BigInt(now + 1),
        endTime: BigInt(now + 3600),
        token: await token.getAddress()
      },
      owner.address
    );
    await auction.waitForDeployment();

    await (await token.mint(await auction.getAddress(), ethers.parseUnits("1000", 18))).wait();

    expect(await token.balanceOf(await auction.getAddress())).to.equal(ethers.parseUnits("1000", 18));
    expect(await auction.owner()).to.equal(owner.address);
  });
});
