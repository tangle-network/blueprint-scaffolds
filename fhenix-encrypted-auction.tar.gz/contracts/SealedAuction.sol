// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "./FHE.sol";
import {FHELib, Permission} from "./FHE.sol";

contract SealedAuction {
    using FHELib for euint32;
    using FHELib for ebool;

    struct Bid {
        euint32 encryptedAmount;
        address bidder;
        bool claimed;
    }

    struct Auction {
        address creator;
        address tokenAddress;
        uint256 tokenAmount;
        uint32 minimumBid;
        uint256 startTime;
        uint256 endTime;
        bool settled;
        address winner;
        uint32 winningBid;
        uint256 bidCount;
    }

    mapping(uint256 => Auction) public auctions;
    mapping(uint256 => mapping(uint256 => Bid)) public auctionBids;
    mapping(uint256 => mapping(address => bool)) public hasBid;

    uint256 public auctionCount;

    event AuctionCreated(
        uint256 indexed auctionId,
        address indexed creator,
        address tokenAddress,
        uint256 tokenAmount,
        uint32 minimumBid,
        uint256 endTime
    );

    event BidPlaced(uint256 indexed auctionId, address indexed bidder, uint256 bidIndex);
    event AuctionSettled(uint256 indexed auctionId, address winner, uint32 winningBid);
    event RefundClaimed(uint256 indexed auctionId, address indexed bidder);

    function createAuction(
        address tokenAddress,
        uint256 tokenAmount,
        uint32 minimumBid,
        uint256 durationSeconds
    ) external returns (uint256) {
        require(durationSeconds > 0, "Duration must be > 0");
        require(tokenAmount > 0, "Token amount must be > 0");

        uint256 auctionId = auctionCount++;
        Auction storage a = auctions[auctionId];
        a.creator = msg.sender;
        a.tokenAddress = tokenAddress;
        a.tokenAmount = tokenAmount;
        a.minimumBid = minimumBid;
        a.startTime = block.timestamp;
        a.endTime = block.timestamp + durationSeconds;
        a.settled = false;
        a.winner = address(0);
        a.winningBid = 0;
        a.bidCount = 0;

        emit AuctionCreated(auctionId, msg.sender, tokenAddress, tokenAmount, minimumBid, a.endTime);

        return auctionId;
    }

    function placeBid(uint256 auctionId, inEuint32 encryptedBid) external {
        Auction storage a = auctions[auctionId];
        require(a.creator != address(0), "Auction does not exist");
        require(block.timestamp < a.endTime, "Auction has ended");
        require(!hasBid[auctionId][msg.sender], "Already placed a bid");

        euint32 bidAmount = FHELib.asEuint32(encryptedBid);

        ebool isValidBid = FHELib.gt(bidAmount, FHELib.asEuint32(a.minimumBid));
        require(FHELib.decrypt(isValidBid), "Bid below minimum");

        Permission.allow(bidAmount, address(this));

        uint256 bidIndex = a.bidCount;
        auctionBids[auctionId][bidIndex] = Bid({
            encryptedAmount: bidAmount,
            bidder: msg.sender,
            claimed: false
        });

        hasBid[auctionId][msg.sender] = true;
        a.bidCount++;

        emit BidPlaced(auctionId, msg.sender, bidIndex);
    }

    function settleAuction(uint256 auctionId) external {
        Auction storage a = auctions[auctionId];
        require(a.creator != address(0), "Auction does not exist");
        require(block.timestamp >= a.endTime, "Auction not ended");
        require(!a.settled, "Already settled");
        require(a.bidCount > 0, "No bids placed");

        uint32 highestBid = 0;
        address winner = address(0);

        for (uint256 i = 0; i < a.bidCount; i++) {
            Bid storage b = auctionBids[auctionId][i];
            uint32 bidValue = FHELib.decrypt(b.encryptedAmount);

            if (bidValue > highestBid) {
                highestBid = bidValue;
                winner = b.bidder;
            }
        }

        a.settled = true;
        a.winner = winner;
        a.winningBid = highestBid;

        emit AuctionSettled(auctionId, winner, highestBid);
    }

    function claimTokens(uint256 auctionId) external {
        Auction storage a = auctions[auctionId];
        require(a.settled, "Auction not settled");
        require(msg.sender == a.winner, "Not the winner");

        a.winner = address(0);

        emit AuctionSettled(auctionId, msg.sender, a.winningBid);
    }

    function claimRefund(uint256 auctionId, uint256 bidIndex) external {
        Auction storage a = auctions[auctionId];
        Bid storage b = auctionBids[auctionId][bidIndex];

        require(a.settled, "Auction not settled");
        require(b.bidder == msg.sender, "Not your bid");
        require(msg.sender != a.winner, "Winner cannot refund");
        require(!b.claimed, "Already claimed");

        b.claimed = true;

        emit RefundClaimed(auctionId, msg.sender);
    }

    function getAuction(uint256 auctionId)
        external
        view
        returns (
            address creator,
            address tokenAddress,
            uint256 tokenAmount,
            uint32 minimumBid,
            uint256 startTime,
            uint256 endTime,
            bool settled,
            address winner,
            uint32 winningBid,
            uint256 bidCount
        )
    {
        Auction storage a = auctions[auctionId];
        return (
            a.creator,
            a.tokenAddress,
            a.tokenAmount,
            a.minimumBid,
            a.startTime,
            a.endTime,
            a.settled,
            a.winner,
            a.winningBid,
            a.bidCount
        );
    }

    function getBid(uint256 auctionId, uint256 bidIndex)
        external
        view
        returns (address bidder, bool claimed)
    {
        Bid storage b = auctionBids[auctionId][bidIndex];
        return (b.bidder, b.claimed);
    }
}
