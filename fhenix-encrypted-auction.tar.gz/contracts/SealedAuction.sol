// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {FHE, euint32, inEuint32} from "@fhevm/solidity/lib/FHE.sol";
import {TFHEExecutor} from "@fhevm/solidity/TFHEExecutor.sol";

contract SealedAuction {
    struct Auction {
        address seller;
        string tokenName;
        string tokenSymbol;
        uint256 tokenSupply;
        uint256 minBid;
        uint256 endTime;
        bool settled;
        address winner;
        uint256 winningBid;
        uint256 bidCount;
    }

    mapping(uint256 => Auction) public auctions;
    mapping(uint256 => mapping(address => euint32)) internal encryptedBids;
    mapping(uint256 => mapping(address => bool)) public hasBid;
    mapping(uint256 => address[]) public bidders;
    mapping(uint256 => mapping(address => uint256)) public escrowedFunds;

    uint256 public auctionCount;

    event AuctionCreated(uint256 indexed auctionId, address indexed seller, string tokenName, uint256 endTime);
    event BidSubmitted(uint256 indexed auctionId, address indexed bidder);
    event AuctionSettled(uint256 indexed auctionId, address indexed winner, uint256 winningBid);
    event RefundClaimed(uint256 indexed auctionId, address indexed bidder, uint256 amount);

    error AuctionNotFound();
    error AuctionStillActive();
    error AuctionAlreadySettled();
    error BidTooLow();
    error AlreadyBid();
    error NotSeller();
    error NoBidPlaced();
    error AuctionNotEnded();
    error TransferFailed();

    function createAuction(
        string calldata _tokenName,
        string calldata _tokenSymbol,
        uint256 _tokenSupply,
        uint256 _minBid,
        uint256 _durationSeconds
    ) external returns (uint256) {
        require(_durationSeconds > 0, "Duration must be > 0");
        require(_tokenSupply > 0, "Supply must be > 0");

        uint256 auctionId = auctionCount++;
        Auction storage a = auctions[auctionId];
        a.seller = msg.sender;
        a.tokenName = _tokenName;
        a.tokenSymbol = _tokenSymbol;
        a.tokenSupply = _tokenSupply;
        a.minBid = _minBid;
        a.endTime = block.timestamp + _durationSeconds;
        a.settled = false;

        emit AuctionCreated(auctionId, msg.sender, _tokenName, a.endTime);
        return auctionId;
    }

    function submitBid(uint256 _auctionId, inEuint32 calldata _encryptedBid) external payable {
        Auction storage a = auctions[_auctionId];
        if (_auctionId >= auctionCount) revert AuctionNotFound();
        if (block.timestamp >= a.endTime) revert AuctionNotEnded();
        if (hasBid[_auctionId][msg.sender]) revert AlreadyBid();

        euint32 bid = FHE.asEuint32(_encryptedBid);

        uint32 minBidUint32 = uint32(a.minBid);
        euint32 minBidEnc = FHE.asEuint32(minBidUint32);
        euint32 cmp = FHE.ge(bid, minBidEnc);
        FHE.require(cmp);

        encryptedBids[_auctionId][msg.sender] = bid;
        hasBid[_auctionId][msg.sender] = true;
        bidders[_auctionId].push(msg.sender);
        escrowedFunds[_auctionId][msg.sender] = msg.value;
        a.bidCount++;

        emit BidSubmitted(_auctionId, msg.sender);
    }

    function settle(uint256 _auctionId) external {
        Auction storage a = auctions[_auctionId];
        if (_auctionId >= auctionCount) revert AuctionNotFound();
        if (block.timestamp < a.endTime) revert AuctionStillActive();
        if (a.settled) revert AuctionAlreadySettled();
        if (a.bidCount == 0) {
            a.settled = true;
            return;
        }

        address[] storage auctionBidders = bidders[_auctionId];
        address bestBidder = auctionBidders[0];
        euint32 highestBid = encryptedBids[_auctionId][bestBidder];

        for (uint256 i = 1; i < auctionBidders.length; i++) {
            address currentBidder = auctionBidders[i];
            euint32 currentBid = encryptedBids[_auctionId][currentBidder];
            euint32 isGreater = FHE.gt(currentBid, highestBid);
            euint32 newHighest = FHE.cmux(isGreater, currentBid, highestBid);

            // We need to track the winner outside FHE for distribution
            // Use a 2-pass approach: first find max bid value, then find who matches
            highestBid = newHighest;
        }

        // Decrypt winning bid through FHE decryption flow
        // In production, this would use FHE.decrypt with proper permissions
        // For the sealed auction, we use a permissioned decryption approach
        a.settled = true;

        emit AuctionSettled(_auctionId, bestBidder, 0);
    }

    function claimRefund(uint256 _auctionId) external {
        Auction storage a = auctions[_auctionId];
        if (!a.settled) revert AuctionAlreadySettled();

        uint256 amount = escrowedFunds[_auctionId][msg.sender];
        if (amount == 0) revert NoBidPlaced();
        if (msg.sender == a.winner) revert AlreadyBid();

        escrowedFunds[_auctionId][msg.sender] = 0;
        (bool success, ) = payable(msg.sender).call{value: amount}("");
        if (!success) revert TransferFailed();

        emit RefundClaimed(_auctionId, msg.sender, amount);
    }

    function getAuction(uint256 _auctionId)
        external
        view
        returns (
            address seller,
            string memory tokenName,
            string memory tokenSymbol,
            uint256 tokenSupply,
            uint256 minBid,
            uint256 endTime,
            bool settled,
            address winner,
            uint256 winningBid,
            uint256 bidCount
        )
    {
        Auction storage a = auctions[_auctionId];
        return (
            a.seller,
            a.tokenName,
            a.tokenSymbol,
            a.tokenSupply,
            a.minBid,
            a.endTime,
            a.settled,
            a.winner,
            a.winningBid,
            a.bidCount
        );
    }

    function getBidderCount(uint256 _auctionId) external view returns (uint256) {
        return bidders[_auctionId].length;
    }

    function isAuctionActive(uint256 _auctionId) external view returns (bool) {
        if (_auctionId >= auctionCount) return false;
        return block.timestamp < auctions[_auctionId].endTime && !auctions[_auctionId].settled;
    }
}
