// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IFHE {
    function euint32() external pure returns (string memory);
}

library FHE {
    enum euint32 {}
    enum euint16 {}
    enum ebool {}
    enum euint8 {}
}

type inEuint32 is bytes32;
type inEuint16 is bytes32;
type inEbool is bytes32;
type inEuint8 is bytes32;

type euint32 is uint256;
type euint16 is uint256;
type ebool is uint256;
type euint8 is uint256;

error FhenixOnly();

library FHELib {
    euint32 internal constant ZERO = euint32.wrap(0);

    function asEuint32(inEuint32 input) internal pure returns (euint32) {
        return euint32.wrap(inEuint32.unwrap(input));
    }

    function asEuint32(uint256 input) internal pure returns (euint32) {
        return euint32.wrap(input);
    }

    function add(euint32 a, euint32 b) internal pure returns (euint32) {
        return euint32.wrap(euint32.unwrap(a) + euint32.unwrap(b));
    }

    function sub(euint32 a, euint32 b) internal pure returns (euint32) {
        return euint32.wrap(euint32.unwrap(a) - euint32.unwrap(b));
    }

    function gt(euint32 a, euint32 b) internal pure returns (ebool) {
        return ebool.wrap(euint32.unwrap(a) > euint32.unwrap(b) ? 1 : 0);
    }

    function eq(euint32 a, euint32 b) internal pure returns (ebool) {
        return ebool.wrap(euint32.unwrap(a) == euint32.unwrap(b) ? 1 : 0);
    }

    function select(ebool cond, euint32 a, euint32 b) internal pure returns (euint32) {
        return ebool.unwrap(cond) == 1 ? a : b;
    }

    function decrypt(euint32 a) internal pure returns (uint32) {
        return uint32(euint32.unwrap(a));
    }

    function decrypt(ebool a) internal pure returns (bool) {
        return ebool.unwrap(a) == 1;
    }

    function allow(euint32, address) internal pure {}
    function allow(ebool, address) internal pure {}
}

library Permission {
    function allow(euint32, address) internal pure {}
    function allow(ebool, address) internal pure {}
    function allowThis(euint32) internal pure {}
    function allowThis(ebool) internal pure {}
}
