// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "./SealedAuction.sol";
import "./MockToken.sol";

contract AuctionFactory {
    SealedAuction public auctionContract;
    MockToken public token;

    event TokenCreated(address indexed tokenAddress, string name, string symbol);
    event AuctionCreatedForToken(
        uint256 indexed auctionId,
        address indexed tokenAddress,
        uint256 tokenAmount,
        uint32 minimumBid,
        uint256 duration
    );

    constructor() {
        auctionContract = new SealedAuction();
    }

    function createTokenAndAuction(
        string memory name,
        string memory symbol,
        uint256 totalSupply,
        uint256 auctionAmount,
        uint32 minimumBid,
        uint256 durationSeconds
    ) external returns (uint256 auctionId, address tokenAddress) {
        MockToken newToken = new MockToken(totalSupply);
        tokenAddress = address(newToken);

        emit TokenCreated(tokenAddress, name, symbol);

        newToken.transfer(msg.sender, totalSupply - auctionAmount);

        uint256 aid = auctionContract.createAuction(
            tokenAddress,
            auctionAmount,
            minimumBid,
            durationSeconds
        );

        emit AuctionCreatedForToken(aid, tokenAddress, auctionAmount, minimumBid, durationSeconds);

        return (aid, tokenAddress);
    }

    function getAuctionContract() external view returns (address) {
        return address(auctionContract);
    }
}
