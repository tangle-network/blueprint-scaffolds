// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {FHE, ebool, euint64, inEuint64} from "@fhenixprotocol/contracts/FHE.sol";

contract EncryptedLaunchpadAuction is Ownable, ReentrancyGuard {
    struct AuctionConfig {
        string metadataURI;
        uint64 reservePrice;
        uint64 minDeposit;
        uint64 maxDeposit;
        uint256 tokensForSale;
        uint40 startTime;
        uint40 endTime;
        address token;
    }

    struct BidRecord {
        euint64 encryptedBid;
        ebool encryptedIsValid;
        uint64 deposit;
        bool claimed;
        bool exists;
    }

    AuctionConfig public auction;
    address[] private bidderList;
    mapping(address bidder => BidRecord record) private bids;

    address public winner;
    uint64 public clearingPrice;
    uint64 public winningBid;
    bool public settled;

    event AuctionCreated(
        address indexed creator,
        address indexed token,
        uint64 reservePrice,
        uint256 tokensForSale,
        uint40 startTime,
        uint40 endTime
    );
    event BidSubmitted(address indexed bidder, uint64 deposit);
    event AuctionSettled(address indexed winner, uint64 winningBid, uint64 clearingPrice);
    event RefundClaimed(address indexed bidder, uint256 amount);

    error AuctionNotActive();
    error AuctionAlreadySettled();
    error AuctionStillRunning();
    error InvalidAuctionWindow();
    error InvalidDeposit();
    error DuplicateBid();
    error UnknownBidder();
    error AlreadyClaimed();

    constructor(AuctionConfig memory config, address initialOwner) Ownable(initialOwner) {
        if (config.startTime >= config.endTime) revert InvalidAuctionWindow();
        if (config.reservePrice == 0 || config.minDeposit == 0 || config.maxDeposit < config.minDeposit) {
            revert InvalidDeposit();
        }
        if (config.tokensForSale == 0 || config.token == address(0)) revert InvalidDeposit();

        auction = config;

        emit AuctionCreated(
            initialOwner,
            config.token,
            config.reservePrice,
            config.tokensForSale,
            config.startTime,
            config.endTime
        );
    }

    function submitBid(inEuint64 calldata encryptedBid) external payable nonReentrant {
        _settleIfEnded();
        if (settled || block.timestamp < auction.startTime || block.timestamp >= auction.endTime) {
            revert AuctionNotActive();
        }
        if (bids[msg.sender].exists) revert DuplicateBid();
        if (msg.value < auction.minDeposit || msg.value > auction.maxDeposit) revert InvalidDeposit();

        euint64 bidValue = FHE.asEuint64(encryptedBid);
        ebool bidWithinDeposit = FHE.lte(bidValue, FHE.asEuint64(msg.value));

        bids[msg.sender] = BidRecord({
            encryptedBid: bidValue,
            encryptedIsValid: bidWithinDeposit,
            deposit: uint64(msg.value),
            claimed: false,
            exists: true
        });
        bidderList.push(msg.sender);

        emit BidSubmitted(msg.sender, uint64(msg.value));
    }

    function settleAuction() external nonReentrant {
        _settle();
    }

    function claimRefund() external nonReentrant returns (uint256 amount) {
        _settleIfEnded();
        BidRecord storage record = bids[msg.sender];
        if (!record.exists) revert UnknownBidder();
        if (!settled) revert AuctionStillRunning();
        if (record.claimed) revert AlreadyClaimed();

        record.claimed = true;
        if (msg.sender == winner) {
            amount = record.deposit - clearingPrice;
        } else {
            amount = record.deposit;
        }

        if (amount > 0) {
            (bool success, ) = payable(msg.sender).call{value: amount}("");
            require(success, "refund failed");
        }

        emit RefundClaimed(msg.sender, amount);
    }

    function getBidderCount() external view returns (uint256) {
        return bidderList.length;
    }

    function getBidderAt(uint256 index) external view returns (address) {
        return bidderList[index];
    }

    function getBidSummary(address bidder) external view returns (uint64 deposit, bool claimed, bool exists) {
        BidRecord storage record = bids[bidder];
        return (record.deposit, record.claimed, record.exists);
    }

    function previewWinnerPayout(address bidder) external view returns (uint256 tokenAmount, uint256 refundAmount) {
        if (!settled || bidder != winner) {
            return (0, 0);
        }
        return (auction.tokensForSale, bids[bidder].deposit - clearingPrice);
    }

    function _settleIfEnded() internal {
        if (!settled && block.timestamp >= auction.endTime) {
            _settle();
        }
    }

    function _settle() internal {
        if (settled) revert AuctionAlreadySettled();
        if (block.timestamp < auction.endTime) revert AuctionStillRunning();

        uint64 highest = auction.reservePrice;
        uint64 secondHighest = auction.reservePrice;
        address topBidder = address(0);

        for (uint256 i = 0; i < bidderList.length; i++) {
            address bidder = bidderList[i];
            BidRecord storage record = bids[bidder];
            if (!FHE.decrypt(record.encryptedIsValid)) {
                continue;
            }

            uint64 currentBid = FHE.decrypt(record.encryptedBid);
            if (currentBid < auction.reservePrice) {
                continue;
            }

            if (currentBid > highest) {
                secondHighest = highest;
                highest = currentBid;
                topBidder = bidder;
            } else if (currentBid > secondHighest) {
                secondHighest = currentBid;
            }
        }

        settled = true;
        winner = topBidder;
        winningBid = highest;
        clearingPrice = topBidder == address(0) ? 0 : secondHighest;

        if (topBidder != address(0)) {
            IERC20(auction.token).transfer(topBidder, auction.tokensForSale);
        }

        emit AuctionSettled(topBidder, highest, clearingPrice);
    }
}
