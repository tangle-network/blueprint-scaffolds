"use client";

import { useEffect, useState, useCallback } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  formatTimestamp,
  formatDuration,
  statusColor,
} from "@/lib/utils";
import type {
  Task,
  TaskEvent,
  LogEntry,
  Checkpoint,
  Metric,
  DashboardStats,
} from "@/lib/types";

function StatusBadge({ status }: { status: string }) {
  const colorMap: Record<string, string> = {
    queued: "bg-gray-100 text-gray-700 border-gray-200",
    running: "bg-blue-100 text-blue-700 border-blue-200",
    completed: "bg-green-100 text-green-700 border-green-200",
    failed: "bg-red-100 text-red-700 border-red-200",
    retrying: "bg-yellow-100 text-yellow-700 border-yellow-200",
  };
  return (
    <Badge variant="outline" className={colorMap[status] || ""}>
      <span className={`mr-1.5 inline-block h-1.5 w-1.5 rounded-full ${statusColor(status)}`} />
      {status}
    </Badge>
  );
}

function PriorityBadge({ priority }: { priority: string }) {
  const colorMap: Record<string, string> = {
    low: "bg-slate-100 text-slate-600 border-slate-200",
    normal: "bg-blue-50 text-blue-600 border-blue-200",
    high: "bg-orange-50 text-orange-600 border-orange-200",
    critical: "bg-red-50 text-red-600 border-red-200",
  };
  return (
    <Badge variant="outline" className={colorMap[priority] || ""}>
      {priority}
    </Badge>
  );
}

function LevelBadge({ level }: { level: string }) {
  const colorMap: Record<string, string> = {
    debug: "bg-slate-100 text-slate-600 border-slate-200",
    info: "bg-blue-50 text-blue-600 border-blue-200",
    warn: "bg-yellow-50 text-yellow-600 border-yellow-200",
    error: "bg-red-50 text-red-600 border-red-200",
  };
  return (
    <Badge variant="outline" className={colorMap[level] || ""}>
      {level.toUpperCase()}
    </Badge>
  );
}

function StatCard({
  title,
  value,
  subtitle,
  icon,
}: {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: React.ReactNode;
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <div className="text-muted-foreground">{icon}</div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {subtitle && (
          <p className="text-xs text-muted-foreground">{subtitle}</p>
        )}
      </CardContent>
    </Card>
  );
}

function MiniSparkline({ data, width = 120, height = 32 }: { data: number[]; width?: number; height?: number }) {
  if (data.length === 0) return null;
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const step = width / (data.length - 1);
  const points = data
    .map((v, i) => `${i * step},${height - ((v - min) / range) * height}`)
    .join(" ");
  return (
    <svg width={width} height={height} className="inline-block">
      <polyline
        fill="none"
        stroke="hsl(222.2, 47.4%, 11.2%)"
        strokeWidth="1.5"
        points={points}
      />
    </svg>
  );
}

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [events, setEvents] = useState<TaskEvent[]>([]);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [checkpoints, setCheckpoints] = useState<Checkpoint[]>([]);
  const [metrics, setMetrics] = useState<Metric[]>([]);
  const [activeTab, setActiveTab] = useState("tasks");
  const [taskFilter, setTaskFilter] = useState<string>("all");

  const fetchData = useCallback(async () => {
    try {
      const [statsRes, tasksRes, eventsRes, logsRes, checkpointsRes, metricsRes] =
        await Promise.all([
          fetch("/api/stats"),
          fetch("/api/tasks"),
          fetch("/api/events"),
          fetch("/api/logs"),
          fetch("/api/checkpoints"),
          fetch("/api/metrics"),
        ]);
      setStats(await statsRes.json());
      setTasks(await tasksRes.json());
      setEvents(await eventsRes.json());
      setLogs(await logsRes.json());
      setCheckpoints(await checkpointsRes.json());
      setMetrics(await metricsRes.json());
    } catch {}
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const filteredTasks =
    taskFilter === "all"
      ? tasks
      : tasks.filter((t) => t.status === taskFilter);

  const throughputData = metrics
    .filter((m) => m.name === "throughput")
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
    .map((m) => m.value);

  const latencyP50 = metrics
    .filter((m) => m.name === "latency_p50")
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
    .map((m) => m.value);

  const latencyP99 = metrics
    .filter((m) => m.name === "latency_p99")
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
    .map((m) => m.value);

  const queueDepth = metrics
    .filter((m) => m.name === "queue_depth")
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
    .map((m) => m.value);

  const errorRate = metrics
    .filter((m) => m.name === "error_rate")
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
    .map((m) => m.value);

  const eventTypeIcon = (type: TaskEvent["type"]) => {
    const map: Record<string, string> = {
      created: "\u25B6",
      started: "\u25B6",
      progress: "\u25CB",
      completed: "\u2713",
      failed: "\u2717",
      retrying: "\u21BB",
      checkpointed: "\u25C6",
    };
    return map[type] || "\u25CF";
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Dashboard</h2>
          <p className="text-muted-foreground">
            Monitor tasks, events, and system health
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={fetchData}>
          Refresh
        </Button>
      </div>

      {stats && (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Total Tasks"
            value={stats.totalTasks}
            subtitle={`${stats.queuedTasks} queued`}
            icon={
              <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
              </svg>
            }
          />
          <StatCard
            title="Running"
            value={stats.runningTasks}
            subtitle={`${stats.retryingTasks} retrying`}
            icon={
              <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            }
          />
          <StatCard
            title="Throughput"
            value={`${stats.throughputPerMinute}/min`}
            subtitle={`Avg latency: ${formatDuration(stats.avgLatencyMs)}`}
            icon={
              <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
              </svg>
            }
          />
          <StatCard
            title="Failed"
            value={stats.failedTasks}
            subtitle={`${stats.completedTasks} completed`}
            icon={
              <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            }
          />
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">Throughput (tasks/min)</CardTitle>
          </CardHeader>
          <CardContent>
            <MiniSparkline data={throughputData} />
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">Latency P50 (ms)</CardTitle>
          </CardHeader>
          <CardContent>
            <MiniSparkline data={latencyP50} />
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">Latency P99 (ms)</CardTitle>
          </CardHeader>
          <CardContent>
            <MiniSparkline data={latencyP99} />
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">Queue Depth</CardTitle>
          </CardHeader>
          <CardContent>
            <MiniSparkline data={queueDepth} />
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">Error Rate (%)</CardTitle>
          </CardHeader>
          <CardContent>
            <MiniSparkline data={errorRate} />
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="tasks">Tasks</TabsTrigger>
          <TabsTrigger value="events">Events</TabsTrigger>
          <TabsTrigger value="logs">Logs</TabsTrigger>
          <TabsTrigger value="checkpoints">Checkpoints</TabsTrigger>
        </TabsList>

        <TabsContent value="tasks">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg">Task Queue</CardTitle>
                  <CardDescription>
                    {filteredTasks.length} task{filteredTasks.length !== 1 ? "s" : ""}
                  </CardDescription>
                </div>
                <div className="flex gap-1">
                  {["all", "queued", "running", "completed", "failed", "retrying"].map(
                    (filter) => (
                      <Button
                        key={filter}
                        variant={taskFilter === filter ? "default" : "ghost"}
                        size="sm"
                        onClick={() => setTaskFilter(filter)}
                      >
                        {filter === "all" ? "All" : filter.charAt(0).toUpperCase() + filter.slice(1)}
                      </Button>
                    )
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Priority</TableHead>
                    <TableHead>Tool</TableHead>
                    <TableHead>Progress</TableHead>
                    <TableHead>Retries</TableHead>
                    <TableHead>Created</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTasks.map((task) => (
                    <TableRow key={task.id}>
                      <TableCell className="font-mono text-xs">{task.id}</TableCell>
                      <TableCell className="font-medium">{task.name}</TableCell>
                      <TableCell>
                        <StatusBadge status={task.status} />
                      </TableCell>
                      <TableCell>
                        <PriorityBadge priority={task.priority} />
                      </TableCell>
                      <TableCell>
                        <code className="rounded bg-muted px-1.5 py-0.5 text-xs">
                          {task.toolName}
                        </code>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2 min-w-[120px]">
                          <Progress value={task.progress} className="h-2 flex-1" />
                          <span className="text-xs text-muted-foreground w-8 text-right">
                            {task.progress}%
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="text-xs">
                        {task.retries}/{task.maxRetries}
                        {task.error && (
                          <span className="block text-red-500 truncate max-w-[150px]" title={task.error}>
                            {task.error}
                          </span>
                        )}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {formatTimestamp(task.createdAt)}
                      </TableCell>
                    </TableRow>
                  ))}
                  {filteredTasks.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={8} className="h-24 text-center text-muted-foreground">
                        No tasks found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="events">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Event Stream</CardTitle>
              <CardDescription>
                {events.length} events in chronological order
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[50px]"></TableHead>
                    <TableHead>Event ID</TableHead>
                    <TableHead>Task</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead>Timestamp</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {events.slice(0, 50).map((evt) => (
                    <TableRow key={evt.id}>
                      <TableCell className="text-lg">
                        {eventTypeIcon(evt.type)}
                      </TableCell>
                      <TableCell className="font-mono text-xs">{evt.id}</TableCell>
                      <TableCell className="font-mono text-xs">{evt.taskId}</TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            evt.type === "completed"
                              ? "bg-green-50 text-green-700 border-green-200"
                              : evt.type === "failed"
                              ? "bg-red-50 text-red-700 border-red-200"
                              : evt.type === "started"
                              ? "bg-blue-50 text-blue-700 border-blue-200"
                              : evt.type === "retrying"
                              ? "bg-yellow-50 text-yellow-700 border-yellow-200"
                              : evt.type === "checkpointed"
                              ? "bg-purple-50 text-purple-700 border-purple-200"
                              : "bg-slate-50 text-slate-700 border-slate-200"
                          }
                        >
                          {evt.type}
                        </Badge>
                      </TableCell>
                      <TableCell className="max-w-[300px]">
                        <code className="text-xs text-muted-foreground truncate block">
                          {JSON.stringify(evt.data)}
                        </code>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {formatTimestamp(evt.timestamp)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="logs">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">System Logs</CardTitle>
              <CardDescription>
                {logs.length} log entries
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-1 max-h-[500px] overflow-auto">
                {logs.map((log) => (
                  <div
                    key={log.id}
                    className="flex items-start gap-3 rounded px-3 py-2 hover:bg-muted/50 text-sm"
                  >
                    <span className="text-xs text-muted-foreground whitespace-nowrap mt-0.5 font-mono">
                      {formatTimestamp(log.timestamp)}
                    </span>
                    <LevelBadge level={log.level} />
                    {log.taskId && (
                      <span className="font-mono text-xs text-muted-foreground mt-0.5">
                        [{log.taskId}]
                      </span>
                    )}
                    <span className="flex-1">{log.message}</span>
                    <span className="text-xs text-muted-foreground whitespace-nowrap">
                      {(log.metadata as Record<string, unknown>).worker as string}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="checkpoints">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Checkpoints</CardTitle>
              <CardDescription>
                {checkpoints.length} saved checkpoints for recovery
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Checkpoint ID</TableHead>
                    <TableHead>Task</TableHead>
                    <TableHead>Step</TableHead>
                    <TableHead>State</TableHead>
                    <TableHead>Created</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {checkpoints.map((cp) => (
                    <TableRow key={cp.id}>
                      <TableCell className="font-mono text-xs">{cp.id}</TableCell>
                      <TableCell className="font-mono text-xs">{cp.taskId}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Progress
                            value={(cp.step / cp.totalSteps) * 100}
                            className="h-2 w-20"
                          />
                          <span className="text-xs text-muted-foreground">
                            {cp.step}/{cp.totalSteps}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <code className="text-xs text-muted-foreground">
                          {JSON.stringify(cp.state)}
                        </code>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {formatTimestamp(cp.createdAt)}
                      </TableCell>
                    </TableRow>
                  ))}
                  {checkpoints.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={5} className="h-24 text-center text-muted-foreground">
                        No checkpoints saved.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
