import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Rust Agent Runtime",
  description: "High-throughput task execution dashboard",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen font-sans antialiased">{children}</body>
    </html>
  );
}
