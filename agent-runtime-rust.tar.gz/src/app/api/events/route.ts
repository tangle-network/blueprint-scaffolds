import { NextResponse } from "next/server";
import { getStore } from "@/lib/store";

export async function GET() {
  const { events } = getStore();
  return NextResponse.json(events);
}
