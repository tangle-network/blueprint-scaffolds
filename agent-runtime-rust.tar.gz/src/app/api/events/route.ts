import { NextResponse } from "next/server";
import { getAllEvents } from "@/lib/store";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const limit = parseInt(searchParams.get("limit") || "200");
  const events = getAllEvents(limit);
  return NextResponse.json({ events, total: events.length });
}
