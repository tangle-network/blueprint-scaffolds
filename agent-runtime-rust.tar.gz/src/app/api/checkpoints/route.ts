import { NextResponse } from "next/server";
import { getStore } from "@/lib/store";

export async function GET() {
  const { checkpoints } = getStore();
  return NextResponse.json(checkpoints);
}
