import { NextResponse } from "next/server";
import { getStore } from "@/lib/store";

export async function GET() {
  const { logs } = getStore();
  return NextResponse.json(logs);
}
