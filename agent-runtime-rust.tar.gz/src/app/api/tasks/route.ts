import { NextResponse } from "next/server";
import { getStore } from "@/lib/store";

export async function GET() {
  const { tasks } = getStore();
  return NextResponse.json(tasks);
}
