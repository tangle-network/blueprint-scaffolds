import { NextResponse } from "next/server";
import { getAllTasks, enqueueTask } from "@/lib/store";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const status = searchParams.get("status");
  const tool = searchParams.get("tool");
  const limit = parseInt(searchParams.get("limit") || "100");

  let tasks = getAllTasks();
  if (status) tasks = tasks.filter(t => t.status === status);
  if (tool) tasks = tasks.filter(t => t.tool === tool);
  tasks = tasks.slice(0, limit);

  return NextResponse.json({ tasks, total: tasks.length });
}

export async function POST(request: Request) {
  const body = await request.json();
  const { name, tool, priority, payload } = body;

  if (!name || !tool) {
    return NextResponse.json({ error: "name and tool are required" }, { status: 400 });
  }

  const task = enqueueTask(name, tool, priority ?? 3, payload ?? "{}");
  return NextResponse.json({ task }, { status: 201 });
}
