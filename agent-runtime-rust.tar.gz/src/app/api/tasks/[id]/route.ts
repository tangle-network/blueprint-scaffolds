import { NextResponse } from "next/server";
import { getTaskById, getEventsForTask, retryTask } from "@/lib/store";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const task = getTaskById(id);
  if (!task) return NextResponse.json({ error: "not found" }, { status: 404 });

  const events = getEventsForTask(id);
  return NextResponse.json({ task, events });
}

export async function POST(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const task = retryTask(id);
  if (!task) return NextResponse.json({ error: "cannot retry this task" }, { status: 400 });

  return NextResponse.json({ task });
}
