import { NextResponse } from "next/server";
import { getStore } from "@/lib/store";

export async function GET() {
  const { metrics } = getStore();
  return NextResponse.json(metrics);
}
