import { NextResponse } from "next/server";
import { getMetrics, getThroughputSeries, getQueueStats } from "@/lib/store";

export async function GET() {
  const metrics = getMetrics();
  const throughput = getThroughputSeries();
  const queues = getQueueStats();
  return NextResponse.json({ metrics, throughput, queues });
}
