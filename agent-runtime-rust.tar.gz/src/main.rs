use std::{
    collections::{HashMap, VecDeque},
    env,
    net::SocketAddr,
    path::{Path, PathBuf},
    sync::Arc,
    time::{Duration, Instant},
};

use anyhow::{anyhow, Context, Result};
use axum::{
    extract::State,
    http::StatusCode,
    response::{sse::Event, Html, IntoResponse, Response, Sse},
    routing::get,
    Json, Router,
};
use chrono::{DateTime, Utc};
use metrics::{counter, gauge, histogram};
use metrics_exporter_prometheus::{PrometheusBuilder, PrometheusHandle};
use rand::Rng;
use serde::{Deserialize, Serialize};
use tokio::{
    fs,
    process::Command,
    sync::{broadcast, Mutex, Notify},
    time::sleep,
};
use tower_http::{cors::CorsLayer, services::ServeDir, trace::TraceLayer};
use uuid::Uuid;

const DEFAULT_WORKERS: usize = 4;
const MAX_EVENTS: usize = 400;
const MAX_LOG_LINES: usize = 120;
const CHECKPOINT_FILE: &str = "data/checkpoint.json";
const ALLOWED_TOOLS: &[&str] = &["echo", "printf", "sh", "bash", "sleep", "ls", "cat"];

#[derive(Clone)]
struct AppState {
    runtime: Arc<Runtime>,
    prometheus: PrometheusHandle,
}

struct Runtime {
    inner: Mutex<RuntimeState>,
    notify: Notify,
    events_tx: broadcast::Sender<RuntimeEvent>,
    checkpoint_path: PathBuf,
    sandbox_root: PathBuf,
}

#[derive(Default, Serialize, Deserialize)]
struct RuntimeState {
    queue: VecDeque<Uuid>,
    jobs: HashMap<Uuid, JobRecord>,
    recent_events: Vec<RuntimeEvent>,
    completed_total: u64,
    failed_total: u64,
    retried_total: u64,
    throughput_per_minute: f64,
    last_seq: u64,
}

#[derive(Clone, Serialize, Deserialize)]
struct JobRecord {
    id: Uuid,
    name: String,
    tool: ToolSpec,
    status: JobStatus,
    created_at: DateTime<Utc>,
    updated_at: DateTime<Utc>,
    started_at: Option<DateTime<Utc>>,
    completed_at: Option<DateTime<Utc>>,
    attempts: u32,
    max_retries: u32,
    timeout_secs: u64,
    checkpoint_seq: u64,
    output: Option<String>,
    last_error: Option<String>,
    logs: Vec<JobLogLine>,
}

#[derive(Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
enum JobStatus {
    Queued,
    Running,
    Succeeded,
    Failed,
    DeadLetter,
}

#[derive(Clone, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
enum ToolSpec {
    Command {
        command: String,
        args: Vec<String>,
        cwd: Option<String>,
    },
    Sleep {
        millis: u64,
    },
    Emit {
        message: String,
    },
    FlakyDemo {
        failure_rate: f64,
        message: String,
    },
}

#[derive(Clone, Serialize, Deserialize)]
struct JobLogLine {
    ts: DateTime<Utc>,
    level: String,
    message: String,
}

#[derive(Clone, Serialize, Deserialize)]
struct RuntimeEvent {
    seq: u64,
    ts: DateTime<Utc>,
    job_id: Uuid,
    kind: String,
    message: String,
    status: Option<JobStatus>,
    attempt: u32,
}

#[derive(Deserialize)]
struct EnqueueJobRequest {
    name: String,
    tool: ToolSpec,
    max_retries: Option<u32>,
    timeout_secs: Option<u64>,
}

#[derive(Serialize)]
struct DashboardSnapshot {
    summary: Summary,
    jobs: Vec<JobRecord>,
    recent_events: Vec<RuntimeEvent>,
}

#[derive(Serialize)]
struct Summary {
    queued: usize,
    running: usize,
    succeeded: usize,
    failed: usize,
    dead_letter: usize,
    completed_total: u64,
    failed_total: u64,
    retried_total: u64,
    throughput_per_minute: f64,
}

#[tokio::main]
async fn main() -> Result<()> {
    fs::create_dir_all("data").await?;
    let checkpoint_path = PathBuf::from(CHECKPOINT_FILE);
    let sandbox_root = env::current_dir()?.join("sandbox");
    fs::create_dir_all(&sandbox_root).await?;

    let builder = PrometheusBuilder::new();
    let handle = builder.install_recorder()?;

    let runtime = Arc::new(Runtime::load(checkpoint_path, sandbox_root).await?);
    runtime.seed_demo_jobs().await?;

    for idx in 0..DEFAULT_WORKERS {
        let runtime = runtime.clone();
        tokio::spawn(async move {
            if let Err(err) = runtime.worker_loop(idx).await {
                eprintln!("worker {idx} stopped: {err:#}");
            }
        });
    }

    let app_state = AppState {
        runtime,
        prometheus: handle,
    };

    let dashboard = ServeDir::new("web-dist").not_found_service(get(index_html));
    let app = Router::new()
        .route("/api/jobs", get(list_jobs).post(enqueue_job))
        .route("/api/jobs/:id", get(get_job))
        .route("/api/events", get(sse_events))
        .route("/api/metrics", get(metrics_endpoint))
        .fallback_service(dashboard)
        .layer(CorsLayer::permissive())
        .layer(TraceLayer::new_for_http())
        .with_state(app_state);

    let addr = SocketAddr::from(([127, 0, 0, 1], 3000));
    println!("task runtime listening on http://{addr}");
    let listener = tokio::net::TcpListener::bind(addr).await?;
    axum::serve(listener, app).await?;
    Ok(())
}

async fn index_html() -> Html<&'static str> {
    Html(
        r#"<!doctype html><html><body style="font-family:sans-serif;padding:2rem">Build the dashboard with <code>pnpm build</code>.</body></html>"#,
    )
}

async fn list_jobs(State(state): State<AppState>) -> Json<DashboardSnapshot> {
    Json(state.runtime.snapshot().await)
}

async fn get_job(
    State(state): State<AppState>,
    axum::extract::Path(id): axum::extract::Path<Uuid>,
) -> Response {
    let guard = state.runtime.inner.lock().await;
    if let Some(job) = guard.jobs.get(&id) {
        Json(job).into_response()
    } else {
        (StatusCode::NOT_FOUND, "job not found").into_response()
    }
}

async fn enqueue_job(
    State(state): State<AppState>,
    Json(req): Json<EnqueueJobRequest>,
) -> Result<Json<JobRecord>, ApiError> {
    let job = state.runtime.enqueue(req).await.map_err(ApiError)?;
    Ok(Json(job))
}

async fn sse_events(
    State(state): State<AppState>,
) -> Sse<impl futures_util::Stream<Item = Result<Event, std::convert::Infallible>>> {
    let rx = state.runtime.events_tx.subscribe();
    let stream = futures_util::stream::unfold(rx, |mut rx| async move {
        match rx.recv().await {
            Ok(event) => {
                let payload = serde_json::to_string(&event).unwrap_or_else(|_| "{}".into());
                Some((Ok(Event::default().event("runtime").data(payload)), rx))
            }
            Err(_) => None,
        }
    });
    Sse::new(stream)
}

async fn metrics_endpoint(State(state): State<AppState>) -> String {
    state.prometheus.render()
}

#[derive(Debug)]
struct ApiError(anyhow::Error);

impl IntoResponse for ApiError {
    fn into_response(self) -> Response {
        (
            StatusCode::INTERNAL_SERVER_ERROR,
            format!("{:#}", self.0),
        )
            .into_response()
    }
}

impl Runtime {
    async fn load(checkpoint_path: PathBuf, sandbox_root: PathBuf) -> Result<Self> {
        let (events_tx, _) = broadcast::channel(256);
        let inner = if fs::try_exists(&checkpoint_path).await.unwrap_or(false) {
            let bytes = fs::read(&checkpoint_path).await?;
            serde_json::from_slice(&bytes).context("failed to parse checkpoint")?
        } else {
            RuntimeState::default()
        };
        Ok(Self {
            inner: Mutex::new(inner),
            notify: Notify::new(),
            events_tx,
            checkpoint_path,
            sandbox_root,
        })
    }

    async fn seed_demo_jobs(&self) -> Result<()> {
        let guard = self.inner.lock().await;
        if !guard.jobs.is_empty() {
            return Ok(());
        }
        drop(guard);

        let demo_jobs = [
            EnqueueJobRequest {
                name: "emit-startup".into(),
                tool: ToolSpec::Emit {
                    message: "runtime boot complete".into(),
                },
                max_retries: Some(0),
                timeout_secs: Some(5),
            },
            EnqueueJobRequest {
                name: "flaky-probe".into(),
                tool: ToolSpec::FlakyDemo {
                    failure_rate: 0.55,
                    message: "storage pressure probe".into(),
                },
                max_retries: Some(3),
                timeout_secs: Some(5),
            },
            EnqueueJobRequest {
                name: "list-sandbox".into(),
                tool: ToolSpec::Command {
                    command: "ls".into(),
                    args: vec!["-la".into()],
                    cwd: Some("sandbox".into()),
                },
                max_retries: Some(1),
                timeout_secs: Some(5),
            },
        ];

        for job in demo_jobs {
            self.enqueue(job).await?;
        }
        Ok(())
    }

    async fn enqueue(&self, req: EnqueueJobRequest) -> Result<JobRecord> {
        let now = Utc::now();
        let id = Uuid::new_v4();
        let mut guard = self.inner.lock().await;
        let job = JobRecord {
            id,
            name: req.name,
            tool: req.tool,
            status: JobStatus::Queued,
            created_at: now,
            updated_at: now,
            started_at: None,
            completed_at: None,
            attempts: 0,
            max_retries: req.max_retries.unwrap_or(2),
            timeout_secs: req.timeout_secs.unwrap_or(30),
            checkpoint_seq: 0,
            output: None,
            last_error: None,
            logs: vec![JobLogLine {
                ts: now,
                level: "info".into(),
                message: "job enqueued".into(),
            }],
        };
        guard.queue.push_back(id);
        guard.jobs.insert(id, job.clone());
        self.push_event_locked(
            &mut guard,
            id,
            "job_enqueued",
            "job added to queue",
            Some(JobStatus::Queued),
            0,
        );
        drop(guard);
        self.persist().await?;
        self.notify.notify_one();
        Ok(job)
    }

    async fn snapshot(&self) -> DashboardSnapshot {
        let guard = self.inner.lock().await;
        let mut jobs: Vec<_> = guard.jobs.values().cloned().collect();
        jobs.sort_by_key(|job| job.created_at);
        jobs.reverse();

        let summary = Summary {
            queued: jobs
                .iter()
                .filter(|job| matches!(job.status, JobStatus::Queued))
                .count(),
            running: jobs
                .iter()
                .filter(|job| matches!(job.status, JobStatus::Running))
                .count(),
            succeeded: jobs
                .iter()
                .filter(|job| matches!(job.status, JobStatus::Succeeded))
                .count(),
            failed: jobs
                .iter()
                .filter(|job| matches!(job.status, JobStatus::Failed))
                .count(),
            dead_letter: jobs
                .iter()
                .filter(|job| matches!(job.status, JobStatus::DeadLetter))
                .count(),
            completed_total: guard.completed_total,
            failed_total: guard.failed_total,
            retried_total: guard.retried_total,
            throughput_per_minute: guard.throughput_per_minute,
        };

        DashboardSnapshot {
            summary,
            jobs,
            recent_events: guard.recent_events.clone(),
        }
    }

    async fn worker_loop(self: Arc<Self>, worker_id: usize) -> Result<()> {
        loop {
            let job_id = match self.pop_next_job().await? {
                Some(id) => id,
                None => {
                    self.notify.notified().await;
                    continue;
                }
            };

            if let Err(err) = self.run_job(job_id, worker_id).await {
                eprintln!("job {job_id} failed with runtime error: {err:#}");
            }
        }
    }

    async fn pop_next_job(&self) -> Result<Option<Uuid>> {
        let mut guard = self.inner.lock().await;
        Ok(guard.queue.pop_front())
    }

    async fn run_job(&self, job_id: Uuid, worker_id: usize) -> Result<()> {
        let start = Instant::now();
        let (tool, timeout_secs, attempt) = {
            let mut guard = self.inner.lock().await;
            let (tool, timeout_secs, attempt) = {
                let job = guard
                    .jobs
                    .get_mut(&job_id)
                    .ok_or_else(|| anyhow!("missing job {job_id}"))?;
                job.attempts += 1;
                job.status = JobStatus::Running;
                job.started_at = Some(Utc::now());
                job.updated_at = Utc::now();
                let attempt = job.attempts;
                push_log(job, "info", format!("worker {worker_id} picked up the job"));
                (job.tool.clone(), job.timeout_secs, attempt)
            };
            self.push_event_locked(
                &mut guard,
                job_id,
                "job_started",
                "worker started job",
                Some(JobStatus::Running),
                attempt,
            );
            (tool, timeout_secs, attempt)
        };
        self.persist().await?;

        let result =
            tokio::time::timeout(Duration::from_secs(timeout_secs), self.execute_tool(job_id, tool))
                .await;

        match result {
            Ok(Ok(output)) => {
                let elapsed = start.elapsed().as_secs_f64();
                histogram!("runtime.job.duration").record(elapsed);
                counter!("runtime.job.completed").increment(1);
                gauge!("runtime.jobs.running").set(0.0);

                let mut guard = self.inner.lock().await;
                let job = guard
                    .jobs
                    .get_mut(&job_id)
                    .ok_or_else(|| anyhow!("missing job {job_id}"))?;
                job.status = JobStatus::Succeeded;
                job.updated_at = Utc::now();
                job.completed_at = Some(Utc::now());
                job.output = Some(output.clone());
                job.last_error = None;
                push_log(job, "info", format!("job completed in {:.2}s", elapsed));
                guard.completed_total += 1;
                self.recompute_throughput_locked(&mut guard);
                self.push_event_locked(
                    &mut guard,
                    job_id,
                    "job_succeeded",
                    &output,
                    Some(JobStatus::Succeeded),
                    attempt,
                );
            }
            Ok(Err(err)) => {
                self.handle_job_failure(job_id, attempt, err.to_string()).await?;
            }
            Err(_) => {
                self.handle_job_failure(job_id, attempt, "job timed out".into())
                    .await?;
            }
        }

        self.persist().await?;
        Ok(())
    }

    async fn handle_job_failure(&self, job_id: Uuid, attempt: u32, error: String) -> Result<()> {
        counter!("runtime.job.failed").increment(1);
        let mut requeue = false;
        {
            let mut guard = self.inner.lock().await;
            let job = guard
                .jobs
                .get_mut(&job_id)
                .ok_or_else(|| anyhow!("missing job {job_id}"))?;
            job.updated_at = Utc::now();
            job.completed_at = Some(Utc::now());
            job.last_error = Some(error.clone());
            push_log(job, "error", error.clone());

            if job.attempts <= job.max_retries {
                job.status = JobStatus::Queued;
                job.completed_at = None;
                requeue = true;
                guard.queue.push_back(job_id);
                guard.retried_total += 1;
                self.push_event_locked(
                    &mut guard,
                    job_id,
                    "job_retry_scheduled",
                    "job requeued after failure",
                    Some(JobStatus::Queued),
                    attempt,
                );
            } else {
                job.status = JobStatus::DeadLetter;
                guard.failed_total += 1;
                self.push_event_locked(
                    &mut guard,
                    job_id,
                    "job_dead_letter",
                    "retry budget exhausted",
                    Some(JobStatus::DeadLetter),
                    attempt,
                );
            }
            self.recompute_throughput_locked(&mut guard);
        }
        self.persist().await?;
        if requeue {
            self.notify.notify_one();
        }
        Ok(())
    }

    async fn execute_tool(&self, job_id: Uuid, tool: ToolSpec) -> Result<String> {
        match tool {
            ToolSpec::Emit { message } => {
                sleep(Duration::from_millis(250)).await;
                Ok(message)
            }
            ToolSpec::Sleep { millis } => {
                sleep(Duration::from_millis(millis)).await;
                Ok(format!("slept for {millis}ms"))
            }
            ToolSpec::FlakyDemo {
                failure_rate,
                message,
            } => {
                sleep(Duration::from_millis(600)).await;
                if rand::thread_rng().gen_bool(failure_rate.clamp(0.0, 1.0)) {
                    Err(anyhow!("{message}: simulated transient failure"))
                } else {
                    Ok(format!("{message}: stable"))
                }
            }
            ToolSpec::Command { command, args, cwd } => {
                self.exec_command(job_id, &command, &args, cwd.as_deref()).await
            }
        }
    }

    async fn exec_command(
        &self,
        job_id: Uuid,
        command: &str,
        args: &[String],
        cwd: Option<&str>,
    ) -> Result<String> {
        if !ALLOWED_TOOLS.contains(&command) {
            return Err(anyhow!("command `{command}` is not allowlisted"));
        }

        let working_dir = self.resolve_cwd(cwd)?;
        let output = Command::new(command)
            .args(args)
            .current_dir(working_dir)
            .output()
            .await
            .with_context(|| format!("failed to execute {command}"))?;

        let stdout = String::from_utf8_lossy(&output.stdout).trim().to_string();
        let stderr = String::from_utf8_lossy(&output.stderr).trim().to_string();

        {
            let mut guard = self.inner.lock().await;
            if let Some(job) = guard.jobs.get_mut(&job_id) {
                if !stdout.is_empty() {
                    push_log(job, "info", format!("stdout: {stdout}"));
                }
                if !stderr.is_empty() {
                    push_log(job, "warn", format!("stderr: {stderr}"));
                }
            }
        }

        if output.status.success() {
            Ok(if stdout.is_empty() {
                "command succeeded".into()
            } else {
                stdout
            })
        } else {
            Err(anyhow!(
                "command exited with {}: {}",
                output.status,
                if stderr.is_empty() { stdout } else { stderr }
            ))
        }
    }

    fn resolve_cwd(&self, cwd: Option<&str>) -> Result<PathBuf> {
        let requested = match cwd {
            Some(raw) => self.sandbox_root.join(raw),
            None => self.sandbox_root.clone(),
        };
        let normalized = clean_path(&requested);
        if !normalized.starts_with(&self.sandbox_root) {
            return Err(anyhow!("requested cwd escapes sandbox"));
        }
        Ok(normalized)
    }

    fn push_event_locked(
        &self,
        guard: &mut RuntimeState,
        job_id: Uuid,
        kind: &str,
        message: &str,
        status: Option<JobStatus>,
        attempt: u32,
    ) {
        guard.last_seq += 1;
        let event = RuntimeEvent {
            seq: guard.last_seq,
            ts: Utc::now(),
            job_id,
            kind: kind.to_string(),
            message: message.to_string(),
            status,
            attempt,
        };
        guard.recent_events.push(event.clone());
        if guard.recent_events.len() > MAX_EVENTS {
            let drain = guard.recent_events.len() - MAX_EVENTS;
            guard.recent_events.drain(0..drain);
        }
        let _ = self.events_tx.send(event);
    }

    fn recompute_throughput_locked(&self, guard: &mut RuntimeState) {
        let now = Utc::now();
        let successes = guard
            .jobs
            .values()
            .filter(|job| {
                matches!(job.status, JobStatus::Succeeded)
                    && job
                        .completed_at
                        .map(|ts| now.signed_duration_since(ts).num_seconds() <= 60)
                        .unwrap_or(false)
            })
            .count();
        guard.throughput_per_minute = successes as f64;
    }

    async fn persist(&self) -> Result<()> {
        let data = {
            let mut guard = self.inner.lock().await;
            let last_seq = guard.last_seq;
            for job in guard.jobs.values_mut() {
                job.checkpoint_seq = last_seq;
            }
            serde_json::to_vec_pretty(&*guard)?
        };
        fs::write(&self.checkpoint_path, data).await?;
        Ok(())
    }
}

fn push_log(job: &mut JobRecord, level: &str, message: String) {
    job.logs.push(JobLogLine {
        ts: Utc::now(),
        level: level.to_string(),
        message,
    });
    if job.logs.len() > MAX_LOG_LINES {
        let drain = job.logs.len() - MAX_LOG_LINES;
        job.logs.drain(0..drain);
    }
}

fn clean_path(path: &Path) -> PathBuf {
    let mut cleaned = PathBuf::new();
    for part in path.components() {
        match part {
            std::path::Component::ParentDir => {
                cleaned.pop();
            }
            std::path::Component::CurDir => {}
            other => cleaned.push(other.as_os_str()),
        }
    }
    cleaned
}
