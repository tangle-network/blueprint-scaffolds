import { generateTasks, generateEvents, computeMetrics, generateThroughputSeries, computeQueueStats, simulateNewTask } from "./engine";
import type { Task, TaskEvent, Metrics, ThroughputPoint, QueueStats, ToolName } from "./types";

const TASK_COUNT = 48;
let tasks = generateTasks(TASK_COUNT);
let events = generateEvents(tasks);

export function getAllTasks(): Task[] {
  return tasks;
}

export function getTaskById(id: string): Task | undefined {
  return tasks.find(t => t.id === id);
}

export function getEventsForTask(taskId: string): TaskEvent[] {
  return events.filter(e => e.task_id === taskId);
}

export function getAllEvents(limit = 200): TaskEvent[] {
  return events.slice(0, limit);
}

export function getMetrics(): Metrics {
  return computeMetrics(tasks);
}

export function getThroughputSeries(): ThroughputPoint[] {
  return generateThroughputSeries();
}

export function getQueueStats(): QueueStats[] {
  return computeQueueStats(tasks);
}

export function enqueueTask(name: string, tool: ToolName, priority: number, payload: string): Task {
  const task = simulateNewTask(name, tool, priority, payload);
  tasks = [task, ...tasks];
  const evt = {
    id: `evt_gen_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    task_id: task.id,
    event_type: "created" as const,
    message: `Task "${task.name}" enqueued via API`,
    timestamp: new Date().toISOString(),
    metadata: { source: "api" },
  };
  events = [evt, ...events];
  return task;
}

export function retryTask(id: string): Task | null {
  const idx = tasks.findIndex(t => t.id === id);
  if (idx === -1) return null;
  const t = tasks[idx];
  if (t.status !== "failed" && t.status !== "retrying") return null;
  if (t.retry_count >= t.max_retries) return null;

  const updated: Task = {
    ...t,
    status: "retrying",
    retry_count: t.retry_count + 1,
    error: null,
  };
  tasks = [...tasks.slice(0, idx), updated, ...tasks.slice(idx + 1)];

  const evt = {
    id: `evt_retry_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    task_id: id,
    event_type: "retry" as const,
    message: `Retry attempt ${updated.retry_count}/${updated.max_retries} triggered via dashboard`,
    timestamp: new Date().toISOString(),
    metadata: { source: "dashboard" },
  };
  events = [evt, ...events];
  return updated;
}
