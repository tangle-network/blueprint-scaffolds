import { type Task, type TaskEvent, type Metric, type LogEntry, type Checkpoint, type DashboardStats } from "./types";

function makeTask(overrides: Partial<Task> & Pick<Task, "id" | "name" | "status" | "toolName">): Task {
  return {
    priority: "normal",
    createdAt: new Date(Date.now() - Math.random() * 86400000).toISOString(),
    startedAt: null,
    completedAt: null,
    retries: 0,
    maxRetries: 3,
    progress: 0,
    payload: {},
    result: null,
    error: null,
    checkpointId: null,
    ...overrides,
  };
}

const TOOLS = [
  "shell_exec",
  "file_read",
  "file_write",
  "http_request",
  "db_query",
  "llm_infer",
  "sandbox_eval",
  "artifact_upload",
];

const TASK_NAMES = [
  "process-invoice-batch",
  "run-data-pipeline",
  "evaluate-ml-model",
  "generate-report",
  "sync-external-api",
  "clean-stale-records",
  "build-search-index",
  "compress-archives",
  "send-notification-batch",
  "validate-schema",
  "train-classifier",
  "deploy-artifact",
  "run-integration-tests",
  "migrate-database",
  "archive-logs",
];

function randomFrom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

const now = Date.now();

const tasks: Task[] = [
  makeTask({
    id: "task-001",
    name: "process-invoice-batch",
    status: "completed",
    toolName: "shell_exec",
    priority: "high",
    createdAt: new Date(now - 3600000).toISOString(),
    startedAt: new Date(now - 3590000).toISOString(),
    completedAt: new Date(now - 3500000).toISOString(),
    progress: 100,
    result: { processed: 245, errors: 0 },
  }),
  makeTask({
    id: "task-002",
    name: "run-data-pipeline",
    status: "running",
    toolName: "db_query",
    priority: "critical",
    createdAt: new Date(now - 1800000).toISOString(),
    startedAt: new Date(now - 1790000).toISOString(),
    progress: 67,
    retries: 1,
    checkpointId: "cp-001",
  }),
  makeTask({
    id: "task-003",
    name: "evaluate-ml-model",
    status: "queued",
    toolName: "sandbox_eval",
    priority: "normal",
    createdAt: new Date(now - 900000).toISOString(),
    progress: 0,
  }),
  makeTask({
    id: "task-004",
    name: "generate-report",
    status: "failed",
    toolName: "llm_infer",
    priority: "high",
    createdAt: new Date(now - 7200000).toISOString(),
    startedAt: new Date(now - 7190000).toISOString(),
    completedAt: new Date(now - 7180000).toISOString(),
    retries: 3,
    maxRetries: 3,
    error: "Model inference timeout after 300s",
  }),
  makeTask({
    id: "task-005",
    name: "sync-external-api",
    status: "retrying",
    toolName: "http_request",
    priority: "normal",
    createdAt: new Date(now - 600000).toISOString(),
    startedAt: new Date(now - 590000).toISOString(),
    retries: 2,
    progress: 30,
    error: "Connection refused: api.example.com:443",
    checkpointId: "cp-002",
  }),
  makeTask({
    id: "task-006",
    name: "clean-stale-records",
    status: "completed",
    toolName: "db_query",
    priority: "low",
    createdAt: new Date(now - 10800000).toISOString(),
    startedAt: new Date(now - 10790000).toISOString(),
    completedAt: new Date(now - 10700000).toISOString(),
    progress: 100,
    result: { deleted: 1583, freed_mb: 42 },
  }),
  makeTask({
    id: "task-007",
    name: "build-search-index",
    status: "running",
    toolName: "shell_exec",
    priority: "high",
    createdAt: new Date(now - 300000).toISOString(),
    startedAt: new Date(now - 290000).toISOString(),
    progress: 45,
    checkpointId: "cp-003",
  }),
  makeTask({
    id: "task-008",
    name: "compress-archives",
    status: "queued",
    toolName: "file_write",
    priority: "low",
    createdAt: new Date(now - 120000).toISOString(),
    progress: 0,
  }),
  makeTask({
    id: "task-009",
    name: "send-notification-batch",
    status: "completed",
    toolName: "http_request",
    priority: "normal",
    createdAt: new Date(now - 5400000).toISOString(),
    startedAt: new Date(now - 5390000).toISOString(),
    completedAt: new Date(now - 5350000).toISOString(),
    progress: 100,
    result: { sent: 1200, failed: 3 },
  }),
  makeTask({
    id: "task-010",
    name: "validate-schema",
    status: "failed",
    toolName: "sandbox_eval",
    priority: "critical",
    createdAt: new Date(now - 14400000).toISOString(),
    startedAt: new Date(now - 14390000).toISOString(),
    completedAt: new Date(now - 14380000).toISOString(),
    retries: 3,
    maxRetries: 3,
    error: "Schema validation failed: missing required field 'timestamp'",
  }),
  makeTask({
    id: "task-011",
    name: "train-classifier",
    status: "running",
    toolName: "sandbox_eval",
    priority: "critical",
    createdAt: new Date(now - 6000000).toISOString(),
    startedAt: new Date(now - 5999000).toISOString(),
    progress: 82,
    retries: 0,
    checkpointId: "cp-004",
  }),
  makeTask({
    id: "task-012",
    name: "deploy-artifact",
    status: "queued",
    toolName: "artifact_upload",
    priority: "normal",
    createdAt: new Date(now - 60000).toISOString(),
    progress: 0,
  }),
];

function generateEvents(tasks: Task[]): TaskEvent[] {
  const events: TaskEvent[] = [];
  let eventId = 1;
  for (const task of tasks) {
    events.push({
      id: `evt-${String(eventId++).padStart(3, "0")}`,
      taskId: task.id,
      type: "created",
      timestamp: task.createdAt,
      data: { name: task.name, priority: task.priority },
    });
    if (task.startedAt) {
      events.push({
        id: `evt-${String(eventId++).padStart(3, "0")}`,
        taskId: task.id,
        type: "started",
        timestamp: task.startedAt,
        data: { tool: task.toolName },
      });
    }
    if (task.progress > 0 && task.status !== "queued") {
      events.push({
        id: `evt-${String(eventId++).padStart(3, "0")}`,
        taskId: task.id,
        type: "progress",
        timestamp: new Date(
          new Date(task.startedAt || task.createdAt).getTime() + 60000
        ).toISOString(),
        data: { progress: task.progress },
      });
    }
    if (task.checkpointId) {
      events.push({
        id: `evt-${String(eventId++).padStart(3, "0")}`,
        taskId: task.id,
        type: "checkpointed",
        timestamp: new Date(
          new Date(task.startedAt || task.createdAt).getTime() + 120000
        ).toISOString(),
        data: { checkpointId: task.checkpointId },
      });
    }
    if (task.status === "completed") {
      events.push({
        id: `evt-${String(eventId++).padStart(3, "0")}`,
        taskId: task.id,
        type: "completed",
        timestamp: task.completedAt!,
        data: task.result || {},
      });
    }
    if (task.status === "failed") {
      events.push({
        id: `evt-${String(eventId++).padStart(3, "0")}`,
        taskId: task.id,
        type: "failed",
        timestamp: task.completedAt!,
        data: { error: task.error, retries: task.retries },
      });
    }
    if (task.status === "retrying") {
      events.push({
        id: `evt-${String(eventId++).padStart(3, "0")}`,
        taskId: task.id,
        type: "retrying",
        timestamp: new Date(
          new Date(task.startedAt || task.createdAt).getTime() + 180000
        ).toISOString(),
        data: { attempt: task.retries, error: task.error },
      });
    }
  }
  return events.sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
}

function generateLogs(tasks: Task[]): LogEntry[] {
  const levels: LogEntry["level"][] = ["debug", "info", "warn", "error"];
  const messages = [
    "Task submitted to queue",
    "Acquired worker slot",
    "Executing tool",
    "Checkpoint saved",
    "Progress update emitted",
    "Retry scheduled",
    "Task completed successfully",
    "Task failed with error",
    "Heartbeat received",
    "Sandbox initialized",
    "Memory usage within limits",
    "Rate limit approaching",
    "Connection pool expanded",
    "Garbage collection triggered",
  ];
  const logs: LogEntry[] = [];
  for (let i = 0; i < 50; i++) {
    const task = randomFrom(tasks);
    logs.push({
      id: `log-${String(i + 1).padStart(3, "0")}`,
      taskId: Math.random() > 0.3 ? task.id : null,
      level: randomFrom(levels),
      message: randomFrom(messages),
      timestamp: new Date(
        now - Math.random() * 14400000
      ).toISOString(),
      metadata: {
        worker: `worker-${Math.floor(Math.random() * 8)}`,
        memory_mb: Math.floor(Math.random() * 512 + 64),
      },
    });
  }
  return logs.sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
}

function generateCheckpoints(tasks: Task[]): Checkpoint[] {
  return tasks
    .filter((t) => t.checkpointId)
    .map((t) => ({
      id: t.checkpointId!,
      taskId: t.id,
      step: Math.floor(t.progress / 10),
      totalSteps: 10,
      state: { toolName: t.toolName, progress: t.progress },
      createdAt: new Date(
        new Date(t.startedAt || t.createdAt).getTime() + 120000
      ).toISOString(),
    }));
}

function generateMetrics(): Metric[] {
  const base = now - 3600000;
  const metrics: Metric[] = [];
  for (let i = 0; i < 60; i++) {
    const t = new Date(base + i * 60000).toISOString();
    metrics.push({ name: "throughput", value: Math.floor(Math.random() * 50 + 20), unit: "tasks/min", timestamp: t });
    metrics.push({ name: "latency_p50", value: Math.floor(Math.random() * 200 + 50), unit: "ms", timestamp: t });
    metrics.push({ name: "latency_p99", value: Math.floor(Math.random() * 1000 + 200), unit: "ms", timestamp: t });
    metrics.push({ name: "queue_depth", value: Math.floor(Math.random() * 30 + 5), unit: "tasks", timestamp: t });
    metrics.push({ name: "active_workers", value: Math.floor(Math.random() * 4 + 4), unit: "workers", timestamp: t });
    metrics.push({ name: "error_rate", value: Math.random() * 5, unit: "%", timestamp: t });
  }
  return metrics;
}

const events = generateEvents(tasks);
const logs = generateLogs(tasks);
const checkpoints = generateCheckpoints(tasks);
const metrics = generateMetrics();

export function getStore() {
  return { tasks, events, logs, checkpoints, metrics };
}

export function getDashboardStats(): DashboardStats {
  const s = getStore();
  const total = s.tasks.length;
  const queued = s.tasks.filter((t) => t.status === "queued").length;
  const running = s.tasks.filter((t) => t.status === "running").length;
  const completed = s.tasks.filter((t) => t.status === "completed").length;
  const failed = s.tasks.filter((t) => t.status === "failed").length;
  const retrying = s.tasks.filter((t) => t.status === "retrying").length;
  const completedTasks = s.tasks.filter(
    (t) => t.status === "completed" && t.completedAt && t.startedAt
  );
  const avgLatencyMs =
    completedTasks.length > 0
      ? completedTasks.reduce((sum, t) => {
          return (
            sum +
            (new Date(t.completedAt!).getTime() -
              new Date(t.startedAt!).getTime())
          );
        }, 0) / completedTasks.length
      : 0;
  const throughputMetrics = s.metrics.filter((m) => m.name === "throughput");
  const throughputPerMinute =
    throughputMetrics.length > 0
      ? throughputMetrics.reduce((s, m) => s + m.value, 0) /
        throughputMetrics.length
      : 0;
  return {
    totalTasks: total,
    queuedTasks: queued,
    runningTasks: running,
    completedTasks: completed,
    failedTasks: failed,
    retryingTasks: retrying,
    throughputPerMinute: Math.round(throughputPerMinute * 10) / 10,
    avgLatencyMs: Math.round(avgLatencyMs),
    uptimeSeconds: 86400,
  };
}
