export type TaskStatus =
  | "queued"
  | "running"
  | "completed"
  | "failed"
  | "retrying"
  | "checkpointed";

export type ToolName =
  | "shell_exec"
  | "file_read"
  | "file_write"
  | "http_request"
  | "sandbox_eval";

export interface Task {
  id: string;
  name: string;
  status: TaskStatus;
  priority: number;
  tool: ToolName;
  payload: string;
  result: string | null;
  error: string | null;
  retry_count: number;
  max_retries: number;
  checkpoint_at: number | null;
  created_at: string;
  started_at: string | null;
  completed_at: string | null;
  duration_ms: number | null;
}

export interface TaskEvent {
  id: string;
  task_id: string;
  event_type:
    | "created"
    | "started"
    | "checkpoint"
    | "tool_call"
    | "tool_result"
    | "retry"
    | "completed"
    | "failed";
  message: string;
  timestamp: string;
  metadata: Record<string, string> | null;
}

export interface Metrics {
  total_tasks: number;
  queued: number;
  running: number;
  completed: number;
  failed: number;
  retrying: number;
  throughput_per_min: number;
  avg_duration_ms: number;
  p50_duration_ms: number;
  p99_duration_ms: number;
  total_retries: number;
  success_rate: number;
}

export interface ThroughputPoint {
  time: string;
  completed: number;
  failed: number;
  queued: number;
}

export interface QueueStats {
  name: string;
  pending: number;
  active: number;
  completed: number;
  failed: number;
}
