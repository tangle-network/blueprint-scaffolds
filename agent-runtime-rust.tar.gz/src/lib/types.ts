export type TaskStatus =
  | "queued"
  | "running"
  | "completed"
  | "failed"
  | "retrying";

export type TaskPriority = "low" | "normal" | "high" | "critical";

export interface Task {
  id: string;
  name: string;
  status: TaskStatus;
  priority: TaskPriority;
  createdAt: string;
  startedAt: string | null;
  completedAt: string | null;
  retries: number;
  maxRetries: number;
  progress: number;
  toolName: string;
  payload: Record<string, unknown>;
  result: Record<string, unknown> | null;
  error: string | null;
  checkpointId: string | null;
}

export interface TaskEvent {
  id: string;
  taskId: string;
  type: "created" | "started" | "progress" | "completed" | "failed" | "retrying" | "checkpointed";
  timestamp: string;
  data: Record<string, unknown>;
}

export interface Metric {
  name: string;
  value: number;
  unit: string;
  timestamp: string;
}

export interface LogEntry {
  id: string;
  taskId: string | null;
  level: "debug" | "info" | "warn" | "error";
  message: string;
  timestamp: string;
  metadata: Record<string, unknown>;
}

export interface Checkpoint {
  id: string;
  taskId: string;
  step: number;
  totalSteps: number;
  state: Record<string, unknown>;
  createdAt: string;
}

export interface DashboardStats {
  totalTasks: number;
  queuedTasks: number;
  runningTasks: number;
  completedTasks: number;
  failedTasks: number;
  retryingTasks: number;
  throughputPerMinute: number;
  avgLatencyMs: number;
  uptimeSeconds: number;
}
