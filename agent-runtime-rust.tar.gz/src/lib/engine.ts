import type { Task, TaskEvent, Metrics, ThroughputPoint, QueueStats, TaskStatus, ToolName } from "./types";

const TOOLS: ToolName[] = ["shell_exec", "file_read", "file_write", "http_request", "sandbox_eval"];

const TASK_NAMES = [
  "compile_shaders", "run_unit_tests", "lint_source_tree", "generate_docs",
  "deploy_canary", "run_integration_suite", "build_release_binary", "audit_dependencies",
  "benchmark_throughput", "validate_schema", "check_licenses", "run_fuzzer",
  "scan_vulnerabilities", "package_artifact", "run_e2e_tests", "generate_protobuf",
  "compress_assets", "run_load_test", "snapshot_database", "sync_registry",
];

const QUEUES = ["critical", "default", "background"];

let taskCounter = 0;
let eventCounter = 0;

function uid(prefix: string): string {
  const c = prefix === "evt" ? ++eventCounter : ++taskCounter;
  return `${prefix}_${String(c).padStart(6, "0")}_${Math.random().toString(36).slice(2, 8)}`;
}

function iso(offsetMs = 0): string {
  return new Date(Date.now() + offsetMs).toISOString();
}

function randInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function createEvent(taskId: string, eventType: TaskEvent["event_type"], message: string, metadata?: Record<string, string>): TaskEvent {
  return {
    id: uid("evt"),
    task_id: taskId,
    event_type: eventType,
    message,
    timestamp: iso(),
    metadata: metadata ?? null,
  };
}

function buildTask(overrides?: Partial<Task>): Task {
  const id = uid("tsk");
  const priority = pick([1, 1, 2, 2, 2, 3, 3, 4, 5]);
  const tool = pick(TOOLS);
  const maxRetries = pick([0, 1, 2, 3]);
  const payload = JSON.stringify({ command: pick(["cargo build", "cargo test", "cargo clippy", "cargo audit", "./run.sh"]), args: ["--release"] });

  const statusRoll = Math.random();
  let status: TaskStatus;
  let startedAt: string | null = null;
  let completedAt: string | null = null;
  let result: string | null = null;
  let error: string | null = null;
  let retryCount = 0;
  let checkpointAt: number | null = null;
  let durationMs: number | null = null;

  const createdAt = iso(-randInt(60000, 3600000));

  if (statusRoll < 0.05) {
    status = "queued";
  } else if (statusRoll < 0.12) {
    status = "running";
    startedAt = iso(-randInt(1000, 30000));
    checkpointAt = randInt(20, 80);
  } else if (statusRoll < 0.58) {
    status = "completed";
    startedAt = iso(-randInt(60000, 300000));
    completedAt = iso(-randInt(1000, 60000));
    durationMs = randInt(50, 5000);
    result = `ok: exit_code=0, output=${randInt(100, 999)} bytes`;
  } else if (statusRoll < 0.78) {
    status = "failed";
    startedAt = iso(-randInt(30000, 180000));
    completedAt = iso(-randInt(1000, 30000));
    durationMs = randInt(100, 8000);
    error = pick([
      "sandbox violation: write to /etc/passwd denied",
      "timeout exceeded: 30s limit reached",
      "OOM: process killed (limit: 512MB)",
      "compilation error: unresolved import `crate::engine`",
      "tool panicked at 'assertion failed: result.is_ok()'",
      "network error: connection refused to 10.0.0.5:9090",
    ]);
    retryCount = randInt(0, maxRetries);
  } else if (statusRoll < 0.88) {
    status = "retrying";
    startedAt = iso(-randInt(10000, 60000));
    retryCount = randInt(1, Math.max(1, maxRetries));
    checkpointAt = randInt(10, 50);
  } else {
    status = "checkpointed";
    startedAt = iso(-randInt(30000, 120000));
    checkpointAt = randInt(30, 90);
  }

  return {
    id,
    name: pick(TASK_NAMES),
    status,
    priority,
    tool,
    payload,
    result,
    error,
    retry_count: retryCount,
    max_retries: maxRetries,
    checkpoint_at: checkpointAt,
    created_at: createdAt,
    started_at: startedAt,
    completed_at: completedAt,
    duration_ms: durationMs,
    ...overrides,
  };
}

function buildEvents(task: Task): TaskEvent[] {
  const events: TaskEvent[] = [];
  events.push(createEvent(task.id, "created", `Task "${task.name}" enqueued with priority=${task.priority}`, { tool: task.tool }));

  if (task.status === "queued") return events;

  events.push(createEvent(task.id, "started", `Worker picked up task, executing ${task.tool}`, { queue: pick(QUEUES) }));

  if (task.checkpoint_at != null) {
    events.push(createEvent(task.id, "checkpoint", `Checkpoint saved at ${task.checkpoint_at}% progress`, { progress: String(task.checkpoint_at) }));
  }

  events.push(createEvent(task.id, "tool_call", `Invoking ${task.tool} with payload (${task.payload.length} bytes)`));
  events.push(createEvent(task.id, "tool_result", `Tool returned status: ${task.status === "completed" ? "success" : "error"}`));

  if (task.retry_count > 0) {
    for (let i = 0; i < task.retry_count; i++) {
      events.push(createEvent(task.id, "retry", `Retry attempt ${i + 1}/${task.max_retries} triggered`, { attempt: String(i + 1) }));
    }
  }

  if (task.status === "completed") {
    events.push(createEvent(task.id, "completed", `Task finished successfully in ${task.duration_ms}ms`));
  } else if (task.status === "failed") {
    events.push(createEvent(task.id, "failed", `Task failed: ${task.error}`));
  }

  return events;
}

export function generateTasks(count = 42): Task[] {
  taskCounter = 0;
  return Array.from({ length: count }, () => buildTask());
}

export function generateEvents(tasks: Task[]): TaskEvent[] {
  eventCounter = 0;
  return tasks.flatMap(buildEvents).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
}

export function computeMetrics(tasks: Task[]): Metrics {
  const total = tasks.length;
  const completed = tasks.filter(t => t.status === "completed");
  const failed = tasks.filter(t => t.status === "failed");
  const durations = completed.map(t => t.duration_ms ?? 0).sort((a, b) => a - b);
  const totalRetries = tasks.reduce((sum, t) => sum + t.retry_count, 0);

  const p = (arr: number[], pct: number) => {
    if (arr.length === 0) return 0;
    const idx = Math.ceil(arr.length * pct) - 1;
    return arr[Math.max(0, idx)];
  };

  return {
    total_tasks: total,
    queued: tasks.filter(t => t.status === "queued").length,
    running: tasks.filter(t => t.status === "running").length,
    completed: completed.length,
    failed: failed.length,
    retrying: tasks.filter(t => t.status === "retrying").length,
    throughput_per_min: Math.round((completed.length / 60) * 60 * 10) / 10,
    avg_duration_ms: durations.length > 0 ? Math.round(durations.reduce((a, b) => a + b, 0) / durations.length) : 0,
    p50_duration_ms: p(durations, 0.5),
    p99_duration_ms: p(durations, 0.99),
    total_retries: totalRetries,
    success_rate: total > 0 ? Math.round((completed.length / total) * 1000) / 10 : 0,
  };
}

export function generateThroughputSeries(): ThroughputPoint[] {
  const points: ThroughputPoint[] = [];
  let cAcc = 0;
  let fAcc = 0;
  let qAcc = 0;
  for (let i = 59; i >= 0; i--) {
    cAcc += randInt(0, 8);
    fAcc += randInt(0, 2);
    qAcc += randInt(0, 5);
    const t = new Date(Date.now() - i * 60000);
    points.push({
      time: `${String(t.getHours()).padStart(2, "0")}:${String(t.getMinutes()).padStart(2, "0")}`,
      completed: cAcc,
      failed: fAcc,
      queued: qAcc,
    });
  }
  return points;
}

export function computeQueueStats(tasks: Task[]): QueueStats[] {
  return QUEUES.map(name => {
    const subset = tasks.filter((_, i) => i % 3 === QUEUES.indexOf(name));
    return {
      name,
      pending: subset.filter(t => t.status === "queued").length,
      active: subset.filter(t => t.status === "running" || t.status === "retrying").length,
      completed: subset.filter(t => t.status === "completed").length,
      failed: subset.filter(t => t.status === "failed").length,
    };
  });
}

export function simulateNewTask(name: string, tool: ToolName, priority: number, payload: string): Task {
  return buildTask({ name, tool, priority, payload, status: "queued", created_at: iso() });
}
