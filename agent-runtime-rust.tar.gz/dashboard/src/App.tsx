import { FormEvent, useEffect, useMemo, useState } from "react";

type JobStatus = "queued" | "running" | "succeeded" | "failed" | "dead_letter";

type ToolSpec =
  | { kind: "emit"; message: string }
  | { kind: "sleep"; millis: number }
  | { kind: "flaky_demo"; failure_rate: number; message: string }
  | { kind: "command"; command: string; args: string[]; cwd?: string | null };

type JobRecord = {
  id: string;
  name: string;
  status: JobStatus;
  attempts: number;
  max_retries: number;
  timeout_secs: number;
  output?: string | null;
  last_error?: string | null;
  created_at: string;
  updated_at: string;
  completed_at?: string | null;
  logs: { ts: string; level: string; message: string }[];
  tool: ToolSpec;
};

type Snapshot = {
  summary: {
    queued: number;
    running: number;
    succeeded: number;
    failed: number;
    dead_letter: number;
    completed_total: number;
    failed_total: number;
    retried_total: number;
    throughput_per_minute: number;
  };
  jobs: JobRecord[];
  recent_events: {
    seq: number;
    ts: string;
    job_id: string;
    kind: string;
    message: string;
    attempt: number;
    status?: JobStatus | null;
  }[];
};

const initialForm = {
  name: "demo-command",
  type: "command",
  command: "echo",
  args: "hello from runtime",
  cwd: "",
  maxRetries: 2,
  timeoutSecs: 10,
};

export function App() {
  const [snapshot, setSnapshot] = useState<Snapshot | null>(null);
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);
  const [form, setForm] = useState(initialForm);
  const [submitting, setSubmitting] = useState(false);

  async function loadSnapshot() {
    const res = await fetch("/api/jobs");
    const data = (await res.json()) as Snapshot;
    setSnapshot(data);
    setSelectedJobId((current) => current ?? data.jobs[0]?.id ?? null);
  }

  useEffect(() => {
    void loadSnapshot();
    const timer = window.setInterval(() => void loadSnapshot(), 4000);
    const stream = new EventSource("/api/events");
    stream.onmessage = () => void loadSnapshot();
    stream.addEventListener("runtime", () => void loadSnapshot());
    return () => {
      window.clearInterval(timer);
      stream.close();
    };
  }, []);

  const selectedJob = useMemo(
    () => snapshot?.jobs.find((job) => job.id === selectedJobId) ?? snapshot?.jobs[0] ?? null,
    [snapshot, selectedJobId]
  );

  async function submitJob(event: FormEvent) {
    event.preventDefault();
    setSubmitting(true);
    try {
      const tool: ToolSpec =
        form.type === "sleep"
          ? { kind: "sleep", millis: 1500 }
          : {
              kind: "command",
              command: form.command,
              args: form.args.split(" ").filter(Boolean),
              cwd: form.cwd || null,
            };

      await fetch("/api/jobs", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          name: form.name,
          tool,
          max_retries: Number(form.maxRetries),
          timeout_secs: Number(form.timeoutSecs),
        }),
      });
      setForm(initialForm);
      await loadSnapshot();
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main className="app-shell">
      <section className="hero">
        <div>
          <p className="eyebrow">Rust Agent Runtime</p>
          <h1>Queue-driven execution with retries, checkpoints, and live signals.</h1>
        </div>
        <div className="hero-metric">
          <span>Throughput/min</span>
          <strong>{snapshot?.summary.throughput_per_minute.toFixed(0) ?? "0"}</strong>
        </div>
      </section>

      <section className="stats-grid">
        {[
          ["Queued", snapshot?.summary.queued ?? 0],
          ["Running", snapshot?.summary.running ?? 0],
          ["Succeeded", snapshot?.summary.succeeded ?? 0],
          ["Dead letter", snapshot?.summary.dead_letter ?? 0],
          ["Retries", snapshot?.summary.retried_total ?? 0],
        ].map(([label, value]) => (
          <article key={label} className="stat-card">
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="content-grid">
        <div className="panel">
          <div className="panel-head">
            <h2>Queue</h2>
            <span>{snapshot?.jobs.length ?? 0} jobs</span>
          </div>
          <div className="job-list">
            {snapshot?.jobs.map((job) => (
              <button
                key={job.id}
                className={`job-row ${selectedJob?.id === job.id ? "selected" : ""}`}
                onClick={() => setSelectedJobId(job.id)}
              >
                <div>
                  <strong>{job.name}</strong>
                  <span>{job.id.slice(0, 8)}</span>
                </div>
                <span className={`pill pill-${job.status}`}>{job.status.replace("_", " ")}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="panel">
          <div className="panel-head">
            <h2>Job Detail</h2>
            <span>{selectedJob?.attempts ?? 0} attempts</span>
          </div>
          {selectedJob ? (
            <div className="job-detail">
              <div className="detail-grid">
                <div>
                  <label>Status</label>
                  <strong>{selectedJob.status}</strong>
                </div>
                <div>
                  <label>Retries</label>
                  <strong>
                    {selectedJob.attempts}/{selectedJob.max_retries}
                  </strong>
                </div>
                <div>
                  <label>Timeout</label>
                  <strong>{selectedJob.timeout_secs}s</strong>
                </div>
                <div>
                  <label>Updated</label>
                  <strong>{new Date(selectedJob.updated_at).toLocaleTimeString()}</strong>
                </div>
              </div>
              <pre className="output-box">{selectedJob.output || selectedJob.last_error || "No output yet."}</pre>
              <div className="log-list">
                {selectedJob.logs.map((line, index) => (
                  <div key={`${line.ts}-${index}`} className="log-row">
                    <span>{new Date(line.ts).toLocaleTimeString()}</span>
                    <span>{line.level}</span>
                    <code>{line.message}</code>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <p className="empty">No jobs available.</p>
          )}
        </div>
      </section>

      <section className="bottom-grid">
        <div className="panel">
          <div className="panel-head">
            <h2>Submit Job</h2>
            <span>Allowlisted commands only</span>
          </div>
          <form className="job-form" onSubmit={submitJob}>
            <label>
              Name
              <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </label>
            <label>
              Type
              <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                <option value="command">command</option>
                <option value="sleep">sleep</option>
              </select>
            </label>
            {form.type === "command" && (
              <>
                <label>
                  Command
                  <input
                    value={form.command}
                    onChange={(e) => setForm({ ...form, command: e.target.value })}
                  />
                </label>
                <label>
                  Args
                  <input value={form.args} onChange={(e) => setForm({ ...form, args: e.target.value })} />
                </label>
                <label>
                  Cwd
                  <input value={form.cwd} onChange={(e) => setForm({ ...form, cwd: e.target.value })} />
                </label>
              </>
            )}
            <label>
              Max retries
              <input
                type="number"
                min="0"
                max="10"
                value={form.maxRetries}
                onChange={(e) => setForm({ ...form, maxRetries: Number(e.target.value) })}
              />
            </label>
            <label>
              Timeout seconds
              <input
                type="number"
                min="1"
                max="300"
                value={form.timeoutSecs}
                onChange={(e) => setForm({ ...form, timeoutSecs: Number(e.target.value) })}
              />
            </label>
            <button type="submit" disabled={submitting}>
              {submitting ? "Submitting..." : "Enqueue job"}
            </button>
          </form>
        </div>

        <div className="panel">
          <div className="panel-head">
            <h2>Event Stream</h2>
            <span>{snapshot?.recent_events.length ?? 0} recent</span>
          </div>
          <div className="event-list">
            {snapshot?.recent_events
              .slice()
              .reverse()
              .map((event) => (
                <div className="event-row" key={event.seq}>
                  <span>{new Date(event.ts).toLocaleTimeString()}</span>
                  <strong>{event.kind}</strong>
                  <code>{event.message}</code>
                </div>
              ))}
          </div>
        </div>
      </section>
    </main>
  );
}
