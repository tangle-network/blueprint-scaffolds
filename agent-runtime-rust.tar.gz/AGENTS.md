# AGENTS.md

Build a Rust agent runtime for high-throughput task execution. Task queue, concurrent workers, typed tool registry.

## What's here

This project was scaffolded by starter-foundry. The user's prompt drove the choices below — read their prompt first, it takes priority over everything in this file.

- **Family:** `agent-service-rust`
- **Layers:** `framework:agent-service-rust`, `database:sqlite`, `sdk:none`, `auth:none`, `payments:none`, `queue:none`

### Architecture notes
- Agent control loop: plan → act → reflect
- Tool registration
- Typed state management

## Getting started

```bash
cargo run
cargo check
```

Key files: `src/main.rs`, `Cargo.toml`, `agent.config.json`

## How to use this scaffold

This is a starting point, not a contract. You own every file.

- **Customize freely.** Replace components, change the layout, swap the color scheme — whatever fits the user's product.
- **The scaffold saves you setup time** — Tailwind, shadcn/ui, path aliases, and framework config are ready. Don't redo them.
- **Check `.starter-foundry/compose-report.json`** if you want to see which layer wrote which file.
- **Update this file** as the project evolves. Delete sections that no longer apply.
