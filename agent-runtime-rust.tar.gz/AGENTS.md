# AGENTS.md

## Goal

Build a Rust agent runtime for high-throughput task execution. Task queue, concurrent workers, typed tool registry.

## Stack

- Family: `agent-service-rust`
- Layers: `database:sqlite`, `sdk:none`, `auth:none`, `payments:none`, `queue:none`

## Architecture

- Agent control loop: plan → act → reflect
- Tool registration
- Typed state management

## Entry Points

- `src/main.rs`
- `Cargo.toml`
- `agent.config.json`

## Commands

- `cargo run`
- `cargo check`

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
