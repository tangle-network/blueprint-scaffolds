// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract SequencerRegistry {
    struct Operator {
        uint256 stake;
        uint64 joinedAt;
        uint32 commissionBps;
        bool active;
        string metadataURI;
    }

    address public immutable owner;
    uint64 public currentEpoch;
    uint256 public minimumStake;
    mapping(address => Operator) public operators;
    address[] public operatorList;

    event OperatorRegistered(address indexed operator, uint256 stake, string metadataURI);
    event OperatorStatusUpdated(address indexed operator, bool active);
    event EpochAdvanced(uint64 indexed newEpoch);

    modifier onlyOwner() {
        require(msg.sender == owner, "not owner");
        _;
    }

    constructor(uint256 _minimumStake) {
        owner = msg.sender;
        minimumStake = _minimumStake;
        currentEpoch = 1;
    }

    function registerOperator(uint256 stake, uint32 commissionBps, string calldata metadataURI) external {
        require(stake >= minimumStake, "stake too low");
        require(commissionBps <= 2_000, "commission too high");

        Operator storage operator = operators[msg.sender];
        require(operator.joinedAt == 0, "already registered");

        operators[msg.sender] = Operator({
            stake: stake,
            joinedAt: uint64(block.timestamp),
            commissionBps: commissionBps,
            active: true,
            metadataURI: metadataURI
        });
        operatorList.push(msg.sender);

        emit OperatorRegistered(msg.sender, stake, metadataURI);
    }

    function setOperatorStatus(address operatorAddr, bool active) external onlyOwner {
        require(operators[operatorAddr].joinedAt != 0, "unknown operator");
        operators[operatorAddr].active = active;
        emit OperatorStatusUpdated(operatorAddr, active);
    }

    function advanceEpoch() external onlyOwner {
        currentEpoch += 1;
        emit EpochAdvanced(currentEpoch);
    }

    function operatorCount() external view returns (uint256) {
        return operatorList.length;
    }
}
