// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface ISequencerRegistry {
    function operators(address operator) external view returns (
        uint256 stake,
        uint64 joinedAt,
        uint32 commissionBps,
        bool active,
        string memory metadataURI
    );
}

contract BatchInbox {
    struct BatchCommitment {
        bytes32 txRoot;
        bytes32 stateRoot;
        uint64 timestamp;
        uint64 l2BlockNumber;
        address proposer;
        string adapterId;
    }

    ISequencerRegistry public immutable registry;
    BatchCommitment[] public batches;

    event BatchSubmitted(
        uint256 indexed batchId,
        bytes32 indexed txRoot,
        bytes32 indexed stateRoot,
        uint64 l2BlockNumber,
        address proposer,
        string adapterId
    );

    constructor(address registryAddress) {
        registry = ISequencerRegistry(registryAddress);
    }

    function submitBatch(
        bytes32 txRoot,
        bytes32 stateRoot,
        uint64 l2BlockNumber,
        string calldata adapterId
    ) external returns (uint256 batchId) {
        (, , , bool active, ) = registry.operators(msg.sender);
        require(active, "operator inactive");

        batchId = batches.length;
        batches.push(
            BatchCommitment({
                txRoot: txRoot,
                stateRoot: stateRoot,
                timestamp: uint64(block.timestamp),
                l2BlockNumber: l2BlockNumber,
                proposer: msg.sender,
                adapterId: adapterId
            })
        );

        emit BatchSubmitted(batchId, txRoot, stateRoot, l2BlockNumber, msg.sender, adapterId);
    }

    function batchCount() external view returns (uint256) {
        return batches.length;
    }
}
