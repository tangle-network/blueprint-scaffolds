mod builder;
mod mempool;

use anyhow::Result;
use tokio::time::{sleep, Duration};

use builder::build_batch;
use mempool::FairMempool;

#[tokio::main]
async fn main() -> Result<()> {
    let mempool = FairMempool::seeded();
    let ordered = mempool.ordered();
    let batch = build_batch("op-stack", &ordered);

    println!("starting sequencer operator loop");
    println!("{}", serde_json::to_string_pretty(&batch)?);

    sleep(Duration::from_millis(250)).await;
    println!("pre-confirmations issued for {} intents", batch.tx_ids.len());

    Ok(())
}
