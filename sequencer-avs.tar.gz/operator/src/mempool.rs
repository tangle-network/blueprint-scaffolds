use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct TxIntent {
    pub id: String,
    pub sender: String,
    pub nonce: u64,
    pub encrypted_payload: String,
    pub ingress_ms: u64,
    pub max_fee_gwei: u64,
}

pub struct FairMempool {
    intents: Vec<TxIntent>,
}

impl FairMempool {
    pub fn seeded() -> Self {
        Self {
            intents: vec![
                TxIntent {
                    id: "0x01".into(),
                    sender: "0xaaa1".into(),
                    nonce: 7,
                    encrypted_payload: "ciphertext:rollup-a".into(),
                    ingress_ms: 1710001001,
                    max_fee_gwei: 4,
                },
                TxIntent {
                    id: "0x02".into(),
                    sender: "0xbbb2".into(),
                    nonce: 2,
                    encrypted_payload: "ciphertext:rollup-b".into(),
                    ingress_ms: 1710001002,
                    max_fee_gwei: 3,
                },
                TxIntent {
                    id: "0x03".into(),
                    sender: "0xaaa1".into(),
                    nonce: 8,
                    encrypted_payload: "ciphertext:rollup-a-next".into(),
                    ingress_ms: 1710001002,
                    max_fee_gwei: 5,
                },
            ],
        }
    }

    pub fn ordered(&self) -> Vec<TxIntent> {
        let mut intents = self.intents.clone();
        intents.sort_by_key(|intent| (intent.ingress_ms, intent.sender.clone(), intent.nonce));
        intents
    }
}
