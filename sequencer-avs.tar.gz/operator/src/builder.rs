use chrono::Utc;
use serde::Serialize;

use crate::mempool::TxIntent;

#[derive(Debug, Serialize)]
pub struct Batch {
    pub tx_ids: Vec<String>,
    pub encrypted_bundle_root: String,
    pub preconfirm_at: String,
    pub adapter: String,
}

pub fn build_batch(adapter: &str, intents: &[TxIntent]) -> Batch {
    let tx_ids = intents.iter().map(|intent| intent.id.clone()).collect::<Vec<_>>();
    let encrypted_bundle_root = format!("bundle:{}:{}", adapter, tx_ids.join("-"));

    Batch {
        tx_ids,
        encrypted_bundle_root,
        preconfirm_at: Utc::now().to_rfc3339(),
        adapter: adapter.to_string(),
    }
}
