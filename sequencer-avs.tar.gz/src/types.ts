export type RollupAdapter = {
  name: string;
  type: 'OP Stack' | 'Arbitrum Orbit' | 'Custom';
  status: 'Live' | 'Testnet' | 'Pilot';
  ttfb: string;
  notes: string;
};

export type Metric = {
  label: string;
  value: string;
  delta: string;
  tone: 'positive' | 'neutral';
};

export type TimelinePoint = {
  slot: string;
  confirmations: number;
  latencyMs: number;
};

export type SequencerNode = {
  id: string;
  region: string;
  stake: string;
  status: 'Primary' | 'Hot Standby' | 'Joining';
  uptime: string;
  lastBlock: string;
};

export type FeatureCard = {
  title: string;
  body: string;
  accent: string;
};
