import type { FeatureCard, Metric, RollupAdapter, SequencerNode, TimelinePoint } from './types';

export const metrics: Metric[] = [
  { label: 'Median Pre-confirmation', value: '420ms', delta: '-18% vs last epoch', tone: 'positive' },
  { label: 'Fair Queue Drift', value: '0.07%', delta: 'FCFS bounded by deterministic nonce ordering', tone: 'positive' },
  { label: 'Batches Finalized', value: '18,240', delta: '64 in the last 10 minutes', tone: 'neutral' },
  { label: 'Censorship Challenge Window', value: '12s', delta: '2 disputes pending review', tone: 'neutral' }
];

export const timeline: TimelinePoint[] = [
  { slot: '12:00', confirmations: 328, latencyMs: 410 },
  { slot: '12:05', confirmations: 341, latencyMs: 395 },
  { slot: '12:10', confirmations: 356, latencyMs: 405 },
  { slot: '12:15', confirmations: 362, latencyMs: 388 },
  { slot: '12:20', confirmations: 371, latencyMs: 376 },
  { slot: '12:25', confirmations: 365, latencyMs: 392 }
];

export const adapters: RollupAdapter[] = [
  {
    name: 'OP Stack Shared Sequencer',
    type: 'OP Stack',
    status: 'Live',
    ttfb: '430ms',
    notes: 'Batch inbox hooks map cleanly into L2OutputOracle cadence and derivation rules.'
  },
  {
    name: 'Orbit Fast Lane',
    type: 'Arbitrum Orbit',
    status: 'Testnet',
    ttfb: '470ms',
    notes: 'Pre-confirmations settle against the AVS quorum before nitro batch posting.'
  },
  {
    name: 'Sovereign SDK Adapter',
    type: 'Custom',
    status: 'Pilot',
    ttfb: '390ms',
    notes: 'Custom DA endpoints supported through builder plugins and sequencer receipts.'
  }
];

export const nodes: SequencerNode[] = [
  { id: 'seq-us-east-1', region: 'Virginia', stake: '18.2k ETH', status: 'Primary', uptime: '99.992%', lastBlock: '#18,240,441' },
  { id: 'seq-eu-west-1', region: 'Dublin', stake: '16.7k ETH', status: 'Hot Standby', uptime: '99.978%', lastBlock: '#18,240,440' },
  { id: 'seq-ap-sg-1', region: 'Singapore', stake: '14.9k ETH', status: 'Joining', uptime: '99.910%', lastBlock: '#18,240,438' }
];

export const featureCards: FeatureCard[] = [
  {
    title: 'FCFS Fairness',
    body: 'Transactions enter a deterministic queue keyed by ingress timestamp, sender nonce, and encrypted commitment reveal order.',
    accent: 'fair'
  },
  {
    title: 'MEV-resistant Batching',
    body: 'Builders operate on encrypted intents and threshold-decrypted bundles, reducing reorderable surface before batch publication.',
    accent: 'mev'
  },
  {
    title: 'Rotating Sequencer Set',
    body: 'EigenLayer operators rotate across epochs with slashable liveness guarantees and challengeable censorship proofs.',
    accent: 'rotation'
  }
];

export const registryHighlights = [
  'Epoch-based operator admission with stake-weighted quorum thresholds',
  'Pre-confirmation receipts signed by the active sequencer committee',
  'Forced inclusion path for censored transactions after challenge timeout',
  'Batch submission contract tuned for OP Stack, Orbit, and custom posting adapters'
];

export const contractFiles = [
  'contracts/src/SequencerRegistry.sol',
  'contracts/src/BatchInbox.sol',
  'operator/src/main.rs',
  'operator/src/mempool.rs',
  'operator/src/builder.rs'
];
