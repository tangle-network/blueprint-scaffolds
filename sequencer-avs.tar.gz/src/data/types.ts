export interface Sequencer {
  id: string;
  address: string;
  stake: string;
  status: "active" | "inactive" | "slashed";
  health: number;
  uptime: string;
  lastBatch: string;
  region: string;
  delegatedShares: string;
}

export interface Batch {
  id: string;
  sequencer: string;
  txCount: number;
  timestamp: string;
  blockNumber: number;
  gasUsed: string;
  orderingType: "FCFS" | "Fair" | "Threshold";
  latency: string;
  preConfirmed: boolean;
}

export interface Metrics {
  throughput: number;
  throughputUnit: string;
  avgLatency: number;
  latencyUnit: string;
  mevResistance: number;
  censorshipResistance: number;
  uptime: number;
  totalBatches: number;
  totalTransactions: number;
  activeSequencers: number;
  networkHealth: number;
}

export interface PreConfirmation {
  id: string;
  txHash: string;
  sequencer: string;
  status: "confirmed" | "pending" | "expired";
  timestamp: string;
  commitmentHash: string;
}
