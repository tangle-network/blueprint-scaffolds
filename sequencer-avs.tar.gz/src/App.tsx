import { Routes, Route, NavLink } from "react-router-dom";
import Dashboard from "./components/Dashboard";
import SequencerList from "./components/SequencerList";
import BatchExplorer from "./components/BatchExplorer";
import MetricsPanel from "./components/MetricsPanel";

const navItems = [
  { to: "/", label: "Dashboard" },
  { to: "/sequencers", label: "Sequencers" },
  { to: "/batches", label: "Batches" },
  { to: "/metrics", label: "Metrics" },
];

export default function App() {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto flex h-14 items-center px-4">
          <h1 className="mr-8 text-lg font-bold">
            Sequencer AVS <span className="text-muted-foreground font-normal text-sm">EigenLayer</span>
          </h1>
          <nav className="flex items-center gap-6 text-sm">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === "/"}
                className={({ isActive }) =>
                  isActive
                    ? "text-foreground font-medium"
                    : "text-muted-foreground hover:text-foreground transition-colors"
                }
              >
                {item.label}
              </NavLink>
            ))}
          </nav>
        </div>
      </header>
      <main className="container mx-auto px-4 py-6">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/sequencers" element={<SequencerList />} />
          <Route path="/batches" element={<BatchExplorer />} />
          <Route path="/metrics" element={<MetricsPanel />} />
        </Routes>
      </main>
    </div>
  );
}
