import {
  Activity,
  ArrowRight,
  Blocks,
  Gauge,
  ShieldCheck,
  TimerReset,
  Waypoints
} from 'lucide-react';
import {
  Area,
  AreaChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from 'recharts';
import {
  adapters,
  contractFiles,
  featureCards,
  metrics,
  nodes,
  registryHighlights,
  timeline
} from './data';

const iconMap = {
  fair: ShieldCheck,
  mev: Blocks,
  rotation: TimerReset
} as const;

function App() {
  return (
    <div className="app-shell">
      <header className="hero">
        <div className="hero__copy">
          <p className="eyebrow">EigenLayer AVS for decentralized rollup ordering</p>
          <h1>Sub-second confirmations with fair ordering and slashable sequencing.</h1>
          <p className="hero__lede">
            Sequencer AVS coordinates a rotating operator set for FCFS ordering, MEV-resistant batching,
            pre-confirmations, and censorship resistance across OP Stack, Arbitrum Orbit, and sovereign rollups.
          </p>
          <div className="hero__actions">
            <a href="#status" className="button button--primary">
              View live status
              <ArrowRight size={16} />
            </a>
            <a href="#contracts" className="button button--secondary">
              Inspect components
            </a>
          </div>
        </div>
        <div className="hero__panel">
          <div className="hero__panel-grid">
            <div>
              <span>Active epoch</span>
              <strong>Epoch 1284</strong>
            </div>
            <div>
              <span>Quorum threshold</span>
              <strong>78%</strong>
            </div>
            <div>
              <span>Pre-conf SLA</span>
              <strong>&lt; 500ms</strong>
            </div>
            <div>
              <span>Dispute bond</span>
              <strong>50 ETH</strong>
            </div>
          </div>
          <div className="hero__status">
            <Activity size={18} />
            <span>Committee healthy. No ordering deviation outside FCFS tolerance.</span>
          </div>
        </div>
      </header>

      <main>
        <section className="metrics">
          {metrics.map((metric) => (
            <article key={metric.label} className="metric-card">
              <span>{metric.label}</span>
              <strong>{metric.value}</strong>
              <em data-tone={metric.tone}>{metric.delta}</em>
            </article>
          ))}
        </section>

        <section className="features">
          {featureCards.map((feature) => {
            const Icon = iconMap[feature.accent as keyof typeof iconMap];
            return (
              <article key={feature.title} className="feature-card">
                <div className="feature-card__icon">
                  <Icon size={18} />
                </div>
                <h2>{feature.title}</h2>
                <p>{feature.body}</p>
              </article>
            );
          })}
        </section>

        <section id="status" className="dashboard-grid">
          <article className="panel panel--chart">
            <div className="panel__header">
              <div>
                <p className="panel__eyebrow">Throughput and latency</p>
                <h3>Pre-confirmations per slot</h3>
              </div>
              <Gauge size={18} />
            </div>
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={timeline}>
                <defs>
                  <linearGradient id="confirmationsFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ff7a18" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#ff7a18" stopOpacity={0.05} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
                <XAxis dataKey="slot" stroke="rgba(244, 236, 220, 0.7)" />
                <YAxis stroke="rgba(244, 236, 220, 0.7)" />
                <Tooltip />
                <Area
                  type="monotone"
                  dataKey="confirmations"
                  stroke="#ffb347"
                  fillOpacity={1}
                  fill="url(#confirmationsFill)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </article>

          <article className="panel panel--chart">
            <div className="panel__header">
              <div>
                <p className="panel__eyebrow">Sequencer responsiveness</p>
                <h3>Slot latency</h3>
              </div>
              <Waypoints size={18} />
            </div>
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={timeline}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
                <XAxis dataKey="slot" stroke="rgba(244, 236, 220, 0.7)" />
                <YAxis stroke="rgba(244, 236, 220, 0.7)" />
                <Tooltip />
                <Line type="monotone" dataKey="latencyMs" stroke="#ffd36e" strokeWidth={3} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </article>
        </section>

        <section className="integration-layout">
          <article className="panel">
            <div className="panel__header">
              <div>
                <p className="panel__eyebrow">Rollup adapters</p>
                <h3>Integration surface</h3>
              </div>
              <Blocks size={18} />
            </div>
            <div className="table-list">
              {adapters.map((adapter) => (
                <div key={adapter.name} className="table-list__row">
                  <div>
                    <strong>{adapter.name}</strong>
                    <span>{adapter.notes}</span>
                  </div>
                  <div>
                    <strong>{adapter.type}</strong>
                    <span>{adapter.status}</span>
                  </div>
                  <div>
                    <strong>{adapter.ttfb}</strong>
                    <span>median TTFB</span>
                  </div>
                </div>
              ))}
            </div>
          </article>

          <article className="panel">
            <div className="panel__header">
              <div>
                <p className="panel__eyebrow">Registry design</p>
                <h3>Protocol controls</h3>
              </div>
              <ShieldCheck size={18} />
            </div>
            <ul className="check-list">
              {registryHighlights.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </article>
        </section>

        <section className="integration-layout">
          <article className="panel">
            <div className="panel__header">
              <div>
                <p className="panel__eyebrow">Rotating sequencer set</p>
                <h3>Operator health</h3>
              </div>
              <Activity size={18} />
            </div>
            <div className="table-list">
              {nodes.map((node) => (
                <div key={node.id} className="table-list__row">
                  <div>
                    <strong>{node.id}</strong>
                    <span>{node.region}</span>
                  </div>
                  <div>
                    <strong>{node.stake}</strong>
                    <span>{node.status}</span>
                  </div>
                  <div>
                    <strong>{node.uptime}</strong>
                    <span>{node.lastBlock}</span>
                  </div>
                </div>
              ))}
            </div>
          </article>

          <article id="contracts" className="panel">
            <div className="panel__header">
              <div>
                <p className="panel__eyebrow">Local source inventory</p>
                <h3>Contracts and operator</h3>
              </div>
              <Blocks size={18} />
            </div>
            <div className="source-list">
              {contractFiles.map((file) => (
                <code key={file}>{file}</code>
              ))}
            </div>
          </article>
        </section>
      </main>
    </div>
  );
}

export default App;
