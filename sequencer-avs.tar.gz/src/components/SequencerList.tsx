import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { getSequencerSet } from "@/data/mock";

const statusVariant: Record<string, "default" | "secondary" | "destructive"> = {
  active: "default",
  inactive: "secondary",
  slashed: "destructive",
};

export default function SequencerList() {
  const sequencers = getSequencerSet();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">
          Sequencer Registry
        </h2>
        <p className="text-muted-foreground">
          Active sequencers, stake, health and status
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Sequencer Set</CardTitle>
          <CardDescription>
            {sequencers.filter((s) => s.status === "active").length} active /{" "}
            {sequencers.length} total
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Address</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Stake</TableHead>
                <TableHead>Delegated</TableHead>
                <TableHead>Health</TableHead>
                <TableHead>Uptime</TableHead>
                <TableHead>Last Batch</TableHead>
                <TableHead>Region</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sequencers.map((seq) => (
                <TableRow key={seq.id}>
                  <TableCell className="font-mono text-xs">{seq.id}</TableCell>
                  <TableCell className="font-mono text-xs">
                    {seq.address.slice(0, 10)}...{seq.address.slice(-6)}
                  </TableCell>
                  <TableCell>
                    <Badge variant={statusVariant[seq.status] ?? "outline"}>
                      {seq.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{seq.stake}</TableCell>
                  <TableCell>{seq.delegatedShares}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Progress value={seq.health} className="w-16" />
                      <span className="text-xs">{seq.health}%</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-xs">{seq.uptime}</TableCell>
                  <TableCell className="text-xs">{seq.lastBatch}</TableCell>
                  <TableCell className="text-xs">{seq.region}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
