import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { getMetrics } from "@/data/mock";

export default function MetricsPanel() {
  const metrics = getMetrics();

  const metricCards = [
    {
      title: "Throughput",
      value: `${metrics.throughput.toLocaleString()} ${metrics.throughputUnit}`,
      progress: Math.min((metrics.throughput / 3000) * 100, 100),
      description: "Transaction processing rate",
    },
    {
      title: "Average Latency",
      value: `${metrics.avgLatency} ${metrics.latencyUnit}`,
      progress: 100 - (metrics.avgLatency / 500) * 100,
      description: "End-to-end confirmation time",
    },
    {
      title: "MEV Resistance",
      value: `${metrics.mevResistance}%`,
      progress: metrics.mevResistance,
      description: "Resistance to MEV extraction attacks",
    },
    {
      title: "Censorship Resistance",
      value: `${metrics.censorshipResistance}%`,
      progress: metrics.censorshipResistance,
      description: "Transaction inclusion fairness",
    },
    {
      title: "Network Uptime",
      value: `${metrics.uptime}%`,
      progress: metrics.uptime,
      description: "Service availability over 30 days",
    },
    {
      title: "Network Health",
      value: `${metrics.networkHealth}%`,
      progress: metrics.networkHealth,
      description: "Overall network health score",
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Metrics</h2>
        <p className="text-muted-foreground">
          Throughput, latency, MEV resistance and performance scores
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {metricCards.map((card) => (
          <Card key={card.title}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">
                {card.title}
              </CardTitle>
              <CardDescription>{card.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{card.value}</div>
              <Progress value={card.progress} className="mt-3" />
              <p className="text-xs text-muted-foreground mt-1">
                {card.progress.toFixed(1)}% of target
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Aggregate Statistics</CardTitle>
          <CardDescription>Summary of sequencing activity</CardDescription>
        </CardHeader>
        <CardContent>
          <dl className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <dt className="text-sm text-muted-foreground">Total Batches</dt>
              <dd className="text-2xl font-bold">{metrics.totalBatches}</dd>
            </div>
            <div>
              <dt className="text-sm text-muted-foreground">
                Total Transactions
              </dt>
              <dd className="text-2xl font-bold">
                {metrics.totalTransactions.toLocaleString()}
              </dd>
            </div>
            <div>
              <dt className="text-sm text-muted-foreground">
                Active Sequencers
              </dt>
              <dd className="text-2xl font-bold">{metrics.activeSequencers}</dd>
            </div>
            <div>
              <dt className="text-sm text-muted-foreground">
                Avg Txs / Batch
              </dt>
              <dd className="text-2xl font-bold">
                {Math.round(metrics.totalTransactions / metrics.totalBatches)}
              </dd>
            </div>
          </dl>
        </CardContent>
      </Card>
    </div>
  );
}
