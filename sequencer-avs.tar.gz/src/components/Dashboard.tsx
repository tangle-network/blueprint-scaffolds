import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  getSequencerSet,
  getRecentBatches,
  getMetrics,
  getPreConfirmations,
} from "@/data/mock";
import NetworkStatus from "./NetworkStatus";
import PreConfirmationPanel from "./PreConfirmationPanel";

export default function Dashboard() {
  const sequencers = getSequencerSet();
  const batches = getRecentBatches();
  const metrics = getMetrics();
  const preConfirmations = getPreConfirmations();
  const activeSequencers = sequencers.filter((s) => s.status === "active");
  const leader = activeSequencers.reduce((a, b) =>
    a.health > b.health ? a : b
  );
  const latestBatch = batches[0];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Dashboard</h2>
        <p className="text-muted-foreground">
          Decentralized rollup ordering service overview
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Active Sequencers
            </CardTitle>
            <Badge variant="default">{metrics.activeSequencers}</Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{sequencers.length} total</div>
            <p className="text-xs text-muted-foreground">
              {activeSequencers.length} active,{" "}
              {sequencers.filter((s) => s.status === "inactive").length}{" "}
              inactive,{" "}
              {sequencers.filter((s) => s.status === "slashed").length} slashed
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Current Leader
            </CardTitle>
            <Badge className="bg-green-600">{leader.id}</Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold truncate">
              {leader.address.slice(0, 10)}...{leader.address.slice(-6)}
            </div>
            <p className="text-xs text-muted-foreground">
              Health: {leader.health}% | {leader.region}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Throughput</CardTitle>
            <Badge variant="secondary">
              {metrics.throughput} {metrics.throughputUnit}
            </Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {metrics.totalTransactions.toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground">
              Total transactions across {metrics.totalBatches} batches
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Latency</CardTitle>
            <Badge variant="outline">
              {metrics.avgLatency} {metrics.latencyUnit}
            </Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Sub-second</div>
            <Progress value={100 - metrics.avgLatency / 5} className="mt-2" />
            <p className="text-xs text-muted-foreground mt-1">
              Target: &lt;500ms | Current: {metrics.avgLatency}ms
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle className="text-base">Latest Batch</CardTitle>
            <CardDescription>Most recently submitted batch</CardDescription>
          </CardHeader>
          <CardContent>
            <dl className="space-y-2 text-sm">
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Batch ID</dt>
                <dd className="font-mono">{latestBatch.id}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Sequencer</dt>
                <dd className="font-mono">{latestBatch.sequencer}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Tx Count</dt>
                <dd>{latestBatch.txCount}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Gas Used</dt>
                <dd>{latestBatch.gasUsed}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Ordering</dt>
                <dd>{latestBatch.orderingType}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Latency</dt>
                <dd>{latestBatch.latency}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Pre-confirmed</dt>
                <dd>
                  {latestBatch.preConfirmed ? (
                    <Badge className="bg-green-600">Yes</Badge>
                  ) : (
                    <Badge variant="destructive">No</Badge>
                  )}
                </dd>
              </div>
            </dl>
          </CardContent>
        </Card>

        <NetworkStatus metrics={metrics} />

        <PreConfirmationPanel preConfirmations={preConfirmations} />
      </div>
    </div>
  );
}
