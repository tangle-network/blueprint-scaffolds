import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import type { Metrics } from "@/data/types";

export default function NetworkStatus({ metrics }: { metrics: Metrics }) {
  const indicators = [
    { label: "Network Health", value: metrics.networkHealth },
    { label: "MEV Resistance", value: metrics.mevResistance },
    { label: "Censorship Resistance", value: metrics.censorshipResistance },
    { label: "Uptime", value: metrics.uptime },
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Network Status</CardTitle>
        <CardDescription>Live network health indicators</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {indicators.map((ind) => (
            <div key={ind.label} className="space-y-1">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">{ind.label}</span>
                <span className="font-medium">{ind.value}%</span>
              </div>
              <Progress value={ind.value} />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
