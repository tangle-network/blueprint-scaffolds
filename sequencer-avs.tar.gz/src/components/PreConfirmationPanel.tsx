import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { PreConfirmation } from "@/data/types";

const statusVariant: Record<string, "default" | "secondary" | "destructive"> = {
  confirmed: "default",
  pending: "secondary",
  expired: "destructive",
};

export default function PreConfirmationPanel({
  preConfirmations,
}: {
  preConfirmations: PreConfirmation[];
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Pre-Confirmations</CardTitle>
        <CardDescription>Recent pre-confirmation commitments</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {preConfirmations.map((pc) => (
            <div
              key={pc.id}
              className="flex items-center justify-between text-sm"
            >
              <div className="flex items-center gap-2 min-w-0">
                <Badge variant={statusVariant[pc.status] ?? "outline"}>
                  {pc.status}
                </Badge>
                <span className="font-mono text-xs truncate">
                  {pc.txHash}
                </span>
              </div>
              <span className="text-xs text-muted-foreground ml-2 shrink-0">
                {pc.sequencer}
              </span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
