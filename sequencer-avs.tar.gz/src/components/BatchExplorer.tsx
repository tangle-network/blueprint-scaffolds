import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { getRecentBatches } from "@/data/mock";

export default function BatchExplorer() {
  const batches = getRecentBatches();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Batch Explorer</h2>
        <p className="text-muted-foreground">
          Recent batches, transaction counts, timing and ordering
        </p>
      </div>

      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All Batches</TabsTrigger>
          <TabsTrigger value="fcfs">FCFS</TabsTrigger>
          <TabsTrigger value="fair">Fair</TabsTrigger>
          <TabsTrigger value="threshold">Threshold</TabsTrigger>
        </TabsList>
        {["all", "fcfs", "fair", "threshold"].map((tab) => (
          <TabsContent key={tab} value={tab}>
            <Card>
              <CardHeader>
                <CardTitle>
                  {tab === "all" ? "All" : tab.toUpperCase()} Batches
                </CardTitle>
                <CardDescription>
                  {tab === "all"
                    ? batches.length
                    : batches.filter((b) =>
                        tab === "fcfs"
                          ? b.orderingType === "FCFS"
                          : tab === "fair"
                            ? b.orderingType === "Fair"
                            : b.orderingType === "Threshold"
                      ).length}{" "}
                  batches shown
                </CardDescription>
              </CardHeader>
              <CardContent>
                <BatchTable
                  batches={
                    tab === "all"
                      ? batches
                      : batches.filter((b) =>
                          tab === "fcfs"
                            ? b.orderingType === "FCFS"
                            : tab === "fair"
                              ? b.orderingType === "Fair"
                              : b.orderingType === "Threshold"
                        )
                  }
                />
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}

function BatchTable({ batches }: { batches: ReturnType<typeof getRecentBatches> }) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Batch ID</TableHead>
          <TableHead>Sequencer</TableHead>
          <TableHead>Tx Count</TableHead>
          <TableHead>Block #</TableHead>
          <TableHead>Gas Used</TableHead>
          <TableHead>Ordering</TableHead>
          <TableHead>Latency</TableHead>
          <TableHead>Pre-confirmed</TableHead>
          <TableHead>Timestamp</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {batches.map((batch) => (
          <TableRow key={batch.id}>
            <TableCell className="font-mono text-xs">{batch.id}</TableCell>
            <TableCell className="font-mono text-xs">
              {batch.sequencer}
            </TableCell>
            <TableCell>{batch.txCount}</TableCell>
            <TableCell className="font-mono text-xs">
              {batch.blockNumber}
            </TableCell>
            <TableCell>{batch.gasUsed}</TableCell>
            <TableCell>
              <Badge variant="outline">{batch.orderingType}</Badge>
            </TableCell>
            <TableCell>{batch.latency}</TableCell>
            <TableCell>
              {batch.preConfirmed ? (
                <Badge className="bg-green-600">Yes</Badge>
              ) : (
                <Badge variant="destructive">No</Badge>
              )}
            </TableCell>
            <TableCell className="text-xs text-muted-foreground">
              {new Date(batch.timestamp).toLocaleTimeString()}
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
