# Sequencer AVS on EigenLayer — Build Plan

## Project: Decentralized Rollup Ordering Service

### Architecture
- **Contracts**: Solidity (SequencerRegistry, BatchSubmission) in `contracts/`
- **Operator**: Rust mempool + block builder in `operator/`
- **Frontend**: Vite + React + TypeScript + Tailwind + shadcn/ui in `src/`

### Pages
1. `/` — Dashboard: overview of sequencer set, current leader, batch stats
2. `/sequencers` — Sequencer registry: active sequencers, stake, health
3. `/batches` — Batch explorer: recent batches, tx counts, timing
4. `/metrics` — Metrics: throughput, latency, MEV resistance scores

### API Routes (mock data via src/data/)
- `getSequencerSet()` — returns active sequencer list
- `getRecentBatches()` — returns recent batch data
- `getMetrics()` — returns performance metrics
- `getPreConfirmations()` — returns pre-confirmation status

### Components (src/components/)
- `ui/` — shadcn/ui primitives (Card, Button, Badge, Table, Tabs, Progress)
- `Dashboard.tsx` — main dashboard view
- `SequencerList.tsx` — sequencer table with status
- `BatchExplorer.tsx` — batch listing
- `MetricsPanel.tsx` — metrics charts
- `NetworkStatus.tsx` — live network health
- `PreConfirmationPanel.tsx` — pre-conf status

### shadcn/ui components to use
- Card, CardHeader, CardContent, CardTitle, CardDescription
- Table, TableBody, TableCell, TableHead, TableHeader, TableRow
- Badge
- Button
- Tabs, TabsList, TabsTrigger, TabsContent
- Progress

### Build Commands
- `pnpm install` — install deps
- `pnpm build` — production build
