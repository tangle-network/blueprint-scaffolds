import { createContext, useContext, useReducer, ReactNode } from 'react';
import { Connection, PublicKey } from '@solana/web3.js';

export interface NFTAsset {
  id: string;
  mint: string;
  name: string;
  symbol: string;
  uri: string;
  image: string;
  description: string;
  collection: string;
  owner: string;
  creator: string;
  royaltyBps: number;
  attributes: { trait_type: string; value: string }[];
  compressed: boolean;
  verified: boolean;
  rarityRank: number;
  rarityScore: number;
}

export interface Listing {
  id: string;
  nftMint: string;
  seller: string;
  price: number;
  currency: 'SOL' | 'USDC';
  type: 'fixed' | 'auction' | 'bundle';
  createdAt: number;
  expiresAt?: number;
  active: boolean;
}

export interface Auction {
  id: string;
  nftMint: string;
  seller: string;
  startingPrice: number;
  currentBid: number;
  currentBidder: string;
  minBidIncrement: number;
  startTime: number;
  endTime: number;
  reservePrice?: number;
  active: boolean;
}

export interface Offer {
  id: string;
  nftMint: string;
  buyer: string;
  price: number;
  currency: 'SOL' | 'USDC';
  expiresAt: number;
  active: boolean;
}

export interface Loan {
  id: string;
  nftMint: string;
  borrower: string;
  lender: string;
  principal: number;
  interestRate: number;
  duration: number;
  startTime: number;
  status: 'active' | 'repaid' | 'liquidated' | 'defaulted';
}

export interface FractionalToken {
  id: string;
  nftMint: string;
  tokenMint: string;
  totalSupply: number;
  availableSupply: number;
  pricePerToken: number;
  creator: string;
}

export interface SwapListing {
  id: string;
  offeredNft: string;
  wantedNfts: string[];
  creator: string;
  active: boolean;
  createdAt: number;
}

export interface BundleListing {
  id: string;
  nftMints: string[];
  seller: string;
  price: number;
  currency: 'SOL' | 'USDC';
  active: boolean;
  createdAt: number;
}

export interface Activity {
  id: string;
  type: 'sale' | 'listing' | 'bid' | 'offer' | 'transfer' | 'mint' | 'burn' | 'loan' | 'fractional' | 'swap';
  nftMint: string;
  from: string;
  to: string;
  price?: number;
  timestamp: number;
  txSignature: string;
}

export interface Collection {
  id: string;
  name: string;
  symbol: string;
  image: string;
  description: string;
  verified: boolean;
  floorPrice: number;
  totalVolume: number;
  totalSupply: number;
  listedCount: number;
  creators: string[];
}

interface MarketplaceState {
  connection: Connection | null;
  wallet: PublicKey | null;
  nfts: NFTAsset[];
  listings: Listing[];
  auctions: Auction[];
  offers: Offer[];
  loans: Loan[];
  fractions: FractionalToken[];
  swaps: SwapListing[];
  bundles: BundleListing[];
  activities: Activity[];
  collections: Collection[];
  loading: boolean;
  error: string | null;
}

type Action =
  | { type: 'SET_CONNECTION'; payload: Connection }
  | { type: 'SET_WALLET'; payload: PublicKey | null }
  | { type: 'SET_NFTS'; payload: NFTAsset[] }
  | { type: 'SET_LISTINGS'; payload: Listing[] }
  | { type: 'SET_AUCTIONS'; payload: Auction[] }
  | { type: 'SET_OFFERS'; payload: Offer[] }
  | { type: 'SET_LOANS'; payload: Loan[] }
  | { type: 'SET_FRACTIONS'; payload: FractionalToken[] }
  | { type: 'SET_SWAPS'; payload: SwapListing[] }
  | { type: 'SET_BUNDLES'; payload: BundleListing[] }
  | { type: 'SET_ACTIVITIES'; payload: Activity[] }
  | { type: 'SET_COLLECTIONS'; payload: Collection[] }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_ERROR'; payload: string | null }
  | { type: 'ADD_LISTING'; payload: Listing }
  | { type: 'ADD_AUCTION'; payload: Auction }
  | { type: 'ADD_OFFER'; payload: Offer }
  | { type: 'ADD_ACTIVITY'; payload: Activity };

const initialState: MarketplaceState = {
  connection: null,
  wallet: null,
  nfts: [],
  listings: [],
  auctions: [],
  offers: [],
  loans: [],
  fractions: [],
  swaps: [],
  bundles: [],
  activities: [],
  collections: [],
  loading: false,
  error: null,
};

function reducer(state: MarketplaceState, action: Action): MarketplaceState {
  switch (action.type) {
    case 'SET_CONNECTION':
      return { ...state, connection: action.payload };
    case 'SET_WALLET':
      return { ...state, wallet: action.payload };
    case 'SET_NFTS':
      return { ...state, nfts: action.payload };
    case 'SET_LISTINGS':
      return { ...state, listings: action.payload };
    case 'SET_AUCTIONS':
      return { ...state, auctions: action.payload };
    case 'SET_OFFERS':
      return { ...state, offers: action.payload };
    case 'SET_LOANS':
      return { ...state, loans: action.payload };
    case 'SET_FRACTIONS':
      return { ...state, fractions: action.payload };
    case 'SET_SWAPS':
      return { ...state, swaps: action.payload };
    case 'SET_BUNDLES':
      return { ...state, bundles: action.payload };
    case 'SET_ACTIVITIES':
      return { ...state, activities: action.payload };
    case 'SET_COLLECTIONS':
      return { ...state, collections: action.payload };
    case 'SET_LOADING':
      return { ...state, loading: action.payload };
    case 'SET_ERROR':
      return { ...state, error: action.payload };
    case 'ADD_LISTING':
      return { ...state, listings: [action.payload, ...state.listings] };
    case 'ADD_AUCTION':
      return { ...state, auctions: [action.payload, ...state.auctions] };
    case 'ADD_OFFER':
      return { ...state, offers: [action.payload, ...state.offers] };
    case 'ADD_ACTIVITY':
      return { ...state, activities: [action.payload, ...state.activities] };
    default:
      return state;
  }
}

interface MarketplaceContextType {
  state: MarketplaceState;
  dispatch: React.Dispatch<Action>;
}

const MarketplaceContext = createContext<MarketplaceContextType | undefined>(undefined);

export function MarketplaceProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  return (
    <MarketplaceContext.Provider value={{ state, dispatch }}>
      {children}
    </MarketplaceContext.Provider>
  );
}

export function useMarketplace() {
  const context = useContext(MarketplaceContext);
  if (!context) {
    throw new Error('useMarketplace must be used within a MarketplaceProvider');
  }
  return context;
}
