import { useState, useEffect, useCallback } from 'react';
import { useMarketplace } from '../context/MarketplaceContext';
import { NFTAsset, Listing } from '../context/MarketplaceContext';
import { generateMockNFTs, generateMockListings, generateMockAuctions, generateMockOffers, generateMockActivities, generateMockCollections, generateMockLoans, generateMockFractions, generateMockSwaps, generateMockBundles } from '../utils/mockData';
import { Connection } from '@solana/web3.js';

export function useInitializeData() {
  const { dispatch } = useMarketplace();

  useEffect(() => {
    const connection = new Connection('https://api.devnet.solana.com', 'confirmed');
    dispatch({ type: 'SET_CONNECTION', payload: connection });

    const nfts = generateMockNFTs(50);
    dispatch({ type: 'SET_NFTS', payload: nfts });
    dispatch({ type: 'SET_LISTINGS', payload: generateMockListings(nfts) });
    dispatch({ type: 'SET_AUCTIONS', payload: generateMockAuctions(nfts) });
    dispatch({ type: 'SET_OFFERS', payload: generateMockOffers(nfts) });
    dispatch({ type: 'SET_ACTIVITIES', payload: generateMockActivities(nfts) });
    dispatch({ type: 'SET_COLLECTIONS', payload: generateMockCollections() });
    dispatch({ type: 'SET_LOANS', payload: generateMockLoans(nfts) });
    dispatch({ type: 'SET_FRACTIONS', payload: generateMockFractions(nfts) });
    dispatch({ type: 'SET_SWAPS', payload: generateMockSwaps(nfts) });
    dispatch({ type: 'SET_BUNDLES', payload: generateMockBundles(nfts) });
  }, [dispatch]);
}

export function useSearchNFTs() {
  const { state } = useMarketplace();
  const [query, setQuery] = useState('');
  const [collection, setCollection] = useState('');
  const [minPrice, setMinPrice] = useState(0);
  const [maxPrice, setMaxPrice] = useState(Infinity);
  const [sortBy, setSortBy] = useState<'price_asc' | 'price_desc' | 'rarity' | 'recent'>('recent');

  const listings = state.listings.filter(l => l.active);

  const filtered = listings.filter(l => {
    const nft = state.nfts.find(n => n.mint === l.nftMint);
    if (!nft) return false;
    if (query && !nft.name.toLowerCase().includes(query.toLowerCase())) return false;
    if (collection && nft.collection !== collection) return false;
    if (l.price < minPrice) return false;
    if (l.price > maxPrice) return false;
    return true;
  });

  const results = filtered.map(l => ({
    listing: l,
    nft: state.nfts.find(n => n.mint === l.nftMint)!,
  })).filter(r => r.nft);

  results.sort((a, b) => {
    switch (sortBy) {
      case 'price_asc': return a.listing.price - b.listing.price;
      case 'price_desc': return b.listing.price - a.listing.price;
      case 'rarity': return a.nft.rarityRank - b.nft.rarityRank;
      case 'recent': return b.listing.createdAt - a.listing.createdAt;
      default: return 0;
    }
  });

  return {
    query, setQuery,
    collection, setCollection,
    minPrice, setMinPrice,
    maxPrice, setMaxPrice,
    sortBy, setSortBy,
    results,
    collections: [...new Set(state.nfts.map(n => n.collection))],
  };
}

export function useNFTDetail(mint: string) {
  const { state } = useMarketplace();
  const nft = state.nfts.find(n => n.mint === mint);
  const listing = state.listings.find(l => l.nftMint === mint && l.active);
  const offers = state.offers.filter(o => o.nftMint === mint && o.active);
  const auction = state.auctions.find(a => a.nftMint === mint && a.active);
  const activities = state.activities.filter(a => a.nftMint === mint);

  return { nft, listing, offers, auction, activities };
}

export function useCreatorStats() {
  const { state } = useMarketplace();
  const wallet = state.wallet?.toString() || '';

  const myListings = state.listings.filter(l => l.seller === wallet);
  const myNfts = state.nfts.filter(n => n.creator === wallet || n.owner === wallet);
  const totalVolume = state.activities
    .filter(a => (a.type === 'sale') && a.from === wallet)
    .reduce((sum, a) => sum + (a.price || 0), 0);

  return { myListings, myNfts, totalVolume, wallet };
}
