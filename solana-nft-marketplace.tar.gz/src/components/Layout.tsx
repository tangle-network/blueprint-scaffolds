import { Link, Outlet, useLocation } from 'react-router-dom';
import { useState } from 'react';
import { useMarketplace } from '../context/MarketplaceContext';

const NAV_ITEMS = [
  { path: '/', label: 'Gallery' },
  { path: '/trading', label: 'Trade' },
  { path: '/auctions', label: 'Auctions' },
  { path: '/collections', label: 'Collections' },
  { path: '/creator', label: 'Create' },
  { path: '/lending', label: 'Lending' },
  { path: '/fractional', label: 'Fractional' },
  { path: '/swaps', label: 'Swaps' },
  { path: '/bundles', label: 'Bundles' },
  { path: '/activity', label: 'Activity' },
];

export default function Layout() {
  const location = useLocation();
  const { state, dispatch } = useMarketplace();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const connectWallet = () => {
    const pk = new (require('@solana/web3.js').PublicKey)(
      '7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU'
    );
    dispatch({ type: 'SET_WALLET', payload: pk });
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <header style={{
        background: 'var(--bg-secondary)',
        borderBottom: '1px solid var(--border)',
        position: 'sticky',
        top: 0,
        zIndex: 100,
        backdropFilter: 'blur(12px)',
      }}>
        <div className="container" style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          height: 64,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 32 }}>
            <Link to="/" style={{
              fontSize: 20,
              fontWeight: 800,
              background: 'var(--gradient-1)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}>
              SolMarket
            </Link>
            <nav style={{ display: 'flex', gap: 4 }} className="desktop-nav">
              {NAV_ITEMS.slice(0, 6).map(item => (
                <Link
                  key={item.path}
                  to={item.path}
                  style={{
                    padding: '6px 14px',
                    borderRadius: 8,
                    fontSize: 13,
                    fontWeight: location.pathname === item.path ? 600 : 400,
                    color: location.pathname === item.path ? 'var(--accent)' : 'var(--text-secondary)',
                    background: location.pathname === item.path ? 'rgba(108,92,231,0.1)' : 'transparent',
                    transition: 'all 0.2s',
                  }}
                >
                  {item.label}
                </Link>
              ))}
              <div style={{ position: 'relative' }} className="more-menu">
                <button style={{
                  padding: '6px 14px',
                  borderRadius: 8,
                  fontSize: 13,
                  color: 'var(--text-secondary)',
                  background: 'transparent',
                }}>
                  More ▾
                </button>
              </div>
            </nav>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <button
              onClick={connectWallet}
              className="btn btn-primary"
              style={{ fontSize: 13, padding: '8px 20px' }}
            >
              {state.wallet
                ? `${state.wallet.toString().slice(0, 4)}...${state.wallet.toString().slice(-4)}`
                : 'Connect Wallet'}
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              style={{
                display: 'none',
                background: 'none',
                color: 'var(--text-primary)',
                fontSize: 24,
              }}
              className="mobile-menu-btn"
            >
              ☰
            </button>
          </div>
        </div>
      </header>

      <main style={{ flex: 1, padding: '24px 0' }}>
        <div className="container">
          <Outlet />
        </div>
      </main>

      <footer style={{
        background: 'var(--bg-secondary)',
        borderTop: '1px solid var(--border)',
        padding: '24px 0',
        marginTop: 48,
      }}>
        <div className="container" style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}>
          <span style={{ color: 'var(--text-muted)', fontSize: 13 }}>
            SolMarket — NFT Marketplace on Solana
          </span>
          <span style={{ color: 'var(--text-muted)', fontSize: 13 }}>
            Built with Anchor + React
          </span>
        </div>
      </footer>
    </div>
  );
}
