import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Gallery from './pages/Gallery';
import NFTDetail from './pages/NFTDetail';
import Trading from './pages/Trading';
import CreatorDashboard from './pages/CreatorDashboard';
import ActivityFeed from './pages/ActivityFeed';
import Auctions from './pages/Auctions';
import Lending from './pages/Lending';
import Fractional from './pages/Fractional';
import Swaps from './pages/Swaps';
import Bundles from './pages/Bundles';
import Collections from './pages/Collections';

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Gallery />} />
        <Route path="nft/:id" element={<NFTDetail />} />
        <Route path="trading" element={<Trading />} />
        <Route path="creator" element={<CreatorDashboard />} />
        <Route path="activity" element={<ActivityFeed />} />
        <Route path="auctions" element={<Auctions />} />
        <Route path="lending" element={<Lending />} />
        <Route path="fractional" element={<Fractional />} />
        <Route path="swaps" element={<Swaps />} />
        <Route path="bundles" element={<Bundles />} />
        <Route path="collections" element={<Collections />} />
      </Route>
    </Routes>
  );
}
