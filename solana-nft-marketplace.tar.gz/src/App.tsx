import { BrowserRouter, Routes, Route } from "react-router-dom"
import { Layout } from "@/components/layout/Layout"
import Gallery from "@/pages/Gallery"
import Auctions from "@/pages/Auctions"
import Dashboard from "@/pages/Dashboard"
import ActivityFeed from "@/pages/ActivityFeed"
import NFTDetail from "@/pages/NFTDetail"
import Lending from "@/pages/Lending"
import Fractional from "@/pages/Fractional"
import Swaps from "@/pages/Swaps"

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<Gallery />} />
          <Route path="/auctions" element={<Auctions />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/activity" element={<ActivityFeed />} />
          <Route path="/nft/:id" element={<NFTDetail />} />
          <Route path="/lending" element={<Lending />} />
          <Route path="/fractional" element={<Fractional />} />
          <Route path="/swaps" element={<Swaps />} />
          <Route path="/bundles" element={<Swaps />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}
