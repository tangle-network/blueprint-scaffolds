import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { useBundleSwapStore } from "@/stores/bundleSwap"
import { useWalletStore } from "@/stores/wallet"
import { formatSOL, shortenAddress, timeAgo } from "@/lib/utils"
import {
  ArrowLeftRight,
  Package,
  ShoppingCart,
  CheckCircle,
  XCircle,
  Clock,
  ArrowRight,
  Tag,
  Layers,
} from "lucide-react"

export default function Swaps() {
  const { bundles, swaps } = useBundleSwapStore()
  const { connected } = useWalletStore()
  const [tab, setTab] = useState<"bundles" | "swaps">("bundles")

  const activeBundles = bundles.filter((b) => b.isActive)
  const activeSwaps = swaps.filter((s) => s.status === "pending")

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <ArrowLeftRight className="h-6 w-6 text-primary" /> Bundles & Swaps
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          Buy NFT bundles or propose swaps with other collectors
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <Package className="h-4 w-4" />
              <span className="text-xs">Active Bundles</span>
            </div>
            <p className="text-2xl font-bold">{activeBundles.length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <ArrowLeftRight className="h-4 w-4" />
              <span className="text-xs">Open Swaps</span>
            </div>
            <p className="text-2xl font-bold">{activeSwaps.length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <ShoppingCart className="h-4 w-4" />
              <span className="text-xs">Bundle Volume</span>
            </div>
            <p className="text-2xl font-bold">
              {formatSOL(activeBundles.reduce((sum, b) => sum + b.price, 0))}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <Layers className="h-4 w-4" />
              <span className="text-xs">NFTs in Bundles</span>
            </div>
            <p className="text-2xl font-bold">
              {activeBundles.reduce((sum, b) => sum + b.nfts.length, 0)}
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="flex gap-2 border-b pb-0">
        {(["bundles", "swaps"] as const).map((t) => (
          <Button
            key={t}
            variant={tab === t ? "secondary" : "ghost"}
            size="sm"
            onClick={() => setTab(t)}
            className="rounded-b-none"
          >
            {t === "bundles" ? (
              <span className="flex items-center gap-1.5">
                <Package className="h-3.5 w-3.5" /> Bundles
              </span>
            ) : (
              <span className="flex items-center gap-1.5">
                <ArrowLeftRight className="h-3.5 w-3.5" /> NFT Swaps
              </span>
            )}
          </Button>
        ))}
      </div>

      {tab === "bundles" && (
        <div className="space-y-4">
          {activeBundles.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                <Package className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No active bundles available</p>
              </CardContent>
            </Card>
          ) : (
            activeBundles.map((bundle) => (
              <Card key={bundle.id}>
                <CardContent className="p-0">
                  <div className="p-4 space-y-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="text-lg font-semibold">{bundle.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {bundle.description}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          by {shortenAddress(bundle.seller)} &bull;{" "}
                          {timeAgo(bundle.createdAt)}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-bold text-primary">
                          {formatSOL(bundle.price)}
                        </p>
                        <Badge variant="outline" className="mt-1">
                          {bundle.nfts.length} NFTs
                        </Badge>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
                      {bundle.nfts.map((nft) => (
                        <div
                          key={nft.id}
                          className="rounded-lg overflow-hidden border bg-muted/30"
                        >
                          <div className="aspect-square overflow-hidden">
                            <img
                              src={nft.image}
                              alt={nft.name}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="p-2">
                            <p className="text-xs font-medium truncate">{nft.name}</p>
                            <p className="text-[10px] text-muted-foreground truncate">
                              {nft.collection}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t">
                      <p className="text-sm text-muted-foreground">
                        Price per NFT:{" "}
                        <span className="font-medium">
                          {formatSOL(bundle.price / bundle.nfts.length)}
                        </span>
                      </p>
                      {connected && (
                        <Button className="gap-2">
                          <ShoppingCart className="h-4 w-4" /> Buy Bundle
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Package className="h-5 w-5" /> Create a Bundle
              </CardTitle>
              <CardDescription>
                Bundle multiple NFTs together and sell at a discount
              </CardDescription>
            </CardHeader>
            <CardContent>
              {!connected ? (
                <p className="text-sm text-muted-foreground text-center py-4">
                  Connect your wallet to create a bundle
                </p>
              ) : (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Bundle Name</Label>
                    <Input placeholder="My NFT Bundle" />
                  </div>
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Input placeholder="A curated collection of..." />
                  </div>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Select NFTs</Label>
                      <p className="text-xs text-muted-foreground">
                        Select NFTs from your wallet to include in the bundle
                      </p>
                    </div>
                    <div className="space-y-2">
                      <Label>Bundle Price (SOL)</Label>
                      <Input type="number" step="0.1" placeholder="0.00" />
                    </div>
                  </div>
                  <Button className="w-full gap-2">
                    <Tag className="h-4 w-4" /> Create Bundle
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {tab === "swaps" && (
        <div className="space-y-4">
          {swaps.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                <ArrowLeftRight className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No swap proposals found</p>
              </CardContent>
            </Card>
          ) : (
            swaps.map((swap) => (
              <Card key={swap.id}>
                <CardContent className="p-4">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium">
                          Swap Proposal from{" "}
                          <span className="font-mono">{shortenAddress(swap.proposer)}</span>
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Target: {shortenAddress(swap.targetOwner)} &bull;{" "}
                          {timeAgo(swap.createdAt)} &bull; Expires{" "}
                          {new Date(swap.expiresAt).toLocaleDateString()}
                        </p>
                      </div>
                      <Badge
                        variant={
                          swap.status === "pending"
                            ? "outline"
                            : swap.status === "accepted"
                              ? "default"
                              : "destructive"
                        }
                      >
                        {swap.status === "pending" && (
                          <Clock className="h-3 w-3 mr-1" />
                        )}
                        {swap.status === "accepted" && (
                          <CheckCircle className="h-3 w-3 mr-1" />
                        )}
                        {swap.status === "rejected" && (
                          <XCircle className="h-3 w-3 mr-1" />
                        )}
                        {swap.status}
                      </Badge>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                          <ArrowRight className="h-3 w-3" /> Offering
                        </p>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                          {swap.offeredNfts.map((nft) => (
                            <div
                              key={nft.id}
                              className="rounded-lg overflow-hidden border bg-muted/30"
                            >
                              <div className="aspect-square overflow-hidden">
                                <img
                                  src={nft.image}
                                  alt={nft.name}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div className="p-1.5">
                                <p className="text-[10px] font-medium truncate">
                                  {nft.name}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                          <ArrowLeftRight className="h-3 w-3" /> Requesting
                        </p>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                          {swap.requestedNfts.map((nft) => (
                            <div
                              key={nft.id}
                              className="rounded-lg overflow-hidden border bg-muted/30"
                            >
                              <div className="aspect-square overflow-hidden">
                                <img
                                  src={nft.image}
                                  alt={nft.name}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div className="p-1.5">
                                <p className="text-[10px] font-medium truncate">
                                  {nft.name}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {swap.status === "pending" && connected && (
                      <div className="flex gap-2 pt-2 border-t">
                        <Button size="sm" variant="default" className="gap-1">
                          <CheckCircle className="h-3.5 w-3.5" /> Accept Swap
                        </Button>
                        <Button size="sm" variant="destructive" className="gap-1">
                          <XCircle className="h-3.5 w-3.5" /> Reject
                        </Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))
          )}

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <ArrowLeftRight className="h-5 w-5" /> Propose a Swap
              </CardTitle>
              <CardDescription>
                Offer your NFTs in exchange for NFTs from another collector
              </CardDescription>
            </CardHeader>
            <CardContent>
              {!connected ? (
                <p className="text-sm text-muted-foreground text-center py-4">
                  Connect your wallet to propose a swap
                </p>
              ) : (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Your NFTs (Offer)</Label>
                    <p className="text-xs text-muted-foreground">
                      Select NFTs from your wallet to offer
                    </p>
                  </div>
                  <Separator />
                  <div className="space-y-2">
                    <Label>Requested NFTs</Label>
                    <p className="text-xs text-muted-foreground">
                      Enter the target owner&apos;s address and select which NFTs you want
                    </p>
                    <Input placeholder="Target wallet address..." />
                  </div>
                  <Button className="w-full gap-2">
                    <ArrowRight className="h-4 w-4" /> Submit Swap Proposal
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
