import React from 'react'

export default function Fractional() { return <div>Fractional</div> }
