import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { useFractionalStore } from "@/stores/fractional"
import { useWalletStore } from "@/stores/wallet"
import { formatSOL, shortenAddress } from "@/lib/utils"
import {
  PieChart,
  TrendingUp,
  Users,
  ShoppingCart,
  ArrowRight,
  Layers,
  Coins,
} from "lucide-react"

export default function Fractional() {
  const { tokens } = useFractionalStore()
  const { connected } = useWalletStore()
  const [selectedToken, setSelectedToken] = useState<string | null>(null)
  const [buyAmount, setBuyAmount] = useState("")
  const [tab, setTab] = useState<"market" | "holdings">("market")

  const selected = tokens.find((t) => t.id === selectedToken)

  const totalMarketCap = tokens.reduce(
    (sum, t) => sum + t.totalSupply * t.pricePerToken,
    0
  )
  const totalAvailable = tokens.reduce((sum, t) => sum + t.availableSupply, 0)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <PieChart className="h-6 w-6 text-primary" /> Fractional Ownership
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          Buy fractional shares of premium NFTs
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <Coins className="h-4 w-4" />
              <span className="text-xs">Total Market Cap</span>
            </div>
            <p className="text-2xl font-bold">{formatSOL(totalMarketCap)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <Layers className="h-4 w-4" />
              <span className="text-xs">Tokenized NFTs</span>
            </div>
            <p className="text-2xl font-bold">{tokens.length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <ShoppingCart className="h-4 w-4" />
              <span className="text-xs">Available Shares</span>
            </div>
            <p className="text-2xl font-bold">{totalAvailable.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <Users className="h-4 w-4" />
              <span className="text-xs">Total Holders</span>
            </div>
            <p className="text-2xl font-bold">
              {tokens.reduce((sum, t) => sum + t.holders.length, 0)}
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="flex gap-2 border-b pb-0">
        {(["market", "holdings"] as const).map((t) => (
          <Button
            key={t}
            variant={tab === t ? "secondary" : "ghost"}
            size="sm"
            onClick={() => setTab(t)}
            className="rounded-b-none"
          >
            {t === "market" ? "Marketplace" : "My Holdings"}
          </Button>
        ))}
      </div>

      {tab === "market" && (
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            {tokens.map((token) => {
              const pctSold =
                ((token.totalSupply - token.availableSupply) / token.totalSupply) * 100
              const isSelected = selectedToken === token.id
              return (
                <Card
                  key={token.id}
                  className={`cursor-pointer transition-colors ${
                    isSelected ? "border-primary" : "hover:border-primary/50"
                  }`}
                  onClick={() => setSelectedToken(token.id)}
                >
                  <CardContent className="p-0">
                    <div className="flex items-stretch">
                      <div className="w-32 shrink-0 bg-muted">
                        <img
                          src={token.nft.image}
                          alt={token.nft.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 p-4 space-y-3">
                        <div className="flex items-start justify-between">
                          <div>
                            <p className="font-semibold">{token.nft.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {token.nft.collection}
                            </p>
                          </div>
                          <Badge variant="outline" className="gap-1">
                            <TrendingUp className="h-3 w-3" />
                            {pctSold.toFixed(0)}% sold
                          </Badge>
                        </div>

                        <div className="grid grid-cols-3 gap-3 text-sm">
                          <div>
                            <p className="text-muted-foreground text-xs">Price/Share</p>
                            <p className="font-medium">{formatSOL(token.pricePerToken)}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground text-xs">Total Shares</p>
                            <p className="font-medium">{token.totalSupply.toLocaleString()}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground text-xs">Available</p>
                            <p className="font-medium">{token.availableSupply.toLocaleString()}</p>
                          </div>
                        </div>

                        <Progress value={pctSold} className="h-1.5" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          <div className="space-y-4">
            {selected ? (
              <>
                <Card>
                  <div className="aspect-square overflow-hidden rounded-t-lg bg-muted">
                    <img
                      src={selected.nft.image}
                      alt={selected.nft.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardHeader>
                    <CardTitle className="text-lg">{selected.nft.name}</CardTitle>
                    <CardDescription>{selected.nft.collection}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Price per Share</span>
                        <span className="font-bold text-primary">
                          {formatSOL(selected.pricePerToken)}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Total Value</span>
                        <span>{formatSOL(selected.totalSupply * selected.pricePerToken)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Creator</span>
                        <span className="font-mono text-sm">
                          {shortenAddress(selected.creator)}
                        </span>
                      </div>
                    </div>

                    <Separator />

                    {connected ? (
                      <div className="space-y-2">
                        <Label htmlFor="buy-shares">Number of Shares</Label>
                        <div className="flex gap-2">
                          <Input
                            id="buy-shares"
                            type="number"
                            placeholder="100"
                            value={buyAmount}
                            onChange={(e) => setBuyAmount(e.target.value)}
                          />
                          <Button
                            onClick={() => {
                              setBuyAmount("")
                            }}
                            className="shrink-0 gap-1"
                          >
                            <ShoppingCart className="h-4 w-4" /> Buy
                          </Button>
                        </div>
                        {buyAmount && (
                          <p className="text-xs text-muted-foreground">
                            Total cost:{" "}
                            {formatSOL(parseInt(buyAmount) * selected.pricePerToken)}
                          </p>
                        )}
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground text-center">
                        Connect wallet to buy shares
                      </p>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <Users className="h-4 w-4" /> Top Holders
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {selected.holders
                        .sort((a, b) => b.percentage - a.percentage)
                        .map((holder, i) => (
                          <div
                            key={holder.address}
                            className="flex items-center justify-between py-1.5 border-b last:border-0"
                          >
                            <div className="flex items-center gap-2">
                              <span className="text-xs text-muted-foreground w-4">
                                {i + 1}
                              </span>
                              <span className="text-sm font-mono">
                                {shortenAddress(holder.address)}
                              </span>
                            </div>
                            <div className="text-right">
                              <p className="text-sm font-medium">
                                {holder.amount.toLocaleString()}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {holder.percentage}%
                              </p>
                            </div>
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  <PieChart className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>Select a tokenized NFT to view details</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      )}

      {tab === "holdings" && (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            {!connected ? (
              <>
                <PieChart className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>Connect your wallet to view your fractional holdings</p>
              </>
            ) : (
              <>
                <Layers className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>You don&apos;t own any fractional shares yet</p>
                <Button variant="outline" className="mt-4" onClick={() => setTab("market")}>
                  Browse Marketplace
                </Button>
              </>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
