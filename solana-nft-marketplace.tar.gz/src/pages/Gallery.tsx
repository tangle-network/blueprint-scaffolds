import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useMarketplace } from '../context/MarketplaceContext';
import { useInitializeData, useSearchNFTs } from '../hooks/useMarketplace';
import { shortenAddress, timeAgo } from '../utils';

export default function Gallery() {
  useInitializeData();
  const { state } = useMarketplace();
  const search = useSearchNFTs();
  const [view, setView] = useState<'grid' | 'list'>('grid');

  const stats = useMemo(() => ({
    totalListed: state.listings.filter(l => l.active).length,
    totalVolume: state.activities.filter(a => a.type === 'sale').reduce((s, a) => s + (a.price || 0), 0),
    floorPrice: Math.min(...state.listings.filter(l => l.active && l.currency === 'SOL').map(l => l.price), 0),
    totalCollections: state.collections.length,
  }), [state]);

  return (
    <div className="fade-in">
      <div style={{
        background: 'var(--gradient-1)',
        borderRadius: 16,
        padding: '40px 48px',
        marginBottom: 32,
        position: 'relative',
        overflow: 'hidden',
      }}>
        <h1 style={{ fontSize: 36, fontWeight: 800, marginBottom: 8 }}>
          Discover, Collect, Trade
        </h1>
        <p style={{ fontSize: 16, opacity: 0.9, maxWidth: 500 }}>
          The premier NFT marketplace on Solana. Fixed-price, auctions, bundles, and more.
        </p>
        <div style={{ display: 'flex', gap: 32, marginTop: 24 }}>
          {[
            { label: 'Listed', value: stats.totalListed },
            { label: 'Floor', value: `${stats.floorPrice.toFixed(2)} SOL` },
            { label: 'Volume', value: `${stats.totalVolume.toFixed(1)} SOL` },
            { label: 'Collections', value: stats.totalCollections },
          ].map(s => (
            <div key={s.label}>
              <div style={{ fontSize: 24, fontWeight: 700 }}>{s.value}</div>
              <div style={{ fontSize: 12, opacity: 0.7 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ display: 'flex', gap: 12, marginBottom: 24, flexWrap: 'wrap', alignItems: 'center' }}>
        <input
          className="input"
          placeholder="Search NFTs..."
          value={search.query}
          onChange={e => search.setQuery(e.target.value)}
          style={{ maxWidth: 300 }}
        />
        <select
          className="input"
          value={search.collection}
          onChange={e => search.setCollection(e.target.value)}
          style={{ maxWidth: 200 }}
        >
          <option value="">All Collections</option>
          {search.collections.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
        <select
          className="input"
          value={search.sortBy}
          onChange={e => search.setSortBy(e.target.value as any)}
          style={{ maxWidth: 180 }}
        >
          <option value="recent">Recently Listed</option>
          <option value="price_asc">Price: Low to High</option>
          <option value="price_desc">Price: High to Low</option>
          <option value="rarity">Rarity Rank</option>
        </select>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 4 }}>
          <button
            onClick={() => setView('grid')}
            className={`btn btn-sm ${view === 'grid' ? 'btn-primary' : 'btn-secondary'}`}
          >Grid</button>
          <button
            onClick={() => setView('list')}
            className={`btn btn-sm ${view === 'list' ? 'btn-primary' : 'btn-secondary'}`}
          >List</button>
        </div>
      </div>

      {view === 'grid' ? (
        <div className="grid grid-4">
          {search.results.map(({ listing, nft }) => (
            <Link to={`/nft/${nft.mint}`} key={nft.id} style={{ textDecoration: 'none', color: 'inherit' }}>
              <div className="card">
                <div style={{ position: 'relative', paddingTop: '100%', background: 'var(--bg-secondary)' }}>
                  <img
                    src={nft.image}
                    alt={nft.name}
                    style={{
                      position: 'absolute', top: 0, left: 0, width: '100%', height: '100%',
                      objectFit: 'cover',
                    }}
                    loading="lazy"
                  />
                  {nft.rarityRank <= 10 && (
                    <span className="badge badge-warning" style={{ position: 'absolute', top: 8, left: 8 }}>
                      Rank #{nft.rarityRank}
                    </span>
                  )}
                  {nft.compressed && (
                    <span className="badge badge-accent" style={{ position: 'absolute', top: 8, right: 8 }}>
                      cNFT
                    </span>
                  )}
                </div>
                <div style={{ padding: 14 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                    <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{nft.collection}</span>
                    {nft.verified && <span style={{ color: 'var(--success)', fontSize: 12 }}>✓</span>}
                  </div>
                  <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 8 }} className="text-truncate">{nft.name}</div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span className="price-tag" style={{ fontSize: 14 }}>
                      {listing.price.toFixed(3)}
                    </span>
                    <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>
                      {shortenAddress(nft.owner)}
                    </span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {search.results.map(({ listing, nft }) => (
            <Link to={`/nft/${nft.mint}`} key={nft.id} style={{ textDecoration: 'none', color: 'inherit' }}>
              <div className="card" style={{ display: 'flex', padding: 12, gap: 16, alignItems: 'center' }}>
                <img src={nft.image} alt={nft.name} style={{ width: 56, height: 56, borderRadius: 8, objectFit: 'cover' }} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 600 }} className="text-truncate">{nft.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{nft.collection}</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div className="price-tag" style={{ fontSize: 14 }}>{listing.price.toFixed(3)}</div>
                  <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{timeAgo(listing.createdAt)}</div>
                </div>
                <div style={{ display: 'flex', gap: 4 }}>
                  {nft.compressed && <span className="badge badge-accent">cNFT</span>}
                  <span className="badge badge-success">#{nft.rarityRank}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
