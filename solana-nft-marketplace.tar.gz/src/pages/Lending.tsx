import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { useLendingStore } from "@/stores/lending"
import { useWalletStore } from "@/stores/wallet"
import { formatSOL, shortenAddress } from "@/lib/utils"
import {
  Landmark,
  TrendingUp,
  Clock,
  AlertTriangle,
  DollarSign,
  Shield,
  ArrowRight,
} from "lucide-react"

const lendingPools = [
  {
    id: "pool-1",
    name: "Blue Chip Pool",
    totalLiquidity: 500 * 1e9,
    availableLiquidity: 320 * 1e9,
    interestRate: 5.2,
    maxDuration: 30,
    minDuration: 7,
    ltvRatio: 60,
    currency: "SOL",
  },
  {
    id: "pool-2",
    name: "Mid-Cap Collection Pool",
    totalLiquidity: 200 * 1e9,
    availableLiquidity: 150 * 1e9,
    interestRate: 8.5,
    maxDuration: 14,
    minDuration: 3,
    ltvRatio: 45,
    currency: "SOL",
  },
  {
    id: "pool-3",
    name: "Compressed NFT Pool",
    totalLiquidity: 50 * 1e9,
    availableLiquidity: 42 * 1e9,
    interestRate: 12.0,
    maxDuration: 7,
    minDuration: 1,
    ltvRatio: 35,
    currency: "SOL",
  },
]

export default function Lending() {
  const { loans } = useLendingStore()
  const { connected } = useWalletStore()
  const [tab, setTab] = useState<"loans" | "pools" | "borrow">("loans")
  const [borrowAmount, setBorrowAmount] = useState("")
  const [borrowDuration, setBorrowDuration] = useState("14")

  const activeLoans = loans.filter((l) => l.status === "active")
  const repaidLoans = loans.filter((l) => l.status === "repaid")

  const totalBorrowed = activeLoans.reduce((sum, l) => sum + l.principal, 0)
  const totalInterest = activeLoans.reduce(
    (sum, l) => sum + (l.principal * l.interestRate) / 100,
    0
  )

  const getTimeRemaining = (endTime: Date) => {
    const diff = endTime.getTime() - Date.now()
    if (diff <= 0) return "Overdue"
    const days = Math.floor(diff / 86400000)
    const hours = Math.floor((diff % 86400000) / 3600000)
    return `${days}d ${hours}h`
  }

  const getHealthFactor = (loan: (typeof activeLoans)[0]) => {
    const estimatedValue = loan.principal * 1.8
    const ratio = estimatedValue / loan.principal
    return ratio.toFixed(2)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Landmark className="h-6 w-6 text-primary" /> NFT Lending
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          Borrow SOL against your NFTs or provide liquidity
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <DollarSign className="h-4 w-4" />
              <span className="text-xs">Total Borrowed</span>
            </div>
            <p className="text-2xl font-bold">{formatSOL(totalBorrowed)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <TrendingUp className="h-4 w-4" />
              <span className="text-xs">Total Interest</span>
            </div>
            <p className="text-2xl font-bold">{formatSOL(totalInterest)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <Shield className="h-4 w-4" />
              <span className="text-xs">Active Loans</span>
            </div>
            <p className="text-2xl font-bold">{activeLoans.length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <Clock className="h-4 w-4" />
              <span className="text-xs">Repaid</span>
            </div>
            <p className="text-2xl font-bold">{repaidLoans.length}</p>
          </CardContent>
        </Card>
      </div>

      <div className="flex gap-2 border-b pb-0">
        {(["loans", "pools", "borrow"] as const).map((t) => (
          <Button
            key={t}
            variant={tab === t ? "secondary" : "ghost"}
            size="sm"
            onClick={() => setTab(t)}
            className="rounded-b-none"
          >
            {t === "borrow" ? "New Loan" : t.charAt(0).toUpperCase() + t.slice(1)}
          </Button>
        ))}
      </div>

      {tab === "loans" && (
        <div className="space-y-4">
          {loans.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                <Landmark className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No loans found</p>
              </CardContent>
            </Card>
          ) : (
            loans.map((loan) => (
              <Card key={loan.id} className="overflow-hidden">
                <CardContent className="p-0">
                  <div className="flex items-stretch">
                    <div className="w-24 shrink-0 bg-muted">
                      <img
                        src={loan.nft.image}
                        alt={loan.nft.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 p-4 space-y-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="font-semibold">{loan.nft.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {loan.nft.collection}
                          </p>
                        </div>
                        <Badge
                          variant={
                            loan.status === "active"
                              ? "default"
                              : loan.status === "repaid"
                                ? "secondary"
                                : "destructive"
                          }
                        >
                          {loan.status}
                        </Badge>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
                        <div>
                          <p className="text-muted-foreground text-xs">Principal</p>
                          <p className="font-medium">{formatSOL(loan.principal)}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground text-xs">Interest Rate</p>
                          <p className="font-medium">{loan.interestRate}%</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground text-xs">Duration</p>
                          <p className="font-medium">{loan.duration} days</p>
                        </div>
                        {loan.status === "active" && (
                          <div>
                            <p className="text-muted-foreground text-xs">Time Left</p>
                            <p className="font-medium">{getTimeRemaining(loan.endTime)}</p>
                          </div>
                        )}
                      </div>

                      {loan.status === "active" && (
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-muted-foreground">
                              Health Factor:
                            </span>
                            <Badge
                              variant="outline"
                              className={
                                parseFloat(getHealthFactor(loan)) > 1.5
                                  ? "text-green-500"
                                  : "text-yellow-500"
                              }
                            >
                              {getHealthFactor(loan)}
                            </Badge>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" variant="default" className="text-xs h-7">
                              Repay Loan
                            </Button>
                          </div>
                        </div>
                      )}

                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span>Lender: {shortenAddress(loan.lender)}</span>
                        <span>Borrower: {shortenAddress(loan.borrower)}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      )}

      {tab === "pools" && (
        <div className="space-y-4">
          {lendingPools.map((pool) => (
            <Card key={pool.id}>
              <CardContent className="pt-6 space-y-4">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-semibold">{pool.name}</p>
                    <p className="text-xs text-muted-foreground">
                      Min {pool.minDuration}d - Max {pool.maxDuration}d &bull;{" "}
                      {pool.ltvRatio}% LTV
                    </p>
                  </div>
                  <Badge variant="outline" className="gap-1">
                    <TrendingUp className="h-3 w-3" />
                    {pool.interestRate}% APR
                  </Badge>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Available Liquidity</span>
                    <span>{formatSOL(pool.availableLiquidity)}</span>
                  </div>
                  <Progress
                    value={
                      ((pool.totalLiquidity - pool.availableLiquidity) /
                        pool.totalLiquidity) *
                      100
                    }
                    className="h-2"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Used: {formatSOL(pool.totalLiquidity - pool.availableLiquidity)}</span>
                    <span>Total: {formatSOL(pool.totalLiquidity)}</span>
                  </div>
                </div>

                <Button variant="outline" className="w-full gap-2">
                  <DollarSign className="h-4 w-4" /> Supply Liquidity
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {tab === "borrow" && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Request a Loan</CardTitle>
            <CardDescription>
              Use your NFT as collateral to borrow SOL
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {!connected ? (
              <div className="text-center py-8 text-muted-foreground">
                <AlertTriangle className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>Connect your wallet to request a loan</p>
              </div>
            ) : (
              <>
                <div className="space-y-2">
                  <Label>Select NFT Collateral</Label>
                  <select className="w-full h-10 rounded-md border bg-background px-3 text-sm">
                    <option value="">Choose an NFT...</option>
                    <option value="nft-5">Compressed Pixel #001</option>
                    <option value="nft-9">Compressed Pixel #500</option>
                  </select>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="borrow-amount">Borrow Amount (SOL)</Label>
                    <Input
                      id="borrow-amount"
                      type="number"
                      step="0.1"
                      placeholder="0.00"
                      value={borrowAmount}
                      onChange={(e) => setBorrowAmount(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="borrow-duration">Duration (days)</Label>
                    <Input
                      id="borrow-duration"
                      type="number"
                      value={borrowDuration}
                      onChange={(e) => setBorrowDuration(e.target.value)}
                    />
                  </div>
                </div>

                <Separator />

                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Interest Rate</span>
                    <span>8.5% APR</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">LTV Ratio</span>
                    <span>45%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Estimated Repayment</span>
                    <span className="font-medium">
                      {borrowAmount
                        ? (
                            parseFloat(borrowAmount) *
                            (1 + 0.085 * (parseInt(borrowDuration) || 14) / 365)
                          ).toFixed(3) + " SOL"
                        : "-- SOL"}
                    </span>
                  </div>
                </div>

                <Button className="w-full gap-2">
                  <ArrowRight className="h-4 w-4" /> Submit Loan Request
                </Button>
              </>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
