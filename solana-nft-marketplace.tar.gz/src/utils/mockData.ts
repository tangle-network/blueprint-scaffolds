import { Keypair, PublicKey } from '@solana/web3.js';
import { NFTAsset, Collection, Activity, Listing, Auction, Offer, Loan, FractionalToken, SwapListing, BundleListing } from '../context/MarketplaceContext';
import { generateId, rankNfts } from '../utils';

const COLLECTION_NAMES = [
  'Solana Monkeys', 'Degenerate Apes', 'Aurora Pixels', 'Cosmic Voyagers',
  'Neon Samurai', 'Pixel Pandas', 'Sol Dragons', 'Metaverse Explorers',
];

const TRAIT_TYPES = ['Background', 'Body', 'Eyes', 'Headwear', 'Clothing', 'Accessory', 'Mouth', 'Skin'];
const TRAIT_VALUES: Record<string, string[]> = {
  Background: ['Cosmic', 'Sunset', 'Ocean', 'Forest', 'Desert', 'Neon City', 'Galaxy', 'Void'],
  Body: ['Normal', 'Cyborg', 'Skeleton', 'Zombie', 'Alien', 'Robot', 'Crystal', 'Shadow'],
  Eyes: ['Laser', 'Sleepy', 'Angry', 'Happy', 'Cyclops', 'Heterochromia', 'Visor', 'Diamond'],
  Headwear: ['Crown', 'Beanie', 'Halo', 'Horns', 'Top Hat', 'Bandana', 'Mohawk', 'None'],
  Clothing: ['Tuxedo', 'Hoodie', 'Armor', 'Spacesuit', 'Kimono', 'Toga', 'Tropical', 'None'],
  Accessory: ['Earring', 'Nose Ring', 'Chain', 'Wings', 'Tail', 'Scar', 'Tattoo', 'None'],
  Mouth: ['Smile', 'Grin', 'Frown', 'Tongue Out', 'Cigar', 'Pipe', 'Vampire', 'None'],
  Skin: ['Gold', 'Diamond', 'Holographic', 'Invisible', 'Lava', 'Ice', 'Electric', 'Normal'],
};

function randomChoice<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export function generateMockNFTs(count: number = 50): NFTAsset[] {
  const nfts: NFTAsset[] = [];
  for (let i = 0; i < count; i++) {
    const collection = randomChoice(COLLECTION_NAMES);
    const attrs = TRAIT_TYPES.map(trait => ({
      trait_type: trait,
      value: randomChoice(TRAIT_VALUES[trait]),
    }));
    nfts.push({
      id: generateId(),
      mint: Keypair.generate().publicKey.toString(),
      name: `${collection} #${i + 1}`,
      symbol: collection.split(' ').map(w => w[0]).join(''),
      uri: `https://arweave.net/mock-${i}`,
      image: `https://picsum.photos/seed/${i}/400/400`,
      description: `A unique piece from the ${collection} collection.`,
      collection,
      owner: Keypair.generate().publicKey.toString(),
      creator: Keypair.generate().publicKey.toString(),
      royaltyBps: randomChoice([250, 500, 750, 1000]),
      attributes: attrs,
      compressed: Math.random() > 0.7,
      verified: Math.random() > 0.3,
      rarityRank: 0,
      rarityScore: 0,
    });
  }
  return rankNfts(nfts);
}

export function generateMockListings(nfts: NFTAsset[]): Listing[] {
  return nfts.slice(0, 20).map((nft, i) => ({
    id: generateId(),
    nftMint: nft.mint,
    seller: nft.owner,
    price: parseFloat((Math.random() * 50 + 0.5).toFixed(3)),
    currency: Math.random() > 0.3 ? 'SOL' as const : 'USDC' as const,
    type: 'fixed' as const,
    createdAt: Date.now() - randomInt(0, 7 * 86400000),
    active: true,
  }));
}

export function generateMockAuctions(nfts: NFTAsset[]): Auction[] {
  return nfts.slice(5, 15).map(nft => ({
    id: generateId(),
    nftMint: nft.mint,
    seller: nft.owner,
    startingPrice: parseFloat((Math.random() * 10 + 0.1).toFixed(3)),
    currentBid: parseFloat((Math.random() * 30 + 1).toFixed(3)),
    currentBidder: Keypair.generate().publicKey.toString(),
    minBidIncrement: 0.1,
    startTime: Date.now() - randomInt(3600000, 86400000),
    endTime: Date.now() + randomInt(3600000, 7 * 86400000),
    reservePrice: Math.random() > 0.5 ? parseFloat((Math.random() * 20 + 5).toFixed(3)) : undefined,
    active: true,
  }));
}

export function generateMockOffers(nfts: NFTAsset[]): Offer[] {
  return nfts.slice(0, 10).map(nft => ({
    id: generateId(),
    nftMint: nft.mint,
    buyer: Keypair.generate().publicKey.toString(),
    price: parseFloat((Math.random() * 20 + 0.1).toFixed(3)),
    currency: Math.random() > 0.5 ? 'SOL' as const : 'USDC' as const,
    expiresAt: Date.now() + randomInt(86400000, 7 * 86400000),
    active: true,
  }));
}

export function generateMockActivities(nfts: NFTAsset[]): Activity[] {
  const types: Activity['type'][] = ['sale', 'listing', 'bid', 'offer', 'transfer', 'mint'];
  return Array.from({ length: 30 }, () => ({
    id: generateId(),
    type: randomChoice(types),
    nftMint: randomChoice(nfts).mint,
    from: Keypair.generate().publicKey.toString(),
    to: Keypair.generate().publicKey.toString(),
    price: parseFloat((Math.random() * 50 + 0.1).toFixed(3)),
    timestamp: Date.now() - randomInt(0, 30 * 86400000),
    txSignature: generateId() + generateId(),
  }));
}

export function generateMockCollections(): Collection[] {
  return COLLECTION_NAMES.map(name => ({
    id: generateId(),
    name,
    symbol: name.split(' ').map(w => w[0]).join(''),
    image: `https://picsum.photos/seed/${name.replace(/\s/g, '')}/200/200`,
    description: `The official ${name} collection on Solana.`,
    verified: Math.random() > 0.3,
    floorPrice: parseFloat((Math.random() * 20 + 0.5).toFixed(2)),
    totalVolume: parseFloat((Math.random() * 10000).toFixed(2)),
    totalSupply: randomInt(500, 10000),
    listedCount: randomInt(10, 500),
    creators: [Keypair.generate().publicKey.toString()],
  }));
}

export function generateMockLoans(nfts: NFTAsset[]): Loan[] {
  const statuses: Loan['status'][] = ['active', 'repaid', 'liquidated'];
  return nfts.slice(0, 8).map(nft => ({
    id: generateId(),
    nftMint: nft.mint,
    borrower: nft.owner,
    lender: Keypair.generate().publicKey.toString(),
    principal: parseFloat((Math.random() * 50 + 1).toFixed(3)),
    interestRate: randomInt(3, 25),
    duration: randomInt(7, 90),
    startTime: Date.now() - randomInt(0, 30 * 86400000),
    status: randomChoice(statuses),
  }));
}

export function generateMockFractions(nfts: NFTAsset[]): FractionalToken[] {
  return nfts.slice(0, 6).map(nft => ({
    id: generateId(),
    nftMint: nft.mint,
    tokenMint: Keypair.generate().publicKey.toString(),
    totalSupply: randomInt(100, 10000),
    availableSupply: randomInt(10, 5000),
    pricePerToken: parseFloat((Math.random() * 0.5 + 0.01).toFixed(4)),
    creator: nft.owner,
  }));
}

export function generateMockSwaps(nfts: NFTAsset[]): SwapListing[] {
  return nfts.slice(0, 6).map(nft => ({
    id: generateId(),
    offeredNft: nft.mint,
    wantedNfts: [randomChoice(nfts).mint, randomChoice(nfts).mint],
    creator: nft.owner,
    active: true,
    createdAt: Date.now() - randomInt(0, 7 * 86400000),
  }));
}

export function generateMockBundles(nfts: NFTAsset[]): BundleListing[] {
  return Array.from({ length: 5 }, () => {
    const bundleSize = randomInt(2, 5);
    const bundleNfts = Array.from({ length: bundleSize }, () => randomChoice(nfts));
    return {
      id: generateId(),
      nftMints: bundleNfts.map(n => n.mint),
      seller: bundleNfts[0].owner,
      price: parseFloat((Math.random() * 100 + 5).toFixed(3)),
      currency: 'SOL' as const,
      active: true,
      createdAt: Date.now() - randomInt(0, 7 * 86400000),
    };
  });
}
