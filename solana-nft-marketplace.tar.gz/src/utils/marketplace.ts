import { Connection, PublicKey, Transaction, SystemProgram, Keypair } from '@solana/web3.js';
import {
  getAssociatedTokenAddress,
  createAssociatedTokenAccountInstruction,
  createTransferInstruction,
  TOKEN_PROGRAM_ID,
} from '@solana/spl-token';
import { NFTAsset, Listing, Auction, Offer } from '../context/MarketplaceContext';
import { generateId } from '../utils';

const PROGRAM_ID = new PublicKey('So1Marketp1aceXXXXXXXXXXXXXXXXXXXXXX');

export class MarketplaceSDK {
  private connection: Connection;

  constructor(endpoint: string = 'https://api.devnet.solana.com') {
    this.connection = new Connection(endpoint, 'confirmed');
  }

  async createListing(
    nftMint: PublicKey,
    seller: PublicKey,
    price: number,
    currency: 'SOL' | 'USDC' = 'SOL'
  ): Promise<string> {
    const tx = new Transaction();
    const listingId = generateId();
    const listingKey = Keypair.generate();

    tx.add(
      SystemProgram.createAccount({
        fromPubkey: seller,
        newAccountPubkey: listingKey.publicKey,
        space: 256,
        lamports: await this.connection.getMinimumBalanceForRentExemption(256),
        programId: PROGRAM_ID,
      })
    );

    const nftAccount = await getAssociatedTokenAddress(nftMint, seller);
    const escrow = await getAssociatedTokenAddress(nftMint, listingKey.publicKey, true);

    tx.add(
      createAssociatedTokenAccountInstruction(seller, escrow, listingKey.publicKey, nftMint),
      createTransferInstruction(nftAccount, escrow, seller, 1, [], TOKEN_PROGRAM_ID)
    );

    return listingId;
  }

  async buyListing(listing: Listing, buyer: PublicKey): Promise<Transaction> {
    const tx = new Transaction();
    if (listing.currency === 'SOL') {
      tx.add(
        SystemProgram.transfer({
          fromPubkey: buyer,
          toPubkey: new PublicKey(listing.seller),
          lamports: Math.floor(listing.price * 1_000_000_000),
        })
      );
    }
    return tx;
  }

  async createAuction(
    nftMint: PublicKey,
    seller: PublicKey,
    startingPrice: number,
    duration: number,
    reservePrice?: number
  ): Promise<string> {
    const auctionId = generateId();
    return auctionId;
  }

  async placeBid(
    auction: Auction,
    bidder: PublicKey,
    amount: number
  ): Promise<Transaction> {
    const tx = new Transaction();
    return tx;
  }

  async settleAuction(auction: Auction): Promise<Transaction> {
    const tx = new Transaction();
    return tx;
  }

  async makeOffer(
    nftMint: PublicKey,
    buyer: PublicKey,
    price: number,
    currency: 'SOL' | 'USDC' = 'SOL'
  ): Promise<string> {
    return generateId();
  }

  async batchBuy(listings: Listing[], buyer: PublicKey): Promise<Transaction> {
    const tx = new Transaction();
    let totalSol = 0;
    for (const listing of listings) {
      if (listing.currency === 'SOL') {
        totalSol += Math.floor(listing.price * 1_000_000_000);
      }
    }
    if (totalSol > 0) {
      tx.add(
        SystemProgram.transfer({
          fromPubkey: buyer,
          toPubkey: new PublicKey(listings[0].seller),
          lamports: totalSol,
        })
      );
    }
    return tx;
  }

  async verifyCollection(
    collectionMint: PublicKey,
    nftMint: PublicKey,
    authority: PublicKey
  ): Promise<Transaction> {
    const tx = new Transaction();
    return tx;
  }

  getConnection(): Connection {
    return this.connection;
  }
}

export const sdk = new MarketplaceSDK();
