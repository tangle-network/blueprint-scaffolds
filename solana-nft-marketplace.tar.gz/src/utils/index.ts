import { NFTAsset } from '../context/MarketplaceContext';

export function shortenAddress(address: string, chars = 4): string {
  return `${address.slice(0, chars)}...${address.slice(-chars)}`;
}

export function formatSOL(lamports: number): string {
  return (lamports / 1_000_000_000).toFixed(4);
}

export function formatUSD(usd: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
  }).format(usd);
}

export function timeAgo(timestamp: number): string {
  const seconds = Math.floor((Date.now() - timestamp) / 1000);
  if (seconds < 60) return `${seconds}s ago`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d ago`;
  const months = Math.floor(days / 30);
  return `${months}mo ago`;
}

export function formatDate(timestamp: number): string {
  return new Date(timestamp).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export function calculateRarityScore(nft: NFTAsset, allNfts: NFTAsset[]): number {
  if (!nft.attributes.length || !allNfts.length) return 0;
  let score = 0;
  const total = allNfts.length;
  for (const attr of nft.attributes) {
    const count = allNfts.filter(n =>
      n.attributes.some(a => a.trait_type === attr.trait_type && a.value === attr.value)
    ).length;
    if (count > 0) {
      score += 1 / (count / total);
    }
  }
  return score;
}

export function rankNfts(nfts: NFTAsset[]): NFTAsset[] {
  const scored = nfts.map(nft => ({
    nft,
    score: calculateRarityScore(nft, nfts),
  }));
  scored.sort((a, b) => b.score - a.score);
  return scored.map((s, i) => ({ ...s.nft, rarityRank: i + 1, rarityScore: s.score }));
}

export function royaltyAmount(price: number, bps: number): number {
  return (price * bps) / 10000;
}

export function validatePrice(price: number): boolean {
  return price > 0 && isFinite(price);
}

export function generateId(): string {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

export function nftDisplayName(nft: NFTAsset): string {
  return nft.name || `#${nft.mint.slice(0, 8)}`;
}
