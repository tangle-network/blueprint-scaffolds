import { create } from "zustand"
import type { Bundle, SwapProposal } from "@/types"
import { mockBundles, mockSwaps } from "@/data/mock"

interface BundleSwapState {
  bundles: Bundle[]
  swaps: SwapProposal[]
  createBundle: (bundle: Bundle) => void
  buyBundle: (id: string) => void
  proposeSwap: (swap: SwapProposal) => void
  acceptSwap: (id: string) => void
  rejectSwap: (id: string) => void
}

export const useBundleSwapStore = create<BundleSwapState>((set) => ({
  bundles: mockBundles,
  swaps: mockSwaps,
  createBundle: (bundle) =>
    set((s) => ({ bundles: [...s.bundles, bundle] })),
  buyBundle: (id) =>
    set((s) => ({
      bundles: s.bundles.map((b) =>
        b.id === id ? { ...b, isActive: false } : b
      ),
    })),
  proposeSwap: (swap) =>
    set((s) => ({ swaps: [...s.swaps, swap] })),
  acceptSwap: (id) =>
    set((s) => ({
      swaps: s.swaps.map((sw) =>
        sw.id === id ? { ...sw, status: "accepted" as const } : sw
      ),
    })),
  rejectSwap: (id) =>
    set((s) => ({
      swaps: s.swaps.map((sw) =>
        sw.id === id ? { ...sw, status: "rejected" as const } : sw
      ),
    })),
}))
