import { create } from "zustand"

interface WalletState {
  connected: boolean
  address: string | null
  balance: number
  connect: () => void
  disconnect: () => void
}

export const useWalletStore = create<WalletState>((set) => ({
  connected: false,
  address: null,
  balance: 0,
  connect: () =>
    set({
      connected: true,
      address: "PhantomW1...123",
      balance: 42.5,
    }),
  disconnect: () =>
    set({
      connected: false,
      address: null,
      balance: 0,
    }),
}))
