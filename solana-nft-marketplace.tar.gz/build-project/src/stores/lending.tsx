import { create } from "zustand"
import type { Loan } from "@/types"
import { mockLoans } from "@/data/mock"

interface LendingState {
  loans: Loan[]
  createLoan: (loan: Loan) => void
  repayLoan: (id: string) => void
  liquidateLoan: (id: string) => void
}

export const useLendingStore = create<LendingState>((set) => ({
  loans: mockLoans,
  createLoan: (loan) =>
    set((s) => ({ loans: [...s.loans, loan] })),
  repayLoan: (id) =>
    set((s) => ({
      loans: s.loans.map((l) =>
        l.id === id ? { ...l, status: "repaid" as const } : l
      ),
    })),
  liquidateLoan: (id) =>
    set((s) => ({
      loans: s.loans.map((l) =>
        l.id === id ? { ...l, status: "liquidated" as const } : l
      ),
    })),
}))
