import { create } from "zustand"
import type { FractionalToken } from "@/types"
import { mockFractionalTokens } from "@/data/mock"

interface FractionalState {
  tokens: FractionalToken[]
  fractionalize: (token: FractionalToken) => void
  buyShares: (id: string, amount: number, buyer: string) => void
}

export const useFractionalStore = create<FractionalState>((set) => ({
  tokens: mockFractionalTokens,
  fractionalize: (token) =>
    set((s) => ({ tokens: [...s.tokens, token] })),
  buyShares: (id, amount, buyer) =>
    set((s) => ({
      tokens: s.tokens.map((t) =>
        t.id === id
          ? {
              ...t,
              availableSupply: t.availableSupply - amount,
              holders: [...t.holders, { address: buyer, amount, percentage: (amount / t.totalSupply) * 100 }],
            }
          : t
      ),
    })),
}))
