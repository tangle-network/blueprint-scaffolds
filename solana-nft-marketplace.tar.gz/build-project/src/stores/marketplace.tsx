import { create } from "zustand"
import type { Listing, Offer } from "@/types"
import { mockListings, mockOffers } from "@/data/mock"

interface MarketplaceState {
  listings: Listing[]
  offers: Offer[]
  addListing: (listing: Listing) => void
  removeListing: (id: string) => void
  addOffer: (offer: Offer) => void
  cancelOffer: (id: string) => void
  buyNft: (listingId: string) => void
  batchBuy: (listingIds: string[]) => void
}

export const useMarketplaceStore = create<MarketplaceState>((set) => ({
  listings: mockListings,
  offers: mockOffers,
  addListing: (listing) =>
    set((s) => ({ listings: [...s.listings, listing] })),
  removeListing: (id) =>
    set((s) => ({ listings: s.listings.filter((l) => l.id !== id) })),
  addOffer: (offer) =>
    set((s) => ({ offers: [...s.offers, offer] })),
  cancelOffer: (id) =>
    set((s) => ({
      offers: s.offers.map((o) => (o.id === id ? { ...o, isActive: false } : o)),
    })),
  buyNft: (listingId) =>
    set((s) => ({
      listings: s.listings.map((l) =>
        l.id === listingId ? { ...l, isActive: false } : l
      ),
    })),
  batchBuy: (listingIds) =>
    set((s) => ({
      listings: s.listings.map((l) =>
        listingIds.includes(l.id) ? { ...l, isActive: false } : l
      ),
    })),
}))
