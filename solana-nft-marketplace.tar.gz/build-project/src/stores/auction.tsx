import { create } from "zustand"
import type { AuctionListing, Bid } from "@/types"
import { mockAuctions, mockBids } from "@/data/mock"

interface AuctionState {
  auctions: AuctionListing[]
  bids: Bid[]
  placeBid: (auctionId: string, bidder: string, amount: number) => void
  createAuction: (auction: AuctionListing) => void
  endAuction: (auctionId: string) => void
}

export const useAuctionStore = create<AuctionState>((set) => ({
  auctions: mockAuctions,
  bids: mockBids,
  placeBid: (auctionId, bidder, amount) =>
    set((s) => {
      const newBid: Bid = {
        id: `bid-${Date.now()}`,
        auctionId,
        bidder,
        amount,
        timestamp: new Date(),
      }
      return {
        bids: [...s.bids, newBid],
        auctions: s.auctions.map((a) =>
          a.id === auctionId
            ? { ...a, currentBid: amount, currentBidder: bidder, bidCount: a.bidCount + 1 }
            : a
        ),
      }
    }),
  createAuction: (auction) =>
    set((s) => ({ auctions: [...s.auctions, auction] })),
  endAuction: (auctionId) =>
    set((s) => ({
      auctions: s.auctions.map((a) =>
        a.id === auctionId ? { ...a, isActive: false } : a
      ),
    })),
}))
