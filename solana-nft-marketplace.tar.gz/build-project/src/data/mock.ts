import type { NFT, Collection, Listing, AuctionListing, Offer, Bid, Bundle, Loan, FractionalToken, SwapProposal, Activity } from "@/types"

const GENESIS = "GenesisArt1...xyz"
const SOLANA_MONKEY = "SMBCreator...abc"
const DEGEN = "DegenArt1...def"
const PHANTOM = "PhantomW1...123"
const BUYER1 = "Buyer111...aaa"
const BUYER2 = "Buyer222...bbb"
const LENDER1 = "Lender11...ccc"
const COLLECTOR = "Collec11...ddd"

export const mockNFTs: NFT[] = [
  {
    id: "nft-1", mint: "So1anaNFT1aaaaaaaaaaaaaaaaaaaaaaaaaaaa", name: "Cosmic Voyager #001", symbol: "COSMIC",
    uri: "https://arweave.net/abc1", image: "https://picsum.photos/seed/cosmic1/600/600",
    description: "A cosmic journey through the Solana blockchain universe.",
    attributes: [
      { trait_type: "Background", value: "Nebula" }, { trait_type: "Body", value: "Ethereal" },
      { trait_type: "Eyes", value: "Laser" }, { trait_type: "Rarity", value: "Legendary" },
      { trait_type: "Power", value: 95, display_type: "number" },
    ],
    collection: "cosmic-voyagers", owner: PHANTOM, creator: GENESIS, royaltyBps: 500,
    isCompressed: false, isVerified: true, rarityRank: 1, rarityScore: 9850,
  },
  {
    id: "nft-2", mint: "So1anaNFT2bbbbbbbbbbbbbbbbbbbbbbbbbbbb", name: "Cosmic Voyager #042", symbol: "COSMIC",
    uri: "https://arweave.net/abc2", image: "https://picsum.photos/seed/cosmic2/600/600",
    description: "The answer to life, the universe, and everything.",
    attributes: [
      { trait_type: "Background", value: "Stars" }, { trait_type: "Body", value: "Astral" },
      { trait_type: "Eyes", value: "Galaxy" }, { trait_type: "Rarity", value: "Epic" },
      { trait_type: "Power", value: 82, display_type: "number" },
    ],
    collection: "cosmic-voyagers", owner: GENESIS, creator: GENESIS, royaltyBps: 500,
    isCompressed: false, isVerified: true, rarityRank: 42, rarityScore: 7200,
  },
  {
    id: "nft-3", mint: "So1anaNFT3cccccccccccccccccccccccccccc", name: "Solana Monkey #1001", symbol: "SMB",
    uri: "https://arweave.net/abc3", image: "https://picsum.photos/seed/smb1/600/600",
    description: "A rare Solana Monkey Business NFT.",
    attributes: [
      { trait_type: "Fur", value: "Gold" }, { trait_type: "Head", value: "Crown" },
      { trait_type: "Eyes", value: "Diamond" }, { trait_type: "Clothes", value: "Tuxedo" },
    ],
    collection: "solana-monkey-business", owner: BUYER1, creator: SOLANA_MONKEY, royaltyBps: 350,
    isCompressed: false, isVerified: true, rarityRank: 5, rarityScore: 9400,
  },
  {
    id: "nft-4", mint: "So1anaNFT4dddddddddddddddddddddddddddd", name: "Degen Ape #5555", symbol: "DAP",
    uri: "https://arweave.net/abc4", image: "https://picsum.photos/seed/degen1/600/600",
    description: "A degen ape from the infamous collection.",
    attributes: [
      { trait_type: "Background", value: "Purple" }, { trait_type: "Fur", value: "Zombie" },
      { trait_type: "Eyes", value: "Red" }, { trait_type: "Mouth", value: "Bored" },
    ],
    collection: "degen-apes", owner: BUYER2, creator: DEGEN, royaltyBps: 400,
    isCompressed: false, isVerified: true, rarityRank: 120, rarityScore: 6800,
  },
  {
    id: "nft-5", mint: "So1anaNFT5eeeeeeeeeeeeeeeeeeeeeeeeeeee", name: "Compressed Pixel #001", symbol: "CPXL",
    uri: "https://arweave.net/abc5", image: "https://picsum.photos/seed/pixel1/600/600",
    description: "A stateless compressed NFT on Solana.",
    attributes: [
      { trait_type: "Color", value: "Neon" }, { trait_type: "Shape", value: "Circle" },
      { trait_type: "Pattern", value: "Grid" },
    ],
    collection: "compressed-pixels", owner: PHANTOM, creator: GENESIS, royaltyBps: 300,
    isCompressed: true, isVerified: true, rarityRank: 10, rarityScore: 8900,
  },
  {
    id: "nft-6", mint: "So1anaNFT6ffffffffffffffffffffffffffff", name: "Cosmic Voyager #100", symbol: "COSMIC",
    uri: "https://arweave.net/abc6", image: "https://picsum.photos/seed/cosmic3/600/600",
    description: "A century mark cosmic voyager.",
    attributes: [
      { trait_type: "Background", value: "Void" }, { trait_type: "Body", value: "Crystal" },
      { trait_type: "Eyes", value: "Prismatic" }, { trait_type: "Rarity", value: "Rare" },
    ],
    collection: "cosmic-voyagers", owner: COLLECTOR, creator: GENESIS, royaltyBps: 500,
    isCompressed: false, isVerified: true, rarityRank: 100, rarityScore: 5400,
  },
  {
    id: "nft-7", mint: "So1anaNFT7gggggggggggggggggggggggggggg", name: "Solana Monkey #2048", symbol: "SMB",
    uri: "https://arweave.net/abc7", image: "https://picsum.photos/seed/smb2/600/600",
    description: "A classic Solana Monkey.",
    attributes: [
      { trait_type: "Fur", value: "Brown" }, { trait_type: "Head", value: "Cap" },
      { trait_type: "Eyes", value: "Normal" }, { trait_type: "Clothes", value: "Hoodie" },
    ],
    collection: "solana-monkey-business", owner: BUYER1, creator: SOLANA_MONKEY, royaltyBps: 350,
    isCompressed: false, isVerified: true, rarityRank: 800, rarityScore: 3200,
  },
  {
    id: "nft-8", mint: "So1anaNFT8hhhhhhhhhhhhhhhhhhhhhhhhhhhh", name: "Degen Ape #9999", symbol: "DAP",
    uri: "https://arweave.net/abc8", image: "https://picsum.photos/seed/degen2/600/600",
    description: "The final degen ape.",
    attributes: [
      { trait_type: "Background", value: "Blue" }, { trait_type: "Fur", value: "Robot" },
      { trait_type: "Eyes", value: "Cyber" }, { trait_type: "Mouth", value: "Grillz" },
    ],
    collection: "degen-apes", owner: BUYER2, creator: DEGEN, royaltyBps: 400,
    isCompressed: false, isVerified: true, rarityRank: 50, rarityScore: 7800,
  },
  {
    id: "nft-9", mint: "So1anaNFT9iiiiiiiiiiiiiiiiiiiiiiiiiiii", name: "Compressed Pixel #500", symbol: "CPXL",
    uri: "https://arweave.net/abc9", image: "https://picsum.photos/seed/pixel2/600/600",
    description: "A mid-rarity compressed pixel.",
    attributes: [
      { trait_type: "Color", value: "Blue" }, { trait_type: "Shape", value: "Square" },
      { trait_type: "Pattern", value: "Wave" },
    ],
    collection: "compressed-pixels", owner: PHANTOM, creator: GENESIS, royaltyBps: 300,
    isCompressed: true, isVerified: true, rarityRank: 500, rarityScore: 4100,
  },
  {
    id: "nft-10", mint: "So1anaNFT10jjjjjjjjjjjjjjjjjjjjjjjjjj", name: "Cosmic Voyager #007", symbol: "COSMIC",
    uri: "https://arweave.net/abc10", image: "https://picsum.photos/seed/cosmic4/600/600",
    description: "Agent 007 of the cosmic voyagers.",
    attributes: [
      { trait_type: "Background", value: "Midnight" }, { trait_type: "Body", value: "Shadow" },
      { trait_type: "Eyes", value: "Infrared" }, { trait_type: "Rarity", value: "Legendary" },
    ],
    collection: "cosmic-voyagers", owner: GENESIS, creator: GENESIS, royaltyBps: 500,
    isCompressed: false, isVerified: true, rarityRank: 7, rarityScore: 9200,
  },
  {
    id: "nft-11", mint: "So1anaNFT11kkkkkkkkkkkkkkkkkkkkkkkkkk", name: "Abstract Wave #012", symbol: "AWAV",
    uri: "https://arweave.net/abc11", image: "https://picsum.photos/seed/abstract1/600/600",
    description: "Generative abstract art on Solana.",
    attributes: [
      { trait_type: "Style", value: "Wave" }, { trait_type: "Palette", value: "Sunset" },
      { trait_type: "Layers", value: 5, display_type: "number" },
    ],
    collection: "abstract-waves", owner: COLLECTOR, creator: DEGEN, royaltyBps: 600,
    isCompressed: false, isVerified: false, rarityRank: 12, rarityScore: 7600,
  },
  {
    id: "nft-12", mint: "So1anaNFT12llllllllllllllllllllllllll", name: "Compressed Pixel #250", symbol: "CPXL",
    uri: "https://arweave.net/abc12", image: "https://picsum.photos/seed/pixel3/600/600",
    description: "A rare compressed pixel with holographic effect.",
    attributes: [
      { trait_type: "Color", value: "Holographic" }, { trait_type: "Shape", value: "Triangle" },
      { trait_type: "Pattern", value: "Prism" },
    ],
    collection: "compressed-pixels", owner: LENDER1, creator: GENESIS, royaltyBps: 300,
    isCompressed: true, isVerified: true, rarityRank: 250, rarityScore: 5200,
  },
]

export const mockCollections: Collection[] = [
  {
    id: "cosmic-voyagers", name: "Cosmic Voyagers", symbol: "COSMIC",
    description: "Journey through the cosmos with 10,000 unique voyagers.",
    image: "https://picsum.photos/seed/cosmiccol/400/400",
    banner: "https://picsum.photos/seed/cosmicbanner/1200/400",
    creator: GENESIS, verified: true, floorPrice: 2.5, totalVolume: 15000,
    totalListed: 120, totalSupply: 10000, uniqueHolders: 6200, royaltyBps: 500,
  },
  {
    id: "solana-monkey-business", name: "Solana Monkey Business", symbol: "SMB",
    description: "The original Solana monkey collection.",
    image: "https://picsum.photos/seed/smbcol/400/400",
    banner: "https://picsum.photos/seed/smbbanner/1200/400",
    creator: SOLANA_MONKEY, verified: true, floorPrice: 15.0, totalVolume: 85000,
    totalListed: 45, totalSupply: 5000, uniqueHolders: 3100, royaltyBps: 350,
  },
  {
    id: "degen-apes", name: "Degen Apes", symbol: "DAP",
    description: "The degenerate ape academy on Solana.",
    image: "https://picsum.photos/seed/degentcol/400/400",
    banner: "https://picsum.photos/seed/degenbanner/1200/400",
    creator: DEGEN, verified: true, floorPrice: 5.0, totalVolume: 42000,
    totalListed: 200, totalSupply: 10000, uniqueHolders: 5500, royaltyBps: 400,
  },
  {
    id: "compressed-pixels", name: "Compressed Pixels", symbol: "CPXL",
    description: "Stateless compressed NFTs pushing Solana boundaries.",
    image: "https://picsum.photos/seed/pixelcol/400/400",
    banner: "https://picsum.photos/seed/pixelbanner/1200/400",
    creator: GENESIS, verified: true, floorPrice: 0.5, totalVolume: 1200,
    totalListed: 300, totalSupply: 100000, uniqueHolders: 25000, royaltyBps: 300,
  },
  {
    id: "abstract-waves", name: "Abstract Waves", symbol: "AWAV",
    description: "Generative abstract art powered by algorithms.",
    image: "https://picsum.photos/seed/abstractcol/400/400",
    banner: "https://picsum.photos/seed/abstractbanner/1200/400",
    creator: DEGEN, verified: false, floorPrice: 1.2, totalVolume: 800,
    totalListed: 50, totalSupply: 2000, uniqueHolders: 1200, royaltyBps: 600,
  },
]

const now = new Date()
const day = 86400000
const hour = 3600000

export const mockListings: Listing[] = [
  {
    id: "list-1", nftId: "nft-2", nft: mockNFTs[1], seller: GENESIS,
    price: 3.5 * 1e9, type: "fixed", createdAt: new Date(now.getTime() - 2 * day), isActive: true,
  },
  {
    id: "list-2", nftId: "nft-4", nft: mockNFTs[3], seller: BUYER2,
    price: 6.0 * 1e9, type: "fixed", createdAt: new Date(now.getTime() - day), isActive: true,
  },
  {
    id: "list-3", nftId: "nft-9", nft: mockNFTs[8], seller: PHANTOM,
    price: 0.8 * 1e9, type: "fixed", createdAt: new Date(now.getTime() - 3 * day), isActive: true,
  },
  {
    id: "list-4", nftId: "nft-10", nft: mockNFTs[9], seller: GENESIS,
    price: 4.2 * 1e9, type: "fixed", createdAt: new Date(now.getTime() - 4 * hour), isActive: true,
  },
  {
    id: "list-5", nftId: "nft-11", nft: mockNFTs[10], seller: COLLECTOR,
    price: 1.8 * 1e9, type: "fixed", createdAt: new Date(now.getTime() - 6 * hour), isActive: true,
  },
]

export const mockAuctions: AuctionListing[] = [
  {
    id: "auction-1", nftId: "nft-1", nft: mockNFTs[0], seller: PHANTOM,
    price: 12.0 * 1e9, type: "auction", createdAt: new Date(now.getTime() - day),
    isActive: true, minBid: 5.0 * 1e9, currentBid: 12.0 * 1e9, currentBidder: BUYER1,
    bidCount: 8, endTime: new Date(now.getTime() + 2 * day),
  },
  {
    id: "auction-2", nftId: "nft-3", nft: mockNFTs[2], seller: BUYER1,
    price: 25.0 * 1e9, type: "auction", createdAt: new Date(now.getTime() - 2 * day),
    isActive: true, minBid: 15.0 * 1e9, currentBid: 25.0 * 1e9, currentBidder: BUYER2,
    bidCount: 15, endTime: new Date(now.getTime() + day),
  },
  {
    id: "auction-3", nftId: "nft-8", nft: mockNFTs[7], seller: BUYER2,
    price: 8.0 * 1e9, type: "auction", createdAt: new Date(now.getTime() - 3 * day),
    isActive: true, minBid: 4.0 * 1e9, currentBid: 8.0 * 1e9, currentBidder: PHANTOM,
    bidCount: 5, reservePrice: 10.0 * 1e9, endTime: new Date(now.getTime() + 3 * day),
  },
]

export const mockOffers: Offer[] = [
  {
    id: "offer-1", nftId: "nft-1", nft: mockNFTs[0], buyer: BUYER2,
    price: 10.0 * 1e9, expiresAt: new Date(now.getTime() + 3 * day),
    createdAt: new Date(now.getTime() - 5 * hour), isActive: true,
  },
  {
    id: "offer-2", nftId: "nft-2", nft: mockNFTs[1], buyer: BUYER1,
    price: 3.0 * 1e9, expiresAt: new Date(now.getTime() + day),
    createdAt: new Date(now.getTime() - 12 * hour), isActive: true,
  },
  {
    id: "offer-3", nftId: "nft-3", nft: mockNFTs[2], buyer: COLLECTOR,
    price: 18.0 * 1e9, expiresAt: new Date(now.getTime() + 5 * day),
    createdAt: new Date(now.getTime() - day), isActive: true,
  },
  {
    id: "offer-4", nftId: "nft-6", nft: mockNFTs[5], buyer: BUYER1,
    price: 2.0 * 1e9, expiresAt: new Date(now.getTime() + 2 * day),
    createdAt: new Date(now.getTime() - 8 * hour), isActive: true,
  },
]

export const mockBids: Bid[] = [
  { id: "bid-1", auctionId: "auction-1", bidder: BUYER1, amount: 12.0 * 1e9, timestamp: new Date(now.getTime() - hour) },
  { id: "bid-2", auctionId: "auction-1", bidder: BUYER2, amount: 10.0 * 1e9, timestamp: new Date(now.getTime() - 3 * hour) },
  { id: "bid-3", auctionId: "auction-1", bidder: COLLECTOR, amount: 8.0 * 1e9, timestamp: new Date(now.getTime() - 6 * hour) },
  { id: "bid-4", auctionId: "auction-2", bidder: BUYER2, amount: 25.0 * 1e9, timestamp: new Date(now.getTime() - 2 * hour) },
  { id: "bid-5", auctionId: "auction-2", bidder: PHANTOM, amount: 22.0 * 1e9, timestamp: new Date(now.getTime() - 5 * hour) },
]

export const mockBundles: Bundle[] = [
  {
    id: "bundle-1", name: "Cosmic Trio", description: "Three cosmic voyagers at a discount",
    nfts: [mockNFTs[1], mockNFTs[5], mockNFTs[9]], seller: GENESIS,
    price: 8.0 * 1e9, createdAt: new Date(now.getTime() - day), isActive: true,
  },
  {
    id: "bundle-2", name: "Degen + SMB Pack", description: "One degen ape and one solana monkey",
    nfts: [mockNFTs[2], mockNFTs[3]], seller: BUYER1,
    price: 18.0 * 1e9, createdAt: new Date(now.getTime() - 2 * day), isActive: true,
  },
]

export const mockLoans: Loan[] = [
  {
    id: "loan-1", nftId: "nft-3", nft: mockNFTs[2], lender: LENDER1, borrower: BUYER1,
    principal: 10.0 * 1e9, interestRate: 5.0, duration: 30,
    startTime: new Date(now.getTime() - 10 * day), endTime: new Date(now.getTime() + 20 * day),
    status: "active",
  },
  {
    id: "loan-2", nftId: "nft-8", nft: mockNFTs[7], lender: LENDER1, borrower: BUYER2,
    principal: 5.0 * 1e9, interestRate: 8.0, duration: 14,
    startTime: new Date(now.getTime() - 5 * day), endTime: new Date(now.getTime() + 9 * day),
    status: "active",
  },
  {
    id: "loan-3", nftId: "nft-4", nft: mockNFTs[3], lender: PHANTOM, borrower: BUYER2,
    principal: 3.0 * 1e9, interestRate: 6.0, duration: 7,
    startTime: new Date(now.getTime() - 14 * day), endTime: new Date(now.getTime() - 7 * day),
    status: "repaid",
  },
]

export const mockFractionalTokens: FractionalToken[] = [
  {
    id: "frac-1", nftId: "nft-1", nft: mockNFTs[0], totalSupply: 10000,
    availableSupply: 3500, pricePerToken: 0.005 * 1e9, creator: PHANTOM,
    holders: [
      { address: PHANTOM, amount: 3500, percentage: 35 },
      { address: BUYER1, amount: 2500, percentage: 25 },
      { address: BUYER2, amount: 2000, percentage: 20 },
      { address: COLLECTOR, amount: 1000, percentage: 10 },
      { address: LENDER1, amount: 1000, percentage: 10 },
    ],
  },
  {
    id: "frac-2", nftId: "nft-3", nft: mockNFTs[2], totalSupply: 5000,
    availableSupply: 1000, pricePerToken: 0.01 * 1e9, creator: BUYER1,
    holders: [
      { address: BUYER1, amount: 1000, percentage: 20 },
      { address: COLLECTOR, amount: 2000, percentage: 40 },
      { address: LENDER1, amount: 1000, percentage: 20 },
      { address: PHANTOM, amount: 1000, percentage: 20 },
    ],
  },
]

export const mockSwaps: SwapProposal[] = [
  {
    id: "swap-1", proposer: BUYER1,
    offeredNfts: [mockNFTs[2]], requestedNfts: [mockNFTs[7]], targetOwner: BUYER2,
    status: "pending", createdAt: new Date(now.getTime() - 3 * hour),
    expiresAt: new Date(now.getTime() + 5 * day),
  },
  {
    id: "swap-2", proposer: COLLECTOR,
    offeredNfts: [mockNFTs[5], mockNFTs[10]], requestedNfts: [mockNFTs[0]], targetOwner: PHANTOM,
    status: "pending", createdAt: new Date(now.getTime() - day),
    expiresAt: new Date(now.getTime() + 3 * day),
  },
]

export const mockActivities: Activity[] = [
  { id: "act-1", type: "sale", nftId: "nft-3", nft: mockNFTs[2], collection: "solana-monkey-business", from: SOLANA_MONKEY, to: BUYER1, price: 14.5 * 1e9, timestamp: new Date(now.getTime() - hour), txHash: "5UkL1...abc1" },
  { id: "act-2", type: "bid", nftId: "nft-1", nft: mockNFTs[0], collection: "cosmic-voyagers", from: BUYER1, price: 12.0 * 1e9, timestamp: new Date(now.getTime() - 2 * hour), txHash: "3jKp9...def2" },
  { id: "act-3", type: "listing", nftId: "nft-2", nft: mockNFTs[1], collection: "cosmic-voyagers", from: GENESIS, price: 3.5 * 1e9, timestamp: new Date(now.getTime() - 3 * hour), txHash: "7mNx2...ghi3" },
  { id: "act-4", type: "offer", nftId: "nft-1", nft: mockNFTs[0], collection: "cosmic-voyagers", from: BUYER2, price: 10.0 * 1e9, timestamp: new Date(now.getTime() - 5 * hour), txHash: "2pQr8...jkl4" },
  { id: "act-5", type: "mint", nftId: "nft-5", nft: mockNFTs[4], collection: "compressed-pixels", to: PHANTOM, timestamp: new Date(now.getTime() - 6 * hour), txHash: "9wSt4...mno5" },
  { id: "act-6", type: "sale", nftId: "nft-4", nft: mockNFTs[3], collection: "degen-apes", from: DEGEN, to: BUYER2, price: 5.8 * 1e9, timestamp: new Date(now.getTime() - 8 * hour), txHash: "1aBc3...pqr6" },
  { id: "act-7", type: "transfer", nftId: "nft-6", nft: mockNFTs[5], collection: "cosmic-voyagers", from: GENESIS, to: COLLECTOR, timestamp: new Date(now.getTime() - 12 * hour), txHash: "6dEf5...stu7" },
  { id: "act-8", type: "loan", nftId: "nft-3", nft: mockNFTs[2], collection: "solana-monkey-business", from: BUYER1, to: LENDER1, price: 10.0 * 1e9, timestamp: new Date(now.getTime() - day), txHash: "4gHi7...vwx8" },
  { id: "act-9", type: "fractional", nftId: "nft-1", nft: mockNFTs[0], collection: "cosmic-voyagers", from: PHANTOM, timestamp: new Date(now.getTime() - 2 * day), txHash: "8jKl9...yza9" },
  { id: "act-10", type: "bundle", nftId: "nft-2", nft: mockNFTs[1], collection: "cosmic-voyagers", from: GENESIS, price: 8.0 * 1e9, timestamp: new Date(now.getTime() - day), txHash: "0mNo1...bcd0" },
  { id: "act-11", type: "swap", nftId: "nft-2", nft: mockNFTs[1], collection: "cosmic-voyagers", from: BUYER1, timestamp: new Date(now.getTime() - 3 * hour), txHash: "5pQr3...efg1" },
  { id: "act-12", type: "bid", nftId: "nft-3", nft: mockNFTs[2], collection: "solana-monkey-business", from: BUYER2, price: 25.0 * 1e9, timestamp: new Date(now.getTime() - 2 * hour), txHash: "7sTu5...hij2" },
]
