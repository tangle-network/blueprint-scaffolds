import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { ActivityItem } from "@/components/shared/ActivityItem"
import { mockActivities } from "@/data/mock"
import { Search, Activity, Filter, ArrowUpRight, Gavel, Tag, Handshake, Send, Flame, Landmark, PieChart, ArrowLeftRight, Package } from "lucide-react"
import type { ActivityType } from "@/types"

const activityTypes: { type: ActivityType; label: string; icon: React.ElementType; color: string }[] = [
  { type: "sale", label: "Sales", icon: ArrowUpRight, color: "text-green-500" },
  { type: "listing", label: "Listings", icon: Tag, color: "text-blue-500" },
  { type: "bid", label: "Bids", icon: Gavel, color: "text-yellow-500" },
  { type: "offer", label: "Offers", icon: Handshake, color: "text-purple-500" },
  { type: "transfer", label: "Transfers", icon: Send, color: "text-gray-500" },
  { type: "mint", label: "Mints", icon: Flame, color: "text-primary" },
  { type: "loan", label: "Loans", icon: Landmark, color: "text-orange-500" },
  { type: "fractional", label: "Fractional", icon: PieChart, color: "text-pink-500" },
  { type: "swap", label: "Swaps", icon: ArrowLeftRight, color: "text-cyan-500" },
  { type: "bundle", label: "Bundles", icon: Package, color: "text-indigo-500" },
]

export default function ActivityFeed() {
  const [search, setSearch] = useState("")
  const [selectedTypes, setSelectedTypes] = useState<Set<ActivityType>>(new Set())
  const [page, setPage] = useState(0)
  const pageSize = 10

  const toggleType = (type: ActivityType) => {
    setSelectedTypes((prev) => {
      const next = new Set(prev)
      if (next.has(type)) next.delete(type)
      else next.add(type)
      return next
    })
    setPage(0)
  }

  const filtered = useMemo(() => {
    let items = [...mockActivities].sort(
      (a, b) => b.timestamp.getTime() - a.timestamp.getTime()
    )
    if (selectedTypes.size > 0) {
      items = items.filter((a) => selectedTypes.has(a.type))
    }
    if (search) {
      const q = search.toLowerCase()
      items = items.filter(
        (a) =>
          a.nft?.name.toLowerCase().includes(q) ||
          a.collection?.toLowerCase().includes(q) ||
          a.txHash.toLowerCase().includes(q)
      )
    }
    return items
  }, [search, selectedTypes])

  const paginated = filtered.slice(page * pageSize, (page + 1) * pageSize)
  const totalPages = Math.ceil(filtered.length / pageSize)

  const stats = useMemo(() => {
    const counts: Record<string, number> = {}
    for (const a of mockActivities) {
      counts[a.type] = (counts[a.type] || 0) + 1
    }
    return counts
  }, [])

  const totalVolume = useMemo(() => {
    return mockActivities
      .filter((a) => a.price !== undefined)
      .reduce((sum, a) => sum + (a.price || 0), 0)
  }, [])

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Activity className="h-6 w-6 text-primary" /> Activity Feed
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            {filtered.length} event{filtered.length !== 1 ? "s" : ""} found
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <p className="text-xs text-muted-foreground mb-1">Total Events</p>
            <p className="text-2xl font-bold">{mockActivities.length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-xs text-muted-foreground mb-1">Total Volume</p>
            <p className="text-2xl font-bold">
              {(totalVolume / 1e9).toFixed(1)} SOL
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-xs text-muted-foreground mb-1">Sales</p>
            <p className="text-2xl font-bold">{stats["sale"] || 0}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-xs text-muted-foreground mb-1">Active Bids</p>
            <p className="text-2xl font-bold">{stats["bid"] || 0}</p>
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by NFT, collection, or tx hash..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value)
              setPage(0)
            }}
            className="pl-9"
          />
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {activityTypes.map(({ type, label, icon: Icon, color }) => {
          const active = selectedTypes.has(type)
          return (
            <Button
              key={type}
              variant={active ? "secondary" : "outline"}
              size="sm"
              className="gap-1.5"
              onClick={() => toggleType(type)}
            >
              <Icon className={`h-3.5 w-3.5 ${color}`} />
              {label}
              <Badge variant="secondary" className="ml-1 text-[10px] px-1.5">
                {stats[type] || 0}
              </Badge>
            </Button>
          )
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Filter className="h-4 w-4" /> Event Log
          </CardTitle>
        </CardHeader>
        <CardContent>
          {paginated.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              No events match your filters.
            </div>
          ) : (
            <div className="divide-y">
              {paginated.map((activity) => (
                <ActivityItem key={activity.id} activity={activity} />
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <Button
            variant="outline"
            size="sm"
            disabled={page === 0}
            onClick={() => setPage((p) => p - 1)}
          >
            Previous
          </Button>
          <span className="text-sm text-muted-foreground">
            Page {page + 1} of {totalPages}
          </span>
          <Button
            variant="outline"
            size="sm"
            disabled={page >= totalPages - 1}
            onClick={() => setPage((p) => p + 1)}
          >
            Next
          </Button>
        </div>
      )}
    </div>
  )
}
