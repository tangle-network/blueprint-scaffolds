import { useParams, useNavigate } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { RarityBadge } from "@/components/shared/RarityBadge"
import { ActivityItem } from "@/components/shared/ActivityItem"
import { useMarketplaceStore } from "@/stores/marketplace"
import { useWalletStore } from "@/stores/wallet"
import { mockNFTs, mockActivities, mockOffers } from "@/data/mock"
import { formatSOL, shortenAddress, timeAgo } from "@/lib/utils"
import { useState } from "react"
import {
  ShoppingCart,
  Tag,
  Gavel,
  Heart,
  Share2,
  ExternalLink,
  CheckCircle,
  Layers,
  ArrowLeft,
} from "lucide-react"

export default function NFTDetail() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const { connected } = useWalletStore()
  const { addOffer, listings } = useMarketplaceStore()
  const [offerAmount, setOfferAmount] = useState("")
  const [tab, setTab] = useState<"details" | "offers" | "activity">("details")

  const nft = mockNFTs.find((n) => n.id === id)
  if (!nft) {
    return (
      <div className="text-center py-20">
        <p className="text-muted-foreground">NFT not found</p>
        <Button variant="outline" onClick={() => navigate("/")} className="mt-4">
          Back to Gallery
        </Button>
      </div>
    )
  }

  const listing = listings.find((l) => l.nftId === nft.id && l.isActive)
  const nftOffers = mockOffers.filter((o) => o.nftId === nft.id && o.isActive)
  const nftActivities = mockActivities.filter((a) => a.nftId === nft.id)

  const handleMakeOffer = () => {
    if (!offerAmount || !connected) return
    addOffer({
      id: `offer-${Date.now()}`,
      nftId: nft.id,
      nft,
      buyer: "PhantomW1...123",
      price: parseFloat(offerAmount) * 1e9,
      expiresAt: new Date(Date.now() + 7 * 86400000),
      createdAt: new Date(),
      isActive: true,
    })
    setOfferAmount("")
  }

  const royaltyAmount = listing
    ? (listing.price * nft.royaltyBps) / 10000
    : 0

  return (
    <div className="space-y-6">
      <Button variant="ghost" size="sm" onClick={() => navigate(-1)} className="gap-1">
        <ArrowLeft className="h-4 w-4" /> Back
      </Button>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="space-y-4">
          <div className="rounded-xl overflow-hidden bg-muted aspect-square">
            <img src={nft.image} alt={nft.name} className="w-full h-full object-cover" />
          </div>
          <div className="flex items-center gap-2">
            {nft.isCompressed && (
              <Badge variant="outline" className="gap-1">
                <Layers className="h-3 w-3" /> Compressed
              </Badge>
            )}
            {nft.isVerified && (
              <Badge variant="outline" className="gap-1 text-blue-500">
                <CheckCircle className="h-3 w-3" /> Verified
              </Badge>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <p className="text-sm text-muted-foreground">{nft.collection}</p>
            <h1 className="text-3xl font-bold mt-1">{nft.name}</h1>
            <div className="mt-2">
              <RarityBadge rank={nft.rarityRank} score={nft.rarityScore} />
            </div>
          </div>

          <Separator />

          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Owner</span>
              <span className="font-mono">{shortenAddress(nft.owner)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Creator</span>
              <span className="font-mono">{shortenAddress(nft.creator)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Royalty</span>
              <span>{nft.royaltyBps / 100}%</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Mint</span>
              <span className="font-mono text-xs">{shortenAddress(nft.mint)}</span>
            </div>
          </div>

          {listing && (
            <Card>
              <CardContent className="pt-6 space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground">Current Price</p>
                  <p className="text-3xl font-bold text-primary">
                    {formatSOL(listing.price)}
                  </p>
                </div>
                {connected && (
                  <Button className="w-full gap-2" size="lg">
                    <ShoppingCart className="h-5 w-5" />
                    Buy Now
                  </Button>
                )}
                <div className="text-xs text-muted-foreground text-center">
                  Royalty: {formatSOL(royaltyAmount)} ({nft.royaltyBps / 100}%)
                </div>
              </CardContent>
            </Card>
          )}

          {!listing && (
            <Card>
              <CardContent className="pt-6 space-y-4">
                <p className="text-muted-foreground text-sm text-center">Not listed for sale</p>
                {connected && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="offer">Make an Offer (SOL)</Label>
                      <div className="flex gap-2">
                        <Input
                          id="offer"
                          type="number"
                          step="0.1"
                          placeholder="0.00"
                          value={offerAmount}
                          onChange={(e) => setOfferAmount(e.target.value)}
                        />
                        <Button onClick={handleMakeOffer} className="shrink-0 gap-1">
                          <Tag className="h-4 w-4" /> Offer
                        </Button>
                      </div>
                    </div>
                    <Button variant="outline" className="w-full gap-2">
                      <Gavel className="h-4 w-4" /> List for Sale
                    </Button>
                  </>
                )}
              </CardContent>
            </Card>
          )}

          <div className="flex gap-2">
            <Button variant="outline" size="icon">
              <Heart className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon">
              <Share2 className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon">
              <ExternalLink className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <div className="flex gap-2 border-b pb-0">
        {(["details", "offers", "activity"] as const).map((t) => (
          <Button
            key={t}
            variant={tab === t ? "secondary" : "ghost"}
            size="sm"
            onClick={() => setTab(t)}
            className="rounded-b-none"
          >
            {t.charAt(0).toUpperCase() + t.slice(1)}
            {t === "offers" && nftOffers.length > 0 && (
              <Badge variant="secondary" className="ml-1.5 text-[10px]">
                {nftOffers.length}
              </Badge>
            )}
          </Button>
        ))}
      </div>

      {tab === "details" && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Attributes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {nft.attributes.map((attr, i) => (
                <div
                  key={i}
                  className="rounded-lg bg-muted/50 p-3 text-center space-y-1"
                >
                  <p className="text-xs text-muted-foreground">{attr.trait_type}</p>
                  <p className="text-sm font-medium">{attr.value}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {tab === "offers" && (
        <Card>
          <CardContent className="pt-6">
            {nftOffers.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">No offers yet</p>
            ) : (
              <div className="space-y-3">
                {nftOffers.map((offer) => (
                  <div key={offer.id} className="flex items-center justify-between py-2 border-b last:border-0">
                    <div>
                      <p className="font-mono text-sm">{shortenAddress(offer.buyer)}</p>
                      <p className="text-xs text-muted-foreground">{timeAgo(offer.createdAt)}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-primary">{formatSOL(offer.price)}</p>
                      {connected && (
                        <Button size="sm" variant="outline" className="mt-1">
                          Accept
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {tab === "activity" && (
        <Card>
          <CardContent className="pt-6">
            {nftActivities.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">No activity yet</p>
            ) : (
              <div className="divide-y">
                {nftActivities.map((act) => (
                  <ActivityItem key={act.id} activity={act} />
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Description</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">{nft.description}</p>
        </CardContent>
      </Card>
    </div>
  )
}
