import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { useWalletStore } from "@/stores/wallet"
import { useMarketplaceStore } from "@/stores/marketplace"
import { mockNFTs, mockCollections } from "@/data/mock"
import { formatSOL, shortenAddress } from "@/lib/utils"
import {
  LayoutDashboard,
  TrendingUp,
  Package,
  DollarSign,
  ShoppingCart,
  Eye,
  Plus,
  Tag,
  CheckCircle,
} from "lucide-react"

export default function Dashboard() {
  const { connected, address } = useWalletStore()
  const { listings, offers } = useMarketplaceStore()
  const [tab, setTab] = useState<"overview" | "my-nfts" | "listings" | "offers">("overview")

  const myNfts = useMemo(() => {
    if (!connected) return []
    return mockNFTs.filter((n) => n.owner === address || n.owner.startsWith("Phantom"))
  }, [connected, address])

  const myListings = useMemo(() => {
    return listings.filter((l) => l.isActive && (l.seller === address || l.seller.startsWith("Phantom")))
  }, [listings, address])

  const myOffers = useMemo(() => {
    return offers.filter((o) => o.isActive)
  }, [offers])

  const stats = useMemo(() => {
    const totalValue = myListings.reduce((sum, l) => sum + l.price, 0)
    return {
      totalNfts: myNfts.length,
      totalListings: myListings.length,
      totalValue,
      totalOffers: myOffers.length,
    }
  }, [myNfts, myListings, myOffers])

  const [newPrice, setNewPrice] = useState("")

  if (!connected) {
    return (
      <div className="text-center py-20">
        <LayoutDashboard className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
        <h2 className="text-xl font-semibold mb-2">Creator Dashboard</h2>
        <p className="text-muted-foreground mb-4">Connect your wallet to view your dashboard</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <LayoutDashboard className="h-6 w-6 text-primary" /> Creator Dashboard
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          Manage your NFTs, listings, and offers
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <Package className="h-4 w-4" />
              <span className="text-xs">My NFTs</span>
            </div>
            <p className="text-2xl font-bold">{stats.totalNfts}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <Tag className="h-4 w-4" />
              <span className="text-xs">Active Listings</span>
            </div>
            <p className="text-2xl font-bold">{stats.totalListings}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <DollarSign className="h-4 w-4" />
              <span className="text-xs">Portfolio Value</span>
            </div>
            <p className="text-2xl font-bold">{formatSOL(stats.totalValue)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <ShoppingCart className="h-4 w-4" />
              <span className="text-xs">Incoming Offers</span>
            </div>
            <p className="text-2xl font-bold">{stats.totalOffers}</p>
          </CardContent>
        </Card>
      </div>

      <div className="flex gap-2 border-b pb-0">
        {(["overview", "my-nfts", "listings", "offers"] as const).map((t) => (
          <Button
            key={t}
            variant={tab === t ? "secondary" : "ghost"}
            size="sm"
            onClick={() => setTab(t)}
            className="rounded-b-none"
          >
            {t === "my-nfts" ? "My NFTs" : t.charAt(0).toUpperCase() + t.slice(1)}
          </Button>
        ))}
      </div>

      {tab === "overview" && (
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="h-4 w-4" /> Recent Performance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {mockCollections.slice(0, 3).map((col) => (
                  <div key={col.id} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <img
                        src={col.image}
                        alt={col.name}
                        className="w-8 h-8 rounded-full"
                      />
                      <div>
                        <p className="text-sm font-medium">{col.name}</p>
                        <p className="text-xs text-muted-foreground">
                          Floor: {col.floorPrice} SOL
                        </p>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {col.totalListed} listed
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button variant="outline" className="w-full justify-start gap-2">
                <Plus className="h-4 w-4" /> List NFT for Sale
              </Button>
              <Button variant="outline" className="w-full justify-start gap-2">
                <Eye className="h-4 w-4" /> View My Collection
              </Button>
              <Button variant="outline" className="w-full justify-start gap-2">
                <CheckCircle className="h-4 w-4" /> Verify Collection
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {tab === "my-nfts" && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {myNfts.map((nft) => (
            <Card key={nft.id} className="overflow-hidden group cursor-pointer hover:border-primary/50 transition-colors">
              <div className="aspect-square overflow-hidden bg-muted">
                <img src={nft.image} alt={nft.name} className="w-full h-full object-cover" />
              </div>
              <CardContent className="p-3">
                <p className="text-sm font-medium truncate">{nft.name}</p>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-xs text-muted-foreground">{nft.collection}</span>
                  <Button size="sm" variant="outline" className="h-6 text-xs px-2">
                    <Tag className="h-3 w-3 mr-1" /> List
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
          {myNfts.length === 0 && (
            <div className="col-span-full text-center py-12 text-muted-foreground">
              No NFTs found in your wallet
            </div>
          )}
        </div>
      )}

      {tab === "listings" && (
        <div className="space-y-3">
          {myListings.map((listing) => (
            <Card key={listing.id}>
              <CardContent className="py-4 flex items-center gap-4">
                <img
                  src={listing.nft.image}
                  alt={listing.nft.name}
                  className="w-14 h-14 rounded-lg object-cover"
                />
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{listing.nft.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {listing.type === "fixed" ? "Fixed Price" : "Auction"} &bull;{" "}
                    Listed {new Date(listing.createdAt).toLocaleDateString()}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-primary">{formatSOL(listing.price)}</p>
                  <Button size="sm" variant="ghost" className="text-destructive text-xs h-6">
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
          {myListings.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              No active listings
            </div>
          )}
        </div>
      )}

      {tab === "offers" && (
        <div className="space-y-3">
          {myOffers.map((offer) => (
            <Card key={offer.id}>
              <CardContent className="py-4 flex items-center gap-4">
                <img
                  src={offer.nft.image}
                  alt={offer.nft.name}
                  className="w-14 h-14 rounded-lg object-cover"
                />
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{offer.nft.name}</p>
                  <p className="text-xs text-muted-foreground">
                    from {shortenAddress(offer.buyer)} &bull;{" "}
                    expires {new Date(offer.expiresAt).toLocaleDateString()}
                  </p>
                </div>
                <div className="text-right flex items-center gap-2">
                  <p className="font-semibold text-primary">{formatSOL(offer.price)}</p>
                  <Button size="sm" variant="default" className="h-7 text-xs">
                    Accept
                  </Button>
                  <Button size="sm" variant="ghost" className="h-7 text-xs text-destructive">
                    Decline
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
          {myOffers.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              No incoming offers
            </div>
          )}
        </div>
      )}
    </div>
  )
}
