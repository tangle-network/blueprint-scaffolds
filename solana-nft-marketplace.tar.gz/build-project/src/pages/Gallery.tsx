import { useState, useMemo } from "react"
import { useSearchParams } from "react-router-dom"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { NFTCard } from "@/components/shared/NFTCard"
import { CollectionCard } from "@/components/shared/CollectionCard"
import { mockNFTs } from "@/data/mock"
import { mockCollections } from "@/data/mock"
import { mockListings } from "@/data/mock"
import { Search, Filter, Grid3X3, LayoutList } from "lucide-react"
import { useMarketplaceStore } from "@/stores/marketplace"

type ViewMode = "grid" | "list"
type TabMode = "all" | "collections" | "listings"

export default function Gallery() {
  const [search, setSearch] = useState("")
  const [tab, setTab] = useState<TabMode>("all")
  const [view, setView] = useState<ViewMode>("grid")
  const [sort, setSort] = useState<"name" | "rarity" | "price">("name")
  const [searchParams] = useSearchParams()
  const collectionFilter = searchParams.get("collection")
  const { listings } = useMarketplaceStore()

  const filteredNfts = useMemo(() => {
    let nfts = mockNFTs
    if (collectionFilter) {
      nfts = nfts.filter((n) => n.collection === collectionFilter)
    }
    if (search) {
      const q = search.toLowerCase()
      nfts = nfts.filter(
        (n) =>
          n.name.toLowerCase().includes(q) ||
          n.collection?.toLowerCase().includes(q)
      )
    }
    if (sort === "rarity") {
      nfts = [...nfts].sort((a, b) => (a.rarityRank ?? 9999) - (b.rarityRank ?? 9999))
    } else if (sort === "name") {
      nfts = [...nfts].sort((a, b) => a.name.localeCompare(b.name))
    }
    return nfts
  }, [search, sort, collectionFilter])

  const activeListings = useMemo(() => {
    return listings.filter((l) => l.isActive)
  }, [listings])

  const filteredCollections = useMemo(() => {
    if (search) {
      const q = search.toLowerCase()
      return mockCollections.filter((c) => c.name.toLowerCase().includes(q))
    }
    return mockCollections
  }, [search])

  const activeCollection = collectionFilter
    ? mockCollections.find((c) => c.id === collectionFilter)
    : null

  return (
    <div className="space-y-6">
      {activeCollection && (
        <div
          className="rounded-xl overflow-hidden h-48 relative"
        >
          <img
            src={activeCollection.banner}
            alt={activeCollection.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
          <div className="absolute bottom-4 left-6 flex items-center gap-3">
            <img
              src={activeCollection.image}
              alt=""
              className="w-16 h-16 rounded-full border-4 border-background"
            />
            <div>
              <h2 className="text-2xl font-bold">{activeCollection.name}</h2>
              <p className="text-sm text-muted-foreground">
                Floor: {activeCollection.floorPrice} SOL &bull;{" "}
                {activeCollection.totalSupply.toLocaleString()} items
              </p>
            </div>
          </div>
        </div>
      )}

      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search NFTs, collections..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex items-center gap-2">
          <div className="flex rounded-md border">
            {(["all", "collections", "listings"] as TabMode[]).map((t) => (
              <Button
                key={t}
                variant={tab === t ? "secondary" : "ghost"}
                size="sm"
                onClick={() => setTab(t)}
                className="rounded-none first:rounded-l-md last:rounded-r-md"
              >
                {t.charAt(0).toUpperCase() + t.slice(1)}
              </Button>
            ))}
          </div>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as typeof sort)}
            className="h-9 rounded-md border bg-background px-2 text-sm"
          >
            <option value="name">Name</option>
            <option value="rarity">Rarity</option>
            <option value="price">Price</option>
          </select>
          <div className="flex rounded-md border">
            <Button
              variant={view === "grid" ? "secondary" : "ghost"}
              size="icon"
              className="rounded-r-none"
              onClick={() => setView("grid")}
            >
              <Grid3X3 className="h-4 w-4" />
            </Button>
            <Button
              variant={view === "list" ? "secondary" : "ghost"}
              size="icon"
              className="rounded-l-none"
              onClick={() => setView("list")}
            >
              <LayoutList className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {tab === "all" && (
        <div
          className={
            view === "grid"
              ? "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4"
              : "space-y-2"
          }
        >
          {filteredNfts.map((nft) => (
            <NFTCard
              key={nft.id}
              nft={nft}
              showRarity
            />
          ))}
        </div>
      )}

      {tab === "collections" && (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filteredCollections.map((col) => (
            <CollectionCard key={col.id} collection={col} />
          ))}
        </div>
      )}

      {tab === "listings" && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {activeListings.map((listing) => (
            <NFTCard
              key={listing.id}
              nft={listing.nft}
              price={listing.price}
              showRarity
            />
          ))}
        </div>
      )}

      {tab === "all" && filteredNfts.length === 0 && (
        <div className="text-center py-20 text-muted-foreground">
          No NFTs found matching your search.
        </div>
      )}
    </div>
  )
}
