import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { NFTCard } from "@/components/shared/NFTCard"
import { useAuctionStore } from "@/stores/auction"
import { useWalletStore } from "@/stores/wallet"
import { formatSOL, shortenAddress, timeAgo } from "@/lib/utils"
import { Gavel, Clock, TrendingUp, AlertCircle } from "lucide-react"

export default function Auctions() {
  const { auctions, bids, placeBid } = useAuctionStore()
  const { connected } = useWalletStore()
  const [bidAmount, setBidAmount] = useState<Record<string, string>>({})
  const [selectedAuction, setSelectedAuction] = useState<string | null>(null)

  const activeAuctions = auctions.filter((a) => a.isActive)
  const selected = activeAuctions.find((a) => a.id === selectedAuction)

  const handleBid = (auctionId: string) => {
    const amount = bidAmount[auctionId]
    if (!amount || !connected) return
    placeBid(auctionId, "PhantomW1...123", parseFloat(amount) * 1e9)
    setBidAmount((prev) => ({ ...prev, [auctionId]: "" }))
  }

  const getTimeRemaining = (endTime: Date) => {
    const diff = endTime.getTime() - Date.now()
    if (diff <= 0) return "Ended"
    const hours = Math.floor(diff / 3600000)
    const minutes = Math.floor((diff % 3600000) / 60000)
    return `${hours}h ${minutes}m`
  }

  const getReserveProgress = (auction: typeof activeAuctions[0]) => {
    if (!auction.reservePrice) return 100
    return Math.min(100, (auction.currentBid / auction.reservePrice) * 100)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Gavel className="h-6 w-6 text-primary" /> Live Auctions
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            {activeAuctions.length} active auction{activeAuctions.length !== 1 ? "s" : ""}
          </p>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            {activeAuctions.map((auction) => {
              const auctionBids = bids.filter((b) => b.auctionId === auction.id)
              const isSelected = selectedAuction === auction.id
              return (
                <Card
                  key={auction.id}
                  className={`cursor-pointer transition-colors ${
                    isSelected ? "border-primary" : "hover:border-primary/50"
                  }`}
                  onClick={() => setSelectedAuction(auction.id)}
                >
                  <div className="aspect-video overflow-hidden rounded-t-lg bg-muted">
                    <img
                      src={auction.nft.image}
                      alt={auction.nft.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardContent className="p-4 space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="font-semibold">{auction.nft.name}</p>
                        <p className="text-xs text-muted-foreground">
                          by {shortenAddress(auction.seller)}
                        </p>
                      </div>
                      <Badge variant="outline" className="gap-1 text-xs">
                        <Clock className="h-3 w-3" />
                        {getTimeRemaining(auction.endTime)}
                      </Badge>
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Current Bid</span>
                        <span className="font-semibold text-primary">
                          {formatSOL(auction.currentBid)}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Bids</span>
                        <span>{auction.bidCount}</span>
                      </div>
                    </div>

                    {auction.reservePrice && (
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Reserve</span>
                          <span>
                            {getReserveProgress(auction) >= 100
                              ? "Met"
                              : `${formatSOL(auction.reservePrice)}`}
                          </span>
                        </div>
                        <Progress value={getReserveProgress(auction)} className="h-1.5" />
                      </div>
                    )}
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>

        <div className="space-y-4">
          {selected ? (
            <>
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">{selected.nft.name}</CardTitle>
                  <CardDescription>{selected.nft.collection}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Highest Bid</span>
                      <span className="font-bold text-primary text-lg">
                        {formatSOL(selected.currentBid)}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Bidder</span>
                      <span className="font-mono text-sm">
                        {shortenAddress(selected.currentBidder)}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Min Bid</span>
                      <span>{formatSOL(selected.minBid)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Ends In</span>
                      <span>{getTimeRemaining(selected.endTime)}</span>
                    </div>
                  </div>

                  <Separator />

                  {connected ? (
                    <div className="space-y-2">
                      <Label htmlFor="bid-input">Your Bid (SOL)</Label>
                      <div className="flex gap-2">
                        <Input
                          id="bid-input"
                          type="number"
                          step="0.1"
                          placeholder={`${(selected.currentBid / 1e9 * 1.05).toFixed(2)}`}
                          value={bidAmount[selected.id] || ""}
                          onChange={(e) =>
                            setBidAmount((prev) => ({
                              ...prev,
                              [selected.id]: e.target.value,
                            }))
                          }
                        />
                        <Button
                          onClick={() => handleBid(selected.id)}
                          className="shrink-0 gap-1"
                        >
                          <TrendingUp className="h-4 w-4" /> Bid
                        </Button>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Min next bid: {formatSOL(Math.ceil(selected.currentBid * 1.05 / 1e7) * 1e7)}
                      </p>
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground text-center">
                      Connect wallet to bid
                    </p>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Bid History</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {bids
                      .filter((b) => b.auctionId === selected.id)
                      .sort((a, b) => b.amount - a.amount)
                      .map((bid) => (
                        <div
                          key={bid.id}
                          className="flex items-center justify-between py-1.5 border-b last:border-0"
                        >
                          <div>
                            <p className="text-sm font-mono">
                              {shortenAddress(bid.bidder)}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {timeAgo(bid.timestamp)}
                            </p>
                          </div>
                          <p className="text-sm font-semibold">
                            {formatSOL(bid.amount)}
                          </p>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                <Gavel className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>Select an auction to view details</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
