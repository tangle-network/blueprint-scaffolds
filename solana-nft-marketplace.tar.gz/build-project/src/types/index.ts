export interface NFTAttribute {
  trait_type: string
  value: string | number
  display_type?: string
}

export interface NFT {
  id: string
  mint: string
  name: string
  symbol: string
  uri: string
  image: string
  description: string
  attributes: NFTAttribute[]
  collection?: string
  owner: string
  creator: string
  royaltyBps: number
  isCompressed: boolean
  isVerified: boolean
  rarityRank?: number
  rarityScore?: number
}

export interface Collection {
  id: string
  name: string
  symbol: string
  description: string
  image: string
  banner: string
  creator: string
  verified: boolean
  floorPrice: number
  totalVolume: number
  totalListed: number
  totalSupply: number
  uniqueHolders: number
  royaltyBps: number
}

export type ListingType = "fixed" | "auction"

export interface Listing {
  id: string
  nftId: string
  nft: NFT
  seller: string
  price: number
  type: ListingType
  createdAt: Date
  expiresAt?: Date
  isActive: boolean
}

export interface AuctionListing extends Listing {
  type: "auction"
  minBid: number
  currentBid: number
  currentBidder: string
  bidCount: number
  reservePrice?: number
  endTime: Date
}

export interface Offer {
  id: string
  nftId: string
  nft: NFT
  buyer: string
  price: number
  expiresAt: Date
  createdAt: Date
  isActive: boolean
}

export interface Bid {
  id: string
  auctionId: string
  bidder: string
  amount: number
  timestamp: Date
}

export interface Bundle {
  id: string
  name: string
  description: string
  nfts: NFT[]
  seller: string
  price: number
  createdAt: Date
  isActive: boolean
}

export interface Loan {
  id: string
  nftId: string
  nft: NFT
  lender: string
  borrower: string
  principal: number
  interestRate: number
  duration: number
  startTime: Date
  endTime: Date
  status: "active" | "repaid" | "liquidated" | "defaulted"
}

export interface FractionalToken {
  id: string
  nftId: string
  nft: NFT
  totalSupply: number
  availableSupply: number
  pricePerToken: number
  creator: string
  holders: FractionalHolder[]
}

export interface FractionalHolder {
  address: string
  amount: number
  percentage: number
}

export interface SwapProposal {
  id: string
  proposer: string
  offeredNfts: NFT[]
  requestedNfts: NFT[]
  targetOwner: string
  status: "pending" | "accepted" | "rejected" | "cancelled"
  createdAt: Date
  expiresAt: Date
}

export type ActivityType =
  | "sale"
  | "listing"
  | "bid"
  | "offer"
  | "transfer"
  | "mint"
  | "burn"
  | "loan"
  | "fractional"
  | "swap"
  | "bundle"

export interface Activity {
  id: string
  type: ActivityType
  nftId?: string
  nft?: NFT
  collection?: string
  from?: string
  to?: string
  price?: number
  timestamp: Date
  txHash: string
}
