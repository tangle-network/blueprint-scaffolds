import { ArrowUpRight, ArrowDownLeft, Tag, Gavel, Handshake, Send, Flame, Landmark, PieChart, ArrowLeftRight, Package } from "lucide-react"
import type { Activity } from "@/types"
import { formatSOL, timeAgo, shortenAddress } from "@/lib/utils"

interface ActivityItemProps {
  activity: Activity
  compact?: boolean
}

const iconMap: Record<string, React.ElementType> = {
  sale: ArrowUpRight,
  listing: Tag,
  bid: Gavel,
  offer: Handshake,
  transfer: Send,
  mint: Flame,
  burn: Flame,
  loan: Landmark,
  fractional: PieChart,
  swap: ArrowLeftRight,
  bundle: Package,
}

const colorMap: Record<string, string> = {
  sale: "text-green-500",
  listing: "text-blue-500",
  bid: "text-yellow-500",
  offer: "text-purple-500",
  transfer: "text-gray-500",
  mint: "text-primary",
  burn: "text-red-500",
  loan: "text-orange-500",
  fractional: "text-pink-500",
  swap: "text-cyan-500",
  bundle: "text-indigo-500",
}

export function ActivityItem({ activity, compact = false }: ActivityItemProps) {
  const Icon = iconMap[activity.type] || Send
  const color = colorMap[activity.type] || "text-muted-foreground"

  return (
    <div className="flex items-center gap-3 py-3">
      <div className={`${color} shrink-0`}>
        <Icon className="h-5 w-5" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm truncate">
          {activity.nft?.name || activity.collection || "Unknown"}
        </p>
        <p className="text-xs text-muted-foreground">
          {activity.type.charAt(0).toUpperCase() + activity.type.slice(1)}
          {activity.from && ` from ${shortenAddress(activity.from)}`}
          {activity.to && ` to ${shortenAddress(activity.to)}`}
        </p>
      </div>
      <div className="text-right shrink-0">
        {activity.price !== undefined && (
          <p className="text-sm font-medium">{formatSOL(activity.price)}</p>
        )}
        {!compact && (
          <p className="text-xs text-muted-foreground">{timeAgo(activity.timestamp)}</p>
        )}
      </div>
    </div>
  )
}
