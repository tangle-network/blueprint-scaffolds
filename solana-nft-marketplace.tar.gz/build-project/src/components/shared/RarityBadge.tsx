import { Badge } from "@/components/ui/badge"

interface RarityBadgeProps {
  rank?: number
  score?: number
}

export function RarityBadge({ rank, score }: RarityBadgeProps) {
  if (!rank && !score) return null

  const tier = rank
    ? rank <= 10
      ? "Legendary"
      : rank <= 100
        ? "Epic"
        : rank <= 500
          ? "Rare"
          : rank <= 1000
            ? "Uncommon"
            : "Common"
    : "Common"

  const tierColor: Record<string, string> = {
    Legendary: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
    Epic: "bg-purple-500/20 text-purple-400 border-purple-500/30",
    Rare: "bg-blue-500/20 text-blue-400 border-blue-500/30",
    Uncommon: "bg-green-500/20 text-green-400 border-green-500/30",
    Common: "bg-gray-500/20 text-gray-400 border-gray-500/30",
  }

  return (
    <div className="flex items-center gap-1.5">
      <Badge className={`${tierColor[tier]} border text-xs`}>
        {tier}
      </Badge>
      {rank && <span className="text-xs text-muted-foreground">#{rank}</span>}
      {score && <span className="text-xs text-muted-foreground">({score.toLocaleString()})</span>}
    </div>
  )
}
