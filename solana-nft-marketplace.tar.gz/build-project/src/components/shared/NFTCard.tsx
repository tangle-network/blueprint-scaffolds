import { Link } from "react-router-dom"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { NFT } from "@/types"
import { formatSOL } from "@/lib/utils"

interface NFTCardProps {
  nft: NFT
  price?: number
  showRarity?: boolean
}

export function NFTCard({ nft, price, showRarity = false }: NFTCardProps) {
  return (
    <Link to={`/nft/${nft.id}`}>
      <Card className="overflow-hidden hover:border-primary/50 transition-colors group cursor-pointer">
        <div className="aspect-square overflow-hidden bg-muted">
          <img
            src={nft.image}
            alt={nft.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            loading="lazy"
          />
        </div>
        <CardContent className="p-3 space-y-1.5">
          <div className="flex items-start justify-between gap-1">
            <p className="font-medium text-sm truncate">{nft.name}</p>
            {nft.isCompressed && (
              <Badge variant="outline" className="text-[10px] shrink-0">cNFT</Badge>
            )}
          </div>
          {nft.collection && (
            <p className="text-xs text-muted-foreground truncate">{nft.collection}</p>
          )}
          <div className="flex items-center justify-between">
            {price !== undefined ? (
              <p className="text-sm font-semibold text-primary">{formatSOL(price)}</p>
            ) : (
              <p className="text-xs text-muted-foreground">{shortenAddr(nft.owner)}</p>
            )}
            {showRarity && nft.rarityRank && (
              <Badge variant="secondary" className="text-[10px]">
                R#{nft.rarityRank}
              </Badge>
            )}
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}

function shortenAddr(addr: string): string {
  if (addr.length <= 12) return addr
  return `${addr.slice(0, 4)}...${addr.slice(-4)}`
}
