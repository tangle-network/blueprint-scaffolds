import { Link } from "react-router-dom"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle } from "lucide-react"
import type { Collection } from "@/types"

interface CollectionCardProps {
  collection: Collection
}

export function CollectionCard({ collection }: CollectionCardProps) {
  return (
    <Link to={`/?collection=${collection.id}`}>
      <Card className="overflow-hidden hover:border-primary/50 transition-colors cursor-pointer">
        <div className="h-32 overflow-hidden bg-muted">
          <img
            src={collection.banner}
            alt={collection.name}
            className="w-full h-full object-cover"
            loading="lazy"
          />
        </div>
        <CardContent className="p-4 space-y-2">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full overflow-hidden bg-muted border-2 border-background -mt-8 relative z-10">
              <img src={collection.image} alt={collection.name} className="w-full h-full object-cover" />
            </div>
            <div className="flex items-center gap-1">
              <p className="font-semibold text-sm truncate">{collection.name}</p>
              {collection.verified && (
                <CheckCircle className="h-3.5 w-3.5 text-blue-500 shrink-0" />
              )}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <p className="text-muted-foreground">Floor</p>
              <p className="font-medium">{collection.floorPrice} SOL</p>
            </div>
            <div>
              <p className="text-muted-foreground">Volume</p>
              <p className="font-medium">{collection.totalVolume.toLocaleString()} SOL</p>
            </div>
            <div>
              <p className="text-muted-foreground">Listed</p>
              <p className="font-medium">{collection.totalListed}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Holders</p>
              <p className="font-medium">{collection.uniqueHolders.toLocaleString()}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}
