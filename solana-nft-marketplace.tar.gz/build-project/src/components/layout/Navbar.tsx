import { Link, useLocation } from "react-router-dom"
import { Wallet, Flame, LayoutGrid, Gavel, LayoutDashboard, Activity, Landmark, PieChart, ArrowLeftRight, Package } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useWalletStore } from "@/stores/wallet"
import { shortenAddress } from "@/lib/utils"

const navItems = [
  { to: "/", label: "Gallery", icon: LayoutGrid },
  { to: "/auctions", label: "Auctions", icon: Gavel },
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/activity", label: "Activity", icon: Activity },
  { to: "/lending", label: "Lending", icon: Landmark },
  { to: "/fractional", label: "Fractional", icon: PieChart },
  { to: "/swaps", label: "Swaps", icon: ArrowLeftRight },
  { to: "/bundles", label: "Bundles", icon: Package },
]

export function Navbar() {
  const { connected, address, balance, connect, disconnect } = useWalletStore()
  const location = useLocation()

  return (
    <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="flex h-16 items-center px-6 gap-4">
        <Link to="/" className="flex items-center gap-2 mr-4">
          <Flame className="h-6 w-6 text-primary" />
          <span className="text-lg font-bold">SolNFT</span>
        </Link>

        <nav className="hidden md:flex items-center gap-1 flex-1">
          {navItems.map((item) => {
            const Icon = item.icon
            const active = location.pathname === item.to
            return (
              <Link key={item.to} to={item.to}>
                <Button
                  variant={active ? "secondary" : "ghost"}
                  size="sm"
                  className="gap-1.5"
                >
                  <Icon className="h-4 w-4" />
                  {item.label}
                </Button>
              </Link>
            )
          })}
        </nav>

        <div className="ml-auto flex items-center gap-3">
          {connected ? (
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">
                {balance.toFixed(2)} SOL
              </span>
              <Button variant="outline" size="sm" onClick={disconnect}>
                <Wallet className="h-4 w-4 mr-1" />
                {shortenAddress(address!)}
              </Button>
            </div>
          ) : (
            <Button size="sm" onClick={connect}>
              <Wallet className="h-4 w-4 mr-1" />
              Connect Wallet
            </Button>
          )}
        </div>
      </div>

      <nav className="md:hidden flex overflow-x-auto gap-1 px-4 pb-2">
        {navItems.map((item) => {
          const Icon = item.icon
          const active = location.pathname === item.to
          return (
            <Link key={item.to} to={item.to}>
              <Button
                variant={active ? "secondary" : "ghost"}
                size="sm"
                className="gap-1 shrink-0"
              >
                <Icon className="h-3.5 w-3.5" />
                {item.label}
              </Button>
            </Link>
          )
        })}
      </nav>
    </header>
  )
}
