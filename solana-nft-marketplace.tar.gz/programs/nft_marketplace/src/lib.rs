use anchor_lang::prelude::*;
use anchor_lang::solana_program::{program_option::COption, pubkey::PUBKEY_BYTES};
use anchor_spl::token::{self, Token, TokenAccount, Transfer};
use std::str::FromStr;

declare_id!("Fg6PaFpoGXkYsidMpWTK6W2BeZ7FEfcYkg476zPFsLnS");

pub mod errors;
pub mod state;

use errors::*;
use state::*;

#[program]
pub mod nft_marketplace {
    use super::*;

    // ─── Marketplace Initialization ─────────────────────────────────

    pub fn initialize_marketplace(
        ctx: Context<InitializeMarketplace>,
        name: String,
        fee_basis_points: u16,
    ) -> Result<()> {
        require!(name.len() <= 64, MarketplaceError::NameTooLong);
        require!(fee_basis_points <= 10000, MarketplaceError::InvalidFee);

        let marketplace = &mut ctx.accounts.marketplace;
        marketplace.authority = ctx.accounts.authority.key();
        marketplace.name = name;
        marketplace.fee_basis_points = fee_basis_points;
        marketplace.fee_recipient = ctx.accounts.fee_recipient.key();
        marketplace.bump = ctx.bumps.marketplace;
        marketplace.collection_count = 0;
        marketplace.listing_count = 0;
        marketplace.volume_traded = 0;

        emit!(MarketplaceCreated {
            authority: ctx.accounts.authority.key(),
            name: marketplace.name.clone(),
        });

        Ok(())
    }

    pub fn update_marketplace(
        ctx: Context<UpdateMarketplace>,
        fee_basis_points: Option<u16>,
    ) -> Result<()> {
        let marketplace = &mut ctx.accounts.marketplace;

        if let Some(fee) = fee_basis_points {
            require!(fee <= 10000, MarketplaceError::InvalidFee);
            marketplace.fee_basis_points = fee;
        }

        emit!(MarketplaceUpdated {
            authority: ctx.accounts.authority.key(),
        });

        Ok(())
    }

    // ─── Collection Management ──────────────────────────────────────

    pub fn verify_collection(ctx: Context<VerifyCollection>) -> Result<()> {
        let collection = &mut ctx.accounts.collection;
        collection.verified = true;

        emit!(CollectionVerified {
            collection_mint: collection.mint,
            authority: ctx.accounts.authority.key(),
        });

        Ok(())
    }

    pub fn register_collection(
        ctx: Context<RegisterCollection>,
        name: String,
        royalty_basis_points: u16,
    ) -> Result<()> {
        require!(name.len() <= 64, MarketplaceError::NameTooLong);
        require!(royalty_basis_points <= 5000, MarketplaceError::InvalidRoyalty);

        let marketplace = &mut ctx.accounts.marketplace;
        marketplace.collection_count += 1;

        let collection = &mut ctx.accounts.collection;
        collection.mint = ctx.accounts.collection_mint.key();
        collection.authority = ctx.accounts.authority.key();
        collection.marketplace = marketplace.key();
        collection.name = name;
        collection.royalty_basis_points = royalty_basis_points;
        collection.verified = false;
        collection.bump = ctx.bumps.collection;
        collection.item_count = 0;
        collection.floor_price = 0;
        collection.total_volume = 0;

        emit!(CollectionRegistered {
            collection_mint: ctx.accounts.collection_mint.key(),
            name: collection.name.clone(),
        });

        Ok(())
    }

    // ─── Fixed-Price Listings ───────────────────────────────────────

    pub fn list_nft(
        ctx: Context<ListNft>,
        price: u64,
        expires_at: Option<i64>,
    ) -> Result<()> {
        require!(price > 0, MarketplaceError::InvalidPrice);

        if let Some(exp) = expires_at {
            let clock = Clock::get()?;
            require!(exp > clock.unix_timestamp, MarketplaceError::ListingExpired);
        }

        let marketplace = &mut ctx.accounts.marketplace;
        marketplace.listing_count += 1;

        let listing = &mut ctx.accounts.listing;
        listing.seller = ctx.accounts.seller.key();
        listing.nft_mint = ctx.accounts.nft_mint.key();
        listing.collection = ctx.accounts.collection.key();
        listing.price = price;
        listing.listed_at = Clock::get()?.unix_timestamp;
        listing.expires_at = expires_at;
        listing.active = true;
        listing.listing_type = ListingType::FixedPrice;
        listing.bump = ctx.bumps.listing;
        listing.token_account = ctx.accounts.seller_token_account.key();

        let nft_vault = &mut ctx.accounts.nft_vault;
        nft_vault.listing = listing.key();
        nft_vault.mint = ctx.accounts.nft_mint.key();
        nft_vault.bump = ctx.bumps.nft_vault;

        token::transfer(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.seller_token_account.to_account_info(),
                    to: ctx.accounts.nft_vault.to_account_info(),
                    authority: ctx.accounts.seller.to_account_info(),
                },
            ),
            1,
        )?;

        emit!(NFTListed {
            mint: ctx.accounts.nft_mint.key(),
            seller: ctx.accounts.seller.key(),
            price,
            listing_type: ListingType::FixedPrice,
        });

        Ok(())
    }

    pub fn delist_nft(ctx: Context<DelistNft>) -> Result<()> {
        let listing = &mut ctx.accounts.listing;
        require!(listing.active, MarketplaceError::ListingNotActive);
        require!(
            listing.seller == ctx.accounts.seller.key(),
            MarketplaceError::Unauthorized
        );

        listing.active = false;

        let seeds = &[
            b"nft_vault",
            listing.nft_mint.as_ref(),
            &[listing.bump],
        ];
        let signer = &[&seeds[..]];

        token::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.nft_vault.to_account_info(),
                    to: ctx.accounts.seller_token_account.to_account_info(),
                    authority: ctx.accounts.nft_vault.to_account_info(),
                },
                signer,
            ),
            1,
        )?;

        emit!(NFTDelisted {
            mint: listing.nft_mint,
            seller: ctx.accounts.seller.key(),
        });

        Ok(())
    }

    pub fn buy_nft(ctx: Context<BuyNft>) -> Result<()> {
        let listing = &mut ctx.accounts.listing;
        require!(listing.active, MarketplaceError::ListingNotActive);
        require!(listing.listing_type == ListingType::FixedPrice, MarketplaceError::WrongListingType);

        if let Some(exp) = listing.expires_at {
            let clock = Clock::get()?;
            require!(exp > clock.unix_timestamp, MarketplaceError::ListingExpired);
        }

        listing.active = false;

        let marketplace = &mut ctx.accounts.marketplace;
        marketplace.volume_traded += listing.price;

        let marketplace_fee = (listing.price as u128)
            .checked_mul(marketplace.fee_basis_points as u128)
            .unwrap()
            .checked_div(10000)
            .unwrap() as u64;

        let seller_proceeds = listing.price.checked_sub(marketplace_fee).unwrap();

        token::transfer(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.buyer_token_account.to_account_info(),
                    to: ctx.accounts.seller_token_account.to_account_info(),
                    authority: ctx.accounts.buyer.to_account_info(),
                },
            ),
            seller_proceeds,
        )?;

        if marketplace_fee > 0 {
            token::transfer(
                CpiContext::new(
                    ctx.accounts.token_program.to_account_info(),
                    Transfer {
                        from: ctx.accounts.buyer_token_account.to_account_info(),
                        to: ctx.accounts.fee_recipient_token_account.to_account_info(),
                        authority: ctx.accounts.buyer.to_account_info(),
                    },
                ),
                marketplace_fee,
            )?;
        }

        let seeds = &[
            b"nft_vault",
            listing.nft_mint.as_ref(),
            &[listing.bump],
        ];
        let signer = &[&seeds[..]];

        token::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.nft_vault.to_account_info(),
                    to: ctx.accounts.buyer_nft_account.to_account_info(),
                    authority: ctx.accounts.nft_vault.to_account_info(),
                },
                signer,
            ),
            1,
        )?;

        emit!(NFTSold {
            mint: listing.nft_mint,
            seller: listing.seller,
            buyer: ctx.accounts.buyer.key(),
            price: listing.price,
        });

        Ok(())
    }

    // ─── Batch Buying ───────────────────────────────────────────────

    pub fn batch_buy_nfts(ctx: Context<BatchBuyNfts>, listing_bumps: Vec<u8>) -> Result<()> {
        let buyer_lamports = ctx.accounts.buyer.lamports();
        let total_price: u64 = ctx
            .accounts
            .listings
            .iter()
            .zip(ctx.accounts.listing_bumps.iter())
            .map(|(l, _)| {
                require!(l.active, MarketplaceError::ListingNotActive);
                l.price
            })
            .sum();
        require!(buyer_lamports >= total_price, MarketplaceError::InsufficientFunds);

        for (listing, vault) in ctx
            .accounts
            .listings
            .iter_mut()
            .zip(ctx.accounts.nft_vaults.iter())
        {
            listing.active = false;

            let seeds = &[
                b"nft_vault",
                listing.nft_mint.as_ref(),
                &[listing.bump],
            ];
            let signer = &[&seeds[..]];

            token::transfer(
                CpiContext::new_with_signer(
                    ctx.accounts.token_program.to_account_info(),
                    Transfer {
                        from: vault.to_account_info(),
                        to: ctx.accounts.buyer_token_account.to_account_info(),
                        authority: vault.to_account_info(),
                    },
                    signer,
                ),
                1,
            )?;
        }

        emit!(BatchPurchase {
            buyer: ctx.accounts.buyer.key(),
            count: ctx.accounts.listings.len() as u64,
            total_price,
        });

        Ok(())
    }

    // ─── Auctions ───────────────────────────────────────────────────

    pub fn create_auction(
        ctx: Context<CreateAuction>,
        min_bid: u64,
        ends_at: i64,
        reserve_price: Option<u64>,
    ) -> Result<()> {
        require!(min_bid > 0, MarketplaceError::InvalidPrice);
        let clock = Clock::get()?;
        require!(ends_at > clock.unix_timestamp, MarketplaceError::InvalidEndTime);

        let marketplace = &mut ctx.accounts.marketplace;
        marketplace.listing_count += 1;

        let listing = &mut ctx.accounts.listing;
        listing.seller = ctx.accounts.seller.key();
        listing.nft_mint = ctx.accounts.nft_mint.key();
        listing.collection = ctx.accounts.collection.key();
        listing.price = min_bid;
        listing.listed_at = clock.unix_timestamp;
        listing.expires_at = Some(ends_at);
        listing.active = true;
        listing.listing_type = ListingType::Auction;
        listing.bump = ctx.bumps.listing;
        listing.token_account = ctx.accounts.seller_token_account.key();

        let auction = &mut ctx.accounts.auction;
        auction.listing = listing.key();
        auction.min_bid = min_bid;
        auction.reserve_price = reserve_price.unwrap_or(0);
        auction.ends_at = ends_at;
        auction.highest_bid = 0;
        auction.highest_bidder = Pubkey::default();
        auction.bid_count = 0;
        auction.bump = ctx.bumps.auction;
        auction.ended = false;

        let nft_vault = &mut ctx.accounts.nft_vault;
        nft_vault.listing = listing.key();
        nft_vault.mint = ctx.accounts.nft_mint.key();
        nft_vault.bump = ctx.bumps.nft_vault;

        token::transfer(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.seller_token_account.to_account_info(),
                    to: ctx.accounts.nft_vault.to_account_info(),
                    authority: ctx.accounts.seller.to_account_info(),
                },
            ),
            1,
        )?;

        emit!(AuctionCreated {
            mint: ctx.accounts.nft_mint.key(),
            seller: ctx.accounts.seller.key(),
            min_bid,
            ends_at,
        });

        Ok(())
    }

    pub fn place_bid(ctx: Context<PlaceBid>, amount: u64) -> Result<()> {
        let auction = &mut ctx.accounts.auction;
        let listing = &mut ctx.accounts.listing;
        require!(listing.active, MarketplaceError::ListingNotActive);
        require!(!auction.ended, MarketplaceError::AuctionEnded);
        require!(amount >= auction.min_bid, MarketplaceError::BidTooLow);
        require!(
            amount > auction.highest_bid,
            MarketplaceError::BidTooLow
        );

        let clock = Clock::get()?;
        require!(clock.unix_timestamp < auction.ends_at, MarketplaceError::AuctionEnded);

        if auction.highest_bid > 0 {
            let seeds = &[
                b"escrow",
                auction.listing.as_ref(),
                &[auction.bump],
            ];
            let signer = &[&seeds[..]];

            token::transfer(
                CpiContext::new_with_signer(
                    ctx.accounts.token_program.to_account_info(),
                    Transfer {
                        from: ctx.accounts.escrow.to_account_info(),
                        to: ctx.accounts
                            .previous_bidder_token_account
                            .to_account_info(),
                        authority: ctx.accounts.escrow.to_account_info(),
                    },
                    signer,
                ),
                auction.highest_bid,
            )?;
        }

        token::transfer(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.bidder_token_account.to_account_info(),
                    to: ctx.accounts.escrow.to_account_info(),
                    authority: ctx.accounts.bidder.to_account_info(),
                },
            ),
            amount,
        )?;

        auction.highest_bid = amount;
        auction.highest_bidder = ctx.accounts.bidder.key();
        auction.bid_count += 1;

        emit!(BidPlaced {
            auction: auction.key(),
            bidder: ctx.accounts.bidder.key(),
            amount,
        });

        Ok(())
    }

    pub fn settle_auction(ctx: Context<SettleAuction>) -> Result<()> {
        let auction = &mut ctx.accounts.auction;
        let listing = &mut ctx.accounts.listing;

        require!(!auction.ended, MarketplaceError::AuctionEnded);

        let clock = Clock::get()?;
        require!(
            clock.unix_timestamp >= auction.ends_at,
            MarketplaceError::AuctionNotEnded
        );

        require!(
            auction.highest_bid >= auction.reserve_price,
            MarketplaceError::ReserveNotMet
        );

        auction.ended = true;
        listing.active = false;

        let marketplace = &mut ctx.accounts.marketplace;
        marketplace.volume_traded += auction.highest_bid;

        let marketplace_fee = (auction.highest_bid as u128)
            .checked_mul(marketplace.fee_basis_points as u128)
            .unwrap()
            .checked_div(10000)
            .unwrap() as u64;

        let seller_proceeds = auction.highest_bid.checked_sub(marketplace_fee).unwrap();

        let seeds = &[b"escrow", auction.listing.as_ref(), &[auction.bump]];
        let signer = &[&seeds[..]];

        token::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.escrow.to_account_info(),
                    to: ctx.accounts.seller_token_account.to_account_info(),
                    authority: ctx.accounts.escrow.to_account_info(),
                },
                signer,
            ),
            seller_proceeds,
        )?;

        if marketplace_fee > 0 {
            token::transfer(
                CpiContext::new_with_signer(
                    ctx.accounts.token_program.to_account_info(),
                    Transfer {
                        from: ctx.accounts.escrow.to_account_info(),
                        to: ctx.accounts.fee_recipient_token_account.to_account_info(),
                        authority: ctx.accounts.escrow.to_account_info(),
                    },
                    signer,
                ),
                marketplace_fee,
            )?;
        }

        let vault_seeds = &[
            b"nft_vault",
            listing.nft_mint.as_ref(),
            &[listing.bump],
        ];
        let vault_signer = &[&vault_seeds[..]];

        token::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.nft_vault.to_account_info(),
                    to: ctx.accounts.winner_nft_account.to_account_info(),
                    authority: ctx.accounts.nft_vault.to_account_info(),
                },
                vault_signer,
            ),
            1,
        )?;

        emit!(AuctionSettled {
            mint: listing.nft_mint,
            winner: auction.highest_bidder,
            amount: auction.highest_bid,
        });

        Ok(())
    }

    // ─── Offers ─────────────────────────────────────────────────────

    pub fn make_offer(
        ctx: Context<MakeOffer>,
        price: u64,
        expires_at: i64,
    ) -> Result<()> {
        require!(price > 0, MarketplaceError::InvalidPrice);
        let clock = Clock::get()?;
        require!(expires_at > clock.unix_timestamp, MarketplaceError::InvalidEndTime);

        let offer = &mut ctx.accounts.offer;
        offer.buyer = ctx.accounts.buyer.key();
        offer.nft_mint = ctx.accounts.nft_mint.key();
        offer.price = price;
        offer.created_at = clock.unix_timestamp;
        offer.expires_at = expires_at;
        offer.active = true;
        offer.bump = ctx.bumps.offer;

        token::transfer(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.buyer_token_account.to_account_info(),
                    to: ctx.accounts.escrow.to_account_info(),
                    authority: ctx.accounts.buyer.to_account_info(),
                },
            ),
            price,
        )?;

        emit!(OfferMade {
            mint: ctx.accounts.nft_mint.key(),
            buyer: ctx.accounts.buyer.key(),
            price,
        });

        Ok(())
    }

    pub fn accept_offer(ctx: Context<AcceptOffer>) -> Result<()> {
        let offer = &mut ctx.accounts.offer;
        require!(offer.active, MarketplaceError::OfferNotActive);

        let clock = Clock::get()?;
        require!(offer.expires_at > clock.unix_timestamp, MarketplaceError::OfferExpired);
        require!(
            offer.nft_mint == ctx.accounts.nft_mint.key(),
            MarketplaceError::MintMismatch
        );

        offer.active = false;

        let marketplace = &mut ctx.accounts.marketplace;
        marketplace.volume_traded += offer.price;

        let marketplace_fee = (offer.price as u128)
            .checked_mul(marketplace.fee_basis_points as u128)
            .unwrap()
            .checked_div(10000)
            .unwrap() as u64;

        let seller_proceeds = offer.price.checked_sub(marketplace_fee).unwrap();

        let seeds = &[b"offer_escrow", offer.nft_mint.as_ref(), ctx.accounts.buyer.as_ref(), &[offer.bump]];
        let signer = &[&seeds[..]];

        token::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.escrow.to_account_info(),
                    to: ctx.accounts.seller_token_account.to_account_info(),
                    authority: ctx.accounts.escrow.to_account_info(),
                },
                signer,
            ),
            seller_proceeds,
        )?;

        if marketplace_fee > 0 {
            token::transfer(
                CpiContext::new_with_signer(
                    ctx.accounts.token_program.to_account_info(),
                    Transfer {
                        from: ctx.accounts.escrow.to_account_info(),
                        to: ctx.accounts.fee_recipient_token_account.to_account_info(),
                        authority: ctx.accounts.escrow.to_account_info(),
                    },
                    signer,
                ),
                marketplace_fee,
            )?;
        }

        token::transfer(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.seller_nft_account.to_account_info(),
                    to: ctx.accounts.buyer_nft_account.to_account_info(),
                    authority: ctx.accounts.seller.to_account_info(),
                },
            ),
            1,
        )?;

        emit!(OfferAccepted {
            mint: offer.nft_mint,
            seller: ctx.accounts.seller.key(),
            buyer: offer.buyer,
            price: offer.price,
        });

        Ok(())
    }

    pub fn cancel_offer(ctx: Context<CancelOffer>) -> Result<()> {
        let offer = &mut ctx.accounts.offer;
        require!(offer.active, MarketplaceError::OfferNotActive);
        require!(
            offer.buyer == ctx.accounts.buyer.key(),
            MarketplaceError::Unauthorized
        );

        offer.active = false;

        let seeds = &[b"offer_escrow", offer.nft_mint.as_ref(), ctx.accounts.buyer.as_ref(), &[offer.bump]];
        let signer = &[&seeds[..]];

        token::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.escrow.to_account_info(),
                    to: ctx.accounts.buyer_token_account.to_account_info(),
                    authority: ctx.accounts.escrow.to_account_info(),
                },
                signer,
            ),
            offer.price,
        )?;

        emit!(OfferCancelled {
            mint: offer.nft_mint,
            buyer: ctx.accounts.buyer.key(),
        });

        Ok(())
    }

    // ─── NFT-to-NFT Swaps ──────────────────────────────────────────

    pub fn create_swap(ctx: Context<CreateSwap>, expires_at: i64) -> Result<()> {
        let clock = Clock::get()?;
        require!(expires_at > clock.unix_timestamp, MarketplaceError::InvalidEndTime);

        let swap = &mut ctx.accounts.swap;
        swap.initiator = ctx.accounts.initiator.key();
        swap.initiator_mint = ctx.accounts.initiator_nft_mint.key();
        swap.receiver = ctx.accounts.receiver.key();
        swap.receiver_mint = ctx.accounts.receiver_nft_mint.key();
        swap.created_at = clock.unix_timestamp;
        swap.expires_at = expires_at;
        swap.active = true;
        swap.bump = ctx.bumps.swap;

        token::transfer(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.initiator_nft_account.to_account_info(),
                    to: ctx.accounts.initiator_vault.to_account_info(),
                    authority: ctx.accounts.initiator.to_account_info(),
                },
            ),
            1,
        )?;

        emit!(SwapCreated {
            swap: swap.key(),
            initiator: ctx.accounts.initiator.key(),
            receiver: ctx.accounts.receiver.key(),
        });

        Ok(())
    }

    pub fn execute_swap(ctx: Context<ExecuteSwap>) -> Result<()> {
        let swap = &mut ctx.accounts.swap;
        require!(swap.active, MarketplaceError::SwapNotActive);
        require!(
            swap.receiver == ctx.accounts.receiver.key(),
            MarketplaceError::Unauthorized
        );
        require!(
            swap.receiver_mint == ctx.accounts.receiver_nft_mint.key(),
            MarketplaceError::MintMismatch
        );

        let clock = Clock::get()?;
        require!(swap.expires_at > clock.unix_timestamp, MarketplaceError::SwapExpired);

        swap.active = false;

        let seeds = &[
            b"initiator_vault",
            swap.initiator_mint.as_ref(),
            &[swap.bump],
        ];
        let signer = &[&seeds[..]];

        token::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.initiator_vault.to_account_info(),
                    to: ctx.accounts.receiver_nft_account.to_account_info(),
                    authority: ctx.accounts.initiator_vault.to_account_info(),
                },
                signer,
            ),
            1,
        )?;

        token::transfer(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.receiver_nft_account_source.to_account_info(),
                    to: ctx.accounts.initiator_nft_account.to_account_info(),
                    authority: ctx.accounts.receiver.to_account_info(),
                },
            ),
            1,
        )?;

        emit!(SwapExecuted {
            swap: swap.key(),
            initiator: swap.initiator,
            receiver: swap.receiver,
        });

        Ok(())
    }

    pub fn cancel_swap(ctx: Context<CancelSwap>) -> Result<()> {
        let swap = &mut ctx.accounts.swap;
        require!(swap.active, MarketplaceError::SwapNotActive);
        require!(
            swap.initiator == ctx.accounts.initiator.key(),
            MarketplaceError::Unauthorized
        );

        swap.active = false;

        let seeds = &[
            b"initiator_vault",
            swap.initiator_mint.as_ref(),
            &[swap.bump],
        ];
        let signer = &[&seeds[..]];

        token::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.initiator_vault.to_account_info(),
                    to: ctx.accounts.initiator_nft_account.to_account_info(),
                    authority: ctx.accounts.initiator_vault.to_account_info(),
                },
                signer,
            ),
            1,
        )?;

        emit!(SwapCancelled {
            swap: swap.key(),
            initiator: ctx.accounts.initiator.key(),
        });

        Ok(())
    }

    // ─── Bundle Sales ───────────────────────────────────────────────

    pub fn create_bundle(
        ctx: Context<CreateBundle>,
        price: u64,
        name: String,
        expires_at: Option<i64>,
    ) -> Result<()> {
        require!(price > 0, MarketplaceError::InvalidPrice);
        require!(name.len() <= 64, MarketplaceError::NameTooLong);

        let bundle = &mut ctx.accounts.bundle;
        bundle.seller = ctx.accounts.seller.key();
        bundle.name = name;
        bundle.price = price;
        bundle.created_at = Clock::get()?.unix_timestamp;
        bundle.expires_at = expires_at;
        bundle.active = true;
        bundle.bump = ctx.bumps.bundle;
        bundle.item_count = ctx.accounts.nft_mints.len() as u32;

        for (i, mint) in ctx.accounts.nft_mints.iter().enumerate() {
            if i < 10 {
                bundle.mints[i] = *mint;
            }
        }

        for (vault, _mint) in ctx.accounts.nft_vaults.iter().zip(ctx.accounts.nft_mints.iter()) {
            let vault_data = &mut vault.data;
        }

        emit!(BundleCreated {
            seller: ctx.accounts.seller.key(),
            name: bundle.name.clone(),
            price,
        });

        Ok(())
    }

    pub fn buy_bundle(ctx: Context<BuyBundle>) -> Result<()> {
        let bundle = &mut ctx.accounts.bundle;
        require!(bundle.active, MarketplaceError::ListingNotActive);

        if let Some(exp) = bundle.expires_at {
            let clock = Clock::get()?;
            require!(exp > clock.unix_timestamp, MarketplaceError::ListingExpired);
        }

        bundle.active = false;

        let marketplace = &mut ctx.accounts.marketplace;
        marketplace.volume_traded += bundle.price;

        let marketplace_fee = (bundle.price as u128)
            .checked_mul(marketplace.fee_basis_points as u128)
            .unwrap()
            .checked_div(10000)
            .unwrap() as u64;

        let seller_proceeds = bundle.price.checked_sub(marketplace_fee).unwrap();

        token::transfer(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.buyer_token_account.to_account_info(),
                    to: ctx.accounts.seller_token_account.to_account_info(),
                    authority: ctx.accounts.buyer.to_account_info(),
                },
            ),
            seller_proceeds,
        )?;

        if marketplace_fee > 0 {
            token::transfer(
                CpiContext::new(
                    ctx.accounts.token_program.to_account_info(),
                    Transfer {
                        from: ctx.accounts.buyer_token_account.to_account_info(),
                        to: ctx.accounts.fee_recipient_token_account.to_account_info(),
                        authority: ctx.accounts.buyer.to_account_info(),
                    },
                ),
                marketplace_fee,
            )?;
        }

        emit!(BundleSold {
            seller: bundle.seller,
            buyer: ctx.accounts.buyer.key(),
            price: bundle.price,
        });

        Ok(())
    }

    // ─── NFT Lending ────────────────────────────────────────────────

    pub fn create_loan(
        ctx: Context<CreateLoan>,
        loan_amount: u64,
        interest_rate: u16,
        duration_seconds: i64,
    ) -> Result<()> {
        require!(loan_amount > 0, MarketplaceError::InvalidPrice);
        require!(interest_rate <= 5000, MarketplaceError::InvalidInterestRate);
        require!(duration_seconds > 0, MarketplaceError::InvalidDuration);

        let loan = &mut ctx.accounts.loan;
        loan.borrower = ctx.accounts.borrower.key();
        loan.nft_mint = ctx.accounts.nft_mint.key();
        loan.loan_amount = loan_amount;
        loan.interest_rate = interest_rate;
        loan.duration_seconds = duration_seconds;
        loan.created_at = Clock::get()?.unix_timestamp;
        loan.repay_by = Clock::get()?.unix_timestamp + duration_seconds;
        loan.active = true;
        loan.repaid = false;
        loan.liquidated = false;
        loan.lender = Pubkey::default();
        loan.bump = ctx.bumps.loan;

        let nft_vault = &mut ctx.accounts.nft_vault;
        nft_vault.listing = loan.key();
        nft_vault.mint = ctx.accounts.nft_mint.key();
        nft_vault.bump = ctx.bumps.nft_vault;

        token::transfer(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.borrower_nft_account.to_account_info(),
                    to: ctx.accounts.nft_vault.to_account_info(),
                    authority: ctx.accounts.borrower.to_account_info(),
                },
            ),
            1,
        )?;

        emit!(LoanCreated {
            borrower: ctx.accounts.borrower.key(),
            nft_mint: ctx.accounts.nft_mint.key(),
            loan_amount,
            interest_rate,
            duration_seconds,
        });

        Ok(())
    }

    pub fn fund_loan(ctx: Context<FundLoan>) -> Result<()> {
        let loan = &mut ctx.accounts.loan;
        require!(loan.active, MarketplaceError::LoanNotActive);
        require!(!loan.repaid, MarketplaceError::LoanRepaid);
        require!(
            loan.lender == Pubkey::default(),
            MarketplaceError::LoanAlreadyFunded
        );

        loan.lender = ctx.accounts.lender.key();

        token::transfer(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.lender_token_account.to_account_info(),
                    to: ctx.accounts.borrower_token_account.to_account_info(),
                    authority: ctx.accounts.lender.to_account_info(),
                },
            ),
            loan.loan_amount,
        )?;

        emit!(LoanFunded {
            loan: loan.key(),
            lender: ctx.accounts.lender.key(),
            amount: loan.loan_amount,
        });

        Ok(())
    }

    pub fn repay_loan(ctx: Context<RepayLoan>) -> Result<()> {
        let loan = &mut ctx.accounts.loan;
        require!(loan.active, MarketplaceError::LoanNotActive);
        require!(!loan.repaid, MarketplaceError::LoanRepaid);
        require!(
            loan.borrower == ctx.accounts.borrower.key(),
            MarketplaceError::Unauthorized
        );

        let clock = Clock::get()?;
        require!(clock.unix_timestamp <= loan.repay_by, MarketplaceError::LoanOverdue);

        loan.repaid = true;
        loan.active = false;

        let interest = (loan.loan_amount as u128)
            .checked_mul(loan.interest_rate as u128)
            .unwrap()
            .checked_div(10000)
            .unwrap() as u64;

        let total_repayment = loan.loan_amount.checked_add(interest).unwrap();

        token::transfer(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.borrower_token_account.to_account_info(),
                    to: ctx.accounts.lender_token_account.to_account_info(),
                    authority: ctx.accounts.borrower.to_account_info(),
                },
            ),
            total_repayment,
        )?;

        let seeds = &[
            b"nft_vault",
            loan.nft_mint.as_ref(),
            &[loan.bump],
        ];
        let signer = &[&seeds[..]];

        token::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.nft_vault.to_account_info(),
                    to: ctx.accounts.borrower_nft_account.to_account_info(),
                    authority: ctx.accounts.nft_vault.to_account_info(),
                },
                signer,
            ),
            1,
        )?;

        emit!(LoanRepaid {
            loan: loan.key(),
            borrower: ctx.accounts.borrower.key(),
            amount: total_repayment,
        });

        Ok(())
    }

    pub fn liquidate_loan(ctx: Context<LiquidateLoan>) -> Result<()> {
        let loan = &mut ctx.accounts.loan;
        require!(loan.active, MarketplaceError::LoanNotActive);
        require!(!loan.repaid, MarketplaceError::LoanRepaid);
        require!(
            loan.lender == ctx.accounts.lender.key(),
            MarketplaceError::Unauthorized
        );

        let clock = Clock::get()?;
        require!(clock.unix_timestamp > loan.repay_by, MarketplaceError::LoanNotOverdue);

        loan.liquidated = true;
        loan.active = false;

        let seeds = &[
            b"nft_vault",
            loan.nft_mint.as_ref(),
            &[loan.bump],
        ];
        let signer = &[&seeds[..]];

        token::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.nft_vault.to_account_info(),
                    to: ctx.accounts.lender_nft_account.to_account_info(),
                    authority: ctx.accounts.nft_vault.to_account_info(),
                },
                signer,
            ),
            1,
        )?;

        emit!(LoanLiquidated {
            loan: loan.key(),
            lender: ctx.accounts.lender.key(),
            nft_mint: loan.nft_mint,
        });

        Ok(())
    }

    // ─── Fractional Ownership ───────────────────────────────────────

    pub fn fractionalize(
        ctx: Context<Fractionalize>,
        total_shares: u64,
        share_price: u64,
    ) -> Result<()> {
        require!(total_shares > 0, MarketplaceError::InvalidAmount);
        require!(share_price > 0, MarketplaceError::InvalidPrice);

        let fractional = &mut ctx.accounts.fractional;
        fractional.nft_mint = ctx.accounts.nft_mint.key();
        fractional.owner = ctx.accounts.owner.key();
        fractional.total_shares = total_shares;
        fractional.available_shares = total_shares;
        fractional.share_price = share_price;
        fractional.active = true;
        fractional.bump = ctx.bumps.fractional;

        let nft_vault = &mut ctx.accounts.nft_vault;
        nft_vault.listing = fractional.key();
        nft_vault.mint = ctx.accounts.nft_mint.key();
        nft_vault.bump = ctx.bumps.nft_vault;

        token::transfer(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.owner_nft_account.to_account_info(),
                    to: ctx.accounts.nft_vault.to_account_info(),
                    authority: ctx.accounts.owner.to_account_info(),
                },
            ),
            1,
        )?;

        emit!(NFTFractionalized {
            nft_mint: ctx.accounts.nft_mint.key(),
            owner: ctx.accounts.owner.key(),
            total_shares,
        });

        Ok(())
    }

    pub fn buy_shares(ctx: Context<BuyShares>, amount: u64) -> Result<()> {
        require!(amount > 0, MarketplaceError::InvalidAmount);

        let fractional = &mut ctx.accounts.fractional;
        require!(fractional.active, MarketplaceError::ListingNotActive);
        require!(
            amount <= fractional.available_shares,
            MarketplaceError::InsufficientShares
        );

        fractional.available_shares = fractional
            .available_shares
            .checked_sub(amount)
            .unwrap();

        let total_cost = (amount as u128)
            .checked_mul(fractional.share_price as u128)
            .unwrap() as u64;

        token::transfer(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.buyer_token_account.to_account_info(),
                    to: ctx.accounts.owner_token_account.to_account_info(),
                    authority: ctx.accounts.buyer.to_account_info(),
                },
            ),
            total_cost,
        )?;

        emit!(SharesBought {
            fractional: fractional.key(),
            buyer: ctx.accounts.buyer.key(),
            amount,
            price: total_cost,
        });

        Ok(())
    }

    // ─── Rarity / Metadata ──────────────────────────────────────────

    pub fn update_rarity_score(
        ctx: Context<UpdateRarityScore>,
        score: u32,
        rank: u32,
    ) -> Result<()> {
        let rarity = &mut ctx.accounts.rarity;
        rarity.nft_mint = ctx.accounts.nft_mint.key();
        rarity.collection = ctx.accounts.collection.key();
        rarity.score = score;
        rarity.rank = rank;
        rarity.bump = ctx.bumps.rarity;

        emit!(RarityUpdated {
            nft_mint: ctx.accounts.nft_mint.key(),
            score,
            rank,
        });

        Ok(())
    }
}
