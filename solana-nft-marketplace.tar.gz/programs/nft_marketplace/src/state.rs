use anchor_lang::prelude::*;

#[account]
pub struct Marketplace {
    pub authority: Pubkey,
    pub name: String,
    pub fee_basis_points: u16,
    pub fee_recipient: Pubkey,
    pub bump: u8,
    pub collection_count: u64,
    pub listing_count: u64,
    pub volume_traded: u64,
}

impl Marketplace {
    pub const LEN: usize = 8 + 32 + (4 + 64) + 2 + 32 + 1 + 8 + 8 + 8;
}

#[account]
pub struct Collection {
    pub mint: Pubkey,
    pub authority: Pubkey,
    pub marketplace: Pubkey,
    pub name: String,
    pub royalty_basis_points: u16,
    pub verified: bool,
    pub bump: u8,
    pub item_count: u64,
    pub floor_price: u64,
    pub total_volume: u64,
}

impl Collection {
    pub const LEN: usize = 8 + 32 + 32 + 32 + (4 + 64) + 2 + 1 + 1 + 8 + 8 + 8;
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq, Eq, Debug)]
pub enum ListingType {
    FixedPrice,
    Auction,
}

#[account]
pub struct Listing {
    pub seller: Pubkey,
    pub nft_mint: Pubkey,
    pub collection: Pubkey,
    pub price: u64,
    pub listed_at: i64,
    pub expires_at: Option<i64>,
    pub active: bool,
    pub listing_type: ListingType,
    pub bump: u8,
    pub token_account: Pubkey,
}

impl Listing {
    pub const LEN: usize = 8 + 32 + 32 + 32 + 8 + 8 + (1 + 8) + 1 + (1 + 1) + 1 + 32;
}

#[account]
pub struct Auction {
    pub listing: Pubkey,
    pub min_bid: u64,
    pub reserve_price: u64,
    pub ends_at: i64,
    pub highest_bid: u64,
    pub highest_bidder: Pubkey,
    pub bid_count: u32,
    pub ended: bool,
    pub bump: u8,
}

impl Auction {
    pub const LEN: usize = 8 + 32 + 8 + 8 + 8 + 8 + 32 + 4 + 1 + 1;
}

#[account]
pub struct Offer {
    pub buyer: Pubkey,
    pub nft_mint: Pubkey,
    pub price: u64,
    pub created_at: i64,
    pub expires_at: i64,
    pub active: bool,
    pub bump: u8,
}

impl Offer {
    pub const LEN: usize = 8 + 32 + 32 + 8 + 8 + 8 + 1 + 1;
}

#[account]
pub struct NftVault {
    pub listing: Pubkey,
    pub mint: Pubkey,
    pub bump: u8,
}

impl NftVault {
    pub const LEN: usize = 8 + 32 + 32 + 1;
}

#[account]
pub struct Escrow {
    pub listing: Pubkey,
    pub bump: u8,
}

impl Escrow {
    pub const LEN: usize = 8 + 32 + 1;
}

#[account]
pub struct Swap {
    pub initiator: Pubkey,
    pub initiator_mint: Pubkey,
    pub receiver: Pubkey,
    pub receiver_mint: Pubkey,
    pub created_at: i64,
    pub expires_at: i64,
    pub active: bool,
    pub bump: u8,
}

impl Swap {
    pub const LEN: usize = 8 + 32 + 32 + 32 + 32 + 8 + 8 + 1 + 1;
}

#[account]
pub struct Bundle {
    pub seller: Pubkey,
    pub name: String,
    pub price: u64,
    pub created_at: i64,
    pub expires_at: Option<i64>,
    pub active: bool,
    pub bump: u8,
    pub item_count: u32,
    pub mints: [Pubkey; 10],
}

impl Bundle {
    pub const LEN: usize = 8 + 32 + (4 + 64) + 8 + 8 + (1 + 8) + 1 + 1 + 4 + (32 * 10);
}

#[account]
pub struct Loan {
    pub borrower: Pubkey,
    pub lender: Pubkey,
    pub nft_mint: Pubkey,
    pub loan_amount: u64,
    pub interest_rate: u16,
    pub duration_seconds: i64,
    pub created_at: i64,
    pub repay_by: i64,
    pub active: bool,
    pub repaid: bool,
    pub liquidated: bool,
    pub bump: u8,
}

impl Loan {
    pub const LEN: usize = 8 + 32 + 32 + 32 + 8 + 2 + 8 + 8 + 8 + 1 + 1 + 1 + 1;
}

#[account]
pub struct Fractional {
    pub nft_mint: Pubkey,
    pub owner: Pubkey,
    pub total_shares: u64,
    pub available_shares: u64,
    pub share_price: u64,
    pub active: bool,
    pub bump: u8,
}

impl Fractional {
    pub const LEN: usize = 8 + 32 + 32 + 8 + 8 + 8 + 1 + 1;
}

#[account]
pub struct Rarity {
    pub nft_mint: Pubkey,
    pub collection: Pubkey,
    pub score: u32,
    pub rank: u32,
    pub bump: u8,
}

impl Rarity {
    pub const LEN: usize = 8 + 32 + 32 + 4 + 4 + 1;
}

#[event]
pub struct MarketplaceCreated {
    pub authority: Pubkey,
    pub name: String,
}

#[event]
pub struct MarketplaceUpdated {
    pub authority: Pubkey,
}

#[event]
pub struct CollectionRegistered {
    pub collection_mint: Pubkey,
    pub name: String,
}

#[event]
pub struct CollectionVerified {
    pub collection_mint: Pubkey,
    pub authority: Pubkey,
}

#[event]
pub struct NFTListed {
    pub mint: Pubkey,
    pub seller: Pubkey,
    pub price: u64,
    pub listing_type: ListingType,
}

#[event]
pub struct NFTDelisted {
    pub mint: Pubkey,
    pub seller: Pubkey,
}

#[event]
pub struct NFTSold {
    pub mint: Pubkey,
    pub seller: Pubkey,
    pub buyer: Pubkey,
    pub price: u64,
}

#[event]
pub struct BatchPurchase {
    pub buyer: Pubkey,
    pub count: u64,
    pub total_price: u64,
}

#[event]
pub struct AuctionCreated {
    pub mint: Pubkey,
    pub seller: Pubkey,
    pub min_bid: u64,
    pub ends_at: i64,
}

#[event]
pub struct BidPlaced {
    pub auction: Pubkey,
    pub bidder: Pubkey,
    pub amount: u64,
}

#[event]
pub struct AuctionSettled {
    pub mint: Pubkey,
    pub winner: Pubkey,
    pub amount: u64,
}

#[event]
pub struct OfferMade {
    pub mint: Pubkey,
    pub buyer: Pubkey,
    pub price: u64,
}

#[event]
pub struct OfferAccepted {
    pub mint: Pubkey,
    pub seller: Pubkey,
    pub buyer: Pubkey,
    pub price: u64,
}

#[event]
pub struct OfferCancelled {
    pub mint: Pubkey,
    pub buyer: Pubkey,
}

#[event]
pub struct SwapCreated {
    pub swap: Pubkey,
    pub initiator: Pubkey,
    pub receiver: Pubkey,
}

#[event]
pub struct SwapExecuted {
    pub swap: Pubkey,
    pub initiator: Pubkey,
    pub receiver: Pubkey,
}

#[event]
pub struct SwapCancelled {
    pub swap: Pubkey,
    pub initiator: Pubkey,
}

#[event]
pub struct BundleCreated {
    pub seller: Pubkey,
    pub name: String,
    pub price: u64,
}

#[event]
pub struct BundleSold {
    pub seller: Pubkey,
    pub buyer: Pubkey,
    pub price: u64,
}

#[event]
pub struct LoanCreated {
    pub borrower: Pubkey,
    pub nft_mint: Pubkey,
    pub loan_amount: u64,
    pub interest_rate: u16,
    pub duration_seconds: i64,
}

#[event]
pub struct LoanFunded {
    pub loan: Pubkey,
    pub lender: Pubkey,
    pub amount: u64,
}

#[event]
pub struct LoanRepaid {
    pub loan: Pubkey,
    pub borrower: Pubkey,
    pub amount: u64,
}

#[event]
pub struct LoanLiquidated {
    pub loan: Pubkey,
    pub lender: Pubkey,
    pub nft_mint: Pubkey,
}

#[event]
pub struct NFTFractionalized {
    pub nft_mint: Pubkey,
    pub owner: Pubkey,
    pub total_shares: u64,
}

#[event]
pub struct SharesBought {
    pub fractional: Pubkey,
    pub buyer: Pubkey,
    pub amount: u64,
    pub price: u64,
}

#[event]
pub struct RarityUpdated {
    pub nft_mint: Pubkey,
    pub score: u32,
    pub rank: u32,
}
