// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "@fhenixprotocol/cofhe-contracts/FHE.sol";

contract EncryptedCounter {
    euint32 private count;
    address public owner;

    event CounterIncremented();
    event CounterDecremented();
    event CounterReset();
    event CountRevealed(uint32 value);

    constructor() {
        owner = msg.sender;
        count = FHE.asEuint32(0);
        FHE.allowThis(count);
    }

    function increment(InEuint32 memory encryptedAmount) external {
        euint32 amount = FHE.asEuint32(encryptedAmount);
        euint32 newCount = FHE.add(count, amount);
        FHE.allowThis(newCount);
        count = newCount;
        emit CounterIncremented();
    }

    function decrement(InEuint32 memory encryptedAmount) external {
        euint32 amount = FHE.asEuint32(encryptedAmount);
        euint32 newCount = FHE.sub(count, amount);
        FHE.allowThis(newCount);
        count = newCount;
        emit CounterDecremented();
    }

    function reset() external {
        require(msg.sender == owner, "Only owner can reset");
        count = FHE.asEuint32(0);
        FHE.allowThis(count);
        emit CounterReset();
    }

    function getCount() external view returns (euint32) {
        return count;
    }

    function revealCount(euint32 ctHash, uint32 plaintext, bytes calldata signature) external {
        FHE.publishDecryptResult(ctHash, plaintext, signature);
        emit CountRevealed(plaintext);
    }
}
