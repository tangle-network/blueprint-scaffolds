// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "@fhenixprotocol/cofhe-contracts/FHE.sol";

contract PrivateVoting {
    struct Proposal {
        string name;
        euint32 voteCount;
        bool isActive;
    }

    address public admin;
    Proposal[] public proposals;
    mapping(address => bool) public hasVoted;
    mapping(address => uint256) public voterChoice;
    uint32[] public revealedResults;
    bool public votingOpen;
    uint256 public totalVoters;

    event VoteCast(address indexed voter);
    event VotingOpened(uint256 proposalCount);
    event VotingClosed();
    event ResultsRevealed(uint32[] results);

    constructor(string[] memory proposalNames) {
        admin = msg.sender;
        votingOpen = false;
        totalVoters = 0;

        for (uint256 i = 0; i < proposalNames.length; i++) {
            euint32 zeroCount = FHE.asEuint32(0);
            FHE.allowThis(zeroCount);
            proposals.push(
                Proposal({
                    name: proposalNames[i],
                    voteCount: zeroCount,
                    isActive: true
                })
            );
        }
    }

    function openVoting() external {
        require(msg.sender == admin, "Only admin can open voting");
        votingOpen = true;
        emit VotingOpened(proposals.length);
    }

    function castVote(uint256 proposalIndex) external {
        require(votingOpen, "Voting is not open");
        require(!hasVoted[msg.sender], "Already voted");
        require(proposalIndex < proposals.length, "Invalid proposal");

        hasVoted[msg.sender] = true;
        voterChoice[msg.sender] = proposalIndex;
        totalVoters++;

        euint32 one = FHE.asEuint32(1);
        euint32 newCount = FHE.add(proposals[proposalIndex].voteCount, one);
        FHE.allowThis(newCount);
        proposals[proposalIndex].voteCount = newCount;

        emit VoteCast(msg.sender);
    }

    function castEncryptedVote(InEuint32 memory encryptedChoice) external {
        require(votingOpen, "Voting is not open");
        require(!hasVoted[msg.sender], "Already voted");

        euint32 choice = FHE.asEuint32(encryptedChoice);

        hasVoted[msg.sender] = true;
        totalVoters++;

        for (uint256 i = 0; i < proposals.length; i++) {
            euint32 index = FHE.asEuint32(i);
            ebool isSelected = FHE.eq(choice, index);

            euint32 increment = FHE.select(isSelected, FHE.asEuint32(1), FHE.asEuint32(0));
            euint32 newCount = FHE.add(proposals[i].voteCount, increment);
            FHE.allowThis(newCount);
            proposals[i].voteCount = newCount;
        }

        emit VoteCast(msg.sender);
    }

    function closeVoting() external {
        require(msg.sender == admin, "Only admin can close voting");
        require(votingOpen, "Voting is not open");
        votingOpen = false;

        for (uint256 i = 0; i < proposals.length; i++) {
            FHE.allowPublic(proposals[i].voteCount);
        }

        emit VotingClosed();
    }

    function revealResults(
        uint256[] calldata proposalIndices,
        uint32[] calldata plaintexts,
        bytes[] calldata signatures
    ) external {
        require(!votingOpen, "Voting must be closed");
        require(
            proposalIndices.length == plaintexts.length &&
            plaintexts.length == signatures.length,
            "Array length mismatch"
        );

        delete revealedResults;

        for (uint256 i = 0; i < proposalIndices.length; i++) {
            uint256 idx = proposalIndices[i];
            require(idx < proposals.length, "Invalid proposal index");

            FHE.publishDecryptResult(
                proposals[idx].voteCount,
                plaintexts[i],
                signatures[i]
            );

            revealedResults.push(plaintexts[i]);
        }

        emit ResultsRevealed(revealedResults);
    }

    function getProposalCount() external view returns (uint256) {
        return proposals.length;
    }

    function getProposalVoteCount(uint256 index) external view returns (euint32) {
        require(index < proposals.length, "Invalid index");
        return proposals[index].voteCount;
    }
}
