// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "@fhenixprotocol/cofhe-contracts/FHE.sol";

contract EncryptedAuction {
    euint64 public highestBid;
    address public highestBidder;
    address public auctioneer;
    bool public auctionClosed;
    uint64 public winningBid;

    event BidPlaced(address indexed bidder);
    event AuctionClosed();
    event RevealedWinningBid(address indexed winner, uint64 amount);

    modifier onlyAuctioneer() {
        require(msg.sender == auctioneer, "Only auctioneer can call this");
        _;
    }

    constructor() {
        auctioneer = msg.sender;
    }

    function placeBid(InEuint64 memory encryptedBid) external {
        require(!auctionClosed, "Auction is closed");

        euint64 bid = FHE.asEuint64(encryptedBid);
        ebool isHigher = FHE.gt(bid, highestBid);

        euint64 newHighestBid = FHE.select(isHigher, bid, highestBid);
        FHE.allowThis(newHighestBid);

        highestBid = newHighestBid;
        highestBidder = msg.sender;

        emit BidPlaced(msg.sender);
    }

    function closeBidding() external onlyAuctioneer {
        require(!auctionClosed, "Auction already closed");

        FHE.allowPublic(highestBid);
        auctionClosed = true;

        emit AuctionClosed();
    }

    function revealWinner(
        euint64 ctHash,
        uint64 plaintext,
        bytes calldata signature
    ) external {
        require(auctionClosed, "Auction must be closed first");

        FHE.publishDecryptResult(ctHash, plaintext, signature);

        winningBid = plaintext;
        emit RevealedWinningBid(highestBidder, plaintext);
    }
}
