import type { Metadata } from "next";
import "./globals.css";
import { Sidebar } from "@/components/sidebar";

export const metadata: Metadata = {
  title: "Fhenix FHE Tutorial",
  description: "Interactive tutorial on Fully Homomorphic Encryption with Fhenix",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen bg-background font-mono antialiased">
        <div className="flex min-h-screen">
          <Sidebar />
          <main className="flex-1 overflow-y-auto">
            <div className="container max-w-4xl py-10 mx-auto">{children}</div>
          </main>
        </div>
      </body>
    </html>
  );
}
