import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { Sidebar } from "@/components/sidebar"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Fhenix FHE Tutorial - Learn Privacy-Preserving Smart Contracts",
  description: "Interactive tutorial covering Fully Homomorphic Encryption on Fhenix, encrypted types, FHE operations, and hands-on contract development.",
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className={inter.className}>
        <Sidebar />
        <main className="ml-72 min-h-screen">
          <div className="mx-auto max-w-4xl px-8 py-12">
            {children}
          </div>
        </main>
      </body>
    </html>
  )
}
