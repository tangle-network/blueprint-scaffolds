import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Shield, Rocket, Binary, Lock, ArrowRightLeft, Vote } from "lucide-react";

const chapters = [
  {
    href: "/tutorial/introduction",
    title: "Introduction to FHE",
    desc: "What is Fully Homomorphic Encryption and why it matters for blockchain privacy",
    icon: Shield,
  },
  {
    href: "/tutorial/getting-started",
    title: "Getting Started",
    desc: "Setting up your Fhenix development environment and the cofhe.js SDK",
    icon: Rocket,
  },
  {
    href: "/tutorial/encrypted-types",
    title: "Encrypted Types",
    desc: "euint8, euint16, ebool, eaddress and type conversion",
    icon: Binary,
  },
  {
    href: "/tutorial/fhe-operations",
    title: "FHE Operations",
    desc: "Arithmetic, comparison, bitwise, and conditional operations on encrypted data",
    icon: Lock,
  },
  {
    href: "/tutorial/encryption-decryption",
    title: "Encryption & Decryption",
    desc: "Encrypting inputs, managing permits, and decrypting results",
    icon: ArrowRightLeft,
  },
  {
    href: "/tutorial/hands-on",
    title: "Hands-on: Private Voting",
    desc: "Build a private voting contract with encrypted vote casting and tallying",
    icon: Vote,
  },
];

export default function HomePage() {
  return (
    <div>
      <div className="mb-10">
        <h1 className="text-4xl font-bold tracking-tight mb-3">
          Fhenix FHE Tutorial
        </h1>
        <p className="text-lg text-muted-foreground max-w-2xl">
          Learn how to build privacy-preserving smart contracts using Fully
          Homomorphic Encryption on Fhenix. This interactive tutorial covers
          everything from FHE fundamentals to deploying your first confidential
          contract.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {chapters.map((ch) => {
          const Icon = ch.icon;
          return (
            <Link key={ch.href} href={ch.href}>
              <Card className="h-full hover:border-primary/50 transition-colors cursor-pointer">
                <CardHeader>
                  <Icon className="h-8 w-8 text-primary mb-2" />
                  <CardTitle className="text-lg">{ch.title}</CardTitle>
                  <CardDescription>{ch.desc}</CardDescription>
                </CardHeader>
              </Card>
            </Link>
          );
        })}
      </div>

      <div className="mt-10 flex items-center gap-4">
        <Link href="/tutorial/introduction">
          <Button size="lg">
            Start Tutorial
          </Button>
        </Link>
        <span className="text-sm text-muted-foreground">6 chapters</span>
      </div>
    </div>
  );
}
