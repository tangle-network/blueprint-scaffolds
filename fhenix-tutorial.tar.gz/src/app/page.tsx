import Link from "next/link"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { BookOpen, Rocket, Lock, Cpu, Key, Vote, ArrowRight, Shield } from "lucide-react"

const chapters = [
  {
    href: "/introduction",
    title: "Introduction to FHE",
    description: "Understand Fully Homomorphic Encryption, why it matters for blockchain privacy, and the Fhenix architecture.",
    icon: BookOpen,
    badge: "Chapter 1",
  },
  {
    href: "/getting-started",
    title: "Getting Started",
    description: "Set up your Fhenix development environment, install fhenix.js, and configure Hardhat for FHE development.",
    icon: Rocket,
    badge: "Chapter 2",
  },
  {
    href: "/encrypted-types",
    title: "Encrypted Types",
    description: "Learn about euint8, euint16, euint32, euint64, euint128, euint256, ebool, and eaddress types.",
    icon: Lock,
    badge: "Chapter 3",
  },
  {
    href: "/fhe-operations",
    title: "FHE Operations",
    description: "Perform arithmetic, comparison, conditional, and bitwise operations on encrypted data.",
    icon: Cpu,
    badge: "Chapter 4",
  },
  {
    href: "/encryption-decryption",
    title: "Encryption & Decryption",
    description: "Encrypt values client-side, manage decryption permits, and implement re-encryption for secure viewing.",
    icon: Key,
    badge: "Chapter 5",
  },
  {
    href: "/hands-on",
    title: "Hands-on: Private Voting",
    description: "Build a complete private voting contract with encrypted vote casting, tallies, and secure result revelation.",
    icon: Vote,
    badge: "Chapter 6",
  },
]

export default function Home() {
  return (
    <div>
      <div className="mb-12 text-center">
        <div className="mb-4 flex items-center justify-center gap-3">
          <Shield className="h-12 w-12 text-primary" />
          <h1 className="text-4xl font-bold">Fhenix FHE Tutorial</h1>
        </div>
        <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
          Learn how to add privacy to your smart contracts using Fully Homomorphic Encryption on Fhenix.
          This interactive tutorial covers everything from FHE fundamentals to building production-ready private applications.
        </p>
        <div className="mt-6 flex justify-center gap-4">
          <Link href="/introduction">
            <Button size="lg" className="gap-2">
              Start Learning <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {chapters.map((chapter) => {
          const Icon = chapter.icon
          return (
            <Link key={chapter.href} href={chapter.href}>
              <Card className="h-full transition-colors hover:border-primary/50 hover:bg-card/80 cursor-pointer">
                <CardHeader>
                  <div className="mb-2 flex items-center justify-between">
                    <Icon className="h-8 w-8 text-primary" />
                    <Badge variant="secondary">{chapter.badge}</Badge>
                  </div>
                  <CardTitle className="text-lg">{chapter.title}</CardTitle>
                  <CardDescription>{chapter.description}</CardDescription>
                </CardHeader>
              </Card>
            </Link>
          )
        })}
      </div>
    </div>
  )
}
