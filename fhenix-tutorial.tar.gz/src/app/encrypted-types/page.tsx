import React from "react"
import { ChapterNav } from "@/components/chapter-nav"
import { CodeBlock } from "@/components/code-block"
import { InfoBox } from "@/components/info-box"
import { Playground } from "@/components/playground"
import { Badge } from "@/components/ui/badge"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"

const encryptedTypes = [
  {
    type: "euint8",
    bits: 8,
    range: "0 to 255",
    useCase: "Small counters, flags, enum values, ratings (1-5)",
    gasCost: "Lowest",
  },
  {
    type: "euint16",
    bits: 16,
    range: "0 to 65,535",
    useCase: "Ports, small numeric IDs, percentages",
    gasCost: "Low",
  },
  {
    type: "euint32",
    bits: 32,
    range: "0 to 4,294,967,295",
    useCase: "Token amounts (with decimals), vote counts, scores",
    gasCost: "Medium",
  },
  {
    type: "euint64",
    bits: 64,
    range: "0 to ~1.8 × 10¹⁹",
    useCase: "Large token amounts, timestamps, block numbers",
    gasCost: "Medium-High",
  },
  {
    type: "euint128",
    bits: 128,
    range: "0 to ~3.4 × 10³⁸",
    useCase: "Very large calculations, intermediate values",
    gasCost: "High",
  },
  {
    type: "euint256",
    bits: 256,
    range: "0 to ~1.16 × 10⁷⁷",
    useCase: "Full EVM word size, hash values, max precision",
    gasCost: "Highest",
  },
]

export default function EncryptedTypesPage() {
  return (
    <div>
      <div className="mb-8">
        <Badge className="mb-4">Chapter 3</Badge>
        <h1 className="text-3xl font-bold">Encrypted Types</h1>
        <p className="mt-2 text-lg text-muted-foreground">
          Learn about the encrypted integer, boolean, and address types that Fhenix adds to Solidity.
        </p>
      </div>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">Overview</h2>
        <p className="mb-4 text-muted-foreground">
          Fhenix extends Solidity with encrypted counterpart types for standard data types. These types
          hold ciphertexts — encrypted values that can be operated on homomorphically. They are declared
          using the <code className="text-primary">euint</code> prefix (short for &quot;encrypted uint&quot;).
        </p>
        <p className="mb-4 text-muted-foreground">
          Encrypted types are <strong>not native Solidity types</strong>. They are custom types provided
          by the FHE library. Under the hood, they are handles (references) to ciphertexts stored in the
          FHE coprocessor&apos;s memory.
        </p>

        <InfoBox type="warning" title="Key Concept: Handles, Not Values">
          When you declare <code className="text-primary">euint32 x</code>, the variable <code className="text-primary">x</code> is
          a handle (an ID) pointing to a ciphertext in the FHE coprocessor. The contract never sees the
          plaintext value. Operations on these handles produce new handles pointing to result ciphertexts.
        </InfoBox>
      </section>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">Encrypted Integer Types</h2>
        <p className="mb-4 text-muted-foreground">
          Fhenix provides six encrypted unsigned integer types, mirroring Solidity&apos;s native uint types:
        </p>

        <div className="mb-6 overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-left">
                <th className="pb-2 pr-4 text-muted-foreground">Type</th>
                <th className="pb-2 pr-4 text-muted-foreground">Bits</th>
                <th className="pb-2 pr-4 text-muted-foreground">Range</th>
                <th className="pb-2 pr-4 text-muted-foreground">Use Case</th>
                <th className="pb-2 text-muted-foreground">Gas Cost</th>
              </tr>
            </thead>
            <tbody>
              {encryptedTypes.map((t) => (
                <tr key={t.type} className="border-b border-border/50">
                  <td className="py-3 pr-4 font-mono text-primary">{t.type}</td>
                  <td className="py-3 pr-4">{t.bits}</td>
                  <td className="py-3 pr-4 font-mono text-xs">{t.range}</td>
                  <td className="py-3 pr-4 text-muted-foreground">{t.useCase}</td>
                  <td className="py-3 text-muted-foreground">{t.gasCost}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <CodeBlock
          title="Declaring encrypted integer variables"
          language="solidity"
          code={`// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "fhe/lib/lib.sol";

contract EncryptedIntegers {
    euint8  public smallCounter;
    euint16 public mediumValue;
    euint32 public balance;
    euint64 public largeAmount;
    euint128 public intermediate;
    euint256 public fullWord;

    // Each type occupies storage proportional to its ciphertext size
    // euint8 and euint16 have similar ciphertext sizes (due to FHE padding)
    // euint32 is the "sweet spot" for most use cases
}`}
        />

        <InfoBox type="tip" title="Choosing the Right Type">
          Use the smallest type that fits your needs. <code className="text-primary">euint32</code> is
          the recommended default — it handles most application logic while keeping gas costs reasonable.
          Only step up to <code className="text-primary">euint64</code> or larger when the value range requires it.
        </InfoBox>
      </section>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">ebool — Encrypted Boolean</h2>
        <p className="mb-4 text-muted-foreground">
          <code className="text-primary">ebool</code> represents an encrypted boolean value. It is the
          return type of all FHE comparison operations and is essential for conditional logic.
        </p>
        <CodeBlock
          title="Using ebool"
          language="solidity"
          code={`contract EncryptedBooleans {
    ebool public isActive;
    ebool public hasVoted;

    function checkEligibility(euint32 threshold, euint32 score) public view returns (ebool) {
        // FHE comparisons return ebool
        ebool isAboveThreshold = FHE.gte(score, threshold);

        // ebool can be used in FHE.select for conditional logic
        euint32 result = FHE.select(isAboveThreshold, score, FHE.asEuint32(0));

        return isAboveThreshold;
    }

    // ebool results can be decrypted to reveal true/false
    // but only by authorized users
}`}
        />
      </section>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">eaddress — Encrypted Address</h2>
        <p className="mb-4 text-muted-foreground">
          <code className="text-primary">eaddress</code> represents an encrypted Ethereum address.
          This enables privacy-preserving identity checks, anonymous voting, and confidential transfers.
        </p>
        <CodeBlock
          title="Using eaddress"
          language="solidity"
          code={`contract EncryptedAddresses {
    eaddress public secretOwner;

    function setOwner(bytes calldata encryptedAddr) public {
        // Convert encrypted bytes to eaddress
        secretOwner = FHE.asEaddress(encryptedAddr);
    }

    // Compare encrypted address with a plaintext address
    // Useful for access control without revealing who has access
    function isOwner(address candidate) public view returns (ebool) {
        return FHE.eq(secretOwner, candidate);
    }

    // Use in conditional logic
    function onlyOwnerAction(bytes calldata encryptedInput) public view returns (euint32) {
        ebool ownerCheck = FHE.eq(secretOwner, msg.sender);
        euint32 input = FHE.asEuint32(encryptedInput);

        // If caller is owner, return input; otherwise return 0
        return FHE.select(ownerCheck, input, FHE.asEuint32(0));
    }
}`}
        />
      </section>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">Creating Encrypted Values</h2>
        <p className="mb-4 text-muted-foreground">
          There are three ways to create encrypted values in a Fhenix contract:
        </p>

        <Tabs defaultValue="from-bytes">
          <TabsList>
            <TabsTrigger value="from-bytes">From Encrypted Bytes</TabsTrigger>
            <TabsTrigger value="from-plaintext">From Plaintext</TabsTrigger>
            <TabsTrigger value="from-cast">Type Casting</TabsTrigger>
          </TabsList>
          <TabsContent value="from-bytes">
            <CodeBlock
              title="From client-encrypted bytes"
              language="solidity"
              code={`// Most common: client encrypts value, sends as calldata
function processEncryptedInput(
    bytes calldata encryptedValue
) public {
    // Convert encrypted bytes to an euint type
    euint32 value = FHE.asEuint32(encryptedValue);

    // The contract never sees the plaintext
    // value is a handle to the ciphertext in the FHE coprocessor
}`}
            />
          </TabsContent>
          <TabsContent value="from-plaintext">
            <CodeBlock
              title="From plaintext values"
              language="solidity"
              code={`// Create encrypted values from known plaintext
// Useful for constants, comparisons, and initial values

euint32 zero = FHE.asEuint32(0);          // Encrypted zero
euint32 hundred = FHE.asEuint32(100);     // Encrypted 100
ebool tru = FHE.asEbool(true);            // Encrypted true
eaddress me = FHE.asEaddress(msg.sender); // Encrypted caller`}
            />
          </TabsContent>
          <TabsContent value="from-cast">
            <CodeBlock
              title="Type casting between encrypted types"
              language="solidity"
              code={`// Cast between encrypted types
euint8 small = FHE.asEuint8(42);
euint32 larger = FHE.cast(small);    // euint8 -> euint32 (safe)
euint16 medium = FHE.cast(larger);   // euint32 -> euint16 (may truncate)

// Casting to a smaller type truncates high bits
// euint32(256) cast to euint8 = 0 (truncated)
// Always ensure the value fits the target type`}
            />
          </TabsContent>
        </Tabs>
      </section>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">Storage and Gas Considerations</h2>
        <p className="mb-4 text-muted-foreground">
          Encrypted types consume significantly more storage than their plaintext counterparts
          because ciphertexts are much larger than plaintext values:
        </p>

        <div className="mb-6 grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Plaintext Storage</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li><code className="text-primary">uint8</code> → 1 byte (packed in 32-byte slot)</li>
                <li><code className="text-primary">uint32</code> → 4 bytes (packed in 32-byte slot)</li>
                <li><code className="text-primary">uint256</code> → 32 bytes (1 storage slot)</li>
              </ul>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Encrypted Storage</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li><code className="text-primary">euint8</code> → ~2,048 bytes (ciphertext)</li>
                <li><code className="text-primary">euint32</code> → ~2,048 bytes (ciphertext)</li>
                <li><code className="text-primary">euint256</code> → ~4,096 bytes (ciphertext)</li>
              </ul>
            </CardContent>
          </Card>
        </div>

        <InfoBox type="warning" title="Gas Impact">
          Encrypted types use more gas for storage and operations. A single <code className="text-primary">euint32</code> SSTORE
          can cost 10-100x more than a plaintext <code className="text-primary">uint32</code>. Optimize by using the smallest
          type possible and minimizing unnecessary encrypted state writes.
        </InfoBox>
      </section>

      <Playground
        title="Try It: Encrypted Type Selection"
        description="See how different types are used for different scenarios"
        initialCode={`// Scenario: Building a private auction
contract PrivateAuction {
    // Bid amounts — use euint32 (supports bids up to ~4.3 billion units)
    euint32 public highestBid;

    // Bidder identity — use eaddress for privacy
    eaddress public highestBidder;

    // Auction state — use ebool for encrypted flags
    ebool public auctionEnded;

    // Minimum bid increment — euint8 works if increments are small (0-255)
    euint8 public minIncrement;

    // Reserve price — euint32 for consistency with bid type
    euint32 public reservePrice;
}`}
        expectedOutput={`✓ Types selected for PrivateAuction:
  - highestBid: euint32   (handles realistic bid amounts)
  - highestBidder: eaddress (keeps bidder anonymous)
  - auctionEnded: ebool    (encrypted state flag)
  - minIncrement: euint8   (small increment values)
  - reservePrice: euint32  (matches bid type for comparison)`}
      />

      <ChapterNav currentPath="/encrypted-types" />
    </div>
  )
}
