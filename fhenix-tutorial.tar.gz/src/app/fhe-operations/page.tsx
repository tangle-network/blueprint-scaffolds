import React from "react"
import { ChapterNav } from "@/components/chapter-nav"
import { CodeBlock } from "@/components/code-block"
import { InfoBox } from "@/components/info-box"
import { Playground } from "@/components/playground"
import { Badge } from "@/components/ui/badge"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"

export default function FheOperationsPage() {
  return (
    <div>
      <div className="mb-8">
        <Badge className="mb-4">Chapter 4</Badge>
        <h1 className="text-3xl font-bold">FHE Operations</h1>
        <p className="mt-2 text-lg text-muted-foreground">
          Perform arithmetic, comparison, conditional, and bitwise operations directly on encrypted data.
        </p>
      </div>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">How FHE Operations Work</h2>
        <p className="mb-4 text-muted-foreground">
          All FHE operations are invoked through the <code className="text-primary">FHE</code> library
          imported from <code className="text-primary">fhe/lib/lib.sol</code>. Operations take encrypted
          values (or a mix of encrypted and plaintext) and return new encrypted handles. The plaintext
          results are never exposed to the contract or anyone on-chain.
        </p>

        <InfoBox type="info" title="Operation Syntax">
          Fhenix supports two syntaxes for binary operations:
          <ul className="mt-2 list-disc pl-4">
            <li><strong>Function syntax:</strong> <code className="text-primary">FHE.add(a, b)</code></li>
            <li><strong>Operator syntax:</strong> <code className="text-primary">a + b</code> (overloaded operators)</li>
          </ul>
          Both produce identical results. The function syntax is used throughout this tutorial for clarity.
        </InfoBox>
      </section>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">Arithmetic Operations</h2>
        <p className="mb-4 text-muted-foreground">
          FHE supports the four basic arithmetic operations. Both operands can be encrypted,
          or one can be a plaintext scalar.
        </p>

        <Tabs defaultValue="add-sub">
          <TabsList>
            <TabsTrigger value="add-sub">Add / Sub</TabsTrigger>
            <TabsTrigger value="mul-div">Mul / Div</TabsTrigger>
            <TabsTrigger value="scalar">Scalar Operations</TabsTrigger>
          </TabsList>
          <TabsContent value="add-sub">
            <CodeBlock
              title="Addition and subtraction on encrypted values"
              language="solidity"
              code={`// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "fhe/lib/lib.sol";

contract EncryptedMath {
    euint32 public total;

    // Add two encrypted values
    function addEncrypted(euint32 a, euint32 b) public pure returns (euint32) {
        return FHE.add(a, b);
    }

    // Subtract encrypted values
    // NOTE: underflow wraps around (modular arithmetic), just like uint32
    function subEncrypted(euint32 a, euint32 b) public pure returns (euint32) {
        return FHE.sub(a, b);
    }

    // Accumulate into state
    function addToTotal(bytes calldata encryptedAmount) public {
        euint32 amount = FHE.asEuint32(encryptedAmount);
        total = FHE.add(total, amount);
    }
}`}
            />
          </TabsContent>
          <TabsContent value="mul-div">
            <CodeBlock
              title="Multiplication and division"
              language="solidity"
              code={`contract EncryptedMulDiv {
    // Multiply two encrypted values
    function multiplyEncrypted(euint32 a, euint32 b) public pure returns (euint32) {
        // Result type matches operand types
        // euint32 * euint32 = euint32 (result truncated to euint32 range)
        return FHE.mul(a, b);
    }

    // Divide encrypted by encrypted
    function divideEncrypted(euint32 a, euint32 b) public pure returns (euint32) {
        // Integer division, rounds toward zero
        // Division by zero returns 0 (no revert in FHE — 
        // the contract can't know if b is zero!)
        return FHE.div(a, b);
    }

    // Compute encrypted percentage
    function percentOf(euint32 amount, euint8 pct) public pure returns (euint32) {
        euint32 scaledPct = FHE.mul(amount, FHE.asEuint32(pct));
        return FHE.div(scaledPct, FHE.asEuint32(100));
    }
}`}
            />
            <InfoBox type="warning" title="Division by Zero">
              In regular Solidity, division by zero reverts. In FHE, the contract cannot know whether
              the divisor is zero (it&apos;s encrypted!). FHE division by zero returns 0. Always validate
              divisors before encrypting if this matters for your application logic.
            </InfoBox>
          </TabsContent>
          <TabsContent value="scalar">
            <CodeBlock
              title="Mixed encrypted/plaintext operations"
              language="solidity"
              code={`contract ScalarOps {
    // FHE operations support one plaintext operand
    // This is cheaper than encrypting both operands
    function addScalar(euint32 encrypted, uint32 plain) public pure returns (euint32) {
        return encrypted + plain;  // Operator syntax
    }

    function mulScalar(euint32 encrypted, uint32 plain) public pure returns (euint32) {
        return FHE.mul(encrypted, plain);  // Function syntax
    }

    // Practical example: apply a fee percentage
    function applyFee(euint32 amount) public pure returns (euint32) {
        // Fee is 2.5% → multiply by 25 then divide by 1000
        euint32 withFee = FHE.mul(amount, 25);
        return FHE.div(withFee, 1000);
    }
}`}
            />
          </TabsContent>
        </Tabs>
      </section>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">Comparison Operations</h2>
        <p className="mb-4 text-muted-foreground">
          FHE comparisons work just like Solidity comparisons but return <code className="text-primary">ebool</code> —
          an encrypted boolean. Nobody can see the comparison result.
        </p>

        <div className="mb-4">
          <CodeBlock
            title="All comparison operations"
            language="solidity"
            code={`contract EncryptedComparisons {
    // All comparisons return ebool (encrypted boolean)
    
    function isEqual(euint32 a, euint32 b) public pure returns (ebool) {
        return FHE.eq(a, b);      // a == b
    }

    function notEqual(euint32 a, euint32 b) public pure returns (ebool) {
        return FHE.ne(a, b);      // a != b
    }

    function greaterThan(euint32 a, euint32 b) public pure returns (ebool) {
        return FHE.gt(a, b);      // a > b
    }

    function lessThan(euint32 a, euint32 b) public pure returns (ebool) {
        return FHE.lt(a, b);      // a < b
    }

    function greaterThanOrEqual(euint32 a, euint32 b) public pure returns (ebool) {
        return FHE.gte(a, b);     // a >= b
    }

    function lessThanOrEqual(euint32 a, euint32 b) public pure returns (ebool) {
        return FHE.lte(a, b);     // a <= b
    }

    // Comparisons also work with plaintext values
    function isAboveThreshold(euint32 value) public pure returns (ebool) {
        return FHE.gte(value, 100);  // Compare encrypted with plaintext
    }
}`}
          />
        </div>

        <div className="mb-4 grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Comparison + Scalar</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                You can compare an encrypted value against a plaintext constant.
                <code className="text-primary">FHE.gt(x, 100)</code> checks if encrypted <code className="text-primary">x</code> is
                greater than 100 without revealing <code className="text-primary">x</code>.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">No Short-Circuit</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Unlike Solidity&apos;s <code className="text-primary">&amp;&amp;</code> and <code className="text-primary">||</code>,
                FHE comparisons always evaluate both operands. There&apos;s no short-circuit evaluation
                because the result is encrypted.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">Conditional: select</h2>
        <p className="mb-4 text-muted-foreground">
          <code className="text-primary">FHE.select</code> is the encrypted equivalent of a ternary operator.
          It returns one of two encrypted values based on an encrypted boolean condition — without
          revealing which branch was taken.
        </p>
        <CodeBlock
          title="FHE.select — encrypted branching"
          language="solidity"
          code={`contract EncryptedConditionals {
    // select(condition, valueIfTrue, valueIfFalse)
    function min(euint32 a, euint32 b) public pure returns (euint32) {
        ebool aIsSmaller = FHE.lt(a, b);
        return FHE.select(aIsSmaller, a, b);
    }

    function max(euint32 a, euint32 b) public pure returns (euint32) {
        ebool aIsLarger = FHE.gt(a, b);
        return FHE.select(aIsLarger, a, b);
    }

    // Practical: private auction bid update
    function updateHighestBid(
        euint32 currentBid,
        euint32 newBid
    ) public pure returns (euint32) {
        ebool isNewHighest = FHE.gt(newBid, currentBid);
        return FHE.select(isNewHighest, newBid, currentBid);
    }

    // select works with ebool too
    function selectBool(ebool condition, ebool ifTrue, ebool ifFalse)
        public pure returns (ebool)
    {
        return FHE.select(condition, ifTrue, ifFalse);
    }

    // And with eaddress
    function selectAddress(ebool condition, eaddress ifTrue, eaddress ifFalse)
        public pure returns (eaddress)
    {
        return FHE.select(condition, ifTrue, ifFalse);
    }
}`}
        />

        <InfoBox type="warning" title="Both Branches Execute">
          Unlike a regular <code className="text-primary">if/else</code>, <code className="text-primary">FHE.select</code> evaluates
          <em>both</em> branches (computes both result ciphertexts). This means it always costs the gas of
          computing both paths. There is no &quot;early return&quot; in FHE.
        </InfoBox>
      </section>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">Bitwise Operations</h2>
        <p className="mb-4 text-muted-foreground">
          Fhenix supports standard bitwise operations on encrypted values. These are useful for
          flags, bitmasks, and certain cryptographic operations.
        </p>
        <CodeBlock
          title="Bitwise operations on encrypted values"
          language="solidity"
          code={`contract EncryptedBitwise {
    // AND: useful for checking flags
    function bitwiseAnd(euint32 a, euint32 b) public pure returns (euint32) {
        return FHE.and(a, b);
    }

    // OR: useful for setting flags
    function bitwiseOr(euint32 a, euint32 b) public pure returns (euint32) {
        return FHE.or(a, b);
    }

    // XOR: useful for toggling or simple encryption
    function bitwiseXor(euint32 a, euint32 b) public pure returns (euint32) {
        return FHE.xor(a, b);
    }

    // NOT: complement (unary)
    function bitwiseNot(euint32 a) public pure returns (euint32) {
        return FHE.not(a);
    }

    // Practical: encrypted permission flags
    // Bits represent permissions: 0x1=read, 0x2=write, 0x4=execute
    function hasReadPermission(euint32 permissions) public pure returns (ebool) {
        euint32 result = FHE.and(permissions, FHE.asEuint32(1));
        return FHE.eq(result, FHE.asEuint32(1));
    }

    function grantWritePermission(euint32 permissions) public pure returns (euint32) {
        return FHE.or(permissions, FHE.asEuint32(2));
    }

    // Logical operations on ebool
    function logicalAnd(ebool a, ebool b) public pure returns (ebool) {
        return FHE.and(a, b);
    }

    function logicalOr(ebool a, ebool b) public pure returns (ebool) {
        return FHE.or(a, b);
    }

    function logicalNot(ebool a) public pure returns (ebool) {
        return FHE.not(a);
    }
}`}
        />
      </section>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">Random Number Generation</h2>
        <p className="mb-4 text-muted-foreground">
          Fhenix provides a secure on-chain random number generator that produces encrypted random values.
          Since the result is encrypted, nobody can see the random number — perfect for lotteries, card games,
          and randomized mechanics.
        </p>
        <CodeBlock
          title="Encrypted random numbers"
          language="solidity"
          code={`contract EncryptedRandom {
    // Generate a random euint8 (0-255)
    function randomByte() public view returns (euint8) {
        return FHE.randEuint8();
    }

    // Generate a random euint32
    function randomU32() public view returns (euint32) {
        return FHE.randEuint32();
    }

    // Generate a random ebool (like a coin flip)
    function coinFlip() public view returns (ebool) {
        euint8 r = FHE.randEuint8();
        return FHE.lt(r, FHE.asEuint8(128));  // ~50% chance
    }

    // Random within range (0 to max-1)
    function randomInRange(uint32 max) public view returns (euint32) {
        euint32 r = FHE.randEuint32();
        return FHE.mod(r, FHE.asEuint32(max));
    }
}`}
        />
      </section>

      <Playground
        title="Try It: Encrypted Calculator"
        description="Simulate FHE operations on encrypted values"
        initialCode={`// Simulated FHE Calculator
// Input: a = 42 (encrypted), b = 17 (encrypted)

const a = 42;  // Would be encrypted on-chain
const b = 17;

const results = {
  "FHE.add(a, b)":  a + b,       // 59
  "FHE.sub(a, b)":  a - b,       // 25
  "FHE.mul(a, b)":  a * b,       // 714
  "FHE.div(a, b)":  Math.floor(a / b), // 2
  "FHE.gt(a, b)":   a > b,       // true
  "FHE.eq(a, b)":   a === b,     // false
  "FHE.select(gt, a, b)": a > b ? a : b, // 42
};`}
        expectedOutput={`FHE.add(42, 17) = 59        [encrypted]
FHE.sub(42, 17) = 25        [encrypted]
FHE.mul(42, 17) = 714       [encrypted]
FHE.div(42, 17) = 2         [encrypted]
FHE.gt(42, 17)  = true      [ebool]
FHE.eq(42, 17)  = false     [ebool]
FHE.select(gt, 42, 17) = 42 [encrypted]

Note: On-chain, ALL results remain encrypted.
Nobody can see these values without a decryption permit.`}
      />

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">Operation Summary</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-left">
                <th className="pb-2 pr-4 text-muted-foreground">Category</th>
                <th className="pb-2 pr-4 text-muted-foreground">Operation</th>
                <th className="pb-2 pr-4 text-muted-foreground">Syntax</th>
                <th className="pb-2 text-muted-foreground">Returns</th>
              </tr>
            </thead>
            <tbody>
              {[
                { cat: "Arithmetic", op: "Add", syntax: "FHE.add(a, b)", ret: "euintN" },
                { cat: "Arithmetic", op: "Subtract", syntax: "FHE.sub(a, b)", ret: "euintN" },
                { cat: "Arithmetic", op: "Multiply", syntax: "FHE.mul(a, b)", ret: "euintN" },
                { cat: "Arithmetic", op: "Divide", syntax: "FHE.div(a, b)", ret: "euintN" },
                { cat: "Arithmetic", op: "Modulo", syntax: "FHE.rem(a, b)", ret: "euintN" },
                { cat: "Comparison", op: "Equal", syntax: "FHE.eq(a, b)", ret: "ebool" },
                { cat: "Comparison", op: "Not Equal", syntax: "FHE.ne(a, b)", ret: "ebool" },
                { cat: "Comparison", op: "Greater Than", syntax: "FHE.gt(a, b)", ret: "ebool" },
                { cat: "Comparison", op: "Less Than", syntax: "FHE.lt(a, b)", ret: "ebool" },
                { cat: "Comparison", op: "Greater/Equal", syntax: "FHE.gte(a, b)", ret: "ebool" },
                { cat: "Comparison", op: "Less/Equal", syntax: "FHE.lte(a, b)", ret: "ebool" },
                { cat: "Conditional", op: "Select", syntax: "FHE.select(cond, a, b)", ret: "euintN/ebool/eaddress" },
                { cat: "Bitwise", op: "AND", syntax: "FHE.and(a, b)", ret: "euintN/ebool" },
                { cat: "Bitwise", op: "OR", syntax: "FHE.or(a, b)", ret: "euintN/ebool" },
                { cat: "Bitwise", op: "XOR", syntax: "FHE.xor(a, b)", ret: "euintN/ebool" },
                { cat: "Bitwise", op: "NOT", syntax: "FHE.not(a)", ret: "euintN/ebool" },
                { cat: "Random", op: "Random", syntax: "FHE.randEuintN()", ret: "euintN" },
              ].map((row, i) => (
                <tr key={i} className="border-b border-border/50">
                  <td className="py-2 pr-4 text-muted-foreground">{row.cat}</td>
                  <td className="py-2 pr-4">{row.op}</td>
                  <td className="py-2 pr-4 font-mono text-xs text-primary">{row.syntax}</td>
                  <td className="py-2 font-mono text-xs">{row.ret}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <ChapterNav currentPath="/fhe-operations" />
    </div>
  )
}
