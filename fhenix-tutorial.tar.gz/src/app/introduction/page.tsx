import React from "react"
import { ChapterNav } from "@/components/chapter-nav"
import { CodeBlock } from "@/components/code-block"
import { InfoBox } from "@/components/info-box"
import { Badge } from "@/components/ui/badge"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"

export default function IntroductionPage() {
  return (
    <div>
      <div className="mb-8">
        <Badge className="mb-4">Chapter 1</Badge>
        <h1 className="text-3xl font-bold">Introduction to Fully Homomorphic Encryption</h1>
        <p className="mt-2 text-lg text-muted-foreground">
          Understand what FHE is, why it matters for blockchain privacy, and how Fhenix brings it to Ethereum.
        </p>
      </div>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">What is Fully Homomorphic Encryption?</h2>
        <p className="mb-4 text-muted-foreground">
          Fully Homomorphic Encryption (FHE) is a form of encryption that allows computations to be performed
          directly on ciphertexts. The result, when decrypted, matches the result of operations performed
          on the corresponding plaintexts. This means you can process encrypted data <em>without ever decrypting it</em>.
        </p>
        <p className="mb-4 text-muted-foreground">
          The concept was first proposed by Rivest, Adleman, and Dertouzos in 1978, but remained a theoretical
          curiosity until Craig Gentry constructed the first fully homomorphic encryption scheme in 2009 using
          lattice-based cryptography.
        </p>

        <div className="mb-6 grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Additively Homomorphic</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                E( a ) + E( b ) = E( a + b ) — only addition is supported. Used in many voting systems and
                simple privacy protocols.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Somewhat Homomorphic</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Supports a limited number of both additions and multiplications. Noise accumulates with each
                operation until decryption fails.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Fully Homomorphic</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Supports arbitrary computations (addition, multiplication, comparison) on encrypted data
                with no depth limit, thanks to bootstrapping.
              </p>
            </CardContent>
          </Card>
        </div>

        <InfoBox type="info" title="Key Insight">
          FHE is often called the &quot;holy grail&quot; of cryptography because it enables processing data
          while it remains encrypted. A server can compute on your data without ever seeing it.
        </InfoBox>
      </section>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">Why FHE Matters for Blockchain</h2>
        <p className="mb-4 text-muted-foreground">
          Blockchains are fundamentally public — every transaction, every smart contract state, and every
          variable is visible to anyone who queries the chain. This transparency is a feature for
          verifiability, but a massive problem for privacy-sensitive applications:
        </p>
        <ul className="mb-4 list-disc space-y-2 pl-6 text-muted-foreground">
          <li><strong>DeFi:</strong> Trading strategies and positions are fully visible, enabling front-running and MEV extraction.</li>
          <li><strong>Governance:</strong> Votes are public, leading to voter coercion and herd behavior.</li>
          <li><strong>Identity:</strong> On-chain credentials expose personal information permanently.</li>
          <li><strong>Gaming:</strong> Hidden game state (hands, strategies) is impossible without trusted intermediaries.</li>
        </ul>

        <div className="mb-4">
          <CodeBlock
            title="The Privacy Problem"
            language="solidity"
            code={`// Traditional Solidity — everything is public!
contract PublicAuction {
    uint256 public highestBid;      // Anyone can see the highest bid
    address public highestBidder;   // Anyone can see who's winning
    
    function bid() external payable {
        // Everyone can see your bid amount and derive your strategy
        require(msg.value > highestBid);
        highestBid = msg.value;
        highestBidder = msg.sender;
    }
}`}
          />
        </div>

        <div>
          <CodeBlock
            title="The FHE Solution"
            language="solidity"
            code={`// Fhenix — bids stay encrypted!
import "fhe/lib/lib.sol";

contract PrivateAuction {
    euint32 public highestBid;      // Encrypted — nobody can see the value
    eaddress public highestBidder;  // Encrypted — nobody knows who's winning
    
    function bid(bytes calldata encryptedBid) external {
        euint32 bidValue = FHE.asEuint32(encryptedBid);
        
        // Comparison happens on ENCRYPTED data
        ebool isHigher = FHE.gt(bidValue, highestBid);
        
        // Conditionally update — all without revealing anything
        highestBid = FHE.select(isHigher, bidValue, highestBid);
        highestBidder = FHE.select(isHigher, FHE.asEaddress(msg.sender), highestBidder);
    }
}`}
          />
        </div>
      </section>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">Fhenix Architecture Overview</h2>
        <p className="mb-4 text-muted-foreground">
          Fhenix is an Ethereum-compatible blockchain that integrates FHE natively into the EVM.
          It uses the TFHE (Tormented Fully Homomorphic Encryption) scheme, which is based on
          the CGGI (Chillotti-Gama-Georgieva-Izabachène) lattice-based FHE scheme — optimized
          for fast boolean and arithmetic circuit evaluations.
        </p>

        <div className="mb-6 grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">FHE Execution Environment</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Fhenix extends the EVM with custom precompiles that handle FHE operations.
                Smart contracts use the <code className="text-primary">fheos</code> library to perform
                encrypted arithmetic, comparisons, and bitwise operations. The FHE coprocessor
                executes these operations off-chain while the EVM handles standard logic.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Threshold Decryption</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Decryption requires participation from a threshold of network validators.
                No single party can decrypt user data. This is enforced through
                threshold decryption ceremonies that require &gt;2/3 of validators
                to collaboratively produce decryption shares.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Permissioned Decryption</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Users control who can decrypt their data through a permit system.
                A user grants a permit to a specific address, allowing that address
                to request decryption or re-encryption of specific ciphertexts.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">fhenix.js SDK</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                The client-side JavaScript SDK handles encryption before data is sent on-chain,
                decryption of results, and permit management. It abstracts away the complexity
                of FHE parameters and key management.
              </p>
            </CardContent>
          </Card>
        </div>

        <InfoBox type="tip" title="Performance Note">
          FHE operations are computationally heavier than regular EVM operations. Fhenix mitigates
          this with a dedicated coprocessor. Expect FHE operations to cost more gas than standard
          ones, but the privacy benefits often justify the trade-off.
        </InfoBox>
      </section>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">How FHE Computations Work</h2>
        <p className="mb-4 text-muted-foreground">
          Here&apos;s a simplified view of how data flows through a Fhenix application:
        </p>
        <div className="mb-6 space-y-3">
          <div className="flex items-start gap-3 rounded-lg border border-primary/20 bg-primary/5 p-4">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">1</span>
            <div>
              <p className="font-medium">Client Encrypts</p>
              <p className="text-sm text-muted-foreground">
                The user&apos;s browser (via fhenix.js) encrypts a plaintext value using the network&apos;s public key, producing a ciphertext.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3 rounded-lg border border-primary/20 bg-primary/5 p-4">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">2</span>
            <div>
              <p className="font-medium">Transaction Submitted</p>
              <p className="text-sm text-muted-foreground">
                The ciphertext is sent as calldata in a regular Ethereum transaction. The encrypted data is stored in contract state.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3 rounded-lg border border-primary/20 bg-primary/5 p-4">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">3</span>
            <div>
              <p className="font-medium">FHE Coprocessor Computes</p>
              <p className="text-sm text-muted-foreground">
                When the contract calls FHE operations (add, compare, etc.), the coprocessor performs homomorphic computations directly on ciphertexts.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3 rounded-lg border border-primary/20 bg-primary/5 p-4">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">4</span>
            <div>
              <p className="font-medium">Encrypted Results Stored</p>
              <p className="text-sm text-muted-foreground">
                The resulting ciphertext is written back to contract storage. Nobody — not even the contract — knows the plaintext value.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3 rounded-lg border border-primary/20 bg-primary/5 p-4">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">5</span>
            <div>
              <p className="font-medium">Authorized Decryption</p>
              <p className="text-sm text-muted-foreground">
                Only users with a valid decryption permit can request the network to decrypt specific results. Threshold decryption ensures no single party can cheat.
              </p>
            </div>
          </div>
        </div>

        <InfoBox type="warning" title="Important Distinction">
          Unlike zero-knowledge proofs (ZKPs), which prove a statement is true without revealing the underlying data,
          FHE allows actual computation on encrypted data. ZKPs verify; FHE computes. They are complementary technologies
          that can be combined for maximum privacy and verifiability.
        </InfoBox>
      </section>

      <ChapterNav currentPath="/introduction" />
    </div>
  )
}
