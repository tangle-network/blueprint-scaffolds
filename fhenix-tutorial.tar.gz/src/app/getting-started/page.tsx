import React from "react"
import { ChapterNav } from "@/components/chapter-nav"
import { CodeBlock } from "@/components/code-block"
import { InfoBox } from "@/components/info-box"
import { Playground } from "@/components/playground"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"

export default function GettingStartedPage() {
  return (
    <div>
      <div className="mb-8">
        <Badge className="mb-4">Chapter 2</Badge>
        <h1 className="text-3xl font-bold">Getting Started with Fhenix</h1>
        <p className="mt-2 text-lg text-muted-foreground">
          Set up your development environment, install the SDK, and configure your toolchain for FHE development.
        </p>
      </div>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">Prerequisites</h2>
        <p className="mb-4 text-muted-foreground">
          Before you begin, make sure you have the following installed:
        </p>
        <ul className="mb-4 list-disc space-y-1 pl-6 text-muted-foreground">
          <li><strong>Node.js</strong> v18+ and npm/pnpm</li>
          <li><strong>Hardhat</strong> — the Ethereum development framework</li>
          <li><strong>A code editor</strong> with Solidity support (e.g., VS Code + Solidity extension)</li>
        </ul>
      </section>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">Project Setup</h2>
        <p className="mb-4 text-muted-foreground">
          Initialize a new Hardhat project and install the Fhenix-specific dependencies.
        </p>

        <Tabs defaultValue="hardhat">
          <TabsList>
            <TabsTrigger value="hardhat">Hardhat</TabsTrigger>
            <TabsTrigger value="foundry">Foundry</TabsTrigger>
          </TabsList>
          <TabsContent value="hardhat">
            <CodeBlock
              title="Initialize project"
              language="bash"
              code={`mkdir my-fhe-project && cd my-fhe-project
npx hardhat init

# Choose "Create a JavaScript or TypeScript project"
# Select TypeScript for the best experience`}
            />
            <div className="mt-4">
              <CodeBlock
                title="Install Fhenix dependencies"
                language="bash"
                code={`# Install the Fhenix Solidity library
npm install fheos

# Install fhenix.js SDK for client-side encryption
npm install fhenix.js

# Install the Hardhat Fhenix plugin
npm install @fhenixhardhat/hardhat-fhenix`}
              />
            </div>
          </TabsContent>
          <TabsContent value="foundry">
            <CodeBlock
              title="Initialize with Foundry"
              language="bash"
              code={`forge init my-fhe-project
cd my-fhe-project

# Install the Fhenix Solidity library
forge install fhenixprotocol/fheos

# fhenix.js SDK for frontend
npm init -y && npm install fhenix.js`}
            />
          </TabsContent>
        </Tabs>
      </section>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">Hardhat Configuration</h2>
        <p className="mb-4 text-muted-foreground">
          Configure Hardhat to work with the Fhenix local testnet and enable FHE compilation.
        </p>
        <CodeBlock
          title="hardhat.config.ts"
          language="typescript"
          code={`import { HardhatUserConfig } from "hardhat/config";
import "@nomicfoundation/hardhat-toolbox";
import "@fhenixhardhat/hardhat-fhenix";

const config: HardhatUserConfig = {
  solidity: {
    version: "0.8.24",
    settings: {
      evmVersion: "cancun",
    },
  },
  networks: {
    fhenix: {
      url: "http://localhost:42069",
      accounts: {
        mnemonic: "test test test test test test test test test test test junk",
      },
    },
    fhenixTestnet: {
      url: "https://api.helium.fhenix.zone",
      accounts: [process.env.PRIVATE_KEY!],
    },
  },
};

export default config;`}
        />
        <InfoBox type="info" title="Local Testnet">
          The Fhenix local testnet runs on port <code className="text-primary">42069</code> by default.
          It comes pre-loaded with test accounts and a mock FHE coprocessor for development.
        </InfoBox>
      </section>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">Starting the Local Fhenix Node</h2>
        <p className="mb-4 text-muted-foreground">
          The easiest way to run a local Fhenix node is using Docker:
        </p>
        <CodeBlock
          title="Run local Fhenix node"
          language="bash"
          code={`# Pull and run the Fhenix local development node
docker run -p 42069:42069 --name fhenix-local \\
  ghcr.io/fhenixprotocol/fhenix-localnet:latest

# Or using the Fhenix CLI
npx fhenix-localnet start

# The node will be available at http://localhost:42069`}
        />
      </section>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">fhenix.js SDK Basics</h2>
        <p className="mb-4 text-muted-foreground">
          The <code className="text-primary">fhenix.js</code> SDK is the client-side library that handles
          encryption, decryption, and permit management. Here&apos;s how to set it up:
        </p>
        <CodeBlock
          title="Setting up fhenix.js"
          language="typescript"
          code={`import { FhenixClient, EncryptedType, EncryptionTypes } from "fhenix.js";
import { ethers } from "ethers";

// Connect to a Fhenix network
const provider = new ethers.JsonRpcProvider("http://localhost:42069");
const signer = new ethers.Wallet(process.env.PRIVATE_KEY!, provider);

// Initialize the Fhenix client
const client = new FhenixClient({ provider });

// The client automatically handles:
// - Fetching the network's public encryption key
// - Encrypting values for on-chain submission
// - Managing decryption permits
// - Decrypting results returned from the chain`}
        />
      </section>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">Your First FHE Contract</h2>
        <p className="mb-4 text-muted-foreground">
          Let&apos;s create a simple contract that stores an encrypted value:
        </p>
        <CodeBlock
          title="contracts/SimpleStorage.sol"
          language="solidity"
          code={`// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "fhe/lib/lib.sol";

contract SimpleStorage {
    euint32 private storedValue;

    function store(bytes calldata encryptedValue) public {
        storedValue = FHE.asEuint32(encryptedValue);
    }

    function add(bytes calldata encryptedValue) public {
        euint32 value = FHE.asEuint32(encryptedValue);
        storedValue = FHE.add(storedValue, value);
    }

    function getStoredValue() public view returns (euint32) {
        return storedValue;
    }
}`}
        />
        <InfoBox type="tip" title="Import Path">
          The <code className="text-primary">fhe/lib/lib.sol</code> import resolves from the <code className="text-primary">fheos</code>
          npm package. It provides the <code className="text-primary">FHE</code> library with all FHE operations.
        </InfoBox>
      </section>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">Interacting from JavaScript</h2>
        <CodeBlock
          title="interact.ts — Encrypt and send"
          language="typescript"
          code={`import { FhenixClient } from "fhenix.js";
import { ethers } from "ethers";
import { SimpleStorage__factory } from "./typechain-types";

async function main() {
  const provider = new ethers.JsonRpcProvider("http://localhost:42069");
  const signer = new ethers.Wallet(process.env.PRIVATE_KEY!, provider);
  const client = new FhenixClient({ provider });

  const contract = SimpleStorage__factory.connect(
    "0xYourContractAddress",
    signer
  );

  // Encrypt the value 42 as euint32
  const encrypted = await client.encrypt(42, EncryptionTypes.euint32);

  // Send the encrypted value to the contract
  const tx = await contract.store(encrypted);
  await tx.wait();

  console.log("Stored encrypted value 42 on-chain!");

  // Retrieve and decrypt the stored value
  const result = await contract.getStoredValue();
  const decrypted = await client.unseal(contract.target, result);
  console.log("Decrypted value:", Number(decrypted)); // 42
}

main();`}
        />

        <Playground
          title="Try It: Encryption Flow"
          description="Simulate the encryption and submission flow"
          language="typescript"
          initialCode={`// Client-side: encrypting the value 42
const client = new FhenixClient({ provider });
const encrypted = await client.encrypt(42, EncryptionTypes.euint32);

// encrypted is a bytes representation of the ciphertext
console.log("Encrypted bytes length:", encrypted.length);

// Send to contract
const tx = await contract.store(encrypted);`}
          expectedOutput={`Encrypted bytes length: 168
Transaction submitted: 0xabc123...
✓ Encrypted value 42 stored on-chain
  - Nobody can see the value "42"
  - Only the encrypted ciphertext is in storage
  - Only authorized users can decrypt the result`}
        />
      </section>

      <section className="mb-10">
        <h2 className="mb-4 text-2xl font-semibold">Project Structure</h2>
        <p className="mb-4 text-muted-foreground">
          Here&apos;s what your Fhenix project structure should look like:
        </p>
        <CodeBlock
          title="Recommended project layout"
          language="text"
          code={`my-fhe-project/
├── contracts/
│   └── SimpleStorage.sol      # Your FHE-enabled contracts
├── scripts/
│   └── deploy.ts              # Deployment scripts
├── test/
│   └── SimpleStorage.test.ts  # Tests using fhenix.js
├── hardhat.config.ts          # Hardhat + Fhenix config
├── package.json
└── .env                       # Private keys (never commit!)`}
        />
      </section>

      <ChapterNav currentPath="/getting-started" />
    </div>
  )
}
