import { useState } from "react";
import {
  architectureLayers,
  encryptedTypes,
  hardhatConfigExample,
  operationNotes,
  privateVotingContract,
  quizzes,
  sdkExample,
  sections,
  setupSteps,
  sources,
  typeCodeExamples,
  type SectionId,
} from "./content";

type OperationId = keyof typeof operationNotes;

const operationIds: OperationId[] = [
  "add",
  "sub",
  "mul",
  "div",
  "eq",
  "gt",
  "select",
  "bitwise",
];

function App() {
  const [activeSection, setActiveSection] = useState<SectionId>("intro");
  const [selectedType, setSelectedType] = useState("euint32");
  const [operation, setOperation] = useState<OperationId>("add");
  const [left, setLeft] = useState(5);
  const [right, setRight] = useState(2);
  const [condition, setCondition] = useState(true);
  const [quizAnswers, setQuizAnswers] = useState<Record<string, string>>({});

  const activeTypeExample = (() => {
    if (selectedType.startsWith("euint")) {
      return typeCodeExamples.euint8;
    }
    if (selectedType === "ebool") {
      return typeCodeExamples.ebool;
    }
    return typeCodeExamples.eaddress;
  })();

  const operationPreview = (() => {
    const safeDivisor = right === 0 ? 0 : right;
    switch (operation) {
      case "add":
        return {
          label: `cipher(${left}) + cipher(${right}) -> cipher(${left + right})`,
          snippet: `euint32 result = lhs + rhs;`,
        };
      case "sub":
        return {
          label: `cipher(${left}) - cipher(${right}) -> cipher(${left - right})`,
          snippet: `euint32 result = lhs - rhs;`,
        };
      case "mul":
        return {
          label: `cipher(${left}) * cipher(${right}) -> cipher(${left * right})`,
          snippet: `euint32 result = lhs * rhs;`,
        };
      case "div":
        return {
          label:
            safeDivisor === 0
              ? `cipher(${left}) / cipher(0) -> cipher(MAX_UINT for the width)`
              : `cipher(${left}) / cipher(${right}) -> cipher(${Math.floor(left / safeDivisor)})`,
          snippet: `euint32 result = FHE.div(lhs, rhs);`,
        };
      case "eq":
        return {
          label: `FHE.eq(lhs, rhs) -> ebool(${left === right ? "true" : "false"})`,
          snippet: `ebool same = FHE.eq(lhs, rhs);`,
        };
      case "gt":
        return {
          label: `FHE.gt(lhs, rhs) -> ebool(${left > right ? "true" : "false"})`,
          snippet: `ebool isGreater = FHE.gt(lhs, rhs);`,
        };
      case "select":
        return {
          label: `FHE.select(flag, lhs, rhs) -> cipher(${condition ? left : right})`,
          snippet: `euint32 chosen = FHE.select(flag, lhs, rhs);`,
        };
      case "bitwise":
        return {
          label: `lhs ^ rhs on encrypted bits -> cipher(${left ^ right})`,
          snippet: `euint32 mixed = lhs ^ rhs;`,
        };
      default:
        return {
          label: "",
          snippet: "",
        };
    }
  })();

  const progress = Math.round(
    (sections.findIndex((section) => section.id === activeSection) /
      (sections.length - 1)) *
      100,
  );

  return (
    <div className="app-shell">
      <div className="ambient ambient-a" />
      <div className="ambient ambient-b" />
      <header className="hero">
        <div className="hero-copy">
          <p className="eyebrow">Fhenix Privacy Workshop</p>
          <h1>Build an intuition for encrypted Solidity, not just the API surface.</h1>
          <p className="lede">
            This interactive guide walks from FHE fundamentals to a private voting
            contract using the current Fhenix Solidity library, Hardhat plugins, and
            fhenixjs flow.
          </p>
        </div>
        <div className="hero-panel">
          <span className="panel-label">Tutorial progress</span>
          <strong>{progress}%</strong>
          <div className="progress-track">
            <div className="progress-fill" style={{ width: `${progress}%` }} />
          </div>
          <p>
            Move section by section, test the operator simulator, and inspect the
            example contract at the end.
          </p>
        </div>
      </header>

      <main className="layout">
        <aside className="sidebar">
          <div className="sidebar-card">
            <p className="sidebar-label">Sections</p>
            {sections.map((section) => (
              <button
                key={section.id}
                className={`nav-button ${
                  activeSection === section.id ? "nav-button-active" : ""
                }`}
                onClick={() => setActiveSection(section.id)}
              >
                <span>{section.title}</span>
                <small>{section.kicker}</small>
              </button>
            ))}
          </div>

          <div className="sidebar-card">
            <p className="sidebar-label">Quick reminders</p>
            <ul className="checklist">
              <li>Encrypted comparisons return ebool, not bool.</li>
              <li>Prefer typed encrypted inputs like inEuint32.</li>
              <li>Use permits when returning sealed private data.</li>
            </ul>
          </div>
        </aside>

        <section className="content">
          <article className="section-card">
            <p className="section-kicker">
              {sections.find((section) => section.id === activeSection)?.kicker}
            </p>
            <h2>{sections.find((section) => section.id === activeSection)?.title}</h2>
            <p className="section-summary">
              {sections.find((section) => section.id === activeSection)?.summary}
            </p>

            {activeSection === "intro" && (
              <div className="stack">
                <div className="grid two-up">
                  <div className="info-card">
                    <h3>What is Fully Homomorphic Encryption?</h3>
                    <p>
                      FHE lets a system compute on ciphertext without decrypting it
                      first. For blockchain apps, that means contract state can stay
                      encrypted while the chain still executes meaningful logic on it.
                    </p>
                  </div>
                  <div className="info-card">
                    <h3>Why it matters on-chain</h3>
                    <p>
                      Standard public chains reveal balances, positions, votes, and
                      business logic. Fhenix aims to keep those values private while
                      preserving verifiable execution.
                    </p>
                  </div>
                </div>

                <div className="timeline-card">
                  <h3>Fhenix architecture overview</h3>
                  <div className="timeline">
                    {architectureLayers.map((layer, index) => (
                      <div key={layer.title} className="timeline-item">
                        <span>{`0${index + 1}`}</span>
                        <div>
                          <strong>{layer.title}</strong>
                          <p>{layer.detail}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeSection === "getting-started" && (
              <div className="stack">
                <div className="grid two-up">
                  {setupSteps.map((step) => (
                    <div key={step.title} className="info-card">
                      <h3>{step.title}</h3>
                      <p>{step.body}</p>
                      <pre>
                        <code>{step.code}</code>
                      </pre>
                    </div>
                  ))}
                </div>
                <div className="info-card">
                  <h3>Minimal Hardhat config</h3>
                  <pre>
                    <code>{hardhatConfigExample}</code>
                  </pre>
                </div>
                <div className="tip-band">
                  <strong>Practical constraint:</strong> current Fhenix docs note that
                  plain `hardhat network` is not enough because encrypted execution
                  depends on custom Fhenix extensions. Use LocalFhenix or a Fhenix
                  network instead.
                </div>
              </div>
            )}

            {activeSection === "encrypted-types" && (
              <div className="stack">
                <div className="type-picker">
                  {encryptedTypes.map((item) => (
                    <button
                      key={item.name}
                      className={`chip ${selectedType === item.name ? "chip-active" : ""}`}
                      onClick={() => setSelectedType(item.name)}
                    >
                      {item.name}
                    </button>
                  ))}
                </div>

                <div className="grid type-grid">
                  {encryptedTypes.map((item) => (
                    <div
                      key={item.name}
                      className={`type-card ${
                        selectedType === item.name ? "type-card-active" : ""
                      }`}
                    >
                      <div className="type-header">
                        <h3>{item.name}</h3>
                        <span>{item.category}</span>
                      </div>
                      <p>
                        <strong>Bits:</strong> {item.bits || "typed input wrapper"}
                      </p>
                      <p>{item.useCase}</p>
                      <p className="muted">{item.note}</p>
                    </div>
                  ))}
                </div>

                <div className="grid two-up">
                  <div className="info-card">
                    <h3>Type conversion and casting</h3>
                    <p>
                      Convert encrypted inputs to in-contract types with helpers like
                      `FHE.asEuint8`, `FHE.asEbool`, and `FHE.asEaddress`. For encrypted
                      integer casting between widths, Fhenix documents `.toUxx()`
                      conversion helpers.
                    </p>
                  </div>
                  <div className="info-card">
                    <h3>Selected example</h3>
                    <pre>
                      <code>{activeTypeExample}</code>
                    </pre>
                  </div>
                </div>
              </div>
            )}

            {activeSection === "operations" && (
              <div className="stack">
                <div className="operator-panel">
                  <div className="operator-controls">
                    <label>
                      Operation
                      <select
                        value={operation}
                        onChange={(event) =>
                          setOperation(event.target.value as OperationId)
                        }
                      >
                        {operationIds.map((id) => (
                          <option key={id} value={id}>
                            {id}
                          </option>
                        ))}
                      </select>
                    </label>
                    <label>
                      Left
                      <input
                        type="number"
                        value={left}
                        onChange={(event) => setLeft(Number(event.target.value))}
                      />
                    </label>
                    <label>
                      Right
                      <input
                        type="number"
                        value={right}
                        onChange={(event) => setRight(Number(event.target.value))}
                      />
                    </label>
                    <label className="toggle">
                      <input
                        type="checkbox"
                        checked={condition}
                        onChange={(event) => setCondition(event.target.checked)}
                      />
                      Select condition is encrypted true
                    </label>
                  </div>

                  <div className="operator-result">
                    <h3>Encrypted operation preview</h3>
                    <p>{operationPreview.label}</p>
                    <pre>
                      <code>{operationPreview.snippet}</code>
                    </pre>
                    <p className="muted">{operationNotes[operation]}</p>
                  </div>
                </div>

                <div className="grid two-up">
                  <div className="info-card">
                    <h3>Arithmetic</h3>
                    <p>
                      `add`, `sub`, `mul`, and `div` exist for supported encrypted
                      widths. Operator overloading is available for the supported
                      matrix, but not every type supports every operator.
                    </p>
                  </div>
                  <div className="info-card">
                    <h3>Conditional logic</h3>
                    <p>
                      Use `select` as the encrypted branching primitive. Instead of
                      decrypting an `ebool` and leaking control flow, you choose
                      between ciphertexts on-chain.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {activeSection === "encryption" && (
              <div className="stack">
                <div className="grid two-up">
                  <div className="info-card">
                    <h3>Encrypt before send</h3>
                    <p>
                      Frontends use `fhenixjs` with an ethers-compatible provider to
                      encrypt values before calling the contract. The contract then
                      accepts typed encrypted inputs like `inEuint8`.
                    </p>
                    <pre>
                      <code>{sdkExample}</code>
                    </pre>
                  </div>
                  <div className="info-card">
                    <h3>Decryption permits and re-encryption</h3>
                    <p>
                      For private reads, the recommended pattern is permit plus sealed
                      output. The contract authenticates the viewer and returns data
                      sealed to that viewer, then `client.unseal(...)` reveals it
                      locally.
                    </p>
                    <p className="muted">
                      Use plaintext `decrypt` only when revelation is actually
                      intended. Otherwise keep values encrypted or sealed to the
                      viewer.
                    </p>
                  </div>
                </div>

                <div className="flow-card">
                  <h3>Secure viewing flow</h3>
                  <ol className="flow-list">
                    <li>User signs a permit tied to the contract.</li>
                    <li>Frontend extracts the permission and calls a view function.</li>
                    <li>Contract seals the requested ciphertext for that viewer.</li>
                    <li>Client unseals locally, without exposing the value on-chain.</li>
                  </ol>
                </div>
              </div>
            )}

            {activeSection === "example" && (
              <div className="stack">
                <div className="grid two-up">
                  <div className="info-card">
                    <h3>Private voting design</h3>
                    <p>
                      In this simplified design, each voter encrypts `1` for yes or `0`
                      for no. The contract compares the encrypted input, updates hidden
                      totals with `select`, and never stores an individual ballot in
                      plaintext.
                    </p>
                    <ul className="checklist">
                      <li>Encrypted vote casting via `inEuint8`.</li>
                      <li>Tally stays encrypted in storage.</li>
                      <li>Result comparison can stay encrypted as `ebool`.</li>
                      <li>Reveal can happen via sealing or intentional decrypt flow.</li>
                    </ul>
                  </div>
                  <div className="info-card">
                    <h3>What this teaches</h3>
                    <p>
                      The pattern generalizes to sealed leaderboards, private scoring,
                      hidden allowances, private auction logic, and identity-sensitive
                      workflows where public state would leak too much.
                    </p>
                  </div>
                </div>

                <div className="info-card">
                  <h3>Example contract</h3>
                  <pre>
                    <code>{privateVotingContract}</code>
                  </pre>
                </div>
              </div>
            )}
          </article>

          <article className="section-card">
            <p className="section-kicker">Knowledge check</p>
            <h2>Test the mental model</h2>
            <div className="quiz-grid">
              {quizzes.map((quiz) => {
                const selected = quizAnswers[quiz.id];
                const isCorrect = selected === quiz.answer;
                return (
                  <div key={quiz.id} className="quiz-card">
                    <h3>{quiz.prompt}</h3>
                    <div className="quiz-options">
                      {quiz.options.map((option) => (
                        <button
                          key={option}
                          className={`quiz-option ${
                            selected === option ? "quiz-option-selected" : ""
                          }`}
                          onClick={() =>
                            setQuizAnswers((current) => ({
                              ...current,
                              [quiz.id]: option,
                            }))
                          }
                        >
                          {option}
                        </button>
                      ))}
                    </div>
                    {selected ? (
                      <p className={isCorrect ? "quiz-correct" : "quiz-wrong"}>
                        {isCorrect ? "Correct." : "Not quite."} {quiz.explanation}
                      </p>
                    ) : null}
                  </div>
                );
              })}
            </div>
          </article>

          <article className="section-card">
            <p className="section-kicker">Reference links</p>
            <h2>Docs used for this tutorial</h2>
            <div className="sources">
              {sources.map((source) => (
                <a key={source.href} href={source.href} target="_blank" rel="noreferrer">
                  {source.label}
                </a>
              ))}
            </div>
          </article>
        </section>
      </main>
    </div>
  );
}

export default App;
