export type SectionId =
  | "intro"
  | "getting-started"
  | "encrypted-types"
  | "operations"
  | "encryption"
  | "example";

export type SectionMeta = {
  id: SectionId;
  title: string;
  kicker: string;
  summary: string;
};

export type TypeDescriptor = {
  name: string;
  bits: number;
  category: "compute" | "input";
  useCase: string;
  note: string;
};

export type QuizQuestion = {
  id: string;
  prompt: string;
  options: string[];
  answer: string;
  explanation: string;
};

export const sections: SectionMeta[] = [
  {
    id: "intro",
    title: "1. Introduction to FHE",
    kicker: "Privacy without moving off-chain",
    summary:
      "Learn what Fully Homomorphic Encryption is, why Fhenix matters for on-chain privacy, and how encrypted execution flows through the network.",
  },
  {
    id: "getting-started",
    title: "2. Getting Started",
    kicker: "Local setup and toolchain",
    summary:
      "Set up a Fhenix-ready Hardhat project, install the SDK, and understand the local Docker-backed workflow.",
  },
  {
    id: "encrypted-types",
    title: "3. Encrypted Types",
    kicker: "FHE-native Solidity values",
    summary:
      "Explore encrypted unsigned integers, booleans, addresses, input wrappers, and type conversion patterns.",
  },
  {
    id: "operations",
    title: "4. FHE Operations",
    kicker: "Compute on ciphertext",
    summary:
      "Walk through arithmetic, comparisons, encrypted branching with select, and bitwise operations.",
  },
  {
    id: "encryption",
    title: "5. Encryption and Decryption",
    kicker: "From wallet to readable output",
    summary:
      "Understand client-side encryption, permits, sealed outputs, and the difference between decrypting and secure viewing.",
  },
  {
    id: "example",
    title: "6. Hands-on Example",
    kicker: "Private voting contract",
    summary:
      "Put the pieces together with a simple private voting design that keeps ballots hidden while still allowing an auditable tally.",
  },
];

export const encryptedTypes: TypeDescriptor[] = [
  {
    name: "euint8",
    bits: 8,
    category: "compute",
    useCase: "Small counters, flags, single-choice votes",
    note: "Good for low-range encrypted values and the cheapest arithmetic tier.",
  },
  {
    name: "euint16",
    bits: 16,
    category: "compute",
    useCase: "Scores, medium counters, compact quotas",
    note: "Often a practical step up when 8 bits is too small.",
  },
  {
    name: "euint32",
    bits: 32,
    category: "compute",
    useCase: "Timestamps, balances in bounded systems, IDs",
    note: "Common default for app logic when 16 bits is tight.",
  },
  {
    name: "euint64",
    bits: 64,
    category: "compute",
    useCase: "Longer-running counters and larger bounded amounts",
    note: "Available in current docs, but not every operation is supported for every larger type.",
  },
  {
    name: "euint128",
    bits: 128,
    category: "compute",
    useCase: "Higher-capacity accounting and larger range calculations",
    note: "Useful when 64 bits is insufficient and the operator matrix still fits your design.",
  },
  {
    name: "euint256",
    bits: 256,
    category: "compute",
    useCase: "Maximum-width encrypted integers",
    note: "Supported as a type, but arithmetic/operator support is more limited than smaller widths.",
  },
  {
    name: "ebool",
    bits: 8,
    category: "compute",
    useCase: "Encrypted yes/no state and comparison results",
    note: "Comparison operators return ebool so you can keep decisions private.",
  },
  {
    name: "eaddress",
    bits: 160,
    category: "compute",
    useCase: "Hidden recipients, private ownership metadata",
    note: "Useful when revealing an address would leak strategy or identity.",
  },
  {
    name: "inEuint8..256",
    bits: 0,
    category: "input",
    useCase: "Typed encrypted inputs sent into contract functions",
    note: "Fhenix recommends inEuintXX inputs instead of raw bytes for safer, explicit parsing.",
  },
  {
    name: "inEbool / inEaddress",
    bits: 0,
    category: "input",
    useCase: "Typed encrypted boolean and address inputs",
    note: "Convert them inside the contract with FHE.asEbool / FHE.asEaddress.",
  },
];

export const typeCodeExamples: Record<string, string> = {
  euint8: `import { FHE, euint8, inEuint8 } from "@fhenixprotocol/contracts/FHE.sol";

contract PrivateCounter {
    euint8 private counter;

    function setCounter(inEuint8 calldata encryptedValue) external {
        counter = FHE.asEuint8(encryptedValue);
    }
}`,
  ebool: `import { FHE, ebool, euint32 } from "@fhenixprotocol/contracts/FHE.sol";

function isHighScore(euint32 score, euint32 threshold) internal returns (ebool) {
    return FHE.gt(score, threshold);
}`,
  eaddress: `import { FHE, eaddress, inEaddress } from "@fhenixprotocol/contracts/FHE.sol";

function setHiddenRecipient(inEaddress calldata encryptedRecipient) external {
    hiddenRecipient = FHE.asEaddress(encryptedRecipient);
}`,
};

export const setupSteps = [
  {
    title: "Install the Solidity library",
    body:
      "Use @fhenixprotocol/contracts for FHE.sol and encrypted types. This is the package referenced in the current docs.",
    code: "pnpm add @fhenixprotocol/contracts",
  },
  {
    title: "Install client and Hardhat support",
    body:
      "fhenixjs handles client-side encryption, permits, and unsealing. The Hardhat plugins add LocalFhenix and runtime helpers.",
    code:
      "pnpm add fhenixjs fhenix-hardhat-plugin fhenix-hardhat-docker ethers hardhat",
  },
  {
    title: "Import the plugins in Hardhat",
    body:
      "Importing both plugins injects Fhenix network helpers and LocalFhenix tasks into Hardhat.",
    code: `import "fhenix-hardhat-plugin";
import "fhenix-hardhat-docker";`,
  },
  {
    title: "Use the Nitrogen testnet or LocalFhenix",
    body:
      "The current docs show the public Nitrogen RPC as https://api.nitrogen.fhenix.zone with chainId 8008148. LocalFhenix defaults to port 42069.",
    code: `networks: {
  fhenixNitrogen: {
    url: "https://api.nitrogen.fhenix.zone",
    chainId: 8008148,
    accounts: mnemonic
  }
}`,
  },
];

export const architectureLayers = [
  {
    title: "Client",
    detail:
      "Wallet or frontend encrypts inputs with fhenixjs before the transaction is sent.",
  },
  {
    title: "Contract",
    detail:
      "Solidity uses FHE.sol types such as euint32 and ebool to compute directly on ciphertext handles.",
  },
  {
    title: "Execution network",
    detail:
      "Fhenix extends EVM execution with FHE-aware precompiles and encrypted type support.",
  },
  {
    title: "Threshold decryption",
    detail:
      "When a contract intentionally reveals data, the network uses permissions and threshold decryption paths rather than exposing raw state.",
  },
];

export const operationNotes = {
  add: "Use encrypted addition for balances, counters, and vote totals without exposing the operands.",
  sub: "Subtraction wraps instead of reverting on overflow, because reverting would leak data-dependent information.",
  mul: "Multiplication is available on smaller encrypted integer widths and is heavier than add/sub.",
  div: "Division support is limited to smaller widths; division by zero returns MAX_UINT instead of reverting.",
  eq: "Comparisons return ebool, keeping the outcome encrypted and composable.",
  gt: "Use gt/lt/gte/lte to make private decisions without emitting a plaintext boolean.",
  select: "select is the encrypted if/else primitive: choose between two ciphertexts using an ebool condition.",
  bitwise: "Bitwise and/or/xor/not exist for supported widths and for ebool where relevant.",
};

export const privateVotingContract = `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.25;

import { FHE, ebool, euint8, euint32, inEuint8 } from "@fhenixprotocol/contracts/FHE.sol";

contract PrivateVoting {
    euint32 private yesVotes;
    euint32 private noVotes;
    mapping(address => bool) public hasVoted;

    function castVote(inEuint8 calldata encryptedVote) external {
        require(!hasVoted[msg.sender], "already voted");

        euint8 vote = FHE.asEuint8(encryptedVote);
        ebool isYes = FHE.eq(vote, FHE.asEuint8(1));
        euint32 one = FHE.asEuint32(1);
        euint32 zero = FHE.asEuint32(0);

        yesVotes = yesVotes + FHE.select(isYes, one, zero);
        noVotes = noVotes + FHE.select(isYes, zero, one);
        hasVoted[msg.sender] = true;
    }

    function revealTotals()
        external
        view
        returns (euint32 sealedYesVotes, euint32 sealedNoVotes)
    {
        return (yesVotes, noVotes);
    }

    function winningSide() external view returns (ebool) {
        return FHE.gt(yesVotes, noVotes);
    }
}`;

export const sdkExample = `import { BrowserProvider } from "ethers";
import { FhenixClient, EncryptionTypes, generatePermit } from "fhenixjs";

const provider = new BrowserProvider(window.ethereum);
const client = new FhenixClient({ provider });

const encryptedVote = await client.encrypt(1, EncryptionTypes.uint8);
await contract.castVote(encryptedVote);

const permit = await generatePermit(contractAddress, provider);
const permission = client.extractPermitPermission(permit);
const response = await contract.getMyPrivateResult(permission);
const plaintext = client.unseal(contractAddress, response);`;

export const hardhatConfigExample = `import { HardhatUserConfig } from "hardhat/config";
import "fhenix-hardhat-plugin";
import "fhenix-hardhat-docker";

const config: HardhatUserConfig = {
  solidity: "0.8.25",
  networks: {
    fhenixNitrogen: {
      url: "https://api.nitrogen.fhenix.zone",
      chainId: 8008148,
      accounts: process.env.MNEMONIC ? [process.env.MNEMONIC] : [],
    },
  },
};

export default config;`;

export const quizzes: QuizQuestion[] = [
  {
    id: "fhe-core",
    prompt: "What makes FHE different from regular encryption in a smart contract workflow?",
    options: [
      "You can compute on encrypted data without decrypting it first.",
      "It removes the need for wallets and signatures.",
      "It stores plaintext on-chain and encrypts only event logs.",
    ],
    answer: "You can compute on encrypted data without decrypting it first.",
    explanation:
      "That is the core property. Fhenix lets contracts keep state encrypted while still performing supported computation.",
  },
  {
    id: "inputs",
    prompt: "What input format does Fhenix recommend for encrypted Solidity function arguments?",
    options: [
      "Typed inEuintXX / inEbool / inEaddress inputs",
      "Raw bytes only",
      "Strings encoded as base64",
    ],
    answer: "Typed inEuintXX / inEbool / inEaddress inputs",
    explanation:
      "The docs recommend typed encrypted inputs instead of raw bytes so the contract can parse and validate inputs explicitly.",
  },
  {
    id: "permits",
    prompt: "Why do permits matter when reading private values back out of a contract?",
    options: [
      "They let the contract verify identity and seal output for the intended viewer.",
      "They replace contract deployment.",
      "They are required only for gas estimation.",
    ],
    answer: "They let the contract verify identity and seal output for the intended viewer.",
    explanation:
      "Permits carry authenticated viewer information so a contract can safely return sealed data that only the permitted client can unseal.",
  },
];

export const sources = [
  {
    label: "Fhenix Hardhat setup",
    href: "https://docs.fhenix.zone/docs/devdocs/Setting%20Up%20Your%20Environment/Hardhat",
  },
  {
    label: "Fhenix Hardhat plugin",
    href: "https://docs.fhenix.zone/docs/devdocs/Tools%20and%20Utilities/Fhenix-Hardhat-Plugin",
  },
  {
    label: "FHE.sol types and usage",
    href: "https://docs.fhenix.zone/docs/devdocs/Writing%20Smart%20Contracts/FHE-sol",
  },
  {
    label: "Types and operations",
    href: "https://docs.fhenix.zone/docs/devdocs/Writing%20Smart%20Contracts/Types-and-Operators",
  },
  {
    label: "Fhenix differences",
    href: "https://docs.fhenix.zone/docs/devdocs/Fhenix%20Testnet/Details/Fhenix-Differences",
  },
  {
    label: "Permits and access control",
    href: "https://docs.fhenix.zone/docs/devdocs/Encryption%20and%20Privacy/Permits-Access-Control",
  },
  {
    label: "fhenix.js basics",
    href: "https://docs.fhenix.zone/docs/devdocs/FhenixJS/Fhenix-JS",
  },
];
