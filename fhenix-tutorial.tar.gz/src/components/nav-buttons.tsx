"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";

const order = [
  "/",
  "/tutorial/introduction",
  "/tutorial/getting-started",
  "/tutorial/encrypted-types",
  "/tutorial/fhe-operations",
  "/tutorial/encryption-decryption",
  "/tutorial/hands-on",
];

interface NavButtonsProps {
  currentPath: string;
}

export function NavButtons({ currentPath }: NavButtonsProps) {
  const idx = order.indexOf(currentPath);
  const prev = idx > 0 ? order[idx - 1] : null;
  const next = idx < order.length - 1 ? order[idx + 1] : null;

  return (
    <div className="flex items-center justify-between mt-12 pt-6 border-t">
      {prev ? (
        <Link href={prev}>
          <Button variant="outline" className="gap-2">
            <ChevronLeft className="h-4 w-4" />
            Previous
          </Button>
        </Link>
      ) : (
        <div />
      )}
      {next ? (
        <Link href={next}>
          <Button className="gap-2">
            Next
            <ChevronRight className="h-4 w-4" />
          </Button>
        </Link>
      ) : (
        <div />
      )}
    </div>
  );
}
