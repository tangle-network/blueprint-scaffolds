"use client"

import React from "react"
import { cn } from "@/lib/utils"

interface CodeBlockProps {
  code: string
  language?: string
  title?: string
}

export function CodeBlock({ code, language = "solidity", title }: CodeBlockProps) {
  const [copied, setCopied] = React.useState(false)

  const handleCopy = () => {
    navigator.clipboard.writeText(code)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="code-block group relative">
      {title && (
        <div className="mb-2 flex items-center justify-between border-b border-border pb-2">
          <span className="text-xs font-medium text-muted-foreground">{title}</span>
        </div>
      )}
      <div className="absolute right-2 top-2">
        <button
          onClick={handleCopy}
          className="rounded-md bg-secondary/80 px-2 py-1 text-xs text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100 hover:text-foreground"
        >
          {copied ? "Copied!" : "Copy"}
        </button>
      </div>
      <pre>
        <code className={cn(`language-${language}`, "text-foreground")}>{code}</code>
      </pre>
    </div>
  )
}
