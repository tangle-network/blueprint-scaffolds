import React from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"

const chapterOrder = [
  "/introduction",
  "/getting-started",
  "/encrypted-types",
  "/fhe-operations",
  "/encryption-decryption",
  "/hands-on",
]

interface ChapterNavProps {
  currentPath: string
}

export function ChapterNav({ currentPath }: ChapterNavProps) {
  const currentIndex = chapterOrder.indexOf(currentPath)
  const prevPath = currentIndex > 0 ? chapterOrder[currentIndex - 1] : null
  const nextPath = currentIndex < chapterOrder.length - 1 ? chapterOrder[currentIndex + 1] : null

  return (
    <div className="mt-12 flex items-center justify-between border-t pt-6">
      {prevPath ? (
        <Link href={prevPath}>
          <Button variant="outline" className="gap-2">
            <ChevronLeft className="h-4 w-4" />
            Previous
          </Button>
        </Link>
      ) : (
        <div />
      )}
      {nextPath ? (
        <Link href={nextPath}>
          <Button className="gap-2">
            Next
            <ChevronRight className="h-4 w-4" />
          </Button>
        </Link>
      ) : (
        <div />
      )}
    </div>
  )
}
