"use client"

import React, { useState } from "react"
import { CodeBlock } from "@/components/code-block"
import { Button } from "@/components/ui/button"
import { Play } from "lucide-react"

interface PlaygroundProps {
  title: string
  description: string
  initialCode: string
  expectedOutput: string
  language?: string
}

export function Playground({ title, description, initialCode, expectedOutput, language = "solidity" }: PlaygroundProps) {
  const [code] = useState(initialCode)
  const [output, setOutput] = useState<string | null>(null)

  return (
    <div className="my-6 rounded-lg border bg-card">
      <div className="border-b p-4">
        <h3 className="text-lg font-semibold">{title}</h3>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
      <div className="p-4">
        <CodeBlock code={code} language={language} />
        <div className="mt-4">
          <Button
            onClick={() => setOutput(expectedOutput)}
            className="gap-2"
          >
            <Play className="h-4 w-4" />
            Run Simulation
          </Button>
        </div>
        {output && (
          <div className="mt-4 rounded-md border border-green-500/30 bg-green-500/5 p-4">
            <p className="mb-1 text-xs font-semibold text-green-400">Output:</p>
            <pre className="text-sm text-foreground whitespace-pre-wrap">{output}</pre>
          </div>
        )}
      </div>
    </div>
  )
}
