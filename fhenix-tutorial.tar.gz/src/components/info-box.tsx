import React from "react"
import { cn } from "@/lib/utils"

interface InfoBoxProps {
  type?: "info" | "warning" | "tip"
  title?: string
  children: React.ReactNode
}

const styles = {
  info: "border-blue-500/30 bg-blue-500/5",
  warning: "border-yellow-500/30 bg-yellow-500/5",
  tip: "border-green-500/30 bg-green-500/5",
}

const titles = {
  info: "Info",
  warning: "Warning",
  tip: "Tip",
}

export function InfoBox({ type = "info", title, children }: InfoBoxProps) {
  return (
    <div className={cn("my-4 rounded-lg border p-4", styles[type])}>
      <p className="mb-1 text-sm font-semibold text-foreground">{title || titles[type]}</p>
      <div className="text-sm text-muted-foreground">{children}</div>
    </div>
  )
}
