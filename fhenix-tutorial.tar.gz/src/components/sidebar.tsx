"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { Shield, BookOpen, Rocket, Lock, Binary, ArrowRightLeft, Vote } from "lucide-react";

const chapters = [
  { href: "/", label: "Welcome", icon: BookOpen },
  { href: "/tutorial/introduction", label: "1. Introduction to FHE", icon: Shield },
  { href: "/tutorial/getting-started", label: "2. Getting Started", icon: Rocket },
  { href: "/tutorial/encrypted-types", label: "3. Encrypted Types", icon: Binary },
  { href: "/tutorial/fhe-operations", label: "4. FHE Operations", icon: Lock },
  { href: "/tutorial/encryption-decryption", label: "5. Encryption & Decryption", icon: ArrowRightLeft },
  { href: "/tutorial/hands-on", label: "6. Hands-on: Private Voting", icon: Vote },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-72 border-r border-border bg-card/50 backdrop-blur-sm flex flex-col">
      <div className="p-6 border-b border-border">
        <Link href="/" className="flex items-center gap-2">
          <Shield className="h-6 w-6 text-primary" />
          <span className="font-bold text-lg">Fhenix Tutorial</span>
        </Link>
        <p className="text-xs text-muted-foreground mt-1">Learn FHE on Fhenix</p>
      </div>
      <nav className="flex-1 p-4 space-y-1">
        {chapters.map((ch) => {
          const Icon = ch.icon;
          const active = pathname === ch.href;
          return (
            <Link
              key={ch.href}
              href={ch.href}
              className={cn(
                "flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors",
                active
                  ? "bg-primary/10 text-primary font-medium"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              )}
            >
              <Icon className="h-4 w-4 shrink-0" />
              {ch.label}
            </Link>
          );
        })}
      </nav>
      <div className="p-4 border-t border-border">
        <p className="text-xs text-muted-foreground">
          Based on <span className="text-primary">coFHE</span> docs
        </p>
      </div>
    </aside>
  );
}
