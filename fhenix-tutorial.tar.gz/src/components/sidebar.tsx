"use client"

import React from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Shield, BookOpen, Rocket, Lock, Cpu, Key, Vote } from "lucide-react"

const chapters = [
  { href: "/introduction", label: "Introduction to FHE", icon: BookOpen },
  { href: "/getting-started", label: "Getting Started", icon: Rocket },
  { href: "/encrypted-types", label: "Encrypted Types", icon: Lock },
  { href: "/fhe-operations", label: "FHE Operations", icon: Cpu },
  { href: "/encryption-decryption", label: "Encrypt / Decrypt", icon: Key },
  { href: "/hands-on", label: "Hands-on: Voting", icon: Vote },
]

export function Sidebar() {
  const pathname = usePathname()

  return (
    <aside className="fixed left-0 top-0 z-40 h-screen w-72 border-r bg-card">
      <div className="flex h-16 items-center gap-2 border-b px-6">
        <Shield className="h-6 w-6 text-primary" />
        <span className="text-lg font-bold">Fhenix Tutorial</span>
      </div>
      <nav className="space-y-1 p-4">
        {chapters.map((chapter) => {
          const Icon = chapter.icon
          const isActive = pathname === chapter.href
          return (
            <Link
              key={chapter.href}
              href={chapter.href}
              className={cn(
                "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                isActive
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:bg-secondary hover:text-foreground"
              )}
            >
              <Icon className="h-4 w-4" />
              {chapter.label}
            </Link>
          )
        })}
      </nav>
    </aside>
  )
}
