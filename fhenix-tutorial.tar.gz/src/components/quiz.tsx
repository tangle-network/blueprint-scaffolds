"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

interface QuizProps {
  title: string;
  questions: QuizQuestion[];
}

export function Quiz({ title, questions }: QuizProps) {
  const [selected, setSelected] = useState<Record<number, number>>({});
  const [revealed, setRevealed] = useState<Record<number, boolean>>({});

  const handleSelect = (qi: number, oi: number) => {
    if (revealed[qi]) return;
    setSelected((s) => ({ ...s, [qi]: oi }));
  };

  const handleReveal = (qi: number) => {
    setRevealed((r) => ({ ...r, [qi]: true }));
  };

  return (
    <Card className="border-primary/30 bg-primary/5">
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Badge variant="outline" className="text-primary border-primary">
            Quiz
          </Badge>
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {questions.map((q, qi) => (
          <div key={qi} className="space-y-3">
            <p className="font-medium text-sm">
              {qi + 1}. {q.question}
            </p>
            <div className="grid gap-2">
              {q.options.map((opt, oi) => {
                const isSelected = selected[qi] === oi;
                const isCorrect = oi === q.correctIndex;
                const showResult = revealed[qi];
                let cls = "justify-start text-left h-auto py-2 px-3 text-sm ";
                if (showResult && isCorrect) cls += "border-green-500 bg-green-500/10 text-green-400 ";
                else if (showResult && isSelected && !isCorrect) cls += "border-red-500 bg-red-500/10 text-red-400 ";
                else if (isSelected) cls += "border-primary bg-primary/10 ";
                else cls += "hover:bg-muted ";

                return (
                  <button
                    key={oi}
                    onClick={() => handleSelect(qi, oi)}
                    className={cls + "rounded-md border text-left"}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>
            {selected[qi] !== undefined && !revealed[qi] && (
              <Button size="sm" variant="secondary" onClick={() => handleReveal(qi)}>
                Check Answer
              </Button>
            )}
            {revealed[qi] && (
              <p className="text-xs text-muted-foreground bg-muted/50 rounded p-2">
                {q.explanation}
              </p>
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
