# AGENTS.md

## Goal

Teach about Fhenix and how to use the Solidity library. Interactive tutorial covering FHE basics, fhenix.js SDK, encrypted types, operations on encrypted data.

## Stack

- Family: `fhenix-contracts`
- Layers: 

## Entry Points

- `contracts/FHECounter.sol`
- `hardhat.config.ts`
- `test/FHECounter.test.ts`

## Commands

- `npx hardhat compile`
- `npx hardhat test`

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
