/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        vault: {
          bg: '#0a0b0f',
          card: '#12131a',
          border: '#1e2030',
          accent: '#6c5ce7',
          accentLight: '#a29bfe',
          green: '#00b894',
          red: '#e74c3c',
          text: '#e2e8f0',
          muted: '#64748b',
        }
      },
      fontFamily: {
        mono: ['JetBrains Mono', 'monospace'],
      }
    }
  },
  plugins: [],
};
