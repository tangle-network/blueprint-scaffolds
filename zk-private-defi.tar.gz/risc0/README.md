# RISC Zero guest layout

This folder contains the zkVM guest program sketches that define the journals consumed by the EVM contracts.

- `methods/deposit.rs`: validates shielded deposit commitments and note creation.
- `methods/lending.rs`: validates hidden collateral ratios, liquidation thresholds, and debt updates.
- `methods/swap.rs`: validates atomic hidden-amount swaps and bounded price execution.
- `methods/interest.rs`: validates interest accrual roll-forwards for a market rate root.

The Solidity contracts compile against the expected journal digests today. Wiring the actual generated image IDs and verifier contracts from `risc0` is the next integration step.
