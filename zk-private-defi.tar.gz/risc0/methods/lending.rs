use risc0_zkvm::guest::env;

#[derive(risc0_zkvm::serde::Deserialize, risc0_zkvm::serde::Serialize)]
struct PositionInput {
    position_id: [u8; 32],
    collateral_commitment: [u8; 32],
    debt_commitment: [u8; 32],
    hidden_threshold_commitment: [u8; 32],
    valid_until: u64,
}

fn main() {
    let input: PositionInput = env::read();
    env::commit(&input);
}
