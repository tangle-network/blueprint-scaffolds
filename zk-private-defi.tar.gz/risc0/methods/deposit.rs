use risc0_zkvm::guest::env;

#[derive(risc0_zkvm::serde::Deserialize, risc0_zkvm::serde::Serialize)]
struct DepositInput {
    note_commitment: [u8; 32],
    amount_commitment: [u8; 32],
    pool_root: [u8; 32],
    receiver: [u8; 32],
    valid_until: u64,
}

fn main() {
    let input: DepositInput = env::read();
    env::commit(&input);
}
