use risc0_zkvm::guest::env;

#[derive(risc0_zkvm::serde::Deserialize, risc0_zkvm::serde::Serialize)]
struct SwapInput {
    order_id: [u8; 32],
    inbound_commitment: [u8; 32],
    outbound_commitment: [u8; 32],
    price_band_commitment: [u8; 32],
    valid_until: u64,
}

fn main() {
    let input: SwapInput = env::read();
    env::commit(&input);
}
