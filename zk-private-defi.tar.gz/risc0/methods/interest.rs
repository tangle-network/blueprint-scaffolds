use risc0_zkvm::guest::env;

#[derive(risc0_zkvm::serde::Deserialize, risc0_zkvm::serde::Serialize)]
struct InterestInput {
    market_id: [u8; 32],
    previous_rate_root: [u8; 32],
    next_rate_root: [u8; 32],
    accrual_timestamp: u64,
}

fn main() {
    let input: InterestInput = env::read();
    env::commit(&input);
}
