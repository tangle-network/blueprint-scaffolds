import "@nomicfoundation/hardhat-ethers";
var config = {
    solidity: {
        version: "0.8.24",
        settings: {
            optimizer: {
                enabled: true,
                runs: 200
            }
        }
    },
    paths: {
        sources: "./contracts"
    }
};
export default config;
