export type PrivacyMetric = {
  label: string;
  value: string;
  detail: string;
};

export type Position = {
  id: string;
  market: string;
  collateralCommitment: string;
  debtCommitment: string;
  liquidationBand: string;
  health: number;
  apr: string;
};

export type SwapRoute = {
  pair: string;
  venue: string;
  proof: string;
  priceBand: string;
  settlement: string;
};

export const privacyMetrics: PrivacyMetric[] = [
  {
    label: "Shielded value",
    value: "$18.4M",
    detail: "Commitments held in the pool with RISC Zero journals gating spend rights."
  },
  {
    label: "Hidden LTV ceiling",
    value: "61.8%",
    detail: "Liquidation thresholds are disclosed to the verifier, not the public mempool."
  },
  {
    label: "Accrual epoch",
    value: "12h",
    detail: "Interest is rolled forward through zkVM proofs before any debt mutation."
  }
];

export const positions: Position[] = [
  {
    id: "PX-041",
    market: "wstETH / zUSD",
    collateralCommitment: "0x7a1f...92de",
    debtCommitment: "0x51bb...44f9",
    liquidationBand: "private 142-148%",
    health: 86,
    apr: "4.9%"
  },
  {
    id: "PX-118",
    market: "WBTC / zUSD",
    collateralCommitment: "0x98ee...2130",
    debtCommitment: "0x10ac...af74",
    liquidationBand: "private 136-141%",
    health: 73,
    apr: "3.6%"
  },
  {
    id: "PX-302",
    market: "USDC / zETH",
    collateralCommitment: "0x32c9...fe10",
    debtCommitment: "0xd211...0b62",
    liquidationBand: "private 120-127%",
    health: 91,
    apr: "2.8%"
  }
];

export const swapRoutes: SwapRoute[] = [
  {
    pair: "zETH -> zBTC",
    venue: "Stealth RFQ",
    proof: "atomic hidden amount",
    priceBand: "0.0574 - 0.0578",
    settlement: "single-note fill"
  },
  {
    pair: "zUSD -> zETH",
    venue: "Internal crossing",
    proof: "balance-conserving swap",
    priceBand: "0.00031 - 0.00032",
    settlement: "nullifier linked"
  },
  {
    pair: "zUSD -> zBTC",
    venue: "OTC batch",
    proof: "multi-fill sealed journal",
    priceBand: "0.000015 - 0.000016",
    settlement: "delayed reveal disabled"
  }
];

export const protocolNotes = [
  "Deposits enter a shielded pool as note commitments and nullifiers.",
  "Borrowing updates only commitment roots and verified rate snapshots.",
  "Liquidation eligibility is checked inside the zkVM against private thresholds.",
  "Atomic swaps prove conservation and price bounds without leaking notional size."
];
