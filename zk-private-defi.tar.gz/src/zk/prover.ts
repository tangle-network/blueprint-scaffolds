function randHex(bytes: number): string {
  const arr = new Uint8Array(bytes);
  crypto.getRandomValues(arr);
  return '0x' + Array.from(arr).map(b => b.toString(16).padStart(2, '0')).join('');
}

function hex(value: bigint | number | string): string {
  const v = BigInt(value);
  return '0x' + v.toString(16).padStart(64, '0');
}

import { ZKProof, ProofReceipt, MerkleProof, ShieldedDeposit, ShieldedPosition, SwapOrder, InterestProof } from '../types';

export async function generateDepositProof(
  amount: string,
  token: string,
  secret: string
): Promise<{ proof: ZKProof; commitment: string; nullifier: string }> {
  await new Promise(r => setTimeout(r, 800));

  const nullifier = randHex(32);
  const commitment = randHex(32);

  const proof: ZKProof = {
    pi_a: [hex(amount), hex(0)],
    pi_b: [[hex(1), hex(2)], [hex(3), hex(4)], ['1', '0']],
    pi_c: [nullifier, commitment, '1'],
    protocol: 'groth16',
    curve: 'bn128',
  };

  return { proof, commitment, nullifier };
}

export async function generateWithdrawProof(
  deposit: ShieldedDeposit,
  merkleProof: MerkleProof,
  recipient: string
): Promise<ZKProof> {
  await new Promise(r => setTimeout(r, 600));

  return {
    pi_a: [deposit.commitment, merkleProof.root, '1'],
    pi_b: [[deposit.nullifier, hex(1)], [recipient.slice(0, 66), hex(2)], ['1', '0']],
    pi_c: [deposit.nullifier, hex(0), '1'],
    protocol: 'groth16',
    curve: 'bn128',
  };
}

export async function generateLiquidationProof(
  position: ShieldedPosition,
  priceOracleRoot: string,
  threshold: number
): Promise<{ proof: ZKProof; isLiquidatable: boolean }> {
  await new Promise(r => setTimeout(r, 1200));
  const isLiquidatable = position.healthFactor < threshold;

  return {
    proof: {
      pi_a: [position.collateralCommitment, position.debtCommitment, '1'],
      pi_b: [[priceOracleRoot, hex(Math.floor(threshold * 100))], [hex(Math.floor(position.healthFactor * 100)), hex(0)], ['1', '0']],
      pi_c: [hex(isLiquidatable ? 1 : 0), position.id, '1'],
      protocol: 'groth16',
      curve: 'bn128',
    },
    isLiquidatable,
  };
}

export async function generateSwapProof(
  inputCommitment: string,
  outputToken: string,
  minRate: string
): Promise<{ proof: ZKProof; outputCommitment: string; outputNullifier: string }> {
  await new Promise(r => setTimeout(r, 900));
  const outputCommitment = randHex(32);
  const outputNullifier = randHex(32);

  return {
    proof: {
      pi_a: [inputCommitment, outputCommitment, '1'],
      pi_b: [[hex(minRate), hex(0)], [outputNullifier, hex(1)], ['1', '0']],
      pi_c: [outputNullifier, hex(0), '1'],
      protocol: 'groth16',
      curve: 'bn128',
    },
    outputCommitment,
    outputNullifier,
  };
}

export async function generateInterestProof(
  position: ShieldedPosition,
  newDebtAmount: string
): Promise<{ proof: ZKProof; newDebtCommitment: string; interestProof: InterestProof }> {
  await new Promise(r => setTimeout(r, 700));
  const newDebtCommitment = randHex(32);
  const proofHash = randHex(32);

  return {
    proof: {
      pi_a: [position.debtCommitment, newDebtCommitment, '1'],
      pi_b: [[hex(newDebtAmount), hex(Date.now())], [hex(1), hex(0)], ['1', '0']],
      pi_c: [newDebtCommitment, hex(0), '1'],
      protocol: 'groth16',
      curve: 'bn128',
    },
    newDebtCommitment,
    interestProof: {
      positionId: position.id,
      accruedInterest: newDebtAmount,
      newDebtCommitment,
      proofHash,
      timestamp: Date.now(),
      blockNumber: Math.floor(Math.random() * 1000000) + 18000000,
    },
  };
}

export function generateRiscZeroReceipt(proof: ZKProof): ProofReceipt {
  const journal = JSON.stringify({
    commitments: [proof.pi_a[0], proof.pi_a[1]],
    nullifiers: [proof.pi_c[0]],
    timestamp: Date.now(),
  });

  return {
    seal: randHex(512),
    journal: '0x' + Buffer.from(journal).toString('hex'),
    imageId: randHex(32),
  };
}

export async function buildMerkleTree(deposits: string[]): Promise<MerkleProof> {
  await new Promise(r => setTimeout(r, 100));

  const padTo = Math.pow(2, Math.ceil(Math.log2(Math.max(deposits.length, 1))));
  const leaves = [...deposits, ...Array(padTo - deposits.length).fill(randHex(32))];

  let currentLevel = leaves;
  const allLevels: string[][] = [currentLevel];

  while (currentLevel.length > 1) {
    const next: string[] = [];
    for (let i = 0; i < currentLevel.length; i += 2) {
      const combined = currentLevel[i] + currentLevel[i + 1];
      const hash = '0x' + Array.from(new TextEncoder().encode(combined))
        .reduce((h, b) => h + b.toString(16).padStart(2, '0'), '').slice(0, 64);
      next.push(hash);
    }
    currentLevel = next;
    allLevels.push(currentLevel);
  }

  const path: string[] = [];
  const indices: number[] = [];
  let idx = 0;

  for (let level = 0; level < allLevels.length - 1; level++) {
    const siblingIdx = idx % 2 === 0 ? idx + 1 : idx - 1;
    path.push(allLevels[level][siblingIdx]);
    indices.push(idx % 2);
    idx = Math.floor(idx / 2);
  }

  return {
    root: allLevels[allLevels.length - 1][0],
    leaf: deposits[0] || randHex(32),
    path,
    indices,
  };
}
