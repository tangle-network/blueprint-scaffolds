import { positions, privacyMetrics, protocolNotes, swapRoutes } from "./data";

function App() {
  return (
    <div className="shell">
      <header className="hero">
        <div className="hero__copy">
          <p className="eyebrow">RISC Zero Confidential DeFi</p>
          <h1>StealthLend Zero</h1>
          <p className="lede">
            A private lending and swap protocol where deposits, collateral ratios,
            liquidation thresholds, and swap notionals remain sealed inside zkVM
            proofs while EVM contracts enforce state transitions.
          </p>
          <div className="hero__actions">
            <button>Connect wallet</button>
            <button className="button--ghost">Inspect verifier flow</button>
          </div>
        </div>
        <div className="hero__panel">
          <span className="panel__label">Verified execution path</span>
          <ol className="flow">
            <li>Generate zkVM journal for deposit, borrow, swap, or accrual.</li>
            <li>Submit seal plus public commitments to the verifier-backed contract.</li>
            <li>Advance Merkle roots and nullifiers without revealing private values.</li>
          </ol>
        </div>
      </header>

      <section className="metrics">
        {privacyMetrics.map((metric) => (
          <article key={metric.label} className="card metric">
            <span>{metric.label}</span>
            <strong>{metric.value}</strong>
            <p>{metric.detail}</p>
          </article>
        ))}
      </section>

      <main className="grid">
        <section className="card portfolio">
          <div className="section-heading">
            <div>
              <p className="section-tag">Private portfolio</p>
              <h2>Shielded positions</h2>
            </div>
            <span className="status">zk-synced</span>
          </div>
          <div className="position-list">
            {positions.map((position) => (
              <article key={position.id} className="position">
                <div>
                  <h3>{position.market}</h3>
                  <p>{position.id}</p>
                </div>
                <dl>
                  <div>
                    <dt>Collateral</dt>
                    <dd>{position.collateralCommitment}</dd>
                  </div>
                  <div>
                    <dt>Debt</dt>
                    <dd>{position.debtCommitment}</dd>
                  </div>
                  <div>
                    <dt>Liq band</dt>
                    <dd>{position.liquidationBand}</dd>
                  </div>
                  <div>
                    <dt>APR</dt>
                    <dd>{position.apr}</dd>
                  </div>
                </dl>
                <div className="healthbar">
                  <div style={{ width: `${position.health}%` }} />
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="card action-panel">
          <div className="section-heading">
            <div>
              <p className="section-tag">Shielded pool</p>
              <h2>Deposit or borrow</h2>
            </div>
          </div>
          <form className="form-grid">
            <label>
              Asset
              <select defaultValue="wstETH">
                <option>wstETH</option>
                <option>WBTC</option>
                <option>USDC</option>
              </select>
            </label>
            <label>
              Mode
              <select defaultValue="deposit">
                <option>deposit</option>
                <option>borrow</option>
                <option>repay</option>
              </select>
            </label>
            <label className="span-2">
              Hidden amount commitment
              <input value="0x79d0...e118" readOnly />
            </label>
            <label>
              Note commitment
              <input value="0xaa40...190d" readOnly />
            </label>
            <label>
              zkVM image ID
              <input value="0x8f17...r0" readOnly />
            </label>
            <button type="button" className="span-2">
              Submit proof-backed action
            </button>
          </form>
        </section>

        <section className="card action-panel">
          <div className="section-heading">
            <div>
              <p className="section-tag">Swap engine</p>
              <h2>Atomic private routing</h2>
            </div>
          </div>
          <div className="route-list">
            {swapRoutes.map((route) => (
              <article key={route.pair} className="route">
                <div>
                  <h3>{route.pair}</h3>
                  <p>{route.venue}</p>
                </div>
                <ul>
                  <li>{route.proof}</li>
                  <li>{route.priceBand}</li>
                  <li>{route.settlement}</li>
                </ul>
              </article>
            ))}
          </div>
          <button type="button" className="button--ghost">
            Generate sealed swap proof
          </button>
        </section>

        <section className="card architecture">
          <div className="section-heading">
            <div>
              <p className="section-tag">Protocol design</p>
              <h2>Execution notes</h2>
            </div>
          </div>
          <ul className="notes">
            {protocolNotes.map((note) => (
              <li key={note}>{note}</li>
            ))}
          </ul>
        </section>
      </main>
    </div>
  );
}

export default App;
