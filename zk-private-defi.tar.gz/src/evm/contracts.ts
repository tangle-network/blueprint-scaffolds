import { ethers } from 'ethers';
import { ProofReceipt, TokenType, TOKEN_ADDRESSES } from '../types';

const SHIELDED_POOL_ABI = [
  'function deposit(bytes calldata proof, bytes32 commitment, bytes32 nullifier, address token, uint256 amount) external',
  'function withdraw(bytes calldata proof, bytes32 nullifier, bytes32 commitment, address recipient) external',
  'function getMerkleRoot() external view returns (bytes32)',
  'function verifyProof(bytes calldata proof) external view returns (bool)',
  'event Deposit(bytes32 indexed commitment, bytes32 indexed nullifier, address indexed token)',
  'event Withdrawal(bytes32 indexed nullifier, address indexed recipient, uint256 amount)',
];

const LENDING_MARKET_ABI = [
  'function supplyCollateral(bytes calldata proof, bytes32 commitment, bytes32 nullifier, address token) external',
  'function borrow(bytes calldata proof, bytes32 debtCommitment, bytes32 positionId) external',
  'function repay(bytes calldata proof, bytes32 debtNullifier, bytes32 positionId) external',
  'function checkLiquidation(bytes calldata proof, bytes32 positionId) external view returns (bool)',
  'function liquidate(bytes calldata proof, bytes32 positionId) external',
  'function accrueInterest(bytes calldata receipt, bytes32 positionId) external',
  'event PositionOpened(bytes32 indexed positionId, bytes32 commitment)',
  'event Liquidation(bytes32 indexed positionId, bytes32 liquidator)',
];

const SWAP_ENGINE_ABI = [
  'function submitOrder(bytes calldata proof, bytes32 inputCommitment, bytes32 outputNullifier, address inputToken, address outputToken, uint256 minRate) external returns (bytes32)',
  'function fillOrder(bytes calldata proof, bytes32 orderId, bytes32 outputCommitment) external',
  'function cancelOrder(bytes32 orderId) external',
  'function verifyAndSettle(bytes calldata riscZeroReceipt, bytes32 orderId) external',
  'event OrderSubmitted(bytes32 indexed orderId, address inputToken, address outputToken)',
  'event OrderFilled(bytes32 indexed orderId, bytes32 outputCommitment)',
];

const RISC_ZERO_VERIFIER_ABI = [
  'function verify(bytes calldata seal, bytes32 imageId, bytes calldata journal) external view returns (bool)',
  'function verifyReceipt((bytes seal, bytes32 imageId, bytes journal) calldata receipt) external view returns (bool)',
];

const CONTRACTS: Record<string, string> = {
  shieldedPool: '0x4a1c8Bbe8f2C0B0fDa0bE33E28B8D3bC9eA94Dc7',
  lendingMarket: '0x8B4eF1c6B39C94f38e1C0E42D6359dc50B57DA50',
  swapEngine: '0xC7a2F8E3b57Bb0bDA56D9E3A21b8f0e6d0B2b3A4',
  riscZeroVerifier: '0x1234567890abcdef1234567890abcdef12345678',
};

export type NetworkConnection = {
  provider: ethers.BrowserProvider;
  signer: ethers.Signer;
  chainId: number;
};

let connection: NetworkConnection | null = null;

export async function connectWallet(): Promise<NetworkConnection> {
  if (!window.ethereum) {
    throw new Error('No Ethereum wallet detected');
  }
  const provider = new ethers.BrowserProvider(window.ethereum as ethers.Eip1193Provider);
  const signer = await provider.getSigner();
  const network = await provider.getNetwork();
  connection = { provider, signer, chainId: Number(network.chainId) };
  return connection;
}

export function getConnection(): NetworkConnection | null {
  return connection;
}

export function disconnectWallet(): void {
  connection = null;
}

export function getShieldedPool(signer?: ethers.Signer) {
  const s = signer || connection?.signer;
  if (!s) throw new Error('Wallet not connected');
  return new ethers.Contract(CONTRACTS.shieldedPool, SHIELDED_POOL_ABI, s);
}

export function getLendingMarket(signer?: ethers.Signer) {
  const s = signer || connection?.signer;
  if (!s) throw new Error('Wallet not connected');
  return new ethers.Contract(CONTRACTS.lendingMarket, LENDING_MARKET_ABI, s);
}

export function getSwapEngine(signer?: ethers.Signer) {
  const s = signer || connection?.signer;
  if (!s) throw new Error('Wallet not connected');
  return new ethers.Contract(CONTRACTS.swapEngine, SWAP_ENGINE_ABI, s);
}

export function getRiscZeroVerifier(signer?: ethers.Signer) {
  const s = signer || connection?.signer;
  if (!s) throw new Error('Wallet not connected');
  return new ethers.Contract(CONTRACTS.riscZeroVerifier, RISC_ZERO_VERIFIER_ABI, s);
}

export async function submitDepositToChain(
  proofBytes: string,
  commitment: string,
  nullifier: string,
  token: TokenType,
  amount: string
): Promise<ethers.TransactionReceipt> {
  const pool = getShieldedPool();
  const tokenAddr = TOKEN_ADDRESSES[token];
  const tx = await pool.deposit(proofBytes, commitment, nullifier, tokenAddr, amount);
  return await tx.wait();
}

export async function submitWithdrawToChain(
  proofBytes: string,
  nullifier: string,
  commitment: string,
  recipient: string
): Promise<ethers.TransactionReceipt> {
  const pool = getShieldedPool();
  const tx = await pool.withdraw(proofBytes, nullifier, commitment, recipient);
  return await tx.wait();
}

export async function submitSwapOrderToChain(
  proofBytes: string,
  inputCommitment: string,
  outputNullifier: string,
  inputToken: TokenType,
  outputToken: TokenType,
  minRate: string
): Promise<{ orderId: string; receipt: ethers.TransactionReceipt }> {
  const engine = getSwapEngine();
  const tx = await engine.submitOrder(proofBytes, inputCommitment, outputNullifier, TOKEN_ADDRESSES[inputToken], TOKEN_ADDRESSES[outputToken], minRate);
  const rcpt = await tx.wait();
  const iface = new ethers.Interface(SWAP_ENGINE_ABI);
  const log = rcpt.logs.find((l: ethers.Log) => {
    try { iface.parseLog(l); return true; } catch { return false; }
  });
  const parsed = log ? iface.parseLog(log as ethers.Log) : null;
  const orderId = parsed?.args?.[0] ?? '0x' + '0'.repeat(64);
  return { orderId, receipt: rcpt };
}

export async function verifyRiscZeroReceipt(receipt: ProofReceipt): Promise<boolean> {
  const verifier = getRiscZeroVerifier();
  return await verifier.verifyReceipt({ seal: receipt.seal, imageId: receipt.imageId, journal: receipt.journal });
}

export async function getOnChainMerkleRoot(): Promise<string> {
  const pool = getShieldedPool();
  return await pool.getMerkleRoot();
}

export { CONTRACTS };
