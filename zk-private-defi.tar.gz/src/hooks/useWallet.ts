import { useState, useEffect, useCallback } from 'react';
import { connectWallet, disconnectWallet, getConnection, NetworkConnection } from '../evm/contracts';

export function useWallet() {
  const [connection, setConnection] = useState<NetworkConnection | null>(null);
  const [address, setAddress] = useState<string>('');
  const [connecting, setConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const existing = getConnection();
    if (existing) {
      setConnection(existing);
    }
  }, []);

  const connect = useCallback(async () => {
    setConnecting(true);
    setError(null);
    try {
      const conn = await connectWallet();
      setConnection(conn);
      const addr = await conn.signer.getAddress();
      setAddress(addr);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Connection failed');
    } finally {
      setConnecting(false);
    }
  }, []);

  const disconnect = useCallback(() => {
    disconnectWallet();
    setConnection(null);
    setAddress('');
  }, []);

  return { connection, address, connecting, error, connect, disconnect, isConnected: !!connection };
}
