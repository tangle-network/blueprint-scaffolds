import { useState, useCallback } from 'react';
import { ShieldedDeposit, ShieldedPosition, SwapOrder, InterestProof, TokenType } from '../types';
import { generateDepositProof, generateWithdrawProof, generateLiquidationProof, generateSwapProof, generateInterestProof, generateRiscZeroReceipt, buildMerkleTree } from '../zk/prover';

export function useProtocol() {
  const [deposits, setDeposits] = useState<ShieldedDeposit[]>([]);
  const [positions, setPositions] = useState<ShieldedPosition[]>([]);
  const [swapOrders, setSwapOrders] = useState<SwapOrder[]>([]);
  const [interestProofs, setInterestProofs] = useState<InterestProof[]>([]);
  const [loading, setLoading] = useState(false);
  const [proving, setProving] = useState(false);

  const deposit = useCallback(async (amount: string, token: TokenType, secret: string) => {
    setProving(true);
    try {
      const result = await generateDepositProof(amount, token, secret);
      const deposit: ShieldedDeposit = {
        commitment: result.commitment,
        nullifier: result.nullifier,
        amount,
        token,
        timestamp: Date.now(),
        leafIndex: deposits.length,
      };
      setDeposits(prev => [...prev, deposit]);
      return { deposit, proof: result.proof };
    } finally {
      setProving(false);
    }
  }, [deposits.length]);

  const withdraw = useCallback(async (deposit: ShieldedDeposit, recipient: string) => {
    setProving(true);
    try {
      const merkleProof = await buildMerkleTree(deposits.map(d => d.commitment));
      const proof = await generateWithdrawProof(deposit, merkleProof, recipient);
      setDeposits(prev => prev.filter(d => d.commitment !== deposit.commitment));
      return proof;
    } finally {
      setProving(false);
    }
  }, [deposits]);

  const openPosition = useCallback(async (collateral: ShieldedDeposit, borrowAmount: string) => {
    setProving(true);
    try {
      const positionId = '0x' + Array.from(crypto.getRandomValues(new Uint8Array(32))).map(b => b.toString(16).padStart(2, '0')).join('');
      const debtCommitment = '0x' + Array.from(crypto.getRandomValues(new Uint8Array(32))).map(b => b.toString(16).padStart(2, '0')).join('');
      const position: ShieldedPosition = {
        id: positionId,
        collateralCommitment: collateral.commitment,
        debtCommitment,
        healthFactor: 2.5 + Math.random(),
        lastUpdated: Date.now(),
        isLiquidatable: false,
      };
      setPositions(prev => [...prev, position]);
      return { position, borrowAmount };
    } finally {
      setProving(false);
    }
  }, []);

  const checkLiquidation = useCallback(async (position: ShieldedPosition, threshold: number) => {
    setProving(true);
    try {
      const oracleRoot = '0x' + Array.from(crypto.getRandomValues(new Uint8Array(32))).map(b => b.toString(16).padStart(2, '0')).join('');
      const result = await generateLiquidationProof(position, oracleRoot, threshold);
      if (result.isLiquidatable) {
        setPositions(prev => prev.map(p => p.id === position.id ? { ...p, isLiquidatable: true } : p));
      }
      return result;
    } finally {
      setProving(false);
    }
  }, []);

  const submitSwap = useCallback(async (inputCommitment: string, inputToken: TokenType, outputToken: TokenType, minRate: string) => {
    setProving(true);
    try {
      const result = await generateSwapProof(inputCommitment, outputToken, minRate);
      const order: SwapOrder = {
        id: '0x' + Array.from(crypto.getRandomValues(new Uint8Array(32))).map(b => b.toString(16).padStart(2, '0')).join(''),
        inputCommitment,
        outputNullifier: result.outputNullifier,
        inputToken,
        outputToken,
        rate: minRate,
        status: 'pending',
        proofHash: '0x' + Array.from(crypto.getRandomValues(new Uint8Array(32))).map(b => b.toString(16).padStart(2, '0')).join(''),
        timestamp: Date.now(),
      };
      setSwapOrders(prev => [...prev, order]);
      return { order, proof: result.proof };
    } finally {
      setProving(false);
    }
  }, []);

  const accrueInterest = useCallback(async (position: ShieldedPosition) => {
    setProving(true);
    try {
      const accrued = (BigInt(position.id.slice(2, 10), 16) % BigInt(1000)).toString();
      const result = await generateInterestProof(position, accrued);
      const receipt = generateRiscZeroReceipt(result.proof);
      setInterestProofs(prev => [...prev, result.interestProof]);
      setPositions(prev => prev.map(p => p.id === position.id ? {
        ...p,
        debtCommitment: result.newDebtCommitment,
        healthFactor: p.healthFactor * 0.998,
        lastUpdated: Date.now(),
      } : p));
      return { proof: result.proof, receipt, interestProof: result.interestProof };
    } finally {
      setProving(false);
    }
  }, []);

  const fillSwap = useCallback(async (orderId: string) => {
    setSwapOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: 'filled' as const } : o));
  }, []);

  const cancelSwap = useCallback(async (orderId: string) => {
    setSwapOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: 'cancelled' as const } : o));
  }, []);

  return {
    deposits,
    positions,
    swapOrders,
    interestProofs,
    loading,
    proving,
    deposit,
    withdraw,
    openPosition,
    checkLiquidation,
    submitSwap,
    fillSwap,
    cancelSwap,
    accrueInterest,
  };
}
