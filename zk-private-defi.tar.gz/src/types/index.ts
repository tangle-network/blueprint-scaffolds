export interface ShieldedDeposit {
  commitment: string;
  nullifier: string;
  amount: string;
  token: string;
  timestamp: number;
  leafIndex: number;
}

export interface ShieldedPosition {
  id: string;
  collateralCommitment: string;
  debtCommitment: string;
  healthFactor: number;
  lastUpdated: number;
  isLiquidatable: boolean;
}

export interface SwapOrder {
  id: string;
  inputCommitment: string;
  outputNullifier: string;
  inputToken: string;
  outputToken: string;
  rate: string;
  status: 'pending' | 'filled' | 'cancelled';
  proofHash: string;
  timestamp: number;
}

export interface InterestProof {
  positionId: string;
  accruedInterest: string;
  newDebtCommitment: string;
  proofHash: string;
  timestamp: number;
  blockNumber: number;
}

export interface MerkleProof {
  root: string;
  leaf: string;
  path: string[];
  indices: number[];
}

export interface ZKProof {
  pi_a: string[];
  pi_b: string[][];
  pi_c: string[];
  protocol: string;
  curve: string;
}

export interface ProofReceipt {
  seal: string;
  journal: string;
  imageId: string;
}

export type TokenType = 'ETH' | 'USDC' | 'DAI' | 'WBTC' | 'rETH';

export const TOKEN_ADDRESSES: Record<TokenType, string> = {
  ETH: '0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE',
  USDC: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
  DAI: '0x6B175474E89094C44Da98b954EedeAC495271d0F',
  WBTC: '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599',
  rETH: '0xae78736Cd6155374dCb40172Bf07Aa9e80098eCf',
};

export const TOKEN_DECIMALS: Record<TokenType, number> = {
  ETH: 18,
  USDC: 6,
  DAI: 18,
  WBTC: 8,
  rETH: 18,
};
