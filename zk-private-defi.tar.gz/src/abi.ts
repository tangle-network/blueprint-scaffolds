export const contractAddresses = {
  shieldedPool: "0xPool000000000000000000000000000000000001",
  lendingMarket: "0xMark000000000000000000000000000000000002",
  swapEngine: "0xSwap000000000000000000000000000000000003"
};

export const shieldedPoolAbi = [
  "function submitDeposit(bytes32 noteCommitment, bytes32 amountCommitment, bytes calldata proofJournal, bytes calldata seal) external",
  "function spendNote(bytes32 nullifier, bytes32 nextRoot, bytes calldata proofJournal, bytes calldata seal) external"
];

export const lendingMarketAbi = [
  "function openPosition(bytes32 positionId, bytes32 collateralCommitment, bytes32 debtCommitment, bytes calldata proofJournal, bytes calldata seal) external",
  "function accrueInterest(bytes32 marketId, bytes32 rateRoot, bytes calldata proofJournal, bytes calldata seal) external"
];

export const swapEngineAbi = [
  "function executeSwap(bytes32 orderId, bytes32 inboundCommitment, bytes32 outboundCommitment, bytes calldata proofJournal, bytes calldata seal) external"
];
