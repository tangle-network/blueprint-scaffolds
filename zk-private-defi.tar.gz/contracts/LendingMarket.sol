// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IRiscZeroVerifier} from "./interfaces/IRiscZeroVerifier.sol";
import {ProofData} from "./libraries/ProofData.sol";

contract LendingMarket {
    using ProofData for ProofData.PositionProof;
    using ProofData for ProofData.InterestProof;

    error PositionExists();
    error PositionMissing();
    error InvalidProof();
    error InvalidAccrualOrder();
    error ProofExpired();

    struct PositionState {
        bytes32 collateralCommitment;
        bytes32 debtCommitment;
        bytes32 hiddenThresholdCommitment;
        uint64 updatedAt;
    }

    IRiscZeroVerifier public immutable verifier;
    bytes32 public immutable positionImageId;
    bytes32 public immutable interestImageId;

    mapping(bytes32 => PositionState) public positions;
    mapping(bytes32 => bytes32) public marketRateRoot;

    event PositionOpened(bytes32 indexed positionId, bytes32 collateralCommitment, bytes32 debtCommitment);
    event PositionUpdated(bytes32 indexed positionId, bytes32 collateralCommitment, bytes32 debtCommitment);
    event InterestAccrued(bytes32 indexed marketId, bytes32 previousRateRoot, bytes32 nextRateRoot, uint64 accrualTimestamp);

    constructor(IRiscZeroVerifier verifier_, bytes32 positionImageId_, bytes32 interestImageId_) {
        verifier = verifier_;
        positionImageId = positionImageId_;
        interestImageId = interestImageId_;
    }

    function openPosition(
        ProofData.PositionProof calldata proof,
        bytes calldata seal
    ) external {
        if (proof.validUntil < block.timestamp) revert ProofExpired();
        if (positions[proof.positionId].updatedAt != 0) revert PositionExists();
        _writePosition(proof, seal, true);
    }

    function updatePosition(
        ProofData.PositionProof calldata proof,
        bytes calldata seal
    ) external {
        if (proof.validUntil < block.timestamp) revert ProofExpired();
        if (positions[proof.positionId].updatedAt == 0) revert PositionMissing();
        _writePosition(proof, seal, false);
    }

    function accrueInterest(
        ProofData.InterestProof calldata proof,
        bytes calldata seal
    ) external {
        if (proof.accrualTimestamp < block.timestamp - 1 days) revert InvalidAccrualOrder();
        if (marketRateRoot[proof.marketId] != proof.previousRateRoot) revert InvalidAccrualOrder();

        bytes32 digest = proof.digestInterest();
        bool ok = verifier.verify(seal, interestImageId, digest);
        if (!ok) revert InvalidProof();

        marketRateRoot[proof.marketId] = proof.nextRateRoot;
        emit InterestAccrued(proof.marketId, proof.previousRateRoot, proof.nextRateRoot, proof.accrualTimestamp);
    }

    function _writePosition(
        ProofData.PositionProof calldata proof,
        bytes calldata seal,
        bool isNew
    ) internal {
        bytes32 digest = proof.digestPosition();
        bool ok = verifier.verify(seal, positionImageId, digest);
        if (!ok) revert InvalidProof();

        positions[proof.positionId] = PositionState({
            collateralCommitment: proof.collateralCommitment,
            debtCommitment: proof.debtCommitment,
            hiddenThresholdCommitment: proof.hiddenThresholdCommitment,
            updatedAt: uint64(block.timestamp)
        });

        if (isNew) {
            emit PositionOpened(proof.positionId, proof.collateralCommitment, proof.debtCommitment);
        } else {
            emit PositionUpdated(proof.positionId, proof.collateralCommitment, proof.debtCommitment);
        }
    }
}
