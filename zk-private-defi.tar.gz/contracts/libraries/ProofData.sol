// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

library ProofData {
    struct DepositProof {
        bytes32 noteCommitment;
        bytes32 amountCommitment;
        bytes32 poolRoot;
        bytes32 receiver;
        uint64 validUntil;
    }

    struct SpendProof {
        bytes32 nullifier;
        bytes32 nextRoot;
        bytes32 recipient;
        uint64 validUntil;
    }

    struct PositionProof {
        bytes32 positionId;
        bytes32 collateralCommitment;
        bytes32 debtCommitment;
        bytes32 hiddenThresholdCommitment;
        uint64 validUntil;
    }

    struct InterestProof {
        bytes32 marketId;
        bytes32 previousRateRoot;
        bytes32 nextRateRoot;
        uint64 accrualTimestamp;
    }

    struct SwapProof {
        bytes32 orderId;
        bytes32 inboundCommitment;
        bytes32 outboundCommitment;
        bytes32 priceBandCommitment;
        uint64 validUntil;
    }

    function digestDeposit(DepositProof memory proof) internal pure returns (bytes32) {
        return keccak256(
            abi.encode(
                proof.noteCommitment,
                proof.amountCommitment,
                proof.poolRoot,
                proof.receiver,
                proof.validUntil
            )
        );
    }

    function digestSpend(SpendProof memory proof) internal pure returns (bytes32) {
        return keccak256(
            abi.encode(
                proof.nullifier,
                proof.nextRoot,
                proof.recipient,
                proof.validUntil
            )
        );
    }

    function digestPosition(PositionProof memory proof) internal pure returns (bytes32) {
        return keccak256(
            abi.encode(
                proof.positionId,
                proof.collateralCommitment,
                proof.debtCommitment,
                proof.hiddenThresholdCommitment,
                proof.validUntil
            )
        );
    }

    function digestInterest(InterestProof memory proof) internal pure returns (bytes32) {
        return keccak256(
            abi.encode(
                proof.marketId,
                proof.previousRateRoot,
                proof.nextRateRoot,
                proof.accrualTimestamp
            )
        );
    }

    function digestSwap(SwapProof memory proof) internal pure returns (bytes32) {
        return keccak256(
            abi.encode(
                proof.orderId,
                proof.inboundCommitment,
                proof.outboundCommitment,
                proof.priceBandCommitment,
                proof.validUntil
            )
        );
    }
}
