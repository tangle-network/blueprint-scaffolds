// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IRiscZeroVerifier} from "./interfaces/IRiscZeroVerifier.sol";
import {ProofData} from "./libraries/ProofData.sol";

contract ShieldedPool {
    using ProofData for ProofData.DepositProof;
    using ProofData for ProofData.SpendProof;

    error NoteAlreadyExists();
    error NullifierUsed();
    error ProofExpired();
    error InvalidProof();

    IRiscZeroVerifier public immutable verifier;
    bytes32 public immutable imageId;
    bytes32 public latestRoot;

    mapping(bytes32 => bool) public noteExists;
    mapping(bytes32 => bool) public nullifierSpent;

    event DepositSubmitted(bytes32 indexed noteCommitment, bytes32 amountCommitment, bytes32 newRoot);
    event NoteSpent(bytes32 indexed nullifier, bytes32 newRoot);

    constructor(IRiscZeroVerifier verifier_, bytes32 imageId_, bytes32 initialRoot_) {
        verifier = verifier_;
        imageId = imageId_;
        latestRoot = initialRoot_;
    }

    function submitDeposit(
        ProofData.DepositProof calldata proof,
        bytes calldata seal
    ) external {
        if (proof.validUntil < block.timestamp) revert ProofExpired();
        if (noteExists[proof.noteCommitment]) revert NoteAlreadyExists();

        bytes32 digest = proof.digestDeposit();
        bool ok = verifier.verify(seal, imageId, digest);
        if (!ok) revert InvalidProof();

        noteExists[proof.noteCommitment] = true;
        latestRoot = proof.poolRoot;

        emit DepositSubmitted(proof.noteCommitment, proof.amountCommitment, proof.poolRoot);
    }

    function spendNote(
        ProofData.SpendProof calldata proof,
        bytes calldata seal
    ) external {
        if (proof.validUntil < block.timestamp) revert ProofExpired();
        if (nullifierSpent[proof.nullifier]) revert NullifierUsed();

        bytes32 digest = proof.digestSpend();
        bool ok = verifier.verify(seal, imageId, digest);
        if (!ok) revert InvalidProof();

        nullifierSpent[proof.nullifier] = true;
        latestRoot = proof.nextRoot;

        emit NoteSpent(proof.nullifier, proof.nextRoot);
    }
}
