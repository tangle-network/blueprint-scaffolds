// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IRiscZeroVerifier} from "./interfaces/IRiscZeroVerifier.sol";
import {ProofData} from "./libraries/ProofData.sol";

contract SwapEngine {
    using ProofData for ProofData.SwapProof;

    error InvalidProof();
    error OrderAlreadyFilled();
    error ProofExpired();

    struct Settlement {
        bytes32 inboundCommitment;
        bytes32 outboundCommitment;
        bytes32 priceBandCommitment;
        uint64 settledAt;
    }

    IRiscZeroVerifier public immutable verifier;
    bytes32 public immutable imageId;

    mapping(bytes32 => Settlement) public settlements;

    event SwapExecuted(
        bytes32 indexed orderId,
        bytes32 inboundCommitment,
        bytes32 outboundCommitment,
        bytes32 priceBandCommitment
    );

    constructor(IRiscZeroVerifier verifier_, bytes32 imageId_) {
        verifier = verifier_;
        imageId = imageId_;
    }

    function executeSwap(
        ProofData.SwapProof calldata proof,
        bytes calldata seal
    ) external {
        if (proof.validUntil < block.timestamp) revert ProofExpired();
        if (settlements[proof.orderId].settledAt != 0) revert OrderAlreadyFilled();

        bytes32 digest = proof.digestSwap();
        bool ok = verifier.verify(seal, imageId, digest);
        if (!ok) revert InvalidProof();

        settlements[proof.orderId] = Settlement({
            inboundCommitment: proof.inboundCommitment,
            outboundCommitment: proof.outboundCommitment,
            priceBandCommitment: proof.priceBandCommitment,
            settledAt: uint64(block.timestamp)
        });

        emit SwapExecuted(
            proof.orderId,
            proof.inboundCommitment,
            proof.outboundCommitment,
            proof.priceBandCommitment
        );
    }
}
