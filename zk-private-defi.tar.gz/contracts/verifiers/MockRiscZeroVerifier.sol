// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IRiscZeroVerifier} from "../interfaces/IRiscZeroVerifier.sol";

contract MockRiscZeroVerifier is IRiscZeroVerifier {
    bytes32 public trustedImageId;
    mapping(bytes32 => bool) public approvedDigests;

    constructor(bytes32 trustedImageId_) {
        trustedImageId = trustedImageId_;
    }

    function approveDigest(bytes32 digest, bool approved) external {
        approvedDigests[digest] = approved;
    }

    function verify(bytes calldata, bytes32 imageId, bytes32 journalDigest) external view returns (bool) {
        return imageId == trustedImageId && approvedDigests[journalDigest];
    }
}
