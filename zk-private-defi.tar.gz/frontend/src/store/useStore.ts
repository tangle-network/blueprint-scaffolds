import { create } from "zustand";
import type {
  StoreShieldedDeposit,
  ShieldedNote,
  CollateralPosition,
  LoanPosition,
  LendingMarket,
  StoreSwapOrder,
  SwapPool,
  ProofStatus,
  StorePortfolioSummary,
  ProtocolStats,
} from "../types";

interface AppState {
  portfolio: StorePortfolioSummary;
  deposits: StoreShieldedDeposit[];
  notes: ShieldedNote[];
  collateralPositions: CollateralPosition[];
  loanPositions: LoanPosition[];
  lendingMarkets: LendingMarket[];
  swapOrders: StoreSwapOrder[];
  swapPools: SwapPool[];
  proofs: ProofStatus[];
  protocolStats: ProtocolStats;

  addDeposit: (deposit: StoreShieldedDeposit) => void;
  addSwapOrder: (order: StoreSwapOrder) => void;
  addProof: (proof: ProofStatus) => void;
  updateProofStatus: (id: string, status: ProofStatus["status"]) => void;
}

const now = Date.now();

export const useStore = create<AppState>((set) => ({
  portfolio: {
    totalShieldedValue: 145832.5,
    totalCollateralValue: 89450.0,
    totalBorrowedValue: 32100.0,
    netWorth: 203182.5,
    healthFactor: 2.14,
    pendingProofs: 2,
    activePositions: 7,
  },

  deposits: [
    {
      id: "dep_001",
      token: "ETH",
      amount: 2.5,
      nullifierHash: "0x1a2b3c4d5e6f7890abcdef1234567890abcdef1234567890abcdef1234567890",
      commitment: "0xabcd1234abcd1234abcd1234abcd1234abcd1234abcd1234abcd1234abcd1234",
      timestamp: now - 86400000 * 2,
      status: "confirmed",
      proofHash: "0xproof001",
    },
    {
      id: "dep_002",
      token: "USDC",
      amount: 15000,
      nullifierHash: "0x2b3c4d5e6f7890abcdef1234567890abcdef1234567890abcdef1234567890ab",
      commitment: "0xbcde2345bcde2345bcde2345bcde2345bcde2345bcde2345bcde2345bcde2345",
      timestamp: now - 86400000,
      status: "confirmed",
      proofHash: "0xproof002",
    },
    {
      id: "dep_003",
      token: "DAI",
      amount: 8500,
      nullifierHash: "0x3c4d5e6f7890abcdef1234567890abcdef1234567890abcdef1234567890abcd",
      commitment: "0xcdef3456cdef3456cdef3456cdef3456cdef3456cdef3456cdef3456cdef3456",
      timestamp: now - 3600000 * 6,
      status: "verified",
      proofHash: "0xproof003",
    },
    {
      id: "dep_004",
      token: "WBTC",
      amount: 0.15,
      nullifierHash: "0x4d5e6f7890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
      commitment: "0xdefa4567defa4567defa4567defa4567defa4567defa4567defa4567defa4567",
      timestamp: now - 3600000 * 2,
      status: "confirmed",
      proofHash: "0xproof004",
    },
    {
      id: "dep_005",
      token: "ETH",
      amount: 1.75,
      nullifierHash: "0x5e6f7890abcdef1234567890abcdef1234567890abcdef1234567890abcdef12",
      commitment: "0xefab5678efab5678efab5678efab5678efab5678efab5678efab5678efab5678",
      timestamp: now - 3600000,
      status: "pending",
      proofHash: "0xproof005",
    },
  ],

  notes: [
    {
      id: "note_001",
      token: "ETH",
      encryptedAmount: "0xenc_2_5_eth",
      commitment: "0xabcd1234abcd1234abcd1234abcd1234abcd1234abcd1234abcd1234abcd1234",
      nullifier: "0x1a2b3c4d5e6f7890abcdef1234567890abcdef1234567890abcdef1234567890",
      createdAt: now - 86400000 * 2,
      spent: false,
    },
    {
      id: "note_002",
      token: "USDC",
      encryptedAmount: "0xenc_15000_usdc",
      commitment: "0xbcde2345bcde2345bcde2345bcde2345bcde2345bcde2345bcde2345bcde2345",
      nullifier: "0x2b3c4d5e6f7890abcdef1234567890abcdef1234567890abcdef1234567890ab",
      createdAt: now - 86400000,
      spent: false,
    },
    {
      id: "note_003",
      token: "DAI",
      encryptedAmount: "0xenc_8500_dai",
      commitment: "0xcdef3456cdef3456cdef3456cdef3456cdef3456cdef3456cdef3456cdef3456",
      nullifier: "0x3c4d5e6f7890abcdef1234567890abcdef1234567890abcdef1234567890abcd",
      createdAt: now - 3600000 * 6,
      spent: true,
    },
    {
      id: "note_004",
      token: "ETH",
      encryptedAmount: "0xenc_1_75_eth",
      commitment: "0xefab5678efab5678efab5678efab5678efab5678efab5678efab5678efab5678",
      nullifier: "0x5e6f7890abcdef1234567890abcdef1234567890abcdef1234567890abcdef12",
      createdAt: now - 3600000,
      spent: false,
    },
  ],

  collateralPositions: [
    {
      id: "coll_001",
      asset: "ETH",
      shieldedAmount: 4.281,
      healthFactor: 2.34,
      liquidationThreshold: 0.8,
      healthStatus: "healthy",
      interestRate: 0.0345,
      accruedInterest: 12.45,
      lastUpdated: now - 3600000,
    },
    {
      id: "coll_002",
      asset: "WBTC",
      shieldedAmount: 0.1542,
      healthFactor: 1.85,
      liquidationThreshold: 0.75,
      healthStatus: "healthy",
      interestRate: 0.0298,
      accruedInterest: 8.32,
      lastUpdated: now - 7200000,
    },
  ],

  loanPositions: [
    {
      id: "loan_001",
      borrowedAsset: "USDC",
      borrowedAmount: 15000,
      interestRate: 0.0512,
      accruedInterest: 42.18,
      collateralId: "coll_001",
      maturityDate: null,
    },
    {
      id: "loan_002",
      borrowedAsset: "DAI",
      borrowedAmount: 8500,
      interestRate: 0.0487,
      accruedInterest: 18.94,
      collateralId: "coll_002",
      maturityDate: null,
    },
  ],

  lendingMarkets: [
    { asset: "ETH", totalDeposits: 45200, totalBorrowed: 28700, supplyAPY: 0.0345, borrowAPY: 0.0512, utilizationRate: 0.635, collateralFactor: 0.82, liquidationThreshold: 0.85, reserveFactor: 0.1 },
    { asset: "USDC", totalDeposits: 128000, totalBorrowed: 96500, supplyAPY: 0.0512, borrowAPY: 0.0734, utilizationRate: 0.754, collateralFactor: 0.75, liquidationThreshold: 0.80, reserveFactor: 0.15 },
    { asset: "DAI", totalDeposits: 87500, totalBorrowed: 54200, supplyAPY: 0.0487, borrowAPY: 0.0698, utilizationRate: 0.619, collateralFactor: 0.77, liquidationThreshold: 0.82, reserveFactor: 0.12 },
    { asset: "WBTC", totalDeposits: 21500, totalBorrowed: 12800, supplyAPY: 0.0298, borrowAPY: 0.0456, utilizationRate: 0.595, collateralFactor: 0.70, liquidationThreshold: 0.75, reserveFactor: 0.1 },
  ],

  swapOrders: [
    {
      id: "swap_001",
      inputToken: "ETH",
      outputToken: "USDC",
      inputAmount: 1.2,
      minOutputAmount: 4104.0,
      estimatedOutput: 4140.25,
      status: "settled",
      proofHash: "0xswap_proof_001",
      createdAt: now - 7200000,
      executedAt: now - 7190000,
    },
    {
      id: "swap_002",
      inputToken: "USDC",
      outputToken: "DAI",
      inputAmount: 5000,
      minOutputAmount: 4985.0,
      estimatedOutput: 4999.5,
      status: "verified",
      proofHash: "0xswap_proof_002",
      createdAt: now - 1800000,
      executedAt: now - 1790000,
    },
    {
      id: "swap_003",
      inputToken: "DAI",
      outputToken: "ETH",
      inputAmount: 3000,
      minOutputAmount: 0.855,
      estimatedOutput: 0.869,
      status: "proving",
      proofHash: null,
      createdAt: now - 300000,
      executedAt: null,
    },
  ],

  swapPools: [
    { pair: "ETH/USDC", tokenA: "ETH", tokenB: "USDC", reserveA: 1245.8, reserveB: 4298010, feeRate: 0.003, volume24h: 12450000 },
    { pair: "ETH/DAI", tokenA: "ETH", tokenB: "DAI", reserveA: 892.3, reserveB: 3078435, feeRate: 0.003, volume24h: 7830000 },
    { pair: "WBTC/ETH", tokenA: "WBTC", tokenB: "ETH", reserveA: 45.2, reserveB: 1274.6, feeRate: 0.003, volume24h: 5420000 },
    { pair: "USDC/DAI", tokenA: "USDC", tokenB: "DAI", reserveA: 892000, reserveB: 891500, feeRate: 0.001, volume24h: 32100000 },
  ],

  proofs: [
    {
      id: "proof_001",
      type: "deposit",
      status: "verified",
      proofBytes: "0xproof_bytes_001",
      publicInputs: ["0xabcd1234", "0x1000"],
      verifierAddress: "0xVerifier00000000000000000000000000000001",
      riscZeroImageId: "0ximage_id_risc_zero_v2",
      journal: "0xjournal_deposit_001",
      createdAt: now - 86400000 * 2,
      completedAt: now - 86400000 * 2 + 4200,
      gasUsed: 284000,
    },
    {
      id: "proof_002",
      type: "swap",
      status: "verified",
      proofBytes: "0xproof_bytes_002",
      publicInputs: ["0xbcde2345", "0x2000"],
      verifierAddress: "0xVerifier00000000000000000000000000000001",
      riscZeroImageId: "0ximage_id_risc_zero_v2",
      journal: "0xjournal_swap_001",
      createdAt: now - 7200000,
      completedAt: now - 7200000 + 6800,
      gasUsed: 342000,
    },
    {
      id: "proof_003",
      type: "interest_proof",
      status: "generating",
      proofBytes: null,
      publicInputs: [],
      verifierAddress: "0xVerifier00000000000000000000000000000001",
      riscZeroImageId: "0ximage_id_risc_zero_v2",
      journal: null,
      createdAt: now - 120000,
      completedAt: null,
      gasUsed: null,
    },
    {
      id: "proof_004",
      type: "withdraw",
      status: "submitted",
      proofBytes: "0xproof_bytes_004_partial",
      publicInputs: ["0xcdef3456"],
      verifierAddress: "0xVerifier00000000000000000000000000000001",
      riscZeroImageId: "0ximage_id_risc_zero_v2",
      journal: null,
      createdAt: now - 60000,
      completedAt: null,
      gasUsed: null,
    },
  ],

  protocolStats: {
    totalValueLocked: 1284500000,
    totalShieldedDeposits: 45230,
    activeLoans: 8945,
    totalSwapVolume: 892450000,
    proofsGenerated: 2345678,
    avgProofTime: 4500,
  },

  addDeposit: (deposit) =>
    set((state) => ({ deposits: [...state.deposits, deposit] })),

  addSwapOrder: (order) =>
    set((state) => ({ swapOrders: [...state.swapOrders, order] })),

  addProof: (proof) =>
    set((state) => ({ proofs: [...state.proofs, proof] })),

  updateProofStatus: (id, status) =>
    set((state) => ({
      proofs: state.proofs.map((p) =>
        p.id === id ? { ...p, status } : p
      ),
    })),
}));
