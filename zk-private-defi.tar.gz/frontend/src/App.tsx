import { Routes, Route } from "react-router-dom";
import Layout from "./components/Layout";
import DashboardPage from "./pages/Dashboard";
import LendingPage from "./pages/Lending";
import SwapPage from "./pages/Swap";
import PortfolioPage from "./pages/Portfolio";

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<DashboardPage />} />
        <Route path="/lending" element={<LendingPage />} />
        <Route path="/swap" element={<SwapPage />} />
        <Route path="/portfolio" element={<PortfolioPage />} />
      </Route>
    </Routes>
  );
}
