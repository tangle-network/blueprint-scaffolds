export interface ShieldedDeposit {
  commitment: string;
  nullifier: string;
  amount: number;
  token: string;
  timestamp: number;
}

export interface LendingPosition {
  id: string;
  collateralCommitment: string;
  debtCommitment: string;
  collateralToken: string;
  debtToken: string;
  healthFactor: number;
  interestRate: number;
  lastAccrual: number;
}

export interface SwapOrder {
  id: string;
  inputCommitment: string;
  outputNullifier: string;
  inputToken: string;
  outputToken: string;
  inputAmount: number;
  outputAmount: number;
  status: "pending" | "filled" | "cancelled";
  proof: string;
}

export interface ZKProof {
  journal: string;
  seal: string;
  imageId: string;
}

export interface ProofReceipt {
  proof: ZKProof;
  publicInputs: string[];
}

export interface PortfolioSummary {
  totalDeposited: number;
  totalBorrowed: number;
  healthFactor: number;
  accruedInterest: number;
  positions: LendingPosition[];
  swaps: SwapOrder[];
}

export interface TokenInfo {
  symbol: string;
  name: string;
  address: string;
  decimals: number;
  icon: string;
}

export const TOKENS: TokenInfo[] = [
  { symbol: "ETH", name: "Ether", address: "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE", decimals: 18, icon: "⟠" },
  { symbol: "USDC", name: "USD Coin", address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48", decimals: 6, icon: "💲" },
  { symbol: "DAI", name: "Dai Stablecoin", address: "0x6B175474E89094C44Da98b954EedeAC495271d0F", decimals: 18, icon: "🔶" },
  { symbol: "WBTC", name: "Wrapped BTC", address: "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599", decimals: 8, icon: "₿" },
];

export const MOCK_COMMITMENTS = [
  "0x1a2b3c4d5e6f7890abcdef1234567890abcdef1234567890abcdef1234567890",
  "0x2b3c4d5e6f7890abcdef1234567890abcdef1234567890abcdef1234567890ab",
  "0x3c4d5e6f7890abcdef1234567890abcdef1234567890abcdef1234567890abcd",
  "0x4d5e6f7890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
];
