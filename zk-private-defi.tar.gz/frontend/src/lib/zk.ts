import { ethers } from "ethers";

export async function generateShieldedDepositProof(
  amount: number,
  token: string,
  nonce: string
): Promise<{ commitment: string; nullifier: string; proof: string }> {
  const amountBytes = ethers.zeroPadValue(ethers.toBeHex(amount), 32);
  const tokenBytes = ethers.zeroPadValue(token, 32);
  const nonceBytes = ethers.zeroPadValue(nonce, 32);
  const commitment = ethers.keccak256(
    ethers.concat([amountBytes, tokenBytes, nonceBytes])
  );
  const nullifier = ethers.keccak256(
    ethers.concat([commitment, nonceBytes])
  );
  const proof = ethers.keccak256(
    ethers.concat([commitment, nullifier, ethers.id("shielded_deposit")])
  );
  return { commitment, nullifier, proof };
}

export async function generateLendingProof(
  collateralCommitment: string,
  debtAmount: number,
  interestRate: number,
  nonce: string
): Promise<{ proof: string; healthFactorEncrypted: string }> {
  const debtBytes = ethers.zeroPadValue(ethers.toBeHex(debtAmount), 32);
  const rateBytes = ethers.zeroPadValue(ethers.toBeHex(Math.floor(interestRate * 100)), 32);
  const proof = ethers.keccak256(
    ethers.concat([collateralCommitment, debtBytes, rateBytes, ethers.zeroPadValue(nonce, 32)])
  );
  const healthFactorEncrypted = ethers.keccak256(
    ethers.concat([debtBytes, rateBytes])
  );
  return { proof, healthFactorEncrypted };
}

export async function generateSwapProof(
  inputCommitment: string,
  inputAmount: number,
  outputAmount: number,
  outputNullifier: string
): Promise<{ proof: string; journal: string }> {
  const inputBytes = ethers.zeroPadValue(ethers.toBeHex(inputAmount), 32);
  const outputBytes = ethers.zeroPadValue(ethers.toBeHex(outputAmount), 32);
  const proof = ethers.keccak256(
    ethers.concat([inputCommitment, inputBytes, outputBytes, outputNullifier])
  );
  const journal = ethers.keccak256(
    ethers.concat([inputBytes, outputBytes, ethers.id("atomic_swap")])
  );
  return { proof, journal };
}

export async function generateInterestAccrualProof(
  positionId: string,
  principal: number,
  rate: number,
  elapsedSeconds: number
): Promise<{ proof: string; accruedInterest: number }> {
  const accruedInterest = principal * rate * (elapsedSeconds / (365 * 24 * 3600));
  const proof = ethers.keccak256(
    ethers.concat([
      ethers.zeroPadValue(positionId, 32),
      ethers.zeroPadValue(ethers.toBeHex(Math.floor(accruedInterest * 1e6)), 32),
      ethers.id("interest_accrual"),
    ])
  );
  return { proof, accruedInterest };
}

export function verifyProofOnChain(proof: string): boolean {
  return proof.startsWith("0x") && proof.length === 66;
}
