import { type TokenInfo, TOKENS } from "./types";

const MOCK_PRICES: Record<string, number> = {
  ETH: 3450.21,
  USDC: 1.0,
  DAI: 0.9998,
  WBTC: 97250.0,
};

const MOCK_BALANCES: Record<string, number> = {
  ETH: 4.281,
  USDC: 12500.0,
  DAI: 8300.0,
  WBTC: 0.1542,
};

export function getTokenPrice(symbol: string): number {
  return MOCK_PRICES[symbol] ?? 0;
}

export function getTokenBalance(symbol: string): number {
  return MOCK_BALANCES[symbol] ?? 0;
}

export function getTokenInfo(symbol: string): TokenInfo | undefined {
  return TOKENS.find((t) => t.symbol === symbol);
}

export function getTokenValue(symbol: string): number {
  return getTokenBalance(symbol) * getTokenPrice(symbol);
}

export function getTotalPortfolioValue(): number {
  return TOKENS.reduce((sum, t) => sum + getTokenValue(t.symbol), 0);
}
