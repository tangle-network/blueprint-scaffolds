import { Outlet, NavLink } from "react-router-dom";
import { Shield, Landmark, ArrowLeftRight, Eye, Lock } from "lucide-react";
import { Separator } from "@/components/ui/separator";

const NAV_ITEMS = [
  { to: "/", label: "Shielded Pool", icon: Shield },
  { to: "/lending", label: "Lending", icon: Landmark },
  { to: "/swap", label: "Swap Engine", icon: ArrowLeftRight },
  { to: "/portfolio", label: "Portfolio", icon: Eye },
];

export default function Layout() {
  return (
    <div className="flex min-h-screen">
      <aside className="w-64 border-r bg-card flex flex-col">
        <div className="p-6">
          <h1 className="text-xl font-bold flex items-center gap-2">
            <Lock className="h-5 w-5 text-primary" />
            ZeroDef
          </h1>
          <p className="text-xs text-muted-foreground mt-1">
            Private DeFi on RISC Zero
          </p>
        </div>
        <Separator />
        <nav className="flex-1 p-4 space-y-1">
          {NAV_ITEMS.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              end={to === "/"}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                  isActive
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`
              }
            >
              <Icon className="h-4 w-4" />
              {label}
            </NavLink>
          ))}
        </nav>
        <div className="p-4">
          <Separator className="mb-4" />
          <div className="rounded-md bg-muted p-3">
            <p className="text-xs text-muted-foreground">Proof System</p>
            <p className="text-sm font-semibold text-primary">RISC-ZV zkVM</p>
            <p className="text-xs text-muted-foreground mt-1">
              EVM Verifier Active
            </p>
          </div>
        </div>
      </aside>
      <main className="flex-1 overflow-auto">
        <div className="container max-w-6xl mx-auto p-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
