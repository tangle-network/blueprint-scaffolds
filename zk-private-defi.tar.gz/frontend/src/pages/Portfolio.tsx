import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { TOKENS } from "@/lib/types";
import { getTokenPrice, getTokenBalance, getTokenValue, getTotalPortfolioValue } from "@/lib/tokens";
import { formatUSD } from "@/lib/utils";
import { Eye, EyeOff, Shield, TrendingUp, Lock, BarChart3, Coins } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function PortfolioPage() {
  const [revealed, setRevealed] = useState(false);
  const totalValue = getTotalPortfolioValue();

  const mockLendingSummary = {
    totalCollateral: 4.281 * getTokenPrice("ETH") + 0.1542 * getTokenPrice("WBTC"),
    totalDebt: 3500,
    avgRate: 0.0412,
    accruedInterest: 42.18,
    healthFactor: 2.34,
  };

  const mockSwapSummary = {
    totalSwaps: 23,
    totalVolume: 145000,
    avgSlippage: 0.04,
    lastSwapTime: "2 hours ago",
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Private Portfolio</h1>
          <p className="text-muted-foreground mt-1">
            Your positions are encrypted — toggle visibility to view
          </p>
        </div>
        <Button
          variant="outline"
          onClick={() => setRevealed(!revealed)}
          className="flex items-center gap-2"
        >
          {revealed ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          {revealed ? "Hide Values" : "Reveal Values"}
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Total Value</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">
              {revealed ? formatUSD(totalValue) : "••••••"}
            </p>
            <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
              <Shield className="h-3 w-3 text-primary" />
              ZK Encrypted
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Collateral Deposited</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">
              {revealed ? formatUSD(mockLendingSummary.totalCollateral) : "••••••"}
            </p>
            <p className="text-xs text-green-500 flex items-center gap-1 mt-1">
              <TrendingUp className="h-3 w-3" />
              Earning yield
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Outstanding Debt</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">
              {revealed ? formatUSD(mockLendingSummary.totalDebt) : "••••••"}
            </p>
            <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
              <Lock className="h-3 w-3" />
              {revealed ? `${(mockLendingSummary.avgRate * 100).toFixed(2)}% avg APY` : "Hidden rate"}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Health Factor</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-500">
              {revealed ? mockLendingSummary.healthFactor.toFixed(2) : "••"}
            </p>
            <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
              <Shield className="h-3 w-3" />
              {revealed ? "Above liquidation" : "Private threshold"}
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Coins className="h-5 w-5 text-primary" />
              Token Balances
            </CardTitle>
            <CardDescription>
              Shielded balances — {revealed ? "revealed" : "hidden"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {TOKENS.map((t) => {
                const balance = getTokenBalance(t.symbol);
                const value = getTokenValue(t.symbol);
                const price = getTokenPrice(t.symbol);
                const pct = totalValue > 0 ? (value / totalValue) * 100 : 0;
                return (
                  <div key={t.symbol} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{t.icon}</span>
                        <div>
                          <p className="text-sm font-medium">{t.symbol}</p>
                          <p className="text-xs text-muted-foreground">{t.name}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">
                          {revealed ? balance.toFixed(4) : "••••"}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {revealed ? formatUSD(value) : "••••••"}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Progress value={pct} className="h-1.5 flex-1" />
                      <span className="text-xs text-muted-foreground w-12 text-right">
                        {revealed ? `${pct.toFixed(1)}%` : "••"}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary" />
                Lending Summary
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Accrued Interest</span>
                <span className="font-medium">
                  {revealed ? formatUSD(mockLendingSummary.accruedInterest) : "••••••"}
                </span>
              </div>
              <Separator />
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Avg Interest Rate</span>
                <span className="font-medium">
                  {revealed ? `${(mockLendingSummary.avgRate * 100).toFixed(2)}%` : "••••"}
                </span>
              </div>
              <Separator />
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Health Factor</span>
                <span className="font-bold text-green-500">
                  {revealed ? mockLendingSummary.healthFactor.toFixed(2) : "••"}
                </span>
              </div>
              <Separator />
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Liquidation Threshold</span>
                <span className="font-medium text-primary">Encrypted</span>
              </div>
              <Separator />
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Proof Status</span>
                <span className="font-medium text-green-500">Verified</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-primary" />
                Swap Activity
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Total Swaps</span>
                <span className="font-medium">
                  {revealed ? mockSwapSummary.totalSwaps : "••"}
                </span>
              </div>
              <Separator />
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Total Volume</span>
                <span className="font-medium">
                  {revealed ? formatUSD(mockSwapSummary.totalVolume) : "••••••"}
                </span>
              </div>
              <Separator />
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Avg Slippage</span>
                <span className="font-medium">
                  {revealed ? `${mockSwapSummary.avgSlippage.toFixed(2)}%` : "••••"}
                </span>
              </div>
              <Separator />
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Last Swap</span>
                <span className="font-medium">{mockSwapSummary.lastSwapTime}</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lock className="h-5 w-5 text-primary" />
            Proof Verification Log
          </CardTitle>
          <CardDescription>
            Recent ZK proof verifications on the EVM verifier
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {[
              { type: "Deposit", time: "Just now", status: "Verified" },
              { type: "Swap", time: "2h ago", status: "Verified" },
              { type: "Interest Accrual", time: "4h ago", status: "Verified" },
              { type: "Borrow", time: "1d ago", status: "Verified" },
              { type: "Deposit", time: "3d ago", status: "Verified" },
            ].map((entry, i) => (
              <div key={i} className="flex items-center justify-between py-2 border-b last:border-0">
                <div className="flex items-center gap-3">
                  <div className="h-2 w-2 rounded-full bg-green-500" />
                  <span className="text-sm">{entry.type}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-xs text-muted-foreground">{entry.time}</span>
                  <span className="text-xs text-green-500 font-medium">{entry.status}</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
