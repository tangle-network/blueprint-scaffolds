import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { TOKENS } from "@/lib/types";
import { generateShieldedDepositProof } from "@/lib/zk";
import { generateNullifier, formatUSD } from "@/lib/utils";
import { Shield, Lock, ArrowDownToLine } from "lucide-react";

interface DepositRecord {
  commitment: string;
  nullifier: string;
  token: string;
  amount: number;
  timestamp: number;
}

export default function DashboardPage() {
  const [token, setToken] = useState("ETH");
  const [amount, setAmount] = useState("");
  const [depositing, setDepositing] = useState(false);
  const [deposits, setDeposits] = useState<DepositRecord[]>([]);
  const [lastProof, setLastProof] = useState<string>("");

  async function handleDeposit() {
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) return;
    setDepositing(true);
    try {
      const tokenInfo = TOKENS.find((t) => t.symbol === token)!;
      const nonce = generateNullifier();
      const result = await generateShieldedDepositProof(amt, tokenInfo.address, nonce);
      setLastProof(result.proof);
      setDeposits((prev) => [
        ...prev,
        {
          commitment: result.commitment,
          nullifier: result.nullifier,
          token,
          amount: amt,
          timestamp: Date.now(),
        },
      ]);
      setAmount("");
    } finally {
      setDepositing(false);
    }
  }

  const totalShielded = deposits.reduce((s, d) => {
    const price = { ETH: 3450, USDC: 1, DAI: 1, WBTC: 97250 }[d.token] ?? 0;
    return s + d.amount * price;
  }, 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Shielded Pool</h1>
        <p className="text-muted-foreground mt-1">
          Deposit assets privately using RISC Zero ZK proofs
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              Shielded Deposit
            </CardTitle>
            <CardDescription>
              Your deposit amount is hidden. Only a commitment hash is stored on-chain.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Token</Label>
              <Select value={token} onValueChange={setToken}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TOKENS.map((t) => (
                    <SelectItem key={t.symbol} value={t.symbol}>
                      {t.icon} {t.symbol} — {t.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Amount</Label>
              <Input
                type="number"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
            </div>
            <Button
              className="w-full"
              onClick={handleDeposit}
              disabled={depositing || !amount}
            >
              {depositing ? (
                "Generating ZK Proof..."
              ) : (
                <span className="flex items-center gap-2">
                  <Lock className="h-4 w-4" />
                  Shield Deposit
                </span>
              )}
            </Button>
            {lastProof && (
              <div className="rounded-md bg-muted p-3 text-xs font-mono break-all">
                <span className="text-muted-foreground">Proof: </span>
                {lastProof}
              </div>
            )}
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Pool Statistics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Total Shielded</p>
                  <p className="text-2xl font-bold">{formatUSD(totalShielded)}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Deposits</p>
                  <p className="text-2xl font-bold">{deposits.length}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Active Notes</p>
                  <p className="text-2xl font-bold">{deposits.length}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Proof System</p>
                  <p className="text-2xl font-bold text-primary">RISC-ZV</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Recent Deposits</CardTitle>
            </CardHeader>
            <CardContent>
              {deposits.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-6">
                  No shielded deposits yet
                </p>
              ) : (
                <div className="space-y-3">
                  {deposits.map((d, i) => (
                    <div key={i} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <ArrowDownToLine className="h-4 w-4 text-green-500" />
                        <span className="text-sm font-medium">{d.token}</span>
                      </div>
                      <div className="text-right">
                        <p className="text-xs font-mono text-muted-foreground">
                          {d.commitment.slice(0, 10)}...
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(d.timestamp).toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
