import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { TOKENS, type LendingPosition } from "@/lib/types";
import { generateLendingProof, generateInterestAccrualProof } from "@/lib/zk";
import { generateNullifier, formatUSD } from "@/lib/utils";
import { getTokenPrice } from "@/lib/tokens";
import { Landmark, Lock, TrendingUp, AlertTriangle, Clock } from "lucide-react";

const MOCK_INTEREST_RATES: Record<string, number> = {
  ETH: 0.0345,
  USDC: 0.0512,
  DAI: 0.0487,
  WBTC: 0.0298,
};

export default function LendingPage() {
  const [collateralToken, setCollateralToken] = useState("ETH");
  const [debtToken, setDebtToken] = useState("USDC");
  const [collateralAmount, setCollateralAmount] = useState("");
  const [borrowAmount, setBorrowAmount] = useState("");
  const [borrowing, setBorrowing] = useState(false);
  const [lastProof, setLastProof] = useState("");
  const [positions, setPositions] = useState<LendingPosition[]>([]);

  const collateralPrice = getTokenPrice(collateralToken);
  const debtPrice = getTokenPrice(debtToken);
  const collValue = (parseFloat(collateralAmount) || 0) * collateralPrice;
  const borrowValue = (parseFloat(borrowAmount) || 0) * debtPrice;
  const ltv = collValue > 0 ? (borrowValue / collValue) * 100 : 0;
  const healthFactor = borrowValue > 0 ? (collValue * 0.8) / borrowValue : Infinity;
  const liquidationThreshold = 80;
  const rate = MOCK_INTEREST_RATES[debtToken] || 0.05;

  async function handleBorrow() {
    const cAmt = parseFloat(collateralAmount);
    const bAmt = parseFloat(borrowAmount);
    if (!cAmt || !bAmt || healthFactor < 1.1) return;
    setBorrowing(true);
    try {
      const nonce = generateNullifier();
      const commitment = `0x${nonce.slice(2, 66)}`;
      const result = await generateLendingProof(commitment, bAmt, rate, nonce);
      setLastProof(result.proof);
      const pos: LendingPosition = {
        id: `pos_${Date.now()}`,
        collateralCommitment: commitment,
        debtCommitment: `0x${generateNullifier().slice(2, 66)}`,
        collateralToken,
        debtToken,
        healthFactor: Math.round(healthFactor * 100) / 100,
        interestRate: rate,
        lastAccrual: Date.now(),
      };
      setPositions((prev) => [pos, ...prev]);
      setCollateralAmount("");
      setBorrowAmount("");
    } finally {
      setBorrowing(false);
    }
  }

  async function handleAccrueInterest(pos: LendingPosition) {
    const elapsed = (Date.now() - pos.lastAccrual) / 1000;
    const principal = parseFloat(borrowAmount || "1000");
    const result = await generateInterestAccrualProof(
      pos.id,
      principal,
      pos.interestRate,
      elapsed
    );
    setPositions((prev) =>
      prev.map((p) =>
        p.id === pos.id
          ? { ...p, lastAccrual: Date.now() }
          : p
      )
    );
    setLastProof(result.proof);
  }

  const healthColor =
    healthFactor >= 2
      ? "text-green-500"
      : healthFactor >= 1.5
        ? "text-yellow-500"
        : healthFactor >= 1.1
          ? "text-orange-500"
          : "text-red-500";

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Lending Market</h1>
        <p className="text-muted-foreground mt-1">
          Borrow against shielded collateral with private liquidation thresholds
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Landmark className="h-5 w-5 text-primary" />
              Create Borrow Position
            </CardTitle>
            <CardDescription>
              Collateral amounts and health factors are encrypted via ZK proofs
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Collateral Token</Label>
              <Select value={collateralToken} onValueChange={setCollateralToken}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TOKENS.map((t) => (
                    <SelectItem key={t.symbol} value={t.symbol}>
                      {t.icon} {t.symbol}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Collateral Amount</Label>
              <Input
                type="number"
                placeholder="0.00"
                value={collateralAmount}
                onChange={(e) => setCollateralAmount(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                Collateral value: {formatUSD(collValue)}
              </p>
            </div>
            <div className="space-y-2">
              <Label>Borrow Token</Label>
              <Select value={debtToken} onValueChange={setDebtToken}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TOKENS.map((t) => (
                    <SelectItem key={t.symbol} value={t.symbol}>
                      {t.icon} {t.symbol}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Borrow Amount</Label>
              <Input
                type="number"
                placeholder="0.00"
                value={borrowAmount}
                onChange={(e) => setBorrowAmount(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                Borrow value: {formatUSD(borrowValue)}
              </p>
            </div>

            <Separator />

            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Loan-to-Value</span>
                <span className={ltv > liquidationThreshold ? "text-red-500 font-medium" : "font-medium"}>
                  {ltv.toFixed(1)}%
                </span>
              </div>
              <Progress value={Math.min(ltv, 100)} className="h-2" />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Safe</span>
                <span className="text-red-500">Liquidation: {liquidationThreshold}%</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Health Factor</span>
                <span className={`font-bold ${healthColor}`}>
                  {healthFactor === Infinity ? "∞" : healthFactor.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Interest Rate (APY)</span>
                <span className="font-medium">{(rate * 100).toFixed(2)}%</span>
              </div>
            </div>

            <Button
              className="w-full"
              onClick={handleBorrow}
              disabled={borrowing || !collateralAmount || !borrowAmount || healthFactor < 1.1}
            >
              {borrowing ? "Generating ZK Proof..." : (
                <span className="flex items-center gap-2">
                  <Lock className="h-4 w-4" />
                  Create Shielded Position
                </span>
              )}
            </Button>

            {lastProof && (
              <div className="rounded-md bg-muted p-3 text-xs font-mono break-all">
                <span className="text-muted-foreground">Proof: </span>
                {lastProof}
              </div>
            )}
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Market Rates</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {TOKENS.map((t) => (
                  <div key={t.symbol} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span>{t.icon}</span>
                      <span className="text-sm font-medium">{t.symbol}</span>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">
                        {((MOCK_INTEREST_RATES[t.symbol] || 0) * 100).toFixed(2)}% APY
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {formatUSD(getTokenPrice(t.symbol))} / {t.symbol}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-primary" />
                Active Positions
              </CardTitle>
            </CardHeader>
            <CardContent>
              {positions.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-6">
                  No active lending positions
                </p>
              ) : (
                <div className="space-y-4">
                  {positions.map((pos) => (
                    <div key={pos.id} className="rounded-md border p-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">
                          {pos.collateralToken} → {pos.debtToken}
                        </span>
                        <span className={`text-xs font-bold ${pos.healthFactor >= 2 ? "text-green-500" : pos.healthFactor >= 1.5 ? "text-yellow-500" : "text-red-500"}`}>
                          HF: {pos.healthFactor.toFixed(2)}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span className="font-mono">{pos.collateralCommitment.slice(0, 10)}...</span>
                        <span>{(pos.interestRate * 100).toFixed(2)}% APY</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          {new Date(pos.lastAccrual).toLocaleTimeString()}
                        </span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleAccrueInterest(pos)}
                        >
                          Accrue Interest
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
