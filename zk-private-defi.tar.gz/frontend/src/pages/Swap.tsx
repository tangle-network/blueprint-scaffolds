import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { TOKENS, type SwapOrder } from "@/lib/types";
import { generateSwapProof } from "@/lib/zk";
import { generateNullifier, formatUSD } from "@/lib/utils";
import { getTokenPrice } from "@/lib/tokens";
import { ArrowLeftRight, Lock, ArrowRight, Check, Clock, X } from "lucide-react";

const MOCK_POOL_RATES: Record<string, Record<string, number>> = {
  ETH: { USDC: 3450, DAI: 3448, WBTC: 0.0355 },
  USDC: { ETH: 0.00029, DAI: 0.999, WBTC: 0.0000103 },
  DAI: { ETH: 0.00029, USDC: 1.001, WBTC: 0.0000103 },
  WBTC: { ETH: 28.2, USDC: 97250, DAI: 97200 },
};

export default function SwapPage() {
  const [inputToken, setInputToken] = useState("ETH");
  const [outputToken, setOutputToken] = useState("USDC");
  const [inputAmount, setInputAmount] = useState("");
  const [swapping, setSwapping] = useState(false);
  const [lastProof, setLastProof] = useState("");
  const [lastJournal, setLastJournal] = useState("");
  const [orders, setOrders] = useState<SwapOrder[]>([]);

  const exchangeRate = MOCK_POOL_RATES[inputToken]?.[outputToken] ?? 0;
  const inAmt = parseFloat(inputAmount) || 0;
  const outputAmount = inAmt * exchangeRate;
  const inputPrice = getTokenPrice(inputToken);
  const outputPrice = getTokenPrice(outputToken);
  const slippage = 0.003;
  const minOutput = outputAmount * (1 - slippage);
  const priceImpact = inAmt > 100 ? 0.12 : inAmt > 10 ? 0.03 : 0.01;

  function handleSwapTokens() {
    setInputToken(outputToken);
    setOutputToken(inputToken);
    setInputAmount("");
  }

  async function handleSwap() {
    if (!inAmt || inAmt <= 0 || outputAmount <= 0) return;
    setSwapping(true);
    try {
      const inputCommitment = `0x${generateNullifier().slice(2, 66)}`;
      const outputNullifier = generateNullifier();
      const result = await generateSwapProof(
        inputCommitment,
        inAmt,
        outputAmount,
        outputNullifier
      );
      setLastProof(result.proof);
      setLastJournal(result.journal);
      const order: SwapOrder = {
        id: `swap_${Date.now()}`,
        inputCommitment,
        outputNullifier,
        inputToken,
        outputToken,
        inputAmount: inAmt,
        outputAmount,
        status: "filled",
        proof: result.proof,
      };
      setOrders((prev) => [order, ...prev]);
      setInputAmount("");
    } finally {
      setSwapping(false);
    }
  }

  const statusIcon = (status: SwapOrder["status"]) => {
    switch (status) {
      case "filled":
        return <Check className="h-4 w-4 text-green-500" />;
      case "pending":
        return <Clock className="h-4 w-4 text-yellow-500" />;
      case "cancelled":
        return <X className="h-4 w-4 text-red-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Swap Engine</h1>
        <p className="text-muted-foreground mt-1">
          Atomic swaps with hidden amounts via RISC Zero proofs
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ArrowLeftRight className="h-5 w-5 text-primary" />
              Private Swap
            </CardTitle>
            <CardDescription>
              Swap amounts are encrypted — only the proof of valid execution is public
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>You Pay</Label>
              <div className="flex gap-2">
                <Select value={inputToken} onValueChange={setInputToken}>
                  <SelectTrigger className="w-28">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TOKENS.map((t) => (
                      <SelectItem key={t.symbol} value={t.symbol}>
                        {t.icon} {t.symbol}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Input
                  type="number"
                  placeholder="0.00"
                  value={inputAmount}
                  onChange={(e) => setInputAmount(e.target.value)}
                  className="flex-1"
                />
              </div>
              <p className="text-xs text-muted-foreground">
                Value: {formatUSD(inAmt * inputPrice)}
              </p>
            </div>

            <div className="flex justify-center">
              <Button
                variant="outline"
                size="icon"
                onClick={handleSwapTokens}
                className="rounded-full"
              >
                <ArrowRight className="h-4 w-4 rotate-90" />
              </Button>
            </div>

            <div className="space-y-2">
              <Label>You Receive</Label>
              <div className="flex gap-2">
                <Select value={outputToken} onValueChange={setOutputToken}>
                  <SelectTrigger className="w-28">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TOKENS.map((t) => (
                      <SelectItem key={t.symbol} value={t.symbol}>
                        {t.icon} {t.symbol}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="flex-1 h-10 rounded-md border bg-muted px-3 py-2 text-sm">
                  {outputAmount > 0 ? outputAmount.toFixed(6) : "0.00"}
                </div>
              </div>
              <p className="text-xs text-muted-foreground">
                Value: {formatUSD(outputAmount * outputPrice)}
              </p>
            </div>

            <Separator />

            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Exchange Rate</span>
                <span>1 {inputToken} = {exchangeRate.toFixed(6)} {outputToken}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Price Impact</span>
                <span className={priceImpact > 0.1 ? "text-orange-500" : "text-green-500"}>
                  {priceImpact.toFixed(2)}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Min. Received</span>
                <span>{minOutput.toFixed(6)} {outputToken}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Slippage Tolerance</span>
                <span>0.3%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Proof Type</span>
                <span className="text-primary font-medium">Atomic ZK</span>
              </div>
            </div>

            <Button
              className="w-full"
              onClick={handleSwap}
              disabled={swapping || !inputAmount || inputToken === outputToken}
            >
              {swapping ? "Generating ZK Proof..." : (
                <span className="flex items-center gap-2">
                  <Lock className="h-4 w-4" />
                  Execute Shielded Swap
                </span>
              )}
            </Button>

            {lastProof && (
              <div className="space-y-2">
                <div className="rounded-md bg-muted p-3 text-xs font-mono break-all">
                  <span className="text-muted-foreground">Proof: </span>
                  {lastProof}
                </div>
                {lastJournal && (
                  <div className="rounded-md bg-muted p-3 text-xs font-mono break-all">
                    <span className="text-muted-foreground">Journal: </span>
                    {lastJournal}
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Swap History</CardTitle>
            </CardHeader>
            <CardContent>
              {orders.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-6">
                  No swap orders yet
                </p>
              ) : (
                <div className="space-y-3">
                  {orders.map((order) => (
                    <div key={order.id} className="rounded-md border p-3 space-y-1">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {statusIcon(order.status)}
                          <span className="text-sm font-medium">
                            {order.inputToken} → {order.outputToken}
                          </span>
                        </div>
                        <span className="text-xs text-muted-foreground capitalize">
                          {order.status}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>Hidden amounts (ZK)</span>
                        <span className="font-mono">
                          {order.inputCommitment.slice(0, 10)}...
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Pool Liquidity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {TOKENS.map((t) => (
                  <div key={t.symbol} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span>{t.icon}</span>
                      <span className="text-sm">{t.symbol}</span>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">
                        {formatUSD(getTokenPrice(t.symbol) * 25000)}
                      </p>
                      <p className="text-xs text-muted-foreground">Pool Depth</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
