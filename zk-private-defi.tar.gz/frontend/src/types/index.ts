export type {
  ShieldedDeposit as ShieldedDeposit,
  LendingPosition,
  SwapOrder,
  ZKProof,
  ProofReceipt,
  PortfolioSummary as PortfolioSummary,
  TokenInfo,
} from "@/lib/types";

export { TOKENS, MOCK_COMMITMENTS } from "@/lib/types";

export interface ShieldedNote {
  id: string;
  token: string;
  encryptedAmount: string;
  commitment: string;
  nullifier: string;
  createdAt: number;
  spent: boolean;
}

export interface CollateralPosition {
  id: string;
  asset: string;
  shieldedAmount: number;
  healthFactor: number;
  liquidationThreshold: number;
  healthStatus: "healthy" | "warning" | "at-risk" | "liquidatable";
  interestRate: number;
  accruedInterest: number;
  lastUpdated: number;
}

export interface LoanPosition {
  id: string;
  borrowedAsset: string;
  borrowedAmount: number;
  interestRate: number;
  accruedInterest: number;
  collateralId: string;
  maturityDate: number | null;
}

export interface LendingMarket {
  asset: string;
  totalDeposits: number;
  totalBorrowed: number;
  supplyAPY: number;
  borrowAPY: number;
  utilizationRate: number;
  collateralFactor: number;
  liquidationThreshold: number;
  reserveFactor: number;
}

export interface StoreSwapOrder {
  id: string;
  inputToken: string;
  outputToken: string;
  inputAmount: number;
  minOutputAmount: number;
  estimatedOutput: number;
  status: "pending" | "executing" | "proving" | "verified" | "settled" | "failed";
  proofHash: string | null;
  createdAt: number;
  executedAt: number | null;
}

export interface SwapPool {
  pair: string;
  tokenA: string;
  tokenB: string;
  reserveA: number;
  reserveB: number;
  feeRate: number;
  volume24h: number;
}

export interface ProofStatus {
  id: string;
  type: "deposit" | "withdraw" | "swap" | "liquidation" | "interest_proof";
  status: "generating" | "submitted" | "verifying" | "verified" | "failed";
  proofBytes: string | null;
  publicInputs: string[];
  verifierAddress: string;
  riscZeroImageId: string;
  journal: string | null;
  createdAt: number;
  completedAt: number | null;
  gasUsed: number | null;
}

export interface StorePortfolioSummary {
  totalShieldedValue: number;
  totalCollateralValue: number;
  totalBorrowedValue: number;
  netWorth: number;
  healthFactor: number;
  pendingProofs: number;
  activePositions: number;
}

export interface ProtocolStats {
  totalValueLocked: number;
  totalShieldedDeposits: number;
  activeLoans: number;
  totalSwapVolume: number;
  proofsGenerated: number;
  avgProofTime: number;
}

export interface StoreShieldedDeposit {
  id: string;
  token: string;
  amount: number;
  nullifierHash: string;
  commitment: string;
  timestamp: number;
  status: "pending" | "verified" | "confirmed";
  proofHash: string;
}
