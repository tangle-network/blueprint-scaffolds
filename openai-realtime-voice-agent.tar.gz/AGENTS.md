# Voice Agent App — Build Plan

## Architecture
- **Framework**: Next.js 14 (App Router) with TypeScript
- **Styling**: Tailwind CSS + shadcn/ui
- **Audio**: Web Audio API + WebSocket for realtime streaming
- **State**: React hooks + Context for session management

## Pages
- `/` — Main voice agent interface

## API Routes
- `POST /api/session` — Create/retrieve voice session
- `GET /api/session/[id]/transcript` — Get transcript history
- `POST /api/session/[id]/tool` — Execute a tool call
- `POST /api/session/[id]/interrupt` — Handle interruption

## Components
- `src/components/ui/` — shadcn/ui primitives (Button, Card, Badge, ScrollArea, Tooltip)
- `src/components/VoiceAgent.tsx` — Main orchestrator
- `src/components/MicrophoneControl.tsx` — Mic button with VAD
- `src/components/TranscriptTimeline.tsx` — Chat transcript display
- `src/components/SpeakingIndicator.tsx` — Animated waveform
- `src/components/ToolCallCard.tsx` — Tool call/result display
- `src/components/SessionHeader.tsx` — Session info & controls

## Audio Pipeline
- `src/lib/audio-capture.ts` — Microphone capture via getUserMedia
- `src/lib/audio-stream.ts` — WebSocket audio streaming
- `src/lib/audio-player.ts` — Playback of agent audio responses
- `src/lib/vad.ts` — Voice Activity Detection
- `src/lib/interruption.ts` — Interruption handling (barge-in)

## Backend Logic
- `src/lib/session-store.ts` — In-memory session/transcript store
- `src/lib/tools.ts` — Tool definitions & execution
- `src/lib/safety.ts` — Safety controls (profanity filter, rate limit, max duration)

## Build & Run
```bash
pnpm install && pnpm build
```
