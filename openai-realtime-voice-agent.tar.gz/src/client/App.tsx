import { useEffect, useRef, useState } from "react";

import type { ServerEvent, SessionSnapshot, ToolEvent, TranscriptEntry } from "../shared/protocol";

declare global {
  interface Window {
    webkitSpeechRecognition?: typeof SpeechRecognition;
    SpeechRecognition?: typeof SpeechRecognition;
  }

  interface SpeechRecognition extends EventTarget {
    continuous: boolean;
    interimResults: boolean;
    lang: string;
    onresult: ((event: SpeechRecognitionEvent) => void) | null;
    onerror: ((event: SpeechRecognitionErrorEvent) => void) | null;
    onend: (() => void) | null;
    start(): void;
    stop(): void;
  }

  interface SpeechRecognitionStatic {
    new (): SpeechRecognition;
  }

  interface SpeechRecognitionEvent {
    resultIndex: number;
    results: SpeechRecognitionResultList;
  }

  interface SpeechRecognitionErrorEvent {
    error: string;
  }

  const SpeechRecognition: SpeechRecognitionStatic | undefined;
}

const emptySnapshot: SessionSnapshot = {
  sessionId: "pending",
  status: "idle",
  speaking: {
    user: false,
    agent: false
  },
  transcript: [],
  tools: [],
  audioBytes: 0
};

const suggestedPrompts = [
  "Check my calendar for free time this afternoon",
  "Search onboarding notes for rollback steps",
  "Draft a follow up summary for the CRM"
];

function formatTime(iso: string): string {
  return new Intl.DateTimeFormat(undefined, {
    hour: "numeric",
    minute: "2-digit"
  }).format(new Date(iso));
}

function App() {
  const [snapshot, setSnapshot] = useState<SessionSnapshot>(emptySnapshot);
  const [connected, setConnected] = useState(false);
  const [listening, setListening] = useState(false);
  const [warning, setWarning] = useState<string | null>(null);
  const [composer, setComposer] = useState("");
  const wsRef = useRef<WebSocket | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss" : "ws";
    const socket = new WebSocket(`${protocol}://${window.location.hostname}:3001/ws`);
    wsRef.current = socket;

    socket.addEventListener("open", () => {
      setConnected(true);
      socket.send(JSON.stringify({ type: "session_start" }));
    });

    socket.addEventListener("message", (event) => {
      const payload = JSON.parse(event.data) as ServerEvent;
      if (payload.type === "session_ready" || payload.type === "session_update") {
        setSnapshot(payload.snapshot);
      }
      if (payload.type === "warning") {
        setWarning(payload.message);
      }
      if (payload.type === "agent_interrupted") {
        setWarning(payload.reason);
      }
    });

    socket.addEventListener("close", () => {
      setConnected(false);
      setListening(false);
    });

    const interval = window.setInterval(() => {
      if (socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ type: "ping", at: new Date().toISOString() }));
      }
    }, 10000);

    return () => {
      window.clearInterval(interval);
      socket.close();
    };
  }, []);

  async function startListening() {
    if (listening) {
      return;
    }

    setWarning(null);
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    streamRef.current = stream;
    const recorder = new MediaRecorder(stream, { mimeType: "audio/webm" });
    recorderRef.current = recorder;

    recorder.addEventListener("dataavailable", async (event) => {
      if (event.data.size === 0 || wsRef.current?.readyState !== WebSocket.OPEN) {
        return;
      }

      const buffer = await event.data.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      let binary = "";
      bytes.forEach((value) => {
        binary += String.fromCharCode(value);
      });
      wsRef.current.send(
        JSON.stringify({
          type: "audio_chunk",
          chunkId: crypto.randomUUID(),
          mimeType: recorder.mimeType,
          payload: btoa(binary),
          energy: Math.min(1, event.data.size / 20000)
        })
      );
    });

    recorder.start(350);

    const Recognition = window.SpeechRecognition ?? window.webkitSpeechRecognition;
    if (Recognition) {
      const recognition = new Recognition();
      recognitionRef.current = recognition;
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = "en-US";
      recognition.onresult = (event) => {
        const latest = event.results[event.resultIndex];
        if (!latest) {
          return;
        }
        const transcript = latest[0]?.transcript?.trim();
        if (!transcript || wsRef.current?.readyState !== WebSocket.OPEN) {
          return;
        }
        wsRef.current.send(
          JSON.stringify({
            type: latest.isFinal ? "speech_final" : "speech_interim",
            text: transcript
          })
        );
      };
      recognition.onerror = (event) => {
        setWarning(`Speech recognition error: ${event.error}`);
      };
      recognition.onend = () => {
        if (listening) {
          recognition.start();
        }
      };
      recognition.start();
    } else {
      setWarning("SpeechRecognition is not available in this browser. Audio streaming still works.");
    }

    setListening(true);
  }

  function stopListening() {
    recorderRef.current?.stop();
    recorderRef.current = null;
    recognitionRef.current?.stop();
    recognitionRef.current = null;
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    setListening(false);
  }

  function sendManualPrompt(text: string) {
    if (wsRef.current?.readyState !== WebSocket.OPEN || !text.trim()) {
      return;
    }
    wsRef.current.send(
      JSON.stringify({
        type: "speech_final",
        text: text.trim()
      })
    );
    setComposer("");
  }

  function interruptAgent() {
    wsRef.current?.send(JSON.stringify({ type: "interrupt" }));
  }

  return (
    <div className="shell">
      <section className="hero">
        <div>
          <p className="eyebrow">Realtime Voice Agent</p>
          <h1>Live audio, transcript memory, tool execution, and interruption control.</h1>
        </div>
        <div className="hero-panel">
          <div className="status-row">
            <Indicator label="Connection" active={connected} tone="neutral" />
            <Indicator label="User" active={snapshot.speaking.user || listening} tone="user" />
            <Indicator label="Agent" active={snapshot.speaking.agent} tone="agent" />
          </div>
          <div className="controls">
            <button className="primary" onClick={listening ? stopListening : startListening}>
              {listening ? "Stop Mic" : "Start Mic"}
            </button>
            <button className="ghost" onClick={interruptAgent} disabled={!connected}>
              Interrupt
            </button>
          </div>
          <p className="microcopy">
            Session status: <strong>{snapshot.status}</strong> · Audio streamed:{" "}
            <strong>{Math.round(snapshot.audioBytes / 1024)} KB</strong>
          </p>
        </div>
      </section>

      <section className="grid">
        <div className="panel transcript-panel">
          <div className="panel-header">
            <h2>Transcript Timeline</h2>
            <span>{snapshot.transcript.length} events</span>
          </div>
          <div className="timeline">
            {snapshot.transcript.length === 0 ? (
              <div className="empty-card">Start the microphone or send a prompt to begin the session.</div>
            ) : (
              snapshot.transcript
                .slice()
                .reverse()
                .map((entry) => <TranscriptCard key={entry.id} entry={entry} />)
            )}
          </div>
        </div>

        <div className="stack">
          <div className="panel">
            <div className="panel-header">
              <h2>Tool Activity</h2>
              <span>{snapshot.tools.length} runs</span>
            </div>
            <div className="tool-list">
              {snapshot.tools.length === 0 ? (
                <div className="empty-card">Tool cards appear here when the agent triggers a backend action.</div>
              ) : (
                snapshot.tools.map((tool) => <ToolCard key={tool.id} tool={tool} />)
              )}
            </div>
          </div>

          <div className="panel">
            <div className="panel-header">
              <h2>Quick Prompt</h2>
              <span>Fallback input</span>
            </div>
            <div className="composer">
              <textarea
                value={composer}
                onChange={(event) => setComposer(event.target.value)}
                placeholder="Type a request if you want to test the orchestration without browser speech recognition."
              />
              <div className="prompt-actions">
                <button className="primary" onClick={() => sendManualPrompt(composer)} disabled={!connected}>
                  Send
                </button>
              </div>
              <div className="chips">
                {suggestedPrompts.map((prompt) => (
                  <button key={prompt} className="chip" onClick={() => sendManualPrompt(prompt)}>
                    {prompt}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {warning ? (
            <div className="panel warning-panel">
              <div className="panel-header">
                <h2>Session Notice</h2>
              </div>
              <p>{warning}</p>
            </div>
          ) : null}
        </div>
      </section>
    </div>
  );
}

function Indicator({ label, active, tone }: { label: string; active: boolean; tone: "neutral" | "user" | "agent" }) {
  return (
    <div className={`indicator ${tone} ${active ? "active" : ""}`}>
      <span className="dot" />
      <span>{label}</span>
    </div>
  );
}

function TranscriptCard({ entry }: { entry: TranscriptEntry }) {
  return (
    <article className={`entry ${entry.speaker}`}>
      <div className="entry-meta">
        <span>{entry.speaker}</span>
        <span>{entry.delivery}</span>
        <span>{formatTime(entry.createdAt)}</span>
      </div>
      <p>{entry.text}</p>
    </article>
  );
}

function ToolCard({ tool }: { tool: ToolEvent }) {
  return (
    <article className={`tool-card ${tool.status}`}>
      <div className="entry-meta">
        <span>{tool.toolName}</span>
        <span>{tool.status}</span>
        <span>{formatTime(tool.createdAt)}</span>
      </div>
      <p>{tool.inputSummary}</p>
      {tool.outputSummary ? <p className="tool-output">{tool.outputSummary}</p> : null}
    </article>
  );
}

export default App;
