const blockedPatterns = [
  /reveal .*api key/i,
  /disable .*safety/i,
  /wire money/i,
  /self-harm/i
];

export interface SafetyCheckResult {
  allowed: boolean;
  reason?: string;
}

export function checkVoiceSafety(input: string): SafetyCheckResult {
  const match = blockedPatterns.find((pattern) => pattern.test(input));
  if (match) {
    return {
      allowed: false,
      reason: "Request blocked by voice safety policy"
    };
  }

  return { allowed: true };
}
