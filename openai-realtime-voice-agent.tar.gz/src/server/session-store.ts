import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname } from "node:path";

import { nanoid } from "nanoid";

import type { SessionSnapshot, ToolEvent, TranscriptEntry } from "../shared/protocol.js";

export interface SessionState extends SessionSnapshot {
  liveAgentMessageId?: string;
}

interface PersistedState {
  sessions: Record<string, SessionState>;
}

const emptyState: PersistedState = { sessions: {} };

export class SessionStore {
  constructor(private readonly filePath: string) {}

  async load(sessionId: string): Promise<SessionState> {
    const persisted = await this.read();
    const existing = persisted.sessions[sessionId];
    if (existing) {
      return existing;
    }

    const created: SessionState = {
      sessionId,
      status: "idle",
      speaking: {
        user: false,
        agent: false
      },
      transcript: [],
      tools: [],
      audioBytes: 0
    };

    persisted.sessions[sessionId] = created;
    await this.write(persisted);
    return created;
  }

  async appendTranscript(sessionId: string, entry: Omit<TranscriptEntry, "id" | "createdAt">): Promise<SessionState> {
    const persisted = await this.read();
    const session = persisted.sessions[sessionId] ?? (await this.load(sessionId));
    session.transcript.push({
      id: nanoid(),
      createdAt: new Date().toISOString(),
      ...entry
    });
    persisted.sessions[sessionId] = session;
    await this.write(persisted);
    return session;
  }

  async upsertLiveAgentEntry(sessionId: string, messageId: string, chunk: string): Promise<SessionState> {
    const persisted = await this.read();
    const session = persisted.sessions[sessionId] ?? (await this.load(sessionId));
    const existing = session.transcript.find((entry) => entry.id === messageId);

    if (existing) {
      existing.text += chunk;
      existing.delivery = "interim";
    } else {
      session.transcript.push({
        id: messageId,
        speaker: "agent",
        text: chunk,
        delivery: "interim",
        createdAt: new Date().toISOString()
      });
    }

    session.liveAgentMessageId = messageId;
    persisted.sessions[sessionId] = session;
    await this.write(persisted);
    return session;
  }

  async finalizeLiveAgentEntry(sessionId: string, messageId: string): Promise<SessionState> {
    const persisted = await this.read();
    const session = persisted.sessions[sessionId] ?? (await this.load(sessionId));
    const existing = session.transcript.find((entry) => entry.id === messageId);
    if (existing) {
      existing.delivery = "final";
    }
    delete session.liveAgentMessageId;
    persisted.sessions[sessionId] = session;
    await this.write(persisted);
    return session;
  }

  async setTool(sessionId: string, tool: ToolEvent): Promise<SessionState> {
    const persisted = await this.read();
    const session = persisted.sessions[sessionId] ?? (await this.load(sessionId));
    const index = session.tools.findIndex((entry) => entry.id === tool.id);
    if (index >= 0) {
      session.tools[index] = tool;
    } else {
      session.tools.unshift(tool);
    }
    persisted.sessions[sessionId] = session;
    await this.write(persisted);
    return session;
  }

  async patchSession(sessionId: string, updater: (session: SessionState) => void): Promise<SessionState> {
    const persisted = await this.read();
    const session = persisted.sessions[sessionId] ?? (await this.load(sessionId));
    updater(session);
    persisted.sessions[sessionId] = session;
    await this.write(persisted);
    return session;
  }

  private async read(): Promise<PersistedState> {
    try {
      const raw = await readFile(this.filePath, "utf8");
      return JSON.parse(raw) as PersistedState;
    } catch (error) {
      await mkdir(dirname(this.filePath), { recursive: true });
      await this.write(emptyState);
      return { ...emptyState };
    }
  }

  private async write(state: PersistedState): Promise<void> {
    await mkdir(dirname(this.filePath), { recursive: true });
    await writeFile(this.filePath, JSON.stringify(state, null, 2), "utf8");
  }
}
