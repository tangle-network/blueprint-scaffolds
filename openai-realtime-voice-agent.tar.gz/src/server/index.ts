import { createServer } from "node:http";
import { existsSync } from "node:fs";
import { join, resolve } from "node:path";

import express from "express";
import { WebSocketServer } from "ws";
import { nanoid } from "nanoid";

import type { ClientEvent, ServerEvent } from "../shared/protocol.js";
import { clientEventSchema } from "../shared/protocol.js";
import { AgentOrchestrator } from "./agent-orchestrator.js";
import { SessionStore } from "./session-store.js";

const app = express();
const port = Number(process.env.PORT ?? 3001);
const rootDir = resolve(process.cwd());
const clientDist = join(rootDir, "dist", "client");
const store = new SessionStore(join(rootDir, "data", "transcripts.json"));
const orchestrator = new AgentOrchestrator(store);

app.get("/health", (_req, res) => {
  res.json({ ok: true });
});

if (existsSync(clientDist)) {
  app.use(express.static(clientDist));
}

const server = createServer(app);
const wss = new WebSocketServer({ server, path: "/ws" });

wss.on("connection", (socket) => {
  const sessionId = nanoid();

  const emit = (event: ServerEvent) => {
    socket.send(JSON.stringify(event));
  };

  void orchestrator.ensureSession(sessionId, emit);

  socket.on("message", (raw) => {
    try {
      const message = JSON.parse(raw.toString()) as ClientEvent;
      const event = clientEventSchema.parse(message);

      switch (event.type) {
        case "session_start":
          void orchestrator.ensureSession(sessionId, emit);
          break;
        case "audio_chunk":
          void orchestrator.recordAudio(sessionId, Buffer.byteLength(event.payload), event.energy, emit);
          break;
        case "speech_interim":
          void orchestrator.recordInterim(sessionId, event.text, emit);
          break;
        case "speech_final":
          void orchestrator.recordFinal(sessionId, event.text, emit);
          break;
        case "interrupt":
          void orchestrator.interrupt(sessionId, "Manual interrupt", emit);
          break;
        case "ping":
          emit({
            type: "pong",
            at: event.at
          });
          break;
      }
    } catch (error) {
      emit({
        type: "warning",
        message: error instanceof Error ? error.message : "Invalid event payload"
      });
    }
  });

  socket.on("close", () => {
    void orchestrator.interrupt(sessionId, "Socket closed", emit);
  });
});

server.listen(port, () => {
  console.log(`Realtime voice agent server listening on http://localhost:${port}`);
});
