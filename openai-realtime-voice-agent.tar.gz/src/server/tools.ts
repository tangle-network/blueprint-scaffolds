import type { ToolEvent } from "../shared/protocol.js";

export interface ToolExecution {
  toolName: string;
  inputSummary: string;
  outputSummary: string;
}

function isoNow(): string {
  return new Date().toISOString();
}

export async function runTool(intent: string, text: string): Promise<ToolExecution | null> {
  if (intent === "calendar") {
    return {
      toolName: "calendar.lookup",
      inputSummary: `Checked availability for: ${text}`,
      outputSummary: "Next free focus block is today at 3:30 PM for 45 minutes."
    };
  }

  if (intent === "knowledge") {
    return {
      toolName: "knowledge.search",
      inputSummary: `Searched internal notes for: ${text}`,
      outputSummary: "Found onboarding guidance, deployment notes, and a rollback checklist."
    };
  }

  if (intent === "followup") {
    return {
      toolName: "crm.follow_up",
      inputSummary: `Prepared follow-up action for: ${text}`,
      outputSummary: "Drafted a concise follow-up summary and marked it for user approval."
    };
  }

  return null;
}

export function toStartedTool(id: string, execution: ToolExecution): ToolEvent {
  return {
    id,
    toolName: execution.toolName,
    status: "started",
    inputSummary: execution.inputSummary,
    createdAt: isoNow()
  };
}

export function toFinishedTool(id: string, execution: ToolExecution): ToolEvent {
  return {
    id,
    toolName: execution.toolName,
    status: "completed",
    inputSummary: execution.inputSummary,
    outputSummary: execution.outputSummary,
    createdAt: isoNow()
  };
}
