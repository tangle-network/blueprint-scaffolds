import { nanoid } from "nanoid";

import type { ServerEvent, SessionStatus } from "../shared/protocol.js";
import { checkVoiceSafety } from "./safety.js";
import { SessionStore } from "./session-store.js";
import { runTool, toFinishedTool, toStartedTool } from "./tools.js";

type Emit = (event: ServerEvent) => void;

function detectIntent(text: string): "calendar" | "knowledge" | "followup" | "general" {
  if (/(calendar|schedule|meeting|free time)/i.test(text)) {
    return "calendar";
  }
  if (/(docs|knowledge|playbook|onboarding|notes)/i.test(text)) {
    return "knowledge";
  }
  if (/(follow up|send summary|email|crm)/i.test(text)) {
    return "followup";
  }
  return "general";
}

function buildReply(text: string, toolSummary?: string): string {
  if (toolSummary) {
    return `${toolSummary} I can keep listening if you want to refine the action.`;
  }

  if (/(status|state|what are you doing)/i.test(text)) {
    return "I am listening to live audio, tracking transcript history, and I can interrupt my response when you speak over me.";
  }

  return "I heard you clearly. I can search notes, check scheduling signals, or draft the next action while keeping the transcript in sync.";
}

export class AgentOrchestrator {
  private readonly activeStreams = new Map<string, NodeJS.Timeout[]>();

  constructor(private readonly store: SessionStore) {}

  async ensureSession(sessionId: string, emit: Emit): Promise<void> {
    const snapshot = await this.store.load(sessionId);
    emit({
      type: "session_ready",
      snapshot
    });
  }

  async recordAudio(sessionId: string, bytes: number, energy: number | undefined, emit: Emit): Promise<void> {
    const snapshot = await this.store.patchSession(sessionId, (session) => {
      session.audioBytes += bytes;
      session.speaking.user = (energy ?? 0) > 0.08;
      if (session.speaking.user) {
        session.status = "listening";
      }
    });
    emit({
      type: "session_update",
      snapshot
    });
  }

  async recordInterim(sessionId: string, text: string, emit: Emit): Promise<void> {
    await this.interrupt(sessionId, "User resumed speaking", emit);
    const snapshot = await this.store.patchSession(sessionId, (session) => {
      session.status = "listening";
      session.speaking.user = true;
      const latest = [...session.transcript].reverse().find((entry) => entry.speaker === "user" && entry.delivery === "interim");
      if (latest) {
        latest.text = text;
      } else {
        session.transcript.push({
          id: nanoid(),
          speaker: "user",
          text,
          delivery: "interim",
          createdAt: new Date().toISOString()
        });
      }
    });
    emit({
      type: "session_update",
      snapshot
    });
  }

  async recordFinal(sessionId: string, text: string, emit: Emit): Promise<void> {
    await this.interrupt(sessionId, "User interruption", emit);
    const safety = checkVoiceSafety(text);
    if (!safety.allowed) {
      const snapshot = await this.store.appendTranscript(sessionId, {
        speaker: "system",
        text: safety.reason ?? "Blocked",
        delivery: "final"
      });
      emit({
        type: "warning",
        message: safety.reason ?? "Blocked"
      });
      emit({
        type: "session_update",
        snapshot
      });
      return;
    }

    let snapshot = await this.store.patchSession(sessionId, (session) => {
      session.speaking.user = false;
      session.status = "thinking";
      session.transcript = session.transcript.filter((entry) => !(entry.speaker === "user" && entry.delivery === "interim"));
      session.transcript.push({
        id: nanoid(),
        speaker: "user",
        text,
        delivery: "final",
        createdAt: new Date().toISOString()
      });
    });
    emit({
      type: "session_update",
      snapshot
    });

    const intent = detectIntent(text);
    if (intent !== "general") {
      const execution = await runTool(intent, text);
      if (execution) {
        const toolId = nanoid();
        const started = toStartedTool(toolId, execution);
        snapshot = await this.store.setTool(sessionId, started);
        emit({ type: "tool_started", tool: started });
        emit({ type: "session_update", snapshot });

        const completed = toFinishedTool(toolId, execution);
        snapshot = await this.store.setTool(sessionId, completed);
        emit({ type: "tool_result", tool: completed });
        emit({ type: "session_update", snapshot });

        await this.streamAgentReply(sessionId, buildReply(text, execution.outputSummary), emit);
        return;
      }
    }

    await this.streamAgentReply(sessionId, buildReply(text), emit);
  }

  async interrupt(sessionId: string, reason: string, emit: Emit): Promise<void> {
    const active = this.activeStreams.get(sessionId);
    if (active && active.length > 0) {
      active.forEach((timer) => clearTimeout(timer));
      this.activeStreams.delete(sessionId);
      const snapshot = await this.store.patchSession(sessionId, (session) => {
        session.speaking.agent = false;
        session.status = "listening";
      });
      emit({ type: "agent_interrupted", reason });
      emit({ type: "session_update", snapshot });
    }
  }

  private async streamAgentReply(sessionId: string, fullText: string, emit: Emit): Promise<void> {
    const messageId = nanoid();
    const words = fullText.split(" ");
    const timers: NodeJS.Timeout[] = [];
    const firstSnapshot = await this.store.patchSession(sessionId, (session) => {
      session.status = "speaking";
      session.speaking.agent = true;
    });
    emit({ type: "session_update", snapshot: firstSnapshot });

    words.forEach((word, index) => {
      const timer = setTimeout(async () => {
        const chunk = `${index === 0 ? "" : " "}${word}`;
        const snapshot = await this.store.upsertLiveAgentEntry(sessionId, messageId, chunk);
        emit({ type: "agent_chunk", text: chunk, messageId });
        emit({ type: "session_update", snapshot });

        if (index === words.length - 1) {
          const finished = await this.store.patchSession(sessionId, (session) => {
            session.status = "idle";
            session.speaking.agent = false;
          });
          await this.store.finalizeLiveAgentEntry(sessionId, messageId);
          emit({ type: "session_update", snapshot: finished });
          this.activeStreams.delete(sessionId);
        }
      }, 90 * (index + 1));

      timers.push(timer);
    });

    this.activeStreams.set(sessionId, timers);
  }
}
