import { SafetyCheck } from "@/types/voice"

const BLOCKED_PATTERNS = [
  /\bignore\s+(all\s+)?previous\s+(instructions?|prompts?)\b/i,
  /\b(system|admin|root)\s*(prompt|command|override)\b/i,
  /\byou\s+are\s+now\b/i,
]

const PII_PATTERNS = [
  /\b\d{3}[-.]?\d{2}[-.]?\d{4}\b/,
  /\b\d{16}\b/,
  /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/,
]

export function checkContentSafety(content: string): SafetyCheck {
  for (const pattern of BLOCKED_PATTERNS) {
    if (pattern.test(content)) {
      return { allowed: false, reason: "Content contains potentially harmful instructions" }
    }
  }
  return { allowed: true }
}

export function sanitizeInput(content: string): string {
  let filtered = content
  for (const pattern of PII_PATTERNS) {
    filtered = filtered.replace(pattern, "[REDACTED]")
  }
  return filtered.trim()
}

export function validateAudioChunk(metadata: { size?: number; mimeType?: string }): SafetyCheck {
  const MAX_SIZE = 512 * 1024
  const ALLOWED_TYPES = ["audio/webm", "audio/pcm", "audio/wav", "audio/ogg", "audio/mp4"]

  if (metadata.size && metadata.size > MAX_SIZE) {
    return { allowed: false, reason: `Audio chunk exceeds ${MAX_SIZE / 1024}KB limit` }
  }
  if (metadata.mimeType && !ALLOWED_TYPES.includes(metadata.mimeType)) {
    return { allowed: false, reason: `Unsupported audio format: ${metadata.mimeType}` }
  }
  return { allowed: true }
}

export function rateLimitCheck(sessionId: string, limits: Map<string, { count: number; resetAt: number }>): SafetyCheck {
  const WINDOW_MS = 60_000
  const MAX_REQUESTS = 30
  const now = Date.now()
  const entry = limits.get(sessionId)

  if (!entry || now > entry.resetAt) {
    limits.set(sessionId, { count: 1, resetAt: now + WINDOW_MS })
    return { allowed: true }
  }

  entry.count++
  if (entry.count > MAX_REQUESTS) {
    return { allowed: false, reason: "Rate limit exceeded. Please wait a moment." }
  }
  return { allowed: true }
}
