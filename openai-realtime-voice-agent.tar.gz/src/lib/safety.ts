const RATE_LIMIT_WINDOW = 60_000;
const MAX_REQUESTS_PER_WINDOW = 30;
const MAX_SESSION_DURATION = 30 * 60_000;

const requestCounts = new Map<string, number[]>();

const profanityList = ["fuck", "shit", "damn", "ass", "bitch", "crap"];

export function containsProfanity(text: string): boolean {
  const lower = text.toLowerCase();
  return profanityList.some((word) => lower.includes(word));
}

export function checkRateLimit(sessionId: string): { allowed: boolean; remaining: number } {
  const now = Date.now();
  const requests = requestCounts.get(sessionId) || [];
  const recent = requests.filter((t) => now - t < RATE_LIMIT_WINDOW);
  requestCounts.set(sessionId, recent);

  if (recent.length >= MAX_REQUESTS_PER_WINDOW) {
    return { allowed: false, remaining: 0 };
  }

  recent.push(now);
  requestCounts.set(sessionId, recent);
  return { allowed: true, remaining: MAX_REQUESTS_PER_WINDOW - recent.length };
}

export function isSessionExpired(createdAt: number): boolean {
  return Date.now() - createdAt > MAX_SESSION_DURATION;
}

export function sanitizeInput(text: string): string {
  return text
    .replace(/<[^>]*>/g, "")
    .trim()
    .slice(0, 5000);
}
