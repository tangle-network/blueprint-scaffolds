import { VoiceSession } from "@/types/voice"
import { v4 as uuid } from "uuid"

const sessions = new Map<string, VoiceSession>()

export function createSession(metadata?: Record<string, string>): VoiceSession {
  const session: VoiceSession = {
    id: uuid(),
    createdAt: new Date().toISOString(),
    status: "active",
    metadata: metadata ?? {},
  }
  sessions.set(session.id, session)
  return session
}

export function getSession(id: string): VoiceSession | undefined {
  return sessions.get(id)
}

export function listSessions(): VoiceSession[] {
  return Array.from(sessions.values()).sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  )
}

export function updateSessionStatus(id: string, status: VoiceSession["status"]): VoiceSession | null {
  const session = sessions.get(id)
  if (!session) return null
  session.status = status
  sessions.set(id, session)
  return session
}

export function deleteSession(id: string): boolean {
  return sessions.delete(id)
}
