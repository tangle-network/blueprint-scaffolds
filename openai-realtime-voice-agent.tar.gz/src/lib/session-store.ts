export interface TranscriptEntry {
  id: string;
  role: "user" | "agent" | "tool" | "system";
  content: string;
  timestamp: number;
  toolCallId?: string;
  toolName?: string;
  toolResult?: string;
}

export interface Session {
  id: string;
  createdAt: number;
  transcript: TranscriptEntry[];
  status: "active" | "ended";
  duration: number;
}

const sessions = new Map<string, Session>();

function generateId(): string {
  return `sess_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}

export function createSession(): Session {
  const session: Session = {
    id: generateId(),
    createdAt: Date.now(),
    transcript: [],
    status: "active",
    duration: 0,
  };
  sessions.set(session.id, session);
  return session;
}

export function getSession(id: string): Session | undefined {
  return sessions.get(id);
}

export function addTranscriptEntry(sessionId: string, entry: Omit<TranscriptEntry, "id" | "timestamp">): TranscriptEntry {
  const session = sessions.get(sessionId);
  if (!session) throw new Error("Session not found");
  const full: TranscriptEntry = {
    ...entry,
    id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    timestamp: Date.now(),
  };
  session.transcript.push(full);
  return full;
}

export function getTranscript(sessionId: string): TranscriptEntry[] {
  const session = sessions.get(sessionId);
  if (!session) throw new Error("Session not found");
  return session.transcript;
}

export function endSession(sessionId: string): Session {
  const session = sessions.get(sessionId);
  if (!session) throw new Error("Session not found");
  session.status = "ended";
  session.duration = Date.now() - session.createdAt;
  return session;
}
