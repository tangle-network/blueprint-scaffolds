export class AudioPlayer {
  private context: AudioContext | null = null;
  private queue: ArrayBuffer[] = [];
  private isPlaying = false;

  async start(): Promise<void> {
    this.context = new AudioContext({ sampleRate: 24000 });
  }

  enqueue(audioData: ArrayBuffer): void {
    this.queue.push(audioData);
    if (!this.isPlaying) {
      this.playNext();
    }
  }

  private async playNext(): Promise<void> {
    if (this.queue.length === 0 || !this.context) {
      this.isPlaying = false;
      return;
    }

    this.isPlaying = true;
    const data = this.queue.shift()!;
    const int16 = new Int16Array(data);
    const float32 = new Float32Array(int16.length);

    for (let i = 0; i < int16.length; i++) {
      float32[i] = int16[i] / (int16[i] < 0 ? 0x8000 : 0x7fff);
    }

    const buffer = this.context.createBuffer(1, float32.length, this.context.sampleRate);
    buffer.getChannelData(0).set(float32);

    const source = this.context.createBufferSource();
    source.buffer = buffer;
    source.connect(this.context.destination);
    source.onended = () => this.playNext();
    source.start();
  }

  stop(): void {
    this.queue = [];
    this.isPlaying = false;
    this.context?.close();
    this.context = null;
  }

  get active(): boolean {
    return this.isPlaying;
  }
}
