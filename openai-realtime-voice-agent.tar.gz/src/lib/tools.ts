export interface ToolDefinition {
  name: string;
  description: string;
  parameters: Record<string, { type: string; description: string; required?: boolean }>;
}

export const availableTools: ToolDefinition[] = [
  {
    name: "get_weather",
    description: "Get current weather for a location",
    parameters: {
      location: { type: "string", description: "City name", required: true },
    },
  },
  {
    name: "search_web",
    description: "Search the web for information",
    parameters: {
      query: { type: "string", description: "Search query", required: true },
    },
  },
  {
    name: "set_timer",
    description: "Set a timer for a specified duration",
    parameters: {
      seconds: { type: "number", description: "Duration in seconds", required: true },
    },
  },
];

type ToolHandler = (params: Record<string, unknown>) => Promise<string>;

const toolHandlers: Record<string, ToolHandler> = {
  get_weather: async (params) => {
    const location = params.location as string;
    const conditions = ["sunny", "cloudy", "rainy", "partly cloudy", "windy"];
    const condition = conditions[Math.floor(Math.random() * conditions.length)];
    const temp = Math.floor(Math.random() * 30) + 5;
    return JSON.stringify({ location, condition, temperature: temp, unit: "celsius" });
  },
  search_web: async (params) => {
    const query = params.query as string;
    return JSON.stringify({
      query,
      results: [
        { title: `Result for: ${query}`, snippet: `Information about ${query}` },
        { title: `${query} - Details`, snippet: `Detailed information about ${query}` },
      ],
    });
  },
  set_timer: async (params) => {
    const seconds = params.seconds as number;
    return JSON.stringify({ timerId: `timer_${Date.now()}`, duration: seconds, status: "started" });
  },
};

export async function executeTool(name: string, params: Record<string, unknown>): Promise<string> {
  const handler = toolHandlers[name];
  if (!handler) throw new Error(`Unknown tool: ${name}`);
  return handler(params);
}
