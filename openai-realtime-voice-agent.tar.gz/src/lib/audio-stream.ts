export type ConnectionState = "disconnected" | "connecting" | "connected" | "error";

export class AudioStream {
  private ws: WebSocket | null = null;
  private onStateChange: (state: ConnectionState) => void = () => {};
  private onAudioData: (data: ArrayBuffer) => void = () => {};
  private onTranscript: (text: string, role: "user" | "agent") => void = () => {};
  private onToolCall: (toolName: string, args: Record<string, unknown>) => void = () => {};
  private onToolResult: (result: string) => void = () => {};

  connect(url: string): void {
    this.onStateChange("connecting");
    try {
      this.ws = new WebSocket(url);
      this.ws.binaryType = "arraybuffer";

      this.ws.onopen = () => this.onStateChange("connected");
      this.ws.onclose = () => this.onStateChange("disconnected");
      this.ws.onerror = () => this.onStateChange("error");

      this.ws.onmessage = (event) => {
        if (typeof event.data === "string") {
          const msg = JSON.parse(event.data);
          if (msg.type === "transcript") this.onTranscript(msg.text, msg.role);
          if (msg.type === "tool_call") this.onToolCall(msg.tool_name, msg.args);
          if (msg.type === "tool_result") this.onToolResult(msg.result);
        } else {
          this.onAudioData(event.data);
        }
      };
    } catch {
      this.onStateChange("error");
    }
  }

  sendAudio(chunk: Int16Array): void {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(chunk.buffer);
    }
  }

  sendInterrupt(): void {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: "interrupt" }));
    }
  }

  disconnect(): void {
    this.ws?.close();
    this.ws = null;
  }

  setHandlers(handlers: {
    onStateChange?: (state: ConnectionState) => void;
    onAudioData?: (data: ArrayBuffer) => void;
    onTranscript?: (text: string, role: "user" | "agent") => void;
    onToolCall?: (toolName: string, args: Record<string, unknown>) => void;
    onToolResult?: (result: string) => void;
  }): void {
    if (handlers.onStateChange) this.onStateChange = handlers.onStateChange;
    if (handlers.onAudioData) this.onAudioData = handlers.onAudioData;
    if (handlers.onTranscript) this.onTranscript = handlers.onTranscript;
    if (handlers.onToolCall) this.onToolCall = handlers.onToolCall;
    if (handlers.onToolResult) this.onToolResult = handlers.onToolResult;
  }
}
