import { AudioPlayer } from "./audio-player";

export class InterruptionHandler {
  private player: AudioPlayer | null = null;
  private isAgentSpeaking = false;
  private bargeInEnabled = true;

  setPlayer(player: AudioPlayer): void {
    this.player = player;
  }

  enableBargeIn(enabled: boolean): void {
    this.bargeInEnabled = enabled;
  }

  setAgentSpeaking(speaking: boolean): void {
    this.isAgentSpeaking = speaking;
  }

  canInterrupt(): boolean {
    return this.bargeInEnabled && this.isAgentSpeaking;
  }

  interrupt(): void {
    if (this.canInterrupt()) {
      this.player?.stop();
      this.isAgentSpeaking = false;
    }
  }
}
