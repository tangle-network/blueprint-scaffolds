import { ToolCall, ToolResult } from "@/types/voice"
import { v4 as uuid } from "uuid"

const toolCalls = new Map<string, ToolCall>()

export function createToolCall(sessionId: string, name: string, args: Record<string, unknown>): ToolCall {
  const tc: ToolCall = {
    id: uuid(),
    sessionId,
    name,
    arguments: args,
    status: "pending",
    timestamp: new Date().toISOString(),
  }
  toolCalls.set(tc.id, tc)
  return tc
}

export function getToolCall(id: string): ToolCall | undefined {
  return toolCalls.get(id)
}

export function getToolCallsForSession(sessionId: string): ToolCall[] {
  return Array.from(toolCalls.values())
    .filter((tc) => tc.sessionId === sessionId)
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
}

export function updateToolCallStatus(id: string, status: ToolCall["status"]): ToolCall | null {
  const tc = toolCalls.get(id)
  if (!tc) return null
  tc.status = status
  toolCalls.set(id, tc)
  return tc
}

export function completeToolCall(id: string, result: ToolResult): ToolCall | null {
  const tc = toolCalls.get(id)
  if (!tc) return null
  tc.status = result.success ? "completed" : "failed"
  tc.result = result
  toolCalls.set(id, tc)
  return tc
}

export async function executeTool(name: string, args: Record<string, unknown>): Promise<ToolResult> {
  const start = Date.now()
  try {
    let data: unknown
    switch (name) {
      case "get_weather":
        data = await executeGetWeather(args)
        break
      case "search_knowledge":
        data = await executeSearchKnowledge(args)
        break
      case "schedule_reminder":
        data = await executeScheduleReminder(args)
        break
      case "execute_calculation":
        data = await executeCalculation(args)
        break
      default:
        return { success: false, error: `Unknown tool: ${name}`, durationMs: Date.now() - start }
    }
    return { success: true, data, durationMs: Date.now() - start }
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Unknown error"
    return { success: false, error: message, durationMs: Date.now() - start }
  }
}

async function executeGetWeather(args: Record<string, unknown>) {
  const location = String(args.location ?? "unknown")
  const unit = String(args.unit ?? "celsius")
  const temp = unit === "fahrenheit" ? 72 : 22
  return {
    location,
    temperature: temp,
    unit,
    condition: "partly_cloudy",
    humidity: 65,
    wind_speed: 12,
  }
}

async function executeSearchKnowledge(args: Record<string, unknown>) {
  const query = String(args.query ?? "")
  const limit = Number(args.limit ?? 5)
  return {
    query,
    results: Array.from({ length: Math.min(limit, 3) }, (_, i) => ({
      title: `Knowledge article ${i + 1} for "${query}"`,
      snippet: `Relevant information about ${query} — result ${i + 1}.`,
      relevanceScore: 0.95 - i * 0.1,
    })),
  }
}

async function executeScheduleReminder(args: Record<string, unknown>) {
  return {
    reminderId: uuid(),
    message: String(args.message ?? ""),
    scheduledFor: String(args.datetime ?? ""),
    status: "scheduled",
  }
}

async function executeCalculation(args: Record<string, unknown>) {
  const expression = String(args.expression ?? "")
  const sanitized = expression.replace(/[^0-9+\-*/().%\s]/g, "")
  if (!sanitized.trim()) throw new Error("Invalid expression")
  const fn = new Function(`return (${sanitized})`)
  const result = fn()
  if (typeof result !== "number" || !isFinite(result)) throw new Error("Calculation error")
  return { expression, result }
}
