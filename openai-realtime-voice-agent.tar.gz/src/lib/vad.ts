export class VoiceActivityDetector {
  private threshold: number;
  private speechFrames = 0;
  private silenceFrames = 0;
  private readonly speechThreshold = 5;
  private readonly silenceThreshold = 15;
  private isSpeaking = false;
  private onSpeechStart: (() => void) | null = null;
  private onSpeechEnd: (() => void) | null = null;

  constructor(threshold = 0.015) {
    this.threshold = threshold;
  }

  process(int16: Int16Array): boolean {
    let sum = 0;
    for (let i = 0; i < int16.length; i++) {
      const float = int16[i] / (int16[i] < 0 ? 0x8000 : 0x7fff);
      sum += float * float;
    }
    const rms = Math.sqrt(sum / int16.length);
    const isActive = rms > this.threshold;

    if (isActive) {
      this.speechFrames++;
      this.silenceFrames = 0;
      if (!this.isSpeaking && this.speechFrames >= this.speechThreshold) {
        this.isSpeaking = true;
        this.onSpeechStart?.();
      }
    } else {
      this.silenceFrames++;
      this.speechFrames = 0;
      if (this.isSpeaking && this.silenceFrames >= this.silenceThreshold) {
        this.isSpeaking = false;
        this.onSpeechEnd?.();
      }
    }

    return this.isSpeaking;
  }

  setHandlers(handlers: { onSpeechStart?: () => void; onSpeechEnd?: () => void }): void {
    this.onSpeechStart = handlers.onSpeechStart || null;
    this.onSpeechEnd = handlers.onSpeechEnd || null;
  }

  reset(): void {
    this.speechFrames = 0;
    this.silenceFrames = 0;
    this.isSpeaking = false;
  }

  get speaking(): boolean {
    return this.isSpeaking;
  }
}
