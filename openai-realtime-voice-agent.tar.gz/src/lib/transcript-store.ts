import { TranscriptEntry } from "@/types/voice"
import { v4 as uuid } from "uuid"

const transcripts = new Map<string, TranscriptEntry[]>()

function ensureSession(sessionId: string) {
  if (!transcripts.has(sessionId)) transcripts.set(sessionId, [])
}

export function addEntry(sessionId: string, role: TranscriptEntry["role"], content: string, extra?: Partial<Pick<TranscriptEntry, "audioUrl" | "interrupted">>): TranscriptEntry {
  ensureSession(sessionId)
  const entry: TranscriptEntry = {
    id: uuid(),
    sessionId,
    role,
    content,
    timestamp: new Date().toISOString(),
    ...extra,
  }
  transcripts.get(sessionId)!.push(entry)
  return entry
}

export function getTranscript(sessionId: string): TranscriptEntry[] {
  return transcripts.get(sessionId) ?? []
}

export function clearTranscript(sessionId: string): void {
  transcripts.set(sessionId, [])
}

export function markInterrupted(sessionId: string, entryId: string): TranscriptEntry | null {
  const entries = transcripts.get(sessionId)
  if (!entries) return null
  const entry = entries.find((e) => e.id === entryId)
  if (!entry) return null
  entry.interrupted = true
  return entry
}
