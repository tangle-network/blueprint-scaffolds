import { create } from "zustand"

interface VoiceAgentState {
  isConnected: boolean
  isSpeaking: boolean
  isListening: boolean
  sessionId: string | null
  audioLevel: number
  setConnected: (connected: boolean) => void
  setSpeaking: (speaking: boolean) => void
  setListening: (listening: boolean) => void
  setSessionId: (id: string | null) => void
  setAudioLevel: (level: number) => void
  reset: () => void
}

const initialState = {
  isConnected: false,
  isSpeaking: false,
  isListening: false,
  sessionId: null as string | null,
  audioLevel: 0,
}

export const useVoiceAgentStore = create<VoiceAgentState>((set: (partial: Partial<VoiceAgentState> | ((state: VoiceAgentState) => Partial<VoiceAgentState>)) => void) => ({
  ...initialState,
  setConnected: (connected: boolean) => set({ isConnected: connected }),
  setSpeaking: (speaking: boolean) => set({ isSpeaking: speaking }),
  setListening: (listening: boolean) => set({ isListening: listening }),
  setSessionId: (id: string | null) => set({ sessionId: id }),
  setAudioLevel: (level: number) => set({ audioLevel: Math.max(0, Math.min(1, level)) }),
  reset: () => set(initialState),
}))
