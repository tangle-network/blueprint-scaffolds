import { z } from "zod";

export type Speaker = "user" | "agent" | "system";
export type Delivery = "interim" | "final";
export type SessionStatus = "idle" | "listening" | "thinking" | "speaking";

export interface TranscriptEntry {
  id: string;
  speaker: Speaker;
  text: string;
  delivery: Delivery;
  createdAt: string;
}

export interface ToolEvent {
  id: string;
  toolName: string;
  status: "started" | "completed" | "blocked";
  inputSummary: string;
  outputSummary?: string;
  createdAt: string;
}

export interface SessionSnapshot {
  sessionId: string;
  status: SessionStatus;
  speaking: {
    user: boolean;
    agent: boolean;
  };
  transcript: TranscriptEntry[];
  tools: ToolEvent[];
  audioBytes: number;
}

export const clientEventSchema = z.discriminatedUnion("type", [
  z.object({
    type: z.literal("session_start")
  }),
  z.object({
    type: z.literal("audio_chunk"),
    chunkId: z.string(),
    mimeType: z.string(),
    payload: z.string(),
    energy: z.number().min(0).max(1).optional()
  }),
  z.object({
    type: z.literal("speech_interim"),
    text: z.string().min(1)
  }),
  z.object({
    type: z.literal("speech_final"),
    text: z.string().min(1)
  }),
  z.object({
    type: z.literal("interrupt")
  }),
  z.object({
    type: z.literal("ping"),
    at: z.string()
  })
]);

export type ClientEvent = z.infer<typeof clientEventSchema>;

export type ServerEvent =
  | {
      type: "session_ready";
      snapshot: SessionSnapshot;
    }
  | {
      type: "session_update";
      snapshot: SessionSnapshot;
    }
  | {
      type: "agent_chunk";
      text: string;
      messageId: string;
    }
  | {
      type: "agent_interrupted";
      reason: string;
    }
  | {
      type: "tool_started";
      tool: ToolEvent;
    }
  | {
      type: "tool_result";
      tool: ToolEvent;
    }
  | {
      type: "warning";
      message: string;
    }
  | {
      type: "pong";
      at: string;
    };
