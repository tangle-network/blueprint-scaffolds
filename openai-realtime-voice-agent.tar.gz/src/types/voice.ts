export interface VoiceSession {
  id: string
  createdAt: string
  status: "active" | "paused" | "ended"
  metadata: Record<string, string>
}

export interface TranscriptEntry {
  id: string
  sessionId: string
  role: "user" | "agent" | "system"
  content: string
  timestamp: string
  audioUrl?: string
  interrupted?: boolean
}

export interface ToolCall {
  id: string
  sessionId: string
  name: string
  arguments: Record<string, unknown>
  result?: ToolResult
  status: "pending" | "running" | "completed" | "failed"
  timestamp: string
}

export interface ToolResult {
  success: boolean
  data?: unknown
  error?: string
  durationMs: number
}

export type AgentState =
  | "idle"
  | "listening"
  | "thinking"
  | "speaking"
  | "processing_tool"

export interface AudioLevel {
  level: number
  timestamp: number
}

export interface WebSocketMessage {
  type:
    | "audio_chunk"
    | "transcript"
    | "agent_state"
    | "tool_call"
    | "tool_result"
    | "interrupt"
    | "error"
    | "session_update"
  payload: unknown
}

export interface SafetyCheck {
  allowed: boolean
  reason?: string
  filteredContent?: string
}

export const TOOL_DEFINITIONS = [
  {
    name: "get_weather",
    description: "Get current weather for a location",
    parameters: {
      location: { type: "string", description: "City name or coordinates" },
      unit: { type: "string", enum: ["celsius", "fahrenheit"], default: "celsius" },
    },
  },
  {
    name: "search_knowledge",
    description: "Search the knowledge base for information",
    parameters: {
      query: { type: "string", description: "Search query" },
      limit: { type: "number", default: 5 },
    },
  },
  {
    name: "schedule_reminder",
    description: "Schedule a reminder for the user",
    parameters: {
      message: { type: "string", description: "Reminder text" },
      datetime: { type: "string", description: "ISO datetime string" },
    },
  },
  {
    name: "execute_calculation",
    description: "Execute a mathematical calculation",
    parameters: {
      expression: { type: "string", description: "Math expression to evaluate" },
    },
  },
] as const
