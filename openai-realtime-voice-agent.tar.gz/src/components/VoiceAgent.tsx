"use client";

import { useState, useCallback, useRef, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { SessionHeader } from "@/components/SessionHeader";
import { MicrophoneControl } from "@/components/MicrophoneControl";
import { TranscriptTimeline } from "@/components/TranscriptTimeline";
import { SpeakingIndicator } from "@/components/SpeakingIndicator";
import { ToolCallCard } from "@/components/ToolCallCard";
import { AudioCapture } from "@/lib/audio-capture";
import { AudioPlayer } from "@/lib/audio-player";
import { AudioStream, type ConnectionState } from "@/lib/audio-stream";
import { VoiceActivityDetector } from "@/lib/vad";
import { InterruptionHandler } from "@/lib/interruption";

interface TranscriptEntry {
  id: string;
  role: "user" | "agent" | "tool" | "system";
  content: string;
  timestamp: number;
  toolName?: string;
  toolResult?: string;
}

interface ToolCall {
  id: string;
  name: string;
  args: Record<string, unknown>;
  status: "pending" | "completed" | "error";
  result?: string;
}

export function VoiceAgent() {
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [transcript, setTranscript] = useState<TranscriptEntry[]>([]);
  const [isMicActive, setIsMicActive] = useState(false);
  const [isAgentSpeaking, setIsAgentSpeaking] = useState(false);
  const [connectionState, setConnectionState] = useState<ConnectionState>("disconnected");
  const [toolCalls, setToolCalls] = useState<ToolCall[]>([]);
  const [sessionStatus, setSessionStatus] = useState<"active" | "ended">("active");

  const captureRef = useRef<AudioCapture | null>(null);
  const playerRef = useRef<AudioPlayer | null>(null);
  const streamRef = useRef<AudioStream | null>(null);
  const vadRef = useRef<VoiceActivityDetector | null>(null);
  const interruptionRef = useRef<InterruptionHandler | null>(null);

  useEffect(() => {
    captureRef.current = new AudioCapture();
    playerRef.current = new AudioPlayer();
    streamRef.current = new AudioStream();
    vadRef.current = new VoiceActivityDetector();
    interruptionRef.current = new InterruptionHandler();

    interruptionRef.current.setPlayer(playerRef.current);

    vadRef.current.setHandlers({
      onSpeechStart: () => {
        if (interruptionRef.current?.canInterrupt()) {
          interruptionRef.current.interrupt();
          streamRef.current?.sendInterrupt();
          setIsAgentSpeaking(false);
        }
      },
    });

    streamRef.current.setHandlers({
      onStateChange: setConnectionState,
      onTranscript: (text, role) => {
        const entry: TranscriptEntry = {
          id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
          role,
          content: text,
          timestamp: Date.now(),
        };
        setTranscript((prev) => [...prev, entry]);
      },
      onAudioData: (data) => {
        playerRef.current?.enqueue(data);
        setIsAgentSpeaking(true);
        interruptionRef.current?.setAgentSpeaking(true);
      },
      onToolCall: (toolName, args) => {
        const tc: ToolCall = {
          id: `tool_${Date.now()}`,
          name: toolName,
          args,
          status: "pending",
        };
        setToolCalls((prev) => [...prev, tc]);
      },
      onToolResult: (result) => {
        setToolCalls((prev) =>
          prev.map((tc) =>
            tc.status === "pending"
              ? { ...tc, status: "completed" as const, result }
              : tc
          )
        );
      },
    });

    return () => {
      captureRef.current?.stop();
      playerRef.current?.stop();
      streamRef.current?.disconnect();
    };
  }, []);

  const createSession = useCallback(async () => {
    const res = await fetch("/api/session", { method: "POST" });
    const data = await res.json();
    setSessionId(data.session.id);
    setSessionStatus(data.session.status);
    return data.session.id;
  }, []);

  const toggleMic = useCallback(async () => {
    if (isMicActive) {
      captureRef.current?.stop();
      streamRef.current?.disconnect();
      setIsMicActive(false);
      vadRef.current?.reset();
      return;
    }

    let sid = sessionId;
    if (!sid) {
      sid = await createSession();
    }

    try {
      await captureRef.current?.start((chunk) => {
        vadRef.current?.process(chunk);
        streamRef.current?.sendAudio(chunk);
      });

      streamRef.current?.connect(`ws://localhost:3001/ws/${sid}`);
      setIsMicActive(true);
    } catch (err) {
      console.error("Failed to start microphone:", err);
      setIsMicActive(false);
    }
  }, [isMicActive, sessionId, createSession]);

  const handleInterrupt = useCallback(async () => {
    if (!sessionId) return;
    interruptionRef.current?.interrupt();
    streamRef.current?.sendInterrupt();
    setIsAgentSpeaking(false);

    await fetch(`/api/session/${sessionId}/interrupt`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reason: "User pressed interrupt" }),
    });
  }, [sessionId]);

  const handleEndSession = useCallback(async () => {
    if (!sessionId) return;
    captureRef.current?.stop();
    streamRef.current?.disconnect();
    setIsMicActive(false);

    const res = await fetch(`/api/session/${sessionId}/interrupt`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reason: "Session ended by user", endSession: true }),
    });
    const data = await res.json();
    setSessionStatus(data.session?.status || "ended");
  }, [sessionId]);

  return (
    <div className="container mx-auto max-w-3xl px-4 py-6 space-y-4">
      <SessionHeader
        sessionId={sessionId}
        connectionState={connectionState}
        sessionStatus={sessionStatus}
        onEndSession={handleEndSession}
      />

      <Card>
        <CardContent className="p-4">
          <ScrollArea className="h-[400px]">
            <TranscriptTimeline entries={transcript} />
          </ScrollArea>
        </CardContent>
      </Card>

      {isAgentSpeaking && <SpeakingIndicator />}

      {toolCalls.length > 0 && (
        <div className="space-y-2">
          {toolCalls.map((tc) => (
            <ToolCallCard
              key={tc.id}
              name={tc.name}
              args={tc.args}
              status={tc.status}
              result={tc.result}
            />
          ))}
        </div>
      )}

      <div className="flex justify-center gap-4">
        <MicrophoneControl
          isActive={isMicActive}
          onToggle={toggleMic}
          disabled={sessionStatus === "ended"}
        />

        {isAgentSpeaking && (
          <Badge
            variant="destructive"
            className="cursor-pointer px-4 py-2 text-sm"
            onClick={handleInterrupt}
          >
            Interrupt
          </Badge>
        )}
      </div>
    </div>
  );
}
