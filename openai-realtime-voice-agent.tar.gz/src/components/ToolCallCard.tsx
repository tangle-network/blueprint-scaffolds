"use client";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface ToolCallCardProps {
  name: string;
  args: Record<string, unknown>;
  status: "pending" | "completed" | "error";
  result?: string;
}

const statusConfig: Record<string, { label: string; variant: "default" | "secondary" | "destructive" }> = {
  pending: { label: "Running...", variant: "secondary" },
  completed: { label: "Done", variant: "default" },
  error: { label: "Error", variant: "destructive" },
};

export function ToolCallCard({ name, args, status, result }: ToolCallCardProps) {
  const cfg = statusConfig[status];

  return (
    <Card>
      <CardContent className="p-3 space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-mono text-sm font-semibold">{name}</span>
            <Badge variant={cfg.variant} className="text-xs">{cfg.label}</Badge>
          </div>
        </div>
        <div className="rounded bg-muted px-2 py-1 text-xs font-mono">
          {JSON.stringify(args, null, 2)}
        </div>
        {result && (
          <div className="rounded bg-accent/50 px-2 py-1 text-xs font-mono">
            {result}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
