"use client";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { ConnectionState } from "@/lib/audio-stream";

interface SessionHeaderProps {
  sessionId: string | null;
  connectionState: ConnectionState;
  sessionStatus: "active" | "ended";
  onEndSession: () => void;
}

const stateLabels: Record<ConnectionState, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  disconnected: { label: "Disconnected", variant: "outline" },
  connecting: { label: "Connecting...", variant: "secondary" },
  connected: { label: "Connected", variant: "default" },
  error: { label: "Error", variant: "destructive" },
};

export function SessionHeader({ sessionId, connectionState, sessionStatus, onEndSession }: SessionHeaderProps) {
  const state = stateLabels[connectionState];

  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-3">
        <h1 className="text-xl font-bold">Voice Agent</h1>
        {sessionId && (
          <Badge variant="outline" className="font-mono text-xs">
            {sessionId.slice(0, 16)}...
          </Badge>
        )}
        <Badge variant={state.variant}>{state.label}</Badge>
        {sessionStatus === "ended" && (
          <Badge variant="secondary">Session Ended</Badge>
        )}
      </div>
      {sessionId && sessionStatus === "active" && (
        <Button variant="ghost" size="sm" onClick={onEndSession}>
          End Session
        </Button>
      )}
    </div>
  );
}
