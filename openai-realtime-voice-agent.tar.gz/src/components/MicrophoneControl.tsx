"use client";

import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Mic, MicOff } from "lucide-react";

interface MicrophoneControlProps {
  isActive: boolean;
  onToggle: () => void;
  disabled?: boolean;
}

export function MicrophoneControl({ isActive, onToggle, disabled }: MicrophoneControlProps) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button
          variant={isActive ? "destructive" : "default"}
          size="lg"
          className={`rounded-full w-16 h-16 shadow-lg transition-all ${
            isActive ? "animate-pulse" : ""
          }`}
          onClick={onToggle}
          disabled={disabled}
        >
          {isActive ? (
            <MicOff className="h-6 w-6" />
          ) : (
            <Mic className="h-6 w-6" />
          )}
        </Button>
      </TooltipTrigger>
      <TooltipContent>
        <p>{isActive ? "Stop recording" : "Start recording"}</p>
      </TooltipContent>
    </Tooltip>
  );
}
