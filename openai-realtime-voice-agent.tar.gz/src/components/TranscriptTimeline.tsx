"use client";

import { useEffect, useRef } from "react";
import { Badge } from "@/components/ui/badge";

interface TranscriptEntry {
  id: string;
  role: "user" | "agent" | "tool" | "system";
  content: string;
  timestamp: number;
  toolName?: string;
  toolResult?: string;
}

interface TranscriptTimelineProps {
  entries: TranscriptEntry[];
}

const roleStyles: Record<string, string> = {
  user: "bg-primary text-primary-foreground ml-auto",
  agent: "bg-muted text-foreground mr-auto",
  tool: "bg-accent text-accent-foreground mr-auto border",
  system: "bg-secondary text-secondary-foreground mx-auto italic",
};

const roleLabels: Record<string, string> = {
  user: "You",
  agent: "Agent",
  tool: "Tool",
  system: "System",
};

export function TranscriptTimeline({ entries }: TranscriptTimelineProps) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [entries.length]);

  if (entries.length === 0) {
    return (
      <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
        Start speaking to see the transcript here
      </div>
    );
  }

  return (
    <div className="space-y-3 p-2">
      {entries.map((entry) => (
        <div key={entry.id} className="flex flex-col gap-1">
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs">
              {roleLabels[entry.role] || entry.role}
            </Badge>
            <span className="text-xs text-muted-foreground">
              {new Date(entry.timestamp).toLocaleTimeString()}
            </span>
          </div>
          <div
            className={`rounded-lg px-3 py-2 text-sm max-w-[80%] ${roleStyles[entry.role] || ""}`}
          >
            {entry.content}
          </div>
          {entry.toolResult && (
            <div className="rounded-md bg-accent/50 px-3 py-1.5 text-xs font-mono max-w-[80%] mr-auto">
              {entry.toolResult}
            </div>
          )}
        </div>
      ))}
      <div ref={bottomRef} />
    </div>
  );
}
