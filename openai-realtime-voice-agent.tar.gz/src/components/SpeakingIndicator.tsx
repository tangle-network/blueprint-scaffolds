"use client";

export function SpeakingIndicator() {
  return (
    <div className="flex items-center justify-center gap-1 py-2">
      {[...Array(5)].map((_, i) => (
        <div
          key={i}
          className="w-1.5 bg-primary rounded-full animate-pulse-wave"
          style={{
            height: "20px",
            animationDelay: `${i * 0.15}s`,
          }}
        />
      ))}
      <span className="ml-3 text-sm text-muted-foreground">Agent is speaking...</span>
    </div>
  );
}
