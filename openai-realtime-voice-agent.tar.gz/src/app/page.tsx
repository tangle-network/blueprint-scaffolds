import { VoiceAgent } from "@/components/VoiceAgent";

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <VoiceAgent />
    </main>
  );
}
