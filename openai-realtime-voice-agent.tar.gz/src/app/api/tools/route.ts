import { NextResponse } from "next/server"
import { z } from "zod"
import { createToolCall, getToolCallsForSession, updateToolCallStatus, completeToolCall, executeTool } from "@/lib/tool-executor"
import { getSession } from "@/lib/session-store"
import { checkContentSafety } from "@/lib/safety"

const executeSchema = z.object({
  sessionId: z.string(),
  toolName: z.string(),
  arguments: z.record(z.unknown()).optional().default({}),
})

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const sessionId = searchParams.get("sessionId")
  if (!sessionId) return NextResponse.json({ error: "sessionId is required" }, { status: 400 })
  return NextResponse.json({ toolCalls: getToolCallsForSession(sessionId) })
}

export async function POST(request: Request) {
  const body = await request.json()
  const parsed = executeSchema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid request", details: parsed.error.flatten() }, { status: 400 })
  }

  const { sessionId, toolName, arguments: args } = parsed.data
  const session = getSession(sessionId)
  if (!session) return NextResponse.json({ error: "Session not found" }, { status: 404 })
  if (session.status !== "active") {
    return NextResponse.json({ error: "Session is not active" }, { status: 400 })
  }

  for (const val of Object.values(args)) {
    if (typeof val === "string") {
      const safety = checkContentSafety(val)
      if (!safety.allowed) return NextResponse.json({ error: safety.reason }, { status: 422 })
    }
  }

  const toolCall = createToolCall(sessionId, toolName, args)
  updateToolCallStatus(toolCall.id, "running")

  const result = await executeTool(toolName, args)
  const completed = completeToolCall(toolCall.id, result)

  return NextResponse.json(completed)
}
