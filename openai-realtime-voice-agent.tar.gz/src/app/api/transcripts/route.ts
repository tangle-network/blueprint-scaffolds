import { NextResponse } from "next/server"
import { getTranscript, addEntry, clearTranscript, markInterrupted } from "@/lib/transcript-store"
import { checkContentSafety, sanitizeInput } from "@/lib/safety"
import { getSession } from "@/lib/session-store"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const sessionId = searchParams.get("sessionId")
  if (!sessionId) return NextResponse.json({ error: "sessionId is required" }, { status: 400 })
  return NextResponse.json({ entries: getTranscript(sessionId) })
}

export async function POST(request: Request) {
  const body = await request.json()
  if (!body.sessionId || !body.content) {
    return NextResponse.json({ error: "sessionId and content are required" }, { status: 400 })
  }
  const session = getSession(body.sessionId)
  if (!session) return NextResponse.json({ error: "Session not found" }, { status: 404 })
  if (session.status === "ended") {
    return NextResponse.json({ error: "Session has ended" }, { status: 400 })
  }

  const sanitized = sanitizeInput(body.content)
  const safety = checkContentSafety(sanitized)
  if (!safety.allowed) {
    return NextResponse.json({ error: safety.reason }, { status: 422 })
  }

  const role = body.role ?? "user"
  const entry = addEntry(body.sessionId, role, sanitized, {
    audioUrl: body.audioUrl,
    interrupted: body.interrupted,
  })
  return NextResponse.json(entry, { status: 201 })
}

export async function PUT(request: Request) {
  const body = await request.json()
  if (body.action === "clear" && body.sessionId) {
    clearTranscript(body.sessionId)
    return NextResponse.json({ success: true })
  }
  if (body.action === "interrupt" && body.sessionId && body.entryId) {
    const entry = markInterrupted(body.sessionId, body.entryId)
    if (!entry) return NextResponse.json({ error: "Entry not found" }, { status: 404 })
    return NextResponse.json(entry)
  }
  return NextResponse.json({ error: "Invalid action" }, { status: 400 })
}
