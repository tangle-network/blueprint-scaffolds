import { NextResponse } from "next/server"
import { getSession, updateSessionStatus, deleteSession } from "@/lib/session-store"
import { getTranscript } from "@/lib/transcript-store"

export async function GET(_request: Request, { params }: { params: { id: string } }) {
  const session = getSession(params.id)
  if (!session) return NextResponse.json({ error: "Session not found" }, { status: 404 })
  const transcript = getTranscript(params.id)
  return NextResponse.json({ ...session, transcript })
}

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  const body = await request.json()
  if (!body.status) return NextResponse.json({ error: "status is required" }, { status: 400 })
  const validStatuses = ["active", "paused", "ended"] as const
  if (!validStatuses.includes(body.status)) {
    return NextResponse.json({ error: "Invalid status" }, { status: 400 })
  }
  const session = updateSessionStatus(params.id, body.status)
  if (!session) return NextResponse.json({ error: "Session not found" }, { status: 404 })
  return NextResponse.json(session)
}

export async function DELETE(_request: Request, { params }: { params: { id: string } }) {
  const deleted = deleteSession(params.id)
  if (!deleted) return NextResponse.json({ error: "Session not found" }, { status: 404 })
  return NextResponse.json({ success: true })
}
