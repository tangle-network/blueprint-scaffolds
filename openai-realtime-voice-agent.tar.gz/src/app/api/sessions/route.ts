import { NextResponse } from "next/server"
import { createSession, listSessions } from "@/lib/session-store"

export async function GET() {
  return NextResponse.json({ sessions: listSessions() })
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}))
  const session = createSession(body.metadata as Record<string, string> | undefined)
  return NextResponse.json(session, { status: 201 })
}
