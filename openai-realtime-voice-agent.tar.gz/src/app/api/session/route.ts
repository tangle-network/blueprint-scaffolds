import { NextRequest, NextResponse } from "next/server";
import { createSession, getSession } from "@/lib/session-store";

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => ({}));
  let session = body.sessionId ? getSession(body.sessionId) : undefined;
  if (!session) {
    session = createSession();
  }
  return NextResponse.json({ session });
}

export async function GET() {
  return NextResponse.json({ error: "Use POST to create a session" }, { status: 405 });
}
