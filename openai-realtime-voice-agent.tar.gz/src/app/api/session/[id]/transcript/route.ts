import { NextRequest, NextResponse } from "next/server";
import { getTranscript, getSession } from "@/lib/session-store";

export async function GET(
  _request: NextRequest,
  { params }: { params: { id: string } }
) {
  const session = getSession(params.id);
  if (!session) {
    return NextResponse.json({ error: "Session not found" }, { status: 404 });
  }
  const transcript = getTranscript(params.id);
  return NextResponse.json({ transcript });
}
