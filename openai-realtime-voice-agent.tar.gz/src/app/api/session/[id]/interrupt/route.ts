import { NextRequest, NextResponse } from "next/server";
import { getSession, endSession, addTranscriptEntry } from "@/lib/session-store";

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const session = getSession(params.id);
  if (!session) {
    return NextResponse.json({ error: "Session not found" }, { status: 404 });
  }

  const body = await request.json().catch(() => ({}));
  const reason = body.reason || "User interrupted";

  addTranscriptEntry(params.id, {
    role: "system",
    content: `Interruption: ${reason}`,
  });

  if (body.endSession) {
    const updated = endSession(params.id);
    return NextResponse.json({ session: updated });
  }

  return NextResponse.json({ success: true, reason });
}
