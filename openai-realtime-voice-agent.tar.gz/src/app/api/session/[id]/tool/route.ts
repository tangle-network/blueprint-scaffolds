import { NextRequest, NextResponse } from "next/server";
import { getSession, addTranscriptEntry } from "@/lib/session-store";
import { executeTool } from "@/lib/tools";
import { checkRateLimit, sanitizeInput } from "@/lib/safety";

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const session = getSession(params.id);
  if (!session) {
    return NextResponse.json({ error: "Session not found" }, { status: 404 });
  }

  const rateLimit = checkRateLimit(params.id);
  if (!rateLimit.allowed) {
    return NextResponse.json({ error: "Rate limit exceeded" }, { status: 429 });
  }

  const body = await request.json();
  const toolName = sanitizeInput(body.toolName || "");
  const toolArgs = body.args || {};

  addTranscriptEntry(params.id, {
    role: "tool",
    content: `Calling tool: ${toolName}`,
    toolName,
  });

  try {
    const result = await executeTool(toolName, toolArgs);
    addTranscriptEntry(params.id, {
      role: "tool",
      content: `Tool result: ${toolName}`,
      toolName,
      toolResult: result,
    });
    return NextResponse.json({ success: true, result });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Tool execution failed";
    return NextResponse.json({ success: false, error: message }, { status: 400 });
  }
}
