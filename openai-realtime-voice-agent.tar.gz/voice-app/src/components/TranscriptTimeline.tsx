import { useEffect, useRef } from "react";
import { useVoiceAgentStore } from "@/store/voice-agent-store";
import type { TranscriptMessage, ToolCall } from "@/types/voice-agent";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { AlertCircle } from "lucide-react";

export function TranscriptTimeline() {
  const transcript = useVoiceAgentStore((s: { transcript: TranscriptMessage[] }) => s.transcript);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [transcript.length]);

  if (transcript.length === 0) {
    return (
      <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
        Start speaking to see the transcript here
      </div>
    );
  }

  return (
    <ScrollArea className="h-full">
      <div className="space-y-3 p-4">
        {transcript.map((msg: TranscriptMessage) => {
          const isUser = msg.role === "user";
          const isSystem = msg.role === "system";

          return (
            <div
              key={msg.id}
              className={`flex flex-col gap-1 ${isUser ? "items-end" : isSystem ? "items-center" : "items-start"}`}
            >
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs">
                  {isUser ? "You" : isSystem ? "System" : "Agent"}
                </Badge>
                <span className="text-xs text-muted-foreground">
                  {new Date(msg.timestamp).toLocaleTimeString()}
                </span>
              </div>

              <Card
                className={`max-w-[80%] ${
                  isUser
                    ? "bg-primary text-primary-foreground border-primary"
                    : isSystem
                      ? "bg-secondary text-secondary-foreground border-secondary italic"
                      : "bg-muted border-muted"
                }`}
              >
                <CardContent className="p-3 text-sm">
                  <p className={msg.isInterrupted ? "line-through opacity-70" : ""}>
                    {msg.content}
                  </p>
                  {msg.isInterrupted && (
                    <div className="flex items-center gap-1 mt-1 text-xs opacity-70">
                      <AlertCircle className="h-3 w-3" />
                      <span>Interrupted</span>
                    </div>
                  )}
                </CardContent>
              </Card>

              {msg.toolCalls && msg.toolCalls.length > 0 && (
                <div className="max-w-[80%] space-y-1.5 ml-4">
                  {msg.toolCalls.map((tc: ToolCall) => (
                    <div
                      key={tc.id}
                      className="rounded-md bg-accent/50 border border-accent px-2.5 py-1.5 text-xs"
                    >
                      <div className="flex items-center gap-1.5 mb-1">
                        <Badge
                          variant={
                            tc.status === "completed"
                              ? "default"
                              : tc.status === "error"
                                ? "destructive"
                                : "secondary"
                          }
                          className="text-[10px] px-1.5 py-0"
                        >
                          {tc.name}
                        </Badge>
                        <span className="text-muted-foreground capitalize">{tc.status}</span>
                      </div>
                      {tc.result && (
                        <p className="text-muted-foreground font-mono text-[10px]">{tc.result}</p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>
    </ScrollArea>
  );
}
