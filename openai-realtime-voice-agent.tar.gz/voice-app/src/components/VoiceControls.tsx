import { useVoiceAgentStore } from "@/store/voice-agent-store";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Mic, MicOff, PhoneOff, Activity } from "lucide-react";

export function VoiceControls() {
  const { isMuted, session, toggleMute, endSession, interrupt, isSpeaking } =
    useVoiceAgentStore();

  const statusVariant =
    session.status === "connected"
      ? "default"
      : session.status === "connecting"
        ? "secondary"
        : session.status === "error"
          ? "destructive"
          : "outline";

  const statusLabel =
    session.status === "connected"
      ? "Connected"
      : session.status === "connecting"
        ? "Connecting..."
        : session.status === "error"
          ? "Error"
          : "Disconnected";

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center gap-3">
        <Badge variant={statusVariant}>{statusLabel}</Badge>
        {session.status === "connected" && (
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Activity className="h-3 w-3" />
            <span>{session.latencyMs}ms</span>
          </div>
        )}
      </div>

      <div className="relative">
        {isSpeaking && !isMuted && (
          <div className="absolute inset-0 rounded-full bg-primary/30 animate-pulse-ring" />
        )}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant={isMuted ? "destructive" : "default"}
              size="lg"
              className={`relative rounded-full w-20 h-20 shadow-lg transition-all ${
                isSpeaking && !isMuted ? "animate-pulse" : ""
              }`}
              onClick={toggleMute}
              disabled={session.status === "idle"}
            >
              {isMuted ? <MicOff className="h-8 w-8" /> : <Mic className="h-8 w-8" />}
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>{isMuted ? "Unmute microphone" : "Mute microphone"}</p>
          </TooltipContent>
        </Tooltip>
      </div>

      <div className="flex gap-2">
        {isSpeaking && (
          <Button variant="destructive" size="sm" onClick={interrupt}>
            Interrupt
          </Button>
        )}
        {session.status !== "idle" && (
          <Button variant="ghost" size="sm" onClick={endSession}>
            <PhoneOff className="h-4 w-4 mr-1" />
            End
          </Button>
        )}
      </div>
    </div>
  );
}
