import { useVoiceAgentStore } from "@/store/voice-agent-store";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TranscriptTimeline } from "@/components/TranscriptTimeline";
import { VoiceControls } from "@/components/VoiceControls";
import { SpeakingIndicator } from "@/components/SpeakingIndicator";
import { ToolCallCard } from "@/components/ToolCallCard";
import { Radio } from "lucide-react";
import type { TranscriptMessage, ToolCall } from "@/types/voice-agent";

export function VoiceAgent() {
  const { session, transcript } = useVoiceAgentStore();

  const allToolCalls: ToolCall[] = transcript
    .flatMap((m: TranscriptMessage) => m.toolCalls ?? [])
    .slice(-4);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="border-b px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Radio className="h-6 w-6 text-primary" />
          <h1 className="text-xl font-bold">Voice Agent</h1>
          <Badge variant="outline" className="font-mono text-xs">
            {session.id.slice(0, 16)}
          </Badge>
        </div>
        <Badge
          variant={
            session.status === "connected"
              ? "default"
              : session.status === "error"
                ? "destructive"
                : "secondary"
          }
        >
          {session.status === "connected"
            ? "Live"
            : session.status === "connecting"
              ? "Connecting..."
              : session.status === "error"
                ? "Error"
                : "Offline"}
        </Badge>
      </header>

      <div className="flex-1 flex overflow-hidden">
        <div className="flex-1 border-r">
          <Card className="h-full rounded-none border-0">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Transcript</CardTitle>
            </CardHeader>
            <CardContent className="p-0" style={{ height: "calc(100vh - 140px)" }}>
              <TranscriptTimeline />
            </CardContent>
          </Card>
        </div>

        <div className="w-[380px] flex flex-col">
          <div className="p-6 border-b">
            <VoiceControls />
          </div>

          <div className="p-6 border-b">
            <SpeakingIndicator />
          </div>

          <div className="flex-1 overflow-auto p-4 space-y-2">
            <h3 className="text-sm font-semibold text-muted-foreground mb-2">Recent Tool Calls</h3>
            {allToolCalls.length === 0 ? (
              <p className="text-xs text-muted-foreground">No tool calls yet</p>
            ) : (
              allToolCalls.map((tc: ToolCall) => <ToolCallCard key={tc.id} toolCall={tc} />)
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
