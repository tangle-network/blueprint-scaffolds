import { useVoiceAgentStore } from "@/store/voice-agent-store";

export function SpeakingIndicator() {
  const { isSpeaking, isThinking, isMuted } = useVoiceAgentStore();

  const statusText = isMuted
    ? "Microphone muted"
    : isThinking
      ? "Agent is thinking..."
      : isSpeaking
        ? "Agent is speaking"
        : "Listening...";

  const isActive = isSpeaking || isThinking;

  return (
    <div className="flex flex-col items-center gap-3 py-4">
      <div className="flex items-end justify-center gap-1 h-8">
        {[...Array(7)].map((_, i) => (
          <div
            key={i}
            className={`w-1.5 rounded-full transition-all ${
              isActive ? "bg-primary animate-pulse-wave" : "bg-muted-foreground/30"
            }`}
            style={{
              height: isActive ? "24px" : "8px",
              animationDelay: isActive ? `${i * 0.12}s` : "0s",
              animationDuration: isActive ? "1.2s" : "0s",
            }}
          />
        ))}
      </div>
      <span className="text-sm text-muted-foreground">{statusText}</span>
    </div>
  );
}
