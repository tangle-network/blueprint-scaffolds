import { create } from "zustand";
import type { TranscriptMessage, ToolCall, VoiceSession } from "@/types/voice-agent";

const BASE_TS = Date.now() - 120_000;

const defaultToolCalls: ToolCall[] = [
  {
    id: "tc_1",
    name: "search_flights",
    arguments: {
      origin: "SFO",
      destination: "JFK",
      date: "2026-04-15",
      passengers: 1,
      class: "economy",
    },
    status: "completed",
    result: "Found 8 flights. Top result: UA-1842 departing 8:30AM, arriving 4:55PM EST, $347",
  },
  {
    id: "tc_2",
    name: "check_seat_availability",
    arguments: { flight_id: "UA-1842", segment: "SFO-JFK" },
    status: "completed",
    result: "12 window seats, 18 aisle seats available. Row 14 exit row available for +$45.",
  },
];

const defaultTranscript: TranscriptMessage[] = [
  {
    id: "msg_1",
    role: "user",
    content: "Hi, I need to book a flight from San Francisco to New York on April 15th.",
    timestamp: BASE_TS,
  },
  {
    id: "msg_2",
    role: "assistant",
    content:
      "I'd be happy to help you find a flight from SFO to JFK on April 15th. Let me search for available flights.",
    timestamp: BASE_TS + 2_000,
    toolCalls: [defaultToolCalls[0]],
  },
  {
    id: "msg_3",
    role: "assistant",
    content:
      "I found several options for you. The best match is United flight UA-1842, departing SFO at 8:30 AM and arriving at JFK at 4:55 PM Eastern for $347 in economy. Would you like me to check seat availability?",
    timestamp: BASE_TS + 5_000,
  },
  {
    id: "msg_4",
    role: "user",
    content: "Yes, are there any window seats available on that flight?",
    timestamp: BASE_TS + 30_000,
  },
  {
    id: "msg_5",
    role: "assistant",
    content: "Let me check the seat map for UA-1842 right away.",
    timestamp: BASE_TS + 32_000,
    toolCalls: [defaultToolCalls[1]],
  },
  {
    id: "msg_6",
    role: "assistant",
    content:
      "Great news! There are 12 window seats available on that flight. There's also an exit row window seat in row 14 for an additional $45, which gives you extra legroom. Would you like to go ahead and book it?",
    timestamp: BASE_TS + 35_000,
  },
  {
    id: "msg_7",
    role: "user",
    content:
      "Actually, wait — I just realized I need to check my calendar first before—",
    timestamp: BASE_TS + 55_000,
    isInterrupted: true,
  },
];

interface VoiceAgentStore {
  transcript: TranscriptMessage[];
  session: VoiceSession;
  isSpeaking: boolean;
  isThinking: boolean;
  isMuted: boolean;
  audioLevel: number;

  sendMessage: (content: string) => void;
  interrupt: () => void;
  toggleMute: () => void;
  startSession: () => void;
  endSession: () => void;
  setAudioLevel: (level: number) => void;
}

export const useVoiceAgentStore = create<VoiceAgentStore>((set, get) => ({
  transcript: defaultTranscript,
  session: {
    id: "sess_demo_001",
    status: "connected",
    audioLevel: 0,
    latencyMs: 142,
  },
  isSpeaking: true,
  isThinking: false,
  isMuted: false,
  audioLevel: 0.65,

  sendMessage: (content: string) => {
    const msg: TranscriptMessage = {
      id: `msg_${Date.now()}`,
      role: "user",
      content,
      timestamp: Date.now(),
    };
    set((s) => ({ transcript: [...s.transcript, msg], isThinking: true }));

    setTimeout(() => {
      const reply: TranscriptMessage = {
        id: `msg_${Date.now()}`,
        role: "assistant",
        content: "I've noted that. Let me process your request.",
        timestamp: Date.now(),
      };
      set((s) => ({
        transcript: [...s.transcript, reply],
        isThinking: false,
        isSpeaking: true,
      }));
    }, 1500);
  },

  interrupt: () => {
    const { transcript } = get();
    const lastIdx = transcript.length - 1;
    if (lastIdx >= 0 && transcript[lastIdx].role === "user" && !transcript[lastIdx].isInterrupted) {
      const updated = [...transcript];
      updated[lastIdx] = { ...updated[lastIdx], isInterrupted: true };
      set({ transcript: updated, isSpeaking: false, isThinking: false });
    } else {
      set({ isSpeaking: false, isThinking: false });
    }
  },

  toggleMute: () => set((s) => ({ isMuted: !s.isMuted })),

  startSession: () =>
    set({
      session: {
        id: `sess_${Date.now()}`,
        status: "connecting",
        audioLevel: 0,
        latencyMs: 0,
      },
      isSpeaking: false,
      isThinking: false,
    }),

  endSession: () =>
    set((s) => ({
      session: { ...s.session, status: "idle" as const },
      isSpeaking: false,
      isThinking: false,
    })),

  setAudioLevel: (level: number) => set({ audioLevel: level }),
}));
