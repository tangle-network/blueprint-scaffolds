export interface ToolCall {
  id: string;
  name: string;
  arguments: Record<string, unknown>;
  status: "pending" | "running" | "completed" | "error";
  result?: string;
}

export interface TranscriptMessage {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: number;
  isInterrupted?: boolean;
  toolCalls?: ToolCall[];
}

export interface VoiceSession {
  id: string;
  status: "idle" | "connecting" | "connected" | "error";
  audioLevel: number;
  latencyMs: number;
}

export interface AgentState {
  isSpeaking: boolean;
  isThinking: boolean;
  currentTranscript: TranscriptMessage[];
  session: VoiceSession;
}
