// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./ZKCreditScoreVerifier.sol";

contract LendingProtocol {
    ZKCreditScoreVerifier public scoreVerifier;

    struct Loan {
        address borrower;
        uint256 amount;
        uint256 interestRate;
        uint256 duration;
        uint256 startTime;
        bool active;
        bool repaid;
    }

    mapping(address => Loan) public loans;
    mapping(address => uint256) public creditBasedLimits;

    uint256 public constant MIN_THRESHOLD = 1;
    uint256 public constant BASE_RATE = 500;
    uint256 public constant RATE_MULTIPLIER = 3;

    event LoanRequested(
        address indexed borrower,
        uint256 amount,
        uint256 interestRate
    );
    event LoanRepaid(address indexed borrower, uint256 amount);
    event CreditLimitUpdated(
        address indexed user,
        uint256 newLimit
    );

    constructor(address _scoreVerifier) {
        scoreVerifier = ZKCreditScoreVerifier(_scoreVerifier);
    }

    function requestLoan(
        uint256 amount,
        uint256[2] calldata _pA,
        uint256[2][2] calldata _pB,
        uint256[2] calldata _pC,
        uint256[] calldata _pubSignals,
        bytes32 nullifier
    ) external {
        require(loans[msg.sender].active == false, "Existing active loan");
        require(amount > 0, "Amount must be positive");

        scoreVerifier.verifyAndStore(
            _pA,
            _pB,
            _pC,
            _pubSignals,
            nullifier
        );

        (, uint256 meetsThreshold, , , bool verified) = scoreVerifier
            .getProof(msg.sender);
        require(verified, "Score not verified");
        require(meetsThreshold >= MIN_THRESHOLD, "Below minimum credit threshold");

        uint256 rate = _calculateRate(meetsThreshold);

        loans[msg.sender] = Loan({
            borrower: msg.sender,
            amount: amount,
            interestRate: rate,
            duration: 365 days,
            startTime: block.timestamp,
            active: true,
            repaid: false
        });

        emit LoanRequested(msg.sender, amount, rate);
    }

    function repayLoan() external payable {
        Loan storage loan = loans[msg.sender];
        require(loan.active, "No active loan");
        require(!loan.repaid, "Already repaid");

        uint256 owed = _calculateOwed(loan);
        require(msg.value >= owed, "Insufficient repayment");

        loan.repaid = true;
        loan.active = false;

        emit LoanRepaid(msg.sender, msg.value);
    }

    function updateCreditLimit(
        uint256[2] calldata _pA,
        uint256[2][2] calldata _pB,
        uint256[2] calldata _pC,
        uint256[] calldata _pubSignals,
        bytes32 nullifier
    ) external {
        scoreVerifier.verifyAndStore(
            _pA,
            _pB,
            _pC,
            _pubSignals,
            nullifier
        );

        (, uint256 meetsThreshold, , , bool verified) = scoreVerifier
            .getProof(msg.sender);
        require(verified, "Score not verified");

        uint256 limit = meetsThreshold * 1 ether;
        creditBasedLimits[msg.sender] = limit;

        emit CreditLimitUpdated(msg.sender, limit);
    }

    function _calculateRate(
        uint256 thresholdLevel
    ) internal pure returns (uint256) {
        return BASE_RATE - (thresholdLevel * RATE_MULTIPLIER);
    }

    function _calculateOwed(
        Loan storage loan
    ) internal view returns (uint256) {
        uint256 elapsed = block.timestamp - loan.startTime;
        uint256 timeFraction = (elapsed * 1e18) / loan.duration;
        return
            loan.amount +
            ((loan.amount * loan.interestRate * timeFraction) / (1e18 * 10000));
    }

    function getLoan(
        address borrower
    )
        external
        view
        returns (
            uint256 amount,
            uint256 interestRate,
            uint256 duration,
            bool active,
            bool repaid
        )
    {
        Loan storage l = loans[borrower];
        return (l.amount, l.interestRate, l.duration, l.active, l.repaid);
    }
}
