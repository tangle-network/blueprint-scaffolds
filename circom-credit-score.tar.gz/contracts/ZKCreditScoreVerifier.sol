// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IVerifier {
    function verifyProof(
        uint256[2] calldata _pA,
        uint256[2][2] calldata _pB,
        uint256[2] calldata _pC,
        uint256[] calldata _pubSignals
    ) external view returns (bool);
}

contract ZKCreditScoreVerifier {
    IVerifier public verifier;

    struct ScoreProof {
        address user;
        uint256 scoreCommitment;
        uint256 meetsThreshold;
        uint256 inRange;
        uint256 timestamp;
        bool verified;
    }

    mapping(address => ScoreProof) public userProofs;
    mapping(bytes32 => bool) public usedNullifiers;

    event ScoreVerified(
        address indexed user,
        uint256 scoreCommitment,
        uint256 meetsThreshold,
        uint256 timestamp
    );

    event ProofInvalidated(address indexed user, uint256 timestamp);

    constructor(address _verifier) {
        verifier = IVerifier(_verifier);
    }

    function verifyAndStore(
        uint256[2] calldata _pA,
        uint256[2][2] calldata _pB,
        uint256[2] calldata _pC,
        uint256[] calldata _pubSignals,
        bytes32 nullifier
    ) external {
        require(!usedNullifiers[nullifier], "Proof already used");

        require(
            verifier.verifyProof(_pA, _pB, _pC, _pubSignals),
            "Invalid ZK proof"
        );

        usedNullifiers[nullifier] = true;

        ScoreProof storage proof = userProofs[msg.sender];
        proof.user = msg.sender;
        proof.scoreCommitment = _pubSignals[0];
        proof.meetsThreshold = _pubSignals.length > 1 ? _pubSignals[1] : 0;
        proof.inRange = _pubSignals.length > 2 ? _pubSignals[2] : 1;
        proof.timestamp = block.timestamp;
        proof.verified = true;

        emit ScoreVerified(
            msg.sender,
            proof.scoreCommitment,
            proof.meetsThreshold,
            block.timestamp
        );
    }

    function isVerified(address user) external view returns (bool) {
        return userProofs[user].verified;
    }

    function getProof(
        address user
    )
        external
        view
        returns (
            uint256 scoreCommitment,
            uint256 meetsThreshold,
            uint256 inRange,
            uint256 timestamp,
            bool verified
        )
    {
        ScoreProof storage p = userProofs[user];
        return (
            p.scoreCommitment,
            p.meetsThreshold,
            p.inRange,
            p.timestamp,
            p.verified
        );
    }

    function invalidateProof() external {
        userProofs[msg.sender].verified = false;
        emit ProofInvalidated(msg.sender, block.timestamp);
    }
}
