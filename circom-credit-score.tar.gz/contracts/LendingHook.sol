// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./ScoreVerifier.sol";

contract LendingHook {
    ScoreVerifier public immutable scoreVerifier;
    uint256 public immutable minScore;

    struct LoanApplication {
        bool approved;
        uint256 amount;
        uint256 rate;
        uint256 appliedAt;
    }

    mapping(address => LoanApplication) public applications;

    event LoanApplied(address indexed borrower, uint256 amount, bool approved);
    event LoanStatusChecked(address indexed borrower, bool approved);

    constructor(address _scoreVerifier, uint256 _minScore) {
        scoreVerifier = ScoreVerifier(_scoreVerifier);
        minScore = _minScore;
    }

    function applyForLoan(
        address borrower,
        uint256 amount,
        uint256[2] calldata _pA,
        uint256[2][2] calldata _pB,
        uint256[2] calldata _pC,
        uint256[] calldata _pubSignals
    ) external returns (bool) {
        bool eligible = scoreVerifier.verifyThreshold(_pA, _pB, _pC, _pubSignals, minScore);
        require(eligible, "Score below minimum threshold");

        uint256 rate = _computeRate(amount);

        applications[borrower] = LoanApplication({
            approved: true,
            amount: amount,
            rate: rate,
            appliedAt: block.timestamp
        });

        emit LoanApplied(borrower, amount, true);
        return true;
    }

    function checkEligibility(
        address borrower,
        uint256[2] calldata _pA,
        uint256[2][2] calldata _pB,
        uint256[2] calldata _pC,
        uint256[] calldata _pubSignals
    ) external view returns (bool) {
        return scoreVerifier.verifyThreshold(_pA, _pB, _pC, _pubSignals, minScore);
    }

    function getLoanStatus(address borrower) external view returns (
        bool approved,
        uint256 amount,
        uint256 rate
    ) {
        LoanApplication memory app = applications[borrower];
        return (app.approved, app.amount, app.rate);
    }

    function _computeRate(uint256 amount) internal pure returns (uint256) {
        if (amount <= 10000e18) return 500;
        if (amount <= 50000e18) return 700;
        return 900;
    }
}
