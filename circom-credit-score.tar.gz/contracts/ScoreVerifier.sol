// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IVerifier {
    function verifyProof(
        uint256[2] calldata _pA,
        uint256[2][2] calldata _pB,
        uint256[2] calldata _pC,
        uint256[] calldata _pubSignals
    ) external view returns (bool);
}

contract ScoreVerifier {
    IVerifier public immutable verifier;

    mapping(address => bytes32) public scoreCommitments;
    mapping(address => uint256) public scoreTimestamps;

    event ScoreStored(address indexed user, bytes32 commitment, uint256 timestamp);
    event ThresholdVerified(address indexed user, uint256 threshold, bool passed);

    constructor(address _verifier) {
        verifier = IVerifier(_verifier);
    }

    function verifyAndStoreScore(
        uint256[2] calldata _pA,
        uint256[2][2] calldata _pB,
        uint256[2] calldata _pC,
        uint256[] calldata _pubSignals
    ) external returns (bool) {
        bool valid = verifier.verifyProof(_pA, _pB, _pC, _pubSignals);
        require(valid, "Invalid proof");

        bytes32 commitment = keccak256(abi.encodePacked(_pubSignals));
        scoreCommitments[msg.sender] = commitment;
        scoreTimestamps[msg.sender] = block.timestamp;

        emit ScoreStored(msg.sender, commitment, block.timestamp);
        return true;
    }

    function verifyThreshold(
        uint256[2] calldata _pA,
        uint256[2][2] calldata _pB,
        uint256[2] calldata _pC,
        uint256[] calldata _pubSignals,
        uint256 _threshold
    ) external view returns (bool) {
        bool valid = verifier.verifyProof(_pA, _pB, _pC, _pubSignals);
        if (!valid) return false;

        uint256 meetsThreshold = _pubSignals[_pubSignals.length - 2];
        if (meetsThreshold != 1) return false;

        uint256 proofThreshold = _pubSignals[1];
        if (proofThreshold != _threshold) return false;

        return true;
    }

    function getScoreCommitment(address user) external view returns (bytes32) {
        return scoreCommitments[user];
    }
}
