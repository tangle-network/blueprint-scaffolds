pragma circom 2.1.0;

template RangeProof(n) {
    signal input in;
    signal input min;
    signal input max;

    signal output inRange;

    signal diffMin;
    diffMin <== in - min;

    signal diffMax;
    diffMax <== max - in;

    signal bitsMin[n];
    signal bitsMax[n];

    bitsMin[0] <== diffMin \ 2;
    bitsMax[0] <== diffMax \ 2;

    for (var i = 1; i < n; i++) {
        bitsMin[i] <== bitsMin[i-1] \ 2;
        bitsMax[i] <== bitsMax[i-1] \ 2;
    }

    signal sumMin;
    sumMin <== min + diffMin;
    sumMin === in;

    signal sumMax;
    sumMax <== in + diffMax;
    sumMax === max;

    inRange <== 1;
}

component main { public [min, max] } = RangeProof(16);
