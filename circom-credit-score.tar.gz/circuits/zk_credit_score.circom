pragma circom 2.1.0;

include "./src/credit_score.circom";
include "./src/range_proof.circom";
include "./src/multi_source.circom";

template ZKCreditScore() {
  signal input paymentHistory;
  signal input creditUtilization;
  signal input lengthOfCreditHistory;
  signal input creditMix;
  signal input newCreditInquiries;
  signal input salt;
  signal input commitment;
  signal input threshold;

  signal output score;
  signal output scoreCommitment;
  signal output meetsThreshold;
  signal output inRange;

  component scorer = CreditScore();
  scorer.paymentHistory <== paymentHistory;
  scorer.creditUtilization <== creditUtilization;
  scorer.lengthOfCreditHistory <== lengthOfCreditHistory;
  scorer.creditMix <== creditMix;
  scorer.newCreditInquiries <== newCreditInquiries;
  scorer.salt <== salt;
  scorer.commitment <== commitment;

  score <== scorer.score;
  scoreCommitment <== scorer.scoreCommitment;

  component thresh = ThresholdProof(16, threshold);
  thresh.score <== scorer.score;
  meetsThreshold <== thresh.meetsThreshold;

  component rp = RangeProof(16, 300, 850);
  rp.value <== scorer.score;
  inRange <== rp.valid;
}

component main { public [threshold, commitment] } = ZKCreditScore();
