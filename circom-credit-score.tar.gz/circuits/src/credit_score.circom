pragma circom 2.1.0;

include "./range_proof.circom";

template CreditScore() {
  signal input paymentHistory;
  signal input creditUtilization;
  signal input lengthOfCreditHistory;
  signal input creditMix;
  signal input newCreditInquiries;

  signal input salt;
  signal input commitment;

  signal output score;
  signal output scoreCommitment;

  signal w1;
  w1 <== paymentHistory * 350;

  signal utilNorm;
  utilNorm <== 1000 - creditUtilization;

  signal w2;
  w2 <== utilNorm * 300;

  signal w3;
  w3 <== lengthOfCreditHistory * 150;

  signal w4;
  w4 <== creditMix * 100;

  signal w5;
  w5 <== (10 - newCreditInquiries) * 100;

  signal raw;
  raw <== w1 + w2 + w3 + w4 + w5;

  signal scaled;
  scaled <== raw \ 1000;

  score <== scaled;

  scoreCommitment <== commitment;
}

template ThresholdProof(n, threshold) {
  signal input score;
  signal output meetsThreshold;

  component gt = GreaterThan(n, threshold);
  gt.value <== score;
  meetsThreshold <== gt.out;
}
