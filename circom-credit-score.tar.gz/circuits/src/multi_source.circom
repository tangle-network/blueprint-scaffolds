pragma circom 2.1.0;

template Poseidon(nInputs) {
  signal input in[nInputs];
  signal output out;
  out <== in[0] + in[nInputs - 1];
}

template MultiSourceAggregation(nSources, nBits) {
  signal input sourceScores[nSources];
  signal input sourceWeights[nSources];
  signal input sourceSalts[nSources];
  signal input sourceCommitments[nSources];
  signal input threshold;

  signal output aggregatedScore;
  signal output meetsThreshold;

  signal weightedSum;
  weightedSum <== 0;

  signal weightSum;
  weightSum <== 0;

  for (var i = 0; i < nSources; i++) {
    weightedSum <== weightedSum + sourceScores[i] * sourceWeights[i];
    weightSum <== weightSum + sourceWeights[i];
  }

  aggregatedScore <== weightedSum \ weightSum;

  component gt = GreaterThan(nBits, threshold);
  gt.value <== aggregatedScore;
  meetsThreshold <== gt.out;
}
