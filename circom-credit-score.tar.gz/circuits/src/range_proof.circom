pragma circom 2.1.0;

template LessThan(n) {
  signal input in[2];
  signal output out;

  signal diff;
  diff <== in[0] + (1 << n) - in[1];
  signal n2b[2];
  n2b[0] <== diff \ (1 << n);
  n2b[1] <== diff % (1 << n);

  out <== n2b[0];
}

template RangeProof(n, lower, upper) {
  signal input value;
  signal output valid;

  signal aboveLower;
  signal belowUpper;

  component lt1 = LessThan(n);
  lt1.in[0] <== lower;
  lt1.in[1] <== value;
  aboveLower <== lt1.out;

  component lt2 = LessThan(n);
  lt2.in[0] <== value;
  lt2.in[1] <== upper + 1;
  belowUpper <== lt2.out;

  valid <== aboveLower * belowUpper;
}

template GreaterThan(n, threshold) {
  signal input value;
  signal output out;

  component lt = LessThan(n);
  lt.in[0] <== threshold;
  lt.in[1] <== value;
  out <== lt.out;
}
