pragma circom 2.1.0;

include "../node_modules/circomlib/circuits/comparators.circom";
include "./range_proof.circom";
include "./credit_score.circom";
include "./multi_source.circom";
