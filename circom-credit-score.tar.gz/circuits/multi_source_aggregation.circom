pragma circom 2.1.0;

template MultiSourceAggregation(nSources) {
    signal input sourceCommitments[nSources];
    signal input sourceWeights[nSources];
    signal input nonce;

    signal output aggregateCommitment;
    signal output sourceCount;

    signal weighted[nSources];
    for (var i = 0; i < nSources; i++) {
        weighted[i] <== sourceCommitments[i] * sourceWeights[i];
    }

    signal agg;
    agg <== weighted[0];
    for (var i = 1; i < nSources; i++) {
        agg <== agg + weighted[i];
    }

    signal weightSum;
    weightSum <== sourceWeights[0];
    for (var i = 1; i < nSources; i++) {
        weightSum <== weightSum + sourceWeights[i];
    }

    aggregateCommitment <== agg / weightSum;
    sourceCount <== nSources;
}

component main { public [nonce] } = MultiSourceAggregation(3);
