pragma circom 2.1.0;

template ThresholdProof() {
    signal input score;
    signal input threshold;
    signal input nonce;

    signal output meetsThreshold;

    signal diff;
    diff <== score - threshold;

    signal bits[16];
    bits[0] <== diff \ 2;
    for (var i = 1; i < 16; i++) {
        bits[i] <== bits[i-1] \ 2;
    }

    signal check;
    check <== threshold + diff;
    check === score;

    meetsThreshold <== 1;
}

component main { public [threshold, nonce] } = ThresholdProof();
