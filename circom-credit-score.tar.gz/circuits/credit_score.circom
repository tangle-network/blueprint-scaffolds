pragma circom 2.1.0;

include "./range_proof.circom";
include "./threshold_proof.circom";
include "./multi_source_aggregation.circom";

template CreditScore() {
    signal input paymentHistory;
    signal input creditUtilization;
    signal input lengthOfHistory;
    signal input creditMix;
    signal input newCredit;
    signal input monthlyIncome;
    signal input totalDebt;
    signal input onTimePayments;
    signal input totalPayments;
    signal input nonce;

    signal output score;

    signal paymentRatio;
    signal paymentScore;
    signal utilRatio;
    signal utilScore;
    signal historyScore;
    signal mixScore;
    signal newCreditScore;

    paymentRatio <== onTimePayments * 10000 / totalPayments;
    paymentScore <== paymentRatio * 100 / 10000;

    signal maxUtil;
    maxUtil <== monthlyIncome;
    signal clampedUtil;
    clampedUtil <== creditUtilization < maxUtil ? creditUtilization : maxUtil;
    signal inverseUtil;
    inverseUtil <== 10000 - (clampedUtil * 10000 / maxUtil);
    utilScore <== inverseUtil * 100 / 10000;

    signal historyRatio;
    historyRatio <== lengthOfHistory * 10000 / 12000;
    historyScore <== historyRatio * 100 / 10000;

    mixScore <== creditMix * 100 / 10;

    signal clampedNew;
    clampedNew <== newCredit < 20 ? newCredit : 19;
    signal inverseNew;
    inverseNew <== 1900 - (clampedNew * 100);
    newCreditScore <== inverseNew * 100 / 1900;

    signal weightedPayment;
    weightedPayment <== paymentScore * 35;
    signal weightedUtil;
    weightedUtil <== utilScore * 30;
    signal weightedHistory;
    weightedHistory <== historyScore * 15;
    signal weightedMix;
    weightedMix <== mixScore * 10;
    signal weightedNew;
    weightedNew <== newCreditScore * 10;

    signal rawScore;
    rawScore <== (weightedPayment + weightedUtil + weightedHistory + weightedMix + weightedNew) / 100;

    signal clampedScore;
    clampedScore <== rawScore < 300 ? 300 : rawScore;
    score <== clampedScore > 850 ? 850 : clampedScore;
}

component main { public [nonce] } = CreditScore();
