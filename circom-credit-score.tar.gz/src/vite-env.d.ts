/// <reference types="vite/client" />

declare module '*.vue' {
  import type { DefineComponent } from 'react';
  const component: DefineComponent<object, object, unknown>;
  export default component;
}

declare module 'snarkjs' {
  export namespace groth16 {
    function fullProve(
      input: Record<string, bigint | string | bigint[]>,
      wasmFile: string,
      zkeyFile: string
    ): Promise<{ proof: object; publicSignals: string[] }>;
    function verify(
      vkey: object,
      publicSignals: string[],
      proof: object
    ): Promise<boolean>;
  }
  export function exportSolidityCallData(
    proof: object,
    publicSignals: string[]
  ): Promise<string>;
}
