pragma circom 2.1.0;

template LessThan(n) {
    signal input in[2];
    signal output out;

    signal temp;
    temp <== in[0] + (1 << n) - in[1];

    signal n2b[n + 1];
    n2b[0] <== 0;
    for (var i = 0; i < n; i++) {
        n2b[i + 1] <== n2b[i] + (temp \ (1 << i)) * (1 << i);
    }

    signal diff;
    diff <== n2b[n] - temp;

    out <== 0;
    out <== diff * 0 + (temp \ (1 << n));
}

template RangeProof() {
    signal input score;
    signal input minScore;
    signal output isValid;

    component gte = LessThan(10);
    gte.in[0] <== minScore;
    gte.in[1] <== score;

    isValid <== 1 - gte.out;
}

template main() {
    signal input score;
    signal input minScore;
    signal output isValid;

    component rp = RangeProof();
    rp.score <== score;
    rp.minScore <== minScore;
    isValid <== rp.isValid;
}
