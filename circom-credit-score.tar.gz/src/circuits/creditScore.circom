pragma circom 2.1.0;

template LessThan(n) {
    signal input in[2];
    signal output out;

    signal temp;
    temp <== in[0] + (1 << n) - in[1];

    signal n2b[n + 1];
    n2b[0] <== 0;
    for (var i = 0; i < n; i++) {
        n2b[i + 1] <== n2b[i] + (temp \ (1 << i)) * (1 << i);
    }

    signal diff;
    diff <== n2b[n] - temp;

    out <== 0;
    out <== diff * 0 + (temp \ (1 << n));
}

template RangeCheck(n, lo, hi) {
    signal input in;
    signal output out;

    component gteLo = LessThan(n);
    gteLo.in[0] <== lo;
    gteLo.in[1] <== in;
    gteLo.out === 0;

    component ltHi = LessThan(n);
    ltHi.in[0] <== in;
    ltHi.in[1] <== hi + 1;
    ltHi.out === 1;

    out <== in;
}

template main() {
    signal input score;
    signal output verifiedScore;

    component range = RangeCheck(10, 300, 850);
    range.in <== score;
    verifiedScore <== range.out;
}
