pragma circom 2.1.0;

template MultiSourceAggregation(nSources) {
    signal input scores[nSources];
    signal input weights[nSources];
    signal output aggregatedScore;

    signal weighted[nSources];
    signal cumulative[nSources + 1];

    cumulative[0] <== 0;

    for (var i = 0; i < nSources; i++) {
        weighted[i] <== scores[i] * weights[i];
        cumulative[i + 1] <== cumulative[i] + weighted[i];
    }

    aggregatedScore <== cumulative[nSources];
}

template main() {
    signal input scores[3];
    signal input weights[3];
    signal output aggregatedScore;

    component agg = MultiSourceAggregation(3);
    for (var i = 0; i < 3; i++) {
        agg.scores[i] <== scores[i];
        agg.weights[i] <== weights[i];
    }
    aggregatedScore <== agg.aggregatedScore;
}
