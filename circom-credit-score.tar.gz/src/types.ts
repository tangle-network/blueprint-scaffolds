export interface FinancialData {
  paymentHistory: number;
  creditUtilization: number;
  lengthOfHistory: number;
  creditMix: number;
  newCredit: number;
  monthlyIncome: number;
  totalDebt: number;
  onTimePayments: number;
  totalPayments: number;
}

export interface DataSource {
  id: string;
  name: string;
  connected: boolean;
  data?: Partial<FinancialData>;
}

export interface ProofResult {
  proof: object;
  publicSignals: string[];
  verified: boolean;
}

export interface ScoreBreakdown {
  paymentScore: number;
  utilizationScore: number;
  historyScore: number;
  mixScore: number;
  newCreditScore: number;
  total: number;
}

export type ProofType = 'score' | 'range' | 'threshold' | 'aggregation';

export interface CircuitInputs {
  paymentHistory: string;
  creditUtilization: string;
  lengthOfHistory: string;
  creditMix: string;
  newCredit: string;
  monthlyIncome: string;
  totalDebt: string;
  onTimePayments: string;
  totalPayments: string;
  threshold?: string;
  nonce: string;
}
