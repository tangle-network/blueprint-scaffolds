import React from 'react';
import { ProofType, ProofResult, ScoreBreakdown } from '../types';

interface Props {
  proofType: ProofType;
  onProofTypeChange: (t: ProofType) => void;
  threshold: number;
  onThresholdChange: (t: number) => void;
  onGenerate: () => void;
  generating: boolean;
  proofResult: ProofResult | null;
  onVerify: () => void;
  verifying: boolean;
  verified: boolean | null;
  score: ScoreBreakdown | null;
}

const PROOF_TYPES: { value: ProofType; label: string }[] = [
  { value: 'score', label: 'Score Proof' },
  { value: 'range', label: 'Range Proof (>700)' },
  { value: 'threshold', label: 'Threshold Proof' },
  { value: 'aggregation', label: 'Aggregation Proof' },
];

export default function ProofGenerator({
  proofType,
  onProofTypeChange,
  threshold,
  onThresholdChange,
  onGenerate,
  generating,
  proofResult,
  onVerify,
  verifying,
  verified,
  score,
}: Props) {
  return (
    <div className="card">
      <h2>Generate ZK Proof</h2>

      <label>Proof Type</label>
      <select value={proofType} onChange={(e) => onProofTypeChange(e.target.value as ProofType)}>
        {PROOF_TYPES.map((pt) => (
          <option key={pt.value} value={pt.value}>
            {pt.label}
          </option>
        ))}
      </select>

      {(proofType === 'threshold' || proofType === 'range') && (
        <>
          <label>Threshold</label>
          <div className="threshold-selector">
            {[600, 650, 700, 740, 780].map((t) => (
              <button
                key={t}
                className={`threshold-btn ${threshold === t ? 'active' : 'btn-secondary'}`}
                onClick={() => onThresholdChange(t)}
                style={{ padding: '0.4rem 0.8rem', border: '1px solid var(--border)' }}
              >
                {t}
              </button>
            ))}
          </div>
        </>
      )}

      <button
        className="btn-primary"
        onClick={onGenerate}
        disabled={generating || !score}
      >
        {generating ? (
          <>
            <span className="loading" /> Generating Proof...
          </>
        ) : (
          'Generate ZK Proof'
        )}
      </button>

      {generating && (
        <div className="steps">
          <div className="step">
            <span className={`step-icon ${generating ? 'active' : 'done'}`}>1</span>
            Preparing circuit inputs...
          </div>
          <div className="step">
            <span className={`step-icon ${generating ? 'pending' : 'done'}`}>2</span>
            Computing witness...
          </div>
          <div className="step">
            <span className="step-icon pending">3</span>
            Generating Groth16 proof...
          </div>
        </div>
      )}

      {proofResult && (
        <>
          <div className={`proof-status ${proofResult.verified ? 'success' : 'error'}`}>
            Proof generated successfully. Public signals: {proofResult.publicSignals.join(', ')}
          </div>

          <button
            className="btn-secondary"
            onClick={onVerify}
            disabled={verifying}
            style={{ marginTop: '0.75rem', width: '100%' }}
          >
            {verifying ? (
              <>
                <span className="loading" /> Verifying...
              </>
            ) : (
              'Verify Proof On-Chain'
            )}
          </button>

          {verified !== null && (
            <div className={`proof-status ${verified ? 'success' : 'error'}`}>
              {verified ? 'Proof verified on-chain!' : 'Verification failed'}
            </div>
          )}
        </>
      )}
    </div>
  );
}
