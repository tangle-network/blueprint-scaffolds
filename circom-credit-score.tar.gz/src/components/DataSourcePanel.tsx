import React from 'react';
import { DataSource } from '../types';

interface Props {
  sources: DataSource[];
  onToggle: (id: string) => void;
  onCompute: () => void;
}

export default function DataSourcePanel({ sources, onToggle, onCompute }: Props) {
  const connectedCount = sources.filter((s) => s.connected).length;

  return (
    <div className="card">
      <h2>Data Sources</h2>
      <ul className="source-list">
        {sources.map((source) => (
          <li key={source.id}>
            <span>
              <span className={`status-dot ${source.connected ? 'connected' : 'disconnected'}`} />
              {source.name}
            </span>
            <button
              className="btn-secondary"
              onClick={() => onToggle(source.id)}
              style={{ padding: '0.3rem 0.8rem', fontSize: '0.75rem' }}
            >
              {source.connected ? 'Disconnect' : 'Connect'}
            </button>
          </li>
        ))}
      </ul>
      <button
        className="btn-primary"
        onClick={onCompute}
        disabled={connectedCount === 0}
        style={{ marginTop: '1rem' }}
      >
        Aggregate & Compute ({connectedCount} source{connectedCount !== 1 ? 's' : ''})
      </button>
    </div>
  );
}
