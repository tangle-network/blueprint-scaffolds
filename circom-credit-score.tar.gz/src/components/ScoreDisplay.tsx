import React from 'react';
import { ScoreBreakdown } from '../types';
import { scoreToRange } from '../lib/scoring';

interface Props {
  score: ScoreBreakdown | null;
}

export default function ScoreDisplay({ score }: Props) {
  if (!score) {
    return (
      <div className="card">
        <h2>Credit Score</h2>
        <div className="score-display" style={{ color: 'var(--text-dim)' }}>---</div>
        <p className="score-label">Connect data sources and compute your score</p>
      </div>
    );
  }

  const range = scoreToRange(score.total);
  const pct = ((score.total - 300) / 550) * 100;

  return (
    <div className="card">
      <h2>Credit Score</h2>
      <div className={`score-display ${range.className}`}>{score.total}</div>
      <p className="score-label">{range.label}</p>
      <div className="range-bar">
        <div
          className="range-fill"
          style={{
            width: `${pct}%`,
            background: `linear-gradient(90deg, var(--danger), var(--warning), var(--success))`,
          }}
        />
      </div>
      <div style={{ marginTop: '1rem' }}>
        <h3>Breakdown</h3>
        <div style={{ fontSize: '0.8rem', lineHeight: 1.8 }}>
          <div>Payment History (35%): <strong>{score.paymentScore}</strong></div>
          <div>Credit Utilization (30%): <strong>{score.utilizationScore}</strong></div>
          <div>Length of History (15%): <strong>{score.historyScore}</strong></div>
          <div>Credit Mix (10%): <strong>{score.mixScore}</strong></div>
          <div>New Credit (10%): <strong>{score.newCreditScore}</strong></div>
        </div>
      </div>
    </div>
  );
}
