import React from 'react';

export default function CircuitInfo() {
  return (
    <div className="card">
      <h2>Circuit Architecture</h2>
      <div style={{ fontSize: '0.82rem', lineHeight: 1.8 }}>
        <h3>CreditScore Circuit</h3>
        <p style={{ color: 'var(--text-dim)', marginBottom: '0.75rem' }}>
          Computes weighted credit score from private financial inputs using
          Circom arithmetic. No raw data is revealed — only the final score
          appears as a public signal.
        </p>

        <h3>RangeProof Circuit</h3>
        <p style={{ color: 'var(--text-dim)', marginBottom: '0.75rem' }}>
          Proves that the computed score falls within [min, max] without
          revealing the exact value. Uses bit decomposition and constraint
          checks.
        </p>

        <h3>ThresholdProof Circuit</h3>
        <p style={{ color: 'var(--text-dim)', marginBottom: '0.75rem' }}>
          Proves score &ge; threshold with a single boolean public output.
          Used by lending protocols for eligibility checks.
        </p>

        <h3>MultiSourceAggregation Circuit</h3>
        <p style={{ color: 'var(--text-dim)', marginBottom: '0.75rem' }}>
          Aggregates attestations from multiple data providers (banks, on-chain
          history) via Poseidon commitment merging. Individual source data
          remains private.
        </p>
      </div>

      <div style={{ marginTop: '1rem', padding: '0.75rem', background: 'var(--surface-2)', borderRadius: 8 }}>
        <h3 style={{ marginBottom: '0.5rem' }}>Parameters</h3>
        <div style={{ fontSize: '0.8rem', color: 'var(--text-dim)' }}>
          <div>Curve: BN254</div>
          <div>Protocol: Groth16</div>
          <div>Signals: 10 private, 2-5 public</div>
          <div>Constraints: ~4,200</div>
        </div>
      </div>
    </div>
  );
}
