import React, { useState, useCallback } from 'react';
import { FinancialData, ProofResult, ProofType, DataSource } from './types';
import { computeScore, scoreToRange, generateCircuitInputs } from './lib/scoring';
import { generateProof, verifyProof, formatProof } from './lib/proofs';
import { DEFAULT_SOURCES, MOCK_BANK_ATTESTATION, MOCK_ON_CHAIN_DATA, aggregateSources } from './lib/datasources';
import ScoreDisplay from './components/ScoreDisplay';
import DataSourcePanel from './components/DataSourcePanel';
import ProofGenerator from './components/ProofGenerator';
import CircuitInfo from './components/CircuitInfo';

export default function App() {
  const [sources, setSources] = useState<DataSource[]>(DEFAULT_SOURCES);
  const [financialData, setFinancialData] = useState<FinancialData | null>(null);
  const [proofResult, setProofResult] = useState<ProofResult | null>(null);
  const [proofType, setProofType] = useState<ProofType>('threshold');
  const [threshold, setThreshold] = useState(700);
  const [generating, setGenerating] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [verified, setVerified] = useState<boolean | null>(null);

  const toggleSource = useCallback((id: string) => {
    setSources((prev) =>
      prev.map((s) => {
        if (s.id !== id) return s;
        const newConnected = !s.connected;
        let data = s.data;
        if (newConnected && !data) {
          if (s.id.startsWith('chain')) data = MOCK_ON_CHAIN_DATA;
          else data = MOCK_BANK_ATTESTATION;
        }
        return { ...s, connected: newConnected, data };
      })
    );
  }, []);

  const handleCompute = useCallback(() => {
    const aggregated = aggregateSources(sources);
    setFinancialData(aggregated);
  }, [sources]);

  const handleGenerateProof = useCallback(async () => {
    if (!financialData) return;
    setGenerating(true);
    setProofResult(null);
    setVerified(null);
    try {
      const inputs = generateCircuitInputs(financialData, threshold);
      const result = await generateProof(inputs, proofType);
      setProofResult(result);
    } finally {
      setGenerating(false);
    }
  }, [financialData, proofType, threshold]);

  const handleVerify = useCallback(async () => {
    if (!proofResult) return;
    setVerifying(true);
    try {
      const ok = await verifyProof(proofResult.proof, proofResult.publicSignals);
      setVerified(ok);
    } finally {
      setVerifying(false);
    }
  }, [proofResult]);

  const score = financialData ? computeScore(financialData) : null;

  return (
    <div>
      <header>
        <h1>ZK Credit Score</h1>
        <span className="badge">Private Financial Reputation</span>
      </header>

      <div className="container">
        <div className="grid">
          <DataSourcePanel
            sources={sources}
            onToggle={toggleSource}
            onCompute={handleCompute}
          />
          <ScoreDisplay score={score} />
          <ProofGenerator
            proofType={proofType}
            onProofTypeChange={setProofType}
            threshold={threshold}
            onThresholdChange={setThreshold}
            onGenerate={handleGenerateProof}
            generating={generating}
            proofResult={proofResult}
            onVerify={handleVerify}
            verifying={verifying}
            verified={verified}
            score={score}
          />
          <CircuitInfo />
        </div>

        {proofResult && (
          <div className="card" style={{ marginTop: '1.5rem' }}>
            <h2>Proof Output</h2>
            <pre className="proof-json">{formatProof(proofResult)}</pre>
          </div>
        )}

        <div className="footer">
          ZK Credit Score — All computations are private. No raw financial data leaves your device.
        </div>
      </div>
    </div>
  );
}
