import { DataSource, FinancialData } from '../types';

export const DEFAULT_SOURCES: DataSource[] = [
  { id: 'bank-1', name: 'National Bank API', connected: false },
  { id: 'bank-2', name: 'Credit Union API', connected: false },
  { id: 'chain-1', name: 'On-Chain History', connected: false },
  { id: 'defi-1', name: 'DeFi Protocol Data', connected: false },
];

export const MOCK_BANK_ATTESTATION: Partial<FinancialData> = {
  paymentHistory: 95,
  creditUtilization: 2500,
  lengthOfHistory: 48,
  creditMix: 4,
  newCredit: 2,
  monthlyIncome: 8000,
  totalDebt: 15000,
  onTimePayments: 47,
  totalPayments: 48,
};

export const MOCK_ON_CHAIN_DATA: Partial<FinancialData> = {
  paymentHistory: 90,
  onTimePayments: 35,
  totalPayments: 36,
  creditUtilization: 1800,
  creditMix: 3,
};

export async function fetchBankAttestation(bankId: string): Promise<Partial<FinancialData>> {
  void bankId;
  await new Promise((r) => setTimeout(r, 1000));
  return MOCK_BANK_ATTESTATION;
}

export async function parseOnChainHistory(address: string): Promise<Partial<FinancialData>> {
  void address;
  await new Promise((r) => setTimeout(r, 1500));
  return MOCK_ON_CHAIN_DATA;
}

export function aggregateSources(sources: DataSource[]): FinancialData {
  const defaults: FinancialData = {
    paymentHistory: 0,
    creditUtilization: 0,
    lengthOfHistory: 0,
    creditMix: 0,
    newCredit: 0,
    monthlyIncome: 0,
    totalDebt: 0,
    onTimePayments: 0,
    totalPayments: 0,
  };

  const connected = sources.filter((s) => s.connected && s.data);
  if (connected.length === 0) return defaults;

  const keys = Object.keys(defaults) as (keyof FinancialData)[];
  const result = { ...defaults };

  for (const key of keys) {
    const values = connected
      .map((s) => s.data![key])
      .filter((v): v is number => v !== undefined);
    if (values.length > 0) {
      result[key] = Math.round(values.reduce((a, b) => a + b, 0) / values.length);
    }
  }

  return result;
}
