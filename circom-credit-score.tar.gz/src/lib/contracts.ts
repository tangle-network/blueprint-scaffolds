export const CONTRACT_ABI = [
  {
    inputs: [
      { name: '_verifier', type: 'address' },
    ],
    stateMutability: 'nonpayable',
    type: 'constructor',
  },
  {
    inputs: [
      { name: 'proof', type: 'uint256[8]' },
      { name: 'publicSignals', type: 'uint256[]' },
    ],
    name: 'verifyAndStoreScore',
    outputs: [{ name: '', type: 'bool' }],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      { name: 'proof', type: 'uint256[8]' },
      { name: 'threshold', type: 'uint256' },
      { name: 'publicSignals', type: 'uint256[]' },
    ],
    name: 'verifyThreshold',
    outputs: [{ name: '', type: 'bool' }],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [{ name: 'user', type: 'address' }],
    name: 'getScoreCommitment',
    outputs: [{ name: '', type: 'bytes32' }],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      { name: 'borrower', type: 'address' },
      { name: 'proof', type: 'uint256[8]' },
      { name: 'publicSignals', type: 'uint256[]' },
    ],
    name: 'checkEligibility',
    outputs: [{ name: '', type: 'bool' }],
    stateMutability: 'nonpayable',
    type: 'function',
  },
];

export const LENDING_HOOK_ABI = [
  {
    inputs: [
      { name: '_scoreVerifier', type: 'address' },
      { name: '_minScore', type: 'uint256' },
    ],
    stateMutability: 'nonpayable',
    type: 'constructor',
  },
  {
    inputs: [
      { name: 'borrower', type: 'address' },
      { name: 'amount', type: 'uint256' },
      { name: 'proof', type: 'uint256[8]' },
      { name: 'publicSignals', type: 'uint256[]' },
    ],
    name: 'applyForLoan',
    outputs: [{ name: '', type: 'bool' }],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [{ name: 'borrower', type: 'address' }],
    name: 'getLoanStatus',
    outputs: [
      { name: 'approved', type: 'bool' },
      { name: 'amount', type: 'uint256' },
      { name: 'rate', type: 'uint256' },
    ],
    stateMutability: 'view',
    type: 'function',
  },
];

export const CONTRACTS = {
  SCORE_VERIFIER: '0x0000000000000000000000000000000000000001',
  LENDING_HOOK: '0x0000000000000000000000000000000000000002',
};
