export type ProofType = "credit_score" | "range" | "threshold" | "multi_source";

export interface StoredProof {
  id: string;
  type: ProofType;
  proof: string;
  publicSignals: string[];
  createdAt: number;
  label: string;
}

export interface DataSourceEntry {
  id: string;
  type: "bank" | "onchain";
  name: string;
  connected: boolean;
  lastSync: number | null;
  dataCount: number;
}

const PROOF_STORAGE_KEY = "zk-credit-proofs";
const DATASOURCE_STORAGE_KEY = "zk-credit-datasources";

export function saveProof(proof: StoredProof): void {
  const proofs = getProofs();
  proofs.unshift(proof);
  localStorage.setItem(PROOF_STORAGE_KEY, JSON.stringify(proofs));
}

export function getProofs(): StoredProof[] {
  try {
    const raw = localStorage.getItem(PROOF_STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function deleteProof(id: string): void {
  const proofs = getProofs().filter((p) => p.id !== id);
  localStorage.setItem(PROOF_STORAGE_KEY, JSON.stringify(proofs));
}

export function saveDataSources(sources: DataSourceEntry[]): void {
  localStorage.setItem(DATASOURCE_STORAGE_KEY, JSON.stringify(sources));
}

export function getDataSources(): DataSourceEntry[] {
  try {
    const raw = localStorage.getItem(DATASOURCE_STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

export function formatDate(timestamp: number): string {
  return new Date(timestamp).toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function formatAddress(address: string): string {
  if (address.length <= 12) return address;
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

export function scoreToLabel(score: number): {
  label: string;
  color: string;
} {
  if (score >= 800) return { label: "Excellent", color: "text-emerald-500" };
  if (score >= 700) return { label: "Good", color: "text-green-500" };
  if (score >= 600) return { label: "Fair", color: "text-yellow-500" };
  if (score >= 500) return { label: "Poor", color: "text-orange-500" };
  return { label: "Very Poor", color: "text-red-500" };
}

export function proofTypeToLabel(type: ProofType): string {
  switch (type) {
    case "credit_score":
      return "Credit Score";
    case "range":
      return "Range Proof";
    case "threshold":
      return "Threshold Proof";
    case "multi_source":
      return "Multi-Source Aggregation";
  }
}
