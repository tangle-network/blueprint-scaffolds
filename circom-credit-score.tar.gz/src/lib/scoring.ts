import { FinancialData, ScoreBreakdown } from '../types';

const WEIGHT_PAYMENT = 35;
const WEIGHT_UTILIZATION = 30;
const WEIGHT_HISTORY = 15;
const WEIGHT_MIX = 10;
const WEIGHT_NEW_CREDIT = 10;

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

export function computeScore(data: FinancialData): ScoreBreakdown {
  const paymentRatio = data.totalPayments > 0 ? data.onTimePayments / data.totalPayments : 0;
  const paymentScore = clamp(Math.round(paymentRatio * 1000), 0, 1000);

  const utilizationRatio = data.monthlyIncome > 0
    ? data.creditUtilization / data.monthlyIncome
    : 1;
  const utilizationScore = clamp(Math.round((1 - clamp(utilizationRatio, 0, 1)) * 1000), 0, 1000);

  const historyScore = clamp(Math.round((data.lengthOfHistory / 120) * 1000), 0, 1000);

  const mixScore = clamp(data.creditMix * 100, 0, 1000);

  const newCreditScore = clamp(Math.round((1 - clamp(data.newCredit / 20, 0, 1)) * 1000), 0, 1000);

  const total = Math.round(
    (paymentScore * WEIGHT_PAYMENT +
      utilizationScore * WEIGHT_UTILIZATION +
      historyScore * WEIGHT_HISTORY +
      mixScore * WEIGHT_MIX +
      newCreditScore * WEIGHT_NEW_CREDIT) /
      (WEIGHT_PAYMENT + WEIGHT_UTILIZATION + WEIGHT_HISTORY + WEIGHT_MIX + WEIGHT_NEW_CREDIT)
  );

  return {
    paymentScore,
    utilizationScore,
    historyScore,
    mixScore,
    newCreditScore,
    total: clamp(total, 300, 850),
  };
}

export function scoreToRange(score: number): { label: string; className: string } {
  if (score >= 740) return { label: 'Excellent', className: 'excellent' };
  if (score >= 670) return { label: 'Good', className: 'good' };
  if (score >= 580) return { label: 'Fair', className: 'fair' };
  return { label: 'Poor', className: 'poor' };
}

export function generateCircuitInputs(data: FinancialData, threshold?: number): Record<string, string> {
  const nonce = BigInt(Math.floor(Math.random() * 1000000)).toString();
  return {
    paymentHistory: String(data.paymentHistory),
    creditUtilization: String(data.creditUtilization),
    lengthOfHistory: String(data.lengthOfHistory),
    creditMix: String(data.creditMix),
    newCredit: String(data.newCredit),
    monthlyIncome: String(data.monthlyIncome),
    totalDebt: String(data.totalDebt),
    onTimePayments: String(data.onTimePayments),
    totalPayments: String(data.totalPayments),
    threshold: threshold ? String(threshold) : '700',
    nonce,
  };
}
