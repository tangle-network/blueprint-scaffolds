export interface BankAttestation {
  bankId: string;
  bankName: string;
  accountHash: string;
  attestationData: {
    onTimePayments: number;
    totalPayments: number;
    averageBalance: number;
    accountAgeMonths: number;
    creditUtilization: number;
  };
  signature: string;
  timestamp: number;
  verified: boolean;
}

export interface BankConnectionStatus {
  connected: boolean;
  bankName: string | null;
  lastSync: number | null;
  attestationCount: number;
}

const MOCK_BANKS = [
  { id: "chase", name: "Chase Bank" },
  { id: "boa", name: "Bank of America" },
  { id: "wells", name: "Wells Fargo" },
  { id: "citi", name: "Citibank" },
  { id: "gs", name: "Goldman Sachs" },
];

export function getAvailableBanks() {
  return MOCK_BANKS;
}

export async function connectBank(bankId: string): Promise<BankConnectionStatus> {
  await new Promise((resolve) => setTimeout(resolve, 1500));

  const bank = MOCK_BANKS.find((b) => b.id === bankId);
  if (!bank) throw new Error("Bank not found");

  return {
    connected: true,
    bankName: bank.name,
    lastSync: Date.now(),
    attestationCount: 0,
  };
}

export async function requestAttestation(
  bankId: string
): Promise<BankAttestation> {
  await new Promise((resolve) => setTimeout(resolve, 2000));

  const bank = MOCK_BANKS.find((b) => b.id === bankId);
  if (!bank) throw new Error("Bank not found");

  const onTimePayments = Math.floor(Math.random() * 20) + 30;
  const totalPayments = onTimePayments + Math.floor(Math.random() * 5);

  return {
    bankId,
    bankName: bank.name,
    accountHash:
      "0x" +
      Array.from({ length: 64 }, () =>
        Math.floor(Math.random() * 16).toString(16)
      ).join(""),
    attestationData: {
      onTimePayments,
      totalPayments,
      averageBalance: Math.floor(Math.random() * 50000) + 5000,
      accountAgeMonths: Math.floor(Math.random() * 120) + 6,
      creditUtilization: Math.floor(Math.random() * 60) + 5,
    },
    signature:
      "0x" +
      Array.from({ length: 128 }, () =>
        Math.floor(Math.random() * 16).toString(16)
      ).join(""),
    timestamp: Date.now(),
    verified: true,
  };
}

export async function verifyAttestation(
  attestation: BankAttestation
): Promise<boolean> {
  await new Promise((resolve) => setTimeout(resolve, 1000));
  return attestation.signature.length > 10 && attestation.verified;
}

export function extractFinancialData(attestation: BankAttestation) {
  const { attestationData } = attestation;
  return {
    paymentHistory: Math.round(
      (attestationData.onTimePayments / attestationData.totalPayments) * 100
    ),
    creditUtilization: attestationData.creditUtilization,
    accountAge: attestationData.accountAgeMonths,
    averageBalance: attestationData.averageBalance,
  };
}
