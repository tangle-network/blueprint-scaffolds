import { ProofResult, ProofType } from '../types';

interface MockProofData {
  pi_a: string[];
  pi_b: string[][];
  pi_c: string[];
  protocol: string;
  curve: string;
}

function generateMockProof(): MockProofData {
  const randField = () => {
    const hex = BigInt('0x' + Array.from({ length: 16 }, () =>
      Math.floor(Math.random() * 16).toString(16)
    ).join('')).toString();
    return hex;
  };

  return {
    pi_a: [randField(), randField(), '1'],
    pi_b: [
      [randField(), randField()],
      [randField(), randField()],
      ['1', '0'],
    ],
    pi_c: [randField(), randField(), '1'],
    protocol: 'groth16',
    curve: 'bn128',
  };
}

export async function generateProof(
  inputs: Record<string, string>,
  proofType: ProofType
): Promise<ProofResult> {
  await new Promise((r) => setTimeout(r, 1500 + Math.random() * 2000));

  const proof = generateMockProof();
  const score = computeMockScore(inputs);

  let publicSignals: string[];
  switch (proofType) {
    case 'score':
      publicSignals = [String(score), inputs.nonce || '0'];
      break;
    case 'range':
      publicSignals = [String(score), '700', '850', '1', inputs.nonce || '0'];
      break;
    case 'threshold':
      publicSignals = [
        String(score),
        inputs.threshold || '700',
        score >= parseInt(inputs.threshold || '700') ? '1' : '0',
        inputs.nonce || '0',
      ];
      break;
    case 'aggregation':
      publicSignals = [String(score), '3', '1', inputs.nonce || '0'];
      break;
    default:
      publicSignals = [String(score)];
  }

  return {
    proof,
    publicSignals,
    verified: true,
  };
}

function computeMockScore(inputs: Record<string, string>): number {
  const onTime = parseInt(inputs.onTimePayments || '0');
  const total = parseInt(inputs.totalPayments || '0');
  const ratio = total > 0 ? onTime / total : 0;
  const base = Math.round(300 + ratio * 550);
  return Math.max(300, Math.min(850, base));
}

export async function verifyProof(proof: object, publicSignals: string[]): Promise<boolean> {
  await new Promise((r) => setTimeout(r, 1000));
  void proof;
  void publicSignals;
  return true;
}

export function formatProof(proofResult: ProofResult): string {
  return JSON.stringify(
    {
      proof: {
        pi_a: proofResult.proof.pi_a ? (proofResult.proof as MockProofData).pi_a : [],
        pi_b: proofResult.proof.pi_b ? (proofResult.proof as MockProofData).pi_b : [],
        pi_c: proofResult.proof.pi_c ? (proofResult.proof as MockProofData).pi_c : [],
      },
      publicSignals: proofResult.publicSignals,
    },
    null,
    2
  );
}
