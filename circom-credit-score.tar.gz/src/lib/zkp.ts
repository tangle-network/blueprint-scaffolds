export interface ZKProof {
  proof: {
    a: [string, string];
    b: [[string, string], [string, string]];
    c: [string, string];
  };
  publicSignals: string[];
}

export interface CreditScoreInputs {
  score: number;
  paymentHistory: number;
  creditUtilization: number;
  accountAge: number;
  totalAccounts: number;
  hardInquiries: number;
}

export interface RangeProofInputs {
  score: number;
  minScore: number;
}

export interface ThresholdInputs {
  score: number;
  threshold: number;
}

export interface MultiSourceInputs {
  scores: number[];
  weights: number[];
}

function hashToField(value: string): string {
  let hash = 0n;
  for (let i = 0; i < value.length; i++) {
    const char = BigInt(value.charCodeAt(i));
    hash = ((hash << 5n) - hash) + char;
    hash = hash & 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffn;
  }
  return "0x" + hash.toString(16);
}

function generateDummyProof(): ZKProof["proof"] {
  const r = () => "0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
  return {
    a: [r(), r()],
    b: [[r(), r()], [r(), r()]],
    c: [r(), r()],
  };
}

export async function computeCreditScore(inputs: CreditScoreInputs): Promise<ZKProof> {
  await new Promise((resolve) => setTimeout(resolve, 2000));

  const paymentWeight = 0.35;
  const utilizationWeight = 0.30;
  const ageWeight = 0.15;
  const accountsWeight = 0.10;
  const inquiriesWeight = 0.10;

  const normalizedPayment = Math.min(inputs.paymentHistory / 100, 1);
  const normalizedUtilization = 1 - Math.min(inputs.creditUtilization / 100, 1);
  const normalizedAge = Math.min(inputs.accountAge / 240, 1);
  const normalizedAccounts = Math.min(inputs.totalAccounts / 20, 1);
  const normalizedInquiries = 1 - Math.min(inputs.hardInquiries / 10, 1);

  const rawScore =
    normalizedPayment * paymentWeight +
    normalizedUtilization * utilizationWeight +
    normalizedAge * ageWeight +
    normalizedAccounts * accountsWeight +
    normalizedInquiries * inquiriesWeight;

  const computedScore = Math.round(300 + rawScore * 550);

  return {
    proof: generateDummyProof(),
    publicSignals: [
      computedScore.toString(),
      hashToField(JSON.stringify(inputs)),
    ],
  };
}

export async function generateRangeProof(inputs: RangeProofInputs): Promise<ZKProof> {
  await new Promise((resolve) => setTimeout(resolve, 1500));

  const isValid = inputs.score >= inputs.minScore ? 1 : 0;

  return {
    proof: generateDummyProof(),
    publicSignals: [isValid.toString(), inputs.minScore.toString()],
  };
}

export async function generateThresholdProof(inputs: ThresholdInputs): Promise<ZKProof> {
  await new Promise((resolve) => setTimeout(resolve, 1500));

  const meetsThreshold = inputs.score >= inputs.threshold ? 1 : 0;

  return {
    proof: generateDummyProof(),
    publicSignals: [meetsThreshold.toString(), inputs.threshold.toString()],
  };
}

export async function aggregateMultiSource(inputs: MultiSourceInputs): Promise<ZKProof> {
  await new Promise((resolve) => setTimeout(resolve, 2500));

  const totalWeight = inputs.weights.reduce((a, b) => a + b, 0);
  const aggregated = inputs.scores.reduce(
    (acc, score, i) => acc + (score * inputs.weights[i]) / totalWeight,
    0
  );

  return {
    proof: generateDummyProof(),
    publicSignals: [
      Math.round(aggregated).toString(),
      inputs.scores.length.toString(),
    ],
  };
}

export function formatProofHex(proof: ZKProof): string {
  return JSON.stringify(proof, null, 2);
}
