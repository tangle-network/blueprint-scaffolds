export interface OnChainTransaction {
  hash: string;
  from: string;
  to: string;
  value: string;
  timestamp: number;
  type: "transfer" | "swap" | "deposit" | "withdraw" | "repayment";
  status: "confirmed" | "pending" | "failed";
}

export interface ParsedHistory {
  totalTransactions: number;
  successfulTransactions: number;
  totalVolume: number;
  avgTransactionValue: number;
  firstActivityDate: number;
  repaymentRate: number;
  defiInteractions: number;
  riskSignals: string[];
}

const MOCK_ADDRESSES = [
  "0x742d35Cc6634C0532925a3b844Bc9e7595f2bD18",
  "0x8ba1f109551bD432803012645Ac136ddd64DBA72",
  "0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045",
];

function generateMockTransactions(count: number): OnChainTransaction[] {
  const types: OnChainTransaction["type"][] = [
    "transfer",
    "swap",
    "deposit",
    "withdraw",
    "repayment",
  ];
  const txs: OnChainTransaction[] = [];

  for (let i = 0; i < count; i++) {
    const type = types[Math.floor(Math.random() * types.length)];
    txs.push({
      hash:
        "0x" +
        Array.from({ length: 64 }, () =>
          Math.floor(Math.random() * 16).toString(16)
        ).join(""),
      from: MOCK_ADDRESSES[Math.floor(Math.random() * MOCK_ADDRESSES.length)],
      to: MOCK_ADDRESSES[Math.floor(Math.random() * MOCK_ADDRESSES.length)],
      value: (Math.random() * 10).toFixed(4),
      timestamp: Date.now() - Math.floor(Math.random() * 90 * 24 * 60 * 60 * 1000),
      type,
      status: Math.random() > 0.1 ? "confirmed" : "failed",
    });
  }

  return txs.sort((a, b) => b.timestamp - a.timestamp);
}

export async function parseOnChainHistory(
  address: string
): Promise<ParsedHistory> {
  await new Promise((resolve) => setTimeout(resolve, 2000));

  const transactions = generateMockTransactions(
    Math.floor(Math.random() * 100) + 50
  );
  const successful = transactions.filter((t) => t.status === "confirmed");
  const repayments = transactions.filter((t) => t.type === "repayment");
  const successfulRepayments = repayments.filter(
    (t) => t.status === "confirmed"
  );

  const totalVolume = successful.reduce(
    (acc, t) => acc + parseFloat(t.value),
    0
  );
  const riskSignals: string[] = [];

  if (successful.length / transactions.length < 0.9) {
    riskSignals.push("High failure rate");
  }
  if (
    repayments.length > 0 &&
    successfulRepayments.length / repayments.length < 0.95
  ) {
    riskSignals.push("Missed repayments detected");
  }

  return {
    totalTransactions: transactions.length,
    successfulTransactions: successful.length,
    totalVolume: Math.round(totalVolume * 1000) / 1000,
    avgTransactionValue:
      Math.round((totalVolume / successful.length) * 10000) / 10000,
    firstActivityDate: transactions[transactions.length - 1]?.timestamp ?? Date.now(),
    repaymentRate:
      repayments.length > 0
        ? successfulRepayments.length / repayments.length
        : 1,
    defiInteractions: transactions.filter(
      (t) => t.type === "swap" || t.type === "deposit"
    ).length,
    riskSignals,
  };
}

export function historyToCreditInputs(history: ParsedHistory) {
  const activityScore = Math.min(
    (history.totalTransactions / 200) * 100,
    100
  );
  const successScore = (history.successfulTransactions / history.totalTransactions) * 100;
  const repaymentScore = history.repaymentRate * 100;
  const defiScore = Math.min((history.defiInteractions / 50) * 100, 100);

  return {
    onChainPaymentHistory: Math.round(
      (successScore * 0.4 + repaymentScore * 0.6)
    ),
    onChainActivity: Math.round(activityScore),
    defiEngagement: Math.round(defiScore),
    totalTransactions: history.totalTransactions,
  };
}
