// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IScoreVerifier {
    function isScoreVerified(address user) external view returns (bool);
    function getProofHash(address user) external view returns (bytes32);
}

contract LendingProtocol {
    struct Loan {
        address borrower;
        uint256 amount;
        uint256 interestRate;
        uint256 duration;
        uint256 startTime;
        bool active;
        bool repaid;
    }

    struct ThresholdConfig {
        uint256 minScore;
        uint256 maxLTV;
        uint256 baseInterestRate;
    }

    IScoreVerifier public scoreVerifier;
    address public owner;

    mapping(address => Loan) public loans;
    mapping(address => uint256) public collateral;
    mapping(uint256 => ThresholdConfig) public thresholdConfigs;

    uint256 public constant SCORE_700 = 700;
    uint256 public constant SCORE_600 = 600;
    uint256 public constant SCORE_500 = 500;

    event LoanCreated(address indexed borrower, uint256 amount, uint256 interestRate);
    event LoanRepaid(address indexed borrower, uint256 amount);
    event CollateralDeposited(address indexed user, uint256 amount);
    event CollateralWithdrawn(address indexed user, uint256 amount);

    modifier onlyOwner() {
        require(msg.sender == owner, "Only owner");
        _;
    }

    modifier hasVerifiedScore() {
        require(scoreVerifier.isScoreVerified(msg.sender), "No verified score");
        _;
    }

    constructor(address _scoreVerifier) {
        scoreVerifier = IScoreVerifier(_scoreVerifier);
        owner = msg.sender;

        thresholdConfigs[SCORE_700] = ThresholdConfig(700, 80, 500);
        thresholdConfigs[SCORE_600] = ThresholdConfig(600, 60, 800);
        thresholdConfigs[SCORE_500] = ThresholdConfig(500, 40, 1200);
    }

    function depositCollateral() external payable {
        require(msg.value > 0, "Must deposit ETH");
        collateral[msg.sender] += msg.value;
        emit CollateralDeposited(msg.sender, msg.value);
    }

    function requestLoan(uint256 amount, uint256 tierScore) external hasVerifiedScore {
        require(loans[msg.sender].active == false, "Active loan exists");
        require(amount > 0, "Invalid amount");

        ThresholdConfig memory config = thresholdConfigs[tierScore];
        require(config.minScore > 0, "Invalid tier");

        uint256 maxBorrow = (collateral[msg.sender] * config.maxLTV) / 100;
        require(amount <= maxBorrow, "Exceeds max LTV");

        loans[msg.sender] = Loan({
            borrower: msg.sender,
            amount: amount,
            interestRate: config.baseInterestRate,
            duration: 365 days,
            startTime: block.timestamp,
            active: true,
            repaid: false
        });

        emit LoanCreated(msg.sender, amount, config.baseInterestRate);
    }

    function repayLoan() external payable {
        Loan storage loan = loans[msg.sender];
        require(loan.active, "No active loan");
        require(!loan.repaid, "Already repaid");

        uint256 owed = calculateOwed(msg.sender);
        require(msg.value >= owed, "Insufficient repayment");

        loan.repaid = true;
        loan.active = false;

        emit LoanRepaid(msg.sender, owed);
    }

    function calculateOwed(address borrower) public view returns (uint256) {
        Loan memory loan = loans[borrower];
        require(loan.active, "No active loan");

        uint256 elapsed = block.timestamp - loan.startTime;
        uint256 interest = (loan.amount * loan.interestRate * elapsed) / (10000 * 365 days);

        return loan.amount + interest;
    }

    function withdrawCollateral(uint256 amount) external {
        require(collateral[msg.sender] >= amount, "Insufficient collateral");

        if (loans[msg.sender].active) {
            uint256 locked = (loans[msg.sender].amount * 100) / thresholdConfigs[SCORE_700].maxLTV;
            require(collateral[msg.sender] - amount >= locked, "Would undercollateralize");
        }

        collateral[msg.sender] -= amount;
        (bool success, ) = msg.sender.call{value: amount}("");
        require(success, "Transfer failed");

        emit CollateralWithdrawn(msg.sender, amount);
    }

    function getLoanInfo(address borrower) external view returns (Loan memory) {
        return loans[borrower];
    }
}
