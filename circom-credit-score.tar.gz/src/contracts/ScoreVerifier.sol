// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract ScoreVerifier {
    struct Proof {
        uint256[2] a;
        uint256[2][2] b;
        uint256[2] c;
    }

    struct VerificationKey {
        uint256 alpha1;
        uint256 beta2;
        uint256 gamma2;
        uint256 delta2;
    }

    mapping(bytes32 => bool) public verifiedScores;
    mapping(address => bytes32) public userProofHash;

    event ScoreVerified(address indexed user, bytes32 proofHash, uint256 timestamp);
    event ProofRevoked(address indexed user, bytes32 proofHash);

    address public owner;

    modifier onlyOwner() {
        require(msg.sender == owner, "Only owner");
        _;
    }

    constructor() {
        owner = msg.sender;
    }

    function verifyProof(
        Proof calldata proof,
        uint256[] calldata publicSignals
    ) external returns (bool) {
        bytes32 proofHash = keccak256(abi.encode(proof, publicSignals));

        require(!verifiedScores[proofHash], "Already verified");

        verifiedScores[proofHash] = true;
        userProofHash[msg.sender] = proofHash;

        emit ScoreVerified(msg.sender, proofHash, block.timestamp);
        return true;
    }

    function isScoreVerified(address user) external view returns (bool) {
        return verifiedScores[userProofHash[user]];
    }

    function revokeProof(address user) external onlyOwner {
        bytes32 proofHash = userProofHash[user];
        require(proofHash != bytes32(0), "No proof found");

        verifiedScores[proofHash] = false;
        delete userProofHash[user];

        emit ProofRevoked(user, proofHash);
    }

    function getProofHash(address user) external view returns (bytes32) {
        return userProofHash[user];
    }
}
