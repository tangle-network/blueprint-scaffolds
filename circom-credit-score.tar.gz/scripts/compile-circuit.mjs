import { mkdir, writeFile } from 'fs/promises';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const root = join(__dirname, '..');

async function main() {
  const outDir = join(root, 'artifacts', 'circuits');
  await mkdir(outDir, { recursive: true });

  const circuitNames = ['credit_score', 'range_proof', 'threshold_proof', 'multi_source_aggregation'];

  for (const name of circuitNames) {
    console.log(`[mock] Compiling ${name}...`);
    const artifact = {
      circuitName: name,
      compiled: true,
      note: 'Mock compilation for frontend build. Use circom compiler for real circuits.',
      constraints: Math.floor(Math.random() * 2000) + 2000,
      privateInputs: 9,
      publicInputs: name === 'credit_score' ? 1 : 2,
    };
    await writeFile(
      join(outDir, `${name}_js`, `${name}.json`),
      JSON.stringify(artifact, null, 2)
    );
    console.log(`[mock] ${name} compiled (${artifact.constraints} constraints)`);
  }

  console.log('\n[mock] All circuits compiled successfully.');
  console.log('Note: These are mock artifacts. Install circom and run: circom circuits/*.circom --r1cs --wasm --sym');
}

main().catch(console.error);
