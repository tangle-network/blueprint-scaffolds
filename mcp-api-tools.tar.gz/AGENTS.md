# AGENTS.md

## Goal

Build an MCP server that wraps REST APIs as tools for AI assistants. API discovery, parameter mapping, response formatting.

## Stack

- Family: `mcp-server-ts`
- Layers: `database:sqlite`, `sdk:none`, `auth:none`, `payments:none`, `queue:none`

## Entry Points

- `server.mjs`
- `mcp.config.json`

## Commands

- `node server.mjs`

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
