export interface RequestContext {
  method: string;
  url: string;
  headers: Record<string, string>;
  body?: unknown;
  params?: Record<string, string>;
  auth?: AuthConfig;
  timeout?: number;
  tags?: string[];
  id: string;
  timestamp: number;
  chainStep?: number;
  parentId?: string;
}

export interface AuthConfig {
  type: 'bearer' | 'basic' | 'apikey' | 'oauth2';
  token?: string;
  username?: string;
  password?: string;
  headerName?: string;
  headerValue?: string;
}

export interface ResponseContext {
  status: number;
  statusText: string;
  headers: Record<string, string>;
  body: unknown;
  rawBody: string;
  duration: number;
  size: number;
  requestId: string;
  timestamp: number;
  extracted?: Record<string, unknown>;
}

export interface CacheEntry {
  key: string;
  response: ResponseContext;
  expiresAt: number;
  tags: string[];
}

export interface RetryConfig {
  maxRetries: number;
  baseDelay: number;
  maxDelay: number;
  backoffMultiplier: number;
  retryOnStatus: number[];
}

export interface EnvironmentConfig {
  name: string;
  variables: Record<string, string>;
  active: boolean;
}

export interface OpenAPISpec {
  openapi?: string;
  swagger?: string;
  info: { title: string; version: string };
  servers?: { url: string; description?: string }[];
  paths: Record<string, Record<string, OpenAPIOperation>>;
  components?: {
    securitySchemes?: Record<string, OpenAPISecurityScheme>;
    schemas?: Record<string, unknown>;
  };
}

export interface OpenAPIOperation {
  operationId?: string;
  summary?: string;
  description?: string;
  parameters?: OpenAPIParameter[];
  requestBody?: { content: Record<string, { schema?: unknown }> };
  responses?: Record<string, { description?: string }>;
  security?: Record<string, string[]>[];
  tags?: string[];
}

export interface OpenAPIParameter {
  name: string;
  in: 'query' | 'header' | 'path' | 'cookie';
  required?: boolean;
  schema?: { type?: string; default?: unknown };
  description?: string;
}

export interface OpenAPISecurityScheme {
  type: string;
  scheme?: string;
  bearerFormat?: string;
  in?: string;
  name?: string;
}

export interface GraphQLQuery {
  query: string;
  variables?: Record<string, unknown>;
  operationName?: string;
}

export interface RequestHistoryEntry {
  id: string;
  request: RequestContext;
  response?: ResponseContext;
  error?: string;
  retried: number;
}

export interface ChainLink {
  request: Omit<RequestContext, 'id' | 'timestamp'>;
  extract?: Record<string, string>;
}

export interface RequestChain {
  id: string;
  name: string;
  links: ChainLink[];
  environment?: string;
}
