import React from 'react';
import { useStore } from '@/lib/store';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RequestBuilder } from '@/components/RequestBuilder';
import { GraphQLExplorer } from '@/components/GraphQLExplorer';
import { ApiDiscovery } from '@/components/ApiDiscovery';
import { ChainBuilder } from '@/components/ChainBuilder';
import { HistoryPanel } from '@/components/HistoryPanel';
import { EnvironmentManager } from '@/components/EnvironmentManager';
import { Card, CardContent } from '@/components/ui/card';

export default function App() {
  const { sidebarTab, setSidebarTab } = useStore();

  return (
    <div className="h-screen flex flex-col">
      <header className="border-b px-4 py-2 flex items-center gap-3">
        <h1 className="text-lg font-bold">MCP API Tools</h1>
        <span className="text-xs text-muted-foreground">REST & GraphQL API explorer</span>
      </header>
      <div className="flex-1 flex overflow-hidden">
        <nav className="w-12 border-r flex flex-col items-center py-2 gap-1">
          {([
            ['rest', 'R'],
            ['graphql', 'G'],
            ['api', 'A'],
            ['chains', 'C'],
            ['env', 'E'],
            ['history', 'H'],
          ] as const).map(([tab, icon]) => (
            <button
              key={tab}
              onClick={() => setSidebarTab(tab)}
              className={`w-8 h-8 rounded text-xs font-bold flex items-center justify-center cursor-pointer ${
                sidebarTab === tab ? 'bg-primary text-primary-foreground' : 'hover:bg-accent'
              }`}
              title={tab}
            >
              {icon}
            </button>
          ))}
        </nav>
        <main className="flex-1 overflow-auto p-4">
          {sidebarTab === 'rest' && <RequestBuilder />}
          {sidebarTab === 'graphql' && <GraphQLExplorer />}
          {sidebarTab === 'api' && <ApiDiscovery />}
          {sidebarTab === 'chains' && <ChainBuilder />}
          {sidebarTab === 'env' && <EnvironmentManager />}
          {sidebarTab === 'history' && <HistoryPanel />}
        </main>
      </div>
    </div>
  );
}
