import React, { useState, useCallback } from 'react';
import type { ResponseContext, RequestHistoryEntry } from './lib';
import {
  executeRequest,
  executeGraphQL,
  getHistory,
  addToHistory,
  clearHistory,
  getEnvVars,
  getActiveEnvironment,
  getEnvironments,
  setVariable,
  addEnvironment,
  setActiveEnvironment,
  invalidateCache,
  parseOpenAPISpec,
  getOperations,
} from './lib';
import RequestBuilder from './components/RequestBuilder';
import ResponseViewer from './components/ResponseViewer';
import HistoryPanel from './components/HistoryPanel';
import EnvPanel from './components/EnvPanel';
import GraphQLEditor from './components/GraphQLEditor';
import OpenAPIImporter from './components/OpenAPIImporter';

type Tab = 'rest' | 'graphql' | 'history' | 'env' | 'openapi';

const tabList: { key: Tab; label: string }[] = [
  { key: 'rest', label: 'REST' },
  { key: 'graphql', label: 'GraphQL' },
  { key: 'history', label: 'History' },
  { key: 'env', label: 'Environments' },
  { key: 'openapi', label: 'OpenAPI' },
];

export default function App() {
  const [tab, setTab] = useState<Tab>('rest');
  const [response, setResponse] = useState<ResponseContext | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [historyEntries, setHistoryEntries] = useState<RequestHistoryEntry[]>(() => getHistory());

  const refreshHistory = useCallback(() => {
    setHistoryEntries(getHistory());
  }, []);

  const handleSendRequest = useCallback(async (req: Parameters<typeof executeRequest>[0]) => {
    setLoading(true);
    setError(null);
    setResponse(null);
    try {
      const envVars = getEnvVars();
      const { response: resp, request } = await executeRequest(req, {
        envVars,
        retry: { maxRetries: 2 },
      });
      setResponse(resp);
      addToHistory(request, resp);
      refreshHistory();
    } catch (err) {
      const msg = (err as Error).message;
      setError(msg);
      addToHistory(
        { ...req, id: `${Date.now()}`, timestamp: Date.now() },
        undefined,
        msg
      );
      refreshHistory();
    } finally {
      setLoading(false);
    }
  }, [refreshHistory]);

  const handleSendGraphQL = useCallback(async (endpoint: string, query: string, variables?: string) => {
    setLoading(true);
    setError(null);
    setResponse(null);
    try {
      const envVars = getEnvVars();
      const parsedVars = variables ? JSON.parse(variables) : undefined;
      const { response: resp } = await executeGraphQL(
        { endpoint, envVars, retry: { maxRetries: 2 } },
        { query, variables: parsedVars }
      );
      setResponse(resp);
      refreshHistory();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }, [refreshHistory]);

  const handleSelectHistory = useCallback((entry: RequestHistoryEntry) => {
    if (entry.response) {
      setResponse(entry.response);
      setError(null);
    }
    if (entry.error) {
      setError(entry.error);
      setResponse(null);
    }
    setTab('rest');
  }, []);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <header style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 20px',
        height: 48,
        background: 'var(--bg-secondary)',
        borderBottom: '1px solid var(--border)',
        flexShrink: 0,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{ fontWeight: 700, fontSize: 16, color: 'var(--accent)' }}>MCP API Tools</span>
          <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>v1.0</span>
        </div>
        <div style={{ display: 'flex', gap: 4 }}>
          {tabList.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              style={{
                background: tab === t.key ? 'var(--accent)' : 'transparent',
                color: tab === t.key ? '#fff' : 'var(--text-secondary)',
                padding: '6px 14px',
                borderRadius: 'var(--radius)',
                fontSize: 13,
                fontWeight: tab === t.key ? 600 : 400,
              }}
            >
              {t.label}
            </button>
          ))}
        </div>
      </header>

      <div style={{ flex: 1, overflow: 'auto', padding: 16 }}>
        {tab === 'rest' && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, height: '100%' }}>
            <RequestBuilder onSend={handleSendRequest} loading={loading} />
            <ResponseViewer response={response} error={error} loading={loading} />
          </div>
        )}

        {tab === 'graphql' && (
          <GraphQLEditor onSend={handleSendGraphQL} loading={loading} />
        )}

        {tab === 'graphql' && (response || error) && (
          <div style={{ marginTop: 16 }}>
            <ResponseViewer response={response} error={error} loading={loading} />
          </div>
        )}

        {tab === 'history' && (
          <HistoryPanel
            entries={historyEntries}
            onSelect={handleSelectHistory}
            onClear={() => { clearHistory(); refreshHistory(); }}
          />
        )}

        {tab === 'env' && (
          <EnvPanel
            environments={getEnvironments()}
            activeEnv={getActiveEnvironment()}
            onSetActive={setActiveEnvironment}
            onAddEnv={(name) => { addEnvironment({ name, variables: {} }); }}
            onSetVar={setVariable}
            onInvalidateCache={() => invalidateCache()}
          />
        )}

        {tab === 'openapi' && (
          <OpenAPIImporter
            onImport={(spec) => {
              try {
                const parsed = parseOpenAPISpec(spec);
                const ops = getOperations(parsed);
                return { spec: parsed, operations: ops };
              } catch (e) {
                setError((e as Error).message);
                return null;
              }
            }}
            onSelectOp={(op) => {
              setTab('rest');
            }}
          />
        )}
      </div>
    </div>
  );
}
