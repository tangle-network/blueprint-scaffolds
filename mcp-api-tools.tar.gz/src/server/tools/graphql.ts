import type { GraphQLOperation, HttpRequest, GraphQLResponse } from '../../shared/types.js';
import { executeRequest } from '../core/http-client.js';
import { EnvironmentManager } from '../core/environment.js';
import { ResponseCache } from '../core/cache.js';
import { HistoryManager } from '../core/history.js';

export interface GraphQLToolInput {
  endpoint: string;
  query: string;
  variables?: Record<string, unknown>;
  operationName?: string;
  headers?: Record<string, string>;
  auth?: {
    type: 'none' | 'bearer' | 'basic' | 'apikey';
    token?: string;
    username?: string;
    password?: string;
    headerName?: string;
    headerValue?: string;
  };
  introspect?: boolean;
  useCache?: boolean;
}

export async function handleGraphQL(
  input: GraphQLToolInput,
  cache: ResponseCache,
  envManager: EnvironmentManager,
  history: HistoryManager
): Promise<{ content: Array<{ type: string; text: string }> }> {
  const resolvedEndpoint = envManager.resolve(input.endpoint);

  if (input.introspect) {
    const introspectionQuery = `
      query IntrospectionQuery {
        __schema {
          queryType { name }
          mutationType { name }
          subscriptionType { name }
          types {
            name kind description
            fields { name description type { name kind ofType { name kind } } args { name type { name kind ofType { name kind } } } }
          }
        }
      }
    `;
    const result = await executeGraphQLRequest(
      resolvedEndpoint,
      introspectionQuery,
      undefined,
      undefined,
      input.headers,
      input.auth,
      envManager
    );

    const parsed = JSON.parse(result.body) as GraphQLResponse;
    return {
      content: [{ type: 'text', text: JSON.stringify({ introspection: parsed.data ?? parsed.errors }, null, 2) }],
    };
  }

  const request: HttpRequest = {
    id: crypto.randomUUID(),
    method: 'POST',
    url: resolvedEndpoint,
    headers: { 'Content-Type': 'application/json', ...input.headers },
    body: JSON.stringify({
      query: input.query,
      variables: input.variables,
      operationName: input.operationName,
    }),
    auth: input.auth as HttpRequest['auth'],
    tags: ['graphql'],
  };

  if (input.useCache !== false) {
    const cached = cache.get('POST', request.url, request.body);
    if (cached) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ source: 'cache', response: cached }, null, 2) }],
      };
    }
  }

  const response = await executeRequest(request);

  if (input.useCache !== false && response.status >= 200 && response.status < 400) {
    cache.set('POST', request.url, response, 300000, ['graphql']);
  }

  history.add({ request, response });

  let parsedBody: unknown;
  try {
    parsedBody = JSON.parse(response.body);
  } catch {
    parsedBody = response.body;
  }

  return {
    content: [{ type: 'text', text: JSON.stringify({ response: { ...response, body: parsedBody } }, null, 2) }],
  };
}

async function executeGraphQLRequest(
  endpoint: string,
  query: string,
  variables?: Record<string, unknown>,
  operationName?: string,
  headers?: Record<string, string>,
  auth?: GraphQLToolInput['auth'],
  envManager?: EnvironmentManager
): Promise<{ body: string }> {
  const request: HttpRequest = {
    id: crypto.randomUUID(),
    method: 'POST',
    url: endpoint,
    headers: { 'Content-Type': 'application/json', ...headers },
    body: JSON.stringify({ query, variables, operationName }),
    auth: auth as HttpRequest['auth'],
  };
  const response = await executeRequest(request);
  return { body: response.body };
}
