import { extractByPath } from '../../shared/json-path.js';
import type { HttpResponse } from '../../shared/types.js';
import { HistoryManager } from '../core/history.js';

export interface ResponseHandlerInput {
  requestId?: string;
  url?: string;
  extractPaths?: string[];
  extractHeaders?: string[];
  formatJson?: boolean;
  filterByStatus?: number;
  limit?: number;
}

export async function handleResponseHandler(
  input: ResponseHandlerInput,
  history: HistoryManager
): Promise<{ content: Array<{ type: string; text: string }> }> {
  let entries = history.getAll();

  if (input.requestId) {
    entries = entries.filter((e) => e.request.id === input.requestId);
  }
  if (input.url) {
    entries = entries.filter((e) => e.request.url.includes(input.url!));
  }
  if (input.filterByStatus) {
    entries = entries.filter((e) => e.response.status === input.filterByStatus);
  }
  if (input.limit) {
    entries = entries.slice(0, input.limit);
  }

  if (entries.length === 0) {
    return { content: [{ type: 'text', text: JSON.stringify({ message: 'No matching history entries found' }) }] };
  }

  const results = entries.map((entry) => {
    const result: Record<string, unknown> = {
      requestId: entry.request.id,
      method: entry.request.method,
      url: entry.request.url,
      status: entry.response.status,
      statusText: entry.response.statusText,
      duration: entry.response.duration,
      size: entry.response.size,
    };

    let body: unknown;
    try {
      body = JSON.parse(entry.response.body);
    } catch {
      body = entry.response.body;
    }

    if (input.extractPaths && input.extractPaths.length > 0) {
      const extractions: Record<string, unknown> = {};
      for (const path of input.extractPaths) {
        extractions[path] = extractByPath(body, path);
      }
      result.extractions = extractions;
    }

    if (input.extractHeaders && input.extractHeaders.length > 0) {
      const extractedHeaders: Record<string, string> = {};
      for (const header of input.extractHeaders) {
        const lowerHeader = header.toLowerCase();
        for (const [key, value] of Object.entries(entry.response.headers)) {
          if (key.toLowerCase() === lowerHeader) {
            extractedHeaders[header] = value;
            break;
          }
        }
      }
      result.extractedHeaders = extractedHeaders;
    }

    if (input.formatJson !== false) {
      result.body = body;
    } else {
      result.body = entry.response.body;
    }

    return result;
  });

  return {
    content: [{ type: 'text', text: JSON.stringify(results.length === 1 ? results[0] : results, null, 2) }],
  };
}
