import type { OpenApiSpec, OpenApiOperation, OpenApiParameter, HttpRequest } from '../../shared/types.js';
import { executeRequest } from '../core/http-client.js';
import { EnvironmentManager } from '../core/environment.js';

export interface ApiDiscoveryInput {
  specUrl: string;
  operationId?: string;
  path?: string;
  method?: string;
  generateRequest?: boolean;
  baseUrl?: string;
}

export async function handleApiDiscovery(
  input: ApiDiscoveryInput,
  envManager: EnvironmentManager
): Promise<{ content: Array<{ type: string; text: string }> }> {
  const specUrl = envManager.resolve(input.specUrl);

  const specRequest: HttpRequest = {
    id: crypto.randomUUID(),
    method: 'GET',
    url: specUrl,
    headers: { Accept: 'application/json' },
  };

  const specResponse = await executeRequest(specRequest);

  if (specResponse.status !== 200) {
    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({ error: 'Failed to fetch OpenAPI spec', status: specResponse.status, body: specResponse.body }),
        },
      ],
    };
  }

  let spec: OpenApiSpec;
  try {
    spec = JSON.parse(specResponse.body);
  } catch {
    return {
      content: [{ type: 'text', text: JSON.stringify({ error: 'Invalid JSON in OpenAPI spec' }) }],
    };
  }

  const info = {
    title: spec.info.title,
    version: spec.info.version,
    description: spec.info.description,
    servers: spec.servers?.map((s) => s.url) ?? [],
    pathCount: Object.keys(spec.paths).length,
  };

  if (input.operationId || (input.path && input.method)) {
    let operation: OpenApiOperation | undefined;
    let operationPath: string | undefined;
    let operationMethod: string | undefined;

    if (input.operationId) {
      for (const [path, methods] of Object.entries(spec.paths)) {
        for (const [method, op] of Object.entries(methods)) {
          if (op.operationId === input.operationId) {
            operation = op as OpenApiOperation;
            operationPath = path;
            operationMethod = method;
            break;
          }
        }
        if (operation) break;
      }
    } else if (input.path && input.method) {
      const lowerMethod = input.method.toLowerCase();
      operationPath = input.path;
      operationMethod = lowerMethod;
      operation = spec.paths[input.path]?.[lowerMethod] as OpenApiOperation | undefined;
    }

    if (!operation) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ error: 'Operation not found', info }) }],
      };
    }

    const result: Record<string, unknown> = {
      info,
      operation: {
        path: operationPath,
        method: operationMethod,
        operationId: operation.operationId,
        summary: operation.summary,
        description: operation.description,
        parameters: operation.parameters,
        tags: operation.tags,
      },
    };

    if (input.generateRequest) {
      const baseUrl = input.baseUrl ?? spec.servers?.[0]?.url ?? '';
      const url = baseUrl + operationPath;
      const headers: Record<string, string> = {};

      if (operation.parameters) {
        for (const param of operation.parameters as OpenApiParameter[]) {
          if (param.in === 'header' && param.schema?.default !== undefined) {
            headers[param.name] = String(param.schema.default);
          }
        }
      }

      let body: string | undefined;
      if (operation.requestBody) {
        const jsonContent = operation.requestBody.content['application/json'];
        if (jsonContent?.example) {
          body = JSON.stringify(jsonContent.example);
        } else if (jsonContent?.schema) {
          body = JSON.stringify(generateExampleFromSchema(jsonContent.schema as Record<string, unknown>));
        }
      }

      result.generatedRequest = {
        method: operationMethod?.toUpperCase(),
        url,
        headers: Object.keys(headers).length > 0 ? headers : undefined,
        body,
      };
    }

    return { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] };
  }

  const allOperations: Array<Record<string, unknown>> = [];
  for (const [path, methods] of Object.entries(spec.paths)) {
    for (const [method, op] of Object.entries(methods)) {
      const operation = op as OpenApiOperation;
      allOperations.push({
        path,
        method: method.toUpperCase(),
        operationId: operation.operationId,
        summary: operation.summary,
        tags: operation.tags,
      });
    }
  }

  return {
    content: [
      { type: 'text', text: JSON.stringify({ info, operations: allOperations }, null, 2) },
    ],
  };
}

function generateExampleFromSchema(schema: Record<string, unknown>): unknown {
  if (!schema) return null;
  const type = schema.type as string;

  if (schema.example) return schema.example;

  switch (type) {
    case 'string':
      return schema.enum ? (schema.enum as string[])[0] : 'string';
    case 'number':
    case 'integer':
      return 0;
    case 'boolean':
      return true;
    case 'array':
      return [generateExampleFromSchema((schema.items as Record<string, unknown>) ?? {})];
    case 'object': {
      const obj: Record<string, unknown> = {};
      const props = schema.properties as Record<string, Record<string, unknown>> | undefined;
      if (props) {
        for (const [key, value] of Object.entries(props)) {
          obj[key] = generateExampleFromSchema(value);
        }
      }
      return obj;
    }
    default:
      return null;
  }
}
