import type { HttpRequest, HttpResponse, AuthConfig } from '../../shared/types.js';
import { executeRequest } from '../core/http-client.js';
import { ResponseCache } from '../core/cache.js';
import { EnvironmentManager } from '../core/environment.js';
import { HistoryManager } from '../core/history.js';

export interface RequestBuilderInput {
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE' | 'HEAD' | 'OPTIONS';
  url: string;
  headers?: Record<string, string>;
  body?: string;
  auth?: {
    type: 'none' | 'bearer' | 'basic' | 'apikey';
    token?: string;
    username?: string;
    password?: string;
    headerName?: string;
    headerValue?: string;
  };
  useCache?: boolean;
  cacheTtlMs?: number;
  tags?: string[];
  retry?: {
    maxRetries?: number;
    initialDelayMs?: number;
    maxDelayMs?: number;
    backoffMultiplier?: number;
    retryOnStatuses?: number[];
  };
}

export async function handleRequestBuilder(
  input: RequestBuilderInput,
  cache: ResponseCache,
  envManager: EnvironmentManager,
  history: HistoryManager
): Promise<{ content: Array<{ type: string; text: string }> }> {
  const method = input.method ?? 'GET';
  const resolvedUrl = envManager.resolve(input.url);
  const resolvedHeaders: Record<string, string> = {};
  for (const [key, value] of Object.entries(input.headers ?? {})) {
    resolvedHeaders[key] = envManager.resolve(value);
  }
  const resolvedBody = input.body ? envManager.resolve(input.body) : undefined;

  const request: HttpRequest = {
    id: crypto.randomUUID(),
    method,
    url: resolvedUrl,
    headers: resolvedHeaders,
    body: resolvedBody,
    auth: input.auth as AuthConfig | undefined,
    tags: input.tags ?? [],
  };

  if (input.useCache !== false) {
    const cached = cache.get(request.method, request.url, request.body);
    if (cached) {
      return {
        content: [
          { type: 'text', text: JSON.stringify({ source: 'cache', request, response: cached }, null, 2) },
        ],
      };
    }
  }

  const response = await executeRequest(request, input.retry ?? {});

  if (input.useCache !== false && response.status >= 200 && response.status < 400) {
    cache.set(request.method, request.url, response, input.cacheTtlMs ?? 300000, input.tags ?? []);
  }

  history.add({ request, response });

  return {
    content: [
      { type: 'text', text: JSON.stringify({ source: 'network', request, response }, null, 2) },
    ],
  };
}
