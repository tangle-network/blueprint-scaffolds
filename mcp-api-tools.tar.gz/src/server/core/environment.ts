import type { Environment, EnvironmentVariable } from '../../shared/types.js';

export class EnvironmentManager {
  private environments = new Map<string, Environment>();
  private activeId: string;

  constructor() {
    const defaultEnv: Environment = {
      id: 'default',
      name: 'Default',
      variables: [],
    };
    this.environments.set(defaultEnv.id, defaultEnv);
    this.activeId = defaultEnv.id;
  }

  create(name: string): Environment {
    const env: Environment = {
      id: crypto.randomUUID(),
      name,
      variables: [],
    };
    this.environments.set(env.id, env);
    return env;
  }

  setActive(id: string): void {
    if (this.environments.has(id)) {
      this.activeId = id;
    }
  }

  getActive(): Environment {
    return this.environments.get(this.activeId)!;
  }

  list(): Environment[] {
    return Array.from(this.environments.values());
  }

  setVariable(key: string, value: string, description?: string): void {
    const env = this.getActive();
    const existing = env.variables.find((v) => v.key === key);
    if (existing) {
      existing.value = value;
      if (description) existing.description = description;
    } else {
      env.variables.push({ key, value, description });
    }
  }

  deleteVariable(key: string): boolean {
    const env = this.getActive();
    const idx = env.variables.findIndex((v) => v.key === key);
    if (idx >= 0) {
      env.variables.splice(idx, 1);
      return true;
    }
    return false;
  }

  resolve(template: string): string {
    const env = this.getActive();
    return template.replace(/\{\{(\w+)\}\}/g, (match, key) => {
      const variable = env.variables.find((v) => v.key === key);
      return variable ? variable.value : match;
    });
  }
}
