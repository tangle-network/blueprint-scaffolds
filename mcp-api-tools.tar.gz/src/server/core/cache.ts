import type { CacheEntry, HttpResponse } from '../../shared/types.js';

export class ResponseCache {
  private cache = new Map<string, CacheEntry>();
  private defaultTtlMs: number;

  constructor(defaultTtlMs = 300000) {
    this.defaultTtlMs = defaultTtlMs;
  }

  generateKey(method: string, url: string, body?: string): string {
    const raw = `${method.toUpperCase()}:${url}:${body ?? ''}`;
    let hash = 0;
    for (let i = 0; i < raw.length; i++) {
      const char = raw.charCodeAt(i);
      hash = ((hash << 5) - hash + char) | 0;
    }
    return `cache_${Math.abs(hash).toString(36)}`;
  }

  get(method: string, url: string, body?: string): HttpResponse | null {
    const key = this.generateKey(method, url, body);
    const entry = this.cache.get(key);
    if (!entry) return null;
    if (Date.now() > entry.expiresAt) {
      this.cache.delete(key);
      return null;
    }
    return entry.response;
  }

  set(
    method: string,
    url: string,
    response: HttpResponse,
    ttlMs?: number,
    tags: string[] = []
  ): void {
    const key = this.generateKey(method, url, response.body);
    this.cache.set(key, {
      key,
      response,
      expiresAt: Date.now() + (ttlMs ?? this.defaultTtlMs),
      tags,
    });
  }

  invalidate(tags: string[]): number {
    let count = 0;
    for (const [key, entry] of this.cache) {
      if (tags.some((tag) => entry.tags.includes(tag))) {
        this.cache.delete(key);
        count++;
      }
    }
    return count;
  }

  clear(): void {
    this.cache.clear();
  }

  stats(): { size: number; entries: Array<{ key: string; expiresAt: number; tags: string[] }> } {
    const entries: Array<{ key: string; expiresAt: number; tags: string[] }> = [];
    for (const [, entry] of this.cache) {
      entries.push({ key: entry.key, expiresAt: entry.expiresAt, tags: entry.tags });
    }
    return { size: this.cache.size, entries };
  }
}
