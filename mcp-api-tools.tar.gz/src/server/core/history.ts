import type { RequestHistoryEntry } from '../../shared/types.js';

export class HistoryManager {
  private history: RequestHistoryEntry[] = [];
  private maxEntries: number;

  constructor(maxEntries = 1000) {
    this.maxEntries = maxEntries;
  }

  add(entry: RequestHistoryEntry): void {
    this.history.unshift(entry);
    if (this.history.length > this.maxEntries) {
      this.history = this.history.slice(0, this.maxEntries);
    }
  }

  getAll(): RequestHistoryEntry[] {
    return [...this.history];
  }

  getRecent(count: number): RequestHistoryEntry[] {
    return this.history.slice(0, count);
  }

  findByTag(tag: string): RequestHistoryEntry[] {
    return this.history.filter((e) => e.request.tags?.includes(tag));
  }

  findByUrl(url: string): RequestHistoryEntry[] {
    return this.history.filter((e) => e.request.url.includes(url));
  }

  clear(): void {
    this.history = [];
  }
}
