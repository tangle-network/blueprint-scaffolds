import type { HttpRequest, HttpResponse, RetryConfig } from '../../shared/types.js';

const DEFAULT_RETRY_CONFIG: RetryConfig = {
  maxRetries: 3,
  initialDelayMs: 1000,
  maxDelayMs: 30000,
  backoffMultiplier: 2,
  retryOnStatuses: [408, 429, 500, 502, 503, 504],
};

function buildHeaders(request: HttpRequest): Record<string, string> {
  const headers: Record<string, string> = { ...request.headers };

  if (request.auth) {
    switch (request.auth.type) {
      case 'bearer':
        headers['Authorization'] = `Bearer ${request.auth.token}`;
        break;
      case 'basic': {
        const encoded = Buffer.from(`${request.auth.username}:${request.auth.password}`).toString('base64');
        headers['Authorization'] = `Basic ${encoded}`;
        break;
      }
      case 'apikey':
        if (request.auth.headerName && request.auth.headerValue) {
          headers[request.auth.headerName] = request.auth.headerValue;
        }
        break;
    }
  }

  if (request.body && !headers['Content-Type']) {
    try {
      JSON.parse(request.body);
      headers['Content-Type'] = 'application/json';
    } catch {
      headers['Content-Type'] = 'text/plain';
    }
  }

  return headers;
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function executeRequest(
  request: HttpRequest,
  retryConfig: Partial<RetryConfig> = {}
): Promise<HttpResponse> {
  const config = { ...DEFAULT_RETRY_CONFIG, ...retryConfig };
  const headers = buildHeaders(request);
  const startTime = Date.now();
  let lastError: Error | null = null;

  for (let attempt = 0; attempt <= config.maxRetries; attempt++) {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 30000);

      const fetchOptions: RequestInit = {
        method: request.method,
        headers,
        signal: controller.signal,
      };

      if (request.body && !['GET', 'HEAD'].includes(request.method)) {
        fetchOptions.body = request.body;
      }

      const response = await fetch(request.url, fetchOptions);
      clearTimeout(timeout);

      const responseBody = await response.text();
      const duration = Date.now() - startTime;

      const responseHeaders: Record<string, string> = {};
      response.headers.forEach((value, key) => {
        responseHeaders[key] = value;
      });

      const httpResponse: HttpResponse = {
        id: crypto.randomUUID(),
        requestId: request.id,
        status: response.status,
        statusText: response.statusText,
        headers: responseHeaders,
        body: responseBody,
        duration,
        timestamp: Date.now(),
        size: new TextEncoder().encode(responseBody).length,
      };

      if (config.retryOnStatuses.includes(response.status) && attempt < config.maxRetries) {
        const delay = Math.min(
          config.initialDelayMs * Math.pow(config.backoffMultiplier, attempt),
          config.maxDelayMs
        );
        await sleep(delay);
        continue;
      }

      return httpResponse;
    } catch (error) {
      lastError = error as Error;
      if (attempt < config.maxRetries) {
        const delay = Math.min(
          config.initialDelayMs * Math.pow(config.backoffMultiplier, attempt),
          config.maxDelayMs
        );
        await sleep(delay);
      }
    }
  }

  const duration = Date.now() - startTime;
  return {
    id: crypto.randomUUID(),
    requestId: request.id,
    status: 0,
    statusText: 'Request Failed',
    headers: {},
    body: JSON.stringify({ error: lastError?.message ?? 'Unknown error' }),
    duration,
    timestamp: Date.now(),
    size: 0,
  };
}
