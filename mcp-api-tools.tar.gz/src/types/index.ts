export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE' | 'HEAD' | 'OPTIONS';

export interface KeyValuePair {
  key: string;
  value: string;
  enabled: boolean;
}

export interface AuthConfig {
  type: 'none' | 'bearer' | 'basic' | 'api-key';
  token?: string;
  username?: string;
  password?: string;
  headerName?: string;
  headerValue?: string;
}

export interface HttpRequest {
  id: string;
  name: string;
  method: HttpMethod;
  url: string;
  headers: KeyValuePair[];
  queryParams: KeyValuePair[];
  body?: string;
  bodyType?: 'json' | 'text' | 'form-data' | 'none';
  auth: AuthConfig;
}

export interface HttpResponse {
  id: string;
  requestId: string;
  status: number;
  statusText: string;
  headers: Record<string, string>;
  body: string;
  size: number;
  duration: number;
  timestamp: number;
}

export interface RequestChain {
  id: string;
  name: string;
  steps: ChainStep[];
}

export interface ChainStep {
  requestId: string;
  variableExtractions: VariableExtraction[];
  enabled: boolean;
}

export interface VariableExtraction {
  source: 'header' | 'body' | 'status';
  path: string;
  variableName: string;
}

export interface Environment {
  id: string;
  name: string;
  variables: Record<string, string>;
}

export interface CacheEntry {
  key: string;
  response: HttpResponse;
  expiresAt: number;
}

export interface OpenApiSpec {
  openapi?: string;
  swagger?: string;
  info: { title: string; version: string; description?: string };
  servers?: { url: string; description?: string }[];
  paths: Record<string, Record<string, OpenApiOperation>>;
  components?: {
    schemas?: Record<string, unknown>;
    securitySchemes?: Record<string, unknown>;
  };
}

export interface OpenApiOperation {
  operationId?: string;
  summary?: string;
  description?: string;
  parameters?: OpenApiParameter[];
  requestBody?: {
    content?: Record<string, { schema?: unknown }>;
    description?: string;
    required?: boolean;
  };
  responses?: Record<string, { description?: string }>;
  tags?: string[];
}

export interface OpenApiParameter {
  name: string;
  in: 'query' | 'header' | 'path' | 'cookie';
  required?: boolean;
  description?: string;
  schema?: unknown;
}

export interface GraphQLRequest {
  id: string;
  name: string;
  endpoint: string;
  query: string;
  variables?: string;
  headers: KeyValuePair[];
  auth: AuthConfig;
}

export interface GraphQLResponse {
  id: string;
  requestId: string;
  data?: unknown;
  errors?: Array<{ message: string; locations?: Array<{ line: number; column: number }> }>;
  duration: number;
  timestamp: number;
}

export interface HistoryEntry {
  id: string;
  type: 'rest' | 'graphql';
  request: HttpRequest | GraphQLRequest;
  response: HttpResponse | GraphQLResponse;
  timestamp: number;
}

export interface RetryConfig {
  maxRetries: number;
  backoffMs: number;
  backoffMultiplier: number;
  retryOnStatuses: number[];
}
