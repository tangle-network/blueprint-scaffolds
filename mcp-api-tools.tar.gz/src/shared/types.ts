export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE' | 'HEAD' | 'OPTIONS';

export interface AuthConfig {
  type: 'none' | 'bearer' | 'basic' | 'apikey';
  token?: string;
  username?: string;
  password?: string;
  headerName?: string;
  headerValue?: string;
}

export interface HttpRequest {
  id: string;
  method: HttpMethod;
  url: string;
  headers: Record<string, string>;
  body?: string;
  auth?: AuthConfig;
  tags?: string[];
}

export interface HttpResponse {
  id: string;
  requestId: string;
  status: number;
  statusText: string;
  headers: Record<string, string>;
  body: string;
  duration: number;
  timestamp: number;
  size: number;
}

export interface CacheEntry {
  key: string;
  response: HttpResponse;
  expiresAt: number;
  tags: string[];
}

export interface EnvironmentVariable {
  key: string;
  value: string;
  description?: string;
}

export interface Environment {
  id: string;
  name: string;
  variables: EnvironmentVariable[];
}

export interface ChainedRequest {
  id: string;
  sourceRequestId: string;
  sourcePath: string;
  targetField: 'url' | 'header' | 'body' | 'query';
  targetName: string;
}

export interface OpenApiSpec {
  openapi: string;
  info: { title: string; version: string; description?: string };
  servers?: Array<{ url: string; description?: string }>;
  paths: Record<string, Record<string, OpenApiOperation>>;
  components?: {
    securitySchemes?: Record<string, OpenApiSecurityScheme>;
    schemas?: Record<string, unknown>;
  };
}

export interface OpenApiOperation {
  operationId?: string;
  summary?: string;
  description?: string;
  parameters?: OpenApiParameter[];
  requestBody?: {
    content: Record<string, { schema?: unknown; example?: unknown }>;
    required?: boolean;
  };
  responses?: Record<string, { description?: string }>;
  security?: Array<Record<string, string[]>>;
  tags?: string[];
}

export interface OpenApiParameter {
  name: string;
  in: 'query' | 'header' | 'path' | 'cookie';
  required?: boolean;
  schema?: { type?: string; enum?: string[]; default?: unknown };
  description?: string;
}

export interface OpenApiSecurityScheme {
  type: 'apiKey' | 'http' | 'oauth2' | 'openIdConnect';
  scheme?: string;
  bearerFormat?: string;
  in?: string;
  name?: string;
}

export interface GraphQLOperation {
  type: 'query' | 'mutation' | 'subscription';
  name?: string;
  query: string;
  variables?: Record<string, unknown>;
  operationName?: string;
}

export interface GraphQLResponse {
  data?: unknown;
  errors?: Array<{ message: string; locations?: Array<{ line: number; column: number }>; path?: string[] }>;
  extensions?: Record<string, unknown>;
}

export interface RequestHistoryEntry {
  request: HttpRequest;
  response: HttpResponse;
  chainResults?: Array<{ sourcePath: string; extractedValue: string }>;
}

export interface RetryConfig {
  maxRetries: number;
  initialDelayMs: number;
  maxDelayMs: number;
  backoffMultiplier: number;
  retryOnStatuses: number[];
}
