export { extractByPath, setByPath } from './json-path.js';
export type * from './types.js';
