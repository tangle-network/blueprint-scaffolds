export function extractByPath(obj: unknown, path: string): unknown {
  if (obj === null || obj === undefined) return undefined;
  if (!path || path === '$') return obj;

  const normalizedPath = path.startsWith('$.') ? path.slice(2) : path;
  const parts = normalizedPath.split(/\.|\[|\]/).filter(Boolean);
  let current: unknown = obj;

  for (const part of parts) {
    if (current === null || current === undefined) return undefined;
    if (Array.isArray(current)) {
      const idx = parseInt(part, 10);
      if (isNaN(idx)) return undefined;
      current = current[idx];
    } else if (typeof current === 'object') {
      current = (current as Record<string, unknown>)[part];
    } else {
      return undefined;
    }
  }
  return current;
}

export function setByPath(obj: unknown, path: string, value: unknown): unknown {
  if (!path || path === '$') return value;
  const normalizedPath = path.startsWith('$.') ? path.slice(2) : path;
  const parts = normalizedPath.split(/\.|\[|\]/).filter(Boolean);

  const result = structuredClone(obj);
  let current: Record<string, unknown> = result as Record<string, unknown>;

  for (let i = 0; i < parts.length - 1; i++) {
    const part = parts[i];
    const nextPart = parts[i + 1];
    if (!(part in current) || current[part] === null || current[part] === undefined) {
      current[part] = isNaN(parseInt(nextPart, 10)) ? {} : [];
    }
    current = current[part] as Record<string, unknown>;
  }

  current[parts[parts.length - 1]] = value;
  return result;
}
