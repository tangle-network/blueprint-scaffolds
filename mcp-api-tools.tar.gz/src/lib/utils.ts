import type {
  RetryConfig,
  CacheEntry,
  ResponseContext,
  AuthConfig,
} from '../types';

const DEFAULT_RETRY: RetryConfig = {
  maxRetries: 3,
  baseDelay: 1000,
  maxDelay: 30000,
  backoffMultiplier: 2,
  retryOnStatus: [408, 429, 500, 502, 503, 504],
};

let cache = new Map<string, CacheEntry>();
let defaultRetry = { ...DEFAULT_RETRY };
let cacheTtl = 60000;

export function getDefaultRetry(): RetryConfig {
  return { ...defaultRetry };
}

export function setDefaultRetry(cfg: Partial<RetryConfig>): void {
  defaultRetry = { ...DEFAULT_RETRY, ...cfg };
}

export function setCacheTtl(ttl: number): void {
  cacheTtl = ttl;
}

export function getCacheTtl(): number {
  return cacheTtl;
}

export function makeCacheKey(method: string, url: string, body?: unknown): string {
  const bodyHash = body ? JSON.stringify(body) : '';
  return `${method.toUpperCase()}:${url}:${bodyHash}`;
}

export function getCached(key: string): CacheEntry | undefined {
  const entry = cache.get(key);
  if (!entry) return undefined;
  if (Date.now() > entry.expiresAt) {
    cache.delete(key);
    return undefined;
  }
  return entry;
}

export function setCache(key: string, response: ResponseContext, tags: string[] = []): void {
  cache.set(key, {
    key,
    response,
    expiresAt: Date.now() + cacheTtl,
    tags,
  });
}

export function invalidateCache(key?: string): void {
  if (key) {
    cache.delete(key);
  } else {
    cache.clear();
  }
}

export function invalidateCacheByTag(tag: string): void {
  for (const [k, v] of cache) {
    if (v.tags.includes(tag)) cache.delete(k);
  }
}

export function buildHeaders(
  headers: Record<string, string>,
  auth?: AuthConfig
): Record<string, string> {
  const h = { ...headers };
  if (!auth) return h;

  switch (auth.type) {
    case 'bearer':
      if (auth.token) h['Authorization'] = `Bearer ${auth.token}`;
      break;
    case 'basic':
      if (auth.username && auth.password) {
        h['Authorization'] = `Basic ${btoa(`${auth.username}:${auth.password}`)}`;
      }
      break;
    case 'apikey':
      if (auth.headerName && auth.headerValue) {
        h[auth.headerName] = auth.headerValue;
      }
      break;
    case 'oauth2':
      if (auth.token) h['Authorization'] = `Bearer ${auth.token}`;
      break;
  }
  return h;
}

export function applyEnvVars(
  template: string,
  envVars: Record<string, string>
): string {
  return template.replace(/\{\{(\w+)\}\}/g, (_, key) => envVars[key] ?? `{{${key}}}`);
}

export function applyEnvVarsDeep<T>(obj: T, envVars: Record<string, string>): T {
  if (typeof obj === 'string') return applyEnvVars(obj, envVars) as unknown as T;
  if (Array.isArray(obj)) return obj.map((v) => applyEnvVarsDeep(v, envVars)) as unknown as T;
  if (obj !== null && typeof obj === 'object') {
    const result: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(obj as Record<string, unknown>)) {
      result[k] = applyEnvVarsDeep(v, envVars);
    }
    return result as T;
  }
  return obj;
}

export function extractFromResponse(
  response: ResponseContext,
  rules: Record<string, string>
): Record<string, unknown> {
  const result: Record<string, unknown> = {};
  for (const [name, path] of Object.entries(rules)) {
    result[name] = resolvePath(response, path);
  }
  return result;
}

function resolvePath(obj: unknown, path: string): unknown {
  const parts = path.replace(/\[(\d+)\]/g, '.$1').split('.');
  let current: unknown = obj;
  for (const part of parts) {
    if (current === null || current === undefined) return undefined;
    if (typeof current === 'object') {
      current = (current as Record<string, unknown>)[part];
    } else {
      return undefined;
    }
  }
  return current;
}

export function computeDelay(attempt: number, cfg: RetryConfig = defaultRetry): number {
  const delay = cfg.baseDelay * Math.pow(cfg.backoffMultiplier, attempt);
  return Math.min(delay, cfg.maxDelay);
}

export function shouldRetry(status: number, cfg: RetryConfig = defaultRetry): boolean {
  return cfg.retryOnStatus.includes(status);
}

export function parseJsonSafe(text: string): unknown {
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}
