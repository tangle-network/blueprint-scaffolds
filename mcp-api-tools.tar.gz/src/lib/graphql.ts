import type { GraphQLRequest, GraphQLResponse, KeyValuePair, AuthConfig } from '@/types';
import { generateId, buildHeaders, substituteVariables } from './request-builder';

export function createDefaultGraphQLRequest(partial?: Partial<GraphQLRequest>): GraphQLRequest {
  return {
    id: generateId(),
    name: 'Untitled Query',
    endpoint: '',
    query: '',
    variables: '{}',
    headers: [] as KeyValuePair[],
    auth: { type: 'none' } as AuthConfig,
    ...partial,
  };
}

export async function executeGraphQL(
  request: GraphQLRequest,
  variables: Record<string, string> = {}
): Promise<GraphQLResponse> {
  const start = Date.now();
  const endpoint = substituteVariables(request.endpoint, variables);
  const headers = buildHeaders(request.headers, request.auth);
  headers['Content-Type'] = 'application/json';

  let parsedVars: Record<string, unknown> = {};
  if (request.variables) {
    try {
      parsedVars = JSON.parse(substituteVariables(request.variables, variables));
    } catch { /* ignore */ }
  }

  const response = await fetch(endpoint, {
    method: 'POST',
    headers,
    body: JSON.stringify({ query: request.query, variables: parsedVars }),
  });

  const json = await response.json();
  return {
    id: generateId(),
    requestId: request.id,
    data: json.data,
    errors: json.errors,
    duration: Date.now() - start,
    timestamp: Date.now(),
  };
}

export function validateQuery(query: string): string[] {
  const errors: string[] = [];
  if (!query.trim()) {
    errors.push('Query is empty');
    return errors;
  }

  const openBraces = (query.match(/\{/g) || []).length;
  const closeBraces = (query.match(/\}/g) || []).length;
  if (openBraces !== closeBraces) {
    errors.push('Mismatched braces');
  }

  const openParens = (query.match(/\(/g) || []).length;
  const closeParens = (query.match(/\)/g) || []).length;
  if (openParens !== closeParens) {
    errors.push('Mismatched parentheses');
  }

  return errors;
}
