import type { RequestContext, ResponseContext, RetryConfig } from '../types';
import {
  buildHeaders,
  applyEnvVarsDeep,
  parseJsonSafe,
  generateId,
  getDefaultRetry,
  makeCacheKey,
  getCached,
  setCache,
  computeDelay,
  shouldRetry,
  extractFromResponse,
} from './utils';

export interface HttpClientOptions {
  envVars?: Record<string, string>;
  retry?: Partial<RetryConfig>;
  cache?: boolean;
  extractRules?: Record<string, string>;
}

async function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

export async function executeRequest(
  req: Omit<RequestContext, 'id' | 'timestamp'>,
  opts: HttpClientOptions = {}
): Promise<{ response: ResponseContext; request: RequestContext }> {
  const id = generateId();
  const timestamp = Date.now();
  const envVars = opts.envVars ?? {};

  let url = applyEnvVarsDeep(req.url, envVars) as string;
  let headers = applyEnvVarsDeep(req.headers ?? {}, envVars) as Record<string, string>;
  let body = req.body ? applyEnvVarsDeep(req.body, envVars) : undefined;

  headers = buildHeaders(headers, req.auth);

  if (req.params && Object.keys(req.params).length > 0) {
    const sp = new URLSearchParams();
    for (const [k, v] of Object.entries(req.params)) {
      sp.set(applyEnvVarsDeep(k, envVars) as string, applyEnvVarsDeep(v, envVars) as string);
    }
    const sep = url.includes('?') ? '&' : '?';
    url = `${url}${sep}${sp.toString()}`;
  }

  if (body && typeof body === 'object' && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }

  const request: RequestContext = {
    ...req,
    id,
    timestamp,
    url,
    headers,
    body,
  };

  const cacheKey = makeCacheKey(req.method, url, body);
  if (opts.cache) {
    const cached = getCached(cacheKey);
    if (cached) return { response: cached.response, request };
  }

  const retryCfg: RetryConfig = { ...getDefaultRetry(), ...opts.retry };
  let lastResponse: Response | undefined;
  let retries = 0;

  for (let attempt = 0; attempt <= retryCfg.maxRetries; attempt++) {
    if (attempt > 0) {
      await sleep(computeDelay(attempt - 1, retryCfg));
      retries = attempt;
    }

    const controller = new AbortController();
    const timeoutId = req.timeout
      ? setTimeout(() => controller.abort(), req.timeout)
      : undefined;

    try {
      const fetchBody = body !== undefined
        ? (typeof body === 'string' ? body : JSON.stringify(body))
        : undefined;

      lastResponse = await fetch(url, {
        method: req.method,
        headers,
        body: req.method !== 'GET' && req.method !== 'HEAD' ? fetchBody : undefined,
        signal: controller.signal,
      });
    } catch (err) {
      if (attempt === retryCfg.maxRetries) {
        throw new Error(`Request failed after ${retries} retries: ${(err as Error).message}`);
      }
      continue;
    } finally {
      if (timeoutId) clearTimeout(timeoutId);
    }

    if (lastResponse && shouldRetry(lastResponse.status, retryCfg) && attempt < retryCfg.maxRetries) {
      continue;
    }

    break;
  }

  if (!lastResponse) {
    throw new Error('Request failed: no response received');
  }

  const rawBody = await lastResponse.text();
  const parsedBody = parseJsonSafe(rawBody);
  const respHeaders: Record<string, string> = {};
  lastResponse.headers.forEach((v, k) => {
    respHeaders[k] = v;
  });

  const response: ResponseContext = {
    status: lastResponse.status,
    statusText: lastResponse.statusText,
    headers: respHeaders,
    body: parsedBody,
    rawBody,
    duration: Date.now() - timestamp,
    size: new Blob([rawBody]).size,
    requestId: id,
    timestamp: Date.now(),
  };

  if (opts.extractRules) {
    response.extracted = extractFromResponse(response, opts.extractRules);
  }

  if (opts.cache) {
    setCache(cacheKey, response, req.tags);
  }

  return { response, request };
}
