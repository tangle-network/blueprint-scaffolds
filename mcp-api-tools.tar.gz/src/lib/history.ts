import type { RequestHistoryEntry, RequestContext, ResponseContext } from '../types';
import { generateId } from './utils';

const MAX_HISTORY = 500;
let history: RequestHistoryEntry[] = [];

export function addToHistory(
  request: RequestContext,
  response?: ResponseContext,
  error?: string,
  retried: number = 0
): RequestHistoryEntry {
  const entry: RequestHistoryEntry = {
    id: generateId(),
    request,
    response,
    error,
    retried,
  };
  history.unshift(entry);
  if (history.length > MAX_HISTORY) {
    history = history.slice(0, MAX_HISTORY);
  }
  return entry;
}

export function getHistory(limit: number = 50): RequestHistoryEntry[] {
  return history.slice(0, limit);
}

export function getHistoryEntry(id: string): RequestHistoryEntry | undefined {
  return history.find((e) => e.id === id);
}

export function clearHistory(): void {
  history = [];
}

export function searchHistory(query: string): RequestHistoryEntry[] {
  const q = query.toLowerCase();
  return history.filter(
    (e) =>
      e.request.url.toLowerCase().includes(q) ||
      e.request.method.toLowerCase().includes(q) ||
      (e.error && e.error.toLowerCase().includes(q))
  );
}

export function retryFromHistory(id: string): RequestContext | undefined {
  const entry = getHistoryEntry(id);
  return entry ? { ...entry.request, id: generateId(), timestamp: Date.now() } : undefined;
}
