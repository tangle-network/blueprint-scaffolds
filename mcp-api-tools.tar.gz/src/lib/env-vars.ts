import type { Environment } from '@/types';
import { generateId } from './request-builder';

const STORAGE_KEY = 'mcp-api-environments';

export function createEnvironment(name: string, variables: Record<string, string> = {}): Environment {
  return { id: generateId(), name, variables };
}

export function loadEnvironments(): Environment[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveEnvironments(envs: Environment[]): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(envs));
}

export function resolveVariables(
  template: string,
  environments: Environment[],
  activeEnvId: string | null
): Record<string, string> {
  const merged: Record<string, string> = {};
  for (const env of environments) {
    Object.assign(merged, env.variables);
  }
  if (activeEnvId) {
    const active = environments.find(e => e.id === activeEnvId);
    if (active) Object.assign(merged, active.variables);
  }
  return merged;
}
