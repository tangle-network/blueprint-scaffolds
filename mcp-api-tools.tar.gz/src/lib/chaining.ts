import type { HttpRequest, HttpResponse, ChainStep, VariableExtraction } from '@/types';
import { executeRequest, substituteVariables } from './request-builder';
import { parseResponse, extractValue } from './response-handler';

export interface ChainResult {
  steps: Array<{
    step: ChainStep;
    response: HttpResponse;
    extractedVariables: Record<string, string>;
  }>;
  totalDuration: number;
}

export async function executeChain(
  requests: Map<string, HttpRequest>,
  steps: ChainStep[],
  globalVariables: Record<string, string> = {}
): Promise<ChainResult> {
  const results: ChainResult['steps'] = [];
  let variables = { ...globalVariables };
  const chainStart = Date.now();

  for (const step of steps) {
    if (!step.enabled) continue;

    const request = requests.get(step.requestId);
    if (!request) continue;

    const resolved = {
      ...request,
      url: substituteVariables(request.url, variables),
      body: request.body ? substituteVariables(request.body, variables) : request.body,
    };

    const start = Date.now();
    const response = await executeRequest(resolved);
    const parsed = await parseResponse(response, resolved.id, start);

    const extracted: Record<string, string> = {};
    for (const extraction of step.variableExtractions) {
      const value = extractValue(parsed, extraction.path);
      if (value !== null) {
        extracted[extraction.variableName] = value;
      }
    }

    variables = { ...variables, ...extracted };
    results.push({ step, response: parsed, extractedVariables: extracted });
  }

  return {
    steps: results,
    totalDuration: Date.now() - chainStart,
  };
}
