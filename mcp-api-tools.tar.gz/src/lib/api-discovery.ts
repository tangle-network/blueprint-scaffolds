import type { OpenApiSpec, OpenApiOperation, HttpRequest, KeyValuePair } from '@/types';
import { createDefaultRequest, generateId } from './request-builder';

export function parseOpenApiSpec(raw: string): OpenApiSpec {
  const spec = JSON.parse(raw);
  if (!spec.openapi && !spec.swagger) {
    throw new Error('Not a valid OpenAPI/Swagger spec');
  }
  return spec as OpenApiSpec;
}

export function getOperationsByTag(spec: OpenApiSpec): Record<string, Array<{ path: string; method: string; op: OpenApiOperation }>> {
  const result: Record<string, Array<{ path: string; method: string; op: OpenApiOperation }>> = {};
  for (const [path, methods] of Object.entries(spec.paths)) {
    for (const [method, op] of Object.entries(methods)) {
      if (['get', 'post', 'put', 'patch', 'delete', 'head', 'options'].includes(method.toLowerCase())) {
        const tags = op.tags?.length ? op.tags : ['default'];
        for (const tag of tags) {
          if (!result[tag]) result[tag] = [];
          result[tag].push({ path, method: method.toUpperCase(), op: op as OpenApiOperation });
        }
      }
    }
  }
  return result;
}

export function operationToRequest(
  spec: OpenApiSpec,
  path: string,
  method: string,
  op: OpenApiOperation
): HttpRequest {
  const baseUrl = (spec.servers && spec.servers.length > 0) ? spec.servers[0].url : '';
  const headers: KeyValuePair[] = [];
  const queryParams: KeyValuePair[] = [];

  if (op.parameters) {
    for (const param of op.parameters) {
      const kv: KeyValuePair = { key: param.name, value: '', enabled: true };
      if (param.in === 'query') queryParams.push(kv);
      else if (param.in === 'header') headers.push(kv);
    }
  }

  let body: string | undefined;
  let bodyType: HttpRequest['bodyType'] = 'none';
  if (op.requestBody?.content) {
    const jsonContent = op.requestBody.content['application/json'];
    if (jsonContent?.schema) {
      body = JSON.stringify(generateSample(jsonContent.schema), null, 2);
      bodyType = 'json';
      headers.push({ key: 'Content-Type', value: 'application/json', enabled: true });
    }
  }

  return createDefaultRequest({
    id: generateId(),
    name: op.summary || op.operationId || `${method} ${path}`,
    method: method.toUpperCase() as HttpRequest['method'],
    url: `${baseUrl}${path}`,
    headers,
    queryParams,
    body,
    bodyType,
  });
}

function generateSample(schema: unknown): unknown {
  if (!schema || typeof schema !== 'object') return null;
  const s = schema as Record<string, unknown>;

  if (s.example !== undefined) return s.example;
  if (s.default !== undefined) return s.default;

  switch (s.type) {
    case 'string': return Array.isArray(s.enum) ? (s.enum as unknown[])[0] : 'string';
    case 'number': return 0;
    case 'integer': return 0;
    case 'boolean': return true;
    case 'array': return s.items ? [generateSample(s.items)] : [];
    case 'object': {
      const obj: Record<string, unknown> = {};
      if (s.properties && typeof s.properties === 'object') {
        for (const [key, val] of Object.entries(s.properties as Record<string, unknown>)) {
          obj[key] = generateSample(val);
        }
      }
      return obj;
    }
    default: return null;
  }
}
