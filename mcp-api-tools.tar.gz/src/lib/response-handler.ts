import type { HttpResponse } from '@/types';
import { generateId } from './request-builder';

export async function parseResponse(
  response: Response,
  requestId: string,
  startTime: number
): Promise<HttpResponse> {
  const body = await response.text();
  const headers: Record<string, string> = {};
  response.headers.forEach((value, key) => { headers[key] = value; });

  return {
    id: generateId(),
    requestId,
    status: response.status,
    statusText: response.statusText,
    headers,
    body,
    size: new Blob([body]).size,
    duration: Date.now() - startTime,
    timestamp: Date.now(),
  };
}

export function extractValue(response: HttpResponse, path: string): string | null {
  if (path.startsWith('headers.')) {
    const headerName = path.slice(8).toLowerCase();
    const found = Object.entries(response.headers).find(
      ([k]) => k.toLowerCase() === headerName
    );
    return found ? found[1] : null;
  }

  if (path === 'status') return String(response.status);

  try {
    const json = JSON.parse(response.body);
    return String(path.split('.').reduce((obj: unknown, key: string) => {
      if (obj && typeof obj === 'object') return (obj as Record<string, unknown>)[key];
      return undefined;
    }, json) ?? null);
  } catch {
    return null;
  }
}

export function formatBody(body: string, contentType?: string): string {
  if (contentType?.includes('json') || contentType?.includes('javascript')) {
    try {
      return JSON.stringify(JSON.parse(body), null, 2);
    } catch { /* not json */ }
  }
  return body;
}

export function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function formatDuration(ms: number): string {
  return ms < 1000 ? `${ms} ms` : `${(ms / 1000).toFixed(2)} s`;
}

export function getStatusColor(status: number): string {
  if (status >= 200 && status < 300) return 'text-green-500';
  if (status >= 300 && status < 400) return 'text-blue-500';
  if (status >= 400 && status < 500) return 'text-yellow-500';
  return 'text-red-500';
}
