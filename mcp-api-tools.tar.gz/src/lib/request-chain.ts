import type { ChainLink, RequestChain, RequestContext, ResponseContext } from '../types';
import { generateId, applyEnvVarsDeep, extractFromResponse } from './utils';
import { executeRequest, type HttpClientOptions } from './http-client';

export interface ChainResult {
  chainId: string;
  results: Array<{
    step: number;
    request: RequestContext;
    response: ResponseContext;
    extracted?: Record<string, unknown>;
  }>;
  success: boolean;
  error?: string;
  failedStep?: number;
}

export async function executeChain(
  chain: RequestChain,
  opts: HttpClientOptions = {}
): Promise<ChainResult> {
  const results: ChainResult['results'] = [];
  let chainVars: Record<string, unknown> = {};
  const envVars = { ...(opts.envVars ?? {}) };

  for (let i = 0; i < chain.links.length; i++) {
    const link = chain.links[i];
    const resolvedUrl = applyEnvVarsDeep(
      applyChainVars(link.request.url, chainVars),
      envVars
    ) as string;

    const resolvedHeaders = applyEnvVarsDeep(
      applyChainVars(link.request.headers ?? {}, chainVars),
      envVars
    ) as Record<string, string>;

    const resolvedBody = link.request.body
      ? applyEnvVarsDeep(applyChainVars(link.request.body, chainVars), envVars)
      : undefined;

    const resolvedParams = link.request.params
      ? applyEnvVarsDeep(applyChainVars(link.request.params, chainVars), envVars) as Record<string, string>
      : undefined;

    try {
      const { request, response } = await executeRequest(
        {
          ...link.request,
          url: resolvedUrl,
          headers: resolvedHeaders,
          body: resolvedBody,
          params: resolvedParams,
        },
        opts
      );

      let extracted: Record<string, unknown> | undefined;
      if (link.extract) {
        extracted = extractFromResponse(response, link.extract);
        chainVars = { ...chainVars, ...extracted };
      }

      results.push({ step: i, request, response, extracted });

      if (response.status >= 400) {
        return {
          chainId: chain.id,
          results,
          success: false,
          error: `Step ${i} returned status ${response.status}`,
          failedStep: i,
        };
      }
    } catch (err) {
      return {
        chainId: chain.id,
        results,
        success: false,
        error: `Step ${i} failed: ${(err as Error).message}`,
        failedStep: i,
      };
    }
  }

  return { chainId: chain.id, results, success: true };
}

function applyChainVars<T>(obj: T, vars: Record<string, unknown>): T {
  if (typeof obj === 'string') {
    return obj.replace(/\{\{(\w+)\}\}/g, (_, key) => {
      const val = vars[key];
      return val !== undefined ? String(val) : `{{${key}}}`;
    }) as unknown as T;
  }
  if (Array.isArray(obj)) return obj.map((v) => applyChainVars(v, vars)) as unknown as T;
  if (obj !== null && typeof obj === 'object') {
    const result: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(obj as Record<string, unknown>)) {
      result[k] = applyChainVars(v, vars);
    }
    return result as T;
  }
  return obj;
}

export function createChain(name: string, links: ChainLink[]): RequestChain {
  return {
    id: generateId(),
    name,
    links,
  };
}
