import { create } from 'zustand';
import type {
  HttpRequest,
  HttpResponse,
  GraphQLRequest,
  GraphQLResponse,
  HistoryEntry,
  Environment,
  RequestChain,
  OpenApiSpec,
} from '@/types';
import { createDefaultRequest } from './request-builder';
import { createDefaultGraphQLRequest } from './graphql';
import { createEnvironment, loadEnvironments, saveEnvironments } from './env-vars';
import { generateId } from './request-builder';

interface AppState {
  requests: HttpRequest[];
  activeRequestId: string | null;
  lastResponse: HttpResponse | null;
  graphqlRequests: GraphQLRequest[];
  activeGraphQLId: string | null;
  lastGraphQLResponse: GraphQLResponse | null;
  history: HistoryEntry[];
  environments: Environment[];
  activeEnvId: string | null;
  chains: RequestChain[];
  openApiSpec: OpenApiSpec | null;
  sidebarTab: 'rest' | 'graphql' | 'api' | 'chains' | 'env' | 'history';

  addRequest: (req?: Partial<HttpRequest>) => HttpRequest;
  updateRequest: (id: string, updates: Partial<HttpRequest>) => void;
  removeRequest: (id: string) => void;
  setActiveRequest: (id: string | null) => void;
  setLastResponse: (response: HttpResponse | null) => void;

  addGraphQLRequest: (req?: Partial<GraphQLRequest>) => GraphQLRequest;
  updateGraphQLRequest: (id: string, updates: Partial<GraphQLRequest>) => void;
  removeGraphQLRequest: (id: string) => void;
  setActiveGraphQLRequest: (id: string | null) => void;
  setLastGraphQLResponse: (response: GraphQLResponse | null) => void;

  addHistoryEntry: (entry: HistoryEntry) => void;
  clearHistory: () => void;

  addEnvironment: (name: string) => Environment;
  updateEnvironment: (id: string, updates: Partial<Environment>) => void;
  removeEnvironment: (id: string) => void;
  setActiveEnv: (id: string | null) => void;

  addChain: (chain: RequestChain) => void;
  updateChain: (id: string, updates: Partial<RequestChain>) => void;
  removeChain: (id: string) => void;

  setOpenApiSpec: (spec: OpenApiSpec | null) => void;
  setSidebarTab: (tab: AppState['sidebarTab']) => void;
}

export const useStore = create<AppState>((set, get) => ({
  requests: [createDefaultRequest()],
  activeRequestId: null,
  lastResponse: null,
  graphqlRequests: [createDefaultGraphQLRequest()],
  activeGraphQLId: null,
  lastGraphQLResponse: null,
  history: [],
  environments: loadEnvironments(),
  activeEnvId: null,
  chains: [],
  openApiSpec: null,
  sidebarTab: 'rest',

  addRequest: (req?: Partial<HttpRequest>) => {
    const request = createDefaultRequest(req);
    set(state => ({ requests: [...state.requests, request], activeRequestId: request.id }));
    return request;
  },
  updateRequest: (id, updates) =>
    set(state => ({
      requests: state.requests.map(r => (r.id === id ? { ...r, ...updates } : r)),
    })),
  removeRequest: id =>
    set(state => {
      const filtered = state.requests.filter(r => r.id !== id);
      return {
        requests: filtered.length ? filtered : [createDefaultRequest()],
        activeRequestId: state.activeRequestId === id ? null : state.activeRequestId,
      };
    }),
  setActiveRequest: id => set({ activeRequestId: id }),
  setLastResponse: response => set({ lastResponse: response }),

  addGraphQLRequest: (req?: Partial<GraphQLRequest>) => {
    const request = createDefaultGraphQLRequest(req);
    set(state => ({ graphqlRequests: [...state.graphqlRequests, request], activeGraphQLId: request.id }));
    return request;
  },
  updateGraphQLRequest: (id, updates) =>
    set(state => ({
      graphqlRequests: state.graphqlRequests.map(r => (r.id === id ? { ...r, ...updates } : r)),
    })),
  removeGraphQLRequest: id =>
    set(state => {
      const filtered = state.graphqlRequests.filter(r => r.id !== id);
      return {
        graphqlRequests: filtered.length ? filtered : [createDefaultGraphQLRequest()],
        activeGraphQLId: state.activeGraphQLId === id ? null : state.activeGraphQLId,
      };
    }),
  setActiveGraphQLRequest: id => set({ activeGraphQLId: id }),
  setLastGraphQLResponse: response => set({ lastGraphQLResponse: response }),

  addHistoryEntry: entry => set(state => ({ history: [entry, ...state.history].slice(0, 100) })),
  clearHistory: () => set({ history: [] }),

  addEnvironment: name => {
    const env = createEnvironment(name);
    const envs = [...get().environments, env];
    saveEnvironments(envs);
    set({ environments: envs });
    return env;
  },
  updateEnvironment: (id, updates) => {
    const envs = get().environments.map(e => (e.id === id ? { ...e, ...updates } : e));
    saveEnvironments(envs);
    set({ environments: envs });
  },
  removeEnvironment: id => {
    const envs = get().environments.filter(e => e.id !== id);
    saveEnvironments(envs);
    set({ environments: envs, activeEnvId: get().activeEnvId === id ? null : get().activeEnvId });
  },
  setActiveEnv: id => set({ activeEnvId: id }),

  addChain: chain => set(state => ({ chains: [...state.chains, chain] })),
  updateChain: (id, updates) =>
    set(state => ({
      chains: state.chains.map(c => (c.id === id ? { ...c, ...updates } : c)),
    })),
  removeChain: id =>
    set(state => ({ chains: state.chains.filter(c => c.id !== id) })),

  setOpenApiSpec: spec => set({ openApiSpec: spec }),
  setSidebarTab: tab => set({ sidebarTab: tab }),
}));

export function getRequestMap(state: AppState): Map<string, HttpRequest> {
  const map = new Map<string, HttpRequest>();
  for (const r of state.requests) map.set(r.id, r);
  return map;
}
