import type { GraphQLQuery, ResponseContext } from '../types';
import { executeRequest, type HttpClientOptions } from './http-client';

export interface GraphQLOptions extends HttpClientOptions {
  endpoint: string;
}

export interface GraphQLResponse {
  data?: unknown;
  errors?: Array<{ message: string; locations?: Array<{ line: number; column: number }>; path?: string[] }>;
  extensions?: Record<string, unknown>;
  response: ResponseContext;
}

export async function executeGraphQL(
  opts: GraphQLOptions,
  query: GraphQLQuery
): Promise<GraphQLResponse> {
  const body: Record<string, unknown> = { query: query.query };
  if (query.variables) body.variables = query.variables;
  if (query.operationName) body.operationName = query.operationName;

  const { response } = await executeRequest(
    {
      method: 'POST',
      url: opts.endpoint,
      headers: { 'Content-Type': 'application/json', Accept: 'application/graphql+json' },
      body,
    },
    opts
  );

  const gqlResult = (response.body as Record<string, unknown>) ?? {};

  return {
    data: gqlResult.data as unknown,
    errors: gqlResult.errors as GraphQLResponse['errors'],
    extensions: gqlResult.extensions as Record<string, unknown>,
    response,
  };
}

export function buildGraphQLQuery(
  operation: 'query' | 'mutation' | 'subscription',
  name: string,
  fields: string,
  variables?: Record<string, { type: string; value: unknown }>
): GraphQLQuery {
  const varDefs: string[] = [];
  const varValues: Record<string, unknown> = {};

  if (variables) {
    for (const [key, { type, value }] of Object.entries(variables)) {
      varDefs.push(`$${key}: ${type}`);
      varValues[key] = value;
    }
  }

  const varString = varDefs.length > 0 ? `(${varDefs.join(', ')})` : '';
  const query = `${operation} ${name}${varString} {\n  ${name}${varString.replace(/\$/g, '')} {\n    ${fields}\n  }\n}`;

  return {
    query,
    variables: Object.keys(varValues).length > 0 ? varValues : undefined,
    operationName: name,
  };
}
