import type { OpenAPISpec, OpenAPIOperation, RequestContext } from '../types';
import { applyEnvVarsDeep } from './utils';

export function parseOpenAPISpec(raw: string): OpenAPISpec {
  const spec = JSON.parse(raw) as OpenAPISpec;
  if (!spec.openapi && !spec.swagger) {
    throw new Error('Invalid OpenAPI/Swagger spec: missing openapi or swagger version');
  }
  if (!spec.paths) {
    throw new Error('Invalid OpenAPI spec: missing paths');
  }
  return spec;
}

export function getOperations(spec: OpenAPISpec): Array<{
  path: string;
  method: string;
  operation: OpenAPIOperation;
}> {
  const operations: Array<{ path: string; method: string; operation: OpenAPIOperation }> = [];

  for (const [path, methods] of Object.entries(spec.paths)) {
    for (const [method, operation] of Object.entries(methods)) {
      if (['get', 'post', 'put', 'patch', 'delete', 'head', 'options'].includes(method.toLowerCase())) {
        operations.push({
          path,
          method: method.toUpperCase(),
          operation: operation as OpenAPIOperation,
        });
      }
    }
  }

  return operations;
}

export function getOperationById(
  spec: OpenAPISpec,
  operationId: string
): { path: string; method: string; operation: OpenAPIOperation } | undefined {
  return getOperations(spec).find((op) => op.operation.operationId === operationId);
}

export function operationToRequest(
  spec: OpenAPISpec,
  path: string,
  method: string,
  operation: OpenAPIOperation,
  baseUrl?: string,
  envVars?: Record<string, string>
): Omit<RequestContext, 'id' | 'timestamp'> {
  const serverUrl = baseUrl ?? spec.servers?.[0]?.url ?? '';
  let fullPath = `${serverUrl}${path}`;

  const headers: Record<string, string> = {};
  const params: Record<string, string> = {};

  if (operation.parameters) {
    for (const param of operation.parameters) {
      const defaultValue = param.schema?.default as string | undefined;
      if (param.in === 'path') {
        fullPath = fullPath.replace(`{${param.name}}`, defaultValue ?? `{${param.name}}`);
      } else if (param.in === 'query') {
        if (defaultValue) params[param.name] = defaultValue;
      } else if (param.in === 'header') {
        if (defaultValue) headers[param.name] = defaultValue;
      }
    }
  }

  if (envVars) {
    fullPath = applyEnvVarsDeep(fullPath, envVars) as string;
  }

  let body: unknown = undefined;
  if (operation.requestBody?.content?.['application/json']?.schema) {
    const schema = operation.requestBody.content['application/json'].schema as Record<string, unknown>;
    body = schemaToExample(schema, spec.components?.schemas);
  }

  return {
    method: method.toUpperCase(),
    url: fullPath,
    headers,
    body,
    params,
  };
}

function schemaToExample(
  schema: Record<string, unknown>,
  definitions?: Record<string, unknown>
): unknown {
  if (schema.$ref && definitions) {
    const refName = (schema.$ref as string).split('/').pop()!;
    const resolved = definitions[refName] as Record<string, unknown> | undefined;
    if (resolved) return schemaToExample(resolved, definitions);
  }

  if (schema.example !== undefined) return schema.example;

  const type = schema.type as string;

  if (type === 'object' && schema.properties) {
    const obj: Record<string, unknown> = {};
    for (const [key, val] of Object.entries(schema.properties as Record<string, Record<string, unknown>>)) {
      obj[key] = schemaToExample(val, definitions);
    }
    return obj;
  }

  if (type === 'array' && schema.items) {
    return [schemaToExample(schema.items as Record<string, unknown>, definitions)];
  }

  if (type === 'string') return '';
  if (type === 'number' || type === 'integer') return 0;
  if (type === 'boolean') return false;

  return null;
}

export function getTags(spec: OpenAPISpec): string[] {
  const tags = new Set<string>();
  for (const methods of Object.values(spec.paths)) {
    for (const [method, op] of Object.entries(methods)) {
      if (typeof op === 'object' && op !== null && 'tags' in op) {
        for (const tag of (op as OpenAPIOperation).tags ?? []) {
          tags.add(tag);
        }
      }
    }
  }
  return Array.from(tags);
}

export function getServerUrls(spec: OpenAPISpec): string[] {
  return spec.servers?.map((s) => s.url) ?? [];
}
