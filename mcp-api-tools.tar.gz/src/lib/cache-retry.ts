import type { HttpResponse, CacheEntry, RetryConfig } from '@/types';

const CACHE_KEY = 'mcp-api-response-cache';
const DEFAULT_TTL = 5 * 60 * 1000;

export function getDefaultRetryConfig(): RetryConfig {
  return {
    maxRetries: 3,
    backoffMs: 1000,
    backoffMultiplier: 2,
    retryOnStatuses: [408, 429, 500, 502, 503, 504],
  };
}

export function getCachedResponse(cacheKey: string): HttpResponse | null {
  const entries = loadCache();
  const entry = entries.find(e => e.key === cacheKey);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    const filtered = entries.filter(e => e.key !== cacheKey);
    saveCache(filtered);
    return null;
  }
  return entry.response;
}

export function setCachedResponse(cacheKey: string, response: HttpResponse, ttlMs: number = DEFAULT_TTL): void {
  const entries = loadCache();
  const existing = entries.findIndex(e => e.key === cacheKey);
  const entry: CacheEntry = { key: cacheKey, response, expiresAt: Date.now() + ttlMs };
  if (existing >= 0) entries[existing] = entry;
  else entries.push(entry);
  saveCache(entries);
}

export function clearCache(): void {
  localStorage.removeItem(CACHE_KEY);
}

export function generateCacheKey(method: string, url: string, body?: string): string {
  return `${method}:${url}${body ? `:${body}` : ''}`;
}

export async function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export async function executeWithRetry<T>(
  fn: () => Promise<{ response: HttpResponse; result: T }>,
  config: RetryConfig = getDefaultRetryConfig(),
  shouldCache: boolean = false,
  cacheKey?: string
): Promise<{ response: HttpResponse; result: T; retries: number }> {
  let lastResponse: HttpResponse | null = null;
  let retries = 0;

  if (shouldCache && cacheKey) {
    const cached = getCachedResponse(cacheKey);
    if (cached) return { response: cached, result: cached.body as unknown as T, retries: 0 };
  }

  for (let attempt = 0; attempt <= config.maxRetries; attempt++) {
    try {
      const { response, result } = await fn();
      lastResponse = response;

      if (attempt > 0) retries = attempt;

      if (config.retryOnStatuses.includes(response.status) && attempt < config.maxRetries) {
        const delay = config.backoffMs * Math.pow(config.backoffMultiplier, attempt);
        await sleep(delay);
        continue;
      }

      if (shouldCache && cacheKey) {
        setCachedResponse(cacheKey, response);
      }

      return { response, result, retries };
    } catch (error) {
      if (attempt >= config.maxRetries) throw error;
      const delay = config.backoffMs * Math.pow(config.backoffMultiplier, attempt);
      await sleep(delay);
    }
  }

  throw new Error('Max retries exceeded');
}

function loadCache(): CacheEntry[] {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveCache(entries: CacheEntry[]): void {
  localStorage.setItem(CACHE_KEY, JSON.stringify(entries));
}
