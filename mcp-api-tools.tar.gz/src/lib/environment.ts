import type { EnvironmentConfig } from '../types';

let environments: EnvironmentConfig[] = [
  { name: 'default', variables: {}, active: true },
];

export function getEnvironments(): EnvironmentConfig[] {
  return [...environments];
}

export function getActiveEnvironment(): EnvironmentConfig {
  return environments.find((e) => e.active) ?? environments[0];
}

export function setActiveEnvironment(name: string): void {
  environments = environments.map((e) => ({
    ...e,
    active: e.name === name,
  }));
}

export function addEnvironment(env: Omit<EnvironmentConfig, 'active'>): void {
  environments.push({ ...env, active: false });
}

export function removeEnvironment(name: string): void {
  if (name === 'default') return;
  environments = environments.filter((e) => e.name !== name);
}

export function setVariable(envName: string, key: string, value: string): void {
  const env = environments.find((e) => e.name === envName);
  if (env) {
    env.variables[key] = value;
  }
}

export function removeVariable(envName: string, key: string): void {
  const env = environments.find((e) => e.name === envName);
  if (env) {
    delete env.variables[key];
  }
}

export function getEnvVars(): Record<string, string> {
  return { ...getActiveEnvironment().variables };
}
