import type { HttpMethod, HttpRequest, KeyValuePair, AuthConfig } from '@/types';

export function generateId(): string {
  return Math.random().toString(36).substring(2, 15) + Date.now().toString(36);
}

export function createDefaultRequest(partial?: Partial<HttpRequest>): HttpRequest {
  return {
    id: generateId(),
    name: 'Untitled Request',
    method: 'GET',
    url: '',
    headers: [] as KeyValuePair[],
    queryParams: [] as KeyValuePair[],
    body: undefined,
    bodyType: 'none',
    auth: { type: 'none' } as AuthConfig,
    ...partial,
  };
}

export function buildHeaders(headers: KeyValuePair[], auth: AuthConfig): Record<string, string> {
  const result: Record<string, string> = {};
  for (const h of headers) {
    if (h.enabled && h.key) {
      result[h.key] = h.value;
    }
  }

  switch (auth.type) {
    case 'bearer':
      if (auth.token) result['Authorization'] = `Bearer ${auth.token}`;
      break;
    case 'basic':
      if (auth.username && auth.password) {
        result['Authorization'] = `Basic ${btoa(`${auth.username}:${auth.password}`)}`;
      }
      break;
    case 'api-key':
      if (auth.headerName && auth.headerValue) {
        result[auth.headerName] = auth.headerValue;
      }
      break;
  }

  return result;
}

export function substituteVariables(template: string, variables: Record<string, string>): string {
  return template.replace(/\{\{(\w+)\}\}/g, (_, key) => variables[key] ?? `{{${key}}}`);
}

export function buildUrl(baseUrl: string, queryParams: KeyValuePair[]): string {
  const url = new URL(baseUrl);
  for (const param of queryParams) {
    if (param.enabled && param.key) {
      url.searchParams.append(param.key, param.value);
    }
  }
  return url.toString();
}

export async function executeRequest(
  request: HttpRequest,
  variables: Record<string, string> = {}
): Promise<Response> {
  const url = buildUrl(substituteVariables(request.url, variables), request.queryParams);
  const headers = buildHeaders(request.headers, request.auth);

  let body: string | undefined;
  if (request.body && request.bodyType !== 'none') {
    body = substituteVariables(request.body, variables);
  }

  return fetch(url, {
    method: request.method,
    headers,
    body,
  });
}
