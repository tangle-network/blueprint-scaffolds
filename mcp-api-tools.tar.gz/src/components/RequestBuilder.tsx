import React, { useState } from 'react';
import { useStore } from '@/lib/store';
import type { HttpRequest } from '@/types';
import { executeRequest, substituteVariables } from '@/lib/request-builder';
import { parseResponse } from '@/lib/response-handler';
import { generateCacheKey, executeWithRetry, getDefaultRetryConfig } from '@/lib/cache-retry';
import { resolveVariables } from '@/lib/env-vars';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { KeyValueEditor } from '@/components/KeyValueEditor';
import { AuthEditor } from '@/components/AuthEditor';
import { ResponseViewer } from '@/components/ResponseViewer';
import { Send, Plus, Trash2 } from 'lucide-react';

export function RequestBuilder() {
  const {
    requests, activeRequestId, lastResponse,
    addRequest, updateRequest, removeRequest,
    setActiveRequest, setLastResponse,
    addHistoryEntry, environments, activeEnvId,
  } = useStore();

  const [loading, setLoading] = useState(false);
  const [useCache, setUseCache] = useState(false);

  const activeRequest = activeRequestId
    ? requests.find(r => r.id === activeRequestId)
    : requests[0];

  const update = (updates: Partial<HttpRequest>) => {
    if (activeRequest) updateRequest(activeRequest.id, updates);
  };

  const handleSend = async () => {
    if (!activeRequest || !activeRequest.url.trim()) return;
    setLoading(true);
    try {
      const vars = resolveVariables('', environments, activeEnvId);
      const cacheKey = generateCacheKey(activeRequest.method, activeRequest.url, activeRequest.body);

      if (useCache) {
        const { response } = await executeWithRetry(
          async () => {
            const start = Date.now();
            const raw = await executeRequest(activeRequest, vars);
            const parsed = await parseResponse(raw, activeRequest.id, start);
            return { response: parsed, result: parsed };
          },
          getDefaultRetryConfig(),
          true,
          cacheKey
        );
        setLastResponse(response);
        addHistoryEntry({
          id: crypto.randomUUID?.() ?? Math.random().toString(36).slice(2),
          type: 'rest',
          request: activeRequest,
          response,
          timestamp: Date.now(),
        });
      } else {
        const start = Date.now();
        const raw = await executeRequest(activeRequest, vars);
        const response = await parseResponse(raw, activeRequest.id, start);
        setLastResponse(response);
        addHistoryEntry({
          id: crypto.randomUUID?.() ?? Math.random().toString(36).slice(2),
          type: 'rest',
          request: activeRequest,
          response,
          timestamp: Date.now(),
        });
      }
    } catch (err: unknown) {
      setLastResponse({
        id: 'err',
        requestId: activeRequest?.id ?? '',
        status: 0,
        statusText: 'Error',
        headers: {},
        body: err instanceof Error ? err.message : String(err),
        size: 0,
        duration: 0,
        timestamp: Date.now(),
      });
    } finally {
      setLoading(false);
    }
  };

  const methodColors: Record<string, string> = {
    GET: 'text-green-600', POST: 'text-blue-600', PUT: 'text-orange-600',
    PATCH: 'text-yellow-600', DELETE: 'text-red-600', HEAD: 'text-purple-600', OPTIONS: 'text-gray-600',
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-2 mb-3">
        <Select value={activeRequest?.method ?? 'GET'} onValueChange={v => update({ method: v as HttpRequest['method'] })}>
          <SelectTrigger className="w-28">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS'].map(m => (
              <SelectItem key={m} value={m}>
                <span className={methodColors[m]}>{m}</span>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Input
          value={activeRequest?.url ?? ''}
          onChange={e => update({ url: e.target.value })}
          placeholder="https://api.example.com/endpoint"
          className="flex-1"
        />
        <Button onClick={handleSend} disabled={loading}>
          <Send className="h-4 w-4 mr-1" />
          {loading ? 'Sending...' : 'Send'}
        </Button>
        <Button variant="outline" size="icon" onClick={() => addRequest()}>
          <Plus className="h-4 w-4" />
        </Button>
      </div>

      <div className="flex gap-1 mb-2 flex-wrap">
        {requests.map(r => (
          <button
            key={r.id}
            onClick={() => setActiveRequest(r.id)}
            className={`px-2 py-1 text-xs rounded border cursor-pointer ${r.id === (activeRequestId ?? requests[0]?.id) ? 'bg-primary text-primary-foreground' : 'bg-muted hover:bg-accent'}`}
          >
            <span className={r.id === (activeRequestId ?? requests[0]?.id) ? '' : methodColors[r.method]}>{r.method}</span>
            {' '}{r.name || r.url || 'New'}
            <span className="ml-1 opacity-50" onClick={e => { e.stopPropagation(); removeRequest(r.id); }}>x</span>
          </button>
        ))}
      </div>

      {activeRequest && (
        <Tabs defaultValue="params" className="flex-1 overflow-auto">
          <TabsList>
            <TabsTrigger value="params">Params</TabsTrigger>
            <TabsTrigger value="headers">Headers</TabsTrigger>
            <TabsTrigger value="body">Body</TabsTrigger>
            <TabsTrigger value="auth">Auth</TabsTrigger>
          </TabsList>
          <TabsContent value="params">
            <KeyValueEditor
              pairs={activeRequest.queryParams}
              onChange={qp => update({ queryParams: qp })}
              keyPlaceholder="Query param"
              valuePlaceholder="Value"
            />
          </TabsContent>
          <TabsContent value="headers">
            <KeyValueEditor
              pairs={activeRequest.headers}
              onChange={h => update({ headers: h })}
              keyPlaceholder="Header name"
              valuePlaceholder="Header value"
            />
          </TabsContent>
          <TabsContent value="body">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Label className="text-xs">Body Type</Label>
                <Select value={activeRequest.bodyType ?? 'none'} onValueChange={v => update({ bodyType: v as HttpRequest['bodyType'] })}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    <SelectItem value="json">JSON</SelectItem>
                    <SelectItem value="text">Text</SelectItem>
                    <SelectItem value="form-data">Form Data</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {activeRequest.bodyType !== 'none' && (
                <Textarea
                  value={activeRequest.body ?? ''}
                  onChange={e => update({ body: e.target.value })}
                  placeholder='{"key": "value"}'
                  className="font-mono text-xs min-h-[200px]"
                />
              )}
            </div>
          </TabsContent>
          <TabsContent value="auth">
            <AuthEditor
              auth={activeRequest.auth}
              onChange={a => update({ auth: a })}
            />
          </TabsContent>
        </Tabs>
      )}

      <div className="mt-3 border-t pt-3">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-sm font-medium">Response</span>
          <label className="flex items-center gap-1 text-xs text-muted-foreground">
            <input type="checkbox" checked={useCache} onChange={e => setUseCache(e.target.checked)} />
            Cache
          </label>
        </div>
        <ResponseViewer response={lastResponse} />
      </div>
    </div>
  );
}
