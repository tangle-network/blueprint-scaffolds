import React from 'react'

export default function GraphQLEditor() { return <div>GraphQLEditor</div> }
