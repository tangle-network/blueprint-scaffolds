import React from 'react';
import { useStore } from '@/lib/store';
import { formatDuration, getStatusColor, formatBody, formatSize } from '@/lib/response-handler';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Trash2 } from 'lucide-react';
import type { HttpRequest, GraphQLRequest, HttpResponse, GraphQLResponse } from '@/types';

export function HistoryPanel() {
  const { history, clearHistory, addRequest, addGraphQLRequest, setActiveRequest, setActiveGraphQLRequest, setSidebarTab } = useStore();

  const handleReuse = (entry: typeof history[0]) => {
    if (entry.type === 'rest') {
      const req = addRequest(entry.request as Partial<HttpRequest>);
      setActiveRequest(req.id);
      setSidebarTab('rest');
    } else {
      const req = addGraphQLRequest(entry.request as Partial<GraphQLRequest>);
      setActiveGraphQLRequest(req.id);
      setSidebarTab('graphql');
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium">Request History</span>
        <Button variant="ghost" size="sm" onClick={clearHistory}>
          <Trash2 className="h-3 w-3 mr-1" /> Clear
        </Button>
      </div>

      {history.length === 0 && (
        <div className="text-sm text-muted-foreground">No requests in history yet.</div>
      )}

      {history.map(entry => {
        const isRest = entry.type === 'rest';
        const restReq = entry.request as HttpRequest;
        const gqlReq = entry.request as GraphQLRequest;
        const restRes = entry.response as HttpResponse;
        const gqlRes = entry.response as GraphQLResponse;

        return (
          <Card key={entry.id} className="cursor-pointer hover:bg-accent/50" onClick={() => handleReuse(entry)}>
            <CardContent className="p-3 space-y-1">
              <div className="flex items-center gap-2 text-xs">
                <span className={`font-mono font-bold ${isRest ? methodColor(restReq.method) : 'text-purple-600'}`}>
                  {isRest ? restReq.method : 'GQL'}
                </span>
                <span className="truncate flex-1 font-mono">
                  {isRest ? restReq.url : gqlReq.endpoint}
                </span>
                {isRest && (
                  <span className={getStatusColor(restRes.status)}>{restRes.status}</span>
                )}
                <span className="text-muted-foreground">
                  {new Date(entry.timestamp).toLocaleTimeString()}
                </span>
              </div>
              {isRest && (
                <div className="text-xs text-muted-foreground">
                  {formatDuration(restRes.duration)} &middot; {formatSize(restRes.size)}
                </div>
              )}
              {!isRest && (
                <div className="text-xs text-muted-foreground">
                  {formatDuration(gqlRes.duration)}
                  {gqlRes.errors && gqlRes.errors.length > 0 && ' · Errors'}
                </div>
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}

function methodColor(method: string): string {
  const colors: Record<string, string> = {
    GET: 'text-green-600', POST: 'text-blue-600', PUT: 'text-orange-600',
    PATCH: 'text-yellow-600', DELETE: 'text-red-600',
  };
  return colors[method] ?? 'text-gray-600';
}
