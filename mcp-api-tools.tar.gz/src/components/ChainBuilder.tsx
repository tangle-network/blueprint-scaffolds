import React, { useState } from 'react';
import { useStore, getRequestMap } from '@/lib/store';
import { executeChain } from '@/lib/chaining';
import { resolveVariables } from '@/lib/env-vars';
import type { RequestChain, ChainStep, VariableExtraction } from '@/types';
import { generateId } from '@/lib/request-builder';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Play, Plus, Trash2 } from 'lucide-react';
import { formatDuration } from '@/lib/response-handler';

export function ChainBuilder() {
  const { requests, chains, addChain, updateChain, removeChain, environments, activeEnvId } = useStore();
  const [selectedChainId, setSelectedChainId] = useState<string | null>(null);
  const [chainResult, setChainResult] = useState<Awaited<ReturnType<typeof executeChain>> | null>(null);
  const [loading, setLoading] = useState(false);

  const selectedChain = chains.find(c => c.id === selectedChainId);

  const handleCreate = () => {
    const chain: RequestChain = {
      id: generateId(),
      name: 'New Chain',
      steps: [],
    };
    addChain(chain);
    setSelectedChainId(chain.id);
  };

  const handleAddStep = () => {
    if (!selectedChain) return;
    const step: ChainStep = {
      requestId: requests[0]?.id ?? '',
      variableExtractions: [],
      enabled: true,
    };
    updateChain(selectedChain.id, { steps: [...selectedChain.steps, step] });
  };

  const handleUpdateStep = (index: number, updates: Partial<ChainStep>) => {
    if (!selectedChain) return;
    const steps = selectedChain.steps.map((s, i) => (i === index ? { ...s, ...updates } : s));
    updateChain(selectedChain.id, { steps });
  };

  const handleRemoveStep = (index: number) => {
    if (!selectedChain) return;
    updateChain(selectedChain.id, { steps: selectedChain.steps.filter((_, i) => i !== index) });
  };

  const handleAddExtraction = (stepIndex: number) => {
    if (!selectedChain) return;
    const steps = selectedChain.steps.map((s, i) => {
      if (i !== stepIndex) return s;
      return {
        ...s,
        variableExtractions: [...s.variableExtractions, { source: 'body' as const, path: '', variableName: '' }],
      };
    });
    updateChain(selectedChain.id, { steps });
  };

  const handleUpdateExtraction = (stepIndex: number, extIndex: number, updates: Partial<VariableExtraction>) => {
    if (!selectedChain) return;
    const steps = selectedChain.steps.map((s, i) => {
      if (i !== stepIndex) return s;
      return {
        ...s,
        variableExtractions: s.variableExtractions.map((e, j) => (j === extIndex ? { ...e, ...updates } : e)),
      };
    });
    updateChain(selectedChain.id, { steps });
  };

  const handleExecute = async () => {
    if (!selectedChain) return;
    setLoading(true);
    try {
      const vars = resolveVariables('', environments, activeEnvId);
      const requestMap = getRequestMap(useStore.getState());
      const result = await executeChain(requestMap, selectedChain.steps, vars);
      setChainResult(result);
    } catch (err: unknown) {
      setChainResult(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Label className="text-sm font-medium">Chains</Label>
        <Button size="sm" onClick={handleCreate}>
          <Plus className="h-3 w-3 mr-1" /> New Chain
        </Button>
      </div>

      <div className="flex gap-1 flex-wrap">
        {chains.map(c => (
          <button
            key={c.id}
            onClick={() => { setSelectedChainId(c.id); setChainResult(null); }}
            className={`px-2 py-1 text-xs rounded border cursor-pointer ${c.id === selectedChainId ? 'bg-primary text-primary-foreground' : 'bg-muted hover:bg-accent'}`}
          >
            {c.name}
            <span className="ml-1 opacity-50" onClick={e => { e.stopPropagation(); removeChain(c.id); }}>x</span>
          </button>
        ))}
      </div>

      {selectedChain && (
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Input
                value={selectedChain.name}
                onChange={e => updateChain(selectedChain.id, { name: e.target.value })}
                className="font-medium"
              />
              <Button onClick={handleExecute} disabled={loading}>
                <Play className="h-4 w-4 mr-1" />
                {loading ? 'Running...' : 'Run'}
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {selectedChain.steps.map((step, si) => (
              <div key={si} className="border rounded p-3 space-y-2">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={step.enabled}
                    onChange={e => handleUpdateStep(si, { enabled: e.target.checked })}
                    className="h-4 w-4"
                  />
                  <Label className="text-xs">Step {si + 1}:</Label>
                  <Select value={step.requestId} onValueChange={v => handleUpdateStep(si, { requestId: v })}>
                    <SelectTrigger className="flex-1">
                      <SelectValue placeholder="Select request" />
                    </SelectTrigger>
                    <SelectContent>
                      {requests.map(r => (
                        <SelectItem key={r.id} value={r.id}>{r.name} ({r.method} {r.url})</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button variant="ghost" size="sm" onClick={() => handleRemoveStep(si)}>
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>

                <div className="ml-4 space-y-1">
                  <div className="flex items-center gap-2">
                    <Label className="text-xs">Extractions:</Label>
                    <Button variant="ghost" size="sm" onClick={() => handleAddExtraction(si)}>+ Ext</Button>
                  </div>
                  {step.variableExtractions.map((ext, ei) => (
                    <div key={ei} className="flex items-center gap-1">
                      <Select value={ext.source} onValueChange={v => handleUpdateExtraction(si, ei, { source: v as VariableExtraction['source'] })}>
                        <SelectTrigger className="w-20 h-7 text-xs"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="body">Body</SelectItem>
                          <SelectItem value="header">Header</SelectItem>
                          <SelectItem value="status">Status</SelectItem>
                        </SelectContent>
                      </Select>
                      <Input value={ext.path} onChange={e => handleUpdateExtraction(si, ei, { path: e.target.value })} placeholder="data.token" className="h-7 text-xs flex-1" />
                      <Input value={ext.variableName} onChange={e => handleUpdateExtraction(si, ei, { variableName: e.target.value })} placeholder="varName" className="h-7 text-xs w-24" />
                    </div>
                  ))}
                </div>
              </div>
            ))}
            <Button variant="outline" size="sm" onClick={handleAddStep}>
              <Plus className="h-3 w-3 mr-1" /> Add Step
            </Button>
          </CardContent>
        </Card>
      )}

      {chainResult && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Chain Result ({formatDuration(chainResult.totalDuration)})</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {chainResult.steps.map((s, i) => (
              <div key={i} className="text-xs border rounded p-2">
                <div className="font-medium">Step {i + 1}: {s.response.status} {s.response.statusText} ({formatDuration(s.response.duration)})</div>
                {Object.keys(s.extractedVariables).length > 0 && (
                  <div className="mt-1 text-muted-foreground">
                    Extracted: {Object.entries(s.extractedVariables).map(([k, v]) => `${k}=${v}`).join(', ')}
                  </div>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
