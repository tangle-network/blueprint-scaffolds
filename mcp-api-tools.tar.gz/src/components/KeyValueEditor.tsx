import React from 'react';
import type { KeyValuePair } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface Props {
  pairs: KeyValuePair[];
  onChange: (pairs: KeyValuePair[]) => void;
  keyPlaceholder?: string;
  valuePlaceholder?: string;
}

export function KeyValueEditor({ pairs, onChange, keyPlaceholder = 'Key', valuePlaceholder = 'Value' }: Props) {
  const update = (index: number, field: keyof KeyValuePair, value: string | boolean) => {
    const updated = pairs.map((p, i) => (i === index ? { ...p, [field]: value } : p));
    onChange(updated);
  };

  const add = () => onChange([...pairs, { key: '', value: '', enabled: true }]);

  const remove = (index: number) => onChange(pairs.filter((_, i) => i !== index));

  return (
    <div className="space-y-2">
      {pairs.map((pair, i) => (
        <div key={i} className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={pair.enabled}
            onChange={e => update(i, 'enabled', e.target.checked)}
            className="h-4 w-4"
          />
          <Input
            value={pair.key}
            onChange={e => update(i, 'key', e.target.value)}
            placeholder={keyPlaceholder}
            className="flex-1"
          />
          <Input
            value={pair.value}
            onChange={e => update(i, 'value', e.target.value)}
            placeholder={valuePlaceholder}
            className="flex-1"
          />
          <Button variant="ghost" size="sm" onClick={() => remove(i)}>
            &times;
          </Button>
        </div>
      ))}
      <Button variant="outline" size="sm" onClick={add}>
        + Add
      </Button>
    </div>
  );
}
