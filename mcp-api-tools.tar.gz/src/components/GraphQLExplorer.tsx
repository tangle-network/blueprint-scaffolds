import React, { useState } from 'react';
import { useStore } from '@/lib/store';
import type { GraphQLRequest } from '@/types';
import { executeGraphQL, validateQuery } from '@/lib/graphql';
import { resolveVariables } from '@/lib/env-vars';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { KeyValueEditor } from '@/components/KeyValueEditor';
import { AuthEditor } from '@/components/AuthEditor';
import { Send, Plus } from 'lucide-react';

export function GraphQLExplorer() {
  const {
    graphqlRequests, activeGraphQLId, lastGraphQLResponse,
    addGraphQLRequest, updateGraphQLRequest, setActiveGraphQLRequest,
    setLastGraphQLResponse, addHistoryEntry,
    environments, activeEnvId,
  } = useStore();

  const [loading, setLoading] = useState(false);

  const activeRequest = activeGraphQLId
    ? graphqlRequests.find(r => r.id === activeGraphQLId)
    : graphqlRequests[0];

  const update = (updates: Partial<GraphQLRequest>) => {
    if (activeRequest) updateGraphQLRequest(activeRequest.id, updates);
  };

  const handleSend = async () => {
    if (!activeRequest || !activeRequest.endpoint.trim() || !activeRequest.query.trim()) return;
    setLoading(true);
    try {
      const vars = resolveVariables('', environments, activeEnvId);
      const response = await executeGraphQL(activeRequest, vars);
      setLastGraphQLResponse(response);
      addHistoryEntry({
        id: Math.random().toString(36).slice(2),
        type: 'graphql',
        request: activeRequest,
        response,
        timestamp: Date.now(),
      });
    } catch (err: unknown) {
      setLastGraphQLResponse({
        id: 'err',
        requestId: activeRequest?.id ?? '',
        errors: [{ message: err instanceof Error ? err.message : String(err) }],
        duration: 0,
        timestamp: Date.now(),
      });
    } finally {
      setLoading(false);
    }
  };

  const validationErrors = activeRequest ? validateQuery(activeRequest.query) : [];

  return (
    <div className="flex flex-col h-full gap-3">
      <div className="flex items-center gap-2 mb-1">
        <Label className="text-xs w-16">Endpoint</Label>
        <Input
          value={activeRequest?.endpoint ?? ''}
          onChange={e => update({ endpoint: e.target.value })}
          placeholder="https://api.example.com/graphql"
          className="flex-1"
        />
        <Button onClick={handleSend} disabled={loading}>
          <Send className="h-4 w-4 mr-1" />
          {loading ? 'Sending...' : 'Send'}
        </Button>
        <Button variant="outline" size="icon" onClick={() => addGraphQLRequest()}>
          <Plus className="h-4 w-4" />
        </Button>
      </div>

      <div className="flex gap-1 flex-wrap">
        {graphqlRequests.map(r => (
          <button
            key={r.id}
            onClick={() => setActiveGraphQLRequest(r.id)}
            className={`px-2 py-1 text-xs rounded border cursor-pointer ${r.id === (activeGraphQLId ?? graphqlRequests[0]?.id) ? 'bg-primary text-primary-foreground' : 'bg-muted hover:bg-accent'}`}
          >
            {r.name || 'Untitled'}
          </button>
        ))}
      </div>

      {activeRequest && (
        <Tabs defaultValue="query" className="flex-1 overflow-auto">
          <TabsList>
            <TabsTrigger value="query">Query</TabsTrigger>
            <TabsTrigger value="variables">Variables</TabsTrigger>
            <TabsTrigger value="headers">Headers</TabsTrigger>
            <TabsTrigger value="auth">Auth</TabsTrigger>
          </TabsList>
          <TabsContent value="query">
            <div className="space-y-2">
              <Input
                value={activeRequest.name}
                onChange={e => update({ name: e.target.value })}
                placeholder="Query name"
                className="mb-2"
              />
              <Textarea
                value={activeRequest.query}
                onChange={e => update({ query: e.target.value })}
                placeholder="query { users { id name } }"
                className="font-mono text-xs min-h-[200px]"
              />
              {validationErrors.length > 0 && (
                <div className="text-xs text-red-500">
                  {validationErrors.map((e, i) => <div key={i}>{e}</div>)}
                </div>
              )}
            </div>
          </TabsContent>
          <TabsContent value="variables">
            <Textarea
              value={activeRequest.variables ?? '{}'}
              onChange={e => update({ variables: e.target.value })}
              placeholder='{"limit": 10}'
              className="font-mono text-xs min-h-[200px]"
            />
          </TabsContent>
          <TabsContent value="headers">
            <KeyValueEditor
              pairs={activeRequest.headers}
              onChange={h => update({ headers: h })}
              keyPlaceholder="Header name"
              valuePlaceholder="Header value"
            />
          </TabsContent>
          <TabsContent value="auth">
            <AuthEditor
              auth={activeRequest.auth}
              onChange={a => update({ auth: a })}
            />
          </TabsContent>
        </Tabs>
      )}

      <div className="border-t pt-3">
        <span className="text-sm font-medium">Response</span>
        {lastGraphQLResponse ? (
          <div className="mt-2 space-y-2">
            <div className="text-xs text-muted-foreground">
              {lastGraphQLResponse.duration} ms
            </div>
            {lastGraphQLResponse.errors && lastGraphQLResponse.errors.length > 0 && (
              <pre className="bg-red-50 text-red-700 p-3 rounded text-xs overflow-auto max-h-[200px]">
                {JSON.stringify(lastGraphQLResponse.errors, null, 2)}
              </pre>
            )}
            {lastGraphQLResponse.data !== undefined && (
              <pre className="bg-muted p-3 rounded text-xs overflow-auto max-h-[300px] font-mono">
                {JSON.stringify(lastGraphQLResponse.data, null, 2)}
              </pre>
            )}
          </div>
        ) : (
          <div className="text-sm text-muted-foreground mt-2">Send a query to see the response</div>
        )}
      </div>
    </div>
  );
}
