import React from 'react';
import type { AuthConfig } from '@/types';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';

interface Props {
  auth: AuthConfig;
  onChange: (auth: AuthConfig) => void;
}

export function AuthEditor({ auth, onChange }: Props) {
  return (
    <div className="space-y-3">
      <div>
        <Label>Auth Type</Label>
        <Select value={auth.type} onValueChange={v => onChange({ ...auth, type: v as AuthConfig['type'] })}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">None</SelectItem>
            <SelectItem value="bearer">Bearer Token</SelectItem>
            <SelectItem value="basic">Basic Auth</SelectItem>
            <SelectItem value="api-key">API Key</SelectItem>
          </SelectContent>
        </Select>
      </div>
      {auth.type === 'bearer' && (
        <div>
          <Label>Token</Label>
          <Input value={auth.token ?? ''} onChange={e => onChange({ ...auth, token: e.target.value })} placeholder="Bearer token" />
        </div>
      )}
      {auth.type === 'basic' && (
        <>
          <div>
            <Label>Username</Label>
            <Input value={auth.username ?? ''} onChange={e => onChange({ ...auth, username: e.target.value })} placeholder="Username" />
          </div>
          <div>
            <Label>Password</Label>
            <Input type="password" value={auth.password ?? ''} onChange={e => onChange({ ...auth, password: e.target.value })} placeholder="Password" />
          </div>
        </>
      )}
      {auth.type === 'api-key' && (
        <>
          <div>
            <Label>Header Name</Label>
            <Input value={auth.headerName ?? ''} onChange={e => onChange({ ...auth, headerName: e.target.value })} placeholder="X-API-Key" />
          </div>
          <div>
            <Label>Header Value</Label>
            <Input value={auth.headerValue ?? ''} onChange={e => onChange({ ...auth, headerValue: e.target.value })} placeholder="your-api-key" />
          </div>
        </>
      )}
    </div>
  );
}
