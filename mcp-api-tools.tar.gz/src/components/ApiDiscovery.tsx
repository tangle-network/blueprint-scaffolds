import React, { useState } from 'react';
import { useStore } from '@/lib/store';
import { parseOpenApiSpec, getOperationsByTag, operationToRequest } from '@/lib/api-discovery';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Globe, Upload, Zap } from 'lucide-react';

export function ApiDiscovery() {
  const { openApiSpec, setOpenApiSpec, addRequest } = useStore();
  const [rawSpec, setRawSpec] = useState('');
  const [specUrl, setSpecUrl] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleParse = () => {
    setError('');
    try {
      const spec = parseOpenApiSpec(rawSpec);
      setOpenApiSpec(spec);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Invalid spec');
    }
  };

  const handleFetchSpec = async () => {
    if (!specUrl.trim()) return;
    setLoading(true);
    setError('');
    try {
      const res = await fetch(specUrl);
      const text = await res.text();
      setRawSpec(text);
      const spec = parseOpenApiSpec(text);
      setOpenApiSpec(spec);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Failed to fetch spec');
    } finally {
      setLoading(false);
    }
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      const text = ev.target?.result as string;
      setRawSpec(text);
      try {
        const spec = parseOpenApiSpec(text);
        setOpenApiSpec(spec);
        setError('');
      } catch (err: unknown) {
        setError(err instanceof Error ? err.message : 'Invalid spec');
      }
    };
    reader.readAsText(file);
  };

  const handleAddOperation = (path: string, method: string) => {
    if (!openApiSpec) return;
    const methods = openApiSpec.paths[path];
    if (!methods) return;
    const op = methods[method];
    if (!op) return;
    const request = operationToRequest(openApiSpec, path, method, op);
    addRequest(request);
  };

  const taggedOps = openApiSpec ? getOperationsByTag(openApiSpec) : {};

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Import OpenAPI / Swagger Spec</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex gap-2">
            <Input
              value={specUrl}
              onChange={e => setSpecUrl(e.target.value)}
              placeholder="https://api.example.com/openapi.json"
              className="flex-1"
            />
            <Button onClick={handleFetchSpec} disabled={loading}>
              <Globe className="h-4 w-4 mr-1" />
              Fetch
            </Button>
          </div>
          <div className="flex items-center gap-2">
            <Label className="text-xs">Or upload file:</Label>
            <input type="file" accept=".json,.yaml,.yml" onChange={handleImport} className="text-xs" />
          </div>
          <Textarea
            value={rawSpec}
            onChange={e => setRawSpec(e.target.value)}
            placeholder="Paste OpenAPI JSON spec here..."
            className="font-mono text-xs min-h-[150px]"
          />
          <Button onClick={handleParse} variant="outline">Parse Spec</Button>
          {error && <div className="text-xs text-red-500">{error}</div>}
        </CardContent>
      </Card>

      {openApiSpec && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">
              {openApiSpec.info.title} v{openApiSpec.info.version}
            </CardTitle>
            {openApiSpec.info.description && (
              <p className="text-sm text-muted-foreground">{openApiSpec.info.description}</p>
            )}
          </CardHeader>
          <CardContent>
            {Object.entries(taggedOps).map(([tag, ops]) => (
              <div key={tag} className="mb-4">
                <h4 className="font-medium text-sm mb-2">{tag}</h4>
                <div className="space-y-1">
                  {ops.map(({ path, method, op }, i) => (
                    <div key={i} className="flex items-center gap-2 p-2 rounded bg-muted text-xs">
                      <span className={`font-mono font-bold ${methodColor(method)}`}>{method}</span>
                      <span className="font-mono">{path}</span>
                      <span className="text-muted-foreground flex-1 truncate">{op.summary ?? ''}</span>
                      <Button size="sm" variant="ghost" onClick={() => handleAddOperation(path, method)}>
                        <Zap className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function methodColor(method: string): string {
  const colors: Record<string, string> = {
    GET: 'text-green-600', POST: 'text-blue-600', PUT: 'text-orange-600',
    PATCH: 'text-yellow-600', DELETE: 'text-red-600',
  };
  return colors[method] ?? 'text-gray-600';
}
