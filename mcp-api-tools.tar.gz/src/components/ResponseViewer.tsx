import React, { useState } from 'react';
import type { HttpResponse } from '@/types';
import { formatBody, formatSize, formatDuration, getStatusColor } from '@/lib/response-handler';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface Props {
  response: HttpResponse | null;
}

export function ResponseViewer({ response }: Props) {
  if (!response) {
    return (
      <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
        Send a request to see the response
      </div>
    );
  }

  const contentType = response.headers['content-type'] ?? '';
  const formatted = formatBody(response.body, contentType);

  return (
    <div className="space-y-3">
      <div className="flex gap-4 text-sm">
        <span className={`font-semibold ${getStatusColor(response.status)}`}>
          {response.status} {response.statusText}
        </span>
        <span className="text-muted-foreground">{formatDuration(response.duration)}</span>
        <span className="text-muted-foreground">{formatSize(response.size)}</span>
      </div>
      <Tabs defaultValue="body">
        <TabsList>
          <TabsTrigger value="body">Body</TabsTrigger>
          <TabsTrigger value="headers">Headers</TabsTrigger>
        </TabsList>
        <TabsContent value="body">
          <pre className="bg-muted p-3 rounded-md text-xs overflow-auto max-h-[500px] font-mono">
            {formatted}
          </pre>
        </TabsContent>
        <TabsContent value="headers">
          <pre className="bg-muted p-3 rounded-md text-xs overflow-auto max-h-[500px] font-mono">
            {Object.entries(response.headers)
              .map(([k, v]) => `${k}: ${v}`)
              .join('\n')}
          </pre>
        </TabsContent>
      </Tabs>
    </div>
  );
}
