import React, { useState } from 'react';
import { useStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, Save } from 'lucide-react';

export function EnvironmentManager() {
  const {
    environments, activeEnvId,
    addEnvironment, updateEnvironment, removeEnvironment, setActiveEnv,
  } = useStore();
  const [newEnvName, setNewEnvName] = useState('');
  const [newVarKey, setNewVarKey] = useState('');
  const [newVarValue, setNewVarValue] = useState('');

  const activeEnv = environments.find(e => e.id === activeEnvId);

  const handleCreate = () => {
    if (!newEnvName.trim()) return;
    addEnvironment(newEnvName.trim());
    setNewEnvName('');
  };

  const handleAddVar = () => {
    if (!activeEnv || !newVarKey.trim()) return;
    updateEnvironment(activeEnv.id, {
      variables: { ...activeEnv.variables, [newVarKey.trim()]: newVarValue },
    });
    setNewVarKey('');
    setNewVarValue('');
  };

  const handleRemoveVar = (key: string) => {
    if (!activeEnv) return;
    const { [key]: _, ...rest } = activeEnv.variables;
    updateEnvironment(activeEnv.id, { variables: rest });
  };

  const handleUpdateVar = (oldKey: string, newKey: string, newValue: string) => {
    if (!activeEnv) return;
    const vars = { ...activeEnv.variables };
    if (oldKey !== newKey) {
      const { [oldKey]: _, ...rest } = vars;
      rest[newKey] = newValue;
      updateEnvironment(activeEnv.id, { variables: rest });
    } else {
      vars[newKey] = newValue;
      updateEnvironment(activeEnv.id, { variables: vars });
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Label className="text-sm font-medium">Active Environment</Label>
        <Select value={activeEnvId ?? 'none'} onValueChange={v => setActiveEnv(v === 'none' ? null : v)}>
          <SelectTrigger className="flex-1">
            <SelectValue placeholder="No environment" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">No environment</SelectItem>
            {environments.map(env => (
              <SelectItem key={env.id} value={env.id}>{env.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="flex gap-2">
        <Input value={newEnvName} onChange={e => setNewEnvName(e.target.value)} placeholder="Environment name" />
        <Button onClick={handleCreate}><Plus className="h-3 w-3 mr-1" /> Create</Button>
      </div>

      {environments.map(env => (
        <Card key={env.id} className={env.id === activeEnvId ? 'border-primary' : ''}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm">{env.name}</CardTitle>
              <div className="flex gap-1">
                <Button variant="ghost" size="sm" onClick={() => setActiveEnv(env.id)}>Use</Button>
                <Button variant="ghost" size="sm" onClick={() => removeEnvironment(env.id)}>
                  <Trash2 className="h-3 w-3" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
            {Object.entries(env.variables).map(([key, value]) => (
              <div key={key} className="flex items-center gap-1">
                <Input
                  value={key}
                  onChange={e => handleUpdateVar(key, e.target.value, value)}
                  className="h-7 text-xs flex-1"
                />
                <Input
                  value={value}
                  onChange={e => handleUpdateVar(key, key, e.target.value)}
                  className="h-7 text-xs flex-1"
                />
                <Button variant="ghost" size="sm" onClick={() => handleRemoveVar(key)}>
                  <Trash2 className="h-3 w-3" />
                </Button>
              </div>
            ))}
            {env.id === activeEnvId && (
              <div className="flex items-center gap-1 mt-2">
                <Input value={newVarKey} onChange={e => setNewVarKey(e.target.value)} placeholder="KEY" className="h-7 text-xs flex-1" />
                <Input value={newVarValue} onChange={e => setNewVarValue(e.target.value)} placeholder="VALUE" className="h-7 text-xs flex-1" />
                <Button variant="outline" size="sm" onClick={handleAddVar}>
                  <Plus className="h-3 w-3" />
                </Button>
              </div>
            )}
            <div className="text-xs text-muted-foreground mt-1">
              Use <code className="bg-muted px-1 rounded">{'{{varName}}'}</code> in URLs, headers, and body
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
