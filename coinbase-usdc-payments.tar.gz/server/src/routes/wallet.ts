import { Router } from "express";
import QRCode from "qrcode";
import { createUserWallet, getUserWallet, getWalletBalance } from "../services/wallet.js";
import { query } from "../services/database.js";

export const walletRouter = Router();

walletRouter.post("/create", async (req, res) => {
  try {
    const { username } = req.body;
    if (!username) {
      res.status(400).json({ error: "Username is required" });
      return;
    }

    const existing = await getUserWallet(username);
    if (existing) {
      res.status(409).json({ error: "Username already exists" });
      return;
    }

    const wallet = await createUserWallet(username);
    res.status(201).json(wallet);
  } catch (err) {
    console.error("Error creating wallet:", err);
    res.status(500).json({ error: "Failed to create wallet" });
  }
});

walletRouter.get("/:username", async (req, res) => {
  try {
    const user = await getUserWallet(req.params.username);
    if (!user) {
      res.status(404).json({ error: "User not found" });
      return;
    }
    res.json(user);
  } catch (err) {
    console.error("Error fetching wallet:", err);
    res.status(500).json({ error: "Failed to fetch wallet" });
  }
});

walletRouter.get("/:username/balance", async (req, res) => {
  try {
    const user = await getUserWallet(req.params.username);
    if (!user) {
      res.status(404).json({ error: "User not found" });
      return;
    }
    const balance = await getWalletBalance(user.wallet_address);
    res.json(balance);
  } catch (err) {
    console.error("Error fetching balance:", err);
    res.status(500).json({ error: "Failed to fetch balance" });
  }
});

walletRouter.get("/:username/qrcode", async (req, res) => {
  try {
    const user = await getUserWallet(req.params.username);
    if (!user) {
      res.status(404).json({ error: "User not found" });
      return;
    }
    const qrData = JSON.stringify({
      address: user.wallet_address,
      username: user.username,
      network: "base",
      token: "usdc",
    });
    const qrImage = await QRCode.toDataURL(qrData);
    res.json({ qr: qrImage, address: user.wallet_address });
  } catch (err) {
    console.error("Error generating QR code:", err);
    res.status(500).json({ error: "Failed to generate QR code" });
  }
});

walletRouter.get("/:username/transactions", async (req, res) => {
  try {
    const user = await getUserWallet(req.params.username);
    if (!user) {
      res.status(404).json({ error: "User not found" });
      return;
    }
    const result = await query(
      `SELECT t.*, 
        su.username as sender_username, 
        ru.username as receiver_username
       FROM transactions t
       LEFT JOIN users su ON t.sender_id = su.id
       LEFT JOIN users ru ON t.receiver_id = ru.id
       WHERE t.sender_id = $1 OR t.receiver_id = $1
       ORDER BY t.created_at DESC`,
      [user.id]
    );
    res.json(result.rows);
  } catch (err) {
    console.error("Error fetching transactions:", err);
    res.status(500).json({ error: "Failed to fetch transactions" });
  }
});
