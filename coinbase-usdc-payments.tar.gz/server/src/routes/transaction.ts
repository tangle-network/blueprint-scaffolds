import { Router } from "express";
import { query } from "../services/database.js";

export const transactionRouter = Router();

transactionRouter.get("/all", async (_req, res) => {
  try {
    const result = await query(
      `SELECT t.*, 
        su.username as sender_username, 
        ru.username as receiver_username
       FROM transactions t
       LEFT JOIN users su ON t.sender_id = su.id
       LEFT JOIN users ru ON t.receiver_id = ru.id
       ORDER BY t.created_at DESC
       LIMIT 100`
    );
    res.json(result.rows);
  } catch (err) {
    console.error("Error fetching transactions:", err);
    res.status(500).json({ error: "Failed to fetch transactions" });
  }
});

transactionRouter.get("/:txHash", async (req, res) => {
  try {
    const result = await query(
      `SELECT t.*, 
        su.username as sender_username, 
        ru.username as receiver_username
       FROM transactions t
       LEFT JOIN users su ON t.sender_id = su.id
       LEFT JOIN users ru ON t.receiver_id = ru.id
       WHERE t.tx_hash = $1`,
      [req.params.txHash]
    );
    if (result.rows.length === 0) {
      res.status(404).json({ error: "Transaction not found" });
      return;
    }
    res.json(result.rows[0]);
  } catch (err) {
    console.error("Error fetching transaction:", err);
    res.status(500).json({ error: "Failed to fetch transaction" });
  }
});
