import { Router } from "express";
import { sendUsdc, getUserWallet } from "../services/wallet.js";
import { query } from "../services/database.js";
import { parseUnits } from "@coinbase/cdp-sdk";

export const paymentRouter = Router();

paymentRouter.post("/send", async (req, res) => {
  try {
    const { fromUsername, toUsername, amount } = req.body;

    if (!fromUsername || !toUsername || !amount) {
      res.status(400).json({
        error: "fromUsername, toUsername, and amount are required",
      });
      return;
    }

    const sender = await getUserWallet(fromUsername);
    const receiver = await getUserWallet(toUsername);

    if (!sender) {
      res.status(404).json({ error: "Sender not found" });
      return;
    }
    if (!receiver) {
      res.status(404).json({ error: "Receiver not found" });
      return;
    }

    const amountAtomic = parseUnits(amount, 6).toString();

    const txResult = await sendUsdc(
      sender.wallet_address,
      receiver.wallet_address,
      amountAtomic
    );

    await query(
      `INSERT INTO transactions (sender_id, receiver_id, amount, tx_hash, status) VALUES ($1, $2, $3, $4, $5)`,
      [
        sender.id,
        receiver.id,
        amount,
        "transactionHash" in txResult
          ? txResult.transactionHash
          : (txResult as { userOpHash: string }).userOpHash,
        "confirmed",
      ]
    );

    res.json({
      success: true,
      txHash:
        "transactionHash" in txResult
          ? txResult.transactionHash
          : (txResult as { userOpHash: string }).userOpHash,
      amount,
      from: sender.username,
      to: receiver.username,
    });
  } catch (err) {
    console.error("Error sending payment:", err);
    res.status(500).json({ error: "Failed to send payment" });
  }
});

paymentRouter.post("/send-address", async (req, res) => {
  try {
    const { fromUsername, toAddress, amount } = req.body;

    if (!fromUsername || !toAddress || !amount) {
      res.status(400).json({
        error: "fromUsername, toAddress, and amount are required",
      });
      return;
    }

    const sender = await getUserWallet(fromUsername);
    if (!sender) {
      res.status(404).json({ error: "Sender not found" });
      return;
    }

    const amountAtomic = parseUnits(amount, 6).toString();

    const txResult = await sendUsdc(
      sender.wallet_address,
      toAddress,
      amountAtomic
    );

    res.json({
      success: true,
      txHash:
        "transactionHash" in txResult
          ? txResult.transactionHash
          : (txResult as { userOpHash: string }).userOpHash,
      amount,
      from: sender.username,
      to: toAddress,
    });
  } catch (err) {
    console.error("Error sending payment to address:", err);
    res.status(500).json({ error: "Failed to send payment" });
  }
});
