import "dotenv/config";
import express from "express";
import cors from "cors";
import { walletRouter } from "./routes/wallet.js";
import { paymentRouter } from "./routes/payment.js";
import { transactionRouter } from "./routes/transaction.js";
import { initDatabase } from "./services/database.js";

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors({ origin: process.env.CLIENT_URL || "http://localhost:5173" }));
app.use(express.json());

app.use("/api/wallet", walletRouter);
app.use("/api/payment", paymentRouter);
app.use("/api/transaction", transactionRouter);

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", network: "base" });
});

async function start() {
  await initDatabase();
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

start().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});

export default app;
