import { CdpClient } from "@coinbase/cdp-sdk";
import { query } from "./database.js";

const cdp = new CdpClient();

const BASE_NETWORK = "base" as const;
const USDC_BASE = "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913" as const;

export { cdp, BASE_NETWORK, USDC_BASE };

export async function createUserWallet(username: string) {
  const account = await cdp.evm.createAccount({
    name: `user-${username}`,
  });

  await query(
    `INSERT INTO users (username, wallet_address, wallet_name) VALUES ($1, $2, $3) RETURNING *`,
    [username, account.address, `user-${username}`]
  );

  return {
    username,
    address: account.address,
    name: account.name,
  };
}

export async function getUserWallet(username: string) {
  const result = await query(`SELECT * FROM users WHERE username = $1`, [
    username,
  ]);
  return result.rows[0] || null;
}

export async function getWalletBalance(address: string) {
  const account = await cdp.evm.getAccount({ address: address as `0x${string}` });
  const networkAccount = await account.useNetwork(BASE_NETWORK);
  const balances = await networkAccount.listTokenBalances({});

  const usdcBalance = balances.balances.find(
    (b) =>
      b.token.contractAddress.toLowerCase() === USDC_BASE.toLowerCase()
  );

  const ethBalance = balances.balances.find(
    (b) =>
      b.token.contractAddress.toLowerCase() ===
      "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee".toLowerCase()
  );

  return {
    usdc: usdcBalance
      ? {
          amount: usdcBalance.amount.amount.toString(),
          decimals: usdcBalance.amount.decimals,
          symbol: usdcBalance.token.symbol || "USDC",
        }
      : { amount: "0", decimals: 6, symbol: "USDC" },
    eth: ethBalance
      ? {
          amount: ethBalance.amount.amount.toString(),
          decimals: ethBalance.amount.decimals,
          symbol: ethBalance.token.symbol || "ETH",
        }
      : { amount: "0", decimals: 18, symbol: "ETH" },
  };
}

export async function sendUsdc(
  senderAddress: string,
  receiverAddress: string,
  amount: string
): Promise<{ transactionHash: string }> {
  const senderAccount = await cdp.evm.getAccount({
    address: senderAddress as `0x${string}`,
  });
  const networkAccount = await senderAccount.useNetwork(BASE_NETWORK);

  const amountBigInt = BigInt(amount);

  const result = await networkAccount.transfer({
    to: receiverAddress as `0x${string}`,
    amount: amountBigInt,
    token: "usdc",
  });

  return { transactionHash: String(result.transactionHash) };
}
