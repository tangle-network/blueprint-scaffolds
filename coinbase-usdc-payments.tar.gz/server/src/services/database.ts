import pg from "pg";

const { Pool } = pg;

const pool = new pg.Pool({
  connectionString:
    process.env.DATABASE_URL ||
    "postgresql://user:password@localhost:5432/usdc_payments",
});

export async function query(text: string, params?: unknown[]) {
  const start = Date.now();
  const res = await pool.query(text, params);
  const duration = Date.now() - start;
  console.log("Executed query", { text, duration, rows: res.rowCount });
  return res;
}

export async function initDatabase() {
  await query(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      username VARCHAR(255) UNIQUE NOT NULL,
      wallet_address VARCHAR(255) UNIQUE NOT NULL,
      wallet_name VARCHAR(255) UNIQUE NOT NULL,
      created_at TIMESTAMP DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS transactions (
      id SERIAL PRIMARY KEY,
      sender_id INTEGER REFERENCES users(id),
      receiver_id INTEGER REFERENCES users(id),
      amount VARCHAR(255) NOT NULL,
      tx_hash VARCHAR(255),
      status VARCHAR(50) DEFAULT 'pending',
      network VARCHAR(50) DEFAULT 'base',
      created_at TIMESTAMP DEFAULT NOW()
    );
  `);
  console.log("Database initialized");
}
