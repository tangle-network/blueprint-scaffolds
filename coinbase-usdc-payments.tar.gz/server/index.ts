import express from "express";
import cors from "cors";
import { Wallet, Coinbase } from "@coinbase/coinbase-sdk";
import { v4 as uuidv4 } from "uuid";

const app = express();
app.use(cors());
app.use(express.json());

interface UserWallet {
  id: string;
  wallet: Wallet;
  address: string;
  createdAt: Date;
}

interface Transaction {
  id: string;
  fromAddress: string;
  toAddress: string;
  amount: string;
  status: "pending" | "completed" | "failed";
  txHash: string;
  createdAt: Date;
}

const wallets = new Map<string, UserWallet>();
const transactions: Transaction[] = [];

let coinbaseConfigured = false;

try {
  if (process.env.CDP_API_KEY_NAME && process.env.CDP_API_KEY_PRIVATE_KEY) {
    Coinbase.configure({
      apiKeyName: process.env.CDP_API_KEY_NAME,
      privateKey: process.env.CDP_API_KEY_PRIVATE_KEY,
    });
    coinbaseConfigured = true;
  }
} catch {
  console.log("CDP SDK not configured - running in demo mode");
}

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", coinbaseConfigured });
});

app.post("/api/wallets", async (req, res) => {
  try {
    const { userId } = req.body;
    if (!userId) {
      res.status(400).json({ error: "userId is required" });
      return;
    }

    if (wallets.has(userId)) {
      const existing = wallets.get(userId)!;
      res.json({
        id: existing.id,
        address: existing.address,
        createdAt: existing.createdAt,
      });
      return;
    }

    let address: string;

    if (coinbaseConfigured) {
      const wallet = await Wallet.create({ networkId: Coinbase.networks.BaseSepolia });
      address = (await wallet.getDefaultAddress()).getId();
      wallets.set(userId, { id: uuidv4(), wallet, address, createdAt: new Date() });
    } else {
      address = "0x" + uuidv4().replace(/-/g, "") + "000000000000000000000000";
      address = address.slice(0, 42);
      wallets.set(userId, {
        id: uuidv4(),
        wallet: null as unknown as Wallet,
        address,
        createdAt: new Date(),
      });
    }

    const w = wallets.get(userId)!;
    res.json({ id: w.id, address: w.address, createdAt: w.createdAt });
  } catch (err) {
    console.error("Error creating wallet:", err);
    res.status(500).json({ error: "Failed to create wallet" });
  }
});

app.get("/api/wallets/:userId", (req, res) => {
  const w = wallets.get(req.params.userId);
  if (!w) {
    res.status(404).json({ error: "Wallet not found" });
    return;
  }
  res.json({ id: w.id, address: w.address, createdAt: w.createdAt });
});

app.get("/api/wallets/:userId/balance", async (req, res) => {
  try {
    const w = wallets.get(req.params.userId);
    if (!w) {
      res.status(404).json({ error: "Wallet not found" });
      return;
    }

    if (coinbaseConfigured && w.wallet) {
      const balance = await w.wallet.getBalance(Coinbase.assets.Usdc);
      res.json({ symbol: "USDC", balance: balance.toString(), network: "Base" });
    } else {
      res.json({
        symbol: "USDC",
        balance: "100.00",
        network: "Base",
        demo: true,
      });
    }
  } catch (err) {
    console.error("Error fetching balance:", err);
    res.json({ symbol: "USDC", balance: "100.00", network: "Base", demo: true });
  }
});

app.post("/api/transfers", async (req, res) => {
  try {
    const { fromUserId, toAddress, amount } = req.body;

    if (!fromUserId || !toAddress || !amount) {
      res.status(400).json({ error: "fromUserId, toAddress, and amount are required" });
      return;
    }

    const w = wallets.get(fromUserId);
    if (!w) {
      res.status(404).json({ error: "Sender wallet not found" });
      return;
    }

    const txId = uuidv4();

    if (coinbaseConfigured && w.wallet) {
      const transfer = await w.wallet.createTransfer({
        amount,
        assetId: Coinbase.assets.Usdc,
        destination: toAddress,
        gasless: true,
      });

      const result = await transfer.wait();

      const tx: Transaction = {
        id: txId,
        fromAddress: w.address,
        toAddress,
        amount,
        status: result.getStatus() === "complete" ? "completed" : "failed",
        txHash: result.getTransactionHash() || "",
        createdAt: new Date(),
      };
      transactions.push(tx);
      res.json(tx);
    } else {
      const tx: Transaction = {
        id: txId,
        fromAddress: w.address,
        toAddress,
        amount,
        status: "completed",
        txHash: "0x" + uuidv4().replace(/-/g, ""),
        createdAt: new Date(),
      };
      transactions.push(tx);
      res.json({ ...tx, demo: true });
    }
  } catch (err) {
    console.error("Error creating transfer:", err);
    res.status(500).json({ error: "Failed to create transfer" });
  }
});

app.get("/api/transactions/:userId", (req, res) => {
  const w = wallets.get(req.params.userId);
  if (!w) {
    res.status(404).json({ error: "Wallet not found" });
    return;
  }

  const userTxs = transactions.filter(
    (tx) => tx.fromAddress === w.address || tx.toAddress === w.address
  );
  res.json(userTxs);
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`CDP SDK configured: ${coinbaseConfigured}`);
});
