import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import type { Transaction } from "@/types";
import { ArrowUpRight, ArrowDownLeft, Clock, CheckCircle2, XCircle } from "lucide-react";

interface TransactionHistoryProps {
  transactions: Transaction[];
  walletAddress: string;
}

function StatusIcon({ status }: { status: Transaction["status"] }) {
  switch (status) {
    case "completed":
      return <CheckCircle2 className="h-4 w-4 text-green-500" />;
    case "pending":
      return <Clock className="h-4 w-4 text-yellow-500" />;
    case "failed":
      return <XCircle className="h-4 w-4 text-red-500" />;
  }
}

export function TransactionHistory({ transactions, walletAddress }: TransactionHistoryProps) {
  if (transactions.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Transaction History</CardTitle>
          <CardDescription>Your past USDC transfers on Base</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <p className="text-lg mb-1">No transactions yet</p>
            <p className="text-sm">Send or receive USDC to see your history</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Transaction History</CardTitle>
        <CardDescription>{transactions.length} transaction{transactions.length !== 1 ? "s" : ""} on Base</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {transactions
            .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
            .map((tx) => {
              const isSent = tx.fromAddress.toLowerCase() === walletAddress.toLowerCase();
              return (
                <div
                  key={tx.id}
                  className="flex items-center justify-between p-3 rounded-lg border bg-white"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        isSent ? "bg-red-50" : "bg-green-50"
                      }`}
                    >
                      {isSent ? (
                        <ArrowUpRight className="h-5 w-5 text-red-500" />
                      ) : (
                        <ArrowDownLeft className="h-5 w-5 text-green-500" />
                      )}
                    </div>
                    <div>
                      <p className="text-sm font-medium">{isSent ? "Sent" : "Received"}</p>
                      <p className="text-xs text-muted-foreground font-mono">
                        {isSent
                          ? `to: ${tx.toAddress.slice(0, 6)}...${tx.toAddress.slice(-4)}`
                          : `from: ${tx.fromAddress.slice(0, 6)}...${tx.fromAddress.slice(-4)}`}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p
                      className={`text-sm font-semibold ${
                        isSent ? "text-red-600" : "text-green-600"
                      }`}
                    >
                      {isSent ? "-" : "+"}
                      {tx.amount} USDC
                    </p>
                    <div className="flex items-center gap-1 justify-end">
                      <StatusIcon status={tx.status} />
                      <span className="text-xs text-muted-foreground">
                        {new Date(tx.createdAt).toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
        </div>
      </CardContent>
    </Card>
  );
}
