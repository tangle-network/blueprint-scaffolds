import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { Send, Loader2 } from "lucide-react";

interface SendPaymentProps {
  walletAddress: string;
  onSend: (toAddress: string, amount: string) => Promise<void>;
  sending: boolean;
}

export function SendPayment({ walletAddress, onSend, sending }: SendPaymentProps) {
  const [toAddress, setToAddress] = useState("");
  const [amount, setAmount] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!toAddress.trim() || !amount.trim()) {
      toast({ title: "Validation Error", description: "Please fill in all fields", variant: "destructive" });
      return;
    }

    if (!/^0x[a-fA-F0-9]{40}$/.test(toAddress.trim())) {
      toast({ title: "Invalid Address", description: "Please enter a valid Ethereum address", variant: "destructive" });
      return;
    }

    if (toAddress.trim().toLowerCase() === walletAddress.toLowerCase()) {
      toast({ title: "Invalid Transfer", description: "Cannot send to your own address", variant: "destructive" });
      return;
    }

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      toast({ title: "Invalid Amount", description: "Please enter a valid positive amount", variant: "destructive" });
      return;
    }

    try {
      await onSend(toAddress.trim(), amount);
      toast({ title: "Transfer Sent!", description: `${amount} USDC sent successfully on Base` });
      setToAddress("");
      setAmount("");
    } catch (err) {
      toast({
        title: "Transfer Failed",
        description: err instanceof Error ? err.message : "Unknown error",
        variant: "destructive",
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Send className="h-5 w-5" />
          Send USDC
        </CardTitle>
        <CardDescription>Transfer USDC for free on Base network</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="toAddress">Recipient Address</Label>
            <Input
              id="toAddress"
              placeholder="0x..."
              value={toAddress}
              onChange={(e) => setToAddress(e.target.value)}
              className="font-mono text-sm"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="amount">Amount (USDC)</Label>
            <div className="relative">
              <Input
                id="amount"
                type="number"
                step="0.01"
                min="0"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                USDC
              </span>
            </div>
          </div>
          <div className="bg-blue-50 rounded-md p-3 text-sm text-blue-700">
            Gas fee: <strong>FREE</strong> on Base network
          </div>
          <Button type="submit" className="w-full" disabled={sending}>
            {sending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Sending...
              </>
            ) : (
              <>
                <Send className="mr-2 h-4 w-4" />
                Send USDC
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
