import { useState, useEffect, useCallback } from "react";
import type { WalletInfo, Balance, Transaction } from "@/types";
import { api } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { SendPayment } from "@/components/SendPayment";
import { ReceivePayment } from "@/components/ReceivePayment";
import { TransactionHistory } from "@/components/TransactionHistory";
import { RefreshCw, Wallet, Coins, ArrowUpDown } from "lucide-react";

interface DashboardProps {
  userId: string;
  wallet: WalletInfo;
  balance: Balance | null;
  onRefreshBalance: () => Promise<void>;
}

export function Dashboard({ userId, wallet, balance, onRefreshBalance }: DashboardProps) {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [sending, setSending] = useState(false);

  const refreshTransactions = useCallback(async () => {
    try {
      const txs = await api.getTransactions(userId);
      setTransactions(txs);
    } catch {
      /* ignore */
    }
  }, [userId]);

  useEffect(() => {
    refreshTransactions();
    const interval = setInterval(() => {
      onRefreshBalance();
      refreshTransactions();
    }, 15000);
    return () => clearInterval(interval);
  }, [userId, onRefreshBalance, refreshTransactions]);

  const handleSend = async (toAddress: string, amount: string) => {
    setSending(true);
    try {
      await api.createTransfer({ fromUserId: userId, toAddress, amount });
      await onRefreshBalance();
      await refreshTransactions();
    } finally {
      setSending(false);
    }
  };

  const shortened = `${wallet.address.slice(0, 6)}...${wallet.address.slice(-4)}`;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Balance</CardTitle>
            <Coins className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold">
                {balance ? parseFloat(balance.balance).toFixed(2) : "0.00"}
              </span>
              <span className="text-sm text-muted-foreground">USDC</span>
              {balance?.demo && (
                <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full">
                  Demo
                </span>
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-1">on {balance?.network || "Base"}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Wallet Address</CardTitle>
            <Wallet className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="text-sm font-mono font-medium">{shortened}</p>
            <p className="text-xs text-muted-foreground mt-1">
              Created {new Date(wallet.createdAt).toLocaleDateString()}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Transactions</CardTitle>
            <ArrowUpDown className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <span className="text-2xl font-bold">{transactions.length}</span>
            <p className="text-xs text-muted-foreground mt-1">Total transfers</p>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end">
        <button
          onClick={() => { onRefreshBalance(); refreshTransactions(); }}
          className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          Refresh
        </button>
      </div>

      <Tabs defaultValue="send" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="send">Send</TabsTrigger>
          <TabsTrigger value="receive">Receive</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>
        <TabsContent value="send">
          <SendPayment walletAddress={wallet.address} onSend={handleSend} sending={sending} />
        </TabsContent>
        <TabsContent value="receive">
          <ReceivePayment walletAddress={wallet.address} />
        </TabsContent>
        <TabsContent value="history">
          <TransactionHistory transactions={transactions} walletAddress={wallet.address} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
