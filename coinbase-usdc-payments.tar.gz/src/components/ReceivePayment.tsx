import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { QrCode, Copy, Check } from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import { useState } from "react";
import { toast } from "@/hooks/use-toast";

interface ReceivePaymentProps {
  walletAddress: string;
}

export function ReceivePayment({ walletAddress }: ReceivePaymentProps) {
  const [copied, setCopied] = useState(false);

  const copyAddress = async () => {
    try {
      await navigator.clipboard.writeText(walletAddress);
      setCopied(true);
      toast({ title: "Copied!", description: "Address copied to clipboard" });
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast({ title: "Copy Failed", description: "Could not copy address", variant: "destructive" });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <QrCode className="h-5 w-5" />
          Receive USDC
        </CardTitle>
        <CardDescription>Share your address or QR code to receive payments on Base</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex justify-center">
          <div className="bg-white p-4 rounded-lg border">
            <QRCodeSVG
              value={walletAddress}
              size={200}
              level="M"
              includeMargin
            />
          </div>
        </div>

        <div className="space-y-2">
          <p className="text-sm font-medium text-center">Your Wallet Address</p>
          <div className="flex items-center gap-2">
            <code className="flex-1 bg-muted px-3 py-2 rounded-md text-xs font-mono break-all">
              {walletAddress}
            </code>
            <Button variant="outline" size="icon" onClick={copyAddress}>
              {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
            </Button>
          </div>
        </div>

        <div className="bg-green-50 rounded-md p-3 text-sm text-green-700">
          <strong>Free transfers</strong> on Base network - sender pays zero gas fees
        </div>
      </CardContent>
    </Card>
  );
}
