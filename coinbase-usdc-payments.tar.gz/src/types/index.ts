export interface WalletInfo {
  id: string;
  address: string;
  createdAt: string;
}

export interface Balance {
  symbol: string;
  balance: string;
  network: string;
  demo?: boolean;
}

export interface Transaction {
  id: string;
  fromAddress: string;
  toAddress: string;
  amount: string;
  status: "pending" | "completed" | "failed";
  txHash: string;
  createdAt: string;
  demo?: boolean;
}

export interface TransferRequest {
  fromUserId: string;
  toAddress: string;
  amount: string;
}
