import { useState, useEffect } from "react";
import { api } from "@/lib/api";
import type { WalletInfo, Balance } from "@/types";
import { WalletSetup } from "@/components/WalletSetup";
import { Dashboard } from "@/components/Dashboard";
import { Toaster } from "@/components/Toaster";

const USER_KEY = "usdc-pay-userId";

function App() {
  const [userId, setUserId] = useState<string | null>(localStorage.getItem(USER_KEY));
  const [wallet, setWallet] = useState<WalletInfo | null>(null);
  const [balance, setBalance] = useState<Balance | null>(null);
  const [loading, setLoading] = useState(false);
  const [sdkReady, setSdkReady] = useState(false);

  useEffect(() => {
    api.getHealth().then((h) => setSdkReady(h.coinbaseConfigured)).catch(() => {});
  }, []);

  useEffect(() => {
    if (!userId) return;
    setLoading(true);
    api
      .createWallet(userId)
      .then((w) => {
        setWallet(w);
        return api.getBalance(userId);
      })
      .then((b) => setBalance(b))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [userId]);

  const refreshBalance = async () => {
    if (!userId) return;
    try {
      const b = await api.getBalance(userId);
      setBalance(b);
    } catch {
      /* ignore */
    }
  };

  const handleLogin = (id: string) => {
    localStorage.setItem(USER_KEY, id);
    setUserId(id);
  };

  const handleLogout = () => {
    localStorage.removeItem(USER_KEY);
    setUserId(null);
    setWallet(null);
    setBalance(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-4xl mx-auto flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center">
              <span className="text-white font-bold text-sm">$</span>
            </div>
            <h1 className="text-lg font-bold text-gray-900">USDC Pay</h1>
            {sdkReady && (
              <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">
                CDP Connected
              </span>
            )}
          </div>
          {userId && (
            <button
              onClick={handleLogout}
              className="text-sm text-gray-500 hover:text-gray-700"
            >
              Logout
            </button>
          )}
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
          </div>
        ) : userId && wallet ? (
          <Dashboard
            userId={userId}
            wallet={wallet}
            balance={balance}
            onRefreshBalance={refreshBalance}
          />
        ) : (
          <WalletSetup onLogin={handleLogin} />
        )}
      </main>
      <Toaster />
    </div>
  );
}

export default App;
