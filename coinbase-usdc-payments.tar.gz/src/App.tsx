import { Routes, Route, Link, useLocation, Navigate } from "react-router-dom";
import { Toaster } from "@/components/Toaster";
import DashboardPage from "@/pages/DashboardPage";
import SendPage from "@/pages/SendPage";
import MerchantsPage from "@/pages/MerchantsPage";
import ContactsPage from "@/pages/ContactsPage";
import { Home, Send, Store, Users } from "lucide-react";

const NAV_ITEMS = [
  { to: "/", label: "Dashboard", icon: Home },
  { to: "/send", label: "Send", icon: Send },
  { to: "/merchants", label: "Merchants", icon: Store },
  { to: "/contacts", label: "Contacts", icon: Users },
];

function NavItem({ to, label, icon: Icon }: (typeof NAV_ITEMS)[number]) {
  const { pathname } = useLocation();
  const active = pathname === to || (to !== "/" && pathname.startsWith(to));
  return (
    <Link
      to={to}
      className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
        active
          ? "bg-primary text-primary-foreground"
          : "text-muted-foreground hover:text-foreground hover:bg-muted"
      }`}
    >
      <Icon className="h-4 w-4" />
      <span className="hidden sm:inline">{label}</span>
    </Link>
  );
}

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-6xl mx-auto flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-4">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center">
                <span className="text-white font-bold text-sm">$</span>
              </div>
              <h1 className="text-lg font-bold text-gray-900">USDC Pay</h1>
            </Link>
            <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">
              Base Network
            </span>
          </div>
          <nav className="flex items-center gap-1">
            {NAV_ITEMS.map((item) => (
              <NavItem key={item.to} {...item} />
            ))}
          </nav>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        <Routes>
          <Route path="/" element={<DashboardPage />} />
          <Route path="/send" element={<SendPage />} />
          <Route path="/merchants" element={<MerchantsPage />} />
          <Route path="/contacts" element={<ContactsPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>

      <Toaster />
    </div>
  );
}

export default App;
