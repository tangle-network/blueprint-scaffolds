import { useState, useEffect, useCallback } from "react";
import type { Wallet, Balance, Transaction, User } from "@/lib/types";
import { api } from "@/lib/api";

export function useWallet(userId: string | null) {
  const [wallet, setWallet] = useState<Wallet | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchWallet = useCallback(async () => {
    if (!userId) { setLoading(false); return; }
    try {
      const res = await api.getWallet(userId);
      setWallet(res.data);
    } catch {
      setWallet(null);
    } finally {
      setLoading(false);
    }
  }, [userId]);

  useEffect(() => { fetchWallet(); }, [fetchWallet]);

  const createWallet = useCallback(async () => {
    if (!userId) return;
    setLoading(true);
    try {
      const res = await api.createWallet(userId);
      setWallet(res.data);
    } finally {
      setLoading(false);
    }
  }, [userId]);

  return { wallet, loading, createWallet, refetch: fetchWallet };
}

export function useBalance(userId: string | null) {
  const [balance, setBalance] = useState<Balance | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchBalance = useCallback(async () => {
    if (!userId) { setLoading(false); return; }
    try {
      const res = await api.getBalance(userId);
      setBalance(res.data);
    } catch {
      setBalance(null);
    } finally {
      setLoading(false);
    }
  }, [userId]);

  useEffect(() => { fetchBalance(); }, [fetchBalance]);

  return { balance, loading, refetch: fetchBalance };
}

export function useTransactions(userId: string | null) {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchTransactions = useCallback(async () => {
    if (!userId) { setLoading(false); return; }
    try {
      const res = await api.getTransactions(userId);
      setTransactions(res.data);
    } catch {
      setTransactions([]);
    } finally {
      setLoading(false);
    }
  }, [userId]);

  useEffect(() => { fetchTransactions(); }, [fetchTransactions]);

  return { transactions, loading, refetch: fetchTransactions };
}

export function useCurrentUser() {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem("usdc_user");
    if (stored) {
      try { setUser(JSON.parse(stored)); } catch { /* ignore */ }
    }
  }, []);

  const login = useCallback(async (email: string, displayName: string) => {
    const res = await api.createUser(email, displayName);
    const u = res.data;
    localStorage.setItem("usdc_user", JSON.stringify(u));
    setUser(u);
    return u;
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem("usdc_user");
    setUser(null);
  }, []);

  return { user, login, logout };
}
