export interface Wallet {
  id: string;
  user_id: string;
  address: string;
  network: string;
  created_at: string;
}

export interface Balance {
  symbol: string;
  amount: string;
  decimals: number;
}

export interface Transaction {
  id: string;
  from_user_id: string;
  to_user_id: string;
  from_address: string;
  to_address: string;
  amount: string;
  status: "pending" | "confirmed" | "failed";
  tx_hash: string | null;
  created_at: string;
}

export interface User {
  id: string;
  email: string;
  display_name: string;
  wallet_id: string;
}

export interface ApiResponse<T> {
  data: T;
  error?: string;
}

export const USDC_CONTRACTS: Record<string, string> = {
  "base-mainnet": "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913",
  "base-sepolia": "0x036CbD53842c5426634e7929541eC2318f3dCF7e",
};

export const USDC_DECIMALS = 6;
export const BASE_NETWORK = "base-sepolia";
