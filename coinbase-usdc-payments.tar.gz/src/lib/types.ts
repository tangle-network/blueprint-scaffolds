export interface WalletInfo {
  id: string;
  address: string;
  createdAt: string;
}

export interface Balance {
  symbol: string;
  balance: string;
  network: string;
  demo?: boolean;
}

export type TransactionStatus = "pending" | "completed" | "failed";

export interface Transaction {
  id: string;
  fromAddress: string;
  toAddress: string;
  amount: string;
  status: TransactionStatus;
  txHash: string;
  createdAt: string;
  demo?: boolean;
}

export interface TransferRequest {
  fromUserId: string;
  toAddress: string;
  amount: string;
}

export interface UserProfile {
  id: string;
  username: string;
  avatar: string;
  wallet: WalletInfo;
  balance: Balance;
  joinedAt: string;
  totalSent: string;
  totalReceived: string;
  transactionCount: number;
}

export interface Contact {
  id: string;
  name: string;
  address: string;
  lastSentAt: string;
  totalSent: string;
}

export interface MerchantInfo {
  id: string;
  name: string;
  description: string;
  address: string;
  logo: string;
  category: string;
  acceptedPayments: string[];
  verified: boolean;
  totalVolume: string;
  createdAt: string;
}

export interface Invoice {
  id: string;
  merchantId: string;
  merchantName: string;
  amount: string;
  description: string;
  status: "draft" | "pending" | "paid" | "expired" | "cancelled";
  dueDate: string;
  createdAt: string;
  paidAt?: string;
}

export interface PriceData {
  symbol: string;
  price: string;
  change24h: string;
  changePercent24h: string;
  volume24h: string;
  marketCap: string;
  lastUpdated: string;
}

export interface NetworkInfo {
  name: string;
 chainId: number;
  blockExplorer: string;
  nativeToken: string;
  avgBlockTime: string;
  tps: number;
  gasToken: string;
}

export interface ActivityItem {
  id: string;
  type: "payment_sent" | "payment_received" | "invoice_created" | "invoice_paid" | "merchant_payment";
  description: string;
  amount: string;
  timestamp: string;
  counterparty: string;
  status: TransactionStatus;
}
