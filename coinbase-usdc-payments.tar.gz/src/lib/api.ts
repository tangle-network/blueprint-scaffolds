import type { Wallet, Balance, Transaction, User, ApiResponse } from "./types";

const BASE = "/api";

async function request<T>(path: string, opts?: RequestInit): Promise<ApiResponse<T>> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...opts,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || err.message || "Request failed");
  }
  return res.json();
}

export const api = {
  createUser: (email: string, displayName: string) =>
    request<User>("/users", {
      method: "POST",
      body: JSON.stringify({ email, displayName }),
    }),

  getUser: (userId: string) => request<User>(`/users/${userId}`),

  createWallet: (userId: string) =>
    request<Wallet>(`/users/${userId}/wallet`, { method: "POST" }),

  getWallet: (userId: string) => request<Wallet>(`/users/${userId}/wallet`),

  getBalance: (userId: string) => request<Balance>(`/users/${userId}/balance`),

  sendPayment: (fromUserId: string, toAddress: string, amount: string) =>
    request<Transaction>("/payments/send", {
      method: "POST",
      body: JSON.stringify({ fromUserId, toAddress, amount }),
    }),

  getTransactions: (userId: string) =>
    request<Transaction[]>(`/users/${userId}/transactions`),

  lookupUser: (address: string) =>
    request<User>(`/users/lookup?address=${encodeURIComponent(address)}`),
};
