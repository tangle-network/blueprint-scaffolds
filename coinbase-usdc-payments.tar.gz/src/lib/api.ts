import type { WalletInfo, Balance, Transaction, TransferRequest } from "@/types";

const API_BASE = "/api";

async function fetchJSON<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${url}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || "Request failed");
  }
  return res.json();
}

export const api = {
  getHealth: () => fetchJSON<{ status: string; coinbaseConfigured: boolean }>("/health"),

  createWallet: (userId: string) =>
    fetchJSON<WalletInfo>("/wallets", {
      method: "POST",
      body: JSON.stringify({ userId }),
    }),

  getWallet: (userId: string) => fetchJSON<WalletInfo>(`/wallets/${userId}`),

  getBalance: (userId: string) =>
    fetchJSON<Balance>(`/wallets/${userId}/balance`),

  createTransfer: (data: TransferRequest) =>
    fetchJSON<Transaction>("/transfers", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  getTransactions: (userId: string) =>
    fetchJSON<Transaction[]>(`/transactions/${userId}`),
};
