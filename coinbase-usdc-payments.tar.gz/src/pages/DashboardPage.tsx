import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  defaultWallet,
  defaultBalance,
  defaultActivity,
} from "@/lib/default-data";
import type { ActivityItem } from "@/lib/types";
import {
  ArrowUpRight,
  ArrowDownLeft,
  Wallet,
  Coins,
  Activity,
  TrendingUp,
  Send,
  RefreshCw,
  CheckCircle2,
  Clock,
  XCircle,
  ShoppingBag,
  FileText,
} from "lucide-react";
import { Link } from "react-router-dom";

function ActivityIcon({ type }: { type: ActivityItem["type"] }) {
  switch (type) {
    case "payment_sent":
      return <ArrowUpRight className="h-4 w-4 text-red-500" />;
    case "payment_received":
      return <ArrowDownLeft className="h-4 w-4 text-green-500" />;
    case "merchant_payment":
      return <ShoppingBag className="h-4 w-4 text-blue-500" />;
    case "invoice_paid":
      return <FileText className="h-4 w-4 text-purple-500" />;
    case "invoice_created":
      return <FileText className="h-4 w-4 text-orange-500" />;
  }
}

function StatusBadge({ status }: { status: ActivityItem["status"] }) {
  const colors = {
    completed: "text-green-600 bg-green-50",
    pending: "text-yellow-600 bg-yellow-50",
    failed: "text-red-600 bg-red-50",
  };
  const icons = {
    completed: <CheckCircle2 className="h-3 w-3" />,
    pending: <Clock className="h-3 w-3" />,
    failed: <XCircle className="h-3 w-3" />,
  };
  return (
    <span
      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${colors[status]}`}
    >
      {icons[status]}
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
}

export default function DashboardPage() {
  const wallet = defaultWallet;
  const balance = defaultBalance;
  const activities = defaultActivity;

  const shortened = `${wallet.address.slice(0, 6)}...${wallet.address.slice(-4)}`;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Balance</CardTitle>
            <Coins className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold">{balance.balance}</span>
              <span className="text-sm text-muted-foreground">USDC</span>
              {balance.demo && (
                <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full">
                  Demo
                </span>
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              on {balance.network} network
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Wallet</CardTitle>
            <Wallet className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="text-sm font-mono font-medium">{shortened}</p>
            <p className="text-xs text-muted-foreground mt-1">
              Created {new Date(wallet.createdAt).toLocaleDateString()}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">24h Change</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <span className="text-2xl font-bold text-green-600">+$824.50</span>
            <p className="text-xs text-muted-foreground mt-1">+50.5% received</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Transactions</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <span className="text-2xl font-bold">{activities.length}</span>
            <p className="text-xs text-muted-foreground mt-1">Last 7 days</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Link to="/send">
              <Button className="w-full justify-start gap-2" variant="outline">
                <Send className="h-4 w-4" />
                Send Payment
              </Button>
            </Link>
            <Link to="/merchants">
              <Button className="w-full justify-start gap-2" variant="outline">
                <ShoppingBag className="h-4 w-4" />
                Browse Merchants
              </Button>
            </Link>
            <Button
              className="w-full justify-start gap-2"
              variant="outline"
              disabled
            >
              <RefreshCw className="h-4 w-4" />
              Refresh Balance
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {activities.slice(0, 4).map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between py-2"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                      <ActivityIcon type={item.type} />
                    </div>
                    <div>
                      <p className="text-sm font-medium">{item.description}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(item.timestamp).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p
                      className={`text-sm font-semibold ${
                        item.amount.startsWith("+")
                          ? "text-green-600"
                          : "text-red-600"
                      }`}
                    >
                      {item.amount} USDC
                    </p>
                    <StatusBadge status={item.status} />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">All Transactions</CardTitle>
            <Link
              to="/send"
              className="text-sm text-primary hover:underline"
            >
              View all
            </Link>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {activities.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between p-3 rounded-lg border bg-white"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      item.amount.startsWith("+")
                        ? "bg-green-50"
                        : "bg-red-50"
                    }`}
                  >
                    <ActivityIcon type={item.type} />
                  </div>
                  <div>
                    <p className="text-sm font-medium">{item.description}</p>
                    <p className="text-xs text-muted-foreground">
                      {item.counterparty}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p
                    className={`text-sm font-semibold ${
                      item.amount.startsWith("+")
                        ? "text-green-600"
                        : "text-red-600"
                    }`}
                  >
                    {item.amount} USDC
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(item.timestamp).toLocaleDateString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
