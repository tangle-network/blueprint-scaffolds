import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { defaultContacts, defaultWallet, defaultTransactions } from "@/lib/default-data";
import type { Contact } from "@/lib/types";
import { toast } from "@/hooks/use-toast";
import {
  Users,
  Search,
  Plus,
  Copy,
  Check,
  Send,
  ArrowUpRight,
  ArrowDownLeft,
  Wallet,
} from "lucide-react";
import { Link } from "react-router-dom";

function ContactDetailDialog({ contact }: { contact: (typeof defaultContacts)[number] }) {
  const [copied, setCopied] = useState(false);

  const relatedTxns = defaultTransactions.filter(
    (tx) =>
      tx.fromAddress.toLowerCase() === contact.address.toLowerCase() ||
      tx.toAddress.toLowerCase() === contact.address.toLowerCase()
  );

  const copyAddress = async () => {
    try {
      await navigator.clipboard.writeText(contact.address);
      setCopied(true);
      toast({ title: "Copied!", description: "Address copied to clipboard" });
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast({ title: "Copy Failed", variant: "destructive" });
    }
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <button className="w-full flex items-center justify-between p-4 rounded-lg border bg-white hover:bg-muted/50 transition-colors text-left">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-full bg-primary/10 flex items-center justify-center">
              <span className="text-primary font-bold">{contact.name.charAt(0)}</span>
            </div>
            <div>
              <p className="text-sm font-semibold">{contact.name}</p>
              <p className="text-xs text-muted-foreground font-mono">
                {contact.address.slice(0, 8)}...{contact.address.slice(-6)}
              </p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs text-muted-foreground">Total sent</p>
            <p className="text-sm font-bold">{contact.totalSent} USDC</p>
          </div>
        </button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
              <span className="text-primary font-bold text-lg">{contact.name.charAt(0)}</span>
            </div>
            <div>
              <p>{contact.name}</p>
              <p className="text-xs font-normal text-muted-foreground font-mono">
                {contact.address.slice(0, 10)}...{contact.address.slice(-6)}
              </p>
            </div>
          </DialogTitle>
          <DialogDescription>Contact details and transaction history</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 pt-2">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-xs text-muted-foreground">Total Sent</p>
              <p className="text-sm font-semibold">{contact.totalSent} USDC</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Last Sent</p>
              <p className="text-sm font-semibold">
                {new Date(contact.lastSentAt).toLocaleDateString()}
              </p>
            </div>
          </div>

          <div>
            <p className="text-xs text-muted-foreground mb-1">Address</p>
            <div className="flex items-center gap-2">
              <code className="flex-1 bg-muted px-3 py-2 rounded-md text-xs font-mono break-all">
                {contact.address}
              </code>
              <Button variant="outline" size="icon" onClick={copyAddress}>
                {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          <div>
            <p className="text-xs text-muted-foreground mb-2">
              Related Transactions ({relatedTxns.length})
            </p>
            {relatedTxns.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">No transactions yet</p>
            ) : (
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {relatedTxns.map((tx) => {
                  const isSent = tx.fromAddress === defaultWallet.address;
                  return (
                    <div key={tx.id} className="flex items-center justify-between p-2 rounded-md bg-muted/50">
                      <div className="flex items-center gap-2">
                        {isSent ? (
                          <ArrowUpRight className="h-4 w-4 text-red-500" />
                        ) : (
                          <ArrowDownLeft className="h-4 w-4 text-green-500" />
                        )}
                        <span className="text-xs">{isSent ? "Sent" : "Received"}</span>
                      </div>
                      <div className="text-right">
                        <p className={`text-xs font-semibold ${isSent ? "text-red-600" : "text-green-600"}`}>
                          {isSent ? "-" : "+"}{tx.amount} USDC
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(tx.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <Link to="/send">
            <Button className="w-full gap-2">
              <Send className="h-4 w-4" />
              Send USDC to {contact.name}
            </Button>
          </Link>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function ContactsPage() {
  const [search, setSearch] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [newName, setNewName] = useState("");
  const [newAddress, setNewAddress] = useState("");

  const filtered = defaultContacts.filter(
    (c) =>
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.address.toLowerCase().includes(search.toLowerCase())
  );

  const handleAddContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newAddress.trim()) {
      toast({ title: "Error", description: "Please fill in all fields", variant: "destructive" });
      return;
    }
    toast({ title: "Contact Added", description: `${newName} has been added to your contacts` });
    setNewName("");
    setNewAddress("");
    setShowAdd(false);
  };

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Users className="h-6 w-6" />
            Contacts
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            Manage your frequent contacts for quick payments
          </p>
        </div>
        <Button onClick={() => setShowAdd(!showAdd)} variant="outline" className="gap-2">
          <Plus className="h-4 w-4" />
          Add Contact
        </Button>
      </div>

      {showAdd && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Add New Contact</CardTitle>
            <CardDescription>Save an address for quick future payments</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAddContact} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="newName">Name</Label>
                <Input
                  id="newName"
                  placeholder="Contact name"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="newAddress">Wallet Address</Label>
                <Input
                  id="newAddress"
                  placeholder="0x..."
                  value={newAddress}
                  onChange={(e) => setNewAddress(e.target.value)}
                  className="font-mono text-sm"
                />
              </div>
              <div className="flex gap-2">
                <Button type="submit">Save Contact</Button>
                <Button type="button" variant="outline" onClick={() => setShowAdd(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search contacts by name or address..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Contacts</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <span className="text-2xl font-bold">{defaultContacts.length}</span>
            <p className="text-xs text-muted-foreground mt-1">Saved addresses</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Volume</CardTitle>
            <Wallet className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <span className="text-2xl font-bold">
              {defaultContacts.reduce((sum, c) => sum + parseFloat(c.totalSent.replace(",", "")), 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}
            </span>
            <p className="text-xs text-muted-foreground mt-1">USDC sent to contacts</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Your Contacts</CardTitle>
          <CardDescription>
            {filtered.length} contact{filtered.length !== 1 ? "s" : ""} found
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filtered.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <p className="text-lg mb-1">No contacts found</p>
              <p className="text-sm">Add a contact or adjust your search</p>
            </div>
          ) : (
            <div className="space-y-2">
              {filtered.map((contact) => (
                <ContactDetailDialog key={contact.id} contact={contact} />
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
