import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  defaultMerchants,
  defaultInvoices,
} from "@/lib/default-data";
import {
  Store,
  ShieldCheck,
  ExternalLink,
  FileText,
  Clock,
  CheckCircle2,
  AlertCircle,
  DollarSign,
} from "lucide-react";
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import type { Invoice } from "@/lib/types";

function InvoiceStatusBadge({ status }: { status: Invoice["status"] }) {
  const config = {
    paid: {
      icon: <CheckCircle2 className="h-3 w-3" />,
      color: "text-green-600 bg-green-50",
      label: "Paid",
    },
    pending: {
      icon: <Clock className="h-3 w-3" />,
      color: "text-yellow-600 bg-yellow-50",
      label: "Pending",
    },
    draft: {
      icon: <FileText className="h-3 w-3" />,
      color: "text-gray-600 bg-gray-50",
      label: "Draft",
    },
    expired: {
      icon: <AlertCircle className="h-3 w-3" />,
      color: "text-red-600 bg-red-50",
      label: "Expired",
    },
    cancelled: {
      icon: <AlertCircle className="h-3 w-3" />,
      color: "text-red-600 bg-red-50",
      label: "Cancelled",
    },
  };
  const c = config[status];
  return (
    <span
      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${c.color}`}
    >
      {c.icon}
      {c.label}
    </span>
  );
}

function MerchantCard({ merchant }: { merchant: (typeof defaultMerchants)[number] }) {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Card className="hover:shadow-md transition-shadow cursor-pointer">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                <span className="text-primary font-bold text-lg">
                  {merchant.logo}
                </span>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-sm">{merchant.name}</h3>
                  {merchant.verified && (
                    <ShieldCheck className="h-4 w-4 text-blue-500 flex-shrink-0" />
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
                  {merchant.description}
                </p>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-xs bg-muted px-2 py-0.5 rounded-full">
                    {merchant.category}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    Vol: ${merchant.totalVolume}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <span className="text-primary font-bold">{merchant.logo}</span>
            </div>
            {merchant.name}
            {merchant.verified && (
              <ShieldCheck className="h-5 w-5 text-blue-500" />
            )}
          </DialogTitle>
          <DialogDescription>{merchant.description}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 pt-2">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-xs text-muted-foreground">Category</p>
              <p className="text-sm font-medium">{merchant.category}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Total Volume</p>
              <p className="text-sm font-medium">${merchant.totalVolume}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Accepted</p>
              <div className="flex gap-1 mt-1">
                {merchant.acceptedPayments.map((p) => (
                  <span
                    key={p}
                    className="text-xs bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full"
                  >
                    {p}
                  </span>
                ))}
              </div>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Address</p>
              <p className="text-xs font-mono">
                {merchant.address.slice(0, 10)}...{merchant.address.slice(-6)}
              </p>
            </div>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Member since</p>
            <p className="text-sm font-medium">
              {new Date(merchant.createdAt).toLocaleDateString()}
            </p>
          </div>
          <Button className="w-full gap-2">
            <DollarSign className="h-4 w-4" />
            Pay with USDC
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function MerchantsPage() {
  const [tab, setTab] = useState<"merchants" | "invoices">("merchants");

  const paidInvoices = defaultInvoices.filter((i) => i.status === "paid");
  const pendingInvoices = defaultInvoices.filter((i) => i.status === "pending");

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Store className="h-6 w-6" />
            Merchants & Invoices
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            Browse verified merchants and manage your invoices
          </p>
        </div>
      </div>

      <div className="flex gap-2">
        <Button
          variant={tab === "merchants" ? "default" : "outline"}
          onClick={() => setTab("merchants")}
        >
          <Store className="h-4 w-4 mr-2" />
          Merchants
        </Button>
        <Button
          variant={tab === "invoices" ? "default" : "outline"}
          onClick={() => setTab("invoices")}
        >
          <FileText className="h-4 w-4 mr-2" />
          Invoices ({defaultInvoices.length})
        </Button>
      </div>

      {tab === "merchants" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Merchants
                </CardTitle>
                <Store className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <span className="text-2xl font-bold">
                  {defaultMerchants.length}
                </span>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Verified</CardTitle>
                <ShieldCheck className="h-4 w-4 text-green-500" />
              </CardHeader>
              <CardContent>
                <span className="text-2xl font-bold">
                  {defaultMerchants.filter((m) => m.verified).length}
                </span>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Categories</CardTitle>
                <ExternalLink className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <span className="text-2xl font-bold">
                  {new Set(defaultMerchants.map((m) => m.category)).size}
                </span>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {defaultMerchants.map((merchant) => (
              <MerchantCard key={merchant.id} merchant={merchant} />
            ))}
          </div>
        </div>
      )}

      {tab === "invoices" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Invoices
                </CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <span className="text-2xl font-bold">
                  {defaultInvoices.length}
                </span>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Pending</CardTitle>
                <Clock className="h-4 w-4 text-yellow-500" />
              </CardHeader>
              <CardContent>
                <span className="text-2xl font-bold">
                  {pendingInvoices.length}
                </span>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Paid</CardTitle>
                <CheckCircle2 className="h-4 w-4 text-green-500" />
              </CardHeader>
              <CardContent>
                <span className="text-2xl font-bold">
                  {paidInvoices.length}
                </span>
              </CardContent>
            </Card>
          </div>

          {pendingInvoices.length > 0 && (
            <div>
              <h3 className="text-sm font-semibold text-muted-foreground mb-3">
                PENDING ({pendingInvoices.length})
              </h3>
              <div className="space-y-3">
                {pendingInvoices.map((invoice) => (
                  <Card key={invoice.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-yellow-50 flex items-center justify-center">
                            <FileText className="h-5 w-5 text-yellow-600" />
                          </div>
                          <div>
                            <p className="text-sm font-medium">
                              {invoice.description}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {invoice.merchantName} | Due:{" "}
                              {new Date(invoice.dueDate).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="text-right flex items-center gap-3">
                          <div>
                            <p className="text-sm font-bold">
                              {invoice.amount} USDC
                            </p>
                            <InvoiceStatusBadge status={invoice.status} />
                          </div>
                          <Button size="sm">Pay</Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {paidInvoices.length > 0 && (
            <div>
              <h3 className="text-sm font-semibold text-muted-foreground mb-3">
                PAID ({paidInvoices.length})
              </h3>
              <div className="space-y-3">
                {paidInvoices.map((invoice) => (
                  <Card key={invoice.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-green-50 flex items-center justify-center">
                            <CheckCircle2 className="h-5 w-5 text-green-600" />
                          </div>
                          <div>
                            <p className="text-sm font-medium">
                              {invoice.description}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {invoice.merchantName} |{" "}
                              {invoice.id} | Paid:{" "}
                              {invoice.paidAt
                                ? new Date(invoice.paidAt).toLocaleDateString()
                                : "N/A"}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-bold text-green-600">
                            {invoice.amount} USDC
                          </p>
                          <InvoiceStatusBadge status={invoice.status} />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
