import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { Send, Loader2, Users } from "lucide-react";
import { defaultWallet, defaultContacts } from "@/lib/default-data";
import { Link } from "react-router-dom";

export default function SendPage() {
  const [toAddress, setToAddress] = useState("");
  const [amount, setAmount] = useState("");
  const [sending, setSending] = useState(false);

  const wallet = defaultWallet;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!toAddress.trim() || !amount.trim()) {
      toast({
        title: "Validation Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    if (!/^0x[a-fA-F0-9]{40}$/.test(toAddress.trim())) {
      toast({
        title: "Invalid Address",
        description: "Please enter a valid Ethereum address",
        variant: "destructive",
      });
      return;
    }

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid positive amount",
        variant: "destructive",
      });
      return;
    }

    setSending(true);
    await new Promise((resolve) => setTimeout(resolve, 1500));
    setSending(false);

    toast({
      title: "Transfer Sent!",
      description: `${amount} USDC sent successfully on Base`,
    });
    setToAddress("");
    setAmount("");
  };

  const fillContact = (address: string) => {
    setToAddress(address);
  };

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Send className="h-5 w-5" />
            Send USDC
          </CardTitle>
          <CardDescription>
            Transfer USDC for free on Base network
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="toAddress">Recipient Address</Label>
              <Input
                id="toAddress"
                placeholder="0x..."
                value={toAddress}
                onChange={(e) => setToAddress(e.target.value)}
                className="font-mono text-sm"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="amount">Amount (USDC)</Label>
              <div className="relative">
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                  USDC
                </span>
              </div>
            </div>
            <div className="bg-blue-50 rounded-md p-3 text-sm text-blue-700">
              Network: <strong>Base</strong> | Gas fee: <strong>FREE</strong> |
              Estimated time: <strong>~2 seconds</strong>
            </div>
            <Button type="submit" className="w-full" disabled={sending}>
              {sending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <Send className="mr-2 h-4 w-4" />
                  Send USDC
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2 text-base">
                <Users className="h-4 w-4" />
                Recent Contacts
              </CardTitle>
              <CardDescription>
                Quick send to your frequent contacts
              </CardDescription>
            </div>
            <Link
              to="/contacts"
              className="text-sm text-primary hover:underline"
            >
              View all
            </Link>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {defaultContacts.map((contact) => (
              <button
                key={contact.id}
                onClick={() => fillContact(contact.address)}
                className="w-full flex items-center justify-between p-3 rounded-lg border bg-white hover:bg-muted/50 transition-colors text-left"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-primary font-semibold text-sm">
                      {contact.name.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-medium">{contact.name}</p>
                    <p className="text-xs text-muted-foreground font-mono">
                      {contact.address.slice(0, 6)}...
                      {contact.address.slice(-4)}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs text-muted-foreground">Total sent</p>
                  <p className="text-sm font-semibold">
                    {contact.totalSent} USDC
                  </p>
                </div>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
