import { useAuth } from "./useAuth";
import { Link, useNavigate } from "react-router-dom";

export function Layout({ children }: { children: React.ReactNode }) {
  const { username, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  return (
    <div className="min-h-screen">
      <nav className="bg-[#1a1b1f] border-b border-gray-800">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <Link to="/dashboard" className="text-lg font-bold text-blue-400">
              USDC Pay
            </Link>
            <div className="flex gap-4">
              <Link
                to="/dashboard"
                className="text-gray-400 hover:text-white text-sm"
              >
                Dashboard
              </Link>
              <Link
                to="/send"
                className="text-gray-400 hover:text-white text-sm"
              >
                Send
              </Link>
              <Link
                to="/receive"
                className="text-gray-400 hover:text-white text-sm"
              >
                Receive
              </Link>
              <Link
                to="/history"
                className="text-gray-400 hover:text-white text-sm"
              >
                History
              </Link>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-400">{username}</span>
            <button
              onClick={handleLogout}
              className="text-sm text-gray-500 hover:text-white"
            >
              Logout
            </button>
          </div>
        </div>
      </nav>
      <main className="max-w-4xl mx-auto px-4 py-8">{children}</main>
    </div>
  );
}
