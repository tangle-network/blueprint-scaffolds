import { Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./hooks/useAuth";
import { Dashboard } from "./pages/Dashboard";
import { SendPayment } from "./pages/SendPayment";
import { TransactionHistory } from "./pages/TransactionHistory";
import { ReceivePayment } from "./pages/ReceivePayment";
import { Layout } from "./components/Layout";

function ProtectedRoutes() {
  const { username } = useAuth();
  if (!username) return <Navigate to="/" replace />;
  return (
    <Layout>
      <Routes>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/send" element={<SendPayment />} />
        <Route path="/receive" element={<ReceivePayment />} />
        <Route path="/history" element={<TransactionHistory />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Layout>
  );
}

function Login() {
  const { login } = useAuth();

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const username = formData.get("username") as string;
    if (username) login(username);
  };

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="bg-[#1a1b1f] p-8 rounded-2xl w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">USDC Payments</h1>
          <p className="text-gray-400">Free transfers on Base</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm text-gray-400 mb-1">Username</label>
            <input
              name="username"
              type="text"
              required
              className="w-full bg-[#0a0b0d] border border-gray-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-blue-500"
              placeholder="Enter your username"
            />
          </div>
          <button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-medium transition-colors"
          >
            Sign In
          </button>
        </form>
        <p className="text-center text-gray-500 text-sm mt-6">
          Powered by Coinbase CDP &middot; Base Network
        </p>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/*" element={<ProtectedRoutes />} />
      </Routes>
    </AuthProvider>
  );
}
