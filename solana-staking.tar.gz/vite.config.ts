import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173
  },
  build: {
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes('node_modules')) {
            if (id.includes('recharts')) {
              return 'charts';
            }

            if (
              id.includes('@solana') ||
              id.includes('@coral-xyz') ||
              id.includes('rpc-websockets')
            ) {
              return 'solana';
            }

            if (id.includes('react')) {
              return 'react-vendor';
            }
          }
        }
      }
    }
  }
});
