# Solana Staking Platform

## Build Plan

### Smart Contract (Anchor)
- `programs/staking/src/lib.rs` — Anchor program with:
  - Pool initialization (single-token, LP, NFT)
  - Stake/unstake with tiered locks & boost multipliers
  - Per-second reward distribution
  - Multiple reward tokens
  - Auto-compound
  - veToken model
  - Governance integration
  - Referral rewards

### Frontend (Vite + React + TypeScript)

#### Pages
| Route | Page | Description |
|-------|------|-------------|
| `/` | Dashboard | Overview of all pools, TVL, user positions |
| `/pools` | PoolDiscovery | Browse & filter all staking pools |
| `/pools/:id` | PoolDetail | Individual pool staking interface |
| `/stake` | StakingInterface | Stake/unstake tokens with tier selection |
| `/rewards` | RewardsDashboard | Claim rewards, view history |
| `/calculator` | APYCalculator | Calculate projected APY & earnings |
| `/governance` | Governance | veToken governance, proposals, voting |
| `/referral` | ReferralProgram | Referral links, stats, rewards |
| `/nft-stake` | NFTStaking | Stake NFTs for boosted rewards |

#### UI Components (shadcn/ui)
- Button, Card, Dialog, Input, Label, Progress, Select, Separator, Switch, Tabs, Tooltip, Badge, DropdownMenu, AlertDialog

#### Layout
- Header (wallet connect, nav)
- Sidebar (navigation links)
- Footer

#### Hooks
- `useWallet` — Solana wallet adapter wrapper
- `usePools` — Fetch pool data
- `useStaking` — Stake/unstake/claim operations
- `useRewards` — Reward calculations & claims
- `useGovernance` — veToken & governance

#### Build
```bash
npm run build
```
