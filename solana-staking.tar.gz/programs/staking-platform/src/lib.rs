use anchor_lang::prelude::*;

declare_id!("StaK1ng111111111111111111111111111111111111");

#[program]
pub mod staking_platform {
    use super::*;

    pub fn initialize_pool(
        ctx: Context<InitializePool>,
        bump: u8,
        config: PoolConfigArgs,
    ) -> Result<()> {
        let pool = &mut ctx.accounts.pool;
        pool.authority = ctx.accounts.authority.key();
        pool.asset_mint = config.asset_mint;
        pool.pool_kind = config.pool_kind;
        pool.reward_mints = config.reward_mints;
        pool.referral_bps = config.referral_bps;
        pool.base_emission_rate = config.base_emission_rate;
        pool.bump = bump;
        pool.lock_tiers = config.lock_tiers;
        pool.governance_realm = config.governance_realm;
        pool.auto_compound_enabled = config.auto_compound_enabled;
        Ok(())
    }

    pub fn stake(ctx: Context<Stake>, amount: u64, lock_tier_index: u8) -> Result<()> {
        require!(amount > 0, StakingError::InvalidAmount);
        let position = &mut ctx.accounts.position;
        position.owner = ctx.accounts.owner.key();
        position.pool = ctx.accounts.pool.key();
        position.amount = position.amount.checked_add(amount).ok_or(StakingError::MathOverflow)?;
        position.lock_tier_index = lock_tier_index;
        position.last_action_ts = Clock::get()?.unix_timestamp;
        position.ve_balance = position
            .ve_balance
            .checked_add(calculate_ve_amount(amount, &ctx.accounts.pool, lock_tier_index)?)
            .ok_or(StakingError::MathOverflow)?;
        Ok(())
    }

    pub fn claim_rewards(ctx: Context<ClaimRewards>) -> Result<()> {
        let position = &mut ctx.accounts.position;
        position.last_claim_ts = Clock::get()?.unix_timestamp;
        Ok(())
    }

    pub fn toggle_auto_compound(ctx: Context<ToggleAutoCompound>, enabled: bool) -> Result<()> {
        let position = &mut ctx.accounts.position;
        position.auto_compound = enabled;
        Ok(())
    }
}

fn calculate_ve_amount(amount: u64, pool: &Account<PoolState>, tier_index: u8) -> Result<u64> {
    let tier = pool
        .lock_tiers
        .get(tier_index as usize)
        .ok_or(StakingError::InvalidLockTier)?;
    let boosted = (amount as u128)
        .checked_mul(tier.ve_multiplier as u128)
        .ok_or(StakingError::MathOverflow)?;
    Ok((boosted / 10_000) as u64)
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub struct PoolConfigArgs {
    pub asset_mint: Pubkey,
    pub pool_kind: u8,
    pub reward_mints: Vec<Pubkey>,
    pub referral_bps: u16,
    pub base_emission_rate: u64,
    pub governance_realm: Pubkey,
    pub auto_compound_enabled: bool,
    pub lock_tiers: Vec<LockTier>,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, Default)]
pub struct LockTier {
    pub duration_seconds: i64,
    pub reward_multiplier_bps: u64,
    pub ve_multiplier: u64,
}

#[account]
pub struct PoolState {
    pub authority: Pubkey,
    pub asset_mint: Pubkey,
    pub governance_realm: Pubkey,
    pub reward_mints: Vec<Pubkey>,
    pub lock_tiers: Vec<LockTier>,
    pub base_emission_rate: u64,
    pub referral_bps: u16,
    pub pool_kind: u8,
    pub bump: u8,
    pub auto_compound_enabled: bool,
}

#[account]
#[derive(Default)]
pub struct PositionState {
    pub owner: Pubkey,
    pub pool: Pubkey,
    pub amount: u64,
    pub ve_balance: u64,
    pub lock_tier_index: u8,
    pub auto_compound: bool,
    pub last_action_ts: i64,
    pub last_claim_ts: i64,
}

#[derive(Accounts)]
pub struct InitializePool<'info> {
    #[account(mut)]
    pub authority: Signer<'info>,
    #[account(init, payer = authority, space = 8 + 512)]
    pub pool: Account<'info, PoolState>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct Stake<'info> {
    #[account(mut)]
    pub owner: Signer<'info>,
    #[account(mut)]
    pub pool: Account<'info, PoolState>,
    #[account(init_if_needed, payer = owner, space = 8 + 128)]
    pub position: Account<'info, PositionState>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct ClaimRewards<'info> {
    #[account(mut)]
    pub owner: Signer<'info>,
    #[account(mut, has_one = owner)]
    pub position: Account<'info, PositionState>,
}

#[derive(Accounts)]
pub struct ToggleAutoCompound<'info> {
    pub owner: Signer<'info>,
    #[account(mut, has_one = owner)]
    pub position: Account<'info, PositionState>,
}

#[error_code]
pub enum StakingError {
    #[msg("Invalid amount")]
    InvalidAmount,
    #[msg("Invalid lock tier")]
    InvalidLockTier,
    #[msg("Math overflow")]
    MathOverflow,
}
