import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import PoolDiscovery from './pages/PoolDiscovery';
import StakePage from './pages/StakePage';
import RewardsDashboard from './pages/RewardsDashboard';
import GovernancePage from './pages/GovernancePage';
import ApyCalculator from './pages/ApyCalculator';

export default function App() {
  return (
    <div style={{ minHeight: '100vh' }}>
      <Navbar />
      <main className="container" style={{ paddingTop: '24px', paddingBottom: '48px' }}>
        <Routes>
          <Route path="/" element={<PoolDiscovery />} />
          <Route path="/stake/:poolId" element={<StakePage />} />
          <Route path="/stake" element={<StakePage />} />
          <Route path="/rewards" element={<RewardsDashboard />} />
          <Route path="/governance" element={<GovernancePage />} />
          <Route path="/calculator" element={<ApyCalculator />} />
        </Routes>
      </main>
    </div>
  );
}
