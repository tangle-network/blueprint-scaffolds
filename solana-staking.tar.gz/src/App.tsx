import { startTransition, useDeferredValue, useMemo, useState } from 'react';
import { Header } from './components/Header';
import { PoolDiscovery } from './components/PoolDiscovery';
import { StakingInterface } from './components/StakingInterface';
import { ApyCalculator } from './components/ApyCalculator';
import { RewardsDashboard } from './components/RewardsDashboard';
import { GovernancePanel } from './components/GovernancePanel';
import { compactNumber, currency } from './lib/format';
import { useStakingStore } from './store/useStakingStore';

const filters = [
  { id: 'all', label: 'All vaults' },
  { id: 'single', label: 'Single token' },
  { id: 'lp', label: 'LP' },
  { id: 'nft', label: 'NFT' }
] as const;

function App() {
  const {
    pools,
    selectedPoolId,
    depositAmount,
    selectedTierId,
    autoCompound,
    includeNftBoost,
    referralCode,
    setSelectedPool,
    setDepositAmount,
    setSelectedTier,
    setAutoCompound,
    setIncludeNftBoost,
    setReferralCode
  } = useStakingStore();
  const [activeFilter, setActiveFilter] = useState<(typeof filters)[number]['id']>('all');
  const deferredFilter = useDeferredValue(activeFilter);

  const selectedPool = pools.find((pool) => pool.id === selectedPoolId) ?? pools[0];
  const selectedTier =
    selectedPool.lockTiers.find((tier) => tier.id === selectedTierId) ?? selectedPool.lockTiers[0];

  const visiblePools = useMemo(() => {
    if (deferredFilter === 'all') {
      return pools;
    }

    return pools.filter((pool) => pool.category === deferredFilter);
  }, [deferredFilter, pools]);

  const totalTvl = pools.reduce((sum, pool) => sum + pool.tvl, 0);

  return (
    <div className="app-shell">
      <Header totalTvl={currency(totalTvl)} activeUsers={compactNumber(18342)} />

      <section className="filter-bar">
        {filters.map((filter) => (
          <button
            key={filter.id}
            type="button"
            className={activeFilter === filter.id ? 'active' : ''}
            onClick={() => startTransition(() => setActiveFilter(filter.id))}
          >
            {filter.label}
          </button>
        ))}
      </section>

      <main className="content-grid">
        <PoolDiscovery
          pools={visiblePools}
          selectedPoolId={selectedPool.id}
          onSelectPool={setSelectedPool}
        />
        <StakingInterface
          pool={selectedPool}
          selectedTier={selectedTier}
          depositAmount={depositAmount}
          autoCompound={autoCompound}
          includeNftBoost={includeNftBoost}
          referralCode={referralCode}
          onDepositAmount={setDepositAmount}
          onTierChange={setSelectedTier}
          onAutoCompound={setAutoCompound}
          onIncludeNftBoost={setIncludeNftBoost}
          onReferralCode={setReferralCode}
        />
        <ApyCalculator
          pool={selectedPool}
          tier={selectedTier}
          amount={depositAmount}
          autoCompound={autoCompound}
          includeNftBoost={includeNftBoost}
        />
        <RewardsDashboard pool={selectedPool} />
        <GovernancePanel pool={selectedPool} />
      </main>
    </div>
  );
}

export default App;
