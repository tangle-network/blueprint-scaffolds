import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import type { StakingPool, LockTier, LockTierConfig } from "@/types";
import { LOCK_TIERS } from "@/types";

const POOLS: (StakingPool & { apy: number; lockDays: number; badge?: string })[] = [
  {
    id: "solx-lp",
    name: "SOL-X LP Pool",
    poolType: "lp",
    stakingMint: "So11111111111111111111111111111111111111112",
    stakingTokenSymbol: "SOL-X LP",
    stakingTokenDecimals: 9,
    totalStaked: 2400000,
    tvlUSD: 2400000,
    rewardTokens: [
      {
        mint: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
        symbol: "USDC",
        decimals: 6,
        rewardRatePerSecond: 0.5,
        remainingRewards: 5000000,
      },
    ],
    lockTiers: LOCK_TIERS,
    autoCompound: true,
    veTokenEnabled: false,
    referralEnabled: true,
    createdAt: Date.now() - 86400000 * 90,
    status: "active",
    apy: 12.5,
    lockDays: 0,
  },
  {
    id: "vesol-single",
    name: "veSOL Single-Side",
    poolType: "single",
    stakingMint: "So11111111111111111111111111111111111111112",
    stakingTokenSymbol: "veSOL",
    stakingTokenDecimals: 9,
    totalStaked: 8100000,
    tvlUSD: 8100000,
    rewardTokens: [
      {
        mint: "So11111111111111111111111111111111111111112",
        symbol: "SOL",
        decimals: 9,
        rewardRatePerSecond: 0.2,
        remainingRewards: 2000000,
      },
    ],
    lockTiers: LOCK_TIERS,
    autoCompound: true,
    veTokenEnabled: true,
    referralEnabled: false,
    createdAt: Date.now() - 86400000 * 60,
    status: "active",
    apy: 8.2,
    lockDays: 30,
  },
  {
    id: "nft-rewards",
    name: "NFT Rewards Pool",
    poolType: "nft",
    stakingMint: "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
    stakingTokenSymbol: "NFT",
    stakingTokenDecimals: 0,
    totalStaked: 1100000,
    tvlUSD: 1100000,
    rewardTokens: [
      {
        mint: "So11111111111111111111111111111111111111112",
        symbol: "SOL",
        decimals: 9,
        rewardRatePerSecond: 0.05,
        remainingRewards: 500000,
      },
    ],
    lockTiers: [LOCK_TIERS[0], LOCK_TIERS[2], LOCK_TIERS[4]],
    autoCompound: false,
    veTokenEnabled: false,
    referralEnabled: false,
    createdAt: Date.now() - 86400000 * 30,
    status: "active",
    apy: 18.7,
    lockDays: 0,
    badge: "NFT-gated",
  },
];

const LOCK_OPTIONS: { tier: LockTier; label: string; boostMultiplier: number }[] = [
  { tier: "flexible", label: "0 days (Flexible)", boostMultiplier: 1.0 },
  { tier: "locked_30d", label: "30 days", boostMultiplier: 1.2 },
  { tier: "locked_90d", label: "90 days", boostMultiplier: 1.5 },
  { tier: "locked_180d", label: "180 days", boostMultiplier: 2.0 },
  { tier: "locked_365d", label: "365 days", boostMultiplier: 3.0 },
];

function formatUSD(value: number): string {
  if (value >= 1_000_000) return `$${(value / 1_000_000).toFixed(1)}M`;
  if (value >= 1_000) return `$${(value / 1_000).toFixed(1)}K`;
  return `$${value.toFixed(2)}`;
}

function Header({
  activeTab,
  onTabChange,
}: {
  activeTab: string;
  onTabChange: (tab: string) => void;
}) {
  return (
    <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-purple-500 to-blue-600" />
          <span className="text-xl font-bold tracking-tight">SolStake</span>
        </div>
        <nav className="flex items-center gap-1">
          {["Dashboard", "Pools", "Governance"].map((tab) => (
            <Button
              key={tab}
              variant={activeTab === tab ? "default" : "ghost"}
              size="sm"
              onClick={() => onTabChange(tab)}
            >
              {tab}
            </Button>
          ))}
        </nav>
        <Button variant="outline" size="sm">
          Connect Wallet
        </Button>
      </div>
    </header>
  );
}

function PoolCard({
  pool,
  onSelect,
}: {
  pool: (typeof POOLS)[number];
  onSelect: () => void;
}) {
  const tvlPct = Math.min((pool.tvlUSD / 10_000_000) * 100, 100);

  return (
    <Card className="transition-shadow hover:shadow-md">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">{pool.name}</CardTitle>
          {pool.badge && (
            <span className="rounded-full bg-purple-100 px-2 py-0.5 text-xs font-medium text-purple-700">
              {pool.badge}
            </span>
          )}
        </div>
        <CardDescription>
          {pool.poolType === "lp"
            ? "Liquidity Provider"
            : pool.poolType === "nft"
              ? "NFT Staking"
              : "Single-Side Staking"}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">TVL</span>
          <span className="font-medium">{formatUSD(pool.tvlUSD)}</span>
        </div>
        <Progress value={tvlPct} className="h-2" />
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">APY</span>
          <span className="font-semibold text-green-600">{pool.apy}%</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Min Lock</span>
          <span className="font-medium">
            {pool.lockDays === 0 ? "None" : `${pool.lockDays} days`}
          </span>
        </div>
        <div className="flex gap-2 flex-wrap">
          {pool.rewardTokens.map((rt) => (
            <span
              key={rt.mint}
              className="rounded-full bg-muted px-2 py-0.5 text-xs"
            >
              {rt.symbol}
            </span>
          ))}
          {pool.autoCompound && (
            <span className="rounded-full bg-green-100 px-2 py-0.5 text-xs text-green-700">
              Auto-compound
            </span>
          )}
        </div>
      </CardContent>
      <CardFooter>
        <Button className="w-full" onClick={onSelect}>
          Stake in Pool
        </Button>
      </CardFooter>
    </Card>
  );
}

function StakingInterface({
  pool,
  onClose,
}: {
  pool: (typeof POOLS)[number];
  onClose: () => void;
}) {
  const [amount, setAmount] = useState("");
  const [selectedTier, setSelectedTier] = useState<LockTier>("flexible");
  const [mode, setMode] = useState<"stake" | "unstake">("stake");

  const currentOption = LOCK_OPTIONS.find((o) => o.tier === selectedTier)!;
  const boost = currentOption.boostMultiplier;
  const effectiveAPY = pool.apy * boost;
  const numAmount = parseFloat(amount) || 0;
  const projectedAnnual = (numAmount * effectiveAPY) / 100;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">{pool.name}</h2>
        <Button variant="ghost" size="sm" onClick={onClose}>
          Back
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>TVL</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{formatUSD(pool.tvlUSD)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Base APY</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-600">{pool.apy}%</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Effective APY</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-600">{effectiveAPY.toFixed(1)}%</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{mode === "stake" ? "Stake Tokens" : "Unstake Tokens"}</CardTitle>
          <CardDescription>
            {mode === "stake"
              ? "Deposit tokens to earn rewards"
              : "Withdraw your staked tokens"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Button
              variant={mode === "stake" ? "default" : "outline"}
              size="sm"
              onClick={() => setMode("stake")}
              className="flex-1"
            >
              Stake
            </Button>
            <Button
              variant={mode === "unstake" ? "default" : "outline"}
              size="sm"
              onClick={() => setMode("unstake")}
              className="flex-1"
            >
              Unstake
            </Button>
          </div>

          <div className="space-y-2">
            <Label htmlFor="stake-amount">
              Amount ({pool.stakingTokenSymbol})
            </Label>
            <div className="flex gap-2">
              <Input
                id="stake-amount"
                type="number"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                min={0}
                step={0.01}
              />
              <Button
                variant="outline"
                size="sm"
                onClick={() => setAmount("100")}
              >
                Max
              </Button>
            </div>
          </div>

          {mode === "stake" && (
            <div className="space-y-2">
              <Label>Lock Duration</Label>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
                {LOCK_OPTIONS.map((opt) => (
                  <Button
                    key={opt.tier}
                    variant={selectedTier === opt.tier ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedTier(opt.tier)}
                    className="text-xs"
                  >
                    {opt.label}
                  </Button>
                ))}
              </div>
            </div>
          )}

          <div className="rounded-lg border bg-muted/50 p-4 space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Boost Multiplier</span>
              <span className="font-semibold text-purple-600">
                {boost}x
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Effective APY</span>
              <span className="font-semibold text-green-600">
                {effectiveAPY.toFixed(1)}%
              </span>
            </div>
            {numAmount > 0 && (
              <>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Projected Annual</span>
                  <span className="font-medium">
                    {projectedAnnual.toFixed(2)} {pool.rewardTokens[0]?.symbol ?? "tokens"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Projected Monthly</span>
                  <span className="font-medium">
                    {(projectedAnnual / 12).toFixed(2)} {pool.rewardTokens[0]?.symbol ?? "tokens"}
                  </span>
                </div>
              </>
            )}
          </div>
        </CardContent>
        <CardFooter className="gap-2">
          <Dialog>
            <DialogTrigger asChild>
              <Button className="flex-1" disabled={numAmount <= 0}>
                {mode === "stake" ? "Stake" : "Unstake"}
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>
                  Confirm {mode === "stake" ? "Staking" : "Unstaking"}
                </DialogTitle>
                <DialogDescription>
                  You are about to {mode} {numAmount} {pool.stakingTokenSymbol}
                  {mode === "stake" && selectedTier !== "flexible"
                    ? ` locked for ${currentOption.label}`
                    : ""}
                  .
                </DialogDescription>
              </DialogHeader>
              <div className="rounded-lg border p-4 space-y-1 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Amount</span>
                  <span>{numAmount} {pool.stakingTokenSymbol}</span>
                </div>
                {mode === "stake" && (
                  <>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Lock</span>
                      <span>{currentOption.label}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Boost</span>
                      <span className="text-purple-600">{boost}x</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">APY</span>
                      <span className="text-green-600">{effectiveAPY.toFixed(1)}%</span>
                    </div>
                  </>
                )}
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={onClose}>
                  Cancel
                </Button>
                <Button
                  onClick={() => {
                    alert(
                      `Transaction submitted: ${mode} ${numAmount} ${pool.stakingTokenSymbol}`
                    );
                    onClose();
                  }}
                >
                  Confirm
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardFooter>
      </Card>
    </div>
  );
}

export default function App() {
  const [activeTab, setActiveTab] = useState("Dashboard");
  const [selectedPool, setSelectedPool] = useState<(typeof POOLS)[number] | null>(null);

  const totalTVL = POOLS.reduce((sum, p) => sum + p.tvlUSD, 0);

  if (selectedPool) {
    return (
      <div className="min-h-screen bg-background">
        <Header activeTab={activeTab} onTabChange={setActiveTab} />
        <main className="container mx-auto px-4 py-8">
          <StakingInterface
            pool={selectedPool}
            onClose={() => setSelectedPool(null)}
          />
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header activeTab={activeTab} onTabChange={setActiveTab} />
      <main className="container mx-auto px-4 py-8 space-y-8">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">
            {activeTab === "Dashboard"
              ? "Welcome to SolStake"
              : activeTab === "Pools"
                ? "Discover Pools"
                : "Governance"}
          </h1>
          <p className="text-muted-foreground">
            {activeTab === "Dashboard"
              ? "Stake your assets and earn rewards across multiple pools."
              : activeTab === "Pools"
                ? "Browse all available staking pools and find the best yields."
                : "Vote on proposals and shape the future of the protocol."}
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Total Value Locked</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{formatUSD(totalTVL)}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Active Pools</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{POOLS.length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Avg. APY</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-green-600">
                {(POOLS.reduce((s, p) => s + p.apy, 0) / POOLS.length).toFixed(1)}%
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <h2 className="text-2xl font-semibold tracking-tight">Staking Pools</h2>
          <div className="grid gap-6 md:grid-cols-3">
            {POOLS.map((pool) => (
              <PoolCard
                key={pool.id}
                pool={pool}
                onSelect={() => setSelectedPool(pool)}
              />
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
