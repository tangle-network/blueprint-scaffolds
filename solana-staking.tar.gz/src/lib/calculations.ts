import type { LockTier, Pool } from '../types';

export const calculateEmissionApr = (pool: Pool) => {
  const yearlyRewardsValue = pool.rewardTokens.reduce(
    (sum, token) => sum + token.dailyEmission * token.price * 365,
    0
  );

  return (yearlyRewardsValue / pool.tvl) * 100;
};

export const calculateBoostedApr = (
  pool: Pool,
  tier: LockTier,
  hasNftBoost: boolean,
  autoCompound: boolean
) => {
  const nftMultiplier = hasNftBoost ? pool.nftBoost : 1;
  const compoundBonus = autoCompound && pool.autoCompound ? 1.12 : 1;
  const veBonus = 1 + pool.veAprBonus / 100;

  return (pool.baseApr + calculateEmissionApr(pool)) * tier.boost * nftMultiplier * compoundBonus * veBonus;
};

export const estimateVeTokens = (amount: number, tier: LockTier) =>
  amount * tier.veMultiplier * Math.max(tier.days / 30, 1);

export const projectAnnualRewards = (deposit: number, apr: number) => (deposit * apr) / 100;
