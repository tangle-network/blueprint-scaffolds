import type { Pool } from '../types';

export const pools: Pool[] = [
  {
    id: 'atlas-sol',
    name: 'Atlas SOL Vault',
    category: 'single',
    tokenSymbol: 'SOL',
    tvl: 12450000,
    baseApr: 12.4,
    utilization: 0.74,
    autoCompound: true,
    referralRate: 0.04,
    governanceWeight: 1.2,
    veAprBonus: 5.6,
    nftBoost: 1.15,
    rewardTokens: [
      { symbol: 'ATLAS', dailyEmission: 42000, price: 0.18 },
      { symbol: 'JTO', dailyEmission: 1800, price: 2.45 }
    ],
    lockTiers: [
      { id: 'flex', label: 'Flexible', days: 0, boost: 1, veMultiplier: 0.25 },
      { id: 'thirty', label: '30D Lock', days: 30, boost: 1.2, veMultiplier: 0.75 },
      { id: 'ninety', label: '90D Lock', days: 90, boost: 1.55, veMultiplier: 1.4 },
      { id: 'year', label: '365D Lock', days: 365, boost: 2.3, veMultiplier: 3.2 }
    ],
    userPosition: {
      staked: 148.2,
      pendingRewardsUsd: 326.72,
      referralRewardsUsd: 42.14,
      veBalance: 1900
    }
  },
  {
    id: 'orca-atlas-usdc',
    name: 'Orca ATLAS/USDC LP',
    category: 'lp',
    tokenSymbol: 'ATLAS/USDC LP',
    tvl: 8830000,
    baseApr: 28.7,
    utilization: 0.61,
    autoCompound: true,
    referralRate: 0.06,
    governanceWeight: 1.5,
    veAprBonus: 8.2,
    nftBoost: 1.3,
    rewardTokens: [
      { symbol: 'ATLAS', dailyEmission: 96000, price: 0.18 },
      { symbol: 'ORCA', dailyEmission: 2400, price: 3.11 }
    ],
    lockTiers: [
      { id: 'flex', label: 'Flexible', days: 0, boost: 1, veMultiplier: 0.2 },
      { id: 'sixty', label: '60D Lock', days: 60, boost: 1.4, veMultiplier: 1.1 },
      { id: 'oneeighty', label: '180D Lock', days: 180, boost: 2.1, veMultiplier: 2.4 }
    ],
    userPosition: {
      staked: 84.6,
      pendingRewardsUsd: 512.8,
      referralRewardsUsd: 93.33,
      veBalance: 2600
    }
  },
  {
    id: 'genesis-council',
    name: 'Genesis Council NFT',
    category: 'nft',
    tokenSymbol: 'ATLAS Genesis',
    tvl: 3310000,
    baseApr: 18.1,
    utilization: 0.52,
    autoCompound: false,
    referralRate: 0.03,
    governanceWeight: 2.4,
    veAprBonus: 10.5,
    nftBoost: 1.8,
    rewardTokens: [
      { symbol: 'ATLAS', dailyEmission: 26000, price: 0.18 },
      { symbol: 'BONK', dailyEmission: 1500000, price: 0.000031 }
    ],
    lockTiers: [
      { id: 'stake', label: 'Stake Only', days: 0, boost: 1.25, veMultiplier: 0.9 },
      { id: 'curator', label: 'Curator 120D', days: 120, boost: 1.95, veMultiplier: 2.2 }
    ],
    userPosition: {
      staked: 3,
      pendingRewardsUsd: 214.44,
      referralRewardsUsd: 18.09,
      veBalance: 780
    }
  }
];
