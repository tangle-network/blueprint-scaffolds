export type PoolKind = 'single' | 'lp' | 'nft';

export type LockTier = {
  id: string;
  label: string;
  days: number;
  boost: number;
  veMultiplier: number;
};

export type RewardToken = {
  symbol: string;
  dailyEmission: number;
  price: number;
};

export type Pool = {
  id: string;
  name: string;
  category: PoolKind;
  tokenSymbol: string;
  tvl: number;
  baseApr: number;
  utilization: number;
  autoCompound: boolean;
  lockTiers: LockTier[];
  rewardTokens: RewardToken[];
  referralRate: number;
  governanceWeight: number;
  veAprBonus: number;
  nftBoost: number;
  userPosition: {
    staked: number;
    pendingRewardsUsd: number;
    referralRewardsUsd: number;
    veBalance: number;
  };
};
