import { useStaking } from '../contexts/StakingContext';
import { useWallet } from '../contexts/WalletContext';
import { formatNumber, formatCountdown } from '../types';

export default function GovernancePage() {
  const { proposals, veToken, vote } = useStaking();
  const { connected, connect } = useWallet();

  const statusColor: Record<string, string> = {
    active: 'badge-green',
    passed: 'badge-purple',
    failed: 'badge-gold',
    executed: 'badge-purple',
  };

  return (
    <div>
      <h2 className="text-lg font-bold mb-24">Governance</h2>

      <div className="grid grid-3 gap-16 mb-24">
        <div className="card">
          <div className="text-xs text-secondary mb-8">Your Voting Power</div>
          <div className="font-bold text-lg text-accent">{formatNumber(veToken.votingPower)}</div>
        </div>
        <div className="card">
          <div className="text-xs text-secondary mb-8">Active Proposals</div>
          <div className="font-bold text-lg">
            {proposals.filter((p) => p.status === 'active').length}
          </div>
        </div>
        <div className="card">
          <div className="text-xs text-secondary mb-8">veToken Locked</div>
          <div className="font-bold text-lg">{formatNumber(veToken.lockedAmount)}</div>
        </div>
      </div>

      <div className="flex flex-col gap-16">
        {proposals.map((prop) => {
          const totalVotes = prop.voteFor + prop.voteAgainst;
          const forPct = totalVotes > 0 ? (prop.voteFor / totalVotes) * 100 : 50;

          return (
            <div key={prop.id} className="card">
              <div className="flex justify-between items-center mb-8">
                <h3 className="font-semibold">{prop.title}</h3>
                <span className={`badge ${statusColor[prop.status] ?? 'badge-purple'}`}>
                  {prop.status}
                </span>
              </div>

              <p className="text-sm text-secondary mb-16">{prop.description}</p>

              <div className="grid grid-3 gap-16 mb-16">
                <div>
                  <div className="text-xs text-secondary">Votes For</div>
                  <div className="font-bold text-success">{formatNumber(prop.voteFor)}</div>
                </div>
                <div>
                  <div className="text-xs text-secondary">Votes Against</div>
                  <div className="font-bold text-danger">{formatNumber(prop.voteAgainst)}</div>
                </div>
                <div>
                  <div className="text-xs text-secondary">
                    {prop.status === 'active' ? 'Time Remaining' : 'Ended'}
                  </div>
                  <div className="font-bold">
                    {prop.status === 'active'
                      ? formatCountdown(prop.endTime - Date.now())
                      : new Date(prop.endTime).toLocaleDateString()}
                  </div>
                </div>
              </div>

              <div className="progress-bar mb-16">
                <div
                  className="progress-bar-fill"
                  style={{ width: `${forPct}%` }}
                />
              </div>

              <div className="flex justify-between items-center text-xs text-secondary mb-16">
                <span>{forPct.toFixed(1)}% For</span>
                <span>Proposer: {prop.proposer.slice(0, 8)}...</span>
              </div>

              {prop.status === 'active' && (
                <div className="flex gap-8">
                  {prop.userVote ? (
                    <div className="text-sm">
                      You voted:{' '}
                      <span
                        className={
                          prop.userVote === 'for' ? 'text-success' : 'text-danger'
                        }
                      >
                        {prop.userVote === 'for' ? 'For' : 'Against'}
                      </span>
                    </div>
                  ) : connected ? (
                    <>
                      <button
                        className="btn btn-primary"
                        onClick={() => vote(prop.id, true)}
                      >
                        Vote For
                      </button>
                      <button
                        className="btn btn-secondary"
                        onClick={() => vote(prop.id, false)}
                      >
                        Vote Against
                      </button>
                    </>
                  ) : (
                    <button className="btn btn-primary" onClick={connect}>
                      Connect Wallet to Vote
                    </button>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
