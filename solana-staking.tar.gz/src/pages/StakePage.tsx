import { useState, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useStaking } from '../contexts/StakingContext';
import { useWallet } from '../contexts/WalletContext';
import { formatNumber, LOCK_TIERS } from '../types';

export default function StakePage() {
  const { poolId } = useParams();
  const { pools, userStakes, stake, unstake, claimRewards, compound, veToken } =
    useStaking();
  const { connected, connect } = useWallet();
  const [amount, setAmount] = useState('');
  const [selectedTier, setSelectedTier] = useState(0);
  const [activeTab, setActiveTab] = useState<'stake' | 'unstake'>('stake');

  const pool = pools.find((p) => p.id === poolId) ?? pools[0];
  const userStake = userStakes.find((s) => s.poolId === pool?.id);

  const effectiveApy = useMemo(() => {
    if (!pool) return [];
    const multiplier = pool.lockTiers[selectedTier]?.multiplier ?? 1;
    return pool.apy.map((a) => a * multiplier);
  }, [pool, selectedTier]);

  const boostedApy = useMemo(() => {
    if (!userStake || !pool) return effectiveApy;
    const veBoost = 1 + (veToken.votingPower / 10000) * 0.5;
    return effectiveApy.map((a) => a * veBoost);
  }, [effectiveApy, userStake, veToken, pool]);

  if (!pool) {
    return (
      <div className="text-center mt-24">
        <h2 className="text-lg font-bold mb-16">No pool selected</h2>
        <p className="text-secondary mb-16">Choose a pool from the discovery page</p>
        <Link to="/" className="btn btn-primary">
          Browse Pools
        </Link>
      </div>
    );
  }

  const handleStake = () => {
    const val = parseFloat(amount);
    if (isNaN(val) || val <= 0) return;
    if (!connected) {
      connect();
      return;
    }
    stake(pool.id, val, selectedTier);
    setAmount('');
  };

  const handleUnstake = () => {
    const val = parseFloat(amount);
    if (isNaN(val) || val <= 0 || !userStake) return;
    unstake(pool.id, val);
    setAmount('');
  };

  const handleClaim = () => claimRewards(pool.id);
  const handleCompound = () => compound(pool.id);

  return (
    <div>
      <Link to="/" className="text-sm text-secondary" style={{ display: 'inline-block', marginBottom: 16 }}>
        &larr; Back to Pools
      </Link>

      <div className="grid grid-2 gap-24">
        <div>
          <div className="card mb-24">
            <h2 className="text-lg font-bold mb-16">{pool.name}</h2>
            <div className="grid grid-2 gap-16 mb-16">
              <div>
                <div className="text-xs text-secondary">TVL</div>
                <div className="font-bold">${formatNumber(pool.tvl)}</div>
              </div>
              <div>
                <div className="text-xs text-secondary">Your Stake</div>
                <div className="font-bold">
                  {userStake ? formatNumber(userStake.amount) : '0'}
                </div>
              </div>
            </div>

            {userStake && userStake.pendingRewards.length > 0 && (
              <div
                className="card mb-16"
                style={{ background: 'rgba(20,241,149,0.1)', borderColor: 'var(--success)' }}
              >
                <div className="text-xs text-success font-semibold mb-8">
                  Pending Rewards
                </div>
                <div className="flex justify-between items-center">
                  <div>
                    {userStake.pendingRewards.map((r, i) => (
                      <div key={i} className="font-bold">
                        {formatNumber(r)} {pool.rewardSymbols[i]}
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-8">
                    <button className="btn btn-primary" onClick={handleClaim}>
                      Claim
                    </button>
                    {pool.autoCompound && (
                      <button className="btn btn-secondary" onClick={handleCompound}>
                        Compound
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )}

            <div className="flex gap-8 mb-16">
              <button
                className={`btn ${activeTab === 'stake' ? 'btn-primary' : 'btn-secondary'}`}
                onClick={() => setActiveTab('stake')}
                style={{ flex: 1 }}
              >
                Stake
              </button>
              <button
                className={`btn ${activeTab === 'unstake' ? 'btn-primary' : 'btn-secondary'}`}
                onClick={() => setActiveTab('unstake')}
                style={{ flex: 1 }}
              >
                Unstake
              </button>
            </div>

            <div className="mb-16">
              <label className="text-xs text-secondary" style={{ display: 'block', marginBottom: 8 }}>
                {activeTab === 'stake' ? 'Amount to Stake' : 'Amount to Unstake'}
              </label>
              <input
                type="number"
                className="input"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                min={0}
                step="0.01"
              />
              {activeTab === 'unstake' && userStake && (
                <button
                  className="text-xs text-accent mt-8"
                  style={{ background: 'none', border: 'none', cursor: 'pointer' }}
                  onClick={() => setAmount(String(userStake.amount))}
                >
                  Max: {userStake.amount}
                </button>
              )}
            </div>

            {activeTab === 'stake' && (
              <div className="mb-16">
                <label className="text-xs text-secondary" style={{ display: 'block', marginBottom: 8 }}>
                  Lock Period
                </label>
                <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(100px, 1fr))', gap: 8 }}>
                  {pool.lockTiers.map((tier, i) => (
                    <button
                      key={i}
                      className={`btn ${selectedTier === i ? 'btn-primary' : 'btn-secondary'}`}
                      style={{ padding: '8px 12px', fontSize: 12 }}
                      onClick={() => setSelectedTier(i)}
                    >
                      <div>{tier.label}</div>
                      <div className="text-xs" style={{ opacity: 0.8 }}>
                        {tier.multiplier}x
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            <button
              className="btn btn-primary w-full"
              onClick={activeTab === 'stake' ? handleStake : handleUnstake}
              style={{ padding: '16px' }}
            >
              {connected
                ? activeTab === 'stake'
                  ? 'Stake'
                  : 'Unstake'
                : 'Connect Wallet'}
            </button>
          </div>

          {userStake && (
            <div className="card">
              <h3 className="font-semibold mb-16">Your Position</h3>
              <div className="flex justify-between text-sm mb-8">
                <span className="text-secondary">Staked Amount</span>
                <span className="font-bold">{formatNumber(userStake.amount)}</span>
              </div>
              <div className="flex justify-between text-sm mb-8">
                <span className="text-secondary">Lock Tier</span>
                <span>
                  {pool.lockTiers[userStake.lockTier]?.label ?? 'Flexible'}
                </span>
              </div>
              {userStake.lockEnd > 0 && (
                <div className="flex justify-between text-sm mb-8">
                  <span className="text-secondary">Lock Ends</span>
                  <span>{new Date(userStake.lockEnd).toLocaleDateString()}</span>
                </div>
              )}
              <div className="flex justify-between text-sm mb-8">
                <span className="text-secondary">veToken Balance</span>
                <span className="text-accent">{userStake.veBalance}</span>
              </div>
              {userStake.referralCount > 0 && (
                <div className="flex justify-between text-sm">
                  <span className="text-secondary">Referral Rewards</span>
                  <span className="text-success">
                    {formatNumber(userStake.referralRewards)}
                  </span>
                </div>
              )}
            </div>
          )}
        </div>

        <div>
          <div className="card mb-24">
            <h3 className="font-semibold mb-16">Reward Projections</h3>
            <div className="mb-16">
              <div className="text-xs text-secondary mb-8">Base APY</div>
              <div className="font-bold text-lg">
                {pool.apy.map((a) => `${a}%`).join(' + ')}
              </div>
            </div>
            <div className="mb-16">
              <div className="text-xs text-secondary mb-8">
                With Lock Boost ({pool.lockTiers[selectedTier]?.multiplier ?? 1}x)
              </div>
              <div className="font-bold text-lg text-success">
                {effectiveApy.map((a) => `${a.toFixed(1)}%`).join(' + ')}
              </div>
            </div>
            {veToken.votingPower > 0 && (
              <div className="mb-16">
                <div className="text-xs text-secondary mb-8">
                  With veToken Boost
                </div>
                <div className="font-bold text-lg text-warning">
                  {boostedApy.map((a) => `${a.toFixed(1)}%`).join(' + ')}
                </div>
              </div>
            )}
            <div>
              <div className="text-xs text-secondary mb-8">Reward Rate</div>
              <div className="text-sm">
                {pool.rewardRatePerSecond
                  .map((r, i) => `${r.toFixed(4)} ${pool.rewardSymbols[i]}/sec`)
                  .join(', ')}
              </div>
            </div>
          </div>

          <div className="card mb-24">
            <h3 className="font-semibold mb-16">veToken Info</h3>
            <div className="flex justify-between text-sm mb-8">
              <span className="text-secondary">Your veBalance</span>
              <span className="text-accent">{veToken.votingPower}</span>
            </div>
            <div className="flex justify-between text-sm mb-8">
              <span className="text-secondary">Locked Amount</span>
              <span>{veToken.lockedAmount}</span>
            </div>
            {veToken.lockEnd > 0 && (
              <div className="flex justify-between text-sm mb-8">
                <span className="text-secondary">Lock Expiry</span>
                <span>{new Date(veToken.lockEnd).toLocaleDateString()}</span>
              </div>
            )}
            <div className="flex justify-between text-sm">
              <span className="text-secondary">Decay Rate</span>
              <span>{veToken.decayRate}%/day</span>
            </div>
          </div>

          <div className="card">
            <h3 className="font-semibold mb-16">Lock Tier Details</h3>
            {LOCK_TIERS.map((tier, i) => (
              <div key={i} className="flex justify-between text-sm mb-8">
                <span>{tier.label}</span>
                <span
                  className={`font-bold ${tier.multiplier >= 2 ? 'text-warning' : tier.multiplier >= 1.5 ? 'text-success' : ''}`}
                >
                  {tier.multiplier}x
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
