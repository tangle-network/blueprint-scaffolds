import { useStaking } from '../contexts/StakingContext';
import { useWallet } from '../contexts/WalletContext';
import { formatNumber } from '../types';

export default function RewardsDashboard() {
  const { userStakes, pools, veToken, referralCode } = useStaking();
  const { connected, connect } = useWallet();

  if (!connected) {
    return (
      <div className="text-center mt-24">
        <h2 className="text-lg font-bold mb-16">Rewards Dashboard</h2>
        <p className="text-secondary mb-16">Connect your wallet to view rewards</p>
        <button className="btn btn-primary" onClick={connect}>
          Connect Wallet
        </button>
      </div>
    );
  }

  const totalPendingByToken: Record<string, number> = {};
  userStakes.forEach((s) => {
    const pool = pools.find((p) => p.id === s.poolId);
    if (!pool) return;
    pool.rewardSymbols.forEach((sym, i) => {
      totalPendingByToken[sym] = (totalPendingByToken[sym] ?? 0) + s.pendingRewards[i];
    });
  });

  const totalStaked = userStakes.reduce((sum, s) => {
    const pool = pools.find((p) => p.id === s.poolId);
    return sum + s.amount * (pool?.tvl ?? 0) / (pool?.totalStaked ?? 1);
  }, 0);

  return (
    <div>
      <h2 className="text-lg font-bold mb-24">Rewards Dashboard</h2>

      <div className="grid grid-4 gap-16 mb-24">
        <div className="card">
          <div className="text-xs text-secondary mb-8">Total Staked Value</div>
          <div className="font-bold text-lg">${formatNumber(totalStaked)}</div>
        </div>
        <div className="card">
          <div className="text-xs text-secondary mb-8">veToken Balance</div>
          <div className="font-bold text-lg text-accent">{veToken.votingPower}</div>
        </div>
        <div className="card">
          <div className="text-xs text-secondary mb-8">Active Positions</div>
          <div className="font-bold text-lg">{userStakes.length}</div>
        </div>
        <div className="card">
          <div className="text-xs text-secondary mb-8">Referral Code</div>
          <div className="font-bold text-sm text-accent">{referralCode}</div>
        </div>
      </div>

      <div className="card mb-24">
        <h3 className="font-semibold mb-16">Pending Rewards by Token</h3>
        <div className="grid grid-3 gap-16">
          {Object.entries(totalPendingByToken).map(([symbol, amount]) => (
            <div key={symbol} className="card" style={{ background: 'var(--bg-secondary)' }}>
              <div className="text-xs text-secondary mb-4">{symbol}</div>
              <div className="font-bold text-lg text-success">{formatNumber(amount)}</div>
            </div>
          ))}
          {Object.keys(totalPendingByToken).length === 0 && (
            <div className="text-secondary text-sm">No pending rewards</div>
          )}
        </div>
      </div>

      <div className="card mb-24">
        <h3 className="font-semibold mb-16">Your Positions</h3>
        {userStakes.length === 0 ? (
          <div className="text-secondary text-sm">
            No active staking positions. Browse pools to start staking.
          </div>
        ) : (
          <div className="flex flex-col gap-16">
            {userStakes.map((s) => {
              const pool = pools.find((p) => p.id === s.poolId);
              if (!pool) return null;
              return (
                <div
                  key={s.poolId}
                  className="card"
                  style={{ background: 'var(--bg-secondary)' }}
                >
                  <div className="flex justify-between items-center mb-8">
                    <span className="font-semibold">{pool.name}</span>
                    <span className="badge badge-green">{pool.lockTiers[s.lockTier]?.label}</span>
                  </div>
                  <div className="grid grid-3 gap-16">
                    <div>
                      <div className="text-xs text-secondary">Staked</div>
                      <div className="font-bold">
                        {formatNumber(s.amount)}{' '}
                        <span className="text-xs text-secondary">
                          {pool.type === 'nft' ? 'NFTs' : 'tokens'}
                        </span>
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-secondary">Pending Rewards</div>
                      {s.pendingRewards.map((r, i) => (
                        <div key={i} className="text-success font-bold">
                          {formatNumber(r)} {pool.rewardSymbols[i]}
                        </div>
                      ))}
                    </div>
                    <div>
                      <div className="text-xs text-secondary">veToken</div>
                      <div className="text-accent font-bold">{s.veBalance}</div>
                    </div>
                  </div>
                  {s.lockEnd > 0 && (
                    <div className="text-xs text-secondary mt-8">
                      Lock ends: {new Date(s.lockEnd).toLocaleDateString()}
                    </div>
                  )}
                  {s.referralCount > 0 && (
                    <div className="text-xs text-secondary mt-8">
                      Referrals: {s.referralCount} | Earned:{' '}
                      {formatNumber(s.referralRewards)}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="card">
        <h3 className="font-semibold mb-16">Referral Program</h3>
        <div className="grid grid-2 gap-16 mb-16">
          <div>
            <div className="text-xs text-secondary mb-8">Your Referral Code</div>
            <div
              className="flex items-center gap-8"
              style={{
                padding: '12px 16px',
                background: 'var(--bg-secondary)',
                borderRadius: 12,
                border: '1px solid var(--border)',
              }}
            >
              <code className="text-accent font-bold">{referralCode}</code>
            </div>
          </div>
          <div>
            <div className="text-xs text-secondary mb-8">Referral Stats</div>
            <div className="text-sm">
              Total referrals:{' '}
              {userStakes.reduce((s, u) => s + u.referralCount, 0)} | Total earned:{' '}
              {formatNumber(userStakes.reduce((s, u) => s + u.referralRewards, 0))} SOL
            </div>
          </div>
        </div>
        <p className="text-xs text-secondary">
          Share your referral code to earn 2% of your referees' staking rewards.
        </p>
      </div>
    </div>
  );
}
