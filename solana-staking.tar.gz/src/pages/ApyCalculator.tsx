import { useState, useMemo } from 'react';
import { useStaking } from '../contexts/StakingContext';
import { LOCK_TIERS, formatNumber } from '../types';

export default function ApyCalculator() {
  const { pools } = useStaking();
  const [selectedPool, setSelectedPool] = useState(0);
  const [stakeAmount, setStakeAmount] = useState('1000');
  const [lockTier, setLockTier] = useState(0);
  const [veTokenAmount, setVeTokenAmount] = useState('0');
  const [days, setDays] = useState('365');

  const pool = pools[selectedPool];

  const calculations = useMemo(() => {
    if (!pool) return null;

    const amount = parseFloat(stakeAmount) || 0;
    const veAmt = parseFloat(veTokenAmount) || 0;
    const numDays = parseFloat(days) || 365;

    const lockMultiplier = pool.lockTiers[lockTier]?.multiplier ?? 1;
    const veBoost = 1 + (veAmt / 10000) * 0.5;

    const seconds = numDays * 86400;

    const baseRewards = pool.rewardRatePerSecond.map((rate) => rate * seconds);
    const boostedRewards = baseRewards.map((r) => r * lockMultiplier * veBoost);
    const perTokenRewards = boostedRewards.map((r) =>
      pool.totalStaked > 0 ? (r / pool.totalStaked) * amount : 0
    );

    const effectiveApys = pool.apy.map((a) => a * lockMultiplier * veBoost);

    return {
      baseRewards,
      boostedRewards,
      perTokenRewards,
      effectiveApys,
      lockMultiplier,
      veBoost,
      totalEffectiveMultiplier: lockMultiplier * veBoost,
    };
  }, [pool, stakeAmount, lockTier, veTokenAmount, days]);

  if (!pool) return null;

  return (
    <div>
      <h2 className="text-lg font-bold mb-24">APY Calculator</h2>

      <div className="grid grid-2 gap-24">
        <div>
          <div className="card mb-24">
            <h3 className="font-semibold mb-16">Configure</h3>

            <div className="mb-16">
              <label className="text-xs text-secondary" style={{ display: 'block', marginBottom: 8 }}>
                Select Pool
              </label>
              <select
                className="input"
                value={selectedPool}
                onChange={(e) => setSelectedPool(parseInt(e.target.value))}
              >
                {pools.map((p, i) => (
                  <option key={p.id} value={i}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="mb-16">
              <label className="text-xs text-secondary" style={{ display: 'block', marginBottom: 8 }}>
                Stake Amount
              </label>
              <input
                type="number"
                className="input"
                value={stakeAmount}
                onChange={(e) => setStakeAmount(e.target.value)}
                min={0}
              />
            </div>

            <div className="mb-16">
              <label className="text-xs text-secondary" style={{ display: 'block', marginBottom: 8 }}>
                Lock Period
              </label>
              <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(90px, 1fr))', gap: 8 }}>
                {pool.lockTiers.map((tier, i) => (
                  <button
                    key={i}
                    className={`btn ${lockTier === i ? 'btn-primary' : 'btn-secondary'}`}
                    style={{ padding: '8px', fontSize: 12 }}
                    onClick={() => setLockTier(i)}
                  >
                    <div>{tier.label}</div>
                    <div className="text-xs" style={{ opacity: 0.8 }}>
                      {tier.multiplier}x
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="mb-16">
              <label className="text-xs text-secondary" style={{ display: 'block', marginBottom: 8 }}>
                veToken Balance
              </label>
              <input
                type="number"
                className="input"
                value={veTokenAmount}
                onChange={(e) => setVeTokenAmount(e.target.value)}
                min={0}
              />
            </div>

            <div>
              <label className="text-xs text-secondary" style={{ display: 'block', marginBottom: 8 }}>
                Time Period (days)
              </label>
              <input
                type="number"
                className="input"
                value={days}
                onChange={(e) => setDays(e.target.value)}
                min={1}
                max={3650}
              />
            </div>
          </div>
        </div>

        <div>
          {calculations && (
            <>
              <div className="card mb-24">
                <h3 className="font-semibold mb-16">Effective APY</h3>
                {calculations.effectiveApys.map((apy, i) => (
                  <div key={i} className="flex justify-between items-center mb-8">
                    <span className="text-secondary text-sm">
                      {pool.rewardSymbols[i]}
                    </span>
                    <span className="font-bold text-success text-lg">
                      {apy.toFixed(2)}%
                    </span>
                  </div>
                ))}
              </div>

              <div className="card mb-24">
                <h3 className="font-semibold mb-16">Boost Multipliers</h3>
                <div className="flex justify-between text-sm mb-8">
                  <span className="text-secondary">Lock Boost</span>
                  <span className="font-bold text-warning">
                    {calculations.lockMultiplier}x
                  </span>
                </div>
                <div className="flex justify-between text-sm mb-8">
                  <span className="text-secondary">veToken Boost</span>
                  <span className="font-bold text-accent">
                    {calculations.veBoost.toFixed(3)}x
                  </span>
                </div>
                <div
                  className="flex justify-between text-sm"
                  style={{ borderTop: '1px solid var(--border)', paddingTop: 8, marginTop: 8 }}
                >
                  <span className="text-secondary">Total Effective</span>
                  <span className="font-bold text-success">
                    {calculations.totalEffectiveMultiplier.toFixed(3)}x
                  </span>
                </div>
              </div>

              <div className="card mb-24">
                <h3 className="font-semibold mb-16">Projected Rewards</h3>
                {pool.rewardSymbols.map((sym, i) => (
                  <div key={i} className="mb-16">
                    <div className="flex justify-between text-sm mb-4">
                      <span className="text-secondary">
                        Base ({sym})
                      </span>
                      <span>{formatNumber(calculations.baseRewards[i])}</span>
                    </div>
                    <div className="flex justify-between text-sm mb-4">
                      <span className="text-secondary">After Boost</span>
                      <span className="font-bold text-success">
                        {formatNumber(calculations.boostedRewards[i])}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-secondary">
                        Your Share ({stakeAmount} tokens)
                      </span>
                      <span className="font-bold text-accent">
                        {formatNumber(calculations.perTokenRewards[i])} {sym}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="card">
                <h3 className="font-semibold mb-16">Pool Info</h3>
                <div className="flex justify-between text-sm mb-8">
                  <span className="text-secondary">Reward Rate</span>
                  <span>
                    {pool.rewardRatePerSecond
                      .map((r, i) => `${r.toFixed(4)} ${pool.rewardSymbols[i]}/sec`)
                      .join(', ')}
                  </span>
                </div>
                <div className="flex justify-between text-sm mb-8">
                  <span className="text-secondary">Total Staked</span>
                  <span>{formatNumber(pool.totalStaked)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-secondary">Auto-Compound</span>
                  <span>{pool.autoCompound ? 'Yes' : 'No'}</span>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
