import { Link } from 'react-router-dom';
import { useStaking } from '../contexts/StakingContext';
import { useWallet } from '../contexts/WalletContext';
import { formatNumber } from '../types';
import type { PoolInfo } from '../types';

function PoolCard({ pool }: { pool: PoolInfo }) {
  const typeBadge: Record<string, string> = {
    single: 'badge-purple',
    lp: 'badge-green',
    nft: 'badge-gold',
  };
  const typeLabel: Record<string, string> = {
    single: 'Single Token',
    lp: 'LP Staking',
    nft: 'NFT Staking',
  };

  return (
    <div className="card">
      <div className="flex justify-between items-center mb-16">
        <h3 className="font-bold text-lg">{pool.name}</h3>
        <span className={`badge ${typeBadge[pool.type]}`}>
          {typeLabel[pool.type]}
        </span>
      </div>

      <div className="grid grid-2 gap-16 mb-16">
        <div>
          <div className="text-xs text-secondary mb-8">TVL</div>
          <div className="font-bold">${formatNumber(pool.tvl)}</div>
        </div>
        <div>
          <div className="text-xs text-secondary mb-8">Base APY</div>
          <div className="font-bold text-success">
            {pool.apy.map((a) => `${a}%`).join(' + ')}
          </div>
        </div>
        <div>
          <div className="text-xs text-secondary mb-8">Total Staked</div>
          <div className="font-semibold">{formatNumber(pool.totalStaked)}</div>
        </div>
        <div>
          <div className="text-xs text-secondary mb-8">Rewards</div>
          <div className="font-semibold">{pool.rewardSymbols.join(', ')}</div>
        </div>
      </div>

      <div className="flex gap-8 mb-16" style={{ flexWrap: 'wrap' }}>
        {pool.autoCompound && <span className="badge badge-green">Auto-Compound</span>}
        {pool.veTokenBoost && <span className="badge badge-purple">veToken Boost</span>}
        {pool.lockTiers.length > 1 && (
          <span className="badge badge-gold">
            Up to {pool.lockTiers[pool.lockTiers.length - 1].multiplier}x Boost
          </span>
        )}
      </div>

      <div className="text-xs text-secondary mb-16">
        Max lock boost: {pool.lockTiers[pool.lockTiers.length - 1].multiplier}x (
        {pool.lockTiers[pool.lockTiers.length - 1].label})
      </div>

      <Link
        to={`/stake/${pool.id}`}
        className="btn btn-primary w-full"
        style={{ display: 'block', textAlign: 'center' }}
      >
        Stake Now
      </Link>
    </div>
  );
}

export default function PoolDiscovery() {
  const { pools } = useStaking();
  const { connected } = useWallet();

  const totalTvl = pools.reduce((sum, p) => sum + p.tvl, 0);

  return (
    <div>
      <div
        className="card mb-24"
        style={{
          background: 'linear-gradient(135deg, rgba(153,69,255,0.15), rgba(20,241,149,0.1))',
        }}
      >
        <h1 className="text-xl font-bold mb-16">Solana Staking Platform</h1>
        <div className="grid grid-4 gap-16">
          <div>
            <div className="text-xs text-secondary">Total Value Locked</div>
            <div className="font-bold text-lg">${formatNumber(totalTvl)}</div>
          </div>
          <div>
            <div className="text-xs text-secondary">Active Pools</div>
            <div className="font-bold text-lg">{pools.length}</div>
          </div>
          <div>
            <div className="text-xs text-secondary">Reward Tokens</div>
            <div className="font-bold text-lg">
              {new Set(pools.flatMap((p) => p.rewardSymbols)).size}
            </div>
          </div>
          <div>
            <div className="text-xs text-secondary">Max Boost</div>
            <div className="font-bold text-lg text-warning">3.0x</div>
          </div>
        </div>
      </div>

      <div className="flex justify-between items-center mb-24">
        <h2 className="text-lg font-bold">Staking Pools</h2>
        {!connected && (
          <span className="text-sm text-secondary">
            Connect wallet to start staking
          </span>
        )}
      </div>

      <div className="grid grid-2">
        {pools.map((pool) => (
          <PoolCard key={pool.id} pool={pool} />
        ))}
      </div>
    </div>
  );
}
