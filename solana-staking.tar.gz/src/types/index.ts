export type PoolType = "single" | "lp" | "nft";

export type LockTier = "none" | "flexible" | "locked_30d" | "locked_90d" | "locked_180d" | "locked_365d";

export interface LockTierConfig {
  tier: LockTier;
  lockDurationSeconds: number;
  boostMultiplier: number;
  label: string;
}

export interface RewardToken {
  mint: string;
  symbol: string;
  decimals: number;
  rewardRatePerSecond: number;
  remainingRewards: number;
}

export interface StakingPool {
  id: string;
  name: string;
  poolType: PoolType;
  stakingMint: string;
  stakingTokenSymbol: string;
  stakingTokenDecimals: number;
  totalStaked: number;
  tvlUSD: number;
  rewardTokens: RewardToken[];
  lockTiers: LockTierConfig[];
  autoCompound: boolean;
  veTokenEnabled: boolean;
  referralEnabled: boolean;
  createdAt: number;
  status: "active" | "paused" | "ended";
}

export interface UserPosition {
  id: string;
  poolId: string;
  poolName: string;
  stakedAmount: number;
  lockTier: LockTier;
  lockEndDate: number | null;
  pendingRewards: PendingReward[];
  stakedAt: number;
  boostMultiplier: number;
  nftMint?: string;
}

export interface PendingReward {
  mint: string;
  symbol: string;
  amount: number;
  usdValue: number;
}

export interface RewardHistory {
  id: string;
  poolId: string;
  poolName: string;
  tokenSymbol: string;
  amount: number;
  usdValue: number;
  claimedAt: number;
  txHash: string;
}

export interface Proposal {
  id: string;
  title: string;
  description: string;
  proposer: string;
  status: "active" | "passed" | "failed" | "executed";
  votesFor: number;
  votesAgainst: number;
  startTime: number;
  endTime: number;
  quorum: number;
}

export interface ReferralStats {
  referralCode: string;
  totalReferrals: number;
  totalEarned: number;
  pendingRewards: number;
  tier: number;
}

export interface NFTStakingInfo {
  mint: string;
  name: string;
  image: string;
  collection: string;
  stakedPoolId: string | null;
  boostPercentage: number;
}

export const LOCK_TIERS: LockTierConfig[] = [
  { tier: "flexible", lockDurationSeconds: 0, boostMultiplier: 1.0, label: "Flexible" },
  { tier: "locked_30d", lockDurationSeconds: 30 * 86400, boostMultiplier: 1.2, label: "30 Days" },
  { tier: "locked_90d", lockDurationSeconds: 90 * 86400, boostMultiplier: 1.5, label: "90 Days" },
  { tier: "locked_180d", lockDurationSeconds: 180 * 86400, boostMultiplier: 2.0, label: "180 Days" },
  { tier: "locked_365d", lockDurationSeconds: 365 * 86400, boostMultiplier: 3.0, label: "365 Days" },
];

export const MOCK_POOLS: StakingPool[] = [
  {
    id: "pool-1",
    name: "SOL Staking Pool",
    poolType: "single",
    stakingMint: "So11111111111111111111111111111111111111112",
    stakingTokenSymbol: "SOL",
    stakingTokenDecimals: 9,
    totalStaked: 1250000,
    tvlUSD: 187500000,
    rewardTokens: [
      { mint: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", symbol: "USDC", decimals: 6, rewardRatePerSecond: 0.5, remainingRewards: 5000000 },
      { mint: "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263", symbol: "BONK", decimals: 5, rewardRatePerSecond: 10000, remainingRewards: 100000000000 },
    ],
    lockTiers: LOCK_TIERS,
    autoCompound: true,
    veTokenEnabled: true,
    referralEnabled: true,
    createdAt: Date.now() - 86400000 * 90,
    status: "active",
  },
  {
    id: "pool-2",
    name: "SOL-USDC LP Pool",
    poolType: "lp",
    stakingMint: "LP1mShRTYkL7kCqtnBdFgDn3Fxt2jUzQBdYqoRLJ8E4",
    stakingTokenSymbol: "SOL-USDC LP",
    stakingTokenDecimals: 9,
    totalStaked: 500000,
    tvlUSD: 75000000,
    rewardTokens: [
      { mint: "So11111111111111111111111111111111111111112", symbol: "SOL", decimals: 9, rewardRatePerSecond: 0.1, remainingRewards: 1000000 },
    ],
    lockTiers: LOCK_TIERS,
    autoCompound: false,
    veTokenEnabled: false,
    referralEnabled: true,
    createdAt: Date.now() - 86400000 * 60,
    status: "active",
  },
  {
    id: "pool-3",
    name: "NFT Staking Pool",
    poolType: "nft",
    stakingMint: "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
    stakingTokenSymbol: "BONK",
    stakingTokenDecimals: 5,
    totalStaked: 100000000,
    tvlUSD: 1500000,
    rewardTokens: [
      { mint: "So11111111111111111111111111111111111111112", symbol: "SOL", decimals: 9, rewardRatePerSecond: 0.05, remainingRewards: 500000 },
    ],
    lockTiers: [LOCK_TIERS[0], LOCK_TIERS[2], LOCK_TIERS[4]],
    autoCompound: false,
    veTokenEnabled: false,
    referralEnabled: false,
    createdAt: Date.now() - 86400000 * 30,
    status: "active",
  },
  {
    id: "pool-4",
    name: "JITO Staking Pool",
    poolType: "single",
    stakingMint: "J1toso1uCk3RLmjorhTtrMwRxnj4BBq2S7gKgJiYbqVW",
    stakingTokenSymbol: "JitoSOL",
    stakingTokenDecimals: 9,
    totalStaked: 800000,
    tvlUSD: 128000000,
    rewardTokens: [
      { mint: "J1toso1uCk3RLmjorhTtrMwRxnj4BBq2S7gKgJiYbqVW", symbol: "JitoSOL", decimals: 9, rewardRatePerSecond: 0.2, remainingRewards: 2000000 },
    ],
    lockTiers: LOCK_TIERS,
    autoCompound: true,
    veTokenEnabled: true,
    referralEnabled: true,
    createdAt: Date.now() - 86400000 * 45,
    status: "active",
  },
];
