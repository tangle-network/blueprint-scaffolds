export interface PoolInfo {
  id: string;
  name: string;
  type: 'single' | 'lp' | 'nft';
  stakeMint: string;
  rewardMints: string[];
  rewardSymbols: string[];
  tvl: number;
  totalStaked: number;
  apy: number[];
  lockTiers: LockTier[];
  rewardRatePerSecond: number[];
  minStake: number;
  maxStake: number;
  autoCompound: boolean;
  veTokenBoost: boolean;
  isActive: boolean;
  createdAt: number;
}

export interface LockTier {
  durationDays: number;
  multiplier: number;
  label: string;
}

export interface UserStake {
  poolId: string;
  amount: number;
  lockTier: number;
  lockEnd: number;
  startTime: number;
  pendingRewards: number[];
  veBalance: number;
  referralCount: number;
  referralRewards: number;
}

export interface GovernanceProposal {
  id: string;
  title: string;
  description: string;
  proposer: string;
  voteFor: number;
  voteAgainst: number;
  status: 'active' | 'passed' | 'failed' | 'executed';
  startTime: number;
  endTime: number;
  userVote?: 'for' | 'against' | null;
}

export interface VeTokenInfo {
  balance: number;
  lockedAmount: number;
  lockEnd: number;
  votingPower: number;
  decayRate: number;
}

export const LOCK_TIERS: LockTier[] = [
  { durationDays: 0, multiplier: 1.0, label: 'Flexible' },
  { durationDays: 30, multiplier: 1.25, label: '30 Days' },
  { durationDays: 90, multiplier: 1.6, label: '90 Days' },
  { durationDays: 180, multiplier: 2.0, label: '180 Days' },
  { durationDays: 365, multiplier: 3.0, label: '1 Year' },
];

export const MOCK_POOLS: PoolInfo[] = [
  {
    id: 'pool-sol-1',
    name: 'SOL Staking Pool',
    type: 'single',
    stakeMint: 'So11111111111111111111111111111111111111112',
    rewardMints: ['EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v'],
    rewardSymbols: ['USDC'],
    tvl: 5_200_000,
    totalStaked: 32_500,
    apy: [8.5],
    lockTiers: LOCK_TIERS,
    rewardRatePerSecond: [0.013],
    minStake: 0.1,
    maxStake: 10000,
    autoCompound: true,
    veTokenBoost: true,
    isActive: true,
    createdAt: Date.now() - 86400000 * 90,
  },
  {
    id: 'pool-lp-1',
    name: 'SOL/USDC LP Pool',
    type: 'lp',
    stakeMint: 'Es9vMFrzaCERmLfJLkqN8fdcpiVEYGBhXDe3abGm4tpA',
    rewardMints: ['So11111111111111111111111111111111111111112', 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v'],
    rewardSymbols: ['SOL', 'USDC'],
    tvl: 12_800_000,
    totalStaked: 80_000,
    apy: [12.3, 5.7],
    lockTiers: LOCK_TIERS,
    rewardRatePerSecond: [0.04, 0.8],
    minStake: 0.01,
    maxStake: 100000,
    autoCompound: true,
    veTokenBoost: true,
    isActive: true,
    createdAt: Date.now() - 86400000 * 60,
  },
  {
    id: 'pool-nft-1',
    name: 'DeGods NFT Staking',
    type: 'nft',
    stakeMint: '6XxjKYFbcndDdMwkFh5fM2fMVpvh5q1hM6DgsMjTbGN3',
    rewardMints: ['DUSTawucrTsGUgbhc2RcHKxrSjQQg6H7bZ5mQxwCXGqR'],
    rewardSymbols: ['DUST'],
    tvl: 2_400_000,
    totalStaked: 1200,
    apy: [22.0],
    lockTiers: [
      { durationDays: 0, multiplier: 1.0, label: 'Flexible' },
      { durationDays: 30, multiplier: 1.5, label: '30 Days' },
      { durationDays: 90, multiplier: 2.2, label: '90 Days' },
      { durationDays: 180, multiplier: 3.0, label: '180 Days' },
    ],
    rewardRatePerSecond: [0.06],
    minStake: 1,
    maxStake: 100,
    autoCompound: false,
    veTokenBoost: true,
    isActive: true,
    createdAt: Date.now() - 86400000 * 120,
  },
  {
    id: 'pool-token-1',
    name: 'mSOL Staking',
    type: 'single',
    stakeMint: 'mSoLzYCxHdYgdzU16g5QSh3GgiqK7RFDjL5b7jHBzxh',
    rewardMints: ['mSoLzYCxHdYgdzU16g5QSh3GgiqK7RFDjL5b7jHBzxh', 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v'],
    rewardSymbols: ['mSOL', 'USDC'],
    tvl: 8_900_000,
    totalStaked: 55_000,
    apy: [6.2, 2.1],
    lockTiers: LOCK_TIERS,
    rewardRatePerSecond: [0.01, 0.3],
    minStake: 0.01,
    maxStake: 50000,
    autoCompound: true,
    veTokenBoost: true,
    isActive: true,
    createdAt: Date.now() - 86400000 * 45,
  },
];

export const MOCK_PROPOSALS: GovernanceProposal[] = [
  {
    id: 'prop-1',
    title: 'Increase SOL Pool APY by 2%',
    description: 'Proposal to increase the SOL staking pool base APY from 8.5% to 10.5% by allocating additional treasury funds to the reward reserve.',
    proposer: '7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU',
    voteFor: 2_450_000,
    voteAgainst: 320_000,
    status: 'active',
    startTime: Date.now() - 86400000 * 2,
    endTime: Date.now() + 86400000 * 5,
  },
  {
    id: 'prop-2',
    title: 'Add BONK as Reward Token',
    description: 'Proposal to add BONK as a reward token to the SOL/USDC LP pool, providing additional incentives for liquidity providers.',
    proposer: 'DRpbCBMxVnDK7maPMoGQfFiB4P4cByAHpLMkP1g8vAJw',
    voteFor: 5_100_000,
    voteAgainst: 890_000,
    status: 'passed',
    startTime: Date.now() - 86400000 * 10,
    endTime: Date.now() - 86400000 * 3,
  },
  {
    id: 'prop-3',
    title: 'Reduce Flexible Lock Penalty',
    description: 'Reduce the penalty for flexible (no-lock) stakers from 1.0x to 0.8x multiplier to incentivize longer lock periods.',
    proposer: 'CcynPupcmYGrKmN7kqVGJ33nCKhUiy2gSPa72yEQazz5',
    voteFor: 1_100_000,
    voteAgainst: 3_200_000,
    status: 'failed',
    startTime: Date.now() - 86400000 * 20,
    endTime: Date.now() - 86400000 * 13,
  },
];

export function formatNumber(n: number, decimals = 2): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(decimals)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(decimals)}K`;
  return n.toFixed(decimals);
}

export function formatAddress(addr: string): string {
  return `${addr.slice(0, 4)}...${addr.slice(-4)}`;
}

export function formatCountdown(ms: number): string {
  if (ms <= 0) return 'Ended';
  const days = Math.floor(ms / 86400000);
  const hours = Math.floor((ms % 86400000) / 3600000);
  const mins = Math.floor((ms % 3600000) / 60000);
  if (days > 0) return `${days}d ${hours}h`;
  if (hours > 0) return `${hours}h ${mins}m`;
  return `${mins}m`;
}

export function calculateApy(
  rewardRatePerSecond: number,
  totalStaked: number,
  rewardPrice: number,
  stakePrice: number
): number {
  if (totalStaked === 0) return 0;
  const yearlyRewards = rewardRatePerSecond * 86400 * 365;
  const yearlyValue = yearlyRewards * rewardPrice;
  const stakedValue = totalStaked * stakePrice;
  return (yearlyValue / stakedValue) * 100;
}
