import { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import {
  PoolInfo,
  UserStake,
  VeTokenInfo,
  GovernanceProposal,
  MOCK_POOLS,
  MOCK_PROPOSALS,
} from '../types';

interface StakingContextType {
  pools: PoolInfo[];
  userStakes: UserStake[];
  veToken: VeTokenInfo;
  proposals: GovernanceProposal[];
  stake: (poolId: string, amount: number, lockTier: number) => void;
  unstake: (poolId: string, amount: number) => void;
  claimRewards: (poolId: string) => void;
  compound: (poolId: string) => void;
  vote: (proposalId: string, support: boolean) => void;
  referralCode: string;
  generateReferral: () => string;
}

const defaultVeToken: VeTokenInfo = {
  balance: 0,
  lockedAmount: 0,
  lockEnd: 0,
  votingPower: 0,
  decayRate: 0,
};

const StakingContext = createContext<StakingContextType>({
  pools: [],
  userStakes: [],
  veToken: defaultVeToken,
  proposals: [],
  stake: () => {},
  unstake: () => {},
  claimRewards: () => {},
  compound: () => {},
  vote: () => {},
  referralCode: '',
  generateReferral: () => '',
});

export function StakingProvider({ children }: { children: ReactNode }) {
  const [pools] = useState<PoolInfo[]>(MOCK_POOLS);
  const [userStakes, setUserStakes] = useState<UserStake[]>([
    {
      poolId: 'pool-sol-1',
      amount: 12.5,
      lockTier: 2,
      lockEnd: Date.now() + 86400000 * 45,
      startTime: Date.now() - 86400000 * 45,
      pendingRewards: [3.47],
      veBalance: 125,
      referralCount: 3,
      referralRewards: 1.2,
    },
    {
      poolId: 'pool-lp-1',
      amount: 250,
      lockTier: 3,
      lockEnd: Date.now() + 86400000 * 120,
      startTime: Date.now() - 86400000 * 60,
      pendingRewards: [4.82, 95.6],
      veBalance: 380,
      referralCount: 0,
      referralRewards: 0,
    },
  ]);
  const [veToken] = useState<VeTokenInfo>({
    balance: 505,
    lockedAmount: 500,
    lockEnd: Date.now() + 86400000 * 180,
    votingPower: 505,
    decayRate: 0.0027,
  });
  const [proposals, setProposals] = useState<GovernanceProposal[]>(MOCK_PROPOSALS);
  const [referralCode] = useState('STAKE-7xKX-2024');

  const stake = useCallback((poolId: string, amount: number, lockTier: number) => {
    setUserStakes((prev) => {
      const existing = prev.find((s) => s.poolId === poolId);
      if (existing) {
        return prev.map((s) =>
          s.poolId === poolId ? { ...s, amount: s.amount + amount, lockTier } : s
        );
      }
      return [
        ...prev,
        {
          poolId,
          amount,
          lockTier,
          lockEnd: lockTier > 0 ? Date.now() + 86400000 * [0, 30, 90, 180, 365][lockTier] : 0,
          startTime: Date.now(),
          pendingRewards: pools.find((p) => p.id === poolId)?.rewardMints.map(() => 0) ?? [],
          veBalance: 0,
          referralCount: 0,
          referralRewards: 0,
        },
      ];
    });
  }, [pools]);

  const unstake = useCallback((poolId: string, amount: number) => {
    setUserStakes((prev) =>
      prev
        .map((s) => (s.poolId === poolId ? { ...s, amount: s.amount - amount } : s))
        .filter((s) => s.amount > 0)
    );
  }, []);

  const claimRewards = useCallback((poolId: string) => {
    setUserStakes((prev) =>
      prev.map((s) =>
        s.poolId === poolId ? { ...s, pendingRewards: s.pendingRewards.map(() => 0) } : s
      )
    );
  }, []);

  const compound = useCallback((poolId: string) => {
    setUserStakes((prev) =>
      prev.map((s) => {
        if (s.poolId !== poolId) return s;
        const rewardValue = s.pendingRewards.reduce((a, b) => a + b, 0);
        return {
          ...s,
          amount: s.amount + rewardValue * 0.01,
          pendingRewards: s.pendingRewards.map(() => 0),
        };
      })
    );
  }, []);

  const vote = useCallback((proposalId: string, support: boolean) => {
    setProposals((prev) =>
      prev.map((p) =>
        p.id === proposalId
          ? {
              ...p,
              userVote: support ? 'for' : 'against',
              voteFor: support ? p.voteFor + 100 : p.voteFor,
              voteAgainst: support ? p.voteAgainst : p.voteAgainst + 100,
            }
          : p
      )
    );
  }, []);

  const generateReferral = useCallback(() => {
    return referralCode;
  }, [referralCode]);

  return (
    <StakingContext.Provider
      value={{
        pools,
        userStakes,
        veToken,
        proposals,
        stake,
        unstake,
        claimRewards,
        compound,
        vote,
        referralCode,
        generateReferral,
      }}
    >
      {children}
    </StakingContext.Provider>
  );
}

export function useStaking() {
  return useContext(StakingContext);
}
