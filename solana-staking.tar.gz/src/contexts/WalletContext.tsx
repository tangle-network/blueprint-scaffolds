import { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { Connection, PublicKey, clusterApiUrl } from '@solana/web3.js';

interface WalletContextType {
  connection: Connection;
  connected: boolean;
  publicKey: PublicKey | null;
  connect: () => void;
  disconnect: () => void;
  balance: number;
}

const WalletContext = createContext<WalletContextType>({
  connection: new Connection(clusterApiUrl('devnet')),
  connected: false,
  publicKey: null,
  connect: () => {},
  disconnect: () => {},
  balance: 0,
});

export function ConnectionProvider({ children }: { children: ReactNode }) {
  const [connection] = useState(() => new Connection(clusterApiUrl('devnet')));
  return (
    <WalletContext.Provider value={{ ...useContext(WalletContext), connection }}>
      {children}
    </WalletContext.Provider>
  );
}

export function WalletProvider({ children }: { children: ReactNode }) {
  const ctx = useContext(WalletContext);
  const [connected, setConnected] = useState(false);
  const [publicKey, setPublicKey] = useState<PublicKey | null>(null);
  const [balance, setBalance] = useState(24.85);

  const connect = useCallback(() => {
    const demoKey = new PublicKey('7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU');
    setPublicKey(demoKey);
    setConnected(true);
    setBalance(24.85);
  }, []);

  const disconnect = useCallback(() => {
    setPublicKey(null);
    setConnected(false);
    setBalance(0);
  }, []);

  return (
    <WalletContext.Provider value={{ ...ctx, connected, publicKey, connect, disconnect, balance }}>
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  return useContext(WalletContext);
}
