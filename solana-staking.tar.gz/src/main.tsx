import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import { ConnectionProvider, WalletProvider } from './contexts/WalletContext';
import { StakingProvider } from './contexts/StakingContext';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <BrowserRouter>
      <ConnectionProvider>
        <WalletProvider>
          <StakingProvider>
            <App />
          </StakingProvider>
        </WalletProvider>
      </ConnectionProvider>
    </BrowserRouter>
  </React.StrictMode>
);
