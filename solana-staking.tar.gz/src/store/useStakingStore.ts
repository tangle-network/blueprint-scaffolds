import { create } from 'zustand';
import { pools } from '../data/pools';
import type { Pool } from '../types';

type StakingState = {
  pools: Pool[];
  selectedPoolId: string;
  depositAmount: number;
  selectedTierId: string;
  autoCompound: boolean;
  includeNftBoost: boolean;
  referralCode: string;
  setSelectedPool: (poolId: string) => void;
  setDepositAmount: (amount: number) => void;
  setSelectedTier: (tierId: string) => void;
  setAutoCompound: (enabled: boolean) => void;
  setIncludeNftBoost: (enabled: boolean) => void;
  setReferralCode: (code: string) => void;
};

const initialPool = pools[0];

export const useStakingStore = create<StakingState>((set) => ({
  pools,
  selectedPoolId: initialPool.id,
  depositAmount: 2500,
  selectedTierId: initialPool.lockTiers[2].id,
  autoCompound: true,
  includeNftBoost: true,
  referralCode: 'ATLAS-OG',
  setSelectedPool: (poolId) =>
    set((state) => {
      const pool = state.pools.find((item) => item.id === poolId) ?? state.pools[0];
      const fallbackTier = pool.lockTiers[0];

      return {
        selectedPoolId: pool.id,
        selectedTierId: fallbackTier.id,
        autoCompound: pool.autoCompound
      };
    }),
  setDepositAmount: (amount) => set({ depositAmount: amount }),
  setSelectedTier: (tierId) => set({ selectedTierId: tierId }),
  setAutoCompound: (enabled) => set({ autoCompound: enabled }),
  setIncludeNftBoost: (enabled) => set({ includeNftBoost: enabled }),
  setReferralCode: (code) => set({ referralCode: code })
}));
