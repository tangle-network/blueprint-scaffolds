import clsx from 'clsx';
import type { Pool } from '../types';
import { compactNumber, currency, percentage } from '../lib/format';
import { calculateEmissionApr } from '../lib/calculations';

type PoolDiscoveryProps = {
  pools: Pool[];
  selectedPoolId: string;
  onSelectPool: (poolId: string) => void;
};

const categoryLabels: Record<Pool['category'], string> = {
  single: 'Single Token',
  lp: 'LP Staking',
  nft: 'NFT Rewards'
};

export function PoolDiscovery({ pools, selectedPoolId, onSelectPool }: PoolDiscoveryProps) {
  return (
    <section className="panel">
      <div className="section-heading">
        <div>
          <span className="eyebrow">Pool discovery</span>
          <h2>Curated staking vaults</h2>
        </div>
      </div>
      <div className="pool-grid">
        {pools.map((pool) => (
          <button
            key={pool.id}
            type="button"
            className={clsx('pool-card', selectedPoolId === pool.id && 'selected')}
            onClick={() => onSelectPool(pool.id)}
          >
            <div className="pool-topline">
              <span>{categoryLabels[pool.category]}</span>
              <span>{percentage(pool.baseApr + calculateEmissionApr(pool))}</span>
            </div>
            <h3>{pool.name}</h3>
            <p>{pool.tokenSymbol}</p>
            <dl>
              <div>
                <dt>TVL</dt>
                <dd>{currency(pool.tvl)}</dd>
              </div>
              <div>
                <dt>Rewards</dt>
                <dd>{pool.rewardTokens.map((token) => token.symbol).join(' + ')}</dd>
              </div>
              <div>
                <dt>Utilization</dt>
                <dd>{compactNumber(pool.utilization * 100)}%</dd>
              </div>
            </dl>
          </button>
        ))}
      </div>
    </section>
  );
}
