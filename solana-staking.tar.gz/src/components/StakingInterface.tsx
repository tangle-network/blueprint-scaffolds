import type { ChangeEvent } from 'react';
import type { LockTier, Pool } from '../types';
import { currency, percentage } from '../lib/format';
import { calculateBoostedApr, estimateVeTokens, projectAnnualRewards } from '../lib/calculations';

type StakingInterfaceProps = {
  pool: Pool;
  selectedTier: LockTier;
  depositAmount: number;
  autoCompound: boolean;
  includeNftBoost: boolean;
  referralCode: string;
  onDepositAmount: (amount: number) => void;
  onTierChange: (tierId: string) => void;
  onAutoCompound: (value: boolean) => void;
  onIncludeNftBoost: (value: boolean) => void;
  onReferralCode: (value: string) => void;
};

export function StakingInterface({
  pool,
  selectedTier,
  depositAmount,
  autoCompound,
  includeNftBoost,
  referralCode,
  onDepositAmount,
  onTierChange,
  onAutoCompound,
  onIncludeNftBoost,
  onReferralCode
}: StakingInterfaceProps) {
  const apr = calculateBoostedApr(pool, selectedTier, includeNftBoost, autoCompound);
  const projectedRewards = projectAnnualRewards(depositAmount, apr);
  const veEstimate = estimateVeTokens(depositAmount, selectedTier);

  const handleDepositChange = (event: ChangeEvent<HTMLInputElement>) => {
    onDepositAmount(Number(event.target.value));
  };

  return (
    <section className="panel staking-panel">
      <div className="section-heading">
        <div>
          <span className="eyebrow">Stake interface</span>
          <h2>{pool.name}</h2>
        </div>
        <div className="badge-row">
          <span className="badge">Per-second rewards</span>
          <span className="badge">{pool.rewardTokens.length} reward tokens</span>
          {pool.autoCompound ? <span className="badge">Auto-compound ready</span> : null}
        </div>
      </div>

      <div className="stake-layout">
        <div className="form-card">
          <label>
            Deposit amount
            <input
              type="number"
              min="0"
              step="1"
              value={depositAmount}
              onChange={handleDepositChange}
            />
          </label>

          <div className="tier-list">
            {pool.lockTiers.map((tier) => (
              <label key={tier.id} className={`tier-card ${selectedTier.id === tier.id ? 'active' : ''}`}>
                <input
                  type="radio"
                  name="tier"
                  checked={selectedTier.id === tier.id}
                  onChange={() => onTierChange(tier.id)}
                />
                <div>
                  <strong>{tier.label}</strong>
                  <span>{tier.days ? `${tier.days} day lock` : 'No lock'}</span>
                </div>
                <em>{tier.boost.toFixed(2)}x boost</em>
              </label>
            ))}
          </div>

          <label className="switch">
            <input
              type="checkbox"
              checked={autoCompound}
              onChange={(event) => onAutoCompound(event.target.checked)}
            />
            Enable auto-compound
          </label>

          <label className="switch">
            <input
              type="checkbox"
              checked={includeNftBoost}
              onChange={(event) => onIncludeNftBoost(event.target.checked)}
            />
            Apply NFT loyalty boost
          </label>

          <label>
            Referral code
            <input value={referralCode} onChange={(event) => onReferralCode(event.target.value)} />
          </label>
        </div>

        <div className="summary-card">
          <div className="summary-grid">
            <div>
              <span>Boosted APR</span>
              <strong>{percentage(apr)}</strong>
            </div>
            <div>
              <span>Projected annual rewards</span>
              <strong>{currency(projectedRewards)}</strong>
            </div>
            <div>
              <span>veATLAS minted</span>
              <strong>{veEstimate.toFixed(0)}</strong>
            </div>
            <div>
              <span>Referral rebate share</span>
              <strong>{percentage(pool.referralRate * 100)}</strong>
            </div>
          </div>

          <div className="reward-stack">
            {pool.rewardTokens.map((token) => (
              <div key={token.symbol} className="reward-token">
                <span>{token.symbol}</span>
                <strong>
                  {token.dailyEmission.toLocaleString()} / day
                </strong>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
