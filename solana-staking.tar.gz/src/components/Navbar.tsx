import { Link, useLocation } from 'react-router-dom';
import { useWallet } from '../contexts/WalletContext';
import { formatAddress } from '../types';

export default function Navbar() {
  const { connected, publicKey, connect, disconnect, balance } = useWallet();
  const location = useLocation();

  const links = [
    { to: '/', label: 'Pools' },
    { to: '/stake', label: 'Stake' },
    { to: '/rewards', label: 'Rewards' },
    { to: '/governance', label: 'Governance' },
    { to: '/calculator', label: 'APY Calculator' },
  ];

  return (
    <nav
      style={{
        background: 'var(--bg-secondary)',
        borderBottom: '1px solid var(--border)',
        padding: '0 24px',
        position: 'sticky',
        top: 0,
        zIndex: 100,
      }}
    >
      <div
        className="container flex items-center justify-between"
        style={{ height: 64 }}
      >
        <div className="flex items-center gap-24">
          <Link
            to="/"
            style={{
              fontSize: 20,
              fontWeight: 800,
              background: 'linear-gradient(135deg, #9945ff, #14f195)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            SolStake
          </Link>
          <div className="flex gap-16">
            {links.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                style={{
                  color:
                    location.pathname === link.to
                      ? 'var(--accent)'
                      : 'var(--text-secondary)',
                  fontWeight: location.pathname === link.to ? 600 : 400,
                  fontSize: 14,
                  transition: 'color 0.2s',
                }}
              >
                {link.label}
              </Link>
            ))}
          </div>
        </div>
        <div className="flex items-center gap-16">
          {connected ? (
            <>
              <span className="text-sm text-secondary">
                {balance.toFixed(2)} SOL
              </span>
              <span
                className="text-sm"
                style={{
                  padding: '6px 12px',
                  background: 'var(--bg-card)',
                  borderRadius: 8,
                  border: '1px solid var(--border)',
                }}
              >
                {formatAddress(publicKey!.toBase58())}
              </span>
              <button className="btn btn-secondary" onClick={disconnect}>
                Disconnect
              </button>
            </>
          ) : (
            <button className="btn btn-primary" onClick={connect}>
              Connect Wallet
            </button>
          )}
        </div>
      </div>
    </nav>
  );
}
