import type { Pool } from '../types';

type GovernancePanelProps = {
  pool: Pool;
};

export function GovernancePanel({ pool }: GovernancePanelProps) {
  return (
    <section className="panel governance-grid">
      <div>
        <span className="eyebrow">Governance integration</span>
        <h2>veToken aligned voting</h2>
        <p className="panel-copy">
          Locking positions mints veATLAS that can route emissions, activate treasury
          buybacks, and prioritize new partner reward markets. NFT vaults receive elevated
          governance weight for curator-driven curation proposals.
        </p>
      </div>
      <div className="governance-cards">
        <div className="metric-card">
          <span>Gauge weight</span>
          <strong>{pool.governanceWeight.toFixed(2)}x</strong>
        </div>
        <div className="metric-card">
          <span>veAPR bonus</span>
          <strong>{pool.veAprBonus.toFixed(1)}%</strong>
        </div>
        <div className="metric-card">
          <span>Referral share</span>
          <strong>{(pool.referralRate * 100).toFixed(1)}%</strong>
        </div>
      </div>
    </section>
  );
}
