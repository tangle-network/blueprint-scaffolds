import type { LockTier, Pool } from '../types';
import { calculateBoostedApr, estimateVeTokens, projectAnnualRewards } from '../lib/calculations';
import { currency, percentage } from '../lib/format';

type ApyCalculatorProps = {
  pool: Pool;
  tier: LockTier;
  amount: number;
  autoCompound: boolean;
  includeNftBoost: boolean;
};

export function ApyCalculator({
  pool,
  tier,
  amount,
  autoCompound,
  includeNftBoost
}: ApyCalculatorProps) {
  const apr = calculateBoostedApr(pool, tier, includeNftBoost, autoCompound);
  const annualRewards = projectAnnualRewards(amount, apr);
  const monthlyRewards = annualRewards / 12;
  const veTokens = estimateVeTokens(amount, tier);

  return (
    <section className="panel">
      <div className="section-heading">
        <div>
          <span className="eyebrow">APY calculator</span>
          <h2>Scenario model</h2>
        </div>
      </div>
      <div className="calculator-grid">
        <div className="metric-card wide">
          <span>Net effective APR</span>
          <strong>{percentage(apr)}</strong>
        </div>
        <div className="metric-card">
          <span>Monthly rewards</span>
          <strong>{currency(monthlyRewards)}</strong>
        </div>
        <div className="metric-card">
          <span>Annual rewards</span>
          <strong>{currency(annualRewards)}</strong>
        </div>
        <div className="metric-card">
          <span>Governance power</span>
          <strong>{(veTokens * pool.governanceWeight).toFixed(0)} votes</strong>
        </div>
      </div>
    </section>
  );
}
