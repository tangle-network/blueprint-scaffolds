import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';

type HeaderProps = {
  totalTvl: string;
  activeUsers: string;
};

export function Header({ totalTvl, activeUsers }: HeaderProps) {
  return (
    <header className="hero">
      <div>
        <span className="eyebrow">Solana staking protocol</span>
        <h1>Atlas Stake</h1>
        <p className="hero-copy">
          Single-token, LP, and NFT staking with per-second emissions, multi-reward vaults,
          auto-compound loops, veToken governance, and referral-aware growth incentives.
        </p>
      </div>
      <div className="hero-side">
        <div className="metric-card">
          <span>Total TVL</span>
          <strong>{totalTvl}</strong>
        </div>
        <div className="metric-card">
          <span>Active stakers</span>
          <strong>{activeUsers}</strong>
        </div>
        <WalletMultiButton className="wallet-button" />
      </div>
    </header>
  );
}
