import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from 'recharts';
import type { Pool } from '../types';
import { currency } from '../lib/format';

type RewardsDashboardProps = {
  pool: Pool;
};

const projection = [0, 1, 2, 3, 4, 5, 6].map((week) => ({
  week: `W${week + 1}`,
  rewards: 150 + week * 42,
  referrals: 22 + week * 8
}));

export function RewardsDashboard({ pool }: RewardsDashboardProps) {
  const totalRewards =
    pool.userPosition.pendingRewardsUsd + pool.userPosition.referralRewardsUsd;

  return (
    <section className="panel dashboard-grid">
      <div>
        <div className="section-heading">
          <div>
            <span className="eyebrow">Rewards dashboard</span>
            <h2>Claim and compound view</h2>
          </div>
        </div>
        <div className="summary-grid">
          <div>
            <span>Pending rewards</span>
            <strong>{currency(pool.userPosition.pendingRewardsUsd)}</strong>
          </div>
          <div>
            <span>Referral rewards</span>
            <strong>{currency(pool.userPosition.referralRewardsUsd)}</strong>
          </div>
          <div>
            <span>Total claimable</span>
            <strong>{currency(totalRewards)}</strong>
          </div>
          <div>
            <span>veBalance</span>
            <strong>{pool.userPosition.veBalance.toLocaleString()}</strong>
          </div>
        </div>
      </div>
      <div className="chart-card">
        <ResponsiveContainer width="100%" height={260}>
          <AreaChart data={projection}>
            <defs>
              <linearGradient id="rewardFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#f9b44e" stopOpacity={0.8} />
                <stop offset="95%" stopColor="#f9b44e" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke="rgba(255,255,255,0.08)" vertical={false} />
            <XAxis dataKey="week" stroke="rgba(255,255,255,0.5)" />
            <YAxis stroke="rgba(255,255,255,0.5)" />
            <Tooltip
              contentStyle={{
                background: '#172033',
                border: '1px solid rgba(255,255,255,0.08)',
                borderRadius: 16
              }}
            />
            <Area
              type="monotone"
              dataKey="rewards"
              stroke="#f9b44e"
              fillOpacity={1}
              fill="url(#rewardFill)"
            />
            <Area type="monotone" dataKey="referrals" stroke="#5fe3c2" fillOpacity={0} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </section>
  );
}
