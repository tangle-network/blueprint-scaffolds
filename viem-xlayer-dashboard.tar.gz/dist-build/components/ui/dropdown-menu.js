import { jsx as _jsx } from "react/jsx-runtime";
import * as React from "react";
import { cn } from "@/lib/utils";
const DropdownContext = React.createContext({ open: false, onOpenChange: () => { } });
function DropdownMenu({ open: controlledOpen, onOpenChange, children }) {
    const [internal, setInternal] = React.useState(false);
    const open = controlledOpen ?? internal;
    const setter = onOpenChange ?? setInternal;
    return _jsx(DropdownContext.Provider, { value: { open, onOpenChange: setter }, children: children });
}
const DropdownMenuTrigger = React.forwardRef(({ onClick, ...props }, ref) => {
    const ctx = React.useContext(DropdownContext);
    return _jsx("button", { ref: ref, type: "button", onClick: (e) => { ctx.onOpenChange(!ctx.open); onClick?.(e); }, ...props });
});
DropdownMenuTrigger.displayName = "DropdownMenuTrigger";
const DropdownMenuContent = React.forwardRef(({ className, ...props }, ref) => {
    const ctx = React.useContext(DropdownContext);
    const contentRef = React.useRef(null);
    React.useEffect(() => {
        if (!ctx.open)
            return;
        const handler = (e) => {
            if (contentRef.current && !contentRef.current.contains(e.target))
                ctx.onOpenChange(false);
        };
        document.addEventListener("mousedown", handler);
        return () => document.removeEventListener("mousedown", handler);
    }, [ctx.open, ctx.onOpenChange]);
    if (!ctx.open)
        return null;
    return (_jsx("div", { ref: (node) => { contentRef.current = node; if (typeof ref === "function")
            ref(node);
        else if (ref)
            ref.current = node; }, className: cn("z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md", className), ...props }));
});
DropdownMenuContent.displayName = "DropdownMenuContent";
const DropdownMenuItem = React.forwardRef(({ className, inset, onClick, ...props }, ref) => {
    const ctx = React.useContext(DropdownContext);
    return (_jsx("div", { ref: ref, role: "menuitem", className: cn("relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground", inset && "pl-8", className), onClick: (e) => { onClick?.(e); ctx.onOpenChange(false); }, ...props }));
});
DropdownMenuItem.displayName = "DropdownMenuItem";
const DropdownMenuSeparator = React.forwardRef(({ className, ...props }, ref) => _jsx("div", { ref: ref, className: cn("-mx-1 my-1 h-px bg-muted", className), ...props }));
DropdownMenuSeparator.displayName = "DropdownMenuSeparator";
const DropdownMenuLabel = React.forwardRef(({ className, inset, ...props }, ref) => (_jsx("div", { ref: ref, className: cn("px-2 py-1.5 text-sm font-semibold", inset && "pl-8", className), ...props })));
DropdownMenuLabel.displayName = "DropdownMenuLabel";
export { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuLabel };
//# sourceMappingURL=dropdown-menu.js.map