import * as React from "react";
declare function Sheet({ open: controlledOpen, onOpenChange, children }: {
    open?: boolean;
    onOpenChange?: (v: boolean) => void;
    children: React.ReactNode;
}): import("react/jsx-runtime").JSX.Element;
declare const SheetTrigger: React.ForwardRefExoticComponent<React.ButtonHTMLAttributes<HTMLButtonElement> & React.RefAttributes<HTMLButtonElement>>;
declare const sheetSideStyles: {
    readonly top: "inset-x-0 top-0 border-b";
    readonly bottom: "inset-x-0 bottom-0 border-t";
    readonly left: "inset-y-0 left-0 h-full w-3/4 border-r sm:max-w-sm";
    readonly right: "inset-y-0 right-0 h-full w-3/4 border-l sm:max-w-sm";
};
declare const SheetContent: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & {
    side?: keyof typeof sheetSideStyles;
} & React.RefAttributes<HTMLDivElement>>;
declare const SheetHeader: ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => import("react/jsx-runtime").JSX.Element;
declare const SheetFooter: ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => import("react/jsx-runtime").JSX.Element;
declare const SheetTitle: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLHeadingElement> & React.RefAttributes<HTMLHeadingElement>>;
declare const SheetDescription: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLParagraphElement> & React.RefAttributes<HTMLParagraphElement>>;
export { Sheet, SheetTrigger, SheetContent, SheetHeader, SheetFooter, SheetTitle, SheetDescription };
//# sourceMappingURL=sheet.d.ts.map