import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from "react";
import { cn } from "@/lib/utils";
const CommandContext = React.createContext({ search: "", onSearchChange: () => { } });
const Command = React.forwardRef(({ className, children, ...props }, ref) => {
    const [search, setSearch] = React.useState("");
    return (_jsx(CommandContext.Provider, { value: { search, onSearchChange: setSearch }, children: _jsx("div", { ref: ref, className: cn("flex h-full w-full flex-col overflow-hidden rounded-md bg-popover text-popover-foreground", className), ...props, children: children }) }));
});
Command.displayName = "Command";
const CommandInput = React.forwardRef(({ className, ...props }, ref) => {
    const ctx = React.useContext(CommandContext);
    return (_jsxs("div", { className: "flex items-center border-b px-3", children: [_jsx("span", { className: "mr-2 h-4 w-4 shrink-0 opacity-50", children: "\u2315" }), _jsx("input", { ref: ref, className: cn("flex h-10 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50", className), value: ctx.search, onChange: (e) => ctx.onSearchChange(e.target.value), ...props })] }));
});
CommandInput.displayName = "CommandInput";
const CommandList = React.forwardRef(({ className, ...props }, ref) => (_jsx("div", { ref: ref, className: cn("max-h-[300px] overflow-y-auto overflow-x-hidden", className), ...props })));
CommandList.displayName = "CommandList";
const CommandEmpty = React.forwardRef(({ className, ...props }, ref) => (_jsx("div", { ref: ref, className: cn("py-6 text-center text-sm", className), ...props })));
CommandEmpty.displayName = "CommandEmpty";
const CommandGroup = React.forwardRef(({ className, heading, children, ...props }, ref) => (_jsxs("div", { ref: ref, className: cn("overflow-hidden p-1 text-foreground", className), ...props, children: [heading && _jsx("div", { className: "px-2 py-1.5 text-xs font-medium text-muted-foreground", children: heading }), children] })));
CommandGroup.displayName = "CommandGroup";
const CommandItem = React.forwardRef(({ className, ...props }, ref) => (_jsx("div", { ref: ref, role: "option", className: cn("relative flex cursor-default gap-2 select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none hover:bg-accent hover:text-accent-foreground data-[disabled=true]:pointer-events-none data-[disabled=true]:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", className), ...props })));
CommandItem.displayName = "CommandItem";
const CommandSeparator = React.forwardRef(({ className, ...props }, ref) => _jsx("div", { ref: ref, className: cn("-mx-1 h-px bg-border", className), ...props }));
CommandSeparator.displayName = "CommandSeparator";
export { Command, CommandInput, CommandList, CommandEmpty, CommandGroup, CommandItem, CommandSeparator };
//# sourceMappingURL=command.js.map