import * as React from "react";
declare const Checkbox: React.ForwardRefExoticComponent<Omit<React.InputHTMLAttributes<HTMLInputElement>, "type"> & {
    onCheckedChange?: (checked: boolean) => void;
} & React.RefAttributes<HTMLInputElement>>;
export { Checkbox };
//# sourceMappingURL=checkbox.d.ts.map