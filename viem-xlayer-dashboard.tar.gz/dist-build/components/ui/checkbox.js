import { jsx as _jsx } from "react/jsx-runtime";
import * as React from "react";
import { cn } from "@/lib/utils";
const Checkbox = React.forwardRef(({ className, onCheckedChange, onChange, ...props }, ref) => {
    return (_jsx("input", { type: "checkbox", ref: ref, className: cn("peer h-4 w-4 shrink-0 rounded-sm border border-primary shadow focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 accent-primary", className), onChange: (e) => {
            onChange?.(e);
            onCheckedChange?.(e.target.checked);
        }, ...props }));
});
Checkbox.displayName = "Checkbox";
export { Checkbox };
//# sourceMappingURL=checkbox.js.map