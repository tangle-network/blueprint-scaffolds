import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import * as React from "react";
import { cn } from "@/lib/utils";
const SheetContext = React.createContext({ open: false, onOpenChange: () => { } });
function Sheet({ open: controlledOpen, onOpenChange, children }) {
    const [internal, setInternal] = React.useState(false);
    const open = controlledOpen ?? internal;
    const setter = onOpenChange ?? setInternal;
    return _jsx(SheetContext.Provider, { value: { open, onOpenChange: setter }, children: children });
}
const SheetTrigger = React.forwardRef(({ onClick, ...props }, ref) => {
    const ctx = React.useContext(SheetContext);
    return _jsx("button", { ref: ref, type: "button", onClick: (e) => { ctx.onOpenChange(true); onClick?.(e); }, ...props });
});
SheetTrigger.displayName = "SheetTrigger";
const sheetSideStyles = {
    top: "inset-x-0 top-0 border-b",
    bottom: "inset-x-0 bottom-0 border-t",
    left: "inset-y-0 left-0 h-full w-3/4 border-r sm:max-w-sm",
    right: "inset-y-0 right-0 h-full w-3/4 border-l sm:max-w-sm",
};
const SheetContent = React.forwardRef(({ className, side = "right", children, ...props }, ref) => {
    const ctx = React.useContext(SheetContext);
    if (!ctx.open)
        return null;
    return (_jsxs(_Fragment, { children: [_jsx("div", { className: "fixed inset-0 z-50 bg-black/80", onClick: () => ctx.onOpenChange(false) }), _jsxs("div", { ref: ref, className: cn("fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out", sheetSideStyles[side], className), ...props, children: [children, _jsxs("button", { className: "absolute right-4 top-4 rounded-sm opacity-70 hover:opacity-100", onClick: () => ctx.onOpenChange(false), children: [_jsx("span", { className: "text-sm", children: "\u2715" }), _jsx("span", { className: "sr-only", children: "Close" })] })] })] }));
});
SheetContent.displayName = "SheetContent";
const SheetHeader = ({ className, ...props }) => (_jsx("div", { className: cn("flex flex-col space-y-2 text-center sm:text-left", className), ...props }));
const SheetFooter = ({ className, ...props }) => (_jsx("div", { className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className), ...props }));
const SheetTitle = React.forwardRef(({ className, ...props }, ref) => (_jsx("h2", { ref: ref, className: cn("text-lg font-semibold text-foreground", className), ...props })));
SheetTitle.displayName = "SheetTitle";
const SheetDescription = React.forwardRef(({ className, ...props }, ref) => (_jsx("p", { ref: ref, className: cn("text-sm text-muted-foreground", className), ...props })));
SheetDescription.displayName = "SheetDescription";
export { Sheet, SheetTrigger, SheetContent, SheetHeader, SheetFooter, SheetTitle, SheetDescription };
//# sourceMappingURL=sheet.js.map