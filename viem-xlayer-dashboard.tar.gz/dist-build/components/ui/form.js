import { jsx as _jsx } from "react/jsx-runtime";
import * as React from "react";
import { cn } from "@/lib/utils";
import { Label } from "@/components/ui/label";
const FormFieldContext = React.createContext({ id: "", name: "" });
function FormField({ name, children, error }) {
    const id = React.useId();
    return _jsx(FormFieldContext.Provider, { value: { id, name, error }, children: children });
}
const FormItem = React.forwardRef(({ className, ...props }, ref) => (_jsx("div", { ref: ref, className: cn("space-y-2", className), ...props })));
FormItem.displayName = "FormItem";
const FormLabel = React.forwardRef(({ className, ...props }, ref) => {
    const { id, error } = React.useContext(FormFieldContext);
    return _jsx(Label, { ref: ref, htmlFor: id, className: cn(error && "text-destructive", className), ...props });
});
FormLabel.displayName = "FormLabel";
const FormControl = React.forwardRef(({ ...props }, ref) => {
    const { id, error } = React.useContext(FormFieldContext);
    return _jsx("div", { ref: ref, id: id, "aria-invalid": !!error, "aria-describedby": error ? `${id}-message` : undefined, ...props });
});
FormControl.displayName = "FormControl";
const FormDescription = React.forwardRef(({ className, ...props }, ref) => (_jsx("p", { ref: ref, className: cn("text-[0.8rem] text-muted-foreground", className), ...props })));
FormDescription.displayName = "FormDescription";
const FormMessage = React.forwardRef(({ className, children, ...props }, ref) => {
    const { id, error } = React.useContext(FormFieldContext);
    const message = error || children;
    if (!message)
        return null;
    return (_jsx("p", { ref: ref, id: `${id}-message`, className: cn("text-[0.8rem] font-medium text-destructive", className), ...props, children: message }));
});
FormMessage.displayName = "FormMessage";
export { FormField, FormItem, FormLabel, FormControl, FormDescription, FormMessage };
//# sourceMappingURL=form.js.map