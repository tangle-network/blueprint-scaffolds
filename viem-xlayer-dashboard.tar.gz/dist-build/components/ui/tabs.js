import { jsx as _jsx } from "react/jsx-runtime";
import * as React from "react";
import { cn } from "@/lib/utils";
const TabsContext = React.createContext({ value: "", onValueChange: () => { } });
function Tabs({ defaultValue = "", value: controlledValue, onValueChange, className, children, ...props }) {
    const [internal, setInternal] = React.useState(defaultValue);
    const value = controlledValue ?? internal;
    const setter = onValueChange ?? setInternal;
    return (_jsx(TabsContext.Provider, { value: { value, onValueChange: setter }, children: _jsx("div", { className: cn("", className), ...props, children: children }) }));
}
const TabsList = React.forwardRef(({ className, ...props }, ref) => (_jsx("div", { ref: ref, className: cn("inline-flex h-9 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground", className), ...props })));
TabsList.displayName = "TabsList";
const TabsTrigger = React.forwardRef(({ className, value, ...props }, ref) => {
    const ctx = React.useContext(TabsContext);
    const active = ctx.value === value;
    return (_jsx("button", { ref: ref, type: "button", role: "tab", "aria-selected": active, "data-state": active ? "active" : "inactive", className: cn("inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50", active && "bg-background text-foreground shadow", className), onClick: () => ctx.onValueChange(value), ...props }));
});
TabsTrigger.displayName = "TabsTrigger";
const TabsContent = React.forwardRef(({ className, value, ...props }, ref) => {
    const ctx = React.useContext(TabsContext);
    if (ctx.value !== value)
        return null;
    return (_jsx("div", { ref: ref, role: "tabpanel", className: cn("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className), ...props }));
});
TabsContent.displayName = "TabsContent";
export { Tabs, TabsList, TabsTrigger, TabsContent };
//# sourceMappingURL=tabs.js.map