import { jsx as _jsx } from "react/jsx-runtime";
import * as React from "react";
import { cn } from "@/lib/utils";
const ScrollArea = React.forwardRef(({ className, children, ...props }, ref) => (_jsx("div", { ref: ref, className: cn("relative overflow-hidden", className), ...props, children: _jsx("div", { className: "h-full w-full overflow-auto scrollbar-thin scrollbar-track-transparent scrollbar-thumb-border", children: children }) })));
ScrollArea.displayName = "ScrollArea";
const ScrollBar = React.forwardRef(({ className, orientation = "vertical", ...props }, ref) => (_jsx("div", { ref: ref, className: cn("flex touch-none select-none transition-colors", orientation === "vertical" && "h-full w-2.5 border-l border-l-transparent p-[1px]", orientation === "horizontal" && "h-2.5 flex-col border-t border-t-transparent p-[1px]", className), ...props })));
ScrollBar.displayName = "ScrollBar";
export { ScrollArea, ScrollBar };
//# sourceMappingURL=scroll-area.js.map