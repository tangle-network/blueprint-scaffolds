import * as React from "react";
declare const toastVariants: (props?: ({
    variant?: "default" | "destructive" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
type ToastData = {
    id: string;
    title?: string;
    description?: string;
    variant?: "default" | "destructive";
    action?: React.ReactNode;
};
declare function toast(opts: Omit<ToastData, "id">): string;
declare function ToastAction({ className, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement>): import("react/jsx-runtime").JSX.Element;
declare function Toaster(): import("react/jsx-runtime").JSX.Element | null;
export { toast, Toaster, ToastAction, toastVariants };
//# sourceMappingURL=toast.d.ts.map