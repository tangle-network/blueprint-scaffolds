import { Fragment as _Fragment, jsx as _jsx } from "react/jsx-runtime";
import * as React from "react";
import { cn } from "@/lib/utils";
function TooltipProvider({ children }) {
    return _jsx(_Fragment, { children: children });
}
const TooltipContext = React.createContext({ open: false, onOpenChange: () => { } });
function Tooltip({ open: controlledOpen, onOpenChange, children }) {
    const [internal, setInternal] = React.useState(false);
    const open = controlledOpen ?? internal;
    const setter = onOpenChange ?? setInternal;
    return _jsx(TooltipContext.Provider, { value: { open, onOpenChange: setter }, children: children });
}
const TooltipTrigger = React.forwardRef(({ onMouseEnter, onMouseLeave, ...props }, ref) => {
    const ctx = React.useContext(TooltipContext);
    return (_jsx("button", { ref: ref, type: "button", onMouseEnter: (e) => { ctx.onOpenChange(true); onMouseEnter?.(e); }, onMouseLeave: (e) => { ctx.onOpenChange(false); onMouseLeave?.(e); }, onFocus: () => ctx.onOpenChange(true), onBlur: () => ctx.onOpenChange(false), ...props }));
});
TooltipTrigger.displayName = "TooltipTrigger";
const TooltipContent = React.forwardRef(({ className, ...props }, ref) => {
    const ctx = React.useContext(TooltipContext);
    if (!ctx.open)
        return null;
    return (_jsx("div", { ref: ref, className: cn("z-50 overflow-hidden rounded-md bg-primary px-3 py-1.5 text-xs text-primary-foreground animate-in fade-in-0 zoom-in-95", className), ...props }));
});
TooltipContent.displayName = "TooltipContent";
export { Tooltip, TooltipTrigger, TooltipContent, TooltipProvider };
//# sourceMappingURL=tooltip.js.map