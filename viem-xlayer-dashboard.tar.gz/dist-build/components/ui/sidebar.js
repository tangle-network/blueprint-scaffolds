import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from "react";
import { cn } from "@/lib/utils";
const SidebarContext = React.createContext({ open: true, onOpenChange: () => { } });
const useSidebar = () => React.useContext(SidebarContext);
function SidebarProvider({ defaultOpen = true, children }) {
    const [open, setOpen] = React.useState(defaultOpen);
    return _jsx(SidebarContext.Provider, { value: { open, onOpenChange: setOpen }, children: children });
}
const Sidebar = React.forwardRef(({ className, children, ...props }, ref) => {
    const { open } = useSidebar();
    return (_jsx("aside", { ref: ref, "data-state": open ? "open" : "closed", className: cn("flex h-full flex-col border-r bg-sidebar text-sidebar-foreground transition-[width] duration-200", open ? "w-64" : "w-0 overflow-hidden", className), ...props, children: children }));
});
Sidebar.displayName = "Sidebar";
const SidebarHeader = React.forwardRef(({ className, ...props }, ref) => _jsx("div", { ref: ref, className: cn("flex flex-col gap-2 p-4", className), ...props }));
SidebarHeader.displayName = "SidebarHeader";
const SidebarContent = React.forwardRef(({ className, ...props }, ref) => _jsx("div", { ref: ref, className: cn("flex-1 overflow-auto p-4", className), ...props }));
SidebarContent.displayName = "SidebarContent";
const SidebarFooter = React.forwardRef(({ className, ...props }, ref) => _jsx("div", { ref: ref, className: cn("flex flex-col gap-2 p-4", className), ...props }));
SidebarFooter.displayName = "SidebarFooter";
const SidebarMenu = React.forwardRef(({ className, ...props }, ref) => _jsx("ul", { ref: ref, className: cn("flex w-full min-w-0 flex-col gap-1", className), ...props }));
SidebarMenu.displayName = "SidebarMenu";
const SidebarMenuItem = React.forwardRef(({ className, ...props }, ref) => _jsx("li", { ref: ref, className: cn("group/menu-item relative", className), ...props }));
SidebarMenuItem.displayName = "SidebarMenuItem";
const SidebarMenuButton = React.forwardRef(({ className, isActive, ...props }, ref) => (_jsx("button", { ref: ref, type: "button", "data-active": isActive, className: cn("flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-sm outline-none transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 focus-visible:ring-sidebar-ring", isActive && "bg-sidebar-accent text-sidebar-accent-foreground font-medium", className), ...props })));
SidebarMenuButton.displayName = "SidebarMenuButton";
function SidebarTrigger({ className, ...props }) {
    const { open, onOpenChange } = useSidebar();
    return (_jsxs("button", { type: "button", className: cn("inline-flex items-center justify-center rounded-md text-sm font-medium h-9 w-9 hover:bg-accent hover:text-accent-foreground", className), onClick: () => onOpenChange(!open), ...props, children: [_jsx("span", { className: "text-lg", children: open ? "◀" : "▶" }), _jsx("span", { className: "sr-only", children: "Toggle Sidebar" })] }));
}
export { Sidebar, SidebarProvider, SidebarHeader, SidebarContent, SidebarFooter, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarTrigger, useSidebar };
//# sourceMappingURL=sidebar.js.map