import { jsx as _jsx } from "react/jsx-runtime";
import * as React from "react";
import { cn } from "@/lib/utils";
const Switch = React.forwardRef(({ className, checked = false, onCheckedChange, ...props }, ref) => {
    return (_jsx("button", { type: "button", role: "switch", "aria-checked": checked, ref: ref, className: cn("peer inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50", checked ? "bg-primary" : "bg-input", className), onClick: () => onCheckedChange?.(!checked), ...props, children: _jsx("span", { className: cn("pointer-events-none block h-4 w-4 rounded-full bg-background shadow-lg ring-0 transition-transform", checked ? "translate-x-4" : "translate-x-0") }) }));
});
Switch.displayName = "Switch";
export { Switch };
//# sourceMappingURL=switch.js.map