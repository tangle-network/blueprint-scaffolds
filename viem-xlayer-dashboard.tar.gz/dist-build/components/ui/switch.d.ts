import * as React from "react";
declare const Switch: React.ForwardRefExoticComponent<React.ButtonHTMLAttributes<HTMLButtonElement> & {
    checked?: boolean;
    onCheckedChange?: (checked: boolean) => void;
} & React.RefAttributes<HTMLButtonElement>>;
export { Switch };
//# sourceMappingURL=switch.d.ts.map