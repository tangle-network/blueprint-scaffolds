import * as React from "react";
declare function Select({ value: controlledValue, onValueChange, defaultValue, children }: {
    value?: string;
    onValueChange?: (v: string) => void;
    defaultValue?: string;
    children: React.ReactNode;
}): import("react/jsx-runtime").JSX.Element;
declare const SelectTrigger: React.ForwardRefExoticComponent<React.ButtonHTMLAttributes<HTMLButtonElement> & React.RefAttributes<HTMLButtonElement>>;
declare function SelectValue({ placeholder }: {
    placeholder?: string;
}): import("react/jsx-runtime").JSX.Element;
declare const SelectContent: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>>;
declare const SelectItem: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & {
    value: string;
} & React.RefAttributes<HTMLDivElement>>;
declare function SelectGroup({ children, ...props }: React.HTMLAttributes<HTMLDivElement>): import("react/jsx-runtime").JSX.Element;
declare const SelectLabel: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>>;
export { Select, SelectTrigger, SelectValue, SelectContent, SelectItem, SelectGroup, SelectLabel };
//# sourceMappingURL=select.d.ts.map