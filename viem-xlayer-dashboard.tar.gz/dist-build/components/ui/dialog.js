import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from "react";
import { cn } from "@/lib/utils";
const DialogContext = React.createContext({ open: false, onOpenChange: () => { } });
function Dialog({ open: controlledOpen, onOpenChange, children }) {
    const [internal, setInternal] = React.useState(false);
    const open = controlledOpen ?? internal;
    const setter = onOpenChange ?? setInternal;
    return _jsx(DialogContext.Provider, { value: { open, onOpenChange: setter }, children: children });
}
const DialogTrigger = React.forwardRef(({ onClick, ...props }, ref) => {
    const ctx = React.useContext(DialogContext);
    return _jsx("button", { ref: ref, type: "button", onClick: (e) => { ctx.onOpenChange(true); onClick?.(e); }, ...props });
});
DialogTrigger.displayName = "DialogTrigger";
function DialogPortal({ children }) {
    return _jsx(_Fragment, { children: children });
}
const DialogOverlay = React.forwardRef(({ className, ...props }, ref) => (_jsx("div", { ref: ref, className: cn("fixed inset-0 z-50 bg-black/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className), ...props })));
DialogOverlay.displayName = "DialogOverlay";
const DialogContent = React.forwardRef(({ className, children, ...props }, ref) => {
    const ctx = React.useContext(DialogContext);
    if (!ctx.open)
        return null;
    return (_jsxs(DialogPortal, { children: [_jsx(DialogOverlay, { onClick: () => ctx.onOpenChange(false) }), _jsxs("div", { ref: ref, className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 sm:rounded-lg", className), ...props, children: [children, _jsxs("button", { className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2", onClick: () => ctx.onOpenChange(false), children: [_jsx("span", { className: "text-sm", children: "\u2715" }), _jsx("span", { className: "sr-only", children: "Close" })] })] })] }));
});
DialogContent.displayName = "DialogContent";
const DialogHeader = ({ className, ...props }) => (_jsx("div", { className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className), ...props }));
const DialogFooter = ({ className, ...props }) => (_jsx("div", { className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className), ...props }));
const DialogTitle = React.forwardRef(({ className, ...props }, ref) => (_jsx("h2", { ref: ref, className: cn("text-lg font-semibold leading-none tracking-tight", className), ...props })));
DialogTitle.displayName = "DialogTitle";
const DialogDescription = React.forwardRef(({ className, ...props }, ref) => (_jsx("p", { ref: ref, className: cn("text-sm text-muted-foreground", className), ...props })));
DialogDescription.displayName = "DialogDescription";
export { Dialog, DialogPortal, DialogOverlay, DialogTrigger, DialogContent, DialogHeader, DialogFooter, DialogTitle, DialogDescription };
//# sourceMappingURL=dialog.js.map