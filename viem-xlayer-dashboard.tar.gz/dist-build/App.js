import { jsx as _jsx } from "react/jsx-runtime";
export default function App() {
    return (_jsx("div", { className: "min-h-screen bg-background text-foreground", children: _jsx("div", { className: "container mx-auto p-8", children: _jsx("h1", { className: "text-3xl font-bold", children: "Loading..." }) }) }));
}
//# sourceMappingURL=App.js.map