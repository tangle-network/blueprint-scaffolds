export const erc20Abi = [
  {
    name: "balanceOf",
    type: "function",
    stateMutability: "view",
    inputs: [{ name: "account", type: "address" }],
    outputs: [{ name: "", type: "uint256" }],
  },
  {
    name: "decimals",
    type: "function",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "", type: "uint8" }],
  },
  {
    name: "symbol",
    type: "function",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "", type: "string" }],
  },
] as const;

export const TOKENS: Record<string, `0x${string}`> = {
  USDC: "0xCb3AEC623D4Af1E9875732DaE3e0ba1f5E39fbC5",
  USDT: "0x94F7E71E033b57188a4AB553C3Dc2713aEd4aCB6",
};
