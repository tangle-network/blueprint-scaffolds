import { createPublicClient, http, formatEther, formatUnits } from "viem";
import { xlayer } from "./chain.js";
import { erc20Abi, TOKENS } from "./tokens.js";

const WALLET = process.env.WALLET_ADDRESS as `0x${string}`;

if (!WALLET) {
  console.error("Set WALLET_ADDRESS env var, e.g.: WALLET_ADDRESS=0x... pnpm start");
  process.exit(1);
}

async function main() {
  const client = createPublicClient({
    chain: xlayer,
    transport: http(),
  });

  const tokenNames = Object.keys(TOKENS);
  const tokenAddresses = Object.values(TOKENS);

  const multicallResult = await client.multicall({
    contracts: [
      { address: tokenAddresses[0], abi: erc20Abi, functionName: "balanceOf", args: [WALLET] },
      { address: tokenAddresses[0], abi: erc20Abi, functionName: "decimals" },
      { address: tokenAddresses[0], abi: erc20Abi, functionName: "symbol" },
      { address: tokenAddresses[1], abi: erc20Abi, functionName: "balanceOf", args: [WALLET] },
      { address: tokenAddresses[1], abi: erc20Abi, functionName: "decimals" },
      { address: tokenAddresses[1], abi: erc20Abi, functionName: "symbol" },
    ],
  });

  const nativeBalance = await client.getBalance({ address: WALLET });

  const tokenBalances = tokenNames.map((name, i) => {
    const base = i * 3;
    const balanceResult = multicallResult[base];
    const decimalsResult = multicallResult[base + 1];
    const symbolResult = multicallResult[base + 2];

    const rawBalance = balanceResult.result as bigint | undefined;
    const decimals = decimalsResult.result as number | undefined;
    const symbol = (symbolResult.result as string | undefined) ?? name;

    const formatted =
      rawBalance !== undefined && decimals !== undefined
        ? formatUnits(rawBalance, decimals)
        : "0";

    return { symbol, balance: formatted, rawBalance: rawBalance ?? 0n };
  });

  const separator = "+----------+----------------------------------------------+";
  const header = "| Asset    | Balance                                      |";

  console.log(`\nWallet: ${WALLET}`);
  console.log(`Chain:  ${xlayer.name} (id: ${xlayer.id})\n`);
  console.log(separator);
  console.log(header);
  console.log(separator);
  console.log(
    `| ${"OKB".padEnd(8)} | ${formatEther(nativeBalance).padEnd(44)} |`
  );
  for (const t of tokenBalances) {
    console.log(
      `| ${t.symbol.padEnd(8)} | ${t.balance.padEnd(44)} |`
    );
  }
  console.log(separator);
  console.log();
}

main().catch((err) => {
  console.error("Error:", err.message);
  process.exit(1);
});
