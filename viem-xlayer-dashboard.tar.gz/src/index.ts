import {
  createPublicClient,
  http,
  defineChain,
  formatUnits,
  type Address,
} from "viem";

const xlayer = defineChain({
  id: 196,
  name: "X Layer",
  nativeCurrency: {
    name: "OKB",
    symbol: "OKB",
    decimals: 18,
  },
  rpcUrls: {
    default: {
      http: ["https://rpc.xlayer.tech"],
    },
  },
  blockExplorers: {
    default: {
      name: "OKLink",
      url: "https://www.oklink.com/xlayer",
    },
  },
});

const ERC20_ABI = [
  {
    name: "balanceOf",
    type: "function",
    stateMutability: "view",
    inputs: [{ name: "account", type: "address" }],
    outputs: [{ name: "", type: "uint256" }],
  },
  {
    name: "decimals",
    type: "function",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "", type: "uint8" }],
  },
  {
    name: "symbol",
    type: "function",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "", type: "string" }],
  },
] as const;

const TOKENS: Record<string, { address: Address; decimals: number }> = {
  USDC: {
    address: "0x6e1A6723fDB13b78A963E22E5116d0b9043Ba9eE",
    decimals: 6,
  },
  USDT: {
    address: "0xdAc17F958D2ee523a2206206994597C13D332A3b",
    decimals: 6,
  },
};

async function main() {
  const walletAddress = process.argv[2];
  if (!walletAddress) {
    console.error(
      "Usage: pnpm start <wallet_address>\nExample: pnpm start 0x1234...abcd"
    );
    process.exit(1);
  }

  const client = createPublicClient({
    chain: xlayer,
    transport: http(),
  });

  console.log(`\nX Layer Balance Checker`);
  console.log(`Network: ${xlayer.name} (Chain ID: ${xlayer.id})`);
  console.log(`Wallet:  ${walletAddress}\n`);

  const multicallResults = await client.multicall({
    contracts: [
      {
        address: TOKENS.USDC.address,
        abi: ERC20_ABI,
        functionName: "balanceOf",
        args: [walletAddress as Address],
      },
      {
        address: TOKENS.USDT.address,
        abi: ERC20_ABI,
        functionName: "balanceOf",
        args: [walletAddress as Address],
      },
    ],
  });

  const nativeBalance = await client.getBalance({
    address: walletAddress as Address,
  });

  const rows: { token: string; balance: string }[] = [
    {
      token: "OKB (native)",
      balance: formatUnits(nativeBalance, xlayer.nativeCurrency.decimals),
    },
  ];

  const tokenEntries = Object.entries(TOKENS);
  for (let i = 0; i < tokenEntries.length; i++) {
    const [symbol, info] = tokenEntries[i];
    const raw = multicallResults[i].result as bigint | undefined;
    const balance = raw ? formatUnits(raw, info.decimals) : "0";
    rows.push({ token: symbol, balance });
  }

  const col1 = 20;
  const col2 = 30;
  const separator = "+".padEnd(col1 + 2, "-") + "+".padEnd(col2 + 2, "-") + "+";

  console.log(separator);
  console.log(
    `| ${"Token".padEnd(col1)} | ${"Balance".padEnd(col2)} |`
  );
  console.log(separator);

  for (const row of rows) {
    console.log(
      `| ${row.token.padEnd(col1)} | ${row.balance.padEnd(col2)} |`
    );
  }
  console.log(separator);
  console.log();
}

main().catch((err) => {
  console.error("Error:", err.message);
  process.exit(1);
});
