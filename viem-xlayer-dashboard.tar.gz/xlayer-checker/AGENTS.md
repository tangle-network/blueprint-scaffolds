# AGENTS.md

## Goal

CLI tool to batch-check ERC20 and native OKB balances on X Layer mainnet using viem.

## Stack

- TypeScript (ES2022, NodeNext modules)
- viem for Ethereum interactions
- No framework — pure Node.js CLI script

## Architecture

```
xlayer-checker/
├── package.json          # Dependencies: viem, typescript, @types/node
├── tsconfig.json         # ES2022 target, NodeNext modules
└── src/
    ├── chain.ts          # X Layer chain definition (ID 196, OKB native)
    ├── tokens.ts         # ERC20 token registry (USDC, USDT) with TokenInfo interface
    ├── multicall.ts      # Batch balance reads via viem multicall + getBalance
    ├── format.ts         # Console table formatting with optional color output
    └── index.ts          # CLI entry point — creates client, fetches, prints results
```

## Entry Points

- `src/index.ts` — Main entry, accepts wallet address as CLI arg
- Compiled output goes to `dist/`

## Commands

- `npm install` — Install dependencies
- `npm run build` — Compile TypeScript
- `npm start` — Run the compiled script
- `npm start -- 0xYOUR_ADDRESS` — Check a specific wallet

## Build Plan

Modules: chain (defineChain), tokens (token registry), multicall (batch reads), format (display), index (CLI)
Data models: TokenInfo, BalanceResult
Integrations: viem PublicClient, multicall, getBalance
