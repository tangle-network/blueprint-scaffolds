export interface TokenInfo {
  address: `0x${string}`;
  symbol: string;
  name: string;
  decimals: number;
}

export const TOKENS: readonly TokenInfo[] = [
  {
    address: "0xDc8d7f92bFE2e259cdea3A3f52f47E5f7d34Bd6f",
    symbol: "USDC",
    name: "USD Coin",
    decimals: 6,
  },
  {
    address: "0x335779BE3c5ebeCf4cE3B3C6b2E6327CC02c0163",
    symbol: "USDT",
    name: "Tether USD",
    decimals: 6,
  },
] as const;
