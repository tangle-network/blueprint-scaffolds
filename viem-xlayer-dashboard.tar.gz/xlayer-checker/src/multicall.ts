import type { PublicClient } from "viem";
import type { TokenInfo } from "./tokens.js";

export interface BalanceResult {
  token: string;
  symbol: string;
  balance: bigint;
  decimals: number;
}

const ERC20_ABI = [
  {
    inputs: [{ name: "account", type: "address" }],
    name: "balanceOf",
    outputs: [{ name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
] as const;

export async function fetchBalances(
  client: PublicClient,
  walletAddress: `0x${string}`,
  tokens: readonly TokenInfo[]
): Promise<BalanceResult[]> {
  const erc20Calls = tokens.map((token) => ({
    address: token.address,
    abi: ERC20_ABI,
    functionName: "balanceOf" as const,
    args: [walletAddress] as const,
  }));

  const [multicallResults, nativeBalance] = await Promise.all([
    client.multicall({ contracts: erc20Calls }),
    client.getBalance({ address: walletAddress }),
  ]);

  const erc20Balances: BalanceResult[] = tokens.map((token, i) => {
    const result = multicallResults[i];
    const balance =
      result.status === "success" && result.result !== undefined
        ? (result.result as bigint)
        : 0n;

    return {
      token: token.name,
      symbol: token.symbol,
      balance,
      decimals: token.decimals,
    };
  });

  const native: BalanceResult = {
    token: "OKB",
    symbol: "OKB",
    balance: nativeBalance,
    decimals: 18,
  };

  return [native, ...erc20Balances];
}
