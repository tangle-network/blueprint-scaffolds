import type { BalanceResult } from "./multicall.js";

const COLORS = {
  reset: "\x1b[0m",
  cyan: "\x1b[36m",
  green: "\x1b[32m",
  yellow: "\x1b[33m",
  dim: "\x1b[2m",
  bold: "\x1b[1m",
  magenta: "\x1b[35m",
} as const;

function supportsColor(): boolean {
  return process.env.NO_COLOR === undefined && process.stdout.isTTY === true;
}

export function formatTokenBalance(value: bigint, decimals: number): string {
  const divisor = 10n ** BigInt(decimals);
  const whole = value / divisor;
  const remainder = value % divisor;

  const fractional = remainder.toString().padStart(decimals, "0").slice(0, 4);

  if (whole === 0n && remainder === 0n) return "0.0000";

  return `${whole.toString()}.${fractional}`;
}

export function formatSummaryTable(results: BalanceResult[]): string {
  const c = supportsColor() ? COLORS : { ...COLORS, reset: "", cyan: "", green: "", yellow: "", dim: "", bold: "", magenta: "" };

  const tokenWidth = 14;
  const balanceWidth = 22;
  const symbolWidth = 8;

  const divider = `${c.dim}${"─".repeat(tokenWidth + balanceWidth + symbolWidth + 8)}${c.reset}`;

  const lines: string[] = [
    "",
    `${c.bold}${c.cyan}  X Layer Balance Summary${c.reset}`,
    "",
    divider,
    `  ${c.bold}${"Token".padEnd(tokenWidth)}${"Balance".padEnd(balanceWidth)}${"Symbol".padEnd(symbolWidth)}${c.reset}`,
    divider,
  ];

  for (const result of results) {
    const formatted = formatTokenBalance(result.balance, result.decimals);
    const color = result.balance > 0n ? c.green : c.dim;
    lines.push(
      `  ${result.token.padEnd(tokenWidth)}${color}${formatted.padEnd(balanceWidth)}${c.reset}${c.yellow}${result.symbol.padEnd(symbolWidth)}${c.reset}`
    );
  }

  lines.push(divider);
  lines.push("");

  return lines.join("\n");
}
