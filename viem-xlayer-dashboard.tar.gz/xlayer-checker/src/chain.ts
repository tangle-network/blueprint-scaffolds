import { defineChain } from "viem";

export const xLayer = defineChain({
  id: 196,
  name: "X Layer",
  nativeCurrency: {
    name: "OKB",
    symbol: "OKB",
    decimals: 18,
  },
  rpcUrls: {
    default: {
      http: ["https://xlayer-rpc.urlnodes.com/"],
    },
  },
  blockExplorers: {
    default: {
      name: "OKLink X Layer",
      url: "https://www.oklink.com/xlayer",
    },
  },
});
