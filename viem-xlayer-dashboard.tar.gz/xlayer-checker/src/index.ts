import { createPublicClient, http } from "viem";
import { xLayer } from "./chain.js";
import { TOKENS } from "./tokens.js";
import { fetchBalances } from "./multicall.js";
import { formatSummaryTable } from "./format.js";

const DEFAULT_WALLET = "0x742d35Cc6634C0532925a3b844Bc9e7595f5bA16" as const;

async function main(): Promise<void> {
  const walletArg = process.argv[2];
  const walletAddress = (walletArg ?? DEFAULT_WALLET) as `0x${string}`;

  if (!/^0x[0-9a-fA-F]{40}$/.test(walletAddress)) {
    console.error(`Invalid wallet address: ${walletAddress}`);
    process.exit(1);
  }

  const publicClient = createPublicClient({
    chain: xLayer,
    transport: http(),
  });

  console.log(`\nQuerying balances for ${walletAddress} on X Layer (chain ${xLayer.id})...`);

  try {
    const results = await fetchBalances(publicClient, walletAddress, TOKENS);
    console.log(formatSummaryTable(results));
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`\nFailed to fetch balances: ${message}`);
    process.exit(1);
  }
}

main();
