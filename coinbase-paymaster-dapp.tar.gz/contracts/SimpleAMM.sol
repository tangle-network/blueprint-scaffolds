// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ERC20} from "./lib/ERC20.sol";

/// @notice Minimal constant-product AMM for two ERC20 tokens.
/// @dev Reference-only contract; integrate with a real DEX/router for production.
contract SimpleAMM {
    ERC20 public immutable tokenA;
    ERC20 public immutable tokenB;

    uint256 public reserveA;
    uint256 public reserveB;

    uint256 public totalShares;
    mapping(address => uint256) public shares;

    event AddLiquidity(address indexed provider, uint256 amountA, uint256 amountB, uint256 mintedShares);
    event RemoveLiquidity(address indexed provider, uint256 amountA, uint256 amountB, uint256 burnedShares);
    event Swap(address indexed trader, address indexed tokenIn, uint256 amountIn, address indexed tokenOut, uint256 amountOut);

    constructor(address a, address b) {
        require(a != b, "SAME");
        tokenA = ERC20(a);
        tokenB = ERC20(b);
    }

    function addLiquidity(uint256 amountA, uint256 amountB) external returns (uint256 minted) {
        require(amountA > 0 && amountB > 0, "AMOUNTS");
        tokenA.transferFrom(msg.sender, address(this), amountA);
        tokenB.transferFrom(msg.sender, address(this), amountB);

        if (totalShares == 0) {
            minted = _sqrt(amountA * amountB);
        } else {
            uint256 mintA = (amountA * totalShares) / reserveA;
            uint256 mintB = (amountB * totalShares) / reserveB;
            minted = mintA < mintB ? mintA : mintB;
        }
        require(minted > 0, "MINT");

        reserveA += amountA;
        reserveB += amountB;
        totalShares += minted;
        shares[msg.sender] += minted;
        emit AddLiquidity(msg.sender, amountA, amountB, minted);
    }

    function removeLiquidity(uint256 burn) external returns (uint256 amountA, uint256 amountB) {
        require(burn > 0, "BURN");
        uint256 userShares = shares[msg.sender];
        require(userShares >= burn, "SHARES");

        amountA = (burn * reserveA) / totalShares;
        amountB = (burn * reserveB) / totalShares;

        shares[msg.sender] = userShares - burn;
        totalShares -= burn;

        reserveA -= amountA;
        reserveB -= amountB;

        tokenA.transfer(msg.sender, amountA);
        tokenB.transfer(msg.sender, amountB);
        emit RemoveLiquidity(msg.sender, amountA, amountB, burn);
    }

    function swapAForB(uint256 amountIn, uint256 minOut) external returns (uint256 amountOut) {
        tokenA.transferFrom(msg.sender, address(this), amountIn);
        uint256 amountInWithFee = (amountIn * 997) / 1000;
        amountOut = (amountInWithFee * reserveB) / (reserveA + amountInWithFee);
        require(amountOut >= minOut, "SLIP");
        reserveA += amountIn;
        reserveB -= amountOut;
        tokenB.transfer(msg.sender, amountOut);
        emit Swap(msg.sender, address(tokenA), amountIn, address(tokenB), amountOut);
    }

    function swapBForA(uint256 amountIn, uint256 minOut) external returns (uint256 amountOut) {
        tokenB.transferFrom(msg.sender, address(this), amountIn);
        uint256 amountInWithFee = (amountIn * 997) / 1000;
        amountOut = (amountInWithFee * reserveA) / (reserveB + amountInWithFee);
        require(amountOut >= minOut, "SLIP");
        reserveB += amountIn;
        reserveA -= amountOut;
        tokenA.transfer(msg.sender, amountOut);
        emit Swap(msg.sender, address(tokenB), amountIn, address(tokenA), amountOut);
    }

    function _sqrt(uint256 y) internal pure returns (uint256 z) {
        if (y == 0) return 0;
        uint256 x = y / 2 + 1;
        z = y;
        while (x < z) {
            z = x;
            x = (y / x + x) / 2;
        }
    }
}
