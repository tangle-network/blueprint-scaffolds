// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ERC20} from "./lib/ERC20.sol";

contract Token is ERC20 {
    constructor(string memory name_, string memory symbol_, uint256 initialSupply, address to) ERC20(name_, symbol_) {
        _mint(to, initialSupply);
    }
}
