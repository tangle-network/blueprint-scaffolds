# Contracts (Reference)

This folder contains Solidity reference contracts:

- `Token.sol`: simple ERC-20
- `SimpleAMM.sol`: minimal constant-product AMM

For ERC-4337 integration on Base, pair these with a standard EntryPoint + account factory and submit UserOperations through a bundler.
