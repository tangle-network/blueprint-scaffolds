# DeFi Paymaster (Base)

Vite + React + TypeScript demo showing how a DeFi UI can be structured around gasless transactions using an ERC-4337-style smart account + Coinbase Paymaster sponsorship.

## Quickstart

```bash
pnpm install
pnpm dev
```

## Environment

Create `.env`:

```bash
VITE_BASE_RPC_URL=https://sepolia.base.org
VITE_BUNDLER_RPC_URL=
VITE_ENTRYPOINT_ADDRESS=
VITE_COINBASE_PAYMASTER_RPC_URL=
VITE_COINBASE_PAYMASTER_API_KEY=
```

If the Paymaster vars are not set, the app runs in “demo mode” and returns random `userOpHash` values.

## Contracts

Solidity contracts are in `contracts/`. They are provided as reference and are not compiled by the frontend build.
