import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatAddress(address: string): string {
  return `${address.slice(0, 6)}...${address.slice(-4)}`
}

export function formatTokenAmount(amount: bigint, decimals: number = 18): string {
  const value = Number(amount) / Math.pow(10, decimals)
  return value.toLocaleString(undefined, { maximumFractionDigits: 6 })
}

export function parseTokenAmount(amount: string, decimals: number = 18): bigint {
  const value = parseFloat(amount)
  return BigInt(Math.floor(value * Math.pow(10, decimals)))
}
