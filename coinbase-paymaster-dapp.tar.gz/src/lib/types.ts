export interface Token {
  symbol: string
  name: string
  address: string
  decimals: number
  logoURI: string
}

export interface Pool {
  id: string
  tokenA: Token
  tokenB: Token
  reserveA: string
  reserveB: string
  tvl: string
  volume24h: string
  fee: number
  apy: string
}

export interface SwapQuote {
  inputAmount: string
  outputAmount: string
  priceImpact: string
  fee: string
  route: string[]
  gasEstimate: string
  gasSponsored: boolean
}

export interface Transaction {
  id: string
  type: "swap" | "add_liquidity" | "remove_liquidity"
  status: "pending" | "confirmed" | "failed"
  hash: string
  from: string
  to: string
  tokenIn?: string
  tokenOut?: string
  amountIn?: string
  amountOut?: string
  timestamp: number
  gasSponsored: boolean
  gasSaved?: string
}

export interface PaymasterConfig {
  sponsorshipEnabled: boolean
  maxGasPerTransaction: string
  dailyGasLimit: string
  whitelistedTokens: string[]
  sponsoredMethods: string[]
}

export interface SmartAccountInfo {
  address: string
  isDeployed: boolean
  owner: string
  nonce: number
}

export const BASE_CHAIN_ID = 8453
export const BASE_RPC_URL = "https://mainnet.base.org"
export const BASE_SCAN_URL = "https://basescan.org"
export const ENTRY_POINT_ADDRESS = "0x5FF137D4b0FDCD49DcA30c7CF57E578a026d2789"
export const PAYMASTER_ADDRESS = "0x00000000000000CE4A375360E9f1D9e4bF72e06A"

export const SUPPORTED_TOKENS: Token[] = [
  { symbol: "ETH", name: "Ethereum", address: "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE", decimals: 18, logoURI: "" },
  { symbol: "USDC", name: "USD Coin", address: "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913", decimals: 6, logoURI: "" },
  { symbol: "USDbC", name: "USD Base Coin", address: "0xd9aAEc86B65D86f6A7B5B1b0c42FFA531710b6CA", decimals: 6, logoURI: "" },
  { symbol: "DAI", name: "Dai Stablecoin", address: "0x50c5725949A6F0c72E6C4a641F24049A917DB0Cb", decimals: 18, logoURI: "" },
  { symbol: "WETH", name: "Wrapped Ether", address: "0x4200000000000000000000000000000000000006", decimals: 18, logoURI: "" },
  { symbol: "cbETH", name: "Coinbase Staked ETH", address: "0x2Ae3F1Ec7F1F5012CFEab0185bfc7aa3cf0DEc22", decimals: 18, logoURI: "" },
]
