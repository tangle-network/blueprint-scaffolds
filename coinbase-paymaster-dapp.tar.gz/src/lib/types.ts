export interface Token {
  symbol: string
  name: string
  address: string
  decimals: number
  logoURI: string
}

export interface Pool {
  token0: Token
  token1: Token
  reserve0: bigint
  reserve1: bigint
  totalLiquidity: bigint
  lpToken: string
  fee: number
  apy: number
}

export interface SwapQuote {
  inputAmount: bigint
  outputAmount: bigint
  priceImpact: number
  fee: bigint
  route: string[]
  estimatedGas: bigint
  gasless: boolean
}

export interface Transaction {
  id: string
  type: 'swap' | 'add_liquidity' | 'remove_liquidity'
  from: string
  to: string
  tokenIn?: string
  tokenOut?: string
  amountIn?: bigint
  amountOut?: bigint
  timestamp: number
  hash: string
  status: 'pending' | 'confirmed' | 'failed'
  gasSponsored: boolean
  gasSaved: string
}

export interface SmartAccount {
  address: string
  owner: string
  salt: bigint
  deployed: boolean
  entryPoint: string
}

export interface PaymasterConfig {
  sponsorAddress: string
  tokenWhitelist: string[]
  maxGasPerTx: bigint
  dailyLimit: bigint
  dailySpent: bigint
  active: boolean
}

export interface WalletState {
  address: string | null
  chainId: number | null
  connected: boolean
  smartAccount: SmartAccount | null
}
