import type { Token } from './types'

export const BASE_CHAIN_ID = 8453
export const BASE_RPC_URL = 'https://mainnet.base.org'
export const ENTRY_POINT_V07 = '0x0000000071727De22E5E9d8BAf0edAc6f37da032'

export const COINBASE_PAYMASTER_URL = 'https://paymaster.base.org'
export const COINBASE_SMART_WALLET_FACTORY = '0x0BA5Ed042597e7106e9bD0a93Df1F5E4e96eC31D'

export const WETH_TOKEN: Token = {
  symbol: 'WETH',
  name: 'Wrapped Ether',
  address: '0x4200000000000000000000000000000000000006',
  decimals: 18,
  logoURI: 'https://assets.coingecko.com/coins/images/252/small/ethereum.png',
}

export const USDC_TOKEN: Token = {
  symbol: 'USDC',
  name: 'USD Coin',
  address: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
  decimals: 6,
  logoURI: 'https://assets.coingecko.com/coins/images/6319/small/usdc.png',
}

export const DAI_TOKEN: Token = {
  symbol: 'DAI',
  name: 'Dai Stablecoin',
  address: '0x50c5725949A6F0c72E6C4a641F24049A917DB0Cb',
  decimals: 18,
  logoURI: 'https://assets.coingecko.com/coins/images/9956/small/dai-multi-collateral.png',
}

export const BASE_TOKEN: Token = {
  symbol: 'ETH',
  name: 'Ethereum',
  address: '0xEeeeeEeeeEeEeeEeEeEeeEeeeeEeeeeEeeeeeE',
  decimals: 18,
  logoURI: 'https://assets.coingecko.com/coins/images/279/small/ethereum.png',
}

export const SUPPORTED_TOKENS: Token[] = [BASE_TOKEN, WETH_TOKEN, USDC_TOKEN, DAI_TOKEN]

export const POOL_FEE_TIER = 0.003

export const NAV_ITEMS = [
  { label: 'Swap', path: '/' },
  { label: 'Pools', path: '/pools' },
  { label: 'History', path: '/history' },
  { label: 'Paymaster', path: '/paymaster' },
] as const
