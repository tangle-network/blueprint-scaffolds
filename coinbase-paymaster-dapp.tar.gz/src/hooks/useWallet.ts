import { useState, useCallback } from "react"
import { type SmartAccountInfo, BASE_CHAIN_ID, ENTRY_POINT_ADDRESS, PAYMASTER_ADDRESS } from "@/lib/types"

interface WalletState {
  isConnected: boolean
  address: string | null
  chainId: number | null
  balance: string
  isConnecting: boolean
  smartAccount: SmartAccountInfo | null
}

export function useWallet() {
  const [wallet, setWallet] = useState<WalletState>({
    isConnected: false,
    address: null,
    chainId: null,
    balance: "0.00",
    isConnecting: false,
    smartAccount: null,
  })

  const connect = useCallback(async () => {
    setWallet((prev) => ({ ...prev, isConnecting: true }))
    try {
      await new Promise((r) => setTimeout(r, 1200))
      const mockAddress = "0x" + Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join("")
      const smartAccount: SmartAccountInfo = {
        address: "0x" + Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join(""),
        isDeployed: true,
        owner: mockAddress,
        nonce: 0,
      }
      setWallet({
        isConnected: true,
        address: mockAddress,
        chainId: BASE_CHAIN_ID,
        balance: (Math.random() * 2 + 0.1).toFixed(4),
        isConnecting: false,
        smartAccount,
      })
    } catch {
      setWallet((prev) => ({ ...prev, isConnecting: false }))
    }
  }, [])

  const disconnect = useCallback(() => {
    setWallet({
      isConnected: false,
      address: null,
      chainId: null,
      balance: "0.00",
      isConnecting: false,
      smartAccount: null,
    })
  }, [])

  return { ...wallet, connect, disconnect, entryPointAddress: ENTRY_POINT_ADDRESS, paymasterAddress: PAYMASTER_ADDRESS }
}
