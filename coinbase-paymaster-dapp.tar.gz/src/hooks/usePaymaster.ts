import { useState, useCallback } from "react"
import type { PaymasterConfig } from "@/lib/types"

const defaultConfig: PaymasterConfig = {
  sponsorshipEnabled: true,
  maxGasPerTransaction: "500000",
  dailyGasLimit: "10000000",
  whitelistedTokens: ["USDC", "WETH", "ETH", "DAI"],
  sponsoredMethods: ["swap", "addLiquidity", "removeLiquidity"],
}

export function usePaymaster() {
  const [config, setConfig] = useState<PaymasterConfig>(defaultConfig)
  const [isSponsoring, setIsSponsoring] = useState(false)
  const [gasSaved, setGasSaved] = useState("0.00")

  const sponsorGas = useCallback(async (operation: string): Promise<boolean> => {
    if (!config.sponsorshipEnabled) return false
    if (!config.sponsoredMethods.includes(operation)) return false

    setIsSponsoring(true)
    try {
      await new Promise((r) => setTimeout(r, 800))
      const saved = (Math.random() * 0.005 + 0.001).toFixed(6)
      setGasSaved(saved)
      setIsSponsoring(false)
      return true
    } catch {
      setIsSponsoring(false)
      return false
    }
  }, [config])

  const updateConfig = useCallback((updates: Partial<PaymasterConfig>) => {
    setConfig((prev) => ({ ...prev, ...updates }))
  }, [])

  return {
    config,
    updateConfig,
    sponsorGas,
    isSponsoring,
    gasSaved,
    isSponsorshipEnabled: config.sponsorshipEnabled,
  }
}
