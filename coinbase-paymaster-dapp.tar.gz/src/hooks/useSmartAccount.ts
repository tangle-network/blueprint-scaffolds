import { useState, useCallback } from "react"
import type { SmartAccountInfo } from "@/lib/types"

interface SmartAccountState {
  isLoading: boolean
  error: string | null
}

export function useSmartAccount(smartAccount: SmartAccountInfo | null) {
  const [state, setState] = useState<SmartAccountState>({
    isLoading: false,
    error: null,
  })

  const createAccount = useCallback(async () => {
    setState({ isLoading: true, error: null })
    try {
      await new Promise((r) => setTimeout(r, 2000))
      const account: SmartAccountInfo = {
        address: "0x" + Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join(""),
        isDeployed: true,
        owner: smartAccount?.owner ?? "",
        nonce: 0,
      }
      setState({ isLoading: false, error: null })
      return account
    } catch (err) {
      setState({ isLoading: false, error: "Failed to create smart account" })
      return null
    }
  }, [smartAccount])

  const executeUserOp = useCallback(async (target: string, data: string) => {
    setState((prev) => ({ ...prev, isLoading: true }))
    try {
      await new Promise((r) => setTimeout(r, 3000))
      const hash = "0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join("")
      setState((prev) => ({ ...prev, isLoading: false }))
      return hash
    } catch {
      setState((prev) => ({ ...prev, isLoading: false, error: "User operation failed" }))
      return null
    }
  }, [])

  return {
    ...state,
    createAccount,
    executeUserOp,
    accountAddress: smartAccount?.address ?? null,
    isDeployed: smartAccount?.isDeployed ?? false,
  }
}
