import { useState, useCallback } from "react"
import type { Transaction, Token } from "@/lib/types"
import { SUPPORTED_TOKENS } from "@/lib/types"

const mockTransactions: Transaction[] = [
  {
    id: "1",
    type: "swap",
    status: "confirmed",
    hash: "0xabc123",
    from: "0x1234...5678",
    to: "0x8765...4321",
    tokenIn: "ETH",
    tokenOut: "USDC",
    amountIn: "0.5",
    amountOut: "1850.25",
    timestamp: Date.now() - 3600000,
    gasSponsored: true,
    gasSaved: "0.0023",
  },
  {
    id: "2",
    type: "add_liquidity",
    status: "confirmed",
    hash: "0xdef456",
    from: "0x1234...5678",
    to: "Pool: ETH/USDC",
    tokenIn: "ETH",
    tokenOut: "USDC",
    amountIn: "1.0",
    amountOut: "3700.50",
    timestamp: Date.now() - 7200000,
    gasSponsored: true,
    gasSaved: "0.0031",
  },
  {
    id: "3",
    type: "swap",
    status: "confirmed",
    hash: "0xghi789",
    from: "0x1234...5678",
    to: "0x8765...4321",
    tokenIn: "USDC",
    tokenOut: "WETH",
    amountIn: "2000",
    amountOut: "0.5405",
    timestamp: Date.now() - 86400000,
    gasSponsored: true,
    gasSaved: "0.0019",
  },
  {
    id: "4",
    type: "remove_liquidity",
    status: "pending",
    hash: "0xjkl012",
    from: "Pool: WETH/USDC",
    to: "0x1234...5678",
    tokenIn: "LP",
    tokenOut: "WETH+USDC",
    amountIn: "0.5",
    amountOut: "0.27 + 1000",
    timestamp: Date.now() - 1800000,
    gasSponsored: true,
    gasSaved: "0.0028",
  },
]

export function useTransactions() {
  const [transactions, setTransactions] = useState<Transaction[]>(mockTransactions)

  const addTransaction = useCallback((tx: Omit<Transaction, "id" | "timestamp">) => {
    const newTx: Transaction = {
      ...tx,
      id: String(Date.now()),
      timestamp: Date.now(),
    }
    setTransactions((prev) => [newTx, ...prev])
    return newTx
  }, [])

  const totalGasSaved = transactions.reduce((sum, tx) => {
    return sum + parseFloat(tx.gasSaved || "0")
  }, 0)

  return { transactions, addTransaction, totalGasSaved: totalGasSaved.toFixed(6) }
}
