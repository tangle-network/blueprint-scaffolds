import { useState, useCallback } from "react"
import type { Pool, Token, SwapQuote } from "@/lib/types"
import { SUPPORTED_TOKENS } from "@/lib/types"

const mockPools: Pool[] = [
  {
    id: "1",
    tokenA: SUPPORTED_TOKENS[0],
    tokenB: SUPPORTED_TOKENS[1],
    reserveA: "1234.56",
    reserveB: "4567890.12",
    tvl: "$4,567,890",
    volume24h: "$234,567",
    fee: 0.3,
    apy: "12.5",
  },
  {
    id: "2",
    tokenA: SUPPORTED_TOKENS[4],
    tokenB: SUPPORTED_TOKENS[1],
    reserveA: "567.89",
    reserveB: "2100000.00",
    tvl: "$2,100,000",
    volume24h: "$189,432",
    fee: 0.3,
    apy: "8.7",
  },
  {
    id: "3",
    tokenA: SUPPORTED_TOKENS[3],
    tokenB: SUPPORTED_TOKENS[1],
    reserveA: "890123.45",
    reserveB: "890000.00",
    tvl: "$890,000",
    volume24h: "$56,789",
    fee: 0.05,
    apy: "5.2",
  },
  {
    id: "4",
    tokenA: SUPPORTED_TOKENS[0],
    tokenB: SUPPORTED_TOKENS[5],
    reserveA: "456.78",
    reserveB: "490.12",
    tvl: "$1,678,900",
    volume24h: "$123,456",
    fee: 0.3,
    apy: "6.3",
  },
]

export function usePools() {
  const [pools] = useState<Pool[]>(mockPools)
  const [userPositions, setUserPositions] = useState<
    { pool: Pool; lpTokenBalance: string; share: string }[]
  >([
    { pool: mockPools[0], lpTokenBalance: "0.45", share: "0.036" },
    { pool: mockPools[1], lpTokenBalance: "1.23", share: "0.217" },
  ])
  const [isLoading, setIsLoading] = useState(false)

  const getQuote = useCallback(
    async (tokenIn: Token, tokenOut: Token, amountIn: string): Promise<SwapQuote | null> => {
      setIsLoading(true)
      await new Promise((r) => setTimeout(r, 1000))
      const inNum = parseFloat(amountIn) || 0
      const rate = tokenIn.symbol === "ETH" || tokenIn.symbol === "WETH" ? 3700 : 1
      const outNum = inNum * rate * (1 - 0.003)
      const quote: SwapQuote = {
        inputAmount: amountIn,
        outputAmount: outNum.toFixed(6),
        priceImpact: (Math.random() * 0.5).toFixed(2),
        fee: (inNum * 0.003).toFixed(6),
        route: [tokenIn.symbol, tokenOut.symbol],
        gasEstimate: "150000",
        gasSponsored: true,
      }
      setIsLoading(false)
      return quote
    },
    []
  )

  const addLiquidity = useCallback(
    async (poolId: string, amountA: string, amountB: string): Promise<string | null> => {
      setIsLoading(true)
      await new Promise((r) => setTimeout(r, 2000))
      setIsLoading(false)
      return "0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join("")
    },
    []
  )

  const removeLiquidity = useCallback(
    async (poolId: string, lpAmount: string): Promise<string | null> => {
      setIsLoading(true)
      await new Promise((r) => setTimeout(r, 2000))
      setIsLoading(false)
      return "0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join("")
    },
    []
  )

  return { pools, userPositions, isLoading, getQuote, addLiquidity, removeLiquidity }
}
