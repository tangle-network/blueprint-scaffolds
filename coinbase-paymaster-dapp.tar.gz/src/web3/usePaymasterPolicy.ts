import type { PaymasterPolicy } from './types'

const KEY = 'defi-paymaster:policy'

export function usePaymasterPolicy() {
  async function simulateSavePolicy(policy: PaymasterPolicy) {
    localStorage.setItem(KEY, JSON.stringify(policy))
    await new Promise((r) => setTimeout(r, 300))
  }

  function loadPolicy(): PaymasterPolicy {
    try {
      const raw = localStorage.getItem(KEY)
      if (!raw) {
        return { maxDailySpendUsd: 5, allow: { swap: true, liquidity: true } }
      }
      return JSON.parse(raw) as PaymasterPolicy
    } catch {
      return { maxDailySpendUsd: 5, allow: { swap: true, liquidity: true } }
    }
  }

  return { simulateSavePolicy, loadPolicy }
}
