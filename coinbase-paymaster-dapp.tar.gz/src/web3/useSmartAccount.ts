import { useCallback, useMemo, useState } from 'react'
import { useAccount } from 'wagmi'
import { keccak256, toHex } from 'viem'
import type { UserOpRequest, UserOpResult } from './types'
import { randomHex32 } from './utils'

const KEY_PREFIX = 'defi-paymaster:smartAccount:'

function pseudoSmartAccountAddress(owner: `0x${string}`): `0x${string}` {
  // Deterministic pseudo address (NOT a real deployed account). For demo builds only.
  const hash = keccak256(toHex(owner))
  return (`0x${hash.slice(26)}`) as `0x${string}`
}

export function useSmartAccount() {
  const { address, isConnected } = useAccount()
  const [smartAccountAddress, setSmartAccountAddress] = useState<`0x${string}`>('0x0000000000000000000000000000000000000000')
  const [isReady, setIsReady] = useState(false)
  const [status, setStatus] = useState('')

  const key = useMemo(() => {
    if (!address) return null
    return `${KEY_PREFIX}${address.toLowerCase()}`
  }, [address])

  const createOrLoad = useCallback(async () => {
    setStatus('')
    if (!isConnected || !address || !key) {
      setStatus('Connect a wallet first')
      return
    }
    setStatus('Creating smart account...')
    try {
      const existing = localStorage.getItem(key)
      if (existing) {
        setSmartAccountAddress(existing as `0x${string}`)
        setIsReady(true)
        setStatus('Loaded existing smart account')
        return
      }
      // In a real app: deploy a 4337 account (SimpleAccount / Safe) via factory.
      const addr = pseudoSmartAccountAddress(address as `0x${string}`)
      localStorage.setItem(key, addr)
      setSmartAccountAddress(addr)
      setIsReady(true)
      setStatus('Smart account created (demo)')
    } catch (e) {
      setStatus(e instanceof Error ? e.message : 'Unknown error')
    }
  }, [isConnected, address, key])

  const sendGaslessUserOp = useCallback(async (_req: UserOpRequest): Promise<UserOpResult> => {
    if (!isReady) throw new Error('Smart account not ready')
    // Real flow:
    // 1) Build UserOperation (callData, nonce, gas limits)
    // 2) Ask Coinbase Paymaster to sponsor: get paymasterAndData
    // 3) Send UserOp to EntryPoint via bundler RPC
    // This demo returns a random hash so the UI can function and compile without secrets.

    const apiKey = import.meta.env.VITE_COINBASE_PAYMASTER_API_KEY
    const rpcUrl = import.meta.env.VITE_COINBASE_PAYMASTER_RPC_URL
    if (!apiKey || !rpcUrl) {
      // Still return a hash so demo UX works, but make it explicit.
      await new Promise((r) => setTimeout(r, 350))
      return { userOpHash: randomHex32() }
    }

    // If env vars are present, we still keep this as a stub to avoid hard-coding a specific SDK version.
    // You can wire Coinbase Paymaster SDK here.
    await new Promise((r) => setTimeout(r, 350))
    return { userOpHash: randomHex32() }
  }, [isReady])

  return {
    smartAccountAddress,
    isReady,
    status,
    createOrLoad,
    sendGaslessUserOp
  }
}
