import { useCallback, useEffect, useMemo, useState } from 'react'

export type TxRecord = {
  id: string
  kind: string
  status: 'submitted' | 'confirmed'
  timestamp: number
  summary: string
  userOpHash: string
  smartAccount: string
}

type Store = {
  txs: TxRecord[]
  addTx: (tx: TxRecord) => void
  clear: () => void
}

const KEY = 'defi-paymaster:txs'

export function useTxStore(): Store {
  const [txs, setTxs] = useState<TxRecord[]>([])

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY)
      if (!raw) return
      const parsed = JSON.parse(raw) as TxRecord[]
      if (Array.isArray(parsed)) setTxs(parsed)
    } catch {
      // ignore
    }
  }, [])

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(txs))
    } catch {
      // ignore
    }
  }, [txs])

  const addTx = useCallback((tx: TxRecord) => {
    setTxs((prev: TxRecord[]) => [tx, ...prev].slice(0, 50))
  }, [])

  const clear = useCallback(() => setTxs([]), [])

  return useMemo(() => ({ txs, addTx, clear }), [txs, addTx, clear])
}
