export type UserOpKind = 'swap' | 'addLiquidity' | 'removeLiquidity'

export type UserOpRequest =
  | {
      kind: 'swap'
      fromToken: string
      toToken: string
      amountIn: bigint
    }
  | {
      kind: 'addLiquidity'
      amountA: bigint
      amountB: bigint
    }
  | {
      kind: 'removeLiquidity'
      shares: bigint
    }

export type UserOpResult = {
  userOpHash: `0x${string}`
}

export type PaymasterPolicy = {
  maxDailySpendUsd: number
  allow: {
    swap: boolean
    liquidity: boolean
  }
}
