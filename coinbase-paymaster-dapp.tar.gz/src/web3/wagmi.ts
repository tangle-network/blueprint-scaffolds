import { http, createConfig } from 'wagmi'
import { baseSepolia } from './chains'

export const wagmiConfig = createConfig({
  chains: [baseSepolia],
  transports: {
    [baseSepolia.id]: http(baseSepolia.rpcUrls.default.http[0])
  },
  ssr: false
})
