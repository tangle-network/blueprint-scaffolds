import { formatUnits, parseUnits } from 'viem'

export function parseUnitsSafe(value: string, decimals: number): bigint | null {
  try {
    const trimmed = value.trim()
    if (!trimmed) return null
    // Reject negative values and scientific notation in this demo
    if (trimmed.startsWith('-') || /e/i.test(trimmed)) return null
    return parseUnits(trimmed as `${number}`, decimals)
  } catch {
    return null
  }
}

export function formatUnitsSafe(value: bigint, decimals: number): string {
  try {
    return formatUnits(value, decimals)
  } catch {
    return '0'
  }
}

export function randomHex32(): `0x${string}` {
  const bytes = new Uint8Array(32)
  crypto.getRandomValues(bytes)
  const hex = Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
  return `0x${hex}`
}
