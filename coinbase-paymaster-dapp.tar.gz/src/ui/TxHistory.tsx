import { useTxStore } from '../web3/useTxStore'

export function TxHistory() {
  const { txs, clear } = useTxStore()
  return (
    <div className="card">
      <div className="cardHeader">
        <div className="cardTitle">Transaction History</div>
        <button className="btn small" onClick={clear}>
          Clear
        </button>
      </div>
      {txs.length === 0 ? (
        <div className="empty">No transactions yet.</div>
      ) : (
        <div className="list">
          {txs.map((t) => (
            <div className="listItem" key={t.id}>
              <div className="listTop">
                <div className="badge">{t.kind}</div>
                <div className={t.status === 'submitted' ? 'state' : 'state done'}>{t.status}</div>
              </div>
              <div className="listSummary">{t.summary}</div>
              <div className="listMeta">
                <span>userOpHash: {t.userOpHash.slice(0, 10)}...</span>
                <span>smart acct: {t.smartAccount.slice(0, 10)}...</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
