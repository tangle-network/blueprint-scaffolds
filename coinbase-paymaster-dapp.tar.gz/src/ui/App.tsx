import { useMemo, useState } from 'react'
import { useAccount, useConnect, useDisconnect } from 'wagmi'
import { injected } from 'wagmi/connectors'

import { SwapCard } from './SwapCard'
import { LiquidityCard } from './LiquidityCard'
import { TxHistory } from './TxHistory'
import { SponsorshipPolicy } from './SponsorshipPolicy'
import { SmartAccountCard } from './SmartAccountCard'

export default function App() {
  const { address, isConnected } = useAccount()
  const { connect, isPending } = useConnect()
  const { disconnect } = useDisconnect()
  const [tab, setTab] = useState<'swap' | 'liquidity' | 'history' | 'policy'>('swap')

  const shortAddr = useMemo(() => {
    if (!address) return ''
    return `${address.slice(0, 6)}...${address.slice(-4)}`
  }, [address])

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <div className="logo" aria-hidden="true" />
          <div className="brandText">
            <div className="title">DeFi Paymaster</div>
            <div className="subtitle">Gasless swaps & pools on Base (ERC-4337 + Coinbase Paymaster)</div>
          </div>
        </div>

        <div className="wallet">
          {!isConnected ? (
            <button
              className="btn primary"
              onClick={() => connect({ connector: injected() })}
              disabled={isPending}
            >
              {isPending ? 'Connecting...' : 'Connect Wallet'}
            </button>
          ) : (
            <div className="walletConnected">
              <div className="pill">{shortAddr}</div>
              <button className="btn" onClick={() => disconnect()}>
                Disconnect
              </button>
            </div>
          )}
        </div>
      </header>

      <main className="content">
        <section className="left">
          <SmartAccountCard />

          <nav className="tabs" aria-label="Main sections">
            <button className={tab === 'swap' ? 'tab active' : 'tab'} onClick={() => setTab('swap')}>
              Swap
            </button>
            <button
              className={tab === 'liquidity' ? 'tab active' : 'tab'}
              onClick={() => setTab('liquidity')}
            >
              Liquidity
            </button>
            <button
              className={tab === 'history' ? 'tab active' : 'tab'}
              onClick={() => setTab('history')}
            >
              History
            </button>
            <button className={tab === 'policy' ? 'tab active' : 'tab'} onClick={() => setTab('policy')}>
              Sponsorship
            </button>
          </nav>

          {tab === 'swap' && <SwapCard />}
          {tab === 'liquidity' && <LiquidityCard />}
          {tab === 'history' && <TxHistory />}
          {tab === 'policy' && <SponsorshipPolicy />}
        </section>

        <aside className="right">
          <div className="panel">
            <div className="panelTitle">What is gasless here?</div>
            <div className="panelBody">
              This demo prepares an ERC-4337-style “user operation” and shows how you would route it through a
              Coinbase Paymaster policy. The actual sending is stubbed so the app compiles without secrets.
            </div>
          </div>

          <div className="panel">
            <div className="panelTitle">Network</div>
            <div className="panelBody">
              Base Sepolia by default. Configure RPC in <code>.env</code>.
            </div>
          </div>

          <div className="panel">
            <div className="panelTitle">Contracts</div>
            <div className="panelBody">
              Contracts are included under <code>contracts/</code> with a minimal AMM and a mock paymaster interface.
              Deploy scripts are intentionally omitted from the frontend build.
            </div>
          </div>
        </aside>
      </main>
    </div>
  )
}
