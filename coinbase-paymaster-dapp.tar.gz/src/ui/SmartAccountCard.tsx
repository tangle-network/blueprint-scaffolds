import { useAccount } from 'wagmi'
import { useSmartAccount } from '../web3/useSmartAccount'

export function SmartAccountCard() {
  const { isConnected } = useAccount()
  const { smartAccountAddress, isReady, createOrLoad, status } = useSmartAccount()

  return (
    <div className="card hero">
      <div className="heroLeft">
        <div className="cardTitle">Smart Account</div>
        <div className="heroText">
          Create (or load) an ERC-4337 smart account. This address is used as the sender for gasless actions.
        </div>
      </div>
      <div className="heroRight">
        <button className="btn primary" onClick={createOrLoad} disabled={!isConnected || isReady}>
          {!isConnected ? 'Connect Wallet' : isReady ? 'Ready' : 'Create Smart Account'}
        </button>
        <div className="pill mono">{isReady ? smartAccountAddress : 'Not created'}</div>
        {status ? <div className="status">{status}</div> : null}
      </div>
    </div>
  )
}
