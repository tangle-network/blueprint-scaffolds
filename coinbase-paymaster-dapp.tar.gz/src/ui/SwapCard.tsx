import { useMemo, useState } from 'react'
import { useAccount } from 'wagmi'

import { useSmartAccount } from '../web3/useSmartAccount'
import { useTxStore } from '../web3/useTxStore'
import { formatUnitsSafe, parseUnitsSafe } from '../web3/utils'

type TokenSymbol = 'TOKA' | 'TOKB'

export function SwapCard() {
  const { isConnected } = useAccount()
  const { smartAccountAddress, sendGaslessUserOp, isReady } = useSmartAccount()
  const { addTx } = useTxStore()

  const [fromToken, setFromToken] = useState<TokenSymbol>('TOKA')
  const [toToken, setToToken] = useState<TokenSymbol>('TOKB')
  const [amountIn, setAmountIn] = useState('')
  const [status, setStatus] = useState<string>('')

  const disabled = !isConnected || !isReady

  const quote = useMemo(() => {
    const parsed = parseUnitsSafe(amountIn, 18)
    if (!parsed) return ''
    // Demo quote: 1:1 minus 0.3% fee
    const out = (parsed * 997n) / 1000n
    return formatUnitsSafe(out, 18)
  }, [amountIn])

  async function onSwap() {
    setStatus('')
    const parsed = parseUnitsSafe(amountIn, 18)
    if (!parsed) {
      setStatus('Enter a valid amount')
      return
    }
    if (fromToken === toToken) {
      setStatus('Select two different tokens')
      return
    }

    setStatus('Preparing gasless swap...')
    try {
      // For a real integration, build calldata for router.swapExactTokensForTokens.
      // Here we send a stub userOp to demonstrate paymaster flow.
      const res = await sendGaslessUserOp({
        kind: 'swap',
        fromToken,
        toToken,
        amountIn: parsed
      })
      addTx({
        id: res.userOpHash,
        kind: 'swap',
        status: 'submitted',
        timestamp: Date.now(),
        summary: `Swap ${amountIn} ${fromToken} -> ~${quote} ${toToken}`,
        userOpHash: res.userOpHash,
        smartAccount: smartAccountAddress
      })
      setStatus(`Submitted (userOpHash: ${res.userOpHash.slice(0, 10)}...)`)
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Unknown error'
      setStatus(msg)
    }
  }

  return (
    <div className="card">
      <div className="cardHeader">
        <div className="cardTitle">Token Swap</div>
        <div className="cardHint">Gasless via Paymaster</div>
      </div>

      <div className="row">
        <label className="label">From</label>
        <select className="select" value={fromToken} onChange={(e) => setFromToken(e.target.value as TokenSymbol)}>
          <option value="TOKA">TOKA</option>
          <option value="TOKB">TOKB</option>
        </select>
      </div>

      <div className="row">
        <label className="label">To</label>
        <select className="select" value={toToken} onChange={(e) => setToToken(e.target.value as TokenSymbol)}>
          <option value="TOKA">TOKA</option>
          <option value="TOKB">TOKB</option>
        </select>
      </div>

      <div className="row">
        <label className="label">Amount</label>
        <input
          className="input"
          inputMode="decimal"
          placeholder="0.0"
          value={amountIn}
          onChange={(e) => setAmountIn(e.target.value)}
        />
      </div>

      <div className="row">
        <div className="label">Quote</div>
        <div className="value">{quote ? `~${quote} ${toToken}` : '-'}</div>
      </div>

      <button className="btn primary" onClick={onSwap} disabled={disabled}>
        {disabled ? 'Connect & Create Smart Account' : 'Swap (Gasless)'}
      </button>

      {status ? <div className="status">{status}</div> : null}
    </div>
  )
}
