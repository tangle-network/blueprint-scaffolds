import { useState } from 'react'
import { useAccount } from 'wagmi'

import { useSmartAccount } from '../web3/useSmartAccount'
import { useTxStore } from '../web3/useTxStore'
import { parseUnitsSafe } from '../web3/utils'

export function LiquidityCard() {
  const { isConnected } = useAccount()
  const { smartAccountAddress, sendGaslessUserOp, isReady } = useSmartAccount()
  const { addTx } = useTxStore()

  const [a, setA] = useState('')
  const [b, setB] = useState('')
  const [status, setStatus] = useState('')

  const disabled = !isConnected || !isReady

  async function onAdd() {
    setStatus('')
    const pa = parseUnitsSafe(a, 18)
    const pb = parseUnitsSafe(b, 18)
    if (!pa || !pb) {
      setStatus('Enter valid amounts')
      return
    }
    setStatus('Preparing gasless add liquidity...')
    try {
      const res = await sendGaslessUserOp({ kind: 'addLiquidity', amountA: pa, amountB: pb })
      addTx({
        id: res.userOpHash,
        kind: 'addLiquidity',
        status: 'submitted',
        timestamp: Date.now(),
        summary: `Add liquidity A=${a}, B=${b}`,
        userOpHash: res.userOpHash,
        smartAccount: smartAccountAddress
      })
      setStatus(`Submitted (userOpHash: ${res.userOpHash.slice(0, 10)}...)`)
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Unknown error'
      setStatus(msg)
    }
  }

  async function onRemove() {
    setStatus('')
    // Demo: remove fixed liquidity shares via stub userOp
    setStatus('Preparing gasless remove liquidity...')
    try {
      const res = await sendGaslessUserOp({ kind: 'removeLiquidity', shares: 1_000_000_000_000_000_000n })
      addTx({
        id: res.userOpHash,
        kind: 'removeLiquidity',
        status: 'submitted',
        timestamp: Date.now(),
        summary: 'Remove liquidity (demo shares)',
        userOpHash: res.userOpHash,
        smartAccount: smartAccountAddress
      })
      setStatus(`Submitted (userOpHash: ${res.userOpHash.slice(0, 10)}...)`)
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Unknown error'
      setStatus(msg)
    }
  }

  return (
    <div className="card">
      <div className="cardHeader">
        <div className="cardTitle">Liquidity Pools</div>
        <div className="cardHint">Add / Remove (Gasless)</div>
      </div>

      <div className="grid2">
        <div className="row">
          <label className="label">Token A (TOKA)</label>
          <input
            className="input"
            inputMode="decimal"
            placeholder="0.0"
            value={a}
            onChange={(e) => setA(e.target.value)}
          />
        </div>
        <div className="row">
          <label className="label">Token B (TOKB)</label>
          <input
            className="input"
            inputMode="decimal"
            placeholder="0.0"
            value={b}
            onChange={(e) => setB(e.target.value)}
          />
        </div>
      </div>

      <div className="actions">
        <button className="btn primary" onClick={onAdd} disabled={disabled}>
          {disabled ? 'Connect & Create Smart Account' : 'Add Liquidity'}
        </button>
        <button className="btn" onClick={onRemove} disabled={disabled}>
          Remove Liquidity
        </button>
      </div>

      {status ? <div className="status">{status}</div> : null}
    </div>
  )
}
