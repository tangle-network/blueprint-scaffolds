import { useMemo, useState } from 'react'
import { usePaymasterPolicy } from '../web3/usePaymasterPolicy'

export function SponsorshipPolicy() {
  const [dailyUsd, setDailyUsd] = useState('5')
  const [allowSwap, setAllowSwap] = useState(true)
  const [allowLiquidity, setAllowLiquidity] = useState(true)
  const [status, setStatus] = useState('')
  const { simulateSavePolicy } = usePaymasterPolicy()

  const preview = useMemo(() => {
    return {
      maxDailySpendUsd: Number(dailyUsd || '0'),
      allow: {
        swap: allowSwap,
        liquidity: allowLiquidity
      }
    }
  }, [dailyUsd, allowSwap, allowLiquidity])

  async function onSave() {
    setStatus('Saving policy (demo)...')
    try {
      await simulateSavePolicy(preview)
      setStatus('Saved locally. Hook up to Coinbase Paymaster policy endpoints to apply it on-chain.')
    } catch (e) {
      setStatus(e instanceof Error ? e.message : 'Unknown error')
    }
  }

  return (
    <div className="card">
      <div className="cardHeader">
        <div className="cardTitle">Gas Sponsorship Policies</div>
        <div className="cardHint">Coinbase Paymaster (API)</div>
      </div>

      <div className="row">
        <label className="label">Daily spend limit (USD)</label>
        <input className="input" inputMode="decimal" value={dailyUsd} onChange={(e) => setDailyUsd(e.target.value)} />
      </div>

      <div className="row inline">
        <label className="checkbox">
          <input type="checkbox" checked={allowSwap} onChange={(e) => setAllowSwap(e.target.checked)} />
          Sponsor swaps
        </label>
        <label className="checkbox">
          <input type="checkbox" checked={allowLiquidity} onChange={(e) => setAllowLiquidity(e.target.checked)} />
          Sponsor liquidity
        </label>
      </div>

      <button className="btn primary" onClick={onSave}>
        Save Policy
      </button>

      <div className="codeBox">
        <div className="codeTitle">Preview</div>
        <pre className="code">{JSON.stringify(preview, null, 2)}</pre>
      </div>
      {status ? <div className="status">{status}</div> : null}
    </div>
  )
}
