import { Settings, Zap, Shield, DollarSign, Gauge } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { usePaymaster } from "@/hooks/usePaymaster"

export default function PaymasterPage() {
  const { config, updateConfig, isSponsoring, gasSaved, isSponsorshipEnabled } = usePaymaster()

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex flex-col items-center gap-2 mb-2">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10">
          <Zap className="h-8 w-8 text-primary" />
        </div>
        <h2 className="text-2xl font-bold">Coinbase Paymaster</h2>
        <p className="text-muted-foreground text-center max-w-md text-sm">
          Configure ERC-4337 gas sponsorship for gasless transactions on Base
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-500/10">
                <Shield className="h-5 w-5 text-green-400" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Status</p>
                <p className="font-medium flex items-center gap-2">
                  {isSponsorshipEnabled ? "Active" : "Disabled"}
                  <span className={`h-2 w-2 rounded-full ${isSponsorshipEnabled ? "bg-green-400" : "bg-red-400"}`} />
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <DollarSign className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Gas Saved</p>
                <p className="font-medium">{gasSaved} ETH</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5 text-primary" />
            Sponsorship Configuration
          </CardTitle>
          <CardDescription>Manage gas sponsorship policies</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Gas Sponsorship</p>
              <p className="text-sm text-muted-foreground">
                Enable or disable gas sponsorship for all transactions
              </p>
            </div>
            <Button
              variant={config.sponsorshipEnabled ? "default" : "outline"}
              size="sm"
              onClick={() =>
                updateConfig({ sponsorshipEnabled: !config.sponsorshipEnabled })
              }
            >
              {config.sponsorshipEnabled ? "Enabled" : "Disabled"}
            </Button>
          </div>

          <Separator />

          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Gauge className="h-4 w-4" />
              Max Gas Per Transaction
            </Label>
            <Input
              value={config.maxGasPerTransaction}
              onChange={(e) =>
                updateConfig({ maxGasPerTransaction: e.target.value })
              }
              placeholder="500000"
            />
            <p className="text-xs text-muted-foreground">
              Maximum gas units sponsored per individual transaction
            </p>
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Daily Gas Limit
            </Label>
            <Input
              value={config.dailyGasLimit}
              onChange={(e) =>
                updateConfig({ dailyGasLimit: e.target.value })
              }
              placeholder="10000000"
            />
            <p className="text-xs text-muted-foreground">
              Total daily gas budget across all sponsored transactions
            </p>
          </div>

          <Separator />

          <div className="space-y-3">
            <Label>Whitelisted Tokens</Label>
            <div className="flex flex-wrap gap-2">
              {config.whitelistedTokens.map((token) => (
                <Badge key={token} variant="secondary">
                  {token}
                </Badge>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <Label>Sponsored Methods</Label>
            <div className="flex flex-wrap gap-2">
              {config.sponsoredMethods.map((method) => (
                <Badge key={method} variant="success" className="gap-1">
                  <Zap className="h-3 w-3" />
                  {method}
                </Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-primary" />
            How It Works
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground text-sm font-bold shrink-0">
                1
              </div>
              <div>
                <p className="font-medium text-sm">Smart Account Created</p>
                <p className="text-xs text-muted-foreground">
                  Your wallet creates an ERC-4337 smart account on Base network
                </p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground text-sm font-bold shrink-0">
                2
              </div>
              <div>
                <p className="font-medium text-sm">UserOperation Submitted</p>
                <p className="text-xs text-muted-foreground">
                  Transactions are wrapped as UserOperations via the EntryPoint contract
                </p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground text-sm font-bold shrink-0">
                3
              </div>
              <div>
                <p className="font-medium text-sm">Paymaster Sponsors Gas</p>
                <p className="text-xs text-muted-foreground">
                  Coinbase Paymaster validates and pays for gas fees on your behalf
                </p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground text-sm font-bold shrink-0">
                4
              </div>
              <div>
                <p className="font-medium text-sm">Transaction Confirmed</p>
                <p className="text-xs text-muted-foreground">
                  Your transaction executes on-chain with zero gas cost to you
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
