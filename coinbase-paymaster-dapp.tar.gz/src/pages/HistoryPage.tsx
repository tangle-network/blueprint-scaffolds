import { Clock, ArrowLeftRight, Droplets, Zap, ExternalLink } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { useTransactions } from "@/hooks/useTransactions"
import { formatAddress } from "@/lib/utils"
import { BASE_SCAN_URL, type Transaction } from "@/lib/types"

interface HistoryPageProps {
  wallet: ReturnType<typeof import("@/hooks/useWallet").useWallet>
}

function getTypeIcon(type: Transaction["type"]) {
  switch (type) {
    case "swap":
      return <ArrowLeftRight className="h-4 w-4" />
    case "add_liquidity":
      return <Droplets className="h-4 w-4" />
    case "remove_liquidity":
      return <Droplets className="h-4 w-4" />
  }
}

function getTypeLabel(type: Transaction["type"]) {
  switch (type) {
    case "swap":
      return "Swap"
    case "add_liquidity":
      return "Add Liquidity"
    case "remove_liquidity":
      return "Remove Liquidity"
  }
}

function getStatusVariant(status: Transaction["status"]): "success" | "warning" | "destructive" {
  switch (status) {
    case "confirmed":
      return "success"
    case "pending":
      return "warning"
    case "failed":
      return "destructive"
  }
}

function timeAgo(timestamp: number): string {
  const diff = Date.now() - timestamp
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return "Just now"
  if (mins < 60) return `${mins}m ago`
  const hours = Math.floor(mins / 60)
  if (hours < 24) return `${hours}h ago`
  const days = Math.floor(hours / 24)
  return `${days}d ago`
}

export default function HistoryPage({ wallet }: HistoryPageProps) {
  const { transactions, totalGasSaved } = useTransactions()

  if (!wallet.isConnected) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10">
          <Clock className="h-8 w-8 text-primary" />
        </div>
        <h2 className="text-2xl font-bold">Transaction History</h2>
        <p className="text-muted-foreground text-center max-w-md">
          Connect your wallet to view your gasless transaction history.
        </p>
      </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground">Total Transactions</p>
            <p className="text-2xl font-bold">{transactions.length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground">Gas Saved</p>
            <p className="text-2xl font-bold text-green-400">{totalGasSaved} ETH</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground">Gasless Rate</p>
            <p className="text-2xl font-bold">
              {transactions.length > 0
                ? Math.round(
                    (transactions.filter((t) => t.gasSponsored).length /
                      transactions.length) *
                      100
                  )
                : 0}
              %
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-primary" />
            Transaction History
          </CardTitle>
          <CardDescription>All your gasless transactions on Base</CardDescription>
        </CardHeader>
        <CardContent>
          {transactions.length === 0 ? (
            <p className="text-muted-foreground text-sm">No transactions yet</p>
          ) : (
            <div className="space-y-1">
              {transactions.map((tx, i) => (
                <div key={tx.id}>
                  <div className="flex items-center gap-3 rounded-lg p-3 hover:bg-accent transition-colors">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                      {getTypeIcon(tx.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium">{getTypeLabel(tx.type)}</p>
                        <Badge variant={getStatusVariant(tx.status)} className="text-xs">
                          {tx.status}
                        </Badge>
                        {tx.gasSponsored && (
                          <Badge variant="success" className="text-xs">
                            <Zap className="h-3 w-3 mr-0.5" />
                            Gasless
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        {tx.tokenIn && tx.tokenOut && (
                          <span>
                            {tx.amountIn} {tx.tokenIn} → {tx.amountOut} {tx.tokenOut}
                          </span>
                        )}
                        <span>· {timeAgo(tx.timestamp)}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      {tx.gasSaved && (
                        <p className="text-xs text-green-400">
                          Saved {tx.gasSaved} ETH
                        </p>
                      )}
                      <a
                        href={`${BASE_SCAN_URL}/tx/${tx.hash}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-muted-foreground hover:text-foreground inline-flex items-center gap-1"
                      >
                        {formatAddress(tx.hash)}
                        <ExternalLink className="h-3 w-3" />
                      </a>
                    </div>
                  </div>
                  {i < transactions.length - 1 && <Separator />}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
