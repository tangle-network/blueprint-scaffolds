import { useState } from "react"
import { ArrowDownUp, Zap, AlertCircle } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { usePools } from "@/hooks/usePools"
import { usePaymaster } from "@/hooks/usePaymaster"
import { useTransactions } from "@/hooks/useTransactions"
import { useSmartAccount } from "@/hooks/useSmartAccount"
import { SUPPORTED_TOKENS, type Token, type SwapQuote } from "@/lib/types"
import { formatTokenAmount } from "@/lib/utils"

interface SwapPageProps {
  wallet: ReturnType<typeof import("@/hooks/useWallet").useWallet>
}

export default function SwapPage({ wallet }: SwapPageProps) {
  const [tokenIn, setTokenIn] = useState<Token>(SUPPORTED_TOKENS[0])
  const [tokenOut, setTokenOut] = useState<Token>(SUPPORTED_TOKENS[1])
  const [amountIn, setAmountIn] = useState("")
  const [quote, setQuote] = useState<SwapQuote | null>(null)
  const [isSwapping, setIsSwapping] = useState(false)
  const [swapSuccess, setSwapSuccess] = useState(false)

  const { getQuote, isLoading: quoteLoading } = usePools()
  const { sponsorGas, isSponsoring, gasSaved } = usePaymaster()
  const { addTransaction } = useTransactions()
  const smartAccount = useSmartAccount(wallet.smartAccount)

  const handleGetQuote = async () => {
    if (!amountIn || parseFloat(amountIn) <= 0) return
    const q = await getQuote(tokenIn, tokenOut, amountIn)
    setQuote(q)
    setSwapSuccess(false)
  }

  const handleSwap = async () => {
    if (!quote || !wallet.isConnected) return
    setIsSwapping(true)
    const sponsored = await sponsorGas("swap")
    const hash = await smartAccount.executeUserOp(
      "0xSwapRouter",
      "0xswapData"
    )
    if (hash) {
      addTransaction({
        type: "swap",
        status: "confirmed",
        hash,
        from: wallet.address ?? "",
        to: "0xSwapRouter",
        tokenIn: tokenIn.symbol,
        tokenOut: tokenOut.symbol,
        amountIn: quote.inputAmount,
        amountOut: quote.outputAmount,
        gasSponsored: sponsored,
        gasSaved: gasSaved,
      })
      setSwapSuccess(true)
      setAmountIn("")
      setQuote(null)
    }
    setIsSwapping(false)
  }

  const flipTokens = () => {
    setTokenIn(tokenOut)
    setTokenOut(tokenIn)
    setQuote(null)
    setAmountIn("")
  }

  if (!wallet.isConnected) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10">
          <Zap className="h-8 w-8 text-primary" />
        </div>
        <h2 className="text-2xl font-bold">Gasless Token Swaps</h2>
        <p className="text-muted-foreground text-center max-w-md">
          Connect your wallet to start swapping tokens with zero gas fees powered by Coinbase Paymaster on Base.
        </p>
      </div>
    )
  }

  return (
    <div className="max-w-lg mx-auto space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-primary" />
            Swap Tokens
            <Badge variant="success" className="ml-auto text-xs">
              <Zap className="h-3 w-3 mr-1" />
              Gasless
            </Badge>
          </CardTitle>
          <CardDescription>Swap tokens with zero gas fees</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>You Pay</Label>
            <div className="flex gap-2">
              <Input
                type="number"
                placeholder="0.0"
                value={amountIn}
                onChange={(e) => {
                  setAmountIn(e.target.value)
                  setQuote(null)
                }}
                className="flex-1"
              />
              <select
                value={tokenIn.symbol}
                onChange={(e) => {
                  setTokenIn(SUPPORTED_TOKENS.find((t) => t.symbol === e.target.value)!)
                  setQuote(null)
                }}
                className="rounded-md border border-input bg-background px-3 py-2 text-sm"
              >
                {SUPPORTED_TOKENS.map((t) => (
                  <option key={t.symbol} value={t.symbol}>
                    {t.symbol}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex justify-center">
            <Button variant="ghost" size="icon" onClick={flipTokens}>
              <ArrowDownUp className="h-4 w-4" />
            </Button>
          </div>

          <div className="space-y-2">
            <Label>You Receive</Label>
            <div className="flex gap-2">
              <Input
                readOnly
                placeholder="0.0"
                value={quote ? formatTokenAmount(quote.outputAmount) : ""}
                className="flex-1"
              />
              <select
                value={tokenOut.symbol}
                onChange={(e) => {
                  setTokenOut(SUPPORTED_TOKENS.find((t) => t.symbol === e.target.value)!)
                  setQuote(null)
                }}
                className="rounded-md border border-input bg-background px-3 py-2 text-sm"
              >
                {SUPPORTED_TOKENS.map((t) => (
                  <option key={t.symbol} value={t.symbol}>
                    {t.symbol}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <Button
            onClick={handleGetQuote}
            disabled={!amountIn || parseFloat(amountIn) <= 0 || quoteLoading}
            className="w-full"
          >
            {quoteLoading ? "Getting Quote..." : "Get Quote"}
          </Button>

          {quote && (
            <>
              <Separator />
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Rate</span>
                  <span>
                    1 {tokenIn.symbol} = {formatTokenAmount(parseFloat(quote.outputAmount) / parseFloat(quote.inputAmount))} {tokenOut.symbol}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Price Impact</span>
                  <span className={parseFloat(quote.priceImpact) > 1 ? "text-yellow-400" : ""}>
                    {quote.priceImpact}%
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Fee</span>
                  <span>{quote.fee} {tokenIn.symbol}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Gas</span>
                  <span className="text-green-400 flex items-center gap-1">
                    <Zap className="h-3 w-3" />
                    Sponsored (Free)
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Route</span>
                  <span>{quote.route.join(" → ")}</span>
                </div>
              </div>

              <Button
                onClick={handleSwap}
                disabled={isSwapping}
                className="w-full"
                size="lg"
              >
                {isSwapping
                  ? isSponsoring
                    ? "Sponsoring Gas..."
                    : "Swapping..."
                  : "Swap (Gasless)"}
              </Button>
            </>
          )}

          {swapSuccess && (
            <div className="flex items-center gap-2 rounded-lg bg-green-500/10 p-3 text-sm text-green-400">
              <Zap className="h-4 w-4" />
              Swap completed! Gas fee sponsored by Coinbase Paymaster.
            </div>
          )}
        </CardContent>
      </Card>

      {wallet.smartAccount && (
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3 text-sm">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <Zap className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="font-medium">Smart Account Active</p>
                <p className="text-muted-foreground text-xs">
                  ERC-4337 account at {wallet.smartAccount.address.slice(0, 10)}...
                  {wallet.smartAccount.address.slice(-8)}
                </p>
              </div>
              <Badge variant="success" className="ml-auto">Active</Badge>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
