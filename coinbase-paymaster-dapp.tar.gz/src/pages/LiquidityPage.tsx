import { useState } from "react"
import { Droplets, Plus, Minus, TrendingUp } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { usePools } from "@/hooks/usePools"
import { usePaymaster } from "@/hooks/usePaymaster"
import { useTransactions } from "@/hooks/useTransactions"
import { useSmartAccount } from "@/hooks/useSmartAccount"
import { formatTokenAmount, formatUSD } from "@/lib/utils"

interface LiquidityPageProps {
  wallet: ReturnType<typeof import("@/hooks/useWallet").useWallet>
}

export default function LiquidityPage({ wallet }: LiquidityPageProps) {
  const [selectedPool, setSelectedPool] = useState<string | null>(null)
  const [addAmountA, setAddAmountA] = useState("")
  const [addAmountB, setAddAmountB] = useState("")
  const [removeAmount, setRemoveAmount] = useState("")
  const [actionLoading, setActionLoading] = useState(false)

  const { pools, userPositions, addLiquidity, removeLiquidity } = usePools()
  const { sponsorGas, isSponsoring } = usePaymaster()
  const { addTransaction } = useTransactions()
  const smartAccount = useSmartAccount(wallet.smartAccount)

  const handleAddLiquidity = async () => {
    if (!selectedPool || !addAmountA || !addAmountB || !wallet.isConnected) return
    setActionLoading(true)
    const sponsored = await sponsorGas("addLiquidity")
    const hash = await addLiquidity(selectedPool, addAmountA, addAmountB)
    if (hash) {
      const pool = pools.find((p) => p.id === selectedPool)
      addTransaction({
        type: "add_liquidity",
        status: "confirmed",
        hash,
        from: wallet.address ?? "",
        to: `Pool: ${pool?.tokenA.symbol}/${pool?.tokenB.symbol}`,
        tokenIn: pool?.tokenA.symbol,
        tokenOut: pool?.tokenB.symbol,
        amountIn: addAmountA,
        amountOut: addAmountB,
        gasSponsored: sponsored,
      })
      setAddAmountA("")
      setAddAmountB("")
    }
    setActionLoading(false)
  }

  const handleRemoveLiquidity = async () => {
    if (!selectedPool || !removeAmount || !wallet.isConnected) return
    setActionLoading(true)
    const sponsored = await sponsorGas("removeLiquidity")
    const hash = await removeLiquidity(selectedPool, removeAmount)
    if (hash) {
      const pool = pools.find((p) => p.id === selectedPool)
      addTransaction({
        type: "remove_liquidity",
        status: "confirmed",
        hash,
        from: `Pool: ${pool?.tokenA.symbol}/${pool?.tokenB.symbol}`,
        to: wallet.address ?? "",
        amountIn: removeAmount,
        gasSponsored: sponsored,
      })
      setRemoveAmount("")
    }
    setActionLoading(false)
  }

  if (!wallet.isConnected) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10">
          <Droplets className="h-8 w-8 text-primary" />
        </div>
        <h2 className="text-2xl font-bold">Liquidity Pools</h2>
        <p className="text-muted-foreground text-center max-w-md">
          Connect your wallet to provide liquidity and earn fees from token swaps.
        </p>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Total Value Locked</CardDescription>
            <CardTitle className="text-3xl">$9,236,790</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-1 text-sm text-green-400">
              <TrendingUp className="h-4 w-4" />
              +5.2% (24h)
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Your Positions</CardDescription>
            <CardTitle className="text-3xl">{userPositions.length}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-sm text-muted-foreground">
              Active liquidity positions
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Droplets className="h-5 w-5 text-primary" />
            Your Positions
          </CardTitle>
        </CardHeader>
        <CardContent>
          {userPositions.length === 0 ? (
            <p className="text-muted-foreground text-sm">No active positions</p>
          ) : (
            <div className="space-y-3">
              {userPositions.map((pos, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between rounded-lg border p-4"
                >
                  <div>
                    <p className="font-medium">
                      {pos.pool.tokenA.symbol}/{pos.pool.tokenB.symbol}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      LP Tokens: {pos.lpTokenBalance} | Share: {pos.share}%
                    </p>
                  </div>
                  <div className="text-right">
                    <Badge variant="success">{pos.pool.apy}% APY</Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Droplets className="h-5 w-5 text-primary" />
            Available Pools
            <Badge variant="success" className="ml-auto text-xs">Gasless</Badge>
          </CardTitle>
          <CardDescription>Select a pool to add or remove liquidity</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {pools.map((pool) => (
              <button
                key={pool.id}
                onClick={() => setSelectedPool(pool.id === selectedPool ? null : pool.id)}
                className={`w-full rounded-lg border p-4 text-left transition-colors ${
                  selectedPool === pool.id ? "border-primary bg-primary/5" : "hover:bg-accent"
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">
                      {pool.tokenA.symbol}/{pool.tokenB.symbol}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Fee: {pool.fee}% | TVL: {pool.tvl}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{pool.apy}% APY</p>
                    <p className="text-xs text-muted-foreground">
                      Vol: {pool.volume24h}
                    </p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {selectedPool && (
        <Card>
          <Tabs defaultValue="add">
            <CardHeader>
              <TabsList className="w-full">
                <TabsTrigger value="add" className="flex-1">
                  <Plus className="h-4 w-4 mr-1" /> Add Liquidity
                </TabsTrigger>
                <TabsTrigger value="remove" className="flex-1">
                  <Minus className="h-4 w-4 mr-1" /> Remove
                </TabsTrigger>
              </TabsList>
            </CardHeader>
            <CardContent>
              <TabsContent value="add" className="space-y-4">
                <div className="space-y-2">
                  <Label>Token A Amount</Label>
                  <Input
                    type="number"
                    placeholder="0.0"
                    value={addAmountA}
                    onChange={(e) => setAddAmountA(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Token B Amount</Label>
                  <Input
                    type="number"
                    placeholder="0.0"
                    value={addAmountB}
                    onChange={(e) => setAddAmountB(e.target.value)}
                  />
                </div>
                <Button
                  onClick={handleAddLiquidity}
                  disabled={actionLoading || !addAmountA || !addAmountB}
                  className="w-full"
                >
                  {actionLoading
                    ? isSponsoring
                      ? "Sponsoring Gas..."
                      : "Adding..."
                    : "Add Liquidity (Gasless)"}
                </Button>
              </TabsContent>

              <TabsContent value="remove" className="space-y-4">
                <div className="space-y-2">
                  <Label>LP Token Amount</Label>
                  <Input
                    type="number"
                    placeholder="0.0"
                    value={removeAmount}
                    onChange={(e) => setRemoveAmount(e.target.value)}
                  />
                </div>
                <Button
                  onClick={handleRemoveLiquidity}
                  disabled={actionLoading || !removeAmount}
                  className="w-full"
                >
                  {actionLoading
                    ? isSponsoring
                      ? "Sponsoring Gas..."
                      : "Removing..."
                    : "Remove Liquidity (Gasless)"}
                </Button>
              </TabsContent>
            </CardContent>
          </Tabs>
        </Card>
      )}
    </div>
  )
}
