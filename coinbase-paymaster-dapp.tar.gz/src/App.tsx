import { Routes, Route, NavLink } from "react-router-dom"
import { Wallet, ArrowLeftRight, Droplets, Clock, Settings } from "lucide-react"
import { useWallet } from "@/hooks/useWallet"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { formatAddress } from "@/lib/utils"
import SwapPage from "@/pages/SwapPage"
import LiquidityPage from "@/pages/LiquidityPage"
import HistoryPage from "@/pages/HistoryPage"
import PaymasterPage from "@/pages/PaymasterPage"

const navItems = [
  { to: "/", label: "Swap", icon: ArrowLeftRight },
  { to: "/liquidity", label: "Pools", icon: Droplets },
  { to: "/history", label: "History", icon: Clock },
  { to: "/paymaster", label: "Paymaster", icon: Settings },
]

export default function App() {
  const wallet = useWallet()

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto flex h-14 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <Wallet className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="text-lg font-bold">GaslessDeFi</span>
            <Badge variant="secondary" className="ml-2 text-xs">Base</Badge>
          </div>

          <nav className="hidden md:flex items-center gap-1">
            {navItems.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                end={to === "/"}
                className={({ isActive }) =>
                  `flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                    isActive
                      ? "bg-accent text-accent-foreground"
                      : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                  }`
                }
              >
                <Icon className="h-4 w-4" />
                {label}
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            {wallet.isConnected && wallet.smartAccount && (
              <Badge variant="outline" className="hidden sm:flex gap-1">
                <span className="h-2 w-2 rounded-full bg-green-400" />
                {formatAddress(wallet.smartAccount.address)}
              </Badge>
            )}
            <Button
              onClick={wallet.isConnected ? wallet.disconnect : wallet.connect}
              disabled={wallet.isConnecting}
              size="sm"
              variant={wallet.isConnected ? "outline" : "default"}
            >
              {wallet.isConnecting
                ? "Connecting..."
                : wallet.isConnected
                ? "Disconnect"
                : "Connect Wallet"}
            </Button>
          </div>
        </div>
      </header>

      <nav className="md:hidden border-b">
        <div className="container mx-auto flex items-center gap-1 overflow-x-auto px-2 py-2">
          {navItems.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              end={to === "/"}
              className={({ isActive }) =>
                `flex items-center gap-1 rounded-md px-3 py-1.5 text-xs font-medium whitespace-nowrap transition-colors ${
                  isActive
                    ? "bg-accent text-accent-foreground"
                    : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                }`
              }
            >
              <Icon className="h-3 w-3" />
              {label}
            </NavLink>
          ))}
        </div>
      </nav>

      <main className="container mx-auto px-4 py-6">
        <Routes>
          <Route path="/" element={<SwapPage wallet={wallet} />} />
          <Route path="/liquidity" element={<LiquidityPage wallet={wallet} />} />
          <Route path="/history" element={<HistoryPage wallet={wallet} />} />
          <Route path="/paymaster" element={<PaymasterPage />} />
        </Routes>
      </main>
    </div>
  )
}
