/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_COINBASE_PAYMASTER_RPC_URL?: string
  readonly VITE_COINBASE_PAYMASTER_API_KEY?: string
  readonly VITE_BUNDLER_RPC_URL?: string
  readonly VITE_ENTRYPOINT_ADDRESS?: string
  readonly VITE_BASE_RPC_URL?: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}
