export const PRIVATE_STABLECOIN_ABI = [
  "function MINTER_ROLE() view returns (bytes32)",
  "function COMPLIANCE_ROLE() view returns (bytes32)",
  "function trackedTotalSupply() view returns (uint256)",
  "function blacklisted(address account) view returns (bool)",
  "function setBlacklist(address account, bool status)",
  "function mintEncrypted(address to, (bytes data, int32 securityZone) encryptedAmount)",
  "function burnEncrypted((bytes data, int32 securityZone) encryptedAmount) returns (uint256)",
  "function burnFromEncrypted(address from, (bytes data, int32 securityZone) encryptedAmount) returns (uint256)",
  "function transferEncrypted(address to, (bytes data, int32 securityZone) encryptedAmount) returns (uint256)",
  "function transferFromEncrypted(address from, address to, (bytes data, int32 securityZone) encryptedAmount) returns (uint256)",
  "function approveEncrypted(address spender, (bytes data, int32 securityZone) value) returns (bool)",
  "function balanceOfEncrypted(address account, (bytes32 publicKey, bytes signature) auth) view returns (string)",
  "function allowanceEncrypted(address owner, address spender, (bytes32 publicKey, bytes signature) permission) view returns (string)"
] as const;

export type EncryptedUint = {
  data: Uint8Array;
  securityZone: number;
};

export type PermitPermission = {
  publicKey: string;
  signature: string;
};

export function getStablecoinAddress(): string {
  const address = import.meta.env.VITE_STABLECOIN_ADDRESS;

  if (!address) {
    return "0x0000000000000000000000000000000000000000";
  }

  return address;
}

export function parseAmount(value: string): bigint {
  const trimmed = value.trim();

  if (!trimmed) {
    return 0n;
  }

  return BigInt(trimmed);
}
