import { ethers, Contract, BrowserProvider, parseUnits } from "ethers";
import { PRIVATE_STABLECOIN_ABI } from "./abi";

declare global {
  interface Window {
    ethereum?: {
      isMetaMask?: boolean;
      request: (args: { method: string; params?: unknown[] }) => Promise<unknown>;
      on: (event: string, handler: (...args: unknown[]) => void) => void;
      removeListener: (event: string, handler: (...args: unknown[]) => void) => void;
    };
  }
}

const CONTRACT_ADDRESS = process.env.NEXT_PUBLIC_CONTRACT_ADDRESS || "0x0000000000000000000000000000000000000000";

export type FhenixClient = {
  provider: BrowserProvider;
  signer: ethers.JsonRpcSigner;
  contract: Contract;
  address: string;
};

export async function connectWallet(): Promise<FhenixClient> {
  if (!window.ethereum) {
    throw new Error("No Ethereum wallet detected. Please install MetaMask.");
  }

  const provider = new BrowserProvider(window.ethereum);
  await provider.send("eth_requestAccounts", []);
  const signer = await provider.getSigner();
  const address = await signer.getAddress();

  const contract = new Contract(CONTRACT_ADDRESS, PRIVATE_STABLECOIN_ABI, signer);

  return { provider, signer, contract, address };
}

export async function getContract(client: FhenixClient): Promise<Contract> {
  return client.contract;
}

export async function mint(client: FhenixClient, to: string, amount: string): Promise<string> {
  const contract = await getContract(client);
  const parsedAmount = parseUnits(amount, 6);
  const tx = await contract.mint(to, parsedAmount);
  const receipt = await tx.wait();
  return receipt.hash;
}

export async function burn(client: FhenixClient, amount: string): Promise<string> {
  const contract = await getContract(client);
  const parsedAmount = parseUnits(amount, 6);
  const tx = await contract.burn(parsedAmount);
  const receipt = await tx.wait();
  return receipt.hash;
}

export async function transferEncrypted(
  client: FhenixClient,
  to: string,
  encryptedAmount: string
): Promise<string> {
  const contract = await getContract(client);
  const tx = await contract.transfer(to, encryptedAmount);
  const receipt = await tx.wait();
  return receipt.hash;
}

export async function transferPlain(
  client: FhenixClient,
  to: string,
  amount: string
): Promise<string> {
  const contract = await getContract(client);
  const parsedAmount = parseUnits(amount, 6);
  const tx = await contract.transfer(to, parsedAmount);
  const receipt = await tx.wait();
  return receipt.hash;
}

export async function approvePlain(
  client: FhenixClient,
  spender: string,
  amount: string
): Promise<string> {
  const contract = await getContract(client);
  const parsedAmount = parseUnits(amount, 6);
  const tx = await contract.approve(spender, parsedAmount);
  const receipt = await tx.wait();
  return receipt.hash;
}

export async function transferFrom(
  client: FhenixClient,
  from: string,
  to: string,
  amount: string
): Promise<string> {
  const contract = await getContract(client);
  const parsedAmount = parseUnits(amount, 6);
  const tx = await contract.transferFrom(from, to, parsedAmount);
  const receipt = await tx.wait();
  return receipt.hash;
}

export async function getTotalSupply(client: FhenixClient): Promise<string> {
  const contract = await getContract(client);
  const supply = await contract.totalSupply();
  return ethers.formatUnits(supply, 6);
}

export async function isBlacklisted(client: FhenixClient, account: string): Promise<boolean> {
  const contract = await getContract(client);
  return contract.isBlacklisted(account);
}

export async function blacklistAddress(client: FhenixClient, account: string): Promise<string> {
  const contract = await getContract(client);
  const tx = await contract.blacklist(account);
  const receipt = await tx.wait();
  return receipt.hash;
}

export async function unblacklistAddress(client: FhenixClient, account: string): Promise<string> {
  const contract = await getContract(client);
  const tx = await contract.unblacklist(account);
  const receipt = await tx.wait();
  return receipt.hash;
}

export async function isAdmin(client: FhenixClient, account: string): Promise<boolean> {
  const contract = await getContract(client);
  return contract.isAdmin(account);
}

export async function isMinter(client: FhenixClient, account: string): Promise<boolean> {
  const contract = await getContract(client);
  return contract.isMinter(account);
}

export async function getOwner(client: FhenixClient): Promise<string> {
  const contract = await getContract(client);
  return contract.owner();
}

export function shortenAddress(address: string): string {
  if (!address) return "";
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}
