export const FENIX_TESTNET_RPC = "https://test01.fhenix.zone/evb";
export const FENIX_LOCAL_RPC = "http://localhost:42069/evb";
export const CHAIN_ID_TESTNET = 42069;
export const CHAIN_ID_LOCAL = 412346;

export const TOKEN_DECIMALS = 18;
export const TOKEN_NAME = "FhenVault USD";
export const TOKEN_SYMBOL = "fUSD";
export const TOKEN_DESCRIPTION = "A privacy-preserving stablecoin built on Fhenix using FHE for encrypted balances and confidential transfers.";

export const MINTER_ROLE = "0x9f2df0fed2c77648de5860a4cc508a081fe9ac31aeb4c7e4e3e6e1e7c5e4e3e2";
export const ADMIN_ROLE = "0x0000000000000000000000000000000000000000000000000000000000000000";
export const PAUSER_ROLE = "0x65d7a28e3265b37a6474929f336521b332c168c986005d89a1b7e7e1b3e0d5a3";

export const SECONDS_PER_BLOCK = 2;

export const CONTRACT_ADDRESSES: Record<number, string> = {
  [CHAIN_ID_TESTNET]: "0x0000000000000000000000000000000000000000",
  [CHAIN_ID_LOCAL]: "0x5FbDB2315678afecb367f032d93F642f64180aa3",
};

export function getContractAddress(chainId: number): string {
  return CONTRACT_ADDRESSES[chainId] || "0x0000000000000000000000000000000000000000";
}
