declare module "@fhenixjs-browser" {
  export * from "fhenixjs";
}
