/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_STABLECOIN_ADDRESS?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

interface Window {
  ethereum?: {
    request(args: { method: string; params?: unknown[] }): Promise<unknown>;
  };
}
