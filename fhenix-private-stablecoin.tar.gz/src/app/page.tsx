"use client";

import React, { useState } from "react";
import { WalletConnect } from "@/components/WalletConnect";
import { BalanceDisplay } from "@/components/BalanceDisplay";
import { TransferForm } from "@/components/TransferForm";
import { MintBurnPanel } from "@/components/MintBurnPanel";
import { BlacklistPanel } from "@/components/BlacklistPanel";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { FhenixClient } from "@/lib/fhenix";
import { Shield, Send, Settings } from "lucide-react";

export default function Home() {
  const [client, setClient] = useState<FhenixClient | null>(null);

  return (
    <main className="min-h-screen bg-background">
      <div className="container mx-auto max-w-4xl py-8 px-4">
        <div className="mb-8 text-center">
          <div className="flex items-center justify-center gap-3 mb-2">
            <Shield className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold">pUSD</h1>
          </div>
          <p className="text-muted-foreground">
            Private Stablecoin — FHERC-20 compliant, powered by Fhenix
          </p>
        </div>

        <div className="space-y-6">
          <WalletConnect
            client={client}
            onConnect={setClient}
            onDisconnect={() => setClient(null)}
          />

          <BalanceDisplay client={client} />

          <Tabs defaultValue="transfer" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="transfer">
                <Send className="mr-2 h-4 w-4" />
                Transfer
              </TabsTrigger>
              <TabsTrigger value="admin">
                <Settings className="mr-2 h-4 w-4" />
                Admin
              </TabsTrigger>
            </TabsList>
            <TabsContent value="transfer" className="mt-4">
              <TransferForm client={client} />
            </TabsContent>
            <TabsContent value="admin" className="mt-4 space-y-4">
              <MintBurnPanel client={client} />
              <BlacklistPanel client={client} />
            </TabsContent>
          </Tabs>

          <div className="text-center text-xs text-muted-foreground py-4 border-t">
            Private USD (pUSD) — FHERC-20 Token on Fhenix Network
          </div>
        </div>
      </div>
    </main>
  );
}
