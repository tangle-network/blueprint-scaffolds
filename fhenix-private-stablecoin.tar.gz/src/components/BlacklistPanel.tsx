"use client";

import React, { useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  blacklistAddress,
  unblacklistAddress,
  isBlacklisted as checkBlacklisted,
  isAdmin,
  type FhenixClient,
} from "@/lib/fhenix";
import { useToast } from "@/components/ui/use-toast";
import { Ban, ShieldCheck, CheckCircle, XCircle } from "lucide-react";

interface BlacklistPanelProps {
  client: FhenixClient | null;
}

export function BlacklistPanel({ client }: BlacklistPanelProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [address, setAddress] = useState("");
  const [checking, setChecking] = useState(false);
  const [blacklisted, setBlacklisted] = useState<boolean | null>(null);
  const [hasAccess, setHasAccess] = useState(false);
  const [verifying, setVerifying] = useState(true);

  const checkAccess = useCallback(async () => {
    if (!client) {
      setVerifying(false);
      return;
    }
    try {
      const admin = await isAdmin(client, client.address);
      setHasAccess(admin);
    } catch {
      setHasAccess(false);
    } finally {
      setVerifying(false);
    }
  }, [client]);

  useEffect(() => {
    checkAccess();
  }, [checkAccess]);

  const handleCheck = async () => {
    if (!client || !address) return;
    setChecking(true);
    try {
      const result = await checkBlacklisted(client, address);
      setBlacklisted(result);
    } catch {
      setBlacklisted(null);
      toast({ title: "Check Failed", description: "Could not check blacklist status", variant: "destructive" });
    } finally {
      setChecking(false);
    }
  };

  const handleBlacklist = async () => {
    if (!client || !address) return;
    setLoading(true);
    try {
      const hash = await blacklistAddress(client, address);
      toast({ title: "Address Blacklisted", description: `TX: ${hash.slice(0, 10)}...${hash.slice(-8)}` });
      setBlacklisted(true);
    } catch (err) {
      toast({
        title: "Blacklist Failed",
        description: err instanceof Error ? err.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleUnblacklist = async () => {
    if (!client || !address) return;
    setLoading(true);
    try {
      const hash = await unblacklistAddress(client, address);
      toast({ title: "Address Unblacklisted", description: `TX: ${hash.slice(0, 10)}...${hash.slice(-8)}` });
      setBlacklisted(false);
    } catch (err) {
      toast({
        title: "Unblacklist Failed",
        description: err instanceof Error ? err.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  if (verifying) {
    return (
      <Card>
        <CardContent className="p-6 text-center text-muted-foreground">
          Checking permissions...
        </CardContent>
      </Card>
    );
  }

  if (!hasAccess) {
    return (
      <Card>
        <CardContent className="p-6 text-center text-muted-foreground">
          <ShieldCheck className="h-8 w-8 mx-auto mb-2 opacity-50" />
          <p className="text-sm">Admin role required for blacklist management</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Ban className="h-5 w-5 text-primary" />
          Blacklist Management
        </CardTitle>
        <CardDescription>Manage compliance blacklist for addresses</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="bl-address">Address</Label>
          <Input
            id="bl-address"
            placeholder="0x..."
            value={address}
            onChange={(e) => {
              setAddress(e.target.value);
              setBlacklisted(null);
            }}
          />
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={handleCheck}
          disabled={!client || checking || !address}
          className="w-full"
        >
          {checking ? "Checking..." : "Check Status"}
        </Button>

        {blacklisted !== null && (
          <div className="flex items-center gap-2 p-3 rounded-lg bg-muted/50 border">
            {blacklisted ? (
              <>
                <XCircle className="h-4 w-4 text-destructive" />
                <span className="text-sm font-medium text-destructive">Blacklisted</span>
              </>
            ) : (
              <>
                <CheckCircle className="h-4 w-4 text-green-600" />
                <span className="text-sm font-medium text-green-600">Not Blacklisted</span>
              </>
            )}
          </div>
        )}

        <div className="grid grid-cols-2 gap-2">
          <Button
            variant="destructive"
            size="sm"
            onClick={handleBlacklist}
            disabled={!client || loading || !address}
          >
            <Ban className="mr-2 h-4 w-4" />
            Blacklist
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleUnblacklist}
            disabled={!client || loading || !address}
          >
            Unblacklist
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
