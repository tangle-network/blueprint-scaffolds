"use client";

import React, { useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { mint, burn, isAdmin, isMinter, type FhenixClient } from "@/lib/fhenix";
import { useToast } from "@/components/ui/use-toast";
import { Plus, Flame, ShieldCheck } from "lucide-react";

interface MintBurnPanelProps {
  client: FhenixClient | null;
}

export function MintBurnPanel({ client }: MintBurnPanelProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [mintTo, setMintTo] = useState("");
  const [mintAmount, setMintAmount] = useState("");
  const [burnAmount, setBurnAmount] = useState("");
  const [hasAccess, setHasAccess] = useState(false);
  const [checking, setChecking] = useState(true);

  const checkAccess = useCallback(async () => {
    if (!client) {
      setChecking(false);
      return;
    }
    try {
      const [admin, minter] = await Promise.all([
        isAdmin(client, client.address),
        isMinter(client, client.address),
      ]);
      setHasAccess(admin || minter);
    } catch {
      setHasAccess(false);
    } finally {
      setChecking(false);
    }
  }, [client]);

  useEffect(() => {
    checkAccess();
  }, [checkAccess]);

  const handleMint = async () => {
    if (!client || !mintTo || !mintAmount) return;
    setLoading(true);
    try {
      const hash = await mint(client, mintTo, mintAmount);
      toast({ title: "Minted Successfully", description: `TX: ${hash.slice(0, 10)}...${hash.slice(-8)}` });
      setMintTo("");
      setMintAmount("");
    } catch (err) {
      toast({
        title: "Mint Failed",
        description: err instanceof Error ? err.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleBurn = async () => {
    if (!client || !burnAmount) return;
    setLoading(true);
    try {
      const hash = await burn(client, burnAmount);
      toast({ title: "Burned Successfully", description: `TX: ${hash.slice(0, 10)}...${hash.slice(-8)}` });
      setBurnAmount("");
    } catch (err) {
      toast({
        title: "Burn Failed",
        description: err instanceof Error ? err.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  if (checking) {
    return (
      <Card>
        <CardContent className="p-6 text-center text-muted-foreground">
          Checking permissions...
        </CardContent>
      </Card>
    );
  }

  if (!hasAccess) {
    return (
      <Card>
        <CardContent className="p-6 text-center text-muted-foreground">
          <ShieldCheck className="h-8 w-8 mx-auto mb-2 opacity-50" />
          <p className="text-sm">Admin or Minter role required to mint/burn</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Plus className="h-5 w-5 text-primary" />
          Mint &amp; Burn
        </CardTitle>
        <CardDescription>Mint new tokens or burn your holdings</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="mint" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="mint">Mint</TabsTrigger>
            <TabsTrigger value="burn">Burn</TabsTrigger>
          </TabsList>

          <TabsContent value="mint" className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label htmlFor="mint-to">Mint To Address</Label>
              <Input
                id="mint-to"
                placeholder="0x..."
                value={mintTo}
                onChange={(e) => setMintTo(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="mint-amount">Amount (pUSD)</Label>
              <Input
                id="mint-amount"
                type="number"
                placeholder="0.00"
                value={mintAmount}
                onChange={(e) => setMintAmount(e.target.value)}
              />
            </div>
            <Button
              className="w-full"
              onClick={handleMint}
              disabled={!client || loading || !mintTo || !mintAmount}
            >
              <Plus className="mr-2 h-4 w-4" />
              {loading ? "Minting..." : "Mint pUSD"}
            </Button>
          </TabsContent>

          <TabsContent value="burn" className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label htmlFor="burn-amount">Amount to Burn (pUSD)</Label>
              <Input
                id="burn-amount"
                type="number"
                placeholder="0.00"
                value={burnAmount}
                onChange={(e) => setBurnAmount(e.target.value)}
              />
            </div>
            <Button
              variant="destructive"
              className="w-full"
              onClick={handleBurn}
              disabled={!client || loading || !burnAmount}
            >
              <Flame className="mr-2 h-4 w-4" />
              {loading ? "Burning..." : "Burn pUSD"}
            </Button>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
