"use client";

import React, { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { connectWallet, shortenAddress, type FhenixClient } from "@/lib/fhenix";
import { Wallet, LogOut } from "lucide-react";

interface WalletConnectProps {
  onConnect: (client: FhenixClient) => void;
  onDisconnect: () => void;
  client: FhenixClient | null;
}

export function WalletConnect({ onConnect, onDisconnect, client }: WalletConnectProps) {
  const [connecting, setConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleConnect = useCallback(async () => {
    setConnecting(true);
    setError(null);
    try {
      const fhenixClient = await connectWallet();
      onConnect(fhenixClient);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to connect wallet");
    } finally {
      setConnecting(false);
    }
  }, [onConnect]);

  const handleDisconnect = useCallback(() => {
    onDisconnect();
  }, [onDisconnect]);

  return (
    <Card>
      <CardContent className="flex items-center justify-between p-4">
        <div className="flex items-center gap-3">
          <Wallet className="h-5 w-5 text-primary" />
          {client ? (
            <div>
              <p className="text-sm font-medium">Connected</p>
              <p className="text-xs text-muted-foreground">{shortenAddress(client.address)}</p>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">No wallet connected</p>
          )}
        </div>
        {client ? (
          <Button variant="outline" size="sm" onClick={handleDisconnect}>
            <LogOut className="mr-2 h-4 w-4" />
            Disconnect
          </Button>
        ) : (
          <Button onClick={handleConnect} disabled={connecting}>
            {connecting ? "Connecting..." : "Connect Wallet"}
          </Button>
        )}
        {error && <p className="text-xs text-destructive ml-4">{error}</p>}
      </CardContent>
    </Card>
  );
}
