"use client";

import React, { useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { getTotalSupply, type FhenixClient } from "@/lib/fhenix";
import { Eye, Coins } from "lucide-react";

interface BalanceDisplayProps {
  client: FhenixClient | null;
}

export function BalanceDisplay({ client }: BalanceDisplayProps) {
  const [totalSupply, setTotalSupply] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const fetchTotalSupply = useCallback(async () => {
    if (!client) return;
    setLoading(true);
    try {
      const supply = await getTotalSupply(client);
      setTotalSupply(supply);
    } catch {
      setTotalSupply("Error");
    } finally {
      setLoading(false);
    }
  }, [client]);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Eye className="h-5 w-5 text-primary" />
            Your Balance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="p-4 rounded-lg bg-muted/50 border">
              <p className="text-sm text-muted-foreground mb-1">Encrypted Balance</p>
              <p className="text-2xl font-bold font-mono">•••••••• pUSD</p>
              <p className="text-xs text-muted-foreground mt-1">
                Balances are encrypted on-chain. Use the Fhenix decryption permit to view.
              </p>
            </div>
            <Button variant="outline" size="sm" className="w-full" disabled={!client}>
              <Eye className="mr-2 h-4 w-4" />
              Decrypt Balance
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Coins className="h-5 w-5 text-primary" />
            Total Supply
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="p-4 rounded-lg bg-muted/50 border">
              <p className="text-sm text-muted-foreground mb-1">pUSD Total Supply</p>
              <p className="text-2xl font-bold font-mono">
                {totalSupply !== null ? `${Number(totalSupply).toLocaleString()} pUSD` : "— pUSD"}
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="w-full"
              onClick={fetchTotalSupply}
              disabled={!client || loading}
            >
              {loading ? "Loading..." : "Refresh Supply"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
