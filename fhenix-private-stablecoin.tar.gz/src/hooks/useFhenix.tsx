"use client";

import { useState, useEffect, useCallback, createContext, useContext, type ReactNode } from "react";
import { ethers, BrowserProvider, Contract } from "ethers";
import { FHERC20_ABI } from "@/lib/abi";
import { getContractAddress, CHAIN_ID_LOCAL, CHAIN_ID_TESTNET, FENIX_LOCAL_RPC, FENIX_TESTNET_RPC } from "@/lib/constants";

interface FhenixContextType {
  provider: BrowserProvider | null;
  signer: ethers.JsonRpcSigner | null;
  contract: Contract | null;
  address: string;
  chainId: number;
  isConnected: boolean;
  isAdmin: boolean;
  isMinter: boolean;
  connect: () => Promise<void>;
  disconnect: () => void;
}

const FhenixContext = createContext<FhenixContextType>({
  provider: null,
  signer: null,
  contract: null,
  address: "",
  chainId: 0,
  isConnected: false,
  isAdmin: false,
  isMinter: false,
  connect: async () => {},
  disconnect: () => {},
});

export function useFhenix() {
  return useContext(FhenixContext);
}

export function FhenixProvider({ children }: { children: ReactNode }) {
  const [provider, setProvider] = useState<BrowserProvider | null>(null);
  const [signer, setSigner] = useState<ethers.JsonRpcSigner | null>(null);
  const [contract, setContract] = useState<Contract | null>(null);
  const [address, setAddress] = useState("");
  const [chainId, setChainId] = useState(0);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isMinter, setIsMinter] = useState(false);

  const isConnected = !!signer && !!address;

  const initContract = useCallback(async (prov: BrowserProvider, sign: ethers.JsonRpcSigner, addr: string, cid: number) => {
    const contractAddr = getContractAddress(cid);
    if (contractAddr === "0x0000000000000000000000000000000000000000") return;

    const c = new Contract(contractAddr, FHERC20_ABI, sign);
    setContract(c);

    try {
      const adminRole = "0x0000000000000000000000000000000000000000000000000000000000000000";
      const minterRole = "0x9f2df0fed2c77648de5860a4cc508a081fe9ac31aeb4c7e4e3e6e1e7c5e4e3e2";
      const [admin, minter] = await Promise.all([
        c.hasRole(adminRole, addr),
        c.hasRole(minterRole, addr),
      ]);
      setIsAdmin(admin);
      setIsMinter(minter);
    } catch {
      setIsAdmin(false);
      setIsMinter(false);
    }
  }, []);

  const connect = useCallback(async () => {
    if (typeof window === "undefined" || !(window as unknown as { ethereum?: unknown }).ethereum) {
      alert("Please install MetaMask or a compatible wallet");
      return;
    }

    try {
      const prov = new BrowserProvider((window as unknown as { ethereum: ethers.Eip1193Provider }).ethereum);
      const accounts = await prov.send("eth_requestAccounts", []);
      const sign = await prov.getSigner();
      const network = await prov.getNetwork();
      const cid = Number(network.chainId);

      setProvider(prov);
      setSigner(sign);
      setAddress(accounts[0]);
      setChainId(cid);
      await initContract(prov, sign, accounts[0], cid);
    } catch (err) {
      console.error("Failed to connect wallet:", err);
    }
  }, [initContract]);

  const disconnect = useCallback(() => {
    setProvider(null);
    setSigner(null);
    setContract(null);
    setAddress("");
    setChainId(0);
    setIsAdmin(false);
    setIsMinter(false);
  }, []);

  useEffect(() => {
    if (typeof window === "undefined" || !(window as unknown as { ethereum?: unknown }).ethereum) return;

    const handleAccountsChanged = (...args: unknown[]) => {
      const accounts = args[0] as string[];
      if (accounts.length === 0) {
        disconnect();
      } else {
        setAddress(accounts[0]);
      }
    };

    const handleChainChanged = () => {
      window.location.reload();
    };

    const ethereum = (window as unknown as { ethereum: { on: (event: string, handler: (...args: unknown[]) => void) => void } }).ethereum;
    ethereum.on("accountsChanged", handleAccountsChanged);
    ethereum.on("chainChanged", handleChainChanged);

    return () => {
      ethereum.on("accountsChanged", handleAccountsChanged);
      ethereum.on("chainChanged", handleChainChanged);
    };
  }, [disconnect]);

  return (
    <FhenixContext.Provider
      value={{ provider, signer, contract, address, chainId, isConnected, isAdmin, isMinter, connect, disconnect }}
    >
      {children}
    </FhenixContext.Provider>
  );
}
