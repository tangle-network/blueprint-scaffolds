"use client";

import { useState, useCallback } from "react";
import { ethers } from "ethers";
import { useFhenix } from "./useFhenix";
import { formatTokenAmount } from "@/lib/utils";
import { TOKEN_DECIMALS } from "@/lib/constants";

export function useBalance() {
  const { contract, address, isConnected } = useFhenix();
  const [balance, setBalance] = useState<string>("0.00");
  const [loading, setLoading] = useState(false);

  const refreshBalance = useCallback(async () => {
    if (!contract || !address || !isConnected) return;
    setLoading(true);
    try {
      const encryptedBalance = await contract.balanceOfEncrypted(address);
      if (encryptedBalance && typeof encryptedBalance === "object" && "data" in encryptedBalance) {
        const bytes = encryptedBalance.data;
        const value = parseInt(bytes, 16);
        setBalance(formatTokenAmount(value, TOKEN_DECIMALS));
      } else {
        setBalance("0.00");
      }
    } catch {
      setBalance("0.00");
    } finally {
      setLoading(false);
    }
  }, [contract, address, isConnected]);

  return { balance, loading, refreshBalance };
}

export function useTotalSupply() {
  const { contract } = useFhenix();
  const [totalSupply, setTotalSupply] = useState<string>("0.00");
  const [loading, setLoading] = useState(false);

  const refreshSupply = useCallback(async () => {
    if (!contract) return;
    setLoading(true);
    try {
      const supply = await contract.totalSupply();
      setTotalSupply(formatTokenAmount(supply, TOKEN_DECIMALS));
    } catch {
      setTotalSupply("0.00");
    } finally {
      setLoading(false);
    }
  }, [contract]);

  return { totalSupply, loading, refreshSupply };
}

export function useTransfer() {
  const { contract, isConnected } = useFhenix();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [txHash, setTxHash] = useState<string | null>(null);

  const transfer = useCallback(
    async (to: string, amount: string) => {
      if (!contract || !isConnected) return;
      if (!ethers.isAddress(to)) {
        setError("Invalid recipient address");
        return;
      }
      setLoading(true);
      setError(null);
      setTxHash(null);
      try {
        const parsedAmount = ethers.parseUnits(amount, TOKEN_DECIMALS);
        const encryptedAmount = await contract.encrypt32(parsedAmount);
        const tx = await contract.transfer(encryptedAmount, to);
        setTxHash(tx.hash);
        await tx.wait();
        return tx;
      } catch (err: unknown) {
        const message = err instanceof Error ? err.message : "Transfer failed";
        setError(message);
      } finally {
        setLoading(false);
      }
    },
    [contract, isConnected]
  );

  return { transfer, loading, error, txHash };
}

export function useMint() {
  const { contract, isConnected } = useFhenix();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [txHash, setTxHash] = useState<string | null>(null);

  const mint = useCallback(
    async (to: string, amount: string) => {
      if (!contract || !isConnected) return;
      setLoading(true);
      setError(null);
      setTxHash(null);
      try {
        const parsedAmount = ethers.parseUnits(amount, TOKEN_DECIMALS);
        const encryptedAmount = await contract.encrypt32(parsedAmount);
        const tx = await contract.mint(encryptedAmount, to);
        setTxHash(tx.hash);
        await tx.wait();
        return tx;
      } catch (err: unknown) {
        const message = err instanceof Error ? err.message : "Mint failed";
        setError(message);
      } finally {
        setLoading(false);
      }
    },
    [contract, isConnected]
  );

  return { mint, loading, error, txHash };
}

export function useBurn() {
  const { contract, isConnected } = useFhenix();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [txHash, setTxHash] = useState<string | null>(null);

  const burn = useCallback(
    async (amount: string) => {
      if (!contract || !isConnected) return;
      setLoading(true);
      setError(null);
      setTxHash(null);
      try {
        const parsedAmount = ethers.parseUnits(amount, TOKEN_DECIMALS);
        const encryptedAmount = await contract.encrypt32(parsedAmount);
        const tx = await contract.burn(encryptedAmount);
        setTxHash(tx.hash);
        await tx.wait();
        return tx;
      } catch (err: unknown) {
        const message = err instanceof Error ? err.message : "Burn failed";
        setError(message);
      } finally {
        setLoading(false);
      }
    },
    [contract, isConnected]
  );

  return { burn, loading, error, txHash };
}

export function useBlacklist() {
  const { contract, isConnected } = useFhenix();
  const [loading, setLoading] = useState(false);

  const checkBlacklisted = useCallback(
    async (account: string): Promise<boolean> => {
      if (!contract) return false;
      try {
        return await contract.isBlacklisted(account);
      } catch {
        return false;
      }
    },
    [contract]
  );

  const addToBlacklist = useCallback(
    async (account: string) => {
      if (!contract || !isConnected) return;
      setLoading(true);
      try {
        const tx = await contract.blacklist(account);
        await tx.wait();
        return tx;
      } finally {
        setLoading(false);
      }
    },
    [contract, isConnected]
  );

  const removeFromBlacklist = useCallback(
    async (account: string) => {
      if (!contract || !isConnected) return;
      setLoading(true);
      try {
        const tx = await contract.unblacklist(account);
        await tx.wait();
        return tx;
      } finally {
        setLoading(false);
      }
    },
    [contract, isConnected]
  );

  return { checkBlacklisted, addToBlacklist, removeFromBlacklist, loading };
}
