import { FormEvent, useMemo, useState } from "react";
import { BrowserProvider, Contract, JsonRpcSigner } from "ethers";
import { FhenixClient, Permit } from "@fhenixjs-browser";
import {
  EncryptedUint,
  getStablecoinAddress,
  parseAmount,
  PermitPermission,
  PRIVATE_STABLECOIN_ABI,
} from "./lib/contract";

type Status = {
  kind: "idle" | "success" | "error";
  message: string;
};

function App() {
  const contractAddress = useMemo(() => getStablecoinAddress(), []);
  const [account, setAccount] = useState<string>("");
  const [trackedSupply, setTrackedSupply] = useState<string>("0");
  const [balance, setBalance] = useState<string>("-");
  const [allowance, setAllowance] = useState<string>("-");
  const [connected, setConnected] = useState(false);
  const [status, setStatus] = useState<Status>({ kind: "idle", message: "Connect a wallet to start." });
  const [mintTo, setMintTo] = useState("");
  const [mintAmount, setMintAmount] = useState("");
  const [burnAmount, setBurnAmount] = useState("");
  const [transferTo, setTransferTo] = useState("");
  const [transferAmount, setTransferAmount] = useState("");
  const [allowanceSpender, setAllowanceSpender] = useState("");
  const [allowanceAmount, setAllowanceAmount] = useState("");
  const [blacklistAddress, setBlacklistAddress] = useState("");
  const [blacklistState, setBlacklistState] = useState(false);

  async function withWallet<T>(action: (deps: {
    provider: BrowserProvider;
    signer: JsonRpcSigner;
    contract: Contract;
    client: FhenixClient;
    account: string;
  }) => Promise<T>): Promise<T> {
    if (!window.ethereum) {
      throw new Error("No injected wallet found.");
    }

    const provider = new BrowserProvider(window.ethereum);
    await provider.send("eth_requestAccounts", []);
    const signer = await provider.getSigner();
    const currentAccount = await signer.getAddress();
    const contract = new Contract(contractAddress, PRIVATE_STABLECOIN_ABI, signer);
    const client = new FhenixClient({ provider: provider as never });

    return action({ provider, signer, contract, client, account: currentAccount });
  }

  async function encryptAmount(client: FhenixClient, rawAmount: string): Promise<EncryptedUint> {
    const encrypted = await client.encrypt_uint128(parseAmount(rawAmount).toString());
    return {
      data: encrypted.data,
      securityZone: encrypted.securityZone,
    };
  }

  async function loadPermitPermission(client: FhenixClient, signer: JsonRpcSigner): Promise<PermitPermission> {
    const owner = await signer.getAddress();
    let permit: Permit | undefined = client.getPermit(contractAddress, owner);

    if (!permit) {
      permit = await client.generatePermit(contractAddress, signer.provider as never, signer);
      client.storePermit(permit, owner);
    }

    return client.extractPermitPermission(permit);
  }

  async function refreshDashboard() {
    try {
      await withWallet(async ({ contract, client, signer, account: currentAccount }) => {
        const permission = await loadPermitPermission(client, signer);
        const [supplyValue, balanceCiphertext] = await Promise.all([
          contract.trackedTotalSupply() as Promise<bigint>,
          contract.balanceOfEncrypted(currentAccount, permission) as Promise<string>,
        ]);

        setAccount(currentAccount);
        setTrackedSupply(supplyValue.toString());
        setBalance(client.unseal(contractAddress, balanceCiphertext, currentAccount).toString());
        setConnected(true);
        setStatus({ kind: "success", message: "Wallet connected and encrypted balance decrypted locally." });
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to refresh dashboard.";
      setStatus({ kind: "error", message });
    }
  }

  async function onConnect() {
    await refreshDashboard();
  }

  async function onMint(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    try {
      await withWallet(async ({ contract, client }) => {
        const encryptedAmount = await encryptAmount(client, mintAmount);
        const tx = await contract.mintEncrypted(mintTo, encryptedAmount);
        await tx.wait();
      });

      setStatus({ kind: "success", message: "Encrypted mint submitted." });
      await refreshDashboard();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Mint failed.";
      setStatus({ kind: "error", message });
    }
  }

  async function onBurn(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    try {
      await withWallet(async ({ contract, client }) => {
        const encryptedAmount = await encryptAmount(client, burnAmount);
        const tx = await contract.burnEncrypted(encryptedAmount);
        await tx.wait();
      });

      setStatus({ kind: "success", message: "Encrypted burn submitted." });
      await refreshDashboard();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Burn failed.";
      setStatus({ kind: "error", message });
    }
  }

  async function onTransfer(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    try {
      await withWallet(async ({ contract, client }) => {
        const encryptedAmount = await encryptAmount(client, transferAmount);
        const tx = await contract.transferEncrypted(transferTo, encryptedAmount);
        await tx.wait();
      });

      setStatus({ kind: "success", message: "Confidential transfer submitted." });
      await refreshDashboard();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Transfer failed.";
      setStatus({ kind: "error", message });
    }
  }

  async function onApprove(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    try {
      await withWallet(async ({ contract, client }) => {
        const encryptedAmount = await encryptAmount(client, allowanceAmount);
        const tx = await contract.approveEncrypted(allowanceSpender, encryptedAmount);
        await tx.wait();
      });

      setStatus({ kind: "success", message: "Encrypted allowance approved." });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Approval failed.";
      setStatus({ kind: "error", message });
    }
  }

  async function onReadAllowance(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    try {
      await withWallet(async ({ contract, client, signer, account: currentAccount }) => {
        const permission = await loadPermitPermission(client, signer);
        const ciphertext = await contract.allowanceEncrypted(currentAccount, allowanceSpender, permission) as string;
        setAllowance(client.unseal(contractAddress, ciphertext, currentAccount).toString());
      });

      setStatus({ kind: "success", message: "Allowance decrypted locally." });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Allowance read failed.";
      setStatus({ kind: "error", message });
    }
  }

  async function onBlacklist(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    try {
      await withWallet(async ({ contract }) => {
        const tx = await contract.setBlacklist(blacklistAddress, blacklistState);
        await tx.wait();
      });

      setStatus({ kind: "success", message: "Blacklist updated." });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Blacklist update failed.";
      setStatus({ kind: "error", message });
    }
  }

  return (
    <main className="app-shell">
      <section className="hero">
        <div>
          <p className="eyebrow">FHERC-20 Stablecoin</p>
          <h1>Private USD on Fhenix</h1>
          <p className="lede">
            Confidential balances, encrypted allowances, admin-gated minting, holder redemptions, and compliance
            blacklist controls in one FHERC-20 flow.
          </p>
        </div>
        <button className="primary-button" onClick={onConnect} type="button">
          {connected ? "Refresh Private State" : "Connect Wallet"}
        </button>
      </section>

      <section className="dashboard">
        <article className="card metric">
          <span>Contract</span>
          <strong>{contractAddress}</strong>
        </article>
        <article className="card metric">
          <span>Account</span>
          <strong>{account || "Not connected"}</strong>
        </article>
        <article className="card metric">
          <span>Tracked Supply</span>
          <strong>{trackedSupply}</strong>
        </article>
        <article className="card metric">
          <span>Private Balance</span>
          <strong>{balance}</strong>
        </article>
        <article className="card metric">
          <span>Allowance Snapshot</span>
          <strong>{allowance}</strong>
        </article>
      </section>

      <section className={`status-panel ${status.kind}`}>
        <span>Status</span>
        <p>{status.message}</p>
      </section>

      <section className="grid">
        <form className="card form-card" onSubmit={onMint}>
          <h2>Admin Mint</h2>
          <input placeholder="Recipient" value={mintTo} onChange={(event) => setMintTo(event.target.value)} />
          <input placeholder="Amount" value={mintAmount} onChange={(event) => setMintAmount(event.target.value)} />
          <button type="submit">Mint Encrypted</button>
        </form>

        <form className="card form-card" onSubmit={onBurn}>
          <h2>Redemption Burn</h2>
          <input placeholder="Amount" value={burnAmount} onChange={(event) => setBurnAmount(event.target.value)} />
          <button type="submit">Burn My Balance</button>
        </form>

        <form className="card form-card" onSubmit={onTransfer}>
          <h2>Private Transfer</h2>
          <input placeholder="Recipient" value={transferTo} onChange={(event) => setTransferTo(event.target.value)} />
          <input
            placeholder="Encrypted amount"
            value={transferAmount}
            onChange={(event) => setTransferAmount(event.target.value)}
          />
          <button type="submit">Send Confidentially</button>
        </form>

        <form className="card form-card" onSubmit={onApprove}>
          <h2>Encrypted Allowance</h2>
          <input
            placeholder="Spender"
            value={allowanceSpender}
            onChange={(event) => setAllowanceSpender(event.target.value)}
          />
          <input
            placeholder="Allowance amount"
            value={allowanceAmount}
            onChange={(event) => setAllowanceAmount(event.target.value)}
          />
          <button type="submit">Approve Encrypted</button>
        </form>

        <form className="card form-card" onSubmit={onReadAllowance}>
          <h2>Decrypt Allowance</h2>
          <input
            placeholder="Spender"
            value={allowanceSpender}
            onChange={(event) => setAllowanceSpender(event.target.value)}
          />
          <button type="submit">Read My Allowance</button>
        </form>

        <form className="card form-card" onSubmit={onBlacklist}>
          <h2>Compliance Blacklist</h2>
          <input
            placeholder="Address"
            value={blacklistAddress}
            onChange={(event) => setBlacklistAddress(event.target.value)}
          />
          <label className="toggle">
            <input
              checked={blacklistState}
              onChange={(event) => setBlacklistState(event.target.checked)}
              type="checkbox"
            />
            <span>Blacklist address</span>
          </label>
          <button type="submit">Update Blacklist</button>
        </form>
      </section>
    </main>
  );
}

export default App;
