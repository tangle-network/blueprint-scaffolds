// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IFHERC20 {
    function name() external view returns (string memory);
    function symbol() external view returns (string memory);
    function decimals() external view returns (uint8);
    function totalSupply() external view returns (uint256);

    function mint(address to, uint256 amount) external;
    function burn(uint256 amount) external;

    function transfer(address to, einput encryptedAmount) external returns (bool);
    function transfer(address to, uint256 amount) external returns (bool);

    function approve(address spender, einput encryptedAmount) external returns (bool);
    function approve(address spender, uint256 amount) external returns (bool);

    function transferFrom(address from, address to, uint256 amount) external returns (bool);

    function balanceOf(address account) external view returns (euint64);
    function allowance(address owner, address spender) external view returns (euint64);

    function balanceOfEncrypted(address account, bytes32 publicKey) external view returns (bytes memory);
    function allowanceEncrypted(address owner, address spender, bytes32 publicKey) external view returns (bytes memory);

    function blacklist(address account) external;
    function unblacklist(address account) external;
    function isBlacklisted(address account) external view returns (bool);

    event Transfer(address indexed from, address indexed to, uint256 amount);
    event TransferEncrypted(address indexed from, address indexed to);
    event Approval(address indexed owner, address indexed spender, uint256 amount);
    event ApprovalEncrypted(address indexed owner, address indexed spender);
    event Blacklisted(address indexed account);
    event Unblacklisted(address indexed account);
    event Mint(address indexed to, uint256 amount);
    event Burn(address indexed from, uint256 amount);
}
