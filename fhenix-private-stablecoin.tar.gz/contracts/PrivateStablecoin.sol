// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import { AccessControl } from "@openzeppelin/contracts/access/AccessControl.sol";
import { ERC20 } from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import { FHE, euint128, inEuint128 } from "@fhenixprotocol/contracts/FHE.sol";
import { Permission, Permissioned } from "@fhenixprotocol/contracts/access/Permissioned.sol";
import { IFHERC20 } from "@fhenixprotocol/contracts/experimental/token/FHERC20/IFHERC20.sol";

contract PrivateStablecoin is ERC20, Permissioned, IFHERC20, AccessControl {
    bytes32 public constant MINTER_ROLE = keccak256("MINTER_ROLE");
    bytes32 public constant COMPLIANCE_ROLE = keccak256("COMPLIANCE_ROLE");

    mapping(address => euint128) internal _encBalances;
    mapping(address => mapping(address => euint128)) internal _allowed;
    mapping(address => bool) public blacklisted;

    euint128 internal _totalEncryptedSupply = FHE.asEuint128(0);
    uint256 private _trackedTotalSupply;

    event BlacklistUpdated(address indexed account, bool blacklistedStatus);
    event MintEncrypted(address indexed operator, address indexed to);
    event BurnEncrypted(address indexed operator, address indexed from);

    error BlacklistedAccount(address account);
    error ZeroAddressNotAllowed();
    constructor(address admin) ERC20("Private USD", "pUSD") {
        if (admin == address(0)) {
            revert ZeroAddressNotAllowed();
        }

        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(MINTER_ROLE, admin);
        _grantRole(COMPLIANCE_ROLE, admin);
    }

    modifier notBlacklisted(address account) {
        if (blacklisted[account]) {
            revert BlacklistedAccount(account);
        }
        _;
    }

    function setBlacklist(address account, bool status) external onlyRole(COMPLIANCE_ROLE) {
        if (account == address(0)) {
            revert ZeroAddressNotAllowed();
        }

        blacklisted[account] = status;
        emit BlacklistUpdated(account, status);
    }

    function balanceOfEncrypted(address account, Permission memory auth)
        public
        view
        override
        onlyPermitted(auth, account)
        notBlacklisted(account)
        returns (string memory)
    {
        return _encBalances[account].seal(auth.publicKey);
    }

    function allowanceEncrypted(address owner, address spender, Permission memory permission)
        public
        view
        override
        onlyBetweenPermitted(permission, owner, spender)
        notBlacklisted(owner)
        notBlacklisted(spender)
        returns (string memory)
    {
        return FHE.sealoutput(_allowed[owner][spender], permission.publicKey);
    }

    function approveEncrypted(address spender, inEuint128 calldata value)
        public
        override
        notBlacklisted(msg.sender)
        notBlacklisted(spender)
        returns (bool)
    {
        _approveEncrypted(msg.sender, spender, FHE.asEuint128(value));
        emit ApprovalEncrypted(msg.sender, spender);
        return true;
    }

    function transferEncrypted(address to, inEuint128 calldata value)
        external
        override
        returns (euint128)
    {
        return _transferEncrypted(to, FHE.asEuint128(value));
    }

    function _transferEncrypted(address to, euint128 value)
        public
        override
        notBlacklisted(msg.sender)
        notBlacklisted(to)
        returns (euint128)
    {
        euint128 transferred = _transferImpl(msg.sender, to, value);
        emit TransferEncrypted(msg.sender, to);
        return transferred;
    }

    function transferFromEncrypted(address from, address to, inEuint128 calldata value)
        external
        override
        returns (euint128)
    {
        return _transferFromEncrypted(from, to, FHE.asEuint128(value));
    }

    function _transferFromEncrypted(address from, address to, euint128 value)
        public
        override
        notBlacklisted(msg.sender)
        notBlacklisted(from)
        notBlacklisted(to)
        returns (euint128)
    {
        euint128 spent = _spendAllowance(from, msg.sender, value);
        euint128 transferred = _transferImpl(from, to, spent);
        emit TransferEncrypted(from, to);
        return transferred;
    }

    function mintEncrypted(address to, inEuint128 calldata encryptedAmount)
        external
        onlyRole(MINTER_ROLE)
        notBlacklisted(to)
    {
        euint128 amount = FHE.asEuint128(encryptedAmount);
        _encBalances[to] = _encBalances[to] + amount;
        _totalEncryptedSupply = _totalEncryptedSupply + amount;
        _trackedTotalSupply += FHE.decrypt(amount);

        emit TransferEncrypted(address(0), to);
        emit MintEncrypted(msg.sender, to);
    }

    function burnEncrypted(inEuint128 calldata encryptedAmount)
        external
        notBlacklisted(msg.sender)
        returns (euint128 burnedAmount)
    {
        burnedAmount = _burnEncrypted(msg.sender, FHE.asEuint128(encryptedAmount));
        emit BurnEncrypted(msg.sender, msg.sender);
    }

    function burnFromEncrypted(address from, inEuint128 calldata encryptedAmount)
        external
        onlyRole(COMPLIANCE_ROLE)
        notBlacklisted(from)
        returns (euint128 burnedAmount)
    {
        burnedAmount = _burnEncrypted(from, FHE.asEuint128(encryptedAmount));
        emit BurnEncrypted(msg.sender, from);
    }

    function trackedTotalSupply() external view returns (uint256) {
        return _trackedTotalSupply;
    }

    function supportsInterface(bytes4 interfaceId)
        public
        view
        override(AccessControl)
        returns (bool)
    {
        return interfaceId == type(IFHERC20).interfaceId || super.supportsInterface(interfaceId);
    }

    function _approveEncrypted(address owner, address spender, euint128 value) internal {
        if (owner == address(0)) {
            revert ERC20InvalidApprover(address(0));
        }
        if (spender == address(0)) {
            revert ERC20InvalidSpender(address(0));
        }

        _allowed[owner][spender] = value;
    }

    function _spendAllowance(address owner, address spender, euint128 value) internal returns (euint128) {
        euint128 currentAllowance = _allowed[owner][spender];
        euint128 spent = FHE.min(currentAllowance, value);
        _approveEncrypted(owner, spender, currentAllowance - spent);
        return spent;
    }

    function _transferImpl(address from, address to, euint128 amount) internal returns (euint128) {
        euint128 amountToSend = FHE.select(amount.lte(_encBalances[from]), amount, FHE.asEuint128(0));
        _encBalances[from] = _encBalances[from] - amountToSend;
        _encBalances[to] = _encBalances[to] + amountToSend;
        return amountToSend;
    }

    function _burnEncrypted(address from, euint128 requestedAmount) internal returns (euint128 burnedAmount) {
        burnedAmount = FHE.select(requestedAmount.lte(_encBalances[from]), requestedAmount, _encBalances[from]);
        _encBalances[from] = _encBalances[from] - burnedAmount;
        _totalEncryptedSupply = _totalEncryptedSupply - burnedAmount;
        _trackedTotalSupply -= FHE.decrypt(burnedAmount);

        emit TransferEncrypted(from, address(0));
    }
}
