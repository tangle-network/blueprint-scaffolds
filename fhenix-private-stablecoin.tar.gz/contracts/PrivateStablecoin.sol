// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IFHERC20} from "./IFHERC20.sol";
import {
    encryptedRes16,
    einput,
    inEuint16,
    euint16,
    FHE,
    fvmPubKey,
    requireEq
} from "@fhenixprotocol/cofhe-contracts/FHE.sol";

abstract contract AccessControl {
    mapping(address => bool) public isAdmin;
    mapping(address => bool) public isMinter;
    address public owner;

    event RoleGranted(bytes32 indexed role, address indexed account);
    event RoleRevoked(bytes32 indexed role, address indexed account);
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }

    modifier onlyAdmin() {
        require(isAdmin[msg.sender] || msg.sender == owner, "Not admin");
        _;
    }

    modifier onlyMinter() {
        require(isMinter[msg.sender] || isAdmin[msg.sender] || msg.sender == owner, "Not minter");
        _;
    }

    constructor() {
        owner = msg.sender;
        isAdmin[msg.sender] = true;
        isMinter[msg.sender] = true;
    }

    function grantAdmin(address account) external onlyOwner {
        isAdmin[account] = true;
        emit RoleGranted(keccak256("ADMIN_ROLE"), account);
    }

    function revokeAdmin(address account) external onlyOwner {
        isAdmin[account] = false;
        emit RoleRevoked(keccak256("ADMIN_ROLE"), account);
    }

    function grantMinter(address account) external onlyAdmin {
        isMinter[account] = true;
        emit RoleGranted(keccak256("MINTER_ROLE"), account);
    }

    function revokeMinter(address account) external onlyAdmin {
        isMinter[account] = false;
        emit RoleRevoked(keccak256("MINTER_ROLE"), account);
    }

    function transferOwnership(address newOwner) external onlyOwner {
        require(newOwner != address(0), "Zero address");
        emit OwnershipTransferred(owner, newOwner);
        owner = newOwner;
    }
}

contract PrivateStablecoin is IFHERC20, AccessControl {
    string public constant override name = "Private USD";
    string public constant override symbol = "pUSD";
    uint8 public constant override decimals = 6;

    uint256 public override totalSupply;

    mapping(address => euint16) internal _balances;
    mapping(address => mapping(address => euint16)) internal _allowances;
    mapping(address => bool) internal _blacklisted;

    constructor() {
        owner = msg.sender;
        isAdmin[msg.sender] = true;
        isMinter[msg.sender] = true;
    }

    function mint(address to, uint256 amount) external override onlyMinter {
        require(to != address(0), "Mint to zero address");
        require(!_blacklisted[to], "Recipient blacklisted");
        require(amount <= type(uint16).max, "Amount exceeds uint16");

        euint16 encryptedAmount = FHE.asEuint16(uint16(amount));
        _balances[to] = FHE.add(_balances[to], encryptedAmount);
        totalSupply += amount;

        emit Mint(to, amount);
        emit Transfer(address(0), to, amount);
    }

    function burn(uint256 amount) external override {
        require(amount <= type(uint16).max, "Amount exceeds uint16");
        require(!_blacklisted[msg.sender], "Sender blacklisted");

        euint16 encryptedAmount = FHE.asEuint16(uint16(amount));

        {
            euint16 senderBalance = _balances[msg.sender];
            euint16 diff = FHE.sub(senderBalance, encryptedAmount);
            requireEq(FHE.le(encryptedAmount, senderBalance), FHE.asEuint16(1), "Insufficient balance");
            _balances[msg.sender] = diff;
        }

        totalSupply -= amount;

        emit Burn(msg.sender, amount);
        emit Transfer(msg.sender, address(0), amount);
    }

    function transfer(address to, einput encryptedAmount) external override returns (bool) {
        require(to != address(0), "Transfer to zero address");
        require(!_blacklisted[msg.sender], "Sender blacklisted");
        require(!_blacklisted[to], "Recipient blacklisted");

        euint16 amount = FHE.asEuint16(encryptedAmount);

        {
            euint16 senderBalance = _balances[msg.sender];
            euint16 diff = FHE.sub(senderBalance, amount);
            requireEq(FHE.le(amount, senderBalance), FHE.asEuint16(1), "Insufficient balance");
            _balances[msg.sender] = diff;
        }

        _balances[to] = FHE.add(_balances[to], amount);

        emit TransferEncrypted(msg.sender, to);
        return true;
    }

    function transfer(address to, uint256 amount) external override returns (bool) {
        require(to != address(0), "Transfer to zero address");
        require(!_blacklisted[msg.sender], "Sender blacklisted");
        require(!_blacklisted[to], "Recipient blacklisted");
        require(amount <= type(uint16).max, "Amount exceeds uint16");

        euint16 encryptedAmount = FHE.asEuint16(uint16(amount));

        {
            euint16 senderBalance = _balances[msg.sender];
            euint16 diff = FHE.sub(senderBalance, encryptedAmount);
            requireEq(FHE.le(encryptedAmount, senderBalance), FHE.asEuint16(1), "Insufficient balance");
            _balances[msg.sender] = diff;
        }

        _balances[to] = FHE.add(_balances[to], encryptedAmount);

        emit Transfer(msg.sender, to, amount);
        return true;
    }

    function approve(address spender, einput encryptedAmount) external override returns (bool) {
        require(!_blacklisted[msg.sender], "Sender blacklisted");
        require(!_blacklisted[spender], "Spender blacklisted");

        euint16 amount = FHE.asEuint16(encryptedAmount);
        _allowances[msg.sender][spender] = amount;

        emit ApprovalEncrypted(msg.sender, spender);
        return true;
    }

    function approve(address spender, uint256 amount) external override returns (bool) {
        require(!_blacklisted[msg.sender], "Sender blacklisted");
        require(!_blacklisted[spender], "Spender blacklisted");
        require(amount <= type(uint16).max, "Amount exceeds uint16");

        _allowances[msg.sender][spender] = FHE.asEuint16(uint16(amount));

        emit Approval(msg.sender, spender, amount);
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) external override returns (bool) {
        require(from != address(0), "Transfer from zero address");
        require(to != address(0), "Transfer to zero address");
        require(!_blacklisted[from], "From blacklisted");
        require(!_blacklisted[to], "Recipient blacklisted");
        require(amount <= type(uint16).max, "Amount exceeds uint16");

        euint16 encryptedAmount = FHE.asEuint16(uint16(amount));

        {
            euint16 currentAllowance = _allowances[from][msg.sender];
            euint16 remainingAllowance = FHE.sub(currentAllowance, encryptedAmount);
            requireEq(FHE.le(encryptedAmount, currentAllowance), FHE.asEuint16(1), "Insufficient allowance");
            _allowances[from][msg.sender] = remainingAllowance;
        }

        {
            euint16 senderBalance = _balances[from];
            euint16 diff = FHE.sub(senderBalance, encryptedAmount);
            requireEq(FHE.le(encryptedAmount, senderBalance), FHE.asEuint16(1), "Insufficient balance");
            _balances[from] = diff;
        }

        _balances[to] = FHE.add(_balances[to], encryptedAmount);

        emit Transfer(from, to, amount);
        return true;
    }

    function balanceOf(address account) external view override returns (euint16) {
        return _balances[account];
    }

    function allowance(address owner_, address spender) external view override returns (euint16) {
        return _allowances[owner_][spender];
    }

    function balanceOfEncrypted(address account, bytes32 publicKey) external view override returns (bytes memory) {
        return FHE.encrypt(_balances[account], publicKey);
    }

    function allowanceEncrypted(address owner_, address spender, bytes32 publicKey) external view override returns (bytes memory) {
        return FHE.encrypt(_allowances[owner_][spender], publicKey);
    }

    function blacklist(address account) external override onlyAdmin {
        _blacklisted[account] = true;
        emit Blacklisted(account);
    }

    function unblacklist(address account) external override onlyAdmin {
        _blacklisted[account] = false;
        emit Unblacklisted(account);
    }

    function isBlacklisted(address account) external view override returns (bool) {
        return _blacklisted[account];
    }
}
