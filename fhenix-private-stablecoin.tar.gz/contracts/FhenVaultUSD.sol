// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {FHE, euint32, inEuint32} from "@fhenixprotocol/contracts/FHE.sol";
import {IFHERC20} from "@fhenixprotocol/contracts/interfaces/IFHERC20.sol";
import {Permissioned, Permission} from "@fhenixprotocol/contracts/access/Permissioned.sol";
import {IAccessControl} from "@openzeppelin/contracts/access/IAccessControl.sol";

error FhenVaultUSD__Unauthorized();
error FhenVaultUSD__Blacklisted(address account);
error FhenVaultUSD__InsufficientBalance();
error FhenVaultUSD__ZeroAddress();
error FhenVaultUSD__Paused();
error FhenVaultUSD__AlreadyBlacklisted(address account);
error FhenVaultUSD__NotBlacklisted(address account);

contract FhenVaultUSD is IFHERC20, Permissioned {
    string public constant name = "FhenVault USD";
    string public constant symbol = "fUSD";
    uint8 public constant decimals = 18;

    bytes32 public constant DEFAULT_ADMIN_ROLE = 0x00;
    bytes32 public constant MINTER_ROLE = keccak256("MINTER_ROLE");
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");

    mapping(address => euint32) private _balances;
    mapping(address => mapping(address => euint32)) private _allowances;
    euint32 private _totalSupply;

    mapping(address => bool) private _blacklisted;
    mapping(bytes32 => bool) private _roles;

    bool private _paused;

    event RoleGranted(bytes32 indexed role, address indexed account, address indexed sender);
    event RoleRevoked(bytes32 indexed role, address indexed account, address indexed sender);
    event Paused(address account);
    event Unpaused(address account);

    modifier onlyRole(bytes32 role) {
        if (!_roles[keccak256(abi.encodePacked(role, msg.sender))]) {
            revert FhenVaultUSD__Unauthorized();
        }
        _;
    }

    modifier whenNotPaused() {
        if (_paused) revert FhenVaultUSD__Paused();
        _;
    }

    modifier whenNotBlacklisted(address account) {
        if (_blacklisted[account]) revert FhenVaultUSD__Blacklisted(account);
        _;
    }

    constructor() {
        _roles[keccak256(abi.encodePacked(DEFAULT_ADMIN_ROLE, msg.sender))] = true;
        _roles[keccak256(abi.encodePacked(MINTER_ROLE, msg.sender))] = true;
        _roles[keccak256(abi.encodePacked(PAUSER_ROLE, msg.sender))] = true;
    }

    function totalSupply() external view override returns (uint256) {
        return FHE.decrypt(_totalSupply);
    }

    function balanceOf(address account, Permission calldata auth) external view override returns (euint32) {
        FHE.reqAuth(auth);
        return _balances[account];
    }

    function balanceOfEncrypted(address account) external view returns (euint32) {
        return _balances[account];
    }

    function transfer(euint32 amount, address to) external override whenNotPaused whenNotBlacklisted(msg.sender) whenNotBlacklisted(to) returns (bool) {
        _transfer(msg.sender, to, amount);
        return true;
    }

    function transferFrom(address from, address to, euint32 amount) external override whenNotPaused whenNotBlacklisted(from) whenNotBlacklisted(to) returns (bool) {
        euint32 currentAllowance = _allowances[from][msg.sender];
        euint32 updatedAllowance = FHE.sub(currentAllowance, amount);
        _allowances[from][msg.sender] = updatedAllowance;
        _transfer(from, to, amount);
        return true;
    }

    function approve(address spender, euint32 amount) external override whenNotPaused returns (bool) {
        _approve(msg.sender, spender, amount);
        return true;
    }

    function allowance(address owner, address spender, Permission calldata auth) external view override returns (euint32) {
        FHE.reqAuth(auth);
        return _allowances[owner][spender];
    }

    function allowanceEncrypted(address owner, address spender) external view returns (euint32) {
        return _allowances[owner][spender];
    }

    function mint(euint32 amount, address to) external onlyRole(MINTER_ROLE) whenNotPaused whenNotBlacklisted(to) {
        _mint(to, amount);
    }

    function burn(euint32 amount) external whenNotPaused whenNotBlacklisted(msg.sender) {
        _burn(msg.sender, amount);
    }

    function blacklist(address account) external onlyRole(DEFAULT_ADMIN_ROLE) {
        if (_blacklisted[account]) revert FhenVaultUSD__AlreadyBlacklisted(account);
        _blacklisted[account] = true;
        emit Blacklisted(account);
    }

    function unblacklist(address account) external onlyRole(DEFAULT_ADMIN_ROLE) {
        if (!_blacklisted[account]) revert FhenVaultUSD__NotBlacklisted(account);
        _blacklisted[account] = false;
        emit Unblacklisted(account);
    }

    function isBlacklisted(address account) external view returns (bool) {
        return _blacklisted[account];
    }

    function pause() external onlyRole(PAUSER_ROLE) {
        _paused = true;
        emit Paused(msg.sender);
    }

    function unpause() external onlyRole(PAUSER_ROLE) {
        _paused = false;
        emit Unpaused(msg.sender);
    }

    function paused() external view returns (bool) {
        return _paused;
    }

    function hasRole(bytes32 role, address account) public view returns (bool) {
        return _roles[keccak256(abi.encodePacked(role, account))];
    }

    function grantRole(bytes32 role, address account) external onlyRole(DEFAULT_ADMIN_ROLE) {
        _roles[keccak256(abi.encodePacked(role, account))] = true;
        emit RoleGranted(role, account, msg.sender);
    }

    function revokeRole(bytes32 role, address account) external onlyRole(DEFAULT_ADMIN_ROLE) {
        _roles[keccak256(abi.encodePacked(role, account))] = false;
        emit RoleRevoked(role, account, msg.sender);
    }

    function _transfer(address from, address to, euint32 amount) internal {
        if (from == address(0) || to == address(0)) revert FhenVaultUSD__ZeroAddress();
        euint32 fromBalance = _balances[from];
        euint32 newFromBalance = FHE.sub(fromBalance, amount);
        _balances[from] = newFromBalance;
        _balances[to] = FHE.add(_balances[to], amount);
        emit IFHERC20.Transfer(from, to, amount);
    }

    function _mint(address to, euint32 amount) internal {
        if (to == address(0)) revert FhenVaultUSD__ZeroAddress();
        _totalSupply = FHE.add(_totalSupply, amount);
        _balances[to] = FHE.add(_balances[to], amount);
        emit Mint(to, amount);
    }

    function _burn(address from, euint32 amount) internal {
        if (from == address(0)) revert FhenVaultUSD__ZeroAddress();
        euint32 fromBalance = _balances[from];
        euint32 newFromBalance = FHE.sub(fromBalance, amount);
        _balances[from] = newFromBalance;
        _totalSupply = FHE.sub(_totalSupply, amount);
        emit Burn(from, amount);
    }

    function _approve(address owner, address spender, euint32 amount) internal {
        if (owner == address(0) || spender == address(0)) revert FhenVaultUSD__ZeroAddress();
        _allowances[owner][spender] = amount;
        emit IFHERC20.Approval(owner, spender, amount);
    }
}
