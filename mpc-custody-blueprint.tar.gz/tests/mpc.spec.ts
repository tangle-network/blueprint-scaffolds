import { describe, expect, it } from "vitest";
import { mockSnapshot } from "../src/data/mockData";
import {
  aggregateSignature,
  approveSigningRequest,
  canAggregateShares,
  evaluateFaultTolerance,
  refreshShares,
  reshareCeremony,
  runDkgCeremony
} from "../src/lib/mpc";

describe("FROST custody blueprint", () => {
  it("creates a deterministic DKG package for the participant set", () => {
    const frost = runDkgCeremony(
      mockSnapshot.ceremony.participants,
      mockSnapshot.ceremony.curve,
      mockSnapshot.ceremony.policy,
      "integration"
    );

    expect(frost.aggregatePublicKey).toContain("ecdsa-agg-");
    expect(frost.shares).toHaveLength(mockSnapshot.ceremony.participants.length);
    expect(new Set(frost.shares.map((share) => share.participantId)).size).toBe(
      mockSnapshot.ceremony.participants.length
    );
  });

  it("aggregates a threshold signature without reconstructing the key", () => {
    const request = structuredClone(mockSnapshot.requests[0]);
    request.approvals = mockSnapshot.ceremony.participants
      .slice(0, 3)
      .map((participant) => approveSigningRequest(request, participant));

    expect(
      canAggregateShares(
        request.approvals,
        mockSnapshot.ceremony.policy,
        mockSnapshot.ceremony.participants
      )
    ).toBe(true);
    expect(aggregateSignature(request, mockSnapshot.ceremony)).toContain("ecdsa-sig-");
  });

  it("detects when byzantine and offline actors exceed tolerance", () => {
    const report = evaluateFaultTolerance(mockSnapshot.ceremony, ["p2", "p4"], ["p3"]);
    expect(report.survives).toBe(false);
    expect(report.healthy).toBe(2);
  });

  it("supports proactive refresh and resharing for participant changes", () => {
    const refreshed = refreshShares(mockSnapshot.ceremony);
    const reshared = reshareCeremony(refreshed, refreshed.participants.slice(0, 4), 3);

    expect(refreshed.lastRefreshEpoch).toBe(mockSnapshot.ceremony.lastRefreshEpoch + 1);
    expect(reshared.policy.threshold).toBe(3);
    expect(reshared.participants).toHaveLength(4);
  });
});
