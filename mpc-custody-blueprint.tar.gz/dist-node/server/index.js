import { createServer } from "./app.js";
const port = Number(process.env.PORT ?? 8787);
const app = createServer();
if (process.env.NODE_ENV !== "test") {
    app.listen(port, () => {
        console.log(`MPC custody API listening on ${port}`);
    });
}
