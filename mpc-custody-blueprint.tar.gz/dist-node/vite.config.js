import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
export default defineConfig({
    plugins: [react()],
    server: {
        port: 4173
    },
    test: {
        include: ["tests/**/*.spec.ts"],
        exclude: ["dist/**", "dist-node/**", "node_modules/**"]
    }
});
