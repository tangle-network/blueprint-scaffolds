import type { CustodySnapshot } from "../lib/types";
export declare const mockSnapshot: CustodySnapshot;
