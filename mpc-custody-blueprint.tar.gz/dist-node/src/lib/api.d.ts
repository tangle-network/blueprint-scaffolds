import type { CustodySnapshot } from "./types";
export declare const custodyApi: {
    fetchSnapshot(): Promise<CustodySnapshot>;
    approveRequest(requestId: string, participantId: string): Promise<import("./types").SigningRequest>;
    refreshCeremony(): Promise<import("./types").CeremonyState>;
    reshare(): Promise<import("./types").CeremonyState>;
    faultReport(): Promise<{
        survives: boolean;
        healthy: number;
        unavailable: number;
        byzantine: number;
    }>;
};
