import type { Approval, CeremonyState, ChainKind, CurveKind, FrostKeyPackage, Participant, SigningRequest, ThresholdPolicy } from "./types";
export declare const buildPolicy: (name: string, threshold: number, participants: number, timelockHours: number) => ThresholdPolicy;
export declare const runDkgCeremony: (participants: Participant[], curve: CurveKind, policy: ThresholdPolicy, label: string) => FrostKeyPackage;
export declare const instantiateCeremony: (id: string, name: string, curve: CurveKind, participants: Participant[], policy: ThresholdPolicy) => CeremonyState;
export declare const createSigningDigest: (chain: ChainKind, destination: string, amount: number, requestedAt: string) => string;
export declare const approveSigningRequest: (request: SigningRequest, participant: Participant) => Approval;
export declare const canAggregateShares: (approvals: Approval[], policy: ThresholdPolicy, participants: Participant[]) => boolean;
export declare const aggregateSignature: (request: SigningRequest, ceremony: CeremonyState) => string | null;
export declare const reshareCeremony: (ceremony: CeremonyState, nextParticipants: Participant[], nextThreshold: number) => CeremonyState;
export declare const refreshShares: (ceremony: CeremonyState) => CeremonyState;
export declare const evaluateFaultTolerance: (ceremony: CeremonyState, unavailable: string[], byzantine: string[]) => {
    survives: boolean;
    healthy: number;
    unavailable: number;
    byzantine: number;
};
