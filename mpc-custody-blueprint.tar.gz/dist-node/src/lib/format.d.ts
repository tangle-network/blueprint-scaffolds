export declare const currency: (value: number) => string;
export declare const amount: (value: number, symbol: string) => string;
export declare const prettyDate: (value: string) => string;
