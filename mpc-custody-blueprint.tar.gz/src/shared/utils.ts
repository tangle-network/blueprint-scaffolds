import { randomBytes, bytesToHex } from '@noble/hashes/utils';

export function generateId(): string {
  return bytesToHex(randomBytes(16));
}

export function now(): number {
  return Math.floor(Date.now() / 1000);
}

export function formatAddress(address: string): string {
  if (address.length <= 12) return address;
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

export function formatAmount(amount: string, decimals = 18): string {
  const num = BigInt(amount);
  const divisor = BigInt(10 ** decimals);
  const whole = num / divisor;
  const frac = num % divisor;
  return `${whole.toString()}.${frac.toString().padStart(decimals, '0').slice(0, 4)}`;
}

export function classNames(...classes: (string | boolean | undefined | null)[]): string {
  return classes.filter(Boolean).join(' ');
}

export const CHAIN_CONFIG = {
  ethereum: { name: 'Ethereum', symbol: 'ETH', decimals: 18, curve: 'secp256k1' as const },
  bitcoin: { name: 'Bitcoin', symbol: 'BTC', decimals: 8, curve: 'secp256k1' as const },
  solana: { name: 'Solana', symbol: 'SOL', decimals: 9, curve: 'ed25519' as const },
} as const;

export type ChainId = keyof typeof CHAIN_CONFIG;
