export type ApprovalPolicyType = 'threshold' | 'unanimous' | 'weighted';

export interface ApprovalPolicy {
  type: ApprovalPolicyType;
  threshold: number;
  totalParticipants: number;
  weights?: Record<string, number>;
  description: string;
}

export interface TimeLock {
  enabled: boolean;
  delaySeconds: number;
  executeAfter: number;
  cancelBefore: number;
}

export interface CustodyVault {
  id: string;
  name: string;
  policy: ApprovalPolicy;
  participants: string[];
  createdAt: number;
  chains: string[];
  emergencyRecoveryEnabled: boolean;
  socialRecoveryGuardians: string[];
  proactiveRefreshEnabled: boolean;
  lastRefreshTimestamp: number;
}

export interface TransactionRequest {
  id: string;
  vaultId: string;
  type: 'transfer' | 'contract_call' | 'raw';
  chain: string;
  to: string;
  amount: string;
  data?: string;
  description: string;
  requestedBy: string;
  requestedAt: number;
  approvals: string[];
  rejections: string[];
  status: 'pending' | 'approved' | 'executing' | 'completed' | 'rejected' | 'expired' | 'timelocked';
  timeLock: TimeLock;
  expiresAt: number;
  maxGasPrice?: string;
  deadline?: number;
}

export interface EmergencyRecovery {
  id: string;
  vaultId: string;
  initiatedBy: string;
  guardianApprovals: string[];
  requiredGuardians: number;
  status: 'pending' | 'approved' | 'executing' | 'completed';
  newPolicy?: ApprovalPolicy;
  initiatedAt: number;
}

export interface AuditLogEntry {
  id: string;
  vaultId: string;
  action: string;
  actor: string;
  timestamp: number;
  details: Record<string, unknown>;
  txHash?: string;
}

export interface WebhookConfig {
  id: string;
  vaultId: string;
  url: string;
  events: string[];
  secret: string;
  active: boolean;
  createdAt: number;
}
