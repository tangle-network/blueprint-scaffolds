import clsx from "clsx";

type Tone = "healthy" | "warning" | "critical" | "neutral";

interface StatusPillProps {
  label: string;
  tone: Tone;
}

export function StatusPill({ label, tone }: StatusPillProps) {
  return <span className={clsx("status-pill", `tone-${tone}`)}>{label}</span>;
}
