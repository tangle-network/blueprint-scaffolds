import type { ReactNode } from "react";

interface MetricCardProps {
  label: string;
  value: string;
  detail: string;
  icon: ReactNode;
}

export function MetricCard({ label, value, detail, icon }: MetricCardProps) {
  return (
    <article className="metric-card">
      <div className="metric-icon">{icon}</div>
      <p className="eyebrow">{label}</p>
      <h3>{value}</h3>
      <p className="muted">{detail}</p>
    </article>
  );
}
