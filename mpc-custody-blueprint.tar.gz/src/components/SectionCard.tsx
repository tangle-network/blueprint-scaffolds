import type { ReactNode } from "react";

interface SectionCardProps {
  title: string;
  subtitle: string;
  action?: ReactNode;
  children: ReactNode;
}

export function SectionCard({ title, subtitle, action, children }: SectionCardProps) {
  return (
    <section className="section-card">
      <header className="section-header">
        <div>
          <p className="eyebrow">{title}</p>
          <h2>{subtitle}</h2>
        </div>
        {action}
      </header>
      {children}
    </section>
  );
}
