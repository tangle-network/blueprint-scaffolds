import { create } from "zustand";
import { CustodyEngine } from "@/lib/custody";
import { AuditLogger } from "@/lib/audit";
import type {
  Participant,
  Transaction,
  ThresholdPolicy,
  VaultBalance,
  AuditEntry,
  KeyCeremonyState,
} from "@/types";

interface CustodyStore {
  participants: Participant[];
  transactions: Transaction[];
  policies: ThresholdPolicy[];
  balances: VaultBalance[];
  auditEntries: AuditEntry[];
  ceremony: KeyCeremonyState | null;
  engine: CustodyEngine;
  logger: AuditLogger;
  selectedTxId: string | null;
  txDialogOpen: boolean;
  newTxDialogOpen: boolean;

  init: () => void;
  setParticipants: (p: Participant[]) => void;
  addParticipant: (p: Participant) => void;
  removeParticipant: (id: string) => void;
  updateParticipantStatus: (id: string, status: Participant["status"]) => void;
  setTransactions: (txs: Transaction[]) => void;
  addTransaction: (tx: Transaction) => void;
  updateTransaction: (tx: Transaction) => void;
  approveTransaction: (txId: string, participantId: string) => void;
  cancelTransaction: (txId: string) => void;
  executeTransaction: (txId: string) => void;
  setPolicies: (p: ThresholdPolicy[]) => void;
  addPolicy: (p: ThresholdPolicy) => void;
  setBalances: (b: VaultBalance[]) => void;
  setAuditEntries: (e: AuditEntry[]) => void;
  addAuditEntry: (e: AuditEntry) => void;
  setCeremony: (c: KeyCeremonyState | null) => void;
  setSelectedTxId: (id: string | null) => void;
  setTxDialogOpen: (open: boolean) => void;
  setNewTxDialogOpen: (open: boolean) => void;
}

export const useCustodyStore = create<CustodyStore>((set, get) => ({
  participants: [],
  transactions: [],
  policies: [],
  balances: [],
  auditEntries: [],
  ceremony: null,
  engine: new CustodyEngine(),
  logger: new AuditLogger(),
  selectedTxId: null,
  txDialogOpen: false,
  newTxDialogOpen: false,

  init: () => {
    const participants = CustodyEngine.generateMockParticipants();
    const transactions = CustodyEngine.generateMockTransactions();
    const policies = CustodyEngine.generateMockPolicies();
    const balances = CustodyEngine.generateMockBalances();
    const auditEntries = AuditLogger.generateMockEntries();
    set({ participants, transactions, policies, balances, auditEntries });
  },

  setParticipants: (p) => set({ participants: p }),
  addParticipant: (p) =>
    set((s) => ({ participants: [...s.participants, p] })),
  removeParticipant: (id) =>
    set((s) => ({ participants: s.participants.filter((p) => p.id !== id) })),
  updateParticipantStatus: (id, status) =>
    set((s) => ({
      participants: s.participants.map((p) =>
        p.id === id ? { ...p, status, lastActive: Date.now() } : p
      ),
    })),

  setTransactions: (txs) => set({ transactions: txs }),
  addTransaction: (tx) =>
    set((s) => ({ transactions: [tx, ...s.transactions] })),
  updateTransaction: (tx) =>
    set((s) => ({
      transactions: s.transactions.map((t) => (t.id === tx.id ? tx : t)),
    })),
  approveTransaction: (txId, participantId) => {
    const { engine, logger, transactions } = get();
    try {
      const updated = engine.approveTransaction(txId, participantId);
      logger.log(
        "transaction.approved",
        participantId,
        txId,
        `Approved (${updated.approvals.length}/${updated.requiredApprovals})`
      );
      set({
        transactions: transactions.map((t) => (t.id === txId ? updated : t)),
      });
    } catch (e) {
      console.error(e);
    }
  },
  cancelTransaction: (txId) => {
    const { engine, logger, transactions } = get();
    try {
      const updated = engine.cancelTransaction(txId, "admin");
      logger.log("transaction.cancelled", "admin", txId, "Cancelled");
      set({
        transactions: transactions.map((t) => (t.id === txId ? updated : t)),
      });
    } catch (e) {
      console.error(e);
    }
  },
  executeTransaction: (txId) => {
    const { engine, logger, transactions } = get();
    try {
      const updated = engine.executeTransaction(txId);
      logger.log(
        "transaction.completed",
        "System",
        txId,
        `Executed. TxHash: ${updated.txHash}`
      );
      set({
        transactions: transactions.map((t) => (t.id === txId ? updated : t)),
      });
    } catch (e) {
      console.error(e);
    }
  },

  setPolicies: (p) => set({ policies: p }),
  addPolicy: (p) => set((s) => ({ policies: [...s.policies, p] })),
  setBalances: (b) => set({ balances: b }),
  setAuditEntries: (e) => set({ auditEntries: e }),
  addAuditEntry: (e) => set((s) => ({ auditEntries: [e, ...s.auditEntries] })),
  setCeremony: (c) => set({ ceremony: c }),
  setSelectedTxId: (id) => set({ selectedTxId: id }),
  setTxDialogOpen: (open) => set({ txDialogOpen: open }),
  setNewTxDialogOpen: (open) => set({ newTxDialogOpen: open }),
}));
