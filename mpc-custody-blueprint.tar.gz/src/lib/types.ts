export type CurveKind = "ecdsa" | "eddsa";
export type ChainKind = "ethereum" | "bitcoin" | "solana";
export type RequestStatus =
  | "draft"
  | "pending"
  | "timelocked"
  | "ready"
  | "signed"
  | "executed"
  | "rejected";
export type ParticipantRole = "signer" | "observer" | "recovery";
export type AuditSeverity = "info" | "warning" | "critical";

export interface AssetBalance {
  chain: ChainKind;
  symbol: string;
  amount: number;
  fiatValue: number;
  pending: number;
}

export interface Participant {
  id: string;
  name: string;
  role: ParticipantRole;
  region: string;
  deviceTrust: "hsm" | "tee" | "software";
  online: boolean;
  byzantine?: boolean;
}

export interface ThresholdPolicy {
  name: string;
  threshold: number;
  participants: number;
  timelockHours: number;
  socialRecoveryThreshold: number;
  refreshIntervalDays: number;
}

export interface CeremonyState {
  id: string;
  name: string;
  curve: CurveKind;
  stage: "planning" | "dkg" | "active" | "resharing";
  participants: Participant[];
  policy: ThresholdPolicy;
  publicKey: string;
  shareCommitments: string[];
  lastRefreshEpoch: number;
  nextRefreshDue: string;
}

export interface Approval {
  participantId: string;
  approvedAt: string;
  signatureShare: string;
}

export interface SigningRequest {
  id: string;
  chain: ChainKind;
  asset: string;
  amount: number;
  destination: string;
  requestedAt: string;
  executeAfter: string;
  status: RequestStatus;
  policyName: string;
  approvals: Approval[];
  requiredApprovals: number;
  payloadDigest: string;
  walletConnectTopic?: string;
}

export interface AuditEvent {
  id: string;
  at: string;
  actor: string;
  action: string;
  severity: AuditSeverity;
  detail: string;
}

export interface WebhookSubscription {
  id: string;
  target: string;
  event: "approval.pending" | "approval.ready" | "execution.complete";
  secretLabel: string;
}

export interface ChainAdapterStatus {
  chain: ChainKind;
  signerCurve: CurveKind;
  connected: boolean;
  rpc: string;
}

export interface FrostKeyPackage {
  aggregatePublicKey: string;
  verificationVector: string[];
  shares: Array<{
    participantId: string;
    index: number;
    nonceCommitment: string;
  }>;
}

export interface RecoveryPlan {
  quorum: number;
  guardians: Participant[];
  timelockHours: number;
}

export interface CustodySnapshot {
  balances: AssetBalance[];
  ceremony: CeremonyState;
  requests: SigningRequest[];
  auditTrail: AuditEvent[];
  adapters: ChainAdapterStatus[];
  webhooks: WebhookSubscription[];
  recovery: RecoveryPlan;
}
