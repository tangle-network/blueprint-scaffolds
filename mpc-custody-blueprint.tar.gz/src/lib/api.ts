import { mockSnapshot } from "../data/mockData";
import {
  aggregateSignature,
  approveSigningRequest,
  canAggregateShares,
  evaluateFaultTolerance,
  refreshShares,
  reshareCeremony
} from "./mpc";
import type { CustodySnapshot } from "./types";

let snapshot: CustodySnapshot = structuredClone(mockSnapshot);

const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export const custodyApi = {
  async fetchSnapshot() {
    await wait(120);
    return structuredClone(snapshot);
  },

  async approveRequest(requestId: string, participantId: string) {
    await wait(180);
    const request = snapshot.requests.find((item) => item.id === requestId);
    const participant = snapshot.ceremony.participants.find((item) => item.id === participantId);
    if (!request || !participant) {
      throw new Error("Request or participant not found");
    }

    const alreadyApproved = request.approvals.some((approval) => approval.participantId === participantId);
    if (!alreadyApproved) {
      request.approvals.push(approveSigningRequest(request, participant));
    }

    if (canAggregateShares(request.approvals, snapshot.ceremony.policy, snapshot.ceremony.participants)) {
      request.status = new Date(request.executeAfter) > new Date() ? "ready" : "signed";
      const signature = aggregateSignature(request, snapshot.ceremony);
      snapshot.auditTrail.unshift({
        id: `audit-${snapshot.auditTrail.length + 1}`,
        at: new Date().toISOString(),
        actor: participant.name,
        action: "Threshold Reached",
        severity: "info",
        detail: `Aggregated signature ${signature ?? "pending"} for ${request.id}`
      });
    }

    return structuredClone(request);
  },

  async refreshCeremony() {
    await wait(160);
    snapshot.ceremony = refreshShares(snapshot.ceremony);
    return structuredClone(snapshot.ceremony);
  },

  async reshare() {
    await wait(220);
    const nextParticipants = snapshot.ceremony.participants.slice(0, 4);
    snapshot.ceremony = reshareCeremony(snapshot.ceremony, nextParticipants, 3);
    return structuredClone(snapshot.ceremony);
  },

  async faultReport() {
    await wait(90);
    return evaluateFaultTolerance(snapshot.ceremony, ["p4"], ["p5"]);
  }
};
