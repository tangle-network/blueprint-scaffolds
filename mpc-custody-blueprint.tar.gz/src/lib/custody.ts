import { generateId, formatAddress, shortenHex } from "./utils";
import { FROSTThreshold } from "./frost";
import { sha256 } from "@noble/hashes/sha256";
import type {
  Transaction,
  TransactionStatus,
  ThresholdPolicy,
  Participant,
  KeyShare,
  VaultBalance,
  ChainType,
  SignatureType,
  SocialRecoveryConfig,
  WebhookConfig,
} from "@/types";

export class CustodyEngine {
  private policies: Map<string, ThresholdPolicy> = new Map();
  private transactions: Map<string, Transaction> = new Map();
  private keyShares: Map<string, KeyShare[]> = new Map();
  private webhooks: Map<string, WebhookConfig> = new Map();
  private socialRecovery: Map<string, SocialRecoveryConfig> = new Map();
  private pendingApprovals: Map<string, Set<string>> = new Map();

  createPolicy(
    name: string,
    threshold: number,
    totalParticipants: number,
    chainType: ChainType,
    signatureType: SignatureType
  ): ThresholdPolicy {
    if (threshold < 1 || threshold > totalParticipants) {
      throw new Error("Invalid threshold configuration");
    }
    const policy: ThresholdPolicy = {
      id: generateId(),
      name,
      threshold,
      totalParticipants,
      chainType,
      signatureType,
      createdAt: Date.now(),
      isActive: true,
    };
    this.policies.set(policy.id, policy);
    return policy;
  }

  getPolicy(policyId: string): ThresholdPolicy | undefined {
    return this.policies.get(policyId);
  }

  getAllPolicies(): ThresholdPolicy[] {
    return Array.from(this.policies.values());
  }

  initiateTransaction(
    policyId: string,
    from: string,
    to: string,
    amount: string,
    token: string,
    chain: ChainType,
    initiatorId: string,
    executeAfter?: number
  ): Transaction {
    const policy = this.policies.get(policyId);
    if (!policy) throw new Error("Policy not found");
    if (!policy.isActive) throw new Error("Policy is not active");

    const status: TransactionStatus = executeAfter
      ? "timelocked"
      : "awaiting_approvals";

    const tx: Transaction = {
      id: generateId(),
      policyId,
      from,
      to,
      amount,
      token,
      chain,
      status,
      approvals: [],
      requiredApprovals: policy.threshold,
      initiatorId,
      createdAt: Date.now(),
      executeAfter,
    };

    this.transactions.set(tx.id, tx);
    this.pendingApprovals.set(tx.id, new Set());
    return tx;
  }

  approveTransaction(
    txId: string,
    participantId: string
  ): Transaction {
    const tx = this.transactions.get(txId);
    if (!tx) throw new Error("Transaction not found");

    if (tx.status === "completed" || tx.status === "cancelled" || tx.status === "failed") {
      throw new Error(`Cannot approve transaction in ${tx.status} state`);
    }

    if (tx.approvals.includes(participantId)) {
      throw new Error("Already approved");
    }

    const pending = this.pendingApprovals.get(txId);
    if (pending) pending.add(participantId);

    const newApprovals = [...tx.approvals, participantId];

    let newStatus: TransactionStatus = tx.status;
    if (newApprovals.length >= tx.requiredApprovals) {
      if (tx.executeAfter && Date.now() < tx.executeAfter) {
        newStatus = "approved";
      } else {
        newStatus = "executing";
      }
    }

    const updatedTx: Transaction = {
      ...tx,
      approvals: newApprovals,
      status: newStatus,
    };
    this.transactions.set(txId, updatedTx);
    return updatedTx;
  }

  executeTransaction(txId: string): Transaction {
    const tx = this.transactions.get(txId);
    if (!tx) throw new Error("Transaction not found");

    if (tx.status !== "executing" && tx.status !== "approved") {
      throw new Error("Transaction not ready for execution");
    }

    if (tx.executeAfter && Date.now() < tx.executeAfter) {
      throw new Error("Time lock has not expired");
    }

    const updatedTx: Transaction = {
      ...tx,
      status: "completed",
      completedAt: Date.now(),
      txHash: `0x${Array.from(sha256(new TextEncoder().encode(txId)))
        .map((b) => b.toString(16).padStart(2, "0"))
        .join("")}`,
    };
    this.transactions.set(txId, updatedTx);
    return updatedTx;
  }

  cancelTransaction(txId: string, cancellerId: string): Transaction {
    const tx = this.transactions.get(txId);
    if (!tx) throw new Error("Transaction not found");

    if (tx.status === "completed" || tx.status === "executing") {
      throw new Error("Cannot cancel completed/executing transaction");
    }

    const updatedTx: Transaction = {
      ...tx,
      status: "cancelled",
    };
    this.transactions.set(txId, updatedTx);
    return updatedTx;
  }

  getTransaction(txId: string): Transaction | undefined {
    return this.transactions.get(txId);
  }

  getTransactionsForPolicy(policyId: string): Transaction[] {
    return Array.from(this.transactions.values()).filter(
      (tx) => tx.policyId === policyId
    );
  }

  getAllTransactions(): Transaction[] {
    return Array.from(this.transactions.values());
  }

  getPendingTransactions(): Transaction[] {
    return Array.from(this.transactions.values()).filter(
      (tx) =>
        tx.status === "awaiting_approvals" ||
        tx.status === "pending" ||
        tx.status === "timelocked"
    );
  }

  storeKeyShares(policyId: string, shares: KeyShare[]): void {
    this.keyShares.set(policyId, shares);
  }

  getKeyShares(policyId: string): KeyShare[] {
    return this.keyShares.get(policyId) || [];
  }

  configureSocialRecovery(
    policyId: string,
    guardians: string[],
    recoveryThreshold: number,
    delayMs: number
  ): SocialRecoveryConfig {
    const config: SocialRecoveryConfig = {
      guardians,
      recoveryThreshold,
      delayMs,
      isActive: true,
    };
    this.socialRecovery.set(policyId, config);
    return config;
  }

  getSocialRecovery(policyId: string): SocialRecoveryConfig | undefined {
    return this.socialRecovery.get(policyId);
  }

  addWebhook(url: string, events: string[]): WebhookConfig {
    const webhook: WebhookConfig = {
      id: generateId(),
      url,
      events,
      isActive: true,
      createdAt: Date.now(),
    };
    this.webhooks.set(webhook.id, webhook);
    return webhook;
  }

  getWebhooks(): WebhookConfig[] {
    return Array.from(this.webhooks.values());
  }

  static generateMockBalances(): VaultBalance[] {
    return [
      {
        chain: "ethereum",
        token: "Ether",
        symbol: "ETH",
        amount: "142.583",
        usdValue: 456265.6,
        address: "0x742d35Cc6634C0532925a3b844Bc9e7595f2bD68",
      },
      {
        chain: "ethereum",
        token: "USD Coin",
        symbol: "USDC",
        amount: "1,250,000.00",
        usdValue: 1250000,
        address: "0x742d35Cc6634C0532925a3b844Bc9e7595f2bD68",
      },
      {
        chain: "bitcoin",
        token: "Bitcoin",
        symbol: "BTC",
        amount: "12.4521",
        usdValue: 861482.92,
        address: "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh",
      },
      {
        chain: "solana",
        token: "Solana",
        symbol: "SOL",
        amount: "3,450.00",
        usdValue: 517500,
        address: "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU",
      },
      {
        chain: "ethereum",
        token: "Tether",
        symbol: "USDT",
        amount: "500,000.00",
        usdValue: 500000,
        address: "0x742d35Cc6634C0532925a3b844Bc9e7595f2bD68",
      },
    ];
  }

  static generateMockParticipants(): Participant[] {
    const now = Date.now();
    return [
      {
        id: "p-1",
        name: "Alice Chen",
        address: "0x742d35Cc6634C0532925a3b844Bc9e7595f2bD68",
        status: "online",
        role: "admin",
        joinedAt: now - 90 * 24 * 3600 * 1000,
        lastActive: now - 120000,
        hsmEnabled: true,
      },
      {
        id: "p-2",
        name: "Bob Martinez",
        address: "0x8Ba1f109551bD432803012645Ac136ddd64DBA72",
        status: "online",
        role: "signer",
        joinedAt: now - 60 * 24 * 3600 * 1000,
        lastActive: now - 300000,
        hsmEnabled: false,
      },
      {
        id: "p-3",
        name: "Carol Williams",
        address: "0xdD870fA1b7C4700F2BD7f44238821C26f7392148",
        status: "offline",
        role: "signer",
        joinedAt: now - 45 * 24 * 3600 * 1000,
        lastActive: now - 86400000,
        hsmEnabled: true,
      },
      {
        id: "p-4",
        name: "David Kim",
        address: "0x583031D1113aD414F02576BD6afaBfb302140225",
        status: "online",
        role: "signer",
        joinedAt: now - 30 * 24 * 3600 * 1000,
        lastActive: now - 60000,
        hsmEnabled: false,
      },
      {
        id: "p-5",
        name: "Eva Fischer",
        address: "0x4B0897b0513fdC7C541B6d9D7E929C4e5364D2dB",
        status: "busy",
        role: "observer",
        joinedAt: now - 15 * 24 * 3600 * 1000,
        lastActive: now - 3600000,
        hsmEnabled: false,
      },
    ];
  }

  static generateMockTransactions(): Transaction[] {
    const now = Date.now();
    return [
      {
        id: "tx-1",
        policyId: "pol-1",
        from: "0x742d35Cc6634C0532925a3b844Bc9e7595f2bD68",
        to: "0xAb5801a7D398351b8bE11C439e05C5B3259aeC9B",
        amount: "10.5",
        token: "ETH",
        chain: "ethereum",
        status: "awaiting_approvals",
        approvals: ["p-1"],
        requiredApprovals: 3,
        initiatorId: "p-2",
        createdAt: now - 1800000,
      },
      {
        id: "tx-2",
        policyId: "pol-1",
        from: "0x742d35Cc6634C0532925a3b844Bc9e7595f2bD68",
        to: "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh",
        amount: "2.0",
        token: "BTC",
        chain: "bitcoin",
        status: "completed",
        approvals: ["p-1", "p-2", "p-3"],
        requiredApprovals: 3,
        initiatorId: "p-1",
        createdAt: now - 86400000,
        completedAt: now - 72000000,
        txHash:
          "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
      },
      {
        id: "tx-3",
        policyId: "pol-2",
        from: "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU",
        to: "DRpbCBMxVnDK7maPM5tGv6MvB3v1sRMC86PZ8ckoTgz",
        amount: "500.0",
        token: "SOL",
        chain: "solana",
        status: "timelocked",
        approvals: ["p-1", "p-4"],
        requiredApprovals: 3,
        initiatorId: "p-4",
        createdAt: now - 3600000,
        executeAfter: now + 86400000,
      },
      {
        id: "tx-4",
        policyId: "pol-1",
        from: "0x742d35Cc6634C0532925a3b844Bc9e7595f2bD68",
        to: "0x5B38Da6a701c568545dCfcB03FcB875f56beddC4",
        amount: "100000.0",
        token: "USDC",
        chain: "ethereum",
        status: "cancelled",
        approvals: ["p-2"],
        requiredApprovals: 3,
        initiatorId: "p-3",
        createdAt: now - 172800000,
      },
    ];
  }

  static generateMockPolicies(): ThresholdPolicy[] {
    return [
      {
        id: "pol-1",
        name: "Main Treasury",
        threshold: 3,
        totalParticipants: 5,
        chainType: "ethereum",
        signatureType: "ecdsa",
        createdAt: Date.now() - 90 * 24 * 3600 * 1000,
        isActive: true,
      },
      {
        id: "pol-2",
        name: "BTC Reserve",
        threshold: 2,
        totalParticipants: 3,
        chainType: "bitcoin",
        signatureType: "ecdsa",
        createdAt: Date.now() - 60 * 24 * 3600 * 1000,
        isActive: true,
      },
      {
        id: "pol-3",
        name: "Solana Operations",
        threshold: 2,
        totalParticipants: 4,
        chainType: "solana",
        signatureType: "eddsa",
        createdAt: Date.now() - 30 * 24 * 3600 * 1000,
        isActive: false,
      },
    ];
  }
}
