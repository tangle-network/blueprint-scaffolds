import type {
  Approval,
  CeremonyState,
  ChainKind,
  CurveKind,
  FrostKeyPackage,
  Participant,
  SigningRequest,
  ThresholdPolicy
} from "./types";

const digest = (seed: string) =>
  Array.from(seed).reduce((acc, char, index) => {
    const next = (acc + char.charCodeAt(0) * (index + 17)) % 0xffffff;
    return next ^ (index * 2654435761);
  }, 2166136261 >>> 0).toString(16).padStart(8, "0");

export const buildPolicy = (
  name: string,
  threshold: number,
  participants: number,
  timelockHours: number
): ThresholdPolicy => ({
  name,
  threshold,
  participants,
  timelockHours,
  socialRecoveryThreshold: Math.max(2, Math.floor(threshold / 2) + 1),
  refreshIntervalDays: 30
});

export const runDkgCeremony = (
  participants: Participant[],
  curve: CurveKind,
  policy: ThresholdPolicy,
  label: string
): FrostKeyPackage => {
  const verificationVector = participants.map((participant, index) =>
    `${curve}-verify-${digest(`${participant.id}-${label}-${index}`)}`
  );

  return {
    aggregatePublicKey: `${curve}-agg-${digest(`${label}-${policy.threshold}-${participants.length}`)}`,
    verificationVector,
    shares: participants.map((participant, index) => ({
      participantId: participant.id,
      index: index + 1,
      nonceCommitment: `${curve}-nonce-${digest(`${participant.id}-${curve}-${label}`)}`
    }))
  };
};

export const instantiateCeremony = (
  id: string,
  name: string,
  curve: CurveKind,
  participants: Participant[],
  policy: ThresholdPolicy
): CeremonyState => {
  const frost = runDkgCeremony(participants, curve, policy, id);
  const refreshDate = new Date(Date.now() + policy.refreshIntervalDays * 86400000);

  return {
    id,
    name,
    curve,
    stage: "active",
    participants,
    policy,
    publicKey: frost.aggregatePublicKey,
    shareCommitments: frost.verificationVector,
    lastRefreshEpoch: 12,
    nextRefreshDue: refreshDate.toISOString()
  };
};

export const createSigningDigest = (
  chain: ChainKind,
  destination: string,
  amount: number,
  requestedAt: string
) => `${chain}-${digest(`${destination}-${amount}-${requestedAt}`)}`;

export const approveSigningRequest = (
  request: SigningRequest,
  participant: Participant
): Approval => ({
  participantId: participant.id,
  approvedAt: new Date().toISOString(),
  signatureShare: `${participant.id}-share-${digest(`${request.id}-${participant.id}-${request.payloadDigest}`)}`
});

export const canAggregateShares = (
  approvals: Approval[],
  policy: ThresholdPolicy,
  participants: Participant[]
) => {
  const distinct = new Set(approvals.map((approval) => approval.participantId));
  const activeApprovals = participants.filter(
    (participant) => distinct.has(participant.id) && !participant.byzantine
  ).length;

  return activeApprovals >= policy.threshold;
};

export const aggregateSignature = (
  request: SigningRequest,
  ceremony: CeremonyState
): string | null => {
  if (!canAggregateShares(request.approvals, ceremony.policy, ceremony.participants)) {
    return null;
  }

  return `${ceremony.curve}-sig-${digest(`${request.id}-${ceremony.publicKey}-${request.approvals.length}`)}`;
};

export const reshareCeremony = (
  ceremony: CeremonyState,
  nextParticipants: Participant[],
  nextThreshold: number
): CeremonyState => {
  const policy = buildPolicy(
    `${ceremony.policy.name} Reshare`,
    nextThreshold,
    nextParticipants.length,
    ceremony.policy.timelockHours
  );
  const next = instantiateCeremony(
    `${ceremony.id}-reshare`,
    `${ceremony.name} Reshared`,
    ceremony.curve,
    nextParticipants,
    policy
  );

  return {
    ...next,
    stage: "resharing",
    lastRefreshEpoch: ceremony.lastRefreshEpoch + 1
  };
};

export const refreshShares = (ceremony: CeremonyState): CeremonyState => {
  const shares = runDkgCeremony(
    ceremony.participants,
    ceremony.curve,
    ceremony.policy,
    `${ceremony.id}-${ceremony.lastRefreshEpoch + 1}`
  );

  return {
    ...ceremony,
    shareCommitments: shares.verificationVector,
    lastRefreshEpoch: ceremony.lastRefreshEpoch + 1,
    nextRefreshDue: new Date(Date.now() + ceremony.policy.refreshIntervalDays * 86400000).toISOString()
  };
};

export const evaluateFaultTolerance = (
  ceremony: CeremonyState,
  unavailable: string[],
  byzantine: string[]
) => {
  const healthy = ceremony.participants.filter(
    (participant) =>
      !unavailable.includes(participant.id) && !byzantine.includes(participant.id)
  ).length;

  return {
    survives: healthy >= ceremony.policy.threshold,
    healthy,
    unavailable: unavailable.length,
    byzantine: byzantine.length
  };
};
