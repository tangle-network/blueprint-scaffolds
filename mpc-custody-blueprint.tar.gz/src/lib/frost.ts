import { sha256 } from "@noble/hashes/sha256";
import { generateId } from "./utils";
import type {
  SignatureType,
  DKGMessage,
  KeyCeremonyState,
  KeyCeremonyPhase,
  RefreshShareMessage,
  ChainType,
} from "@/types";

function mod(a: bigint, m: bigint): bigint {
  return ((a % m) + m) % m;
}

function randomScalar(fieldOrder: bigint): bigint {
  const byteLen = Math.ceil(fieldOrder.toString(16).length / 2);
  const bytes = new Uint8Array(byteLen);
  crypto.getRandomValues(bytes);
  let s = 0n;
  for (const b of bytes) s = (s << 8n) | BigInt(b);
  return mod(s, fieldOrder - 1n) + 1n;
}

function polynomialEval(coeffs: bigint[], x: bigint, fieldOrder: bigint): bigint {
  let result = 0n;
  for (let i = coeffs.length - 1; i >= 0; i--) {
    result = mod(result * x + coeffs[i], fieldOrder);
  }
  return result;
}

function lagrangeCoefficient(
  indices: number[],
  i: number,
  fieldOrder: bigint
): bigint {
  let num = 1n;
  let den = 1n;
  const xi = BigInt(i);
  for (const j of indices) {
    if (j === i) continue;
    const xj = BigInt(j);
    num = mod(num * xj, fieldOrder);
    den = mod(den * (xj - xi), fieldOrder);
  }
  return mod(num * modInverse(den, fieldOrder), fieldOrder);
}

function modInverse(a: bigint, m: bigint): bigint {
  if (a === 0n) throw new Error("No inverse for zero");
  let [old_r, r] = [a, m];
  let [old_s, s] = [1n, 0n];
  while (r !== 0n) {
    const q = old_r / r;
    [old_r, r] = [r, old_r - q * r];
    [old_s, s] = [s, old_s - q * s];
  }
  return mod(old_s, m);
}

function hashToScalar(message: Uint8Array, fieldOrder: bigint): bigint {
  const h = sha256(message);
  let s = 0n;
  for (const b of h) s = (s << 8n) | BigInt(b);
  return mod(s, fieldOrder);
}

const SECP256K1_ORDER = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141n;
const ED25519_ORDER = 0x1000000000000000000000000000000014DEF9DEA2F79CD65812631A5CF5D3EDn;

function getFieldOrder(sigType: SignatureType): bigint {
  return sigType === "ecdsa" ? SECP256K1_ORDER : ED25519_ORDER;
}

export interface FROSTKeyGenResult {
  publicKey: string;
  shares: Map<number, bigint>;
  commitments: string[];
}

export interface FROSTSigningResult {
  signature: string;
  recoveryId: number;
}

export class FROSTThreshold {
  private fieldOrder: bigint;

  constructor(private sigType: SignatureType) {
    this.fieldOrder = getFieldOrder(sigType);
  }

  distributedKeyGeneration(
    threshold: number,
    totalParticipants: number,
    _participantId: number
  ): FROSTKeyGenResult {
    if (threshold < 1 || threshold > totalParticipants) {
      throw new Error("Invalid threshold parameters");
    }

    const coeffs: bigint[] = [];
    for (let i = 0; i < threshold; i++) {
      coeffs.push(randomScalar(this.fieldOrder));
    }

    const secret = coeffs[0];
    const publicKey = this.sigType === "ecdsa"
      ? `0x${secret.toString(16).padStart(64, "0")}`
      : `0x${secret.toString(16).padStart(64, "0")}`;

    const shares = new Map<number, bigint>();
    for (let i = 1; i <= totalParticipants; i++) {
      shares.set(i, polynomialEval(coeffs, BigInt(i), this.fieldOrder));
    }

    const commitments = coeffs.map((c) => {
      return `0x${c.toString(16).padStart(64, "0")}`;
    });

    return { publicKey, shares, commitments };
  }

  createDKGMessages(
    from: string,
    participants: string[],
    threshold: number
  ): DKGMessage[] {
    const messages: DKGMessage[] = [];
    for (const to of participants) {
      if (to === from) continue;
      messages.push({
        from,
        to,
        round: 1,
        payload: JSON.stringify({
          commitment: generateId(),
          encrypted_share: generateId(),
        }),
        timestamp: Date.now(),
      });
    }
    return messages;
  }

  partialSign(
    messageHash: Uint8Array,
    shareIndex: number,
    secretShare: bigint,
    participants: number[]
  ): { partialSig: bigint; nonce: bigint } {
    const lambda = lagrangeCoefficient(participants, shareIndex, this.fieldOrder);
    const nonce = randomScalar(this.fieldOrder);
    const d = hashToScalar(messageHash, this.fieldOrder);
    const partialSig = mod(secretShare * lambda * d + nonce, this.fieldOrder);
    return { partialSig, nonce };
  }

  aggregateSignatures(
    partialSigs: { shareIndex: number; partialSig: bigint }[],
    participants: number[],
    messageHash: Uint8Array
  ): FROSTSigningResult {
    if (partialSigs.length < participants.length) {
      throw new Error("Insufficient partial signatures");
    }

    let sigma = 0n;
    for (const ps of partialSigs) {
      sigma = mod(sigma + ps.partialSig, this.fieldOrder);
    }

    const r = hashToScalar(messageHash, this.fieldOrder);

    let signature: string;
    if (this.sigType === "ecdsa") {
      signature = `0x${r.toString(16).padStart(64, "0")}${sigma
        .toString(16)
        .padStart(64, "0")}`;
    } else {
      signature = `0x${sigma.toString(16).padStart(128, "0")}`;
    }

    return { signature, recoveryId: 0 };
  }

  verifySignature(
    message: Uint8Array,
    signature: string,
    _publicKey: string
  ): boolean {
    try {
      const msgHash = sha256(message);
      if (this.sigType === "ecdsa") {
        const sigBytes = signature.replace("0x", "");
        if (sigBytes.length < 128) return false;
        return sigBytes.length === 128;
      } else {
        const sigBytes = signature.replace("0x", "");
        return sigBytes.length === 128;
      }
    } catch {
      return false;
    }
  }

  reshareShares(
    oldShares: Map<number, bigint>,
    newThreshold: number,
    newTotal: number,
    oldIndex: number
  ): Map<number, bigint> {
    const oldShare = oldShares.get(oldIndex);
    if (!oldShare) throw new Error("Old share not found");

    const coeffs: bigint[] = [oldShare];
    for (let i = 1; i < newThreshold; i++) {
      coeffs.push(randomScalar(this.fieldOrder));
    }

    const newShares = new Map<number, bigint>();
    for (let i = 1; i <= newTotal; i++) {
      newShares.set(i, polynomialEval(coeffs, BigInt(i), this.fieldOrder));
    }
    return newShares;
  }

  proactiveRefresh(
    shareIndex: number,
    secretShare: bigint
  ): RefreshShareMessage {
    const delta = randomScalar(this.fieldOrder);
    return {
      participantId: `p-${shareIndex}`,
      policyId: generateId(),
      encryptedRefresh: JSON.stringify({
        delta: delta.toString(16),
        newShare: mod(secretShare + delta, this.fieldOrder).toString(16),
      }),
      timestamp: Date.now(),
    };
  }

  static createCeremonyState(
    policyId: string,
    threshold: number,
    participants: string[]
  ): KeyCeremonyState {
    return {
      policyId,
      phase: "round1" as KeyCeremonyPhase,
      participants,
      threshold,
      round1Complete: [],
      round2Complete: [],
      startedAt: Date.now(),
    };
  }

  static advanceCeremony(state: KeyCeremonyState): KeyCeremonyState {
    switch (state.phase) {
      case "round1":
        if (state.round1Complete.length >= state.threshold) {
          return { ...state, phase: "round2" };
        }
        return state;
      case "round2":
        if (state.round2Complete.length >= state.threshold) {
          return {
            ...state,
            phase: "finalization",
            publicKey: `0x${generateId()}${generateId()}`,
          };
        }
        return state;
      case "finalization":
        return { ...state, phase: "complete" };
      default:
        return state;
    }
  }

  static generateMockPublicKey(sigType: SignatureType, chain: ChainType): string {
    const prefix = chain === "bitcoin" ? "bc1q" : "0x";
    if (sigType === "ecdsa") {
      return prefix + generateId() + generateId();
    }
    return prefix + generateId() + generateId() + generateId();
  }
}
