import { generateId } from "./utils";
import type { AuditEntry } from "@/types";

export class AuditLogger {
  private entries: AuditEntry[] = [];
  private listeners: ((entry: AuditEntry) => void)[] = [];

  log(
    action: string,
    actor: string,
    target: string,
    details: string,
    severity: AuditEntry["severity"] = "info"
  ): AuditEntry {
    const entry: AuditEntry = {
      id: generateId(),
      action,
      actor,
      target,
      timestamp: Date.now(),
      details,
      severity,
    };
    this.entries.push(entry);
    this.listeners.forEach((fn) => fn(entry));
    return entry;
  }

  getEntries(filter?: {
    action?: string;
    actor?: string;
    severity?: AuditEntry["severity"];
    since?: number;
    limit?: number;
  }): AuditEntry[] {
    let result = [...this.entries];

    if (filter?.action) {
      result = result.filter((e) => e.action === filter.action);
    }
    if (filter?.actor) {
      result = result.filter((e) => e.actor === filter.actor);
    }
    if (filter?.severity) {
      result = result.filter((e) => e.severity === filter.severity);
    }
    if (filter?.since) {
      result = result.filter((e) => e.timestamp >= filter.since!);
    }

    result.sort((a, b) => b.timestamp - a.timestamp);

    if (filter?.limit) {
      result = result.slice(0, filter.limit);
    }

    return result;
  }

  getEntryCount(): number {
    return this.entries.length;
  }

  clear(): void {
    this.entries = [];
  }

  subscribe(fn: (entry: AuditEntry) => void): () => void {
    this.listeners.push(fn);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== fn);
    };
  }

  exportJSON(): string {
    return JSON.stringify(this.entries, null, 2);
  }

  static generateMockEntries(): AuditEntry[] {
    const now = Date.now();
    return [
      {
        id: generateId(),
        action: "transaction.initiated",
        actor: "Bob Martinez",
        target: "tx-1",
        timestamp: now - 1800000,
        details: "Initiated 10.5 ETH transfer",
        severity: "info",
      },
      {
        id: generateId(),
        action: "transaction.approved",
        actor: "Alice Chen",
        target: "tx-1",
        timestamp: now - 1500000,
        details: "Approved transaction (1/3 signatures)",
        severity: "info",
      },
      {
        id: generateId(),
        action: "key.ceremony.started",
        actor: "Alice Chen",
        target: "pol-1",
        timestamp: now - 86400000,
        details: "DKG ceremony started for 3-of-5 threshold",
        severity: "info",
      },
      {
        id: generateId(),
        action: "key.ceremony.completed",
        actor: "System",
        target: "pol-1",
        timestamp: now - 86400000 + 300000,
        details: "DKG ceremony completed. Public key generated.",
        severity: "info",
      },
      {
        id: generateId(),
        action: "transaction.completed",
        actor: "System",
        target: "tx-2",
        timestamp: now - 72000000,
        details: "Transaction executed. TxHash: 0x1234...abcdef",
        severity: "info",
      },
      {
        id: generateId(),
        action: "share.refresh",
        actor: "System",
        target: "pol-1",
        timestamp: now - 43200000,
        details: "Proactive secret share refresh completed for all participants",
        severity: "info",
      },
      {
        id: generateId(),
        action: "policy.created",
        actor: "Alice Chen",
        target: "pol-2",
        timestamp: now - 60 * 24 * 3600 * 1000,
        details: "Created 2-of-3 threshold policy for BTC Reserve",
        severity: "info",
      },
      {
        id: generateId(),
        action: "participant.joined",
        actor: "David Kim",
        target: "pol-1",
        timestamp: now - 30 * 24 * 3600 * 1000,
        details: "New signer joined Main Treasury policy",
        severity: "info",
      },
      {
        id: generateId(),
        action: "recovery.attempt",
        actor: "System",
        target: "pol-3",
        timestamp: now - 7200000,
        details: "Social recovery triggered by guardian threshold",
        severity: "warning",
      },
      {
        id: generateId(),
        action: "transaction.cancelled",
        actor: "Alice Chen",
        target: "tx-4",
        timestamp: now - 172800000,
        details: "Transaction cancelled by admin after risk review",
        severity: "warning",
      },
      {
        id: generateId(),
        action: "hsm.connection_failed",
        actor: "System",
        target: "p-3",
        timestamp: now - 3600000,
        details: "HSM connection failed for Carol Williams",
        severity: "critical",
      },
    ];
  }
}
