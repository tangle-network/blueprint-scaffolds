export const currency = (value: number) =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0
  }).format(value);

export const amount = (value: number, symbol: string) =>
  `${new Intl.NumberFormat("en-US", {
    maximumFractionDigits: 4
  }).format(value)} ${symbol}`;

export const prettyDate = (value: string) =>
  new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit"
  }).format(new Date(value));
