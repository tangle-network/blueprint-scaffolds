export type SignatureType = "ecdsa" | "eddsa";

export type ChainType = "ethereum" | "bitcoin" | "solana";

export type TransactionStatus =
  | "pending"
  | "awaiting_approvals"
  | "approved"
  | "executing"
  | "completed"
  | "failed"
  | "cancelled"
  | "timelocked";

export type ParticipantStatus = "online" | "offline" | "busy";

export type KeyCeremonyPhase =
  | "idle"
  | "round1"
  | "round2"
  | "finalization"
  | "complete"
  | "failed";

export interface Participant {
  id: string;
  name: string;
  address: string;
  status: ParticipantStatus;
  role: "admin" | "signer" | "observer";
  joinedAt: number;
  lastActive: number;
  avatarUrl?: string;
  hsmEnabled: boolean;
}

export interface ThresholdPolicy {
  id: string;
  name: string;
  threshold: number;
  totalParticipants: number;
  chainType: ChainType;
  signatureType: SignatureType;
  createdAt: number;
  isActive: boolean;
}

export interface KeyShare {
  participantId: string;
  policyId: string;
  publicKey: string;
  shareIndex: number;
  encryptedShare: string;
  createdAt: number;
}

export interface Transaction {
  id: string;
  policyId: string;
  from: string;
  to: string;
  amount: string;
  token: string;
  chain: ChainType;
  status: TransactionStatus;
  approvals: string[];
  requiredApprovals: number;
  initiatorId: string;
  createdAt: number;
  executeAfter?: number;
  completedAt?: number;
  txHash?: string;
  metadata?: Record<string, string>;
}

export interface AuditEntry {
  id: string;
  action: string;
  actor: string;
  target: string;
  timestamp: number;
  details: string;
  severity: "info" | "warning" | "critical";
}

export interface KeyCeremonyState {
  policyId: string;
  phase: KeyCeremonyPhase;
  participants: string[];
  threshold: number;
  round1Complete: string[];
  round2Complete: string[];
  publicKey?: string;
  startedAt: number;
}

export interface SigningRequest {
  id: string;
  transactionId: string;
  participantId: string;
  partialSignature: string;
  createdAt: number;
}

export interface VaultBalance {
  chain: ChainType;
  token: string;
  symbol: string;
  amount: string;
  usdValue: number;
  address: string;
}

export interface WebhookConfig {
  id: string;
  url: string;
  events: string[];
  isActive: boolean;
  createdAt: number;
}

export interface DKGMessage {
  from: string;
  to: string;
  round: 1 | 2;
  payload: string;
  timestamp: number;
}

export interface RefreshShareMessage {
  participantId: string;
  policyId: string;
  encryptedRefresh: string;
  timestamp: number;
}

export interface SocialRecoveryConfig {
  guardians: string[];
  recoveryThreshold: number;
  delayMs: number;
  isActive: boolean;
}
