import { useCustodyStore } from "@/store";
import { formatUSD, formatDate, formatAddress } from "@/lib/utils";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Wallet,
  ArrowLeftRight,
  Users,
  Shield,
  TrendingUp,
  Clock,
  AlertTriangle,
} from "lucide-react";

function StatCard({
  title,
  value,
  subtitle,
  icon: Icon,
}: {
  title: string;
  value: string;
  subtitle: string;
  icon: React.ElementType;
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground">{subtitle}</p>
      </CardContent>
    </Card>
  );
}

function BalanceTable({ balances }: { balances: import("@/types").VaultBalance[] }) {
  const totalUsd = balances.reduce((sum, b) => sum + b.usdValue, 0);
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Wallet className="h-5 w-5" />
          Vault Balances
        </CardTitle>
        <CardDescription>
          Total: {formatUSD(totalUsd)}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {balances.map((b, i) => (
            <div
              key={i}
              className="flex items-center justify-between p-3 rounded-lg border"
            >
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="text-sm font-bold">{b.symbol.slice(0, 2)}</span>
                </div>
                <div>
                  <p className="font-medium">{b.token}</p>
                  <p className="text-xs text-muted-foreground">
                    {b.chain.charAt(0).toUpperCase() + b.chain.slice(1)} &middot;{" "}
                    {formatAddress(b.address)}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-medium">
                  {b.amount} {b.symbol}
                </p>
                <p className="text-sm text-muted-foreground">
                  {formatUSD(b.usdValue)}
                </p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function PendingTxCard({
  transactions,
}: {
  transactions: import("@/types").Transaction[];
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="h-5 w-5" />
          Pending Approvals
        </CardTitle>
        <CardDescription>{transactions.length} awaiting action</CardDescription>
      </CardHeader>
      <CardContent>
        {transactions.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-6">
            No pending transactions
          </p>
        ) : (
          <div className="space-y-3">
            {transactions.map((tx) => (
              <div key={tx.id} className="p-3 rounded-lg border space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-medium">
                    {tx.amount} {tx.token}
                  </span>
                  <Badge
                    variant={
                      tx.status === "timelocked" ? "warning" : "secondary"
                    }
                  >
                    {tx.status === "timelocked" ? "Time-locked" : "Awaiting"}
                  </Badge>
                </div>
                <div className="text-xs text-muted-foreground">
                  To: {formatAddress(tx.to)}
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span>Approvals</span>
                    <span>
                      {tx.approvals.length}/{tx.requiredApprovals}
                    </span>
                  </div>
                  <Progress
                    value={(tx.approvals.length / tx.requiredApprovals) * 100}
                    className="h-2"
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  {formatDate(tx.createdAt)}
                </p>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function PolicyCard({ policies }: { policies: import("@/types").ThresholdPolicy[] }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5" />
          Active Policies
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {policies.map((p) => (
            <div key={p.id} className="p-3 rounded-lg border">
              <div className="flex justify-between items-center">
                <span className="font-medium">{p.name}</span>
                <Badge variant={p.isActive ? "success" : "secondary"}>
                  {p.isActive ? "Active" : "Inactive"}
                </Badge>
              </div>
              <div className="mt-2 flex items-center gap-4 text-sm text-muted-foreground">
                <span>
                  {p.threshold}-of-{p.totalParticipants}
                </span>
                <span>{p.chainType.toUpperCase()}</span>
                <span>{p.signatureType.toUpperCase()}</span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

export default function Dashboard() {
  const balances = useCustodyStore((s) => s.balances);
  const transactions = useCustodyStore((s) => s.transactions);
  const policies = useCustodyStore((s) => s.policies);
  const participants = useCustodyStore((s) => s.participants);

  const totalUsd = balances.reduce((sum, b) => sum + b.usdValue, 0);
  const pendingTxs = transactions.filter(
    (t) =>
      t.status === "awaiting_approvals" ||
      t.status === "pending" ||
      t.status === "timelocked"
  );
  const onlineCount = participants.filter(
    (p) => p.status === "online"
  ).length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Custody Dashboard</h1>
        <p className="text-muted-foreground">
          Multi-party threshold signature custody overview
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Vault Value"
          value={formatUSD(totalUsd)}
          subtitle={`${balances.length} assets across ${new Set(balances.map((b) => b.chain)).size} chains`}
          icon={TrendingUp}
        />
        <StatCard
          title="Pending Transactions"
          value={String(pendingTxs.length)}
          subtitle="Awaiting approvals"
          icon={ArrowLeftRight}
        />
        <StatCard
          title="Active Policies"
          value={String(policies.filter((p) => p.isActive).length)}
          subtitle={`${policies.length} total policies`}
          icon={Shield}
        />
        <StatCard
          title="Online Participants"
          value={`${onlineCount}/${participants.length}`}
          subtitle={
            participants.some((p) => p.status === "busy")
              ? "Some participants busy"
              : "All available"
          }
          icon={Users}
        />
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <BalanceTable balances={balances} />
        <div className="space-y-6">
          <PendingTxCard transactions={pendingTxs} />
          <PolicyCard policies={policies} />
        </div>
      </div>
    </div>
  );
}
