import { useCustodyStore } from "@/store";
import { formatDate } from "@/lib/utils";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ScrollText, Download, AlertTriangle, Info, AlertCircle } from "lucide-react";
import { useState } from "react";
import type { AuditEntry } from "@/types";

const severityIcon: Record<string, React.ElementType> = {
  info: Info,
  warning: AlertTriangle,
  critical: AlertCircle,
};

const severityColor: Record<string, string> = {
  info: "text-blue-500",
  warning: "text-yellow-500",
  critical: "text-red-500",
};

const severityBadge: Record<string, "default" | "secondary" | "warning" | "destructive"> = {
  info: "secondary",
  warning: "warning",
  critical: "destructive",
};

export default function AuditTrail() {
  const auditEntries = useCustodyStore((s) => s.auditEntries);
  const [filterSeverity, setFilterSeverity] = useState<string>("all");
  const [search, setSearch] = useState("");

  const filtered = auditEntries.filter((e) => {
    if (filterSeverity !== "all" && e.severity !== filterSeverity) return false;
    if (
      search &&
      !e.action.toLowerCase().includes(search.toLowerCase()) &&
      !e.actor.toLowerCase().includes(search.toLowerCase()) &&
      !e.details.toLowerCase().includes(search.toLowerCase())
    )
      return false;
    return true;
  });

  const exportAudit = () => {
    const data = JSON.stringify(filtered, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `audit-trail-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Audit Trail</h1>
          <p className="text-muted-foreground">
            Complete history of custody operations
          </p>
        </div>
        <Button variant="outline" onClick={exportAudit}>
          <Download className="h-4 w-4 mr-2" />
          Export JSON
        </Button>
      </div>

      <div className="flex items-center gap-3">
        <Input
          placeholder="Search actions, actors, details..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="max-w-sm"
        />
        <Select value={filterSeverity} onValueChange={setFilterSeverity}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Severity" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Levels</SelectItem>
            <SelectItem value="info">Info</SelectItem>
            <SelectItem value="warning">Warning</SelectItem>
            <SelectItem value="critical">Critical</SelectItem>
          </SelectContent>
        </Select>
        <span className="text-sm text-muted-foreground">
          {filtered.length} entries
        </span>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ScrollText className="h-5 w-5" />
            Event Log
          </CardTitle>
          <CardDescription>
            {filtered.length} events recorded
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {filtered.map((entry) => {
              const Icon = severityIcon[entry.severity] || Info;
              return (
                <div
                  key={entry.id}
                  className="flex items-start gap-3 p-3 rounded-lg border"
                >
                  <Icon
                    className={`h-4 w-4 mt-0.5 ${severityColor[entry.severity]}`}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm">{entry.action}</span>
                      <Badge variant={severityBadge[entry.severity]}>
                        {entry.severity}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      {entry.details}
                    </p>
                    <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                      <span>Actor: {entry.actor}</span>
                      <span>Target: {entry.target}</span>
                      <span>{formatDate(entry.timestamp)}</span>
                    </div>
                  </div>
                </div>
              );
            })}
            {filtered.length === 0 && (
              <p className="text-center py-8 text-muted-foreground">
                No audit entries found
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
