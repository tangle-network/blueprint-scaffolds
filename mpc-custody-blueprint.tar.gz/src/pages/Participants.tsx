import { useCustodyStore } from "@/store";
import { formatDate, formatAddress } from "@/lib/utils";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Users, Plus, Shield, UserCheck, Eye } from "lucide-react";
import { useState } from "react";
import type { Participant, ParticipantStatus } from "@/types";

const statusColor: Record<ParticipantStatus, string> = {
  online: "bg-green-500",
  offline: "bg-gray-400",
  busy: "bg-yellow-500",
};

const roleVariant: Record<string, "default" | "secondary" | "outline"> = {
  admin: "default",
  signer: "secondary",
  observer: "outline",
};

function ParticipantCard({ participant }: { participant: Participant }) {
  const initials = participant.name
    .split(" ")
    .map((n) => n[0])
    .join("");

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="relative">
            <Avatar>
              <AvatarFallback>{initials}</AvatarFallback>
            </Avatar>
            <span
              className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-background ${statusColor[participant.status]}`}
            />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <p className="font-medium text-sm">{participant.name}</p>
              <Badge variant={roleVariant[participant.role]}>
                {participant.role}
              </Badge>
            </div>
            <p className="text-xs font-mono text-muted-foreground mt-1">
              {formatAddress(participant.address)}
            </p>
            <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
              <span className="capitalize">{participant.status}</span>
              <span>Last active: {formatDate(participant.lastActive)}</span>
            </div>
            {participant.hsmEnabled && (
              <Badge variant="outline" className="mt-2 text-xs">
                <Shield className="h-3 w-3 mr-1" />
                HSM
              </Badge>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Participants() {
  const participants = useCustodyStore((s) => s.participants);
  const addParticipant = useCustodyStore((s) => s.addParticipant);
  const removeParticipant = useCustodyStore((s) => s.removeParticipant);
  const updateParticipantStatus = useCustodyStore(
    (s) => s.updateParticipantStatus
  );
  const [addOpen, setAddOpen] = useState(false);
  const [form, setForm] = useState({
    name: "",
    address: "",
    role: "signer" as "admin" | "signer" | "observer",
  });

  const handleAdd = () => {
    if (!form.name || !form.address) return;
    const p: Participant = {
      id: `p-${Date.now()}`,
      name: form.name,
      address: form.address,
      status: "online",
      role: form.role,
      joinedAt: Date.now(),
      lastActive: Date.now(),
      hsmEnabled: false,
    };
    addParticipant(p);
    setAddOpen(false);
    setForm({ name: "", address: "", role: "signer" });
  };

  const online = participants.filter((p) => p.status === "online").length;
  const admins = participants.filter((p) => p.role === "admin").length;
  const signers = participants.filter((p) => p.role === "signer").length;
  const observers = participants.filter((p) => p.role === "observer").length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Participants</h1>
          <p className="text-muted-foreground">
            Manage custody key holders and signers
          </p>
        </div>
        <Button onClick={() => setAddOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Participant
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <Users className="h-5 w-5 text-muted-foreground" />
            <div>
              <p className="text-2xl font-bold">{participants.length}</p>
              <p className="text-xs text-muted-foreground">Total</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="h-3 w-3 rounded-full bg-green-500" />
            <div>
              <p className="text-2xl font-bold">{online}</p>
              <p className="text-xs text-muted-foreground">Online</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <Shield className="h-5 w-5 text-muted-foreground" />
            <div>
              <p className="text-2xl font-bold">{admins}</p>
              <p className="text-xs text-muted-foreground">Admins</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <UserCheck className="h-5 w-5 text-muted-foreground" />
            <div>
              <p className="text-2xl font-bold">{signers + observers}</p>
              <p className="text-xs text-muted-foreground">Signers & Observers</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {participants.map((p) => (
          <ParticipantCard key={p.id} participant={p} />
        ))}
      </div>

      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Participant</DialogTitle>
            <DialogDescription>
              Add a new participant to the custody group
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Name</Label>
              <Input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Full name"
              />
            </div>
            <div>
              <Label>Address</Label>
              <Input
                value={form.address}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
                placeholder="0x..."
              />
            </div>
            <div>
              <Label>Role</Label>
              <Select
                value={form.role}
                onValueChange={(v) =>
                  setForm({
                    ...form,
                    role: v as "admin" | "signer" | "observer",
                  })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="signer">Signer</SelectItem>
                  <SelectItem value="observer">Observer</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAdd}>Add Participant</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
