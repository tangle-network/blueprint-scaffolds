import { useCustodyStore } from "@/store";
import { FROSTThreshold } from "@/lib/frost";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  KeyRound,
  Play,
  CheckCircle,
  Loader2,
  AlertCircle,
  RefreshCw,
} from "lucide-react";
import { useState } from "react";
import type { KeyCeremonyState, KeyCeremonyPhase, SignatureType, ChainType } from "@/types";

const phaseSteps: KeyCeremonyPhase[] = [
  "idle",
  "round1",
  "round2",
  "finalization",
  "complete",
];

const phaseLabels: Record<KeyCeremonyPhase, string> = {
  idle: "Not Started",
  round1: "Round 1 - Commitments",
  round2: "Round 2 - Share Exchange",
  finalization: "Finalization",
  complete: "Complete",
  failed: "Failed",
};

function CeremonyProgress({ phase }: { phase: KeyCeremonyPhase }) {
  const idx = phaseSteps.indexOf(phase);
  const failed = phase === "failed";
  const pct =
    phase === "complete"
      ? 100
      : phase === "failed"
        ? 0
        : Math.round(((idx + 0.5) / phaseSteps.length) * 100);

  return (
    <div className="space-y-2">
      <div className="flex justify-between text-sm">
        <span>{failed ? "Ceremony Failed" : phaseLabels[phase]}</span>
        <span>{pct}%</span>
      </div>
      <Progress value={pct} className="h-3" />
      <div className="flex justify-between">
        {phaseSteps.slice(1).map((p) => (
          <div
            key={p}
            className={`flex items-center gap-1 text-xs ${
              phaseSteps.indexOf(phase) >= phaseSteps.indexOf(p)
                ? "text-primary font-medium"
                : "text-muted-foreground"
            }`}
          >
            {phaseSteps.indexOf(phase) > phaseSteps.indexOf(p) ? (
              <CheckCircle className="h-3 w-3" />
            ) : (
              <span className="h-3 w-3 rounded-full border" />
            )}
            {phaseLabels[p].split(" - ")[0]}
          </div>
        ))}
      </div>
    </div>
  );
}

export default function KeyCeremony() {
  const participants = useCustodyStore((s) => s.participants);
  const policies = useCustodyStore((s) => s.policies);
  const setCeremony = useCustodyStore((s) => s.setCeremony);
  const ceremony = useCustodyStore((s) => s.ceremony);

  const [form, setForm] = useState({
    threshold: 3,
    totalParticipants: 5,
    chainType: "ethereum" as ChainType,
    signatureType: "ecdsa" as SignatureType,
    name: "",
  });
  const [refreshing, setRefreshing] = useState(false);

  const startCeremony = () => {
    const ids = participants
      .slice(0, form.totalParticipants)
      .map((p) => p.id);
    const state = FROSTThreshold.createCeremonyState(
      `ceremony-${Date.now()}`,
      form.threshold,
      ids
    );
    setCeremony(state);
  };

  const advanceCeremony = () => {
    if (!ceremony) return;
    const current = ceremony;
    let updated = { ...current };

    if (current.phase === "round1") {
      updated = {
        ...updated,
        round1Complete: current.participants.slice(0, current.threshold),
      };
    } else if (current.phase === "round2") {
      updated = {
        ...updated,
        round2Complete: current.participants.slice(0, current.threshold),
      };
    }

    updated = FROSTThreshold.advanceCeremony(updated);
    setCeremony(updated);
  };

  const handleRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Key Ceremony</h1>
        <p className="text-muted-foreground">
          Distributed key generation and management for threshold policies
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <KeyRound className="h-5 w-5" />
              New DKG Ceremony
            </CardTitle>
            <CardDescription>
              Configure and start a distributed key generation ceremony
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Policy Name</Label>
              <Input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="e.g., Main Treasury"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Threshold (t)</Label>
                <Input
                  type="number"
                  value={form.threshold}
                  onChange={(e) =>
                    setForm({ ...form, threshold: parseInt(e.target.value) || 1 })
                  }
                  min={1}
                />
              </div>
              <div>
                <Label>Total Participants (n)</Label>
                <Input
                  type="number"
                  value={form.totalParticipants}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      totalParticipants: parseInt(e.target.value) || 1,
                    })
                  }
                  min={1}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Chain</Label>
                <Select
                  value={form.chainType}
                  onValueChange={(v) =>
                    setForm({ ...form, chainType: v as ChainType })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ethereum">Ethereum</SelectItem>
                    <SelectItem value="bitcoin">Bitcoin</SelectItem>
                    <SelectItem value="solana">Solana</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Signature Type</Label>
                <Select
                  value={form.signatureType}
                  onValueChange={(v) =>
                    setForm({ ...form, signatureType: v as SignatureType })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ecdsa">ECDSA (secp256k1)</SelectItem>
                    <SelectItem value="eddsa">EdDSA (Ed25519)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="p-3 rounded-lg bg-muted text-sm">
              <p className="font-medium">
                {form.threshold}-of-{form.totalParticipants} Threshold
              </p>
              <p className="text-muted-foreground text-xs mt-1">
                Requires {form.threshold} participants to sign. Up to{" "}
                {form.totalParticipants - form.threshold} can be offline or
                compromised.
              </p>
            </div>
            <Button
              className="w-full"
              onClick={startCeremony}
              disabled={ceremony?.phase !== "idle" && ceremony?.phase !== "complete" && ceremony !== null}
            >
              <Play className="h-4 w-4 mr-2" />
              {ceremony ? "Restart Ceremony" : "Start Ceremony"}
            </Button>
          </CardContent>
        </Card>

        {ceremony && (
          <Card>
            <CardHeader>
              <CardTitle>Ceremony Progress</CardTitle>
              <CardDescription>
                Policy: {ceremony.policyId}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <CeremonyProgress phase={ceremony.phase} />

              <Separator />

              <div>
                <h4 className="text-sm font-medium mb-2">Participants</h4>
                <div className="flex flex-wrap gap-2">
                  {ceremony.participants.map((pid) => {
                    const p = participants.find((x) => x.id === pid);
                    const r1Done = ceremony.round1Complete.includes(pid);
                    const r2Done = ceremony.round2Complete.includes(pid);
                    return (
                      <div
                        key={pid}
                        className="flex items-center gap-1 text-xs px-2 py-1 rounded border"
                      >
                        <span>{p?.name || pid}</span>
                        {r1Done && (
                          <CheckCircle className="h-3 w-3 text-green-500" />
                        )}
                        {r2Done && (
                          <CheckCircle className="h-3 w-3 text-blue-500" />
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {ceremony.publicKey && (
                <div>
                  <h4 className="text-sm font-medium mb-1">Public Key</h4>
                  <p className="text-xs font-mono bg-muted p-2 rounded break-all">
                    {ceremony.publicKey}
                  </p>
                </div>
              )}

              {ceremony.phase !== "complete" && ceremony.phase !== "failed" && (
                <Button onClick={advanceCeremony} className="w-full">
                  <Loader2 className="h-4 w-4 mr-2" />
                  Advance Ceremony
                </Button>
              )}

              {ceremony.phase === "complete" && (
                <div className="flex items-center gap-2 p-3 rounded-lg bg-green-50 text-green-700">
                  <CheckCircle className="h-5 w-5" />
                  <span className="font-medium">
                    Key ceremony completed successfully
                  </span>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <RefreshCw className="h-5 w-5" />
            Proactive Secret Sharing
          </CardTitle>
          <CardDescription>
            Periodically refresh shares without changing the public key
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <p className="text-sm text-muted-foreground flex-1">
              Last refresh: Never &middot; Recommended interval: 24 hours
            </p>
            <Button
              variant="outline"
              onClick={handleRefresh}
              disabled={refreshing}
            >
              {refreshing ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4 mr-2" />
              )}
              Refresh Shares
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
