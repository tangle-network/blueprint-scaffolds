import { useCustodyStore } from "@/store";
import { formatAddress, formatDate, formatUSD } from "@/lib/utils";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import {
  Plus,
  Check,
  X,
  Clock,
  ExternalLink,
  ArrowLeftRight,
  Play,
} from "lucide-react";
import { useState } from "react";
import type { Transaction, ChainType } from "@/types";

const statusVariant: Record<string, "default" | "secondary" | "success" | "warning" | "destructive"> = {
  pending: "secondary",
  awaiting_approvals: "default",
  approved: "default",
  executing: "warning",
  completed: "success",
  failed: "destructive",
  cancelled: "secondary",
  timelocked: "warning",
};

function StatusBadge({ status }: { status: string }) {
  return <Badge variant={statusVariant[status] || "secondary"}>{status.replace("_", " ")}</Badge>;
}

function TxDetailDialog({
  tx,
  open,
  onClose,
}: {
  tx: Transaction | null;
  open: boolean;
  onClose: () => void;
}) {
  const participants = useCustodyStore((s) => s.participants);
  const approveTransaction = useCustodyStore((s) => s.approveTransaction);
  const cancelTransaction = useCustodyStore((s) => s.cancelTransaction);
  const executeTransaction = useCustodyStore((s) => s.executeTransaction);

  if (!tx) return null;

  const canApprove = !["completed", "cancelled", "failed"].includes(tx.status);
  const canCancel = !["completed", "executing", "failed"].includes(tx.status);
  const canExecute = tx.status === "executing" || tx.status === "approved";

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ArrowLeftRight className="h-5 w-5" />
            Transaction Details
          </DialogTitle>
          <DialogDescription>
            {formatDate(tx.createdAt)}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <p className="text-muted-foreground">Status</p>
              <StatusBadge status={tx.status} />
            </div>
            <div>
              <p className="text-muted-foreground">Chain</p>
              <p className="font-medium">{tx.chain.toUpperCase()}</p>
            </div>
            <div>
              <p className="text-muted-foreground">From</p>
              <p className="font-mono text-xs">{formatAddress(tx.from)}</p>
            </div>
            <div>
              <p className="text-muted-foreground">To</p>
              <p className="font-mono text-xs">{formatAddress(tx.to)}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Amount</p>
              <p className="font-medium">
                {tx.amount} {tx.token}
              </p>
            </div>
            <div>
              <p className="text-muted-foreground">Policy</p>
              <p className="font-medium">{tx.policyId}</p>
            </div>
          </div>

          {tx.txHash && (
            <div className="text-sm">
              <p className="text-muted-foreground">Tx Hash</p>
              <p className="font-mono text-xs break-all">{tx.txHash}</p>
            </div>
          )}

          {tx.executeAfter && (
            <div className="text-sm">
              <p className="text-muted-foreground">Execute After</p>
              <p className="font-medium flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {formatDate(tx.executeAfter)}
              </p>
            </div>
          )}

          <Separator />

          <div>
            <div className="flex justify-between text-sm mb-2">
              <span>Approvals</span>
              <span>
                {tx.approvals.length}/{tx.requiredApprovals}
              </span>
            </div>
            <Progress
              value={(tx.approvals.length / tx.requiredApprovals) * 100}
              className="h-2 mb-3"
            />
            <div className="space-y-1">
              {tx.approvals.map((aid) => {
                const p = participants.find((x) => x.id === aid);
                return (
                  <div
                    key={aid}
                    className="flex items-center gap-2 text-sm"
                  >
                    <Check className="h-3 w-3 text-green-500" />
                    <span>{p?.name || aid}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
        <DialogFooter className="gap-2">
          {canApprove && (
            <Button
              onClick={() => {
                approveTransaction(tx.id, "p-1");
              }}
              size="sm"
            >
              <Check className="h-4 w-4 mr-1" />
              Approve
            </Button>
          )}
          {canExecute && (
            <Button
              onClick={() => executeTransaction(tx.id)}
              size="sm"
              variant="secondary"
            >
              <Play className="h-4 w-4 mr-1" />
              Execute
            </Button>
          )}
          {canCancel && (
            <Button
              onClick={() => cancelTransaction(tx.id)}
              size="sm"
              variant="destructive"
            >
              <X className="h-4 w-4 mr-1" />
              Cancel
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function Transactions() {
  const transactions = useCustodyStore((s) => s.transactions);
  const policies = useCustodyStore((s) => s.policies);
  const balances = useCustodyStore((s) => s.balances);
  const addTransaction = useCustodyStore((s) => s.addTransaction);
  const setSelectedTxId = useCustodyStore((s) => s.setSelectedTxId);
  const [newDialog, setNewDialog] = useState(false);
  const [detailTx, setDetailTx] = useState<Transaction | null>(null);
  const [form, setForm] = useState({
    to: "",
    amount: "",
    token: "ETH",
    chain: "ethereum" as ChainType,
    policyId: "",
    timelock: "",
  });

  const handleSubmit = () => {
    if (!form.to || !form.amount || !form.policyId) return;
    const policy = policies.find((p) => p.id === form.policyId);
    if (!policy) return;
    const balance = balances.find(
      (b) => b.chain === form.chain && b.symbol === form.token
    );
    const tx: Transaction = {
      id: `tx-${Date.now()}`,
      policyId: form.policyId,
      from: balance?.address || "0x0000",
      to: form.to,
      amount: form.amount,
      token: form.token,
      chain: form.chain,
      status: form.timelock ? "timelocked" : "awaiting_approvals",
      approvals: [],
      requiredApprovals: policy.threshold,
      initiatorId: "p-1",
      createdAt: Date.now(),
      executeAfter: form.timelock
        ? Date.now() + parseInt(form.timelock) * 3600000
        : undefined,
    };
    addTransaction(tx);
    setNewDialog(false);
    setForm({
      to: "",
      amount: "",
      token: "ETH",
      chain: "ethereum",
      policyId: "",
      timelock: "",
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Transactions</h1>
          <p className="text-muted-foreground">
            Initiate and approve custody transactions
          </p>
        </div>
        <Button onClick={() => setNewDialog(true)}>
          <Plus className="h-4 w-4 mr-2" />
          New Transaction
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Transaction History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {transactions.map((tx) => (
              <div
                key={tx.id}
                className="flex items-center justify-between p-3 rounded-lg border cursor-pointer hover:bg-accent/50 transition-colors"
                onClick={() => setDetailTx(tx)}
              >
                <div className="flex items-center gap-3">
                  <ArrowLeftRight className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="font-medium text-sm">
                      {tx.amount} {tx.token}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {formatAddress(tx.from)} &rarr; {formatAddress(tx.to)}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xs text-muted-foreground">
                    {formatDate(tx.createdAt)}
                  </span>
                  <StatusBadge status={tx.status} />
                  <div className="text-xs text-muted-foreground w-16 text-right">
                    {tx.approvals.length}/{tx.requiredApprovals}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Dialog open={newDialog} onOpenChange={setNewDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>New Transaction</DialogTitle>
            <DialogDescription>
              Initiate a new custody transaction
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Policy</Label>
              <Select
                value={form.policyId}
                onValueChange={(v) => {
                  const pol = policies.find((p) => p.id === v);
                  setForm({
                    ...form,
                    policyId: v,
                    chain: pol?.chainType || "ethereum",
                    token: pol?.chainType === "bitcoin" ? "BTC" : pol?.chainType === "solana" ? "SOL" : "ETH",
                  });
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select policy" />
                </SelectTrigger>
                <SelectContent>
                  {policies
                    .filter((p) => p.isActive)
                    .map((p) => (
                      <SelectItem key={p.id} value={p.id}>
                        {p.name} ({p.threshold}-of-{p.totalParticipants})
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Recipient Address</Label>
              <Input
                value={form.to}
                onChange={(e) => setForm({ ...form, to: e.target.value })}
                placeholder="0x..."
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Amount</Label>
                <Input
                  value={form.amount}
                  onChange={(e) => setForm({ ...form, amount: e.target.value })}
                  placeholder="0.00"
                  type="number"
                />
              </div>
              <div>
                <Label>Token</Label>
                <Input value={form.token} disabled />
              </div>
            </div>
            <div>
              <Label>Time-lock (hours, optional)</Label>
              <Input
                value={form.timelock}
                onChange={(e) => setForm({ ...form, timelock: e.target.value })}
                placeholder="Leave empty for immediate"
                type="number"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setNewDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleSubmit}>Submit Transaction</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <TxDetailDialog
        tx={detailTx}
        open={!!detailTx}
        onClose={() => setDetailTx(null)}
      />
    </div>
  );
}
