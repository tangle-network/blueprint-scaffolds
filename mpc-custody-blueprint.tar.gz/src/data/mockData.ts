import {
  approveSigningRequest,
  buildPolicy,
  createSigningDigest,
  instantiateCeremony
} from "../lib/mpc";
import type { CustodySnapshot, Participant, SigningRequest } from "../lib/types";

const participants: Participant[] = [
  { id: "p1", name: "North America Ops", role: "signer", region: "Virginia", deviceTrust: "hsm", online: true },
  { id: "p2", name: "Europe Treasury", role: "signer", region: "Frankfurt", deviceTrust: "hsm", online: true },
  { id: "p3", name: "APAC Security", role: "signer", region: "Singapore", deviceTrust: "tee", online: true },
  { id: "p4", name: "DAO Delegate", role: "recovery", region: "Lisbon", deviceTrust: "software", online: false },
  { id: "p5", name: "Board Observer", role: "observer", region: "New York", deviceTrust: "software", online: true }
];

const policy = buildPolicy("Institutional 3-of-5", 3, 5, 12);
const ceremony = instantiateCeremony("ceremony-001", "Primary Treasury Key", "ecdsa", participants, policy);

const requestBase = (
  id: string,
  chain: SigningRequest["chain"],
  asset: string,
  amount: number,
  destination: string,
  offsetHours: number,
  status: SigningRequest["status"]
): SigningRequest => {
  const requestedAt = new Date(Date.now() - offsetHours * 3600000).toISOString();
  const executeAfter = new Date(Date.now() + Math.max(1, 12 - offsetHours) * 3600000).toISOString();
  return {
    id,
    chain,
    asset,
    amount,
    destination,
    requestedAt,
    executeAfter,
    status,
    policyName: policy.name,
    approvals: [],
    requiredApprovals: policy.threshold,
    payloadDigest: createSigningDigest(chain, destination, amount, requestedAt),
    walletConnectTopic: chain === "ethereum" ? "wc_treasury_topic" : undefined
  };
};

const req1 = requestBase("req-eth-1", "ethereum", "ETH", 182.4, "0xA11CEcafe0000000000000000000000000001234", 5, "pending");
req1.approvals = [
  approveSigningRequest(req1, participants[0]),
  approveSigningRequest(req1, participants[1])
];

const req2 = requestBase("req-btc-1", "bitcoin", "BTC", 4.52, "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh", 16, "ready");
req2.approvals = [
  approveSigningRequest(req2, participants[0]),
  approveSigningRequest(req2, participants[1]),
  approveSigningRequest(req2, participants[2])
];

const req3 = requestBase("req-sol-1", "solana", "SOL", 1250, "8xYk9vW3FQv2mNhM5VW7gR3yAHJ8DsQ4kv6j8QJLg9a", 1, "timelocked");
req3.approvals = [approveSigningRequest(req3, participants[2])];

export const mockSnapshot: CustodySnapshot = {
  balances: [
    { chain: "ethereum", symbol: "ETH", amount: 7425.43, fiatValue: 24500000, pending: 182.4 },
    { chain: "bitcoin", symbol: "BTC", amount: 128.84, fiatValue: 8600000, pending: 4.52 },
    { chain: "solana", symbol: "SOL", amount: 98124.22, fiatValue: 14200000, pending: 1250 }
  ],
  ceremony,
  requests: [req1, req2, req3],
  auditTrail: [
    {
      id: "audit-1",
      at: new Date(Date.now() - 20 * 60000).toISOString(),
      actor: "Policy Engine",
      action: "Webhook Dispatched",
      severity: "info",
      detail: "Sent approval.pending notification to treasury Slack relay"
    },
    {
      id: "audit-2",
      at: new Date(Date.now() - 90 * 60000).toISOString(),
      actor: "North America Ops",
      action: "Signature Share Submitted",
      severity: "info",
      detail: "ECDSA FROST share accepted for req-btc-1"
    },
    {
      id: "audit-3",
      at: new Date(Date.now() - 36 * 3600000).toISOString(),
      actor: "Security Service",
      action: "Proactive Refresh Completed",
      severity: "warning",
      detail: "Share refresh epoch 12 completed with zero key reconstruction"
    },
    {
      id: "audit-4",
      at: new Date(Date.now() - 72 * 3600000).toISOString(),
      actor: "Recovery Council",
      action: "Social Recovery Drill",
      severity: "critical",
      detail: "4 guardian attestations validated against delayed recovery procedure"
    }
  ],
  adapters: [
    { chain: "ethereum", signerCurve: "ecdsa", connected: true, rpc: "wss://eth-mainnet.example/rpc" },
    { chain: "bitcoin", signerCurve: "ecdsa", connected: true, rpc: "https://bitcoin-core.example/rpc" },
    { chain: "solana", signerCurve: "eddsa", connected: true, rpc: "https://solana-mainnet.example/rpc" }
  ],
  webhooks: [
    { id: "wh-1", target: "https://hooks.example.com/treasury/pending", event: "approval.pending", secretLabel: "vault/webhook/pending" },
    { id: "wh-2", target: "https://hooks.example.com/treasury/ready", event: "approval.ready", secretLabel: "vault/webhook/ready" }
  ],
  recovery: {
    quorum: 4,
    guardians: participants.filter((participant) => participant.role !== "observer"),
    timelockHours: 48
  }
};
