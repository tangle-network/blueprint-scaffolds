import { Routes, Route, NavLink } from "react-router-dom";
import { useEffect } from "react";
import { LayoutDashboard, ArrowLeftRight, Users, KeyRound, ScrollText, Shield } from "lucide-react";
import { cn } from "@/lib/utils";
import { useCustodyStore } from "@/store";
import Dashboard from "@/pages/Dashboard";
import Transactions from "@/pages/Transactions";
import Participants from "@/pages/Participants";
import KeyCeremony from "@/pages/KeyCeremony";
import AuditTrail from "@/pages/AuditTrail";

const navItems = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard },
  { to: "/transactions", label: "Transactions", icon: ArrowLeftRight },
  { to: "/participants", label: "Participants", icon: Users },
  { to: "/ceremony", label: "Key Ceremony", icon: KeyRound },
  { to: "/audit", label: "Audit Trail", icon: ScrollText },
];

export default function App() {
  const init = useCustodyStore((s) => s.init);

  useEffect(() => {
    init();
  }, [init]);

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center px-4 mx-auto">
          <div className="flex items-center gap-2 mr-8">
            <Shield className="h-6 w-6 text-primary" />
            <span className="font-bold text-lg">Tangle Custody</span>
          </div>
          <nav className="flex items-center gap-1">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === "/"}
                className={({ isActive }) =>
                  cn(
                    "flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors",
                    isActive
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                  )
                }
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </NavLink>
            ))}
          </nav>
        </div>
      </header>
      <main className="container px-4 py-6 mx-auto">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/transactions" element={<Transactions />} />
          <Route path="/participants" element={<Participants />} />
          <Route path="/ceremony" element={<KeyCeremony />} />
          <Route path="/audit" element={<AuditTrail />} />
        </Routes>
      </main>
    </div>
  );
}
