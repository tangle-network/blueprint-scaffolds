import { secp256k1 } from '@noble/curves/secp256k1';
import { ed25519 } from '@noble/curves/ed25519';
import { sha256 } from '@noble/hashes/sha256';
import { randomBytes, bytesToHex, hexToBytes } from '@noble/hashes/utils';

export type CurveType = 'secp256k1' | 'ed25519';

export interface FROSTParticipant {
  id: number;
  publicKey: string;
  shareCommitment: string[];
}

export interface FROSTKeyShare {
  participantId: number;
  secretShare: string;
  publicKey: string;
  verifyingKey: string;
  curve: CurveType;
  threshold: number;
  totalParticipants: number;
}

export interface FROSTRound1Package {
  senderId: number;
  commitments: string[];
  proofOfKnowledge: string;
}

export interface FROSTRound2Package {
  senderId: number;
  receiverId: number;
  encryptedShare: string;
}

export interface FROSTSigningCommitment {
  participantId: number;
  bindingFactor: string;
  commitment: string;
}

export interface FROSTSignatureResult {
  signature: string;
  publicKey: string;
  participants: number[];
}

const ORDER_SECP256K1 = secp256k1.CURVE.n;
const ORDER_ED25519 = ed25519.CURVE.n;

function getOrder(curve: CurveType): bigint {
  return curve === 'secp256k1' ? ORDER_SECP256K1 : ORDER_ED25519;
}

function mod(a: bigint, n: bigint): bigint {
  return ((a % n) + n) % n;
}

function generatePolynomial(threshold: number, curve: CurveType): bigint[] {
  const order = getOrder(curve);
  const coefficients: bigint[] = [];
  for (let i = 0; i < threshold; i++) {
    const rand = randomBytes(32);
    coefficients.push(mod(BigInt('0x' + bytesToHex(rand)), order));
  }
  return coefficients;
}

function evaluatePolynomial(coeffs: bigint[], x: bigint, order: bigint): bigint {
  let result = 0n;
  for (let i = coeffs.length - 1; i >= 0; i--) {
    result = mod(result * x + coeffs[i], order);
  }
  return result;
}

function modInverse(a: bigint, n: bigint): bigint {
  if (a === 0n) return 0n;
  let lm = 1n;
  let hm = 0n;
  let low = mod(a, n);
  let high = n;
  while (low > 1n) {
    const r = high / low;
    const nm = hm - lm * r;
    const news = high - low * r;
    hm = lm;
    lm = nm;
    high = low;
    low = news;
  }
  return mod(lm, n);
}

function computeLagrange(participants: number[], selfId: number, order: bigint): bigint {
  let numerator = 1n;
  let denominator = 1n;
  for (const pid of participants) {
    if (pid === selfId) continue;
    numerator = mod(numerator * BigInt(-pid), order);
    denominator = mod(denominator * BigInt(selfId - pid), order);
  }
  return mod(numerator * modInverse(denominator, order), order);
}

export class FROSTDKG {
  private curve: CurveType;
  private threshold: number;
  private totalParticipants: number;
  private coefficients: bigint[] | null = null;
  private round1Packages: Map<number, FROSTRound1Package> = new Map();
  private keyShare: FROSTKeyShare | null = null;

  constructor(curve: CurveType, threshold: number, totalParticipants: number) {
    if (threshold < 1 || threshold > totalParticipants) {
      throw new Error(`Invalid threshold ${threshold} for ${totalParticipants} participants`);
    }
    this.curve = curve;
    this.threshold = threshold;
    this.totalParticipants = totalParticipants;
  }

  init(participantId: number): void {
    this.coefficients = generatePolynomial(this.threshold, this.curve);
    const commitments: string[] = this.coefficients.map(() => bytesToHex(randomBytes(32)));
    const proofOfKnowledge = bytesToHex(sha256(
      new TextEncoder().encode(`${participantId}:${this.coefficients[0]}`)
    ));
    this.round1Packages.set(participantId, {
      senderId: participantId,
      commitments,
      proofOfKnowledge,
    });
  }

  generateRound2Packages(selfId: number): FROSTRound2Package[] {
    if (!this.coefficients) throw new Error('DKG not initialized');
    const order = getOrder(this.curve);
    const packages: FROSTRound2Package[] = [];
    for (let i = 1; i <= this.totalParticipants; i++) {
      if (i === selfId) continue;
      const share = evaluatePolynomial(this.coefficients, BigInt(i), order);
      const encryptedShare = bytesToHex(sha256(
        new TextEncoder().encode(`${selfId}:${i}:${share}`)
      ));
      packages.push({ senderId: selfId, receiverId: i, encryptedShare });
    }
    return packages;
  }

  finalize(participantId: number, receivedPackages: FROSTRound2Package[]): FROSTKeyShare {
    if (!this.coefficients) throw new Error('DKG not initialized');
    const order = getOrder(this.curve);
    const selfShare = evaluatePolynomial(this.coefficients, BigInt(participantId), order);
    const combinedShare = mod(
      receivedPackages.reduce((acc, pkg) => {
        return acc + BigInt('0x' + pkg.encryptedShare.slice(0, 16));
      }, selfShare),
      order
    );
    const shareHex = combinedShare.toString(16).padStart(64, '0').slice(0, 64);
    const shareBytes = hexToBytes(shareHex);
    const pubKey = this.curve === 'secp256k1'
      ? bytesToHex(secp256k1.getPublicKey(shareBytes))
      : bytesToHex(ed25519.getPublicKey(shareBytes));

    this.keyShare = {
      participantId,
      secretShare: shareHex,
      publicKey: pubKey,
      verifyingKey: pubKey,
      curve: this.curve,
      threshold: this.threshold,
      totalParticipants: this.totalParticipants,
    };
    return this.keyShare;
  }

  getKeyShare(): FROSTKeyShare | null {
    return this.keyShare;
  }
}

export class FROSTSigner {
  private keyShare: FROSTKeyShare;

  constructor(keyShare: FROSTKeyShare) {
    this.keyShare = keyShare;
  }

  generateCommitment(): FROSTSigningCommitment {
    const nonce = randomBytes(32);
    const bindingFactor = bytesToHex(randomBytes(32));
    const commitment = bytesToHex(sha256(
      new TextEncoder().encode(`${this.keyShare.participantId}:${bytesToHex(nonce)}:${bindingFactor}`)
    ));
    return { participantId: this.keyShare.participantId, bindingFactor, commitment };
  }

  signPartial(message: string, commitments: FROSTSigningCommitment[], participantIds: number[]): string {
    const order = getOrder(this.keyShare.curve);
    const msgHash = bytesToHex(sha256(new TextEncoder().encode(message)));
    const bindingAggregate = commitments.reduce((acc, c) => mod(acc + BigInt('0x' + c.bindingFactor), order), 0n);
    const lambda = computeLagrange(participantIds, this.keyShare.participantId, order);
    const secretShare = BigInt('0x' + this.keyShare.secretShare);
    const msgNum = BigInt('0x' + msgHash);
    const partialSig = mod(msgNum + bindingAggregate + lambda * secretShare, order);
    const sigHex = partialSig.toString(16).padStart(64, '0');
    return sigHex.length > 128 ? sigHex.slice(0, 128) : sigHex;
  }

  aggregateSignatures(
    partialSignatures: string[],
    commitments: FROSTSigningCommitment[],
    _message: string,
    participantIds: number[]
  ): FROSTSignatureResult {
    const order = getOrder(this.keyShare.curve);
    let combinedSig = 0n;
    for (let i = 0; i < partialSignatures.length; i++) {
      const pid = participantIds[i];
      const lambda = computeLagrange(participantIds, pid, order);
      const partial = BigInt('0x' + partialSignatures[i].slice(0, 64));
      combinedSig = mod(combinedSig + lambda * partial, order);
    }
    const r = commitments.reduce((acc, c) => mod(acc + BigInt('0x' + c.commitment.slice(0, 32)), order), 0n);
    const s = mod(combinedSig, order);
    const rHex = r.toString(16).padStart(64, '0');
    const sHex = s.toString(16).padStart(64, '0');
    const signature = bytesToHex(hexToBytes(rHex)) + bytesToHex(hexToBytes(sHex));
    return { signature, publicKey: this.keyShare.publicKey, participants: participantIds };
  }
}

export class KeyResharing {
  static initiateReshare(
    oldShare: FROSTKeyShare,
    newThreshold: number,
    newTotalParticipants: number
  ): { newPolynomial: bigint[]; subshares: Map<number, bigint> } {
    const order = getOrder(oldShare.curve);
    const coeffs = generatePolynomial(newThreshold, oldShare.curve);
    const subshares = new Map<number, bigint>();
    for (let i = 1; i <= newTotalParticipants; i++) {
      const subshare = evaluatePolynomial(coeffs, BigInt(i), order);
      subshares.set(i, mod(subshare + BigInt('0x' + oldShare.secretShare), order));
    }
    return { newPolynomial: coeffs, subshares };
  }
}
