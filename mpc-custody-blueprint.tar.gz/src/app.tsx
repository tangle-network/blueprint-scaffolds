import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  AlertTriangle,
  ArrowRightLeft,
  BadgeCheck,
  Blocks,
  Clock3,
  KeyRound,
  ShieldCheck,
  Siren,
  Wallet
} from "lucide-react";
import { custodyApi } from "./lib/api";
import { amount, currency, prettyDate } from "./lib/format";
import { MetricCard } from "./components/MetricCard";
import { SectionCard } from "./components/SectionCard";
import { StatusPill } from "./components/StatusPill";

export default function App() {
  const queryClient = useQueryClient();
  const snapshotQuery = useQuery({
    queryKey: ["snapshot"],
    queryFn: custodyApi.fetchSnapshot
  });
  const faultQuery = useQuery({
    queryKey: ["fault-report"],
    queryFn: custodyApi.faultReport
  });

  const approveMutation = useMutation({
    mutationFn: ({ requestId, participantId }: { requestId: string; participantId: string }) =>
      custodyApi.approveRequest(requestId, participantId),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["snapshot"] })
  });

  const refreshMutation = useMutation({
    mutationFn: custodyApi.refreshCeremony,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["snapshot"] })
  });

  const reshareMutation = useMutation({
    mutationFn: custodyApi.reshare,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["snapshot"] })
  });

  if (snapshotQuery.isLoading || !snapshotQuery.data) {
    return <main className="shell"><div className="loading-panel">Loading custody blueprint...</div></main>;
  }

  const { balances, ceremony, requests, auditTrail, adapters, webhooks, recovery } = snapshotQuery.data;
  const totalAum = balances.reduce((sum, asset) => sum + asset.fiatValue, 0);
  const pendingValue = balances.reduce((sum, asset) => sum + asset.pending, 0);

  return (
    <main className="shell">
      <section className="hero">
        <div>
          <p className="eyebrow">Tangle Native MPC Custody</p>
          <h1>Threshold custody with FROST signing, time-lock controls, and social recovery.</h1>
          <p className="hero-copy">
            This blueprint models institutional-grade distributed key management for Ethereum, Bitcoin, and Solana without ever reconstructing private keys.
          </p>
        </div>
        <div className="hero-rail">
          <StatusPill label={`${ceremony.policy.threshold}-of-${ceremony.policy.participants} active`} tone="healthy" />
          <StatusPill label={`Refresh epoch ${ceremony.lastRefreshEpoch}`} tone="neutral" />
          <StatusPill label={faultQuery.data?.survives ? "Byzantine tolerant" : "Recovery required"} tone={faultQuery.data?.survives ? "healthy" : "critical"} />
        </div>
      </section>

      <section className="metrics-grid">
        <MetricCard label="Assets Under Custody" value={currency(totalAum)} detail="Cross-chain balances with policy-bound withdrawals" icon={<Wallet size={20} />} />
        <MetricCard label="Pending Value" value={pendingValue.toFixed(2)} detail="Transactions awaiting timelock or threshold completion" icon={<Clock3 size={20} />} />
        <MetricCard label="Signing Curve" value={ceremony.curve.toUpperCase()} detail={`Aggregate key ${ceremony.publicKey}`} icon={<KeyRound size={20} />} />
        <MetricCard label="Recovery Guard" value={`${recovery.quorum}/${recovery.guardians.length}`} detail="Guardian quorum for delayed emergency recovery" icon={<ShieldCheck size={20} />} />
      </section>

      <div className="content-grid">
        <SectionCard
          title="Custody Dashboard"
          subtitle="Balances and chain adapters"
          action={<StatusPill label={`${adapters.filter((adapter) => adapter.connected).length}/${adapters.length} chains online`} tone="healthy" />}
        >
          <div className="table-list">
            {balances.map((asset) => (
              <div className="table-row" key={asset.chain}>
                <div>
                  <strong>{asset.symbol}</strong>
                  <p className="muted">{asset.chain}</p>
                </div>
                <div>{amount(asset.amount, asset.symbol)}</div>
                <div>{currency(asset.fiatValue)}</div>
                <div className="muted">Pending {amount(asset.pending, asset.symbol)}</div>
              </div>
            ))}
          </div>
          <div className="adapter-row">
            {adapters.map((adapter) => (
              <div className="adapter-card" key={adapter.chain}>
                <div className="adapter-title">
                  <Blocks size={16} />
                  <strong>{adapter.chain}</strong>
                </div>
                <p className="muted">{adapter.rpc}</p>
                <StatusPill label={`${adapter.signerCurve.toUpperCase()} signer`} tone="neutral" />
              </div>
            ))}
          </div>
        </SectionCard>

        <SectionCard
          title="Transaction Workflow"
          subtitle="Initiation, approvals, timelocks"
          action={<StatusPill label={`${requests.filter((request) => request.status !== "executed").length} active requests`} tone="warning" />}
        >
          <div className="request-stack">
            {requests.map((request) => (
              <article className="request-card" key={request.id}>
                <div className="request-header">
                  <div>
                    <h3>{request.id}</h3>
                    <p className="muted">
                      {amount(request.amount, request.asset)} to {request.destination.slice(0, 14)}...
                    </p>
                  </div>
                  <StatusPill
                    label={request.status}
                    tone={request.status === "ready" || request.status === "signed" ? "healthy" : request.status === "timelocked" ? "warning" : "neutral"}
                  />
                </div>
                <div className="request-meta">
                  <span>{request.chain}</span>
                  <span>{request.approvals.length}/{request.requiredApprovals} approvals</span>
                  <span>Earliest execution {prettyDate(request.executeAfter)}</span>
                </div>
                <div className="approval-bar">
                  {ceremony.participants
                    .filter((participant) => participant.role !== "observer")
                    .map((participant) => {
                      const approved = request.approvals.some((approval) => approval.participantId === participant.id);
                      return (
                        <button
                          key={`${request.id}-${participant.id}`}
                          className="approval-chip"
                          disabled={approved || approveMutation.isPending}
                          onClick={() => approveMutation.mutate({ requestId: request.id, participantId: participant.id })}
                        >
                          {approved ? <BadgeCheck size={14} /> : <ArrowRightLeft size={14} />}
                          {participant.name}
                        </button>
                      );
                    })}
                </div>
              </article>
            ))}
          </div>
        </SectionCard>

        <SectionCard
          title="Key Ceremony"
          subtitle="DKG, resharing, and proactive refresh"
          action={
            <div className="action-row">
              <button className="ghost-button" onClick={() => refreshMutation.mutate()} disabled={refreshMutation.isPending}>
                Refresh shares
              </button>
              <button className="ghost-button" onClick={() => reshareMutation.mutate()} disabled={reshareMutation.isPending}>
                Reshare set
              </button>
            </div>
          }
        >
          <div className="split-grid">
            <div>
              <p className="muted">Current aggregate key</p>
              <h3>{ceremony.publicKey}</h3>
              <p className="muted">Next proactive refresh due {prettyDate(ceremony.nextRefreshDue)}</p>
            </div>
            <div className="participants-list">
              {ceremony.participants.map((participant) => (
                <div className="participant-row" key={participant.id}>
                  <div>
                    <strong>{participant.name}</strong>
                    <p className="muted">{participant.role} · {participant.region}</p>
                  </div>
                  <StatusPill
                    label={`${participant.deviceTrust.toUpperCase()} ${participant.online ? "online" : "offline"}`}
                    tone={participant.online ? "healthy" : "warning"}
                  />
                </div>
              ))}
            </div>
          </div>
        </SectionCard>

        <SectionCard
          title="Security Controls"
          subtitle="Fault tolerance, HSM posture, recovery"
          action={<StatusPill label={faultQuery.data?.survives ? "Policy survivable" : "Incident mode"} tone={faultQuery.data?.survives ? "healthy" : "critical"} />}
        >
          <div className="security-grid">
            <div className="security-card">
              <Siren size={18} />
              <h3>Byzantine tolerance</h3>
              <p className="muted">
                Healthy signers: {faultQuery.data?.healthy ?? 0}. Unavailable: {faultQuery.data?.unavailable ?? 0}. Byzantine: {faultQuery.data?.byzantine ?? 0}.
              </p>
            </div>
            <div className="security-card">
              <ShieldCheck size={18} />
              <h3>HSM integration option</h3>
              <p className="muted">Two primary signers are pinned to HSM-backed nonce generation and share storage.</p>
            </div>
            <div className="security-card">
              <AlertTriangle size={18} />
              <h3>Social recovery</h3>
              <p className="muted">{recovery.quorum} guardian attestations unlock an emergency flow after {recovery.timelockHours} hours.</p>
            </div>
          </div>
        </SectionCard>

        <SectionCard
          title="Integrations"
          subtitle="WalletConnect, API, webhooks"
          action={<StatusPill label={`${webhooks.length} webhooks`} tone="neutral" />}
        >
          <div className="integration-grid">
            <div className="integration-card">
              <h3>WalletConnect</h3>
              <p className="muted">Ethereum signing requests carry WalletConnect topics for dApp originated approvals.</p>
            </div>
            <div className="integration-card">
              <h3>Programmatic API</h3>
              <p className="muted">Express routes expose custody state, signing requests, ceremony refresh, and resharing operations.</p>
            </div>
            <div className="integration-card">
              <h3>Webhook delivery</h3>
              <div className="table-list compact">
                {webhooks.map((webhook) => (
                  <div className="table-row" key={webhook.id}>
                    <strong>{webhook.event}</strong>
                    <span className="muted">{webhook.target}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </SectionCard>

        <SectionCard title="Audit Trail" subtitle="Signing and recovery activity">
          <div className="table-list">
            {auditTrail.map((event) => (
              <div className="table-row audit-row" key={event.id}>
                <div>
                  <strong>{event.action}</strong>
                  <p className="muted">{event.actor}</p>
                </div>
                <div>{event.detail}</div>
                <div className="muted">{prettyDate(event.at)}</div>
                <StatusPill
                  label={event.severity}
                  tone={event.severity === "critical" ? "critical" : event.severity === "warning" ? "warning" : "neutral"}
                />
              </div>
            ))}
          </div>
        </SectionCard>
      </div>
    </main>
  );
}
