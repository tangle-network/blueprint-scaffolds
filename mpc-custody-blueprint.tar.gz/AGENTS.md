# AGENTS.md

## Goal

Build a threshold signature custody solution using Tangle's native MPC support. Key generation, signing ceremonies, policy management.

## Stack

- Family: `tangle-blueprint`
- Layers: `capability:tangle-custody`
- Partner: `tangle`

## Entry Points

- `mpc-custody-blueprint-bin/src/main.rs`
- `mpc-custody-blueprint-lib/src/lib.rs`
- `blueprint.json`
- `contracts/src/HelloBlueprint.sol`
- `Cargo.toml`

## Commands

- `cargo test -p mpc-custody-blueprint-lib`
- `cargo build --release`

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
