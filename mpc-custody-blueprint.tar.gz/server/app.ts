import express, { type Express } from "express";
import { z } from "zod";
import { mockSnapshot } from "../src/data/mockData";
import {
  aggregateSignature,
  approveSigningRequest,
  canAggregateShares,
  refreshShares,
  reshareCeremony
} from "../src/lib/mpc";
import type { CustodySnapshot } from "../src/lib/types";

const approvalSchema = z.object({
  participantId: z.string()
});

let state: CustodySnapshot = structuredClone(mockSnapshot);

export function createServer(): Express {
  const app = express();
  app.use(express.json());

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, service: "tangle-mpc-custody-blueprint" });
  });

  app.get("/api/custody", (_req, res) => {
    res.json(state);
  });

  app.post("/api/signing-requests/:id/approve", (req, res) => {
    const { participantId } = approvalSchema.parse(req.body);
    const request = state.requests.find((item) => item.id === req.params.id);
    const participant = state.ceremony.participants.find((item) => item.id === participantId);

    if (!request || !participant) {
      res.status(404).json({ error: "request_or_participant_not_found" });
      return;
    }

    request.approvals.push(approveSigningRequest(request, participant));
    if (canAggregateShares(request.approvals, state.ceremony.policy, state.ceremony.participants)) {
      request.status = "signed";
    }

    res.json({
      request,
      aggregateSignature: aggregateSignature(request, state.ceremony)
    });
  });

  app.post("/api/ceremony/refresh", (_req, res) => {
    state.ceremony = refreshShares(state.ceremony);
    res.json(state.ceremony);
  });

  app.post("/api/ceremony/reshare", (_req, res) => {
    state.ceremony = reshareCeremony(
      state.ceremony,
      state.ceremony.participants.slice(0, 4),
      3
    );
    res.json(state.ceremony);
  });

  app.get("/api/webhooks", (_req, res) => {
    res.json(state.webhooks);
  });

  return app;
}
