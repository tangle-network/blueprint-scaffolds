import express, { Request, Response } from "express";
import { BlockMonitor } from "./monitor";
import { StatsTracker } from "./stats";
import { StatsResponse } from "./types";

export function createServer(monitor: BlockMonitor, statsTracker: StatsTracker) {
  const app = express();

  app.get("/stats", (_req: Request, res: Response) => {
    const response: StatsResponse = {
      connected: monitor.isConnected,
      reconnectAttempts: monitor.reconnectCount,
      stats: statsTracker.getStats(),
      lastUpdated: monitor.getLastUpdated(),
    };
    res.json(response);
  });

  app.get("/health", (_req: Request, res: Response) => {
    res.json({ status: monitor.isConnected ? "healthy" : "reconnecting" });
  });

  return app;
}
