import { StatsTracker } from "./stats";
import { BlockMonitor } from "./monitor";
import { createServer } from "./server";

const PORT = parseInt(process.env.PORT || "3000", 10);

const statsTracker = new StatsTracker();
const monitor = new BlockMonitor(statsTracker);
const app = createServer(monitor, statsTracker);

monitor.start();

app.listen(PORT, () => {
  console.log(`[Server] X Layer Monitor listening on http://0.0.0.0:${PORT}`);
  console.log(`[Server] Stats endpoint: http://0.0.0.0:${PORT}/stats`);
  console.log(`[Server] Health endpoint: http://0.0.0.0:${PORT}/health`);
});

process.on("SIGINT", () => {
  console.log("\n[Server] Shutting down...");
  monitor.stop();
  process.exit(0);
});

process.on("SIGTERM", () => {
  console.log("\n[Server] Shutting down...");
  monitor.stop();
  process.exit(0);
});
