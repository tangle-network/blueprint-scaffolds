import WebSocket from "ws";
import { StatsEngine } from "./stats";
import { BlockData } from "./types";
import http from "http";

const WS_URL = "wss://xlayer-rpc.metro.one/xlayer";
const HTTP_URL = "https://xlayer-rpc.metro.one/xlayer";
const RECONNECT_DELAY_MS = 3000;
const MAX_RECONNECT_DELAY_MS = 60000;

let ws: WebSocket | null = null;
let connected = false;
let reconnectAttempts = 0;
const stats = new StatsEngine();

function rpcRequest(method: string, params: unknown[]): Promise<unknown> {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({
      jsonrpc: "2.0",
      id: Date.now(),
      method,
      params,
    });

    const url = new URL(HTTP_URL);
    const req = http.request(
      {
        hostname: url.hostname,
        port: url.port || 443,
        path: url.pathname,
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Content-Length": Buffer.byteLength(body),
        },
      },
      (res) => {
        let data = "";
        res.on("data", (chunk) => (data += chunk));
        res.on("end", () => {
          try {
            const parsed = JSON.parse(data);
            resolve(parsed.result);
          } catch (e) {
            reject(new Error(`Failed to parse RPC response: ${data}`));
          }
        });
      }
    );

    req.on("error", reject);
    req.write(body);
    req.end();
  });
}

async function fetchBlockData(blockNumber: string): Promise<BlockData | null> {
  try {
    const [block, txCount, gasPrice] = await Promise.all([
      rpcRequest("eth_getBlockByNumber", [blockNumber, false]),
      rpcRequest("eth_getBlockTransactionCountByNumber", [blockNumber]),
      rpcRequest("eth_gasPrice", []),
    ]);

    const blockObj = block as Record<string, string>;
    if (!blockObj) return null;

    return {
      number: parseInt(blockObj.number, 16),
      gasPrice: (gasPrice as string) || "0x0",
      transactionCount: parseInt((txCount as string) || "0x0", 16),
      timestamp: parseInt(blockObj.timestamp, 16),
    };
  } catch (err) {
    console.error(`Error fetching block ${blockNumber}:`, err);
    return null;
  }
}

function getReconnectDelay(): number {
  const delay = RECONNECT_DELAY_MS * Math.pow(2, reconnectAttempts);
  return Math.min(delay, MAX_RECONNECT_DELAY_MS);
}

function connect(): void {
  console.log(`Connecting to X Layer mainnet: ${WS_URL}`);
  ws = new WebSocket(WS_URL);

  ws.on("open", () => {
    connected = true;
    reconnectAttempts = 0;
    console.log("WebSocket connected. Subscribing to new blocks...");
    ws!.send(
      JSON.stringify({
        jsonrpc: "2.0",
        id: 1,
        method: "eth_subscribe",
        params: ["newHeads"],
      })
    );
  });

  ws.on("message", async (data: WebSocket.Data) => {
    try {
      const msg = JSON.parse(data.toString());

      if (msg.id === 1 && msg.result) {
        console.log(`Subscribed to new heads: ${msg.result}`);
        return;
      }

      if (msg.method === "eth_subscription" && msg.params?.result) {
        const header = msg.params.result;
        const blockNumber: string = header.number;
        const blockData = await fetchBlockData(blockNumber);
        if (blockData) {
          stats.addBlock(blockData);
          console.log(
            `Block #${blockData.number} | txs: ${blockData.transactionCount} | gasPrice: ${blockData.gasPrice}`
          );
        }
      }
    } catch (err) {
      console.error("Error processing message:", err);
    }
  });

  ws.on("close", (code, reason) => {
    connected = false;
    console.log(`WebSocket closed: ${code} ${reason.toString()}`);
    scheduleReconnect();
  });

  ws.on("error", (err) => {
    connected = false;
    console.error("WebSocket error:", err.message);
  });
}

function scheduleReconnect(): void {
  reconnectAttempts++;
  const delay = getReconnectDelay();
  console.log(`Reconnecting in ${delay}ms (attempt ${reconnectAttempts})...`);
  setTimeout(() => {
    connect();
  }, delay);
}

const server = http.createServer((req, res) => {
  if (req.url === "/stats") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify(stats.getStats(connected), null, 2));
  } else {
    res.writeHead(404);
    res.end("Not found");
  }
});

const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;
server.listen(PORT, () => {
  console.log(`Stats server listening on http://localhost:${PORT}/stats`);
});

connect();
