export interface BlockData {
  number: number;
  timestamp: number;
  gasPrice: bigint;
  transactionCount: number;
}

export interface StatsSnapshot {
  latestBlock: number;
  latestTimestamp: number;
  latestGasPriceWei: string;
  latestGasPriceOkb: string;
  latestTxCount: number;
  avgGasPriceWei: string;
  avgGasPriceOkb: string;
  avgBlockTimeSeconds: number;
  avgTps: number;
  totalBlocksMonitored: number;
  windowSize: number;
  connected: boolean;
  lastUpdated: string;
}

const OKB_DECIMALS = 18;

export class StatsTracker {
  private blocks: BlockData[] = [];
  private readonly windowSize: number;
  private totalBlocks = 0;
  private connected = false;

  constructor(windowSize = 100) {
    this.windowSize = windowSize;
  }

  setConnected(value: boolean): void {
    this.connected = value;
  }

  addBlock(block: BlockData): void {
    this.blocks.push(block);
    if (this.blocks.length > this.windowSize) {
      this.blocks.shift();
    }
    this.totalBlocks++;
  }

  private weiToOkb(wei: bigint): string {
    const whole = wei / BigInt(10 ** OKB_DECIMALS);
    const frac = wei % BigInt(10 ** OKB_DECIMALS);
    const fracStr = frac.toString().padStart(OKB_DECIMALS, "0").slice(0, 8);
    return `${whole.toString()}.${fracStr}`;
  }

  private computeAvgGasPrice(): { wei: bigint; okb: string } {
    if (this.blocks.length === 0) return { wei: BigInt(0), okb: "0.00000000" };
    const totalWei = this.blocks.reduce((sum, b) => sum + b.gasPrice, BigInt(0));
    const avgWei = totalWei / BigInt(this.blocks.length);
    return { wei: avgWei, okb: this.weiToOkb(avgWei) };
  }

  private computeAvgBlockTime(): number {
    if (this.blocks.length < 2) return 0;
    const first = this.blocks[0].timestamp;
    const last = this.blocks[this.blocks.length - 1].timestamp;
    return (last - first) / (this.blocks.length - 1);
  }

  private computeAvgTps(): number {
    if (this.blocks.length < 2) return 0;
    const totalTx = this.blocks.reduce((sum, b) => sum + b.transactionCount, 0);
    const first = this.blocks[0].timestamp;
    const last = this.blocks[this.blocks.length - 1].timestamp;
    const span = last - first;
    if (span === 0) return 0;
    return totalTx / span;
  }

  getSnapshot(): StatsSnapshot {
    const latest = this.blocks[this.blocks.length - 1];
    const avg = this.computeAvgGasPrice();
    return {
      latestBlock: latest?.number ?? 0,
      latestTimestamp: latest?.timestamp ?? 0,
      latestGasPriceWei: (latest?.gasPrice ?? BigInt(0)).toString(),
      latestGasPriceOkb: latest ? this.weiToOkb(latest.gasPrice) : "0.00000000",
      latestTxCount: latest?.transactionCount ?? 0,
      avgGasPriceWei: avg.wei.toString(),
      avgGasPriceOkb: avg.okb,
      avgBlockTimeSeconds: Math.round(this.computeAvgBlockTime() * 1000) / 1000,
      avgTps: Math.round(this.computeAvgTps() * 1000) / 1000,
      totalBlocksMonitored: this.totalBlocks,
      windowSize: this.windowSize,
      connected: this.connected,
      lastUpdated: new Date().toISOString(),
    };
  }
}
