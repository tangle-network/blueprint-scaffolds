import { BlockData, RollingStats } from "./types";

const MAX_BLOCKS = 100;

export class StatsTracker {
  private blocks: BlockData[] = [];

  addBlock(block: BlockData): void {
    this.blocks.push(block);
    if (this.blocks.length > MAX_BLOCKS) {
      this.blocks.shift();
    }
  }

  getStats(): RollingStats {
    const blocks = this.blocks;
    const count = blocks.length;

    if (count === 0) {
      return {
        avgGasPriceOKB: "0",
        avgBlockTime: "0",
        avgTps: "0",
        blockCount: 0,
        latestBlock: 0,
        startTime: Date.now(),
        blocks: [],
      };
    }

    const avgGasPriceWei =
      blocks.reduce((sum, b) => sum + b.gasPrice, BigInt(0)) / BigInt(count);

    const avgGasPriceOKB = this.weiToOKB(avgGasPriceWei);

    let avgBlockTime = "0";
    if (count > 1) {
      const timeDiffs: number[] = [];
      for (let i = 1; i < blocks.length; i++) {
        timeDiffs.push(blocks[i].timestamp - blocks[i - 1].timestamp);
      }
      const avgMs =
        timeDiffs.reduce((a, b) => a + b, 0) / timeDiffs.length;
      avgBlockTime = avgMs.toFixed(2);
    }

    let avgTps = "0";
    if (count > 1) {
      const firstTs = blocks[0].timestamp;
      const lastTs = blocks[blocks.length - 1].timestamp;
      const totalTx = blocks.reduce((s, b) => s + b.transactionCount, 0);
      const elapsed = (lastTs - firstTs) / 1000;
      if (elapsed > 0) {
        avgTps = (totalTx / elapsed).toFixed(4);
      }
    }

    return {
      avgGasPriceOKB,
      avgBlockTime,
      avgTps,
      blockCount: count,
      latestBlock: blocks[blocks.length - 1].number,
      startTime: blocks[0].timestamp,
      blocks,
    };
  }

  private weiToOKB(wei: bigint): string {
    const decimals = 18;
    const weiStr = wei.toString().padStart(decimals + 1, "0");
    const intPart = weiStr.slice(0, -decimals) || "0";
    const fracPart = weiStr.slice(-decimals);
    const trimmed = intPart + "." + fracPart.slice(0, 9);
    return parseFloat(trimmed).toFixed(9);
  }
}
