import { BlockData, RollingStats } from "./types";

const WEI_PER_OKB = 1e18;
const MAX_WINDOW = 100;

export class StatsEngine {
  private blocks: BlockData[] = [];

  addBlock(block: BlockData): void {
    this.blocks.push(block);
    if (this.blocks.length > MAX_WINDOW) {
      this.blocks.shift();
    }
  }

  getStats(connected: boolean): RollingStats {
    const count = this.blocks.length;
    if (count === 0) {
      return {
        avgGasPriceOKB: "0",
        avgBlockTime: "0",
        avgTPS: "0",
        blockCount: 0,
        latestBlock: 0,
        connected,
        lastUpdated: new Date().toISOString(),
      };
    }

    const avgGasPriceWei =
      this.blocks.reduce((sum, b) => sum + BigInt(b.gasPrice), BigInt(0)) /
      BigInt(count);
    const avgGasPriceOKB = Number(avgGasPriceWei) / WEI_PER_OKB;

    let totalBlockTime = 0;
    let blockTimeSamples = 0;
    for (let i = 1; i < this.blocks.length; i++) {
      totalBlockTime +=
        this.blocks[i].timestamp - this.blocks[i - 1].timestamp;
      blockTimeSamples++;
    }
    const avgBlockTime =
      blockTimeSamples > 0 ? totalBlockTime / blockTimeSamples : 0;

    const totalTx = this.blocks.reduce((s, b) => s + b.transactionCount, 0);
    const timeSpan =
      count > 1
        ? this.blocks[count - 1].timestamp - this.blocks[0].timestamp
        : 1;
    const avgTPS = timeSpan > 0 ? totalTx / timeSpan : 0;

    return {
      avgGasPriceOKB: avgGasPriceOKB.toFixed(9),
      avgBlockTime: avgBlockTime.toFixed(2),
      avgTPS: avgTPS.toFixed(4),
      blockCount: count,
      latestBlock: this.blocks[count - 1].number,
      connected,
      lastUpdated: new Date().toISOString(),
    };
  }
}
