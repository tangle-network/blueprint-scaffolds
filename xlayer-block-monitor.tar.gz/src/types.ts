export interface BlockData {
  number: number;
  hash: string;
  timestamp: number;
  gasPrice: bigint;
  transactionCount: number;
  gasUsed: bigint;
  gasLimit: bigint;
}

export interface RollingStats {
  avgGasPriceOKB: string;
  avgBlockTime: string;
  avgTps: string;
  blockCount: number;
  latestBlock: number;
  startTime: number;
  blocks: BlockData[];
}

export interface StatsResponse {
  connected: boolean;
  reconnectAttempts: number;
  stats: RollingStats;
  lastUpdated: number | null;
}
