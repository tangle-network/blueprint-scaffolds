export interface BlockData {
  number: number;
  gasPrice: string;
  transactionCount: number;
  timestamp: number;
}

export interface RollingStats {
  avgGasPriceOKB: string;
  avgBlockTime: string;
  avgTPS: string;
  blockCount: number;
  latestBlock: number;
  connected: boolean;
  lastUpdated: string;
}
