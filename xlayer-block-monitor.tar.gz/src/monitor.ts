import WebSocket from "ws";
import { ethers } from "ethers";
import { BlockData } from "./types";
import { StatsTracker } from "./stats";

const XLAYER_RPC = "https://exrpc.xlayer.tech";
const XLAYER_WS = "wss://exws.xlayer.tech";

export class BlockMonitor {
  private ws: WebSocket | null = null;
  private provider: ethers.JsonRpcProvider;
  private statsTracker: StatsTracker;
  private reconnectAttempts = 0;
  private maxReconnectDelay = 30000;
  private baseReconnectDelay = 1000;
  private connected = false;
  private lastUpdated: number | null = null;
  private pingInterval: ReturnType<typeof setInterval> | null = null;
  private subscriptionId: string | null = null;

  constructor(statsTracker: StatsTracker) {
    this.provider = new ethers.JsonRpcProvider(XLAYER_RPC);
    this.statsTracker = statsTracker;
  }

  get isConnected(): boolean {
    return this.connected;
  }

  get reconnectCount(): number {
    return this.reconnectAttempts;
  }

  getLastUpdated(): number | null {
    return this.lastUpdated;
  }

  start(): void {
    this.connect();
  }

  private connect(): void {
    console.log(
      `[Monitor] Connecting to X Layer WebSocket: ${XLAYER_WS} (attempt ${this.reconnectAttempts + 1})`
    );

    try {
      this.ws = new WebSocket(XLAYER_WS);

      this.ws.on("open", () => {
        console.log("[Monitor] WebSocket connected");
        this.connected = true;
        this.reconnectAttempts = 0;
        this.subscribe();
        this.startPing();
      });

      this.ws.on("message", (data: WebSocket.Data) => {
        this.handleMessage(data);
      });

      this.ws.on("close", (code: number, reason: Buffer) => {
        console.log(`[Monitor] WebSocket closed: ${code} ${reason.toString()}`);
        this.connected = false;
        this.cleanup();
        this.scheduleReconnect();
      });

      this.ws.on("error", (err: Error) => {
        console.error(`[Monitor] WebSocket error: ${err.message}`);
        this.connected = false;
        this.cleanup();
        this.scheduleReconnect();
      });
    } catch (err) {
      console.error(`[Monitor] Connection failed: ${err}`);
      this.scheduleReconnect();
    }
  }

  private subscribe(): void {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;

    const subscribeMsg = JSON.stringify({
      jsonrpc: "2.0",
      id: 1,
      method: "eth_subscribe",
      params: ["newHeads"],
    });

    this.ws.send(subscribeMsg);
    console.log("[Monitor] Subscribed to newHeads");
  }

  private handleMessage(data: WebSocket.Data): void {
    try {
      const msg = JSON.parse(data.toString());

      if (msg.id === 1 && msg.result) {
        this.subscriptionId = msg.result;
        console.log(`[Monitor] Subscription confirmed: ${this.subscriptionId}`);
        return;
      }

      if (
        msg.method === "eth_subscription" &&
        msg.params &&
        msg.params.result
      ) {
        const header = msg.params.result;
        const blockNumber = parseInt(header.number, 16);
        this.fetchBlockDetails(blockNumber);
      }
    } catch {
      // ignore non-JSON messages
    }
  }

  private async fetchBlockDetails(blockNumber: number): Promise<void> {
    try {
      const block = await this.provider.getBlock(blockNumber);
      if (!block) {
        console.warn(`[Monitor] Block ${blockNumber} not found`);
        return;
      }

      const feeData = await this.provider.getFeeData();
      const gasPrice = feeData.gasPrice ?? BigInt(0);

      const blockData: BlockData = {
        number: blockNumber,
        hash: block.hash ?? "",
        timestamp: Number(block.timestamp) * 1000,
        gasPrice,
        transactionCount: block.transactions.length,
        gasUsed: block.gasUsed,
        gasLimit: block.gasLimit,
      };

      this.statsTracker.addBlock(blockData);
      this.lastUpdated = Date.now();

      const stats = this.statsTracker.getStats();
      console.log(
        `[Monitor] Block #${blockNumber} | Txns: ${blockData.transactionCount} | Gas Price: ${stats.avgGasPriceOKB} OKB | Avg Block Time: ${stats.avgBlockTime}ms | TPS: ${stats.avgTps}`
      );
    } catch (err) {
      console.error(`[Monitor] Error fetching block ${blockNumber}: ${err}`);
    }
  }

  private startPing(): void {
    this.pingInterval = setInterval(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.ping();
      }
    }, 15000);
  }

  private cleanup(): void {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
    this.subscriptionId = null;
  }

  private scheduleReconnect(): void {
    const delay = Math.min(
      this.baseReconnectDelay * Math.pow(2, this.reconnectAttempts),
      this.maxReconnectDelay
    );

    this.reconnectAttempts++;
    console.log(
      `[Monitor] Reconnecting in ${delay}ms (attempt ${this.reconnectAttempts})`
    );

    setTimeout(() => {
      this.connect();
    }, delay);
  }

  stop(): void {
    this.cleanup();
    if (this.ws) {
      this.ws.removeAllListeners();
      if (this.ws.readyState === WebSocket.OPEN) {
        this.ws.close();
      }
      this.ws = null;
    }
    this.connected = false;
  }
}
