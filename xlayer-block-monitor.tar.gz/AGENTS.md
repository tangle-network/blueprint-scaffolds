# AGENTS.md

## Goal

Build a block monitoring service for X Layer. Real-time block tracking, event filtering, alerting.

## Stack

- Family: `agent-service-ts`
- Layers: `database:sqlite`, `sdk:evm-wallet`, `auth:none`, `payments:none`, `queue:none`
- Partner: `xlayer`

## Architecture

- Agent control loop: plan → act → reflect
- Tool registration
- Memory/state management
- HTTP health endpoint
- Create lib/wagmi.ts with wagmi config (chains, transports, connectors).
- Wrap root layout: WagmiProvider → QueryClientProvider → RainbowKit/ConnectKit provider.
- Use useAccount(), useBalance(), useSendTransaction() hooks in components.
- For SIWE: generate nonce server-side, sign client-side, verify server-side.

## Entry Points

- `agent.mjs`
- `agent.config.json`

## Commands

- `node agent.mjs`

## Build Plan

Components: WalletProvider, ConnectButton, AccountDisplay, ChainSwitcher
Data models: ConnectedWallet, Chain, Transaction
Integrations: WalletConnect v2, Coinbase Wallet SDK, SIWE auth

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
