// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IVerifier {
    function verify(bytes calldata proof, uint256[2] calldata publicSignals) external view returns (bool);
}
