// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

struct EncryptedVote {
    uint256 c1;
    uint256 c2;
    uint256 c3;
}

struct Proposal {
    uint256 id;
    string description;
    uint256 snapshotBlock;
    uint256 deadline;
    uint256 forVotes;
    uint256 againstVotes;
    uint256 abstainVotes;
    bool executed;
    bytes32 merkleRoot;
    mapping(address => bool) hasVoted;
    mapping(bytes32 => bool) nullifiers;
    EncryptedVote[] encryptedVotes;
}

contract PrivateGovernor {
    string public constant name = "Private DAO Governor";
    uint256 public proposalCount;
    uint256 public votingDelay = 1;
    uint256 public votingPeriod = 50400;
    uint256 public proposalThreshold = 100e18;
    uint256 public quorumNumerator = 4;

    mapping(uint256 => Proposal) public proposals;
    mapping(bytes32 => bool) public globalNullifiers;

    event ProposalCreated(
        uint256 indexed proposalId,
        address indexed proposer,
        string description,
        uint256 snapshotBlock,
        uint256 deadline,
        bytes32 merkleRoot
    );

    event VoteCast(
        uint256 indexed proposalId,
        bytes32 indexed nullifier,
        uint256[3] ciphertext
    );

    event VotesTallied(
        uint256 indexed proposalId,
        uint256 forVotes,
        uint256 againstVotes,
        uint256 abstainVotes
    );

    event DelegationUpdated(
        address indexed delegator,
        address indexed delegatee,
        uint256 nonce
    );

    function createProposal(
        string calldata description,
        bytes32 merkleRoot
    ) external returns (uint256) {
        uint256 snapshotBlock = block.number + votingDelay;
        uint256 deadline = snapshotBlock + votingPeriod;

        proposalCount++;
        Proposal storage p = proposals[proposalCount];
        p.id = proposalCount;
        p.description = description;
        p.snapshotBlock = snapshotBlock;
        p.deadline = deadline;
        p.merkleRoot = merkleRoot;

        emit ProposalCreated(
            proposalCount,
            msg.sender,
            description,
            snapshotBlock,
            deadline,
            merkleRoot
        );

        return proposalCount;
    }

    function castEncryptedVote(
        uint256 proposalId,
        bytes32 nullifier,
        uint256[2] calldata proofA,
        uint256[2][2] calldata proofB,
        uint256[2] calldata proofC,
        uint256[3] calldata ciphertext
    ) external {
        Proposal storage p = proposals[proposalId];
        require(block.number >= p.snapshotBlock, "Voting not started");
        require(block.number < p.deadline, "Voting ended");
        require(!p.nullifiers[nullifier], "Already voted");
        require(!globalNullifiers[nullifier], "Nullifier used globally");

        p.nullifiers[nullifier] = true;
        globalNullifiers[nullifier] = true;

        p.encryptedVotes.push(
            EncryptedVote(ciphertext[0], ciphertext[1], ciphertext[2])
        );

        emit VoteCast(proposalId, nullifier, ciphertext);
    }

    function tallyVotes(
        uint256 proposalId,
        uint256 forVotes,
        uint256 againstVotes,
        uint256 abstainVotes,
        uint256[2] calldata proofA,
        uint256[2][2] calldata proofB,
        uint256[2] calldata proofC
    ) external {
        Proposal storage p = proposals[proposalId];
        require(block.number >= p.deadline, "Voting not ended");
        require(!p.executed, "Already tallied");

        p.forVotes = forVotes;
        p.againstVotes = againstVotes;
        p.abstainVotes = abstainVotes;
        p.executed = true;

        emit VotesTallied(proposalId, forVotes, againstVotes, abstainVotes);
    }

    function getEncryptedVotes(
        uint256 proposalId
    ) external view returns (EncryptedVote[] memory) {
        return proposals[proposalId].encryptedVotes;
    }

    function state(uint256 proposalId) external view returns (string memory) {
        Proposal storage p = proposals[proposalId];
        if (p.executed) return "Executed";
        if (block.number >= p.deadline) return "Closed";
        if (block.number >= p.snapshotBlock) return "Active";
        return "Pending";
    }
}
