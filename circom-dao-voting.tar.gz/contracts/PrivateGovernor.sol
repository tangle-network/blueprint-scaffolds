// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/governance/Governor.sol";
import "@openzeppelin/contracts/governance/extensions/GovernorSettings.sol";
import "@openzeppelin/contracts/governance/extensions/GovernorCountingSimple.sol";
import "@openzeppelin/contracts/governance/extensions/GovernorVotes.sol";
import "@openzeppelin/contracts/governance/extensions/GovernorVotesQuorumFraction.sol";
import "@openzeppelin/contracts/governance/extensions/GovernorTimelockControl.sol";
import "./IVerifier.sol";

contract PrivateGovernor is
    Governor,
    GovernorSettings,
    GovernorCountingSimple,
    GovernorVotes,
    GovernorVotesQuorumFraction
{
    IVerifier public voteVerifier;
    IVerifier public eligibilityVerifier;
    IVerifier public tallyVerifier;

    mapping(uint256 => bytes32) public proposalSnapshotRoots;
    mapping(uint256 => mapping(bytes32 => bool)) public spentNullifiers;
    mapping(uint256 => TallyResult) public proposalTallies;

    struct TallyResult {
        uint256 totalFor;
        uint256 totalAgainst;
        uint256 totalAbstain;
        bytes32 commitment;
        bool finalized;
    }

    struct EncryptedVote {
        bytes32 commitment;
        bytes32 nullifierHash;
        bytes proof;
        uint256[2] proofPublicSignals;
    }

    event VoteCastEncrypted(
        uint256 indexed proposalId,
        bytes32 indexed nullifierHash,
        bytes32 commitment,
        address voter
    );

    event TallyFinalized(
        uint256 indexed proposalId,
        uint256 totalFor,
        uint256 totalAgainst,
        uint256 totalAbstain
    );

    event SnapshotRootSet(uint256 indexed proposalId, bytes32 merkleRoot);

    constructor(
        IVotes _token,
        IVerifier _voteVerifier,
        IVerifier _eligibilityVerifier,
        IVerifier _tallyVerifier
    )
        Governor("PrivateDAO")
        GovernorSettings(7200, 50400, 100e18)
        GovernorVotes(_token)
        GovernorVotesQuorumFraction(4)
    {
        voteVerifier = _voteVerifier;
        eligibilityVerifier = _eligibilityVerifier;
        tallyVerifier = _tallyVerifier;
    }

    function setSnapshotRoot(uint256 proposalId, bytes32 merkleRoot) external onlyGovernance {
        proposalSnapshotRoots[proposalId] = merkleRoot;
        emit SnapshotRootSet(proposalId, merkleRoot);
    }

    function castEncryptedVote(
        uint256 proposalId,
        bytes32 commitment,
        bytes32 nullifierHash,
        bytes calldata eligibilityProof,
        uint256[2] calldata eligibilityPubSignals,
        bytes calldata voteProof,
        uint256[2] calldata votePubSignals
    ) external {
        require(!spentNullifiers[proposalId][nullifierHash], "Already voted");
        require(proposalSnapshotRoots[proposalId] != bytes32(0), "No snapshot");

        require(
            eligibilityVerifier.verify(eligibilityProof, eligibilityPubSignals),
            "Invalid eligibility proof"
        );

        require(
            voteVerifier.verify(voteProof, votePubSignals),
            "Invalid vote proof"
        );

        spentNullifiers[proposalId][nullifierHash] = true;

        emit VoteCastEncrypted(proposalId, nullifierHash, commitment, msg.sender);
    }

    function finalizeTally(
        uint256 proposalId,
        uint256 totalFor,
        uint256 totalAgainst,
        uint256 totalAbstain,
        bytes calldata tallyProof,
        uint256[2] calldata tallyPubSignals
    ) external {
        require(!proposalTallies[proposalId].finalized, "Already finalized");

        require(
            tallyVerifier.verify(tallyProof, tallyPubSignals),
            "Invalid tally proof"
        );

        proposalTallies[proposalId] = TallyResult({
            totalFor: totalFor,
            totalAgainst: totalAgainst,
            totalAbstain: totalAbstain,
            commitment: keccak256(abi.encodePacked(totalFor, totalAgainst, totalAbstain)),
            finalized: true
        });

        emit TallyFinalized(proposalId, totalFor, totalAgainst, totalAbstain);
    }

    function hasVoted(uint256 proposalId, bytes32 nullifierHash) external view returns (bool) {
        return spentNullifiers[proposalId][nullifierHash];
    }

    function getTally(uint256 proposalId)
        external
        view
        returns (uint256, uint256, uint256, bool)
    {
        TallyResult storage t = proposalTallies[proposalId];
        return (t.totalFor, t.totalAgainst, t.totalAbstain, t.finalized);
    }

    function votingDelay() public pure override(IGovernor, GovernorSettings) returns (uint256) {
        return 7200;
    }

    function votingPeriod() public pure override(IGovernor, GovernorSettings) returns (uint256) {
        return 50400;
    }

    function quorum(uint256 blockNumber)
        public
        view
        override(IGovernor, GovernorVotesQuorumFraction)
        returns (uint256)
    {
        return super.quorum(blockNumber);
    }

    function proposalThreshold()
        public
        view
        override(IGovernor, GovernorSettings)
        returns (uint256)
    {
        return super.proposalThreshold();
    }
}
