// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governor} from "@openzeppelin/contracts/governance/Governor.sol";
import {GovernorVotes} from "@openzeppelin/contracts/governance/extensions/GovernorVotes.sol";
import {GovernorVotesQuorumFraction} from "@openzeppelin/contracts/governance/extensions/GovernorVotesQuorumFraction.sol";
import {IVotes} from "@openzeppelin/contracts/governance/utils/IVotes.sol";

contract PrivateDAOGovernor is Governor, GovernorVotes, GovernorVotesQuorumFraction {
    enum VoteType {
        Against,
        For,
        Abstain
    }

    struct SnapshotConfig {
        bytes32 merkleRoot;
        uint48 snapshotBlock;
        bool exists;
    }

    struct EncryptedBallot {
        uint256 ciphertextX;
        uint256 ciphertextY;
        bytes32 nullifier;
        address delegate;
        uint256 delegatedWeight;
    }

    struct ProposalTally {
        uint256 againstVotes;
        uint256 forVotes;
        uint256 abstainVotes;
        mapping(address voter => bool) hasVoted;
    }

    mapping(uint256 proposalId => SnapshotConfig) public proposalSnapshots;
    mapping(uint256 proposalId => EncryptedBallot[]) private _encryptedBallots;
    mapping(uint256 proposalId => ProposalTally) private _proposalTallies;
    mapping(bytes32 nullifier => bool used) public usedNullifiers;
    mapping(uint256 proposalId => bytes32 aggregateCommitment) public aggregateTallies;

    event SnapshotRootRegistered(uint256 indexed proposalId, bytes32 merkleRoot, uint48 snapshotBlock);
    event AnonymousVoteSubmitted(
        uint256 indexed proposalId,
        bytes32 indexed nullifier,
        uint256 ciphertextX,
        uint256 ciphertextY,
        address delegate,
        uint256 delegatedWeight
    );
    event AggregateTallyStored(uint256 indexed proposalId, bytes32 aggregateCommitment);

    constructor(IVotes token)
        Governor("PrivateDAOGovernor")
        GovernorVotes(token)
        GovernorVotesQuorumFraction(4)
    {}

    function votingDelay() public pure override returns (uint256) {
        return 1 days;
    }

    function votingPeriod() public pure override returns (uint256) {
        return 1 weeks;
    }

    function proposalThreshold() public pure override returns (uint256) {
        return 100_000e18;
    }

    function COUNTING_MODE() public pure override returns (string memory) {
        return "support=hidden&quorum=for,abstain&params=anonymous";
    }

    function hasVoted(uint256 proposalId, address account) public view override returns (bool) {
        return _proposalTallies[proposalId].hasVoted[account];
    }

    function proposalVotes(
        uint256 proposalId
    ) external view returns (uint256 againstVotes, uint256 forVotes, uint256 abstainVotes) {
        ProposalTally storage tally = _proposalTallies[proposalId];
        return (tally.againstVotes, tally.forVotes, tally.abstainVotes);
    }

    function registerSnapshotRoot(uint256 proposalId, bytes32 merkleRoot, uint48 snapshotBlock) external onlyGovernance {
        proposalSnapshots[proposalId] = SnapshotConfig({
            merkleRoot: merkleRoot,
            snapshotBlock: snapshotBlock,
            exists: true
        });

        emit SnapshotRootRegistered(proposalId, merkleRoot, snapshotBlock);
    }

    function submitAnonymousVote(
        uint256 proposalId,
        uint256 ciphertextX,
        uint256 ciphertextY,
        bytes32 nullifier,
        address delegate,
        uint256 delegatedWeight
    ) external {
        require(state(proposalId) == ProposalState.Active, "Governor: proposal not active");
        require(proposalSnapshots[proposalId].exists, "Governor: snapshot root missing");
        require(!usedNullifiers[nullifier], "Governor: nullifier already used");

        usedNullifiers[nullifier] = true;
        _encryptedBallots[proposalId].push(
            EncryptedBallot({
                ciphertextX: ciphertextX,
                ciphertextY: ciphertextY,
                nullifier: nullifier,
                delegate: delegate,
                delegatedWeight: delegatedWeight
            })
        );

        emit AnonymousVoteSubmitted(
            proposalId,
            nullifier,
            ciphertextX,
            ciphertextY,
            delegate,
            delegatedWeight
        );
    }

    function ballotCount(uint256 proposalId) external view returns (uint256) {
        return _encryptedBallots[proposalId].length;
    }

    function encryptedBallotAt(uint256 proposalId, uint256 index) external view returns (EncryptedBallot memory) {
        return _encryptedBallots[proposalId][index];
    }

    function storeAggregateTally(uint256 proposalId, bytes32 aggregateCommitment) external onlyGovernance {
        require(proposalSnapshots[proposalId].exists, "Governor: snapshot root missing");
        aggregateTallies[proposalId] = aggregateCommitment;
        emit AggregateTallyStored(proposalId, aggregateCommitment);
    }

    function relayPublicTally(
        uint256 proposalId,
        uint256 againstVotes,
        uint256 forVotes,
        uint256 abstainVotes
    ) external onlyGovernance {
        ProposalTally storage tally = _proposalTallies[proposalId];
        tally.againstVotes = againstVotes;
        tally.forVotes = forVotes;
        tally.abstainVotes = abstainVotes;
    }

    function _quorumReached(uint256 proposalId) internal view override returns (bool) {
        ProposalTally storage tally = _proposalTallies[proposalId];
        return quorum(proposalSnapshot(proposalId)) <= tally.forVotes + tally.abstainVotes;
    }

    function _voteSucceeded(uint256 proposalId) internal view override returns (bool) {
        ProposalTally storage tally = _proposalTallies[proposalId];
        return tally.forVotes > tally.againstVotes;
    }

    function _countVote(
        uint256 proposalId,
        address account,
        uint8 support,
        uint256 totalWeight,
        bytes memory
    ) internal override returns (uint256) {
        ProposalTally storage tally = _proposalTallies[proposalId];

        if (tally.hasVoted[account]) {
            revert GovernorAlreadyCastVote(account);
        }
        tally.hasVoted[account] = true;

        if (support == uint8(VoteType.Against)) {
            tally.againstVotes += totalWeight;
        } else if (support == uint8(VoteType.For)) {
            tally.forVotes += totalWeight;
        } else if (support == uint8(VoteType.Abstain)) {
            tally.abstainVotes += totalWeight;
        } else {
            revert GovernorInvalidVoteType();
        }

        return totalWeight;
    }

    function quorum(uint256 blockNumber)
        public
        view
        override(Governor, GovernorVotesQuorumFraction)
        returns (uint256)
    {
        return super.quorum(blockNumber);
    }
}
