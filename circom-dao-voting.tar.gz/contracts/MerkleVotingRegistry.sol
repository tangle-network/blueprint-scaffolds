// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/access/Ownable.sol";

contract MerkleVotingRegistry is Ownable {
    mapping(uint256 => bytes32) public snapshotRoots;
    mapping(address => uint256) public delegations;

    event RootUpdated(uint256 indexed blockNumber, bytes32 root);
    event Delegated(address indexed from, address indexed to, uint256 blockNumber);

    function setSnapshotRoot(uint256 blockNumber, bytes32 root) external onlyOwner {
        snapshotRoots[blockNumber] = root;
        emit RootUpdated(blockNumber, root);
    }

    function delegate(address to) external {
        delegations[msg.sender] = uint160(to);
        emit Delegated(msg.sender, to, block.number);
    }

    function getDelegation(address account) external view returns (address) {
        uint256 delegated = delegations[account];
        if (delegated == 0) return account;
        return address(uint160(delegated));
    }
}
