// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import { IERC5267 } from "@openzeppelin/contracts/interfaces/IERC5267.sol";

contract SnapshotRegistry {
    mapping(address => mapping(uint256 => uint256)) public balanceOfAt;
    mapping(address => mapping(uint256 => uint256)) public totalSupplyAt;
    mapping(uint256 => bool) public snapshotExists;

    uint256[] public snapshotBlocks;

    event SnapshotTaken(uint256 indexed blockNumber, bytes32 indexed merkleRoot);

    function takeSnapshot(
        bytes32 merkleRoot,
        address[] calldata voters,
        uint256[] calldata balances
    ) external {
        require(voters.length == balances.length, "Length mismatch");

        uint256 blockNum = block.number;
        require(!snapshotExists[blockNum], "Snapshot exists");

        snapshotExists[blockNum] = true;
        snapshotBlocks.push(blockNum);

        for (uint256 i = 0; i < voters.length; i++) {
            balanceOfAt[voters[i]][blockNum] = balances[i];
        }

        emit SnapshotTaken(blockNum, merkleRoot);
    }

    function getSnapshotBlocks() external view returns (uint256[] memory) {
        return snapshotBlocks;
    }

    function verifyEligibility(
        address voter,
        uint256 blockNumber,
        bytes32[] calldata proof,
        bytes32 root
    ) external view returns (bool) {
        require(snapshotExists[blockNumber], "No snapshot");
        bytes32 hash = keccak256(abi.encodePacked(voter, balanceOfAt[voter][blockNumber]));

        for (uint256 i = 0; i < proof.length; i++) {
            if (hash < proof[i]) {
                hash = keccak256(abi.encodePacked(hash, proof[i]));
            } else {
                hash = keccak256(abi.encodePacked(proof[i], hash));
            }
        }

        return hash == root;
    }
}
