export interface Proposal {
  id: string;
  title: string;
  description: string;
  proposer: string;
  snapshotBlock: number;
  deadline: number;
  status: "pending" | "active" | "closed" | "executed";
  merkleRoot: string;
  encryptedVoteCount: number;
  tally?: TallyResult;
}

export interface TallyResult {
  forVotes: number;
  againstVotes: number;
  abstainVotes: number;
  totalVotingPower: number;
}

export type VoteChoice = "for" | "against" | "abstain";

export interface EncryptedVote {
  c1: string;
  c2: string;
  c3: string;
  nullifier: string;
}

export interface VoteReceipt {
  proposalId: string;
  nullifier: string;
  timestamp: number;
  ciphertext: [string, string, string];
}

export interface Delegation {
  delegator: string;
  delegatee: string;
  nonce: number;
  timestamp: number;
  active: boolean;
}

export interface SnapshotInfo {
  blockNumber: number;
  merkleRoot: string;
  timestamp: number;
}

export interface VoterEligibility {
  eligible: boolean;
  votingPower: number;
  merkleProof: string[];
  snapshotBlock: number;
}

export interface ZKProof {
  proofA: [string, string];
  proofB: [[string, string], [string, string]];
  proofC: [string, string];
  publicSignals: string[];
}

export interface CircuitArtifacts {
  wasm: string;
  zkey: string;
  vkey: string;
}
