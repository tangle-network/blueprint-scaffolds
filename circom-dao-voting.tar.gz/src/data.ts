export type CircuitDescriptor = {
  name: string;
  purpose: string;
  publicInputs: string[];
  outputs: string[];
};

export type Proposal = {
  id: number;
  title: string;
  description: string;
  snapshotBlock: number;
  merkleRoot: string;
  delegatedVotingPower: number;
  quorum: number;
  encryptedVotes: number;
};

export const circuits: CircuitDescriptor[] = [
  {
    name: "vote_encryption",
    purpose: "Encrypts the vote choice with voter randomness and proves ballot well-formedness.",
    publicInputs: ["proposalId", "ciphertextX", "ciphertextY", "nullifier"],
    outputs: ["ciphertextCommitment"]
  },
  {
    name: "eligibility_proof",
    purpose: "Proves the voter existed in the snapshot Merkle tree without revealing the leaf.",
    publicInputs: ["snapshotRoot", "proposalId", "nullifier"],
    outputs: ["leafCommitment"]
  },
  {
    name: "tally_computation",
    purpose: "Aggregates encrypted ballots and exposes the homomorphic sum for final decryption.",
    publicInputs: ["aggregateX", "aggregateY", "ballotCount"],
    outputs: ["tallyCommitment"]
  }
];

export const proposals: Proposal[] = [
  {
    id: 7,
    title: "Treasury Diversification Program",
    description: "Authorize a diversified stablecoin basket while keeping individual votes private.",
    snapshotBlock: 19753124,
    merkleRoot: "0x8f24a87ab6d73480e8e54ca1bc93325f08039d7adf28964f11d6551111bca001",
    delegatedVotingPower: 18420,
    quorum: 12000,
    encryptedVotes: 318
  },
  {
    id: 8,
    title: "Grants Council Expansion",
    description: "Increase delegates on the grants council and preserve coercion-resistant participation.",
    snapshotBlock: 19781205,
    merkleRoot: "0x309aa87ab6d73480e8e54ca1bc93325f08039d7adf28964f11d6551111bca9fe",
    delegatedVotingPower: 12280,
    quorum: 9000,
    encryptedVotes: 241
  }
];

export const governanceFlow = [
  "Snapshot produces a token-balance Merkle root for the proposal block.",
  "The eligibility circuit proves inclusion in that root and binds the proof to a nullifier.",
  "The vote encryption circuit outputs an ElGamal-style ciphertext and a proof that the vote is binary.",
  "The governor stores only encrypted ballots, nullifiers, delegation checkpoints, and the snapshot root.",
  "The tally circuit folds ciphertexts into a homomorphic aggregate for threshold decryption."
];
