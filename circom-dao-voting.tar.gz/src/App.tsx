import { circuits, governanceFlow, proposals } from "./data";

const formatNumber = (value: number) => new Intl.NumberFormat("en-US").format(value);

export default function App() {
  return (
    <main className="shell">
      <section className="hero">
        <p className="eyebrow">Private DAO Governance</p>
        <h1>Anonymous votes, snapshot eligibility, delegated power.</h1>
        <p className="lede">
          This reference implementation pairs Circom proofs with an OpenZeppelin Governor flow so
          proposal voting stays private while tallying remains verifiable.
        </p>
        <div className="hero-grid">
          <article className="metric-card">
            <span>Total proposals</span>
            <strong>{proposals.length}</strong>
          </article>
          <article className="metric-card">
            <span>Circuits</span>
            <strong>{circuits.length}</strong>
          </article>
          <article className="metric-card">
            <span>Delegated voting power</span>
            <strong>{formatNumber(proposals.reduce((sum, item) => sum + item.delegatedVotingPower, 0))}</strong>
          </article>
        </div>
      </section>

      <section className="panel">
        <div className="section-heading">
          <h2>Governance flow</h2>
          <p>Designed for coercion resistance, anonymous ballots, and snapshot-based eligibility.</p>
        </div>
        <div className="timeline">
          {governanceFlow.map((step, index) => (
            <article className="timeline-item" key={step}>
              <span>{String(index + 1).padStart(2, "0")}</span>
              <p>{step}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="grid two-up">
        <div className="panel">
          <div className="section-heading">
            <h2>Active proposals</h2>
            <p>The frontend exposes the snapshot root, encrypted ballot count, and delegated voting power.</p>
          </div>
          <div className="proposal-list">
            {proposals.map((proposal) => (
              <article className="proposal-card" key={proposal.id}>
                <div className="proposal-header">
                  <div>
                    <p className="proposal-id">Proposal #{proposal.id}</p>
                    <h3>{proposal.title}</h3>
                  </div>
                  <button type="button">Create proof bundle</button>
                </div>
                <p>{proposal.description}</p>
                <dl>
                  <div>
                    <dt>Snapshot block</dt>
                    <dd>{formatNumber(proposal.snapshotBlock)}</dd>
                  </div>
                  <div>
                    <dt>Merkle root</dt>
                    <dd>{proposal.merkleRoot}</dd>
                  </div>
                  <div>
                    <dt>Delegated power</dt>
                    <dd>{formatNumber(proposal.delegatedVotingPower)}</dd>
                  </div>
                  <div>
                    <dt>Encrypted votes</dt>
                    <dd>{formatNumber(proposal.encryptedVotes)}</dd>
                  </div>
                </dl>
              </article>
            ))}
          </div>
        </div>

        <div className="panel">
          <div className="section-heading">
            <h2>Circuits</h2>
            <p>The contract verifies roots and nullifiers while off-chain provers generate witness data.</p>
          </div>
          <div className="circuit-list">
            {circuits.map((circuit) => (
              <article className="circuit-card" key={circuit.name}>
                <h3>{circuit.name}</h3>
                <p>{circuit.purpose}</p>
                <div className="chip-row">
                  {circuit.publicInputs.map((input) => (
                    <span className="chip" key={input}>
                      {input}
                    </span>
                  ))}
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
