pragma circom 2.1.8;

template TallyComputation(ballots) {
    signal input ciphertextX[ballots];
    signal input ciphertextY[ballots];

    signal output aggregateX;
    signal output aggregateY;
    signal output tallyCommitment;

    aggregateX <== 0;
    aggregateY <== 0;

    for (var i = 0; i < ballots; i++) {
        aggregateX <== aggregateX + ciphertextX[i];
        aggregateY <== aggregateY + ciphertextY[i];
    }

    tallyCommitment <== aggregateX + aggregateY + ballots;
}

component main = TallyComputation(64);
