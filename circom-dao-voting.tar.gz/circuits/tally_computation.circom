pragma circom 2.1.0;

include "../node_modules/circomlib/circuits/poseidon.circom";

template TallyComputation(nVoters) {
    signal input encryptedVotes[nVoters];
    signal input votingPowers[nVoters];
    signal input randomness;
    signal input decryptionKey;

    signal output totalFor;
    signal output totalAgainst;
    signal output totalAbstain;
    signal output tallyCommitment;

    signal partialFor[nVoters + 1];
    signal partialAgainst[nVoters + 1];
    signal partialAbstain[nVoters + 1];

    partialFor[0] <== 0;
    partialAgainst[0] <== 0;
    partialAbstain[0] <== 0;

    for (var i = 0; i < nVoters; i++) {
        partialFor[i + 1] <== partialFor[i] + votingPowers[i] * (encryptedVotes[i] === 1 ? 1 : 0);
        partialAgainst[i + 1] <== partialAgainst[i] + votingPowers[i] * (encryptedVotes[i] === 2 ? 1 : 0);
        partialAbstain[i + 1] <== partialAbstain[i] + votingPowers[i] * (encryptedVotes[i] === 3 ? 1 : 0);
    }

    totalFor <== partialFor[nVoters];
    totalAgainst <== partialAgainst[nVoters];
    totalAbstain <== partialAbstain[nVoters];

    component hashTally = Poseidon(3);
    hashTally.inputs[0] <== totalFor;
    hashTally.inputs[1] <== totalAgainst;
    hashTally.inputs[2] <== totalAbstain;
    tallyCommitment <== hashTally.out;
}

component main { public [decryptionKey] } = TallyComputation(4);
