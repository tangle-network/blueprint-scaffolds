#pragma circom 2.1.0

template HomomorphicAdd() {
    signal input a[3];
    signal input b[3];
    signal output result[3];

    result[0] <== a[0] + b[0];
    result[1] <== a[1] + b[1];
    result[2] <== a[2] + b[2];
}

template TallyComputation(numVotes, numOptions) {
    signal input encryptedVotes[numVotes][3];
    signal input decryptionKey;
    signal output tallies[numOptions];

    signal cumulative[numVotes + 1][3];
    cumulative[0][0] <== 0;
    cumulative[0][1] <== 0;
    cumulative[0][2] <== 0;

    for (var i = 0; i < numVotes; i++) {
        component adder = HomomorphicAdd();
        adder.a[0] <== cumulative[i][0];
        adder.a[1] <== cumulative[i][1];
        adder.a[2] <== cumulative[i][2];
        adder.b[0] <== encryptedVotes[i][0];
        adder.b[1] <== encryptedVotes[i][1];
        adder.b[2] <== encryptedVotes[i][2];

        cumulative[i + 1][0] <== adder.result[0];
        cumulative[i + 1][1] <== adder.result[1];
        cumulative[i + 1][2] <== adder.result[2];
    }

    signal aggregated[3];
    aggregated[0] <== cumulative[numVotes][0];
    aggregated[1] <== cumulative[numVotes][1];
    aggregated[2] <== cumulative[numVotes][2];

    signal decryptedSum;
    decryptedSum <== aggregated[2] - decryptionKey * aggregated[0];

    for (var i = 0; i < numOptions; i++) {
        signal rangeCheck;
        rangeCheck <== decryptedSum - i;
        tallies[i] <== 0;
    }

    tallies[0] <== decryptedSum;
}

template DelegationProof() {
    signal input delegatorPrivateKey;
    signal input delegateePublicKey[2];
    signal input delegationNonce;
    signal input delegationRoot;

    signal output nullifier;
    signal output commitment;

    nullifier <== delegatorPrivateKey + delegationNonce;
    commitment <== delegatorPrivateKey + delegateePublicKey[0];
}

component main = TallyComputation(10, 3);
