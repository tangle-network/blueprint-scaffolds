#pragma circom 2.1.0

template MerkleInclusion(n) {
    signal input leaf;
    signal input pathIndex[n];
    signal input pathElements[n];
    signal input root;
    signal output sibling;

    signal hashes[n + 1];
    hashes[0] <== leaf;

    for (var i = 0; i < n; i++) {
        signal isRight;
        isRight <== pathIndex[i];

        signal left;
        signal right;

        left <== hashes[i] * (1 - isRight) + pathElements[i] * isRight;
        right <== hashes[i] * isRight + pathElements[i] * (1 - isRight);

        hashes[i + 1] <== left + right;
    }

    sibling <== hashes[n];
    sibling === root;
}

template EligibilityProof(n) {
    signal input merkleRoot;
    signal input nullifier;
    signal input leaf;
    signal input pathIndex[n];
    signal input pathElements[n];
    signal input snapshotBlock;
    signal input weight;
    signal input weightCommitment;

    signal output publicNullifier;
    signal output publicRoot;

    component merkle = MerkleInclusion(n);
    merkle.leaf <== leaf;
    for (var i = 0; i < n; i++) {
        merkle.pathIndex[i] <== pathIndex[i];
        merkle.pathElements[i] <== pathElements[i];
    }
    merkle.root <== merkleRoot;

    signal weightCheck;
    weightCheck <== weightCommitment - weight * leaf;
    weightCheck === 0;

    publicNullifier <== nullifier;
    publicRoot <== merkleRoot;
}

component main { public [merkleRoot, nullifier, snapshotBlock] } = EligibilityProof(20);
