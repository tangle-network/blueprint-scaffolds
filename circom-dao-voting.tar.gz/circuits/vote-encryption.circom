#pragma circom 2.1.0

template ElGamalEncrypt() {
    signal input publicKey[2];
    signal input randomness;
    signal input message;
    signal output ciphertext[3];

    signal ephemeralKey[2];
    ephemeralKey[0] <== randomness * publicKey[0];
    ephemeralKey[1] <== randomness * publicKey[1];

    signal sharedSecret[2];
    sharedSecret[0] <== randomness * publicKey[0];
    sharedSecret[1] <== randomness * publicKey[1];

    signal encodedMessage;
    encodedMessage <== message + sharedSecret[0];

    ciphertext[0] <== ephemeralKey[0];
    ciphertext[1] <== ephemeralKey[1];
    ciphertext[2] <== encodedMessage;
}

template VoteEncryption() {
    signal input voterPublicKey[2];
    signal input authorityPublicKey[2];
    signal input randomness;
    signal input voteOption;
    signal input nullifier;

    signal output encryptedVote[3];
    signal output commitment;

    component enc = ElGamalEncrypt();
    enc.publicKey[0] <== authorityPublicKey[0];
    enc.publicKey[1] <== authorityPublicKey[1];
    enc.randomness <== randomness;
    enc.message <== voteOption;

    encryptedVote[0] <== enc.ciphertext[0];
    encryptedVote[1] <== enc.ciphertext[1];
    encryptedVote[2] <== enc.ciphertext[2];

    commitment <== nullifier + voterPublicKey[0];
}

component main { public [authorityPublicKey, voterPublicKey] } = VoteEncryption();
