pragma circom 2.1.8;

include "circomlib/comparators.circom";

template VoteEncryption() {
    signal input vote;
    signal input randomness;
    signal input publicKeyX;
    signal input publicKeyY;
    signal input proposalId;

    signal output ciphertextX;
    signal output ciphertextY;
    signal output commitment;

    component isBinary = IsEqual();
    isBinary.in[0] <== vote * (vote - 1);
    isBinary.in[1] <== 0;
    isBinary.out === 1;

    ciphertextX <== publicKeyX + randomness;
    ciphertextY <== publicKeyY + (vote * randomness) + proposalId;
    commitment <== ciphertextX + ciphertextY + vote;
}

component main = VoteEncryption();
