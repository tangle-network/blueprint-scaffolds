pragma circom 2.1.0;

include "../node_modules/circomlib/circuits/poseidon.circom";
include "../node_modules/circomlib/circuits/eddsaposeidon.circom";

template VoteEncryption() {
    signal input voteChoice;
    signal input randomness;
    signal input nullifier;
    signal input votingPower;
    signal input encryptedVote;
    signal input encryptionKey;

    signal output commitment;
    signal output nullifierHash;

    component hashNullifier = Poseidon(1);
    hashNullifier.inputs[0] <== nullifier;
    nullifierHash <== hashNullifier.out;

    component hashCommit = Poseidon(3);
    hashCommit.inputs[0] <== voteChoice;
    hashCommit.inputs[1] <== randomness;
    hashCommit.inputs[2] <== nullifier;
    commitment <== hashCommit.out;

    assert(voteChoice === 0 || voteChoice === 1);
    assert(votingPower > 0);
}

component main { public [encryptionKey] } = VoteEncryption();
