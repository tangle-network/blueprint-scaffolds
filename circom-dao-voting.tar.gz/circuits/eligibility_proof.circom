pragma circom 2.1.0;

include "../node_modules/circomlib/circuits/poseidon.circom";
include "../node_modules/circomlib/circuits/eddsaposeidon.circom";

template EligibilityProof() {
    signal input identitySecret;
    signal input merkleProof[10];
    signal input merkleRoot;
    signal input snapshotBlock;
    signal input tokenBalance;
    signal input delegatedFrom;
    signal input nullifier;

    signal output nullifierHash;
    signal output commitment;

    component hashNullifier = Poseidon(2);
    hashNullifier.inputs[0] <== identitySecret;
    hashNullifier.inputs[1] <== nullifier;
    nullifierHash <== hashNullifier.out;

    component hashIdentity = Poseidon(1);
    hashIdentity.inputs[0] <== identitySecret;

    signal identityLeaf;
    identityLeaf <== hashIdentity.out;

    signal computedRoot;
    computedRoot <== identityLeaf;

    for (var i = 0; i < 10; i++) {
        component hash = Poseidon(2);
        hash.inputs[0] <== computedRoot;
        hash.inputs[1] <== merkleProof[i];
        computedRoot <== hash.out;
    }

    computedRoot === merkleRoot;

    assert(tokenBalance >= 0);

    component hashCommit = Poseidon(2);
    hashCommit.inputs[0] <== merkleRoot;
    hashCommit.inputs[1] <== snapshotBlock;
    commitment <== hashCommit.out;
}

component main { public [merkleRoot, snapshotBlock, nullifier] } = EligibilityProof();
