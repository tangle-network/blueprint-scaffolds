pragma circom 2.1.8;

template EligibilityProof(depth) {
    signal input leaf;
    signal input pathElements[depth];
    signal input pathIndices[depth];
    signal input proposalId;
    signal input snapshotRoot;

    signal output nullifier;
    signal output leafCommitment;

    signal hash[depth + 1];
    hash[0] <== leaf;

    for (var i = 0; i < depth; i++) {
        signal left;
        signal right;

        left <== hash[i] + (pathIndices[i] * (pathElements[i] - hash[i]));
        right <== pathElements[i] + (pathIndices[i] * (hash[i] - pathElements[i]));
        hash[i + 1] <== left + right;
    }

    hash[depth] === snapshotRoot;
    nullifier <== leaf + proposalId;
    leafCommitment <== leaf + snapshotRoot;
}

component main = EligibilityProof(20);
