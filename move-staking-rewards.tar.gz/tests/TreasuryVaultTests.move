module move-staking-rewards::TreasuryVaultTests {
    use move-staking-rewards::TreasuryVault;

    #[test(account = @move-staking-rewards)]
    fun initializes_balance(account: signer) {
        TreasuryVault::initialize(&account);
        assert!(TreasuryVault::balance(@move-staking-rewards) == 0, 0);
    }
}
