# AGENTS.md

## Goal

Build a staking platform on Aptos with multiple reward mechanisms. Stake/unstake, reward distribution, delegation.

## Stack

- Family: `move-contracts`
- Layers: `capability:move-staking`

## Entry Points

- `Move.toml`
- `sources/TreasuryVault.move`
- `tests/TreasuryVaultTests.move`

## Commands

- `aptos move test`
- `sui move test`

## Build Plan

Components: StakePool, RewardDistributor, BoostModule
Data models: Stake, Reward, BoostMultiplier
Integrations: Reward distribution, Delegation, Boost multipliers

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
