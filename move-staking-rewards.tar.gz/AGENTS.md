# AGENTS.md

Build a staking platform on Aptos with multiple reward mechanisms. Stake/unstake, reward distribution, delegation.

## What's here

This project was scaffolded by starter-foundry. The user's prompt drove the choices below — read their prompt first, it takes priority over everything in this file.

- **Family:** `move-contracts`
- **Layers:** `framework:move-package`, `capability:move-staking`

## Getting started

```bash
aptos move test
sui move test
```

Key files: `Move.toml`, `sources/TreasuryVault.move`, `tests/TreasuryVaultTests.move`

## Suggested build plan

These are starting points — adapt them to the user's actual needs.

- **Components:** StakePool, RewardDistributor, BoostModule
- **Data models:** Stake, Reward, BoostMultiplier
- **Integrations:** Reward distribution, Delegation, Boost multipliers

## How to use this scaffold

This is a starting point, not a contract. You own every file.

- **Customize freely.** Replace components, change the layout, swap the color scheme — whatever fits the user's product.
- **The scaffold saves you setup time** — Tailwind, shadcn/ui, path aliases, and framework config are ready. Don't redo them.
- **Check `.starter-foundry/compose-report.json`** if you want to see which layer wrote which file.
- **Update this file** as the project evolves. Delete sections that no longer apply.
