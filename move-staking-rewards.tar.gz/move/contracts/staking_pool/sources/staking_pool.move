module staking::staking_pool {
    use std::signer;
    use aptos_framework::coin::{Self, Coin};
    use aptos_framework::timestamp;

    struct StakingPool<phantom StakingToken> has key {
        total_staked: u64,
        reward_rate_per_second: u64,
        last_reward_timestamp: u64,
        accumulated_reward_per_share: u64,
        total_delegators: u64,
        paused: bool,
    }

    struct StakePosition has store {
        amount: u64,
        start_timestamp: u64,
        lock_end_timestamp: u64,
        lock_tier: u8,
        accumulated_reward_checkpoint: u64,
        pending_rewards: u64,
        boost_multiplier: u64,
    }

    struct UserStake<phantom StakingToken> has key {
        positions: vector<StakePosition>,
    }

    struct PoolCreatorCapability has key, store {}

    const ERROR_POOL_NOT_INITIALIZED: u64 = 100;
    const ERROR_INSUFFICIENT_STAKE: u64 = 101;
    const ERROR_LOCK_NOT_EXPIRED: u64 = 102;
    const ERROR_POOL_PAUSED: u64 = 103;
    const ERROR_INVALID_LOCK_TIER: u64 = 104;
    const ERROR_ZERO_AMOUNT: u64 = 105;

    const LOCK_TIER_NONE: u8 = 0;
    const LOCK_TIER_30_DAYS: u8 = 1;
    const LOCK_TIER_90_DAYS: u8 = 2;
    const LOCK_TIER_180_DAYS: u8 = 3;
    const LOCK_TIER_365_DAYS: u8 = 4;

    const BOOST_NONE: u64 = 100;
    const BOOST_30_DAYS: u64 = 120;
    const BOOST_90_DAYS: u64 = 150;
    const BOOST_180_DAYS: u64 = 200;
    const BOOST_365_DAYS: u64 = 300;

    public entry fun initialize<StakingToken>(account: &signer) {
        let account_addr = signer::address_of(account);
        assert!(!exists<StakingPool<StakingToken>>(account_addr), 0);
        move_to(account, StakingPool<StakingToken> {
            total_staked: 0,
            reward_rate_per_second: 0,
            last_reward_timestamp: timestamp::now_seconds(),
            accumulated_reward_per_share: 0,
            total_delegators: 0,
            paused: false,
        });
        move_to(account, PoolCreatorCapability {});
    }

    public entry fun set_reward_rate<StakingToken>(
        admin: &signer,
        new_rate: u64,
    ) acquires StakingPool, PoolCreatorCapability {
        let admin_addr = signer::address_of(admin);
        assert!(exists<PoolCreatorCapability>(admin_addr), 1);
        let pool = borrow_global_mut<StakingPool<StakingToken>>(admin_addr);
        update_pool_reward<StakingToken>(admin_addr);
        pool.reward_rate_per_second = new_rate;
    }

    public entry fun stake<StakingToken>(
        user: &signer,
        amount: u64,
        lock_tier: u8,
    ) acquires StakingPool, UserStake {
        assert!(amount > 0, ERROR_ZERO_AMOUNT);
        let user_addr = signer::address_of(user);
        let pool_addr = get_pool_address<StakingToken>();

        update_pool_reward<StakingToken>(pool_addr);
        let pool = borrow_global_mut<StakingPool<StakingToken>>(pool_addr);
        assert!(!pool.paused, ERROR_POOL_PAUSED);

        let (lock_duration, boost) = get_lock_config(lock_tier);

        if (!exists<UserStake<StakingToken>>(user_addr)) {
            move_to(user, UserStake<StakingToken> { positions: vector::empty() });
        };

        let user_stake = borrow_global_mut<UserStake<StakingToken>>(user_addr);
        let now = timestamp::now_seconds();
        let position = StakePosition {
            amount,
            start_timestamp: now,
            lock_end_timestamp: now + lock_duration,
            lock_tier,
            accumulated_reward_checkpoint: pool.accumulated_reward_per_share,
            pending_rewards: 0,
            boost_multiplier: boost,
        };
        vector::push_back(&mut user_stake.positions, position);

        coin::transfer<StakingToken>(user, pool_addr, amount);
        pool.total_staked = pool.total_staked + amount;
    }

    public entry fun unstake<StakingToken>(
        user: &signer,
        position_index: u64,
    ) acquires StakingPool, UserStake {
        let user_addr = signer::address_of(user);
        let pool_addr = get_pool_address<StakingToken>();

        update_pool_reward<StakingToken>(pool_addr);
        let pool = borrow_global_mut<StakingPool<StakingToken>>(pool_addr);
        let user_stake = borrow_global_mut<UserStake<StakingToken>>(user_addr);

        assert!(position_index < vector::length(&user_stake.positions), ERROR_INSUFFICIENT_STAKE);
        let position = vector::borrow_mut(&mut user_stake.positions, position_index);

        let now = timestamp::now_seconds();
        assert!(now >= position.lock_end_timestamp, ERROR_LOCK_NOT_EXPIRED);

        let reward = calculate_pending_rewards(position, pool.accumulated_reward_per_share);
        let amount = position.amount;
        pool.total_staked = pool.total_staked - amount;

        vector::remove(&mut user_stake.positions, position_index);

        coin::transfer<StakingToken>(signer::address_of(&create_signer_at(pool_addr)), user_addr, amount);
    }

    public entry fun claim_rewards<StakingToken>(
        user: &signer,
        position_index: u64,
    ) acquires StakingPool, UserStake {
        let user_addr = signer::address_of(user);
        let pool_addr = get_pool_address<StakingToken>();
        update_pool_reward<StakingToken>(pool_addr);
        let pool = borrow_global_mut<StakingPool<StakingToken>>(pool_addr);
        let user_stake = borrow_global_mut<UserStake<StakingToken>>(user_addr);
        let position = vector::borrow_mut(&mut user_stake.positions, position_index);
        let reward = calculate_pending_rewards(position, pool.accumulated_reward_per_share);
        position.accumulated_reward_checkpoint = pool.accumulated_reward_per_share;
        position.pending_rewards = 0;
    }

    public entry fun emergency_withdraw<StakingToken>(
        user: &signer,
        position_index: u64,
    ) acquires StakingPool, UserStake {
        let user_addr = signer::address_of(user);
        let pool_addr = get_pool_address<StakingToken>();
        let pool = borrow_global_mut<StakingPool<StakingToken>>(pool_addr);
        let user_stake = borrow_global_mut<UserStake<StakingToken>>(user_addr);

        assert!(position_index < vector::length(&user_stake.positions), ERROR_INSUFFICIENT_STAKE);
        let position = vector::borrow_mut(&mut user_stake.positions, position_index);
        let amount = position.amount * 90 / 100;
        pool.total_staked = pool.total_staked - position.amount;

        vector::remove(&mut user_stake.positions, position_index);

        coin::transfer<StakingToken>(signer::address_of(&create_signer_at(pool_addr)), user_addr, amount);
    }

    fun update_pool_reward<StakingToken>(pool_addr: address) acquires StakingPool {
        let pool = borrow_global_mut<StakingPool<StakingToken>>(pool_addr);
        let now = timestamp::now_seconds();
        if (now <= pool.last_reward_timestamp) { return };
        if (pool.total_staked == 0) {
            pool.last_reward_timestamp = now;
            return;
        };
        let elapsed = now - pool.last_reward_timestamp;
        let reward = elapsed * pool.reward_rate_per_second;
        pool.accumulated_reward_per_share = pool.accumulated_reward_per_share + (reward * 1e8 / pool.total_staked);
        pool.last_reward_timestamp = now;
    }

    fun calculate_pending_rewards(position: &StakePosition, acc_reward_per_share: u64): u64 {
        (position.amount * (acc_reward_per_share - position.accumulated_reward_checkpoint) * position.boost_multiplier / 100) / 1e8 + position.pending_rewards
    }

    fun get_lock_config(lock_tier: u8): (u64, u64) {
        if (lock_tier == LOCK_TIER_NONE) { (0, BOOST_NONE) }
        else if (lock_tier == LOCK_TIER_30_DAYS) { (2592000, BOOST_30_DAYS) }
        else if (lock_tier == LOCK_TIER_90_DAYS) { (7776000, BOOST_90_DAYS) }
        else if (lock_tier == LOCK_TIER_180_DAYS) { (15552000, BOOST_180_DAYS) }
        else if (lock_tier == LOCK_TIER_365_DAYS) { (31536000, BOOST_365_DAYS) }
        else { abort ERROR_INVALID_LOCK_TIER }
    }

    fun get_pool_address<StakingToken>(): address {
        @staking
    }

    #[view]
    public fun get_pool_info<StakingToken>(): (u64, u64, u64, bool) acquires StakingPool {
        let pool = borrow_global<StakingPool<StakingToken>>(get_pool_address<StakingToken>());
        (pool.total_staked, pool.reward_rate_per_second, pool.accumulated_reward_per_share, pool.paused)
    }

    #[view]
    public fun get_user_positions<StakingToken>(user: address): vector<StakePosition> acquires UserStake {
        if (!exists<UserStake<StakingToken>>(user)) {
            return vector::empty<StakePosition>()
        };
        let user_stake = borrow_global<UserStake<StakingToken>>(user);
        user_stake.positions
    }
}
