module vault::auto_compound_vault {
    use std::signer;
    use aptos_framework::coin::{Self, Coin};
    use aptos_framework::timestamp;

    struct Vault<phantom Token> has key {
        total_deposits: u64,
        total_shares: u64,
        last_compound: u64,
        compound_interval: u64,
        performance_fee_bps: u64,
        reward_rate_per_second: u64,
    }

    struct VaultShare<phantom Token> has key {
        shares: u64,
        deposit_amount: u64,
    }

    const ERROR_ZERO_DEPOSIT: u64 = 100;
    const BPS_DENOMINATOR: u64 = 10000;

    public entry fun initialize<Token>(account: &signer) {
        move_to(account, Vault<Token> {
            total_deposits: 0,
            total_shares: 0,
            last_compound: timestamp::now_seconds(),
            compound_interval: 86400,
            performance_fee_bps: 1000,
            reward_rate_per_second: 0,
        });
    }

    public entry fun deposit<Token>(user: &signer, amount: u64) acquires Vault, VaultShare {
        assert!(amount > 0, ERROR_ZERO_DEPOSIT);
        let user_addr = signer::address_of(user);
        let vault_addr = @vault;

        maybe_compound<Token>(vault_addr);
        let vault = borrow_global_mut<Vault<Token>>(vault_addr);
        let shares = if (vault.total_shares == 0) { amount } else { amount * vault.total_shares / vault.total_deposits };
        vault.total_deposits = vault.total_deposits + amount;
        vault.total_shares = vault.total_shares + shares;

        if (!exists<VaultShare<Token>>(user_addr)) {
            move_to(user, VaultShare<Token> { shares: 0, deposit_amount: 0 })
        };
        let user_share = borrow_global_mut<VaultShare<Token>>(user_addr);
        user_share.shares = user_share.shares + shares;
        user_share.deposit_amount = user_share.deposit_amount + amount;

        coin::transfer<Token>(user, vault_addr, amount);
    }

    public entry fun withdraw<Token>(user: &signer, share_amount: u64) acquires Vault, VaultShare {
        assert!(share_amount > 0, ERROR_ZERO_DEPOSIT);
        let user_addr = signer::address_of(user);
        let vault_addr = @vault;

        maybe_compound<Token>(vault_addr);
        let vault = borrow_global_mut<Vault<Token>>(vault_addr);
        let user_share = borrow_global_mut<VaultShare<Token>>(user_addr);
        assert!(user_share.shares >= share_amount, 101);

        let amount = share_amount * vault.total_deposits / vault.total_shares;
        vault.total_deposits = vault.total_deposits - amount;
        vault.total_shares = vault.total_shares - share_amount;
        user_share.shares = user_share.shares - share_amount;

        coin::transfer<Token>(signer::address_of(&create_signer_at(vault_addr)), user_addr, amount);
    }

    public entry fun compound<Token>(_admin: &signer) acquires Vault {
        maybe_compound<Token>(@vault);
    }

    fun maybe_compound<Token>(vault_addr: address) acquires Vault {
        let vault = borrow_global_mut<Vault<Token>>(vault_addr);
        let now = timestamp::now_seconds();
        if (now - vault.last_compound < vault.compound_interval) { return };
        let elapsed = now - vault.last_compound;
        let reward = elapsed * vault.reward_rate_per_second;
        let fee = reward * vault.performance_fee_bps / BPS_DENOMINATOR;
        vault.total_deposits = vault.total_deposits + reward - fee;
        vault.last_compound = now;
    }

    #[view]
    public fun get_vault_info<Token>(): (u64, u64, u64, u64) acquires Vault {
        let vault = borrow_global<Vault<Token>>(@vault);
        (vault.total_deposits, vault.total_shares, vault.compound_interval, vault.performance_fee_bps)
    }
}
