module ve::ve_token {
    use std::signer;
    use aptos_framework::timestamp;

    struct VeToken has key {
        total_supply: u64,
    }

    struct VeTokenBalance has key, store {
        amount: u64,
        lock_end: u64,
        original_amount: u64,
    }

    public entry fun initialize(account: &signer) {
        move_to(account, VeToken { total_supply: 0 });
    }

    public entry fun lock(account: &signer, amount: u64, lock_duration_seconds: u64) acquires VeToken, VeTokenBalance {
        let addr = signer::address_of(account);
        let now = timestamp::now_seconds();
        let ve_amount = amount * lock_duration_seconds / (365 * 24 * 3600);
        assert!(ve_amount > 0, 1);

        let ve_store = borrow_global_mut<VeToken>(@ve);
        ve_store.total_supply = ve_store.total_supply + ve_amount;

        if (!exists<VeTokenBalance>(addr)) {
            move_to(account, VeTokenBalance { amount: ve_amount, lock_end: now + lock_duration_seconds, original_amount: amount })
        } else {
            let balance = borrow_global_mut<VeTokenBalance>(addr);
            balance.amount = balance.amount + ve_amount;
            balance.lock_end = now + lock_duration_seconds;
            balance.original_amount = balance.original_amount + amount;
        }
    }

    public entry fun increase_lock_time(account: &signer, additional_seconds: u64) acquires VeToken, VeTokenBalance {
        let addr = signer::address_of(account);
        assert!(exists<VeTokenBalance>(addr), 2);
        let balance = borrow_global_mut<VeTokenBalance>(addr);
        let now = timestamp::now_seconds();
        assert!(balance.lock_end > now, 3);
        let old_ve = balance.amount;
        let new_duration = balance.lock_end - now + additional_seconds;
        let new_ve = balance.original_amount * new_duration / (365 * 24 * 3600);
        let delta = new_ve - old_ve;
        balance.amount = new_ve;
        balance.lock_end = balance.lock_end + additional_seconds;
        let ve_store = borrow_global_mut<VeToken>(@ve);
        ve_store.total_supply = ve_store.total_supply + delta;
    }

    #[view]
    public fun get_balance(addr: address): (u64, u64, u64) acquires VeTokenBalance {
        if (!exists<VeTokenBalance>(addr)) { return (0, 0, 0) };
        let b = borrow_global<VeTokenBalance>(addr);
        (b.amount, b.lock_end, b.original_amount)
    }

    #[view]
    public fun get_total_supply(): u64 acquires VeToken {
        borrow_global<VeToken>(@ve).total_supply
    }
}
