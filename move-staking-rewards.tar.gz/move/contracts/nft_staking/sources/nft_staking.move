module nft_staking::nft_staking {
    use std::signer;
    use aptos_framework::timestamp;
    use aptos_framework::object::{Self, Object};

    struct NftStakingPool has key {
        total_staked: u64,
        reward_rate_per_second: u64,
        last_update: u64,
        acc_reward_per_share: u64,
    }

    struct NftPosition has store {
        nft_id: address,
        stake_time: u64,
        tier: u8,
        boost: u64,
    }

    struct UserNftStake has key {
        positions: vector<NftPosition>,
    }

    public entry fun initialize(account: &signer) {
        move_to(account, NftStakingPool {
            total_staked: 0,
            reward_rate_per_second: 0,
            last_update: timestamp::now_seconds(),
            acc_reward_per_share: 0,
        });
    }

    public entry fun stake_nft(user: &signer, nft_id: address, tier: u8) acquires NftStakingPool, UserNftStake {
        let user_addr = signer::address_of(user);
        let pool_addr = @nft_staking;
        let now = timestamp::now_seconds();

        let pool = borrow_global_mut<NftStakingPool>(pool_addr);
        if (pool.total_staked > 0) {
            let elapsed = now - pool.last_update;
            pool.acc_reward_per_share = pool.acc_reward_per_share + elapsed * pool.reward_rate_per_second * 1e8 / pool.total_staked;
        };
        pool.last_update = now;
        pool.total_staked = pool.totalaked + 1;

        let boost = if (tier == 1) { 100 } else if (tier == 2) { 150 } else if (tier == 3) { 250 } else { 100 };

        if (!exists<UserNftStake>(user_addr)) {
            move_to(user, UserNftStake { positions: vector::empty() })
        };
        let user_stake = borrow_global_mut<UserNftStake>(user_addr);
        vector::push_back(&mut user_stake.positions, NftPosition {
            nft_id,
            stake_time: now,
            tier,
            boost,
        });

        object::transfer(user, nft_id, pool_addr);
    }

    public entry fun unstake_nft(user: &signer, position_index: u64) acquires NftStakingPool, UserNftStake {
        let user_addr = signer::address_of(user);
        let pool = borrow_global_mut<NftStakingPool>(@nft_staking);
        let user_stake = borrow_global_mut<UserNftStake>(user_addr);
        assert!(position_index < vector::length(&user_stake.positions), 1);
        let pos = vector::borrow_mut(&mut user_stake.positions, position_index);
        let nft_id = pos.nft_id;
        vector::remove(&mut user_stake.positions, position_index);
        pool.total_staked = pool.total_staked - 1;
        object::transfer(signer::address_of(&create_signer_at(@nft_staking)), nft_id, user_addr);
    }
}
