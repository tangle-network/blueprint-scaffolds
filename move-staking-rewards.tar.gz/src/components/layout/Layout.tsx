import { Navbar, Sidebar, MobileNav } from "./Navbar"
import type { ReactNode } from "react"

interface LayoutProps {
  children: ReactNode
  connected: boolean
  address: string | null
  balance: number
  connecting: boolean
  onConnect: () => void
  onDisconnect: () => void
}

export function Layout({ children, connected, address, balance, connecting, onConnect, onDisconnect }: LayoutProps) {
  return (
    <div className="min-h-screen bg-background">
      <Navbar
        connected={connected}
        address={address}
        balance={balance}
        connecting={connecting}
        onConnect={onConnect}
        onDisconnect={onDisconnect}
      />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 container px-4 py-6 pb-20 md:pb-6">{children}</main>
      </div>
      <MobileNav />
    </div>
  )
}
