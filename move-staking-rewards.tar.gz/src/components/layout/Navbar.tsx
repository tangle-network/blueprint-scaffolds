import { Link, useLocation } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { formatAddress, formatTokenAmount } from "@/lib/utils"
import { Wallet, LogOut, Coins, Layers, BarChart3, Image, Shield, Vault, Server } from "lucide-react"

interface NavbarProps {
  connected: boolean
  address: string | null
  balance: number
  connecting: boolean
  onConnect: () => void
  onDisconnect: () => void
}

export function Navbar({ connected, address, balance, connecting, onConnect, onDisconnect }: NavbarProps) {
  return (
    <header className="sticky top-0 z-40 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <Coins className="h-6 w-6 text-primary" />
          <Link to="/" className="text-xl font-bold">
            Aptos Stake
          </Link>
        </div>
        <div className="flex items-center gap-4">
          {connected ? (
            <>
              <div className="hidden sm:flex items-center gap-2 rounded-md border px-3 py-1.5 text-sm">
                <span className="text-muted-foreground">Balance:</span>
                <span className="font-medium">{formatTokenAmount(balance)} APT</span>
              </div>
              <div className="flex items-center gap-2 rounded-md border px-3 py-1.5 text-sm">
                <Wallet className="h-4 w-4 text-muted-foreground" />
                <span>{formatAddress(address!)}</span>
              </div>
              <Button variant="ghost" size="icon" onClick={onDisconnect}>
                <LogOut className="h-4 w-4" />
              </Button>
            </>
          ) : (
            <Button onClick={onConnect} disabled={connecting}>
              <Wallet className="mr-2 h-4 w-4" />
              {connecting ? "Connecting..." : "Connect Wallet"}
            </Button>
          )}
        </div>
      </div>
    </header>
  )
}

const NAV_ITEMS = [
  { path: "/", label: "Pools", icon: Layers },
  { path: "/stake", label: "Stake", icon: Coins },
  { path: "/rewards", label: "Rewards", icon: BarChart3 },
  { path: "/nft", label: "NFT Stake", icon: Image },
  { path: "/vetoken", label: "veToken", icon: Shield },
  { path: "/vaults", label: "Vaults", icon: Vault },
  { path: "/delegate", label: "Delegate", icon: Server },
]

export function Sidebar() {
  const location = useLocation()
  return (
    <aside className="hidden md:flex w-64 flex-col border-r bg-card min-h-[calc(100vh-4rem)]">
      <nav className="flex flex-col gap-1 p-4">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon
          const active = location.pathname === item.path
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                active
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              }`}
            >
              <Icon className="h-4 w-4" />
              {item.label}
            </Link>
          )
        })}
      </nav>
    </aside>
  )
}

export function MobileNav() {
  const location = useLocation()
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 border-t bg-background">
      <div className="flex justify-around py-2">
        {NAV_ITEMS.slice(0, 5).map((item) => {
          const Icon = item.icon
          const active = location.pathname === item.path
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex flex-col items-center gap-1 px-2 py-1 text-xs ${
                active ? "text-primary" : "text-muted-foreground"
              }`}
            >
              <Icon className="h-5 w-5" />
              {item.label}
            </Link>
          )
        })}
      </div>
    </nav>
  )
}
