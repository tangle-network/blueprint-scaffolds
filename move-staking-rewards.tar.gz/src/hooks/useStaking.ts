import { useState, useCallback } from "react"
import type { PoolInfo, StakePosition, LockTier } from "@/types"
import { MOCK_POOLS, getMockUserPositions } from "@/lib/aptos"

export function usePools() {
  const [pools] = useState<PoolInfo[]>(MOCK_POOLS)

  const getPool = useCallback(
    (id: string) => pools.find((p) => p.id === id),
    [pools]
  )

  return { pools, getPool }
}

export function useStaking() {
  const [positions, setPositions] = useState<StakePosition[]>(getMockUserPositions())
  const [txPending, setTxPending] = useState(false)

  const stake = useCallback(
    async (poolId: string, amount: number, lockTier: number) => {
      setTxPending(true)
      await new Promise((r) => setTimeout(r, 1500))
      const pool = MOCK_POOLS.find((p) => p.id === poolId)
      if (!pool) { setTxPending(false); return }
      const tier = pool.lockTiers.find((t) => t.tier === lockTier) as LockTier | undefined
      setPositions((prev) => [
        ...prev,
        {
          id: `pos-${Date.now()}`,
          poolId,
          amount,
          stakingToken: pool.stakingToken,
          startTimestamp: Date.now() / 1000,
          lockEndTimestamp: Date.now() / 1000 + (tier?.days ?? 0) * 86400,
          lockTier,
          boostMultiplier: tier?.boostMultiplier ?? 1.0,
          pendingRewards: pool.rewardTokens.map((t) => ({ token: t, amount: 0 })),
          isActive: true,
        },
      ])
      setTxPending(false)
    },
    []
  )

  const unstake = useCallback(async (positionId: string) => {
    setTxPending(true)
    await new Promise((r) => setTimeout(r, 1500))
    setPositions((prev) => prev.filter((p) => p.id !== positionId))
    setTxPending(false)
  }, [])

  const claimRewards = useCallback(async (positionId: string) => {
    setTxPending(true)
    await new Promise((r) => setTimeout(r, 1000))
    setPositions((prev) =>
      prev.map((p) =>
        p.id === positionId
          ? { ...p, pendingRewards: p.pendingRewards.map((r) => ({ ...r, amount: 0 })) }
          : p
      )
    )
    setTxPending(false)
  }, [])

  const emergencyWithdraw = useCallback(async (positionId: string) => {
    setTxPending(true)
    await new Promise((r) => setTimeout(r, 1500))
    setPositions((prev) => prev.filter((p) => p.id !== positionId))
    setTxPending(false)
  }, [])

  const claimAllRewards = useCallback(async () => {
    setTxPending(true)
    await new Promise((r) => setTimeout(r, 2000))
    setPositions((prev) =>
      prev.map((p) => ({ ...p, pendingRewards: p.pendingRewards.map((r) => ({ ...r, amount: 0 })) }))
    )
    setTxPending(false)
  }, [])

  return { positions, txPending, stake, unstake, claimRewards, emergencyWithdraw, claimAllRewards }
}
