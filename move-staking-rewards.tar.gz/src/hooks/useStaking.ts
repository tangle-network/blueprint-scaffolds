import { useState, useEffect, useCallback } from 'react';
import type { PoolInfo, UserStake, LockTier } from '../types';
import { MOCK_POOLS } from '../utils/formatting';

export function usePools() {
  const [pools, setPools] = useState<PoolInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'single' | 'lp' | 'nft'>('all');

  useEffect(() => {
    const timer = setTimeout(() => {
      setPools(MOCK_POOLS);
      setLoading(false);
    }, 600);
    return () => clearTimeout(timer);
  }, []);

  const filteredPools = pools.filter((p: PoolInfo) => filter === 'all' || p.type === filter);
  return { pools: filteredPools, allPools: pools, loading, filter, setFilter };
}

export function useUserStakes(poolId?: string) {
  const [stakes, setStakes] = useState<UserStake[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (poolId) {
        setStakes<UserStake[]>([{
          poolId: poolId!,
          stakedAmount: '50000000000',
          stakeTokenSymbol: 'APT',
          lockTier: '90d' as LockTier,
          lockEnd: Date.now() + 86400000 * 60,
          pendingRewards: [
            { tokenSymbol: 'APT', tokenAddress: '0x1::aptos_coin::AptosCoin', amount: '12500000', decimals: 8 },
            { tokenSymbol: 'USDT', tokenAddress: '0x1::usdt::USDT', amount: '500000', decimals: 6 },
          ],
          boostMultiplier: 1.6,
          depositTime: Date.now() - 86400000 * 30,
        }]);
      } else {
        setStakes([]);
      }
      setLoading(false);
    }, 400);
    return () => clearTimeout(timer);
  }, [poolId]);

  const totalStakedValue = stakes.reduce((acc: number, s: UserStake) => acc + parseFloat(s.stakedAmount) / 1e8, 0);
  const totalPendingRewards = stakes.flatMap((s: UserStake) => s.pendingRewards);
  return { stakes, loading, totalStakedValue, totalPendingRewards };
}

export function usePoolActions(poolId: string) {
  const [txStatus, setTxStatus] = useState<'idle' | 'pending' | 'success' | 'error'>('idle');
  const [txHash, setTxHash] = useState<string | null>(null);

  const executeAction = useCallback(async (_action: string, _params: Record<string, string> = {}) => {
    setTxStatus('pending');
    try {
      await new Promise(r => setTimeout(r, 1500));
      const hash = '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
      setTxHash(hash);
      setTxStatus('success');
      return hash;
    } catch {
      setTxStatus('error');
      throw new Error('Transaction failed');
    }
  }, [poolId]);

  const reset = useCallback(() => { setTxStatus('idle'); setTxHash(null); }, []);
  return { executeAction, txStatus, txHash, reset };
}
