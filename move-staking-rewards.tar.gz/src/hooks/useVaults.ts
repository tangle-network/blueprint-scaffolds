import { useState, useEffect, useCallback } from 'react';
import type { VaultInfo } from '../types';
import { MOCK_VAULTS } from '../utils/formatting';

export function useVaults() {
  const [vaults, setVaults] = useState<VaultInfo[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setVaults(MOCK_VAULTS);
      setLoading(false);
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  return { vaults, loading };
}

export function useVaultActions(vaultId: string) {
  const [txStatus, setTxStatus] = useState<'idle' | 'pending' | 'success' | 'error'>('idle');

  const deposit = useCallback(async (_amount: string) => {
    setTxStatus('pending');
    await new Promise(r => setTimeout(r, 1500));
    setTxStatus('success');
  }, [vaultId]);

  const withdraw = useCallback(async (_shares: string) => {
    setTxStatus('pending');
    await new Promise(r => setTimeout(r, 1500));
    setTxStatus('success');
  }, [vaultId]);

  const harvest = useCallback(async () => {
    setTxStatus('pending');
    await new Promise(r => setTimeout(r, 1500));
    setTxStatus('success');
  }, [vaultId]);

  return { deposit, withdraw, harvest, txStatus };
}
