import { useState, useCallback } from "react"

interface WalletState {
  connected: boolean
  address: string | null
  balance: number
  connecting: boolean
}

export function useWallet() {
  const [wallet, setWallet] = useState<WalletState>({
    connected: false,
    address: null,
    balance: 0,
    connecting: false,
  })

  const connect = useCallback(async () => {
    setWallet((prev) => ({ ...prev, connecting: true }))
    await new Promise((r) => setTimeout(r, 800))
    setWallet({
      connected: true,
      address: "0x1234abcd5678efgh9012ijkl3456mnop7890qrst",
      balance: 1250.75,
      connecting: false,
    })
  }, [])

  const disconnect = useCallback(() => {
    setWallet({ connected: false, address: null, balance: 0, connecting: false })
  }, [])

  return { ...wallet, connect, disconnect }
}
