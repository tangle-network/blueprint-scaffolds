import { useState, useEffect, useCallback } from 'react';
import type { ValidatorInfo, VeTokenInfo } from '../types';
import { MOCK_VALIDATORS } from '../utils/formatting';

export function useValidators() {
  const [validators, setValidators] = useState<ValidatorInfo[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setValidators(MOCK_VALIDATORS);
      setLoading(false);
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  const activeValidators = validators.filter((v: ValidatorInfo) => v.isActive && !v.isJailed);
  return { validators, activeValidators, loading };
}

export function useDelegation() {
  const [delegatedAmount, setDelegatedAmount] = useState('0');
  const [delegatedValidator, setDelegatedValidator] = useState<string | null>(null);
  const [txStatus, setTxStatus] = useState<'idle' | 'pending' | 'success' | 'error'>('idle');

  const delegate = useCallback(async (validatorAddress: string, amount: string) => {
    setTxStatus('pending');
    await new Promise(r => setTimeout(r, 1500));
    setDelegatedAmount(amount);
    setDelegatedValidator(validatorAddress);
    setTxStatus('success');
  }, []);

  const undelegate = useCallback(async () => {
    setTxStatus('pending');
    await new Promise(r => setTimeout(r, 1500));
    setDelegatedAmount('0');
    setDelegatedValidator(null);
    setTxStatus('success');
  }, []);

  return { delegatedAmount, delegatedValidator, delegate, undelegate, txStatus };
}

export function useVeToken() {
  const [veTokenInfo, setVeTokenInfo] = useState<VeTokenInfo>({
    balance: '0',
    lockedAmount: '0',
    lockEnd: 0,
    votingPower: '0',
    multiplier: 1.0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setVeTokenInfo({
        balance: '250000000000',
        lockedAmount: '500000000000',
        lockEnd: Date.now() + 86400000 * 180,
        votingPower: '125000000000',
        multiplier: 1.85,
      });
      setLoading(false);
    }, 400);
    return () => clearTimeout(timer);
  }, []);

  const lockTokens = useCallback(async (amount: string, durationDays: number) => {
    await new Promise(r => setTimeout(r, 1500));
    setVeTokenInfo((prev: VeTokenInfo) => ({
      ...prev,
      lockedAmount: (parseFloat(prev.lockedAmount) + parseFloat(amount)).toString(),
      lockEnd: Date.now() + durationDays * 86400 * 1000,
    }));
  }, []);

  return { veTokenInfo, loading, lockTokens };
}
