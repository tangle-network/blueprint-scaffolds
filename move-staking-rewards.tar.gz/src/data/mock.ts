import type { PoolInfo, VaultInfo, ValidatorInfo, LockTier } from '../types';

export function formatApt(amount: string | number, decimals = 8): string {
  const val = typeof amount === 'string' ? parseFloat(amount) / 10 ** decimals : amount;
  return formatNumber(val);
}

export function formatNumber(num: number, maxDecimals = 4): string {
  if (num === 0) return '0';
  if (num < 0.0001) return '<0.0001';
  if (num >= 1_000_000_000) return `${(num / 1_000_000_000).toFixed(2)}B`;
  if (num >= 1_000_000) return `${(num / 1_000_000).toFixed(2)}M`;
  if (num >= 1_000) return `${(num / 1_000).toFixed(2)}K`;
  return num.toFixed(maxDecimals);
}

export function formatPercent(num: number): string {
  return `${num.toFixed(2)}%`;
}

export function formatAddress(address: string): string {
  if (!address || address.length < 12) return address;
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

export function formatDuration(seconds: number): string {
  if (seconds <= 0) return 'Unlocked';
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  if (days > 0) return `${days}d ${hours}h`;
  const minutes = Math.floor(seconds / 60);
  return `${minutes}m`;
}

export function parseInputAmount(input: string): string {
  const cleaned = input.replace(/[^0-9.]/g, '');
  const parts = cleaned.split('.');
  if (parts.length > 2) return parts[0] + '.' + parts.slice(1).join('');
  return cleaned;
}

export const MOCK_POOLS: PoolInfo[] = [
  {
    id: 'apt-single-1',
    name: 'APT Single Staking',
    type: 'single',
    stakeTokenAddress: '0x1::aptos_coin::AptosCoin',
    stakeTokenSymbol: 'APT',
    stakeTokenDecimals: 8,
    rewardTokens: [
      { address: '0x1::aptos_coin::AptosCoin', symbol: 'APT', decimals: 8, rewardsPerSecond: '5000000' },
      { address: '0x1::usdt::USDT', symbol: 'USDT', decimals: 6, rewardsPerSecond: '200000' },
    ],
    totalStaked: '500000000000000',
    tvlUsd: 3500000,
    apy: 12.5,
    boostMultiplier: 1.0,
    minStakeAmount: '100000000',
    isAutoCompound: false,
    isActive: true,
    lockTiers: ['flexible', '30d', '90d', '180d', '365d'] as LockTier[],
    emergencyWithdrawEnabled: true,
    createdAt: Date.now() - 86400000 * 30,
  },
  {
    id: 'apt-lp-1',
    name: 'APT/USDC LP Pool',
    type: 'lp',
    stakeTokenAddress: '0x1::lp::APT_USDC',
    stakeTokenSymbol: 'APT-USDC LP',
    stakeTokenDecimals: 8,
    rewardTokens: [
      { address: '0x1::aptos_coin::AptosCoin', symbol: 'APT', decimals: 8, rewardsPerSecond: '8000000' },
    ],
    totalStaked: '250000000000000',
    tvlUsd: 5200000,
    apy: 24.8,
    boostMultiplier: 1.5,
    minStakeAmount: '1000000',
    isAutoCompound: false,
    isActive: true,
    lockTiers: ['flexible', '30d', '90d'] as LockTier[],
    emergencyWithdrawEnabled: true,
    createdAt: Date.now() - 86400000 * 20,
  },
  {
    id: 'nft-apt-1',
    name: 'Aptos Monkey NFT Staking',
    type: 'nft',
    stakeTokenAddress: '0x1::nft::AptosMonkeys',
    stakeTokenSymbol: 'AMK',
    stakeTokenDecimals: 0,
    nftCollection: 'Aptos Monkeys',
    rewardTokens: [
      { address: '0x1::aptos_coin::AptosCoin', symbol: 'APT', decimals: 8, rewardsPerSecond: '3000000' },
    ],
    totalStaked: '5000',
    tvlUsd: 890000,
    apy: 8.2,
    boostMultiplier: 1.0,
    minStakeAmount: '1',
    isAutoCompound: false,
    isActive: true,
    lockTiers: ['flexible', '90d'] as LockTier[],
    emergencyWithdrawEnabled: false,
    createdAt: Date.now() - 86400000 * 15,
  },
];

export const MOCK_VAULTS: VaultInfo[] = [
  {
    id: 'vault-apt-1',
    name: 'APT Auto-Compound Vault',
    underlyingToken: '0x1::aptos_coin::AptosCoin',
    underlyingSymbol: 'APT',
    totalDeposits: '120000000000000',
    available: '45000000000000',
    apy: 15.3,
    strategy: 'Stake APT → Claim rewards → Re-stake',
    harvestInterval: 43200,
    lastHarvest: Date.now() - 3600000,
    userDeposits: '0',
    userShares: '0',
  },
  {
    id: 'vault-lp-1',
    name: 'APT/USDC LP Vault',
    underlyingToken: '0x1::lp::APT_USDC',
    underlyingSymbol: 'APT-USDC LP',
    totalDeposits: '80000000000000',
    available: '20000000000000',
    apy: 28.7,
    strategy: 'Provide LP → Farm rewards → Compound',
    harvestInterval: 28800,
    lastHarvest: Date.now() - 7200000,
    userDeposits: '0',
    userShares: '0',
  },
];

export const MOCK_VALIDATORS: ValidatorInfo[] = [
  { address: '0xval1', name: 'Aptos Labs', commissionRate: 5.0, totalStake: '50000000000000000', apy: 7.2, isActive: true, isJailed: false },
  { address: '0xval2', name: 'Binance Staking', commissionRate: 3.0, totalStake: '35000000000000000', apy: 7.5, isActive: true, isJailed: false },
  { address: '0xval3', name: 'Figment', commissionRate: 7.0, totalStake: '20000000000000000', apy: 6.9, isActive: true, isJailed: false },
  { address: '0xval4', name: 'Chorus One', commissionRate: 6.0, totalStake: '15000000000000000', apy: 7.1, isActive: true, isJailed: false },
  { address: '0xval5', name: 'Invalid Node', commissionRate: 10.0, totalStake: '5000000000000000', apy: 0, isActive: false, isJailed: true },
];
