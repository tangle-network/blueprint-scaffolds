import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatTokenAmount(amount: number | string, decimals: number = 8): string {
  const num = typeof amount === "string" ? parseFloat(amount) : amount
  if (isNaN(num)) return "0.00"
  if (num >= 1_000_000) return `${(num / 1_000_000).toFixed(2)}M`
  if (num >= 1_000) return `${(num / 1_000).toFixed(2)}K`
  return num.toFixed(decimals > 2 ? 2 : decimals)
}

export function formatAddress(address: string): string {
  if (!address) return ""
  return `${address.slice(0, 6)}...${address.slice(-4)}`
}

export function formatDuration(seconds: number): string {
  const days = Math.floor(seconds / 86400)
  const hours = Math.floor((seconds % 86400) / 3600)
  const mins = Math.floor((seconds % 3600) / 60)
  if (days > 0) return `${days}d ${hours}h`
  if (hours > 0) return `${hours}h ${mins}m`
  return `${mins}m`
}

export function annualizedAPR(rewardPerSecond: number, totalStaked: number): string {
  if (totalStaked === 0) return "0.00"
  const yearly = rewardPerSecond * 365 * 24 * 3600
  return ((yearly / totalStaked) * 100).toFixed(2)
}

export const LOCK_TIERS = [
  { tier: 0, label: "No Lock", days: 0, boost: 1.0 },
  { tier: 1, label: "30 Days", days: 30, boost: 1.2 },
  { tier: 2, label: "90 Days", days: 90, boost: 1.5 },
  { tier: 3, label: "180 Days", days: 180, boost: 2.0 },
  { tier: 4, label: "365 Days", days: 365, boost: 3.0 },
] as const
