import type {
  PoolInfo,
  StakePosition,
  TokenInfo,
  NFTPosition,
  VeTokenBalance,
  VaultInfo,
  VaultShare,
  ValidatorInfo,
  DelegationInfo,
  RewardInfo,
} from "@/types"

const APT_ADDRESS = "0x1::aptos_coin::AptosCoin"

export const TOKENS: Record<string, TokenInfo> = {
  APT: { symbol: "APT", name: "Aptos Coin", decimals: 8, address: APT_ADDRESS },
  USDT: { symbol: "USDT", name: "Tether USD", decimals: 6, address: "0xusdt::coin::T" },
  USDC: { symbol: "USDC", name: "USD Coin", decimals: 6, address: "0xusdc::coin::T" },
  LP_APT_USDT: {
    symbol: "APT-USDT LP",
    name: "APT-USDT Liquidity Pool",
    decimals: 8,
    address: "0xlp::apt_usdt::LPToken",
  },
  LP_APT_USDC: {
    symbol: "APT-USDC LP",
    name: "APT-USDC Liquidity Pool",
    decimals: 8,
    address: "0xlp::apt_usdc::LPToken",
  },
}

export const MOCK_POOLS: PoolInfo[] = [
  {
    id: "pool-apt-single",
    name: "APT Single Stake",
    type: "single",
    stakingToken: TOKENS.APT,
    rewardTokens: [TOKENS.APT],
    totalStaked: 1_250_000,
    rewardRatePerSecond: 0.5,
    apr: "12.61",
    lockTiers: [
      { tier: 0, label: "No Lock", days: 0, boostMultiplier: 1.0 },
      { tier: 1, label: "30 Days", days: 30, boostMultiplier: 1.2 },
      { tier: 2, label: "90 Days", days: 90, boostMultiplier: 1.5 },
      { tier: 3, label: "180 Days", days: 180, boostMultiplier: 2.0 },
      { tier: 4, label: "365 Days", days: 365, boostMultiplier: 3.0 },
    ],
    minStake: 0.1,
    emergencyWithdrawPenalty: 10,
    autoCompound: false,
    paused: false,
    delegatable: true,
  },
  {
    id: "pool-apt-usdt-lp",
    name: "APT-USDT LP Farm",
    type: "lp",
    stakingToken: TOKENS.LP_APT_USDT,
    rewardTokens: [TOKENS.APT, TOKENS.USDT],
    totalStaked: 3_500_000,
    rewardRatePerSecond: 1.2,
    apr: "18.94",
    lockTiers: [
      { tier: 0, label: "No Lock", days: 0, boostMultiplier: 1.0 },
      { tier: 1, label: "30 Days", days: 30, boostMultiplier: 1.2 },
      { tier: 2, label: "90 Days", days: 90, boostMultiplier: 1.5 },
    ],
    minStake: 0.5,
    emergencyWithdrawPenalty: 15,
    autoCompound: false,
    paused: false,
    delegatable: false,
  },
  {
    id: "pool-apt-usdc-lp",
    name: "APT-USDC LP Farm",
    type: "lp",
    stakingToken: TOKENS.LP_APT_USDC,
    rewardTokens: [TOKENS.APT, TOKENS.USDC],
    totalStaked: 2_100_000,
    rewardRatePerSecond: 0.8,
    apr: "14.73",
    lockTiers: [
      { tier: 0, label: "No Lock", days: 0, boostMultiplier: 1.0 },
      { tier: 1, label: "30 Days", days: 30, boostMultiplier: 1.2 },
      { tier: 2, label: "90 Days", days: 90, boostMultiplier: 1.5 },
      { tier: 3, label: "180 Days", days: 180, boostMultiplier: 2.0 },
    ],
    minStake: 0.3,
    emergencyWithdrawPenalty: 10,
    autoCompound: false,
    paused: false,
    delegatable: false,
  },
  {
    id: "pool-usdt-single",
    name: "USDT Stake",
    type: "single",
    stakingToken: TOKENS.USDT,
    rewardTokens: [TOKENS.APT],
    totalStaked: 890_000,
    rewardRatePerSecond: 0.3,
    apr: "9.47",
    lockTiers: [
      { tier: 0, label: "No Lock", days: 0, boostMultiplier: 1.0 },
      { tier: 1, label: "30 Days", days: 30, boostMultiplier: 1.2 },
    ],
    minStake: 10,
    emergencyWithdrawPenalty: 5,
    autoCompound: false,
    paused: false,
    delegatable: false,
  },
]

export const MOCK_NFT_POOL: PoolInfo = {
  id: "pool-nft",
  name: "NFT Staking",
  type: "nft",
  stakingToken: { symbol: "NFT", name: "Aptos NFT", decimals: 0, address: "0xnft" },
  rewardTokens: [TOKENS.APT],
  totalStaked: 450,
  rewardRatePerSecond: 0.1,
  apr: "22.50",
  lockTiers: [
    { tier: 1, label: "Common", days: 0, boostMultiplier: 1.0 },
    { tier: 2, label: "Rare", days: 0, boostMultiplier: 1.5 },
    { tier: 3, label: "Legendary", days: 0, boostMultiplier: 2.5 },
  ],
  minStake: 1,
  emergencyWithdrawPenalty: 0,
  autoCompound: false,
  paused: false,
  delegatable: false,
}

export const MOCK_VAULTS: VaultInfo[] = [
  {
    id: "vault-apt",
    token: TOKENS.APT,
    totalDeposits: 5_200_000,
    totalShares: 4_800_000,
    compoundInterval: 86400,
    performanceFeeBps: 1000,
    apr: "15.20",
  },
  {
    id: "vault-usdt",
    token: TOKENS.USDT,
    totalDeposits: 1_800_000,
    totalShares: 1_700_000,
    compoundInterval: 43200,
    performanceFeeBps: 500,
    apr: "8.50",
  },
]

export const MOCK_VALIDATORS: ValidatorInfo[] = [
  { address: "0xval1", name: "Aptos Validator 1", commissionRate: 0, totalStake: 10_000_000, apy: "7.00", active: true },
  { address: "0xval2", name: "Aptos Validator 2", commissionRate: 5, totalStake: 5_500_000, apy: "6.65", active: true },
  { address: "0xval3", name: "Aptos Validator 3", commissionRate: 10, totalStake: 3_200_000, apy: "6.30", active: true },
  { address: "0xval4", name: "Aptos Validator 4", commissionRate: 2, totalStake: 8_100_000, apy: "6.86", active: true },
]

export function getMockUserPositions(): StakePosition[] {
  return [
    {
      id: "pos-1",
      poolId: "pool-apt-single",
      amount: 500,
      stakingToken: TOKENS.APT,
      startTimestamp: Date.now() / 1000 - 30 * 86400,
      lockEndTimestamp: Date.now() / 1000 + 60 * 86400,
      lockTier: 2,
      boostMultiplier: 1.5,
      pendingRewards: [{ token: TOKENS.APT, amount: 12.45 }],
      isActive: true,
    },
    {
      id: "pos-2",
      poolId: "pool-apt-single",
      amount: 200,
      stakingToken: TOKENS.APT,
      startTimestamp: Date.now() / 1000 - 5 * 86400,
      lockEndTimestamp: Date.now() / 1000,
      lockTier: 0,
      boostMultiplier: 1.0,
      pendingRewards: [{ token: TOKENS.APT, amount: 1.2 }],
      isActive: true,
    },
    {
      id: "pos-3",
      poolId: "pool-apt-usdt-lp",
      amount: 1200,
      stakingToken: TOKENS.LP_APT_USDT,
      startTimestamp: Date.now() / 1000 - 60 * 86400,
      lockEndTimestamp: Date.now() / 1000 + 30 * 86400,
      lockTier: 1,
      boostMultiplier: 1.2,
      pendingRewards: [
        { token: TOKENS.APT, amount: 8.75 },
        { token: TOKENS.USDT, amount: 15.3 },
      ],
      isActive: true,
    },
  ]
}

export function getMockNFTPositions(): NFTPosition[] {
  return [
    { id: "nft-1", nftId: "0xnft001", stakeTime: Date.now() / 1000 - 15 * 86400, tier: 1, boost: 1.0, pendingRewards: [{ token: TOKENS.APT, amount: 0.5 }] },
    { id: "nft-2", nftId: "0xnft002", stakeTime: Date.now() / 1000 - 30 * 86400, tier: 3, boost: 2.5, pendingRewards: [{ token: TOKENS.APT, amount: 4.2 }] },
  ]
}

export function getMockVeBalance(): VeTokenBalance {
  return { amount: 1500, lockEnd: Date.now() / 1000 + 180 * 86400, originalAmount: 3000 }
}

export function getMockVaultShares(): VaultShare[] {
  return [
    { shares: 100, depositAmount: 100, currentValue: 108.5 },
    { shares: 500, depositAmount: 500, currentValue: 522.1 },
  ]
}

export function getMockDelegations(): DelegationInfo[] {
  return [
    { validatorAddress: "0xval1", amount: 1000, rewardsEarned: 12.5, isActive: true },
    { validatorAddress: "0xval2", amount: 500, rewardsEarned: 4.8, isActive: true },
  ]
}

export function calculatePendingRewards(
  position: StakePosition,
  nowSeconds: number
): RewardInfo[] {
  return position.pendingRewards.map((r) => {
    const elapsed = Math.max(0, nowSeconds - position.startTimestamp)
    const accReward = (elapsed * 0.001 * position.boostMultiplier * position.amount) / 100
    return { ...r, amount: r.amount + accReward }
  })
}
