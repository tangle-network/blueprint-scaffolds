export const MODULE_ADDRESS = '0x1';
export const APT_DECIMALS = 8;
export const REFRESH_INTERVAL_MS = 15000;
