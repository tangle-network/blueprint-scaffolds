import { WalletState } from '../context/WalletContext';

export interface TransactionPayload {
  type: 'entry_function_payload';
  function: string;
  type_arguments: string[];
  arguments: string[];
}
