export type LockTier = 'flexible' | '30d' | '90d' | '180d' | '365d';

export interface LockTierConfig {
  label: string;
  durationSeconds: number;
  multiplier: number;
  penaltyBps: number;
}

export const LOCK_TIERS: Record<LockTier, LockTierConfig> = {
  flexible: { label: 'Flexible', durationSeconds: 0, multiplier: 1.0, penaltyBps: 0 },
  '30d': { label: '30 Days', durationSeconds: 30 * 86400, multiplier: 1.25, penaltyBps: 500 },
  '90d': { label: '90 Days', durationSeconds: 90 * 86400, multiplier: 1.6, penaltyBps: 300 },
  '180d': { label: '180 Days', durationSeconds: 180 * 86400, multiplier: 2.0, penaltyBps: 200 },
  '365d': { label: '365 Days', durationSeconds: 365 * 86400, multiplier: 3.0, penaltyBps: 100 },
};

export interface RewardToken {
  address: string;
  symbol: string;
  decimals: number;
  iconUrl?: string;
  rewardsPerSecond: string;
}

export interface PoolInfo {
  id: string;
  name: string;
  type: 'single' | 'lp' | 'nft';
  stakeTokenAddress: string;
  stakeTokenSymbol: string;
  stakeTokenDecimals: number;
  stakeTokenIcon?: string;
  rewardTokens: RewardToken[];
  totalStaked: string;
  tvlUsd: number;
  apy: number;
  boostMultiplier: number;
  minStakeAmount: string;
  maxStakeAmount?: string;
  isAutoCompound: boolean;
  isActive: boolean;
  lockTiers: LockTier[];
  emergencyWithdrawEnabled: boolean;
  validatorAddress?: string;
  nftCollection?: string;
  createdAt: number;
}

export interface UserStake {
  poolId: string;
  stakedAmount: string;
  stakeTokenSymbol: string;
  lockTier: LockTier;
  lockEnd: number;
  pendingRewards: PendingReward[];
  boostMultiplier: number;
  depositTime: number;
  nftIds?: string[];
}

export interface PendingReward {
  tokenSymbol: string;
  tokenAddress: string;
  amount: string;
  decimals: number;
  usdValue?: number;
}

export interface VeTokenInfo {
  balance: string;
  lockedAmount: string;
  lockEnd: number;
  votingPower: string;
  multiplier: number;
}

export interface ValidatorInfo {
  address: string;
  name: string;
  commissionRate: number;
  totalStake: string;
  apy: number;
  isActive: boolean;
  isJailed: boolean;
}

export interface VaultInfo {
  id: string;
  name: string;
  underlyingToken: string;
  underlyingSymbol: string;
  totalDeposits: string;
  available: string;
  apy: number;
  strategy: string;
  harvestInterval: number;
  lastHarvest: number;
  userDeposits: string;
  userShares: string;
}
