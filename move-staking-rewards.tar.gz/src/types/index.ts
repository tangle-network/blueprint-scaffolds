export interface PoolInfo {
  id: string
  name: string
  type: "single" | "lp" | "nft"
  stakingToken: TokenInfo
  rewardTokens: TokenInfo[]
  totalStaked: number
  rewardRatePerSecond: number
  apr: string
  lockTiers: LockTier[]
  minStake: number
  emergencyWithdrawPenalty: number
  autoCompound: boolean
  paused: boolean
  delegatable: boolean
}

export interface TokenInfo {
  symbol: string
  name: string
  decimals: number
  address: string
  logoUrl?: string
}

export interface LockTier {
  tier: number
  label: string
  days: number
  boostMultiplier: number
}

export interface StakePosition {
  id: string
  poolId: string
  amount: number
  stakingToken: TokenInfo
  startTimestamp: number
  lockEndTimestamp: number
  lockTier: number
  boostMultiplier: number
  pendingRewards: RewardInfo[]
  isActive: boolean
}

export interface RewardInfo {
  token: TokenInfo
  amount: number
}

export interface NFTPosition {
  id: string
  nftId: string
  stakeTime: number
  tier: number
  boost: number
  pendingRewards: RewardInfo[]
}

export interface VeTokenBalance {
  amount: number
  lockEnd: number
  originalAmount: number
}

export interface VaultInfo {
  id: string
  token: TokenInfo
  totalDeposits: number
  totalShares: number
  compoundInterval: number
  performanceFeeBps: number
  apr: string
}

export interface VaultShare {
  shares: number
  depositAmount: number
  currentValue: number
}

export interface ValidatorInfo {
  address: string
  name: string
  commissionRate: number
  totalStake: number
  apy: string
  active: boolean
}

export interface DelegationInfo {
  validatorAddress: string
  amount: number
  rewardsEarned: number
  isActive: boolean
}
