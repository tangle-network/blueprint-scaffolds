import React, { createContext, useContext, useState, useCallback, type ReactNode } from 'react';

interface WalletState {
  address: string | null;
  connected: boolean;
  connecting: boolean;
  balance: string;
  network: string;
}

interface WalletContextType extends WalletState {
  connect: () => Promise<void>;
  disconnect: () => void;
  signAndSubmitTransaction: (payload: Record<string, unknown>) => Promise<{ hash: string }>;
}

const WalletContext = createContext<WalletContextType | null>(null);

export function useWallet(): WalletContextType {
  const ctx = useContext(WalletContext);
  if (!ctx) throw new Error('useWallet must be used within WalletProvider');
  return ctx;
}

export function WalletProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<WalletState>({
    address: null,
    connected: false,
    connecting: false,
    balance: '0',
    network: 'mainnet',
  });

  const connect = useCallback(async () => {
    setState((s: WalletState) => ({ ...s, connecting: true }));
    await new Promise(r => setTimeout(r, 800));
    const hex = () => Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    setState({
      address: '0x' + hex(),
      connected: true,
      connecting: false,
      balance: '12500000000',
      network: 'mainnet',
    });
  }, []);

  const disconnect = useCallback(() => {
    setState({ address: null, connected: false, connecting: false, balance: '0', network: 'mainnet' });
  }, []);

  const signAndSubmitTransaction = useCallback(async (_payload: Record<string, unknown>) => {
    await new Promise(r => setTimeout(r, 1500));
    const hex = () => Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    return { hash: '0x' + hex() };
  }, []);

  return (
    <WalletContext.Provider value={{ ...state, connect, disconnect, signAndSubmitTransaction }}>
      {children}
    </WalletContext.Provider>
  );
}
