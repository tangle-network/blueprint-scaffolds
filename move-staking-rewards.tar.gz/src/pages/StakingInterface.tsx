import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { usePools, useStaking } from "@/hooks/useStaking"
import { useWallet } from "@/hooks/useWallet"
import { formatTokenAmount, formatDuration } from "@/lib/utils"
import { Coins, Lock, TrendingUp, AlertTriangle, Loader2 } from "lucide-react"
import type { PoolInfo } from "@/types"

function StakeForm({ pool, onStake }: { pool: PoolInfo; onStake: (poolId: string, amount: number, tier: number) => Promise<void> }) {
  const [amount, setAmount] = useState("")
  const [lockTier, setLockTier] = useState("0")
  const [pending, setPending] = useState(false)

  const handleStake = async () => {
    const num = parseFloat(amount)
    if (!num || num <= 0) return
    setPending(true)
    await onStake(pool.id, num, parseInt(lockTier))
    setAmount("")
    setPending(false)
  }

  const selectedTier = pool.lockTiers.find((t) => t.tier === parseInt(lockTier))
  const boostDisplay = selectedTier ? `${(selectedTier.boostMultiplier * 100).toFixed(0)}%` : "100%"
  const lockDays = selectedTier?.days ?? 0

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Coins className="h-5 w-5" />
          Stake {pool.stakingToken.symbol}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>Amount</Label>
          <div className="flex gap-2">
            <Input
              type="number"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              min={0}
            />
            <Button variant="outline" size="sm" onClick={() => setAmount("100")} className="shrink-0">
              Max
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">Min: {pool.minStake} {pool.stakingToken.symbol}</p>
        </div>

        <div className="space-y-2">
          <Label className="flex items-center gap-1">
            <Lock className="h-4 w-4" /> Lock Period
          </Label>
          <Select value={lockTier} onValueChange={setLockTier}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {pool.lockTiers.map((tier) => (
                <SelectItem key={tier.tier} value={tier.tier.toString()}>
                  {tier.label} {tier.days > 0 ? `(${tier.boostMultiplier}x boost)` : "(Flexible)"}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Separator />

        <div className="space-y-1 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Boost Multiplier</span>
            <span className="font-medium">{boostDisplay}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Pool APR</span>
            <span className="font-medium text-green-600">{pool.apr}%</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Rewards</span>
            <span className="font-medium">{pool.rewardTokens.map((t) => t.symbol).join(", ")}</span>
          </div>
          {lockDays > 0 && (
            <div className="flex justify-between">
              <span className="text-muted-foreground">Lock Duration</span>
              <span className="font-medium">{lockDays} days</span>
            </div>
          )}
        </div>

        <Button className="w-full" onClick={handleStake} disabled={pending || !amount}>
          {pending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Coins className="mr-2 h-4 w-4" />}
          {pending ? "Staking..." : "Stake"}
        </Button>
      </CardContent>
    </Card>
  )
}

function ActivePositions({ positions, onUnstake, onClaim, onEmergency }: {
  positions: ReturnType<typeof useStaking>["positions"]
  onUnstake: (id: string) => Promise<void>
  onClaim: (id: string) => Promise<void>
  onEmergency: (id: string) => Promise<void>
}) {
  const [pendingId, setPendingId] = useState<string | null>(null)

  const now = Date.now() / 1000

  if (positions.length === 0) {
    return (
      <Card>
        <CardContent className="pt-6 text-center text-muted-foreground py-12">
          No active positions. Stake tokens to get started.
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {positions.map((pos) => {
        const locked = now < pos.lockEndTimestamp
        const lockRemaining = locked ? pos.lockEndTimestamp - now : 0
        const totalReward = pos.pendingRewards.reduce((sum, r) => sum + r.amount, 0)

        return (
          <Card key={pos.id}>
            <CardContent className="pt-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold">{formatTokenAmount(pos.amount)} {pos.stakingToken.symbol}</span>
                    <Badge variant={locked ? "secondary" : "outline"}>
                      {locked ? `Locked ${formatDuration(lockRemaining)}` : "Unlocked"}
                    </Badge>
                    {pos.boostMultiplier > 1 && (
                      <Badge variant="default">{pos.boostMultiplier}x</Badge>
                    )}
                  </div>
                  <div className="flex gap-4 text-sm text-muted-foreground">
                    <span>APR Boost: {(pos.boostMultiplier * 100).toFixed(0)}%</span>
                    <span>Pending: {pos.pendingRewards.map((r) => `${formatTokenAmount(r.amount)} ${r.token.symbol}`).join(", ")}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={async () => { setPendingId(pos.id); await onClaim(pos.id); setPendingId(null) }}
                    disabled={pendingId === pos.id}
                  >
                    {pendingId === pos.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <TrendingUp className="h-4 w-4" />}
                  </Button>
                  {!locked && (
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={async () => { setPendingId(pos.id); await onUnstake(pos.id); setPendingId(null) }}
                      disabled={pendingId === pos.id}
                    >
                      Unstake
                    </Button>
                  )}
                  {locked && (
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={async () => { setPendingId(pos.id); await onEmergency(pos.id); setPendingId(null) }}
                      disabled={pendingId === pos.id}
                    >
                      <AlertTriangle className="mr-1 h-3 w-3" /> Emergency
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}

export default function StakingInterface() {
  const { pools } = usePools()
  const wallet = useWallet()
  const { positions, stake, unstake, claimRewards, emergencyWithdraw } = useStaking()
  const [selectedPoolId, setSelectedPoolId] = useState(pools[0]?.id ?? "")

  const selectedPool = pools.find((p) => p.id === selectedPoolId) ?? pools[0]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Staking</h1>
        <p className="text-muted-foreground">Stake tokens and earn rewards with tiered lock boosts</p>
      </div>

      {!wallet.connected && (
        <Card className="border-yellow-500/50 bg-yellow-50 dark:bg-yellow-950/20">
          <CardContent className="pt-6 flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-yellow-600" />
            <span className="text-sm">Connect your wallet to start staking</span>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <Tabs value={selectedPoolId} onValueChange={setSelectedPoolId}>
            <TabsList className="flex-wrap h-auto">
              {pools.map((pool) => (
                <TabsTrigger key={pool.id} value={pool.id}>
                  {pool.stakingToken.symbol}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
          {selectedPool && <StakeForm pool={selectedPool} onStake={stake} />}
        </div>

        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Your Positions</h2>
          <ActivePositions
            positions={positions}
            onUnstake={unstake}
            onClaim={claimRewards}
            onEmergency={emergencyWithdraw}
          />
        </div>
      </div>
    </div>
  )
}
