import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { useWallet } from "@/hooks/useWallet"
import { getMockVeBalance } from "@/lib/aptos"
import { formatTokenAmount, formatDuration } from "@/lib/utils"
import { Shield, Lock, TrendingUp, Loader2, Timer, Coins } from "lucide-react"

export default function VeToken() {
  const wallet = useWallet()
  const ve = getMockVeBalance()
  const [lockAmount, setLockAmount] = useState("")
  const [lockDuration, setLockDuration] = useState("365")
  const [pending, setPending] = useState(false)

  const now = Date.now() / 1000
  const lockRemaining = Math.max(0, ve.lockEnd - now)
  const lockProgress = ve.lockEnd > 0 ? Math.min(100, ((now - (ve.lockEnd - parseInt(lockDuration) * 86400)) / (parseInt(lockDuration) * 86400)) * 100) : 0

  const handleLock = async () => {
    if (!lockAmount || parseFloat(lockAmount) <= 0) return
    setPending(true)
    await new Promise((r) => setTimeout(r, 1500))
    setLockAmount("")
    setPending(false)
  }

  const votingPower = ve.amount > 0 ? ((ve.amount / 10000) * 100).toFixed(2) : "0.00"

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">veToken Governance</h1>
        <p className="text-muted-foreground">Lock tokens to receive veToken voting power and boost rewards</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              <div>
                <p className="text-xs text-muted-foreground">veToken Balance</p>
                <p className="text-2xl font-bold">{formatTokenAmount(ve.amount)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Timer className="h-5 w-5 text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Lock Remaining</p>
                <p className="text-2xl font-bold">{formatDuration(lockRemaining)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-600" />
              <div>
                <p className="text-xs text-muted-foreground">Voting Power</p>
                <p className="text-2xl font-bold">{votingPower}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5" />
              Lock Tokens
            </CardTitle>
            <CardDescription>
              Lock APT to receive veToken. Longer locks = more voting power.
              veToken amount = locked_amount * lock_duration / 1_year
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Amount to Lock (APT)</Label>
              <Input
                type="number"
                placeholder="0.00"
                value={lockAmount}
                onChange={(e) => setLockAmount(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Lock Duration</Label>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { label: "30d", days: 30 },
                  { label: "90d", days: 90 },
                  { label: "180d", days: 180 },
                  { label: "365d", days: 365 },
                ].map((d) => (
                  <Button
                    key={d.days}
                    variant={lockDuration === d.days.toString() ? "default" : "outline"}
                    size="sm"
                    onClick={() => setLockDuration(d.days.toString())}
                    className="w-full"
                  >
                    {d.label}
                  </Button>
                ))}
              </div>
            </div>

            <Separator />

            <div className="text-sm space-y-1">
              <div className="flex justify-between">
                <span className="text-muted-foreground">You will receive</span>
                <span className="font-medium">
                  {lockAmount ? formatTokenAmount(parseFloat(lockAmount) * parseInt(lockDuration) / 365) : "0.00"} veToken
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Lock ends</span>
                <span className="font-medium">{parseInt(lockDuration)} days from now</span>
              </div>
            </div>

            <Button className="w-full" onClick={handleLock} disabled={pending || !lockAmount}>
              {pending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Lock className="mr-2 h-4 w-4" />}
              {pending ? "Locking..." : "Lock & Mint veToken"}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Your veToken Position</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Original Locked</span>
                <span className="font-medium">{formatTokenAmount(ve.originalAmount)} APT</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">veToken Balance</span>
                <span className="font-medium">{formatTokenAmount(ve.amount)} ve</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Lock Expiry</span>
                <span className="font-medium">{formatDuration(lockRemaining)} remaining</span>
              </div>
            </div>

            <Separator />

            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Lock Progress</Label>
              <Progress value={lockProgress} className="h-2" />
              <p className="text-xs text-muted-foreground">
                {lockProgress.toFixed(1)}% elapsed
              </p>
            </div>

            <Separator />

            <div className="p-4 rounded-md bg-muted">
              <h4 className="font-medium mb-2">veToken Benefits</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li className="flex items-center gap-2">
                  <TrendingUp className="h-3 w-3" /> Boost staking rewards up to 2.5x
                </li>
                <li className="flex items-center gap-2">
                  <Shield className="h-3 w-3" /> Governance voting power
                </li>
                <li className="flex items-center gap-2">
                  <Coins className="h-3 w-3" /> Pool incentive allocations
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
