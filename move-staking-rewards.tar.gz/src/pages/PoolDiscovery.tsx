import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { usePools } from "@/hooks/useStaking"
import { formatTokenAmount } from "@/lib/utils"
import { TrendingUp, Lock, Coins, Layers, Search, ExternalLink } from "lucide-react"
import { Link } from "react-router-dom"
import type { PoolInfo } from "@/types"

function PoolCard({ pool }: { pool: PoolInfo }) {
  const typeColor = pool.type === "single" ? "default" : pool.type === "lp" ? "secondary" : "outline"
  const typeLabel = pool.type === "single" ? "Single" : pool.type === "lp" ? "LP" : "NFT"

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">{pool.name}</CardTitle>
          <Badge variant={typeColor as "default" | "secondary" | "outline"}>{typeLabel}</Badge>
        </div>
        <CardDescription>
          Stake {pool.stakingToken.symbol}
          {pool.rewardTokens.length > 1 && ` → Earn ${pool.rewardTokens.map((t) => t.symbol).join(" + ")}`}
          {pool.rewardTokens.length === 1 && ` → Earn ${pool.rewardTokens[0].symbol}`}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <p className="text-xs text-muted-foreground">TVL</p>
            <p className="text-lg font-semibold">${formatTokenAmount(pool.totalStaked)}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">APR</p>
            <p className="text-lg font-semibold text-green-600">{pool.apr}%</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Reward Rate</p>
            <p className="text-sm font-medium">{pool.rewardRatePerSecond}/sec</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Lock Tiers</p>
            <div className="flex items-center gap-1">
              <Lock className="h-3 w-3 text-muted-foreground" />
              <span className="text-sm font-medium">{pool.lockTiers.length} tiers</span>
            </div>
          </div>
        </div>
        {pool.emergencyWithdrawPenalty > 0 && (
          <p className="text-xs text-muted-foreground mb-3">
            Emergency withdraw: {pool.emergencyWithdrawPenalty}% penalty
          </p>
        )}
        <div className="flex gap-2">
          <Link to="/stake" className="flex-1">
            <Button className="w-full" size="sm">
              <Coins className="mr-1 h-4 w-4" /> Stake
            </Button>
          </Link>
          <Link to="/rewards">
            <Button variant="outline" size="sm">
              <TrendingUp className="mr-1 h-4 w-4" /> Rewards
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  )
}

export default function PoolDiscovery() {
  const { pools } = usePools()
  const [search, setSearch] = useState("")
  const [tab, setTab] = useState("all")

  const totalTVL = pools.reduce((sum, p) => sum + p.totalStaked, 0)
  const avgAPR = pools.reduce((sum, p) => sum + parseFloat(p.apr), 0) / pools.length

  const filtered = pools.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.stakingToken.symbol.toLowerCase().includes(search.toLowerCase())
    const matchesTab = tab === "all" || p.type === tab
    return matchesSearch && matchesTab
  })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Pool Discovery</h1>
        <p className="text-muted-foreground">Explore staking pools and earn rewards</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Layers className="h-5 w-5 text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Total Pools</p>
                <p className="text-2xl font-bold">{pools.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Coins className="h-5 w-5 text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Total TVL</p>
                <p className="text-2xl font-bold">${formatTokenAmount(totalTVL)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-600" />
              <div>
                <p className="text-xs text-muted-foreground">Avg APR</p>
                <p className="text-2xl font-bold text-green-600">{avgAPR.toFixed(2)}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search pools..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList>
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="single">Single</TabsTrigger>
            <TabsTrigger value="lp">LP</TabsTrigger>
            <TabsTrigger value="nft">NFT</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((pool) => (
          <PoolCard key={pool.id} pool={pool} />
        ))}
        {filtered.length === 0 && (
          <div className="col-span-full text-center py-12 text-muted-foreground">
            No pools found matching your criteria
          </div>
        )}
      </div>
    </div>
  )
}
