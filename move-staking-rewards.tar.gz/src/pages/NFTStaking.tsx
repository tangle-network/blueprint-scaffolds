import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { useWallet } from "@/hooks/useWallet"
import { MOCK_NFT_POOL, getMockNFTPositions } from "@/lib/aptos"
import { formatTokenAmount, formatDuration } from "@/lib/utils"
import { Image, Loader2, TrendingUp, AlertTriangle, Gem } from "lucide-react"
import type { NFTPosition } from "@/types"

function NFTStakeForm({ onStake }: { onStake: (nftId: string, tier: number) => void }) {
  const [nftId, setNftId] = useState("")
  const [tier, setTier] = useState("1")
  const [pending, setPending] = useState(false)

  const handleStake = async () => {
    if (!nftId) return
    setPending(true)
    await new Promise((r) => setTimeout(r, 1500))
    onStake(nftId, parseInt(tier))
    setNftId("")
    setPending(false)
  }

  const selectedTier = MOCK_NFT_POOL.lockTiers.find((t) => t.tier === parseInt(tier))

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Image className="h-5 w-5" />
          Stake NFT
        </CardTitle>
        <CardDescription>Stake your NFTs to earn APT rewards based on rarity tier</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>NFT ID</Label>
          <Input
            placeholder="Enter NFT object ID (0x...)"
            value={nftId}
            onChange={(e) => setNftId(e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <Label>NFT Tier</Label>
          <Select value={tier} onValueChange={setTier}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {MOCK_NFT_POOL.lockTiers.map((t) => (
                <SelectItem key={t.tier} value={t.tier.toString()}>
                  {t.label} ({t.boostMultiplier}x rewards)
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        {selectedTier && (
          <div className="text-sm space-y-1">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Tier</span>
              <span className="font-medium">{selectedTier.label}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Boost</span>
              <span className="font-medium">{selectedTier.boostMultiplier}x</span>
            </div>
          </div>
        )}
        <Button className="w-full" onClick={handleStake} disabled={pending || !nftId}>
          {pending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Image className="mr-2 h-4 w-4" />}
          {pending ? "Staking..." : "Stake NFT"}
        </Button>
      </CardContent>
    </Card>
  )
}

export default function NFTStaking() {
  const wallet = useWallet()
  const [positions, setPositions] = useState<NFTPosition[]>(getMockNFTPositions())

  const handleStake = (nftId: string, tier: number) => {
    const boost = tier === 1 ? 1.0 : tier === 2 ? 1.5 : 2.5
    setPositions((prev) => [
      ...prev,
      {
        id: `nft-${Date.now()}`,
        nftId,
        stakeTime: Date.now() / 1000,
        tier,
        boost,
        pendingRewards: [{ token: { symbol: "APT", name: "Aptos Coin", decimals: 8, address: "0x1" }, amount: 0 }],
      },
    ])
  }

  const handleUnstake = async (id: string) => {
    setPositions((prev) => prev.filter((p) => p.id !== id))
  }

  const now = Date.now() / 1000

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">NFT Staking</h1>
        <p className="text-muted-foreground">Stake NFTs and earn rewards based on rarity tier</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <p className="text-xs text-muted-foreground">Total NFTs Staked</p>
            <p className="text-2xl font-bold">{MOCK_NFT_POOL.totalStaked}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-xs text-muted-foreground">Pool APR</p>
            <p className="text-2xl font-bold text-green-600">{MOCK_NFT_POOL.apr}%</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-xs text-muted-foreground">Reward Rate</p>
            <p className="text-2xl font-bold">{MOCK_NFT_POOL.rewardRatePerSecond}/sec</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <NFTStakeForm onStake={handleStake} />

        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Your NFTs</h2>
          {positions.length === 0 ? (
            <Card>
              <CardContent className="pt-6 text-center text-muted-foreground py-12">
                No NFTs staked. Stake an NFT to earn rewards.
              </CardContent>
            </Card>
          ) : (
            positions.map((pos) => {
              const tierName = pos.tier === 1 ? "Common" : pos.tier === 2 ? "Rare" : "Legendary"
              const stakedDays = Math.floor((now - pos.stakeTime) / 86400)
              return (
                <Card key={pos.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="h-12 w-12 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                          <Gem className="h-6 w-6 text-white" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-sm">NFT {pos.nftId.slice(0, 10)}...</span>
                            <Badge variant={pos.tier === 3 ? "default" : pos.tier === 2 ? "secondary" : "outline"}>
                              {tierName}
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground">
                            Staked {stakedDays}d ago | {pos.boost}x boost
                          </p>
                          <p className="text-sm font-medium text-green-600">
                            {formatTokenAmount(pos.pendingRewards[0]?.amount ?? 0)} APT pending
                          </p>
                        </div>
                      </div>
                      <Button size="sm" variant="destructive" onClick={() => handleUnstake(pos.id)}>
                        Unstake
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )
            })
          )}
        </div>
      </div>
    </div>
  )
}
