import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { useWallet } from "@/hooks/useWallet"
import { MOCK_VAULTS, getMockVaultShares } from "@/lib/aptos"
import { formatTokenAmount } from "@/lib/utils"
import { Vault, TrendingUp, Loader2, ArrowRightLeft, Clock, Percent } from "lucide-react"
import type { VaultInfo, VaultShare } from "@/types"

function VaultCard({ vault, shares }: { vault: VaultInfo; shares: VaultShare[] }) {
  const [depositAmount, setDepositAmount] = useState("")
  const [withdrawShares, setWithdrawShares] = useState("")
  const [pending, setPending] = useState(false)
  const [mode, setMode] = useState<"deposit" | "withdraw">("deposit")

  const userShare = shares[0]
  const feePercent = (vault.performanceFeeBps / 100).toFixed(1)
  const compoundHours = (vault.compoundInterval / 3600).toFixed(0)

  const handleAction = async () => {
    setPending(true)
    await new Promise((r) => setTimeout(r, 1500))
    setDepositAmount("")
    setWithdrawShares("")
    setPending(false)
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Vault className="h-5 w-5" />
            {vault.token.symbol} Vault
          </CardTitle>
          <Badge className="bg-green-600">{vault.apr}% APR</Badge>
        </div>
        <CardDescription>Auto-compounding vault with {feePercent}% performance fee</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-xs text-muted-foreground">Total Deposits</p>
            <p className="font-semibold">{formatTokenAmount(vault.totalDeposits)} {vault.token.symbol}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Total Shares</p>
            <p className="font-semibold">{formatTokenAmount(vault.totalShares)}</p>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3 text-muted-foreground" />
            <span className="text-muted-foreground">Compounds every {compoundHours}h</span>
          </div>
          <div className="flex items-center gap-1">
            <Percent className="h-3 w-3 text-muted-foreground" />
            <span className="text-muted-foreground">{feePercent}% fee</span>
          </div>
        </div>

        {userShare && (
          <>
            <Separator />
            <div className="text-sm space-y-1">
              <p className="text-xs text-muted-foreground">Your Position</p>
              <div className="flex justify-between">
                <span>Deposited</span>
                <span className="font-medium">{formatTokenAmount(userShare.depositAmount)} {vault.token.symbol}</span>
              </div>
              <div className="flex justify-between">
                <span>Current Value</span>
                <span className="font-medium text-green-600">{formatTokenAmount(userShare.currentValue)} {vault.token.symbol}</span>
              </div>
              <div className="flex justify-between">
                <span>Yield</span>
                <span className="font-medium text-green-600">
                  +{formatTokenAmount(userShare.currentValue - userShare.depositAmount)} {vault.token.symbol}
                </span>
              </div>
            </div>
          </>
        )}

        <div className="flex gap-2">
          <Button
            variant={mode === "deposit" ? "default" : "outline"}
            size="sm"
            onClick={() => setMode("deposit")}
            className="flex-1"
          >
            Deposit
          </Button>
          <Button
            variant={mode === "withdraw" ? "default" : "outline"}
            size="sm"
            onClick={() => setMode("withdraw")}
            className="flex-1"
          >
            Withdraw
          </Button>
        </div>

        {mode === "deposit" ? (
          <div className="space-y-2">
            <Label>Deposit Amount</Label>
            <div className="flex gap-2">
              <Input
                type="number"
                placeholder="0.00"
                value={depositAmount}
                onChange={(e) => setDepositAmount(e.target.value)}
              />
              <Button variant="outline" size="sm" className="shrink-0" onClick={() => setDepositAmount("100")}>
                Max
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-2">
            <Label>Shares to Withdraw</Label>
            <div className="flex gap-2">
              <Input
                type="number"
                placeholder="0"
                value={withdrawShares}
                onChange={(e) => setWithdrawShares(e.target.value)}
              />
              {userShare && (
                <Button variant="outline" size="sm" className="shrink-0" onClick={() => setWithdrawShares(userShare.shares.toString())}>
                  Max
                </Button>
              )}
            </div>
          </div>
        )}

        <Button className="w-full" onClick={handleAction} disabled={pending}>
          {pending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : mode === "deposit" ? <TrendingUp className="mr-2 h-4 w-4" /> : <ArrowRightLeft className="mr-2 h-4 w-4" />}
          {pending ? "Processing..." : mode === "deposit" ? "Deposit" : "Withdraw"}
        </Button>
      </CardContent>
    </Card>
  )
}

export default function Vaults() {
  const wallet = useWallet()
  const shares = getMockVaultShares()

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Auto-Compound Vaults</h1>
        <p className="text-muted-foreground">Deposit tokens and let the vault auto-compound your yields</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {MOCK_VAULTS.map((vault, i) => (
          <VaultCard key={vault.id} vault={vault} shares={shares[i] ? [shares[i]] : []} />
        ))}
      </div>
    </div>
  )
}
