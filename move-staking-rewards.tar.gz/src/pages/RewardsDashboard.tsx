import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { useStaking } from "@/hooks/useStaking"
import { useWallet } from "@/hooks/useWallet"
import { formatTokenAmount } from "@/lib/utils"
import { TrendingUp, Coins, AlertTriangle, Loader2, Gift } from "lucide-react"
import { useState } from "react"
import { MOCK_POOLS } from "@/lib/aptos"

export default function RewardsDashboard() {
  const wallet = useWallet()
  const { positions, claimRewards, claimAllRewards, txPending } = useStaking()
  const [pendingPosId, setPendingPosId] = useState<string | null>(null)

  const now = Date.now() / 1000
  const totalPending = positions.reduce(
    (sum, pos) => sum + pos.pendingRewards.reduce((s, r) => s + r.amount, 0),
    0
  )

  const totalStaked = positions.reduce((sum, pos) => sum + pos.amount, 0)

  const rewardByToken = positions.reduce<Record<string, number>>((acc, pos) => {
    for (const r of pos.pendingRewards) {
      acc[r.token.symbol] = (acc[r.token.symbol] ?? 0) + r.amount
    }
    return acc
  }, {})

  const handleClaim = async (posId: string) => {
    setPendingPosId(posId)
    await claimRewards(posId)
    setPendingPosId(null)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Rewards Dashboard</h1>
          <p className="text-muted-foreground">Track and claim your staking rewards</p>
        </div>
        <Button onClick={claimAllRewards} disabled={txPending || positions.length === 0}>
          {txPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Gift className="mr-2 h-4 w-4" />}
          Claim All
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <p className="text-xs text-muted-foreground">Total Staked</p>
            <p className="text-2xl font-bold">{formatTokenAmount(totalStaked)}</p>
          </CardContent>
        </Card>
        <Card className="border-green-500/30">
          <CardContent className="pt-6">
            <p className="text-xs text-muted-foreground">Total Pending Rewards</p>
            <p className="text-2xl font-bold text-green-600">{formatTokenAmount(totalPending)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-xs text-muted-foreground">Active Positions</p>
            <p className="text-2xl font-bold">{positions.length}</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Rewards by Token</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            {Object.entries(rewardByToken).map(([symbol, amount]) => (
              <div key={symbol} className="flex items-center gap-3 p-3 rounded-md border">
                <Coins className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium">{symbol}</p>
                  <p className="text-lg font-bold">{formatTokenAmount(amount)}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Position Rewards</h2>
        {positions.length === 0 && (
          <Card>
            <CardContent className="pt-6 text-center text-muted-foreground py-12">
              No active positions. Start staking to earn rewards.
            </CardContent>
          </Card>
        )}
        {positions.map((pos) => {
          const pool = MOCK_POOLS.find((p) => p.id === pos.poolId)
          const locked = now < pos.lockEndTimestamp
          const posReward = pos.pendingRewards.reduce((s, r) => s + r.amount, 0)

          return (
            <Card key={pos.id}>
              <CardContent className="pt-6">
                <div className="flex flex-col sm:flex-row justify-between gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold">{pool?.name ?? "Unknown Pool"}</span>
                      <Badge variant={locked ? "secondary" : "outline"}>
                        {locked ? "Locked" : "Unlocked"}
                      </Badge>
                      {pos.boostMultiplier > 1 && <Badge>{pos.boostMultiplier}x boost</Badge>}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Staked: {formatTokenAmount(pos.amount)} {pos.stakingToken.symbol}
                    </div>
                    <Separator className="my-2" />
                    <div className="space-y-1">
                      {pos.pendingRewards.map((r, i) => (
                        <div key={i} className="flex items-center gap-2 text-sm">
                          <TrendingUp className="h-4 w-4 text-green-600" />
                          <span>{formatTokenAmount(r.amount)} {r.token.symbol}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="flex sm:flex-col gap-2 justify-end">
                    <Button
                      size="sm"
                      onClick={() => handleClaim(pos.id)}
                      disabled={posReward === 0 || pendingPosId === pos.id}
                    >
                      {pendingPosId === pos.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Gift className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
