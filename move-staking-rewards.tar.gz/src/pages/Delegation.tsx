import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { useWallet } from "@/hooks/useWallet"
import { MOCK_VALIDATORS, getMockDelegations } from "@/lib/aptos"
import { formatTokenAmount, formatAddress } from "@/lib/utils"
import { Server, TrendingUp, Loader2, Shield, Coins, ArrowRightLeft } from "lucide-react"
import type { ValidatorInfo, DelegationInfo } from "@/types"

function ValidatorCard({
  validator,
  onDelegate,
}: {
  validator: ValidatorInfo
  onDelegate: (addr: string, amount: number) => void
}) {
  const [amount, setAmount] = useState("")
  const [pending, setPending] = useState(false)

  const handleDelegate = async () => {
    const num = parseFloat(amount)
    if (!num || num <= 0) return
    setPending(true)
    await new Promise((r) => setTimeout(r, 1500))
    onDelegate(validator.address, num)
    setAmount("")
    setPending(false)
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Server className="h-4 w-4" />
            {validator.name}
          </CardTitle>
          <div className="flex items-center gap-2">
            <Badge variant={validator.active ? "default" : "destructive"}>
              {validator.active ? "Active" : "Inactive"}
            </Badge>
            <Badge variant="outline" className="text-green-600">{validator.apy}% APY</Badge>
          </div>
        </div>
        <CardDescription>{formatAddress(validator.address)}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div>
            <p className="text-xs text-muted-foreground">Total Stake</p>
            <p className="font-medium">{formatTokenAmount(validator.totalStake)} APT</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Commission</p>
            <p className="font-medium">{validator.commissionRate}%</p>
          </div>
        </div>

        <Separator />

        <div className="space-y-2">
          <Label className="text-xs">Delegate APT</Label>
          <div className="flex gap-2">
            <Input
              type="number"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
            <Button
              size="sm"
              onClick={handleDelegate}
              disabled={pending || !amount}
            >
              {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Delegate"}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default function Delegation() {
  const wallet = useWallet()
  const [delegations, setDelegations] = useState<DelegationInfo[]>(getMockDelegations())

  const handleDelegate = (addr: string, amount: number) => {
    setDelegations((prev) => {
      const existing = prev.find((d) => d.validatorAddress === addr)
      if (existing) {
        return prev.map((d) =>
          d.validatorAddress === addr ? { ...d, amount: d.amount + amount } : d
        )
      }
      return [...prev, { validatorAddress: addr, amount, rewardsEarned: 0, isActive: true }]
    })
  }

  const handleUndelegate = async (addr: string) => {
    setDelegations((prev) => prev.filter((d) => d.validatorAddress !== addr))
  }

  const totalDelegated = delegations.reduce((s, d) => s + d.amount, 0)
  const totalRewards = delegations.reduce((s, d) => s + d.rewardsEarned, 0)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Validator Delegation</h1>
        <p className="text-muted-foreground">Delegate APT to validators and earn staking rewards</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              <div>
                <p className="text-xs text-muted-foreground">Total Delegated</p>
                <p className="text-2xl font-bold">{formatTokenAmount(totalDelegated)} APT</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Coins className="h-5 w-5 text-green-600" />
              <div>
                <p className="text-xs text-muted-foreground">Rewards Earned</p>
                <p className="text-2xl font-bold text-green-600">{formatTokenAmount(totalRewards)} APT</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Server className="h-5 w-5 text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Active Delegations</p>
                <p className="text-2xl font-bold">{delegations.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {delegations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Your Delegations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {delegations.map((del) => {
                const val = MOCK_VALIDATORS.find((v) => v.address === del.validatorAddress)
                return (
                  <div key={del.validatorAddress} className="flex items-center justify-between p-3 rounded-md border">
                    <div>
                      <p className="font-medium">{val?.name ?? formatAddress(del.validatorAddress)}</p>
                      <p className="text-sm text-muted-foreground">
                        {formatTokenAmount(del.amount)} APT staked | {formatTokenAmount(del.rewardsEarned)} APT earned
                      </p>
                    </div>
                    <Button size="sm" variant="outline" onClick={() => handleUndelegate(del.validatorAddress)}>
                      <ArrowRightLeft className="mr-1 h-3 w-3" /> Undelegate
                    </Button>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      )}

      <h2 className="text-xl font-semibold">Validators</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {MOCK_VALIDATORS.map((v) => (
          <ValidatorCard key={v.address} validator={v} onDelegate={handleDelegate} />
        ))}
      </div>
    </div>
  )
}
