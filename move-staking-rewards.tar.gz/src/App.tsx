import {
  AlertTriangle,
  ArrowUpRight,
  BadgeDollarSign,
  CandlestickChart,
  CheckCircle2,
  CircleDollarSign,
  Coins,
  Gauge,
  Gem,
  Layers3,
  LockKeyhole,
  ShieldAlert,
  Sparkles,
  TimerReset,
  Vault,
} from 'lucide-react';

type RewardToken = {
  symbol: string;
  apr: number;
  perSecond: string;
};

type LockTier = {
  name: string;
  duration: string;
  boost: string;
};

type Pool = {
  id: string;
  name: string;
  category: 'Single Token' | 'LP Staking' | 'NFT Staking' | 'veToken';
  tvl: string;
  stakedAsset: string;
  lockModel: string;
  boosts: string[];
  rewards: RewardToken[];
  risk: 'Low' | 'Medium' | 'Strategic';
};

type Metric = {
  label: string;
  value: string;
  change: string;
  icon: typeof Coins;
};

const metrics: Metric[] = [
  { label: 'Total Value Locked', value: '$184.2M', change: '+12.4% WoW', icon: CandlestickChart },
  { label: 'Rewards Streaming', value: '92.4 APT/s', change: 'Across 14 gauges', icon: CircleDollarSign },
  { label: 'Delegated Stake', value: '1.84M APT', change: '8 active validators', icon: ShieldAlert },
  { label: 'Vault Auto-Compound', value: '$38.9M', change: 'Rebalanced every 4h', icon: Vault },
];

const pools: Pool[] = [
  {
    id: 'apt-core',
    name: 'APT Core Reserve',
    category: 'Single Token',
    tvl: '$54.8M',
    stakedAsset: 'APT',
    lockModel: 'Flexible or 30/90/180 day locks',
    boosts: ['veAPT multiplier', 'Validator uptime bonus', 'Genesis NFT bonus'],
    risk: 'Low',
    rewards: [
      { symbol: 'APT', apr: 11.8, perSecond: '21.20 / sec' },
      { symbol: 'stAPT', apr: 2.4, perSecond: '4.10 / sec' },
    ],
  },
  {
    id: 'apt-usdc-lp',
    name: 'APT-USDC Depth Vault',
    category: 'LP Staking',
    tvl: '$41.1M',
    stakedAsset: 'APT-USDC LP',
    lockModel: '7/30/60 day tiered locks',
    boosts: ['Auto-compounding', 'Emission voting', 'Market making rebate'],
    risk: 'Medium',
    rewards: [
      { symbol: 'APT', apr: 18.2, perSecond: '10.02 / sec' },
      { symbol: 'THL', apr: 9.7, perSecond: '2.94 / sec' },
      { symbol: 'USDC', apr: 4.2, perSecond: '6.20 / sec' },
    ],
  },
  {
    id: 'legends-nft',
    name: 'Legends Collection Forge',
    category: 'NFT Staking',
    tvl: '$12.7M',
    stakedAsset: 'Legends NFTs',
    lockModel: 'No lock, rarity-weighted boosts',
    boosts: ['Trait score multiplier', 'Companion set bonus', 'Quest rewards'],
    risk: 'Strategic',
    rewards: [
      { symbol: 'LGS', apr: 22.5, perSecond: '18.80 / sec' },
      { symbol: 'APT', apr: 3.1, perSecond: '1.10 / sec' },
    ],
  },
  {
    id: 'veapt-governance',
    name: 'veAPT Governance Lock',
    category: 'veToken',
    tvl: '$75.6M',
    stakedAsset: 'APT -> veAPT',
    lockModel: '1 week to 4 year decay model',
    boosts: ['Gauge voting', 'Fee share', 'Boost delegation'],
    risk: 'Low',
    rewards: [
      { symbol: 'veAPT', apr: 14.1, perSecond: '46.30 / sec' },
      { symbol: 'APT', apr: 5.6, perSecond: '8.80 / sec' },
    ],
  },
];

const lockTiers: LockTier[] = [
  { name: 'Sprint', duration: '7 days', boost: '1.05x' },
  { name: 'Core', duration: '30 days', boost: '1.35x' },
  { name: 'Conviction', duration: '90 days', boost: '1.8x' },
  { name: 'Institutional', duration: '180 days', boost: '2.4x' },
];

const rewardTimeline = [
  { time: '00:00 UTC', event: 'Reward index checkpoint', detail: 'Pool snapshots persist per-second emission state.' },
  { time: '04:00 UTC', event: 'Vault compound cycle', detail: 'LP rewards harvested, swapped, and re-deployed.' },
  { time: '12:00 UTC', event: 'Validator rebalance', detail: 'Delegation moved toward highest net yield and uptime.' },
  { time: '18:00 UTC', event: 'Gauge vote sync', detail: 'veAPT voting power refreshes pool boosts.' },
];

const validatorRows = [
  { name: 'Atlas One', stake: '420k APT', apy: '8.9%', commission: '4%', uptime: '99.98%' },
  { name: 'Pontem Secure', stake: '295k APT', apy: '8.6%', commission: '5%', uptime: '99.91%' },
  { name: 'Echelon Labs', stake: '240k APT', apy: '8.4%', commission: '3%', uptime: '99.83%' },
];

const dashboardCards = [
  { label: 'Claimable Rewards', value: '$18,420.33', note: 'Across 6 reward tokens' },
  { label: 'Boosted Position Value', value: '$246,118', note: '1.92x net multiplier active' },
  { label: 'Auto-Compound Gain', value: '+$4,931', note: '30-day added performance' },
  { label: 'Emergency Liquidity', value: '$63,000', note: 'Available with penalty bypass disabled' },
];

function formatApr(rewards: RewardToken[]) {
  return `${rewards.reduce((sum, reward) => sum + reward.apr, 0).toFixed(1)}% APR`;
}

function App() {
  return (
    <div className="app-shell">
      <header className="hero">
        <div className="hero__backdrop" />
        <nav className="topbar">
          <div>
            <p className="eyebrow">Aptos Staking Suite</p>
            <h1>Multi-reward staking with veToken governance and validator yield routing.</h1>
          </div>
          <button className="connect-button">Connect Wallet</button>
        </nav>

        <section className="hero__content">
          <div className="hero__copy">
            <p>
              Discover single-token pools, LP vaults, NFT farms, and veAPT locks with per-second
              emissions, multi-token rewards, boost multipliers, validator delegation, and guarded
              emergency exits.
            </p>
            <div className="hero__actions">
              <button className="primary-button">Launch Staking</button>
              <button className="secondary-button">View Docs</button>
            </div>
            <div className="hero__pills">
              <span>Per-second accounting</span>
              <span>Tiered locks</span>
              <span>Multi-token rewards</span>
              <span>Auto-compounding</span>
            </div>
          </div>

          <div className="hero__panel glass-card">
            <div className="hero__panel-header">
              <p className="eyebrow">Live Strategy Overview</p>
              <span className="status-pill">
                <CheckCircle2 size={16} />
                Healthy
              </span>
            </div>
            <div className="strategy-grid">
              <div>
                <span>Primary Gauge</span>
                <strong>APT-USDC Depth Vault</strong>
              </div>
              <div>
                <span>Current Net APR</span>
                <strong>32.1%</strong>
              </div>
              <div>
                <span>Boost Source</span>
                <strong>veAPT + Genesis NFT</strong>
              </div>
              <div>
                <span>Delegation Route</span>
                <strong>Atlas One validator</strong>
              </div>
            </div>
            <div className="hero__panel-footer">
              <span>Compound cycle in 02:14:18</span>
              <ArrowUpRight size={18} />
            </div>
          </div>
        </section>
      </header>

      <main className="content">
        <section className="metrics-grid">
          {metrics.map(({ label, value, change, icon: Icon }) => (
            <article key={label} className="metric-card glass-card">
              <div className="metric-card__icon">
                <Icon size={18} />
              </div>
              <div>
                <p>{label}</p>
                <h2>{value}</h2>
                <span>{change}</span>
              </div>
            </article>
          ))}
        </section>

        <section className="section-header">
          <div>
            <p className="eyebrow">Pool Discovery</p>
            <h2>Curated staking rails across Aptos liquidity, collectibles, and governance.</h2>
          </div>
          <div className="filter-row">
            <span>4 active strategies</span>
            <span>Zero downtime migrations</span>
          </div>
        </section>

        <section className="pool-grid">
          {pools.map((pool) => (
            <article key={pool.id} className="pool-card glass-card">
              <div className="pool-card__header">
                <div>
                  <p className="eyebrow">{pool.category}</p>
                  <h3>{pool.name}</h3>
                </div>
                <span className={`risk-pill risk-pill--${pool.risk.toLowerCase()}`}>{pool.risk}</span>
              </div>

              <div className="pool-card__stats">
                <div>
                  <span>TVL</span>
                  <strong>{pool.tvl}</strong>
                </div>
                <div>
                  <span>Asset</span>
                  <strong>{pool.stakedAsset}</strong>
                </div>
                <div>
                  <span>Total Rewards</span>
                  <strong>{formatApr(pool.rewards)}</strong>
                </div>
                <div>
                  <span>Lock Model</span>
                  <strong>{pool.lockModel}</strong>
                </div>
              </div>

              <div className="reward-table">
                {pool.rewards.map((reward) => (
                  <div key={`${pool.id}-${reward.symbol}`} className="reward-row">
                    <div>
                      <span>{reward.symbol}</span>
                      <strong>{reward.apr.toFixed(1)}% APR</strong>
                    </div>
                    <p>{reward.perSecond}</p>
                  </div>
                ))}
              </div>

              <div className="pool-card__boosts">
                {pool.boosts.map((boost) => (
                  <span key={boost}>{boost}</span>
                ))}
              </div>

              <div className="pool-card__actions">
                <button className="primary-button">Stake</button>
                <button className="secondary-button">Analytics</button>
              </div>
            </article>
          ))}
        </section>

        <section className="two-column">
          <article className="glass-card stake-panel">
            <div className="section-title">
              <div>
                <p className="eyebrow">Staking Interface</p>
                <h2>Configure lock tiers, rewards routing, and boost attachments.</h2>
              </div>
              <LockKeyhole size={20} />
            </div>

            <div className="stake-panel__grid">
              <div className="input-card">
                <label htmlFor="asset">Asset / Position</label>
                <select id="asset" defaultValue="APT-USDC LP">
                  <option>APT-USDC LP</option>
                  <option>APT</option>
                  <option>Legends NFT #184</option>
                  <option>APT to veAPT</option>
                </select>
              </div>
              <div className="input-card">
                <label htmlFor="amount">Amount</label>
                <input id="amount" type="text" defaultValue="1,250.00" />
              </div>
              <div className="input-card">
                <label htmlFor="reward">Primary reward token</label>
                <select id="reward" defaultValue="Auto-compound">
                  <option>Auto-compound</option>
                  <option>APT</option>
                  <option>USDC</option>
                  <option>THL</option>
                </select>
              </div>
              <div className="input-card">
                <label htmlFor="boost">Boost source</label>
                <select id="boost" defaultValue="veAPT delegation">
                  <option>veAPT delegation</option>
                  <option>Genesis NFT</option>
                  <option>Validator loyalty</option>
                </select>
              </div>
            </div>

            <div className="tier-grid">
              {lockTiers.map((tier) => (
                <div key={tier.name} className="tier-card">
                  <span>{tier.name}</span>
                  <strong>{tier.duration}</strong>
                  <p>{tier.boost} reward boost</p>
                </div>
              ))}
            </div>

            <div className="stake-summary">
              <div>
                <span>Projected rewards</span>
                <strong>+$1,284 / month</strong>
              </div>
              <div>
                <span>Net multiplier</span>
                <strong>1.92x</strong>
              </div>
              <div>
                <span>Unlock date</span>
                <strong>September 22, 2026</strong>
              </div>
            </div>
          </article>

          <article className="glass-card dashboard-panel">
            <div className="section-title">
              <div>
                <p className="eyebrow">Rewards Dashboard</p>
                <h2>Claim, compound, and route emissions across all positions.</h2>
              </div>
              <BadgeDollarSign size={20} />
            </div>

            <div className="dashboard-cards">
              {dashboardCards.map((card) => (
                <div key={card.label} className="dashboard-card">
                  <span>{card.label}</span>
                  <strong>{card.value}</strong>
                  <p>{card.note}</p>
                </div>
              ))}
            </div>

            <div className="timeline">
              {rewardTimeline.map((item) => (
                <div key={item.time} className="timeline__item">
                  <span>{item.time}</span>
                  <div>
                    <strong>{item.event}</strong>
                    <p>{item.detail}</p>
                  </div>
                </div>
              ))}
            </div>
          </article>
        </section>

        <section className="three-column">
          <article className="glass-card feature-card">
            <div className="feature-card__title">
              <Vault size={18} />
              <h3>Auto-Compounding Vaults</h3>
            </div>
            <p>
              Harvests reward tokens on a fixed schedule, swaps into underlying liquidity legs, and
              redeploys with slippage caps and strategy-specific fee controls.
            </p>
            <ul>
              <li>Supports multi-token harvest bundles</li>
              <li>Allocates by target pool weights</li>
              <li>Reports gross and net APY deltas</li>
            </ul>
          </article>

          <article className="glass-card feature-card">
            <div className="feature-card__title">
              <ShieldAlert size={18} />
              <h3>Validator Delegation</h3>
            </div>
            <p>
              Routes idle APT into delegated stake with uptime-aware validator scoring and
              commission-adjusted reward estimation.
            </p>
            <div className="validator-list">
              {validatorRows.map((validator) => (
                <div key={validator.name} className="validator-row">
                  <div>
                    <strong>{validator.name}</strong>
                    <span>{validator.stake}</span>
                  </div>
                  <p>{validator.apy} APY</p>
                  <p>{validator.commission} fee</p>
                  <p>{validator.uptime} uptime</p>
                </div>
              ))}
            </div>
          </article>

          <article className="glass-card feature-card">
            <div className="feature-card__title">
              <AlertTriangle size={18} />
              <h3>Emergency Withdrawal</h3>
            </div>
            <p>
              Allows immediate exit with configurable penalties, pauses auto-compounding, and
              protects reward accounting during high-volatility windows.
            </p>
            <div className="emergency-box">
              <span>Penalty if active lock is bypassed</span>
              <strong>4.5% unwind fee</strong>
              <button className="danger-button">Simulate Withdrawal</button>
            </div>
          </article>
        </section>

        <section className="tokenomics">
          <article className="glass-card tokenomics__main">
            <div className="section-title">
              <div>
                <p className="eyebrow">veToken Model</p>
                <h2>Time-locked veAPT powers boosts, fee sharing, and gauge voting.</h2>
              </div>
              <Sparkles size={20} />
            </div>
            <div className="tokenomics__stats">
              <div>
                <Gem size={18} />
                <strong>2.6x max boost</strong>
                <span>Attach veAPT power to any eligible pool.</span>
              </div>
              <div>
                <Gauge size={18} />
                <strong>Weekly gauge votes</strong>
                <span>Direct reward streams toward favored markets.</span>
              </div>
              <div>
                <TimerReset size={18} />
                <strong>Linear decay</strong>
                <span>Voting power trends down until lock extension.</span>
              </div>
              <div>
                <Layers3 size={18} />
                <strong>Delegable boosts</strong>
                <span>Split veAPT across partner vaults and LPs.</span>
              </div>
            </div>
          </article>

          <aside className="glass-card tokenomics__side">
            <div className="tokenomics__side-header">
              <p className="eyebrow">Protocol Revenue</p>
              <strong>$842k / month</strong>
            </div>
            <div className="revenue-splits">
              <div>
                <span>veAPT lockers</span>
                <strong>45%</strong>
              </div>
              <div>
                <span>Treasury</span>
                <strong>20%</strong>
              </div>
              <div>
                <span>Vault operators</span>
                <strong>15%</strong>
              </div>
              <div>
                <span>Insurance reserve</span>
                <strong>20%</strong>
              </div>
            </div>
          </aside>
        </section>
      </main>
    </div>
  );
}

export default App;
