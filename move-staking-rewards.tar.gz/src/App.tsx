import { BrowserRouter, Routes, Route } from "react-router-dom"
import { Layout } from "@/components/layout/Layout"
import { useWallet } from "@/hooks/useWallet"
import PoolDiscovery from "@/pages/PoolDiscovery"
import StakingInterface from "@/pages/StakingInterface"
import RewardsDashboard from "@/pages/RewardsDashboard"
import NFTStaking from "@/pages/NFTStaking"
import VeToken from "@/pages/VeToken"
import Vaults from "@/pages/Vaults"
import Delegation from "@/pages/Delegation"

export default function App() {
  const wallet = useWallet()

  return (
    <BrowserRouter>
      <Layout
        connected={wallet.connected}
        address={wallet.address}
        balance={wallet.balance}
        connecting={wallet.connecting}
        onConnect={wallet.connect}
        onDisconnect={wallet.disconnect}
      >
        <Routes>
          <Route path="/" element={<PoolDiscovery />} />
          <Route path="/stake" element={<StakingInterface />} />
          <Route path="/rewards" element={<RewardsDashboard />} />
          <Route path="/nft" element={<NFTStaking />} />
          <Route path="/vetoken" element={<VeToken />} />
          <Route path="/vaults" element={<Vaults />} />
          <Route path="/delegate" element={<Delegation />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  )
}
