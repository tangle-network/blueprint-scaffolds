export type FlowKind = 'add' | 'remove' | 'swap';

export type TokenOption = {
  symbol: string;
  address: string;
  decimals: number;
};

export type QuoteResult = {
  estimatedOut: number;
  minOut: number;
  priceImpactBps: number;
  reserveBand: string;
};

export type EncryptedPayload = {
  hex: string;
  securityZone: number;
  length: number;
};

export type PreparedAction = {
  calldata: string;
  encryptedAmount: EncryptedPayload;
  permitPublicKey?: string;
  summary: string;
};

export type PoolSnapshot = {
  label: string;
  reserveBand: string;
  utilizationBand: string;
  invariantBand: string;
  mevShield: string;
};

export type DemoState = {
  token0: number;
  token1: number;
  lpSupply: number;
};
