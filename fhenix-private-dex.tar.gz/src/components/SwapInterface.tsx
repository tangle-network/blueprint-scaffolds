"use client";

import { useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { TOKENS, SLIPPAGE_TOLERANCE } from "@/lib/constants";
import { getSwapQuote, executeSwap } from "@/lib/contract";
import { encryptAmount, type FHECiphertext } from "@/lib/fhe";
import type { PoolState, SwapQuote } from "@/lib/contract";

interface SwapInterfaceProps {
  poolState: PoolState | null;
  isLoading: boolean;
  onSwapComplete: () => void;
}

export function SwapInterface({ poolState, isLoading, onSwapComplete }: SwapInterfaceProps) {
  const [isAToB, setIsAToB] = useState(true);
  const [amountIn, setAmountIn] = useState("");
  const [quote, setQuote] = useState<SwapQuote | null>(null);
  const [isQuoting, setIsQuoting] = useState(false);
  const [isSwapping, setIsSwapping] = useState(false);
  const [lastTxHash, setLastTxHash] = useState<string | null>(null);
  const [encOutput, setEncOutput] = useState<FHECiphertext | null>(null);

  const tokenIn = isAToB ? TOKENS[0] : TOKENS[1];
  const tokenOut = isAToB ? TOKENS[1] : TOKENS[0];

  const handleQuote = useCallback(async () => {
    const amt = parseFloat(amountIn);
    if (isNaN(amt) || amt <= 0) return;
    setIsQuoting(true);
    try {
      const q = await getSwapQuote("default", amt, isAToB, SLIPPAGE_TOLERANCE);
      setQuote(q);
    } finally {
      setIsQuoting(false);
    }
  }, [amountIn, isAToB]);

  const handleSwap = useCallback(async () => {
    if (!quote) return;
    setIsSwapping(true);
    try {
      const result = await executeSwap("default", quote.amountIn, isAToB, quote.minAmountOut);
      setLastTxHash(result.txHash);
      setEncOutput(result.amountOut);
      setAmountIn("");
      setQuote(null);
      onSwapComplete();
    } finally {
      setIsSwapping(false);
    }
  }, [quote, isAToB, onSwapComplete]);

  const flipTokens = () => {
    setIsAToB(!isAToB);
    setQuote(null);
    setAmountIn("");
  };

  return (
    <Card className="glow-border">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <svg className="h-5 w-5 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
          </svg>
          Private Swap
          <Badge variant="secondary" className="ml-auto text-xs">FHE Encrypted</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>You Pay</Label>
          <div className="flex gap-2">
            <Input
              type="number"
              placeholder="0.0"
              value={amountIn}
              onChange={(e) => {
                setAmountIn(e.target.value);
                setQuote(null);
              }}
              className="flex-1"
            />
            <div className="flex items-center px-3 rounded-md border border-input bg-secondary text-sm font-medium min-w-[80px] justify-center">
              {tokenIn.symbol}
            </div>
          </div>
        </div>

        <div className="flex justify-center">
          <button
            onClick={flipTokens}
            className="h-8 w-8 rounded-full border border-border bg-card hover:bg-accent flex items-center justify-center transition-colors"
          >
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
            </svg>
          </button>
        </div>

        <div className="space-y-2">
          <Label>You Receive (Encrypted)</Label>
          <div className="flex gap-2">
            <div className="flex-1 h-10 rounded-md border border-input bg-secondary/50 px-3 py-2 text-sm text-muted-foreground flex items-center">
              {quote ? (
                <span className="cipher-text text-foreground">
                  {encryptAmount(quote.estimatedAmountOut).hash}...
                </span>
              ) : (
                "Get a quote to see encrypted output"
              )}
            </div>
            <div className="flex items-center px-3 rounded-md border border-input bg-secondary text-sm font-medium min-w-[80px] justify-center">
              {tokenOut.symbol}
            </div>
          </div>
        </div>

        <div className="flex gap-2">
          <Button
            className="flex-1"
            onClick={handleQuote}
            disabled={!amountIn || parseFloat(amountIn) <= 0 || isQuoting || isLoading}
            variant="secondary"
          >
            {isQuoting ? "Encrypting Quote..." : "Get Private Quote"}
          </Button>
          <Button
            className="flex-1"
            onClick={handleSwap}
            disabled={!quote || isSwapping}
          >
            {isSwapping ? "Executing Encrypted Swap..." : "Swap Privately"}
          </Button>
        </div>

        {quote && (
          <>
            <Separator />
            <div className="space-y-2 text-sm">
              <div className="flex justify-between text-muted-foreground">
                <span>Estimated Output</span>
                <span className="cipher-text text-foreground">
                  {quote.encryptedAmountOut.hash}...
                </span>
              </div>
              <div className="flex justify-between text-muted-foreground">
                <span>Price Impact</span>
                <span className={quote.priceImpact > 5 ? "text-destructive" : "text-green-400"}>
                  {quote.priceImpact.toFixed(2)}%
                </span>
              </div>
              <div className="flex justify-between text-muted-foreground">
                <span>Fee (0.3%)</span>
                <span>{quote.fee.toFixed(6)} (encrypted)</span>
              </div>
              <div className="flex justify-between text-muted-foreground">
                <span>Min. Received</span>
                <span className="cipher-text">{encryptAmount(quote.minAmountOut).hash}...</span>
              </div>
              <div className="flex justify-between text-muted-foreground">
                <span>Slippage Tolerance</span>
                <span>{SLIPPAGE_TOLERANCE}%</span>
              </div>
            </div>
          </>
        )}

        {lastTxHash && encOutput && (
          <>
            <Separator />
            <div className="rounded-md bg-secondary/50 p-3 space-y-1">
              <p className="text-xs font-medium text-green-400">Swap Executed Successfully</p>
              <p className="text-xs text-muted-foreground cipher-text">
                TX: {lastTxHash.slice(0, 20)}...
              </p>
              <p className="text-xs text-muted-foreground">
                Encrypted Output: <span className="cipher-text text-foreground">{encOutput.hash}...</span>
              </p>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
