"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { connectWallet } from "@/lib/contract";

interface WalletConnectProps {
  onConnect: (address: string) => void;
  isConnected?: boolean;
}

export function WalletConnect({ onConnect, isConnected }: WalletConnectProps) {
  const [isConnecting, setIsConnecting] = useState(false);

  const handleConnect = async () => {
    setIsConnecting(true);
    try {
      const address = await connectWallet();
      onConnect(address);
    } finally {
      setIsConnecting(false);
    }
  };

  if (isConnected) {
    return (
      <Button variant="outline" onClick={handleConnect} disabled={isConnecting}>
        {isConnecting ? "Reconnecting..." : "Connected"}
      </Button>
    );
  }

  return (
    <Card className="w-full max-w-sm glow-border">
      <CardContent className="pt-6 space-y-4">
        <div className="text-center space-y-2">
          <div className="mx-auto h-16 w-16 rounded-full bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center">
            <svg className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <h3 className="font-semibold">Connect Wallet</h3>
          <p className="text-xs text-muted-foreground">
            Connect to start private trading with FHE encryption
          </p>
        </div>
        <Button className="w-full" onClick={handleConnect} disabled={isConnecting}>
          {isConnecting ? "Connecting..." : "Connect Fhenix Wallet"}
        </Button>
      </CardContent>
    </Card>
  );
}
