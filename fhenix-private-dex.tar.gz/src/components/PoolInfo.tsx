"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { TOKENS, CONTRACTS, FEE_RATE } from "@/lib/constants";
import { encryptAmount } from "@/lib/fhe";
import type { PoolState } from "@/lib/contract";

interface PoolInfoProps {
  poolState: PoolState | null;
  isLoading: boolean;
}

export function PoolInfo({ poolState, isLoading }: PoolInfoProps) {
  if (isLoading || !poolState) {
    return (
      <Card className="glow-border">
        <CardHeader>
          <CardTitle className="text-base">Pool Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 animate-pulse">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-4 bg-secondary rounded w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="glow-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            Pool Information
            <Badge variant="outline" className="text-xs">eETH / eUSDC</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">
              Encrypted Reserves
            </p>
            <div className="rounded-md bg-secondary/50 p-2 space-y-1">
              <div className="flex justify-between items-center">
                <span className="text-xs text-muted-foreground">{TOKENS[0].symbol}</span>
                <span className="cipher-text text-xs text-foreground">
                  {poolState.reserveAEncrypted.hash}...
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs text-muted-foreground">{TOKENS[1].symbol}</span>
                <span className="cipher-text text-xs text-foreground">
                  {poolState.reserveBEncrypted.hash}...
                </span>
              </div>
            </div>
          </div>

          <Separator />

          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Fee Rate</span>
              <span>{FEE_RATE}%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Total LP Supply</span>
              <span className="cipher-text">{encryptAmount(poolState.totalLPSupply).hash}...</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Pool ID</span>
              <span className="cipher-text text-xs">{poolState.poolId.slice(0, 16)}...</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="glow-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-base">How FHE Privacy Works</CardTitle>
        </CardHeader>
        <CardContent className="text-xs text-muted-foreground space-y-2">
          <p>
            All swap amounts, liquidity positions, and pool reserves are encrypted using Fully Homomorphic Encryption (FHE).
          </p>
          <div className="space-y-1.5">
            <div className="flex items-start gap-2">
              <span className="text-purple-400 mt-0.5">&#x25CF;</span>
              <span>Swap amounts are never visible on-chain</span>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-indigo-400 mt-0.5">&#x25CF;</span>
              <span>LP contributions remain private</span>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-blue-400 mt-0.5">&#x25CF;</span>
              <span>Reserve balances are FHE-encrypted</span>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-green-400 mt-0.5">&#x25CF;</span>
              <span>MEV bots cannot front-run hidden trades</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="glow-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Contract Addresses</CardTitle>
        </CardHeader>
        <CardContent className="text-xs space-y-2">
          <div className="space-y-1">
            <p className="text-muted-foreground">PrivateDEX</p>
            <p className="cipher-text text-foreground break-all">{CONTRACTS.PrivateDEX}</p>
          </div>
          <div className="space-y-1">
            <p className="text-muted-foreground">{TOKENS[0].name}</p>
            <p className="cipher-text text-foreground break-all">{TOKENS[0].address}</p>
          </div>
          <div className="space-y-1">
            <p className="text-muted-foreground">{TOKENS[1].name}</p>
            <p className="cipher-text text-foreground break-all">{TOKENS[1].address}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
