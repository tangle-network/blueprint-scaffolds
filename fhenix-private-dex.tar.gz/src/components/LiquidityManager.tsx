"use client";

import { useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { TOKENS, SLIPPAGE_TOLERANCE } from "@/lib/constants";
import { addLiquidity, removeLiquidity } from "@/lib/contract";
import { encryptAmount } from "@/lib/fhe";
import type { PoolState, LPPosition } from "@/lib/contract";

interface LiquidityManagerProps {
  poolState: PoolState | null;
  lpPosition: LPPosition | null;
  isLoading: boolean;
  onLiquidityChange: () => void;
}

export function LiquidityManager({
  poolState,
  lpPosition,
  isLoading,
  onLiquidityChange,
}: LiquidityManagerProps) {
  const [mode, setMode] = useState<"add" | "remove">("add");
  const [amountA, setAmountA] = useState("");
  const [amountB, setAmountB] = useState("");
  const [removePercent, setRemovePercent] = useState("");
  const [isWorking, setIsWorking] = useState(false);
  const [lastResult, setLastResult] = useState<{
    txHash: string;
    detail: string;
  } | null>(null);

  const handleAddLiquidity = useCallback(async () => {
    const a = parseFloat(amountA);
    const b = parseFloat(amountB);
    if (isNaN(a) || isNaN(b) || a <= 0 || b <= 0) return;
    setIsWorking(true);
    try {
      const result = await addLiquidity("default", a, b, SLIPPAGE_TOLERANCE);
      setLastResult({
        txHash: result.txHash,
        detail: `Encrypted LP: ${result.lpTokens.hash}...`,
      });
      setAmountA("");
      setAmountB("");
      onLiquidityChange();
    } finally {
      setIsWorking(false);
    }
  }, [amountA, amountB, onLiquidityChange]);

  const handleRemoveLiquidity = useCallback(async () => {
    const pct = parseFloat(removePercent);
    if (isNaN(pct) || pct <= 0 || pct > 100) return;
    setIsWorking(true);
    try {
      const result = await removeLiquidity("default", pct, SLIPPAGE_TOLERANCE);
      setLastResult({
        txHash: result.txHash,
        detail: `Removed ${pct}% — Encrypted A: ${result.amountA.hash}... B: ${result.amountB.hash}...`,
      });
      setRemovePercent("");
      onLiquidityChange();
    } finally {
      setIsWorking(false);
    }
  }, [removePercent, onLiquidityChange]);

  return (
    <Card className="glow-border">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <svg className="h-5 w-5 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
          </svg>
          Liquidity Pool
          <Badge variant="secondary" className="ml-auto text-xs">Encrypted</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Button
            variant={mode === "add" ? "default" : "secondary"}
            className="flex-1"
            size="sm"
            onClick={() => setMode("add")}
          >
            Add Liquidity
          </Button>
          <Button
            variant={mode === "remove" ? "default" : "secondary"}
            className="flex-1"
            size="sm"
            onClick={() => setMode("remove")}
          >
            Remove
          </Button>
        </div>

        {mode === "add" ? (
          <div className="space-y-3">
            <div className="space-y-2">
              <Label>{TOKENS[0].symbol} Amount</Label>
              <Input
                type="number"
                placeholder="0.0"
                value={amountA}
                onChange={(e) => setAmountA(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>{TOKENS[1].symbol} Amount</Label>
              <Input
                type="number"
                placeholder="0.0"
                value={amountB}
                onChange={(e) => setAmountB(e.target.value)}
              />
            </div>
            {amountA && amountB && (
              <div className="text-xs text-muted-foreground space-y-1">
                <div className="flex justify-between">
                  <span>Encrypted LP tokens</span>
                  <span className="cipher-text text-foreground">
                    {encryptAmount(parseFloat(amountA) * parseFloat(amountB)).hash}...
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Pool share (est.)</span>
                  <span>
                    {poolState
                      ? (
                          (parseFloat(amountA) /
                            (parseFloat(amountA) + 100000)) *
                          100
                        ).toFixed(2)
                      : "—"}
                    %
                  </span>
                </div>
              </div>
            )}
            <Button
              className="w-full"
              onClick={handleAddLiquidity}
              disabled={
                !amountA ||
                !amountB ||
                parseFloat(amountA) <= 0 ||
                parseFloat(amountB) <= 0 ||
                isWorking ||
                isLoading
              }
            >
              {isWorking ? "Encrypting & Adding..." : "Add Encrypted Liquidity"}
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {lpPosition && (
              <div className="rounded-md bg-secondary/50 p-3 text-xs space-y-1">
                <p className="text-muted-foreground">Your Encrypted LP Position</p>
                <p className="cipher-text text-foreground">
                  Tokens: {lpPosition.lpTokens.hash}...
                </p>
                <p className="cipher-text text-foreground">
                  {TOKENS[0].symbol}: {lpPosition.contributionA.hash}...
                </p>
                <p className="cipher-text text-foreground">
                  {TOKENS[1].symbol}: {lpPosition.contributionB.hash}...
                </p>
              </div>
            )}
            <div className="space-y-2">
              <Label>Percentage to Remove (%)</Label>
              <Input
                type="number"
                placeholder="e.g. 50"
                min="1"
                max="100"
                value={removePercent}
                onChange={(e) => setRemovePercent(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              {[25, 50, 75, 100].map((pct) => (
                <Button
                  key={pct}
                  variant="outline"
                  size="sm"
                  className="flex-1 text-xs"
                  onClick={() => setRemovePercent(String(pct))}
                >
                  {pct}%
                </Button>
              ))}
            </div>
            <Button
              className="w-full"
              onClick={handleRemoveLiquidity}
              disabled={
                !removePercent ||
                parseFloat(removePercent) <= 0 ||
                parseFloat(removePercent) > 100 ||
                isWorking ||
                isLoading
              }
            >
              {isWorking ? "Removing..." : "Remove Liquidity"}
            </Button>
          </div>
        )}

        {lastResult && (
          <>
            <Separator />
            <div className="rounded-md bg-secondary/50 p-3 space-y-1">
              <p className="text-xs font-medium text-green-400">Transaction Successful</p>
              <p className="text-xs text-muted-foreground cipher-text">
                TX: {lastResult.txHash.slice(0, 20)}...
              </p>
              <p className="text-xs text-muted-foreground">{lastResult.detail}</p>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
