"use client";

import { Badge } from "@/components/ui/badge";

export function Header() {
  return (
    <header className="border-b border-border">
      <div className="container mx-auto max-w-5xl flex items-center justify-between px-4 py-4">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center">
            <span className="text-white font-bold text-sm">FHE</span>
          </div>
          <h1 className="text-lg font-bold">Private DEX</h1>
          <Badge variant="secondary" className="text-xs">Testnet</Badge>
        </div>
        <div className="flex items-center gap-4">
          <Badge variant="outline" className="cipher-text text-xs">
            Fhenix FHE
          </Badge>
        </div>
      </div>
    </header>
  );
}
