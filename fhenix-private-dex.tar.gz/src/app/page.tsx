"use client";

import { useState, useCallback } from "react";
import { Header } from "@/components/Header";
import { WalletConnect } from "@/components/WalletConnect";
import { SwapInterface } from "@/components/SwapInterface";
import { LiquidityManager } from "@/components/LiquidityManager";
import { PoolInfo } from "@/components/PoolInfo";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import type { PoolState, LPPosition } from "@/lib/contract";
import { getPoolInfo, getLPPosition } from "@/lib/contract";

export default function Home() {
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [poolState, setPoolState] = useState<PoolState | null>(null);
  const [lpPosition, setLpPosition] = useState<LPPosition | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleWalletConnect = useCallback(async (address: string) => {
    setWalletAddress(address);
    setIsLoading(true);
    try {
      const [pool, position] = await Promise.all([
        getPoolInfo("default"),
        getLPPosition("default", address),
      ]);
      setPoolState(pool);
      setLpPosition(position);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const refreshPool = useCallback(async () => {
    if (!walletAddress) return;
    const [pool, position] = await Promise.all([
      getPoolInfo("default"),
      getLPPosition("default", walletAddress),
    ]);
    setPoolState(pool);
    setLpPosition(position);
  }, [walletAddress]);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 container mx-auto max-w-5xl px-4 py-8">
        {!walletAddress ? (
          <div className="flex flex-col items-center justify-center min-h-[60vh] gap-8">
            <div className="text-center space-y-4">
              <h1 className="text-4xl font-bold gradient-text">
                Private DEX
              </h1>
              <p className="text-muted-foreground max-w-md">
                Trade tokens with fully encrypted amounts. Liquidity pools, swap sizes, and LP positions are hidden from all observers using FHE.
              </p>
            </div>
            <WalletConnect onConnect={handleWalletConnect} />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8 w-full max-w-2xl">
              <FeatureCard
                title="Encrypted Swaps"
                description="Trade amounts are never revealed on-chain"
              />
              <FeatureCard
                title="Hidden Liquidity"
                description="Pool reserves stay private via FHE"
              />
              <FeatureCard
                title="MEV Resistant"
                description="No front-running possible on hidden trades"
              />
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold gradient-text">Trading Interface</h2>
                <p className="text-sm text-muted-foreground">
                  Connected: {walletAddress.slice(0, 6)}...{walletAddress.slice(-4)}
                </p>
              </div>
              <WalletConnect onConnect={handleWalletConnect} isConnected={!!walletAddress} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Tabs defaultValue="swap">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="swap">Swap</TabsTrigger>
                    <TabsTrigger value="liquidity">Liquidity</TabsTrigger>
                  </TabsList>
                  <TabsContent value="swap">
                    <SwapInterface
                      poolState={poolState}
                      isLoading={isLoading}
                      onSwapComplete={refreshPool}
                    />
                  </TabsContent>
                  <TabsContent value="liquidity">
                    <LiquidityManager
                      poolState={poolState}
                      lpPosition={lpPosition}
                      isLoading={isLoading}
                      onLiquidityChange={refreshPool}
                    />
                  </TabsContent>
                </Tabs>
              </div>
              <div className="space-y-4">
                <PoolInfo poolState={poolState} isLoading={isLoading} />
              </div>
            </div>
          </div>
        )}
      </main>
      <footer className="border-t py-6 text-center text-sm text-muted-foreground">
        <p>Private DEX — Powered by Fhenix FHE</p>
      </footer>
    </div>
  );
}

function FeatureCard({ title, description }: { title: string; description: string }) {
  return (
    <div className="rounded-lg border border-border bg-card p-4 space-y-2">
      <h3 className="font-semibold text-sm">{title}</h3>
      <p className="text-xs text-muted-foreground">{description}</p>
    </div>
  );
}
