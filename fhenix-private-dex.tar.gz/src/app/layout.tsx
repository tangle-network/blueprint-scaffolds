import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Private DEX - Encrypted Trading",
  description: "Decentralized exchange with fully homomorphic encryption for private trading",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen bg-background antialiased">{children}</body>
    </html>
  );
}
