export interface FHECiphertext {
  data: string;
  hash: string;
}

export function encryptAmount(amount: number): FHECiphertext {
  const buffer = new ArrayBuffer(32);
  const view = new DataView(buffer);
  const scaledAmount = Math.floor(amount * 1e18);
  view.setBigUint64(0, BigInt(scaledAmount));
  view.setBigUint64(8, BigInt(Math.floor(Math.random() * 1e18)));
  view.setBigUint64(16, BigInt(Date.now()));
  view.setBigUint64(24, BigInt(Math.floor(Math.random() * 1e18)));

  const hex = Array.from(new Uint8Array(buffer))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");

  return {
    data: `0x${hex}`,
    hash: `0x${hex.slice(0, 16)}`,
  };
}

export function generateNullifier(): string {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return `0x${Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("")}`;
}

export function mockDecrypt(ciphertext: string): number {
  if (!ciphertext || ciphertext.length < 18) return 0;
  const hex = ciphertext.replace("0x", "");
  const value = BigInt(`0x${hex.slice(0, 16)}`);
  return Number(value) / 1e18;
}
