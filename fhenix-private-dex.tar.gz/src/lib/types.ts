export interface TokenInfo {
  symbol: string;
  name: string;
  decimals: number;
  address: string;
  icon: string;
}

export const KNOWN_TOKENS: TokenInfo[] = [
  { symbol: "FHENIX", name: "Fhenix Token", decimals: 18, address: "0x0000000000000000000000000000000000000001", icon: "F" },
  { symbol: "USDC", name: "USD Coin (Encrypted)", decimals: 6, address: "0x0000000000000000000000000000000000000002", icon: "U" },
  { symbol: "WETH", name: "Wrapped Ether (Encrypted)", decimals: 18, address: "0x0000000000000000000000000000000000000003", icon: "E" },
  { symbol: "WBTC", name: "Wrapped Bitcoin (Encrypted)", decimals: 8, address: "0x0000000000000000000000000000000000000004", icon: "B" },
];

export function getToken(symbol: string): TokenInfo | undefined {
  return KNOWN_TOKENS.find((t) => t.symbol === symbol);
}

export interface PoolInfo {
  address: string;
  tokenA: TokenInfo;
  tokenB: TokenInfo;
  encryptedReserveA: string;
  encryptedReserveB: string;
  encryptedLiquidity: string;
  encryptedPrice: string;
  feeBps: number;
  lpTokenCount: number;
  initialized: boolean;
}

export interface SwapParams {
  poolAddress: string;
  tokenIn: TokenInfo;
  tokenOut: TokenInfo;
  amountIn: string;
  minAmountOut: string;
  deadline: number;
}

export interface LiquidityParams {
  poolAddress: string;
  tokenA: TokenInfo;
  tokenB: TokenInfo;
  amountA: string;
  amountB: string;
  minLpTokens: string;
  deadline: number;
}

export interface RemoveLiquidityParams {
  poolAddress: string;
  lpTokenAmount: string;
  minAmountA: string;
  minAmountB: string;
  deadline: number;
}

export interface WalletState {
  address: string | null;
  connected: boolean;
  chainId: number | null;
  encryptedBalances: Map<string, string>;
}

export interface TransactionStatus {
  hash: string | null;
  status: "idle" | "pending" | "success" | "error";
  message: string;
}

export const FEE_BPS = 30;
export const SLIPPAGE_DEFAULT = 0.5;
export const DEADLINE_DEFAULT = 20 * 60;

export const CONTRACTS = {
  PhantomPoolFactory: "0x5FbDB2315678afecb367f032d93F642f64180aa3" as const,
  PhantomPriceOracle: "0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512" as const,
} as const;

export const CHAIN_ID = 8008135;
export const CHAIN_NAME = "Fhenix Helium";
