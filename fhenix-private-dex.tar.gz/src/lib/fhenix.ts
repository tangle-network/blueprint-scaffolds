import type { Eip1193Provider } from 'ethers';
import { BrowserProvider, Interface, parseUnits } from 'ethers';
import type { Permit, PermitSigner, SupportedProvider } from 'fhenixjs';
import { CONTRACT_ADDRESS, DEX_ABI, SECURITY_ZONE } from '../config';
import type { PreparedAction, TokenOption } from '../types';
import { toHexPayload } from './encoding';

type EthereumWindow = Window & {
  ethereum?: Eip1193Provider;
};

type FhenixModule = typeof import('fhenixjs');
const FHENIX_BROWSER_BUNDLE = 'https://esm.sh/fhenixjs@0.4.1?bundle';

const encoder = new TextEncoder();
const dexInterface = new Interface(DEX_ABI);

const getEthereum = (): Eip1193Provider | undefined =>
  (window as EthereumWindow).ethereum;

const getProvider = (): BrowserProvider => {
  const ethereum = getEthereum();

  if (!ethereum) {
    throw new Error('Install a wallet to generate Fhenix ciphertexts.');
  }

  return new BrowserProvider(ethereum);
};

const importFhenix = async (): Promise<FhenixModule> =>
  import(/* @vite-ignore */ FHENIX_BROWSER_BUNDLE);

const getFhenixProvider = (): SupportedProvider => {
  const browserProvider = getProvider();
  const ethereum = getEthereum();

  if (!ethereum) {
    throw new Error('Install a wallet to generate Fhenix ciphertexts.');
  }

  return {
    request: ethereum.request?.bind(ethereum),
    send: (method: string, params?: unknown[]) => browserProvider.send(method, params ?? []),
    getSigner: () => browserProvider.getSigner(),
  };
};

const bytes32FromHex = (hex: string): string => {
  const normalized = hex.startsWith('0x') ? hex.slice(2) : hex;
  const trimmed = normalized.slice(0, 64);
  return `0x${trimmed.padEnd(64, '0')}`;
};

const encryptAmount = async (amount: string, decimals: number) => {
  const provider = getFhenixProvider();
  const fhenix = await importFhenix();
  const client = new fhenix.FhenixClient({ provider });
  const encrypted = await client.encrypt_uint64(parseUnits(amount, decimals).toString(), SECURITY_ZONE);

  return toHexPayload(encrypted.data, encrypted.securityZone);
};

const getPermit = async (): Promise<Permit> => {
  const provider = getFhenixProvider();
  const fhenix = await importFhenix();
  const signer = await provider.getSigner?.();

  if (!signer) {
    throw new Error('Wallet signer unavailable for permit generation.');
  }

  return fhenix.generatePermit(CONTRACT_ADDRESS, provider, signer as PermitSigner);
};

export const connectWallet = async (): Promise<string> => {
  const provider = getProvider();
  const accounts = await provider.send('eth_requestAccounts', []);
  const first = accounts[0];

  if (typeof first !== 'string') {
    throw new Error('Wallet did not return an account.');
  }

  return first;
};

export const supportsWallet = (): boolean => Boolean(getEthereum());

export const prepareAddLiquidity = async (
  amount0: string,
  amount1: string,
  token0: TokenOption,
  token1: TokenOption,
  minLpOut: string,
): Promise<PreparedAction> => {
  const [encrypted0, encrypted1, permit] = await Promise.all([
    encryptAmount(amount0, token0.decimals),
    encryptAmount(amount1, token1.decimals),
    getPermit(),
  ]);

  const calldata = dexInterface.encodeFunctionData('addLiquidity', [
    encrypted0.hex,
    encrypted1.hex,
    bytes32FromHex(permit.publicKey),
    parseUnits(minLpOut || '0', 18),
  ]);

  return {
    calldata,
    encryptedAmount: encrypted0,
    permitPublicKey: permit.publicKey,
    summary: `Encrypted ${amount0} ${token0.symbol} and ${amount1} ${token1.symbol} for LP minting.`,
  };
};

export const prepareRemoveLiquidity = async (
  lpAmount: string,
  minAmount0: string,
  minAmount1: string,
): Promise<PreparedAction> => {
  const [encryptedLp, permit] = await Promise.all([
    encryptAmount(lpAmount, 18),
    getPermit(),
  ]);

  const calldata = dexInterface.encodeFunctionData('removeLiquidity', [
    encryptedLp.hex,
    bytes32FromHex(permit.publicKey),
    parseUnits(minAmount0 || '0', 18),
    parseUnits(minAmount1 || '0', 18),
  ]);

  return {
    calldata,
    encryptedAmount: encryptedLp,
    permitPublicKey: permit.publicKey,
    summary: `Prepared encrypted burn for ${lpAmount} sLP with private withdrawal bounds.`,
  };
};

export const prepareSwap = async (
  amountIn: string,
  tokenIn: TokenOption,
  minAmountOut: string,
): Promise<PreparedAction> => {
  const [encryptedAmount, permit] = await Promise.all([
    encryptAmount(amountIn, tokenIn.decimals),
    getPermit(),
  ]);

  const calldata = dexInterface.encodeFunctionData('swap', [
    encryptedAmount.hex,
    tokenIn.address,
    parseUnits(minAmountOut || '0', 18),
    bytes32FromHex(permit.publicKey),
  ]);

  return {
    calldata,
    encryptedAmount,
    permitPublicKey: permit.publicKey,
    summary: `Swap input encrypted for ${tokenIn.symbol}; only your slippage bound remains public.`,
  };
};

export const mockEncryptedAction = (
  label: string,
  amount: string,
): PreparedAction => {
  const payload = encoder.encode(`${label}:${amount}:${Date.now()}`);
  const encryptedAmount = toHexPayload(payload, SECURITY_ZONE);

  return {
    calldata: encryptedAmount.hex,
    encryptedAmount,
    summary: 'Wallet not connected, so this preview uses a local mock ciphertext.',
  };
};
