export const CONTRACTS = {
  PrivateDEX: "0x000000000000000000000000000000000000dEx",
  EncryptedTokenA: "0x0000000000000000000000000000000000tOkA",
  EncryptedTokenB: "0x0000000000000000000000000000000000tOkB",
} as const;

export const CHAIN_CONFIG = {
  chainId: 0x1,
  name: "Fhenix Helium Testnet",
  rpcUrl: "https://api.helium.fhenix.zone",
  blockExplorer: "https://explorer.helium.fhenix.zone",
  nativeCurrency: {
    name: "FHENIX",
    symbol: "fFHENIX",
    decimals: 18,
  },
} as const;

export const FEE_RATE = 0.3;
export const MINIMUM_LIQUIDITY = 1000;
export const SLIPPAGE_TOLERANCE = 0.5;

export const TOKENS = [
  { symbol: "eETH", name: "Encrypted ETH", address: CONTRACTS.EncryptedTokenA },
  { symbol: "eUSDC", name: "Encrypted USDC", address: CONTRACTS.EncryptedTokenB },
] as const;
