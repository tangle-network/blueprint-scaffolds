import type { EncryptedPayload } from '../types';

const bytesToHex = (bytes: Uint8Array): string =>
  `0x${Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('')}`;

export const toHexPayload = (bytes: Uint8Array, securityZone: number): EncryptedPayload => ({
  hex: bytesToHex(bytes),
  securityZone,
  length: bytes.byteLength,
});

export const safeParseAmount = (value: string): number => {
  const parsed = Number(value);

  if (!Number.isFinite(parsed) || parsed <= 0) {
    return 0;
  }

  return parsed;
};

export const clampBps = (value: number): number => {
  if (!Number.isFinite(value)) {
    return 0;
  }

  return Math.min(5_000, Math.max(0, Math.round(value)));
};
