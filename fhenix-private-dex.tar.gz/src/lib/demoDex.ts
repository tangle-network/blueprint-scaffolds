import type { DemoState, PoolSnapshot, QuoteResult } from '../types';
import { clampBps } from './encoding';

export const initialDemoState: DemoState = {
  token0: 4_800,
  token1: 3_300,
  lpSupply: 3_950,
};

export const quoteSwap = (
  reservesIn: number,
  reservesOut: number,
  amountIn: number,
  slippageBps: number,
): QuoteResult => {
  const feeAdjustedIn = amountIn * 0.997;
  const numerator = feeAdjustedIn * reservesOut;
  const denominator = reservesIn + feeAdjustedIn;
  const estimatedOut = denominator === 0 ? 0 : numerator / denominator;
  const priceImpactBps = clampBps((amountIn / Math.max(reservesIn, 1)) * 10_000);
  const minOut = estimatedOut * (1 - slippageBps / 10_000);

  return {
    estimatedOut,
    minOut,
    priceImpactBps,
    reserveBand: toReserveBand(reservesIn, reservesOut),
  };
};

export const estimateLpMint = (
  state: DemoState,
  amount0: number,
  amount1: number,
): number => {
  if (state.lpSupply === 0) {
    return Math.sqrt(amount0 * amount1);
  }

  const minted0 = (amount0 / state.token0) * state.lpSupply;
  const minted1 = (amount1 / state.token1) * state.lpSupply;
  return Math.min(minted0, minted1);
};

export const buildPoolSnapshot = (state: DemoState): PoolSnapshot => {
  const invariant = state.token0 * state.token1;
  const utilization = state.token0 / Math.max(state.token0 + state.token1, 1);

  return {
    label: 'Encrypted Constant Product',
    reserveBand: toReserveBand(state.token0, state.token1),
    utilizationBand:
      utilization > 0.62 ? 'token0 heavy' : utilization < 0.38 ? 'token1 heavy' : 'balanced',
    invariantBand:
      invariant > 16_000_000 ? 'deep liquidity' : invariant > 8_000_000 ? 'medium depth' : 'thin depth',
    mevShield: 'Trade sizes hidden until execution, reducing sandwich precision.',
  };
};

const toReserveBand = (token0: number, token1: number): string => {
  const total = token0 + token1;

  if (total > 10_000) {
    return '9k-12k notional';
  }

  if (total > 6_000) {
    return '6k-9k notional';
  }

  return '3k-6k notional';
};
