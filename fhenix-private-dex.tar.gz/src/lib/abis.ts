export const PHANTOM_POOL_ABI = [
  {
    type: "function",
    name: "addLiquidity",
    inputs: [
      { name: "amountA", type: "inEuint16" },
      { name: "amountB", type: "inEuint16" },
    ],
    outputs: [{ name: "", type: "euint16" }],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "removeLiquidity",
    inputs: [{ name: "lpAmount", type: "inEuint16" }],
    outputs: [
      { name: "", type: "euint16" },
      { name: "", type: "euint16" },
    ],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "swapAtoB",
    inputs: [{ name: "amountIn", type: "inEuint16" }],
    outputs: [{ name: "", type: "euint16" }],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "swapBtoA",
    inputs: [{ name: "amountIn", type: "inEuint16" }],
    outputs: [{ name: "", type: "euint16" }],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "getEncryptedBalance",
    inputs: [
      { name: "owner", type: "address" },
      { name: "perm", type: "tuple", components: [
        { name: "owner", type: "address" },
        { name: "allowedContracts", type: "bytes32[]" },
      ]},
    ],
    outputs: [{ name: "", type: "euint16" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "getEncryptedSupply",
    inputs: [{ name: "perm", type: "tuple", components: [
      { name: "owner", type: "address" },
      { name: "allowedContracts", type: "bytes32[]" },
    ]}],
    outputs: [{ name: "", type: "euint16" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "getEncryptedReserves",
    inputs: [{ name: "perm", type: "tuple", components: [
      { name: "owner", type: "address" },
      { name: "allowedContracts", type: "bytes32[]" },
    ]}],
    outputs: [
      { name: "", type: "euint16" },
      { name: "", type: "euint16" },
    ],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "tokenA",
    inputs: [],
    outputs: [{ name: "", type: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "tokenB",
    inputs: [],
    outputs: [{ name: "", type: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "initialized",
    inputs: [],
    outputs: [{ name: "", type: "bool" }],
    stateMutability: "view",
  },
  {
    type: "event",
    name: "LiquidityAdded",
    inputs: [
      { name: "provider", type: "address", indexed: true },
      { name: "timestamp", type: "uint256", indexed: false },
    ],
  },
  {
    type: "event",
    name: "LiquidityRemoved",
    inputs: [
      { name: "provider", type: "address", indexed: true },
      { name: "timestamp", type: "uint256", indexed: false },
    ],
  },
  {
    type: "event",
    name: "SwapExecuted",
    inputs: [
      { name: "trader", type: "address", indexed: true },
      { name: "directionAtoB", type: "bool", indexed: false },
      { name: "timestamp", type: "uint256", indexed: false },
    ],
  },
] as const;

export const PHANTOM_FACTORY_ABI = [
  {
    type: "function",
    name: "createPool",
    inputs: [
      { name: "tokenA", type: "address" },
      { name: "tokenB", type: "address" },
    ],
    outputs: [{ name: "", type: "address" }],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "getPool",
    inputs: [{ name: "", type: "bytes32" }],
    outputs: [{ name: "", type: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "getPoolAddress",
    inputs: [
      { name: "tokenA", type: "address" },
      { name: "tokenB", type: "address" },
    ],
    outputs: [{ name: "", type: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "allPools",
    inputs: [{ name: "", type: "uint256" }],
    outputs: [{ name: "", type: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "allPoolsLength",
    inputs: [],
    outputs: [{ name: "", type: "uint256" }],
    stateMutability: "view",
  },
  {
    type: "event",
    name: "PoolCreated",
    inputs: [
      { name: "tokenA", type: "address", indexed: true },
      { name: "tokenB", type: "address", indexed: true },
      { name: "pool", type: "address", indexed: false },
      { name: "index", type: "uint256", indexed: false },
    ],
  },
] as const;

export const PHANTOM_ORACLE_ABI = [
  {
    type: "function",
    name: "recordPrice",
    inputs: [
      { name: "pool", type: "address" },
      { name: "perm", type: "tuple", components: [
        { name: "owner", type: "address" },
        { name: "allowedContracts", type: "bytes32[]" },
      ]},
    ],
    outputs: [],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "getLatestPrice",
    inputs: [{ name: "pool", type: "address" }],
    outputs: [{ name: "", type: "tuple", components: [
      { name: "price", type: "euint16" },
      { name: "timestamp", type: "uint256" },
    ]}],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "getPriceHistoryLength",
    inputs: [{ name: "pool", type: "address" }],
    outputs: [{ name: "", type: "uint256" }],
    stateMutability: "view",
  },
  {
    type: "event",
    name: "PriceRecorded",
    inputs: [
      { name: "pool", type: "address", indexed: true },
      { name: "timestamp", type: "uint256", indexed: false },
    ],
  },
] as const;
