import { KNOWN_TOKENS, type PoolInfo, CONTRACTS } from "@/lib/types";
import { mockEncryptedDisplay } from "@/lib/fhe-client";

const MOCK_POOLS: PoolInfo[] = [
  {
    address: "0x1BDd7D0740b6e0EeF5a8fbe5c39B8c1A3E8F8a7e",
    tokenA: KNOWN_TOKENS[0]!,
    tokenB: KNOWN_TOKENS[1]!,
    encryptedReserveA: mockEncryptedDisplay(),
    encryptedReserveB: mockEncryptedDisplay(),
    encryptedLiquidity: mockEncryptedDisplay(),
    encryptedPrice: mockEncryptedDisplay(),
    feeBps: 30,
    lpTokenCount: 12,
    initialized: true,
  },
  {
    address: "0x2aC4f5b3D8e7E2e1B9F06A4c5d3E2f1A8b7C6D4E",
    tokenA: KNOWN_TOKENS[0]!,
    tokenB: KNOWN_TOKENS[2]!,
    encryptedReserveA: mockEncryptedDisplay(),
    encryptedReserveB: mockEncryptedDisplay(),
    encryptedLiquidity: mockEncryptedDisplay(),
    encryptedPrice: mockEncryptedDisplay(),
    feeBps: 30,
    lpTokenCount: 8,
    initialized: true,
  },
  {
    address: "0x3fE7d2A6c1B9D4e5F8a0E3c2B1d4A6c8E7f2D5B8",
    tokenA: KNOWN_TOKENS[2]!,
    tokenB: KNOWN_TOKENS[3]!,
    encryptedReserveA: mockEncryptedDisplay(),
    encryptedReserveB: mockEncryptedDisplay(),
    encryptedLiquidity: mockEncryptedDisplay(),
    encryptedPrice: mockEncryptedDisplay(),
    feeBps: 30,
    lpTokenCount: 5,
    initialized: true,
  },
  {
    address: "0x4D8c2B7e1A6f3E5d9C4b8A2f1E6d3C7b9F4a8D2E",
    tokenA: KNOWN_TOKENS[1]!,
    tokenB: KNOWN_TOKENS[3]!,
    encryptedReserveA: mockEncryptedDisplay(),
    encryptedReserveB: mockEncryptedDisplay(),
    encryptedLiquidity: mockEncryptedDisplay(),
    encryptedPrice: mockEncryptedDisplay(),
    feeBps: 30,
    lpTokenCount: 3,
    initialized: false,
  },
];

export function getPools(): PoolInfo[] {
  return MOCK_POOLS;
}

export function getPoolByTokens(
  tokenASymbol: string,
  tokenBSymbol: string
): PoolInfo | undefined {
  return MOCK_POOLS.find(
    (p) =>
      (p.tokenA.symbol === tokenASymbol && p.tokenB.symbol === tokenBSymbol) ||
      (p.tokenA.symbol === tokenBSymbol && p.tokenB.symbol === tokenASymbol)
  );
}

export function getPoolByAddress(address: string): PoolInfo | undefined {
  return MOCK_POOLS.find((p) => p.address.toLowerCase() === address.toLowerCase());
}

export function getFactoryAddress(): string {
  return CONTRACTS.PhantomPoolFactory;
}

export function getOracleAddress(): string {
  return CONTRACTS.PhantomPriceOracle;
}
