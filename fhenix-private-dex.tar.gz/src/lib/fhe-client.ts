export type EncryptedUint16 = {
  data: Uint8Array;
  hash: string;
};

export type FhePermission = {
  owner: string;
  allowedContracts: string[];
};

export type SealedResult = {
  sealed: Uint8Array;
  plaintext?: number;
};

export function encryptAmount(amount: number): EncryptedUint16 {
  const buffer = new Uint8Array(32);
  const view = new DataView(buffer.buffer);
  view.setUint16(0, amount, false);
  crypto.getRandomValues(buffer.subarray(2));
  return {
    data: buffer,
    hash: Array.from(buffer.slice(0, 4))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join(""),
  };
}

export function createPermission(
  ownerAddress: string,
  contractAddresses: string[]
): FhePermission {
  return {
    owner: ownerAddress,
    allowedContracts: contractAddresses,
  };
}

export function sealResult(
  encryptedData: Uint8Array,
  privateKey?: Uint8Array
): SealedResult {
  return {
    sealed: encryptedData,
    plaintext: undefined,
  };
}

export function computeMinOutput(
  estimatedOutput: number,
  slippagePercent: number
): number {
  return Math.floor(estimatedOutput * (1 - slippagePercent / 100));
}

export function computeConstantProduct(
  reserveA: number,
  reserveB: number,
  amountIn: number,
  feeBps: number
): number {
  const feeMultiplier = (10000 - feeBps) / 10000;
  const amountInWithFee = amountIn * feeMultiplier;
  const numerator = amountInWithFee * reserveB;
  const denominator = reserveA + amountInWithFee;
  return Math.floor(numerator / denominator);
}

export function computeLpTokens(
  reserveA: number,
  reserveB: number,
  amountA: number,
  amountB: number,
  totalSupply: number
): number {
  if (totalSupply === 0) {
    return Math.floor(Math.sqrt(amountA * amountB));
  }
  const liquidityA = Math.floor((totalSupply * amountA) / reserveA);
  const liquidityB = Math.floor((totalSupply * amountB) / reserveB);
  return Math.min(liquidityA, liquidityB);
}

export function computeRemoveLiquidity(
  reserveA: number,
  reserveB: number,
  lpAmount: number,
  totalSupply: number
): { amountA: number; amountB: number } {
  return {
    amountA: Math.floor((reserveA * lpAmount) / totalSupply),
    amountB: Math.floor((reserveB * lpAmount) / totalSupply),
  };
}

export function generateEncryptionKey(): Uint8Array {
  const key = new Uint8Array(32);
  crypto.getRandomValues(key);
  return key;
}

export function mockEncryptedDisplay(): string {
  const chars = "0123456789abcdef";
  let result = "0x";
  for (let i = 0; i < 16; i++) {
    result += chars[Math.floor(Math.random() * chars.length)];
  }
  return result;
}

export function formatEncrypted(label: string, hash: string): string {
  return `${label}: [encrypted ${hash.slice(0, 8)}...]`;
}
