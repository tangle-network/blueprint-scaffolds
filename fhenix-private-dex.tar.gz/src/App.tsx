import { useMemo, useState } from 'react';
import { DEFAULT_SLIPPAGE_BPS, TOKENS } from './config';
import { buildPoolSnapshot, estimateLpMint, initialDemoState, quoteSwap } from './lib/demoDex';
import { clampBps, safeParseAmount } from './lib/encoding';
import {
  connectWallet,
  mockEncryptedAction,
  prepareAddLiquidity,
  prepareRemoveLiquidity,
  prepareSwap,
  supportsWallet,
} from './lib/fhenix';
import type { FlowKind, PreparedAction } from './types';

const token0 = TOKENS[0];
const token1 = TOKENS[1];

const formatNumber = (value: number): string =>
  new Intl.NumberFormat('en-US', {
    maximumFractionDigits: 4,
  }).format(value);

function App() {
  const [account, setAccount] = useState<string>('');
  const [liquidity0, setLiquidity0] = useState<string>('125');
  const [liquidity1, setLiquidity1] = useState<string>('82');
  const [removeAmount, setRemoveAmount] = useState<string>('40');
  const [swapAmount, setSwapAmount] = useState<string>('18');
  const [slippageBps, setSlippageBps] = useState<number>(DEFAULT_SLIPPAGE_BPS);
  const [activeFlow, setActiveFlow] = useState<FlowKind>('swap');
  const [status, setStatus] = useState<string>('Idle');
  const [prepared, setPrepared] = useState<PreparedAction | null>(null);
  const [error, setError] = useState<string>('');

  const poolSnapshot = useMemo(() => buildPoolSnapshot(initialDemoState), []);
  const addLpEstimate = useMemo(
    () => estimateLpMint(initialDemoState, safeParseAmount(liquidity0), safeParseAmount(liquidity1)),
    [liquidity0, liquidity1],
  );
  const swapQuote = useMemo(
    () => quoteSwap(initialDemoState.token0, initialDemoState.token1, safeParseAmount(swapAmount), slippageBps),
    [slippageBps, swapAmount],
  );
  const removeQuote = useMemo(() => {
    const burnShare = safeParseAmount(removeAmount) / Math.max(initialDemoState.lpSupply, 1);

    return {
      amount0: initialDemoState.token0 * burnShare,
      amount1: initialDemoState.token1 * burnShare,
    };
  }, [removeAmount]);

  const handleConnect = async () => {
    try {
      setError('');
      setStatus('Connecting wallet...');
      const nextAccount = await connectWallet();
      setAccount(nextAccount);
      setStatus('Wallet connected. Permits and encrypted calldata are available.');
    } catch (connectError) {
      const message = connectError instanceof Error ? connectError.message : 'Failed to connect wallet.';
      setError(message);
      setStatus('Wallet connection unavailable.');
    }
  };

  const handlePrepare = async (flow: FlowKind) => {
    try {
      setPrepared(null);
      setError('');
      setActiveFlow(flow);
      setStatus(`Preparing ${flow} flow...`);

      if (!supportsWallet()) {
        const fallbackAmount = flow === 'swap' ? swapAmount : flow === 'add' ? liquidity0 : removeAmount;
        setPrepared(mockEncryptedAction(flow, fallbackAmount));
        setStatus('Prepared local preview. Connect a wallet to generate real ciphertexts.');
        return;
      }

      if (flow === 'add') {
        const minLpOut = Math.max(addLpEstimate * (1 - slippageBps / 10_000), 0).toFixed(6);
        setPrepared(await prepareAddLiquidity(liquidity0, liquidity1, token0, token1, minLpOut));
      } else if (flow === 'remove') {
        const min0 = Math.max(removeQuote.amount0 * (1 - slippageBps / 10_000), 0).toFixed(6);
        const min1 = Math.max(removeQuote.amount1 * (1 - slippageBps / 10_000), 0).toFixed(6);
        setPrepared(await prepareRemoveLiquidity(removeAmount, min0, min1));
      } else {
        setPrepared(await prepareSwap(swapAmount, token0, swapQuote.minOut.toFixed(6)));
      }

      setStatus('Encrypted payload prepared. Review calldata and submit with your wallet flow.');
    } catch (prepareError) {
      const message = prepareError instanceof Error ? prepareError.message : 'Encryption failed.';
      setError(message);
      setStatus('Preparation failed.');
    }
  };

  return (
    <div className="shell">
      <header className="hero">
        <div>
          <p className="eyebrow">ShadowSwap / Fhenix FHE</p>
          <h1>Private constant-product liquidity with hidden trade sizes.</h1>
          <p className="lede">
            Liquidity balances, LP shares, and swap inputs stay encrypted while the pool still clears
            against a constant-product invariant and bounded slippage checks.
          </p>
        </div>
        <div className="hero-panel">
          <div className="badge-row">
            <span className="badge">Encrypted reserves</span>
            <span className="badge">Hidden LP balances</span>
            <span className="badge">MEV-resistant sizing</span>
          </div>
          <button className="primary-button" onClick={handleConnect} type="button">
            {account ? `${account.slice(0, 6)}...${account.slice(-4)}` : 'Connect wallet'}
          </button>
          <p className="muted">
            {supportsWallet()
              ? 'Wallet detected. Prepare permit-backed ciphertexts for on-chain execution.'
              : 'No injected wallet found. The UI will show local ciphertext previews only.'}
          </p>
        </div>
      </header>

      <main className="grid">
        <section className="card">
          <div className="section-head">
            <h2>Pool envelope</h2>
            <span className="pill">{poolSnapshot.label}</span>
          </div>
          <dl className="metrics">
            <div>
              <dt>Reserve oracle</dt>
              <dd>{poolSnapshot.reserveBand}</dd>
            </div>
            <div>
              <dt>Utilization</dt>
              <dd>{poolSnapshot.utilizationBand}</dd>
            </div>
            <div>
              <dt>Invariant band</dt>
              <dd>{poolSnapshot.invariantBand}</dd>
            </div>
            <div>
              <dt>MEV shield</dt>
              <dd>{poolSnapshot.mevShield}</dd>
            </div>
          </dl>
        </section>

        <section className="card">
          <div className="section-head">
            <h2>Swap privately</h2>
            <span className="pill">{swapQuote.reserveBand}</span>
          </div>
          <label>
            Token in
            <input value={token0.symbol} disabled />
          </label>
          <label>
            Encrypted amount in
            <input value={swapAmount} onChange={(event) => setSwapAmount(event.target.value)} />
          </label>
          <label>
            Slippage tolerance
            <div className="input-row">
              <input
                value={slippageBps}
                onChange={(event) => setSlippageBps(clampBps(Number(event.target.value)))}
                type="number"
              />
              <span>bps</span>
            </div>
          </label>
          <div className="quote-box">
            <strong>{formatNumber(swapQuote.estimatedOut)} {token1.symbol}</strong>
            <span>Min out: {formatNumber(swapQuote.minOut)}</span>
            <span>Price impact: {swapQuote.priceImpactBps} bps</span>
          </div>
          <button className="primary-button" onClick={() => void handlePrepare('swap')} type="button">
            Encrypt swap
          </button>
        </section>

        <section className="card">
          <div className="section-head">
            <h2>Add liquidity</h2>
            <span className="pill">Private LP minting</span>
          </div>
          <label>
            {token0.symbol} contribution
            <input value={liquidity0} onChange={(event) => setLiquidity0(event.target.value)} />
          </label>
          <label>
            {token1.symbol} contribution
            <input value={liquidity1} onChange={(event) => setLiquidity1(event.target.value)} />
          </label>
          <div className="quote-box">
            <strong>{formatNumber(addLpEstimate)} sLP</strong>
            <span>LP mint estimate stays client-side until encrypted.</span>
            <span>Minted shares derive from encrypted proportional deposits.</span>
          </div>
          <button className="primary-button" onClick={() => void handlePrepare('add')} type="button">
            Encrypt deposit
          </button>
        </section>

        <section className="card">
          <div className="section-head">
            <h2>Remove liquidity</h2>
            <span className="pill">Hidden withdrawal size</span>
          </div>
          <label>
            sLP to burn
            <input value={removeAmount} onChange={(event) => setRemoveAmount(event.target.value)} />
          </label>
          <div className="quote-box">
            <strong>
              {formatNumber(removeQuote.amount0)} {token0.symbol} / {formatNumber(removeQuote.amount1)} {token1.symbol}
            </strong>
            <span>Withdrawals are bounded by slippage checks, not public reserve disclosure.</span>
            <span>Counterparties see the settlement, not the requested burn size.</span>
          </div>
          <button className="primary-button" onClick={() => void handlePrepare('remove')} type="button">
            Encrypt burn
          </button>
        </section>

        <section className="card wide">
          <div className="section-head">
            <h2>Prepared payload</h2>
            <span className="pill">{activeFlow}</span>
          </div>
          <p className="status">{status}</p>
          {error ? <p className="error">{error}</p> : null}
          {prepared ? (
            <div className="payload-grid">
              <div>
                <h3>Summary</h3>
                <p>{prepared.summary}</p>
              </div>
              <div>
                <h3>Ciphertext</h3>
                <code>{prepared.encryptedAmount.hex}</code>
              </div>
              <div>
                <h3>Metadata</h3>
                <p>Security zone: {prepared.encryptedAmount.securityZone}</p>
                <p>Payload bytes: {prepared.encryptedAmount.length}</p>
                <p>Permit key: {prepared.permitPublicKey ?? 'mock preview'}</p>
              </div>
              <div>
                <h3>Calldata</h3>
                <code>{prepared.calldata}</code>
              </div>
            </div>
          ) : (
            <p className="muted">
              Prepare any flow to generate encrypted payloads, calldata, and the permit public key used for
              sealed reserve queries.
            </p>
          )}
        </section>

        <section className="card wide">
          <div className="section-head">
            <h2>Contract model</h2>
            <span className="pill">FHE AMM</span>
          </div>
          <ul className="feature-list">
            <li>Encrypted reserve slots use FHE arithmetic for adds, subs, muls, divs, and comparisons.</li>
            <li>Swap amounts stay encrypted, and only the user receives sealed reserve bands through permits.</li>
            <li>LP balances are stored as encrypted positions so observers cannot infer concentration changes.</li>
            <li>Public slippage bounds remain available to protect traders without leaking exact order size.</li>
          </ul>
        </section>
      </main>
    </div>
  );
}

export default App;
