import type { TokenOption } from './types';

export const CONTRACT_ADDRESS =
  '0x000000000000000000000000000000000000dEaD';

export const TOKENS: TokenOption[] = [
  {
    symbol: 'sUSD',
    address: '0x0000000000000000000000000000000000001001',
    decimals: 18,
  },
  {
    symbol: 'sETH',
    address: '0x0000000000000000000000000000000000001002',
    decimals: 18,
  },
];

export const DEFAULT_SLIPPAGE_BPS = 100;
export const SECURITY_ZONE = 0;

export const DEX_ABI = [
  'function addLiquidity(bytes encryptedAmount0, bytes encryptedAmount1, bytes32 permitPublicKey, uint256 minLpOut)',
  'function removeLiquidity(bytes encryptedLpAmount, bytes32 permitPublicKey, uint256 minAmount0, uint256 minAmount1)',
  'function swap(bytes encryptedAmountIn, address tokenIn, uint256 minAmountOut, bytes32 permitPublicKey)',
  'function reserveBand(bytes32 publicKey) view returns (string memory)',
] as const;
