// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {FHE} from "./FHE.sol";

contract EncryptedERC20 {
    string public name;
    string public symbol;
    uint8 public decimals = 18;

    mapping(address => FHE.euint32) private _encryptedBalances;
    mapping(address => mapping(address => FHE.euint32)) private _encryptedAllowances;
    uint256 public totalSupply;

    event Transfer(address indexed from, address indexed to, uint256 ciphertext);
    event Approval(address indexed owner, address indexed spender, uint256 ciphertext);

    constructor(string memory _name, string memory _symbol) {
        name = _name;
        symbol = _symbol;
    }

    function encryptedBalanceOf(address account) public view returns (FHE.euint32 memory) {
        return _encryptedBalances[account];
    }

    function encryptedAllowance(address owner, address spender) public view returns (FHE.euint32 memory) {
        return _encryptedAllowances[owner][spender];
    }

    function mintEncrypted(address to, uint256 ciphertext) external {
        FHE.euint32 memory amount = FHE.asEuint32(ciphertext);
        _encryptedBalances[to] = FHE.add(_encryptedBalances[to], amount);
        totalSupply += ciphertext;
        emit Transfer(address(0), to, ciphertext);
    }

    function transferEncrypted(address to, uint256 ciphertext) external returns (bool) {
        FHE.euint32 memory amount = FHE.asEuint32(ciphertext);
        _encryptedBalances[msg.sender] = FHE.sub(_encryptedBalances[msg.sender], amount);
        _encryptedBalances[to] = FHE.add(_encryptedBalances[to], amount);
        emit Transfer(msg.sender, to, ciphertext);
        return true;
    }

    function approveEncrypted(address spender, uint256 ciphertext) external returns (bool) {
        _encryptedAllowances[msg.sender][spender] = FHE.asEuint32(ciphertext);
        emit Approval(msg.sender, spender, ciphertext);
        return true;
    }

    function transferFromEncrypted(address from, address to, uint256 ciphertext) external returns (bool) {
        FHE.euint32 memory amount = FHE.asEuint32(ciphertext);
        _encryptedAllowances[from][msg.sender] = FHE.sub(_encryptedAllowances[from][msg.sender], amount);
        _encryptedBalances[from] = FHE.sub(_encryptedBalances[from], amount);
        _encryptedBalances[to] = FHE.add(_encryptedBalances[to], amount);
        emit Transfer(from, to, ciphertext);
        return true;
    }
}
