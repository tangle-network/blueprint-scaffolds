// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {FHE, euint16, inEuint16} from "fhenix-contracts/FHE.sol";
import {Permissioned, Permission} from "fhenix-contracts/access/Permissioned.sol";
import {PhantomPool} from "./PhantomPool.sol";

contract PhantomPoolFactory {
    mapping(bytes32 => address) public getPool;
    address[] public allPools;

    event PoolCreated(
        address indexed tokenA,
        address indexed tokenB,
        address pool,
        uint256 index
    );

    function createPool(
        address tokenA,
        address tokenB
    ) external returns (address) {
        require(tokenA != tokenB, "IDENTICAL_ADDRESSES");
        (address token0, address token1) = tokenA < tokenB
            ? (tokenA, tokenB)
            : (tokenB, tokenA);

        bytes32 salt = keccak256(abi.encodePacked(token0, token1));
        require(getPool[salt] == address(0), "POOL_EXISTS");

        PhantomPool pool = new PhantomPool(token0, token1);
        getPool[salt] = address(pool);
        allPools.push(address(pool));

        emit PoolCreated(token0, token1, address(pool), allPools.length - 1);
        return address(pool);
    }

    function allPoolsLength() external view returns (uint256) {
        return allPools.length;
    }

    function getPoolAddress(
        address tokenA,
        address tokenB
    ) external view returns (address) {
        (address token0, address token1) = tokenA < tokenB
            ? (tokenA, tokenB)
            : (tokenB, tokenA);
        bytes32 salt = keccak256(abi.encodePacked(token0, token1));
        return getPool[salt];
    }
}
