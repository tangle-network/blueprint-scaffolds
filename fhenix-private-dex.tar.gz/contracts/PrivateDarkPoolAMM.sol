// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {FHE, ebool, euint64, inEuint64} from "@fhenixprotocol/contracts/FHE.sol";
import {Permission, Permissioned} from "@fhenixprotocol/contracts/access/Permissioned.sol";

/// @title PrivateDarkPoolAMM
/// @notice Demonstration AMM that stores reserves and LP balances as encrypted values.
/// @dev This contract is intended as a reference implementation for Fhenix-enabled frontends.
contract PrivateDarkPoolAMM is Permissioned {
    struct PoolState {
        euint64 reserve0;
        euint64 reserve1;
        euint64 kLast;
        euint64 totalLpSupply;
    }

    PoolState private pool;
    mapping(address => euint64) private lpBalances;

    event LiquidityAdded(address indexed provider, uint256 minLpOut);
    event LiquidityRemoved(address indexed provider, uint256 minAmount0, uint256 minAmount1);
    event SwapExecuted(address indexed trader, address indexed tokenIn, uint256 minAmountOut);

    constructor() {
        pool.reserve0 = FHE.asEuint64(5_000);
        pool.reserve1 = FHE.asEuint64(3_500);
        pool.totalLpSupply = FHE.asEuint64(4_000);
        pool.kLast = FHE.mul(pool.reserve0, pool.reserve1);
    }

    function addLiquidity(
        inEuint64 calldata encryptedAmount0,
        inEuint64 calldata encryptedAmount1,
        bytes32 permitPublicKey,
        uint256 minLpOut
    ) external {
        euint64 amount0 = FHE.asEuint64(encryptedAmount0.data, encryptedAmount0.securityZone);
        euint64 amount1 = FHE.asEuint64(encryptedAmount1.data, encryptedAmount1.securityZone);

        euint64 lpFrom0 = FHE.div(FHE.mul(amount0, pool.totalLpSupply), pool.reserve0);
        euint64 lpFrom1 = FHE.div(FHE.mul(amount1, pool.totalLpSupply), pool.reserve1);
        ebool take0 = FHE.lte(lpFrom0, lpFrom1);
        euint64 mintedLp = FHE.select(take0, lpFrom0, lpFrom1);
        ebool respectsMinimum = FHE.gte(mintedLp, FHE.asEuint64(minLpOut));

        pool.reserve0 = FHE.add(pool.reserve0, amount0);
        pool.reserve1 = FHE.add(pool.reserve1, amount1);
        pool.totalLpSupply = FHE.add(pool.totalLpSupply, mintedLp);
        lpBalances[msg.sender] = FHE.add(lpBalances[msg.sender], mintedLp);
        pool.kLast = FHE.mul(pool.reserve0, pool.reserve1);

        FHE.allowThis(mintedLp);
        FHE.allow(msg.sender, mintedLp);
        FHE.allowThis(respectsMinimum);
        FHE.allow(msg.sender, respectsMinimum);
        FHE.allowThis(pool.reserve0);
        FHE.allow(msg.sender, pool.reserve0);

        permitPublicKey;
        emit LiquidityAdded(msg.sender, minLpOut);
    }

    function removeLiquidity(
        inEuint64 calldata encryptedLpAmount,
        bytes32 permitPublicKey,
        uint256 minAmount0,
        uint256 minAmount1
    ) external {
        euint64 lpAmount = FHE.asEuint64(encryptedLpAmount.data, encryptedLpAmount.securityZone);
        euint64 amount0 = FHE.div(FHE.mul(lpAmount, pool.reserve0), pool.totalLpSupply);
        euint64 amount1 = FHE.div(FHE.mul(lpAmount, pool.reserve1), pool.totalLpSupply);

        lpBalances[msg.sender] = FHE.sub(lpBalances[msg.sender], lpAmount);
        pool.totalLpSupply = FHE.sub(pool.totalLpSupply, lpAmount);
        pool.reserve0 = FHE.sub(pool.reserve0, amount0);
        pool.reserve1 = FHE.sub(pool.reserve1, amount1);
        pool.kLast = FHE.mul(pool.reserve0, pool.reserve1);

        FHE.allowThis(amount0);
        FHE.allow(msg.sender, amount0);
        FHE.allowThis(amount1);
        FHE.allow(msg.sender, amount1);

        permitPublicKey;
        minAmount0;
        minAmount1;
        emit LiquidityRemoved(msg.sender, minAmount0, minAmount1);
    }

    function swap(
        inEuint64 calldata encryptedAmountIn,
        address tokenIn,
        uint256 minAmountOut,
        bytes32 permitPublicKey
    ) external {
        euint64 amountIn = FHE.asEuint64(encryptedAmountIn.data, encryptedAmountIn.securityZone);
        euint64 feeNumerator = FHE.asEuint64(997);
        euint64 feeDenominator = FHE.asEuint64(1000);
        euint64 amountInWithFee = FHE.div(FHE.mul(amountIn, feeNumerator), feeDenominator);
        ebool zeroForOne = FHE.eq(FHE.asEaddress(tokenIn), FHE.asEaddress(address(0x0000000000000000000000000000000000001001)));

        euint64 reserveIn = FHE.select(zeroForOne, pool.reserve0, pool.reserve1);
        euint64 reserveOut = FHE.select(zeroForOne, pool.reserve1, pool.reserve0);
        euint64 numerator = FHE.mul(amountInWithFee, reserveOut);
        euint64 denominator = FHE.add(reserveIn, amountInWithFee);
        euint64 amountOut = FHE.div(numerator, denominator);

        euint64 nextReserve0 = FHE.select(
            zeroForOne,
            FHE.add(pool.reserve0, amountIn),
            FHE.sub(pool.reserve0, amountOut)
        );
        euint64 nextReserve1 = FHE.select(
            zeroForOne,
            FHE.sub(pool.reserve1, amountOut),
            FHE.add(pool.reserve1, amountIn)
        );

        pool.reserve0 = nextReserve0;
        pool.reserve1 = nextReserve1;
        pool.kLast = FHE.mul(pool.reserve0, pool.reserve1);

        FHE.allowThis(amountOut);
        FHE.allow(msg.sender, amountOut);

        permitPublicKey;
        emit SwapExecuted(msg.sender, tokenIn, minAmountOut);
    }

    function balanceOfEncrypted(address owner, Permission calldata permission)
        external
        view
        onlyPermitted(permission, owner)
        returns (string memory)
    {
        return FHE.sealoutput(lpBalances[owner], permission.publicKey);
    }

    function reserveBand(bytes32 publicKey) external view returns (string memory) {
        ebool deep = FHE.gte(pool.kLast, FHE.asEuint64(12_000_000));
        euint64 band = FHE.select(deep, FHE.asEuint64(3), FHE.asEuint64(2));
        return FHE.sealoutput(band, publicKey);
    }

    function reserve0Sealed(Permission calldata permission) external view onlySender(permission) returns (string memory) {
        return FHE.sealoutput(pool.reserve0, permission.publicKey);
    }

    function reserve1Sealed(Permission calldata permission) external view onlySender(permission) returns (string memory) {
        return FHE.sealoutput(pool.reserve1, permission.publicKey);
    }
}
