// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {FHE, euint16, inEuint16} from "fhenix-contracts/FHE.sol";
import {PhantomPool} from "./PhantomPool.sol";

contract PhantomPriceOracle {
    struct PriceSnapshot {
        euint16 price;
        uint256 timestamp;
    }

    mapping(address => PriceSnapshot[]) private _priceHistory;
    uint256 public constant MAX_HISTORY = 100;

    event PriceRecorded(address indexed pool, uint256 timestamp);

    function recordPrice(
        address pool,
        Permission calldata perm
    ) external {
        PhantomPool p = PhantomPool(pool);
        (euint16 reserveA, euint16 reserveB) = p.getEncryptedReserves(perm);

        euint16 price = FHE.div(reserveB, reserveA);

        PriceSnapshot[] storage history = _priceHistory[pool];
        if (history.length >= MAX_HISTORY) {
            for (uint256 i = 1; i < history.length; i++) {
                history[i - 1] = history[i];
            }
            history.pop();
        }

        history.push(PriceSnapshot({price: price, timestamp: block.timestamp}));
        emit PriceRecorded(pool, block.timestamp);
    }

    function getLatestPrice(
        address pool
    ) external view returns (PriceSnapshot memory) {
        PriceSnapshot[] storage history = _priceHistory[pool];
        require(history.length > 0, "NO_PRICE_DATA");
        return history[history.length - 1];
    }

    function getPriceHistoryLength(
        address pool
    ) external view returns (uint256) {
        return _priceHistory[pool].length;
    }
}

// Stub for Permission since it's referenced by PhantomPool
library Types {
    struct Permission {
        address owner;
        bytes32[] allowedContracts;
    }
}
