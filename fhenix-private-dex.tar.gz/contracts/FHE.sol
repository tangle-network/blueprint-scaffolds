// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

library FHE {
    struct euint32 {
        uint256 ciphertext;
        address owner;
    }

    function asEuint32(uint256 ciphertext) internal pure returns (euint32 memory) {
        return euint32(ciphertext, address(0));
    }

    function add(euint32 memory a, euint32 memory b) internal pure returns (euint32 memory) {
        return euint32(a.ciphertext + b.ciphertext, a.owner);
    }

    function sub(euint32 memory a, euint32 memory b) internal pure returns (euint32 memory) {
        return euint32(a.ciphertext - b.ciphertext, a.owner);
    }

    function mul(euint32 memory a, euint32 memory b) internal pure returns (euint32 memory) {
        return euint32(a.ciphertext * b.ciphertext, a.owner);
    }

    function div(euint32 memory a, euint32 memory b) internal pure returns (euint32 memory) {
        require(b.ciphertext > 0, "Division by zero");
        return euint32(a.ciphertext / b.ciphertext, a.owner);
    }

    function eq(euint32 memory a, euint32 memory b) internal pure returns (euint32 memory) {
        return euint32(a.ciphertext == b.ciphertext ? 1 : 0, a.owner);
    }

    function gt(euint32 memory a, euint32 memory b) internal pure returns (euint32 memory) {
        return euint32(a.ciphertext > b.ciphertext ? 1 : 0, a.owner);
    }

    function gte(euint32 memory a, euint32 memory b) internal pure returns (euint32 memory) {
        return euint32(a.ciphertext >= b.ciphertext ? 1 : 0, a.owner);
    }

    function lt(euint32 memory a, euint32 memory b) internal pure returns (euint32 memory) {
        return euint32(a.ciphertext < b.ciphertext ? 1 : 0, a.owner);
    }

    function lte(euint32 memory a, euint32 memory b) internal pure returns (euint32 memory) {
        return euint32(a.ciphertext <= b.ciphertext ? 1 : 0, a.owner);
    }

    function select(euint32 memory cond, euint32 memory a, euint32 memory b) internal pure returns (euint32 memory) {
        return euint32(cond.ciphertext == 1 ? a.ciphertext : b.ciphertext, a.owner);
    }

    function decrypt(euint32 memory a) internal pure returns (uint32) {
        return uint32(a.ciphertext);
    }
}
