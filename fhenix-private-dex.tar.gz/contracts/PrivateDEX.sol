// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {FHE} from "./FHE.sol";
import {EncryptedERC20} from "./EncryptedERC20.sol";

contract PrivateDEX {
    struct Pool {
        address tokenA;
        address tokenB;
        FHE.euint32 reserveA;
        FHE.euint32 reserveB;
        uint256 totalLPSupply;
        mapping(address => FHE.euint32) lpBalance;
        mapping(address => FHE.euint32) lpContributionA;
        mapping(address => FHE.euint32) lpContributionB;
    }

    mapping(bytes32 => Pool) public pools;
    bytes32[] public poolIds;

    uint256 public constant FEE_RATE = 30;
    uint256 public constant FEE_DENOMINATOR = 10000;
    uint256 public constant MINIMUM_LIQUIDITY = 1000;

    event PoolCreated(bytes32 indexed poolId, address tokenA, address tokenB);
    event LiquidityAdded(bytes32 indexed poolId, address provider, uint256 amountA, uint256 amountB, uint256 lpTokens);
    event LiquidityRemoved(bytes32 indexed poolId, address provider, uint256 lpTokens);
    event SwapExecuted(bytes32 indexed poolId, address swapper, uint256 amountIn, uint256 amountOut, bool isAToB);

    function createPool(address tokenA, address tokenB) external returns (bytes32) {
        require(tokenA != tokenB, "Identical addresses");
        bytes32 poolId = keccak256(abi.encodePacked(tokenA, tokenB));
        require(pools[poolId].tokenA == address(0), "Pool exists");

        Pool storage pool = pools[poolId];
        pool.tokenA = tokenA;
        pool.tokenB = tokenB;

        poolIds.push(poolId);
        emit PoolCreated(poolId, tokenA, tokenB);
        return poolId;
    }

    function addLiquidity(
        bytes32 poolId,
        uint256 ciphertextAmountA,
        uint256 ciphertextAmountB,
        uint256 minLPTokens
    ) external returns (uint256 lpMinted) {
        Pool storage pool = pools[poolId];
        require(pool.tokenA != address(0), "Pool not found");

        FHE.euint32 memory amountA = FHE.asEuint32(ciphertextAmountA);
        FHE.euint32 memory amountB = FHE.asEuint32(ciphertextAmountB);

        if (pool.totalLPSupply == 0) {
            FHE.euint32 memory product = FHE.mul(amountA, amountB);
            lpMinted = product.ciphertext - MINIMUM_LIQUIDITY;
            pool.totalLPSupply = MINIMUM_LIQUIDITY;
        } else {
            FHE.euint32 memory ratioA = FHE.div(
                FHE.mul(amountA, FHE.asEuint32(pool.totalLPSupply)),
                pool.reserveA
            );
            FHE.euint32 memory ratioB = FHE.div(
                FHE.mul(amountB, FHE.asEuint32(pool.totalLPSupply)),
                pool.reserveB
            );
            lpMinted = ratioA.ciphertext < ratioB.ciphertext ? ratioA.ciphertext : ratioB.ciphertext;
        }

        require(lpMinted >= minLPTokens, "Slippage: insufficient LP tokens");

        EncryptedERC20(pool.tokenA).transferFromEncrypted(msg.sender, address(this), ciphertextAmountA);
        EncryptedERC20(pool.tokenB).transferFromEncrypted(msg.sender, address(this), ciphertextAmountB);

        pool.reserveA = FHE.add(pool.reserveA, amountA);
        pool.reserveB = FHE.add(pool.reserveB, amountB);
        pool.lpBalance[msg.sender] = FHE.add(pool.lpBalance[msg.sender], FHE.asEuint32(lpMinted));
        pool.lpContributionA[msg.sender] = FHE.add(pool.lpContributionA[msg.sender], amountA);
        pool.lpContributionB[msg.sender] = FHE.add(pool.lpContributionB[msg.sender], amountB);
        pool.totalLPSupply += lpMinted;

        emit LiquidityAdded(poolId, msg.sender, ciphertextAmountA, ciphertextAmountB, lpMinted);
    }

    function removeLiquidity(
        bytes32 poolId,
        uint256 ciphertextLPTokens,
        uint256 minAmountA,
        uint256 minAmountB
    ) external returns (uint256 amountA, uint256 amountB) {
        Pool storage pool = pools[poolId];
        require(pool.tokenA != address(0), "Pool not found");

        FHE.euint32 memory lpTokens = FHE.asEuint32(ciphertextLPTokens);
        FHE.euint32 memory totalSupply = FHE.asEuint32(pool.totalLPSupply);

        amountA = FHE.mul(lpTokens, pool.reserveA).ciphertext / totalSupply.ciphertext;
        amountB = FHE.mul(lpTokens, pool.reserveB).ciphertext / totalSupply.ciphertext;

        require(amountA >= minAmountA, "Slippage: insufficient amountA");
        require(amountB >= minAmountB, "Slippage: insufficient amountB");

        pool.reserveA = FHE.sub(pool.reserveA, FHE.asEuint32(amountA));
        pool.reserveB = FHE.sub(pool.reserveB, FHE.asEuint32(amountB));
        pool.lpBalance[msg.sender] = FHE.sub(pool.lpBalance[msg.sender], lpTokens);
        pool.totalLPSupply -= ciphertextLPTokens;

        EncryptedERC20(pool.tokenA).transferEncrypted(msg.sender, amountA);
        EncryptedERC20(pool.tokenB).transferEncrypted(msg.sender, amountB);

        emit LiquidityRemoved(poolId, msg.sender, ciphertextLPTokens);
    }

    function swap(
        bytes32 poolId,
        uint256 ciphertextAmountIn,
        bool isAToB,
        uint256 minAmountOut
    ) external returns (uint256 amountOut) {
        Pool storage pool = pools[poolId];
        require(pool.tokenA != address(0), "Pool not found");

        FHE.euint32 memory amountIn = FHE.asEuint32(ciphertextAmountIn);

        FHE.euint32 memory reserveIn = isAToB ? pool.reserveA : pool.reserveB;
        FHE.euint32 memory reserveOut = isAToB ? pool.reserveB : pool.reserveA;

        FHE.euint32 memory amountInWithFee = FHE.mul(amountIn, FHE.asEuint32(FEE_DENOMINATOR - FEE_RATE));
        FHE.euint32 memory numerator = FHE.mul(amountInWithFee, reserveOut);
        FHE.euint32 memory denominator = FHE.add(FHE.mul(reserveIn, FHE.asEuint32(FEE_DENOMINATOR)), amountInWithFee);
        amountOut = FHE.div(numerator, denominator).ciphertext;

        require(amountOut >= minAmountOut, "Slippage: insufficient output");

        if (isAToB) {
            EncryptedERC20(pool.tokenA).transferFromEncrypted(msg.sender, address(this), ciphertextAmountIn);
            pool.reserveA = FHE.add(pool.reserveA, amountIn);
            pool.reserveB = FHE.sub(pool.reserveB, FHE.asEuint32(amountOut));
            EncryptedERC20(pool.tokenB).transferEncrypted(msg.sender, amountOut);
        } else {
            EncryptedERC20(pool.tokenB).transferFromEncrypted(msg.sender, address(this), ciphertextAmountIn);
            pool.reserveB = FHE.add(pool.reserveB, amountIn);
            pool.reserveA = FHE.sub(pool.reserveA, FHE.asEuint32(amountOut));
            EncryptedERC20(pool.tokenA).transferEncrypted(msg.sender, amountOut);
        }

        emit SwapExecuted(poolId, msg.sender, ciphertextAmountIn, amountOut, isAToB);
    }

    function getEncryptedReserves(bytes32 poolId) external view returns (FHE.euint32 memory, FHE.euint32 memory) {
        Pool storage pool = pools[poolId];
        return (pool.reserveA, pool.reserveB);
    }

    function getLPPosition(bytes32 poolId, address provider) external view returns (FHE.euint32 memory) {
        return pools[poolId].lpBalance[provider];
    }

    function getPoolCount() external view returns (uint256) {
        return poolIds.length;
    }
}
