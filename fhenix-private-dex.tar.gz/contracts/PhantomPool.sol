// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {FHE, euint16, inEuint16} from "fhenix-contracts/FHE.sol";
import {Permissioned, Permission} from "fhenix-contracts/access/Permissioned.sol";

contract PhantomPool is Permissioned {
    string public name;
    string public symbol;

    euint16 private _reserveA;
    euint16 private _reserveB;
    euint16 private _totalSupply;

    mapping(address => euint16) private _balances;
    mapping(address => uint256) private _nonce;

    uint256 public constant FEE_NUMERATOR = 997;
    uint256 public constant FEE_DENOMINATOR = 1000;
    uint16 public constant MINIMUM_LIQUIDITY = 1000;

    address public tokenA;
    address public tokenB;
    bool public initialized;

    event LiquidityAdded(address indexed provider, uint256 timestamp);
    event LiquidityRemoved(address indexed provider, uint256 timestamp);
    event SwapExecuted(address indexed trader, bool directionAtoB, uint256 timestamp);

    constructor(address _tokenA, address _tokenB) {
        tokenA = _tokenA;
        tokenB = _tokenB;
        name = "Phantom LP Token";
        symbol = "pLP";
    }

    function addLiquidity(
        inEuint16 calldata amountA,
        inEuint16 calldata amountB
    ) external returns (euint16) {
        euint16 a = FHE.asEuint16(amountA);
        euint16 b = FHE.asEuint16(amountB);

        euint16 liquidity;

        if (!initialized) {
            FHE.req(FHE.gt(a, FHE.asEuint16(MINIMUM_LIQUIDITY)));
            FHE.req(FHE.gt(b, FHE.asEuint16(MINIMUM_LIQUIDITY)));
            liquidity = FHE.sub(FHE.sqrt(FHE.mul(a, b)), FHE.asEuint16(MINIMUM_LIQUIDITY));
            _totalSupply = FHE.asEuint16(MINIMUM_LIQUIDITY);
            initialized = true;
        } else {
            euint16 totalSupplySnap = _totalSupply;
            euint16 reserveASnap = _reserveA;
            euint16 reserveBSnap = _reserveB;

            euint16 liquidityA = FHE.div(FHE.mul(totalSupplySnap, a), reserveASnap);
            euint16 liquidityB = FHE.div(FHE.mul(totalSupplySnap, b), reserveBSnap);

            liquidity = FHE.min(liquidityA, liquidityB);
        }

        _balances[msg.sender] = FHE.add(_balances[msg.sender], liquidity);
        _totalSupply = FHE.add(_totalSupply, liquidity);
        _reserveA = FHE.add(_reserveA, a);
        _reserveB = FHE.add(_reserveB, b);

        emit LiquidityAdded(msg.sender, block.timestamp);
        return liquidity;
    }

    function removeLiquidity(
        inEuint16 calldata lpAmount
    ) external returns (euint16, euint16) {
        euint16 lp = FHE.asEuint16(lpAmount);
        euint16 totalSupplySnap = _totalSupply;

        FHE.req(FHE.le(lp, _balances[msg.sender]));
        FHE.req(FHE.gt(lp, FHE.asEuint16(0)));

        euint16 reserveASnap = _reserveA;
        euint16 reserveBSnap = _reserveB;

        euint16 amountA = FHE.div(FHE.mul(reserveASnap, lp), totalSupplySnap);
        euint16 amountB = FHE.div(FHE.mul(reserveBSnap, lp), totalSupplySnap);

        _balances[msg.sender] = FHE.sub(_balances[msg.sender], lp);
        _totalSupply = FHE.sub(_totalSupply, lp);
        _reserveA = FHE.sub(_reserveA, amountA);
        _reserveB = FHE.sub(_reserveB, amountB);

        emit LiquidityRemoved(msg.sender, block.timestamp);
        return (amountA, amountB);
    }

    function swapAtoB(inEuint16 calldata amountIn) external returns (euint16) {
        euint16 inAmount = FHE.asEuint16(amountIn);

        euint16 reserveA = _reserveA;
        euint16 reserveB = _reserveB;

        euint16 inAmountWithFee = FHE.mul(inAmount, FHE.asEuint16(uint16(FEE_NUMERATOR)));
        euint16 numerator = FHE.mul(inAmountWithFee, reserveB);
        euint16 denominator = FHE.add(FHE.mul(reserveA, FHE.asEuint16(uint16(FEE_DENOMINATOR))), inAmountWithFee);
        euint16 outAmount = FHE.div(numerator, denominator);

        FHE.req(FHE.gt(outAmount, FHE.asEuint16(0)));
        FHE.req(FHE.lt(outAmount, reserveB));

        _reserveA = FHE.add(reserveA, inAmount);
        _reserveB = FHE.sub(reserveB, outAmount);

        emit SwapExecuted(msg.sender, true, block.timestamp);
        return outAmount;
    }

    function swapBtoA(inEuint16 calldata amountIn) external returns (euint16) {
        euint16 inAmount = FHE.asEuint16(amountIn);

        euint16 reserveA = _reserveA;
        euint16 reserveB = _reserveB;

        euint16 inAmountWithFee = FHE.mul(inAmount, FHE.asEuint16(uint16(FEE_NUMERATOR)));
        euint16 numerator = FHE.mul(inAmountWithFee, reserveA);
        euint16 denominator = FHE.add(FHE.mul(reserveB, FHE.asEuint16(uint16(FEE_DENOMINATOR))), inAmountWithFee);
        euint16 outAmount = FHE.div(numerator, denominator);

        FHE.req(FHE.gt(outAmount, FHE.asEuint16(0)));
        FHE.req(FHE.lt(outAmount, reserveA));

        _reserveB = FHE.add(reserveB, inAmount);
        _reserveA = FHE.sub(reserveA, outAmount);

        emit SwapExecuted(msg.sender, false, block.timestamp);
        return outAmount;
    }

    function getEncryptedBalance(
        address owner,
        Permission calldata perm
    ) external view onlyPermitted(perm) returns (euint16) {
        return _balances[owner];
    }

    function getEncryptedSupply(
        Permission calldata perm
    ) external view onlyPermitted(perm) returns (euint16) {
        return _totalSupply;
    }

    function getEncryptedReserves(
        Permission calldata perm
    ) external view onlyPermitted(perm) returns (euint16, euint16) {
        return (_reserveA, _reserveB);
    }
}
