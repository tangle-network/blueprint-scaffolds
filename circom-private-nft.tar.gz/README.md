# Private NFT Ownership

A Vite + React demo with Circom circuit sources for private NFT ownership commitments, collection membership proofs, and trait claims without revealing the specific NFT.

## Scripts

- `pnpm dev`: run the frontend locally
- `pnpm build`: type-check and build the frontend
- `pnpm compile:circuits`: compile Circom circuits if `circom` is installed
- `pnpm prove:sample`: emit a small sample of public proof signals

## Circuits

- `circuits/ownership_commitment.circom`: private ownership commitment and nullifier hash
- `circuits/collection_membership.circom`: Merkle inclusion proof for committed collection membership
- `circuits/trait_membership.circom`: trait proof layered on collection membership
