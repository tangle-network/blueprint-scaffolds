pragma circom 2.1.6;

include "../node_modules/circomlib/circuits/poseidon.circom";

template MerklePath(depth) {
    signal input leaf;
    signal input pathElements[depth];
    signal input pathIndices[depth];
    signal output root;

    signal hashes[depth + 1];
    hashes[0] <== leaf;

    for (var i = 0; i < depth; i++) {
        component leftHasher = Poseidon(2);
        component rightHasher = Poseidon(2);

        leftHasher.inputs[0] <== hashes[i];
        leftHasher.inputs[1] <== pathElements[i];

        rightHasher.inputs[0] <== pathElements[i];
        rightHasher.inputs[1] <== hashes[i];

        hashes[i + 1] <== (1 - pathIndices[i]) * leftHasher.out + pathIndices[i] * rightHasher.out;
    }

    root <== hashes[depth];
}

template CollectionMembership(depth) {
    signal input secret;
    signal input nullifier;
    signal input tokenId;
    signal input collectionIdHash;
    signal input traitHash;
    signal input pathElements[depth];
    signal input pathIndices[depth];

    signal output merkleRoot;
    signal output ownershipCommitment;
    signal output nullifierHash;

    component commitment = Poseidon(4);
    commitment.inputs[0] <== secret;
    commitment.inputs[1] <== nullifier;
    commitment.inputs[2] <== tokenId;
    commitment.inputs[3] <== collectionIdHash;

    component nullifierCommit = Poseidon(2);
    nullifierCommit.inputs[0] <== nullifier;
    nullifierCommit.inputs[1] <== collectionIdHash;

    component leafCommit = Poseidon(4);
    leafCommit.inputs[0] <== collectionIdHash;
    leafCommit.inputs[1] <== tokenId;
    leafCommit.inputs[2] <== traitHash;
    leafCommit.inputs[3] <== commitment.out;

    component merkle = MerklePath(depth);
    merkle.leaf <== leafCommit.out;

    for (var i = 0; i < depth; i++) {
        merkle.pathElements[i] <== pathElements[i];
        merkle.pathIndices[i] <== pathIndices[i];
    }

    ownershipCommitment <== commitment.out;
    nullifierHash <== nullifierCommit.out;
    merkleRoot <== merkle.root;
}

component main = CollectionMembership(8);
