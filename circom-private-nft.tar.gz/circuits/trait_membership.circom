pragma circom 2.1.6;

include "./collection_membership.circom";
include "../node_modules/circomlib/circuits/poseidon.circom";

template TraitMembership(depth) {
    signal input secret;
    signal input nullifier;
    signal input tokenId;
    signal input collectionIdHash;
    signal input traitValue;
    signal input pathElements[depth];
    signal input pathIndices[depth];

    signal output merkleRoot;
    signal output ownershipCommitment;
    signal output nullifierHash;
    signal output traitHash;

    component traitHasher = Poseidon(1);
    traitHasher.inputs[0] <== traitValue;

    component membership = CollectionMembership(depth);
    membership.secret <== secret;
    membership.nullifier <== nullifier;
    membership.tokenId <== tokenId;
    membership.collectionIdHash <== collectionIdHash;
    membership.traitHash <== traitHasher.out;

    for (var i = 0; i < depth; i++) {
        membership.pathElements[i] <== pathElements[i];
        membership.pathIndices[i] <== pathIndices[i];
    }

    merkleRoot <== membership.merkleRoot;
    ownershipCommitment <== membership.ownershipCommitment;
    nullifierHash <== membership.nullifierHash;
    traitHash <== traitHasher.out;
}

component main = TraitMembership(8);
