pragma circom 2.1.6;

include "../node_modules/circomlib/circuits/poseidon.circom";

template OwnershipCommitment() {
    signal input secret;
    signal input nullifier;
    signal input tokenId;
    signal input collectionIdHash;

    signal output commitment;
    signal output nullifierHash;

    component commitHasher = Poseidon(4);
    commitHasher.inputs[0] <== secret;
    commitHasher.inputs[1] <== nullifier;
    commitHasher.inputs[2] <== tokenId;
    commitHasher.inputs[3] <== collectionIdHash;

    component nullifierHasher = Poseidon(2);
    nullifierHasher.inputs[0] <== nullifier;
    nullifierHasher.inputs[1] <== collectionIdHash;

    commitment <== commitHasher.out;
    nullifierHash <== nullifierHasher.out;
}

component main = OwnershipCommitment();
