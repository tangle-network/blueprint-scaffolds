# Private NFT Ownership System - Build Plan

## Stack
- Vite + React + TypeScript
- Tailwind CSS + shadcn/ui
- Circom circuits (simulated in frontend)
- React Router for navigation

## Pages
1. `/` - Dashboard - Overview of private NFT portfolio
2. `/generate` - Generate Proof - Create zero-knowledge proofs
3. `/verify` - Verify Proof - Verify submitted proofs

## Components
- `src/components/ui/` - shadcn/ui base components (Button, Card, Input, Label, Progress, Select, Tabs, Dialog)
- `src/components/Layout.tsx` - App shell with nav
- `src/components/WalletView.tsx` - Private wallet display
- `src/components/ProofGenerator.tsx` - Proof generation interface
- `src/components/ProofVerifier.tsx` - Proof verification interface
- `src/components/NFTCard.tsx` - Private NFT card display
- `src/components/CircuitSelector.tsx` - Circuit type selector
- `src/components/TraitReveal.tsx` - Trait reveal component

## Lib
- `src/lib/utils.ts` - Utility functions (cn helper)
- `src/lib/types.ts` - TypeScript types
- `src/lib/circuits.ts` - Circuit simulation logic
- `src/lib/poseidon.ts` - Poseidon hash simulation
- `src/lib/noir.ts` - Noir-style proof helpers

## Circuits (conceptual Circom)
- `src/circuits/ownership.circom` - Private ownership proof
- `src/circuits/membership.circom` - Collection membership
- `src/circuits/trait.circom` - Trait verification
