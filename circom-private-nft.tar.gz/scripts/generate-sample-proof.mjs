import { buildPoseidon } from "circomlibjs";

const poseidon = await buildPoseidon();
const F = poseidon.F;
const hash = (...values) => `0x${BigInt(F.toString(poseidon(values))).toString(16)}`;

const collectionIdHash = 0x1234n;
const traitHash = hash(0x5555n);
const ownershipCommitment = hash(987654321n, 123456789n, 18n, collectionIdHash);
const nullifierHash = hash(123456789n, collectionIdHash);
const merkleRoot = hash(collectionIdHash, 18n, BigInt(traitHash), BigInt(ownershipCommitment));

console.log(
  JSON.stringify(
    {
      ownershipCommitment,
      nullifierHash,
      traitHash,
      merkleRoot,
    },
    null,
    2,
  ),
);
