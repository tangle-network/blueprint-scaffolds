import { mkdir } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import path from "node:path";

const circuits = [
  "ownership_commitment.circom",
  "collection_membership.circom",
  "trait_membership.circom",
];

const projectRoot = new URL("..", import.meta.url);
const circuitsDir = path.join(projectRoot.pathname, "circuits");
const outputDir = path.join(projectRoot.pathname, "artifacts");

const circomCheck = spawnSync("circom", ["--version"], { stdio: "ignore" });
if (circomCheck.status !== 0) {
  console.log("circom is not installed. Install it locally to compile the circuits.");
  process.exit(0);
}

await mkdir(outputDir, { recursive: true });

for (const circuit of circuits) {
  const input = path.join(circuitsDir, circuit);
  const result = spawnSync(
    "circom",
    [input, "--r1cs", "--wasm", "--sym", "-o", outputDir],
    { stdio: "inherit" },
  );

  if (result.status !== 0) {
    process.exit(result.status ?? 1);
  }
}
