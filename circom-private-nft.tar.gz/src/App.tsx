import { AppProvider, useApp } from './context/AppContext';
import { WalletView } from './components/WalletView';
import { CommitView } from './components/CommitView';
import { ProveView } from './components/ProveView';
import { VerifyView } from './components/VerifyView';
import './styles/global.css';

function AppContent() {
  const { state, dispatch } = useApp();

  return (
    <div>
      <div className="header">
        <span className="header-icon">🔐</span>
        <div>
          <h1>Private NFT Ownership</h1>
          <p className="subtitle">Zero-knowledge proofs for hidden NFT ownership with Circom</p>
        </div>
      </div>

      <div className="stats-bar">
        <div className="stat">
          <div className="number">{state.wallet.length}</div>
          <div className="label">NFTs</div>
        </div>
        <div className="stat">
          <div className="number">{state.commitments.length}</div>
          <div className="label">Commitments</div>
        </div>
        <div className="stat">
          <div className="number">{state.proofs.length}</div>
          <div className="label">Proofs</div>
        </div>
      </div>

      <div className="tab-bar">
        {(['wallet', 'commit', 'prove', 'verify'] as const).map(tab => (
          <button
            key={tab}
            className={`tab ${state.activeTab === tab ? 'active' : ''}`}
            onClick={() => dispatch({ type: 'SET_TAB', payload: tab })}
          >
            {tab === 'wallet' && 'Wallet'}
            {tab === 'commit' && 'Commit'}
            {tab === 'prove' && 'Prove'}
            {tab === 'verify' && 'Verify'}
          </button>
        ))}
      </div>

      {state.activeTab === 'wallet' && <WalletView />}
      {state.activeTab === 'commit' && <CommitView />}
      {state.activeTab === 'prove' && <ProveView />}
      {state.activeTab === 'verify' && <VerifyView />}
    </div>
  );
}

function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

export default App;
