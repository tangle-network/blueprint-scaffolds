import { useEffect, useMemo, useState } from "react";
import { demoWallet } from "./data";
import { createOwnershipRecord, generateProofPayload, verifyGeneratedProof } from "./lib/zk";
import type { GeneratedProof, OwnershipRecord, ProofMode } from "./types";

const proofLabels: Record<ProofMode, string> = {
  ownership: "Private ownership",
  collection: "Collection membership",
  trait: "Trait claim",
};

function App() {
  const [records, setRecords] = useState<OwnershipRecord[]>([]);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [proofMode, setProofMode] = useState<ProofMode>("ownership");
  const [proof, setProof] = useState<GeneratedProof | null>(null);
  const [verificationState, setVerificationState] = useState<string>("No proof checked yet.");

  useEffect(() => {
    Promise.all(demoWallet.map((nft) => createOwnershipRecord(nft))).then(setRecords);
  }, []);

  const selectedNft = demoWallet[selectedIndex];

  const proofDescription = useMemo(() => {
    if (proofMode === "ownership") {
      return "Reveal a valid ownership commitment and one-time nullifier without disclosing the wallet identity.";
    }
    if (proofMode === "collection") {
      return "Prove the NFT belongs to a committed collection root without exposing the token id.";
    }
    return "Prove a trait hash belongs to one NFT inside the collection root without revealing which token carries it.";
  }, [proofMode]);

  async function handleGenerateProof() {
    const nextProof = await generateProofPayload(demoWallet, selectedIndex, proofMode);
    setProof(nextProof);
    setVerificationState("Proof generated locally. Run verification to validate the statement.");
  }

  async function handleVerifyProof() {
    if (!proof) {
      setVerificationState("Generate a proof payload before verifying.");
      return;
    }

    const result = await verifyGeneratedProof(proof, demoWallet);
    setVerificationState(result.ok ? `Verified: ${result.reason}` : `Rejected: ${result.reason}`);
  }

  return (
    <main className="shell">
      <section className="hero">
        <div>
          <p className="eyebrow">Private NFT Ownership System</p>
          <h1>Hidden ownership proofs with Circom circuits and a local verifier UI.</h1>
          <p className="lede">
            Commit to NFT ownership privately, prove collection membership anonymously, and
            assert traits without revealing which token you hold.
          </p>
        </div>
        <div className="hero-card">
          <span>Supported flows</span>
          <strong>Private membership verification</strong>
          <strong>Anonymous holder voting</strong>
          <strong>Hidden portfolio proofs</strong>
        </div>
      </section>

      <section className="grid">
        <article className="panel wallet-panel">
          <div className="panel-header">
            <div>
              <p className="eyebrow">Wallet View</p>
              <h2>Committed assets</h2>
            </div>
            <span className="badge">{records.length} NFTs</span>
          </div>
          <div className="wallet-list">
            {demoWallet.map((nft, index) => {
              const record = records[index];
              const active = selectedIndex === index;
              return (
                <button
                  className={`wallet-item ${active ? "active" : ""}`}
                  key={`${nft.collectionId}-${nft.tokenId}`}
                  onClick={() => setSelectedIndex(index)}
                  type="button"
                >
                  <img alt={nft.collectionName} src={nft.image} />
                  <div>
                    <strong>{nft.collectionName}</strong>
                    <span>Token #{nft.tokenId}</span>
                    <span>Trait: {nft.trait}</span>
                    <code>{record ? record.commitment.slice(0, 20) : "loading..."}...</code>
                  </div>
                </button>
              );
            })}
          </div>
        </article>

        <article className="panel generator-panel">
          <div className="panel-header">
            <div>
              <p className="eyebrow">Proof Generator</p>
              <h2>{proofLabels[proofMode]}</h2>
            </div>
            <span className="badge">Local witness</span>
          </div>
          <p className="muted">{proofDescription}</p>
          <div className="modes">
            {(Object.keys(proofLabels) as ProofMode[]).map((mode) => (
              <button
                className={`mode-pill ${proofMode === mode ? "active" : ""}`}
                key={mode}
                onClick={() => setProofMode(mode)}
                type="button"
              >
                {proofLabels[mode]}
              </button>
            ))}
          </div>
          <div className="statement">
            <span>Selected NFT</span>
            <strong>
              {selectedNft.collectionName} #{selectedNft.tokenId}
            </strong>
            <span>Trait: {selectedNft.trait}</span>
          </div>
          <button className="primary" onClick={() => void handleGenerateProof()} type="button">
            Generate proof payload
          </button>
          {proof ? (
            <div className="code-block">
              <h3>Public signals</h3>
              <pre>{JSON.stringify(proof.publicSignals, null, 2)}</pre>
              <h3>Merkle path</h3>
              <pre>{JSON.stringify({ pathElements: proof.pathElements, pathIndices: proof.pathIndices }, null, 2)}</pre>
            </div>
          ) : (
            <div className="empty-state">Generate a proof to inspect the public statement.</div>
          )}
        </article>

        <article className="panel verifier-panel">
          <div className="panel-header">
            <div>
              <p className="eyebrow">Verification Interface</p>
              <h2>Statement verifier</h2>
            </div>
            <span className="badge">App-side</span>
          </div>
          <p className="muted">
            The frontend validates the public statement against the same committed wallet state.
            The Circom circuits in <code>circuits/</code> are the source of truth for real zk proof
            compilation with <code>snarkjs</code>.
          </p>
          <button className="secondary" onClick={() => void handleVerifyProof()} type="button">
            Verify current proof
          </button>
          <div className="verification-result">{verificationState}</div>
          {proof ? (
            <div className="code-block compact">
              <h3>Proof digest</h3>
              <pre>{proof.verificationDigest}</pre>
              <h3>Hidden witness bundle</h3>
              <pre>{JSON.stringify(proof.proverBundle, null, 2)}</pre>
            </div>
          ) : null}
        </article>
      </section>
    </main>
  );
}

export default App;
