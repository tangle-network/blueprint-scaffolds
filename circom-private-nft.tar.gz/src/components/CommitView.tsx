import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { createCommitment, generateSecret } from '../lib/proofs';
import '../styles/components.css';

export function CommitView() {
  const { state, dispatch } = useApp();
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [ownerSecret, setOwnerSecret] = useState('');
  const [nullifier, setNullifier] = useState('');
  const [lastCommit, setLastCommit] = useState<string | null>(null);

  const nft = state.wallet.find(n => n.id === selectedId);

  const handleCommit = () => {
    if (!nft) return;
    const secret = ownerSecret || generateSecret();
    const nul = nullifier || generateSecret();
    const commitment = createCommitment(nft, secret, nul);
    dispatch({ type: 'ADD_COMMITMENT', payload: commitment });
    setLastCommit(commitment.commitment);
    setOwnerSecret('');
    setNullifier('');
    setSelectedId(null);
  };

  return (
    <div>
      <h2>Commit to Ownership</h2>
      <p style={{ color: '#888', fontSize: 14, marginBottom: 16 }}>
        Create a private commitment that binds you to an NFT without revealing your identity.
        The commitment is a hash of (NFT ID + owner secret + nullifier).
      </p>

      {state.wallet.length === 0 ? (
        <div className="empty-state">
          <h3>No NFTs in Wallet</h3>
          <p>Add NFTs from the Wallet tab first</p>
        </div>
      ) : (
        <>
          <label style={{ fontSize: 13, color: '#888', display: 'block', marginBottom: 6 }}>
            Select NFT
          </label>
          <select
            className="input"
            value={selectedId ?? ''}
            onChange={e => setSelectedId(Number(e.target.value) || null)}
          >
            <option value="">Choose an NFT...</option>
            {state.wallet.map(n => (
              <option key={n.id} value={n.id}>
                #{n.id} — {n.name} ({n.collection})
              </option>
            ))}
          </select>

          {nft && (
            <div className="card" style={{ marginTop: 16 }}>
              <strong>{nft.name}</strong>
              <span style={{ color: '#888', fontSize: 13, marginLeft: 8 }}>
                {nft.collection}
              </span>
              <div className="trait-grid" style={{ marginTop: 10 }}>
                {Object.entries(nft.traits).map(([k, v]) => (
                  <div key={k} className="trait-item">
                    <div className="label">{k}</div>
                    <div className="value">{v}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div style={{ marginTop: 16 }}>
            <label style={{ fontSize: 13, color: '#888', display: 'block', marginBottom: 6 }}>
              Owner Secret (leave blank to auto-generate)
            </label>
            <input
              className="input"
              type="text"
              placeholder="Auto-generated if empty"
              value={ownerSecret}
              onChange={e => setOwnerSecret(e.target.value)}
            />
          </div>

          <div style={{ marginTop: 12 }}>
            <label style={{ fontSize: 13, color: '#888', display: 'block', marginBottom: 6 }}>
              Nullifier (leave blank to auto-generate)
            </label>
            <input
              className="input"
              type="text"
              placeholder="Auto-generated if empty"
              value={nullifier}
              onChange={e => setNullifier(e.target.value)}
            />
          </div>

          <button
            className="btn btn-primary"
            style={{ marginTop: 16, width: '100%' }}
            disabled={!selectedId}
            onClick={handleCommit}
          >
            Generate Commitment
          </button>
        </>
      )}

      {lastCommit && (
        <div className="proof-box" style={{ marginTop: 16 }}>
          <p style={{ fontSize: 13, color: '#6c63ff', marginBottom: 6 }}>
            Commitment Created
          </p>
          <p className="mono">{lastCommit}</p>
          <p style={{ fontSize: 12, color: '#555', marginTop: 8 }}>
            This commitment is stored locally. Use it in the Prove tab to generate zero-knowledge proofs.
          </p>
        </div>
      )}

      {state.commitments.length > 0 && (
        <>
          <p className="section-title">Your Commitments ({state.commitments.length})</p>
          {state.commitments.map((c, i) => (
            <div key={i} className="proof-box">
              <div className="flex-row">
                <span className="badge badge-ownership">NFT #{c.nftId}</span>
                <span className="spacer" />
                <span style={{ fontSize: 12, color: '#555' }}>#{i + 1}</span>
              </div>
              <p className="mono" style={{ marginTop: 8 }}>{c.commitment}</p>
            </div>
          ))}
        </>
      )}
    </div>
  );
}
