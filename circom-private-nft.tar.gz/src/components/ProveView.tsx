import { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  generateOwnershipProof,
  generateCollectionProof,
  generateTraitProof,
  generateMerkleRoot,
} from '../lib/proofs';
import '../styles/components.css';

type ProofType = 'ownership' | 'collection_membership' | 'trait_verification';

export function ProveView() {
  const { state, dispatch } = useApp();
  const [commitIdx, setCommitIdx] = useState<number>(0);
  const [proofType, setProofType] = useState<ProofType>('ownership');
  const [traitKey, setTraitKey] = useState('');
  const [error, setError] = useState('');

  const commitment = state.commitments[commitIdx] ?? null;
  const nft = commitment ? state.wallet.find(n => n.id === commitment.nftId) : null;

  const handleProve = () => {
    setError('');
    if (!commitment || !nft) {
      setError('Select a valid commitment');
      return;
    }

    try {
      let proof;
      if (proofType === 'ownership') {
        proof = generateOwnershipProof(commitment, nft);
      } else if (proofType === 'collection_membership') {
        const merkleRoot = generateMerkleRoot(state.commitments);
        proof = generateCollectionProof(commitment, nft, merkleRoot);
      } else {
        if (!traitKey) {
          setError('Select a trait to prove');
          return;
        }
        const merkleRoot = generateMerkleRoot(state.commitments);
        proof = generateTraitProof(commitment, nft, traitKey, merkleRoot);
      }
      dispatch({ type: 'ADD_PROOF', payload: proof });
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Proof generation failed');
    }
  };

  return (
    <div>
      <h2>Generate Zero-Knowledge Proof</h2>
      <p style={{ color: '#888', fontSize: 14, marginBottom: 16 }}>
        Prove properties about your NFTs without revealing which one you own or your identity.
        In production, these use Circom circuits with real zk-SNARKs.
      </p>

      {state.commitments.length === 0 ? (
        <div className="empty-state">
          <h3>No Commitments</h3>
          <p>Create commitments in the Commit tab first</p>
        </div>
      ) : (
        <>
          <label style={{ fontSize: 13, color: '#888', display: 'block', marginBottom: 6 }}>
            Select Commitment
          </label>
          <select
            className="input"
            value={commitIdx}
            onChange={e => setCommitIdx(Number(e.target.value))}
          >
            {state.commitments.map((c, i) => (
              <option key={i} value={i}>
                Commitment #{i + 1} — NFT #{c.nftId}
              </option>
            ))}
          </select>

          {nft && (
            <div className="card" style={{ marginTop: 12 }}>
              <div className="flex-row">
                <strong>{nft.name}</strong>
                <span className="spacer" />
                <span style={{ fontSize: 13, color: '#888' }}>{nft.collection}</span>
              </div>
              <p className="mono" style={{ marginTop: 6, fontSize: 11 }}>
                {commitment!.commitment.slice(0, 40)}...
              </p>
            </div>
          )}

          <div style={{ marginTop: 16 }}>
            <label style={{ fontSize: 13, color: '#888', display: 'block', marginBottom: 6 }}>
              Proof Type
            </label>
            <select
              className="input"
              value={proofType}
              onChange={e => setProofType(e.target.value as ProofType)}
            >
              <option value="ownership">Ownership Proof</option>
              <option value="collection_membership">Collection Membership</option>
              <option value="trait_verification">Trait Verification</option>
            </select>
          </div>

          {proofType === 'ownership' && (
            <div className="proof-box" style={{ marginTop: 12 }}>
              <p style={{ fontSize: 13, color: '#6c63ff' }}>Ownership Proof</p>
              <p style={{ fontSize: 12, color: '#888', marginTop: 4 }}>
                Proves you own an NFT in the commitment set without revealing your identity or which NFT.
                Outputs the commitment hash as a public signal.
              </p>
            </div>
          )}

          {proofType === 'collection_membership' && (
            <div className="proof-box" style={{ marginTop: 12 }}>
              <p style={{ fontSize: 13, color: '#f39c12' }}>Collection Membership Proof</p>
              <p style={{ fontSize: 12, color: '#888', marginTop: 4 }}>
                Proves your NFT belongs to a specific collection via Merkle tree membership.
                Only the collection root is revealed — not which NFT.
              </p>
            </div>
          )}

          {proofType === 'trait_verification' && nft && (
            <div style={{ marginTop: 12 }}>
              <label style={{ fontSize: 13, color: '#888', display: 'block', marginBottom: 6 }}>
                Select Trait to Prove
              </label>
              <select className="input" value={traitKey} onChange={e => setTraitKey(e.target.value)}>
                <option value="">Choose a trait...</option>
                {Object.keys(nft.traits).map(k => (
                  <option key={k} value={k}>
                    {k} = {nft.traits[k]}
                  </option>
                ))}
              </select>
              <div className="proof-box" style={{ marginTop: 8 }}>
                <p style={{ fontSize: 13, color: '#27ae60' }}>Trait Verification Proof</p>
                <p style={{ fontSize: 12, color: '#888', marginTop: 4 }}>
                  Proves your NFT has a specific trait value without revealing which NFT you own.
                  Only the trait hash is revealed publicly.
                </p>
              </div>
            </div>
          )}

          {error && (
            <p style={{ color: '#e74c3c', fontSize: 13, marginTop: 8 }}>{error}</p>
          )}

          <button
            className="btn btn-primary"
            style={{ marginTop: 16, width: '100%' }}
            disabled={!commitment || !nft || (proofType === 'trait_verification' && !traitKey)}
            onClick={handleProve}
          >
            Generate ZK Proof
          </button>
        </>
      )}

      {state.proofs.length > 0 && (
        <>
          <p className="section-title">Generated Proofs ({state.proofs.length})</p>
          {state.proofs.map((p, i) => (
            <div key={i} className="proof-box">
              <div className="flex-row">
                <span className={`badge badge-${p.type}`}>
                  {p.type.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}
                </span>
                <span className="spacer" />
                <span style={{ fontSize: 12, color: '#555' }}>#{state.proofs.length - i}</span>
              </div>
              <p style={{ fontSize: 13, color: '#ccc', marginTop: 8 }}>{p.description}</p>
              <p className="mono" style={{ marginTop: 6 }}>Proof: {p.proof.slice(0, 32)}...</p>
              <p className="mono">Public: {p.publicSignals.join(', ').slice(0, 40)}...</p>
            </div>
          ))}
        </>
      )}
    </div>
  );
}
