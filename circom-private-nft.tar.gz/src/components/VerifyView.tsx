import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { verifyProof } from '../lib/proofs';
import type { VerificationResult } from '../types';
import '../styles/components.css';

export function VerifyView() {
  const { state } = useApp();
  const [selectedProof, setSelectedProof] = useState<number>(0);
  const [results, setResults] = useState<VerificationResult[]>([]);

  const handleVerify = () => {
    const proof = state.proofs[selectedProof];
    if (!proof) return;
    const valid = verifyProof(proof);
    const result: VerificationResult = {
      valid,
      message: valid
        ? `Valid ${proof.type.replace(/_/g, ' ')} proof — verification successful`
        : 'Invalid proof — verification failed',
    };
    setResults([result, ...results]);
  };

  return (
    <div>
      <h2>Verify Proof</h2>
      <p style={{ color: '#888', fontSize: 14, marginBottom: 16 }}>
        Verify a zero-knowledge proof. In production, this uses a verifier smart contract
        or snarkjs verification against a trusted setup.
      </p>

      {state.proofs.length === 0 ? (
        <div className="empty-state">
          <h3>No Proofs Generated</h3>
          <p>Generate proofs in the Prove tab first</p>
        </div>
      ) : (
        <>
          <label style={{ fontSize: 13, color: '#888', display: 'block', marginBottom: 6 }}>
            Select Proof to Verify
          </label>
          <select
            className="input"
            value={selectedProof}
            onChange={e => setSelectedProof(Number(e.target.value))}
          >
            {state.proofs.map((p, i) => (
              <option key={i} value={i}>
                #{state.proofs.length - i} — {p.type.replace(/_/g, ' ')}
              </option>
            ))}
          </select>

          {state.proofs[selectedProof] && (
            <div className="card" style={{ marginTop: 12 }}>
              <div className="flex-row">
                <span className={`badge badge-${state.proofs[selectedProof].type}`}>
                  {state.proofs[selectedProof].type.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}
                </span>
              </div>
              <p style={{ fontSize: 13, color: '#ccc', marginTop: 8 }}>
                {state.proofs[selectedProof].description}
              </p>
              <div style={{ marginTop: 10 }}>
                <p className="section-title">Proof Data</p>
                <p className="mono">Proof: {state.proofs[selectedProof].proof.slice(0, 40)}...</p>
                <p className="mono" style={{ marginTop: 4 }}>
                  Public Signals: {state.proofs[selectedProof].publicSignals.join(', ').slice(0, 50)}...
                </p>
              </div>

              <button
                className="btn btn-success"
                style={{ marginTop: 14, width: '100%' }}
                onClick={handleVerify}
              >
                Verify Proof
              </button>
            </div>
          )}
        </>
      )}

      {results.length > 0 && (
        <>
          <p className="section-title">Verification Results</p>
          {results.map((r, i) => (
            <div
              key={i}
              className={`proof-box ${r.valid ? 'verify-success' : 'verify-fail'}`}
            >
              <div className="flex-row">
                <span style={{ fontSize: 16 }}>{r.valid ? '✓' : '✗'}</span>
                <span
                  style={{
                    fontSize: 14,
                    fontWeight: 600,
                    color: r.valid ? '#27ae60' : '#e74c3c',
                  }}
                >
                  {r.valid ? 'VERIFIED' : 'INVALID'}
                </span>
              </div>
              <p style={{ fontSize: 13, color: '#ccc', marginTop: 6 }}>{r.message}</p>
            </div>
          ))}
        </>
      )}

      <div style={{ marginTop: 24 }}>
        <p className="section-title">Circom Circuit Reference</p>
        <div className="proof-box" style={{ fontFamily: 'monospace', fontSize: 12, lineHeight: 1.8, color: '#aaa' }}>
          <p style={{ color: '#6c63ff' }}>{'// Ownership circuit (ownership.circom)'}</p>
          <p>template NFTOwnership() {'{'}</p>
          <p>&nbsp;&nbsp;signal input nftId;</p>
          <p>&nbsp;&nbsp;signal input ownerSecret;</p>
          <p>&nbsp;&nbsp;signal input nullifier;</p>
          <p>&nbsp;&nbsp;signal output commitment;</p>
          <p>&nbsp;&nbsp;commitment {'<=='} Poseidon(nftId, ownerSecret, nullifier);</p>
          <p>{'}'}</p>
          <br />
          <p style={{ color: '#f39c12' }}>{'// Collection membership (membership.circom)'}</p>
          <p>template CollectionMembership() {'{'}</p>
          <p>&nbsp;&nbsp;signal input commitment;</p>
          <p>&nbsp;&nbsp;signal input pathElements[8];</p>
          <p>&nbsp;&nbsp;signal input pathIndices[8];</p>
          <p>&nbsp;&nbsp;signal output merkleRoot;</p>
          <p>&nbsp;&nbsp;merkleRoot {'<=='} MerkleTreeVerifier(8);</p>
          <p>{'}'}</p>
          <br />
          <p style={{ color: '#27ae60' }}>{'// Trait verification (traits.circom)'}</p>
          <p>template TraitProof() {'{'}</p>
          <p>&nbsp;&nbsp;signal input traitKey;</p>
          <p>&nbsp;&nbsp;signal input traitValue;</p>
          <p>&nbsp;&nbsp;signal input ownerSecret;</p>
          <p>&nbsp;&nbsp;signal output traitHash;</p>
          <p>&nbsp;&nbsp;traitHash {'<=='} Poseidon(traitKey, traitValue);</p>
          <p>{'}'}</p>
        </div>
      </div>
    </div>
  );
}
