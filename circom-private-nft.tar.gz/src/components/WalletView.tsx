import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { MOCK_NFTS, COLLECTION_COLORS } from '../data/mockData';
import '../styles/components.css';

export function WalletView() {
  const { state, dispatch } = useApp();
  const [showMint, setShowMint] = useState(false);

  const ownedIds = new Set(state.wallet.map(n => n.id));
  const available = MOCK_NFTS.filter(n => !ownedIds.has(n.id));

  const addToWallet = (nft: typeof MOCK_NFTS[0]) => {
    dispatch({ type: 'ADD_NFT', payload: nft });
    setShowMint(false);
  };

  const removeFromWallet = (id: number) => {
    dispatch({ type: 'REMOVE_NFT', payload: id });
    if (state.selectedNft?.id === id) {
      dispatch({ type: 'SELECT_NFT', payload: null });
    }
  };

  return (
    <div>
      <div className="flex-row" style={{ marginBottom: 16 }}>
        <h2>Private Wallet</h2>
        <span className="spacer" />
        <button className="btn btn-primary" onClick={() => setShowMint(!showMint)}>
          {showMint ? 'Cancel' : '+ Add NFT'}
        </button>
      </div>

      {showMint && (
        <div style={{ marginBottom: 20 }}>
          <p className="section-title">Available NFTs</p>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {available.map(nft => (
              <div key={nft.id} className="card" style={{ padding: 14, cursor: 'pointer' }} onClick={() => addToWallet(nft)}>
                <div className="flex-row">
                  <strong style={{ fontSize: 14 }}>{nft.name}</strong>
                  <span className="spacer" />
                  <span
                    className="badge"
                    style={{
                      background: (COLLECTION_COLORS[nft.collection] || '#666') + '33',
                      color: COLLECTION_COLORS[nft.collection] || '#666',
                    }}
                  >
                    {nft.collection}
                  </span>
                </div>
              </div>
            ))}
            {available.length === 0 && (
              <p style={{ color: '#555', gridColumn: '1/-1', textAlign: 'center', padding: 20 }}>
                All NFTs already in wallet
              </p>
            )}
          </div>
        </div>
      )}

      {state.wallet.length === 0 ? (
        <div className="empty-state">
          <h3>No NFTs Yet</h3>
          <p>Add NFTs to your private wallet to begin</p>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          {state.wallet.map(nft => (
            <div
              key={nft.id}
              className={`card ${state.selectedNft?.id === nft.id ? 'selected' : ''}`}
              style={{ cursor: 'pointer' }}
              onClick={() =>
                dispatch({
                  type: 'SELECT_NFT',
                  payload: state.selectedNft?.id === nft.id ? null : nft,
                })
              }
            >
              <div className="flex-row" style={{ marginBottom: 10 }}>
                <strong>{nft.name}</strong>
                <span className="spacer" />
                <button
                  className="btn btn-danger"
                  style={{ padding: '4px 8px', fontSize: 12 }}
                  onClick={e => {
                    e.stopPropagation();
                    removeFromWallet(nft.id);
                  }}
                >
                  Remove
                </button>
              </div>
              <span
                className="badge"
                style={{
                  background: (COLLECTION_COLORS[nft.collection] || '#666') + '33',
                  color: COLLECTION_COLORS[nft.collection] || '#666',
                  marginBottom: 10,
                  display: 'inline-block',
                }}
              >
                {nft.collection}
              </span>
              <div className="trait-grid">
                {Object.entries(nft.traits).map(([k, v]) => (
                  <div key={k} className="trait-item">
                    <div className="label">{k}</div>
                    <div className="value">{v}</div>
                  </div>
                ))}
              </div>
              {state.selectedNft?.id === nft.id && (
                <div style={{ marginTop: 10, textAlign: 'center', fontSize: 12, color: '#6c63ff' }}>
                  Selected — ready for commitment
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
