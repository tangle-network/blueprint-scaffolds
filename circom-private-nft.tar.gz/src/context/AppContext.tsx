import { createContext, useContext, useReducer, type ReactNode } from 'react';
import type { NFTItem, Commitment, Proof } from '../types';

type State = {
  wallet: NFTItem[];
  commitments: Commitment[];
  proofs: Proof[];
  selectedNft: NFTItem | null;
  activeTab: 'wallet' | 'commit' | 'prove' | 'verify';
};

type Action =
  | { type: 'ADD_NFT'; payload: NFTItem }
  | { type: 'REMOVE_NFT'; payload: number }
  | { type: 'SELECT_NFT'; payload: NFTItem | null }
  | { type: 'ADD_COMMITMENT'; payload: Commitment }
  | { type: 'ADD_PROOF'; payload: Proof }
  | { type: 'SET_TAB'; payload: State['activeTab'] };

const initialState: State = {
  wallet: [],
  commitments: [],
  proofs: [],
  selectedNft: null,
  activeTab: 'wallet',
};

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case 'ADD_NFT':
      return { ...state, wallet: [...state.wallet, action.payload] };
    case 'REMOVE_NFT':
      return { ...state, wallet: state.wallet.filter(n => n.id !== action.payload) };
    case 'SELECT_NFT':
      return { ...state, selectedNft: action.payload };
    case 'ADD_COMMITMENT':
      return { ...state, commitments: [...state.commitments, action.payload] };
    case 'ADD_PROOF':
      return { ...state, proofs: [action.payload, ...state.proofs] };
    case 'SET_TAB':
      return { ...state, activeTab: action.payload };
    default:
      return state;
  }
}

const AppCtx = createContext<{ state: State; dispatch: React.Dispatch<Action> } | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  return <AppCtx.Provider value={{ state, dispatch }}>{children}</AppCtx.Provider>;
}

export function useApp() {
  const ctx = useContext(AppCtx);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
