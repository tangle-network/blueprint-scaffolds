/// <reference types="vite/client" />

declare module "circomlibjs" {
  export function buildPoseidon(): Promise<unknown>;
}
