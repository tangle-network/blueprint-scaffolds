export type NftRecord = {
  collectionId: string;
  collectionName: string;
  tokenId: number;
  trait: string;
  image: string;
  secret: bigint;
  nullifier: bigint;
};

export type OwnershipRecord = {
  collectionId: string;
  tokenId: number;
  trait: string;
  commitment: string;
  nullifierHash: string;
  leaf: string;
};

export type ProofMode = "ownership" | "collection" | "trait";

export type GeneratedProof = {
  mode: ProofMode;
  nft: OwnershipRecord;
  merkleRoot: string;
  pathElements: string[];
  pathIndices: number[];
  publicSignals: Record<string, string>;
  proverBundle: Record<string, string>;
  verificationDigest: string;
};
