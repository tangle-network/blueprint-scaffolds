export type NFTItem = {
  id: number;
  name: string;
  collection: string;
  traits: Record<string, string>;
};

export type Commitment = {
  nftId: number;
  nullifier: string;
  commitment: string;
  ownerSecret: string;
};

export type Proof = {
  proof: string;
  publicSignals: string[];
  type: string;
  description: string;
};

export type VerificationResult = {
  valid: boolean;
  message: string;
};
