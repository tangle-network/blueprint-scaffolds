import { randomFieldElement, toHex } from "./utils"
import { poseidonHash } from "./poseidon"
import type { Proof } from "./types"

export function createNoirProof(privateKey: bigint, tokenId: number): Proof {
  const commitment = poseidonHash([privateKey, BigInt(tokenId)])
  const nullifier = poseidonHash([privateKey, BigInt(tokenId), randomFieldElement()])
  const proofData = poseidonHash([commitment, nullifier, randomFieldElement()])

  return {
    pi_a: [toHex(proofData), toHex(randomFieldElement()), toHex(1n)],
    pi_b: [
      [toHex(randomFieldElement()), toHex(randomFieldElement())],
      [toHex(randomFieldElement()), toHex(randomFieldElement())],
      [toHex(1n), toHex(2n)],
    ],
    pi_c: [toHex(poseidonHash([proofData])), toHex(randomFieldElement()), toHex(1n)],
    protocol: "ultraplonk",
    curve: "bn254",
    publicSignals: [toHex(commitment), toHex(nullifier)],
  }
}

export function aggregateProofs(proofs: Proof[]): string {
  const inputs = proofs.flatMap((p) =>
    p.publicSignals.map((s) => BigInt(s))
  )
  return toHex(poseidonHash(inputs.length > 0 ? inputs : [randomFieldElement()]))
}
