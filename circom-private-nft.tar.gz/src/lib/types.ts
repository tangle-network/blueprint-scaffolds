export interface NFTAsset {
  id: string
  name: string
  collection: string
  traits: Record<string, string>
  commitment: string
  ownerPrivateKey: string
  tokenId: number
}

export interface Proof {
  pi_a: string[]
  pi_b: string[][]
  pi_c: string[]
  protocol: string
  curve: string
  publicSignals: string[]
}

export interface CircuitType {
  id: string
  name: string
  description: string
  inputs: CircuitInput[]
}

export interface CircuitInput {
  name: string
  type: "field" | "private" | "public"
  description: string
  placeholder: string
}

export interface VerificationResult {
  valid: boolean
  circuitType: string
  timestamp: number
  publicOutputs: Record<string, string>
}

export interface WalletState {
  address: string
  balance: number
  nfts: NFTAsset[]
  isRevealed: boolean
}

export type TraitCategory = "rarity" | "element" | "power" | "region"

export interface TraitFilter {
  category: TraitCategory
  value: string
}
