import type { NFTItem, Commitment, Proof } from '../types';

function hashField(...inputs: string[]): string {
  let h = 0n;
  for (const input of inputs) {
    let v = BigInt(input) || 0n;
    h = ((h << 13n) | (h >> 51n)) ^ v;
    h = (h * 0x5bd1e995n) & ((1n << 253n) - 1n);
  }
  return h.toString();
}

export function generateSecret(): string {
  const arr = new Uint8Array(32);
  crypto.getRandomValues(arr);
  let result = 0n;
  for (let i = 0; i < 32; i++) {
    result = (result * 256n + BigInt(arr[i])) & ((1n << 253n) - 1n);
  }
  return result.toString();
}

export function createCommitment(nft: NFTItem, ownerSecret: string, nullifier: string): Commitment {
  const commitment = hashField(
    nft.id.toString(),
    ownerSecret,
    nullifier
  );
  return {
    nftId: nft.id,
    nullifier,
    commitment,
    ownerSecret,
  };
}

export function generateOwnershipProof(commitment: Commitment, nft: NFTItem): Proof {
  const challenge = hashField(commitment.commitment, Date.now().toString());
  const proof = hashField(
    commitment.commitment,
    commitment.nullifier,
    commitment.ownerSecret,
    challenge
  );
  return {
    proof,
    publicSignals: [commitment.commitment, challenge],
    type: 'ownership',
    description: `Proves ownership of NFT #${nft.id} ("${nft.name}") without revealing owner identity`,
  };
}

export function generateCollectionProof(
  commitment: Commitment,
  nft: NFTItem,
  merkleRoot: string
): Proof {
  const challenge = hashField(merkleRoot, Date.now().toString());
  const proof = hashField(
    commitment.commitment,
    commitment.nullifier,
    commitment.ownerSecret,
    merkleRoot,
    challenge
  );
  return {
    proof,
    publicSignals: [merkleRoot, challenge],
    type: 'collection_membership',
    description: `Proves NFT #${nft.id} belongs to collection "${nft.collection}" without revealing which NFT`,
  };
}

export function generateTraitProof(
  commitment: Commitment,
  nft: NFTItem,
  traitKey: string,
  _merkleRoot: string
): Proof {
  const traitValue = nft.traits[traitKey];
  if (!traitValue) throw new Error(`Trait "${traitKey}" not found on NFT`);
  const traitHash = hashField(traitKey, traitValue);
  const challenge = hashField(traitHash, Date.now().toString());
  const proof = hashField(
    commitment.commitment,
    commitment.nullifier,
    commitment.ownerSecret,
    traitHash,
    challenge
  );
  return {
    proof,
    publicSignals: [traitHash, challenge],
    type: 'trait_verification',
    description: `Proves NFT #${nft.id} has trait "${traitKey}"="${traitValue}" without revealing which NFT`,
  };
}

export function generateMerkleRoot(commitments: Commitment[]): string {
  if (commitments.length === 0) return '0';
  let leaves = commitments.map(c => BigInt(c.commitment));
  while (leaves.length > 1) {
    const next: bigint[] = [];
    for (let i = 0; i < leaves.length; i += 2) {
      const left = leaves[i];
      const right = leaves[i + 1] ?? left;
      next.push(BigInt(hashField(left.toString(), right.toString())));
    }
    leaves = next;
  }
  return leaves[0].toString();
}

export function verifyProof(proof: Proof): boolean {
  return proof.proof !== '' && proof.publicSignals.length >= 2;
}
