import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function toHex(n: bigint): string {
  return "0x" + n.toString(16).padStart(64, "0")
}

export function randomFieldElement(): bigint {
  const bits = new Uint8Array(32)
  crypto.getRandomValues(bits)
  let result = 0n
  for (let i = 0; i < 32; i++) {
    result = (result << 8n) | BigInt(bits[i])
  }
  return result % BigInt("21888242871839275222246405745257275088548364400416034343698204186575808495617")
}

export function shortenHash(hash: string): string {
  return hash.slice(0, 10) + "..." + hash.slice(-6)
}
