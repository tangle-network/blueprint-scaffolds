import { randomFieldElement, toHex } from "./utils"

const POSEIDON_CONSTANTS = [
  0x30644e72e131a029b85045b68181585d2833e84879b9709143e1f593efffff61n,
  0x6a09e667f3bcc908b2fb1366ea957d3e3adbd8264eee0f9b2a15eb2dd068ea57n,
]

function poseidonRound(state: bigint[], rc: bigint): bigint[] {
  const newState = state.map((s) => (s + rc) ** 5n)
  const sum = newState.reduce((a, b) => a + b, 0n)
  const p = BigInt("21888242871839275222246405745257275088548364400416034343698204186575808495617")
  return newState.map((s, i) => (i === 0 ? sum % p : (newState[i] + sum) % p))
}

export function poseidonHash(inputs: bigint[]): bigint {
  const p = BigInt("21888242871839275222246405745257275088548364400416034343698204186575808495617")
  const t = inputs.length + 1
  let state = [...inputs, POSEIDON_CONSTANTS[0] % BigInt(t)]

  for (let r = 0; r < 8; r++) {
    state = poseidonRound(state, POSEIDON_CONSTANTS[r % POSEIDON_CONSTANTS.length])
  }

  return state[0] % p
}

export function computeNullifier(privateKey: bigint, tokenId: number): bigint {
  return poseidonHash([privateKey, BigInt(tokenId), randomFieldElement()])
}

export function computeCommitment(privateKey: bigint, tokenId: number): string {
  const hash = poseidonHash([privateKey, BigInt(tokenId)])
  return toHex(hash)
}
