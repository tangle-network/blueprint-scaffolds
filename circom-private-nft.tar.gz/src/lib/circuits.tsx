import type { Proof, CircuitType } from "./types"
import { poseidonHash, computeNullifier, computeCommitment } from "./poseidon"
import { randomFieldElement, toHex } from "./utils"

export const CIRCUIT_TYPES: CircuitType[] = [
  {
    id: "ownership",
    name: "Private Ownership Proof",
    description: "Prove you own an NFT without revealing which one or your identity",
    inputs: [
      { name: "privateKey", type: "private", description: "Your private key", placeholder: "0x..." },
      { name: "tokenId", type: "field", description: "Token ID of the NFT", placeholder: "1" },
      { name: "commitment", type: "public", description: "Published commitment", placeholder: "0x..." },
    ],
  },
  {
    id: "membership",
    name: "Collection Membership Proof",
    description: "Prove you hold an NFT from a specific collection without revealing which token",
    inputs: [
      { name: "privateKey", type: "private", description: "Your private key", placeholder: "0x..." },
      { name: "tokenId", type: "field", description: "Token ID", placeholder: "1" },
      { name: "collectionId", type: "public", description: "Collection identifier", placeholder: "0x..." },
      { name: "merkleRoot", type: "public", description: "Merkle root of collection", placeholder: "0x..." },
    ],
  },
  {
    id: "trait",
    name: "Trait Verification Proof",
    description: "Prove your NFT has a specific trait without revealing which NFT you own",
    inputs: [
      { name: "privateKey", type: "private", description: "Your private key", placeholder: "0x..." },
      { name: "tokenId", type: "field", description: "Token ID", placeholder: "1" },
      { name: "traitValue", type: "field", description: "Trait value to prove", placeholder: "rare" },
      { name: "traitCommitment", type: "public", description: "Trait commitment", placeholder: "0x..." },
    ],
  },
]

function simulateProof(circuitId: string, inputs: Record<string, string>): Proof {
  const values: Record<string, bigint> = {}

  for (const [key, val] of Object.entries(inputs)) {
    if (val.startsWith("0x")) {
      values[key] = BigInt(val)
    } else if (!isNaN(Number(val))) {
      values[key] = BigInt(val)
    } else {
      let hash = 0n
      for (let i = 0; i < val.length; i++) {
        hash = ((hash << 5n) - hash + BigInt(val.charCodeAt(i))) % BigInt("21888242871839275222246405745257275088548364400416034343698204186575808495617")
      }
      values[key] = hash
    }
  }

  let proofHash: bigint
  let publicSignals: string[] = []

  switch (circuitId) {
    case "ownership": {
      const privKey = values.privateKey || randomFieldElement()
      const tid = values.tokenId || 0n
      const commitment = computeCommitment(privKey, Number(tid))
      const nullifier = computeNullifier(privKey, Number(tid))
      proofHash = poseidonHash([privKey, tid, nullifier])
      publicSignals = [commitment, toHex(nullifier)]
      break
    }
    case "membership": {
      const privKey = values.privateKey || randomFieldElement()
      const tid = values.tokenId || 0n
      const collId = values.collectionId || randomFieldElement()
      const merkleRoot = values.merkleRoot || randomFieldElement()
      proofHash = poseidonHash([privKey, tid, collId, merkleRoot])
      publicSignals = [toHex(collId), toHex(merkleRoot)]
      break
    }
    case "trait": {
      const privKey = values.privateKey || randomFieldElement()
      const tid = values.tokenId || 0n
      const traitVal = values.traitValue || 0n
      const traitCommit = values.traitCommitment || randomFieldElement()
      proofHash = poseidonHash([privKey, tid, traitVal, traitCommit])
      publicSignals = [toHex(traitCommit), toHex(traitVal)]
      break
    }
    default:
      proofHash = randomFieldElement()
  }

  const r1 = randomFieldElement()
  const r2 = randomFieldElement()
  const r3 = randomFieldElement()

  return {
    pi_a: [toHex(proofHash), toHex(r1), "0x0000000000000000000000000000000000000000000000000000000000000001"],
    pi_b: [
      [toHex(r2), toHex(r3)],
      [toHex(randomFieldElement()), toHex(randomFieldElement())],
      ["0x0000000000000000000000000000000000000000000000000000000000000001", "0x0000000000000000000000000000000000000000000000000000000000000002"],
    ],
    pi_c: [toHex(poseidonHash([proofHash, r1])), toHex(r2), "0x0000000000000000000000000000000000000000000000000000000000000001"],
    protocol: "groth16",
    curve: "bn128",
    publicSignals,
  }
}

export function generateProof(circuitId: string, inputs: Record<string, string>): Promise<Proof> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const proof = simulateProof(circuitId, inputs)
      resolve(proof)
    }, 1500 + Math.random() * 1000)
  })
}

export function verifyProof(_proof: Proof): Promise<boolean> {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(true)
    }, 800 + Math.random() * 500)
  })
}
