import { buildPoseidon } from "circomlibjs";
import type { GeneratedProof, NftRecord, OwnershipRecord, ProofMode } from "../types";

type Hasher = (inputs: bigint[]) => bigint;
type PoseidonFactory = {
  F: {
    toString(value: unknown): string;
  };
  (inputs: bigint[]): unknown;
};

let poseidonPromise: Promise<Hasher> | undefined;

const SNARK_FIELD =
  21888242871839275222246405745257275088548364400416034343698204186575808495617n;

function ensureHasher() {
  if (!poseidonPromise) {
    poseidonPromise = buildPoseidon().then((poseidonRaw) => {
      const poseidon = poseidonRaw as PoseidonFactory;
      const F = poseidon.F;
      return (inputs: bigint[]) => BigInt(F.toString(poseidon(inputs)));
    });
  }

  return poseidonPromise;
}

function normalize(value: bigint) {
  const mod = value % SNARK_FIELD;
  return mod >= 0n ? mod : mod + SNARK_FIELD;
}

function textToField(text: string) {
  let acc = 0n;
  for (const char of text) {
    acc = (acc * 257n + BigInt(char.codePointAt(0) ?? 0)) % SNARK_FIELD;
  }
  return acc;
}

function toHexDigest(value: bigint) {
  return `0x${normalize(value).toString(16)}`;
}

export async function createOwnershipRecord(nft: NftRecord): Promise<OwnershipRecord> {
  const poseidon = await ensureHasher();
  const collectionField = textToField(nft.collectionId);
  const traitField = textToField(nft.trait);
  const commitment = poseidon([
    nft.secret,
    nft.nullifier,
    BigInt(nft.tokenId),
    collectionField,
  ]);
  const nullifierHash = poseidon([nft.nullifier, collectionField]);
  const leaf = poseidon([collectionField, BigInt(nft.tokenId), traitField, commitment]);

  return {
    collectionId: nft.collectionId,
    tokenId: nft.tokenId,
    trait: nft.trait,
    commitment: toHexDigest(commitment),
    nullifierHash: toHexDigest(nullifierHash),
    leaf: toHexDigest(leaf),
  };
}

export async function buildMerkleArtifacts(records: OwnershipRecord[]) {
  const poseidon = await ensureHasher();
  let currentLevel = records.map((record) => BigInt(record.leaf));
  const levels: bigint[][] = [currentLevel];

  while (currentLevel.length > 1) {
    const nextLevel: bigint[] = [];
    for (let index = 0; index < currentLevel.length; index += 2) {
      const left = currentLevel[index];
      const right = currentLevel[index + 1] ?? currentLevel[index];
      nextLevel.push(poseidon([left, right]));
    }
    currentLevel = nextLevel;
    levels.push(currentLevel);
  }

  return {
    root: toHexDigest(levels[levels.length - 1][0] ?? 0n),
    levels,
  };
}

export async function getMerkleProof(records: OwnershipRecord[], leafIndex: number) {
  const { root, levels } = await buildMerkleArtifacts(records);
  const pathElements: string[] = [];
  const pathIndices: number[] = [];
  let index = leafIndex;

  for (let levelIndex = 0; levelIndex < levels.length - 1; levelIndex += 1) {
    const level = levels[levelIndex];
    const siblingIndex = index ^ 1;
    pathElements.push(toHexDigest(level[siblingIndex] ?? level[index]));
    pathIndices.push(index & 1);
    index = Math.floor(index / 2);
  }

  return { root, pathElements, pathIndices };
}

export async function generateProofPayload(
  wallet: NftRecord[],
  selectedIndex: number,
  mode: ProofMode,
): Promise<GeneratedProof> {
  const records = await Promise.all(wallet.map((item) => createOwnershipRecord(item)));
  const nft = records[selectedIndex];
  const original = wallet[selectedIndex];
  const { root, pathElements, pathIndices } = await getMerkleProof(records, selectedIndex);
  const poseidon = await ensureHasher();
  const traitHash = toHexDigest(poseidon([textToField(original.trait)]));
  const collectionField = textToField(original.collectionId);
  const verificationDigest = toHexDigest(
    poseidon([
      BigInt(nft.commitment),
      BigInt(root),
      BigInt(nft.nullifierHash),
      BigInt(selectedIndex),
    ]),
  );

  const baseSignals = {
    merkleRoot: root,
    nullifierHash: nft.nullifierHash,
    ownershipCommitment: nft.commitment,
  };

  const publicSignals =
    mode === "trait"
      ? {
          ...baseSignals,
          traitHash,
        }
      : mode === "collection"
        ? {
            ...baseSignals,
            collectionIdHash: toHexDigest(collectionField),
          }
        : baseSignals;

  return {
    mode,
    nft,
    merkleRoot: root,
    pathElements,
    pathIndices,
    publicSignals,
    proverBundle: {
      secret: original.secret.toString(),
      nullifier: original.nullifier.toString(),
      tokenId: String(original.tokenId),
      collectionId: original.collectionId,
      trait: original.trait,
    },
    verificationDigest,
  };
}

export async function verifyGeneratedProof(proof: GeneratedProof, wallet: NftRecord[]) {
  const records = await Promise.all(wallet.map((item) => createOwnershipRecord(item)));
  const match = records.find(
    (record) =>
      record.commitment === proof.publicSignals.ownershipCommitment &&
      record.nullifierHash === proof.publicSignals.nullifierHash,
  );

  if (!match) {
    return { ok: false, reason: "Commitment or nullifier does not match any wallet record." };
  }

  const merkle = await buildMerkleArtifacts(records);
  if (merkle.root !== proof.publicSignals.merkleRoot) {
    return { ok: false, reason: "Merkle root mismatch." };
  }

  if (proof.mode === "trait") {
    const poseidon = await ensureHasher();
    const expectedTraitHash = toHexDigest(poseidon([textToField(match.trait)]));
    if (expectedTraitHash !== proof.publicSignals.traitHash) {
      return { ok: false, reason: "Trait statement does not match the committed NFT." };
    }
  }

  if (proof.mode === "collection") {
    const expectedCollectionHash = toHexDigest(textToField(match.collectionId));
    if (expectedCollectionHash !== proof.publicSignals.collectionIdHash) {
      return { ok: false, reason: "Collection statement does not match the committed NFT." };
    }
  }

  return { ok: true, reason: "Statement validated against the committed wallet state." };
}
