import type { NftRecord } from "./types";

export const demoWallet: NftRecord[] = [
  {
    collectionId: "moonbirds-private",
    collectionName: "Moonbirds Private",
    tokenId: 18,
    trait: "gold-feather",
    image:
      "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=600&q=80",
    secret: 1112233445566778899n,
    nullifier: 900100200300400500n,
  },
  {
    collectionId: "azuki-shadow",
    collectionName: "Azuki Shadow",
    tokenId: 207,
    trait: "red-jacket",
    image:
      "https://images.unsplash.com/photo-1516321497487-e288fb19713f?auto=format&fit=crop&w=600&q=80",
    secret: 2223344556677889900n,
    nullifier: 800100200300400500n,
  },
  {
    collectionId: "cryptoadz-stealth",
    collectionName: "CrypToadz Stealth",
    tokenId: 911,
    trait: "laser-eyes",
    image:
      "https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=600&q=80",
    secret: 3334455667788990011n,
    nullifier: 700100200300400500n,
  },
];
