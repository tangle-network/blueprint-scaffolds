import type { NFTItem } from '../types';

export const MOCK_NFTS: NFTItem[] = [
  {
    id: 1,
    name: 'Celestial Phoenix',
    collection: 'Mythic Beasts',
    traits: { rarity: 'Legendary', element: 'Fire', power: '950', region: 'Volcano Peak' },
  },
  {
    id: 2,
    name: 'Aqua Serpent',
    collection: 'Mythic Beasts',
    traits: { rarity: 'Epic', element: 'Water', power: '780', region: 'Deep Ocean' },
  },
  {
    id: 3,
    name: 'Shadow Wolf',
    collection: 'Mythic Beasts',
    traits: { rarity: 'Rare', element: 'Dark', power: '650', region: 'Midnight Forest' },
  },
  {
    id: 4,
    name: 'Golden Ape #0042',
    collection: 'Bored Universe',
    traits: { background: 'Sunset', fur: 'Gold', eyes: 'Laser', hat: 'Crown' },
  },
  {
    id: 5,
    name: 'Cyber Punk #1337',
    collection: 'Bored Universe',
    traits: { background: 'Neon City', fur: 'Robot', eyes: 'Holographic', hat: 'Mohawk' },
  },
  {
    id: 6,
    name: 'Genesis Ring',
    collection: 'Metaverse Artifacts',
    traits: { material: 'Adamantium', glow: 'Prismatic', tier: 'S', enchantment: 'Time Warp' },
  },
];

export const COLLECTION_COLORS: Record<string, string> = {
  'Mythic Beasts': '#e74c3c',
  'Bored Universe': '#f39c12',
  'Metaverse Artifacts': '#9b59b6',
};
