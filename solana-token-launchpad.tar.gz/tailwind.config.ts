/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        sol: {
          50: '#f0f7ff',
          100: '#dcf0ff',
          200: '#b9e2ff',
          300: '#85cfff',
          400: '#4cb3f6',
          500: '#1c92dc',
          600: '#1a6fb5',
          700: '#1a5a93',
          800: '#1b4a76',
          900: '#1a3f62',
          950: '#0f2842',
        },
      },
    },
  },
  plugins: [],
};
