import { useState, useEffect } from 'react';

export function useCountdown(targetTime: number): string {
  const [countdown, setCountdown] = useState('');

  useEffect(() => {
    const update = () => {
      const diff = targetTime - Date.now();
      if (diff <= 0) {
        setCountdown('Ended');
        return;
      }
      const days = Math.floor(diff / 86400000);
      const hours = Math.floor((diff % 86400000) / 3600000);
      const mins = Math.floor((diff % 3600000) / 60000);
      const secs = Math.floor((diff % 60000) / 1000);
      if (days > 0) setCountdown(`${days}d ${hours}h ${mins}m ${secs}s`);
      else if (hours > 0) setCountdown(`${hours}h ${mins}m ${secs}s`);
      else if (mins > 0) setCountdown(`${mins}m ${secs}s`);
      else setCountdown(`${secs}s`);
    };

    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, [targetTime]);

  return countdown;
}
