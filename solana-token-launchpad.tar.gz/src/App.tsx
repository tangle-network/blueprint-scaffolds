import { useState } from 'react'
import { Calendar } from './components/Calendar'
import { ClaimPortal } from './components/ClaimPortal'
import { FeatureGrid } from './components/FeatureGrid'
import { Header } from './components/Header'
import { LaunchOpsPanel } from './components/LaunchOpsPanel'
import { ParticipationPanel } from './components/ParticipationPanel'
import { launches } from './data/launches'

function App() {
  const [selectedId, setSelectedId] = useState(launches[0].id)
  const selectedLaunch = launches.find((launch) => launch.id === selectedId) ?? launches[0]

  return (
    <div className="app-shell">
      <Header />
      <main className="main-layout">
        <FeatureGrid />
        <Calendar selectedId={selectedId} onSelect={setSelectedId} />
        <ParticipationPanel launch={selectedLaunch} />
        <LaunchOpsPanel launch={selectedLaunch} />
        <ClaimPortal />
      </main>
    </div>
  )
}

export default App
