import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { WalletProvider } from '@/context/WalletContext';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Layout } from '@/components/Layout';
import { HomePage } from '@/pages/HomePage';
import { CalendarPage } from '@/pages/CalendarPage';
import { LaunchDetailPage } from '@/pages/LaunchDetailPage';
import { ParticipatePage } from '@/pages/ParticipatePage';
import { ClaimPage } from '@/pages/ClaimPage';

export default function App() {
  return (
    <BrowserRouter>
      <WalletProvider>
        <TooltipProvider>
          <Routes>
            <Route element={<Layout />}>
              <Route path="/" element={<HomePage />} />
              <Route path="/calendar" element={<CalendarPage />} />
              <Route path="/launch/:id" element={<LaunchDetailPage />} />
              <Route path="/participate" element={<ParticipatePage />} />
              <Route path="/claim" element={<ClaimPage />} />
            </Route>
          </Routes>
        </TooltipProvider>
      </WalletProvider>
    </BrowserRouter>
  );
}
