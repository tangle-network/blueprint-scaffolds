import React, { createContext, useContext, useState, useCallback } from 'react';

interface WalletState {
  connected: boolean;
  publicKey: string | null;
  balance: number;
}

interface WalletContextType extends WalletState {
  connect: () => void;
  disconnect: () => void;
}

const WalletContext = createContext<WalletContextType>({
  connected: false,
  publicKey: null,
  balance: 0,
  connect: () => {},
  disconnect: () => {},
});

export function WalletProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<WalletState>({
    connected: false,
    publicKey: null,
    balance: 0,
  });

  const connect = useCallback(() => {
    const mockAddress = '7xKpF3a1Zb8YWjoJb9sLvMDvQjHb8aKrJjWiVfKzLZrq';
    setState({
      connected: true,
      publicKey: mockAddress,
      balance: 42.5,
    });
  }, []);

  const disconnect = useCallback(() => {
    setState({ connected: false, publicKey: null, balance: 0 });
  }, []);

  return (
    <WalletContext.Provider value={{ ...state, connect, disconnect }}>
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  return useContext(WalletContext);
}
