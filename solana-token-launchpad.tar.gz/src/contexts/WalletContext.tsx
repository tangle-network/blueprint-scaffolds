import { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { PublicKey } from '@solana/web3.js';

interface WalletState {
  connected: boolean;
  publicKey: PublicKey | null;
  balance: number;
  connect: () => Promise<void>;
  disconnect: () => void;
}

const WalletContext = createContext<WalletState>({
  connected: false,
  publicKey: null,
  balance: 0,
  connect: async () => {},
  disconnect: () => {},
});

export function useWallet() {
  return useContext(WalletContext);
}

export function WalletProvider({ children }: { children: ReactNode }) {
  const [connected, setConnected] = useState(false);
  const [publicKey, setPublicKey] = useState<PublicKey | null>(null);
  const [balance, setBalance] = useState(0);

  const connect = useCallback(async () => {
    try {
      const provider = (window as any).solana;
      if (!provider?.isPhantom) {
        window.open('https://phantom.app/', '_blank');
        return;
      }
      const resp = await provider.connect();
      setPublicKey(resp.publicKey);
      setConnected(true);
      setBalance(Math.random() * 50 + 1);
    } catch {
      setConnected(false);
      setPublicKey(null);
    }
  }, []);

  const disconnect = useCallback(() => {
    const provider = (window as any).solana;
    if (provider?.isPhantom) {
      provider.disconnect();
    }
    setConnected(false);
    setPublicKey(null);
    setBalance(0);
  }, []);

  return (
    <WalletContext.Provider value={{ connected, publicKey, balance, connect, disconnect }}>
      {children}
    </WalletContext.Provider>
  );
}
