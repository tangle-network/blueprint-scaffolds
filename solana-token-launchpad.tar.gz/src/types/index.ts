export enum LaunchType {
  FixedPrice = 'fixed_price',
  DutchAuction = 'dutch_auction',
  BondingCurve = 'bonding_curve',
  Whitelist = 'whitelist',
}

export enum LaunchStatus {
  Upcoming = 'upcoming',
  Live = 'live',
  Ended = 'ended',
  Claimable = 'claimable',
  Cancelled = 'cancelled',
}

export interface VestingSchedule {
  totalTokens: number;
  cliffDuration: number;
  cliffUnits: 'days' | 'months';
  vestingDuration: number;
  vestingUnits: 'days' | 'months';
  vestingInterval: number;
}

export interface ContributionLimit {
  minContribution: number;
  maxContribution: number;
  maxPerWallet: number;
}

export interface AntiBotConfig {
  enabled: boolean;
  minDelayBetweenTx: number;
  maxTxPerMinute: number;
  captchaRequired: boolean;
}

export interface LaunchConfig {
  id: string;
  name: string;
  symbol: string;
  description: string;
  logoUrl: string;
  website: string;
  twitter: string;
  launchType: LaunchType;
  status: LaunchStatus;
  tokenMint: string;
  tokenDecimals: number;
  totalSupply: number;
  tokensForSale: number;
  pricePerToken: number;
  startDate: string;
  endDate: string;
  vesting: VestingSchedule;
  contributionLimits: ContributionLimit;
  antiBot: AntiBotConfig;
  autoLpProvision: boolean;
  lpLockDuration: number;
  raised: number;
  participants: number;
  hardCap: number;
  softCap: number;
  dutchAuctionConfig?: {
    startPrice: number;
    endPrice: number;
    priceDecreaseInterval: number;
  };
  bondingCurveConfig?: {
    initialPrice: number;
    slope: number;
    maxSupply: number;
  };
  whitelistConfig?: {
    merkleRoot: string;
    maxWhitelistSpots: number;
    whitelistPrice: number;
  };
}

export interface Participation {
  launchId: string;
  wallet: string;
  amount: number;
  tokensAllocated: number;
  claimed: boolean;
  claimedAmount: number;
  timestamp: string;
}

export interface ClaimInfo {
  totalAllocated: number;
  totalClaimed: number;
  available: number;
  nextVestingDate: string;
  vestingSchedule: VestingSchedule;
}
