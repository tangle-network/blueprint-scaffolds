import { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { getMockLaunches, getMockClaimInfo } from '@/lib/mock-data';
import { useWallet } from '@/context/WalletContext';
import { formatNumber, formatDate, shortenAddress } from '@/lib/constants';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Gift, CheckCircle2, Lock, Clock, AlertTriangle } from 'lucide-react';

export function ClaimPage() {
  const [searchParams] = useSearchParams();
  const preselectedId = searchParams.get('launchId');
  const launches = getMockLaunches();
  const { connected, publicKey } = useWallet();

  const endedLaunches = launches.filter((l) => l.status === 'ended');
  const [selectedId, setSelectedId] = useState(preselectedId || (endedLaunches[0]?.id ?? ''));
  const [claiming, setClaiming] = useState(false);
  const [claimed, setClaimed] = useState(false);

  const claimInfo = useMemo(() => {
    if (!selectedId) return null;
    return getMockClaimInfo(selectedId);
  }, [selectedId]);

  const selectedLaunch = launches.find((l) => l.id === selectedId);

  const handleClaim = () => {
    setClaiming(true);
    setTimeout(() => {
      setClaiming(false);
      setClaimed(true);
      setTimeout(() => setClaimed(false), 3000);
    }, 2000);
  };

  const vestingPct = claimInfo
    ? (claimInfo.claimed / claimInfo.totalAllocated) * 100
    : 0;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold mb-2">Claim Portal</h1>
        <p className="text-muted-foreground">Claim your vested tokens from completed launches.</p>
      </div>

      {!connected && (
        <div className="flex items-center gap-2 p-3 rounded-md bg-yellow-500/10 text-yellow-400 text-sm">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          Connect your wallet to view and claim tokens
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Gift className="w-5 h-5 text-primary" />
                Select Launch to Claim
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Select value={selectedId} onValueChange={setSelectedId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a completed launch" />
                </SelectTrigger>
                <SelectContent>
                  {endedLaunches.map((l) => (
                    <SelectItem key={l.id} value={l.id}>
                      {l.logoUrl} {l.name} ({l.symbol})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {claimInfo && (
                <>
                  <Separator />

                  <div className="flex items-center gap-4">
                    {selectedLaunch && (
                      <div className="w-14 h-14 rounded-full solana-gradient flex items-center justify-center text-2xl">
                        {selectedLaunch.logoUrl}
                      </div>
                    )}
                    <div>
                      <h3 className="text-lg font-semibold">{claimInfo.tokenName}</h3>
                      <p className="text-sm text-muted-foreground">{claimInfo.tokenSymbol}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Vesting Progress</span>
                      <span>{vestingPct.toFixed(1)}%</span>
                    </div>
                    <Progress value={vestingPct} className="h-3" />
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="rounded-lg border p-3">
                      <div className="text-xs text-muted-foreground mb-1">Total Allocated</div>
                      <div className="text-lg font-semibold">{formatNumber(claimInfo.totalAllocated)}</div>
                    </div>
                    <div className="rounded-lg border p-3">
                      <div className="text-xs text-muted-foreground mb-1">Already Claimed</div>
                      <div className="text-lg font-semibold">{formatNumber(claimInfo.claimed)}</div>
                    </div>
                    <div className="rounded-lg border p-3 border-green-500/30">
                      <div className="text-xs text-green-400 mb-1">Claimable Now</div>
                      <div className="text-lg font-semibold text-green-400">{formatNumber(claimInfo.claimableNow)}</div>
                    </div>
                    <div className="rounded-lg border p-3">
                      <div className="text-xs text-muted-foreground mb-1">Locked</div>
                      <div className="text-lg font-semibold">
                        {formatNumber(claimInfo.totalAllocated - claimInfo.claimed - claimInfo.claimableNow)}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      Next claim: {formatDate(claimInfo.nextClaimDate)}
                    </div>
                    <div className="flex items-center gap-1">
                      <Lock className="w-4 h-4" />
                      Vesting ends: {formatDate(claimInfo.vestingEndDate)}
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <Card className="gradient-border">
            <CardHeader>
              <CardTitle className="text-lg">Claim Tokens</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {claimInfo ? (
                <>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-400 mb-1">
                      {formatNumber(claimInfo.claimableNow)}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {claimInfo.tokenSymbol} tokens available
                    </div>
                  </div>

                  <Button
                    className="w-full"
                    size="lg"
                    disabled={!connected || claiming || claimInfo.claimableNow <= 0 || claimed}
                    onClick={handleClaim}
                  >
                    {claiming ? (
                      'Claiming...'
                    ) : claimed ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 mr-2" /> Claimed Successfully
                      </>
                    ) : (
                      <>
                        <Gift className="w-4 h-4 mr-2" /> Claim {formatNumber(claimInfo.claimableNow)} {claimInfo.tokenSymbol}
                      </>
                    )}
                  </Button>
                </>
              ) : (
                <div className="text-center text-sm text-muted-foreground py-4">
                  Select a launch to view claimable tokens
                </div>
              )}
            </CardContent>
          </Card>

          {connected && publicKey && (
            <Card>
              <CardContent className="p-4">
                <div className="text-xs text-muted-foreground mb-2">Wallet</div>
                <div className="text-sm font-mono">{shortenAddress(publicKey)}</div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
