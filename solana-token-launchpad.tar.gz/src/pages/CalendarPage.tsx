import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { getMockLaunches } from '@/lib/mock-data';
import { LaunchCard } from '@/components/LaunchCard';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import type { CalendarDay } from '@/types/launch';

function buildCalendarDays(year: number, month: number): CalendarDay[] {
  const firstDay = new Date(year, month, 1);
  const startWeekday = firstDay.getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const daysInPrevMonth = new Date(year, month, 0).getDate();
  const launches = getMockLaunches();
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const days: CalendarDay[] = [];

  for (let i = startWeekday - 1; i >= 0; i--) {
    const d = new Date(year, month - 1, daysInPrevMonth - i);
    const dayLaunches = launches.filter((l) => {
      const ld = new Date(l.startTime);
      return ld.getFullYear() === d.getFullYear() && ld.getMonth() === d.getMonth() && ld.getDate() === d.getDate();
    });
    days.push({ date: d, launches: dayLaunches, isCurrentMonth: false, isToday: d.getTime() === today.getTime() });
  }

  for (let d = 1; d <= daysInMonth; d++) {
    const date = new Date(year, month, d);
    const dayLaunches = launches.filter((l) => {
      const ld = new Date(l.startTime);
      return ld.getFullYear() === date.getFullYear() && ld.getMonth() === date.getMonth() && ld.getDate() === date.getDate();
    });
    days.push({ date, launches: dayLaunches, isCurrentMonth: true, isToday: date.getTime() === today.getTime() });
  }

  const remaining = 42 - days.length;
  for (let d = 1; d <= remaining; d++) {
    const date = new Date(year, month + 1, d);
    const dayLaunches = launches.filter((l) => {
      const ld = new Date(l.startTime);
      return ld.getFullYear() === date.getFullYear() && ld.getMonth() === date.getMonth() && ld.getDate() === date.getDate();
    });
    days.push({ date, launches: dayLaunches, isCurrentMonth: false, isToday: false });
  }

  return days;
}

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export function CalendarPage() {
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth());
  const days = useMemo(() => buildCalendarDays(year, month), [year, month]);

  const prev = () => {
    if (month === 0) { setMonth(11); setYear(year - 1); }
    else setMonth(month - 1);
  };

  const next = () => {
    if (month === 11) { setMonth(0); setYear(year + 1); }
    else setMonth(month + 1);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Launch Calendar</h1>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={prev}>
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <span className="text-lg font-semibold min-w-[180px] text-center">
            {MONTH_NAMES[month]} {year}
          </span>
          <Button variant="outline" size="icon" onClick={next}>
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-7 gap-px bg-border/50 rounded-lg overflow-hidden">
            {WEEKDAYS.map((d) => (
              <div key={d} className="bg-card text-center text-xs font-medium text-muted-foreground py-2">
                {d}
              </div>
            ))}
            {days.map((day, i) => (
              <div
                key={i}
                className={`bg-card min-h-[80px] p-1.5 ${
                  !day.isCurrentMonth ? 'opacity-40' : ''
                } ${day.isToday ? 'ring-1 ring-primary' : ''}`}
              >
                <div className="text-xs font-medium mb-1">
                  {day.date.getDate()}
                </div>
                <div className="space-y-0.5">
                  {day.launches.slice(0, 2).map((l) => (
                    <Link
                      key={l.id}
                      to={`/launch/${l.id}`}
                      className={`block text-[10px] px-1 py-0.5 rounded truncate ${
                        l.status === 'live'
                          ? 'bg-green-500/20 text-green-400'
                          : l.status === 'upcoming'
                          ? 'bg-blue-500/20 text-blue-400'
                          : 'bg-gray-500/20 text-gray-400'
                      }`}
                    >
                      {l.symbol}
                    </Link>
                  ))}
                  {day.launches.length > 2 && (
                    <div className="text-[10px] text-muted-foreground px-1">
                      +{day.launches.length - 2} more
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="flex items-center gap-4 text-xs text-muted-foreground">
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-3 rounded bg-green-500/20 border border-green-500/30" /> Live
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-3 rounded bg-blue-500/20 border border-blue-500/30" /> Upcoming
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-3 rounded bg-gray-500/20 border border-gray-500/30" /> Ended
        </div>
      </div>
    </div>
  );
}
