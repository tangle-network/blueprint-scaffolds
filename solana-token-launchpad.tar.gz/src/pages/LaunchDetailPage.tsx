import { useParams, Link } from 'react-router-dom';
import { getMockLaunch } from '@/lib/mock-data';
import {
  launchTypeLabel, statusColor, formatNumber, formatDate, formatSol, shortenAddress,
} from '@/lib/constants';
import { useCountdown } from '@/hooks/useCountdown';
import { useWallet } from '@/context/WalletContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  Clock, Users, Globe, Twitter, Shield, Zap, Lock, TrendingUp, ArrowLeft, AlertTriangle,
} from 'lucide-react';

export function LaunchDetailPage() {
  const { id } = useParams<{ id: string }>();
  const launch = getMockLaunch(id || '');
  const { connected } = useWallet();

  if (!launch) {
    return (
      <div className="text-center py-20">
        <h2 className="text-xl font-semibold mb-2">Launch not found</h2>
        <Link to="/">
          <Button variant="outline">
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to Home
          </Button>
        </Link>
      </div>
    );
  }

  const countdown = useCountdown(launch.status === 'live' ? launch.endTime : launch.startTime);
  const progressPct = Math.min(
    (launch.raised / (launch.tokensForSale * launch.pricePerToken)) * 100,
    100
  );
  const isActive = launch.status === 'live';
  const isUpcoming = launch.status === 'upcoming';

  return (
    <div className="space-y-6">
      <Link to="/" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="w-4 h-4 mr-1" /> Back to launches
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-start gap-4 mb-6">
                <div className="w-16 h-16 rounded-full solana-gradient flex items-center justify-center text-2xl shrink-0">
                  {launch.logoUrl}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 mb-1">
                    <h1 className="text-2xl font-bold">{launch.name}</h1>
                    <Badge className={`${statusColor(launch.status)} border`}>
                      {launch.status.charAt(0).toUpperCase() + launch.status.slice(1)}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Badge variant="outline">{launchTypeLabel(launch.launchType)}</Badge>
                    <span>${launch.symbol}</span>
                    <span>by {shortenAddress(launch.creator)}</span>
                  </div>
                </div>
              </div>

              <p className="text-sm text-muted-foreground mb-6">{launch.description}</p>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="text-center">
                  <div className="text-xs text-muted-foreground mb-1">Time</div>
                  <div className="flex items-center justify-center gap-1 text-sm font-medium">
                    <Clock className="w-4 h-4 text-primary" />
                    {countdown}
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-xs text-muted-foreground mb-1">Raised</div>
                  <div className="text-sm font-medium">{formatSol(launch.raised)} SOL</div>
                </div>
                <div className="text-center">
                  <div className="text-xs text-muted-foreground mb-1">Participants</div>
                  <div className="flex items-center justify-center gap-1 text-sm font-medium">
                    <Users className="w-4 h-4 text-primary" />
                    {formatNumber(launch.participants)}
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-xs text-muted-foreground mb-1">Price</div>
                  <div className="text-sm font-medium">{launch.pricePerToken.toFixed(4)} SOL</div>
                </div>
              </div>

              <div className="space-y-2 mb-6">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Sale Progress</span>
                  <span className="font-medium">{progressPct.toFixed(1)}%</span>
                </div>
                <Progress value={progressPct} className="h-3" />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>{launch.raised.toFixed(2)} SOL</span>
                  <span>{formatNumber(launch.tokensForSale * launch.pricePerToken)} SOL goal</span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                {launch.websiteUrl && (
                  <a href={launch.websiteUrl} target="_blank" rel="noopener noreferrer">
                    <Button variant="outline" size="sm">
                      <Globe className="w-4 h-4 mr-1" /> Website
                    </Button>
                  </a>
                )}
                {launch.twitterUrl && (
                  <a href={launch.twitterUrl} target="_blank" rel="noopener noreferrer">
                    <Button variant="outline" size="sm">
                      <Twitter className="w-4 h-4 mr-1" /> Twitter
                    </Button>
                  </a>
                )}
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="details">
            <TabsList>
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="vesting">Vesting</TabsTrigger>
              <TabsTrigger value="antibot">Anti-Bot</TabsTrigger>
            </TabsList>
            <TabsContent value="details">
              <Card>
                <CardContent className="p-6 space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div><span className="text-muted-foreground">Total Supply:</span> {formatNumber(launch.totalSupply)}</div>
                    <div><span className="text-muted-foreground">Tokens for Sale:</span> {formatNumber(launch.tokensForSale)}</div>
                    <div><span className="text-muted-foreground">Start:</span> {formatDate(launch.startTime)}</div>
                    <div><span className="text-muted-foreground">End:</span> {formatDate(launch.endTime)}</div>
                    <div><span className="text-muted-foreground">Token Mint:</span> {shortenAddress(launch.tokenMint)}</div>
                    <div><span className="text-muted-foreground">Creator:</span> {shortenAddress(launch.creator)}</div>
                  </div>
                  {launch.launchType === 'dutch_auction' && (
                    <>
                      <Separator />
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div><span className="text-muted-foreground">Start Price:</span> {launch.startPrice?.toFixed(4)} SOL</div>
                        <div><span className="text-muted-foreground">End Price:</span> {launch.endPrice?.toFixed(4)} SOL</div>
                        <div><span className="text-muted-foreground">Decay Rate:</span> {launch.priceDecayRate}</div>
                      </div>
                    </>
                  )}
                  {launch.launchType === 'bonding_curve' && (
                    <>
                      <Separator />
                      <div className="text-sm">
                        <span className="text-muted-foreground">Curve Constant (K):</span> {launch.bondingCurveK?.toFixed(6)}
                      </div>
                    </>
                  )}
                  {launch.autoLpProvision && (
                    <>
                      <Separator />
                      <div className="flex items-center gap-2 text-sm">
                        <Zap className="w-4 h-4 text-primary" />
                        <span>Auto LP provision enabled</span>
                        <Lock className="w-4 h-4 text-primary ml-2" />
                        <span>Locked for {(launch.lpLockDuration / 86400000).toFixed(0)} days</span>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="vesting">
              <Card>
                <CardContent className="p-6 space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div><span className="text-muted-foreground">Cliff Duration:</span> {(launch.vesting.cliffDuration / 86400000).toFixed(0)} days</div>
                    <div><span className="text-muted-foreground">Cliff Amount:</span> {(launch.vesting.cliffAmount * 100).toFixed(0)}%</div>
                    <div><span className="text-muted-foreground">Vesting Duration:</span> {(launch.vesting.vestingDuration / 86400000).toFixed(0)} days</div>
                    <div><span className="text-muted-foreground">Release Interval:</span> {(launch.vesting.vestingInterval / 86400000).toFixed(0)} days</div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="antibot">
              <Card>
                <CardContent className="p-6 space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Shield className="w-4 h-4 text-primary" />
                      <span>Captcha: {launch.antiBot.captchaEnabled ? 'Enabled' : 'Disabled'}</span>
                    </div>
                    <div><span className="text-muted-foreground">Min Hold:</span> {(launch.antiBot.minHoldingPeriod / 3600000).toFixed(0)}h</div>
                    <div><span className="text-muted-foreground">Max Per Wallet:</span> {launch.antiBot.maxPerWallet.toFixed(1)} SOL</div>
                    <div><span className="text-muted-foreground">Cooldown:</span> {(launch.antiBot.cooldownBetweenTx / 60000).toFixed(0)}m</div>
                  </div>
                  <Separator />
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div><span className="text-muted-foreground">Min Contribution:</span> {launch.contributionLimits.minContribution} SOL</div>
                    <div><span className="text-muted-foreground">Max Contribution:</span> {launch.contributionLimits.maxContribution.toFixed(1)} SOL</div>
                    <div><span className="text-muted-foreground">Max Total:</span> {launch.contributionLimits.maxTotalPerWallet.toFixed(0)} SOL</div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-4">
          <Card className={isActive ? 'gradient-border' : ''}>
            <CardHeader>
              <CardTitle className="text-lg">
                {isActive ? 'Participate' : isUpcoming ? 'Not Started' : 'Sale Ended'}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {isActive && (
                <>
                  <div className="text-sm text-muted-foreground">
                    Price: <span className="text-foreground font-medium">{launch.pricePerToken.toFixed(4)} SOL</span> per token
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Min: {launch.contributionLimits.minContribution} SOL / Max: {launch.contributionLimits.maxContribution.toFixed(1)} SOL
                  </div>
                  <Link to={`/participate?launchId=${launch.id}`}>
                    <Button className="w-full" disabled={!connected}>
                      {connected ? 'Contribute' : 'Connect Wallet to Participate'}
                    </Button>
                  </Link>
                  {!connected && (
                    <p className="text-xs text-muted-foreground text-center">
                      Connect your wallet first to participate
                    </p>
                  )}
                </>
              )}
              {isUpcoming && (
                <div className="text-center text-sm text-muted-foreground">
                  <Clock className="w-8 h-8 mx-auto mb-2 text-primary" />
                  Starts {formatDate(launch.startTime)}
                </div>
              )}
              {launch.status === 'ended' && (
                <Link to={`/claim?launchId=${launch.id}`}>
                  <Button className="w-full" variant="outline">
                    Claim Tokens
                  </Button>
                </Link>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-sm mb-3">
                <AlertTriangle className="w-4 h-4 text-yellow-500" />
                <span className="font-medium">Quick Stats</span>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Sold</span>
                  <span>{formatNumber(launch.soldTokens)} tokens</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Remaining</span>
                  <span>{formatNumber(launch.tokensForSale - launch.soldTokens)} tokens</span>
                </div>
                <Separator />
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Auto LP</span>
                  <span>{launch.autoLpProvision ? 'Yes' : 'No'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">LP Lock</span>
                  <span>{(launch.lpLockDuration / 86400000).toFixed(0)} days</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
