import { useState } from 'react';
import { Link } from 'react-router-dom';
import { getMockLaunches } from '@/lib/mock-data';
import { LaunchCard } from '@/components/LaunchCard';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Rocket, TrendingUp, Shield, Zap, ArrowRight } from 'lucide-react';
import type { LaunchStatus, LaunchType } from '@/types/launch';

const features = [
  { icon: Rocket, title: 'Fair Launches', desc: 'Transparent token launches with multiple sale mechanisms' },
  { icon: Shield, title: 'Anti-Bot', desc: 'Captcha, cooldowns, and wallet limits to prevent manipulation' },
  { icon: TrendingUp, title: 'Vesting & Cliff', desc: 'Gradual token release with customizable cliff periods' },
  { icon: Zap, title: 'Auto LP & Lock', desc: 'Automatic liquidity provision and time-locked LP tokens' },
];

export function HomePage() {
  const launches = getMockLaunches();
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');

  const liveLaunches = launches.filter((l) => l.status === 'live');
  const filtered = launches.filter((l) => {
    if (statusFilter !== 'all' && l.status !== statusFilter) return false;
    if (typeFilter !== 'all' && l.launchType !== typeFilter) return false;
    return true;
  });

  return (
    <div className="space-y-12">
      <section className="text-center py-12 relative">
        <div className="absolute inset-0 solana-gradient opacity-5 rounded-3xl blur-3xl" />
        <div className="relative">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Fair Token Launches on{' '}
            <span className="solana-gradient bg-clip-text text-transparent">Solana</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            Launch tokens with fixed-price sales, Dutch auctions, bonding curves, or whitelist rounds.
            Built-in anti-bot measures, vesting, and auto LP provision.
          </p>
          <div className="flex items-center justify-center gap-3">
            <Link to="/calendar">
              <Button size="lg">
                View Calendar <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
            <Link to="/participate">
              <Button size="lg" variant="outline">
                Explore Launches
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <section>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {features.map(({ icon: Icon, title, desc }) => (
            <div
              key={title}
              className="rounded-lg border border-border/50 bg-card/50 p-5 hover:border-primary/30 transition-colors"
            >
              <Icon className="w-8 h-8 text-primary mb-3" />
              <h3 className="font-semibold mb-1">{title}</h3>
              <p className="text-sm text-muted-foreground">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {liveLaunches.length > 0 && (
        <section>
          <div className="flex items-center gap-3 mb-4">
            <h2 className="text-2xl font-bold">Live Now</h2>
            <Badge className="bg-green-500/20 text-green-400 border-green-500/30 border animate-pulse">
              {liveLaunches.length} Active
            </Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {liveLaunches.map((l) => (
              <LaunchCard key={l.id} launch={l} />
            ))}
          </div>
        </section>
      )}

      <section>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <h2 className="text-2xl font-bold">All Launches</h2>
          <div className="flex items-center gap-3">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="upcoming">Upcoming</SelectItem>
                <SelectItem value="live">Live</SelectItem>
                <SelectItem value="ended">Ended</SelectItem>
              </SelectContent>
            </Select>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="fixed_price">Fixed Price</SelectItem>
                <SelectItem value="dutch_auction">Dutch Auction</SelectItem>
                <SelectItem value="bonding_curve">Bonding Curve</SelectItem>
                <SelectItem value="whitelist">Whitelist</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((l) => (
            <LaunchCard key={l.id} launch={l} />
          ))}
        </div>
        {filtered.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            No launches match your filters.
          </div>
        )}
      </section>
    </div>
  );
}
