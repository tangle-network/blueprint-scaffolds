import { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { getMockLaunches, getMockUserParticipations } from '@/lib/mock-data';
import { LaunchCard } from '@/components/LaunchCard';
import { useWallet } from '@/context/WalletContext';
import { launchTypeLabel, formatNumber, formatSol } from '@/lib/constants';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Coins, AlertTriangle, CheckCircle2 } from 'lucide-react';

export function ParticipatePage() {
  const [searchParams] = useSearchParams();
  const preselectedId = searchParams.get('launchId');
  const launches = getMockLaunches();
  const activeLaunches = launches.filter((l) => l.status === 'live');
  const { connected, publicKey } = useWallet();

  const [selectedId, setSelectedId] = useState(preselectedId || (activeLaunches[0]?.id ?? ''));
  const [amount, setAmount] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const selectedLaunch = launches.find((l) => l.id === selectedId);

  const participations = useMemo(() => {
    if (!connected || !publicKey) return [];
    return getMockUserParticipations(publicKey);
  }, [connected, publicKey]);

  const estimatedTokens = selectedLaunch && amount
    ? parseFloat(amount) / selectedLaunch.pricePerToken
    : 0;

  const handleSubmit = () => {
    if (!amount || !selectedLaunch) return;
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold mb-2">Participate in a Launch</h1>
        <p className="text-muted-foreground">Contribute SOL to token launches and receive allocated tokens.</p>
      </div>

      <Tabs defaultValue="participate">
        <TabsList>
          <TabsTrigger value="participate">Contribute</TabsTrigger>
          <TabsTrigger value="my-participations">My Participations</TabsTrigger>
          <TabsTrigger value="browse">Browse All</TabsTrigger>
        </TabsList>

        <TabsContent value="participate">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Contribute</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {!connected && (
                  <div className="flex items-center gap-2 p-3 rounded-md bg-yellow-500/10 text-yellow-400 text-sm">
                    <AlertTriangle className="w-4 h-4 shrink-0" />
                    Connect your wallet to participate
                  </div>
                )}

                <div>
                  <Label>Select Launch</Label>
                  <Select value={selectedId} onValueChange={setSelectedId}>
                    <SelectTrigger className="mt-1.5">
                      <SelectValue placeholder="Select a launch" />
                    </SelectTrigger>
                    <SelectContent>
                      {activeLaunches.map((l) => (
                        <SelectItem key={l.id} value={l.id}>
                          {l.logoUrl} {l.name} ({l.symbol}) - {launchTypeLabel(l.launchType)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedLaunch && (
                  <>
                    <div>
                      <Label>Amount (SOL)</Label>
                      <Input
                        type="number"
                        placeholder={`Min ${selectedLaunch.contributionLimits.minContribution} SOL`}
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        className="mt-1.5"
                        min={selectedLaunch.contributionLimits.minContribution}
                        max={selectedLaunch.contributionLimits.maxContribution}
                      />
                      <p className="text-xs text-muted-foreground mt-1">
                        Range: {selectedLaunch.contributionLimits.minContribution} - {selectedLaunch.contributionLimits.maxContribution.toFixed(1)} SOL
                      </p>
                    </div>

                    <Separator />

                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Price per token</span>
                        <span>{selectedLaunch.pricePerToken.toFixed(4)} SOL</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Estimated tokens</span>
                        <span>{formatNumber(estimatedTokens)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Cliff</span>
                        <span>{(selectedLaunch.vesting.cliffDuration / 86400000).toFixed(0)} days</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Vesting</span>
                        <span>{(selectedLaunch.vesting.vestingDuration / 86400000).toFixed(0)} days</span>
                      </div>
                    </div>

                    <Button
                      className="w-full"
                      disabled={!connected || !amount || parseFloat(amount) <= 0 || submitted}
                      onClick={handleSubmit}
                    >
                      {submitted ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 mr-2" /> Transaction Submitted
                        </>
                      ) : (
                        <>
                          <Coins className="w-4 h-4 mr-2" /> Contribute {amount ? `${amount} SOL` : ''}
                        </>
                      )}
                    </Button>
                  </>
                )}
              </CardContent>
            </Card>

            {selectedLaunch && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Launch Info</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full solana-gradient flex items-center justify-center text-xl">
                      {selectedLaunch.logoUrl}
                    </div>
                    <div>
                      <h3 className="font-semibold">{selectedLaunch.name}</h3>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Badge variant="outline" className="text-xs">
                          {launchTypeLabel(selectedLaunch.launchType)}
                        </Badge>
                        <Badge className="bg-green-500/20 text-green-400 border-green-500/30 border text-xs">
                          Live
                        </Badge>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Progress</span>
                      <span>{((selectedLaunch.raised / (selectedLaunch.tokensForSale * selectedLaunch.pricePerToken)) * 100).toFixed(1)}%</span>
                    </div>
                    <Progress
                      value={(selectedLaunch.raised / (selectedLaunch.tokensForSale * selectedLaunch.pricePerToken)) * 100}
                      className="h-2"
                    />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>{formatSol(selectedLaunch.raised)} SOL</span>
                      <span>{formatNumber(selectedLaunch.participants)} participants</span>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Anti-Bot Captcha</span>
                      <span>{selectedLaunch.antiBot.captchaEnabled ? 'Enabled' : 'Disabled'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Cooldown</span>
                      <span>{(selectedLaunch.antiBot.cooldownBetweenTx / 60000).toFixed(0)} min</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Auto LP</span>
                      <span>{selectedLaunch.autoLpProvision ? 'Yes' : 'No'}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="my-participations">
          {!connected ? (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                Connect your wallet to view your participations.
              </CardContent>
            </Card>
          ) : participations.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                You haven't participated in any launches yet.
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {participations.map((p) => {
                const launch = launches.find((l) => l.id === p.launchId);
                return (
                  <Card key={p.launchId}>
                    <CardContent className="p-5">
                      <div className="flex items-center gap-3 mb-3">
                        {launch && (
                          <div className="w-10 h-10 rounded-full solana-gradient flex items-center justify-center">
                            {launch.logoUrl}
                          </div>
                        )}
                        <div>
                          <h3 className="font-semibold">{launch?.name || p.launchId}</h3>
                          <p className="text-xs text-muted-foreground">{launch?.symbol}</p>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <span className="text-muted-foreground text-xs">Contributed</span>
                          <div>{p.contributed.toFixed(2)} SOL</div>
                        </div>
                        <div>
                          <span className="text-muted-foreground text-xs">Allocated</span>
                          <div>{formatNumber(p.allocatedTokens)} tokens</div>
                        </div>
                        <div>
                          <span className="text-muted-foreground text-xs">Claimed</span>
                          <div>{formatNumber(p.claimed)} tokens</div>
                        </div>
                        <div>
                          <span className="text-muted-foreground text-xs">Claimable</span>
                          <div className="text-green-400">{formatNumber(p.claimable)} tokens</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="browse">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {launches.map((l) => (
              <LaunchCard key={l.id} launch={l} />
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
