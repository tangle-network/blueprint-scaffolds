export type LaunchType = 'fixed_price' | 'dutch_auction' | 'bonding_curve' | 'whitelist';

export type LaunchStatus = 'upcoming' | 'live' | 'ended' | 'cancelled';

export interface VestingSchedule {
  cliffDuration: number;
  cliffAmount: number;
  vestingDuration: number;
  vestingInterval: number;
}

export interface AntiBotConfig {
  captchaEnabled: boolean;
  minHoldingPeriod: number;
  maxPerWallet: number;
  cooldownBetweenTx: number;
}

export interface ContributionLimit {
  minContribution: number;
  maxContribution: number;
  maxTotalPerWallet: number;
}

export interface LaunchConfig {
  id: string;
  name: string;
  symbol: string;
  description: string;
  logoUrl: string;
  tokenMint: string;
  creator: string;
  launchType: LaunchType;
  status: LaunchStatus;
  totalSupply: number;
  tokensForSale: number;
  pricePerToken: number;
  startPrice?: number;
  endPrice?: number;
  priceDecayRate?: number;
  bondingCurveK?: number;
  startTime: number;
  endTime: number;
  vesting: VestingSchedule;
  antiBot: AntiBotConfig;
  contributionLimits: ContributionLimit;
  autoLpProvision: boolean;
  lpLockDuration: number;
  raised: number;
  participants: number;
  soldTokens: number;
  whitelistMerkleRoot?: string;
  websiteUrl?: string;
  twitterUrl?: string;
}

export interface UserParticipation {
  launchId: string;
  wallet: string;
  contributed: number;
  allocatedTokens: number;
  claimed: number;
  claimable: number;
  vestingClaimed: number;
}

export interface ClaimInfo {
  launchId: string;
  tokenName: string;
  tokenSymbol: string;
  totalAllocated: number;
  claimed: number;
  claimableNow: number;
  nextClaimDate: number;
  vestingEndDate: number;
}

export interface CalendarDay {
  date: Date;
  launches: LaunchConfig[];
  isCurrentMonth: boolean;
  isToday: boolean;
}

export interface WalletState {
  connected: boolean;
  publicKey: string | null;
  balance: number;
}

export interface WalletContextType extends WalletState {
  connect: () => void;
  disconnect: () => void;
}
