import { LaunchType } from '../types';

export function formatSOL(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 4,
  }).format(amount);
}

export function formatNumber(n: number): string {
  if (n >= 1_000_000_000) return (n / 1_000_000_000).toFixed(2) + 'B';
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(2) + 'M';
  if (n >= 1_000) return (n / 1_000).toFixed(2) + 'K';
  return n.toFixed(2);
}

export function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function daysRemaining(endDate: string): number {
  const diff = new Date(endDate).getTime() - Date.now();
  return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
}

export function progressPercent(raised: number, cap: number): number {
  if (cap === 0) return 0;
  return Math.min(100, (raised / cap) * 100);
}

export function launchTypeLabel(type: LaunchType): string {
  switch (type) {
    case LaunchType.FixedPrice:
      return 'Fixed Price';
    case LaunchType.DutchAuction:
      return 'Dutch Auction';
    case LaunchType.BondingCurve:
      return 'Bonding Curve';
    case LaunchType.Whitelist:
      return 'Whitelist';
  }
}

export function launchTypeColor(type: LaunchType): string {
  switch (type) {
    case LaunchType.FixedPrice:
      return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
    case LaunchType.DutchAuction:
      return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
    case LaunchType.BondingCurve:
      return 'bg-green-500/20 text-green-400 border-green-500/30';
    case LaunchType.Whitelist:
      return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
  }
}

export function statusColor(status: string): string {
  switch (status) {
    case 'live':
      return 'bg-green-500';
    case 'upcoming':
      return 'bg-yellow-500';
    case 'ended':
      return 'bg-gray-500';
    case 'claimable':
      return 'bg-cyan-500';
    case 'cancelled':
      return 'bg-red-500';
    default:
      return 'bg-gray-500';
  }
}

export function truncateAddress(address: string): string {
  if (!address) return '';
  return address.slice(0, 4) + '...' + address.slice(-4);
}

export function getDutchAuctionPrice(
  startPrice: number,
  endPrice: number,
  startDate: string,
  endDate: string,
): number {
  const now = Date.now();
  const start = new Date(startDate).getTime();
  const end = new Date(endDate).getTime();
  if (now <= start) return startPrice;
  if (now >= end) return endPrice;
  const progress = (now - start) / (end - start);
  return startPrice - (startPrice - endPrice) * progress;
}

export function getBondingCurvePrice(
  currentSupply: number,
  slope: number,
  initialPrice: number,
): number {
  return initialPrice + slope * currentSupply;
}
