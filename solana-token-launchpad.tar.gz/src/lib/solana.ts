import { PublicKey } from '@solana/web3.js'
import type { Launch, ParticipationPreview } from '../types'

export const FAIR_MINT_PROGRAM_ID = new PublicKey(
  'FM1ntRrWwUVom7k25rh8K4yY5C1H1s3PG2L7AqM3zby',
)

export function safeShortAddress(address: string) {
  return `${address.slice(0, 4)}...${address.slice(-4)}`
}

export function deriveMintAddress(seed: string) {
  const bytes = new TextEncoder().encode(seed.padEnd(32, '0').slice(0, 32))
  return new PublicKey(bytes)
}

export function computeParticipationPreview(
  launch: Launch,
  contribution: number,
  walletCommitted: number,
  isWhitelisted: boolean,
): ParticipationPreview {
  const totalAllocation = launch.tokenSupply * (launch.saleAllocationPercent / 100)
  const walletCapReached =
    walletCommitted + contribution > launch.contributionPolicy.perWalletCap
  const requiresWhitelist = launch.whitelistEnabled && !isWhitelisted

  let clearingPrice = launch.basePrice
  if (launch.type === 'dutch-auction' && launch.priceFloor && launch.priceCeiling) {
    const fillRatio = launch.targetRaise === 0 ? 0 : launch.contributed / launch.targetRaise
    clearingPrice =
      launch.priceCeiling - (launch.priceCeiling - launch.priceFloor) * Math.min(fillRatio, 1)
  }

  if (launch.type === 'bonding-curve') {
    const progress = (launch.contributed + contribution) / launch.targetRaise
    clearingPrice = launch.basePrice * (1 + (launch.curveFactor ?? 1) * progress)
  }

  const estimatedTokenOutput = contribution <= 0 ? 0 : (contribution / clearingPrice) * 100
  const liquidityReserved = totalAllocation * (launch.liquidityPlan.lpPercent / 100)

  return {
    estimatedTokenOutput,
    clearingPrice,
    walletCapReached,
    requiresWhitelist,
    liquidityReserved,
  }
}
