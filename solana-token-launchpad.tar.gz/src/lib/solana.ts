import {
  Connection,
  Keypair,
  PublicKey,
  SystemProgram,
  Transaction,
  LAMPORTS_PER_SOL,
  TransactionInstruction,
} from '@solana/web3.js';
import {
  createInitializeMintInstruction,
  TOKEN_PROGRAM_ID,
  MINT_SIZE,
  getMinimumBalanceForRentExemptMint,
  createAssociatedTokenAccountInstruction,
  getAssociatedTokenAddressSync,
  ASSOCIATED_TOKEN_PROGRAM_ID,
} from '@solana/spl-token';

const RPC_ENDPOINT = 'https://api.devnet.solana.com';

export function getConnection(): Connection {
  return new Connection(RPC_ENDPOINT, 'confirmed');
}

export async function deploySPLToken(
  payer: Keypair,
  decimals: number = 9,
): Promise<{ mint: PublicKey; signature: string }> {
  const connection = getConnection();
  const lamports = await getMinimumBalanceForRentExemptMint(connection);
  const mintKeypair = Keypair.generate();

  const transaction = new Transaction().add(
    SystemProgram.createAccount({
      fromPubkey: payer.publicKey,
      newAccountPubkey: mintKeypair.publicKey,
      space: MINT_SIZE,
      lamports,
      programId: TOKEN_PROGRAM_ID,
    }),
    createInitializeMintInstruction(
      mintKeypair.publicKey,
      decimals,
      payer.publicKey,
      payer.publicKey,
      TOKEN_PROGRAM_ID,
    ),
  );

  const signature = await connection.sendTransaction(transaction, [payer, mintKeypair]);
  await connection.confirmTransaction(signature, 'confirmed');

  return { mint: mintKeypair.publicKey, signature };
}

export async function createTokenAccount(
  payer: Keypair,
  mint: PublicKey,
  owner: PublicKey,
): Promise<Transaction> {
  const connection = getConnection();
  const ata = getAssociatedTokenAddressSync(mint, owner, false, TOKEN_PROGRAM_ID, ASSOCIATED_TOKEN_PROGRAM_ID);

  const transaction = new Transaction().add(
    createAssociatedTokenAccountInstruction(
      payer.publicKey,
      ata,
      owner,
      mint,
      TOKEN_PROGRAM_ID,
      ASSOCIATED_TOKEN_PROGRAM_ID,
    ),
  );

  const { blockhash } = await connection.getLatestBlockhash();
  transaction.recentBlockhash = blockhash;
  transaction.feePayer = payer.publicKey;

  return transaction;
}

export function createVestingInstruction(
  programId: PublicKey,
  payer: PublicKey,
  beneficiary: PublicKey,
  mint: PublicKey,
  vestingAccount: PublicKey,
  totalAmount: number,
  cliffTimestamp: number,
  endTimestamp: number,
  interval: number,
): TransactionInstruction {
  const data = Buffer.alloc(8 + 8 + 8 + 8 + 8);
  data.writeBigUInt64LE(BigInt(totalAmount), 0);
  data.writeBigUInt64LE(BigInt(cliffTimestamp), 8);
  data.writeBigUInt64LE(BigInt(endTimestamp), 16);
  data.writeBigUInt64LE(BigInt(interval), 24);

  return new TransactionInstruction({
    keys: [
      { pubkey: payer, isSigner: true, isWritable: true },
      { pubkey: beneficiary, isSigner: false, isWritable: true },
      { pubkey: mint, isSigner: false, isWritable: false },
      { pubkey: vestingAccount, isSigner: false, isWritable: true },
      { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
      { pubkey: TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
    ],
    programId,
    data,
  });
}

export function createAntiBotInstruction(
  programId: PublicKey,
  launchConfig: PublicKey,
  minDelay: number,
  maxTxPerMinute: number,
): TransactionInstruction {
  const data = Buffer.alloc(8 + 8);
  data.writeBigUInt64LE(BigInt(minDelay), 0);
  data.writeBigUInt64LE(BigInt(maxTxPerMinute), 8);

  return new TransactionInstruction({
    keys: [
      { pubkey: launchConfig, isSigner: false, isWritable: true },
    ],
    programId,
    data,
  });
}

export function createAutoLpLockInstruction(
  programId: PublicKey,
  authority: PublicKey,
  tokenMint: PublicKey,
  quoteMint: PublicKey,
  lpTokenAccount: PublicKey,
  lockDuration: number,
): TransactionInstruction {
  const data = Buffer.alloc(8 + 8);
  data.writeBigUInt64LE(BigInt(lockDuration * LAMPORTS_PER_SOL), 0);
  data.writeBigUInt64LE(BigInt(0), 8);

  return new TransactionInstruction({
    keys: [
      { pubkey: authority, isSigner: true, isWritable: true },
      { pubkey: tokenMint, isSigner: false, isWritable: true },
      { pubkey: quoteMint, isSigner: false, isWritable: true },
      { pubkey: lpTokenAccount, isSigner: false, isWritable: true },
      { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
      { pubkey: TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
    ],
    programId,
    data,
  });
}

export function getPhantomProvider(): any {
  if (typeof window !== 'undefined') {
    const solana = (window as any).solana;
    if (solana?.isPhantom) return solana;
  }
  return null;
}
