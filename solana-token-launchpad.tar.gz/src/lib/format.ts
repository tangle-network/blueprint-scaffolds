import { format, formatDistanceToNowStrict } from 'date-fns'

export function formatUsd(value: number) {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 2,
  }).format(value)
}

export function formatCompact(value: number) {
  return new Intl.NumberFormat('en-US', {
    notation: 'compact',
    maximumFractionDigits: 2,
  }).format(value)
}

export function formatPercent(value: number) {
  return `${value.toFixed(value >= 10 ? 0 : 1)}%`
}

export function formatDateTime(value: string) {
  return format(new Date(value), 'MMM d, yyyy HH:mm UTC')
}

export function formatCountdown(value: string) {
  return formatDistanceToNowStrict(new Date(value), { addSuffix: true })
}
