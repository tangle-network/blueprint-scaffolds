import { LaunchConfig, LaunchType, LaunchStatus } from '@/types/launch';

const MOCK_CREATORS = [
  '7xKpF3a1Zb8YWjoJb9sLvMDvQjHb8aKrJjWiVfKzLZrq',
  'DRpbCBMxVnDK7maPMoGQfFiB4P4cByAHpLMkP1g8vAJw',
  'B1iGxMLMb9Z8RFgSX5XzGqoi5y8YFm3jF1sQjRTYyLBY',
];

const MOCK_TOKENS = [
  { name: 'NovaCoin', symbol: 'NOVA', logo: '🚀' },
  { name: 'SolFlare', symbol: 'SFLR', logo: '🔥' },
  { name: 'MetaVault', symbol: 'MVT', logo: '🏦' },
  { name: 'GalaxyPay', symbol: 'GPAY', logo: '🌌' },
  { name: 'CryptoNexus', symbol: 'CNEX', logo: '🔗' },
  { name: 'StarForge', symbol: 'STRF', logo: '⭐' },
  { name: 'OrbitDAO', symbol: 'ORBD', logo: '🪐' },
  { name: 'QuantumSwap', symbol: 'QSWP', logo: '⚛️' },
  { name: 'PulseFi', symbol: 'PLSF', logo: '💓' },
  { name: 'AetherDAO', symbol: 'AETH', logo: '🌀' },
  { name: 'SolarisNet', symbol: 'SNET', logo: '☀️' },
  { name: 'NeonStake', symbol: 'NSTK', logo: '💜' },
];

const launchTypes: LaunchType[] = ['fixed_price', 'dutch_auction', 'bonding_curve', 'whitelist'];
const statuses: LaunchStatus[] = ['upcoming', 'live', 'ended', 'upcoming'];

function randomBetween(min: number, max: number): number {
  return Math.random() * (max - min) + min;
}

function generateLaunch(id: number, daysOffset: number): LaunchConfig {
  const token = MOCK_TOKENS[id % MOCK_TOKENS.length];
  const launchType = launchTypes[id % launchTypes.length];
  const status = statuses[id % statuses.length];
  const now = Date.now();
  const startTime = now + daysOffset * 86400000 + randomBetween(-3600000, 3600000);
  const duration = randomBetween(86400000, 604800000);
  const totalSupply = Math.floor(randomBetween(1000000, 100000000));
  const tokensForSale = Math.floor(totalSupply * randomBetween(0.3, 0.6));
  const price = randomBetween(0.001, 0.5);
  const raised = status === 'ended' ? randomBetween(100, 5000) : status === 'live' ? randomBetween(10, 2000) : 0;

  return {
    id: `launch_${id}`,
    name: token.name,
    symbol: token.symbol,
    description: `${token.name} is a next-generation DeFi protocol built on Solana, offering innovative solutions for decentralized trading and yield generation. The ${token.symbol} token powers the ecosystem governance and staking rewards.`,
    logoUrl: token.logo,
    tokenMint: `TokenMint${id.toString().padStart(40, '1')}`,
    creator: MOCK_CREATORS[id % MOCK_CREATORS.length],
    launchType,
    status,
    totalSupply,
    tokensForSale,
    pricePerToken: price,
    startPrice: launchType === 'dutch_auction' ? price * 2 : undefined,
    endPrice: launchType === 'dutch_auction' ? price * 0.1 : undefined,
    priceDecayRate: launchType === 'dutch_auction' ? 0.05 : undefined,
    bondingCurveK: launchType === 'bonding_curve' ? randomBetween(0.0001, 0.01) : undefined,
    startTime,
    endTime: startTime + duration,
    vesting: {
      cliffDuration: randomBetween(0, 30) * 86400000,
      cliffAmount: randomBetween(0, 0.25),
      vestingDuration: randomBetween(90, 365) * 86400000,
      vestingInterval: randomBetween(7, 30) * 86400000,
    },
    antiBot: {
      captchaEnabled: id % 2 === 0,
      minHoldingPeriod: Math.floor(randomBetween(0, 72)) * 3600000,
      maxPerWallet: randomBetween(1, 10),
      cooldownBetweenTx: Math.floor(randomBetween(1, 30)) * 60000,
    },
    contributionLimits: {
      minContribution: 0.1,
      maxContribution: randomBetween(5, 50),
      maxTotalPerWallet: randomBetween(10, 100),
    },
    autoLpProvision: id % 3 !== 0,
    lpLockDuration: randomBetween(30, 365) * 86400000,
    raised,
    participants: Math.floor(randomBetween(50, 5000)),
    soldTokens: Math.floor(tokensForSale * (raised / (tokensForSale * price || 1))),
    whitelistMerkleRoot: launchType === 'whitelist' ? 'merkleRoot123abc' : undefined,
    websiteUrl: `https://${token.symbol.toLowerCase()}.io`,
    twitterUrl: `https://twitter.com/${token.symbol.toLowerCase()}`,
  };
}

let cachedLaunches: LaunchConfig[] | null = null;

export function getMockLaunches(): LaunchConfig[] {
  if (cachedLaunches) return cachedLaunches;
  cachedLaunches = [];
  for (let i = 0; i < 12; i++) {
    cachedLaunches.push(generateLaunch(i, i - 6));
  }
  return cachedLaunches;
}

export function getMockLaunch(id: string): LaunchConfig | undefined {
  return getMockLaunches().find((l) => l.id === id);
}

export function getMockUserParticipations(walletAddress: string) {
  const launches = getMockLaunches();
  return launches
    .filter((l) => l.status === 'live' || l.status === 'ended')
    .slice(0, 4)
    .map((launch) => ({
      launchId: launch.id,
      wallet: walletAddress,
      contributed: randomBetween(0.5, 20),
      allocatedTokens: randomBetween(100, 10000),
      claimed: randomBetween(0, 50),
      claimable: randomBetween(10, 200),
      vestingClaimed: randomBetween(0, 30),
    }));
}

export function getMockClaimInfo(launchId: string): ClaimInfo | null {
  const launch = getMockLaunch(launchId);
  if (!launch) return null;
  return {
    launchId,
    tokenName: launch.name,
    tokenSymbol: launch.symbol,
    totalAllocated: Math.floor(randomBetween(500, 20000)),
    claimed: Math.floor(randomBetween(0, 200)),
    claimableNow: Math.floor(randomBetween(50, 500)),
    nextClaimDate: Date.now() + randomBetween(86400000, 604800000),
    vestingEndDate: launch.endTime + launch.vesting.vestingDuration,
  };
}

import type { ClaimInfo } from '@/types/launch';
