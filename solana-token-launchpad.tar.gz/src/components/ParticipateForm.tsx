import { LaunchConfig, LaunchType, LaunchStatus } from '../types';
import { useWallet } from '../contexts/WalletContext';
import { useNotification } from '../contexts/NotificationContext';
import {
  formatSOL,
  formatNumber,
  progressPercent,
  launchTypeLabel,
  launchTypeColor,
  getDutchAuctionPrice,
  getBondingCurvePrice,
} from '../lib/utils';
import { useState } from 'react';

interface Props {
  launch: LaunchConfig;
}

export default function ParticipateForm({ launch }: Props) {
  const { connected, connect } = useWallet();
  const { addNotification } = useNotification();
  const [amount, setAmount] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const currentPrice = (() => {
    switch (launch.launchType) {
      case LaunchType.DutchAuction:
        return launch.dutchAuctionConfig
          ? getDutchAuctionPrice(
              launch.dutchAuctionConfig.startPrice,
              launch.dutchAuctionConfig.endPrice,
              launch.startDate,
              launch.endDate,
            )
          : 0;
      case LaunchType.BondingCurve:
        return launch.bondingCurveConfig
          ? getBondingCurvePrice(
              launch.raised,
              launch.bondingCurveConfig.slope,
              launch.bondingCurveConfig.initialPrice,
            )
          : 0;
      default:
        return launch.pricePerToken;
    }
  })();

  const tokensEstimate = amount ? (parseFloat(amount) / Math.max(currentPrice, 0.0001)) : 0;
  const isLive = launch.status === LaunchStatus.Live;
  const isUpcoming = launch.status === LaunchStatus.Upcoming;
  const progress = progressPercent(launch.raised, launch.hardCap);

  const handleSubmit = async () => {
    if (!connected) {
      await connect();
      return;
    }
    const val = parseFloat(amount);
    if (!val || val <= 0) {
      addNotification('error', 'Enter a valid amount');
      return;
    }
    if (val < launch.contributionLimits.minContribution) {
      addNotification('error', `Minimum contribution is ${launch.contributionLimits.minContribution} SOL`);
      return;
    }
    if (val > launch.contributionLimits.maxContribution) {
      addNotification('error', `Maximum contribution is ${launch.contributionLimits.maxContribution} SOL`);
      return;
    }

    setSubmitting(true);
    try {
      await new Promise((r) => setTimeout(r, 1500));
      addNotification('success', `Successfully contributed ${val} SOL to ${launch.name}!`);
      setAmount('');
    } catch {
      addNotification('error', 'Transaction failed. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 space-y-5">
      <h3 className="text-white font-semibold text-lg">Participate</h3>

      <div className={`inline-block text-xs font-medium px-2.5 py-1 rounded-full border ${launchTypeColor(launch.launchType)}`}>
        {launchTypeLabel(launch.launchType)}
      </div>

      <div className="space-y-3">
        <div className="flex justify-between text-sm">
          <span className="text-gray-400">Current Price</span>
          <span className="text-white font-medium">{currentPrice.toFixed(6)} SOL</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-400">Progress</span>
          <span className="text-white font-medium">{progress.toFixed(1)}%</span>
        </div>
        <div className="w-full bg-gray-800 rounded-full h-2">
          <div
            className="bg-gradient-to-r from-sol-500 to-purple-500 h-2 rounded-full transition-all"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="flex justify-between text-xs text-gray-500">
          <span>{formatSOL(launch.raised)} SOL raised</span>
          <span>{formatSOL(launch.hardCap)} SOL hard cap</span>
        </div>
      </div>

      <div className="space-y-2">
        <label className="text-sm text-gray-400">Amount (SOL)</label>
        <input
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder={`Min ${launch.contributionLimits.minContribution} - Max ${launch.contributionLimits.maxContribution}`}
          className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder:text-gray-600 focus:outline-none focus:border-sol-500 text-sm"
          disabled={!isLive}
        />
        <div className="flex gap-2">
          <button
            onClick={() => setAmount(launch.contributionLimits.minContribution.toString())}
            className="flex-1 bg-gray-800 border border-gray-700 text-gray-400 text-xs py-1.5 rounded hover:border-gray-600 transition-colors"
          >
            Min
          </button>
          <button
            onClick={() => setAmount((launch.contributionLimits.maxContribution / 4).toString())}
            className="flex-1 bg-gray-800 border border-gray-700 text-gray-400 text-xs py-1.5 rounded hover:border-gray-600 transition-colors"
          >
            25%
          </button>
          <button
            onClick={() => setAmount((launch.contributionLimits.maxContribution / 2).toString())}
            className="flex-1 bg-gray-800 border border-gray-700 text-gray-400 text-xs py-1.5 rounded hover:border-gray-600 transition-colors"
          >
            50%
          </button>
          <button
            onClick={() => setAmount(launch.contributionLimits.maxContribution.toString())}
            className="flex-1 bg-gray-800 border border-gray-700 text-gray-400 text-xs py-1.5 rounded hover:border-gray-600 transition-colors"
          >
            Max
          </button>
        </div>
      </div>

      {tokensEstimate > 0 && (
        <div className="bg-gray-800/50 rounded-lg p-3 text-center">
          <p className="text-xs text-gray-500 mb-1">Estimated tokens</p>
          <p className="text-lg text-white font-semibold">
            {formatNumber(tokensEstimate)} {launch.symbol}
          </p>
        </div>
      )}

      <button
        onClick={handleSubmit}
        disabled={!isLive || submitting}
        className={`w-full py-3 rounded-lg text-sm font-semibold transition-all ${
          isLive
            ? 'bg-gradient-to-r from-sol-500 to-purple-600 text-white hover:from-sol-400 hover:to-purple-500 disabled:opacity-50'
            : 'bg-gray-800 text-gray-500 cursor-not-allowed'
        }`}
      >
        {submitting
          ? 'Processing...'
          : !connected
          ? 'Connect Wallet'
          : isUpcoming
          ? 'Launch Not Started'
          : isLive
          ? 'Contribute'
          : 'Launch Ended'}
      </button>

      {launch.antiBot.enabled && (
        <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-3">
          <p className="text-xs text-yellow-400">
            Anti-bot protection active. Max {launch.antiBot.maxTxPerMinute} tx/min,{' '}
            {launch.antiBot.minDelayBetweenTx}s min delay.
            {launch.antiBot.captchaRequired && ' CAPTCHA required.'}
          </p>
        </div>
      )}
    </div>
  );
}
