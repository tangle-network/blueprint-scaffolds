import { Coins, TimerReset } from 'lucide-react'
import { launches, positions } from '../data/launches'
import { formatCompact, formatDateTime, formatPercent } from '../lib/format'
import { SectionTitle } from './SectionTitle'

export function ClaimPortal() {
  const enrichedPositions = positions.map((position) => ({
    ...position,
    launch: launches.find((launch) => launch.id === position.launchId)!,
  }))

  return (
    <section className="panel">
      <SectionTitle
        eyebrow="Claim Portal"
        title="Vesting with cliff and staged unlocks"
        description="Claim unlocked SPL allocations, inspect remaining vesting balances, and monitor future unlock dates."
      />
      <div className="claim-list">
        {enrichedPositions.map((position) => {
          const claimable = position.purchasedTokens * (position.unlockedPercent / 100) - position.claimedTokens

          return (
            <article className="claim-card" key={position.launchId}>
              <div className="claim-card-head">
                <div>
                  <p>{position.launch.name}</p>
                  <h3>{position.launch.symbol}</h3>
                </div>
                <span className="status-pill status-claimable">claimable</span>
              </div>

              <div className="claim-metrics">
                <div>
                  <span>Purchased</span>
                  <strong>{formatCompact(position.purchasedTokens)}</strong>
                </div>
                <div>
                  <span>Already claimed</span>
                  <strong>{formatCompact(position.claimedTokens)}</strong>
                </div>
                <div>
                  <span>Unlocked</span>
                  <strong>{formatPercent(position.unlockedPercent)}</strong>
                </div>
                <div>
                  <span>Claimable now</span>
                  <strong>{formatCompact(Math.max(claimable, 0))}</strong>
                </div>
              </div>

              <div className="claim-footer">
                <span>
                  <TimerReset size={16} />
                  Next unlock {formatDateTime(position.nextUnlockAt)}
                </span>
                <span>
                  <Coins size={16} />
                  Cliff {position.launch.vesting.cliffDays}d, total {position.launch.vesting.durationDays}d
                </span>
              </div>
            </article>
          )
        })}
      </div>
    </section>
  )
}
