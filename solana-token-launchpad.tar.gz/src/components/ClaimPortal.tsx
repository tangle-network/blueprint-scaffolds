import { useState } from 'react';
import { LaunchConfig } from '../types';
import { useWallet } from '../contexts/WalletContext';
import { useNotification } from '../contexts/NotificationContext';
import { formatNumber, formatSOL, formatDate } from '../lib/utils';

interface Props {
  launch: LaunchConfig;
}

export default function ClaimPortal({ launch }: Props) {
  const { connected } = useWallet();
  const { addNotification } = useNotification();
  const [claiming, setClaiming] = useState(false);

  const vesting = launch.vesting;
  const totalAllocated = 12500;
  const totalClaimed = 3125;
  const available = totalAllocated - totalClaimed;
  const cliffEnd = vesting.cliffDuration > 0
    ? new Date(new Date(launch.startDate).getTime() + vesting.cliffDuration * 30 * 86400000)
    : null;
  const isVestingActive = vesting.vestingDuration > 0;
  const canClaim = launch.status === 'claimable' || launch.status === 'ended';

  const handleClaim = async () => {
    if (!connected) {
      addNotification('error', 'Connect your wallet first');
      return;
    }
    setClaiming(true);
    try {
      await new Promise((r) => setTimeout(r, 2000));
      addNotification('success', `Claimed ${formatNumber(available)} ${launch.symbol}!`);
    } catch {
      addNotification('error', 'Claim failed. Please try again.');
    } finally {
      setClaiming(false);
    }
  };

  const vestingEvents = (() => {
    if (!isVestingActive) return [];
    const events = [];
    const start = new Date(launch.startDate).getTime();
    const cliffMs = vesting.cliffDuration * (vesting.cliffUnits === 'months' ? 30 : 1) * 86400000;
    const vestingMs = vesting.vestingDuration * (vesting.vestingUnits === 'months' ? 30 : 1) * 86400000;
    const intervalMs = vesting.vestingInterval * (vesting.vestingUnits === 'months' ? 30 : 1) * 86400000;
    const numSteps = Math.floor(vestingMs / Math.max(intervalMs, 1));
    const perStep = totalAllocated / Math.max(numSteps, 1);
    let cumulative = 0;

    for (let i = 0; i <= numSteps; i++) {
      const ts = start + cliffMs + intervalMs * i;
      cumulative += perStep;
      events.push({
        date: new Date(ts),
        amount: perStep,
        cumulative: Math.min(cumulative, totalAllocated),
        isPast: ts < Date.now(),
      });
    }
    return events.slice(0, 12);
  })();

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 space-y-5">
      <h3 className="text-white font-semibold text-lg">Claim Portal</h3>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-gray-800/50 rounded-lg p-4 text-center">
          <p className="text-xs text-gray-500 mb-1">Total Allocated</p>
          <p className="text-xl text-white font-bold">{formatNumber(totalAllocated)}</p>
          <p className="text-xs text-gray-500">{launch.symbol}</p>
        </div>
        <div className="bg-gray-800/50 rounded-lg p-4 text-center">
          <p className="text-xs text-gray-500 mb-1">Available to Claim</p>
          <p className="text-xl text-green-400 font-bold">{formatNumber(available)}</p>
          <p className="text-xs text-gray-500">{launch.symbol}</p>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-gray-400">Claimed</span>
          <span className="text-white">{formatNumber(totalClaimed)} {launch.symbol}</span>
        </div>
        <div className="w-full bg-gray-800 rounded-full h-2">
          <div
            className="bg-green-500 h-2 rounded-full"
            style={{ width: `${(totalClaimed / totalAllocated) * 100}%` }}
          />
        </div>
      </div>

      {cliffEnd && (
        <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3">
          <p className="text-xs text-blue-400">
            Cliff ends: {formatDate(cliffEnd.toISOString())}
          </p>
        </div>
      )}

      {isVestingActive && vestingEvents.length > 0 && (
        <div className="space-y-3">
          <h4 className="text-sm text-gray-400 font-medium">Vesting Schedule</h4>
          <div className="max-h-48 overflow-y-auto space-y-2 pr-1">
            {vestingEvents.map((ev, i) => (
              <div
                key={i}
                className={`flex items-center justify-between text-xs p-2 rounded ${
                  ev.isPast ? 'bg-gray-800/30' : 'bg-gray-800/70'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      ev.isPast ? 'bg-green-500' : 'bg-gray-600'
                    }`}
                  />
                  <span className="text-gray-400">{formatDate(ev.date.toISOString())}</span>
                </div>
                <span className={ev.isPast ? 'text-green-400' : 'text-gray-500'}>
                  +{formatNumber(ev.amount)} ({formatNumber(ev.cumulative)} total)
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      <button
        onClick={handleClaim}
        disabled={!canClaim || !connected || claiming || available <= 0}
        className={`w-full py-3 rounded-lg text-sm font-semibold transition-all ${
          canClaim && connected && available > 0
            ? 'bg-gradient-to-r from-green-500 to-emerald-600 text-white hover:from-green-400 hover:to-emerald-500 disabled:opacity-50'
            : 'bg-gray-800 text-gray-500 cursor-not-allowed'
        }`}
      >
        {claiming
          ? 'Claiming...'
          : !connected
          ? 'Connect Wallet'
          : !canClaim
          ? 'Not Claimable Yet'
          : available <= 0
          ? 'Nothing to Claim'
          : `Claim ${formatNumber(available)} ${launch.symbol}`}
      </button>
    </div>
  );
}
