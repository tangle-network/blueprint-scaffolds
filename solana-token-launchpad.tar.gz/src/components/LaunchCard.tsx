import { LaunchConfig, LaunchStatus } from '../types';
import { Link } from 'react-router-dom';
import {
  formatSOL,
  formatNumber,
  daysRemaining,
  progressPercent,
  launchTypeLabel,
  launchTypeColor,
  statusColor,
} from '../lib/utils';

interface Props {
  launch: LaunchConfig;
}

export default function LaunchCard({ launch }: Props) {
  const progress = progressPercent(launch.raised, launch.hardCap);

  return (
    <Link
      to={`/launch/${launch.id}`}
      className="block bg-gray-900 border border-gray-800 rounded-xl p-5 hover:border-sol-500/50 transition-all hover:-translate-y-0.5 group"
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-sol-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm">
            {launch.symbol.slice(0, 2)}
          </div>
          <div>
            <h3 className="text-white font-semibold group-hover:text-sol-400 transition-colors">
              {launch.name}
            </h3>
            <p className="text-gray-500 text-xs">${launch.symbol}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-medium px-2 py-0.5 rounded-full border uppercase tracking-wider">
            {launchTypeLabel(launch.launchType)}
          </span>
        </div>
      </div>

      <p className="text-gray-400 text-xs mb-4 line-clamp-2">{launch.description}</p>

      <div className="flex items-center justify-between mb-2">
        <span
          className={`inline-flex items-center gap-1.5 text-xs font-medium`}
        >
          <span className={`w-1.5 h-1.5 rounded-full ${statusColor(launch.status)}`} />
          <span className="text-gray-300 capitalize">{launch.status}</span>
        </span>
        <span className="text-xs text-gray-500">
          {daysRemaining(launch.endDate)}d left
        </span>
      </div>

      <div className="w-full bg-gray-800 rounded-full h-1.5 mb-3">
        <div
          className="bg-gradient-to-r from-sol-500 to-purple-500 h-1.5 rounded-full transition-all"
          style={{ width: `${progress}%` }}
        />
      </div>

      <div className="grid grid-cols-3 gap-2 text-center">
        <div>
          <p className="text-xs text-gray-500">Raised</p>
          <p className="text-sm text-white font-medium">{formatSOL(launch.raised)} SOL</p>
        </div>
        <div>
          <p className="text-xs text-gray-500">Hard Cap</p>
          <p className="text-sm text-white font-medium">{formatSOL(launch.hardCap)} SOL</p>
        </div>
        <div>
          <p className="text-xs text-gray-500">Participants</p>
          <p className="text-sm text-white font-medium">{launch.participants}</p>
        </div>
      </div>

      <div className={`inline-block mt-3 text-[10px] font-medium px-2 py-0.5 rounded-full border ${launchTypeColor(launch.launchType)}`}>
        {launchTypeLabel(launch.launchType)}
      </div>
    </Link>
  );
}
