import { LaunchConfig } from '@/lib/types';
import { launchTypeLabel, statusColor, formatNumber, formatCountdown } from '@/lib/constants';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Clock, Users, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';

interface LaunchCardProps {
  launch: LaunchConfig;
}

export function LaunchCard({ launch }: LaunchCardProps) {
  const progressPct = Math.min(
    (launch.raised / (launch.tokensForSale * launch.pricePerToken)) * 100,
    100
  );

  return (
    <Link to={`/launch/${launch.id}`}>
      <Card className="hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/5 cursor-pointer">
        <CardContent className="p-5">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full solana-gradient flex items-center justify-center text-lg">
                {launch.logoUrl}
              </div>
              <div>
                <h3 className="font-semibold text-foreground">{launch.name}</h3>
                <p className="text-xs text-muted-foreground">{launch.symbol}</p>
              </div>
            </div>
            <Badge className={`${statusColor(launch.status)} border text-xs`}>
              {launch.status.charAt(0).toUpperCase() + launch.status.slice(1)}
            </Badge>
          </div>

          <div className="flex items-center gap-2 mb-3">
            <Badge variant="outline" className="text-xs">
              {launchTypeLabel(launch.launchType)}
            </Badge>
            {launch.autoLpProvision && (
              <Badge variant="secondary" className="text-xs flex items-center gap-1">
                <Zap className="w-3 h-3" /> Auto LP
              </Badge>
            )}
          </div>

          <div className="space-y-2 mb-3">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Progress</span>
              <span className="text-foreground font-medium">{progressPct.toFixed(1)}%</span>
            </div>
            <Progress value={progressPct} className="h-2" />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>{launch.raised.toFixed(2)} SOL raised</span>
              <span>{formatNumber(launch.tokensForSale * launch.pricePerToken)} SOL goal</span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 text-xs">
            <div className="flex items-center gap-1 text-muted-foreground">
              <Clock className="w-3 h-3" />
              <span>{formatCountdown(launch.endTime)}</span>
            </div>
            <div className="flex items-center gap-1 text-muted-foreground">
              <Users className="w-3 h-3" />
              <span>{formatNumber(launch.participants)}</span>
            </div>
            <div className="text-right text-muted-foreground">
              {launch.pricePerToken.toFixed(4)} SOL
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
