import { ReactNode } from 'react';

interface Props {
  title: string;
  children: ReactNode;
  className?: string;
}

export default function StatsCard({ title, children, className = '' }: Props) {
  return (
    <div className={`bg-gray-900 border border-gray-800 rounded-xl p-5 ${className}`}>
      <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">{title}</p>
      <div className="text-white">{children}</div>
    </div>
  );
}
