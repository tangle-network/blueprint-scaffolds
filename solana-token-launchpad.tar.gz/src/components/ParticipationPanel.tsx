import { useMemo, useState } from 'react'
import { Gauge, LockKeyhole, Wallet } from 'lucide-react'
import type { Launch } from '../types'
import { formatCompact, formatDateTime, formatPercent, formatUsd } from '../lib/format'
import { computeParticipationPreview, deriveMintAddress, safeShortAddress } from '../lib/solana'
import { SectionTitle } from './SectionTitle'

type ParticipationPanelProps = {
  launch: Launch
}

export function ParticipationPanel({ launch }: ParticipationPanelProps) {
  const [contribution, setContribution] = useState(12)
  const [walletCommitted] = useState(26)
  const [isWhitelisted] = useState(launch.whitelistEnabled ? launch.id === 'atlas' : true)

  const preview = useMemo(
    () => computeParticipationPreview(launch, contribution, walletCommitted, isWhitelisted),
    [contribution, isWhitelisted, launch, walletCommitted],
  )

  return (
    <section className="panel">
      <SectionTitle
        eyebrow="Participation"
        title={`${launch.name} sale controls`}
        description="Configure contribution size, inspect price discovery, and review anti-bot restrictions before signing."
      />
      <div className="detail-grid">
        <div className="detail-card">
          <div className="detail-card-head">
            <Gauge size={18} />
            <h3>Sale mechanics</h3>
          </div>
          <dl className="metric-list">
            <div>
              <dt>Launch type</dt>
              <dd>{launch.type.replace('-', ' ')}</dd>
            </div>
            <div>
              <dt>Base price</dt>
              <dd>{formatUsd(launch.basePrice)}</dd>
            </div>
            <div>
              <dt>Estimated clearing price</dt>
              <dd>{formatUsd(preview.clearingPrice)}</dd>
            </div>
            <div>
              <dt>Sale allocation</dt>
              <dd>{formatPercent(launch.saleAllocationPercent)}</dd>
            </div>
            <div>
              <dt>Mint PDA preview</dt>
              <dd>{safeShortAddress(deriveMintAddress(launch.id).toBase58())}</dd>
            </div>
            <div>
              <dt>Settlement</dt>
              <dd>{formatDateTime(launch.settlementAt)}</dd>
            </div>
          </dl>
        </div>

        <div className="detail-card">
          <div className="detail-card-head">
            <Wallet size={18} />
            <h3>Commit capital</h3>
          </div>
          <label className="input-wrap">
            <span>Contribution amount ({launch.raiseAsset})</span>
            <input
              min={launch.contributionPolicy.minSol}
              max={launch.contributionPolicy.maxSol}
              step="0.25"
              type="number"
              value={contribution}
              onChange={(event) => setContribution(Number(event.target.value))}
            />
          </label>

          <div className="preview-grid">
            <div>
              <span>Token output</span>
              <strong>{formatCompact(preview.estimatedTokenOutput)}</strong>
            </div>
            <div>
              <span>Wallet committed</span>
              <strong>{walletCommitted} {launch.raiseAsset}</strong>
            </div>
            <div>
              <span>LP reserve</span>
              <strong>{formatCompact(preview.liquidityReserved)} tokens</strong>
            </div>
            <div>
              <span>Claim opens</span>
              <strong>{formatDateTime(launch.claimOpensAt)}</strong>
            </div>
          </div>

          <div className="notice-stack">
            {preview.walletCapReached ? (
              <p className="notice danger">Wallet cap exceeded. Reduce the order size before submission.</p>
            ) : (
              <p className="notice success">Contribution fits inside the per-wallet fair launch cap.</p>
            )}
            {preview.requiresWhitelist ? (
              <p className="notice warning">This round needs an allowlist proof before order placement.</p>
            ) : (
              <p className="notice neutral">Whitelist proof not required for the connected wallet.</p>
            )}
          </div>

          <button
            className="primary-button wide"
            disabled={preview.walletCapReached || preview.requiresWhitelist}
            type="button"
          >
            Simulate signed participation
          </button>
        </div>

        <div className="detail-card">
          <div className="detail-card-head">
            <LockKeyhole size={18} />
            <h3>Fairness rules</h3>
          </div>
          <dl className="metric-list">
            <div>
              <dt>Min contribution</dt>
              <dd>{launch.contributionPolicy.minSol} {launch.raiseAsset}</dd>
            </div>
            <div>
              <dt>Max contribution</dt>
              <dd>{launch.contributionPolicy.maxSol} {launch.raiseAsset}</dd>
            </div>
            <div>
              <dt>Per-wallet cap</dt>
              <dd>{launch.contributionPolicy.perWalletCap} {launch.raiseAsset}</dd>
            </div>
            <div>
              <dt>Auto LP lock</dt>
              <dd>{launch.liquidityPlan.lockDays} days on {launch.liquidityPlan.dex}</dd>
            </div>
          </dl>
          <ul className="rule-list">
            {launch.antiBotRules.map((rule) => (
              <li key={rule.id}>
                <strong>{rule.label}</strong>
                <p>{rule.description}</p>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}
