import type { Launch } from '../types'
import { formatCompact, formatPercent, formatUsd } from '../lib/format'
import { SectionTitle } from './SectionTitle'

type LaunchOpsPanelProps = {
  launch: Launch
}

export function LaunchOpsPanel({ launch }: LaunchOpsPanelProps) {
  const saleAllocation = launch.tokenSupply * (launch.saleAllocationPercent / 100)
  const lpTokens = saleAllocation * (launch.liquidityPlan.lpPercent / 100)

  return (
    <section className="panel ops-panel">
      <SectionTitle
        eyebrow="Operator View"
        title="Treasury, vesting, and LP automation"
        description="A compact operating summary for project teams preparing sale settlement and post-launch liquidity."
      />
      <div className="ops-grid">
        <article className="ops-card">
          <span>Sale allocation</span>
          <strong>{formatCompact(saleAllocation)} tokens</strong>
          <p>{formatPercent(launch.saleAllocationPercent)} of total supply exposed to the launch.</p>
        </article>
        <article className="ops-card">
          <span>Target raise</span>
          <strong>{formatUsd(launch.targetRaise)}</strong>
          <p>Contributions settle into the treasury at {launch.treasury.slice(0, 12)}...</p>
        </article>
        <article className="ops-card">
          <span>LP bootstrap</span>
          <strong>{formatCompact(lpTokens)} tokens</strong>
          <p>{launch.liquidityPlan.lpPercent}% paired on {launch.liquidityPlan.dex} and locked for {launch.liquidityPlan.lockDays} days.</p>
        </article>
        <article className="ops-card">
          <span>Vesting</span>
          <strong>{formatPercent(launch.vesting.tgeUnlockPercent)}</strong>
          <p>TGE unlock after settlement, then {launch.vesting.durationDays} day linear release after a {launch.vesting.cliffDays} day cliff.</p>
        </article>
      </div>
    </section>
  )
}
