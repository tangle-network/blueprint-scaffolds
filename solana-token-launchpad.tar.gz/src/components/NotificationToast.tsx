import { useNotification } from '../contexts/NotificationContext';

export default function NotificationToast() {
  const { notifications, removeNotification } = useNotification();

  if (notifications.length === 0) return null;

  const colorMap = {
    success: 'border-green-500 bg-green-500/10 text-green-400',
    error: 'border-red-500 bg-red-500/10 text-red-400',
    info: 'border-blue-500 bg-blue-500/10 text-blue-400',
    warning: 'border-yellow-500 bg-yellow-500/10 text-yellow-400',
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 space-y-2 max-w-sm">
      {notifications.map((n) => (
        <div
          key={n.id}
          className={`border rounded-lg p-4 backdrop-blur-sm animate-in slide-in-from-right ${colorMap[n.type]}`}
          onClick={() => removeNotification(n.id)}
        >
          <div className="flex items-start justify-between gap-2">
            <p className="text-sm">{n.message}</p>
            <button className="text-xs opacity-50 hover:opacity-100 shrink-0">&times;</button>
          </div>
        </div>
      ))}
    </div>
  );
}
