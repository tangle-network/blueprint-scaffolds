import { useWallet } from '@/context/WalletContext';
import { shortenAddress } from '@/lib/constants';
import { Button } from '@/components/ui/button';
import { Wallet, LogOut } from 'lucide-react';

export function ConnectButton() {
  const { connected, publicKey, connect, disconnect } = useWallet();

  if (connected && publicKey) {
    return (
      <div className="flex items-center gap-2">
        <span className="text-sm text-muted-foreground hidden sm:inline">
          {shortenAddress(publicKey)}
        </span>
        <Button variant="outline" size="sm" onClick={disconnect}>
          <LogOut className="w-4 h-4 mr-1" />
          Disconnect
        </Button>
      </div>
    );
  }

  return (
    <Button onClick={connect} size="sm">
      <Wallet className="w-4 h-4 mr-1" />
      Connect Wallet
    </Button>
  );
}
