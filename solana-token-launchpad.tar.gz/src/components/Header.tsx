import { ShieldCheck, Waves } from 'lucide-react'

export function Header() {
  return (
    <header className="hero">
      <nav className="topbar">
        <div className="brand">
          <div className="brand-mark">
            <Waves size={18} />
          </div>
          <div>
            <strong>FairMint</strong>
            <p>Solana launch infrastructure</p>
          </div>
        </div>
        <div className="topbar-actions">
          <span className="chip">Mainnet-beta ready</span>
          <button className="ghost-button" type="button">
            Connect wallet
          </button>
        </div>
      </nav>

      <div className="hero-grid">
        <div>
          <p className="eyebrow">Fair launches without private backdoors</p>
          <h1>Token deployment, sale orchestration, vesting, and LP locking in one Solana launchpad.</h1>
          <p className="hero-copy">
            Run fixed-price rounds, Dutch auctions, bonding curves, and whitelist windows with
            wallet caps, anti-bot checks, auto-liquidity, and post-sale claims.
          </p>
          <div className="hero-actions">
            <button className="primary-button" type="button">
              Create launch
            </button>
            <button className="secondary-button" type="button">
              Review docs
            </button>
          </div>
        </div>
        <div className="hero-card">
          <div className="hero-card-row">
            <span>FairMint program</span>
            <strong>Audited release candidate</strong>
          </div>
          <div className="hero-card-row">
            <span>SPL token deployment</span>
            <strong>One-click mint, treasury, and metadata setup</strong>
          </div>
          <div className="hero-card-row">
            <span>Risk controls</span>
            <strong>Commit-reveal, Merkle whitelist, slot throttles, wallet limits</strong>
          </div>
          <div className="hero-card-foot">
            <ShieldCheck size={18} />
            <p>Auto LP provision routes a configurable share of raised assets into locked Raydium, Orca, or Meteora liquidity.</p>
          </div>
        </div>
      </div>
    </header>
  )
}
