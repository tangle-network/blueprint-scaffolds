import { Link } from 'react-router-dom';
import { useWallet } from '../contexts/WalletContext';
import { truncateAddress } from '../lib/utils';

export default function Header() {
  const { connected, publicKey, balance, connect, disconnect } = useWallet();

  return (
    <header className="border-b border-gray-800 bg-gray-950/80 backdrop-blur-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-8">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-sol-400 to-purple-600 flex items-center justify-center text-white font-bold text-sm">
                S
              </div>
              <span className="text-white font-bold text-lg hidden sm:inline">SolLaunch</span>
            </Link>
            <nav className="hidden md:flex items-center gap-6">
              <Link to="/" className="text-gray-400 hover:text-white text-sm transition-colors">
                Calendar
              </Link>
              <Link to="/launches" className="text-gray-400 hover:text-white text-sm transition-colors">
                All Launches
              </Link>
              <Link to="/claims" className="text-gray-400 hover:text-white text-sm transition-colors">
                Claims
              </Link>
            </nav>
          </div>

          <div className="flex items-center gap-4">
            {connected ? (
              <div className="flex items-center gap-3">
                <span className="text-xs text-gray-400 hidden sm:inline">
                  {balance.toFixed(3)} SOL
                </span>
                <div className="flex items-center gap-2 bg-gray-800 rounded-lg px-3 py-1.5">
                  <div className="w-2 h-2 rounded-full bg-green-500" />
                  <span className="text-sm text-white">
                    {publicKey ? truncateAddress(publicKey.toString()) : ''}
                  </span>
                </div>
                <button
                  onClick={disconnect}
                  className="text-xs text-gray-400 hover:text-red-400 transition-colors"
                >
                  Disconnect
                </button>
              </div>
            ) : (
              <button
                onClick={connect}
                className="bg-gradient-to-r from-sol-500 to-purple-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:from-sol-400 hover:to-purple-500 transition-all"
              >
                Connect Wallet
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
