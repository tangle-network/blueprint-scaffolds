import { LaunchConfig } from '../types';
import { launchTypeLabel, launchTypeColor, formatNumber, formatDate } from '../lib/utils';

interface Props {
  launch: LaunchConfig;
}

export default function LaunchDetails({ launch }: Props) {
  return (
    <div className="space-y-6">
      <div className="flex items-start gap-4">
        <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-sol-500 to-purple-600 flex items-center justify-center text-white font-bold text-xl shrink-0">
          {launch.symbol.slice(0, 2)}
        </div>
        <div className="flex-1">
          <h1 className="text-2xl font-bold text-white">{launch.name}</h1>
          <p className="text-gray-500">${launch.symbol}</p>
          <p className="text-gray-400 text-sm mt-2">{launch.description}</p>
        </div>
        <span
          className={`text-xs font-medium px-2.5 py-1 rounded-full border ${launchTypeColor(
            launch.launchType,
          )}`}
        >
          {launchTypeLabel(launch.launchType)}
        </span>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-4">
          <p className="text-xs text-gray-500">Total Supply</p>
          <p className="text-white font-semibold">{formatNumber(launch.totalSupply)}</p>
        </div>
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-4">
          <p className="text-xs text-gray-500">Tokens for Sale</p>
          <p className="text-white font-semibold">{formatNumber(launch.tokensForSale)}</p>
        </div>
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-4">
          <p className="text-xs text-gray-500">Start Date</p>
          <p className="text-white font-semibold text-sm">{formatDate(launch.startDate)}</p>
        </div>
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-4">
          <p className="text-xs text-gray-500">End Date</p>
          <p className="text-white font-semibold text-sm">{formatDate(launch.endDate)}</p>
        </div>
      </div>

      {launch.dutchAuctionConfig && (
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-5">
          <h3 className="text-white font-semibold mb-3">Dutch Auction Parameters</h3>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-xs text-gray-500">Start Price</p>
              <p className="text-white">{launch.dutchAuctionConfig.startPrice} SOL</p>
            </div>
            <div>
              <p className="text-xs text-gray-500">End Price</p>
              <p className="text-white">{launch.dutchAuctionConfig.endPrice} SOL</p>
            </div>
            <div>
              <p className="text-xs text-gray-500">Decrease Interval</p>
              <p className="text-white">{launch.dutchAuctionConfig.priceDecreaseInterval}h</p>
            </div>
          </div>
        </div>
      )}

      {launch.bondingCurveConfig && (
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-5">
          <h3 className="text-white font-semibold mb-3">Bonding Curve Parameters</h3>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-xs text-gray-500">Initial Price</p>
              <p className="text-white">{launch.bondingCurveConfig.initialPrice} SOL</p>
            </div>
            <div>
              <p className="text-xs text-gray-500">Slope</p>
              <p className="text-white">{launch.bondingCurveConfig.slope}</p>
            </div>
            <div>
              <p className="text-xs text-gray-500">Max Supply</p>
              <p className="text-white">{formatNumber(launch.bondingCurveConfig.maxSupply)}</p>
            </div>
          </div>
        </div>
      )}

      {launch.whitelistConfig && (
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-5">
          <h3 className="text-white font-semibold mb-3">Whitelist Round</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-xs text-gray-500">Max Spots</p>
              <p className="text-white">{launch.whitelistConfig.maxWhitelistSpots}</p>
            </div>
            <div>
              <p className="text-xs text-gray-500">Whitelist Price</p>
              <p className="text-white">{launch.whitelistConfig.whitelistPrice} SOL</p>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-5">
          <h3 className="text-white font-semibold mb-3">Vesting</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-400">Cliff</span>
              <span className="text-white">
                {launch.vesting.cliffDuration} {launch.vesting.cliffUnits}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Duration</span>
              <span className="text-white">
                {launch.vesting.vestingDuration} {launch.vesting.vestingUnits}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Interval</span>
              <span className="text-white">
                Every {launch.vesting.vestingInterval} {launch.vesting.vestingUnits}
              </span>
            </div>
          </div>
        </div>

        <div className="bg-gray-900 border border-gray-800 rounded-lg p-5">
          <h3 className="text-white font-semibold mb-3">Contribution Limits</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-400">Minimum</span>
              <span className="text-white">{launch.contributionLimits.minContribution} SOL</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Maximum</span>
              <span className="text-white">{launch.contributionLimits.maxContribution} SOL</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Per Wallet Max</span>
              <span className="text-white">{launch.contributionLimits.maxPerWallet} SOL</span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gray-900 border border-gray-800 rounded-lg p-5">
        <h3 className="text-white font-semibold mb-3">Liquidity & Security</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <div>
            <p className="text-xs text-gray-500">Auto LP</p>
            <p className={launch.autoLpProvision ? 'text-green-400' : 'text-red-400'}>
              {launch.autoLpProvision ? 'Enabled' : 'Disabled'}
            </p>
          </div>
          <div>
            <p className="text-xs text-gray-500">LP Lock</p>
            <p className="text-white">{launch.lpLockDuration} days</p>
          </div>
          <div>
            <p className="text-xs text-gray-500">Anti-Bot</p>
            <p className={launch.antiBot.enabled ? 'text-green-400' : 'text-red-400'}>
              {launch.antiBot.enabled ? 'Active' : 'Inactive'}
            </p>
          </div>
          <div>
            <p className="text-xs text-gray-500">Captcha</p>
            <p className={launch.antiBot.captchaRequired ? 'text-green-400' : 'text-gray-500'}>
              {launch.antiBot.captchaRequired ? 'Required' : 'Not Required'}
            </p>
          </div>
        </div>
      </div>

      <div className="flex gap-4">
        {launch.website && (
          <a
            href={launch.website}
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm text-sol-400 hover:text-sol-300 transition-colors"
          >
            Website &rarr;
          </a>
        )}
        {launch.twitter && (
          <a
            href={`https://twitter.com/${launch.twitter.replace('@', '')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm text-sol-400 hover:text-sol-300 transition-colors"
          >
            Twitter &rarr;
          </a>
        )}
      </div>
    </div>
  );
}
