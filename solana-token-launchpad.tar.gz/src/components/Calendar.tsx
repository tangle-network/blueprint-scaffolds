import clsx from 'clsx'
import { CalendarRange } from 'lucide-react'
import { launches } from '../data/launches'
import { formatCompact, formatCountdown, formatDateTime } from '../lib/format'
import { SectionTitle } from './SectionTitle'

type CalendarProps = {
  selectedId: string
  onSelect: (id: string) => void
}

export function Calendar({ selectedId, onSelect }: CalendarProps) {
  return (
    <section className="panel">
      <SectionTitle
        eyebrow="Launch Calendar"
        title="Upcoming and active rounds"
        description="Track all launch windows, settlement checkpoints, and claim openings from a single timeline."
      />
      <div className="calendar-list">
        {launches.map((launch) => (
          <button
            key={launch.id}
            className={clsx('launch-card', selectedId === launch.id && 'selected')}
            onClick={() => onSelect(launch.id)}
            type="button"
          >
            <div className="launch-card-top">
              <div>
                <p className="launch-type">{launch.type.replace('-', ' ')}</p>
                <h3>
                  {launch.name} <span>{launch.symbol}</span>
                </h3>
              </div>
              <span className={`status-pill status-${launch.status}`}>{launch.status}</span>
            </div>
            <p className="launch-description">{launch.description}</p>
            <div className="launch-stats">
              <div>
                <span>Raise</span>
                <strong>${formatCompact(launch.targetRaise)}</strong>
              </div>
              <div>
                <span>Participants</span>
                <strong>{formatCompact(launch.participants)}</strong>
              </div>
              <div>
                <span>Starts</span>
                <strong>{formatDateTime(launch.startsAt)}</strong>
              </div>
            </div>
            <div className="launch-card-foot">
              <span>
                <CalendarRange size={16} />
                {formatCountdown(launch.endsAt)}
              </span>
              <span>{launch.raiseAsset} raise</span>
            </div>
          </button>
        ))}
      </div>
    </section>
  )
}
