import { Factory, Shield, Sparkles, Users } from 'lucide-react'
import { SectionTitle } from './SectionTitle'

const features = [
  {
    icon: Factory,
    title: 'SPL token deployment',
    text: 'Provision mint authority, freeze rules, treasury routing, and launch configuration from one issuance flow.',
  },
  {
    icon: Users,
    title: 'Whitelist rounds',
    text: 'Run Merkle-gated community rounds before public launch windows and cap tickets by wallet.',
  },
  {
    icon: Shield,
    title: 'Anti-bot measures',
    text: 'Combine commit-reveal, slot throttles, wallet entropy checks, and dynamic cooldowns for fair order flow.',
  },
  {
    icon: Sparkles,
    title: 'Auto LP and lock',
    text: 'Route a share of raises into immediate liquidity and lock LP positions for a configurable vesting horizon.',
  },
]

export function FeatureGrid() {
  return (
    <section className="panel">
      <SectionTitle
        eyebrow="Launch Stack"
        title="Everything required for fair Solana token distribution"
        description="The product surface is organized around launch operators, contributors, and post-sale claims."
      />
      <div className="feature-grid">
        {features.map((feature) => {
          const Icon = feature.icon
          return (
            <article className="feature-card" key={feature.title}>
              <div className="feature-icon">
                <Icon size={18} />
              </div>
              <h3>{feature.title}</h3>
              <p>{feature.text}</p>
            </article>
          )
        })}
      </div>
    </section>
  )
}
