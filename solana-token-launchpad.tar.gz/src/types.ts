export type LaunchType = 'fixed-price' | 'dutch-auction' | 'bonding-curve' | 'whitelist'

export type PhaseStatus = 'upcoming' | 'live' | 'settlement' | 'claimable'

export type VestingSchedule = {
  cliffDays: number
  durationDays: number
  tgeUnlockPercent: number
}

export type ContributionPolicy = {
  minSol: number
  maxSol: number
  perWalletCap: number
  maxTicketsPerWallet?: number
  geographicRestriction?: string
}

export type AntiBotRule = {
  id: string
  label: string
  description: string
}

export type LiquidityPlan = {
  dex: string
  lpPercent: number
  lockDays: number
  quoteAsset: 'SOL' | 'USDC'
}

export type Launch = {
  id: string
  name: string
  symbol: string
  description: string
  type: LaunchType
  status: PhaseStatus
  startsAt: string
  endsAt: string
  settlementAt: string
  tokenSupply: number
  saleAllocationPercent: number
  treasury: string
  whitelistEnabled: boolean
  auditState: 'draft' | 'reviewed' | 'audited'
  raiseAsset: 'SOL' | 'USDC'
  basePrice: number
  priceFloor?: number
  priceCeiling?: number
  curveFactor?: number
  targetRaise: number
  contributed: number
  participants: number
  contributionPolicy: ContributionPolicy
  antiBotRules: AntiBotRule[]
  liquidityPlan: LiquidityPlan
  vesting: VestingSchedule
  cliffUnlockDate: string
  claimOpensAt: string
}

export type ParticipationPreview = {
  estimatedTokenOutput: number
  clearingPrice: number
  walletCapReached: boolean
  requiresWhitelist: boolean
  liquidityReserved: number
}

export type VestingPosition = {
  launchId: string
  wallet: string
  purchasedTokens: number
  claimedTokens: number
  nextUnlockAt: string
  unlockedPercent: number
}
