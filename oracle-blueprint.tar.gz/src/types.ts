export interface PriceReport {
  pair: string;
  price: number;
  timestamp: number;
  sources: DataSourceResult[];
  weightedMedian: number;
  confidence: number;
  signature: string;
}

export interface DataSourceResult {
  source: string;
  type: 'cex' | 'dex';
  price: number;
  volume: number;
  timestamp: number;
  weight: number;
  latency: number;
}

export interface Operator {
  id: string;
  address: string;
  stake: number;
  reputation: number;
  isActive: boolean;
  lastHeartbeat: number;
  totalSubmissions: number;
  successfulSubmissions: number;
  slashCount: number;
}

export interface PriceFeed {
  pair: string;
  currentPrice: number;
  previousPrice: number;
  change24h: number;
  lastUpdate: number;
  sources: string[];
  isPaused: boolean;
  history: PricePoint[];
}

export interface PricePoint {
  timestamp: number;
  price: number;
  volume: number;
}

export interface DataSourceHealth {
  name: string;
  type: 'cex' | 'dex';
  status: 'healthy' | 'degraded' | 'down';
  latency: number;
  lastFetch: number;
  errorRate: number;
  uptime: number;
}

export interface CrossChainDeployment {
  chain: string;
  chainId: number;
  feedAddress: string;
  lastUpdate: number;
  blockNumber: number;
  synced: boolean;
}

export interface AggregationConfig {
  pair: string;
  updateInterval: number;
  deviationThreshold: number;
  heartbeatInterval: number;
  minSources: number;
  circuitBreakerThreshold: number;
}

export const SUPPORTED_PAIRS = [
  'BTC/USD', 'ETH/USD', 'POL/USD', 'ARB/USD',
  'SOL/USD', 'AVAX/USD', 'DOT/USD', 'LINK/USD',
];

export const SUPPORTED_CHAINS: CrossChainDeployment[] = [
  { chain: 'Ethereum', chainId: 1, feedAddress: '0x0000000000000000000000000000000000000001', lastUpdate: 0, blockNumber: 0, synced: false },
  { chain: 'Polygon', chainId: 137, feedAddress: '0x0000000000000000000000000000000000000002', lastUpdate: 0, blockNumber: 0, synced: false },
  { chain: 'Arbitrum', chainId: 42161, feedAddress: '0x0000000000000000000000000000000000000003', lastUpdate: 0, blockNumber: 0, synced: false },
];

export const DEFAULT_AGGREGATION_CONFIG: AggregationConfig = {
  pair: 'BTC/USD',
  updateInterval: 60,
  deviationThreshold: 0.5,
  heartbeatInterval: 3600,
  minSources: 3,
  circuitBreakerThreshold: 10,
};
