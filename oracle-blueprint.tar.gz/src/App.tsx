import { Routes, Route, NavLink } from 'react-router-dom'
import { Activity, Users, Heart, BookOpen, Shield } from 'lucide-react'
import Dashboard from './pages/Dashboard'
import Operators from './pages/Operators'
import HealthMonitor from './pages/HealthMonitor'
import IntegrationGuide from './pages/IntegrationGuide'

const navItems = [
  { to: '/', label: 'Dashboard', icon: Activity },
  { to: '/operators', label: 'Operators', icon: Users },
  { to: '/health', label: 'Health', icon: Heart },
  { to: '/guide', label: 'Integration', icon: BookOpen },
]

export default function App() {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto flex h-16 items-center px-4">
          <div className="flex items-center gap-2 font-bold text-xl mr-8">
            <Shield className="h-6 w-6 text-primary" />
            <span>Tangle Oracle</span>
          </div>
          <nav className="flex items-center gap-1">
            {navItems.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                className={({ isActive }) =>
                  `flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground'
                  }`
                }
              >
                <Icon className="h-4 w-4" />
                {label}
              </NavLink>
            ))}
          </nav>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/operators" element={<Operators />} />
          <Route path="/health" element={<HealthMonitor />} />
          <Route path="/guide" element={<IntegrationGuide />} />
        </Routes>
      </main>
    </div>
  )
}
