import { useState, useEffect, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { TrendingUp, TrendingDown, Activity, Clock, Layers, Shield } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts'
import type { AggregatedPrice, ChainFeed, SupportedPair } from '@/oracle/types'
import { SUPPORTED_PAIRS } from '@/oracle/types'
import { fetchAllSources } from '@/oracle/sources/fetchers'
import { aggregatePrices, checkCircuitBreaker } from '@/oracle/aggregation'
import { generateThresholdSignature } from '@/oracle/security'
import { getChainFeeds, verifyCrossChainConsistency } from '@/oracle/crosschain'

interface HistoricalPoint {
  time: string
  price: number
  confidence: number
}

function generateHistory(basePrice: number): HistoricalPoint[] {
  const points: HistoricalPoint[] = []
  const now = Date.now()
  for (let i = 24; i >= 0; i--) {
    const variation = basePrice * (1 + (Math.random() - 0.5) * 0.04)
    points.push({
      time: new Date(now - i * 5 * 60 * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      price: variation,
      confidence: 0.85 + Math.random() * 0.15,
    })
  }
  return points
}

function PriceCard({ pair, price, prevPrice, deviation, sources, confidence }: {
  pair: string
  price: number
  prevPrice: number
  deviation: number
  sources: number
  confidence: number
}) {
  const change = prevPrice > 0 ? ((price - prevPrice) / prevPrice) * 100 : 0
  const isUp = change >= 0

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base font-semibold">{pair}</CardTitle>
          <Badge variant={deviation < 1 ? 'default' : deviation < 3 ? 'secondary' : 'destructive'}>
            {deviation.toFixed(2)}% dev
          </Badge>
        </div>
        <CardDescription>
          {sources} source{sources !== 1 ? 's' : ''} aggregated
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-end justify-between">
          <div>
            <div className="text-2xl font-bold">
              ${price < 1 ? price.toFixed(4) : price < 100 ? price.toFixed(2) : price.toLocaleString(undefined, { maximumFractionDigits: 2 })}
            </div>
            <div className={`flex items-center text-sm ${isUp ? 'text-green-600' : 'text-red-600'}`}>
              {isUp ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
              {isUp ? '+' : ''}{change.toFixed(3)}%
            </div>
          </div>
          <div className="text-right text-xs text-muted-foreground">
            <div>Confidence: {(confidence * 100).toFixed(1)}%</div>
            <div className="mt-1 flex items-center gap-1">
              <Shield className="h-3 w-3" />
              Threshold signed
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default function Dashboard() {
  const [selectedPair, setSelectedPair] = useState<SupportedPair>('BTC/USD')
  const [prices, setPrices] = useState<Map<string, AggregatedPrice>>(new Map())
  const [history, setHistory] = useState<Map<string, HistoricalPoint[]>>(new Map())
  const [chainFeeds, setChainFeeds] = useState<ChainFeed[]>([])
  const [lastUpdate, setLastUpdate] = useState<number>(Date.now())

  const updatePrices = useCallback(() => {
    const newPrices = new Map<string, AggregatedPrice>()
    const newHistory = new Map<string, HistoricalPoint[]>()

    for (const pair of SUPPORTED_PAIRS) {
      const sources = fetchAllSources(pair)
      const agg = aggregatePrices(pair, sources)
      const prevPrice = prices.get(pair)?.price ?? agg.price
      const cb = checkCircuitBreaker(prevPrice, agg.price, pair)
      const sig = generateThresholdSignature(
        Array.from({ length: 7 }, (_, i) => ({
          id: `op-${i + 1}`,
          address: `0x${i.toString(16).padStart(40, 'a')}`,
          stake: 10000 + i * 5000,
          reputation: 90 + i,
          status: i < 5 ? 'active' as const : 'inactive' as const,
          lastHeartbeat: Date.now() - i * 5000,
          totalSubmissions: 1000 + i * 100,
          validSubmissions: 990 + i * 100,
        })),
      )

      const newPrice: AggregatedPrice = {
        pair,
        price: cb.paused ? prevPrice : agg.price,
        timestamp: Date.now(),
        sources: agg.sources,
        confidence: agg.confidence,
        deviation: agg.deviation,
        signature: sig.signature,
      }
      newPrices.set(pair, newPrice)

      const existing = history.get(pair) ?? generateHistory(agg.price)
      newHistory.set(pair, [
        ...existing.slice(-23),
        {
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          price: newPrice.price,
          confidence: newPrice.confidence,
        },
      ])
    }

    setPrices(newPrices)
    setHistory(newHistory)

    const selectedPrice = newPrices.get(selectedPair)?.price ?? 0
    setChainFeeds(getChainFeeds(selectedPair, selectedPrice))
    setLastUpdate(Date.now())
  }, [selectedPair, prices, history])

  useEffect(() => {
    updatePrices()
    const interval = setInterval(updatePrices, 5000)
    return () => clearInterval(interval)
  }, [updatePrices])

  const selectedPrice = prices.get(selectedPair)
  const selectedHistory = history.get(selectedPair) ?? []
  const consistency = chainFeeds.length > 0 ? verifyCrossChainConsistency(chainFeeds) : { consistent: true, maxDeviation: 0, details: [] }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Oracle Dashboard</h1>
          <p className="text-muted-foreground mt-1">Live aggregated price feeds from multiple sources</p>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Activity className="h-4 w-4 text-green-500 animate-pulse" />
          <span>Updated {Math.floor((Date.now() - lastUpdate) / 1000)}s ago</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        {SUPPORTED_PAIRS.map((pair) => {
          const p = prices.get(pair)
          if (!p) return null
          return (
            <div key={pair} onClick={() => setSelectedPair(pair)} className="cursor-pointer">
              <PriceCard
                pair={pair}
                price={p.price}
                prevPrice={selectedPrice?.price ?? 0}
                deviation={p.deviation}
                sources={p.sources}
                confidence={p.confidence}
              />
            </div>
          )
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              {selectedPair} Price History
            </CardTitle>
            <CardDescription>2-hour rolling window with confidence interval</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={selectedHistory}>
                  <defs>
                    <linearGradient id="priceGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(221.2, 83.2%, 53.3%)" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="hsl(221.2, 83.2%, 53.3%)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                  <XAxis dataKey="time" tick={{ fontSize: 11 }} interval={3} />
                  <YAxis tick={{ fontSize: 11 }} domain={['auto', 'auto']} />
                  <Tooltip
                    contentStyle={{ borderRadius: '8px', border: '1px solid hsl(var(--border))' }}
                    formatter={(value: number) => [`$${value.toFixed(2)}`, 'Price']}
                  />
                  <Area
                    type="monotone"
                    dataKey="price"
                    stroke="hsl(221.2, 83.2%, 53.3%)"
                    fill="url(#priceGradient)"
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Layers className="h-5 w-5" />
              Cross-Chain Feeds
            </CardTitle>
            <CardDescription>
              <Badge variant={consistency.consistent ? 'default' : 'destructive'} className="text-xs">
                {consistency.consistent ? 'Consistent' : 'Inconsistent'}
              </Badge>
              <span className="ml-2">Max dev: {consistency.maxDeviation.toFixed(3)}%</span>
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Chain</TableHead>
                  <TableHead className="text-right">Price</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {chainFeeds.map((feed) => (
                  <TableRow key={feed.chainId}>
                    <TableCell className="font-medium">{feed.chain}</TableCell>
                    <TableCell className="text-right">
                      ${feed.lastPrice < 1 ? feed.lastPrice.toFixed(4) : feed.lastPrice.toFixed(2)}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={feed.status === 'synced' ? 'default' : feed.status === 'delayed' ? 'secondary' : 'destructive'}
                        className="text-xs"
                      >
                        {feed.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Active Pairs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{SUPPORTED_PAIRS.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Sources</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8</div>
            <p className="text-xs text-muted-foreground">3 CEX + 5 DEX</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-1">
              <Clock className="h-3 w-3" /> Update Interval
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">5s</div>
            <p className="text-xs text-muted-foreground">Auto-refresh active</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
