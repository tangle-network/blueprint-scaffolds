import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Users, Shield, AlertTriangle, CheckCircle, XCircle, Clock, Zap } from 'lucide-react'
import type { Operator } from '@/oracle/types'
import { generateMockOperators, validateSubmission, checkHeartbeat, generateThresholdSignature } from '@/oracle/security'

function StatusBadge({ status }: { status: Operator['status'] }) {
  switch (status) {
    case 'active':
      return <Badge variant="default" className="gap-1"><CheckCircle className="h-3 w-3" />Active</Badge>
    case 'inactive':
      return <Badge variant="secondary" className="gap-1"><Clock className="h-3 w-3" />Inactive</Badge>
    case 'slashed':
      return <Badge variant="destructive" className="gap-1"><XCircle className="h-3 w-3" />Slashed</Badge>
  }
}

function OperatorRow({ operator, consensusPrice }: { operator: Operator; consensusPrice: number }) {
  const alive = checkHeartbeat(operator)
  const validityRate = operator.totalSubmissions > 0
    ? (operator.validSubmissions / operator.totalSubmissions) * 100
    : 0
  const testPrice = consensusPrice * (1 + (Math.random() - 0.5) * 0.06)
  const validation = validateSubmission(operator, testPrice, consensusPrice)

  return (
    <TableRow>
      <TableCell className="font-mono text-xs">{operator.address.slice(0, 10)}...{operator.address.slice(-6)}</TableCell>
      <TableCell><StatusBadge status={operator.status} /></TableCell>
      <TableCell className="text-right">{operator.stake.toLocaleString()} TNT</TableCell>
      <TableCell className="text-right">{operator.reputation.toFixed(1)}</TableCell>
      <TableCell>
        <div className="flex items-center gap-2">
          <Progress value={validityRate} className="h-2 w-16" />
          <span className="text-xs">{validityRate.toFixed(1)}%</span>
        </div>
      </TableCell>
      <TableCell>
        <Badge variant={alive ? 'default' : 'destructive'} className="text-xs">
          {alive ? 'Alive' : 'Dead'}
        </Badge>
      </TableCell>
      <TableCell>
        <Badge variant={validation.valid ? 'default' : 'destructive'} className="text-xs">
          {validation.valid ? 'Valid' : 'Invalid'}
        </Badge>
      </TableCell>
    </TableRow>
  )
}

export default function Operators() {
  const [operators, setOperators] = useState<Operator[]>([])
  const [signature, setSignature] = useState<ReturnType<typeof generateThresholdSignature> | null>(null)
  const [registerStake, setRegisterStake] = useState(10000)
  const [showRegister, setShowRegister] = useState(false)

  useEffect(() => {
    setOperators(generateMockOperators(8))
  }, [])

  useEffect(() => {
    if (operators.length > 0) {
      setSignature(generateThresholdSignature(operators))
    }
  }, [operators])

  const activeOps = operators.filter(o => o.status === 'active')
  const totalStake = operators.reduce((s, o) => s + o.stake, 0)
  const avgReputation = operators.length > 0
    ? operators.reduce((s, o) => s + o.reputation, 0) / operators.length
    : 0
  const slashedOps = operators.filter(o => o.status === 'slashed')

  const consensusPrice = 67542.18

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Operator Management</h1>
          <p className="text-muted-foreground mt-1">Register, stake, and monitor oracle operators</p>
        </div>
        <Button onClick={() => setShowRegister(!showRegister)}>
          <Users className="h-4 w-4 mr-2" />
          Register Operator
        </Button>
      </div>

      {showRegister && (
        <Card className="border-primary">
          <CardHeader>
            <CardTitle>Register New Operator</CardTitle>
            <CardDescription>Stake TNT tokens to become an oracle operator</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium">Stake Amount (TNT)</label>
                <div className="flex gap-2 mt-1">
                  <input
                    type="number"
                    value={registerStake}
                    onChange={e => setRegisterStake(Number(e.target.value))}
                    className="flex-1 rounded-md border px-3 py-2 text-sm"
                    min={10000}
                  />
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setRegisterStake(10000)}
                  >Min</Button>
                </div>
                <p className="text-xs text-muted-foreground mt-1">Minimum stake: 10,000 TNT</p>
              </div>
              <div className="flex items-end">
                <Button
                  onClick={() => {
                    const newOp: Operator = {
                      id: `op-${operators.length + 1}`,
                      address: `0x${Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`,
                      stake: registerStake,
                      reputation: 100,
                      status: 'active',
                      lastHeartbeat: Date.now(),
                      totalSubmissions: 0,
                      validSubmissions: 0,
                    }
                    setOperators([...operators, newOp])
                    setShowRegister(false)
                  }}
                  disabled={registerStake < 10000}
                >
                  <Shield className="h-4 w-4 mr-2" />
                  Submit Registration
                </Button>
              </div>
              <div className="flex items-end">
                <Button variant="ghost" onClick={() => setShowRegister(false)}>Cancel</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Active Operators</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{activeOps.length}</div>
            <p className="text-xs text-muted-foreground">of {operators.length} total</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Staked</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalStake.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">TNT tokens</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Avg Reputation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{avgReputation.toFixed(1)}</div>
            <p className="text-xs text-muted-foreground">out of 100</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-1">
              <AlertTriangle className="h-3 w-3" /> Slashed
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{slashedOps.length}</div>
            <p className="text-xs text-muted-foreground">penalty events</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="operators">
        <TabsList>
          <TabsTrigger value="operators">All Operators</TabsTrigger>
          <TabsTrigger value="signatures">Threshold Signatures</TabsTrigger>
          <TabsTrigger value="slashing">Slashing Log</TabsTrigger>
        </TabsList>

        <TabsContent value="operators">
          <Card>
            <CardContent className="pt-6">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Address</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Stake</TableHead>
                    <TableHead className="text-right">Reputation</TableHead>
                    <TableHead>Validity</TableHead>
                    <TableHead>Heartbeat</TableHead>
                    <TableHead>Test Submit</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {operators.map(op => (
                    <OperatorRow key={op.id} operator={op} consensusPrice={consensusPrice} />
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="signatures">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Latest Threshold Signature
              </CardTitle>
              <CardDescription>MPC-based attestation for price data integrity</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {signature && (
                <>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="rounded-lg bg-muted p-3">
                      <div className="text-sm text-muted-foreground">Signers</div>
                      <div className="text-xl font-bold">{signature.signers.length}/{signature.totalOperators}</div>
                    </div>
                    <div className="rounded-lg bg-muted p-3">
                      <div className="text-sm text-muted-foreground">Threshold</div>
                      <div className="text-xl font-bold">{signature.threshold}</div>
                    </div>
                    <div className="rounded-lg bg-muted p-3">
                      <div className="text-sm text-muted-foreground">Timestamp</div>
                      <div className="text-xl font-bold">{new Date(signature.timestamp).toLocaleTimeString()}</div>
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Signature</div>
                    <code className="block rounded bg-muted p-3 text-xs break-all font-mono">{signature.signature}</code>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Signing Operators</div>
                    <div className="space-y-1">
                      {signature.signers.map((s, i) => (
                        <div key={i} className="flex items-center gap-2 text-xs">
                          <CheckCircle className="h-3 w-3 text-green-500" />
                          <code className="font-mono">{s.slice(0, 10)}...{s.slice(-6)}</code>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="slashing">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Slashing Events
              </CardTitle>
              <CardDescription>Penalty actions against misbehaving operators</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Operator</TableHead>
                    <TableHead>Reason</TableHead>
                    <TableHead className="text-right">Slash Amount</TableHead>
                    <TableHead>Time</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {slashedOps.map(op => (
                    <TableRow key={op.id}>
                      <TableCell className="font-mono text-xs">{op.address.slice(0, 10)}...{op.address.slice(-6)}</TableCell>
                      <TableCell>Extreme price deviation detected</TableCell>
                      <TableCell className="text-right text-red-600">-{(op.stake * 0.1).toLocaleString()} TNT</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{new Date(op.lastHeartbeat).toLocaleString()}</TableCell>
                    </TableRow>
                  ))}
                  {slashedOps.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center text-muted-foreground">No slashing events recorded</TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
