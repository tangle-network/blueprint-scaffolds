import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { BookOpen, Code, Copy, CheckCircle, ExternalLink, FileCode, Layers } from 'lucide-react'
import { SUPPORTED_CHAINS, SUPPORTED_PAIRS } from '@/oracle/types'

const CONSUMER_CONTRACT = `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

interface ITangleOracle {
    function getPrice(string calldata pair) external view returns (
        uint256 price,
        uint256 timestamp,
        uint256 confidence
    );
    function getPriceWithSignature(string calldata pair) external view returns (
        uint256 price,
        uint256 timestamp,
        uint256 confidence,
        bytes memory signature
    );
}

contract OracleConsumer {
    ITangleOracle public immutable oracle;
    address public owner;

    event PriceUpdated(string pair, uint256 price, uint256 timestamp);

    constructor(address _oracle) {
        oracle = ITangleOracle(_oracle);
        owner = msg.sender;
    }

    function getLatestPrice(string calldata pair) external view returns (uint256, uint256) {
        (uint256 price, uint256 timestamp, uint256 confidence) = oracle.getPrice(pair);
        require(confidence >= 80, "Low confidence");
        return (price, timestamp);
    }

    function executeWithPrice(string calldata pair, uint256 maxDeviation) external {
        (uint256 price, uint256 timestamp,) = oracle.getPrice(pair);
        require(block.timestamp - timestamp < 60, "Stale price");
        emit PriceUpdated(pair, price, timestamp);
    }
}`

const ORACLE_INTERFACE = `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

interface ITangleOracleFeed {
    struct PriceUpdate {
        uint256 price;
        uint256 timestamp;
        uint256 confidence;
        bytes32 pairId;
        bytes signature;
    }

    event PriceSubmitted(
        bytes32 indexed pairId,
        uint256 price,
        uint256 timestamp,
        address indexed submitter
    );

    function getPrice(bytes32 pairId) external view returns (PriceUpdate memory);
    function getSupportedPairs() external view returns (bytes32[] memory);
    function verifySignature(PriceUpdate calldata update) external view returns (bool);
}`

const DEPLOY_SCRIPT = `import { ethers } from "ethers";

const ORACLE_ADDRESSES: Record<number, string> = {
  1: "0x7A9aB221F4DD8C13c383B1e634b4fE0fB9c1e8A3",
  137: "0x3C4Bf2c0e2D5C9A6f2e8E7bD1A4c5F6d7B8e9F0a",
  42161: "0x5D6e7F8a9B0c1D2e3F4a5B6c7D8e9F0a1B2c3D4e",
};

async function deployConsumer(chainId: number) {
  const provider = new ethers.JsonRpcProvider(process.env.RPC_URL);
  const wallet = new ethers.Wallet(process.env.PRIVATE_KEY!, provider);

  const factory = new ethers.ContractFactory(
    ConsumerArtifact.abi,
    ConsumerArtifact.bytecode,
    wallet
  );

  const contract = await factory.deploy(ORACLE_ADDRESSES[chainId]);
  await contract.waitForDeployment();
  console.log("Consumer deployed to:", await contract.getAddress());
}

deployConsumer(Number(process.env.CHAIN_ID!));`

const EXAMPLE_TS = `import { TangleOracleSDK } from "@tangle-network/oracle-sdk";

const sdk = new TangleOracleSDK({
  network: "testnet",
  operatorCount: 7,
  threshold: 0.67,
});

async function subscribeToPrice(pair: string) {
  const stream = await sdk.subscribe(pair);

  stream.on("price", (data) => {
    console.log(\`\${data.pair}: $\${data.price} (confidence: \${data.confidence}%)\`);
  });

  stream.on("error", (err) => {
    console.error("Oracle error:", err);
  });
}

subscribeToPrice("BTC/USD");`

function CodeBlock({ code, title }: { code: string; title: string }) {
  const [copied, setCopied] = useState(false)

  const handleCopy = () => {
    navigator.clipboard.writeText(code)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="relative">
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-medium text-muted-foreground">{title}</span>
        <Button variant="ghost" size="sm" onClick={handleCopy} className="h-7 px-2">
          {copied ? <CheckCircle className="h-3 w-3 text-green-500" /> : <Copy className="h-3 w-3" />}
          <span className="ml-1 text-xs">{copied ? 'Copied' : 'Copy'}</span>
        </Button>
      </div>
      <pre className="rounded-lg bg-muted p-4 overflow-x-auto text-xs leading-relaxed">
        <code>{code}</code>
      </pre>
    </div>
  )
}

export default function IntegrationGuide() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <BookOpen className="h-8 w-8" />
            Integration Guide
          </h1>
          <p className="text-muted-foreground mt-1">Consumer contracts, SDK usage, and deployment instructions</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Supported Chains</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{SUPPORTED_CHAINS.length}</div>
            <div className="flex gap-1 mt-2">
              {SUPPORTED_CHAINS.map(c => (
                <Badge key={c.chainId} variant="outline" className="text-xs">{c.name}</Badge>
              ))}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Supported Pairs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{SUPPORTED_PAIRS.length}</div>
            <div className="flex flex-wrap gap-1 mt-2">
              {SUPPORTED_PAIRS.map(p => (
                <Badge key={p} variant="outline" className="text-xs">{p}</Badge>
              ))}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Oracle Contract Addresses</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableBody>
                {SUPPORTED_CHAINS.map(chain => (
                  <TableRow key={chain.chainId}>
                    <TableCell className="text-xs font-medium py-1">{chain.name}</TableCell>
                    <TableCell className="text-xs font-mono py-1">
                      0x7A9a...8A3
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="contract">
        <TabsList>
          <TabsTrigger value="contract" className="gap-1">
            <FileCode className="h-3 w-3" /> Consumer Contract
          </TabsTrigger>
          <TabsTrigger value="interface" className="gap-1">
            <Layers className="h-3 w-3" /> Oracle Interface
          </TabsTrigger>
          <TabsTrigger value="deploy" className="gap-1">
            <Code className="h-3 w-3" /> Deploy Script
          </TabsTrigger>
          <TabsTrigger value="sdk" className="gap-1">
            <ExternalLink className="h-3 w-3" /> SDK Usage
          </TabsTrigger>
        </TabsList>

        <TabsContent value="contract">
          <Card>
            <CardHeader>
              <CardTitle>Consumer Contract Example</CardTitle>
              <CardDescription>
                A minimal Solidity contract that reads prices from the Tangle Oracle
              </CardDescription>
            </CardHeader>
            <CardContent>
              <CodeBlock code={CONSUMER_CONTRACT} title="OracleConsumer.sol" />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="interface">
          <Card>
            <CardHeader>
              <CardTitle>Oracle Feed Interface</CardTitle>
              <CardDescription>
                The ITangleOracleFeed interface implemented by deployed oracle contracts
              </CardDescription>
            </CardHeader>
            <CardContent>
              <CodeBlock code={ORACLE_INTERFACE} title="ITangleOracleFeed.sol" />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="deploy">
          <Card>
            <CardHeader>
              <CardTitle>Deployment Script</CardTitle>
              <CardDescription>
                Deploy a consumer contract to your target chain using ethers.js
              </CardDescription>
            </CardHeader>
            <CardContent>
              <CodeBlock code={DEPLOY_SCRIPT} title="deploy.ts" />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sdk">
          <Card>
            <CardHeader>
              <CardTitle>SDK Usage (TypeScript)</CardTitle>
              <CardDescription>
                Subscribe to real-time price feeds using the Tangle Oracle SDK
              </CardDescription>
            </CardHeader>
            <CardContent>
              <CodeBlock code={EXAMPLE_TS} title="oracle-subscriber.ts" />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>Quick Start Steps</CardTitle>
          <CardDescription>Get your contract consuming oracle data in 5 minutes</CardDescription>
        </CardHeader>
        <CardContent>
          <ol className="space-y-3">
            {[
              { step: 'Install dependencies', cmd: 'npm install @tangle-network/oracle-sdk ethers' },
              { step: 'Import the oracle interface', cmd: 'import "./ITangleOracleFeed.sol"' },
              { step: 'Deploy consumer with oracle address', cmd: 'Constructor arg: oracle contract address for your chain' },
              { step: 'Call getPrice(pairId) to read data', cmd: 'Returns price, timestamp, confidence' },
              { step: 'Verify confidence >= 80 before acting', cmd: 'Reject low-confidence data' },
            ].map(({ step, cmd }, i) => (
              <li key={i} className="flex gap-3">
                <Badge variant="outline" className="h-6 w-6 flex items-center justify-center rounded-full p-0 text-xs">
                  {i + 1}
                </Badge>
                <div>
                  <div className="font-medium text-sm">{step}</div>
                  <code className="text-xs text-muted-foreground">{cmd}</code>
                </div>
              </li>
            ))}
          </ol>
        </CardContent>
      </Card>
    </div>
  )
}
