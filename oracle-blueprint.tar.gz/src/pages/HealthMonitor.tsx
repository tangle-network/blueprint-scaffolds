import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Heart, Wifi, WifiOff, AlertTriangle, Clock, BarChart3, Zap, RefreshCw } from 'lucide-react'
import type { DataSource, CircuitBreakerState, SupportedPair } from '@/oracle/types'
import { SUPPORTED_PAIRS } from '@/oracle/types'
import { getAllSourceStatuses } from '@/oracle/sources/fetchers'
import { checkCircuitBreaker } from '@/oracle/aggregation'
import { checkStaleness } from '@/oracle/security'

const MOCK_PRICES: Record<string, number> = {
  BTC: 67542.18,
  ETH: 3521.44,
  MATIC: 0.7123,
  ARB: 1.2345,
  SUSHI: 1.1234,
}

export default function HealthMonitor() {
  const [sources, setSources] = useState<DataSource[]>([])
  const [circuitBreakers, setCircuitBreakers] = useState<CircuitBreakerState[]>([])
  const [lastRefresh, setLastRefresh] = useState(Date.now())

  useEffect(() => {
    const refresh = () => {
      setSources(getAllSourceStatuses())
      setCircuitBreakers(
        SUPPORTED_PAIRS.map((pair) => {
          const [base] = pair.split('/')
          const basePrice = MOCK_PRICES[base] ?? 1
          const newPrice = basePrice * (1 + (Math.random() - 0.5) * 0.2)
          return checkCircuitBreaker(basePrice, newPrice, pair)
        }),
      )
      setLastRefresh(Date.now())
    }
    refresh()
    const interval = setInterval(refresh, 8000)
    return () => clearInterval(interval)
  }, [])

  const healthyCount = sources.filter(s => s.status === 'healthy').length
  const degradedCount = sources.filter(s => s.status === 'degraded').length
  const downCount = sources.filter(s => s.status === 'down').length
  const triggeredCbs = circuitBreakers.filter(cb => cb.triggered)

  function StatusIcon({ status }: { status: DataSource['status'] }) {
    switch (status) {
      case 'healthy':
        return <Wifi className="h-4 w-4 text-green-500" />
      case 'degraded':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />
      case 'down':
        return <WifiOff className="h-4 w-4 text-red-500" />
    }
  }

  function formatAge(ms: number): string {
    const seconds = Math.floor(ms / 1000)
    if (seconds < 60) return `${seconds}s ago`
    const minutes = Math.floor(seconds / 60)
    return `${minutes}m ${seconds % 60}s ago`
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Heart className="h-8 w-8 text-red-500" />
            Health Monitor
          </h1>
          <p className="text-muted-foreground mt-1">Data source health, circuit breakers, and system diagnostics</p>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <RefreshCw className="h-4 w-4 animate-spin" style={{ animationDuration: '8s' }} />
          <span>Auto-refresh every 8s</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Healthy Sources</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{healthyCount}</div>
            <Progress value={(healthyCount / sources.length) * 100} className="mt-2 h-2" />
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Degraded</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{degradedCount}</div>
            <Progress value={(degradedCount / sources.length) * 100} className="mt-2 h-2" />
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Down</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{downCount}</div>
            <Progress value={(downCount / sources.length) * 100} className="mt-2 h-2" />
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-1">
              <Zap className="h-3 w-3" /> Circuit Breakers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${triggeredCbs.length > 0 ? 'text-red-600' : 'text-green-600'}`}>
              {triggeredCbs.length}
            </div>
            <p className="text-xs text-muted-foreground">{triggeredCbs.length > 0 ? 'TRIGGERED' : 'All clear'}</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="sources">
        <TabsList>
          <TabsTrigger value="sources">Data Sources</TabsTrigger>
          <TabsTrigger value="circuit">Circuit Breakers</TabsTrigger>
          <TabsTrigger value="staleness">Staleness Check</TabsTrigger>
        </TabsList>

        <TabsContent value="sources">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Source Status Overview
              </CardTitle>
              <CardDescription>Real-time health of all price data sources</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Status</TableHead>
                    <TableHead>Source</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Chain</TableHead>
                    <TableHead className="text-right">Latency</TableHead>
                    <TableHead>Last Update</TableHead>
                    <TableHead className="text-right">Errors</TableHead>
                    <TableHead>Health</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sources.map((source) => {
                    const staleness = checkStaleness(source.lastUpdate)
                    return (
                      <TableRow key={source.name}>
                        <TableCell><StatusIcon status={source.status} /></TableCell>
                        <TableCell className="font-medium">{source.name}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-xs">
                            {source.type.toUpperCase()}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm">{source.chain ?? '—'}</TableCell>
                        <TableCell className="text-right text-sm">
                          {source.latency > 0 ? `${source.latency}ms` : '—'}
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {formatAge(Date.now() - source.lastUpdate)}
                        </TableCell>
                        <TableCell className="text-right">
                          <span className={source.errorCount > 5 ? 'text-red-600 font-bold' : ''}>
                            {source.errorCount}
                          </span>
                        </TableCell>
                        <TableCell>
                          <Progress
                            value={source.status === 'healthy' ? 95 : source.status === 'degraded' ? 50 : 5}
                            className="h-2 w-16"
                          />
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="circuit">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5" />
                Circuit Breaker Status
              </CardTitle>
              <CardDescription>
                Automatic pause on extreme price movements (threshold: 10%)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Pair</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Current Deviation</TableHead>
                    <TableHead className="text-right">Threshold</TableHead>
                    <TableHead>Triggered At</TableHead>
                    <TableHead>Paused</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {circuitBreakers.map((cb) => (
                    <TableRow key={cb.pair}>
                      <TableCell className="font-medium">{cb.pair}</TableCell>
                      <TableCell>
                        <Badge variant={cb.triggered ? 'destructive' : 'default'}>
                          {cb.triggered ? 'TRIGGERED' : 'Normal'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">{cb.currentDeviation.toFixed(2)}%</TableCell>
                      <TableCell className="text-right">{cb.threshold}%</TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {cb.triggeredAt ? new Date(cb.triggeredAt).toLocaleTimeString() : '—'}
                      </TableCell>
                      <TableCell>
                        <Badge variant={cb.paused ? 'destructive' : 'secondary'} className="text-xs">
                          {cb.paused ? 'PAUSED' : 'Active'}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="staleness">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Data Staleness Monitor
              </CardTitle>
              <CardDescription>Maximum age: 60 seconds before flagged as stale</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Source</TableHead>
                    <TableHead className="text-right">Age (ms)</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Threshold</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sources.map((source) => {
                    const { stale, ageMs } = checkStaleness(source.lastUpdate)
                    return (
                      <TableRow key={source.name}>
                        <TableCell className="font-medium">{source.name}</TableCell>
                        <TableCell className="text-right">{ageMs.toLocaleString()}ms</TableCell>
                        <TableCell>
                          <Badge variant={stale ? 'destructive' : 'default'} className="text-xs">
                            {stale ? 'STALE' : 'Fresh'}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">60,000ms</TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
