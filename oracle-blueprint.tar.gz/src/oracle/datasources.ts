import { DataSourceResult, DataSourceHealth } from '../types';

const CEX_APIS = {
  binance: 'https://api.binance.com/api/v3/ticker/price',
  coinbase: 'https://api.exchange.coinbase.com/products',
  kraken: 'https://api.kraken.com/0/public/Ticker',
};

export class DataSourceManager {
  private health: Map<string, DataSourceHealth> = new Map();
  private isPaused = false;

  constructor() {
    this.initHealth();
  }

  private initHealth(): void {
    const sources = [
      { name: 'Binance', type: 'cex' as const },
      { name: 'Coinbase', type: 'cex' as const },
      { name: 'Kraken', type: 'cex' as const },
      { name: 'Uniswap V3 (Ethereum)', type: 'dex' as const },
      { name: 'Uniswap V3 (Arbitrum)', type: 'dex' as const },
      { name: 'SushiSwap (Polygon)', type: 'dex' as const },
    ];

    for (const s of sources) {
      this.health.set(s.name, {
        name: s.name,
        type: s.type,
        status: 'healthy',
        latency: Math.random() * 100 + 20,
        lastFetch: Date.now(),
        errorRate: Math.random() * 0.05,
        uptime: 99.5 + Math.random() * 0.5,
      });
    }
  }

  async fetchPrice(pair: string, source: string): Promise<DataSourceResult | null> {
    if (this.isPaused) return null;

    const start = Date.now();
    try {
      const price = this.simulateFetch(pair, source);
      const latency = Date.now() - start;

      this.updateHealth(source, true, latency);

      return {
        source,
        type: this.getSourceType(source),
        price,
        volume: Math.random() * 1e8,
        timestamp: Date.now(),
        weight: this.getSourceWeight(source),
        latency,
      };
    } catch {
      this.updateHealth(source, false, Date.now() - start);
      return null;
    }
  }

  async fetchAllSources(pair: string): Promise<DataSourceResult[]> {
    const sources = ['Binance', 'Coinbase', 'Kraken', 'Uniswap V3 (Ethereum)', 'Uniswap V3 (Arbitrum)', 'SushiSwap (Polygon)'];
    const results = await Promise.allSettled(
      sources.map(s => this.fetchPrice(pair, s))
    );
    return results
      .filter((r): r is PromiseFulfilledResult<DataSourceResult> => r.status === 'fulfilled' && r.value !== null)
      .map(r => r.value);
  }

  getHealthStatus(): DataSourceHealth[] {
    return Array.from(this.health.values());
  }

  pause(): void { this.isPaused = true; }
  resume(): void { this.isPaused = false; }
  paused(): boolean { return this.isPaused; }

  private simulateFetch(pair: string, source: string): number {
    const basePrices: Record<string, number> = {
      'BTC/USD': 67432.50,
      'ETH/USD': 3521.80,
      'POL/USD': 0.5842,
      'ARB/USD': 1.1243,
      'SOL/USD': 178.35,
      'AVAX/USD': 38.92,
      'DOT/USD': 7.21,
      'LINK/USD': 14.87,
    };
    const base = basePrices[pair] ?? 100;
    const noise = (Math.random() - 0.5) * base * 0.002;
    return base + noise;
  }

  private getSourceType(source: string): 'cex' | 'dex' {
    return source.includes('Uniswap') || source.includes('SushiSwap') ? 'dex' : 'cex';
  }

  private getSourceWeight(source: string): number {
    const weights: Record<string, number> = {
      'Binance': 0.25,
      'Coinbase': 0.20,
      'Kraken': 0.15,
      'Uniswap V3 (Ethereum)': 0.20,
      'Uniswap V3 (Arbitrum)': 0.10,
      'SushiSwap (Polygon)': 0.10,
    };
    return weights[source] ?? 0.1;
  }

  private updateHealth(source: string, success: boolean, latency: number): void {
    const h = this.health.get(source);
    if (!h) return;
    h.lastFetch = Date.now();
    h.latency = latency;
    if (!success) {
      h.errorRate = Math.min(1, h.errorRate + 0.05);
    } else {
      h.errorRate = Math.max(0, h.errorRate - 0.01);
    }
    h.status = h.errorRate > 0.2 ? 'down' : h.errorRate > 0.1 ? 'degraded' : 'healthy';
  }
}

export { CEX_APIS };
