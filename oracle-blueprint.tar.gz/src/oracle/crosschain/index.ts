import type { ChainFeed } from '../types';
import { SUPPORTED_CHAINS } from '../types';

const MOCK_CONTRACTS: Record<number, string> = {
  1: '0x7A9aB221F4DD8C13c383B1e634b4fE0fB9c1e8A3',
  137: '0x3C4Bf2c0e2D5C9A6f2e8E7bD1A4c5F6d7B8e9F0a',
  42161: '0x5D6e7F8a9B0c1D2e3F4a5B6c7D8e9F0a1B2c3D4e',
};

export function getChainFeeds(pair: string, price: number): ChainFeed[] {
  return SUPPORTED_CHAINS.map(chain => {
    const statusRoll = Math.random();
    return {
      chain: chain.name,
      chainId: chain.chainId,
      contractAddress: MOCK_CONTRACTS[chain.chainId] ?? '0x0',
      lastPrice: price * (1 + (Math.random() - 0.5) * 0.002),
      lastUpdate: Date.now() - Math.floor(Math.random() * 30000),
      blockNumber: 19000000 + Math.floor(Math.random() * 100000),
      status: statusRoll > 0.95 ? 'error' : statusRoll > 0.85 ? 'delayed' : 'synced',
    };
  });
}

export function verifyCrossChainConsistency(feeds: ChainFeed[], tolerancePercent: number = 0.5): {
  consistent: boolean;
  maxDeviation: number;
  details: { chain: string; deviation: number }[];
} {
  if (feeds.length < 2) {
    return { consistent: true, maxDeviation: 0, details: [] };
  }

  const prices = feeds.map(f => f.lastPrice);
  const avgPrice = prices.reduce((a, b) => a + b, 0) / prices.length;

  const details = feeds.map(f => ({
    chain: f.chain,
    deviation: Math.abs(f.lastPrice - avgPrice) / avgPrice * 100,
  }));

  const maxDeviation = Math.max(...details.map(d => d.deviation));

  return {
    consistent: maxDeviation <= tolerancePercent,
    maxDeviation,
    details,
  };
}

export function formatCrossChainMessage(
  pair: string,
  price: number,
  sourceChainId: number,
  targetChainId: number,
): { messageId: string; payload: string } {
  return {
    messageId: `0x${Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`,
    payload: JSON.stringify({
      pair,
      price,
      sourceChainId,
      targetChainId,
      timestamp: Date.now(),
      nonce: Math.floor(Math.random() * 1e6),
    }),
  };
}
