import type { Operator, ThresholdSignature } from '../types';

export function generateMockOperators(count: number): Operator[] {
  const operators: Operator[] = [];
  for (let i = 0; i < count; i++) {
    const vs = Math.floor(Math.random() * 10000) + 5000;
    operators.push({
      id: `op-${i + 1}`,
      address: `0x${Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`,
      stake: Math.floor(Math.random() * 50000) + 10000,
      reputation: 85 + Math.random() * 15,
      status: i === count - 1 ? 'slashed' : i === count - 2 ? 'inactive' : 'active',
      lastHeartbeat: Date.now() - Math.floor(Math.random() * 30000),
      totalSubmissions: vs + Math.floor(Math.random() * 50),
      validSubmissions: vs,
    });
  }
  return operators;
}

export function validateSubmission(
  operator: Operator,
  submittedPrice: number,
  consensusPrice: number,
  tolerancePercent: number = 2,
): { valid: boolean; slashAmount: number; reason: string } {
  if (operator.status === 'slashed') {
    return { valid: false, slashAmount: 0, reason: 'Operator already slashed' };
  }

  if (operator.status === 'inactive') {
    return { valid: false, slashAmount: 0, reason: 'Operator inactive' };
  }

  const deviation = Math.abs(submittedPrice - consensusPrice) / consensusPrice * 100;

  if (deviation > tolerancePercent * 3) {
    return {
      valid: false,
      slashAmount: operator.stake * 0.1,
      reason: `Extreme deviation: ${deviation.toFixed(2)}% (> ${tolerancePercent * 3}%)`,
    };
  }

  if (deviation > tolerancePercent) {
    return {
      valid: false,
      slashAmount: operator.stake * 0.01,
      reason: `Significant deviation: ${deviation.toFixed(2)}% (> ${tolerancePercent}%)`,
    };
  }

  return { valid: true, slashAmount: 0, reason: 'Valid submission' };
}

export function checkHeartbeat(
  operator: Operator,
  maxIntervalMs: number = 60000,
): boolean {
  return Date.now() - operator.lastHeartbeat < maxIntervalMs;
}

export function generateThresholdSignature(
  operators: Operator[],
  threshold: number = 0.67,
): ThresholdSignature {
  const activeOperators = operators.filter(op => op.status === 'active' && checkHeartbeat(op));
  const requiredSigs = Math.ceil(activeOperators.length * threshold);

  const signers = activeOperators.slice(0, requiredSigs).map(op => op.address);

  return {
    signers,
    threshold: requiredSigs,
    totalOperators: operators.length,
    signature: `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`,
    timestamp: Date.now(),
  };
}

export function checkStaleness(
  lastUpdate: number,
  maxAgeMs: number = 60000,
): { stale: boolean; ageMs: number } {
  const ageMs = Date.now() - lastUpdate;
  return { stale: ageMs > maxAgeMs, ageMs };
}
