import type { PriceDataPoint, DataSource } from '../types';

const MOCK_PRICES: Record<string, number> = {
  BTC: 67542.18,
  ETH: 3521.44,
  MATIC: 0.7123,
  ARB: 1.2345,
  SUSHI: 1.1234,
};

function randomVariation(base: number, percent: number): number {
  return base * (1 + (Math.random() - 0.5) * 2 * percent / 100);
}

export function fetchBinancePrice(pair: string): PriceDataPoint {
  const [base] = pair.split('/');
  const basePrice = MOCK_PRICES[base] ?? 1;
  return {
    price: randomVariation(basePrice, 0.05),
    timestamp: Date.now(),
    source: 'Binance',
    volume: Math.random() * 1e9,
    confidence: 0.99,
  };
}

export function fetchCoinbasePrice(pair: string): PriceDataPoint {
  const [base] = pair.split('/');
  const basePrice = MOCK_PRICES[base] ?? 1;
  return {
    price: randomVariation(basePrice, 0.08),
    timestamp: Date.now(),
    source: 'Coinbase',
    volume: Math.random() * 5e8,
    confidence: 0.97,
  };
}

export function fetchKrakenPrice(pair: string): PriceDataPoint {
  const [base] = pair.split('/');
  const basePrice = MOCK_PRICES[base] ?? 1;
  return {
    price: randomVariation(basePrice, 0.06),
    timestamp: Date.now(),
    source: 'Kraken',
    volume: Math.random() * 3e8,
    confidence: 0.96,
  };
}

export function fetchUniswapTWAP(pair: string): PriceDataPoint {
  const [base] = pair.split('/');
  const basePrice = MOCK_PRICES[base] ?? 1;
  return {
    price: randomVariation(basePrice, 0.12),
    timestamp: Date.now(),
    source: 'Uniswap V3',
    volume: Math.random() * 2e8,
    confidence: 0.92,
  };
}

export function fetchSushiSwapPrice(pair: string): PriceDataPoint {
  const [base] = pair.split('/');
  const basePrice = MOCK_PRICES[base] ?? 1;
  return {
    price: randomVariation(basePrice, 0.15),
    timestamp: Date.now(),
    source: 'SushiSwap',
    volume: Math.random() * 1e8,
    confidence: 0.89,
  };
}

export function getAllSourceStatuses(): DataSource[] {
  return [
    { name: 'Binance', type: 'cex', status: 'healthy', latency: 45, lastUpdate: Date.now() - 1000, errorCount: 0 },
    { name: 'Coinbase', type: 'cex', status: 'healthy', latency: 62, lastUpdate: Date.now() - 1500, errorCount: 1 },
    { name: 'Kraken', type: 'cex', status: 'healthy', latency: 78, lastUpdate: Date.now() - 2000, errorCount: 0 },
    { name: 'Uniswap V3', type: 'dex', chain: 'Ethereum', status: 'healthy', latency: 2100, lastUpdate: Date.now() - 12000, errorCount: 0 },
    { name: 'Uniswap V3 (Polygon)', type: 'dex', chain: 'Polygon', status: 'degraded', latency: 4500, lastUpdate: Date.now() - 25000, errorCount: 3 },
    { name: 'Uniswap V3 (Arbitrum)', type: 'dex', chain: 'Arbitrum', status: 'healthy', latency: 800, lastUpdate: Date.now() - 3000, errorCount: 0 },
    { name: 'SushiSwap', type: 'dex', chain: 'Ethereum', status: 'healthy', latency: 2800, lastUpdate: Date.now() - 14000, errorCount: 1 },
    { name: 'SushiSwap (Polygon)', type: 'dex', chain: 'Polygon', status: 'down', latency: 0, lastUpdate: Date.now() - 120000, errorCount: 15 },
  ];
}

export function fetchAllSources(pair: string): PriceDataPoint[] {
  return [
    fetchBinancePrice(pair),
    fetchCoinbasePrice(pair),
    fetchKrakenPrice(pair),
    fetchUniswapTWAP(pair),
    fetchSushiSwapPrice(pair),
  ];
}
