import type { ChainName, CrossChainMessage, AggregatedPrice } from './types';

const CHAIN_IDS: Record<ChainName, number> = {
  ethereum: 1,
  polygon: 137,
  arbitrum: 42161,
  tangle: 5845,
};

const RPC_ENDPOINTS: Record<ChainName, string> = {
  ethereum: 'https://eth.llamarpc.com',
  polygon: 'https://polygon-rpc.com',
  arbitrum: 'https://arb1.arbitrum.io/rpc',
  tangle: 'https://rpc.tangle.tools',
};

const FEED_CONTRACTS: Record<string, Record<ChainName, string>> = {
  'BTC/USD': {
    ethereum: '0x0000000000000000000000000000000000000001',
    polygon: '0x0000000000000000000000000000000000000002',
    arbitrum: '0x0000000000000000000000000000000000000003',
    tangle: '0x0000000000000000000000000000000000000004',
  },
  'ETH/USD': {
    ethereum: '0x0000000000000000000000000000000000000005',
    polygon: '0x0000000000000000000000000000000000000006',
    arbitrum: '0x0000000000000000000000000000000000000007',
    tangle: '0x0000000000000000000000000000000000000008',
  },
};

export class CrossChainBridge {
  private chainId: number;
  private sourceChain: ChainName;

  constructor(sourceChain: ChainName = 'tangle') {
    this.sourceChain = sourceChain;
    this.chainId = CHAIN_IDS[sourceChain];
  }

  createMessage(
    feedId: string,
    aggregated: AggregatedPrice,
    targetChain: ChainName,
  ): CrossChainMessage {
    const proof = this.generateProof(aggregated);

    return {
      feedId,
      price: aggregated.price,
      timestamp: aggregated.timestamp,
      sourceChain: this.sourceChain,
      targetChain,
      proof,
    };
  }

  async pushPrice(
    feedId: string,
    aggregated: AggregatedPrice,
    targetChains: ChainName[],
  ): Promise<Map<ChainName, { success: boolean; txHash?: string }>> {
    const results = new Map<ChainName, { success: boolean; txHash?: string }>();

    for (const chain of targetChains) {
      const message = this.createMessage(feedId, aggregated, chain);
      const contractAddr = FEED_CONTRACTS[feedId]?.[chain];

      if (!contractAddr) {
        results.set(chain, { success: false });
        continue;
      }

      try {
        void RPC_ENDPOINTS[chain];
        const txHash = this.simulateCrossChainTx(message, contractAddr);
        results.set(chain, { success: true, txHash });
      } catch {
        results.set(chain, { success: false });
      }
    }

    return results;
  }

  verifyConsistency(
    feedId: string,
    prices: Map<ChainName, number>,
    tolerancePercent: number = 0.1,
  ): { consistent: boolean; deviations: Map<ChainName, number> } {
    const priceValues = Array.from(prices.values());
    if (priceValues.length < 2) {
      return { consistent: true, deviations: new Map() };
    }

    const avg = priceValues.reduce((s, p) => s + p, 0) / priceValues.length;
    const deviations = new Map<ChainName, number>();
    let consistent = true;

    for (const [chain, price] of prices) {
      const dev = Math.abs(price - avg) / avg * 100;
      deviations.set(chain, dev);
      if (dev > tolerancePercent) {
        consistent = false;
      }
    }

    return { consistent, deviations };
  }

  getContractAddress(feedId: string, chain: ChainName): string | undefined {
    return FEED_CONTRACTS[feedId]?.[chain];
  }

  getChainId(chain: ChainName): number {
    return CHAIN_IDS[chain];
  }

  private generateProof(aggregated: AggregatedPrice): string {
    const data = `${aggregated.pair}:${aggregated.price}:${aggregated.timestamp}:${aggregated.signature ?? 'unsigned'}`;
    let hash = 0;
    for (let i = 0; i < data.length; i++) {
      const char = data.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return `0x${Math.abs(hash).toString(16).padStart(64, '0')}`;
  }

  private simulateCrossChainTx(_message: CrossChainMessage, _contractAddr: string): string {
    return `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;
  }
}

export { CHAIN_IDS, RPC_ENDPOINTS, FEED_CONTRACTS };
