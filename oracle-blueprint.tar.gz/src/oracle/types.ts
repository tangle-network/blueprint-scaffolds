export interface PriceReport {
  pair: string;
  price: number;
  timestamp: number;
  source: string;
  volume: number;
  confidence: number;
}

export interface AggregatedPrice {
  pair: string;
  price: number;
  timestamp: number;
  sources: string[];
  weightedMedian: number;
  standardDeviation: number;
  confidence: number;
  outlierCount: number;
  signature?: string;
}

export interface DataSourceConfig {
  name: string;
  type: 'cex' | 'dex';
  weight: number;
  endpoint: string;
  apiKey?: string;
  chainId?: number;
  enabled: boolean;
}

export interface OperatorInfo {
  id: string;
  address: string;
  stake: number;
  reputation: number;
  isActive: boolean;
  lastHeartbeat: number;
  totalSubmissions: number;
  validSubmissions: number;
  slashCount: number;
}

export interface OracleFeed {
  pair: string;
  decimals: number;
  heartbeat: number;
  deviationThreshold: number;
  chains: ChainDeployment[];
  lastUpdate: number;
  isPaused: boolean;
}

export interface ChainDeployment {
  chain: string;
  chainId: number;
  contractAddress: string;
  lastPush: number;
  status: 'active' | 'stale' | 'error';
}

export interface CircuitBreakerConfig {
  maxDeviationPercent: number;
  cooldownMs: number;
  minSources: number;
  maxStalenessMs: number;
  pauseOnTrigger: boolean;
}

export interface MPCSession {
  id: string;
  participants: string[];
  threshold: number;
  data: PriceReport;
  signatures: Map<string, string>;
  completed: boolean;
}

export interface JobSchedule {
  id: string;
  pair: string;
  intervalMs: number;
  lastRun: number;
  nextRun: number;
  enabled: boolean;
}

export interface BlueprintDefinition {
  name: string;
  version: string;
  description: string;
  author: string;
  jobs: JobSchedule[];
  sources: DataSourceConfig[];
  feeds: OracleFeed[];
  security: CircuitBreakerConfig;
}

export type ChainName = 'ethereum' | 'polygon' | 'arbitrum' | 'tangle';

export interface CrossChainMessage {
  feedId: string;
  price: number;
  timestamp: number;
  sourceChain: ChainName;
  targetChain: ChainName;
  proof: string;
}

export interface HealthStatus {
  source: string;
  status: 'healthy' | 'degraded' | 'down';
  latencyMs: number;
  lastSuccess: number;
  errorCount: number;
  uptime: number;
}
