export interface PriceDataPoint {
  price: number;
  timestamp: number;
  source: string;
  volume: number;
  confidence: number;
}

export interface AggregatedPrice {
  pair: string;
  price: number;
  timestamp: number;
  sources: number;
  confidence: number;
  deviation: number;
  signature: string;
}

export interface DataSource {
  name: string;
  type: 'cex' | 'dex';
  chain?: string;
  status: 'healthy' | 'degraded' | 'down';
  latency: number;
  lastUpdate: number;
  errorCount: number;
}

export interface Operator {
  id: string;
  address: string;
  stake: number;
  reputation: number;
  status: 'active' | 'inactive' | 'slashed';
  lastHeartbeat: number;
  totalSubmissions: number;
  validSubmissions: number;
}

export interface ChainFeed {
  chain: string;
  chainId: number;
  contractAddress: string;
  lastPrice: number;
  lastUpdate: number;
  blockNumber: number;
  status: 'synced' | 'delayed' | 'error';
}

export interface CircuitBreakerState {
  pair: string;
  triggered: boolean;
  threshold: number;
  currentDeviation: number;
  triggeredAt: number | null;
  paused: boolean;
}

export interface ThresholdSignature {
  signers: string[];
  threshold: number;
  totalOperators: number;
  signature: string;
  timestamp: number;
}

export type SupportedPair =
  | 'BTC/USD'
  | 'ETH/USD'
  | 'MATIC/USD'
  | 'ARB/USD'
  | 'SUSHI/USD';

export const SUPPORTED_PAIRS: SupportedPair[] = [
  'BTC/USD',
  'ETH/USD',
  'MATIC/USD',
  'ARB/USD',
  'SUSHI/USD',
];

export const SUPPORTED_CHAINS = [
  { name: 'Ethereum', chainId: 1 },
  { name: 'Polygon', chainId: 137 },
  { name: 'Arbitrum', chainId: 42161 },
] as const;
