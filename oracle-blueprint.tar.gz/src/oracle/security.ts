import type { OperatorInfo, PriceReport, MPCSession } from './types';

export class SecurityManager {
  private operators: Map<string, OperatorInfo> = new Map();
  private mpcThreshold: number;
  private minOperators: number;
  private maxInvalidSubmissions: number;
  private slashPercentage: number;
  private heartbeatTimeoutMs: number;

  constructor(config?: {
    mpcThreshold?: number;
    minOperators?: number;
    maxInvalidSubmissions?: number;
    slashPercentage?: number;
    heartbeatTimeoutMs?: number;
  }) {
    this.mpcThreshold = config?.mpcThreshold ?? 0.67;
    this.minOperators = config?.minOperators ?? 3;
    this.maxInvalidSubmissions = config?.maxInvalidSubmissions ?? 5;
    this.slashPercentage = config?.slashPercentage ?? 10;
    this.heartbeatTimeoutMs = config?.heartbeatTimeoutMs ?? 120000;
  }

  registerOperator(info: Omit<OperatorInfo, 'totalSubmissions' | 'validSubmissions' | 'slashCount'>): void {
    this.operators.set(info.id, {
      ...info,
      totalSubmissions: 0,
      validSubmissions: 0,
      slashCount: 0,
    });
  }

  removeOperator(id: string): boolean {
    return this.operators.delete(id);
  }

  getOperator(id: string): OperatorInfo | undefined {
    return this.operators.get(id);
  }

  getAllOperators(): OperatorInfo[] {
    return Array.from(this.operators.values());
  }

  getActiveOperators(): OperatorInfo[] {
    const now = Date.now();
    return this.getAllOperators().filter(
      (op) =>
        op.isActive &&
        now - op.lastHeartbeat < this.heartbeatTimeoutMs,
    );
  }

  recordHeartbeat(operatorId: string): boolean {
    const op = this.operators.get(operatorId);
    if (!op) return false;
    op.lastHeartbeat = Date.now();
    op.isActive = true;
    return true;
  }

  validateSubmission(operatorId: string, report: PriceReport): {
    valid: boolean;
    reason?: string;
  } {
    const op = this.operators.get(operatorId);
    if (!op) return { valid: false, reason: 'unknown_operator' };
    if (!op.isActive) return { valid: false, reason: 'inactive_operator' };

    const now = Date.now();
    if (now - op.lastHeartbeat > this.heartbeatTimeoutMs) {
      op.isActive = false;
      return { valid: false, reason: 'heartbeat_timeout' };
    }

    if (report.timestamp > now + 30000) {
      this.recordInvalidSubmission(operatorId);
      return { valid: false, reason: 'future_timestamp' };
    }

    if (report.price <= 0 || !isFinite(report.price)) {
      this.recordInvalidSubmission(operatorId);
      return { valid: false, reason: 'invalid_price' };
    }

    if (report.confidence < 0 || report.confidence > 1) {
      this.recordInvalidSubmission(operatorId);
      return { valid: false, reason: 'invalid_confidence' };
    }

    op.totalSubmissions++;
    op.validSubmissions++;
    return { valid: true };
  }

  recordInvalidSubmission(operatorId: string): void {
    const op = this.operators.get(operatorId);
    if (!op) return;

    op.totalSubmissions++;
    const invalidCount = op.totalSubmissions - op.validSubmissions;

    if (invalidCount >= this.maxInvalidSubmissions) {
      this.slashOperator(operatorId);
    }
  }

  slashOperator(operatorId: string): { slashed: boolean; amount: number } {
    const op = this.operators.get(operatorId);
    if (!op) return { slashed: false, amount: 0 };

    const slashAmount = op.stake * (this.slashPercentage / 100);
    op.stake -= slashAmount;
    op.slashCount++;
    op.reputation = Math.max(0, op.reputation - 10);

    if (op.stake <= 0) {
      op.isActive = false;
    }

    return { slashed: true, amount: slashAmount };
  }

  createMPCSession(data: PriceReport): MPCSession {
    const activeOps = this.getActiveOperators();
    const participants = activeOps
      .slice(0, Math.ceil(activeOps.length * this.mpcThreshold))
      .map((op) => op.id);

    return {
      id: `mpc-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      participants,
      threshold: Math.ceil(participants.length * 0.67),
      data,
      signatures: new Map(),
      completed: false,
    };
  }

  addMPCSignature(
    session: MPCSession,
    operatorId: string,
    signature: string,
  ): { complete: boolean } {
    if (!session.participants.includes(operatorId)) {
      return { complete: false };
    }

    session.signatures.set(operatorId, signature);

    if (session.signatures.size >= session.threshold) {
      session.completed = true;
    }

    return { complete: session.completed };
  }

  verifyAttestation(session: MPCSession): boolean {
    if (!session.completed) return false;
    if (session.signatures.size < session.threshold) return false;
    return session.participants.every(
      (p) =>
        session.signatures.has(p) ||
        session.signatures.size >= session.threshold,
    );
  }

  getReputationScore(operatorId: string): number {
    const op = this.operators.get(operatorId);
    if (!op) return 0;

    const validRate =
      op.totalSubmissions > 0
        ? op.validSubmissions / op.totalSubmissions
        : 0;
    const stakeScore = Math.min(op.stake / 10000, 1);
    const slashPenalty = op.slashCount * 5;

    return Math.max(0, validRate * 60 + stakeScore * 30 + op.reputation * 0.1 - slashPenalty);
  }
}
