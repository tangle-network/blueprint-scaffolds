import type { PriceDataPoint, CircuitBreakerState } from '../types';

export function weightedMedian(
  dataPoints: PriceDataPoint[],
): number {
  if (dataPoints.length === 0) return 0;

  const sorted = [...dataPoints].sort((a, b) => a.price - b.price);
  const totalWeight = sorted.reduce((sum, dp) => sum + dp.confidence * Math.log(dp.volume + 1), 0);

  if (totalWeight === 0) {
    const mid = Math.floor(sorted.length / 2);
    return sorted.length % 2 !== 0 ? sorted[mid].price : (sorted[mid - 1].price + sorted[mid].price) / 2;
  }

  let cumulativeWeight = 0;
  for (const dp of sorted) {
    cumulativeWeight += (dp.confidence * Math.log(dp.volume + 1)) / totalWeight;
    if (cumulativeWeight >= 0.5) {
      return dp.price;
    }
  }

  return sorted[sorted.length - 1].price;
}

export function detectOutliers(
  dataPoints: PriceDataPoint[],
  thresholdPercent: number = 5,
): { filtered: PriceDataPoint[]; outliers: PriceDataPoint[] } {
  if (dataPoints.length < 3) {
    return { filtered: dataPoints, outliers: [] };
  }

  const median = weightedMedian(dataPoints);
  const lowerBound = median * (1 - thresholdPercent / 100);
  const upperBound = median * (1 + thresholdPercent / 100);

  const filtered: PriceDataPoint[] = [];
  const outliers: PriceDataPoint[] = [];

  for (const dp of dataPoints) {
    if (dp.price >= lowerBound && dp.price <= upperBound) {
      filtered.push(dp);
    } else {
      outliers.push(dp);
    }
  }

  return { filtered, outliers };
}

export function calculateDeviation(dataPoints: PriceDataPoint[]): number {
  if (dataPoints.length === 0) return 0;
  const median = weightedMedian(dataPoints);
  const squaredDiffs = dataPoints.map(dp => Math.pow(dp.price - median, 2));
  const variance = squaredDiffs.reduce((a, b) => a + b, 0) / dataPoints.length;
  return Math.sqrt(variance) / median * 100;
}

export function aggregatePrices(
  pair: string,
  dataPoints: PriceDataPoint[],
  thresholdPercent: number = 5,
): { price: number; sources: number; confidence: number; deviation: number; outliers: PriceDataPoint[] } {
  const { filtered, outliers } = detectOutliers(dataPoints, thresholdPercent);
  const price = weightedMedian(filtered);
  const deviation = calculateDeviation(filtered);
  const avgConfidence = filtered.length > 0
    ? filtered.reduce((sum, dp) => sum + dp.confidence, 0) / filtered.length
    : 0;

  return {
    price,
    sources: filtered.length,
    confidence: avgConfidence,
    deviation,
    outliers,
  };
}

export function checkCircuitBreaker(
  previousPrice: number,
  newPrice: number,
  pair: string,
  thresholdPercent: number = 10,
): CircuitBreakerState {
  const deviation = previousPrice > 0
    ? Math.abs(newPrice - previousPrice) / previousPrice * 100
    : 0;

  return {
    pair,
    triggered: deviation > thresholdPercent,
    threshold: thresholdPercent,
    currentDeviation: deviation,
    triggeredAt: deviation > thresholdPercent ? Date.now() : null,
    paused: deviation > thresholdPercent,
  };
}

export function calculateTWAP(
  historicalPrices: { price: number; timestamp: number }[],
  windowMs: number = 30 * 60 * 1000,
): number {
  const cutoff = Date.now() - windowMs;
  const recent = historicalPrices.filter(p => p.timestamp >= cutoff);

  if (recent.length === 0) return 0;

  let weightedSum = 0;
  let totalWeight = 0;

  for (let i = 0; i < recent.length; i++) {
    const weight = i === 0
      ? (recent[i + 1]?.timestamp ?? recent[i].timestamp + 1) - recent[i].timestamp
      : recent[i].timestamp - recent[i - 1].timestamp;
    weightedSum += recent[i].price * weight;
    totalWeight += weight;
  }

  return totalWeight > 0 ? weightedSum / totalWeight : recent[recent.length - 1].price;
}
