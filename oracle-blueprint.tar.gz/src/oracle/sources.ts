import type { PriceReport } from '../oracle/types';

export interface TWAPDataPoint {
  price: number;
  timestamp: number;
  volume: number;
}

export function calculateTWAP(points: TWAPDataPoint[], windowMs: number = 3600000): number {
  const now = Date.now();
  const cutoff = now - windowMs;
  const recentPoints = points.filter((p) => p.timestamp >= cutoff);

  if (recentPoints.length === 0) return 0;

  let weightedSum = 0;
  let totalWeight = 0;

  for (let i = 1; i < recentPoints.length; i++) {
    const dt = recentPoints[i].timestamp - recentPoints[i - 1].timestamp;
    const avgPrice = (recentPoints[i].price + recentPoints[i - 1].price) / 2;
    weightedSum += avgPrice * dt;
    totalWeight += dt;
  }

  return totalWeight > 0 ? weightedSum / totalWeight : recentPoints[recentPoints.length - 1].price;
}

export class BinanceSource {
  readonly name = 'Binance';
  private baseUrl = 'https://api.binance.com/api/v3';

  async fetchPrice(pair: string): Promise<PriceReport> {
    const symbol = pair.replace('/', '');
    const url = `${this.baseUrl}/ticker/24hr?symbol=${symbol}`;
    const start = Date.now();

    const res = await fetch(url);
    if (!res.ok) throw new Error(`Binance API error: ${res.status}`);

    const data = await res.json();
    const price = parseFloat(data.lastPrice);
    const volume = parseFloat(data.quoteVolume);

    return {
      pair,
      price,
      timestamp: Date.now(),
      source: this.name,
      volume,
      confidence: Math.min(volume / 1e9, 1),
    };
  }
}

export class CoinbaseSource {
  readonly name = 'Coinbase';
  private baseUrl = 'https://api.pro.coinbase.com';

  async fetchPrice(pair: string): Promise<PriceReport> {
    const [base, quote] = pair.split('/');
    const productId = `${base}-${quote}`;
    const url = `${this.baseUrl}/products/${productId}/ticker`;

    const res = await fetch(url);
    if (!res.ok) throw new Error(`Coinbase API error: ${res.status}`);

    const data = await res.json();
    const price = parseFloat(data.price);
    const volume = parseFloat(data.volume ?? '0') * price;

    return {
      pair,
      price,
      timestamp: Date.now(),
      source: this.name,
      volume,
      confidence: Math.min(volume / 5e8, 1),
    };
  }
}

export class KrakenSource {
  readonly name = 'Kraken';
  private baseUrl = 'https://api.kraken.com/0/public';

  async fetchPrice(pair: string): Promise<PriceReport> {
    const [base, quote] = pair.split('/');
    const pairMap: Record<string, string> = {
      'BTC/USD': 'XXBTZUSD',
      'ETH/USD': 'XETHZUSD',
      'BTC/EUR': 'XXBTZEUR',
      'ETH/EUR': 'XETHZEUR',
    };
    const krakenPair = pairMap[pair] ?? `${base}${quote}`;
    const url = `${this.baseUrl}/Ticker?pair=${krakenPair}`;

    const res = await fetch(url);
    if (!res.ok) throw new Error(`Kraken API error: ${res.status}`);

    const data = await res.json();
    if (data.error && data.error.length > 0) {
      throw new Error(`Kraken error: ${data.error.join(', ')}`);
    }

    const resultKeys = Object.keys(data.result).filter((k) => k !== 'last');
    const ticker = data.result[resultKeys[0]];
    const price = parseFloat(ticker.c[0]);
    const volume = parseFloat(ticker.v[1]) * price;

    return {
      pair,
      price,
      timestamp: Date.now(),
      source: this.name,
      volume,
      confidence: Math.min(volume / 3e8, 1),
    };
  }
}

export class UniswapV3Source {
  readonly name = 'Uniswap V3';
  private chainId: number;
  private twapHistory: Map<string, TWAPDataPoint[]> = new Map();

  constructor(chainId: number = 1) {
    this.chainId = chainId;
  }

  async fetchPrice(pair: string): Promise<PriceReport> {
    const quoterAddresses: Record<number, string> = {
      1: '0xb27308f9F90D607463bb33eA1BeBb41C27CE5AB6',
      137: '0x61fFE014bA17989E743c5F6cB21bF9697530B21e',
      42161: '0xb27308f9F90D607463bb33eA1BeBb41C27CE5AB6',
    };

    const feeBps = 3000;
    const sqrtPriceLimitX96 = pair.includes('BTC') ? 2n ** 32n : 2n ** 96n;

    void quoterAddresses;
    void feeBps;
    void sqrtPriceLimitX96;

    const basePrice = this.simulateDEXPrice(pair);
    const history = this.twapHistory.get(pair) ?? [];
    history.push({ price: basePrice, timestamp: Date.now(), volume: 1e6 });
    if (history.length > 100) history.shift();
    this.twapHistory.set(pair, history);

    const twap = calculateTWAP(history);

    return {
      pair,
      price: twap > 0 ? twap : basePrice,
      timestamp: Date.now(),
      source: `${this.name} (Chain ${this.chainId})`,
      volume: 1e6,
      confidence: 0.7,
    };
  }

  private simulateDEXPrice(pair: string): number {
    const basePrices: Record<string, number> = {
      'BTC/USD': 67500 + Math.random() * 200,
      'ETH/USD': 3450 + Math.random() * 30,
      'WBTC/ETH': 19.5 + Math.random() * 0.2,
    };
    return basePrices[pair] ?? 100 + Math.random() * 10;
  }

  getTWAPHistory(pair: string): TWAPDataPoint[] {
    return this.twapHistory.get(pair) ?? [];
  }
}

export class SushiSwapSource {
  readonly name = 'SushiSwap';
  private chainId: number;

  constructor(chainId: number = 1) {
    this.chainId = chainId;
  }

  async fetchPrice(pair: string): Promise<PriceReport> {
    const basePrice = this.simulateDEXPrice(pair);
    return {
      pair,
      price: basePrice,
      timestamp: Date.now(),
      source: `${this.name} (Chain ${this.chainId})`,
      volume: 5e5,
      confidence: 0.6,
    };
  }

  private simulateDEXPrice(pair: string): number {
    const basePrices: Record<string, number> = {
      'BTC/USD': 67480 + Math.random() * 250,
      'ETH/USD': 3445 + Math.random() * 40,
    };
    return basePrices[pair] ?? 99 + Math.random() * 12;
  }
}

export class DataSourceManager {
  private sources: { name: string; fetch: (pair: string) => Promise<PriceReport> }[] = [];

  constructor() {
    this.sources = [
      { name: 'Binance', fetch: (p) => new BinanceSource().fetchPrice(p) },
      { name: 'Coinbase', fetch: (p) => new CoinbaseSource().fetchPrice(p) },
      { name: 'Kraken', fetch: (p) => new KrakenSource().fetchPrice(p) },
      { name: 'Uniswap V3', fetch: (p) => new UniswapV3Source().fetchPrice(p) },
      { name: 'SushiSwap', fetch: (p) => new SushiSwapSource().fetchPrice(p) },
    ];
  }

  async fetchFromAll(pair: string): Promise<PriceReport[]> {
    const results = await Promise.allSettled(
      this.sources.map((s) => s.fetch(pair)),
    );

    return results
      .filter((r): r is PromiseFulfilledResult<PriceReport> => r.status === 'fulfilled')
      .map((r) => r.value);
  }

  async fetchWithRetry(pair: string, retries: number = 3): Promise<PriceReport[]> {
    for (let attempt = 0; attempt < retries; attempt++) {
      const reports = await this.fetchFromAll(pair);
      if (reports.length > 0) return reports;
    }
    return [];
  }
}
