import type {
  PriceReport,
  AggregatedPrice,
  CircuitBreakerConfig,
} from './types';

const DEFAULT_CB_CONFIG: CircuitBreakerConfig = {
  maxDeviationPercent: 15,
  cooldownMs: 60000,
  minSources: 2,
  maxStalenessMs: 120000,
  pauseOnTrigger: true,
};

export function weightedMedian(reports: PriceReport[]): number {
  if (reports.length === 0) return 0;
  if (reports.length === 1) return reports[0].price;

  const sorted = [...reports].sort((a, b) => a.price - b.price);
  const totalWeight = sorted.reduce((sum, r) => sum + r.confidence, 0);
  const halfWeight = totalWeight / 2;

  let cumulative = 0;
  for (const report of sorted) {
    cumulative += report.confidence;
    if (cumulative >= halfWeight) {
      return report.price;
    }
  }

  return sorted[Math.floor(sorted.length / 2)].price;
}

export function detectOutliers(
  reports: PriceReport[],
  thresholdPercent: number = 15,
): { valid: PriceReport[]; outliers: PriceReport[] } {
  if (reports.length < 3) {
    return { valid: reports, outliers: [] };
  }

  const prices = reports.map((r) => r.price);
  const median = simpleMedian(prices);
  const deviation = median * (thresholdPercent / 100);

  const valid: PriceReport[] = [];
  const outliers: PriceReport[] = [];

  for (const report of reports) {
    if (Math.abs(report.price - median) <= deviation) {
      valid.push(report);
    } else {
      outliers.push(report);
    }
  }

  return { valid, outliers };
}

export function simpleMedian(values: number[]): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 !== 0
    ? sorted[mid]
    : (sorted[mid - 1] + sorted[mid]) / 2;
}

export function standardDeviation(values: number[]): number {
  if (values.length === 0) return 0;
  const mean = values.reduce((sum, v) => sum + v, 0) / values.length;
  const squaredDiffs = values.map((v) => Math.pow(v - mean, 2));
  return Math.sqrt(
    squaredDiffs.reduce((sum, d) => sum + d, 0) / values.length,
  );
}

export function computeConfidence(reports: PriceReport[]): number {
  if (reports.length === 0) return 0;
  if (reports.length === 1) return reports[0].confidence * 0.5;

  const prices = reports.map((r) => r.price);
  const dev = standardDeviation(prices);
  const median = simpleMedian(prices);
  const coeffOfVariation = median > 0 ? dev / median : 1;

  const sourceBonus = Math.min(reports.length / 5, 1) * 0.3;
  const agreementBonus = Math.max(0, 1 - coeffOfVariation * 10) * 0.5;
  const volumeConfidence =
    reports.reduce((sum, r) => sum + r.confidence, 0) / reports.length * 0.2;

  return Math.min(sourceBonus + agreementBonus + volumeConfidence, 1);
}

export function aggregatePrices(
  reports: PriceReport[],
  pair: string,
  cbConfig: CircuitBreakerConfig = DEFAULT_CB_CONFIG,
): AggregatedPrice {
  const now = Date.now();
  const freshReports = reports.filter(
    (r) => now - r.timestamp < cbConfig.maxStalenessMs,
  );

  const { valid, outliers } = detectOutliers(
    freshReports,
    cbConfig.maxDeviationPercent,
  );

  if (valid.length < cbConfig.minSources) {
    return {
      pair,
      price: 0,
      timestamp: now,
      sources: [],
      weightedMedian: 0,
      standardDeviation: 0,
      confidence: 0,
      outlierCount: outliers.length,
    };
  }

  const wm = weightedMedian(valid);
  const prices = valid.map((r) => r.price);
  const dev = standardDeviation(prices);
  const conf = computeConfidence(valid);

  return {
    pair,
    price: wm,
    timestamp: now,
    sources: valid.map((r) => r.source),
    weightedMedian: wm,
    standardDeviation: dev,
    confidence: conf,
    outlierCount: outliers.length,
  };
}

export class CircuitBreaker {
  private config: CircuitBreakerConfig;
  private lastTriggered: Map<string, number> = new Map();
  private pausedFeeds: Set<string> = new Set();
  private previousPrices: Map<string, number> = new Map();

  constructor(config: CircuitBreakerConfig = DEFAULT_CB_CONFIG) {
    this.config = config;
  }

  check(pair: string, newPrice: number): {
    allowed: boolean;
    reason?: string;
  } {
    if (this.pausedFeeds.has(pair)) {
      const lastTrigger = this.lastTriggered.get(pair) ?? 0;
      if (Date.now() - lastTrigger < this.config.cooldownMs) {
        return { allowed: false, reason: 'circuit_breaker_cooldown' };
      }
      this.pausedFeeds.delete(pair);
    }

    const prev = this.previousPrices.get(pair);
    if (prev !== undefined && prev > 0) {
      const deviationPct = (Math.abs(newPrice - prev) / prev) * 100;
      if (deviationPct > this.config.maxDeviationPercent) {
        this.trigger(pair);
        return { allowed: false, reason: 'extreme_price_movement' };
      }
    }

    this.previousPrices.set(pair, newPrice);
    return { allowed: true };
  }

  trigger(pair: string): void {
    this.lastTriggered.set(pair, Date.now());
    if (this.config.pauseOnTrigger) {
      this.pausedFeeds.add(pair);
    }
  }

  isPaused(pair: string): boolean {
    return this.pausedFeeds.has(pair);
  }

  unpause(pair: string): void {
    this.pausedFeeds.delete(pair);
    this.lastTriggered.delete(pair);
  }

  emergencyPause(pairs?: string[]): void {
    const targets = pairs ?? Array.from(this.previousPrices.keys());
    for (const pair of targets) {
      this.pausedFeeds.add(pair);
      this.lastTriggered.set(pair, Date.now());
    }
  }
}
