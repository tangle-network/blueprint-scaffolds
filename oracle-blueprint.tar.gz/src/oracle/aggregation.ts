import { DataSourceResult, PricePoint } from './types';

export function weightedMedian(data: DataSourceResult[]): number {
  if (data.length === 0) return 0;
  if (data.length === 1) return data[0].price;

  const sorted = [...data].sort((a, b) => a.price - b.price);
  const totalWeight = sorted.reduce((sum, d) => sum + d.weight, 0);
  let cumulativeWeight = 0;

  for (const item of sorted) {
    cumulativeWeight += item.weight;
    if (cumulativeWeight >= totalWeight / 2) {
      return item.price;
    }
  }

  return sorted[Math.floor(sorted.length / 2)].price;
}

export function detectOutliers(
  data: DataSourceResult[],
  medianThreshold: number = 0.05
): { clean: DataSourceResult[]; outliers: DataSourceResult[] } {
  if (data.length < 3) return { clean: data, outliers: [] };

  const median = weightedMedian(data);
  const clean: DataSourceResult[] = [];
  const outliers: DataSourceResult[] = [];

  for (const point of data) {
    const deviation = Math.abs(point.price - median) / median;
    if (deviation > medianThreshold) {
      outliers.push(point);
    } else {
      clean.push(point);
    }
  }

  return { clean, outliers };
}

export function calculateConfidence(data: DataSourceResult[]): number {
  if (data.length === 0) return 0;
  if (data.length === 1) return 0.5;

  const prices = data.map(d => d.price);
  const mean = prices.reduce((a, b) => a + b, 0) / prices.length;
  const variance = prices.reduce((sum, p) => sum + Math.pow(p - mean, 2), 0) / prices.length;
  const stdDev = Math.sqrt(variance);
  const cv = stdDev / mean;

  const sourceScore = Math.min(data.length / 5, 1);
  const consistencyScore = Math.max(0, 1 - cv * 20);

  return (sourceScore * 0.4 + consistencyScore * 0.6);
}

export function checkCircuitBreaker(
  currentPrice: number,
  previousPrice: number,
  threshold: number
): { triggered: boolean; deviation: number } {
  if (previousPrice === 0) return { triggered: false, deviation: 0 };
  const deviation = Math.abs(currentPrice - previousPrice) / previousPrice * 100;
  return { triggered: deviation > threshold, deviation };
}

export function calculateTWAP(history: PricePoint[], windowMs: number): number {
  const now = Date.now();
  const cutoff = now - windowMs;
  const relevant = history.filter(p => p.timestamp >= cutoff);

  if (relevant.length === 0) return 0;
  if (relevant.length === 1) return relevant[0].price;

  let weightedSum = 0;
  let totalWeight = 0;

  for (let i = 1; i < relevant.length; i++) {
    const dt = relevant[i].timestamp - relevant[i - 1].timestamp;
    const avgPrice = (relevant[i].price + relevant[i - 1].price) / 2;
    weightedSum += avgPrice * dt;
    totalWeight += dt;
  }

  return totalWeight > 0 ? weightedSum / totalWeight : relevant[relevant.length - 1].price;
}

export function simulateThresholdSignature(data: string, threshold: number, totalParties: number): string {
  const hash = simpleHash(data);
  const signers = Math.min(threshold, totalParties);
  return `0x${hash.slice(0, 16)}...t${signers}/n${totalParties}`;
}

function simpleHash(input: string): string {
  let hash = 0;
  for (let i = 0; i < input.length; i++) {
    const char = input.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(16).padStart(32, '0');
}
