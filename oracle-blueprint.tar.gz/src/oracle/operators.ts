import { Operator } from '../types';

export class OperatorManager {
  private operators: Map<string, Operator> = new Map();
  private readonly MIN_STAKE = 1000;
  private readonly SLASH_PERCENT = 5;
  private readonly HEARTBEAT_TIMEOUT = 300_000;

  registerOperator(id: string, address: string, stake: number): { success: boolean; error?: string } {
    if (this.operators.has(id)) {
      return { success: false, error: 'Operator already registered' };
    }
    if (stake < this.MIN_STAKE) {
      return { success: false, error: `Minimum stake is ${this.MIN_STAKE}` };
    }
    this.operators.set(id, {
      id, address, stake, reputation: 100,
      isActive: true, lastHeartbeat: Date.now(),
      totalSubmissions: 0, successfulSubmissions: 0, slashCount: 0,
    });
    return { success: true };
  }

  submitHeartbeat(operatorId: string): boolean {
    const op = this.operators.get(operatorId);
    if (!op) return false;
    op.lastHeartbeat = Date.now();
    return true;
  }

  recordSubmission(operatorId: string, valid: boolean): void {
    const op = this.operators.get(operatorId);
    if (!op) return;
    op.totalSubmissions++;
    if (valid) {
      op.successfulSubmissions++;
      op.reputation = Math.min(100, op.reputation + 0.1);
    } else {
      this.slashOperator(operatorId, 'invalid_data');
    }
  }

  slashOperator(operatorId: string, reason: string): { slashed: boolean; amount: number } {
    const op = this.operators.get(operatorId);
    if (!op) return { slashed: false, amount: 0 };

    const slashAmount = op.stake * (this.SLASH_PERCENT / 100);
    op.stake -= slashAmount;
    op.slashCount++;
    op.reputation = Math.max(0, op.reputation - 10);

    if (op.stake < this.MIN_STAKE) {
      op.isActive = false;
    }

    return { slashed: true, amount: slashAmount };
  }

  checkHeartbeats(): string[] {
    const now = Date.now();
    const timedOut: string[] = [];
    for (const [id, op] of this.operators) {
      if (op.isActive && now - op.lastHeartbeat > this.HEARTBEAT_TIMEOUT) {
        timedOut.push(id);
      }
    }
    return timedOut;
  }

  getActiveOperators(): Operator[] {
    return Array.from(this.operators.values()).filter(op => op.isActive);
  }

  getOperator(id: string): Operator | undefined {
    return this.operators.get(id);
  }

  getAllOperators(): Operator[] {
    return Array.from(this.operators.values());
  }

  addStake(operatorId: string, amount: number): boolean {
    const op = this.operators.get(operatorId);
    if (!op) return false;
    op.stake += amount;
    if (op.stake >= this.MIN_STAKE && !op.isActive) {
      op.isActive = true;
    }
    return true;
  }
}
