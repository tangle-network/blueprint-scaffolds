import { PriceReport, AggregationConfig, PriceFeed, PricePoint, DEFAULT_AGGREGATION_CONFIG } from '../types';
import { DataSourceManager } from './datasources';
import { OperatorManager } from './operators';
import { CrossChainManager } from './crosschain';
import { weightedMedian, detectOutliers, calculateConfidence, checkCircuitBreaker, simulateThresholdSignature } from './aggregation';

export class OracleBlueprint {
  private dataSourceManager: DataSourceManager;
  private operatorManager: OperatorManager;
  private crossChainManager: CrossChainManager;
  private feeds: Map<string, PriceFeed> = new Map();
  private configs: Map<string, AggregationConfig> = new Map();
  private isPaused = false;
  private updateTimer: ReturnType<typeof setInterval> | null = null;

  constructor() {
    this.dataSourceManager = new DataSourceManager();
    this.operatorManager = new OperatorManager();
    this.crossChainManager = new CrossChainManager();
  }

  async startFeeds(pairs: string[], config?: Partial<AggregationConfig>): Promise<void> {
    for (const pair of pairs) {
      const cfg: AggregationConfig = { ...DEFAULT_AGGREGATION_CONFIG, ...config, pair };
      this.configs.set(pair, cfg);
      this.feeds.set(pair, {
        pair,
        currentPrice: 0,
        previousPrice: 0,
        change24h: 0,
        lastUpdate: 0,
        sources: [],
        isPaused: false,
        history: this.generateInitialHistory(pair),
      });
    }
    this.startUpdateLoop();
  }

  stopFeeds(): void {
    if (this.updateTimer) {
      clearInterval(this.updateTimer);
      this.updateTimer = null;
    }
  }

  async updatePrice(pair: string): Promise<PriceReport | null> {
    if (this.isPaused) return null;
    const feed = this.feeds.get(pair);
    const config = this.configs.get(pair);
    if (!feed || !config) return null;

    const rawData = await this.dataSourceManager.fetchAllSources(pair);
    if (rawData.length < config.minSources) return null;

    const { clean, outliers } = detectOutliers(rawData);
    if (clean.length < config.minSources) return null;

    const median = weightedMedian(clean);
    const confidence = calculateConfidence(clean);

    const circuitBreaker = checkCircuitBreaker(median, feed.currentPrice || median, config.circuitBreakerThreshold);
    if (circuitBreaker.triggered) {
      this.dataSourceManager.pause();
      feed.isPaused = true;
      return null;
    }

    const reportData = JSON.stringify({ pair, price: median, timestamp: Date.now(), sources: clean.length });
    const signature = simulateThresholdSignature(reportData, 3, 5);

    const report: PriceReport = {
      pair,
      price: median,
      timestamp: Date.now(),
      sources: clean,
      weightedMedian: median,
      confidence,
      signature,
    };

    feed.previousPrice = feed.currentPrice;
    feed.currentPrice = median;
    feed.lastUpdate = report.timestamp;
    feed.sources = clean.map(s => s.source);

    feed.history.push({ timestamp: report.timestamp, price: median, volume: clean.reduce((a, c) => a + c.volume, 0) });
    if (feed.history.length > 1000) feed.history = feed.history.slice(-500);

    await this.crossChainManager.broadcastPrice(pair, median, report.timestamp);

    return report;
  }

  getFeed(pair: string): PriceFeed | undefined {
    return this.feeds.get(pair);
  }

  getAllFeeds(): PriceFeed[] {
    return Array.from(this.feeds.values());
  }

  getDataSourceHealth() {
    return this.dataSourceManager.getHealthStatus();
  }

  getOperators() {
    return this.operatorManager;
  }

  getCrossChainStatus() {
    return this.crossChainManager.getDeploymentStatus();
  }

  pauseAll(): void {
    this.isPaused = true;
    this.dataSourceManager.pause();
  }

  resumeAll(): void {
    this.isPaused = false;
    this.dataSourceManager.resume();
    for (const feed of this.feeds.values()) {
      feed.isPaused = false;
    }
  }

  isSystemPaused(): boolean {
    return this.isPaused;
  }

  private startUpdateLoop(): void {
    this.updateTimer = setInterval(async () => {
      for (const [pair] of this.feeds) {
        await this.updatePrice(pair);
      }
    }, 5000);
  }

  private generateInitialHistory(pair: string): PricePoint[] {
    const basePrices: Record<string, number> = {
      'BTC/USD': 67432, 'ETH/USD': 3521, 'POL/USD': 0.584,
      'ARB/USD': 1.124, 'SOL/USD': 178, 'AVAX/USD': 38.9,
      'DOT/USD': 7.21, 'LINK/USD': 14.87,
    };
    const base = basePrices[pair] ?? 100;
    const history: PricePoint[] = [];
    const now = Date.now();
    for (let i = 100; i >= 0; i--) {
      const noise = (Math.random() - 0.5) * base * 0.01;
      const trend = Math.sin(i / 10) * base * 0.005;
      history.push({
        timestamp: now - i * 60000,
        price: base + noise + trend,
        volume: Math.random() * 1e7,
      });
    }
    return history;
  }
}

export const oracleBlueprint = new OracleBlueprint();
