import type {
  BlueprintDefinition,
  JobSchedule,
  DataSourceConfig,
  OracleFeed,
  CircuitBreakerConfig,
  PriceReport,
  AggregatedPrice,
  HealthStatus,
} from './types';
import { aggregatePrices, CircuitBreaker } from './aggregation';
import { SecurityManager } from './security';
import { DataSourceManager } from './sources';
import { CrossChainBridge } from './crosschain';
import type { ChainName } from './types';

const DEFAULT_BLUEPRINT: BlueprintDefinition = {
  name: 'Tangle Oracle Blueprint',
  version: '1.0.0',
  description: 'Decentralized oracle service for secure and verifiable price feeds',
  author: 'Tangle Network',
  jobs: [
    { id: 'btc-usd-1s', pair: 'BTC/USD', intervalMs: 1000, lastRun: 0, nextRun: 0, enabled: true },
    { id: 'eth-usd-1s', pair: 'ETH/USD', intervalMs: 1000, lastRun: 0, nextRun: 0, enabled: true },
    { id: 'btc-usd-60s', pair: 'BTC/USD', intervalMs: 60000, lastRun: 0, nextRun: 0, enabled: true },
    { id: 'eth-usd-60s', pair: 'ETH/USD', intervalMs: 60000, lastRun: 0, nextRun: 0, enabled: true },
  ],
  sources: [
    { name: 'Binance', type: 'cex', weight: 0.3, endpoint: 'https://api.binance.com/api/v3', enabled: true },
    { name: 'Coinbase', type: 'cex', weight: 0.25, endpoint: 'https://api.pro.coinbase.com', enabled: true },
    { name: 'Kraken', type: 'cex', weight: 0.2, endpoint: 'https://api.kraken.com/0/public', enabled: true },
    { name: 'Uniswap V3', type: 'dex', weight: 0.15, endpoint: 'on-chain', chainId: 1, enabled: true },
    { name: 'SushiSwap', type: 'dex', weight: 0.1, endpoint: 'on-chain', chainId: 1, enabled: true },
  ],
  feeds: [
    {
      pair: 'BTC/USD',
      decimals: 8,
      heartbeat: 60000,
      deviationThreshold: 0.5,
      chains: [
        { chain: 'ethereum', chainId: 1, contractAddress: '0x01', lastPush: 0, status: 'active' },
        { chain: 'polygon', chainId: 137, contractAddress: '0x02', lastPush: 0, status: 'active' },
        { chain: 'arbitrum', chainId: 42161, contractAddress: '0x03', lastPush: 0, status: 'active' },
      ],
      lastUpdate: 0,
      isPaused: false,
    },
    {
      pair: 'ETH/USD',
      decimals: 8,
      heartbeat: 60000,
      deviationThreshold: 0.5,
      chains: [
        { chain: 'ethereum', chainId: 1, contractAddress: '0x05', lastPush: 0, status: 'active' },
        { chain: 'polygon', chainId: 137, contractAddress: '0x06', lastPush: 0, status: 'active' },
        { chain: 'arbitrum', chainId: 42161, contractAddress: '0x07', lastPush: 0, status: 'active' },
      ],
      lastUpdate: 0,
      isPaused: false,
    },
  ],
  security: {
    maxDeviationPercent: 15,
    cooldownMs: 60000,
    minSources: 2,
    maxStalenessMs: 120000,
    pauseOnTrigger: true,
  },
};

export class JobScheduler {
  private jobs: Map<string, JobSchedule> = new Map();
  private timers: Map<string, ReturnType<typeof setInterval>> = new Map();
  private callbacks: Map<string, (job: JobSchedule) => Promise<void>> = new Map();

  addJob(job: JobSchedule, callback: (job: JobSchedule) => Promise<void>): void {
    this.jobs.set(job.id, { ...job });
    this.callbacks.set(job.id, callback);
  }

  startJob(jobId: string): void {
    const job = this.jobs.get(jobId);
    const cb = this.callbacks.get(jobId);
    if (!job || !cb) return;
    if (!job.enabled) return;

    job.nextRun = Date.now() + job.intervalMs;
    const timer = setInterval(async () => {
      job.lastRun = Date.now();
      job.nextRun = Date.now() + job.intervalMs;
      try {
        await cb(job);
      } catch {
        // log error
      }
    }, job.intervalMs);

    this.timers.set(jobId, timer);
  }

  stopJob(jobId: string): void {
    const timer = this.timers.get(jobId);
    if (timer) {
      clearInterval(timer);
      this.timers.delete(jobId);
    }
  }

  stopAll(): void {
    for (const [id] of this.timers) {
      this.stopJob(id);
    }
  }

  getJob(jobId: string): JobSchedule | undefined {
    return this.jobs.get(jobId);
  }

  getAllJobs(): JobSchedule[] {
    return Array.from(this.jobs.values());
  }

  enableJob(jobId: string): void {
    const job = this.jobs.get(jobId);
    if (job) {
      job.enabled = true;
      this.startJob(jobId);
    }
  }

  disableJob(jobId: string): void {
    const job = this.jobs.get(jobId);
    if (job) {
      job.enabled = false;
      this.stopJob(jobId);
    }
  }
}

export class OracleBlueprint {
  private definition: BlueprintDefinition;
  private scheduler: JobScheduler;
  private circuitBreaker: CircuitBreaker;
  private securityManager: SecurityManager;
  private sourceManager: DataSourceManager;
  private crossChainBridge: CrossChainBridge;
  private latestPrices: Map<string, AggregatedPrice> = new Map();
  private priceHistory: Map<string, AggregatedPrice[]> = new Map();
  private healthStatuses: Map<string, HealthStatus> = new Map();
  private isRunning = false;
  private listeners: Map<string, ((data: AggregatedPrice) => void)[]> = new Map();

  constructor(definition: BlueprintDefinition = DEFAULT_BLUEPRINT) {
    this.definition = definition;
    this.scheduler = new JobScheduler();
    this.circuitBreaker = new CircuitBreaker(definition.security);
    this.securityManager = new SecurityManager();
    this.sourceManager = new DataSourceManager();
    this.crossChainBridge = new CrossChainBridge('tangle');

    for (const job of definition.jobs) {
      this.scheduler.addJob(job, (j) => this.executeJob(j));
    }

    this.initHealthStatuses();
  }

  private initHealthStatuses(): void {
    for (const source of this.definition.sources) {
      this.healthStatuses.set(source.name, {
        source: source.name,
        status: 'healthy',
        latencyMs: 0,
        lastSuccess: Date.now(),
        errorCount: 0,
        uptime: 1,
      });
    }
  }

  async start(): Promise<void> {
    this.isRunning = true;
    for (const job of this.definition.jobs) {
      if (job.enabled) {
        this.scheduler.startJob(job.id);
      }
    }
  }

  stop(): void {
    this.isRunning = false;
    this.scheduler.stopAll();
  }

  getDefinition(): BlueprintDefinition {
    return this.definition;
  }

  getLatestPrice(pair: string): AggregatedPrice | undefined {
    return this.latestPrices.get(pair);
  }

  getAllLatestPrices(): Map<string, AggregatedPrice> {
    return new Map(this.latestPrices);
  }

  getPriceHistory(pair: string): AggregatedPrice[] {
    return this.priceHistory.get(pair) ?? [];
  }

  getHealthStatuses(): Map<string, HealthStatus> {
    return new Map(this.healthStatuses);
  }

  getSecurityManager(): SecurityManager {
    return this.securityManager;
  }

  getCircuitBreaker(): CircuitBreaker {
    return this.circuitBreaker;
  }

  getScheduler(): JobScheduler {
    return this.scheduler;
  }

  onPriceUpdate(pair: string, callback: (data: AggregatedPrice) => void): void {
    const existing = this.listeners.get(pair) ?? [];
    existing.push(callback);
    this.listeners.set(pair, existing);
  }

  async fetchAndAggregate(pair: string): Promise<AggregatedPrice> {
    const reports = await this.sourceManager.fetchFromAll(pair);
    const aggregated = aggregatePrices(reports, pair, this.definition.security);

    const cbResult = this.circuitBreaker.check(pair, aggregated.price);
    if (!cbResult.allowed) {
      aggregated.confidence = 0;
    }

    this.latestPrices.set(pair, aggregated);
    const history = this.priceHistory.get(pair) ?? [];
    history.push(aggregated);
    if (history.length > 1000) history.shift();
    this.priceHistory.set(pair, history);

    const listeners = this.listeners.get(pair) ?? [];
    for (const cb of listeners) {
      cb(aggregated);
    }

    return aggregated;
  }

  private async executeJob(job: JobSchedule): Promise<void> {
    try {
      const aggregated = await this.fetchAndAggregate(job.pair);

      if (aggregated.confidence > 0 && !this.circuitBreaker.isPaused(job.pair)) {
        const targetChains: ChainName[] = ['ethereum', 'polygon', 'arbitrum'];
        await this.crossChainBridge.pushPrice(job.pair, aggregated, targetChains);
      }
    } catch {
      const health = this.healthStatuses.get(job.pair);
      if (health) {
        health.errorCount++;
        health.status = health.errorCount > 5 ? 'down' : 'degraded';
      }
    }
  }

  emergencyPause(pairs?: string[]): void {
    this.circuitBreaker.emergencyPause(pairs);
  }

  emergencyUnpause(pair: string): void {
    this.circuitBreaker.unpause(pair);
  }
}

export { DEFAULT_BLUEPRINT };
export type { BlueprintDefinition as Blueprint };
