# AGENTS.md

## Goal

Build a decentralized oracle service using Tangle Blueprints for cross-chain data feeds. Job submission, operator consensus, result reporting.

## Stack

- Family: `tangle-blueprint`
- Layers: `capability:tangle-oracle`
- Partner: `tangle`

## Entry Points

- `oracle-blueprint-bin/src/main.rs`
- `oracle-blueprint-lib/src/lib.rs`
- `blueprint.json`
- `contracts/src/HelloBlueprint.sol`
- `Cargo.toml`

## Commands

- `cargo test -p oracle-blueprint-lib`
- `cargo build --release`

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
