import { expect } from "chai";
import { ethers } from "hardhat";

describe("SampleToken", function () {
  it("should deploy with correct initial supply", async function () {
    const initialSupply = 1_000_000;
    const SampleToken = await ethers.getContractFactory("SampleToken");
    const token = await SampleToken.deploy(initialSupply);
    await token.waitForDeployment();

    const totalSupply = await token.totalSupply();
    expect(ethers.formatEther(totalSupply)).to.equal("1000000.0");
  });

  it("should assign total supply to deployer", async function () {
    const [owner] = await ethers.getSigners();
    const initialSupply = 1_000_000;
    const SampleToken = await ethers.getContractFactory("SampleToken");
    const token = await SampleToken.deploy(initialSupply);
    await token.waitForDeployment();

    const ownerBalance = await token.balanceOf(owner.address);
    expect(ownerBalance).to.equal(await token.totalSupply());
  });

  it("should have correct name and symbol", async function () {
    const SampleToken = await ethers.getContractFactory("SampleToken");
    const token = await SampleToken.deploy(1000);
    await token.waitForDeployment();

    expect(await token.name()).to.equal("SampleToken");
    expect(await token.symbol()).to.equal("STK");
  });
});
