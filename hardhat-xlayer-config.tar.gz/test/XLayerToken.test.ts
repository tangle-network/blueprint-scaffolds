import { expect } from "chai";
import { ethers } from "hardhat";
import { HardhatEthersSigner } from "@nomicfoundation/hardhat-ethers/signers";
import { XLayerToken } from "../typechain-types";

describe("XLayerToken", function () {
  let token: XLayerToken;
  let owner: HardhatEthersSigner;
  let addr1: HardhatEthersSigner;
  let addr2: HardhatEthersSigner;

  const TOKEN_NAME = "X Layer Token";
  const TOKEN_SYMBOL = "XLT";
  const TOKEN_DECIMALS = 18;
  const INITIAL_SUPPLY = 1_000_000;
  const INITIAL_SUPPLY_WEI = BigInt(INITIAL_SUPPLY) * 10n ** BigInt(TOKEN_DECIMALS);

  beforeEach(async function () {
    [owner, addr1, addr2] = await ethers.getSigners();
    const factory = await ethers.getContractFactory("XLayerToken");
    token = await factory.deploy(TOKEN_NAME, TOKEN_SYMBOL, TOKEN_DECIMALS, INITIAL_SUPPLY);
    await token.waitForDeployment();
  });

  describe("Deployment", function () {
    it("should set the correct name and symbol", async function () {
      expect(await token.name()).to.equal(TOKEN_NAME);
      expect(await token.symbol()).to.equal(TOKEN_SYMBOL);
    });

    it("should set the correct decimals", async function () {
      expect(await token.decimals()).to.equal(TOKEN_DECIMALS);
    });

    it("should mint initial supply to deployer", async function () {
      expect(await token.totalSupply()).to.equal(INITIAL_SUPPLY_WEI);
      expect(await token.balanceOf(owner.address)).to.equal(INITIAL_SUPPLY_WEI);
    });

    it("should set owner correctly", async function () {
      expect(await token.owner()).to.equal(owner.address);
    });
  });

  describe("Transfers", function () {
    it("should transfer tokens between accounts", async function () {
      const amount = 100n;
      await token.transfer(addr1.address, amount);
      expect(await token.balanceOf(addr1.address)).to.equal(amount);
    });

    it("should fail if sender has insufficient balance", async function () {
      await expect(
        token.connect(addr1).transfer(addr2.address, 1n)
      ).to.be.revertedWithCustomError(token, "ERC20InsufficientBalance");
    });
  });

  describe("Minting", function () {
    it("should allow owner to mint tokens", async function () {
      const amount = 500n;
      await token.mint(addr1.address, amount);
      expect(await token.balanceOf(addr1.address)).to.equal(amount);
      expect(await token.totalSupply()).to.equal(INITIAL_SUPPLY_WEI + amount);
    });

    it("should revert if non-owner tries to mint", async function () {
      await expect(
        token.connect(addr1).mint(addr2.address, 100n)
      ).to.be.revertedWithCustomError(token, "OwnableUnauthorizedAccount");
    });
  });

  describe("Burning", function () {
    it("should allow any holder to burn their tokens", async function () {
      const amount = 500n;
      await token.burn(amount);
      expect(await token.balanceOf(owner.address)).to.equal(INITIAL_SUPPLY_WEI - amount);
      expect(await token.totalSupply()).to.equal(INITIAL_SUPPLY_WEI - amount);
    });

    it("should revert if burning more than balance", async function () {
      await expect(
        token.connect(addr1).burn(1n)
      ).to.be.revertedWithCustomError(token, "ERC20InsufficientBalance");
    });
  });
});
