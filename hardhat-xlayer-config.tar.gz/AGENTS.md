# AGENTS.md

Deploy smart contracts to X Layer using Hardhat. Network config, deploy tasks, verification scripts.

## What's here

This project was scaffolded by starter-foundry. The user's prompt drove the choices below — read their prompt first, it takes priority over everything in this file.

- **Family:** `hardhat-contracts`
- **Layers:** `framework:hardhat-ts`
- **Partner:** `xlayer`

### Architecture notes
- Hardhat TypeScript
- Contracts in contracts/
- Deploy tasks
- Hardhat config with network settings

## Getting started

```bash
npm run test
npm run deploy
```

Key files: `hardhat.config.ts`, `contracts/StarterToken.sol`, `scripts/deploy.ts`

## How to use this scaffold

This is a starting point, not a contract. You own every file.

- **Customize freely.** Replace components, change the layout, swap the color scheme — whatever fits the user's product.
- **The scaffold saves you setup time** — Tailwind, shadcn/ui, path aliases, and framework config are ready. Don't redo them.
- **Check `.starter-foundry/compose-report.json`** if you want to see which layer wrote which file.
- **Update this file** as the project evolves. Delete sections that no longer apply.
