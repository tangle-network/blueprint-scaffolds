import { ethers } from "hardhat";

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying contracts with account:", deployer.address);

  const balance = await ethers.provider.getBalance(deployer.address);
  console.log("Account balance (OKB):", ethers.formatEther(balance));

  const initialSupply = 1_000_000;
  const SampleToken = await ethers.getContractFactory("SampleToken");
  const token = await SampleToken.deploy(initialSupply);

  await token.waitForDeployment();
  const tokenAddress = await token.getAddress();

  console.log("SampleToken deployed to:", tokenAddress);
  console.log("Initial supply:", ethers.formatEther(await token.totalSupply()), "STK");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
