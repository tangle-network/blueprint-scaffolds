import { ethers } from "hardhat";

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying contracts with account:", deployer.address);

  const balance = await ethers.provider.getBalance(deployer.address);
  console.log("Account balance:", ethers.formatEther(balance), "OKB");

  const XLayerToken = await ethers.getContractFactory("XLayerToken");

  const name = "X Layer Token";
  const symbol = "XLT";
  const decimals = 18;
  const initialSupply = 1_000_000;

  console.log("Deploying XLayerToken...");
  const token = await XLayerToken.deploy(name, symbol, decimals, initialSupply);
  await token.waitForDeployment();

  const tokenAddress = await token.getAddress();
  console.log("XLayerToken deployed to:", tokenAddress);
  console.log(
    "Verify with: npx hardhat verify --network xlayer-testnet",
    tokenAddress,
    `"${name}"`,
    `"${symbol}"`,
    decimals.toString(),
    initialSupply.toString()
  );
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
