import hre from "hardhat";

async function main() {
  const tokenName = process.env.TOKEN_NAME || "XLayer Token";
  const tokenSymbol = process.env.TOKEN_SYMBOL || "XLT";
  const tokenDecimals = 18;
  const initialSupply = 1000000;

  console.log("Deploying XLayerToken...");
  console.log(`  Name: ${tokenName}`);
  console.log(`  Symbol: ${tokenSymbol}`);
  console.log(`  Decimals: ${tokenDecimals}`);
  console.log(`  Initial supply: ${initialSupply}`);
  console.log(`  Network: ${hre.network.name} (native token: OKB)`);

  const XLayerToken = await hre.ethers.getContractFactory("XLayerToken");
  const token = await XLayerToken.deploy(
    tokenName,
    tokenSymbol,
    tokenDecimals,
    initialSupply
  );

  await token.waitForDeployment();

  const address = await token.getAddress();
  console.log(`\nXLayerToken deployed to: ${address}`);

  const signer = (await hre.ethers.getSigners())[0];
  const balance = await token.balanceOf(signer.address);
  console.log(
    `Deployer (${signer.address}) balance: ${hre.ethers.formatUnits(balance, tokenDecimals)} ${tokenSymbol}`
  );
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
