import { task } from "hardhat/config";
import { ethers } from "hardhat";

task("deploy-erc20", "Deploys the SampleToken ERC20 contract")
  .addOptionalParam("supply", "Initial token supply", "1000000")
  .setAction(async (taskArgs, hre) => {
    const [deployer] = await hre.ethers.getSigners();
    console.log("Deploying SampleToken on network:", hre.network.name);
    console.log("Deployer:", deployer.address);

    const balance = await hre.ethers.provider.getBalance(deployer.address);
    console.log("Deployer balance (OKB):", hre.ethers.formatEther(balance));

    const SampleToken = await hre.ethers.getContractFactory("SampleToken");
    const token = await SampleToken.deploy(taskArgs.supply);
    await token.waitForDeployment();

    const address = await token.getAddress();
    console.log("SampleToken deployed to:", address);
    console.log("Total supply:", hre.ethers.formatEther(await token.totalSupply()), "STK");

    if (hre.network.name !== "hardhat") {
      console.log("Waiting 10 blocks before verifying...");
      await token.deploymentTransaction()!.wait(10);

      try {
        await hre.run("verify:verify", {
          address,
          constructorArguments: [taskArgs.supply],
        });
        console.log("Contract verified on explorer");
      } catch (e: any) {
        console.log("Verification failed or already verified:", e.message);
      }
    }
  });
