import { task } from "hardhat/config";
import { HardhatRuntimeEnvironment } from "hardhat/types";

task("deploy", "Deploy the XLayerToken ERC20 contract")
  .addOptionalParam("name", "Token name", "XLayer Token")
  .addOptionalParam("symbol", "Token symbol", "XLT")
  .addOptionalParam("decimals", "Token decimals", "18")
  .addOptionalParam("supply", "Initial supply (in whole tokens)", "1000000")
  .setAction(
    async (
      taskArgs: {
        name: string;
        symbol: string;
        decimals: string;
        supply: string;
      },
      hre: HardhatRuntimeEnvironment
    ) => {
      const { name, symbol, decimals, supply } = taskArgs;

      console.log(`Deploying ${name} (${symbol}) to X Layer...`);
      console.log(`Decimals: ${decimals}, Initial supply: ${supply}`);

      const XLayerToken = await hre.ethers.getContractFactory("XLayerToken");
      const token = await XLayerToken.deploy(
        name,
        symbol,
        parseInt(decimals, 10),
        BigInt(supply)
      );

      await token.waitForDeployment();

      const address = await token.getAddress();
      console.log(`${symbol} deployed to: ${address}`);

      const signer = (await hre.ethers.getSigners())[0];
      console.log(`Deployer: ${signer.address}`);

      const balance = await token.balanceOf(signer.address);
      console.log(
        `Deployer balance: ${hre.ethers.formatUnits(balance, parseInt(decimals, 10))} ${symbol}`
      );

      const network = hre.network.name;
      const chainId = (await hre.ethers.provider.getNetwork()).chainId;
      console.log(`Network: ${network} (chainId: ${chainId})`);

      if (network === "xlayer" || network === "xlayerTestnet") {
        console.log(
          `\nTo verify on OKLink explorer, run:\n  npx hardhat verify --network ${network} ${address} "${name}" "${symbol}" ${decimals} ${supply}`
        );
      }

      return { address, name, symbol, decimals, supply };
    }
  );
