import { task } from "hardhat/config";
import { ethers } from "hardhat";

task("deploy-erc20", "Deploy an ERC20 token to X Layer")
  .addOptionalParam("name", "Token name", "X Layer Token")
  .addOptionalParam("symbol", "Token symbol", "XLT")
  .addOptionalParam("decimals", "Token decimals", "18")
  .addOptionalParam("supply", "Initial supply", "1000000")
  .setAction(async (args, hre) => {
    const [deployer] = await hre.ethers.getSigners();
    console.log("Deploying with account:", deployer.address);

    const balance = await hre.ethers.provider.getBalance(deployer.address);
    console.log("Balance:", hre.ethers.formatEther(balance), "OKB");

    const XLayerToken = await hre.ethers.getContractFactory("XLayerToken");

    console.log("Deploying token:", args.name, `(${args.symbol})`);
    const token = await XLayerToken.deploy(
      args.name,
      args.symbol,
      parseInt(args.decimals),
      parseInt(args.supply)
    );
    await token.waitForDeployment();

    const address = await token.getAddress();
    console.log("Token deployed to:", address);

    console.log("Waiting 5 blocks before verification...");
    await token.deploymentTransaction()!.wait(5);

    try {
      await hre.run("verify:verify", {
        address,
        constructorArguments: [
          args.name,
          args.symbol,
          parseInt(args.decimals),
          parseInt(args.supply),
        ],
      });
      console.log("Contract verified on explorer");
    } catch (err: any) {
      if (err.message.includes("already verified")) {
        console.log("Contract already verified");
      } else {
        console.error("Verification failed:", err.message);
      }
    }
  });
