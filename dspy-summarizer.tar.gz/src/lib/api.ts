const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:8000"

export interface SummarizeRequest {
  documents: string[]
  mode: "extractive" | "abstractive"
  style: "concise" | "detailed" | "technical" | "casual"
  max_length: number
}

export interface SummarizeResponse {
  summary: string
  key_points: string[]
  timeline: { event: string; date: string }[]
}

export interface CompareResponse {
  extractive: {
    summary: string
    score: number
  }
  abstractive: {
    summary: string
    score: number
  }
}

export interface HealthResponse {
  status: string
  version: string
}

export async function summarize(req: SummarizeRequest): Promise<SummarizeResponse> {
  const res = await fetch(`${API_BASE}/api/summarize`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(req),
  })
  if (!res.ok) throw new Error(`Summarize failed: ${res.statusText}`)
  return res.json()
}

export async function compare(documents: string[]): Promise<CompareResponse> {
  const res = await fetch(`${API_BASE}/api/compare`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ documents }),
  })
  if (!res.ok) throw new Error(`Compare failed: ${res.statusText}`)
  return res.json()
}

export async function healthCheck(): Promise<HealthResponse> {
  const res = await fetch(`${API_BASE}/api/health`)
  if (!res.ok) throw new Error(`Health check failed: ${res.statusText}`)
  return res.json()
}
