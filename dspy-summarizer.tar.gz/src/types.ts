export interface SummarizeRequest {
  documents: string[]
  mode: 'extractive' | 'abstractive' | 'hybrid'
  style: 'neutral' | 'academic' | 'journalistic' | 'casual' | 'technical'
  target_length: 'short' | 'medium' | 'long' | 'custom'
  custom_length?: number
  extract_key_points: boolean
  generate_timeline: boolean
  multi_document: boolean
}

export interface SummaryResponse {
  summary: string
  key_points: string[]
  timeline: TimelineEntry[]
  scores: ScoreBreakdown
  mode: string
  style: string
  word_count: number
  original_word_count: number
  compression_ratio: number
}

export interface TimelineEntry {
  date: string
  event: string
}

export interface ScoreBreakdown {
  rouge_1: number
  rouge_2: number
  rouge_l: number
  bertscore_f1: number
}

export interface ComparisonItem {
  id: string
  label: string
  config: SummarizeRequest
  response: SummaryResponse
}

export type TabId = 'upload' | 'results' | 'comparison' | 'history'
