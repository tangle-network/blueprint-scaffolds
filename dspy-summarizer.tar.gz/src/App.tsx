import { useState } from 'react'
import { TabId, SummarizeRequest, SummaryResponse, ComparisonItem } from './types'
import { Header } from './components/Header'
import { Sidebar } from './components/Sidebar'
import { UploadPanel } from './components/UploadPanel'
import { ResultsPanel } from './components/ResultsPanel'
import { ComparisonPanel } from './components/ComparisonPanel'
import { HistoryPanel } from './components/HistoryPanel'

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>('upload')
  const [latestResult, setLatestResult] = useState<SummaryResponse | null>(null)
  const [latestRequest, setLatestRequest] = useState<SummarizeRequest | null>(null)
  const [comparisons, setComparisons] = useState<ComparisonItem[]>([])
  const [history, setHistory] = useState<SummaryResponse[]>([])
  const [isProcessing, setIsProcessing] = useState(false)

  const handleResult = (request: SummarizeRequest, response: SummaryResponse) => {
    setLatestRequest(request)
    setLatestResult(response)
    setHistory(prev => [response, ...prev])
    setActiveTab('results')
  }

  const addToComparison = (item: ComparisonItem) => {
    setComparisons(prev => [...prev, item])
  }

  const removeFromComparison = (id: string) => {
    setComparisons(prev => prev.filter(c => c.id !== id))
  }

  const renderPanel = () => {
    switch (activeTab) {
      case 'upload':
        return (
          <UploadPanel
            onResult={handleResult}
            isProcessing={isProcessing}
            setIsProcessing={setIsProcessing}
          />
        )
      case 'results':
        return (
          <ResultsPanel
            result={latestResult}
            request={latestRequest}
            onAddToComparison={addToComparison}
          />
        )
      case 'comparison':
        return (
          <ComparisonPanel
            items={comparisons}
            onRemove={removeFromComparison}
          />
        )
      case 'history':
        return (
          <HistoryPanel
            history={history}
            onSelect={(r) => { setLatestResult(r); setActiveTab('results') }}
          />
        )
      default:
        return null
    }
  }

  return (
    <div className="h-screen flex flex-col overflow-hidden">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar activeTab={activeTab} onTabChange={setActiveTab} comparisonCount={comparisons.length} />
        <main className="flex-1 overflow-y-auto p-6 scrollbar-thin">
          {renderPanel()}
        </main>
      </div>
    </div>
  )
}
