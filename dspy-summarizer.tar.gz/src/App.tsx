import { Routes, Route } from "react-router-dom"
import HomePage from "./pages/HomePage"
import SummarizePage from "./pages/SummarizePage"
import ComparePage from "./pages/ComparePage"

export default function App() {
  return (
    <div className="min-h-screen bg-background">
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/summarize" element={<SummarizePage />} />
        <Route path="/compare" element={<ComparePage />} />
      </Routes>
    </div>
  )
}
