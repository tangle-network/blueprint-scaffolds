import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ListChecks } from "lucide-react"

interface KeyPointsListProps {
  points: string[]
}

export default function KeyPointsList({ points }: KeyPointsListProps) {
  if (points.length === 0) return null

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ListChecks className="h-5 w-5" />
          Key Points
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="grid gap-3">
          {points.map((point, i) => (
            <li key={i} className="flex items-start gap-3">
              <Badge variant="outline" className="mt-0.5 shrink-0">
                {i + 1}
              </Badge>
              <span className="text-sm leading-relaxed">{point}</span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}
