import { FileText } from 'lucide-react'
import { SummaryResponse } from '../types'

interface Props {
  history: SummaryResponse[]
  onSelect: (item: SummaryResponse) => void
}

export function HistoryPanel({ history, onSelect }: Props) {
  if (history.length === 0) {
    return (
      <div className="flex items-center justify-center h-full text-surface-500">
        <p>No history yet. Summarize some documents first.</p>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-white">History</h2>
        <p className="text-surface-400 mt-1">{history.length} summaries generated</p>
      </div>

      <div className="space-y-3">
        {history.map((item, idx) => (
          <button
            key={idx}
            onClick={() => onSelect(item)}
            className="w-full text-left bg-surface-800 border border-surface-700 rounded-xl p-4 hover:border-surface-600 transition-colors"
          >
            <div className="flex items-center gap-3 mb-2">
              <FileText className="w-4 h-4 text-primary-400" />
              <span className="text-sm font-medium text-surface-200">
                {item.mode} &middot; {item.style}
              </span>
              <span className="text-xs text-surface-500 ml-auto">
                {item.word_count} words &middot; ROUGE-L: {(item.scores.rouge_l * 100).toFixed(1)}%
              </span>
            </div>
            <p className="text-sm text-surface-400 line-clamp-2">{item.summary.slice(0, 200)}...</p>
          </button>
        ))}
      </div>
    </div>
  )
}
