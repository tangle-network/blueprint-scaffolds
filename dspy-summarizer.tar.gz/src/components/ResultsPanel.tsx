import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Legend } from 'recharts'
import { Download, GitCompare, List, Clock } from 'lucide-react'
import { SummaryResponse, SummarizeRequest, ComparisonItem } from '../types'
import { formatScore, generateId, cn } from '../utils'

interface Props {
  result: SummaryResponse | null
  request: SummarizeRequest | null
  onAddToComparison: (item: ComparisonItem) => void
}

function ScoreCard({ label, score }: { label: string; score: number }) {
  const pct = (score * 100).toFixed(1)
  return (
    <div className="bg-surface-700/50 rounded-lg p-4 text-center">
      <div className="text-2xl font-bold text-white">{pct}%</div>
      <div className="text-xs text-surface-400 mt-1">{label}</div>
    </div>
  )
}

export function ResultsPanel({ result, request, onAddToComparison }: Props) {
  if (!result) {
    return (
      <div className="flex items-center justify-center h-full text-surface-500">
        <p>No results yet. Upload and summarize documents first.</p>
      </div>
    )
  }

  const barData = [
    { name: 'ROUGE-1', value: result.scores.rouge_1 * 100 },
    { name: 'ROUGE-2', value: result.scores.rouge_2 * 100 },
    { name: 'ROUGE-L', value: result.scores.rouge_l * 100 },
    { name: 'BERTScore', value: result.scores.bertscore_f1 * 100 },
  ]

  const radarData = [
    { metric: 'ROUGE-1', score: result.scores.rouge_1 * 100 },
    { metric: 'ROUGE-2', score: result.scores.rouge_2 * 100 },
    { metric: 'ROUGE-L', score: result.scores.rouge_l * 100 },
    { metric: 'BERTScore', score: result.scores.bertscore_f1 * 100 },
  ]

  const handleCompare = () => {
    if (!request || !result) return
    onAddToComparison({
      id: generateId(),
      label: `${result.mode} / ${result.style}`,
      config: request,
      response: result,
    })
  }

  const handleExport = () => {
    const blob = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'summary-result.json'
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Summary Results</h2>
          <p className="text-surface-400 mt-1">
            {result.mode} mode &middot; {result.style} style &middot; {result.word_count} words
            ({result.compression_ratio.toFixed(0)}% compression)
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={handleCompare}
            className="flex items-center gap-2 px-3 py-2 bg-surface-700 rounded-lg text-sm text-surface-300 hover:bg-surface-600"
          >
            <GitCompare className="w-4 h-4" /> Compare
          </button>
          <button
            onClick={handleExport}
            className="flex items-center gap-2 px-3 py-2 bg-surface-700 rounded-lg text-sm text-surface-300 hover:bg-surface-600"
          >
            <Download className="w-4 h-4" /> Export
          </button>
        </div>
      </div>

      <div className="bg-surface-800 border border-surface-700 rounded-xl p-5">
        <h3 className="text-sm font-semibold text-surface-300 mb-3">Summary</h3>
        <div className="text-surface-200 leading-relaxed whitespace-pre-wrap">{result.summary}</div>
      </div>

      {result.key_points.length > 0 && (
        <div className="bg-surface-800 border border-surface-700 rounded-xl p-5">
          <h3 className="flex items-center gap-2 text-sm font-semibold text-surface-300 mb-3">
            <List className="w-4 h-4" /> Key Points
          </h3>
          <ul className="space-y-2">
            {result.key_points.map((point, i) => (
              <li key={i} className="flex gap-3 text-sm text-surface-200">
                <span className="text-primary-400 font-bold shrink-0">{i + 1}.</span>
                <span>{point}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {result.timeline.length > 0 && (
        <div className="bg-surface-800 border border-surface-700 rounded-xl p-5">
          <h3 className="flex items-center gap-2 text-sm font-semibold text-surface-300 mb-3">
            <Clock className="w-4 h-4" /> Timeline
          </h3>
          <div className="space-y-3">
            {result.timeline.map((entry, i) => (
              <div key={i} className="flex gap-4 items-start">
                <div className="w-28 shrink-0 text-sm font-mono text-primary-400">{entry.date}</div>
                <div className="w-2 h-2 rounded-full bg-primary-500 mt-1.5 shrink-0" />
                <div className="text-sm text-surface-200">{entry.event}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-6">
        <div className="bg-surface-800 border border-surface-700 rounded-xl p-5">
          <h3 className="text-sm font-semibold text-surface-300 mb-4">Quality Scores</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={barData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="name" tick={{ fill: '#94a3b8', fontSize: 12 }} />
              <YAxis domain={[0, 100]} tick={{ fill: '#94a3b8', fontSize: 12 }} />
              <Tooltip
                contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 8 }}
                labelStyle={{ color: '#e2e8f0' }}
                formatter={(v: number) => [v.toFixed(1), 'Score']}
              />
              <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-surface-800 border border-surface-700 rounded-xl p-5">
          <h3 className="text-sm font-semibold text-surface-300 mb-4">Score Radar</h3>
          <ResponsiveContainer width="100%" height={220}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="#334155" />
              <PolarAngleAxis dataKey="metric" tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <PolarRadiusAxis domain={[0, 100]} tick={{ fill: '#64748b', fontSize: 10 }} />
              <Radar name="Scores" dataKey="score" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.2} />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-3">
        <ScoreCard label="ROUGE-1" score={result.scores.rouge_1} />
        <ScoreCard label="ROUGE-2" score={result.scores.rouge_2} />
        <ScoreCard label="ROUGE-L" score={result.scores.rouge_l} />
        <ScoreCard label="BERTScore F1" score={result.scores.bertscore_f1} />
      </div>
    </div>
  )
}
