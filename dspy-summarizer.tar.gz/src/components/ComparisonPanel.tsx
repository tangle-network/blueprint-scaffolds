import { X } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts'
import { ComparisonItem } from '../types'
import { cn } from '../utils'

interface Props {
  items: ComparisonItem[]
  onRemove: (id: string) => void
}

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6']

export function ComparisonPanel({ items, onRemove }: Props) {
  if (items.length === 0) {
    return (
      <div className="flex items-center justify-center h-full text-surface-500">
        <p>Add results to comparison from the Results panel.</p>
      </div>
    )
  }

  const metrics = ['rouge_1', 'rouge_2', 'rouge_l', 'bertscore_f1'] as const
  const metricLabels: Record<string, string> = {
    rouge_1: 'ROUGE-1',
    rouge_2: 'ROUGE-2',
    rouge_l: 'ROUGE-L',
    bertscore_f1: 'BERTScore',
  }

  const chartData = metrics.map(m => {
    const row: Record<string, string | number> = { name: metricLabels[m] }
    items.forEach((item, idx) => {
      row[item.label] = (item.response.scores as any)[m] * 100
    })
    return row
  })

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-white">Comparison</h2>
        <p className="text-surface-400 mt-1">Compare summaries side by side</p>
      </div>

      <div className="bg-surface-800 border border-surface-700 rounded-xl p-5">
        <h3 className="text-sm font-semibold text-surface-300 mb-4">Score Comparison</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData} barCategoryGap="20%">
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
            <XAxis dataKey="name" tick={{ fill: '#94a3b8', fontSize: 12 }} />
            <YAxis domain={[0, 100]} tick={{ fill: '#94a3b8', fontSize: 12 }} />
            <Tooltip
              contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 8 }}
              labelStyle={{ color: '#e2e8f0' }}
              formatter={(v: number) => [v.toFixed(1), '']}
            />
            <Legend />
            {items.map((item, idx) => (
              <Bar key={item.id} dataKey={item.label} fill={COLORS[idx % COLORS.length]} radius={[4, 4, 0, 0]} />
            ))}
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="space-y-4">
        {items.map((item, idx) => (
          <div key={item.id} className="bg-surface-800 border border-surface-700 rounded-xl p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full" style={{ background: COLORS[idx % COLORS.length] }} />
                <h4 className="text-sm font-semibold text-surface-200">{item.label}</h4>
                <span className="text-xs text-surface-500">
                  {item.response.word_count} words &middot; {item.response.compression_ratio.toFixed(0)}% compression
                </span>
              </div>
              <button onClick={() => onRemove(item.id)} className="text-surface-500 hover:text-red-400">
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-sm text-surface-300 leading-relaxed whitespace-pre-wrap">{item.response.summary}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
