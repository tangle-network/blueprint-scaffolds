import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { FileText } from "lucide-react"

interface SummaryResultProps {
  summary: string
  mode: "extractive" | "abstractive"
  style: string
}

export default function SummaryResult({ summary, mode, style }: SummaryResultProps) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Summary
          </CardTitle>
          <div className="flex gap-2">
            <Badge variant="default">{mode}</Badge>
            <Badge variant="secondary">{style}</Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Separator className="mb-4" />
        <div className="prose prose-sm max-w-none">
          <p className="text-sm leading-relaxed whitespace-pre-wrap">{summary}</p>
        </div>
      </CardContent>
    </Card>
  )
}
