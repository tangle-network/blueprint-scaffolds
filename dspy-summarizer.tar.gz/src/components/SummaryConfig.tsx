import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { Settings } from "lucide-react"

interface SummaryConfigProps {
  mode: "extractive" | "abstractive"
  onModeChange: (mode: "extractive" | "abstractive") => void
  style: "concise" | "detailed" | "technical" | "casual"
  onStyleChange: (style: "concise" | "detailed" | "technical" | "casual") => void
  maxLength: number
  onMaxLengthChange: (length: number) => void
}

export default function SummaryConfig({
  mode,
  onModeChange,
  style,
  onStyleChange,
  maxLength,
  onMaxLengthChange,
}: SummaryConfigProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="h-5 w-5" />
          Configuration
        </CardTitle>
        <CardDescription>Configure summarization mode, style, and output length</CardDescription>
      </CardHeader>
      <CardContent className="grid gap-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="grid gap-2">
            <label className="text-sm font-medium">Summarization Mode</label>
            <Select value={mode} onValueChange={(v) => onModeChange(v as "extractive" | "abstractive")}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="extractive">Extractive</SelectItem>
                <SelectItem value="abstractive">Abstractive</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              {mode === "extractive"
                ? "Selects key sentences from source documents"
                : "Generates new text using DSPy ChainOfThought"}
            </p>
          </div>

          <div className="grid gap-2">
            <label className="text-sm font-medium">Output Style</label>
            <Select value={style} onValueChange={(v) => onStyleChange(v as any)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="concise">Concise</SelectItem>
                <SelectItem value="detailed">Detailed</SelectItem>
                <SelectItem value="technical">Technical</SelectItem>
                <SelectItem value="casual">Casual</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">Adapts tone and vocabulary of the output</p>
          </div>
        </div>

        <div className="grid gap-2">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium">Max Length</label>
            <Badge variant="outline">{maxLength} words</Badge>
          </div>
          <Slider
            value={[maxLength]}
            onValueChange={([v]) => onMaxLengthChange(v)}
            min={50}
            max={500}
            step={10}
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>50 words</span>
            <span>500 words</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
