import { useCallback } from "react"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Plus, Trash2, FileText } from "lucide-react"

interface FileUploadProps {
  documents: string[]
  onDocumentsChange: (docs: string[]) => void
}

export default function FileUpload({ documents, onDocumentsChange }: FileUploadProps) {
  const addDocument = useCallback(() => {
    onDocumentsChange([...documents, ""])
  }, [documents, onDocumentsChange])

  const updateDocument = useCallback(
    (index: number, value: string) => {
      const updated = [...documents]
      updated[index] = value
      onDocumentsChange(updated)
    },
    [documents, onDocumentsChange]
  )

  const removeDocument = useCallback(
    (index: number) => {
      onDocumentsChange(documents.filter((_, i) => i !== index))
    },
    [documents, onDocumentsChange]
  )

  const handleFileUpload = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = e.target.files
      if (!files) return
      Array.from(files).forEach((file) => {
        const reader = new FileReader()
        reader.onload = (event) => {
          const text = event.target?.result as string
          if (text) {
            onDocumentsChange([...documents, text])
          }
        }
        reader.readAsText(file)
      })
      e.target.value = ""
    },
    [documents, onDocumentsChange]
  )

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Documents
        </CardTitle>
        <CardDescription>
          Upload text files or paste document content directly
        </CardDescription>
      </CardHeader>
      <CardContent className="grid gap-4">
        <div className="flex gap-2">
          <Button variant="outline" size="sm" asChild>
            <label className="cursor-pointer">
              <Plus className="h-4 w-4 mr-1" />
              Upload Files
              <input type="file" className="hidden" multiple accept=".txt,.md,.csv" onChange={handleFileUpload} />
            </label>
          </Button>
          <Button variant="outline" size="sm" onClick={addDocument}>
            <Plus className="h-4 w-4 mr-1" />
            Add Text
          </Button>
        </div>

        {documents.map((doc, i) => (
          <div key={i} className="grid gap-2">
            <div className="flex items-center justify-between">
              <Badge variant="secondary">Document {i + 1}</Badge>
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">{doc.length} chars</span>
                <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => removeDocument(i)}>
                  <Trash2 className="h-3 w-3" />
                </Button>
              </div>
            </div>
            <Textarea
              placeholder="Paste document text here..."
              value={doc}
              onChange={(e) => updateDocument(i, e.target.value)}
              rows={5}
            />
          </div>
        ))}

        {documents.length === 0 && (
          <p className="text-sm text-muted-foreground text-center py-4">
            No documents added yet. Upload files or add text to begin.
          </p>
        )}
      </CardContent>
    </Card>
  )
}
