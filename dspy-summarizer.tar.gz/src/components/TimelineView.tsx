import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock } from "lucide-react"

interface TimelineViewProps {
  timeline: { event: string; date: string }[]
}

export default function TimelineView({ timeline }: TimelineViewProps) {
  if (timeline.length === 0) return null

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="h-5 w-5" />
          Timeline
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="relative pl-6">
          <div className="absolute left-2 top-0 bottom-0 w-0.5 bg-border" />
          <div className="grid gap-4">
            {timeline.map((item, i) => (
              <div key={i} className="relative flex items-start gap-3">
                <div className="absolute -left-4 mt-1 h-3 w-3 rounded-full bg-primary" />
                <Badge variant="secondary" className="shrink-0 mt-0">
                  {item.date}
                </Badge>
                <span className="text-sm leading-relaxed">{item.event}</span>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
