import { Upload, BarChart3, GitCompare, Clock } from 'lucide-react'
import { TabId } from '../types'
import { cn } from '../utils'

interface SidebarProps {
  activeTab: TabId
  onTabChange: (tab: TabId) => void
  comparisonCount: number
}

const tabs: { id: TabId; label: string; icon: React.ReactNode }[] = [
  { id: 'upload', label: 'Upload', icon: <Upload className="w-4 h-4" /> },
  { id: 'results', label: 'Results', icon: <BarChart3 className="w-4 h-4" /> },
  { id: 'comparison', label: 'Compare', icon: <GitCompare className="w-4 h-4" /> },
  { id: 'history', label: 'History', icon: <Clock className="w-4 h-4" /> },
]

export function Sidebar({ activeTab, onTabChange, comparisonCount }: SidebarProps) {
  return (
    <nav className="w-56 bg-surface-800 border-r border-surface-700 shrink-0">
      <div className="p-3 space-y-1">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={cn(
              'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors',
              activeTab === tab.id
                ? 'bg-primary-600/20 text-primary-400'
                : 'text-surface-400 hover:bg-surface-700 hover:text-surface-200'
            )}
          >
            {tab.icon}
            <span>{tab.label}</span>
            {tab.id === 'comparison' && comparisonCount > 0 && (
              <span className="ml-auto bg-primary-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {comparisonCount}
              </span>
            )}
          </button>
        ))}
      </div>
    </nav>
  )
}
