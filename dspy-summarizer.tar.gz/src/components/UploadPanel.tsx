import { useState, useCallback } from 'react'
import { Upload, FileText, X, Loader2, Settings2 } from 'lucide-react'
import { SummarizeRequest } from '../types'
import { summarizeDocuments } from '../api'
import { readFileAsText, generateId, cn } from '../utils'

interface Props {
  onResult: (req: SummarizeRequest, res: import('../types').SummaryResponse) => void
  isProcessing: boolean
  setIsProcessing: (v: boolean) => void
}

const MODES = [
  { value: 'extractive' as const, label: 'Extractive', desc: 'Key sentences from source' },
  { value: 'abstractive' as const, label: 'Abstractive', desc: 'Generated in new words' },
  { value: 'hybrid' as const, label: 'Hybrid', desc: 'Combined approach' },
]

const STYLES = [
  { value: 'neutral' as const, label: 'Neutral' },
  { value: 'academic' as const, label: 'Academic' },
  { value: 'journalistic' as const, label: 'Journalistic' },
  { value: 'casual' as const, label: 'Casual' },
  { value: 'technical' as const, label: 'Technical' },
]

const LENGTHS = [
  { value: 'short' as const, label: 'Short (~100 words)' },
  { value: 'medium' as const, label: 'Medium (~250 words)' },
  { value: 'long' as const, label: 'Long (~500 words)' },
  { value: 'custom' as const, label: 'Custom' },
]

export function UploadPanel({ onResult, isProcessing, setIsProcessing }: Props) {
  const [documents, setDocuments] = useState<{ id: string; name: string; text: string }[]>([])
  const [pasteText, setPasteText] = useState('')
  const [mode, setMode] = useState<SummarizeRequest['mode']>('abstractive')
  const [style, setStyle] = useState<SummarizeRequest['style']>('neutral')
  const [targetLength, setTargetLength] = useState<SummarizeRequest['target_length']>('medium')
  const [customLength, setCustomLength] = useState(300)
  const [extractKeyPoints, setExtractKeyPoints] = useState(true)
  const [generateTimeline, setGenerateTimeline] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleFiles = useCallback(async (files: FileList) => {
    const newDocs = await Promise.all(
      Array.from(files).map(async (file) => ({
        id: generateId(),
        name: file.name,
        text: await readFileAsText(file),
      }))
    )
    setDocuments(prev => [...prev, ...newDocs])
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    if (e.dataTransfer.files.length) handleFiles(e.dataTransfer.files)
  }, [handleFiles])

  const addPasted = () => {
    if (!pasteText.trim()) return
    setDocuments(prev => [...prev, { id: generateId(), name: 'Pasted text', text: pasteText.trim() }])
    setPasteText('')
  }

  const removeDoc = (id: string) => setDocuments(prev => prev.filter(d => d.id !== id))

  const handleSubmit = async () => {
    if (documents.length === 0) { setError('Add at least one document'); return }
    setError(null)
    setIsProcessing(true)
    const request: SummarizeRequest = {
      documents: documents.map(d => d.text),
      mode,
      style,
      target_length: targetLength,
      custom_length: targetLength === 'custom' ? customLength : undefined,
      extract_key_points: extractKeyPoints,
      generate_timeline: generateTimeline,
      multi_document: documents.length > 1,
    }
    try {
      const response = await summarizeDocuments(request)
      onResult(request, response)
    } catch (err: any) {
      setError(err.message || 'Summarization failed')
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-white">Upload Documents</h2>
        <p className="text-surface-400 mt-1">Add text files or paste content to summarize</p>
      </div>

      <div
        onDrop={handleDrop}
        onDragOver={e => e.preventDefault()}
        className="border-2 border-dashed border-surface-600 rounded-xl p-8 text-center hover:border-primary-500 transition-colors cursor-pointer"
        onClick={() => document.getElementById('file-input')?.click()}
      >
        <Upload className="w-10 h-10 text-surface-500 mx-auto mb-3" />
        <p className="text-surface-300">Drop files here or click to browse</p>
        <p className="text-surface-500 text-sm mt-1">Supports .txt, .md files</p>
        <input
          id="file-input"
          type="file"
          multiple
          accept=".txt,.md,.text"
          className="hidden"
          onChange={e => e.target.files && handleFiles(e.target.files)}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <textarea
          value={pasteText}
          onChange={e => setPasteText(e.target.value)}
          placeholder="Or paste text here..."
          className="col-span-2 bg-surface-800 border border-surface-600 rounded-lg p-3 h-32 text-surface-200 placeholder-surface-500 resize-none focus:outline-none focus:border-primary-500"
        />
        <div className="col-span-2">
          <button onClick={addPasted} className="text-sm text-primary-400 hover:text-primary-300">
            + Add pasted text as document
          </button>
        </div>
      </div>

      {documents.length > 0 && (
        <div className="space-y-2">
          <h3 className="text-sm font-medium text-surface-300">Documents ({documents.length})</h3>
          {documents.map(doc => (
            <div key={doc.id} className="flex items-center gap-3 bg-surface-800 border border-surface-700 rounded-lg px-4 py-2">
              <FileText className="w-4 h-4 text-surface-400 shrink-0" />
              <span className="text-sm text-surface-200 truncate flex-1">{doc.name}</span>
              <span className="text-xs text-surface-500">{doc.text.split(/\s+/).length} words</span>
              <button onClick={() => removeDoc(doc.id)} className="text-surface-500 hover:text-red-400">
                <X className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}

      <div className="bg-surface-800 border border-surface-700 rounded-xl p-5 space-y-5">
        <div className="flex items-center gap-2 text-surface-200">
          <Settings2 className="w-5 h-5" />
          <h3 className="font-semibold">Configuration</h3>
        </div>

        <div className="grid grid-cols-2 gap-5">
          <div>
            <label className="block text-sm font-medium text-surface-300 mb-2">Summarization Mode</label>
            <div className="space-y-2">
              {MODES.map(m => (
                <button
                  key={m.value}
                  onClick={() => setMode(m.value)}
                  className={cn(
                    'w-full text-left px-3 py-2 rounded-lg border transition-colors',
                    mode === m.value
                      ? 'border-primary-500 bg-primary-600/10 text-primary-300'
                      : 'border-surface-600 text-surface-400 hover:border-surface-500'
                  )}
                >
                  <span className="text-sm font-medium">{m.label}</span>
                  <span className="text-xs block text-surface-500">{m.desc}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-surface-300 mb-2">Output Style</label>
              <div className="flex flex-wrap gap-2">
                {STYLES.map(s => (
                  <button
                    key={s.value}
                    onClick={() => setStyle(s.value)}
                    className={cn(
                      'px-3 py-1.5 rounded-full text-sm border transition-colors',
                      style === s.value
                        ? 'border-primary-500 bg-primary-600/10 text-primary-300'
                        : 'border-surface-600 text-surface-400 hover:border-surface-500'
                    )}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-surface-300 mb-2">Target Length</label>
              <div className="space-y-1">
                {LENGTHS.map(l => (
                  <button
                    key={l.value}
                    onClick={() => setTargetLength(l.value)}
                    className={cn(
                      'block w-full text-left px-3 py-1.5 rounded text-sm transition-colors',
                      targetLength === l.value
                        ? 'text-primary-300 bg-primary-600/10'
                        : 'text-surface-400 hover:text-surface-300'
                    )}
                  >
                    {l.label}
                  </button>
                ))}
              </div>
              {targetLength === 'custom' && (
                <input
                  type="number"
                  value={customLength}
                  onChange={e => setCustomLength(Number(e.target.value))}
                  className="mt-2 w-full bg-surface-700 border border-surface-600 rounded px-3 py-1.5 text-sm text-surface-200 focus:outline-none focus:border-primary-500"
                  placeholder="Word count"
                />
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={extractKeyPoints}
              onChange={e => setExtractKeyPoints(e.target.checked)}
              className="accent-primary-500 w-4 h-4"
            />
            <span className="text-sm text-surface-300">Extract key points</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={generateTimeline}
              onChange={e => setGenerateTimeline(e.target.checked)}
              className="accent-primary-500 w-4 h-4"
            />
            <span className="text-sm text-surface-300">Generate timeline</span>
          </label>
        </div>
      </div>

      {error && <div className="bg-red-900/30 border border-red-700 rounded-lg px-4 py-3 text-red-300 text-sm">{error}</div>}

      <button
        onClick={handleSubmit}
        disabled={isProcessing || documents.length === 0}
        className={cn(
          'w-full py-3 rounded-xl font-semibold text-white transition-colors',
          isProcessing || documents.length === 0
            ? 'bg-surface-600 cursor-not-allowed'
            : 'bg-primary-600 hover:bg-primary-500'
        )}
      >
        {isProcessing ? (
          <span className="flex items-center justify-center gap-2">
            <Loader2 className="w-5 h-5 animate-spin" /> Processing...
          </span>
        ) : (
          'Summarize Documents'
        )}
      </button>
    </div>
  )
}
