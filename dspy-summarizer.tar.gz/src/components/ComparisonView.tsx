import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import type { CompareResponse } from "@/lib/api"
import { GitCompare } from "lucide-react"

interface ComparisonViewProps {
  result: CompareResponse
}

export default function ComparisonView({ result }: ComparisonViewProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <GitCompare className="h-5 w-5" />
          Comparison Results
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Badge variant="default">Extractive</Badge>
              <Badge variant="outline">Score: {(result.extractive.score * 100).toFixed(1)}%</Badge>
            </div>
            <Separator className="mb-3" />
            <p className="text-sm leading-relaxed whitespace-pre-wrap">{result.extractive.summary}</p>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Badge variant="default">Abstractive</Badge>
              <Badge variant="outline">Score: {(result.abstractive.score * 100).toFixed(1)}%</Badge>
            </div>
            <Separator className="mb-3" />
            <p className="text-sm leading-relaxed whitespace-pre-wrap">{result.abstractive.summary}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
