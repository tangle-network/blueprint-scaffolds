import { FileText, Zap } from 'lucide-react'

export function Header() {
  return (
    <header className="h-14 bg-surface-800 border-b border-surface-700 flex items-center px-6 shrink-0">
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center">
          <Zap className="w-4 h-4 text-white" />
        </div>
        <h1 className="text-lg font-semibold text-white">DSPy Summarizer</h1>
      </div>
      <div className="ml-auto flex items-center gap-4 text-sm text-surface-400">
        <FileText className="w-4 h-4" />
        <span>Advanced Summarization System</span>
      </div>
    </header>
  )
}
