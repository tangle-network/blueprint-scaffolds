export function cn(...classes: (string | boolean | undefined | null)[]): string {
  return classes.filter(Boolean).join(' ')
}

export function formatScore(score: number): string {
  return (score * 100).toFixed(1) + '%'
}

export function generateId(): string {
  return Math.random().toString(36).slice(2, 10)
}

export function countWords(text: string): number {
  return text.split(/\s+/).filter(Boolean).length
}

export function readFileAsText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(reader.result as string)
    reader.onerror = reject
    reader.readAsText(file)
  })
}
