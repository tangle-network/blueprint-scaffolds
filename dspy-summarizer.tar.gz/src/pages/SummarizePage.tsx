import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import FileUpload from "@/components/FileUpload"
import SummaryConfig from "@/components/SummaryConfig"
import SummaryResult from "@/components/SummaryResult"
import KeyPointsList from "@/components/KeyPointsList"
import TimelineView from "@/components/TimelineView"
import { summarize, type SummarizeResponse, type SummarizeRequest } from "@/lib/api"
import { ArrowLeft, Loader2 } from "lucide-react"

export default function SummarizePage() {
  const navigate = useNavigate()
  const [documents, setDocuments] = useState<string[]>([])
  const [mode, setMode] = useState<"extractive" | "abstractive">("abstractive")
  const [style, setStyle] = useState<"concise" | "detailed" | "technical" | "casual">("concise")
  const [maxLength, setMaxLength] = useState(200)
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<SummarizeResponse | null>(null)
  const [error, setError] = useState<string | null>(null)

  const handleSummarize = async () => {
    if (documents.length === 0) {
      setError("Please add at least one document.")
      return
    }
    setLoading(true)
    setError(null)
    setResult(null)
    try {
      const req: SummarizeRequest = { documents, mode, style, max_length: maxLength }
      const res = await summarize(req)
      setResult(res)
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="flex items-center gap-4 mb-8">
        <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold">Summarize Documents</h1>
          <p className="text-muted-foreground">Upload or paste documents, configure options, and generate summaries</p>
        </div>
      </div>

      <div className="grid gap-6">
        <FileUpload documents={documents} onDocumentsChange={setDocuments} />

        <SummaryConfig
          mode={mode}
          onModeChange={setMode}
          style={style}
          onStyleChange={setStyle}
          maxLength={maxLength}
          onMaxLengthChange={setMaxLength}
        />

        <Button size="lg" onClick={handleSummarize} disabled={loading || documents.length === 0}>
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Generating Summary...
            </>
          ) : (
            "Generate Summary"
          )}
        </Button>

        {loading && <Progress value={66} className="h-2" />}

        {error && (
          <Card className="border-destructive">
            <CardContent className="pt-6">
              <p className="text-destructive">{error}</p>
            </CardContent>
          </Card>
        )}

        {result && (
          <>
            <SummaryResult summary={result.summary} mode={mode} style={style} />
            <Separator />
            <KeyPointsList points={result.key_points} />
            <Separator />
            <TimelineView timeline={result.timeline} />
          </>
        )}
      </div>
    </div>
  )
}
