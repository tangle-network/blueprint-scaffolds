import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import ComparisonView from "@/components/ComparisonView"
import { compare, type CompareResponse } from "@/lib/api"
import { ArrowLeft, Loader2 } from "lucide-react"

export default function ComparePage() {
  const navigate = useNavigate()
  const [documents, setDocuments] = useState<string[]>([""])
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<CompareResponse | null>(null)
  const [error, setError] = useState<string | null>(null)

  const handleCompare = async () => {
    const filtered = documents.filter((d) => d.trim().length > 0)
    if (filtered.length === 0) {
      setError("Please enter at least one document.")
      return
    }
    setLoading(true)
    setError(null)
    setResult(null)
    try {
      const res = await compare(filtered)
      setResult(res)
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  const addDocument = () => setDocuments([...documents, ""])

  const updateDocument = (index: number, value: string) => {
    const updated = [...documents]
    updated[index] = value
    setDocuments(updated)
  }

  const removeDocument = (index: number) => {
    if (documents.length <= 1) return
    setDocuments(documents.filter((_, i) => i !== index))
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      <div className="flex items-center gap-4 mb-8">
        <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold">Compare Modes</h1>
          <p className="text-muted-foreground">Side-by-side comparison of extractive vs abstractive summaries</p>
        </div>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Documents</CardTitle>
            <CardDescription>Paste one or more documents to compare summarization modes</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
            {documents.map((doc, i) => (
              <div key={i} className="grid gap-2">
                <div className="flex items-center justify-between">
                  <Badge variant="secondary">Document {i + 1}</Badge>
                  {documents.length > 1 && (
                    <Button variant="ghost" size="sm" onClick={() => removeDocument(i)}>
                      Remove
                    </Button>
                  )}
                </div>
                <Textarea
                  placeholder="Paste document text here..."
                  value={doc}
                  onChange={(e) => updateDocument(i, e.target.value)}
                  rows={6}
                />
              </div>
            ))}
          </CardContent>
          <CardFooter className="flex gap-2">
            <Button variant="outline" onClick={addDocument}>
              Add Document
            </Button>
            <Button onClick={handleCompare} disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Comparing...
                </>
              ) : (
                "Compare Summaries"
              )}
            </Button>
          </CardFooter>
        </Card>

        {error && (
          <Card className="border-destructive">
            <CardContent className="pt-6">
              <p className="text-destructive">{error}</p>
            </CardContent>
          </Card>
        )}

        {result && <ComparisonView result={result} />}
      </div>
    </div>
  )
}
