import { useNavigate } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"
import { FileText, GitCompare, Sparkles, Clock, ListChecks, Palette } from "lucide-react"

const features = [
  { icon: FileText, title: "Extractive Summaries", desc: "Pull key sentences directly from source documents" },
  { icon: Sparkles, title: "Abstractive Summaries", desc: "Generate human-like summaries using DSPy ChainOfThought" },
  { icon: GitCompare, title: "Side-by-Side Compare", desc: "Compare extractive vs abstractive outputs with scores" },
  { icon: ListChecks, title: "Key Point Extraction", desc: "Automatically identify the most important points" },
  { icon: Clock, title: "Timeline Generation", desc: "Build chronological timelines from document events" },
  { icon: Palette, title: "Style Adaptation", desc: "Concise, detailed, technical, or casual output styles" },
]

export default function HomePage() {
  const navigate = useNavigate()

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-16">
        <h1 className="text-5xl font-bold tracking-tight mb-4">
          Advanced Summarization System
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
          Powered by DSPy — intelligent document summarization with extractive &amp; abstractive modes,
          multi-document synthesis, style adaptation, and more.
        </p>
        <div className="flex gap-4 justify-center">
          <Button size="lg" onClick={() => navigate("/summarize")}>
            Summarize Documents
          </Button>
          <Button size="lg" variant="outline" onClick={() => navigate("/compare")}>
            Compare Modes
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
        {features.map((f) => (
          <Card key={f.title} className="hover:shadow-md transition-shadow cursor-pointer"
            onClick={() => navigate("/summarize")}>
            <CardHeader>
              <f.icon className="h-8 w-8 mb-2 text-primary" />
              <CardTitle className="text-lg">{f.title}</CardTitle>
              <CardDescription>{f.desc}</CardDescription>
            </CardHeader>
          </Card>
        ))}
      </div>
    </div>
  )
}
