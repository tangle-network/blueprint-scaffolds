from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional

router = APIRouter(prefix="/api")


class SummarizeRequest(BaseModel):
    documents: list[str]
    mode: str = "abstractive"
    style: str = "concise"
    max_length: int = 200


class CompareRequest(BaseModel):
    documents: list[str]


@router.get("/health")
async def health():
    return {"status": "ok", "version": "1.0.0"}


@router.post("/summarize")
async def summarize(req: SummarizeRequest):
    if not req.documents:
        raise HTTPException(status_code=400, detail="No documents provided")

    from backend.dspy_modules.summarizer import Summarizer
    summarizer = Summarizer()

    try:
        result = summarizer.summarize(
            documents=req.documents,
            mode=req.mode,
            style=req.style,
            max_length=req.max_length,
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/compare")
async def compare(req: CompareRequest):
    if not req.documents:
        raise HTTPException(status_code=400, detail="No documents provided")

    from backend.dspy_modules.summarizer import Summarizer
    summarizer = Summarizer()

    try:
        result = summarizer.compare(documents=req.documents)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
