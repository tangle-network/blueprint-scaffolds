from pydantic import BaseModel
from typing import Optional


class DocumentInput(BaseModel):
    id: str
    title: str
    content: str
    source: Optional[str] = None


class SummaryConfig(BaseModel):
    mode: str = "abstractive"
    style: str = "journalistic"
    length: str = "medium"
    max_words: Optional[int] = None
    extract_key_points: bool = True
    generate_timeline: bool = False
    focus_topics: Optional[list[str]] = None


class SummarizeRequest(BaseModel):
    documents: list[DocumentInput]
    config: SummaryConfig


class KeyPoint(BaseModel):
    point: str
    confidence: float
    source_document: Optional[str] = None


class TimelineEvent(BaseModel):
    date: str
    event: str
    significance: str


class ScoreMetrics(BaseModel):
    rouge_1: float
    rouge_2: float
    rouge_l: float
    bertscore_f1: float


class SummaryResult(BaseModel):
    summary: str
    mode: str
    style: str
    length: str
    key_points: list[KeyPoint]
    timeline: list[TimelineEvent]
    scores: ScoreMetrics
    word_count: int
    processing_time_ms: float


class CompareRequest(BaseModel):
    documents: list[DocumentInput]
    configs: list[SummaryConfig]


class ComparisonResult(BaseModel):
    summaries: list[SummaryResult]
    comparison_notes: str


class HealthResponse(BaseModel):
    status: str
    dspy_configured: bool
    model: str
