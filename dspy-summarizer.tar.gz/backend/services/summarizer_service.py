import json
import re
import time
from typing import Optional

from rouge_score import rouge_scorer

from .document_processor import (
    chunk_text,
    extractive_summarize,
    get_length_constraints,
    preprocess_document,
    synthesize_documents,
    truncate_to_word_limit,
)
from .dspy_modules import SummarizationPipeline
from models.schemas import (
    DocumentInput,
    KeyPoint,
    ScoreMetrics,
    SummaryConfig,
    SummaryResult,
    TimelineEvent,
)


def _safe_json_parse(text: str, fallback: list) -> list:
    try:
        text = text.strip()
        if text.startswith("```"):
            text = re.sub(r"^```(?:json)?\s*", "", text)
            text = re.sub(r"\s*```$", "", text)
        parsed = json.loads(text)
        return parsed if isinstance(parsed, list) else fallback
    except (json.JSONDecodeError, TypeError):
        json_match = re.search(r"\[[\s\S]*\]", text)
        if json_match:
            try:
                return json.loads(json_match.group())
            except json.JSONDecodeError:
                pass
        return fallback


def compute_rouge_scores(summary: str, reference: str) -> dict:
    scorer = rouge_scorer.RougeScorer(["rouge1", "rouge2", "rougeL"], use_stemmer=True)
    scores = scorer.score(reference, summary)
    return {
        "rouge_1": scores["rouge1"].fmeasure,
        "rouge_2": scores["rouge2"].fmeasure,
        "rouge_l": scores["rougeL"].fmeasure,
    }


def compute_bertscore(summary: str, reference: str) -> float:
    try:
        from bert_score import score as bert_score_fn

        P, R, F1 = bert_score_fn([summary], [reference], lang="en", verbose=False)
        return float(F1[0])
    except Exception:
        return max(compute_rouge_scores(summary, reference)["rouge_l"], 0.0)


def compute_metrics(summary: str, reference: str) -> ScoreMetrics:
    rouge = compute_rouge_scores(summary, reference)
    bert_f1 = compute_bertscore(summary, reference)
    return ScoreMetrics(
        rouge_1=rouge["rouge_1"],
        rouge_2=rouge["rouge_2"],
        rouge_l=rouge["rouge_l"],
        bertscore_f1=bert_f1,
    )


def generate_summary(
    documents: list[DocumentInput],
    config: SummaryConfig,
    pipeline: Optional[SummarizationPipeline] = None,
) -> SummaryResult:
    start_time = time.time()

    constraints = get_length_constraints(config.length, config.max_words)
    length_guidance = f"{config.length} ({constraints['sentence_guidance']}, ~{constraints['target_word_count']} words)"
    focus_topics = ", ".join(config.focus_topics) if config.focus_topics else "general"

    doc_dicts = [d.model_dump() for d in documents]
    is_multi = len(doc_dicts) > 1
    combined_text = synthesize_documents(doc_dicts)

    if config.mode == "extractive":
        num_sentences = {"brief": 3, "medium": 6, "detailed": 10}.get(config.length, 6)
        fallback_summary = extractive_summarize(
            combined_text,
            num_sentences=num_sentences,
            focus_topics=config.focus_topics,
        )
    else:
        fallback_summary = "Summary could not be generated. Please check DSPy configuration and try again."

    summary = fallback_summary

    if pipeline is not None:
        try:
            chunks = chunk_text(combined_text, max_chars=6000)
            text_for_dspy = chunks[0] if len(chunks) == 1 else combined_text[:8000]

            summary = pipeline.summarize(
                documents=text_for_dspy,
                mode=config.mode,
                style=config.style,
                length_guidance=length_guidance,
                focus_topics=focus_topics,
                is_multi_document=is_multi,
            )
        except Exception:
            summary = fallback_summary

    if config.max_words:
        summary = truncate_to_word_limit(summary, config.max_words)

    key_points: list[KeyPoint] = []
    if config.extract_key_points:
        num_points = {"brief": 3, "medium": 5, "detailed": 8}.get(config.length, 5)
        if pipeline is not None:
            try:
                kp_text = pipeline.extract_key_points(combined_text[:6000], num_points)
                parsed = _safe_json_parse(kp_text, [])
                for item in parsed[:num_points]:
                    if isinstance(item, dict) and "point" in item:
                        key_points.append(KeyPoint(
                            point=item["point"],
                            confidence=float(item.get("confidence", 0.7)),
                            source_document=item.get("source_document"),
                        ))
            except Exception:
                pass

        if not key_points:
            sentences = combined_text.split(". ")[:num_points]
            for s in sentences:
                if s.strip():
                    key_points.append(KeyPoint(
                        point=s.strip(),
                        confidence=0.5,
                    ))

    timeline: list[TimelineEvent] = []
    if config.generate_timeline:
        if pipeline is not None:
            try:
                tl_text = pipeline.generate_timeline(combined_text[:6000])
                parsed = _safe_json_parse(tl_text, [])
                for item in parsed:
                    if isinstance(item, dict) and "date" in item and "event" in item:
                        timeline.append(TimelineEvent(
                            date=item["date"],
                            event=item["event"],
                            significance=item.get("significance", ""),
                        ))
            except Exception:
                pass

        if not timeline:
            from .document_processor import extract_dates

            raw_events = extract_dates(combined_text)
            for ev in raw_events[:10]:
                timeline.append(TimelineEvent(
                    date=ev["date"],
                    event=ev["context"][:200],
                    significance="Auto-extracted from document",
                ))

    reference = " ".join(d.content for d in documents)[:2000]
    scores = compute_metrics(summary, reference)

    processing_time = (time.time() - start_time) * 1000

    return SummaryResult(
        summary=summary,
        mode=config.mode,
        style=config.style,
        length=config.length,
        key_points=key_points,
        timeline=timeline,
        scores=scores,
        word_count=len(summary.split()),
        processing_time_ms=processing_time,
    )
