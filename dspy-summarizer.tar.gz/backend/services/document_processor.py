import re
import textwrap
from collections import Counter
from typing import Optional

import nltk

try:
    nltk.data.find("tokenizers/punkt_tab")
except LookupError:
    nltk.download("punkt_tab", quiet=True)

try:
    nltk.data.find("corpora/stopwords")
except LookupError:
    nltk.download("stopwords", quiet=True)


def chunk_text(text: str, max_chars: int = 4000, overlap: int = 200) -> list[str]:
    paragraphs = text.split("\n\n")
    chunks: list[str] = []
    current = ""

    for para in paragraphs:
        if len(current) + len(para) + 2 > max_chars and current:
            chunks.append(current.strip())
            if overlap > 0:
                words = current.split()
                overlap_text = " ".join(words[-overlap // 5 :]) if len(words) > overlap // 5 else current
                current = overlap_text + "\n\n" + para
            else:
                current = para
        else:
            current = current + "\n\n" + para if current else para

    if current.strip():
        chunks.append(current.strip())

    return chunks if chunks else [text]


def preprocess_document(content: str, title: str = "") -> str:
    content = re.sub(r"\s+", " ", content).strip()
    content = re.sub(r"\n{3,}", "\n\n", content)
    if title:
        content = f"[Document: {title}]\n\n{content}"
    return content


def synthesize_documents(documents: list[dict]) -> str:
    if len(documents) == 1:
        return preprocess_document(documents[0]["content"], documents[0].get("title", ""))

    parts = []
    for doc in documents:
        processed = preprocess_document(doc["content"], doc.get("title", ""))
        parts.append(processed)

    return "\n\n---\n\n".join(parts)


def extract_sentences(text: str) -> list[str]:
    from nltk.tokenize import sent_tokenize

    return sent_tokenize(text)


def compute_sentence_scores(sentences: list[str], query: Optional[str] = None) -> list[float]:
    from nltk.corpus import stopwords

    stop_words = set(stopwords.words("english"))
    all_words = []
    for s in sentences:
        words = re.findall(r"\b\w+\b", s.lower())
        all_words.extend([w for w in words if w not in stop_words])

    word_freq = Counter(all_words)
    if not word_freq:
        return [0.5] * len(sentences)

    scores = []
    for s in sentences:
        words = re.findall(r"\b\w+\b", s.lower())
        words = [w for w in words if w not in stop_words]
        if not words:
            scores.append(0.0)
            continue

        score = sum(word_freq.get(w, 0) for w in words) / len(words)

        if query:
            query_words = set(re.findall(r"\b\w+\b", query.lower()))
            overlap = len(set(words) & query_words)
            score += overlap * 2

        scores.append(score)

    max_score = max(scores) if scores else 1
    return [s / max_score for s in scores] if max_score > 0 else scores


def extractive_summarize(
    text: str,
    num_sentences: int = 5,
    focus_topics: Optional[list[str]] = None,
) -> str:
    sentences = extract_sentences(text)
    if len(sentences) <= num_sentences:
        return " ".join(sentences)

    query = " ".join(focus_topics) if focus_topics else None
    scores = compute_sentence_scores(sentences, query)

    ranked = sorted(enumerate(scores), key=lambda x: x[1], reverse=True)
    top_indices = sorted([idx for idx, _ in ranked[:num_sentences]])

    return " ".join(sentences[i] for i in top_indices)


def truncate_to_word_limit(text: str, max_words: int) -> str:
    words = text.split()
    if len(words) <= max_words:
        return text
    return " ".join(words[:max_words])


def get_length_constraints(length: str, max_words: Optional[int] = None) -> dict:
    word_targets = {"brief": 100, "medium": 250, "detailed": 500}
    target = max_words or word_targets.get(length, 250)

    sentence_targets = {"brief": "2-3 sentences", "medium": "1-2 paragraphs", "detailed": "3-5 paragraphs"}
    sentence_target = sentence_targets.get(length, "1-2 paragraphs")

    return {
        "target_word_count": target,
        "sentence_guidance": sentence_target,
        "length_description": length,
    }


def extract_dates(text: str) -> list[dict]:
    patterns = [
        r"\b(\w+ \d{1,2},? \d{4})\b",
        r"\b(\d{1,2}/\d{1,2}/\d{4})\b",
        r"\b(\d{4}-\d{2}-\d{2})\b",
        r"\b(\d{1,2} \w+ \d{4})\b",
        r"\b((?:January|February|March|April|May|June|July|August|September|October|November|December) \d{4})\b",
    ]

    events = []
    for pattern in patterns:
        matches = re.finditer(pattern, text)
        for match in matches:
            date_str = match.group(1)
            start = max(0, match.start() - 100)
            end = min(len(text), match.end() + 100)
            context = text[start:end].strip()
            events.append({"date": date_str, "context": context})

    return events
