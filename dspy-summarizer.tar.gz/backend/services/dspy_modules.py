import dspy
from dspy import ChainOfThought
from typing import Optional


class AbstractiveSummarySignature(dspy.Signature):
    """Synthesize a coherent summary from one or more source documents, adapting to the specified style and length."""

    documents: str = dspy.InputField(desc="Full text of the source document(s)")
    style: str = dspy.InputField(desc="Writing style: academic, journalistic, casual, technical, or executive")
    length_guidance: str = dspy.InputField(desc="Target length description with word count guidance")
    focus_topics: str = dspy.InputField(desc="Comma-separated topics to focus on, or 'general' if none specified")

    summary: str = dspy.OutputField(desc="The generated summary in the specified style")


class ExtractiveSummarySignature(dspy.Signature):
    """Select and combine the most important sentences from documents to form a coherent extractive summary."""

    documents: str = dspy.InputField(desc="Full text of the source document(s)")
    length_guidance: str = dspy.InputField(desc="Target length description with word count guidance")
    focus_topics: str = dspy.InputField(desc="Comma-separated topics to focus on, or 'general' if none specified")

    summary: str = dspy.OutputField(desc="Extractive summary composed of key sentences from the source text")


class KeyPointExtractionSignature(dspy.Signature):
    """Extract the most important key points and claims from the given text."""

    documents: str = dspy.InputField(desc="Source text to extract key points from")
    num_points: str = dspy.InputField(desc="Target number of key points to extract")

    key_points: str = dspy.OutputField(desc="JSON array of objects with 'point' and 'confidence' (0-1) fields")


class TimelineGenerationSignature(dspy.Signature):
    """Extract temporal events from documents and create a chronological timeline."""

    documents: str = dspy.InputField(desc="Source documents to extract timeline from")

    timeline: str = dspy.OutputField(desc="JSON array of objects with 'date', 'event', and 'significance' fields")


class MultiDocumentSynthesisSignature(dspy.Signature):
    """Synthesize information from multiple documents into a unified summary, identifying common themes and unique insights."""

    documents: str = dspy.InputField(desc="Multiple source documents separated by markers")
    style: str = dspy.InputField(desc="Writing style for the synthesis")
    length_guidance: str = dspy.InputField(desc="Target length description")

    summary: str = dspy.OutputField(desc="Unified synthesis of all documents")
    themes: str = dspy.OutputField(desc="Common themes identified across documents")


class AbstractiveSummarizer(dspy.Module):
    def __init__(self):
        super().__init__()
        self.summarize = ChainOfThought(AbstractiveSummarySignature)

    def forward(self, documents: str, style: str, length_guidance: str, focus_topics: str = "general"):
        return self.summarize(
            documents=documents,
            style=style,
            length_guidance=length_guidance,
            focus_topics=focus_topics,
        )


class ExtractiveSummarizer(dspy.Module):
    def __init__(self):
        super().__init__()
        self.summarize = ChainOfThought(ExtractiveSummarySignature)

    def forward(self, documents: str, length_guidance: str, focus_topics: str = "general"):
        return self.summarize(
            documents=documents,
            length_guidance=length_guidance,
            focus_topics=focus_topics,
        )


class KeyPointExtractor(dspy.Module):
    def __init__(self):
        super().__init__()
        self.extract = ChainOfThought(KeyPointExtractionSignature)

    def forward(self, documents: str, num_points: str = "5"):
        return self.extract(documents=documents, num_points=num_points)


class TimelineGenerator(dspy.Module):
    def __init__(self):
        super().__init__()
        self.generate = ChainOfThought(TimelineGenerationSignature)

    def forward(self, documents: str):
        return self.generate(documents=documents)


class MultiDocumentSynthesizer(dspy.Module):
    def __init__(self):
        super().__init__()
        self.synthesize = ChainOfThought(MultiDocumentSynthesisSignature)

    def forward(self, documents: str, style: str, length_guidance: str):
        return self.synthesize(documents=documents, style=style, length_guidance=length_guidance)


class SummarizationPipeline:
    def __init__(self, lm: Optional[dspy.LM] = None):
        if lm:
            dspy.configure(lm=lm)
        self.abstractive = AbstractiveSummarizer()
        self.extractive = ExtractiveSummarizer()
        self.key_point_extractor = KeyPointExtractor()
        self.timeline_generator = TimelineGenerator()
        self.multi_doc_synthesizer = MultiDocumentSynthesizer()

    def summarize(
        self,
        documents: str,
        mode: str = "abstractive",
        style: str = "journalistic",
        length_guidance: str = "medium (~250 words)",
        focus_topics: str = "general",
        is_multi_document: bool = False,
    ) -> str:
        if is_multi_document:
            result = self.multi_doc_synthesizer(
                documents=documents,
                style=style,
                length_guidance=length_guidance,
            )
            return result.summary

        if mode == "extractive":
            result = self.extractive(
                documents=documents,
                length_guidance=length_guidance,
                focus_topics=focus_topics,
            )
        else:
            result = self.abstractive(
                documents=documents,
                style=style,
                length_guidance=length_guidance,
                focus_topics=focus_topics,
            )
        return result.summary

    def extract_key_points(self, documents: str, num_points: int = 5) -> str:
        result = self.key_point_extractor(documents=documents, num_points=str(num_points))
        return result.key_points

    def generate_timeline(self, documents: str) -> str:
        result = self.timeline_generator(documents=documents)
        return result.timeline
