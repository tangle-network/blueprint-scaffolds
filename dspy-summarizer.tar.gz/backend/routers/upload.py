import os
import tempfile
from typing import List

from fastapi import APIRouter, UploadFile, File

from models.schemas import DocumentInput

router = APIRouter()


@router.post("/upload", response_model=List[DocumentInput])
async def upload_documents(files: List[UploadFile] = File(...)):
    documents = []
    for file in files:
        content = await file.read()
        try:
            text = content.decode("utf-8")
        except UnicodeDecodeError:
            text = content.decode("latin-1")

        doc = DocumentInput(
            id=f"upload-{id(file)}-{hash(file.filename)}",
            title=file.filename or "uploaded_file",
            content=text,
            source=file.filename,
        )
        documents.append(doc)
    return documents
