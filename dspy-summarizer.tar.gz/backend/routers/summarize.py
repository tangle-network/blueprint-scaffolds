from typing import Optional

from fastapi import APIRouter

from models.schemas import (
    CompareRequest,
    ComparisonResult,
    SummarizeRequest,
    SummaryResult,
)
from services.summarizer_service import generate_summary

router = APIRouter()

_pipeline: Optional[object] = None


def _get_pipeline():
    global _pipeline
    if _pipeline is None:
        from main import pipeline as app_pipeline
        _pipeline = app_pipeline
    return _pipeline


@router.post("/summarize", response_model=SummaryResult)
async def summarize(request: SummarizeRequest):
    pipeline = _get_pipeline()
    result = generate_summary(
        documents=request.documents,
        config=request.config,
        pipeline=pipeline,
    )
    return result


@router.post("/compare", response_model=ComparisonResult)
async def compare(request: CompareRequest):
    pipeline = _get_pipeline()
    summaries = []
    for config in request.configs:
        result = generate_summary(
            documents=request.documents,
            config=config,
            pipeline=pipeline,
        )
        summaries.append(result)

    modes = [c.mode for c in request.configs]
    styles = [c.style for c in request.configs]
    lengths = [c.length for c in request.configs]

    notes_parts = []
    if len(set(modes)) > 1:
        notes_parts.append(f"Comparing modes: {', '.join(modes)}")
    if len(set(styles)) > 1:
        notes_parts.append(f"Comparing styles: {', '.join(styles)}")
    if len(set(lengths)) > 1:
        notes_parts.append(f"Comparing lengths: {', '.join(lengths)}")

    if len(summaries) >= 2:
        wc = [s.word_count for s in summaries]
        notes_parts.append(
            f"Word counts range from {min(wc)} to {max(wc)}. "
            f"Processing times: {', '.join(f'{s.processing_time_ms:.0f}ms' for s in summaries)}"
        )

    notes = " | ".join(notes_parts) if notes_parts else "Comparison complete"

    return ComparisonResult(summaries=summaries, comparison_notes=notes)
