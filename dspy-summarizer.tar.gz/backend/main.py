import os
import tempfile
from typing import Optional

import dspy
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from models.schemas import (
    CompareRequest,
    ComparisonResult,
    HealthResponse,
    SummarizeRequest,
    SummaryResult,
)
from routers import upload, summarize

app = FastAPI(title="DSPy Summarizer API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

pipeline: Optional[object] = None


def init_dspy():
    global pipeline
    from services.dspy_modules import SummarizationPipeline

    model = os.environ.get("DSPY_MODEL", "openai/gpt-4o-mini")
    api_key = os.environ.get("OPENAI_API_KEY", "")

    try:
        if api_key:
            lm = dspy.LM(model=model, api_key=api_key)
            dspy.configure(lm=lm)
        pipeline = SummarizationPipeline()
    except Exception:
        pipeline = None


@app.on_event("startup")
async def startup():
    init_dspy()


@app.get("/api/health", response_model=HealthResponse)
async def health():
    return HealthResponse(
        status="ok",
        dspy_configured=pipeline is not None,
        model=os.environ.get("DSPY_MODEL", "openai/gpt-4o-mini"),
    )


app.include_router(summarize.router, prefix="/api")
app.include_router(upload.router, prefix="/api")
