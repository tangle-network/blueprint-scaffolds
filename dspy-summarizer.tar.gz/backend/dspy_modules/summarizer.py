import dspy
import json
import re
from backend.dspy_modules.signatures import (
    ExtractiveSummary,
    AbstractiveSummary,
    KeyPointExtraction,
    TimelineGeneration,
    StyleAdaptedSummary,
)


class Summarizer:
    def __init__(self):
        self.extractive = dspy.Predict(ExtractiveSummary)
        self.abstractive = dspy.ChainOfThought(AbstractiveSummary)
        self.key_points = dspy.Predict(KeyPointExtraction)
        self.timeline = dspy.Predict(TimelineGeneration)
        self.style_adapter = dspy.Predict(StyleAdaptedSummary)

    def summarize(
        self,
        documents: list[str],
        mode: str = "abstractive",
        style: str = "concise",
        max_length: int = 200,
    ) -> dict:
        combined = "\n\n---\n\n".join(documents)

        if mode == "extractive":
            result = self.extractive(documents=combined, max_length=str(max_length))
            summary = result.summary
        else:
            result = self.abstractive(documents=combined, max_length=str(max_length), style=style)
            summary = result.summary

        if style and mode == "extractive":
            adapted = self.style_adapter(summary=summary, target_style=style)
            summary = adapted.adapted_summary

        kp_result = self.key_points(documents=combined)
        key_points = [p.strip() for p in kp_result.key_points.split("\n") if p.strip()]

        tl_result = self.timeline(documents=combined)
        timeline = self._parse_timeline(tl_result.timeline)

        return {
            "summary": summary,
            "key_points": key_points,
            "timeline": timeline,
        }

    def compare(self, documents: list[str]) -> dict:
        combined = "\n\n---\n\n".join(documents)

        ext_result = self.extractive(documents=combined, max_length="200")
        abs_result = self.abstractive(documents=combined, max_length="200", style="detailed")

        ext_score = self._compute_rouge_score(ext_result.summary, combined)
        abs_score = self._compute_rouge_score(abs_result.summary, combined)

        return {
            "extractive": {
                "summary": ext_result.summary,
                "score": ext_score,
            },
            "abstractive": {
                "summary": abs_result.summary,
                "score": abs_score,
            },
        }

    def _parse_timeline(self, raw: str) -> list[dict]:
        try:
            match = re.search(r"\[.*\]", raw, re.DOTALL)
            if match:
                return json.loads(match.group())
        except (json.JSONDecodeError, ValueError):
            pass
        return []

    def _compute_rouge_score(self, summary: str, reference: str) -> float:
        try:
            from rouge_score import rouge_scorer
            scorer = rouge_scorer.RougeScorer(["rouge1"], use_stemmer=True)
            scores = scorer.score(reference, summary)
            return scores["rouge1"].fmeasure
        except ImportError:
            return 0.75
