import dspy
from typing import Optional


class ExtractiveSummary(dspy.Signature):
    """Extract the most important sentences from the given documents to create a summary. Select exact sentences from the source text."""

    documents = dspy.InputField(desc="The source documents to extract sentences from")
    max_length = dspy.InputField(desc="Maximum number of words in the summary")
    summary = dspy.OutputField(desc="An extractive summary composed of key sentences from the source")


class AbstractiveSummary(dspy.Signature):
    """Generate a new abstractive summary that captures the key information from the documents in a coherent narrative."""

    documents = dspy.InputField(desc="The source documents to summarize")
    max_length = dspy.InputField(desc="Maximum number of words in the summary")
    style = dspy.InputField(desc="Output style: concise, detailed, technical, or casual")
    summary = dspy.OutputField(desc="An abstractive summary written in new language")


class KeyPointExtraction(dspy.Signature):
    """Extract the most important key points from the given documents."""

    documents = dspy.InputField(desc="The source documents")
    key_points = dspy.OutputField(desc="A list of the most important key points, separated by newlines")


class TimelineGeneration(dspy.Signature):
    """Extract events with dates from the documents and arrange them chronologically."""

    documents = dspy.InputField(desc="The source documents")
    timeline = dspy.OutputField(
        desc="A chronological timeline of events in JSON format: [{\"date\": \"...\", \"event\": \"...\"}]"
    )


class StyleAdaptedSummary(dspy.Signature):
    """Adapt the given summary to the specified style while preserving key information."""

    summary = dspy.InputField(desc="The original summary text")
    target_style = dspy.InputField(desc="Target style: concise, detailed, technical, or casual")
    adapted_summary = dspy.OutputField(desc="The summary rewritten in the target style")
