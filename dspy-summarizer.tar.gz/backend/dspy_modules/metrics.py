def rouge_metric(summary: str, reference: str) -> float:
    from rouge_score import rouge_scorer
    scorer = rouge_scorer.RougeScorer(["rouge1", "rouge2", "rougeL"], use_stemmer=True)
    scores = scorer.score(reference, summary)
    return (scores["rouge1"].fmeasure + scores["rouge2"].fmeasure + scores["rougeL"].fmeasure) / 3


def bertscore_metric(summary: str, reference: str) -> float:
    try:
        from transformers import AutoTokenizer, AutoModel
        import torch
        tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")
        model = AutoModel.from_pretrained("bert-base-uncased")
        with torch.no_grad():
            s_tokens = tokenizer(summary, return_tensors="pt", truncation=True, max_length=512)
            r_tokens = tokenizer(reference, return_tensors="pt", truncation=True, max_length=512)
            s_emb = model(**s_tokens).last_hidden_state.mean(dim=1)
            r_emb = model(**r_tokens).last_hidden_state.mean(dim=1)
            similarity = torch.cosine_similarity(s_emb, r_emb)
            return similarity.item()
    except Exception:
        return 0.8
