# Advanced Summarization System — Build Plan

## Stack
- Frontend: Vite + React + TypeScript + Tailwind CSS + shadcn/ui
- Backend: Python + FastAPI + DSPy
- Monorepo: all files in project root

## Directory Structure
```
src/
  main.tsx
  App.tsx
  index.css
  lib/
    utils.ts
    api.ts
  components/
    ui/          (shadcn/ui components)
    FileUpload.tsx
    SummaryConfig.tsx
    SummaryResult.tsx
    ComparisonView.tsx
    KeyPointsList.tsx
    TimelineView.tsx
  pages/
    HomePage.tsx
    SummarizePage.tsx
    ComparePage.tsx
backend/
  main.py
  requirements.txt
  dspy_modules/
    __init__.py
    signatures.py
    summarizer.py
    metrics.py
  api/
    __init__.py
    routes.py
```

## Pages
1. **HomePage** — Hero, feature cards, nav to Summarize/Compare
2. **SummarizePage** — Upload docs, configure mode/style/length, view result + key points + timeline
3. **ComparePage** — Side-by-side comparison of extractive vs abstractive outputs

## API Routes (Python FastAPI)
- POST /api/summarize — accepts documents, mode, style, max_length → returns summary, key_points, timeline
- POST /api/compare — accepts documents → returns both extractive and abstractive summaries with scores
- GET /api/health — health check

## shadcn/ui Components to Use
- Button, Card, Select, Tabs, Badge, Textarea, Slider, Progress, Separator

## DSPy Modules
- ChainOfThought for abstractive summaries
- Custom signatures: ExtractiveSummary, AbstractiveSummary, KeyPointExtraction, TimelineGeneration, StyleAdaptedSummary
- ROUGE + BERTScore metrics

## Build
- cd /home/agent && pnpm install && pnpm build
