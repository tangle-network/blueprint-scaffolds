import type {
  SummarizeRequest,
  SummaryResult,
  ComparisonResult,
  HealthResponse,
  SummaryConfig,
  DocumentInput,
} from '../types'

const API_BASE = '/api'

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }))
    throw new Error(err.detail || 'Request failed')
  }
  return res.json()
}

export async function summarize(
  documents: DocumentInput[],
  config: SummaryConfig,
): Promise<SummaryResult> {
  return request<SummaryResult>('/summarize', {
    method: 'POST',
    body: JSON.stringify({ documents, config }),
  })
}

export async function compareSummaries(
  documents: DocumentInput[],
  configs: SummaryConfig[],
): Promise<ComparisonResult> {
  return request<ComparisonResult>('/compare', {
    method: 'POST',
    body: JSON.stringify({ documents, configs }),
  })
}

export async function checkHealth(): Promise<HealthResponse> {
  return request<HealthResponse>('/health')
}

export async function uploadDocuments(files: File[]): Promise<DocumentInput[]> {
  const formData = new FormData()
  files.forEach((f) => formData.append('files', f))
  const res = await fetch(`${API_BASE}/upload`, {
    method: 'POST',
    body: formData,
  })
  if (!res.ok) throw new Error('Upload failed')
  return res.json()
}
