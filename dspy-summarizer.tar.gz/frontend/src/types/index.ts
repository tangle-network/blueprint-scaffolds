export type SummaryMode = 'extractive' | 'abstractive'
export type SummaryStyle = 'academic' | 'journalistic' | 'casual' | 'technical' | 'executive'
export type SummaryLength = 'brief' | 'medium' | 'detailed'

export interface DocumentInput {
  id: string
  title: string
  content: string
  source?: string
}

export interface SummaryConfig {
  mode: SummaryMode
  style: SummaryStyle
  length: SummaryLength
  max_words?: number
  extract_key_points: boolean
  generate_timeline: boolean
  focus_topics?: string[]
}

export interface KeyPoint {
  point: string
  confidence: number
  source_document?: string
}

export interface TimelineEvent {
  date: string
  event: string
  significance: string
}

export interface ScoreMetrics {
  rouge_1: number
  rouge_2: number
  rouge_l: number
  bertscore_f1: number
}

export interface SummaryResult {
  summary: string
  mode: SummaryMode
  style: SummaryStyle
  length: SummaryLength
  key_points: KeyPoint[]
  timeline: TimelineEvent[]
  scores: ScoreMetrics
  word_count: number
  processing_time_ms: number
}

export interface ComparisonResult {
  summaries: SummaryResult[]
  comparison_notes: string
}

export interface SummarizeRequest {
  documents: DocumentInput[]
  config: SummaryConfig
}

export interface HealthResponse {
  status: string
  dspy_configured: boolean
  model: string
}
