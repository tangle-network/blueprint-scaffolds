import type { ComparisonResult } from '../types'
import { ResultCard } from './SummaryResults'

interface Props {
  comparison: ComparisonResult
}

export function ComparisonView({ comparison }: Props) {
  return (
    <div className="panel">
      <div className="panel-header">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
        Comparison Results
      </div>
      <div className="panel-body">
        <div className="comparison-container">
          {comparison.summaries.map((s, i) => (
            <ResultCard key={i} result={s} />
          ))}
        </div>
        {comparison.comparison_notes && (
          <div className="comparison-notes">
            <div className="section-title">Comparison Notes</div>
            {comparison.comparison_notes}
          </div>
        )}
      </div>
    </div>
  )
}
