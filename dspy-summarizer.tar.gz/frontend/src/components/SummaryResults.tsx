import type { SummaryResult } from '../types'

interface Props {
  result: SummaryResult
}

export function SummaryResults({ result }: Props) {
  return (
    <div className="panel">
      <div className="panel-header">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
        Summary Result
      </div>
      <div className="panel-body">
        <ResultCard result={result} />
      </div>
    </div>
  )
}

export function ResultCard({ result }: Props) {
  return (
    <div className="result-card">
      <div className="result-card-header">
        <span className={`mode-badge ${result.mode}`}>{result.mode}</span>
        <span style={{ color: 'var(--text-secondary)', fontSize: '0.85rem' }}>
          {result.style} &middot; {result.length}
        </span>
        <span className="meta">
          {result.word_count} words &middot; {(result.processing_time_ms / 1000).toFixed(1)}s
        </span>
      </div>
      <div className="result-card-body">
        <div className="summary-text">{result.summary}</div>

        <div className="section-title">Quality Metrics</div>
        <div className="metrics-grid">
          <MetricItem label="ROUGE-1" value={result.scores.rouge_1} />
          <MetricItem label="ROUGE-2" value={result.scores.rouge_2} />
          <MetricItem label="ROUGE-L" value={result.scores.rouge_l} />
          <MetricItem label="BERTScore" value={result.scores.bertscore_f1} />
        </div>

        {result.key_points.length > 0 && (
          <>
            <div className="section-title">Key Points</div>
            <ul className="key-points-list">
              {result.key_points.map((kp, i) => (
                <li key={i}>
                  <span className="kp-bullet">&bull;</span>
                  <span>{kp.point}</span>
                  <span className="kp-confidence">
                    {(kp.confidence * 100).toFixed(0)}%
                  </span>
                </li>
              ))}
            </ul>
          </>
        )}

        {result.timeline.length > 0 && (
          <>
            <div className="section-title">Timeline</div>
            <ul className="timeline-list">
              {result.timeline.map((ev, i) => (
                <li key={i}>
                  <div className="timeline-date">{ev.date}</div>
                  <div className="timeline-event">{ev.event}</div>
                  <div className="timeline-significance">{ev.significance}</div>
                </li>
              ))}
            </ul>
          </>
        )}
      </div>
    </div>
  )
}

function MetricItem({ label, value }: { label: string; value: number }) {
  return (
    <div className="metric-item">
      <div className="metric-label">{label}</div>
      <div className="metric-value">{value.toFixed(3)}</div>
    </div>
  )
}
