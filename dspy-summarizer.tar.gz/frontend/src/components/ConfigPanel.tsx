import type { SummaryConfig, SummaryMode, SummaryStyle, SummaryLength } from '../types'

interface Props {
  config: SummaryConfig
  onChange: (config: SummaryConfig) => void
}

const MODES: { value: SummaryMode; label: string }[] = [
  { value: 'extractive', label: 'Extractive' },
  { value: 'abstractive', label: 'Abstractive' },
]

const STYLES: { value: SummaryStyle; label: string }[] = [
  { value: 'academic', label: 'Academic' },
  { value: 'journalistic', label: 'Journalistic' },
  { value: 'casual', label: 'Casual' },
  { value: 'technical', label: 'Technical' },
  { value: 'executive', label: 'Executive' },
]

const LENGTHS: { value: SummaryLength; label: string }[] = [
  { value: 'brief', label: 'Brief' },
  { value: 'medium', label: 'Medium' },
  { value: 'detailed', label: 'Detailed' },
]

export function ConfigPanel({ config, onChange }: Props) {
  const update = <K extends keyof SummaryConfig>(key: K, value: SummaryConfig[K]) => {
    onChange({ ...config, [key]: value })
  }

  return (
    <>
      <div className="form-group">
        <label>Summarization Mode</label>
        <div className="radio-grid">
          {MODES.map((m) => (
            <div key={m.value} className="radio-option">
              <input
                type="radio"
                name={`mode-${config.mode}`}
                checked={config.mode === m.value}
                onChange={() => update('mode', m.value)}
              />
              <label>{m.label}</label>
            </div>
          ))}
        </div>
      </div>

      <div className="form-group">
        <label>Output Style</label>
        <div className="radio-grid">
          {STYLES.map((s) => (
            <div key={s.value} className="radio-option">
              <input
                type="radio"
                name={`style-${config.style}`}
                checked={config.style === s.value}
                onChange={() => update('style', s.value)}
              />
              <label>{s.label}</label>
            </div>
          ))}
        </div>
      </div>

      <div className="form-group">
        <label>Output Length</label>
        <div className="radio-grid">
          {LENGTHS.map((l) => (
            <div key={l.value} className="radio-option">
              <input
                type="radio"
                name={`length-${config.length}`}
                checked={config.length === l.value}
                onChange={() => update('length', l.value)}
              />
              <label>{l.label}</label>
            </div>
          ))}
        </div>
      </div>

      <div className="form-group">
        <label>Max Words (optional)</label>
        <input
          type="text"
          value={config.max_words ?? ''}
          onChange={(e) => {
            const v = parseInt(e.target.value, 10)
            update('max_words', isNaN(v) ? undefined : v)
          }}
          placeholder="Auto"
        />
      </div>

      <div className="form-group">
        <label>Focus Topics (comma separated, optional)</label>
        <input
          type="text"
          value={config.focus_topics?.join(', ') ?? ''}
          onChange={(e) => {
            const topics = e.target.value
              .split(',')
              .map((t) => t.trim())
              .filter(Boolean)
            update('focus_topics', topics.length > 0 ? topics : undefined)
          }}
          placeholder="e.g., climate, economy, technology"
        />
      </div>

      <div className="checkbox-group">
        <input
          type="checkbox"
          id={`kp-${config.mode}`}
          checked={config.extract_key_points}
          onChange={(e) => update('extract_key_points', e.target.checked)}
        />
        <label htmlFor={`kp-${config.mode}`}>Extract Key Points</label>
      </div>

      <div className="checkbox-group">
        <input
          type="checkbox"
          id={`tl-${config.mode}`}
          checked={config.generate_timeline}
          onChange={(e) => update('generate_timeline', e.target.checked)}
        />
        <label htmlFor={`tl-${config.mode}`}>Generate Timeline</label>
      </div>
    </>
  )
}
