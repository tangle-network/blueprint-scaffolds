import { useCallback, useRef, useState } from 'react'
import type { DocumentInput } from '../types'

interface Props {
  onUpload: (docs: DocumentInput[]) => void
}

export function FileUploadZone({ onUpload }: Props) {
  const [dragover, setDragover] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  const processFiles = useCallback(
    async (files: FileList | File[]) => {
      const docs: DocumentInput[] = []
      for (const file of Array.from(files)) {
        const text = await file.text()
        docs.push({
          id: `upload-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          title: file.name,
          content: text,
          source: file.name,
        })
      }
      if (docs.length > 0) onUpload(docs)
    },
    [onUpload],
  )

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setDragover(false)
      if (e.dataTransfer.files.length) processFiles(e.dataTransfer.files)
    },
    [processFiles],
  )

  return (
    <div
      className={`upload-zone ${dragover ? 'dragover' : ''}`}
      onDragOver={(e) => {
        e.preventDefault()
        setDragover(true)
      }}
      onDragLeave={() => setDragover(false)}
      onDrop={handleDrop}
      onClick={() => inputRef.current?.click()}
    >
      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
      <p>Drop files here or click to browse</p>
      <p className="hint">Supports .txt, .md, .csv, .json files</p>
      <input
        ref={inputRef}
        type="file"
        multiple
        accept=".txt,.md,.csv,.json,.text"
        style={{ display: 'none' }}
        onChange={(e) => e.target.files && processFiles(e.target.files)}
      />
    </div>
  )
}
