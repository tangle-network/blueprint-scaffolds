import { useState, useEffect, useCallback, useRef } from 'react'
import type {
  DocumentInput,
  SummaryConfig,
  SummaryResult,
  ComparisonResult,
  SummaryMode,
  SummaryStyle,
  SummaryLength,
} from './types'
import * as api from './api/client'
import { FileUploadZone } from './components/FileUploadZone'
import { ConfigPanel } from './components/ConfigPanel'
import { SummaryResults } from './components/SummaryResults'
import { ComparisonView } from './components/ComparisonView'

type Tab = 'summarize' | 'compare'

const DEFAULT_CONFIG: SummaryConfig = {
  mode: 'abstractive',
  style: 'journalistic',
  length: 'medium',
  extract_key_points: true,
  generate_timeline: false,
}

function App() {
  const [tab, setTab] = useState<Tab>('summarize')
  const [documents, setDocuments] = useState<DocumentInput[]>([])
  const [config, setConfig] = useState<SummaryConfig>(DEFAULT_CONFIG)
  const [compareConfigs, setCompareConfigs] = useState<SummaryConfig[]>([
    { ...DEFAULT_CONFIG, mode: 'extractive' },
    { ...DEFAULT_CONFIG, mode: 'abstractive' },
  ])
  const [result, setResult] = useState<SummaryResult | null>(null)
  const [comparison, setComparison] = useState<ComparisonResult | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [backendOnline, setBackendOnline] = useState(false)
  const idCounter = useRef(0)

  useEffect(() => {
    api.checkHealth().then(
      (h) => setBackendOnline(h.status === 'ok'),
      () => setBackendOnline(false),
    )
  }, [])

  const addDocuments = useCallback((docs: DocumentInput[]) => {
    setDocuments((prev) => [...prev, ...docs])
  }, [])

  const removeDocument = useCallback((id: string) => {
    setDocuments((prev) => prev.filter((d) => d.id !== id))
  }, [])

  const addTextDocument = useCallback(() => {
    idCounter.current += 1
    const doc: DocumentInput = {
      id: `doc-${idCounter.current}`,
      title: `Document ${documents.length + 1}`,
      content: '',
    }
    setDocuments((prev) => [...prev, doc])
  }, [documents.length])

  const updateDocument = useCallback((id: string, field: keyof DocumentInput, value: string) => {
    setDocuments((prev) =>
      prev.map((d) => (d.id === id ? { ...d, [field]: value } : d)),
    )
  }, [])

  const handleSummarize = useCallback(async () => {
    const validDocs = documents.filter((d) => d.content.trim())
    if (validDocs.length === 0) {
      setError('Please add at least one document with content')
      return
    }
    setLoading(true)
    setError(null)
    setResult(null)
    try {
      const res = await api.summarize(validDocs, config)
      setResult(res)
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [documents, config])

  const handleCompare = useCallback(async () => {
    const validDocs = documents.filter((d) => d.content.trim())
    if (validDocs.length === 0) {
      setError('Please add at least one document with content')
      return
    }
    if (compareConfigs.length < 2) {
      setError('Need at least 2 configurations for comparison')
      return
    }
    setLoading(true)
    setError(null)
    setComparison(null)
    try {
      const res = await api.compareSummaries(validDocs, compareConfigs)
      setComparison(res)
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [documents, compareConfigs])

  return (
    <div className="app-container">
      <header className="app-header">
        <div>
          <h1>DSPy Summarizer</h1>
          <p className="subtitle">Advanced multi-document summarization with DSPy</p>
        </div>
        <div className={`status-badge ${backendOnline ? 'online' : 'offline'}`}>
          <span className="status-dot" />
          {backendOnline ? 'Backend Online' : 'Backend Offline'}
        </div>
      </header>

      <div className="tabs">
        <button
          className={`tab-btn ${tab === 'summarize' ? 'active' : ''}`}
          onClick={() => setTab('summarize')}
        >
          Summarize
        </button>
        <button
          className={`tab-btn ${tab === 'compare' ? 'active' : ''}`}
          onClick={() => setTab('compare')}
        >
          Compare Modes
        </button>
      </div>

      <div className="main-layout">
        <div className="panel">
          <div className="panel-header">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
            Documents
          </div>
          <div className="panel-body">
            <FileUploadZone
              onUpload={addDocuments}
            />
            <button className="btn btn-secondary" onClick={addTextDocument} style={{ width: '100%', marginBottom: 16 }}>
              + Add Text Document
            </button>
            <ul className="doc-list">
              {documents.map((doc) => (
                <li key={doc.id} className="doc-item">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                  <input
                    className="doc-title"
                    value={doc.title}
                    onChange={(e) => updateDocument(doc.id, 'title', e.target.value)}
                    style={{ background: 'transparent', border: 'none', color: 'inherit', fontFamily: 'inherit', fontSize: 'inherit', outline: 'none', width: '100%' }}
                  />
                  <button className="doc-remove" onClick={() => removeDocument(doc.id)}>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                  </button>
                </li>
              ))}
            </ul>
            {documents.map(
              (doc) =>
                doc.content !== undefined && (
                  <div key={`textarea-${doc.id}`} className="form-group" style={{ marginTop: 12 }}>
                    <label>{doc.title} — Content</label>
                    <textarea
                      value={doc.content}
                      onChange={(e) => updateDocument(doc.id, 'content', e.target.value)}
                      placeholder="Paste or type document content here..."
                    />
                  </div>
                ),
            )}
          </div>
        </div>

        <div className="panel">
          <div className="panel-header">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
            Configuration
          </div>
          <div className="panel-body">
            {tab === 'summarize' ? (
              <>
                <ConfigPanel config={config} onChange={setConfig} />
                <button
                  className="btn btn-primary"
                  onClick={handleSummarize}
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <span className="spinner" style={{ width: 16, height: 16 }} />
                      Processing...
                    </>
                  ) : (
                    'Generate Summary'
                  )}
                </button>
              </>
            ) : (
              <>
                {compareConfigs.map((cfg, idx) => (
                  <div key={idx} style={{ marginBottom: 24, paddingBottom: 16, borderBottom: '1px solid var(--border)' }}>
                    <h4 style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', marginBottom: 12 }}>
                      Configuration {idx + 1}
                    </h4>
                    <ConfigPanel
                      config={cfg}
                      onChange={(c) => {
                        const next = [...compareConfigs]
                        next[idx] = c
                        setCompareConfigs(next)
                      }}
                    />
                  </div>
                ))}
                <button
                  className="btn btn-secondary"
                  onClick={() =>
                    setCompareConfigs((prev) => [...prev, { ...DEFAULT_CONFIG }])
                  }
                  style={{ width: '100%', marginBottom: 12 }}
                >
                  + Add Configuration
                </button>
                <button
                  className="btn btn-primary"
                  onClick={handleCompare}
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <span className="spinner" style={{ width: 16, height: 16 }} />
                      Comparing...
                    </>
                  ) : (
                    'Compare Summaries'
                  )}
                </button>
              </>
            )}
          </div>
        </div>

        {error && (
          <div className="full-width">
            <div className="error-banner">{error}</div>
          </div>
        )}

        {loading && !result && (
          <div className="full-width loading-overlay">
            <span className="spinner" />
            <span>Generating summary with DSPy...</span>
          </div>
        )}

        {tab === 'summarize' && result && (
          <div className="results-panel">
            <SummaryResults result={result} />
          </div>
        )}

        {tab === 'compare' && comparison && (
          <div className="results-panel">
            <ComparisonView comparison={comparison} />
          </div>
        )}

        {!loading && !result && !comparison && (
          <div className="full-width">
            <div className="panel">
              <div className="empty-state">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>
                <p>Add documents and configure settings to generate a summary</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default App
