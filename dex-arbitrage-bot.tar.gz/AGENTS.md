# AGENTS.md

Build a DEX arbitrage bot for Ethereum mainnet. Monitor price differences across DEXes, execute profitable trades, manage gas costs, track P&L.

## What's here

This project was scaffolded by starter-foundry. The user's prompt drove the choices below — read their prompt first, it takes priority over everything in this file.

- **Family:** `agent-service-ts`
- **Layers:** `framework:agent-service-ts`, `capability:agent-trading`, `database:sqlite`, `sdk:evm-wallet`, `auth:none`, `payments:none`, `queue:none`

### Architecture notes
- Agent control loop: plan → act → reflect
- Tool registration
- Memory/state management
- HTTP health endpoint
- Create lib/wagmi.ts with wagmi config (chains, transports, connectors).
- Wrap root layout: WagmiProvider → QueryClientProvider → RainbowKit/ConnectKit provider.
- Use useAccount(), useBalance(), useSendTransaction() hooks in components.
- For SIWE: generate nonce server-side, sign client-side, verify server-side.

## Getting started

```bash
node agent.mjs
```

Key files: `agent.mjs`, `agent.config.json`

## Suggested build plan

These are starting points — adapt them to the user's actual needs.

- **API routes:** /api/strategy, /api/positions, /api/risk
- **Components:** StrategyConfig, PositionTable, PnLChart, RiskDashboard, WalletProvider, ConnectButton, AccountDisplay, ChainSwitcher
- **Data models:** Position, Order, Signal, RiskLimit, ConnectedWallet, Chain, Transaction
- **Integrations:** Exchange API (from exchange config), Market data WebSocket, WalletConnect v2, Coinbase Wallet SDK, SIWE auth

## How to use this scaffold

This is a starting point, not a contract. You own every file.

- **Customize freely.** Replace components, change the layout, swap the color scheme — whatever fits the user's product.
- **The scaffold saves you setup time** — Tailwind, shadcn/ui, path aliases, and framework config are ready. Don't redo them.
- **Check `.starter-foundry/compose-report.json`** if you want to see which layer wrote which file.
- **Update this file** as the project evolves. Delete sections that no longer apply.
