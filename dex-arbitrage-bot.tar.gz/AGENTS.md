# AGENTS.md

## Goal

Build a DEX arbitrage bot for Ethereum mainnet. Monitor price differences across DEXes, execute profitable trades, manage gas costs, track P&L.

## Stack

- Family: `agent-service-ts`
- Layers: `capability:agent-trading`, `database:sqlite`, `sdk:evm-wallet`, `auth:none`, `payments:none`, `queue:none`

## Architecture

- Agent control loop: plan → act → reflect
- Tool registration
- Memory/state management
- HTTP health endpoint
- Create lib/wagmi.ts with wagmi config (chains, transports, connectors).
- Wrap root layout: WagmiProvider → QueryClientProvider → RainbowKit/ConnectKit provider.
- Use useAccount(), useBalance(), useSendTransaction() hooks in components.
- For SIWE: generate nonce server-side, sign client-side, verify server-side.

## Entry Points

- `agent.mjs`
- `agent.config.json`

## Commands

- `node agent.mjs`

## Build Plan

API routes: /api/strategy, /api/positions, /api/risk
Components: StrategyConfig, PositionTable, PnLChart, RiskDashboard, WalletProvider, ConnectButton, AccountDisplay, ChainSwitcher
Data models: Position, Order, Signal, RiskLimit, ConnectedWallet, Chain, Transaction
Integrations: Exchange API (from exchange config), Market data WebSocket, WalletConnect v2, Coinbase Wallet SDK, SIWE auth

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
