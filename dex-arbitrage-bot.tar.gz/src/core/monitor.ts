import { ethers } from "ethers";
import type { PoolState, PriceQuote, PoolInfo } from "../types/index.js";

const UNISWAP_PAIR_ABI = [
  "function getReserves() view view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast)",
  "event Swap(address indexed sender, uint amount0In, uint amount1In, uint amount0Out, uint amount1Out, address indexed to)",
];

const CURVE_POOL_ABI = [
  "function get_dy(int128 i, int128 j, uint256 dx) view returns (uint256)",
  "function coins(uint256 i) view returns (address)",
  "event TokenExchange(address indexed buyer, int128 sold_id, uint256 tokens_sold, int128 bought_id, uint256 tokens_bought)",
];

export class PoolMonitor {
  private provider: ethers.WebSocketProvider;
  private poolStates: Map<string, PoolState> = new Map();
  private listeners: Array<(quotes: PriceQuote[]) => void> = [];

  constructor(wsUrl: string) {
    this.provider = new ethers.WebSocketProvider(wsUrl);
  }

  async start(pools: PoolInfo[]): Promise<void> {
    for (const pool of pools) {
      await this.subscribePool(pool);
    }
  }

  private async subscribePool(pool: PoolInfo): Promise<void> {
    if (pool.dex === "curve") {
      await this.subscribeCurvePool(pool);
    } else {
      await this.subscribeUniswapV2Pool(pool);
    }
  }

  private async subscribeUniswapV2Pool(pool: PoolInfo): Promise<void> {
    const contract = new ethers.Contract(pool.address, UNISWAP_PAIR_ABI, this.provider);

    const reserves = await contract.getReserves();
    this.poolStates.set(pool.address, {
      pool,
      reserveA: BigInt(reserves.reserve0.toString()),
      reserveB: BigInt(reserves.reserve1.toString()),
      lastUpdate: Date.now(),
    });

    contract.on("Swap", async () => {
      try {
        const res = await contract.getReserves();
        const state: PoolState = {
          pool,
          reserveA: BigInt(res.reserve0.toString()),
          reserveB: BigInt(res.reserve1.toString()),
          lastUpdate: Date.now(),
        };
        this.poolStates.set(pool.address, state);
        this.emitQuotes(pool.address);
      } catch {
        // ignore stale call errors on reconnect
      }
    });
  }

  private async subscribeCurvePool(pool: PoolInfo): Promise<void> {
    const contract = new ethers.Contract(pool.address, CURVE_POOL_ABI, this.provider);

    contract.on("TokenExchange", async () => {
      try {
        const dy = await contract.get_dy(0, 1, ethers.parseUnits("1", pool.tokenA.decimals));
        const state: PoolState = {
          pool,
          reserveA: BigInt(ethers.parseUnits("1000000", pool.tokenA.decimals).toString()),
          reserveB: BigInt(dy.toString()) * 1000000n,
          lastUpdate: Date.now(),
        };
        this.poolStates.set(pool.address, state);
        this.emitQuotes(pool.address);
      } catch {
        // ignore
      }
    });
  }

  private emitQuotes(poolAddress: string): void {
    const state = this.poolStates.get(poolAddress);
    if (!state) return;

    const { pool, reserveA, reserveB } = state;
    const feeMul = 10000n - BigInt(pool.feeBps);

    const quoteForward: PriceQuote = {
      pool,
      inputToken: pool.tokenA.address,
      outputToken: pool.tokenB.address,
      inputAmount: reserveA / 1000n,
      outputAmount: this.getAmountOut(reserveA / 1000n, reserveA, reserveB, feeMul),
      timestamp: Date.now(),
    };

    const quoteReverse: PriceQuote = {
      pool,
      inputToken: pool.tokenB.address,
      outputToken: pool.tokenA.address,
      inputAmount: reserveB / 1000n,
      outputAmount: this.getAmountOut(reserveB / 1000n, reserveB, reserveA, feeMul),
      timestamp: Date.now(),
    };

    const quotes = [quoteForward, quoteReverse];
    for (const cb of this.listeners) {
      cb(quotes);
    }
  }

  private getAmountOut(amountIn: bigint, reserveIn: bigint, reserveOut: bigint, feeMul: bigint): bigint {
    const amountInWithFee = amountIn * feeMul;
    const numerator = amountInWithFee * reserveOut;
    const denominator = reserveIn * 10000n + amountInWithFee;
    return numerator / denominator;
  }

  getPoolState(poolAddress: string): PoolState | undefined {
    return this.poolStates.get(poolAddress);
  }

  getAllStates(): Map<string, PoolState> {
    return this.poolStates;
  }

  onUpdate(cb: (quotes: PriceQuote[]) => void): void {
    this.listeners.push(cb);
  }

  async stop(): Promise<void> {
    this.provider.destroy();
  }
}
