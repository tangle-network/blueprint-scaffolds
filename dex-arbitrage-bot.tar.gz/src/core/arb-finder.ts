import { ethers } from "ethers";
import type { ArbOpportunity, PriceQuote, PoolState, RouteHop, PoolInfo } from "../types/index.js";

interface TokenPair {
  tokenA: string;
  tokenB: string;
}

interface RouteResult {
  hops: RouteHop[];
  inputAmount: bigint;
  expectedOutput: bigint;
  profitWei: bigint;
  gasEstimate: bigint;
  pools: PoolInfo[];
}

export class ArbFinder {
  private poolStates: Map<string, PoolState> = new Map();
  private gasPrice: bigint = 0n;
  private ethPriceUsd: number = 2000;

  updatePoolStates(states: Map<string, PoolState>): void {
    this.poolStates = states;
  }

  updateGasPrice(gasPrice: bigint): void {
    this.gasPrice = gasPrice;
  }

  updateEthPrice(usd: number): void {
    this.ethPriceUsd = usd;
  }

  findOpportunities(minProfitUsd: number): ArbOpportunity[] {
    const opportunities: ArbOpportunity[] = [];
    const tokenPairs = this.getTokenPairs();

    for (const pair of tokenPairs) {
      const poolsForPair = this.getPoolsForPair(pair);
      if (poolsForPair.length < 2) continue;

      for (let i = 0; i < poolsForPair.length; i++) {
        for (let j = 0; j < poolsForPair.length; j++) {
          if (i === j) continue;
          const route = this.evaluateRoute(
            poolsForPair[i],
            poolsForPair[j],
            pair,
            minProfitUsd
          );
          if (route) {
            opportunities.push(route);
          }
        }
      }
    }

    return opportunities.sort((a, b) => b.netProfitUsd - a.netProfitUsd);
  }

  private getTokenPairs(): TokenPair[] {
    const pairs: Map<string, TokenPair> = new Map();
    for (const [_, state] of this.poolStates) {
      const key = [state.pool.tokenA.address, state.pool.tokenB.address].sort().join("-");
      if (!pairs.has(key)) {
        pairs.set(key, {
          tokenA: state.pool.tokenA.address,
          tokenB: state.pool.tokenB.address,
        });
      }
    }
    return Array.from(pairs.values());
  }

  private getPoolsForPair(pair: TokenPair): PoolState[] {
    const pools: PoolState[] = [];
    for (const [_, state] of this.poolStates) {
      const tA = state.pool.tokenA.address.toLowerCase();
      const tB = state.pool.tokenB.address.toLowerCase();
      const pA = pair.tokenA.toLowerCase();
      const pB = pair.tokenB.toLowerCase();
      if ((tA === pA && tB === pB) || (tA === pB && tB === pA)) {
        pools.push(state);
      }
    }
    return pools;
  }

  private evaluateRoute(
    buyPool: PoolState,
    sellPool: PoolState,
    pair: TokenPair,
    minProfitUsd: number
  ): ArbOpportunity | null {
    const buyFee = 10000n - BigInt(buyPool.pool.feeBps);
    const sellFee = 10000n - BigInt(sellPool.pool.feeBps);

    const testAmounts = [
      buyPool.reserveA / 100n,
      buyPool.reserveA / 50n,
      buyPool.reserveA / 20n,
      buyPool.reserveA / 10n,
      buyPool.reserveA / 5n,
    ];

    let bestOpp: ArbOpportunity | null = null;

    for (const inputAmount of testAmounts) {
      if (inputAmount <= 0n) continue;

      const buyOutput = this.getAmountOut(inputAmount, buyPool.reserveA, buyPool.reserveB, buyFee);
      if (buyOutput <= 0n) continue;

      const sellOutput = this.getAmountOut(buyOutput, sellPool.reserveB, sellPool.reserveA, sellFee);
      if (sellOutput <= 0n) continue;

      const grossProfit = sellOutput - inputAmount;
      if (grossProfit <= 0n) continue;

      const gasCost = this.estimateGasCost(buyPool.pool.dex === "curve" || sellPool.pool.dex === "curve");
      const premium = (inputAmount * 9n) / 10000n;
      const netProfitWei = grossProfit - premium - gasCost;

      const tokenDecimals = buyPool.pool.tokenA.decimals;
      const netProfitEth = Number(ethers.formatUnits(netProfitWei > 0n ? netProfitWei : 0n, tokenDecimals));
      const netProfitUsd = netProfitEth * this.ethPriceUsd;

      if (netProfitUsd < minProfitUsd) continue;

      if (!bestOpp || netProfitUsd > bestOpp.netProfitUsd) {
        const gasCostEth = Number(ethers.formatUnits(gasCost, 18));
        const grossProfitEth = Number(ethers.formatUnits(grossProfit, tokenDecimals));

        bestOpp = {
          id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          route: [
            { pool: buyPool.pool, tokenIn: pair.tokenA, tokenOut: pair.tokenB },
            { pool: sellPool.pool, tokenIn: pair.tokenB, tokenOut: pair.tokenA },
          ],
          inputToken: pair.tokenA,
          outputToken: pair.tokenA,
          inputAmount,
          expectedOutput: sellOutput,
          profitWei: grossProfit,
          profitUsd: grossProfitEth * this.ethPriceUsd,
          gasCostWei: gasCost,
          gasCostUsd: gasCostEth * this.ethPriceUsd,
          netProfitUsd,
          timestamp: Date.now(),
        };
      }
    }

    return bestOpp;
  }

  private getAmountOut(amountIn: bigint, reserveIn: bigint, reserveOut: bigint, feeMul: bigint): bigint {
    const amountInWithFee = amountIn * feeMul;
    const numerator = amountInWithFee * reserveOut;
    const denominator = reserveIn * 10000n + amountInWithFee;
    return numerator / denominator;
  }

  private estimateGasCost(hasCurve: boolean): bigint {
    const gasLimit = hasCurve ? 500000n : 350000n;
    return gasLimit * this.gasPrice;
  }
}
