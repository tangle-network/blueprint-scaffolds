import type { BotConfig } from "../types/index.js";

export const DEFAULT_CONFIG: BotConfig = {
  rpcUrl: process.env.RPC_URL || "http://localhost:8545",
  wsUrl: process.env.WS_URL || "ws://localhost:8546",
  flashbotsRelayUrl: process.env.FLASHBOTS_RELAY || "https://relay.flashbots.net",
  privateKey: process.env.PRIVATE_KEY || "",
  aaveLendingPool: process.env.AAVE_LENDING_POOL || "0x7d2768dE32b0b80b7a3454c06BdAc94A69DDc7A9",
  monitorTokens: [
    { address: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2", symbol: "WETH", decimals: 18 },
    { address: "0x6B175474E89094C44Da98b954EedeAC495271d0F", symbol: "DAI", decimals: 18 },
    { address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48", symbol: "USDC", decimals: 6 },
    { address: "0xdAC17F958D2ee523a2206206994597C13D831ec7", symbol: "USDT", decimals: 6 },
    { address: "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599", symbol: "WBTC", decimals: 8 },
  ],
  monitorPools: [
    {
      address: "0x0d4a11d5EEaaC28EC3F61d100daF4d40471f1852",
      dex: "uniswap",
      tokenA: { address: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2", symbol: "WETH", decimals: 18 },
      tokenB: { address: "0x6B175474E89094C44Da98b954EedeAC495271d0F", symbol: "DAI", decimals: 18 },
      feeBps: 30,
    },
    {
      address: "0xCBCdF9626bC03E24f779434178A73a0B4bad62eD",
      dex: "sushiswap",
      tokenA: { address: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2", symbol: "WETH", decimals: 18 },
      tokenB: { address: "0x6B175474E89094C44Da98b954EedeAC495271d0F", symbol: "DAI", decimals: 18 },
      feeBps: 30,
    },
    {
      address: "0xA478c2975Ab1Ea89e8196811F51A7B7Ade33eB11",
      dex: "uniswap",
      tokenA: { address: "0x6B175474E89094C44Da98b954EedeAC495271d0F", symbol: "DAI", decimals: 18 },
      tokenB: { address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48", symbol: "USDC", decimals: 6 },
      feeBps: 5,
    },
    {
      address: "0x397FF1542f962076d0BFE58eA045FfA2d347ACa0",
      dex: "sushiswap",
      tokenA: { address: "0x6B175474E89094C44Da98b954EedeAC495271d0F", symbol: "DAI", decimals: 18 },
      tokenB: { address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48", symbol: "USDC", decimals: 6 },
      feeBps: 5,
    },
    {
      address: "0xD51a44d3FaE010294C616388b506AcdA1bfAAE46",
      dex: "curve",
      tokenA: { address: "0x6B175474E89094C44Da98b954EedeAC495271d0F", symbol: "DAI", decimals: 18 },
      tokenB: { address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48", symbol: "USDC", decimals: 6 },
      feeBps: 4,
    },
  ],
  minProfitUsd: 5,
  maxGasPriceGwei: 100,
  flashLoanPremiumBps: 9,
  simulationEnabled: true,
  dbPath: "./data/arbitrage.db",
  dashboardPort: 3001,
};

export function loadConfig(overrides?: Partial<BotConfig>): BotConfig {
  return { ...DEFAULT_CONFIG, ...overrides };
}
