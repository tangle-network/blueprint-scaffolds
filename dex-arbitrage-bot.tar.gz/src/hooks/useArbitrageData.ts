import { useState, useEffect, useCallback } from 'react'
import type { ArbitrageOpportunity, PnLEntry, PnLSummary, MonitoringStatus, Pool, BotConfig } from '@/types'
import { WETH, USDC, USDT, DAI, WBTC, DEFAULT_CONFIG } from '@/lib/constants'

const MOCK_POOLS: Pool[] = [
  { address: '0x1', tokenA: WETH, tokenB: USDC, dex: 'uniswap', fee: 0.05, reserveA: 1000n, reserveB: 3000000000n, price: 3000, liquidity: 5000000, lastUpdated: Date.now() },
  { address: '0x2', tokenA: WETH, tokenB: USDC, dex: 'sushiswap', fee: 0.05, reserveA: 800n, reserveB: 2400000000n, price: 3005, liquidity: 4000000, lastUpdated: Date.now() },
  { address: '0x3', tokenA: WETH, tokenB: USDT, dex: 'uniswap', fee: 0.05, reserveA: 1200n, reserveB: 3600000000n, price: 2998, liquidity: 6000000, lastUpdated: Date.now() },
  { address: '0x4', tokenA: WETH, tokenB: USDT, dex: 'curve', fee: 0.04, reserveA: 900n, reserveB: 2700000000n, price: 3002, liquidity: 3500000, lastUpdated: Date.now() },
  { address: '0x5', tokenA: WETH, tokenB: DAI, dex: 'sushiswap', fee: 0.05, reserveA: 500n, reserveB: 1500000000n, price: 3001, liquidity: 2000000, lastUpdated: Date.now() },
  { address: '0x6', tokenA: WBTC, tokenB: WETH, dex: 'uniswap', fee: 0.05, reserveA: 100n, reserveB: 3500n, price: 17.5, liquidity: 8000000, lastUpdated: Date.now() },
  { address: '0x7', tokenA: WBTC, tokenB: USDC, dex: 'curve', fee: 0.04, reserveA: 80n, reserveB: 140000000n, price: 17500, liquidity: 3000000, lastUpdated: Date.now() },
  { address: '0x8', tokenA: USDC, tokenB: USDT, dex: 'curve', fee: 0.01, reserveA: 50000000n, reserveB: 50000000n, price: 1.0001, liquidity: 100000000, lastUpdated: Date.now() },
]

function generateOpportunity(): ArbitrageOpportunity {
  const pairs = [
    { start: WETH, end: USDC, pair: 'WETH/USDC' },
    { start: WETH, end: USDT, pair: 'WETH/USDT' },
    { start: WETH, end: DAI, pair: 'WETH/DAI' },
    { start: WBTC, end: WETH, pair: 'WBTC/WETH' },
    { start: USDC, end: USDT, pair: 'USDC/USDT' },
  ]
  const pair = pairs[Math.floor(Math.random() * pairs.length)]
  const profit = Math.random() * 50 + 2
  const inputAmt = Math.random() * 10000 + 1000
  const statuses: ArbitrageOpportunity['status'][] = ['detected', 'simulating', 'ready', 'executing', 'completed', 'failed', 'expired']
  const status = statuses[Math.floor(Math.random() * statuses.length)]
  const gasCost = Math.random() * 8 + 2

  return {
    id: `opp-${Math.random().toString(36).slice(2, 8)}`,
    timestamp: Date.now() - Math.random() * 300000,
    routes: [{
      id: `route-${Math.random().toString(36).slice(2, 8)}`,
      hops: [],
      startToken: pair.start,
      endToken: pair.end,
      inputAmount: inputAmt,
      expectedOutput: inputAmt + profit,
      profitUsd: profit,
      profitPercent: (profit / inputAmt) * 100,
      gasCost,
      netProfit: profit - gasCost,
      confidence: Math.random() * 0.4 + 0.6,
      dexes: Math.random() > 0.5 ? ['uniswap', 'sushiswap'] : ['uniswap', 'curve'],
      flashLoanFee: inputAmt * 0.0009,
    }],
    bestRoute: {
      id: `route-${Math.random().toString(36).slice(2, 8)}`,
      hops: [],
      startToken: pair.start,
      endToken: pair.end,
      inputAmount: inputAmt,
      expectedOutput: inputAmt + profit,
      profitUsd: profit,
      profitPercent: (profit / inputAmt) * 100,
      gasCost,
      netProfit: profit - gasCost,
      confidence: Math.random() * 0.4 + 0.6,
      dexes: Math.random() > 0.5 ? ['uniswap', 'sushiswap'] : ['uniswap', 'curve'],
      flashLoanFee: inputAmt * 0.0009,
    },
    status,
    blockNumber: 19_000_000 + Math.floor(Math.random() * 1000),
    gasPrice: Math.random() * 30 + 10,
    flashLoanProvider: Math.random() > 0.5 ? 'aave' : 'dydx',
  }
}

function generatePnLEntry(daysAgo: number): PnLEntry {
  const profit = (Math.random() - 0.3) * 100
  const gas = Math.random() * 10 + 2
  const pairs = ['WETH/USDC', 'WETH/USDT', 'WBTC/WETH', 'USDC/USDT', 'WETH/DAI']
  const routes = ['Uniswap→SushiSwap', 'Uniswap→Curve', 'SushiSwap→Curve', 'Curve→Uniswap']
  return {
    id: `pnl-${Math.random().toString(36).slice(2, 8)}`,
    timestamp: Date.now() - daysAgo * 86400000 - Math.random() * 86400000,
    opportunityId: `opp-${Math.random().toString(36).slice(2, 8)}`,
    profitUsd: profit,
    gasCostUsd: gas,
    netProfitUsd: profit - gas,
    tokenPair: pairs[Math.floor(Math.random() * pairs.length)],
    route: routes[Math.floor(Math.random() * routes.length)],
    txHash: `0x${Math.random().toString(16).slice(2, 66)}`,
    blockNumber: 19_000_000 + Math.floor(Math.random() * 1000),
    success: profit > 0,
  }
}

const PNL_ENTRIES: PnLEntry[] = Array.from({ length: 50 }, (_, i) => generatePnLEntry(Math.floor(i / 3)))

export function useArbitrageData() {
  const [opportunities, setOpportunities] = useState<ArbitrageOpportunity[]>(() =>
    Array.from({ length: 15 }, () => generateOpportunity())
  )
  const [pnlEntries] = useState<PnLEntry[]>(PNL_ENTRIES)
  const [pools] = useState<Pool[]>(MOCK_POOLS)

  useEffect(() => {
    const interval = setInterval(() => {
      setOpportunities(prev => {
        const newOpp = generateOpportunity()
        const updated = [newOpp, ...prev].slice(0, 20)
        return updated
      })
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  const pnlSummary: PnLSummary = useCallback(() => {
    const total = pnlEntries.reduce((acc, e) => acc + e.netProfitUsd, 0)
    const successes = pnlEntries.filter(e => e.success)
    const last24h = pnlEntries.filter(e => Date.now() - e.timestamp < 86400000).reduce((a, e) => a + e.netProfitUsd, 0)
    const last7d = pnlEntries.filter(e => Date.now() - e.timestamp < 604800000).reduce((a, e) => a + e.netProfitUsd, 0)
    return {
      totalProfit: pnlEntries.reduce((a, e) => a + e.profitUsd, 0),
      totalGasCost: pnlEntries.reduce((a, e) => a + e.gasCostUsd, 0),
      totalNetProfit: total,
      tradeCount: pnlEntries.length,
      successRate: pnlEntries.length > 0 ? (successes.length / pnlEntries.length) * 100 : 0,
      avgProfit: pnlEntries.length > 0 ? total / pnlEntries.length : 0,
      bestTrade: successes.length > 0 ? successes.reduce((a, b) => a.netProfitUsd > b.netProfitUsd ? a : b) : null,
      last24hProfit: last24h,
      last7dProfit: last7d,
    }
  }, [pnlEntries])()

  return { opportunities, pnlEntries, pnlSummary, pools }
}

export function useMonitoring() {
  const [status, setStatus] = useState<MonitoringStatus>({
    connected: true,
    poolsTracked: 8,
    lastBlock: 19_000_432,
    wsLatency: 12,
    opportunitiesDetected: 156,
    tradesExecuted: 43,
    uptime: Date.now() - 86400000 * 3,
    memoryUsage: 256,
    cpuUsage: 23,
  })

  useEffect(() => {
    const interval = setInterval(() => {
      setStatus(prev => ({
        ...prev,
        lastBlock: prev.lastBlock + 1,
        wsLatency: Math.max(5, Math.min(50, prev.wsLatency + (Math.random() - 0.5) * 8)),
        memoryUsage: Math.max(200, Math.min(512, prev.memoryUsage + (Math.random() - 0.5) * 20)),
        cpuUsage: Math.max(10, Math.min(80, prev.cpuUsage + (Math.random() - 0.5) * 10)),
        opportunitiesDetected: prev.opportunitiesDetected + (Math.random() > 0.7 ? 1 : 0),
        tradesExecuted: prev.tradesExecuted + (Math.random() > 0.9 ? 1 : 0),
      }))
    }, 3000)
    return () => clearInterval(interval)
  }, [])

  return status
}

export function useConfig() {
  const [config, setConfig] = useState<BotConfig>(DEFAULT_CONFIG)
  const updateConfig = useCallback((updates: Partial<BotConfig>) => {
    setConfig(prev => ({ ...prev, ...updates }))
  }, [])
  return { config, updateConfig }
}
