import { Routes, Route } from 'react-router-dom'
import { Layout } from '@/components/Layout'
import DashboardPage from '@/pages/Dashboard'
import OpportunitiesPage from '@/pages/Opportunities'
import RoutesPage from '@/pages/Routes'
import FlashLoansPage from '@/pages/FlashLoans'
import PnLPage from '@/pages/PnL'
import MonitoringPage from '@/pages/Monitoring'
import SettingsPage from '@/pages/Settings'

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<DashboardPage />} />
        <Route path="/opportunities" element={<OpportunitiesPage />} />
        <Route path="/routes" element={<RoutesPage />} />
        <Route path="/flash-loans" element={<FlashLoansPage />} />
        <Route path="/pnl" element={<PnLPage />} />
        <Route path="/monitoring" element={<MonitoringPage />} />
        <Route path="/settings" element={<SettingsPage />} />
      </Route>
    </Routes>
  )
}
