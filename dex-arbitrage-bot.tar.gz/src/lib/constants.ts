import type { Token, DEX } from '@/types'

export const WETH: Token = {
  symbol: 'WETH',
  name: 'Wrapped Ether',
  address: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
  decimals: 18,
}

export const USDC: Token = {
  symbol: 'USDC',
  name: 'USD Coin',
  address: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
  decimals: 6,
}

export const USDT: Token = {
  symbol: 'USDT',
  name: 'Tether USD',
  address: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
  decimals: 6,
}

export const DAI: Token = {
  symbol: 'DAI',
  name: 'Dai Stablecoin',
  address: '0x6B175474E89094C44Da98b954EedeAC495271d0F',
  decimals: 18,
}

export const WBTC: Token = {
  symbol: 'WBTC',
  name: 'Wrapped BTC',
  address: '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599',
  decimals: 8,
}

export const COMMON_TOKENS: Token[] = [WETH, USDC, USDT, DAI, WBTC]

export const DEX_INFO: Record<DEX, { name: string; color: string; router: string }> = {
  uniswap: {
    name: 'Uniswap V3',
    color: '#FF007A',
    router: '0xEfF92A263d31888d860bD50809A8D171709b7b1c',
  },
  sushiswap: {
    name: 'SushiSwap',
    color: '#FA52A0',
    router: '0xd9e1cE17f2641f24aE83637ab66a2cca9C378B9F',
  },
  curve: {
    name: 'Curve Finance',
    color: '#0000FF',
    router: '0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D',
  },
}

export const AAVE_LENDING_POOL = '0x7d2768dE32b0b80b7a3454c06BdAc94A69DDc7A9'
export const FLASHBOTS_RELAY = 'https://relay.flashbots.net'

export const DEFAULT_CONFIG = {
  maxGasPriceGwei: 50,
  minProfitUsd: 5,
  minProfitPercent: 0.3,
  maxPositionSize: 100000,
  flashLoanProvider: 'aave' as const,
  enabledDexes: ['uniswap', 'sushiswap', 'curve'] as DEX[],
  enabledPairs: ['WETH/USDC', 'WETH/USDT', 'WETH/DAI', 'WBTC/WETH', 'WBTC/USDC'],
  autoExecute: false,
  flashbotsEnabled: true,
  simulationEnabled: true,
  maxSlippage: 0.5,
}
