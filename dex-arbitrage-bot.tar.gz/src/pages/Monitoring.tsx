import { useMonitoring } from '@/hooks/useArbitrageData'
import { useArbitrageData } from '@/hooks/useArbitrageData'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Separator } from '@/components/ui/separator'
import { formatNumber, formatTimestamp, timeAgo } from '@/lib/utils'
import { DEX_INFO } from '@/lib/constants'
import {
  Activity,
  Wifi,
  Cpu,
  HardDrive,
  Clock,
  Server,
  Radio,
  Database,
  CheckCircle2,
  XCircle,
  AlertTriangle,
} from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts'

function generateCpuHistory() {
  const data = []
  for (let i = 30; i >= 0; i--) {
    data.push({
      time: `${i}m`,
      cpu: Math.max(10, Math.min(80, 23 + (Math.random() - 0.5) * 20)),
      memory: Math.max(200, Math.min(512, 256 + (Math.random() - 0.5) * 40)),
    })
  }
  return data
}

const CPU_HISTORY = generateCpuHistory()

function generateLatencyHistory() {
  const data = []
  for (let i = 30; i >= 0; i--) {
    data.push({
      time: `${i}m`,
      latency: Math.max(5, Math.min(50, 12 + (Math.random() - 0.5) * 15)),
    })
  }
  return data
}

const LATENCY_HISTORY = generateLatencyHistory()

const WS_EVENTS = [
  { time: Date.now() - 5000, type: 'pool_update', status: 'success', message: 'Uniswap WETH/USDC price updated' },
  { time: Date.now() - 8000, type: 'pool_update', status: 'success', message: 'SushiSwap WETH/USDT price updated' },
  { time: Date.now() - 12000, type: 'arbitrage_detected', status: 'warning', message: 'Arb detected: WETH/USDC spread 0.17%' },
  { time: Date.now() - 15000, type: 'price_update', status: 'success', message: 'Curve USDC/USDT price updated' },
  { time: Date.now() - 20000, type: 'trade_executed', status: 'success', message: 'Flash loan executed: +$23.45 profit' },
  { time: Date.now() - 25000, type: 'pool_update', status: 'success', message: 'Uniswap WBTC/WETH price updated' },
  { time: Date.now() - 30000, type: 'error', status: 'error', message: 'Simulation failed: insufficient liquidity' },
  { time: Date.now() - 35000, type: 'pool_update', status: 'success', message: 'Curve WETH/USDT price updated' },
]

export default function MonitoringPage() {
  const monitoring = useMonitoring()
  const { pools } = useArbitrageData()

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Monitoring</h1>
        <p className="text-sm text-muted-foreground">WebSocket pool monitoring and system health</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">WebSocket</CardTitle>
            <Wifi className="h-4 w-4 text-emerald-500" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <span className="h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-2xl font-bold">Connected</span>
            </div>
            <p className="text-xs text-muted-foreground">Latency: {monitoring.wsLatency.toFixed(0)}ms</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">CPU Usage</CardTitle>
            <Cpu className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{monitoring.cpuUsage.toFixed(0)}%</div>
            <div className="mt-1 h-2 w-full rounded-full bg-secondary overflow-hidden">
              <div
                className="h-full rounded-full bg-blue-500 transition-all"
                style={{ width: `${monitoring.cpuUsage}%` }}
              />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Memory</CardTitle>
            <HardDrive className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{monitoring.memoryUsage.toFixed(0)} MB</div>
            <div className="mt-1 h-2 w-full rounded-full bg-secondary overflow-hidden">
              <div
                className="h-full rounded-full bg-amber-500 transition-all"
                style={{ width: `${(monitoring.memoryUsage / 512) * 100}%` }}
              />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Uptime</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{timeAgo(monitoring.uptime)}</div>
            <p className="text-xs text-muted-foreground">Since last restart</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">CPU / Memory History</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={CPU_HISTORY}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                  <XAxis dataKey="time" tick={{ fontSize: 10 }} stroke="#666" interval={5} />
                  <YAxis tick={{ fontSize: 10 }} stroke="#666" />
                  <Tooltip contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #333', borderRadius: 6 }} />
                  <Area type="monotone" dataKey="cpu" stroke="#3b82f6" fill="#3b82f620" name="CPU %" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">WS Latency History</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={LATENCY_HISTORY}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                  <XAxis dataKey="time" tick={{ fontSize: 10 }} stroke="#666" interval={5} />
                  <YAxis tick={{ fontSize: 10 }} stroke="#666" />
                  <Tooltip contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #333', borderRadius: 6 }} />
                  <Line type="monotone" dataKey="latency" stroke="#10b981" strokeWidth={2} dot={false} name="Latency (ms)" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm flex items-center gap-2">
              <Database className="h-4 w-4" /> Tracked Pools
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Pool</TableHead>
                  <TableHead>DEX</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Liquidity</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pools.map(pool => (
                  <TableRow key={pool.address}>
                    <TableCell className="font-medium">{pool.tokenA.symbol}/{pool.tokenB.symbol}</TableCell>
                    <TableCell>
                      <Badge variant="outline" style={{ borderColor: DEX_INFO[pool.dex].color, color: DEX_INFO[pool.dex].color }}>
                        {DEX_INFO[pool.dex].name.split(' ')[0]}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-mono">{pool.price.toFixed(pool.price > 100 ? 2 : 4)}</TableCell>
                    <TableCell>${(pool.liquidity / 1000000).toFixed(1)}M</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm flex items-center gap-2">
              <Radio className="h-4 w-4" /> WebSocket Events
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-80 overflow-y-auto">
              {WS_EVENTS.map((event, i) => (
                <div key={i} className="flex items-start gap-2 rounded-md border p-2 text-sm">
                  {event.status === 'success' && <CheckCircle2 className="h-4 w-4 text-emerald-500 mt-0.5 shrink-0" />}
                  {event.status === 'warning' && <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5 shrink-0" />}
                  {event.status === 'error' && <XCircle className="h-4 w-4 text-red-500 mt-0.5 shrink-0" />}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary" className="text-xs">{event.type}</Badge>
                      <span className="text-xs text-muted-foreground">{timeAgo(event.time)}</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">{event.message}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
