import { useArbitrageData } from '@/hooks/useArbitrageData'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { formatUsd, formatPercent, formatNumber } from '@/lib/utils'
import { DEX_INFO } from '@/lib/constants'
import { ArrowRight, Route as RouteIcon, Gauge, Shield, Zap } from 'lucide-react'

function RouteCard({ opp, rank }: { opp: ReturnType<typeof useArbitrageData>['opportunities'][0]; rank: number }) {
  const route = opp.bestRoute
  const dexA = route.dexes[0]
  const dexB = route.dexes[1]

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <RouteIcon className="h-4 w-4" />
            {route.startToken.symbol}/{route.endToken.symbol}
          </CardTitle>
          <Badge variant="outline">#{rank}</Badge>
        </div>
        <CardDescription>Route {route.id}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between rounded-md border p-3">
          <div className="text-center">
            <div className="text-xs text-muted-foreground">Buy</div>
            <Badge variant="outline" style={{ borderColor: DEX_INFO[dexA].color, color: DEX_INFO[dexA].color }}>
              {DEX_INFO[dexA].name}
            </Badge>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-px flex-1 bg-border w-16" />
            <ArrowRight className="h-4 w-4 text-muted-foreground" />
            <div className="h-px flex-1 bg-border w-16" />
          </div>
          <div className="text-center">
            <div className="text-xs text-muted-foreground">Sell</div>
            <Badge variant="outline" style={{ borderColor: DEX_INFO[dexB].color, color: DEX_INFO[dexB].color }}>
              {DEX_INFO[dexB].name}
            </Badge>
          </div>
        </div>

        <Separator />

        <div className="grid grid-cols-2 gap-3 text-sm">
          <div>
            <div className="text-muted-foreground text-xs">Input Amount</div>
            <div className="font-medium">{formatUsd(route.inputAmount)}</div>
          </div>
          <div>
            <div className="text-muted-foreground text-xs">Expected Output</div>
            <div className="font-medium">{formatUsd(route.expectedOutput)}</div>
          </div>
          <div>
            <div className="text-muted-foreground text-xs flex items-center gap-1">
              <Zap className="h-3 w-3" /> Flash Loan Fee
            </div>
            <div className="font-medium">{formatUsd(route.flashLoanFee)}</div>
          </div>
          <div>
            <div className="text-muted-foreground text-xs flex items-center gap-1">
              <Gauge className="h-3 w-3" /> Gas Cost
            </div>
            <div className="font-medium">{formatUsd(route.gasCost)}</div>
          </div>
        </div>

        <Separator />

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Shield className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Confidence</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-2 w-24 rounded-full bg-secondary overflow-hidden">
              <div
                className="h-full rounded-full bg-emerald-500"
                style={{ width: `${route.confidence * 100}%` }}
              />
            </div>
            <span className="text-sm font-medium">{(route.confidence * 100).toFixed(0)}%</span>
          </div>
        </div>

        <div className="flex items-center justify-between rounded-md bg-emerald-500/10 p-3">
          <span className="text-sm font-medium text-emerald-700 dark:text-emerald-400">Net Profit</span>
          <div className="text-right">
            <div className="font-bold text-emerald-700 dark:text-emerald-400">{formatUsd(route.netProfit)}</div>
            <div className="text-xs text-emerald-600 dark:text-emerald-500">{formatPercent(route.profitPercent)}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default function RoutesPage() {
  const { opportunities } = useArbitrageData()

  const profitableRoutes = opportunities
    .filter(o => o.bestRoute.netProfit > 0)
    .sort((a, b) => b.bestRoute.netProfit - a.bestRoute.netProfit)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Routes</h1>
        <p className="text-sm text-muted-foreground">Multi-path arbitrage routes ranked by profitability</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {profitableRoutes.slice(0, 9).map((opp, i) => (
          <RouteCard key={opp.id} opp={opp} rank={i + 1} />
        ))}
      </div>

      {profitableRoutes.length === 0 && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <RouteIcon className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground">No profitable routes currently detected</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
