import { useArbitrageData, useMonitoring } from '@/hooks/useArbitrageData'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { formatUsd, formatPercent, timeAgo, formatNumber } from '@/lib/utils'
import { DEX_INFO } from '@/lib/constants'
import {
  DollarSign,
  TrendingUp,
  Activity,
  Zap,
  Flame,
  BarChart3,
} from 'lucide-react'
import type { ArbitrageOpportunity } from '@/types'

function StatusBadge({ status }: { status: ArbitrageOpportunity['status'] }) {
  const variants: Record<string, 'success' | 'warning' | 'destructive' | 'secondary' | 'default'> = {
    detected: 'secondary',
    simulating: 'warning',
    ready: 'success',
    executing: 'default',
    completed: 'success',
    failed: 'destructive',
    expired: 'destructive',
  }
  return <Badge variant={variants[status] || 'secondary'}>{status}</Badge>
}

export default function DashboardPage() {
  const { opportunities, pnlSummary, pools } = useArbitrageData()
  const monitoring = useMonitoring()

  const recentOpps = opportunities.slice(0, 5)
  const activeOpps = opportunities.filter(o => ['detected', 'simulating', 'ready', 'executing'].includes(o.status))

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <p className="text-sm text-muted-foreground">Real-time DEX arbitrage overview</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Net Profit (24h)</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatUsd(pnlSummary.last24hProfit)}</div>
            <p className="text-xs text-muted-foreground">{formatPercent(pnlSummary.last24hProfit / Math.max(1, pnlSummary.totalNetProfit) * 100)} of total</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Opportunities</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeOpps.length}</div>
            <p className="text-xs text-muted-foreground">{opportunities.length} total detected</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pnlSummary.successRate.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">{pnlSummary.tradeCount} trades executed</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Gas Cost</CardTitle>
            <Flame className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatUsd(pnlSummary.totalGasCost / Math.max(1, pnlSummary.tradeCount))}</div>
            <p className="text-xs text-muted-foreground">{formatUsd(pnlSummary.totalGasCost)} total</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pools Tracked</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{monitoring.poolsTracked}</div>
            <p className="text-xs text-muted-foreground">Across 3 DEXes</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Net Profit</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatUsd(pnlSummary.totalNetProfit)}</div>
            <p className="text-xs text-muted-foreground">7d: {formatUsd(pnlSummary.last7dProfit)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Flash Loans Used</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{monitoring.tradesExecuted}</div>
            <p className="text-xs text-muted-foreground">{monitoring.opportunitiesDetected} opportunities detected</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Opportunities</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Pair</TableHead>
                <TableHead>Profit</TableHead>
                <TableHead>Net</TableHead>
                <TableHead>DEXes</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Block</TableHead>
                <TableHead>Time</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {recentOpps.map(opp => (
                <TableRow key={opp.id}>
                  <TableCell className="font-medium">
                    {opp.bestRoute.startToken.symbol}/{opp.bestRoute.endToken.symbol}
                  </TableCell>
                  <TableCell className="text-emerald-500">{formatUsd(opp.bestRoute.profitUsd)}</TableCell>
                  <TableCell className={opp.bestRoute.netProfit > 0 ? 'text-emerald-500' : 'text-red-500'}>
                    {formatUsd(opp.bestRoute.netProfit)}
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      {opp.bestRoute.dexes.map(d => (
                        <Badge key={d} variant="outline" style={{ borderColor: DEX_INFO[d].color, color: DEX_INFO[d].color }}>
                          {DEX_INFO[d].name.split(' ')[0]}
                        </Badge>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell><StatusBadge status={opp.status} /></TableCell>
                  <TableCell className="font-mono text-xs">{formatNumber(opp.blockNumber, 0)}</TableCell>
                  <TableCell className="text-muted-foreground">{timeAgo(opp.timestamp)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
