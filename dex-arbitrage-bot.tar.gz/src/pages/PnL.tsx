import { useArbitrageData } from '@/hooks/useArbitrageData'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { formatUsd, formatPercent, formatTimestamp, formatAddress, timeAgo } from '@/lib/utils'
import { TrendingUp, TrendingDown, DollarSign, BarChart3, Trophy } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts'

export default function PnLPage() {
  const { pnlEntries, pnlSummary } = useArbitrageData()

  const byRoute = pnlEntries.reduce<Record<string, { profit: number; count: number }>>((acc, e) => {
    if (!acc[e.route]) acc[e.route] = { profit: 0, count: 0 }
    acc[e.route].profit += e.netProfitUsd
    acc[e.route].count += 1
    return acc
  }, {})

  const routeChartData = Object.entries(byRoute).map(([route, data]) => ({
    route,
    profit: Number(data.profit.toFixed(2)),
    trades: data.count,
  }))

  const byDay = pnlEntries.reduce<Record<string, number>>((acc, e) => {
    const day = new Date(e.timestamp).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
    acc[day] = (acc[day] || 0) + e.netProfitUsd
    return acc
  }, {})

  const dailyChartData = Object.entries(byDay).map(([day, profit]) => ({
    day,
    profit: Number(profit.toFixed(2)),
  }))

  const successCount = pnlEntries.filter(e => e.success).length
  const failCount = pnlEntries.length - successCount
  const pieData = [
    { name: 'Success', value: successCount, color: '#10b981' },
    { name: 'Failed', value: failCount, color: '#ef4444' },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Profit & Loss</h1>
        <p className="text-sm text-muted-foreground">Historical trading performance analytics</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Profit</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-500">{formatUsd(pnlSummary.totalProfit)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Gas Cost</CardTitle>
            <TrendingDown className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-500">{formatUsd(pnlSummary.totalGasCost)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Net Profit</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatUsd(pnlSummary.totalNetProfit)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pnlSummary.successRate.toFixed(1)}%</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Best Trade</CardTitle>
            <Trophy className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-500">
              {pnlSummary.bestTrade ? formatUsd(pnlSummary.bestTrade.netProfitUsd) : '$0.00'}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="daily">
        <TabsList>
          <TabsTrigger value="daily">Daily P&L</TabsTrigger>
          <TabsTrigger value="routes">By Route</TabsTrigger>
          <TabsTrigger value="success">Success Rate</TabsTrigger>
        </TabsList>
        <TabsContent value="daily">
          <Card>
            <CardHeader>
              <CardTitle>Daily Net Profit</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={dailyChartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                    <XAxis dataKey="day" tick={{ fontSize: 12 }} stroke="#888" />
                    <YAxis tick={{ fontSize: 12 }} stroke="#888" />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #333', borderRadius: 6 }}
                      formatter={(value: number) => [formatUsd(value), 'Profit']}
                    />
                    <Bar dataKey="profit" fill="#10b981" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="routes">
          <Card>
            <CardHeader>
              <CardTitle>Profit by Route</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={routeChartData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                    <XAxis type="number" tick={{ fontSize: 12 }} stroke="#888" />
                    <YAxis dataKey="route" type="category" tick={{ fontSize: 12 }} stroke="#888" width={120} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #333', borderRadius: 6 }}
                      formatter={(value: number) => [formatUsd(value), 'Profit']}
                    />
                    <Bar dataKey="profit" fill="#6366f1" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="success">
          <Card>
            <CardHeader>
              <CardTitle>Trade Outcomes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={pieData} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                      {pieData.map((entry, i) => (
                        <Cell key={i} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>Trade History</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Time</TableHead>
                <TableHead>Pair</TableHead>
                <TableHead>Route</TableHead>
                <TableHead>Profit</TableHead>
                <TableHead>Gas</TableHead>
                <TableHead>Net</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Tx</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pnlEntries.slice(0, 20).map(entry => (
                <TableRow key={entry.id}>
                  <TableCell className="text-xs text-muted-foreground">{timeAgo(entry.timestamp)}</TableCell>
                  <TableCell className="font-medium">{entry.tokenPair}</TableCell>
                  <TableCell className="text-xs">{entry.route}</TableCell>
                  <TableCell className={entry.profitUsd > 0 ? 'text-emerald-500' : 'text-red-500'}>
                    {formatUsd(entry.profitUsd)}
                  </TableCell>
                  <TableCell className="text-red-500">{formatUsd(entry.gasCostUsd)}</TableCell>
                  <TableCell className={entry.netProfitUsd > 0 ? 'text-emerald-500 font-medium' : 'text-red-500 font-medium'}>
                    {formatUsd(entry.netProfitUsd)}
                  </TableCell>
                  <TableCell>
                    <Badge variant={entry.success ? 'success' : 'destructive'}>
                      {entry.success ? 'Success' : 'Failed'}
                    </Badge>
                  </TableCell>
                  <TableCell className="font-mono text-xs">{formatAddress(entry.txHash)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
