import { useConfig } from '@/hooks/useArbitrageData'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Separator } from '@/components/ui/separator'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { FLASHBOTS_RELAY, DEX_INFO } from '@/lib/constants'
import { formatUsd, formatNumber } from '@/lib/utils'
import type { DEX } from '@/types'
import { Settings as SettingsIcon, Shield, Zap, Gauge, Cpu, Save, RotateCcw } from 'lucide-react'

function SettingRow({ label, description, children }: { label: string; description: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between py-3">
      <div className="space-y-0.5">
        <div className="text-sm font-medium">{label}</div>
        <div className="text-xs text-muted-foreground">{description}</div>
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  )
}

export default function SettingsPage() {
  const { config, updateConfig } = useConfig()

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-sm text-muted-foreground">Configure arbitrage bot parameters</p>
      </div>

      <Tabs defaultValue="general">
        <TabsList>
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="dexes">DEXes</TabsTrigger>
          <TabsTrigger value="flash-loans">Flash Loans</TabsTrigger>
          <TabsTrigger value="advanced">Advanced</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Gauge className="h-4 w-4" /> Profit Thresholds
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-1">
              <SettingRow label="Minimum Profit (USD)" description="Skip opportunities below this threshold">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">$</span>
                  <Input
                    type="number"
                    value={config.minProfitUsd}
                    onChange={e => updateConfig({ minProfitUsd: Number(e.target.value) })}
                    className="w-24"
                  />
                </div>
              </SettingRow>
              <Separator />
              <SettingRow label="Minimum Profit (%)" description="Minimum percentage profit after gas">
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    value={config.minProfitPercent}
                    onChange={e => updateConfig({ minProfitPercent: Number(e.target.value) })}
                    className="w-24"
                  />
                  <span className="text-sm text-muted-foreground">%</span>
                </div>
              </SettingRow>
              <Separator />
              <SettingRow label="Max Position Size" description="Maximum flash loan amount per trade">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">$</span>
                  <Input
                    type="number"
                    value={config.maxPositionSize}
                    onChange={e => updateConfig({ maxPositionSize: Number(e.target.value) })}
                    className="w-32"
                  />
                </div>
              </SettingRow>
              <Separator />
              <SettingRow label="Max Slippage" description="Maximum acceptable slippage percentage">
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    value={config.maxSlippage}
                    onChange={e => updateConfig({ maxSlippage: Number(e.target.value) })}
                    className="w-24"
                  />
                  <span className="text-sm text-muted-foreground">%</span>
                </div>
              </SettingRow>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Cpu className="h-4 w-4" /> Execution
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-1">
              <SettingRow label="Auto Execute" description="Automatically execute profitable opportunities">
                <Switch
                  checked={config.autoExecute}
                  onCheckedChange={v => updateConfig({ autoExecute: v })}
                />
              </SettingRow>
              <Separator />
              <SettingRow label="Max Gas Price (Gwei)" description="Skip trades when gas exceeds this price">
                <Input
                  type="number"
                  value={config.maxGasPriceGwei}
                  onChange={e => updateConfig({ maxGasPriceGwei: Number(e.target.value) })}
                  className="w-24"
                />
              </SettingRow>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="dexes" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Enabled DEXes</CardTitle>
              <CardDescription>Toggle DEXes for arbitrage route calculation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-1">
              {(Object.keys(DEX_INFO) as DEX[]).map(dex => (
                <div key={dex}>
                  <SettingRow label={DEX_INFO[dex].name} description={`Router: ${DEX_INFO[dex].router.slice(0, 10)}...`}>
                    <Switch
                      checked={config.enabledDexes.includes(dex)}
                      onCheckedChange={v => {
                        const dexes = v
                          ? [...config.enabledDexes, dex]
                          : config.enabledDexes.filter(d => d !== dex)
                        updateConfig({ enabledDexes: dexes })
                      }}
                    />
                  </SettingRow>
                  <Separator />
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Enabled Pairs</CardTitle>
              <CardDescription>Token pairs to monitor for arbitrage</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {config.enabledPairs.map(pair => (
                  <Badge key={pair} variant="secondary">{pair}</Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="flash-loans" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Zap className="h-4 w-4" /> Flash Loan Provider
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-1">
              {(['aave', 'dydx', 'uniswap'] as const).map(provider => (
                <div key={provider}>
                  <SettingRow
                    label={provider === 'aave' ? 'Aave V3' : provider === 'dydx' ? 'dYdX' : 'Uniswap V3'}
                    description={provider === 'aave' ? '0.09% fee, most liquid' : provider === 'dydx' ? '0% fee, limited tokens' : '0.05% fee, ETH only'}
                  >
                    <Switch
                      checked={config.flashLoanProvider === provider}
                      onCheckedChange={() => updateConfig({ flashLoanProvider: provider })}
                    />
                  </SettingRow>
                  <Separator />
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Shield className="h-4 w-4" /> MEV Protection
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-1">
              <SettingRow label="Flashbots Enabled" description="Submit transactions via Flashbots relay">
                <Switch
                  checked={config.flashbotsEnabled}
                  onCheckedChange={v => updateConfig({ flashbotsEnabled: v })}
                />
              </SettingRow>
              <Separator />
              <div className="pt-2">
                <Label className="text-xs text-muted-foreground">Relay URL</Label>
                <Input value={FLASHBOTS_RELAY} readOnly className="mt-1 font-mono text-xs" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="advanced" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <SettingsIcon className="h-4 w-4" /> Advanced Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-1">
              <SettingRow label="Simulation Enabled" description="Simulate trades on mainnet before execution">
                <Switch
                  checked={config.simulationEnabled}
                  onCheckedChange={v => updateConfig({ simulationEnabled: v })}
                />
              </SettingRow>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Current Configuration</CardTitle>
              <CardDescription>Raw configuration JSON</CardDescription>
            </CardHeader>
            <CardContent>
              <pre className="rounded-md bg-secondary p-4 text-xs font-mono overflow-x-auto">
                {JSON.stringify(config, null, 2)}
              </pre>
            </CardContent>
          </Card>

          <div className="flex gap-2">
            <Button>
              <Save className="mr-2 h-4 w-4" />
              Save Configuration
            </Button>
            <Button variant="outline">
              <RotateCcw className="mr-2 h-4 w-4" />
              Reset Defaults
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
