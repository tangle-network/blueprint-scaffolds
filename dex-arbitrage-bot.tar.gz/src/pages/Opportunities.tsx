import { useState } from 'react'
import { useArbitrageData } from '@/hooks/useArbitrageData'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Input } from '@/components/ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { formatUsd, formatPercent, timeAgo, formatNumber, formatAddress } from '@/lib/utils'
import { DEX_INFO } from '@/lib/constants'
import { Search, Filter, Play, XCircle, CheckCircle, Clock, AlertTriangle } from 'lucide-react'
import type { ArbitrageOpportunity } from '@/types'

function StatusIcon({ status }: { status: ArbitrageOpportunity['status'] }) {
  switch (status) {
    case 'completed': return <CheckCircle className="h-4 w-4 text-emerald-500" />
    case 'failed': case 'expired': return <XCircle className="h-4 w-4 text-red-500" />
    case 'executing': return <Play className="h-4 w-4 text-blue-500" />
    case 'simulating': return <AlertTriangle className="h-4 w-4 text-amber-500" />
    default: return <Clock className="h-4 w-4 text-muted-foreground" />
  }
}

export default function OpportunitiesPage() {
  const { opportunities } = useArbitrageData()
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')

  const filtered = opportunities.filter(o => {
    const pair = `${o.bestRoute.startToken.symbol}/${o.bestRoute.endToken.symbol}`
    const matchesSearch = search === '' || pair.toLowerCase().includes(search.toLowerCase())
    const matchesStatus = statusFilter === 'all' || o.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const stats = {
    detected: opportunities.filter(o => o.status === 'detected').length,
    simulating: opportunities.filter(o => o.status === 'simulating').length,
    ready: opportunities.filter(o => o.status === 'ready').length,
    executing: opportunities.filter(o => o.status === 'executing').length,
    completed: opportunities.filter(o => o.status === 'completed').length,
    failed: opportunities.filter(o => o.status === 'failed').length,
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Opportunities</h1>
        <p className="text-sm text-muted-foreground">Detected arbitrage opportunities across DEXes</p>
      </div>

      <div className="grid gap-4 md:grid-cols-6">
        {Object.entries(stats).map(([key, count]) => (
          <Card key={key}>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold">{count}</div>
              <div className="text-xs text-muted-foreground capitalize">{key}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search by pair..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Tabs value={statusFilter} onValueChange={setStatusFilter}>
          <TabsList>
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="detected">Detected</TabsTrigger>
            <TabsTrigger value="ready">Ready</TabsTrigger>
            <TabsTrigger value="completed">Done</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-8" />
                <TableHead>ID</TableHead>
                <TableHead>Pair</TableHead>
                <TableHead>Input</TableHead>
                <TableHead>Profit</TableHead>
                <TableHead>Net Profit</TableHead>
                <TableHead>Gas</TableHead>
                <TableHead>DEXes</TableHead>
                <TableHead>Confidence</TableHead>
                <TableHead>Flash Loan</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Time</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map(opp => (
                <TableRow key={opp.id}>
                  <TableCell><StatusIcon status={opp.status} /></TableCell>
                  <TableCell className="font-mono text-xs">{formatAddress(opp.id)}</TableCell>
                  <TableCell className="font-medium">{opp.bestRoute.startToken.symbol}/{opp.bestRoute.endToken.symbol}</TableCell>
                  <TableCell>{formatUsd(opp.bestRoute.inputAmount)}</TableCell>
                  <TableCell className="text-emerald-500">{formatUsd(opp.bestRoute.profitUsd)}</TableCell>
                  <TableCell className={opp.bestRoute.netProfit > 0 ? 'text-emerald-500' : 'text-red-500'}>
                    {formatUsd(opp.bestRoute.netProfit)}
                  </TableCell>
                  <TableCell>{formatUsd(opp.bestRoute.gasCost)}</TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      {opp.bestRoute.dexes.map(d => (
                        <Badge key={d} variant="outline" style={{ borderColor: DEX_INFO[d].color, color: DEX_INFO[d].color }}>
                          {DEX_INFO[d].name.split(' ')[0]}
                        </Badge>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell>{(opp.bestRoute.confidence * 100).toFixed(0)}%</TableCell>
                  <TableCell>
                    <Badge variant="secondary">{opp.flashLoanProvider}</Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant={opp.status === 'completed' ? 'success' : opp.status === 'failed' ? 'destructive' : 'secondary'}>
                      {opp.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground text-xs">{timeAgo(opp.timestamp)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
