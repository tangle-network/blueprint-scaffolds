import { useArbitrageData } from '@/hooks/useArbitrageData'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { formatUsd, formatNumber, formatPercent, formatAddress } from '@/lib/utils'
import { AAVE_LENDING_POOL, DEX_INFO } from '@/lib/constants'
import { Zap, ShieldCheck, ArrowRightLeft, Database, Clock, ExternalLink } from 'lucide-react'

function FlashLoanCard({ opp }: { opp: ReturnType<typeof useArbitrageData>['opportunities'][0] }) {
  const route = opp.bestRoute
  const provider = opp.flashLoanProvider
  const providerInfo = {
    aave: { name: 'Aave V3', fee: '0.09%', color: '#B6509E' },
    dydx: { name: 'dYdX', fee: '0%', color: '#6966FF' },
    uniswap: { name: 'Uniswap V3', fee: '0.05%', color: '#FF007A' },
  }[provider]

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Zap className="h-4 w-4" />
            {route.startToken.symbol}/{route.endToken.symbol}
          </CardTitle>
          <Badge style={{ backgroundColor: providerInfo.color + '20', color: providerInfo.color }}>
            {providerInfo.name}
          </Badge>
        </div>
        <CardDescription>
          Flash loan: {formatUsd(route.inputAmount)} {route.startToken.symbol}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="rounded-md border p-3 space-y-2">
          <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Execution Flow</div>
          <div className="flex items-center gap-2 text-sm">
            <ShieldCheck className="h-4 w-4 text-blue-500 shrink-0" />
            <span>Borrow {formatUsd(route.inputAmount)} {route.startToken.symbol}</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <ArrowRightLeft className="h-4 w-4 text-amber-500 shrink-0" />
            <span>
              Buy on {DEX_INFO[route.dexes[0]].name}
              {' → '}
              Sell on {DEX_INFO[route.dexes[1]].name}
            </span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <ShieldCheck className="h-4 w-4 text-emerald-500 shrink-0" />
            <span>Repay loan + fee ({providerInfo.fee})</span>
          </div>
        </div>

        <Separator />

        <div className="grid grid-cols-2 gap-2 text-sm">
          <div>
            <div className="text-xs text-muted-foreground">Loan Amount</div>
            <div className="font-medium">{formatUsd(route.inputAmount)}</div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground">Fee</div>
            <div className="font-medium">{formatUsd(route.flashLoanFee)}</div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground">Gas Cost</div>
            <div className="font-medium">{formatUsd(route.gasCost)}</div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground">Net Profit</div>
            <div className="font-medium text-emerald-500">{formatUsd(route.netProfit)}</div>
          </div>
        </div>

        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            Block {formatNumber(opp.blockNumber, 0)}
          </div>
          <Badge variant="secondary">{opp.status}</Badge>
        </div>
      </CardContent>
    </Card>
  )
}

export default function FlashLoansPage() {
  const { opportunities } = useArbitrageData()

  const flashLoanOpps = opportunities.filter(o =>
    ['ready', 'executing', 'completed'].includes(o.status)
  )

  const totalBorrowed = flashLoanOpps.reduce((a, o) => a + o.bestRoute.inputAmount, 0)
  const totalFees = flashLoanOpps.reduce((a, o) => a + o.bestRoute.flashLoanFee, 0)
  const totalProfit = flashLoanOpps.reduce((a, o) => a + o.bestRoute.netProfit, 0)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Flash Loans</h1>
        <p className="text-sm text-muted-foreground">Aave flash loan arbitrage execution</p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Borrowed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatUsd(totalBorrowed)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Fees Paid</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatUsd(totalFees)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Net Profit</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-500">{formatUsd(totalProfit)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-1">
              <Database className="h-4 w-4" /> Aave Pool
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-sm font-mono">{formatAddress(AAVE_LENDING_POOL)}</div>
          </CardContent>
        </Card>
      </div>

      <div className="rounded-md border bg-blue-500/10 border-blue-500/20 p-4 text-sm">
        <div className="flex items-center gap-2 font-medium text-blue-700 dark:text-blue-400 mb-1">
          <ShieldCheck className="h-4 w-4" />
          Flashbots MEV Protection Active
        </div>
        <p className="text-blue-600 dark:text-blue-500">
          All flash loan transactions are submitted via Flashbots bundles to prevent front-running and sandwich attacks.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {flashLoanOpps.map(opp => (
          <FlashLoanCard key={opp.id} opp={opp} />
        ))}
      </div>

      {flashLoanOpps.length === 0 && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Zap className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground">No active flash loan executions</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
