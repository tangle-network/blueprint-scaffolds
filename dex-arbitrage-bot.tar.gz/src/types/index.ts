export type DEXProtocol = 'uniswap' | 'sushiswap' | 'curve'

export interface Token {
  symbol: string
  address: string
  decimals: number
}

export interface PoolState {
  poolAddress: string
  protocol: DEXProtocol
  tokenA: Token
  tokenB: Token
  reserveA: bigint
  reserveB: bigint
  feeBps: number
  lastUpdate: number
}

export interface PriceQuote {
  protocol: DEXProtocol
  poolAddress: string
  inputToken: string
  outputToken: string
  inputAmount: bigint
  outputAmount: bigint
  priceImpact: number
  fee: bigint
}

export interface ArbitrageRoute {
  id: string
  steps: RouteStep[]
  estimatedProfitWei: bigint
  gasCostWei: bigint
  netProfitWei: bigint
  netProfitUsd: number
  capitalRequired: bigint
  flashLoanFee: bigint
  confidence: number
}

export interface RouteStep {
  protocol: DEXProtocol
  poolAddress: string
  tokenIn: string
  tokenOut: string
  amountIn: bigint
  amountOut: bigint
}

export interface TradeExecution {
  id: string
  route: ArbitrageRoute
  txHash: string
  blockNumber: number
  submittedAt: number
  confirmedAt: number
  status: 'pending' | 'confirmed' | 'failed' | 'reverted'
  actualProfitWei: bigint
  gasUsed: bigint
  gasPrice: bigint
}

export interface BotMetrics {
  totalProfitUsd: number
  totalTrades: number
  successfulTrades: number
  failedTrades: number
  avgProfitUsd: number
  successRate: number
  totalGasSpentEth: number
  netProfitUsd: number
  activePools: number
  monitoredPairs: number
  uptime: number
}

export interface ProfitRecord {
  timestamp: number
  profitUsd: number
  gasCostEth: number
  netProfitUsd: number
  route: string
}

export interface PoolMetrics {
  poolAddress: string
  protocol: DEXProtocol
  pair: string
  volume24h: number
  feeApr: number
  lastOpportunity: number
  opportunitiesCount: number
}

export interface FlashbotBundle {
  bundleId: string
  blockTarget: number
  transactions: string[]
  signedTx: string
  submittedAt: number
  status: 'pending' | 'included' | 'failed'
}
