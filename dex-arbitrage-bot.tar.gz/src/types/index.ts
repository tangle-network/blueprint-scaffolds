export interface TokenInfo {
  address: string;
  symbol: string;
  decimals: number;
}

export interface PoolInfo {
  address: string;
  dex: DEXName;
  tokenA: TokenInfo;
  tokenB: TokenInfo;
  feeBps: number;
}

export type DEXName = "uniswap" | "sushiswap" | "curve";

export interface PriceQuote {
  pool: PoolInfo;
  inputToken: string;
  outputToken: string;
  inputAmount: bigint;
  outputAmount: bigint;
  timestamp: number;
}

export interface ArbOpportunity {
  id: string;
  route: RouteHop[];
  inputToken: string;
  outputToken: string;
  inputAmount: bigint;
  expectedOutput: bigint;
  profitWei: bigint;
  profitUsd: number;
  gasCostWei: bigint;
  gasCostUsd: number;
  netProfitUsd: number;
  timestamp: number;
}

export interface RouteHop {
  pool: PoolInfo;
  tokenIn: string;
  tokenOut: string;
}

export interface FlashLoanParams {
  asset: string;
  amount: bigint;
  premium: bigint;
  route: RouteHop[];
}

export interface TradeRecord {
  id: number;
  timestamp: number;
  tokenIn: string;
  tokenOut: string;
  amountIn: string;
  amountOut: string;
  profitWei: string;
  profitUsd: number;
  gasCostWei: string;
  gasCostUsd: number;
  netProfitUsd: number;
  txHash: string;
  status: "success" | "failed" | "simulated";
  route: string;
}

export interface BotConfig {
  rpcUrl: string;
  wsUrl: string;
  flashbotsRelayUrl: string;
  privateKey: string;
  aaveLendingPool: string;
  monitorTokens: TokenInfo[];
  monitorPools: PoolInfo[];
  minProfitUsd: number;
  maxGasPriceGwei: number;
  flashLoanPremiumBps: number;
  simulationEnabled: boolean;
  dbPath: string;
  dashboardPort: number;
}

export interface PoolState {
  pool: PoolInfo;
  reserveA: bigint;
  reserveB: bigint;
  lastUpdate: number;
}
