export type DEX = 'uniswap' | 'sushiswap' | 'curve'

export interface Token {
  symbol: string
  name: string
  address: string
  decimals: number
}

export interface Pool {
  address: string
  tokenA: Token
  tokenB: Token
  dex: DEX
  fee: number
  reserveA: bigint
  reserveB: bigint
  price: number
  liquidity: number
  lastUpdated: number
}

export interface PriceQuote {
  inputToken: Token
  outputToken: Token
  inputAmount: number
  outputAmount: number
  price: number
  priceImpact: number
  dex: DEX
  pool: Pool
  route: RouteHop[]
}

export interface RouteHop {
  pool: Pool
  tokenIn: Token
  tokenOut: Token
  fraction: number
}

export interface ArbitrageRoute {
  id: string
  hops: RouteHop[]
  startToken: Token
  endToken: Token
  inputAmount: number
  expectedOutput: number
  profitUsd: number
  profitPercent: number
  gasCost: number
  netProfit: number
  confidence: number
  dexes: DEX[]
  flashLoanFee: number
}

export interface ArbitrageOpportunity {
  id: string
  timestamp: number
  routes: ArbitrageRoute[]
  bestRoute: ArbitrageRoute
  status: 'detected' | 'simulating' | 'ready' | 'executing' | 'completed' | 'failed' | 'expired'
  blockNumber: number
  gasPrice: number
  flashLoanProvider: 'aave' | 'dydx' | 'uniswap'
}

export interface FlashLoanParams {
  provider: 'aave' | 'dydx' | 'uniswap'
  token: Token
  amount: number
  fee: number
  route: ArbitrageRoute
}

export interface FlashbotsBundle {
  transactions: string[]
  blockNumber: number
  minTimestamp: number
  maxTimestamp: number
  revertingTxHashes: string[]
}

export interface GasEstimate {
  gasLimit: number
  gasPrice: number
  maxFeePerGas: number
  maxPriorityFeePerGas: number
  totalCostEth: number
  totalCostUsd: number
}

export interface PnLEntry {
  id: string
  timestamp: number
  opportunityId: string
  profitUsd: number
  gasCostUsd: number
  netProfitUsd: number
  tokenPair: string
  route: string
  txHash: string
  blockNumber: number
  success: boolean
}

export interface PnLSummary {
  totalProfit: number
  totalGasCost: number
  totalNetProfit: number
  tradeCount: number
  successRate: number
  avgProfit: number
  bestTrade: PnLEntry | null
  last24hProfit: number
  last7dProfit: number
}

export interface WebSocketMessage {
  type: 'pool_update' | 'price_update' | 'arbitrage_detected' | 'trade_executed' | 'error' | 'status'
  data: unknown
  timestamp: number
}

export interface BotConfig {
  maxGasPriceGwei: number
  minProfitUsd: number
  minProfitPercent: number
  maxPositionSize: number
  flashLoanProvider: 'aave' | 'dydx' | 'uniswap'
  enabledDexes: DEX[]
  enabledPairs: string[]
  autoExecute: boolean
  flashbotsEnabled: boolean
  simulationEnabled: boolean
  maxSlippage: number
}

export interface MonitoringStatus {
  connected: boolean
  poolsTracked: number
  lastBlock: number
  wsLatency: number
  opportunitiesDetected: number
  tradesExecuted: number
  uptime: number
  memoryUsage: number
  cpuUsage: number
}
