import * as React from "react"
import { cn } from "@/lib/utils"

const TooltipProvider = React.createContext<{ delayDuration: number }>({ delayDuration: 200 })

const Tooltip: React.FC<{ children: React.ReactNode; content: React.ReactNode; side?: "top" | "bottom" | "left" | "right" }> = ({ children, content, side = "top" }) => {
  const [show, setShow] = React.useState(false)
  return (
    <div className="relative inline-block" onMouseEnter={() => setShow(true)} onMouseLeave={() => setShow(false)}>
      {children}
      {show && (
        <div
          className={cn(
            "absolute z-50 whitespace-nowrap rounded-md border bg-popover px-3 py-1.5 text-sm text-popover-foreground shadow-md animate-in fade-in-0 zoom-in-95",
            side === "top" && "bottom-full left-1/2 -translate-x-1/2 mb-2",
            side === "bottom" && "top-full left-1/2 -translate-x-1/2 mt-2",
            side === "left" && "right-full top-1/2 -translate-y-1/2 mr-2",
            side === "right" && "left-full top-1/2 -translate-y-1/2 ml-2",
          )}
        >
          {content}
        </div>
      )}
    </div>
  )
}

export { TooltipProvider, Tooltip }
