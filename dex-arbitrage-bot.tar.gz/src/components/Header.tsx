import { useMonitoring } from '@/hooks/useArbitrageData'
import { Badge } from '@/components/ui/badge'
import { Wifi, WifiOff, Clock } from 'lucide-react'
import { formatNumber, timeAgo } from '@/lib/utils'

export function Header() {
  const status = useMonitoring()

  return (
    <header className="flex h-14 items-center justify-between border-b bg-card px-6">
      <div className="flex items-center gap-4">
        <h2 className="text-sm font-medium text-muted-foreground">
          Ethereum Mainnet
        </h2>
        <Badge variant={status.connected ? 'success' : 'destructive'}>
          {status.connected ? (
            <Wifi className="mr-1 h-3 w-3" />
          ) : (
            <WifiOff className="mr-1 h-3 w-3" />
          )}
          {status.connected ? 'WS Connected' : 'Disconnected'}
        </Badge>
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <Clock className="h-3 w-3" />
          <span>Uptime: {timeAgo(status.uptime)}</span>
        </div>
      </div>
      <div className="flex items-center gap-6 text-xs text-muted-foreground">
        <div>Block <span className="font-mono text-foreground">{formatNumber(status.lastBlock, 0)}</span></div>
        <div>Latency <span className="font-mono text-foreground">{status.wsLatency.toFixed(0)}ms</span></div>
        <div>Pools <span className="font-mono text-foreground">{status.poolsTracked}</span></div>
      </div>
    </header>
  )
}
