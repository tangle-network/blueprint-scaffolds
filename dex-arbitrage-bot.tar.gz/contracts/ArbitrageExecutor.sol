// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "./Interfaces.sol";

contract ArbitrageExecutor is IFlashLoanReceiver {
    address public owner;
    address public lendingPool;
    uint256 public totalProfits;
    uint256 public totalTrades;
    uint256 public totalGasSpent;

    event ArbitrageExecuted(
        address indexed tokenIn,
        address indexed tokenOut,
        uint256 amountIn,
        uint256 amountOut,
        uint256 profit,
        uint256 gasUsed
    );

    event FlashLoanReceived(
        address indexed asset,
        uint256 amount,
        uint256 premium
    );

    error NotOwner();
    error NotLendingPool();
    error InsufficientProfit();
    error TransferFailed();
    error RepayFailed();

    modifier onlyOwner() {
        if (msg.sender != owner) revert NotOwner();
        _;
    }

    modifier onlyLendingPool() {
        if (msg.sender != lendingPool) revert NotLendingPool();
        _;
    }

    constructor(address _lendingPool) {
        owner = msg.sender;
        lendingPool = _lendingPool;
    }

    function executeFlashLoan(
        address asset,
        uint256 amount,
        RouteHop[] calldata route
    ) external onlyOwner {
        address[] memory assets = new address[](1);
        assets[0] = asset;

        uint256[] memory amounts = new uint256[](1);
        amounts[0] = amount;

        uint256[] memory modes = new uint256[](1);
        modes[0] = 0;

        bytes memory params = abi.encode(route);

        IAaveLendingPool(lendingPool).flashLoan(
            address(this),
            assets,
            amounts,
            modes,
            address(0),
            params,
            0
        );
    }

    function executeOperation(
        address asset,
        uint256 amount,
        uint256 premium,
        address initiator,
        bytes calldata params
    ) external onlyLendingPool returns (bool) {
        if (initiator != address(this)) revert NotOwner();

        emit FlashLoanReceived(asset, amount, premium);

        RouteHop[] memory route = abi.decode(params, (RouteHop[]));

        uint256 currentBalance = IERC20(asset).balanceOf(address(this));
        uint256 runningAmount = currentBalance;

        for (uint256 i = 0; i < route.length; i++) {
            RouteHop memory hop = route[i];

            IERC20(hop.tokenIn).approve(hop.pool, runningAmount);

            if (hop.isCurve) {
                uint256 received = ICurvePool(hop.pool).exchange(
                    hop.curveI,
                    hop.curveJ,
                    runningAmount,
                    0
                );
                runningAmount = received;
            } else {
                uint256 balanceBefore = IERC20(hop.tokenOut).balanceOf(address(this));

                address[] memory path = new address[](2);
                path[0] = hop.tokenIn;
                path[1] = hop.tokenOut;

                IUniswapV2Pair(hop.pool).swap(
                    hop.tokenIn < hop.tokenOut ? 0 : runningAmount,
                    hop.tokenIn < hop.tokenOut ? runningAmount : 0,
                    address(this),
                    new bytes(0)
                );

                uint256 balanceAfter = IERC20(hop.tokenOut).balanceOf(address(this));
                runningAmount = balanceAfter - balanceBefore;
            }
        }

        uint256 amountOwed = amount + premium;
        if (runningAmount <= amountOwed) revert InsufficientProfit();

        uint256 profit = runningAmount - amountOwed;

        IERC20(asset).approve(lendingPool, amountOwed);

        uint256 gasUsed = gasleft();

        totalProfits += profit;
        totalTrades += 1;

        if (profit > 0) {
            bool success = IERC20(asset).transfer(owner, profit);
            if (!success) revert TransferFailed();
        }

        emit ArbitrageExecuted(
            route[0].tokenIn,
            route[route.length - 1].tokenOut,
            amount,
            runningAmount,
            profit,
            gasUsed
        );

        return true;
    }

    function rescueTokens(address token, uint256 amount) external onlyOwner {
        bool success = IERC20(token).transfer(owner, amount);
        if (!success) revert TransferFailed();
    }

    function setLendingPool(address _lendingPool) external onlyOwner {
        lendingPool = _lendingPool;
    }

    function getStats() external view returns (
        uint256 _totalProfits,
        uint256 _totalTrades,
        uint256 _totalGasSpent
    ) {
        return (totalProfits, totalTrades, totalGasSpent);
    }

    receive() external payable {}
}
