# AGENTS.md

## Goal

Create a crypto wallet using the FHERC standard for token privacy. Encrypted balance storage, private transfers, UI that decrypts balances only for owner.

## Stack

- Family: `fhenix-contracts`
- Layers: `capability:fhe-private-token`

## Entry Points

- `contracts/FHECounter.sol`
- `hardhat.config.ts`
- `test/FHECounter.test.ts`

## Commands

- `npx hardhat compile`
- `npx hardhat test`

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
