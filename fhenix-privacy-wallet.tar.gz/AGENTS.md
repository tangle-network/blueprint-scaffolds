# AGENTS.md

Create a crypto wallet using the FHERC standard for token privacy. Encrypted balance storage, private transfers, UI that decrypts balances only for owner.

## What's here

This project was scaffolded by starter-foundry. The user's prompt drove the choices below — read their prompt first, it takes priority over everything in this file.

- **Family:** `fhenix-contracts`
- **Layers:** `framework:fhenix-contracts`, `capability:fhe-private-token`

## Getting started

```bash
npx hardhat compile
npx hardhat test
```

Key files: `contracts/FHECounter.sol`, `hardhat.config.ts`, `test/FHECounter.test.ts`

## How to use this scaffold

This is a starting point, not a contract. You own every file.

- **Customize freely.** Replace components, change the layout, swap the color scheme — whatever fits the user's product.
- **The scaffold saves you setup time** — Tailwind, shadcn/ui, path aliases, and framework config are ready. Don't redo them.
- **Check `.starter-foundry/compose-report.json`** if you want to see which layer wrote which file.
- **Update this file** as the project evolves. Delete sections that no longer apply.
