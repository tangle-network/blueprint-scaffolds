import type { Config } from "tailwindcss";

export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#08111f",
        mist: "#eef5ff",
        signal: "#2ce6b5",
        flare: "#ff985d",
        night: "#11243d",
      },
      boxShadow: {
        glow: "0 0 0 1px rgba(44, 230, 181, 0.35), 0 30px 80px rgba(8, 17, 31, 0.18)",
      },
      fontFamily: {
        display: ["'Space Grotesk'", "sans-serif"],
        body: ["'IBM Plex Sans'", "sans-serif"],
      },
    },
  },
  plugins: [],
} satisfies Config;
