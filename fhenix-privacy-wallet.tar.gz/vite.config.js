"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_path_1 = __importDefault(require("node:path"));
const plugin_react_1 = __importDefault(require("@vitejs/plugin-react"));
const vite_plugin_top_level_await_1 = __importDefault(require("vite-plugin-top-level-await"));
const vite_plugin_wasm_1 = __importDefault(require("vite-plugin-wasm"));
exports.default = {
    plugins: [(0, plugin_react_1.default)(), (0, vite_plugin_wasm_1.default)(), (0, vite_plugin_top_level_await_1.default)()],
    resolve: {
        alias: {
            fhenixjs: node_path_1.default.resolve(__dirname, "node_modules/fhenixjs/dist/fhenix.esm.min.js"),
        },
    },
};
