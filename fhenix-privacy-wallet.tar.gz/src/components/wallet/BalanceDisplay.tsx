"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FHERC20Token } from "@/types";
import { shortenAddress } from "@/lib/utils";
import { Eye, Lock, Shield } from "lucide-react";

interface BalanceDisplayProps {
  token: FHERC20Token | null;
  decryptedBalance: number | null | undefined;
  isDecrypting: boolean;
}

export function BalanceDisplay({ token, decryptedBalance, isDecrypting }: BalanceDisplayProps) {
  if (!token) {
    return (
      <Card className="glow-border border-primary/20">
        <CardContent className="py-8 text-center text-muted-foreground">
          <Shield className="mx-auto mb-2 h-8 w-8 opacity-50" />
          <p className="text-sm">Select a token to view balance</p>
        </CardContent>
      </Card>
    );
  }

  const isDecrypted = decryptedBalance !== undefined && decryptedBalance !== null;

  return (
    <Card className="glow-border border-primary/20">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Eye className="h-5 w-5 text-primary" />
          Balance Decryption
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Token</p>
              <p className="font-medium">{token.name}</p>
              <p className="text-xs text-muted-foreground">
                {token.symbol} — {shortenAddress(token.address, 10)}
              </p>
            </div>
          </div>

          <div className="rounded-lg border border-border/50 bg-secondary/30 p-4">
            <p className="text-xs text-muted-foreground mb-1">
              {isDecrypted ? "Decrypted Balance (owner-only)" : "Encrypted Balance"}
            </p>
            {isDecrypting ? (
              <div className="flex items-center gap-2">
                <div className="h-6 w-32 animate-pulse rounded bg-muted" />
                <p className="text-xs text-muted-foreground">Decrypting...</p>
              </div>
            ) : isDecrypted ? (
              <div className="flex items-center gap-2">
                <p className="text-2xl font-mono font-bold text-foreground">
                  {decryptedBalance!.toLocaleString()}
                </p>
                <span className="text-sm text-muted-foreground">{token.symbol}</span>
                <Eye className="h-4 w-4 text-green-400" />
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <span className="encrypted-pulse text-2xl font-mono text-muted-foreground">
                  ••••••••
                </span>
                <Lock className="h-4 w-4 text-muted-foreground" />
              </div>
            )}
          </div>

          <p className="text-xs text-muted-foreground leading-relaxed">
            Balances are stored as encrypted euint32 values on-chain. Only the owner with
            the correct decryption key can reveal the actual amount. Third-party observers
            see only encrypted ciphertext.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
