"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Loader2 } from "lucide-react";

interface CreateTokenDialogProps {
  isCreating: boolean;
  onSubmit: (name: string, symbol: string) => Promise<void>;
}

export function CreateTokenDialog({ isCreating, onSubmit }: CreateTokenDialogProps) {
  const [name, setName] = useState("");
  const [symbol, setSymbol] = useState("");
  const [isOpen, setIsOpen] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !symbol) return;
    await onSubmit(name, symbol);
    setName("");
    setSymbol("");
    setIsOpen(false);
  };

  if (!isOpen) {
    return (
      <Button
        variant="outline"
        onClick={() => setIsOpen(true)}
        className="w-full border-primary/30 hover:bg-primary/10"
      >
        <Plus className="mr-2 h-4 w-4" />
        Create New FHERC-20 Token
      </Button>
    );
  }

  return (
    <Card className="glow-border border-primary/20">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Plus className="h-5 w-5 text-primary" />
          Create FHERC-20 Token
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="tokenName" className="text-sm text-muted-foreground">
              Token Name
            </Label>
            <Input
              id="tokenName"
              placeholder="Private USD"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="bg-secondary/50"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="tokenSymbol" className="text-sm text-muted-foreground">
              Symbol
            </Label>
            <Input
              id="tokenSymbol"
              placeholder="pUSD"
              value={symbol}
              onChange={(e) => setSymbol(e.target.value.toUpperCase())}
              className="bg-secondary/50"
              maxLength={8}
            />
          </div>
          <div className="flex gap-2">
            <Button
              type="submit"
              disabled={isCreating || !name || !symbol}
              className="flex-1 bg-primary hover:bg-primary/90"
            >
              {isCreating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creating...
                </>
              ) : (
                "Create Token"
              )}
            </Button>
            <Button
              type="button"
              variant="ghost"
              onClick={() => setIsOpen(false)}
            >
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
