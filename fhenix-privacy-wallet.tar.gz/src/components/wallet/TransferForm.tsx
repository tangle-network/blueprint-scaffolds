"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FHERC20Token } from "@/types";
import { shortenAddress } from "@/lib/utils";
import { Send, Loader2, Lock } from "lucide-react";

interface TransferFormProps {
  tokens: FHERC20Token[];
  selectedToken: string | null;
  isSubmitting: boolean;
  onSubmit: (to: string, amount: number) => Promise<void>;
}

export function TransferForm({
  tokens,
  selectedToken,
  isSubmitting,
  onSubmit,
}: TransferFormProps) {
  const [toAddress, setToAddress] = useState("");
  const [amount, setAmount] = useState("");

  const activeToken = tokens.find((t) => t.address === selectedToken);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!toAddress || !amount || isNaN(Number(amount))) return;
    await onSubmit(toAddress, Number(amount));
    setToAddress("");
    setAmount("");
  };

  return (
    <Card className="glow-border border-primary/20">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Send className="h-5 w-5 text-primary" />
          Private Transfer
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label className="text-sm text-muted-foreground">Token</Label>
            <div className="flex items-center gap-2 rounded-md border border-input bg-secondary/50 px-3 py-2">
              {activeToken ? (
                <>
                  <span className="text-sm">{activeToken.name}</span>
                  <span className="text-xs text-primary">({activeToken.symbol})</span>
                  <span className="text-xs text-muted-foreground ml-auto">
                    {shortenAddress(activeToken.address, 6)}
                  </span>
                </>
              ) : (
                <span className="text-sm text-muted-foreground">Select a token from the list</span>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="recipient" className="text-sm text-muted-foreground">
              Recipient Address
            </Label>
            <Input
              id="recipient"
              placeholder="0x..."
              value={toAddress}
              onChange={(e) => setToAddress(e.target.value)}
              className="bg-secondary/50 font-mono text-sm"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="amount" className="text-sm text-muted-foreground">
              Amount (encrypted)
            </Label>
            <div className="relative">
              <Input
                id="amount"
                type="number"
                placeholder="0.00"
                min="0"
                step="any"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="bg-secondary/50 pr-10 font-mono"
              />
              <Lock className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            </div>
            <p className="text-xs text-muted-foreground">
              Amount will be encrypted before submission. Observers cannot see the transfer value.
            </p>
          </div>

          <Button
            type="submit"
            disabled={
              isSubmitting ||
              !selectedToken ||
              !toAddress ||
              !amount ||
              isNaN(Number(amount))
            }
            className="w-full bg-primary hover:bg-primary/90"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Encrypting & Sending...
              </>
            ) : (
              <>
                <Send className="mr-2 h-4 w-4" />
                Send Encrypted Transfer
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
