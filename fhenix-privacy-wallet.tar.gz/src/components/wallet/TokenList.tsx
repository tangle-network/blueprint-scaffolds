"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { FHERC20Token } from "@/types";
import { shortenAddress } from "@/lib/utils";
import { Lock, Eye, EyeOff, Coins } from "lucide-react";

interface TokenListProps {
  tokens: FHERC20Token[];
  selectedToken: string | null;
  onSelect: (address: string) => void;
  onDecrypt: (address: string) => void;
  decryptedBalances: Record<string, number>;
}

export function TokenList({
  tokens,
  selectedToken,
  onSelect,
  onDecrypt,
  decryptedBalances,
}: TokenListProps) {
  if (tokens.length === 0) {
    return (
      <Card className="glow-border border-primary/20">
        <CardContent className="py-8 text-center text-muted-foreground">
          <Coins className="mx-auto mb-2 h-8 w-8 opacity-50" />
          <p className="text-sm">No tokens found</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glow-border border-primary/20">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Coins className="h-5 w-5 text-primary" />
          Token Balances
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-1">
        {tokens.map((token) => {
          const isSelected = selectedToken === token.address;
          const decrypted = decryptedBalances[token.address];
          const hasDecrypted = decrypted !== undefined && decrypted !== null;

          return (
            <div key={token.address}>
              <button
                onClick={() => onSelect(token.address)}
                className={`w-full rounded-lg p-3 text-left transition-colors hover:bg-secondary ${
                  isSelected ? "bg-secondary ring-1 ring-primary/50" : ""
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium truncate">{token.name}</p>
                      <span className="rounded bg-primary/10 px-1.5 py-0.5 text-xs text-primary">
                        {token.symbol}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {shortenAddress(token.address, 8)}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 ml-3">
                    <div className="text-right">
                      {hasDecrypted ? (
                        <div className="flex items-center gap-1">
                          <p className="text-sm font-mono font-medium">
                            {decrypted.toLocaleString()}
                          </p>
                          <Eye className="h-3 w-3 text-green-400" />
                        </div>
                      ) : (
                        <div className="flex items-center gap-1">
                          <span className="encrypted-pulse text-sm font-mono text-muted-foreground">
                            ••••••
                          </span>
                          <Lock className="h-3 w-3 text-muted-foreground" />
                        </div>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 w-7 p-0"
                      onClick={(e) => {
                        e.stopPropagation();
                        onDecrypt(token.address);
                      }}
                    >
                      {hasDecrypted ? (
                        <EyeOff className="h-3.5 w-3.5" />
                      ) : (
                        <Eye className="h-3.5 w-3.5 text-primary" />
                      )}
                    </Button>
                  </div>
                </div>
              </button>
              <Separator className="opacity-30" />
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
