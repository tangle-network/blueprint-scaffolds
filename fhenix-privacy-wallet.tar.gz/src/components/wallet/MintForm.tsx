"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FHERC20Token } from "@/types";
import { Lock, Loader2, Coins } from "lucide-react";

interface MintFormProps {
  token: FHERC20Token | null;
  isMinting: boolean;
  onSubmit: (tokenAddress: string, amount: number) => Promise<void>;
}

export function MintForm({ token, isMinting, onSubmit }: MintFormProps) {
  const [amount, setAmount] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !amount || isNaN(Number(amount))) return;
    await onSubmit(token.address, Number(amount));
    setAmount("");
  };

  if (!token) {
    return null;
  }

  return (
    <Card className="glow-border border-primary/20">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Coins className="h-5 w-5 text-primary" />
          Mint Tokens
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label className="text-sm text-muted-foreground">Token</Label>
            <div className="rounded-md border border-input bg-secondary/50 px-3 py-2 text-sm">
              {token.name} ({token.symbol})
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="mintAmount" className="text-sm text-muted-foreground">
              Amount to Mint (encrypted)
            </Label>
            <div className="relative">
              <Input
                id="mintAmount"
                type="number"
                placeholder="1000"
                min="1"
                step="1"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="bg-secondary/50 pr-10 font-mono"
              />
              <Lock className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            </div>
            <p className="text-xs text-muted-foreground">
              The mint amount is encrypted using FHE before being submitted on-chain.
            </p>
          </div>
          <Button
            type="submit"
            disabled={isMinting || !amount || isNaN(Number(amount))}
            className="w-full bg-primary hover:bg-primary/90"
          >
            {isMinting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Encrypting & Minting...
              </>
            ) : (
              <>
                <Coins className="mr-2 h-4 w-4" />
                Mint Encrypted Tokens
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
