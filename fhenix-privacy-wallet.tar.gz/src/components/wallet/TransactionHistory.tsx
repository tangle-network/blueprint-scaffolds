"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TransferRecord } from "@/types";
import { shortenAddress, formatTimestamp } from "@/lib/utils";
import { ArrowUpRight, ArrowDownLeft, History, Lock } from "lucide-react";

interface TransactionHistoryProps {
  transfers: TransferRecord[];
  currentAddress: string | null;
}

export function TransactionHistory({ transfers, currentAddress }: TransactionHistoryProps) {
  if (transfers.length === 0) {
    return (
      <Card className="glow-border border-primary/20">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg">
            <History className="h-5 w-5 text-primary" />
            Transaction History
          </CardTitle>
        </CardHeader>
        <CardContent className="py-8 text-center text-muted-foreground">
          <History className="mx-auto mb-2 h-8 w-8 opacity-50" />
          <p className="text-sm">No transactions yet</p>
          <p className="text-xs mt-1">Send your first private transfer above</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glow-border border-primary/20">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <History className="h-5 w-5 text-primary" />
          Transaction History
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {transfers
          .sort((a, b) => b.timestamp - a.timestamp)
          .map((tx) => {
            const isSent = currentAddress && tx.from.toLowerCase() === currentAddress.toLowerCase();
            return (
              <div
                key={tx.id}
                className="flex items-center gap-3 rounded-lg border border-border/50 p-3"
              >
                <div
                  className={`flex h-8 w-8 items-center justify-center rounded-full ${
                    isSent ? "bg-orange-500/10" : "bg-green-500/10"
                  }`}
                >
                  {isSent ? (
                    <ArrowUpRight className="h-4 w-4 text-orange-400" />
                  ) : (
                    <ArrowDownLeft className="h-4 w-4 text-green-400" />
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium">
                      {isSent ? "Sent" : "Received"} {tx.tokenSymbol}
                    </p>
                    <Lock className="h-3 w-3 text-muted-foreground" />
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {isSent
                      ? `To: ${shortenAddress(tx.to, 6)}`
                      : `From: ${shortenAddress(tx.from, 6)}`}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-muted-foreground">
                    {formatTimestamp(tx.timestamp)}
                  </p>
                  <p className="text-xs font-mono text-muted-foreground truncate max-w-[120px]">
                    {shortenAddress(tx.txHash, 8)}
                  </p>
                </div>
              </div>
            );
          })}
      </CardContent>
    </Card>
  );
}
