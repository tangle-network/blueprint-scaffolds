"use client";

import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { WalletState } from "@/types";
import { walletManager } from "@/lib/wallet";
import { shortenAddress } from "@/lib/utils";
import { Wallet, LogOut, Loader2, Shield } from "lucide-react";

interface WalletConnectProps {
  walletState: WalletState;
  onStateChange: (state: WalletState) => void;
}

export function WalletConnect({ walletState, onStateChange }: WalletConnectProps) {
  const [error, setError] = useState<string | null>(null);

  const connect = useCallback(async () => {
    setError(null);
    try {
      const state = await walletManager.connect();
      onStateChange(state);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to connect");
    }
  }, [onStateChange]);

  const disconnect = useCallback(async () => {
    await walletManager.disconnect();
    onStateChange(walletManager.getState());
  }, [onStateChange]);

  return (
    <Card className="glow-border border-primary/20">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Shield className="h-5 w-5 text-primary" />
          FHERC Wallet
        </CardTitle>
      </CardHeader>
      <CardContent>
        {walletState.isConnected && walletState.address ? (
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/20">
                <Wallet className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-sm font-medium">
                  {shortenAddress(walletState.address, 6)}
                </p>
                <p className="text-xs text-muted-foreground">
                  Chain ID: {walletState.chainId ?? "—"}
                </p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={disconnect}>
              <LogOut className="mr-2 h-4 w-4" />
              Disconnect
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Connect your wallet to access private token balances and transfers.
            </p>
            <Button
              onClick={connect}
              disabled={walletState.isConnecting}
              className="w-full bg-primary hover:bg-primary/90"
            >
              {walletState.isConnecting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Connecting...
                </>
              ) : (
                <>
                  <Wallet className="mr-2 h-4 w-4" />
                  Connect Wallet
                </>
              )}
            </Button>
          </div>
        )}
        {error && (
          <p className="mt-2 text-xs text-destructive">{error}</p>
        )}
      </CardContent>
    </Card>
  );
}
