"use client";

import React, { createContext, useContext, useReducer, useCallback, useEffect } from "react";
import type { WalletState, WalletAction, TokenInfo, TransactionRecord, EncryptedBalance } from "@/lib/types";
import { getAllTokens } from "@/lib/token-registry";
import { loadTransactions, saveTransactions } from "@/lib/token-registry";
import { requestEncryptionKey, generateFHEPublicKey } from "@/lib/encryption";
import { getFhenixClient, resetFhenixClient } from "@/lib/fhenix-client";
import { FHERC20_DEFAULT_TOKENS } from "@/lib/constants";

const initialState: WalletState = {
  address: null,
  isConnected: false,
  chainId: null,
  encryptionKey: null,
  balances: new Map(),
  tokens: [],
  transactions: [],
  isLoading: false,
};

function walletReducer(state: WalletState, action: WalletAction): WalletState {
  switch (action.type) {
    case "SET_ADDRESS":
      return { ...state, address: action.address };
    case "SET_CONNECTED":
      return { ...state, isConnected: action.isConnected };
    case "SET_CHAIN_ID":
      return { ...state, chainId: action.chainId };
    case "SET_ENCRYPTION_KEY":
      return { ...state, encryptionKey: action.key };
    case "SET_BALANCE": {
      const newBalances = new Map(state.balances);
      newBalances.set(action.tokenAddress, action.balance);
      return { ...state, balances: newBalances };
    }
    case "SET_TOKENS":
      return { ...state, tokens: action.tokens };
    case "ADD_TOKEN":
      return { ...state, tokens: [...state.tokens, action.token] };
    case "ADD_TRANSACTION":
      return { ...state, transactions: [action.tx, ...state.transactions] };
    case "SET_LOADING":
      return { ...state, isLoading: action.isLoading };
    case "RESET":
      return { ...initialState };
    default:
      return state;
  }
}

interface WalletContextValue {
  state: WalletState;
  connect: () => Promise<void>;
  disconnect: () => void;
  refreshBalances: () => Promise<void>;
  transfer: (tokenAddress: `0x${string}`, to: `0x${string}`, amount: number) => Promise<string>;
  mint: (tokenAddress: `0x${string}`, amount: number) => Promise<string>;
  addToken: (token: TokenInfo) => void;
  decryptBalance: (tokenAddress: string) => Promise<number | null>;
}

const WalletContext = createContext<WalletContextValue | null>(null);

export function WalletProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(walletReducer, initialState);

  useEffect(() => {
    const tokens = getAllTokens();
    dispatch({ type: "SET_TOKENS", tokens });
    const stored = loadTransactions() as TransactionRecord[];
    if (stored.length > 0) {
      stored.forEach((tx) => dispatch({ type: "ADD_TRANSACTION", tx }));
    }
  }, []);

  useEffect(() => {
    if (state.transactions.length > 0) {
      saveTransactions(state.transactions);
    }
  }, [state.transactions]);

  const connect = useCallback(async () => {
    try {
      dispatch({ type: "SET_LOADING", isLoading: true });

      if (typeof window === "undefined" || !window.ethereum) {
        throw new Error("No Ethereum provider found. Please install MetaMask.");
      }

      const ethers = await import("ethers");
      const provider = new ethers.BrowserProvider(window.ethereum);
      const accounts = await provider.send("eth_requestAccounts", []);
      const network = await provider.getNetwork();
      const signer = await provider.getSigner();
      const address = accounts[0] as `0x${string}`;

      dispatch({ type: "SET_ADDRESS", address });
      dispatch({ type: "SET_CONNECTED", isConnected: true });
      dispatch({ type: "SET_CHAIN_ID", chainId: Number(network.chainId) });

      getFhenixClient({ provider, signer });

      try {
        const key = await requestEncryptionKey(signer);
        dispatch({ type: "SET_ENCRYPTION_KEY", key });

        for (const token of FHERC20_DEFAULT_TOKENS) {
          try {
            const pk = await generateFHEPublicKey(key);
            const client = getFhenixClient();
            await client.setPublicKey(token.address, pk);
          } catch {}
        }
      } catch {}

      dispatch({ type: "SET_LOADING", isLoading: false });
    } catch (error) {
      dispatch({ type: "SET_LOADING", isLoading: false });
      throw error;
    }
  }, []);

  const disconnect = useCallback(() => {
    resetFhenixClient();
    dispatch({ type: "RESET" });
  }, []);

  const refreshBalances = useCallback(async () => {
    if (!state.address || !state.isConnected) return;

    const client = getFhenixClient();
    for (const token of state.tokens) {
      try {
        const ciphertext = await client.getEncryptedBalance(token.address, state.address);
        dispatch({
          type: "SET_BALANCE",
          tokenAddress: token.address,
          balance: {
            tokenAddress: token.address,
            ciphertext,
            loading: false,
          },
        });
      } catch {
        dispatch({
          type: "SET_BALANCE",
          tokenAddress: token.address,
          balance: {
            tokenAddress: token.address,
            ciphertext: "0x",
            loading: false,
          },
        });
      }
    }
  }, [state.address, state.isConnected, state.tokens]);

  const transfer = useCallback(
    async (tokenAddress: `0x${string}`, to: `0x${string}`, amount: number): Promise<string> => {
      if (!state.address) throw new Error("Wallet not connected");

      dispatch({ type: "SET_LOADING", isLoading: true });
      try {
        const client = getFhenixClient();
        const encryptedAmount = await client.encrypt(amount);
        const txHash = await client.transfer(tokenAddress, to, encryptedAmount);

        const token = state.tokens.find((t) => t.address.toLowerCase() === tokenAddress.toLowerCase());
        dispatch({
          type: "ADD_TRANSACTION",
          tx: {
            id: `tx_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
            type: "send",
            tokenSymbol: token?.symbol || "UNKNOWN",
            tokenAddress,
            counterparty: to,
            txHash: txHash as `0x${string}`,
            timestamp: Date.now(),
          },
        });

        await refreshBalances();
        return txHash;
      } finally {
        dispatch({ type: "SET_LOADING", isLoading: false });
      }
    },
    [state.address, state.tokens, refreshBalances]
  );

  const mint = useCallback(
    async (tokenAddress: `0x${string}`, amount: number): Promise<string> => {
      if (!state.address) throw new Error("Wallet not connected");

      dispatch({ type: "SET_LOADING", isLoading: true });
      try {
        const client = getFhenixClient();
        const encryptedAmount = await client.encrypt(amount);
        const txHash = await client.mint(tokenAddress, state.address, encryptedAmount);

        const token = state.tokens.find((t) => t.address.toLowerCase() === tokenAddress.toLowerCase());
        dispatch({
          type: "ADD_TRANSACTION",
          tx: {
            id: `tx_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
            type: "receive",
            tokenSymbol: token?.symbol || "UNKNOWN",
            tokenAddress,
            counterparty: state.address,
            txHash: txHash as `0x${string}`,
            timestamp: Date.now(),
          },
        });

        await refreshBalances();
        return txHash;
      } finally {
        dispatch({ type: "SET_LOADING", isLoading: false });
      }
    },
    [state.address, state.tokens, refreshBalances]
  );

  const addToken = useCallback((token: TokenInfo) => {
    dispatch({ type: "ADD_TOKEN", token });
  }, []);

  const decryptBalance = useCallback(
    async (tokenAddress: string): Promise<number | null> => {
      if (!state.encryptionKey) return null;
      const bal = state.balances.get(tokenAddress);
      if (!bal || bal.ciphertext === "0x") return null;

      try {
        const { decryptBalanceFromSealed } = await import("@/lib/encryption");
        return decryptBalanceFromSealed(bal.ciphertext, state.encryptionKey);
      } catch {
        return null;
      }
    },
    [state.encryptionKey, state.balances]
  );

  return (
    <WalletContext.Provider
      value={{
        state,
        connect,
        disconnect,
        refreshBalances,
        transfer,
        mint,
        addToken,
        decryptBalance,
      }}
    >
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet(): WalletContextValue {
  const ctx = useContext(WalletContext);
  if (!ctx) throw new Error("useWallet must be used within WalletProvider");
  return ctx;
}
