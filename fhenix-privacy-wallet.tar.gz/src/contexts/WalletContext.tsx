export const useWallet = {} as any
