import { useEffect, useState } from "react";
import type { Permit } from "fhenixjs";
import { isAddress, toHex } from "viem";

import { privateTokenAbi, type ContractEncryptedInput, type ContractPermissionTuple } from "./lib/abi";
import { configuredChainId, configuredTokens, type TokenConfig } from "./lib/config";
import { deriveLocalEncryptionKey } from "./lib/crypto";
import { createOwnerPermit, getFhenixClient } from "./lib/fhenix";
import { loadEncryptedPermit, saveEncryptedPermit } from "./lib/storage";
import { createClients, getEthereumProvider, requestAccounts } from "./lib/wallet";

type TokenView = TokenConfig & {
  name: string;
  symbol: string;
  balance: string;
  history: TransferRecord[];
  permitReady: boolean;
};

type TransferRecord = {
  transferId: string;
  from: string;
  to: string;
  encryptedAmountHash: string;
  timestamp: number;
  memo: string;
};

type TransferFormState = Record<string, { recipient: string; amount: string; memo: string }>;

const initialForm = { recipient: "", amount: "", memo: "" };

export default function App() {
  const [account, setAccount] = useState<`0x${string}` | null>(null);
  const [status, setStatus] = useState("Connect a wallet to create private FHERC permits.");
  const [tokenViews, setTokenViews] = useState<TokenView[]>([]);
  const [forms, setForms] = useState<TransferFormState>({});
  const [localKey, setLocalKey] = useState<CryptoKey | null>(null);
  const [permitCache, setPermitCache] = useState<Record<string, Permit>>({});
  const [busyToken, setBusyToken] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function loadTokenMetadata() {
      if (configuredTokens.length === 0) {
        setTokenViews([]);
        return;
      }

      try {
        const { publicClient } = createClients();
        const views = await Promise.all(
          configuredTokens.map(async (token) => {
            const [name, symbol] = await Promise.all([
              publicClient.readContract({ address: token.address, abi: privateTokenAbi, functionName: "name" }),
              publicClient.readContract({ address: token.address, abi: privateTokenAbi, functionName: "symbol" }),
            ]);

            return {
              ...token,
              name,
              symbol,
              balance: "Locked",
              history: [],
              permitReady: false,
            } satisfies TokenView;
          }),
        );

        if (!cancelled) {
          setTokenViews(views);
          setForms(
            Object.fromEntries(views.map((token) => [token.address, initialForm])),
          );
        }
      } catch (error) {
        if (!cancelled) {
          setStatus((error as Error).message);
        }
      }
    }

    loadTokenMetadata();
    return () => {
      cancelled = true;
    };
  }, []);

  async function connectWallet() {
    try {
      const [selected] = await requestAccounts();
      setAccount(selected);
      setStatus(`Connected ${selected}`);
    } catch (error) {
      setStatus((error as Error).message);
    }
  }

  async function unlockLocalKey() {
    if (!account) {
      setStatus("Connect a wallet before unlocking local key storage.");
      return;
    }

    try {
      const provider = getEthereumProvider();
      const signature = (await provider.request({
        method: "personal_sign",
        params: ["Authorize private wallet key derivation", account],
      })) as string;

      const key = await deriveLocalEncryptionKey(signature);
      setLocalKey(key);

      const restoredPermits = await Promise.all(
        tokenViews.map(async (token) => {
          const permit = await loadEncryptedPermit(account, token.address, key);
          return [token.address, permit] as const;
        }),
      );

      const nextPermits = restoredPermits.reduce<Record<string, Permit>>((accumulator, [tokenAddress, permit]) => {
        if (permit) {
          accumulator[tokenAddress] = permit;
        }
        return accumulator;
      }, {});

      setPermitCache(nextPermits);
      setTokenViews((current) =>
        current.map((token) => ({
          ...token,
          permitReady: Boolean(nextPermits[token.address]),
        })),
      );
      setStatus("Owner-only balance viewing unlocked.");
    } catch (error) {
      setStatus((error as Error).message);
    }
  }

  async function provisionPermit(tokenAddress: `0x${string}`) {
    if (!account || !localKey) {
      setStatus("Connect and unlock the local key before creating permits.");
      return;
    }

    setBusyToken(tokenAddress);

    try {
      const { permit } = await createOwnerPermit(tokenAddress, account);
      await saveEncryptedPermit(account, tokenAddress, permit, localKey);
      setPermitCache((current) => ({ ...current, [tokenAddress]: permit }));
      setTokenViews((current) =>
        current.map((token) => (token.address === tokenAddress ? { ...token, permitReady: true } : token)),
      );
      setStatus(`Stored encrypted viewing permit for ${tokenAddress}.`);
      await refreshToken(tokenAddress, permit);
    } catch (error) {
      setStatus((error as Error).message);
    } finally {
      setBusyToken(null);
    }
  }

  async function refreshToken(tokenAddress: `0x${string}`, suppliedPermit?: Permit) {
    if (!account) {
      setStatus("Connect wallet before refreshing token state.");
      return;
    }

    const permit = suppliedPermit ?? permitCache[tokenAddress];
    if (!permit) {
      setStatus("Create an owner permit to decrypt balances.");
      return;
    }

    setBusyToken(tokenAddress);
    try {
      const { publicClient } = createClients();
      const client = await getFhenixClient();
      const permission = client.extractPermitPermission(permit) as ContractPermissionTuple;
      const sealedBalance = await publicClient.readContract({
        address: tokenAddress,
        abi: privateTokenAbi,
        functionName: "viewOwnBalance",
        args: [permission],
      });
      const historyLength = await publicClient.readContract({
        address: tokenAddress,
        abi: privateTokenAbi,
        functionName: "historyLength",
      });

      const count = Number(historyLength);
      const limit = Math.min(count, 8);
      const history = await Promise.all(
        Array.from({ length: limit }, (_, offset) => count - 1 - offset).map(async (index) => {
          const record = await publicClient.readContract({
            address: tokenAddress,
            abi: privateTokenAbi,
            functionName: "getTransferRecord",
            args: [BigInt(index)],
          });

          return {
            transferId: record.transferId,
            from: record.from,
            to: record.to,
            encryptedAmountHash: record.encryptedAmountHash,
            timestamp: Number(record.timestamp),
            memo: record.memo,
          } satisfies TransferRecord;
        }),
      );

      const balance = client.unseal(tokenAddress, sealedBalance, account).toString();
      setTokenViews((current) =>
        current.map((token) =>
          token.address === tokenAddress ? { ...token, balance, history, permitReady: true } : token,
        ),
      );
      setStatus(`Decrypted owner balance for ${tokenAddress}.`);
    } catch (error) {
      setStatus((error as Error).message);
    } finally {
      setBusyToken(null);
    }
  }

  async function submitTransfer(tokenAddress: `0x${string}`) {
    if (!account) {
      setStatus("Connect wallet before sending encrypted transfers.");
      return;
    }

    const form = forms[tokenAddress] ?? initialForm;
    if (!isAddress(form.recipient)) {
      setStatus("Recipient must be a valid address.");
      return;
    }

    try {
      const amount = BigInt(form.amount);
      const client = await getFhenixClient();
      const encrypted = await client.encrypt_uint128(amount);
      const { walletClient } = createClients();

      setBusyToken(tokenAddress);
      const encryptedInput: ContractEncryptedInput = {
        data: toHex(encrypted.data),
        securityZone: encrypted.securityZone,
      };

      await walletClient.writeContract({
        account,
        chain: undefined,
        address: tokenAddress,
        abi: privateTokenAbi,
        functionName: "transferEncryptedWithMemo",
        args: [
          form.recipient as `0x${string}`,
          encryptedInput,
          form.memo,
        ],
      });

      setStatus(`Submitted encrypted transfer from ${tokenAddress}.`);
      setForms((current) => ({ ...current, [tokenAddress]: initialForm }));
      await refreshToken(tokenAddress);
    } catch (error) {
      setStatus((error as Error).message);
    } finally {
      setBusyToken(null);
    }
  }

  return (
    <main className="min-h-screen bg-mist px-4 py-8 text-ink sm:px-6 lg:px-10">
      <section className="mx-auto max-w-7xl">
        <div className="overflow-hidden rounded-[32px] border border-white/70 bg-white/80 shadow-glow backdrop-blur">
          <div className="grid gap-8 px-6 py-8 lg:grid-cols-[1.15fr_0.85fr] lg:px-10">
            <div className="space-y-6">
              <div className="space-y-4">
                <span className="inline-flex rounded-full bg-ink px-3 py-1 text-xs font-semibold uppercase tracking-[0.24em] text-mist">
                  FHERC Privacy Wallet
                </span>
                <h1 className="max-w-2xl font-display text-4xl font-bold tracking-tight text-ink sm:text-5xl">
                  Encrypted balances, private transfers, and owner-gated balance decryption.
                </h1>
                <p className="max-w-2xl text-base leading-7 text-night/80">
                  The wallet uses FHERC-20 encrypted storage on-chain, Fhenix permits for sealed output access,
                  and a wallet-signature-derived local key to keep viewing credentials encrypted in the browser.
                </p>
              </div>

              <div className="grid gap-4 sm:grid-cols-3">
                <Metric label="Configured tokens" value={String(tokenViews.length)} />
                <Metric label="Chain guard" value={configuredChainId > 0 ? String(configuredChainId) : "Unset"} />
                <Metric label="Owner session" value={localKey ? "Unlocked" : "Locked"} />
              </div>

              <div className="rounded-3xl bg-ink px-5 py-5 text-mist">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
                  <button
                    type="button"
                    onClick={connectWallet}
                    className="rounded-2xl bg-signal px-4 py-3 font-semibold text-ink transition hover:opacity-90"
                  >
                    {account ? "Wallet Connected" : "Connect Wallet"}
                  </button>
                  <button
                    type="button"
                    onClick={unlockLocalKey}
                    disabled={!account}
                    className="rounded-2xl border border-white/20 px-4 py-3 font-semibold transition hover:border-signal disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    Unlock Private View
                  </button>
                </div>
                <p className="mt-4 text-sm text-mist/80">{status}</p>
                {account ? <p className="mt-2 text-sm font-medium">{account}</p> : null}
              </div>
            </div>

            <aside className="rounded-[28px] bg-gradient-to-br from-[#10233f] via-[#173154] to-[#10233f] p-6 text-mist">
              <h2 className="font-display text-2xl font-bold">Security model</h2>
              <ul className="mt-5 space-y-4 text-sm leading-6 text-mist/85">
                <li>Encrypted balances live on-chain as `euint128` values inside FHERC storage.</li>
                <li>Transfers accept ciphertext tuples, so observers never see the raw amount.</li>
                <li>Balance reads require a permit signed by the owner and are unsealed only in the owner session.</li>
                <li>Viewing permits are re-encrypted locally with an AES key derived from a wallet signature.</li>
              </ul>
            </aside>
          </div>
        </div>

        <section className="mt-8 grid gap-6 xl:grid-cols-2">
          {tokenViews.length === 0 ? (
            <div className="rounded-[28px] border border-dashed border-night/20 bg-white/70 p-8 text-sm text-night/70">
              Add deployed FHERC token addresses in `.env` using `VITE_TOKEN_ADDRESSES`.
            </div>
          ) : (
            tokenViews.map((token) => {
              const form = forms[token.address] ?? initialForm;

              return (
                <article key={token.address} className="rounded-[28px] bg-white p-6 shadow-glow">
                  <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                    <div>
                      <h3 className="font-display text-2xl font-bold">{token.name}</h3>
                      <p className="mt-1 text-sm uppercase tracking-[0.3em] text-night/60">{token.symbol}</p>
                      <p className="mt-3 text-xs text-night/70">{token.address}</p>
                    </div>
                    <div className="rounded-3xl bg-mist px-4 py-3 text-right">
                      <p className="text-xs uppercase tracking-[0.24em] text-night/50">Owner balance</p>
                      <p className="mt-1 font-display text-3xl font-bold text-ink">{token.balance}</p>
                    </div>
                  </div>

                  <div className="mt-5 flex flex-wrap gap-3">
                    <button
                      type="button"
                      onClick={() => provisionPermit(token.address)}
                      disabled={!localKey || busyToken === token.address}
                      className="rounded-2xl bg-ink px-4 py-3 text-sm font-semibold text-mist transition hover:bg-night disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      {token.permitReady ? "Refresh Permit" : "Create Permit"}
                    </button>
                    <button
                      type="button"
                      onClick={() => refreshToken(token.address)}
                      disabled={!token.permitReady || busyToken === token.address}
                      className="rounded-2xl border border-night/15 px-4 py-3 text-sm font-semibold text-ink transition hover:border-ink disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      Refresh Balance
                    </button>
                  </div>

                  <div className="mt-6 grid gap-3">
                    <input
                      value={form.recipient}
                      onChange={(event) =>
                        setForms((current) => ({
                          ...current,
                          [token.address]: { ...form, recipient: event.target.value },
                        }))
                      }
                      placeholder="Recipient address"
                      className="rounded-2xl border border-night/10 bg-mist px-4 py-3 text-sm outline-none transition focus:border-signal"
                    />
                    <input
                      value={form.amount}
                      onChange={(event) =>
                        setForms((current) => ({
                          ...current,
                          [token.address]: { ...form, amount: event.target.value },
                        }))
                      }
                      placeholder="Encrypted amount"
                      className="rounded-2xl border border-night/10 bg-mist px-4 py-3 text-sm outline-none transition focus:border-signal"
                    />
                    <input
                      value={form.memo}
                      onChange={(event) =>
                        setForms((current) => ({
                          ...current,
                          [token.address]: { ...form, memo: event.target.value },
                        }))
                      }
                      placeholder="Private memo tag"
                      className="rounded-2xl border border-night/10 bg-mist px-4 py-3 text-sm outline-none transition focus:border-signal"
                    />
                    <button
                      type="button"
                      onClick={() => submitTransfer(token.address)}
                      disabled={!token.permitReady || busyToken === token.address}
                      className="rounded-2xl bg-flare px-4 py-3 text-sm font-semibold text-white transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      Send Private Transfer
                    </button>
                  </div>

                  <div className="mt-6 rounded-[24px] bg-mist p-5">
                    <div className="flex items-center justify-between">
                      <h4 className="font-display text-lg font-bold">History</h4>
                      <span className="text-xs uppercase tracking-[0.24em] text-night/50">Amounts hidden</span>
                    </div>
                    <div className="mt-4 space-y-3">
                      {token.history.length === 0 ? (
                        <p className="text-sm text-night/60">No private transfers loaded yet.</p>
                      ) : (
                        token.history.map((item) => (
                          <div key={item.transferId} className="rounded-2xl bg-white px-4 py-3 text-sm text-night/80">
                            <div className="flex items-center justify-between gap-4">
                              <span>{item.from === account ? "Sent" : "Received"}</span>
                              <span>{new Date(item.timestamp * 1000).toLocaleString()}</span>
                            </div>
                            <p className="mt-2 truncate text-xs">{item.memo || item.encryptedAmountHash}</p>
                            <p className="mt-1 truncate text-xs text-night/60">{item.from} → {item.to}</p>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </article>
              );
            })
          )}
        </section>
      </section>
    </main>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-[24px] bg-white/80 px-4 py-4">
      <p className="text-xs uppercase tracking-[0.22em] text-night/50">{label}</p>
      <p className="mt-2 font-display text-2xl font-bold text-ink">{value}</p>
    </div>
  );
}
