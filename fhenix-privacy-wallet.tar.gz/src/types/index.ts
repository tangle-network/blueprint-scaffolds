export interface EncryptedBalance {
  ciphertext: string;
  handle: string;
}

export interface FHERC20Token {
  address: string;
  name: string;
  symbol: string;
  balance?: EncryptedBalance | null;
  decryptedBalance?: number | null;
}

export interface TransferRecord {
  id: string;
  from: string;
  to: string;
  tokenAddress: string;
  tokenSymbol: string;
  timestamp: number;
  txHash: string;
}

export interface WalletState {
  address: string | null;
  isConnected: boolean;
  isConnecting: boolean;
  chainId: number | null;
}

export interface FHEKeyPair {
  publicKey: string;
  encryptionKey: string;
}

export interface Permission {
  contract: string;
  account: string;
  permitted: boolean;
}
