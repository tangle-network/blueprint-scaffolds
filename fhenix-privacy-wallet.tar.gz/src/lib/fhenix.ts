import { FhenixClient, removePermitFromLocalstorage, type Permit } from "fhenixjs";

import { getEthereumProvider } from "./wallet";

let clientPromise: Promise<FhenixClient> | null = null;

export async function getFhenixClient(): Promise<FhenixClient> {
  if (!clientPromise) {
    clientPromise = Promise.resolve(new FhenixClient({ provider: getEthereumProvider() }));
  }
  return clientPromise;
}

export async function createOwnerPermit(
  tokenAddress: string,
  account: string,
): Promise<{ client: FhenixClient; permit: Permit }> {
  const client = await getFhenixClient();
  const permit = await client.generatePermit(tokenAddress, getEthereumProvider());

  removePermitFromLocalstorage(tokenAddress, account);
  client.storePermit(permit, account);

  return { client, permit };
}
