import { FHERC20_ABI } from "./abi";
import type { TokenInfo } from "./types";

interface FhenixClientConfig {
  provider: unknown;
  signer: unknown;
}

class FhenixClient {
  private provider: unknown;
  private signer: unknown;

  constructor(config: FhenixClientConfig) {
    this.provider = config.provider;
    this.signer = config.signer;
  }

  async encrypt(amount: number): Promise<string> {
    const buffer = new ArrayBuffer(32);
    const view = new DataView(buffer);
    view.setUint32(0, amount, false);
    const bytes = new Uint8Array(buffer);
    return `0x${Array.from(bytes)
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("")}`;
  }

  async getContract(tokenAddress: string) {
    const { ethers } = await import("ethers");
    if (!this.signer) throw new Error("No signer available");
    return new ethers.Contract(tokenAddress, FHERC20_ABI, this.signer as ethers.Signer);
  }

  async getReadOnlyContract(tokenAddress: string) {
    const { ethers } = await import("ethers");
    if (!this.provider) throw new Error("No provider available");
    return new ethers.Contract(tokenAddress, FHERC20_ABI, this.provider as ethers.Provider);
  }

  async transfer(tokenAddress: string, to: string, encryptedAmount: string): Promise<string> {
    const contract = await this.getContract(tokenAddress);
    const tx = await contract.transfer(to, encryptedAmount);
    const receipt = await tx.wait();
    return receipt.hash;
  }

  async getEncryptedBalance(tokenAddress: string, account: string): Promise<string> {
    const contract = await this.getReadOnlyContract(tokenAddress);
    const balance = await contract.balanceOf(account);
    return balance;
  }

  async setPublicKey(tokenAddress: string, publicKey: string): Promise<void> {
    const contract = await this.getContract(tokenAddress);
    const tx = await contract.setPublicKey(publicKey);
    await tx.wait();
  }

  async mint(tokenAddress: string, to: string, encryptedAmount: string): Promise<string> {
    const contract = await this.getContract(tokenAddress);
    const tx = await contract.mint(to, encryptedAmount);
    const receipt = await tx.wait();
    return receipt.hash;
  }

  async getTokenInfo(tokenAddress: string): Promise<TokenInfo> {
    const contract = await this.getReadOnlyContract(tokenAddress);
    const [name, symbol] = await Promise.all([contract.name(), contract.symbol()]);
    return {
      address: tokenAddress as `0x${string}`,
      name,
      symbol,
      decimals: 18,
    };
  }
}

let clientInstance: FhenixClient | null = null;

export function getFhenixClient(config?: FhenixClientConfig): FhenixClient {
  if (!clientInstance && config) {
    clientInstance = new FhenixClient(config);
  }
  if (!clientInstance) {
    throw new Error("FhenixClient not initialized");
  }
  return clientInstance;
}

export function resetFhenixClient(): void {
  clientInstance = null;
}

export { FhenixClient };
