import { type EncryptedBalance, type FHEKeyPair } from "@/types";

export class FHEOperations {
  private keyPair: FHEKeyPair | null = null;

  async initialize(walletAddress: string, signature: string): Promise<FHEKeyPair> {
    const encoder = new TextEncoder();
    const data = encoder.encode(signature + walletAddress);
    const hashBuffer = await crypto.subtle.digest("SHA-256", data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");

    this.keyPair = {
      publicKey: hashHex.slice(0, 64),
      encryptionKey: hashHex,
    };

    return this.keyPair;
  }

  getKeyPair(): FHEKeyPair | null {
    return this.keyPair;
  }

  encryptAmount(amount: number, publicKey?: string): EncryptedBalance {
    const key = publicKey || this.keyPair?.encryptionKey || "default-key";
    const amountStr = amount.toString();
    let encrypted = "";
    for (let i = 0; i < amountStr.length; i++) {
      const charCode = amountStr.charCodeAt(i);
      const keyChar = key.charCodeAt(i % key.length);
      encrypted += ((charCode + keyChar) % 256).toString(16).padStart(2, "0");
    }
    const handle = `handle_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    return { ciphertext: encrypted, handle };
  }

  decryptBalance(encrypted: EncryptedBalance, key?: string): number {
    const decryptionKey = key || this.keyPair?.encryptionKey || "default-key";
    let decrypted = "";
    for (let i = 0; i < encrypted.ciphertext.length; i += 2) {
      const byte = parseInt(encrypted.ciphertext.slice(i, i + 2), 16);
      const keyChar = decryptionKey.charCodeAt((i / 2) % decryptionKey.length);
      decrypted += String.fromCharCode((byte - keyChar + 256) % 256);
    }
    return parseInt(decrypted, 10) || 0;
  }

  isInitialized(): boolean {
    return this.keyPair !== null;
  }
}

export const fheOperations = new FHEOperations();
