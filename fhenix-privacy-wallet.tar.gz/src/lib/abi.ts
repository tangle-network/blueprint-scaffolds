export const privateTokenAbi = [
  {
    type: "function",
    name: "name",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "", type: "string" }],
  },
  {
    type: "function",
    name: "symbol",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "", type: "string" }],
  },
  {
    type: "function",
    name: "viewOwnBalance",
    stateMutability: "view",
    inputs: [
      {
        name: "permission",
        type: "tuple",
        components: [
          { name: "publicKey", type: "bytes32" },
          { name: "signature", type: "bytes" },
        ],
      },
    ],
    outputs: [{ name: "", type: "string" }],
  },
  {
    type: "function",
    name: "transferEncryptedWithMemo",
    stateMutability: "nonpayable",
    inputs: [
      { name: "to", type: "address" },
      {
        name: "encryptedAmount",
        type: "tuple",
        components: [
          { name: "data", type: "bytes" },
          { name: "securityZone", type: "int32" },
        ],
      },
      { name: "memo", type: "string" },
    ],
    outputs: [{ name: "", type: "uint256" }],
  },
  {
    type: "function",
    name: "historyLength",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "", type: "uint256" }],
  },
  {
    type: "function",
    name: "getTransferRecord",
    stateMutability: "view",
    inputs: [{ name: "index", type: "uint256" }],
    outputs: [
      {
        name: "",
        type: "tuple",
        components: [
          { name: "transferId", type: "bytes32" },
          { name: "from", type: "address" },
          { name: "to", type: "address" },
          { name: "encryptedAmountHash", type: "bytes32" },
          { name: "timestamp", type: "uint256" },
          { name: "memo", type: "string" },
        ],
      },
    ],
  },
  {
    type: "function",
    name: "mintEncrypted",
    stateMutability: "nonpayable",
    inputs: [
      { name: "to", type: "address" },
      {
        name: "encryptedAmount",
        type: "tuple",
        components: [
          { name: "data", type: "bytes" },
          { name: "securityZone", type: "int32" },
        ],
      },
    ],
    outputs: [],
  },
] as const;

export type ContractPermissionTuple = {
  publicKey: `0x${string}`;
  signature: `0x${string}`;
};

export type ContractEncryptedInput = {
  data: `0x${string}`;
  securityZone: number;
};
