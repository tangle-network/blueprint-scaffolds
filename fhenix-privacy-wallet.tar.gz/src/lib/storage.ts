import { type FHERC20Token, type TransferRecord } from "@/types";
import { KNOWN_TOKENS } from "./contracts";

const STORAGE_KEY_TOKENS = "fherc_wallet_tokens";
const STORAGE_KEY_TRANSFERS = "fherc_wallet_transfers";
const STORAGE_KEY_DECRYPTED = "fherc_wallet_decrypted";

export function getStoredTokens(address: string): FHERC20Token[] {
  if (typeof window === "undefined") return KNOWN_TOKENS;
  try {
    const stored = localStorage.getItem(`${STORAGE_KEY_TOKENS}_${address}`);
    if (stored) return JSON.parse(stored);
  } catch {}
  return KNOWN_TOKENS;
}

export function storeTokens(address: string, tokens: FHERC20Token[]): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(
      `${STORAGE_KEY_TOKENS}_${address}`,
      JSON.stringify(tokens)
    );
  } catch {}
}

export function getStoredTransfers(address: string): TransferRecord[] {
  if (typeof window === "undefined") return [];
  try {
    const stored = localStorage.getItem(`${STORAGE_KEY_TRANSFERS}_${address}`);
    if (stored) return JSON.parse(stored);
  } catch {}
  return [];
}

export function storeTransfers(address: string, transfers: TransferRecord[]): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(
      `${STORAGE_KEY_TRANSFERS}_${address}`,
      JSON.stringify(transfers)
    );
  } catch {}
}

export function getDecryptedBalances(
  address: string
): Record<string, number> {
  if (typeof window === "undefined") return {};
  try {
    const stored = localStorage.getItem(
      `${STORAGE_KEY_DECRYPTED}_${address}`
    );
    if (stored) return JSON.parse(stored);
  } catch {}
  return {};
}

export function storeDecryptedBalances(
  address: string,
  balances: Record<string, number>
): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(
      `${STORAGE_KEY_DECRYPTED}_${address}`,
      JSON.stringify(balances)
    );
  } catch {}
}
