import type { Permit } from "fhenixjs";

import { decryptJson, encryptJson, type LocalCipher } from "./crypto";

const prefix = "fherc-wallet";

function permitStorageKey(account: string, token: string): string {
  return `${prefix}:permit:${account.toLowerCase()}:${token.toLowerCase()}`;
}

export async function saveEncryptedPermit(
  account: string,
  token: string,
  permit: Permit,
  key: CryptoKey,
): Promise<void> {
  const encrypted = await encryptJson(permit, key);
  localStorage.setItem(permitStorageKey(account, token), JSON.stringify(encrypted));
}

export async function loadEncryptedPermit(
  account: string,
  token: string,
  key: CryptoKey,
): Promise<Permit | null> {
  const raw = localStorage.getItem(permitStorageKey(account, token));
  if (!raw) {
    return null;
  }

  const parsed = JSON.parse(raw) as LocalCipher;
  return decryptJson<Permit>(parsed, key);
}
