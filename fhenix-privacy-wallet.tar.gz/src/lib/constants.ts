export const FHENIX_CHAIN_ID = 0x1a86;
export const FHENIX_CHAIN_ID_DECIMAL = 6779;
export const FHENIX_RPC_URL = "https://api.fhenix.zone";
export const FHENIX_CHAIN_NAME = "Fhenix Helium Testnet";
export const FHENIX_EXPLORER_URL = "https://explorer.fhenix.zone";

export const FHERC20_FACTORY_ADDRESS = "0x0000000000000000000000000000000000000001" as const;

export const FHERC20_DEFAULT_TOKENS = [
  {
    address: "0x0000000000000000000000000000000000000002" as `0x${string}`,
    name: "Private USD",
    symbol: "pUSD",
    decimals: 18,
  },
  {
    address: "0x0000000000000000000000000000000000000003" as `0x${string}`,
    name: "Private ETH",
    symbol: "pETH",
    decimals: 18,
  },
  {
    address: "0x0000000000000000000000000000000000000004" as `0x${string}`,
    name: "Private BTC",
    symbol: "pBTC",
    decimals: 8,
  },
] as const;

export const ENCRYPTION_KEY_MESSAGE = "FHERC-20 Wallet: Derive encryption key for private balance viewing\n\nSigning this message allows the wallet to derive your FHE decryption key.\n\nKey: ";
