export interface TokenInfo {
  address: `0x${string}`;
  name: string;
  symbol: string;
  decimals: number;
}

export interface EncryptedBalance {
  tokenAddress: `0x${string}`;
  ciphertext: string;
  decrypted?: number;
  loading: boolean;
}

export interface TransferParams {
  tokenAddress: `0x${string}`;
  to: `0x${string}`;
  amount: number;
}

export interface TransactionRecord {
  id: string;
  type: "send" | "receive";
  tokenSymbol: string;
  tokenAddress: `0x${string}`;
  counterparty: `0x${string}`;
  txHash: `0x${string}`;
  timestamp: number;
  blockNumber?: number;
}

export interface WalletState {
  address: `0x${string}` | null;
  isConnected: boolean;
  chainId: number | null;
  encryptionKey: string | null;
  balances: Map<string, EncryptedBalance>;
  tokens: TokenInfo[];
  transactions: TransactionRecord[];
  isLoading: boolean;
}

export interface FhenixInstance {
  encrypt: (value: number) => Promise<Uint8Array>;
  seal: (data: Uint8Array, publicKey: Uint8Array) => Promise<Uint8Array>;
  getPublicKey: () => Promise<Uint8Array>;
}

export type WalletAction =
  | { type: "SET_ADDRESS"; address: `0x${string}` }
  | { type: "SET_CONNECTED"; isConnected: boolean }
  | { type: "SET_CHAIN_ID"; chainId: number }
  | { type: "SET_ENCRYPTION_KEY"; key: string | null }
  | { type: "SET_BALANCE"; tokenAddress: string; balance: EncryptedBalance }
  | { type: "SET_TOKENS"; tokens: TokenInfo[] }
  | { type: "ADD_TOKEN"; token: TokenInfo }
  | { type: "ADD_TRANSACTION"; tx: TransactionRecord }
  | { type: "SET_LOADING"; isLoading: boolean }
  | { type: "RESET" };
