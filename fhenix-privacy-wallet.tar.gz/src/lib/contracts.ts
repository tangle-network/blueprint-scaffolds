export const FHERC20_ABI = [
  "function name() view returns (string)",
  "function symbol() view returns (string)",
  "function totalSupply() view returns (uint256)",
  "function mint(address to, bytes encryptedAmount)",
  "function encryptedTransfer(address to, bytes encryptedAmount)",
  "function encryptedBalanceOf(address account) view returns (bytes)",
  "function allowance(address owner, address spender) view returns (uint256)",
  "function approve(address spender, uint256 amount) returns (bool)",
  "function generatePermission(address account) view returns (tuple(address contract, address account, bool permitted))",
  "event Transfer(address indexed from, address indexed to)",
  "event Mint(address indexed to)",
  "event Approval(address indexed owner, address indexed spender, uint256 amount)",
];

export const FACTORY_ABI = [
  "function createToken(string _name, string _symbol) returns (address)",
  "function getTokenCount() view returns (uint256)",
  "function getTokens() view returns (address[])",
  "function tokenNames(address) view returns (string)",
  "function tokenSymbols(address) view returns (string)",
  "event TokenCreated(address indexed tokenAddress, string name, string symbol)",
];

export const FHERC20_BYTECODE = "0x";

export const FACTORY_BYTECODE = "0x";

export const FHENIX_TESTNET_RPC = "https://api.helium.fhenix.zone";
export const FHENIX_LOCALNET_RPC = "http://localhost:42000";

export const KNOWN_TOKENS: Array<{ address: string; name: string; symbol: string }> = [
  {
    address: "0x0000000000000000000000000000000000000001",
    name: "Private FHENIX Dollar",
    symbol: "pUSD",
  },
  {
    address: "0x0000000000000000000000000000000000000002",
    name: "Private FHENIX Ether",
    symbol: "pETH",
  },
  {
    address: "0x0000000000000000000000000000000000000003",
    name: "Private Bitcoin",
    symbol: "pBTC",
  },
];
