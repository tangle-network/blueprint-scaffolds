import { FHERC20_DEFAULT_TOKENS } from "./constants";
import type { TokenInfo } from "./types";

const STORAGE_KEYS = {
  CUSTOM_TOKENS: "fherc-custom-tokens",
  TX_HISTORY: "fherc-tx-history",
  ENCRYPTION_KEY: "fherc-encryption-key",
} as const;

function safeGetItem(key: string): string | null {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}

function safeSetItem(key: string, value: string): void {
  try {
    localStorage.setItem(key, value);
  } catch {}
}

export function getDefaultTokens(): TokenInfo[] {
  return FHERC20_DEFAULT_TOKENS.map((t) => ({ ...t }));
}

export function getCustomTokens(): TokenInfo[] {
  const raw = safeGetItem(STORAGE_KEYS.CUSTOM_TOKENS);
  if (!raw) return [];
  try {
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveCustomToken(token: TokenInfo): void {
  const existing = getCustomTokens();
  if (existing.some((t) => t.address.toLowerCase() === token.address.toLowerCase())) return;
  existing.push(token);
  safeSetItem(STORAGE_KEYS.CUSTOM_TOKENS, JSON.stringify(existing));
}

export function getAllTokens(): TokenInfo[] {
  return [...getDefaultTokens(), ...getCustomTokens()];
}

export function saveTransactions(txs: unknown[]): void {
  safeSetItem(STORAGE_KEYS.TX_HISTORY, JSON.stringify(txs));
}

export function loadTransactions(): unknown[] {
  const raw = safeGetItem(STORAGE_KEYS.TX_HISTORY);
  if (!raw) return [];
  try {
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function shortenAddress(address: string): string {
  if (address.length < 10) return address;
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

export function shortenHash(hash: string): string {
  if (hash.length < 14) return hash;
  return `${hash.slice(0, 10)}...${hash.slice(-6)}`;
}

export function formatTimestamp(ts: number): string {
  return new Date(ts).toLocaleString();
}

export function generateTxId(): string {
  return `tx_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}
