import { isAddress } from "viem";

export type TokenConfig = {
  address: `0x${string}`;
  label: string;
};

const configuredAddresses = (import.meta.env.VITE_TOKEN_ADDRESSES ?? "")
  .split(",")
  .map((value) => value.trim())
  .filter(Boolean);

export const configuredTokens: TokenConfig[] = configuredAddresses
  .filter((value): value is `0x${string}` => isAddress(value))
  .map((address, index) => ({
    address,
    label: `Private Token ${index + 1}`,
  }));

export const configuredChainId = Number(import.meta.env.VITE_CHAIN_ID ?? "0");
