import { ENCRYPTION_KEY_MESSAGE } from "./constants";

function hexToBytes(hex: string): Uint8Array {
  const clean = hex.startsWith("0x") ? hex.slice(2) : hex;
  const bytes = new Uint8Array(clean.length / 2);
  for (let i = 0; i < clean.length; i += 2) {
    bytes[i / 2] = parseInt(clean.substring(i, i + 2), 16);
  }
  return bytes;
}

async function deriveKeyFromSignature(signature: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(signature);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

export async function requestEncryptionKey(
  signer: { signMessage: (msg: string) => Promise<string> }
): Promise<string> {
  const message = ENCRYPTION_KEY_MESSAGE + Date.now().toString();
  const signature = await signer.signMessage(message);
  return deriveKeyFromSignature(signature);
}

export function encryptAmountForTransfer(amount: number, encryptionKey: string): string {
  const buffer = new ArrayBuffer(32);
  const view = new DataView(buffer);
  view.setUint32(0, amount, false);
  const keyBytes = hexToBytes(encryptionKey.slice(0, 16));
  const amountBytes = new Uint8Array(buffer, 0, 4);
  const encrypted = new Uint8Array(32);
  encrypted.set(amountBytes, 0);
  for (let i = 0; i < keyBytes.length && i + 4 < 32; i++) {
    encrypted[i + 4] = keyBytes[i] ^ amountBytes[i % 4];
  }
  const hex = Array.from(encrypted)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
  return `0x${hex}`;
}

export function decryptBalanceFromSealed(sealedHex: string, encryptionKey: string): number | null {
  try {
    const clean = sealedHex.startsWith("0x") ? sealedHex.slice(2) : sealedHex;
    if (clean.length < 8) return null;
    const sealedBytes = new Uint8Array(clean.length / 2);
    for (let i = 0; i < clean.length; i += 2) {
      sealedBytes[i / 2] = parseInt(clean.substring(i, i + 2), 16);
    }
    const keyBytes = hexToBytes(encryptionKey.slice(0, 16));
    const decrypted = new Uint8Array(4);
    for (let i = 0; i < 4; i++) {
      decrypted[i] = sealedBytes[i + 4] ^ keyBytes[i];
    }
    const view = new DataView(decrypted.buffer);
    return view.getUint32(0, false);
  } catch {
    return null;
  }
}

export async function generateFHEPublicKey(encryptionKey: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(encryptionKey + "-fhe-pk");
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  return `0x${Array.from(new Uint8Array(hashBuffer))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("")}`;
}
