import { createPublicClient, createWalletClient, custom } from "viem";

export function getEthereumProvider() {
  if (!window.ethereum) {
    throw new Error("No injected wallet found.");
  }
  return window.ethereum;
}

export async function requestAccounts(): Promise<`0x${string}`[]> {
  const provider = getEthereumProvider();
  const result = await provider.request({ method: "eth_requestAccounts" });
  return result as `0x${string}`[];
}

export function createClients() {
  const provider = getEthereumProvider();

  return {
    publicClient: createPublicClient({
      transport: custom(provider),
    }),
    walletClient: createWalletClient({
      transport: custom(provider),
    }),
  };
}
