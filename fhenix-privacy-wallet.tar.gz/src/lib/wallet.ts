import { ethers } from "ethers";
import { fheOperations } from "./fhe";
import { FHERC20_ABI, FACTORY_ABI, FHERC20_BYTECODE, FACTORY_BYTECODE, FHENIX_TESTNET_RPC } from "./contracts";
import { type FHERC20Token, type TransferRecord, type WalletState } from "@/types";
import { generateId } from "./utils";

declare global {
  interface Window {
    ethereum?: {
      isMetaMask?: boolean;
      request: (args: { method: string; params?: unknown[] }) => Promise<unknown>;
      on: (event: string, handler: (...args: unknown[]) => void) => void;
      removeListener: (event: string, handler: (...args: unknown[]) => void) => void;
    };
  }
}

export class WalletManager {
  private provider: ethers.BrowserProvider | null = null;
  private signer: ethers.JsonRpcSigner | null = null;
  private state: WalletState = {
    address: null,
    isConnected: false,
    isConnecting: false,
    chainId: null,
  };

  getState(): WalletState {
    return { ...this.state };
  }

  async connect(): Promise<WalletState> {
    if (!window.ethereum) {
      throw new Error("No Ethereum provider found. Install MetaMask.");
    }

    this.state.isConnecting = true;
    try {
      this.provider = new ethers.BrowserProvider(window.ethereum);
      const accounts = await this.provider.send("eth_requestAccounts", []);
      this.signer = await this.provider.getSigner();
      const network = await this.provider.getNetwork();

      this.state.address = accounts[0] as string;
      this.state.isConnected = true;
      this.state.chainId = Number(network.chainId);

      await this.initializeFHE(this.state.address);

      return this.getState();
    } finally {
      this.state.isConnecting = false;
    }
  }

  async disconnect(): Promise<void> {
    this.provider = null;
    this.signer = null;
    this.state = {
      address: null,
      isConnected: false,
      isConnecting: false,
      chainId: null,
    };
  }

  private async initializeFHE(address: string): Promise<void> {
    if (!window.ethereum) return;
    const message = `FHERC Wallet Authentication\n\nSigning this message derives your FHE encryption keys.\n\nAddress: ${address}`;
    const signature = (await window.ethereum.request({
      method: "personal_sign",
      params: [message, address],
    })) as string;
    await fheOperations.initialize(address, signature);
  }

  async mintTokens(
    tokenAddress: string,
    amount: number
  ): Promise<string> {
    if (!this.signer) throw new Error("Wallet not connected");

    const encrypted = fheOperations.encryptAmount(amount);
    const contract = new ethers.Contract(tokenAddress, FHERC20_ABI, this.signer);
    const tx = await contract.mint(
      this.state.address,
      ethers.hexlify(ethers.toUtf8Bytes(encrypted.ciphertext))
    );
    await tx.wait();
    return tx.hash;
  }

  async transfer(
    tokenAddress: string,
    toAddress: string,
    amount: number,
    tokenSymbol: string
  ): Promise<TransferRecord> {
    if (!this.signer) throw new Error("Wallet not connected");

    const encrypted = fheOperations.encryptAmount(amount);
    const contract = new ethers.Contract(tokenAddress, FHERC20_ABI, this.signer);
    const tx = await contract.encryptedTransfer(
      toAddress,
      ethers.hexlify(ethers.toUtf8Bytes(encrypted.ciphertext))
    );
    await tx.wait();

    return {
      id: generateId(),
      from: this.state.address!,
      to: toAddress,
      tokenAddress,
      tokenSymbol,
      timestamp: Date.now(),
      txHash: tx.hash,
    };
  }

  async fetchEncryptedBalance(
    tokenAddress: string
  ): Promise<string | null> {
    if (!this.signer) return null;
    try {
      const contract = new ethers.Contract(tokenAddress, FHERC20_ABI, this.signer);
      const result = await contract.encryptedBalanceOf(this.state.address);
      return result;
    } catch {
      return null;
    }
  }

  async createToken(
    name: string,
    symbol: string,
    factoryAddress: string
  ): Promise<string> {
    if (!this.signer) throw new Error("Wallet not connected");
    const factory = new ethers.Contract(factoryAddress, FACTORY_ABI, this.signer);
    const tx = await factory.createToken(name, symbol);
    const receipt = await tx.wait();
    const event = receipt.logs.find(
      (log: unknown) => log instanceof Object && "topics" in (log as Record<string, unknown>)
    );
    return tx.hash;
  }

  getAddress(): string | null {
    return this.state.address;
  }

  getSigner(): ethers.JsonRpcSigner | null {
    return this.signer;
  }
}

export const walletManager = new WalletManager();
