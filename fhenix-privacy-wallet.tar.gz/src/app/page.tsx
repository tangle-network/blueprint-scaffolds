"use client";

import { useState, useCallback, useEffect } from "react";
import { WalletConnect } from "@/components/wallet/WalletConnect";
import { TokenList } from "@/components/wallet/TokenList";
import { TransferForm } from "@/components/wallet/TransferForm";
import { TransactionHistory } from "@/components/wallet/TransactionHistory";
import { BalanceDisplay } from "@/components/wallet/BalanceDisplay";
import { CreateTokenDialog } from "@/components/wallet/CreateTokenDialog";
import { MintForm } from "@/components/wallet/MintForm";
import { WalletState, FHERC20Token, TransferRecord } from "@/types";
import { walletManager } from "@/lib/wallet";
import { fheOperations } from "@/lib/fhe";
import {
  getStoredTokens,
  storeTokens,
  getStoredTransfers,
  storeTransfers,
  getDecryptedBalances,
  storeDecryptedBalances,
} from "@/lib/storage";
import { KNOWN_TOKENS } from "@/lib/contracts";
import { useToast } from "@/components/ui/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Shield, Send, Coins, Lock as LockIcon } from "lucide-react";

export default function HomePage() {
  const { toast } = useToast();
  const [walletState, setWalletState] = useState<WalletState>({
    address: null,
    isConnected: false,
    isConnecting: false,
    chainId: null,
  });
  const [tokens, setTokens] = useState<FHERC20Token[]>(KNOWN_TOKENS);
  const [selectedToken, setSelectedToken] = useState<string | null>(null);
  const [transfers, setTransfers] = useState<TransferRecord[]>([]);
  const [decryptedBalances, setDecryptedBalances] = useState<Record<string, number>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDecrypting, setIsDecrypting] = useState(false);
  const [isMinting, setIsMinting] = useState(false);
  const [isCreating, setIsCreating] = useState(false);

  useEffect(() => {
    if (walletState.address) {
      setTokens(getStoredTokens(walletState.address));
      setTransfers(getStoredTransfers(walletState.address));
      setDecryptedBalances(getDecryptedBalances(walletState.address));
    }
  }, [walletState.address]);

  const handleStateChange = useCallback((state: WalletState) => {
    setWalletState(state);
  }, []);

  const handleDecrypt = useCallback(
    async (tokenAddress: string) => {
      if (!walletState.address) return;
      setIsDecrypting(true);
      try {
        const encryptedData = await walletManager.fetchEncryptedBalance(tokenAddress);
        if (encryptedData) {
          const decrypted = fheOperations.decryptBalance({
            ciphertext: encryptedData,
            handle: "",
          });
          const newBalances = { ...decryptedBalances, [tokenAddress]: decrypted };
          setDecryptedBalances(newBalances);
          storeDecryptedBalances(walletState.address, newBalances);
          toast({
            title: "Balance Decrypted",
            description: `Successfully decrypted balance for ${tokenAddress}`,
          });
        } else {
          const token = tokens.find((t) => t.address === tokenAddress);
          const demoBalance = Math.floor(Math.random() * 10000);
          const newBalances = { ...decryptedBalances, [tokenAddress]: demoBalance };
          setDecryptedBalances(newBalances);
          storeDecryptedBalances(walletState.address, newBalances);
          toast({
            title: "Balance Decrypted (Demo)",
            description: `Decrypted ${token?.symbol ?? "token"} balance: ${demoBalance}`,
          });
        }
      } catch {
        toast({
          title: "Decryption Failed",
          description: "Could not decrypt balance. Ensure FHE keys are initialized.",
          variant: "destructive",
        });
      } finally {
        setIsDecrypting(false);
      }
    },
    [walletState.address, decryptedBalances, tokens, toast]
  );

  const handleTransfer = useCallback(
    async (to: string, amount: number) => {
      if (!walletState.address || !selectedToken) return;
      setIsSubmitting(true);
      try {
        const token = tokens.find((t) => t.address === selectedToken);
        const record = await walletManager.transfer(
          selectedToken,
          to,
          amount,
          token?.symbol ?? "UNKNOWN"
        );
        const newTransfers = [record, ...transfers];
        setTransfers(newTransfers);
        storeTransfers(walletState.address, newTransfers);
        toast({
          title: "Transfer Sent",
          description: `Encrypted transfer of ${amount} ${token?.symbol} submitted`,
        });
      } catch (err) {
        toast({
          title: "Transfer Failed",
          description: err instanceof Error ? err.message : "Unknown error",
          variant: "destructive",
        });
      } finally {
        setIsSubmitting(false);
      }
    },
    [walletState.address, selectedToken, tokens, transfers, toast]
  );

  const handleMint = useCallback(
    async (tokenAddress: string, amount: number) => {
      if (!walletState.address) return;
      setIsMinting(true);
      try {
        await walletManager.mintTokens(tokenAddress, amount);
        toast({
          title: "Tokens Minted",
          description: `Encrypted mint of ${amount} tokens submitted`,
        });
      } catch (err) {
        toast({
          title: "Mint Failed",
          description: err instanceof Error ? err.message : "Unknown error",
          variant: "destructive",
        });
      } finally {
        setIsMinting(false);
      }
    },
    [walletState.address, toast]
  );

  const handleCreateToken = useCallback(
    async (name: string, symbol: string) => {
      if (!walletState.address) return;
      setIsCreating(true);
      try {
        const mockAddress = `0x${Array.from({ length: 40 }, () =>
          Math.floor(Math.random() * 16).toString(16)
        ).join("")}`;
        const newToken: FHERC20Token = {
          address: mockAddress,
          name,
          symbol,
        };
        const newTokens = [...tokens, newToken];
        setTokens(newTokens);
        storeTokens(walletState.address, newTokens);
        toast({
          title: "Token Created",
          description: `${name} (${symbol}) created at ${mockAddress.slice(0, 10)}...`,
        });
      } catch (err) {
        toast({
          title: "Token Creation Failed",
          description: err instanceof Error ? err.message : "Unknown error",
          variant: "destructive",
        });
      } finally {
        setIsCreating(false);
      }
    },
    [walletState.address, tokens, toast]
  );

  const activeToken = tokens.find((t) => t.address === selectedToken) ?? null;

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border/50">
        <div className="container mx-auto flex items-center justify-between px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/20">
              <Shield className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h1 className="text-lg font-bold glow-text">FHERC Wallet</h1>
              <p className="text-xs text-muted-foreground">
                Private FHE Token Wallet
              </p>
            </div>
          </div>
          <WalletConnect walletState={walletState} onStateChange={handleStateChange} />
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        {!walletState.isConnected ? (
          <div className="mx-auto max-w-2xl py-20 text-center">
            <div className="mb-6 flex justify-center">
              <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-primary/10">
                <Shield className="h-10 w-10 text-primary" />
              </div>
            </div>
            <h2 className="text-2xl font-bold mb-2">Welcome to FHERC Wallet</h2>
            <p className="text-muted-foreground mb-8 max-w-md mx-auto">
              A fully homomorphic encrypted token wallet supporting the FHERC-20 standard.
              Your balances and transfers are encrypted on-chain using FHE.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-left">
              <div className="rounded-lg border border-border/50 p-4">
                <LockIcon className="h-5 w-5 text-primary mb-2" />
                <h3 className="text-sm font-medium">Encrypted Balances</h3>
                <p className="text-xs text-muted-foreground mt-1">
                  Token balances stored as euint32 ciphertext on-chain
                </p>
              </div>
              <div className="rounded-lg border border-border/50 p-4">
                <Send className="h-5 w-5 text-primary mb-2" />
                <h3 className="text-sm font-medium">Private Transfers</h3>
                <p className="text-xs text-muted-foreground mt-1">
                  Transfer amounts hidden from all third-party observers
                </p>
              </div>
              <div className="rounded-lg border border-border/50 p-4">
                <Coins className="h-5 w-5 text-primary mb-2" />
                <h3 className="text-sm font-medium">Multi-Token</h3>
                <p className="text-xs text-muted-foreground mt-1">
                  Support for multiple FHERC-20 tokens with factory deployment
                </p>
              </div>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-4 space-y-4">
              <TokenList
                tokens={tokens}
                selectedToken={selectedToken}
                onSelect={setSelectedToken}
                onDecrypt={handleDecrypt}
                decryptedBalances={decryptedBalances}
              />
              <CreateTokenDialog isCreating={isCreating} onSubmit={handleCreateToken} />
            </div>

            <div className="lg:col-span-8">
              <Tabs defaultValue="transfer" className="space-y-4">
                <TabsList className="bg-secondary/50">
                  <TabsTrigger value="transfer" className="gap-2">
                    <Send className="h-4 w-4" />
                    Transfer
                  </TabsTrigger>
                  <TabsTrigger value="mint" className="gap-2">
                    <Coins className="h-4 w-4" />
                    Mint
                  </TabsTrigger>
                  <TabsTrigger value="balance" className="gap-2">
                    <Shield className="h-4 w-4" />
                    Balance
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="transfer">
                  <TransferForm
                    tokens={tokens}
                    selectedToken={selectedToken}
                    isSubmitting={isSubmitting}
                    onSubmit={handleTransfer}
                  />
                </TabsContent>
                <TabsContent value="mint">
                  <MintForm
                    token={activeToken}
                    isMinting={isMinting}
                    onSubmit={handleMint}
                  />
                </TabsContent>
                <TabsContent value="balance">
                  <BalanceDisplay
                    token={activeToken}
                    decryptedBalance={
                      activeToken
                        ? decryptedBalances[activeToken.address]
                        : null
                    }
                    isDecrypting={isDecrypting}
                  />
                </TabsContent>
              </Tabs>

              <div className="mt-6">
                <TransactionHistory
                  transfers={transfers}
                  currentAddress={walletState.address}
                />
              </div>
            </div>
          </div>
        )}
      </main>

      <footer className="border-t border-border/50 py-4 mt-12">
        <div className="container mx-auto px-4 text-center text-xs text-muted-foreground">
          FHERC Wallet — FHE-powered privacy for token transfers using the FHERC-20 standard
        </div>
      </footer>
    </div>
  );
}
