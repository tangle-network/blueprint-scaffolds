import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'fherc-wallet',
  description: 'fherc-wallet',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
