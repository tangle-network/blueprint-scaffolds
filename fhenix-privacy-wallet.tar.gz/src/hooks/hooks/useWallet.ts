"use client";

import { useEffect, useState, useCallback } from "react";
import { useWallet } from "@/contexts/WalletContext";

export function useEncryptedBalance(tokenAddress: string) {
  const { state, decryptBalance, refreshBalances } = useWallet();
  const [decrypted, setDecrypted] = useState<number | null>(null);
  const [isDecrypting, setIsDecrypting] = useState(false);

  const balance = state.balances.get(tokenAddress);

  const decrypt = useCallback(async () => {
    if (!balance || !state.encryptionKey) return;
    setIsDecrypting(true);
    try {
      const val = await decryptBalance(tokenAddress);
      setDecrypted(val);
    } finally {
      setIsDecrypting(false);
    }
  }, [balance, state.encryptionKey, tokenAddress, decryptBalance]);

  useEffect(() => {
    if (balance && balance.ciphertext !== "0x" && state.encryptionKey) {
      decrypt();
    }
  }, [balance?.ciphertext, state.encryptionKey, decrypt]);

  return {
    encryptedBalance: balance?.ciphertext ?? null,
    decryptedBalance: decrypted,
    isDecrypting,
    decrypt,
    refresh: () => refreshBalances(),
  };
}

export function useTransactionHistory() {
  const { state } = useWallet();
  return {
    transactions: state.transactions,
    isLoading: state.isLoading,
  };
}

export function useTokenList() {
  const { state, addToken } = useWallet();
  return {
    tokens: state.tokens,
    addToken,
  };
}
