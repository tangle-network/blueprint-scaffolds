declare const _default: {
    plugins: any[];
    resolve: {
        alias: {
            fhenixjs: string;
        };
    };
};
export default _default;
