import "@nomicfoundation/hardhat-ethers";
import { HardhatUserConfig } from "hardhat/config";
declare const config: HardhatUserConfig;
export default config;
