import path from "node:path";

import react from "@vitejs/plugin-react";
import topLevelAwait from "vite-plugin-top-level-await";
import wasm from "vite-plugin-wasm";

export default {
  plugins: [react(), wasm(), topLevelAwait()],
  resolve: {
    alias: {
      fhenixjs: path.resolve(__dirname, "node_modules/fhenixjs/dist/fhenix.esm.min.js"),
    },
  },
};
