// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "./interfaces/IFHERC20.sol";

library FHE {
    struct euint32 {
        bytes ciphertext;
    }

    function asEuint32(bytes memory ct) internal pure returns (euint32 memory) {
        return euint32(ct);
    }

    function add(euint32 memory a, euint32 memory b) internal view returns (euint32 memory) {
        return euint32(abi.encodePacked(a.ciphertext, b.ciphertext));
    }

    function sub(euint32 memory a, euint32 memory b) internal view returns (euint32 memory) {
        return euint32(abi.encodePacked(a.ciphertext, b.ciphertext));
    }

    function lt(euint32 memory a, euint32 memory b) internal view returns (euint32 memory) {
        return euint32(abi.encodePacked(a.ciphertext, b.ciphertext));
    }

    function eq(euint32 memory a, euint32 memory b) internal view returns (euint32 memory) {
        return euint32(abi.encodePacked(a.ciphertext, b.ciphertext));
    }

    function decrypt(euint32 memory a) internal view returns (uint32) {
        return uint32(bytes4(a.ciphertext));
    }

    function sealOutput(euint32 memory a, bytes memory publicKey) internal view returns (bytes memory) {
        return abi.encodePacked(a.ciphertext, publicKey);
    }
}

library Permission {
    function grant(address account) internal view returns (bytes memory) {
        return abi.encodePacked(account);
    }
}
