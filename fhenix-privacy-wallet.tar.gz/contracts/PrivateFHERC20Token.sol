// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {FHERC20} from "@fhenixprotocol/contracts/experimental/token/FHERC20/FHERC20.sol";
import {Permission} from "@fhenixprotocol/contracts/access/Permissioned.sol";
import {FHE, euint128, inEuint128} from "@fhenixprotocol/contracts/FHE.sol";

contract PrivateFHERC20Token is FHERC20, Ownable {
    struct PrivateTransferRecord {
        bytes32 transferId;
        address from;
        address to;
        bytes32 encryptedAmountHash;
        uint256 timestamp;
        string memo;
    }

    PrivateTransferRecord[] private _history;

    event PrivateTransferLogged(
        bytes32 indexed transferId,
        address indexed from,
        address indexed to,
        bytes32 encryptedAmountHash,
        string memo
    );

    event PrivateMint(address indexed to);

    constructor(
        string memory name_,
        string memory symbol_,
        address owner_
    ) FHERC20(name_, symbol_) {
        _transferOwnership(owner_);
    }

    function mintEncrypted(address to, inEuint128 calldata encryptedAmount) external onlyOwner {
        _mintEncrypted(to, encryptedAmount);
        emit PrivateMint(to);
    }

    function transferEncryptedWithMemo(
        address to,
        inEuint128 calldata encryptedAmount,
        string calldata memo
    ) external returns (euint128) {
        bytes32 ciphertextHash = keccak256(abi.encode(encryptedAmount));
        euint128 amountSent = _transferEncrypted(to, FHE.asEuint128(encryptedAmount));

        bytes32 transferId = keccak256(
            abi.encodePacked(block.chainid, address(this), msg.sender, to, ciphertextHash, _history.length)
        );

        _history.push(
            PrivateTransferRecord({
                transferId: transferId,
                from: msg.sender,
                to: to,
                encryptedAmountHash: ciphertextHash,
                timestamp: block.timestamp,
                memo: memo
            })
        );

        emit PrivateTransferLogged(transferId, msg.sender, to, ciphertextHash, memo);
        return amountSent;
    }

    function historyLength() external view returns (uint256) {
        return _history.length;
    }

    function getTransferRecord(uint256 index) external view returns (PrivateTransferRecord memory) {
        return _history[index];
    }

    function viewOwnBalance(Permission calldata permission) external view returns (string memory) {
        return balanceOfEncrypted(msg.sender, permission);
    }
}
