// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "./FHERC20.sol";

contract FHERC20Factory {
    address[] public tokens;
    mapping(address => string) public tokenNames;
    mapping(address => string) public tokenSymbols;

    event TokenCreated(address indexed tokenAddress, string name, string symbol);

    function createToken(string memory _name, string memory _symbol) public returns (address) {
        FHERC20 newToken = new FHERC20(_name, _symbol);
        address tokenAddr = address(newToken);
        tokens.push(tokenAddr);
        tokenNames[tokenAddr] = _name;
        tokenSymbols[tokenAddr] = _symbol;
        emit TokenCreated(tokenAddr, _name, _symbol);
        return tokenAddr;
    }

    function getTokenCount() public view returns (uint256) {
        return tokens.length;
    }

    function getTokens() public view returns (address[] memory) {
        return tokens;
    }
}
