// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {FHE, euint32, inEuint32} from "fhe-lib/FHE.sol";
import {Permissioned, Permission} from "fhe-lib/Permissioned.sol";

contract FHERC20 is Permissioned {
    string public name;
    string public symbol;
    uint256 public totalSupply;

    mapping(address => euint32) private _encryptedBalances;
    mapping(address => mapping(address => uint256)) private _allowances;

    event Transfer(address indexed from, address indexed to);
    event Mint(address indexed to);
    event Approval(address indexed owner, address indexed spender, uint256 amount);

    constructor(string memory _name, string memory _symbol) {
        name = _name;
        symbol = _symbol;
    }

    function mint(address to, inEuint32 memory encryptedAmount) public virtual {
        euint32 amount = FHE.asEuint32(encryptedAmount);
        _encryptedBalances[to] = FHE.add(_encryptedBalances[to], amount);
        totalSupply += 1;
        emit Mint(to);
    }

    function encryptedTransfer(address to, inEuint32 memory encryptedAmount) public virtual {
        euint32 amount = FHE.asEuint32(encryptedAmount);
        euint32 senderBalance = _encryptedBalances[msg.sender];
        euint32 updatedSenderBalance = FHE.sub(senderBalance, amount);
        euint32 updatedRecipientBalance = FHE.add(_encryptedBalances[to], amount);
        _encryptedBalances[msg.sender] = updatedSenderBalance;
        _encryptedBalances[to] = updatedRecipientBalance;
        emit Transfer(msg.sender, to);
    }

    function encryptedBalanceOf(address account) public view virtual returns (euint32) {
        return _encryptedBalances[account];
    }

    function approve(address spender, uint256 amount) public virtual returns (bool) {
        _allowances[msg.sender][spender] = amount;
        emit Approval(msg.sender, spender, amount);
        return true;
    }

    function allowance(address owner, address spender) public view virtual returns (uint256) {
        return _allowances[owner][spender];
    }

    function generatePermission(address account) public view returns (Permission memory) {
        return Permission(address(this), account, true);
    }
}
