// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "./interfaces/IFHERC20.sol";
import "./libraries/FHE.sol";

contract FHERC20 is IFHERC20, FHERC20Errors {
    using FHE for FHE.euint32;
    using FHE for *;

    string private _name;
    string private _symbol;
    uint256 private _totalSupply;
    address private _owner;

    mapping(address => bytes) private _encryptedBalances;
    mapping(address => bytes) private _publicKeys;
    mapping(address => mapping(address => bytes)) private _allowances;

    event Transfer(address indexed from, address indexed to, bytes encryptedAmount);
    event Approval(address indexed owner, address indexed spender, bytes encryptedAmount);
    event Mint(address indexed to, bytes encryptedAmount);

    modifier onlyOwner() {
        if (msg.sender != _owner) revert FHERC20__OnlyOwner();
        _;
    }

    constructor(string memory name_, string memory symbol_) {
        _name = name_;
        _symbol = symbol_;
        _owner = msg.sender;
    }

    function name() external view override returns (string memory) {
        return _name;
    }

    function symbol() external view override returns (string memory) {
        return _symbol;
    }

    function totalSupply() external view override returns (uint256) {
        return _totalSupply;
    }

    function balanceOf(address account) external view override returns (bytes memory) {
        return _encryptedBalances[account];
    }

    function balanceOfEncrypted(address account, bytes calldata perm) external view returns (bytes memory) {
        bytes memory bal = _encryptedBalances[account];
        bytes memory pk = _publicKeys[account];
        require(pk.length > 0, "No public key");
        return FHE.sealOutput(FHE.asEuint32(bal), pk);
    }

    function setPublicKey(bytes calldata publicKey) external {
        _publicKeys[msg.sender] = publicKey;
    }

    function transfer(address to, bytes calldata encryptedAmount) external override {
        if (to == address(0)) revert FHERC20__ZeroAddress();
        _transfer(msg.sender, to, encryptedAmount);
    }

    function transferFrom(address from, address to, bytes calldata encryptedAmount) external override {
        if (to == address(0)) revert FHERC20__ZeroAddress();
        bytes memory allowance = _allowances[from][msg.sender];
        _allowances[from][msg.sender] = new bytes(0);
        _transfer(from, to, encryptedAmount);
        emit Approval(from, msg.sender, _allowances[from][msg.sender]);
    }

    function approve(address spender, bytes calldata encryptedAmount) external override {
        _allowances[msg.sender][spender] = encryptedAmount;
        emit Approval(msg.sender, spender, encryptedAmount);
    }

    function allowance(address owner, address spender) external view override returns (bytes memory) {
        return _allowances[owner][spender];
    }

    function mint(address to, bytes calldata encryptedAmount) external override onlyOwner {
        if (to == address(0)) revert FHERC20__ZeroAddress();
        bytes memory current = _encryptedBalances[to];
        FHE.euint32 memory amount = FHE.asEuint32(encryptedAmount);
        FHE.euint32 memory newBal = current.length == 0
            ? amount
            : FHE.add(FHE.asEuint32(current), amount);
        _encryptedBalances[to] = newBal.ciphertext;
        _totalSupply += 1;
        emit Mint(to, encryptedAmount);
    }

    function burnedBalanceOf(address) external pure override returns (bytes memory) {
        return new bytes(0);
    }

    function _transfer(address from, address to, bytes memory encryptedAmount) internal {
        bytes memory fromBal = _encryptedBalances[from];
        require(fromBal.length > 0, "Insufficient balance");
        FHE.euint32 memory amount = FHE.asEuint32(encryptedAmount);
        FHE.euint32 memory newFromBal = FHE.sub(FHE.asEuint32(fromBal), amount);
        bytes memory toBal = _encryptedBalances[to];
        FHE.euint32 memory newToBal = toBal.length == 0
            ? amount
            : FHE.add(FHE.asEuint32(toBal), amount);
        _encryptedBalances[from] = newFromBal.ciphertext;
        _encryptedBalances[to] = newToBal.ciphertext;
        emit Transfer(from, to, encryptedAmount);
    }
}

contract FHERC20Factory {
    address[] public tokens;
    mapping(address => string) public tokenNames;
    mapping(address => string) public tokenSymbols;

    event TokenCreated(address indexed tokenAddress, string name, string symbol, address indexed creator);

    function createToken(string calldata name, string calldata symbol) external returns (address) {
        FHERC20 token = new FHERC20(name, symbol);
        address tokenAddr = address(token);
        tokens.push(tokenAddr);
        tokenNames[tokenAddr] = name;
        tokenSymbols[tokenAddr] = symbol;
        emit TokenCreated(tokenAddr, name, symbol, msg.sender);
        return tokenAddr;
    }

    function getTokenCount() external view returns (uint256) {
        return tokens.length;
    }

    function getTokens() external view returns (address[] memory) {
        return tokens;
    }
}
