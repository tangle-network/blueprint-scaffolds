// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";

import {PrivateFHERC20Token} from "./PrivateFHERC20Token.sol";

contract PrivateTokenFactory is Ownable {
    address[] private _tokens;

    event TokenCreated(address indexed token, string name, string symbol, address indexed owner);

    constructor(address owner_) {
        _transferOwnership(owner_);
    }

    function createToken(
        string calldata name_,
        string calldata symbol_,
        address owner_
    ) external onlyOwner returns (address token) {
        PrivateFHERC20Token created = new PrivateFHERC20Token(name_, symbol_, owner_);
        token = address(created);
        _tokens.push(token);
        emit TokenCreated(token, name_, symbol_, owner_);
    }

    function allTokens() external view returns (address[] memory) {
        return _tokens;
    }
}
