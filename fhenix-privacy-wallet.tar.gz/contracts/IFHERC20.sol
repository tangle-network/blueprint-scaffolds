// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IFHERC20 {
    function name() external view returns (string memory);
    function symbol() external view returns (string memory);
    function totalSupply() external view returns (uint256);
    function mint(address to, inEuint32 memory encryptedAmount) external;
    function encryptedTransfer(address to, inEuint32 memory encryptedAmount) external;
    function encryptedBalanceOf(address account) external view returns (euint32);
    function allowance(address owner, address spender) external view returns (uint256);
    function approve(address spender, uint256 amount) external returns (bool);
}
