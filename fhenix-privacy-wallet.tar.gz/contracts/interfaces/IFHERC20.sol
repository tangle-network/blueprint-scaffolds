// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IEncrypted {
    function encrypt(uint256 value) external view returns (bytes memory);
}

interface IPermissions {
    function getPermission(address account) external view returns (bytes memory);
    function setPermission(bytes memory perm) external;
}

interface IFHERC20 {
    function name() external view returns (string memory);
    function symbol() external view returns (string memory);
    function totalSupply() external view returns (uint256);
    function balanceOf(address account) external view returns (bytes memory);
    function transfer(address to, bytes calldata encryptedAmount) external;
    function transferFrom(address from, address to, bytes calldata encryptedAmount) external;
    function approve(address spender, bytes calldata encryptedAmount) external;
    function allowance(address owner, address spender) external view returns (bytes memory);
    function mint(address to, bytes calldata encryptedAmount) external;
    function burnedBalanceOf(address account) external view returns (bytes memory);
}

interface IEncryptedBalanceOf {
    function balanceOfEncrypted(address account, bytes calldata perm) external view returns (bytes memory);
}

abstract contract FHERC20Errors {
    error FHERC20__InsufficientBalance();
    error FHERC20__InsufficientAllowance();
    error FHERC20__ZeroAddress();
    error FHERC20__OnlyOwner();
}
