import subprocess
import tempfile
import json
from pathlib import Path
from typing import Optional

ALLOWED_COMMANDS = {"python3", "node", "echo", "cat", "ls", "wc", "grep", "head", "tail", "sort", "uniq", "curl", "date"}
SANDBOX_DIR = Path(__file__).parent / "data" / "sandbox"
MAX_OUTPUT_BYTES = 100_000
TIMEOUT_SECONDS = 30


def _ensure_sandbox():
    SANDBOX_DIR.mkdir(parents=True, exist_ok=True)


def validate_command(cmd: str) -> tuple[bool, str]:
    parts = cmd.strip().split()
    if not parts:
        return False, "Empty command"
    base = Path(parts[0]).name
    if base not in ALLOWED_COMMANDS:
        return False, f"Command '{base}' not allowed. Allowed: {sorted(ALLOWED_COMMANDS)}"
    if ".." in cmd or ";" in cmd or "|" in cmd or "&" in cmd or "$" in cmd or "`" in cmd:
        return False, "Potentially unsafe characters in command"
    return True, "OK"


def run_sandboxed(code: str, language: str = "python", timeout: int = TIMEOUT_SECONDS) -> dict:
    _ensure_sandbox()

    if language == "python":
        suffix = ".py"
        cmd_template = ["python3", "-c"]
    elif language == "javascript":
        suffix = ".js"
        cmd_template = ["node", "-e"]
    else:
        return {"success": False, "error": f"Unsupported language: {language}"}

    safe_dir = SANDBOX_DIR / f"exec_{id(code)}"
    safe_dir.mkdir(exist_ok=True)

    try:
        with tempfile.NamedTemporaryFile(mode="w", suffix=suffix, dir=safe_dir, delete=False) as f:
            f.write(code)
            tmp_path = f.name

        cmd = ["python3" if language == "python" else "node", tmp_path]

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=str(safe_dir),
            env={"HOME": str(safe_dir), "PATH": "/usr/bin:/usr/local/bin", "PYTHONPATH": ""},
        )

        stdout = result.stdout[:MAX_OUTPUT_BYTES]
        stderr = result.stderr[:MAX_OUTPUT_BYTES]

        return {
            "success": result.returncode == 0,
            "returncode": result.returncode,
            "stdout": stdout,
            "stderr": stderr,
        }
    except subprocess.TimeoutExpired:
        return {"success": False, "error": f"Execution timed out after {timeout}s"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def run_validated_command(cmd: str, timeout: int = TIMEOUT_SECONDS) -> dict:
    valid, msg = validate_command(cmd)
    if not valid:
        return {"success": False, "error": msg}

    _ensure_sandbox()
    try:
        result = subprocess.run(
            cmd.split(),
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=str(SANDBOX_DIR),
            env={"HOME": str(SANDBOX_DIR), "PATH": "/usr/bin:/usr/local/bin"},
        )
        return {
            "success": result.returncode == 0,
            "returncode": result.returncode,
            "stdout": result.stdout[:MAX_OUTPUT_BYTES],
            "stderr": result.stderr[:MAX_OUTPUT_BYTES],
        }
    except subprocess.TimeoutExpired:
        return {"success": False, "error": f"Command timed out after {timeout}s"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def analyze_code(code: str) -> dict:
    lines = code.split("\n")
    non_empty = [l for l in lines if l.strip() and not l.strip().startswith("#")]
    imports = [l.strip() for l in lines if l.strip().startswith("import ") or l.strip().startswith("from ")]
    functions = [l.strip() for l in lines if "def " in l]
    classes = [l.strip() for l in lines if "class " in l]
    return {
        "total_lines": len(lines),
        "code_lines": len(non_empty),
        "imports": imports,
        "functions": functions,
        "classes": classes,
    }
