import uuid
from datetime import datetime

from backend.models import NodeName, NodeTransition, RunState, RunStatus
from backend.tools import finalize_artifact, generate_plan, review_plan, web_search
from backend.memory import save_checkpoint


def _transition(state: RunState, to_node: NodeName, output: dict | None = None) -> RunState:
    state.transitions.append(
        NodeTransition(
            from_node=state.current_node,
            to_node=to_node,
            timestamp=datetime.utcnow(),
            output_snapshot=output,
        )
    )
    state.current_node = to_node
    state.updated_at = datetime.utcnow()
    save_checkpoint(state.run_id, state.model_dump(mode="json"))
    return state


def create_run(title: str, description: str, workflow_type: str = "research_implementation") -> RunState:
    run_id = str(uuid.uuid4())[:8]
    state = RunState(
        run_id=run_id,
        title=title,
        description=description,
        workflow_type=workflow_type,
        status=RunStatus.RUNNING,
    )
    return _transition(state, NodeName.PLANNER)


def planner_node(state: RunState) -> RunState:
    research = web_search(state.description)
    plan = generate_plan(state.title, research)
    state.plan = plan
    state.status = RunStatus.RUNNING
    return _transition(state, NodeName.EXECUTOR, {"plan_length": len(plan)})


def executor_node(state: RunState) -> RunState:
    state.execution_result = f"Executed plan for: {state.title}\nAll phases initiated. Key results documented."
    state.status = RunStatus.RUNNING
    return _transition(state, NodeName.REVIEWER, {"executed": True})


def reviewer_node(state: RunState) -> RunState:
    review = review_plan(state.plan or "")
    state.review = review
    state.status = RunStatus.WAITING_APPROVAL
    return _transition(state, NodeName.HUMAN_APPROVAL, {"verdict": "APPROVED_WITH_SUGGESTIONS"})


def human_approval_node(state: RunState, approved: bool, feedback: str = "") -> RunState:
    if approved:
        state.approval_status = "approved"
        state.status = RunStatus.APPROVED
    else:
        state.approval_status = "rejected"
        state.status = RunStatus.REJECTED
    if feedback:
        state.review = (state.review or "") + f"\n\n## Human Feedback\n{feedback}"
    return _transition(state, NodeName.FINALIZER, {"approved": approved})


def finalizer_node(state: RunState) -> RunState:
    artifact = finalize_artifact(
        state.plan or "",
        state.review or "",
        state.approval_status == "approved",
    )
    state.final_artifact = artifact
    state.status = RunStatus.COMPLETED
    return _transition(state, NodeName.FINALIZER, {"artifact_length": len(artifact)})


def run_full_workflow(title: str, description: str) -> RunState:
    state = create_run(title, description)
    state = planner_node(state)
    state = executor_node(state)
    state = reviewer_node(state)
    return state


def resume_after_approval(run_id: str, approved: bool, feedback: str = "") -> RunState:
    from backend.memory import load_checkpoint
    data = load_checkpoint(run_id)
    if not data:
        raise ValueError(f"Run {run_id} not found")
    state = RunState(**data)
    state = human_approval_node(state, approved, feedback)
    state = finalizer_node(state)
    return state
