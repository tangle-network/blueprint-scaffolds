from langgraph.graph import StateGraph, END
from models import NodeName
from state import AgentState, initial_state
from nodes import (
    planner_node,
    executor_node,
    reviewer_node,
    human_approval_node,
    finalizer_node,
)
from memory import store_memory, get_run_memories


def should_route_after_review(state: AgentState) -> str:
    review_passed = state.get("review_passed", False)
    if review_passed:
        return "human_approval"
    return "planner"


def should_route_after_approval(state: AgentState) -> str:
    approved = state.get("human_approved")
    if approved is None:
        return "human_approval"
    if approved:
        return "finalizer"
    return "planner"


def build_graph() -> StateGraph:
    graph = StateGraph(AgentState)

    graph.add_node("planner", planner_node)
    graph.add_node("executor", executor_node)
    graph.add_node("reviewer", reviewer_node)
    graph.add_node("human_approval", human_approval_node)
    graph.add_node("finalizer", finalizer_node)

    graph.set_entry_point("planner")

    graph.add_edge("planner", "executor")
    graph.add_edge("executor", "reviewer")
    graph.add_conditional_edges("reviewer", should_route_after_review, {
        "human_approval": "human_approval",
        "planner": "planner",
    })
    graph.add_conditional_edges("human_approval", should_route_after_approval, {
        "finalizer": "finalizer",
        "planner": "planner",
        "human_approval": "human_approval",
    })
    graph.add_edge("finalizer", END)

    return graph


def compile_graph():
    graph = build_graph()
    try:
        from langgraph.checkpoint.sqlite import SqliteSaver
        import sqlite3
        from pathlib import Path
        Path("data").mkdir(exist_ok=True)
        conn = sqlite3.connect("data/checkpoints.db", check_same_thread=False)
        saver = SqliteSaver(conn)
        return graph.compile(checkpointer=saver)
    except Exception:
        return graph.compile()


def run_workflow_sync(run_id: str, task_description: str, workflow_type: str) -> AgentState:
    import database
    from datetime import datetime, timezone

    state = initial_state(run_id, task_description, workflow_type)

    store_memory(run_id, "task", task_description, ["task", workflow_type])
    database.add_transition(run_id, None, NodeName.PLANNER, "Starting workflow — entering planner node")

    state.update(planner_node(state))
    database.add_transition(run_id, NodeName.PLANNER, NodeName.EXECUTOR, f"Plan generated ({len(state.get('plan', ''))} chars). Research complete.")
    database.add_snapshot(run_id, NodeName.PLANNER, {"plan": state.get("plan", ""), "research": state.get("research_results", "")})
    store_memory(run_id, "plan", state.get("plan", ""), ["plan", "research"])

    state.update(executor_node(state))
    database.add_transition(run_id, NodeName.EXECUTOR, NodeName.REVIEWER, f"Execution complete ({len(state.get('execution_output', ''))} chars output).")
    database.add_snapshot(run_id, NodeName.EXECUTOR, {"implementation": state.get("implementation_steps", ""), "output": state.get("execution_output", "")})
    store_memory(run_id, "execution", state.get("execution_output", ""), ["execution", "output"])

    state.update(reviewer_node(state))
    review_passed = state.get("review_passed", False)
    database.add_transition(
        run_id, NodeName.REVIEWER, NodeName.HUMAN_APPROVAL,
        f"Review complete. Verdict: {'PASS' if review_passed else 'FAIL'}. Awaiting human approval."
    )
    database.add_snapshot(run_id, NodeName.REVIEWER, {"review_notes": state.get("review_notes", ""), "passed": review_passed})
    store_memory(run_id, "review", state.get("review_notes", ""), ["review", "verdict"])

    database.set_status(run_id, "awaiting_approval" if review_passed else "running")

    return state


def finalize_workflow(run_id: str, state: AgentState, approved: bool, feedback: str = None) -> AgentState:
    import database
    from nodes import finalizer_node

    state["human_approved"] = approved
    state["human_feedback"] = feedback

    if not approved:
        database.add_transition(run_id, NodeName.HUMAN_APPROVAL, NodeName.PLANNER, f"Rejected: {feedback or 'No feedback provided'}. Routing back to planner.")
        database.set_status(run_id, "running")
        state.update(planner_node(state))
        state.update(executor_node(state))
        state.update(reviewer_node(state))
        database.add_transition(run_id, NodeName.REVIEWER, NodeName.HUMAN_APPROVAL, "Re-review complete after revision. Awaiting approval.")
        database.set_status(run_id, "awaiting_approval")
        return state

    database.add_transition(run_id, NodeName.HUMAN_APPROVAL, NodeName.FINALIZER, f"Approved: {feedback or 'No additional feedback'}")

    state.update(finalizer_node(state))
    artifact = state.get("artifact", "")
    database.add_snapshot(run_id, NodeName.FINALIZER, {"artifact": artifact[:500]})
    database.set_artifact(run_id, artifact)
    database.set_status(run_id, "completed")

    store_memory(run_id, "final_artifact", artifact, ["artifact", "final"])
    return state
