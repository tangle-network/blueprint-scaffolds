import threading
from typing import Optional
import graph as graph_module
import database
from state import AgentState


_active_runs: dict[str, threading.Thread] = {}
_run_states: dict[str, AgentState] = {}


def start_run(run_id: str, task_description: str, workflow_type: str) -> None:
    _active_runs[run_id] = threading.Thread(
        target=_execute_run,
        args=(run_id, task_description, workflow_type),
        daemon=True,
    )
    _active_runs[run_id].start()


def _execute_run(run_id: str, task_description: str, workflow_type: str) -> None:
    try:
        state = graph_module.run_workflow_sync(run_id, task_description, workflow_type)
        _run_states[run_id] = state
    except Exception as e:
        database.set_status(run_id, "failed")
        database.add_transition(
            None, None, None,
            f"Run failed: {str(e)}",
        )


def process_approval(run_id: str, approved: bool, feedback: Optional[str] = None) -> Optional[AgentState]:
    state = _run_states.get(run_id)
    if not state:
        return None

    try:
        updated = graph_module.finalize_workflow(run_id, state, approved, feedback)
        _run_states[run_id] = updated
        return updated
    except Exception as e:
        database.set_status(run_id, "failed")
        return None


def get_run_state(run_id: str) -> Optional[AgentState]:
    return _run_states.get(run_id)


def get_pending_approvals() -> list[dict]:
    runs = database.list_runs()
    pending = []
    for run in runs:
        if run.status.value == "awaiting_approval":
            state = _run_states.get(run.id)
            pending.append({
                "run_id": run.id,
                "node": "human_approval",
                "summary": f"Run '{run.title}' requires human approval",
                "details": {
                    "plan": state.get("plan", "")[:200] if state else "N/A",
                    "review_notes": state.get("review_notes", "")[:200] if state else "N/A",
                    "review_passed": state.get("review_passed") if state else None,
                },
            })
    return pending
