from pydantic import BaseModel
from typing import Optional
from datetime import datetime
from enum import Enum


class NodeName(str, Enum):
    PLANNER = "planner"
    EXECUTOR = "executor"
    REVIEWER = "reviewer"
    HUMAN_APPROVAL = "human_approval"
    FINALIZER = "finalizer"


class RunStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    WAITING_APPROVAL = "waiting_approval"
    APPROVED = "approved"
    REJECTED = "rejected"
    COMPLETED = "completed"
    FAILED = "failed"


class RunCreate(BaseModel):
    title: str
    description: str
    workflow_type: str = "research_implementation"


class ApprovalDecision(BaseModel):
    run_id: str
    approved: bool
    feedback: Optional[str] = None


class NodeTransition(BaseModel):
    from_node: Optional[NodeName] = None
    to_node: NodeName
    timestamp: datetime
    output_snapshot: Optional[dict] = None


class RunState(BaseModel):
    run_id: str
    title: str
    description: str
    workflow_type: str
    status: RunStatus = RunStatus.PENDING
    current_node: Optional[NodeName] = None
    plan: Optional[str] = None
    execution_result: Optional[str] = None
    review: Optional[str] = None
    approval_status: Optional[str] = None
    final_artifact: Optional[str] = None
    transitions: list[NodeTransition] = []
    created_at: datetime = datetime.utcnow()
    updated_at: datetime = datetime.utcnow()


class RunSummary(BaseModel):
    run_id: str
    title: str
    status: RunStatus
    current_node: Optional[NodeName]
    workflow_type: str
    created_at: datetime
    updated_at: datetime
