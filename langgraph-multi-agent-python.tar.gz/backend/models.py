from pydantic import BaseModel
from typing import Optional
from datetime import datetime
from enum import Enum


class NodeName(str, Enum):
    PLANNER = "planner"
    EXECUTOR = "executor"
    REVIEWER = "reviewer"
    HUMAN_APPROVAL = "human_approval"
    FINALIZER = "finalizer"


class RunStatus(str, Enum):
    RUNNING = "running"
    AWAITING_APPROVAL = "awaiting_approval"
    COMPLETED = "completed"
    FAILED = "failed"


class NodeTransition(BaseModel):
    from_node: Optional[NodeName] = None
    to_node: NodeName
    timestamp: str
    summary: str


class StateSnapshot(BaseModel):
    node: NodeName
    timestamp: str
    state: dict


class Run(BaseModel):
    id: str
    title: str
    status: RunStatus
    created_at: str
    updated_at: str
    transitions: list[NodeTransition] = []
    snapshots: list[StateSnapshot] = []
    artifact: Optional[str] = None


class NewRunRequest(BaseModel):
    title: str
    task_description: str
    workflow_type: str = "research_implementation"


class ApprovalRequest(BaseModel):
    run_id: str
    node: str
    summary: str
    details: dict = {}


class ApprovalDecision(BaseModel):
    approved: bool
    feedback: Optional[str] = None
