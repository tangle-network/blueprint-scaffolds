import json
import hashlib
from pathlib import Path
from typing import Optional

MEMORY_DIR = Path(__file__).parent / "data" / "memory"
MEMORY_INDEX = MEMORY_DIR / "index.json"


def _ensure_memory():
    MEMORY_DIR.mkdir(parents=True, exist_ok=True)
    if not MEMORY_INDEX.exists():
        MEMORY_INDEX.write_text(json.dumps({"entries": []}))


def _load_index() -> dict:
    _ensure_memory()
    return json.loads(MEMORY_INDEX.read_text())


def _save_index(index: dict):
    _ensure_memory()
    MEMORY_INDEX.write_text(json.dumps(index, indent=2))


def _simple_hash(text: str) -> str:
    return hashlib.md5(text.encode()).hexdigest()[:16]


def store_memory(run_id: str, key: str, content: str, tags: list[str] = None) -> str:
    _ensure_memory()
    entry_id = _simple_hash(f"{run_id}:{key}:{content[:100]}")
    entry_path = MEMORY_DIR / f"{entry_id}.json"
    entry = {
        "id": entry_id,
        "run_id": run_id,
        "key": key,
        "content": content,
        "tags": tags or [],
        "embedding_hash": _simple_hash(content),
    }
    entry_path.write_text(json.dumps(entry, indent=2))

    index = _load_index()
    entries = [e for e in index["entries"] if e["id"] != entry_id]
    entries.append({
        "id": entry_id,
        "run_id": run_id,
        "key": key,
        "tags": tags or [],
        "embedding_hash": _simple_hash(content),
    })
    index["entries"] = entries
    _save_index(index)
    return entry_id


def search_memory(query: str, limit: int = 5, run_id: Optional[str] = None) -> list[dict]:
    _ensure_memory()
    index = _load_index()
    query_words = set(query.lower().split())
    scored = []
    for entry in index["entries"]:
        if run_id and entry["run_id"] != run_id:
            continue
        key_words = set(entry["key"].lower().split("_"))
        tag_words = set(t.lower() for t in entry.get("tags", []))
        overlap = len(query_words & (key_words | tag_words))
        if overlap > 0:
            scored.append((overlap, entry))

    scored.sort(key=lambda x: -x[0])
    results = []
    for _, entry in scored[:limit]:
        entry_path = MEMORY_DIR / f"{entry['id']}.json"
        if entry_path.exists():
            results.append(json.loads(entry_path.read_text()))
    return results


def get_run_memories(run_id: str) -> list[dict]:
    _ensure_memory()
    index = _load_index()
    results = []
    for entry in index["entries"]:
        if entry["run_id"] == run_id:
            entry_path = MEMORY_DIR / f"{entry['id']}.json"
            if entry_path.exists():
                results.append(json.loads(entry_path.read_text()))
    return results
