import json
import os
from datetime import datetime

DB_PATH = os.environ.get("MEMORY_DB", "/tmp/langgraph_checkpoints.json")


def _load() -> dict:
    if os.path.exists(DB_PATH):
        with open(DB_PATH, "r") as f:
            return json.load(f)
    return {"runs": {}, "checkpoints": {}}


def _save(data: dict):
    with open(DB_PATH, "w") as f:
        json.dump(data, f, default=str, indent=2)


def save_checkpoint(run_id: str, state: dict):
    data = _load()
    ts = datetime.utcnow().isoformat()
    checkpoint_id = f"{run_id}_{ts}"
    data["checkpoints"][checkpoint_id] = {
        "run_id": run_id,
        "timestamp": ts,
        "state": state,
    }
    data["runs"][run_id] = state
    _save(data)
    return checkpoint_id


def load_checkpoint(run_id: str) -> dict | None:
    data = _load()
    return data["runs"].get(run_id)


def list_checkpoints(run_id: str) -> list[dict]:
    data = _load()
    return [
        {**v, "checkpoint_id": k}
        for k, v in data["checkpoints"].items()
        if v["run_id"] == run_id
    ]


def list_all_runs() -> list[dict]:
    data = _load()
    return list(data["runs"].values())
