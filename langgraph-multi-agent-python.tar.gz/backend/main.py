from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware

from backend.models import RunCreate, ApprovalDecision, RunState, RunSummary
from backend.graph import run_full_workflow, resume_after_approval
from backend.memory import load_checkpoint, list_all_runs, list_checkpoints

app = FastAPI(title="LangGraph Multi-Agent Control Plane", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/runs", response_model=list[RunSummary])
def get_runs():
    runs = list_all_runs()
    return [
        RunSummary(
            run_id=r["run_id"],
            title=r["title"],
            status=r["status"],
            current_node=r.get("current_node"),
            workflow_type=r.get("workflow_type", "research_implementation"),
            created_at=r["created_at"],
            updated_at=r["updated_at"],
        )
        for r in runs
    ]


@app.get("/api/runs/{run_id}", response_model=RunState)
def get_run(run_id: str):
    data = load_checkpoint(run_id)
    if not data:
        raise HTTPException(404, "Run not found")
    return RunState(**data)


@app.post("/api/runs", response_model=RunState)
def create_run(body: RunCreate, background_tasks: BackgroundTasks):
    background_tasks.add_task(run_full_workflow, body.title, body.description)
    state = run_full_workflow(body.title, body.description)
    return state


@app.post("/api/runs/{run_id}/approve", response_model=RunState)
def approve_run(run_id: str, body: ApprovalDecision):
    try:
        state = resume_after_approval(run_id, body.approved, body.feedback or "")
        return state
    except ValueError as e:
        raise HTTPException(404, str(e))


@app.get("/api/runs/{run_id}/checkpoints")
def get_checkpoints(run_id: str):
    return list_checkpoints(run_id)


@app.get("/api/health")
def health():
    return {"status": "ok"}
