from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pathlib import Path

import database
import runner
from models import NewRunRequest, ApprovalDecision, Run

app = FastAPI(title="Multi-Agent Control Plane", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/runs")
def list_runs():
    return [r.model_dump(mode="json") for r in database.list_runs()]


@app.post("/api/runs", response_model=Run)
def create_run(req: NewRunRequest):
    run = database.create_run(req.title, req.task_description, req.workflow_type)
    runner.start_run(run.id, req.task_description, req.workflow_type)
    return run.model_dump(mode="json")


@app.get("/api/runs/{run_id}")
def get_run(run_id: str):
    run = database.get_run(run_id)
    if not run:
        return {"error": "Run not found"}, 404
    return run.model_dump(mode="json")


@app.post("/api/runs/{run_id}/approve")
def approve_run(run_id: str, decision: ApprovalDecision):
    run = database.get_run(run_id)
    if not run:
        return {"error": "Run not found"}, 404

    state = runner.process_approval(run_id, decision.approved, decision.feedback)
    if not state:
        return {"error": "No active state for this run"}, 400

    run = database.get_run(run_id)
    return run.model_dump(mode="json") if run else {"error": "Run not found"}


@app.get("/api/approvals")
def get_approvals():
    return runner.get_pending_approvals()


@app.get("/api/runs/{run_id}/state")
def get_run_state(run_id: str):
    state = runner.get_run_state(run_id)
    if not state:
        run = database.get_run(run_id)
        if run and run.snapshots:
            return [s.model_dump(mode="json") for s in run.snapshots]
        return []
    clean = {k: v for k, v in state.items() if v is not None}
    return [{"node": state.get("current_node", "unknown"), "timestamp": "live", "state": clean}]


frontend_dist = Path(__file__).parent.parent / "frontend" / "dist"
if frontend_dist.exists():
    app.mount("/", StaticFiles(directory=str(frontend_dist), html=True), name="frontend")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
