from typing import TypedDict, Optional
from models import NodeName


class AgentState(TypedDict, total=False):
    run_id: str
    task_description: str
    workflow_type: str
    current_node: NodeName
    plan: Optional[str]
    research_results: Optional[str]
    implementation_steps: Optional[str]
    execution_output: Optional[str]
    review_notes: Optional[str]
    review_passed: Optional[bool]
    human_approved: Optional[bool]
    human_feedback: Optional[str]
    artifact: Optional[str]
    error: Optional[str]
    messages: list[dict]


def initial_state(run_id: str, task_description: str, workflow_type: str) -> AgentState:
    return AgentState(
        run_id=run_id,
        task_description=task_description,
        workflow_type=workflow_type,
        current_node=NodeName.PLANNER,
        messages=[],
        plan=None,
        research_results=None,
        implementation_steps=None,
        execution_output=None,
        review_notes=None,
        review_passed=None,
        human_approved=None,
        human_feedback=None,
        artifact=None,
        error=None,
    )
