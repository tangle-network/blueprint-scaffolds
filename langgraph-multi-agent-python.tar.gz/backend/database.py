import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from models import Run, RunStatus, NodeTransition, StateSnapshot, NodeName

DB_PATH = Path(__file__).parent / "data" / "runs.json"


def _ensure_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    if not DB_PATH.exists():
        DB_PATH.write_text("[]")


def _load_runs() -> list[dict]:
    _ensure_db()
    return json.loads(DB_PATH.read_text())


def _save_runs(runs: list[dict]):
    _ensure_db()
    DB_PATH.write_text(json.dumps(runs, indent=2, default=str))


def list_runs() -> list[Run]:
    runs = _load_runs()
    return [Run(**r) for r in runs]


def get_run(run_id: str) -> Optional[Run]:
    runs = _load_runs()
    for r in runs:
        if r["id"] == run_id:
            return Run(**r)
    return None


def create_run(title: str, task_description: str, workflow_type: str) -> Run:
    now = datetime.now(timezone.utc).isoformat()
    run = Run(
        id=str(uuid.uuid4()),
        title=title,
        status=RunStatus.RUNNING,
        created_at=now,
        updated_at=now,
    )
    runs = _load_runs()
    runs.append(run.model_dump(mode="json"))
    _save_runs(runs)
    return run


def update_run(run_id: str, **kwargs) -> Optional[Run]:
    runs = _load_runs()
    for i, r in enumerate(runs):
        if r["id"] == run_id:
            r.update(kwargs)
            r["updated_at"] = datetime.now(timezone.utc).isoformat()
            runs[i] = r
            _save_runs(runs)
            return Run(**r)
    return None


def add_transition(run_id: str, from_node: Optional[NodeName], to_node: NodeName, summary: str) -> Optional[Run]:
    run = get_run(run_id)
    if not run:
        return None
    transition = NodeTransition(
        from_node=from_node,
        to_node=to_node,
        timestamp=datetime.now(timezone.utc).isoformat(),
        summary=summary,
    )
    transitions = [t.model_dump(mode="json") for t in run.transitions]
    transitions.append(transition.model_dump(mode="json"))
    return update_run(run_id, transitions=transitions)


def add_snapshot(run_id: str, node: NodeName, state: dict) -> Optional[Run]:
    run = get_run(run_id)
    if not run:
        return None
    snapshot = StateSnapshot(
        node=node,
        timestamp=datetime.now(timezone.utc).isoformat(),
        state=state,
    )
    snapshots = [s.model_dump(mode="json") for s in run.snapshots]
    snapshots.append(snapshot.model_dump(mode="json"))
    return update_run(run_id, snapshots=snapshots)


def set_artifact(run_id: str, artifact: str) -> Optional[Run]:
    return update_run(run_id, artifact=artifact)


def set_status(run_id: str, status: RunStatus) -> Optional[Run]:
    return update_run(run_id, status=status.value)
