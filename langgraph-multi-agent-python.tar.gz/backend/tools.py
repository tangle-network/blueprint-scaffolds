import subprocess
import json
import textwrap


ALLOWED_COMMANDS = {"python3", "pip", "echo", "cat", "ls", "head", "wc", "grep"}


def _validate_command(cmd: str) -> str:
    parts = cmd.strip().split()
    if not parts:
        raise ValueError("Empty command")
    base = parts[0].split("/")[-1]
    if base not in ALLOWED_COMMANDS:
        raise ValueError(f"Command '{base}' is not allowed. Allowed: {ALLOWED_COMMANDS}")
    return cmd


def run_sandboxed(command: str, timeout: int = 30) -> dict:
    try:
        validated = _validate_command(command)
        result = subprocess.run(
            validated,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd="/tmp",
        )
        return {
            "command": validated,
            "exit_code": result.returncode,
            "stdout": result.stdout[:5000],
            "stderr": result.stderr[:2000],
        }
    except subprocess.TimeoutExpired:
        return {"command": command, "exit_code": -1, "stdout": "", "stderr": "Timeout"}
    except Exception as e:
        return {"command": command, "exit_code": -1, "stdout": "", "stderr": str(e)}


def web_search(query: str) -> str:
    return json.dumps({
        "query": query,
        "results": [
            {"title": f"Research: {query}", "snippet": f"Comprehensive analysis of {query} with key findings and recommendations.", "source": "internal-kb"},
            {"title": f"Best practices for {query}", "snippet": "Industry standard approaches and implementation guidelines.", "source": "internal-kb"},
        ],
    })


def generate_plan(topic: str, research: str) -> str:
    return textwrap.dedent(f"""\
    # Implementation Plan: {topic}

    ## Research Summary
    {research[:500]}

    ## Phase 1: Architecture Design
    - Define system boundaries and interfaces
    - Choose technology stack and frameworks
    - Design data models and API contracts

    ## Phase 2: Core Implementation
    - Implement domain logic and business rules
    - Build API endpoints and service layer
    - Create database schemas and migrations

    ## Phase 3: Testing & Verification
    - Write unit tests for core modules
    - Integration tests for API endpoints
    - Performance benchmarks and load testing

    ## Phase 4: Deployment
    - Containerize the application
    - Set up CI/CD pipeline
    - Configure monitoring and alerting
    """)


def review_plan(plan: str) -> str:
    return textwrap.dedent("""\
    ## Review Summary

    **Completeness:** 8/10 - Plan covers all major phases.
    **Feasibility:** 9/10 - Technology choices are well-suited.
    **Risk Assessment:** Medium - Timeline may be tight for Phase 3.

    ### Recommendations
    1. Add rollback strategy for deployment phase
    2. Include security audit in Phase 3
    3. Consider incremental rollout strategy

    ### Verdict: APPROVED_WITH_SUGGESTIONS
    """)


def finalize_artifact(plan: str, review: str, approval: bool) -> str:
    if not approval:
        return "## Final Artifact\n\nWorkflow was rejected. No artifact generated."
    return textwrap.dedent(f"""\
    # Final Deliverable

    {plan}

    ---

    ## Review Sign-off
    {review}

    ## Approval Status
    ✅ Approved for implementation
    """)
