from models import NodeName
from state import AgentState


RESEARCH_PROMPT = """You are a research planner agent. Given a task, create a detailed plan with:

1. RESEARCH PHASE: Key questions to investigate and information to gather
2. IMPLEMENTATION PHASE: Step-by-step plan with specific actions
3. VERIFICATION PHASE: How to validate the results

Task: {task_description}

Provide a structured plan with clear sections and actionable items."""

IMPLEMENTATION_PROMPT = """You are an implementation agent. Based on this plan:

{plan}

Execute the following steps for the task: {task_description}

Research context: {research_results}

Provide:
1. Detailed implementation steps with code examples where appropriate
2. Key decisions and rationale
3. Dependencies and requirements
4. Testing approach"""

REVIEW_PROMPT = """You are a code review and verification agent. Review the following implementation:

Plan: {plan}
Execution output: {execution_output}
Task: {task_description}

Evaluate on:
1. COMPLETENESS: Does it address all parts of the task?
2. CORRECTNESS: Are there logical errors or issues?
3. QUALITY: Is the code well-structured and maintainable?
4. SECURITY: Any security concerns?

Provide a PASS or FAIL verdict with detailed notes."""

FINALIZE_PROMPT = """Create a final summary artifact for this completed task:

Task: {task_description}
Plan: {plan}
Implementation: {execution_output}
Review: {review_notes}

Format as a comprehensive report with:
- Executive Summary
- Implementation Details
- Review Assessment
- Conclusions and Next Steps"""


def planner_node(state: AgentState) -> dict:
    task = state.get("task_description", "")
    workflow_type = state.get("workflow_type", "research_implementation")

    if workflow_type == "research_implementation":
        plan = _generate_research_plan(task)
        research = _simulate_research(task)
    elif workflow_type == "code_review":
        plan = _generate_review_plan(task)
        research = "Code analysis complete"
    else:
        plan = _generate_generic_plan(task)
        research = "Background research complete"

    return {
        "plan": plan,
        "research_results": research,
        "current_node": NodeName.EXECUTOR,
    }


def executor_node(state: AgentState) -> dict:
    task = state.get("task_description", "")
    plan = state.get("plan", "")
    research = state.get("research_results", "")

    implementation = _execute_plan(task, plan, research)
    code_output = _simulate_code_execution(task, plan)

    return {
        "implementation_steps": implementation,
        "execution_output": code_output,
        "current_node": NodeName.REVIEWER,
    }


def reviewer_node(state: AgentState) -> dict:
    task = state.get("task_description", "")
    plan = state.get("plan", "")
    execution = state.get("execution_output", "")

    review = _conduct_review(task, plan, execution)
    passed = "PASS" in review and "FAIL" not in review.split("PASS")[0]

    return {
        "review_notes": review,
        "review_passed": passed,
        "current_node": NodeName.HUMAN_APPROVAL,
    }


def human_approval_node(state: AgentState) -> dict:
    return {
        "current_node": NodeName.HUMAN_APPROVAL,
    }


def finalizer_node(state: AgentState) -> dict:
    task = state.get("task_description", "")
    plan = state.get("plan", "")
    execution = state.get("execution_output", "")
    review = state.get("review_notes", "")

    artifact = _generate_artifact(task, plan, execution, review)
    return {
        "artifact": artifact,
        "current_node": NodeName.FINALIZER,
    }


def _generate_research_plan(task: str) -> str:
    return f"""## Research & Implementation Plan
### Task: {task}

### Phase 1: Research
1. Identify core concepts and technologies relevant to the task
2. Survey existing solutions and best practices
3. Document constraints and requirements
4. Identify potential risks and mitigations

### Phase 2: Implementation
1. Design the solution architecture
2. Implement core functionality with test-driven approach
3. Integrate components and handle edge cases
4. Add error handling and logging

### Phase 3: Verification
1. Unit test all critical paths
2. Integration testing of component interactions
3. Performance benchmarking
4. Security review and validation"""


def _simulate_research(task: str) -> str:
    return f"""## Research Results for: {task}

### Key Findings
- LangGraph provides stateful multi-agent orchestration with checkpointing
- FastAPI offers async endpoints with automatic OpenAPI documentation
- Vector-backed memory enables semantic search across run histories
- Tool sandboxing with subprocess isolation prevents unauthorized access

### Recommended Approach
- Use LangGraph StateGraph for workflow definition
- Implement each agent as a node function
- Use conditional edges for human approval gates
- Store state snapshots at each transition for full auditability

### References
- LangGraph documentation on persistent checkpointing
- FastAPI background tasks for async processing
- SQLAlchemy async session patterns"""


def _generate_review_plan(task: str) -> str:
    return f"""## Code Review Plan
### Target: {task}

1. Analyze code structure and organization
2. Check for common anti-patterns
3. Verify error handling completeness
4. Assess test coverage
5. Security vulnerability scan"""


def _generate_generic_plan(task: str) -> str:
    return f"""## Plan: {task}

1. Understand requirements
2. Design approach
3. Implement solution
4. Test and validate"""


def _execute_plan(task: str, plan: str, research: str) -> str:
    return f"""## Implementation Steps

### Step 1: Project Setup
- Initialize project structure with proper module organization
- Configure dependencies (fastapi, langgraph, sqlalchemy, pydantic)
- Set up async database connection with aiosqlite

### Step 2: Core State Management
```python
class AgentState(TypedDict):
    run_id: str
    task_description: str
    plan: Optional[str]
    execution_output: Optional[str]
    review_notes: Optional[str]
    human_approved: Optional[bool]
    artifact: Optional[str]
```

### Step 3: Graph Construction
- Define nodes: planner -> executor -> reviewer -> human_approval -> finalizer
- Add conditional edge after reviewer for approval routing
- Implement checkpoint saver for persistent state

### Step 4: API Layer
- POST /runs - Create new workflow run
- GET /runs - List all runs
- GET /runs/{{id}} - Get run with full state
- POST /runs/{{id}}/approve - Submit human approval
- GET /approvals - List pending approvals"""


def _simulate_code_execution(task: str, plan: str) -> str:
    return f"""## Execution Output

[executor] Starting implementation for: {task}
[executor] Phase 1 complete: Project structure created
[executor] Phase 2 complete: State management implemented
[executor] Phase 3 complete: LangGraph workflow constructed
[executor] Phase 4 complete: FastAPI endpoints defined
[executor] Phase 5 complete: Frontend React control plane built

### Build Results
- TypeScript compilation: PASS (0 errors)
- All 5 agent nodes registered in workflow graph
- Checkpoint persistence configured with SqliteSaver
- Memory store initialized with vector-backed search
- Sandbox tool executor validated with safety checks

### Files Created
- backend/main.py (FastAPI app with CORS and background tasks)
- backend/graph.py (LangGraph StateGraph definition)
- backend/nodes.py (Agent node implementations)
- backend/database.py (JSON-backed run persistence)
- backend/memory.py (Vector-backed memory store)
- backend/sandbox.py (Tool sandboxing with subprocess isolation)
- frontend/src/App.tsx (Main control plane UI)
- frontend/src/api.ts (API client with typed endpoints)
- frontend/src/components/ (RunList, RunDetail, NewRunModal, ApprovalBadge)"""


def _conduct_review(task: str, plan: str, execution: str) -> str:
    return f"""## Review Assessment

### COMPLETENESS: PASS
- All phases of the plan have been addressed
- Task requirements fully covered in implementation
- No missing functionality identified

### CORRECTNESS: PASS
- State management follows LangGraph patterns correctly
- API endpoints properly handle async operations
- Error handling covers edge cases
- Type annotations are consistent

### QUALITY: PASS
- Clean separation of concerns between modules
- Consistent coding style throughout
- Proper use of Pydantic models for validation
- Well-structured React components with clear props

### SECURITY: PASS
- Tool sandboxing prevents command injection
- Input validation on all API endpoints
- No hardcoded credentials
- Sandbox directory isolation enforced

### OVERALL VERDICT: PASS
The implementation meets all requirements. Ready for human approval."""


def _generate_artifact(task: str, plan: str, execution: str, review: str) -> str:
    return f"""=============================================
  MULTI-AGENT SYSTEM — FINAL REPORT
=============================================

Task: {task}
Date: Generated by multi-agent pipeline

---------------------------------------------
  EXECUTIVE SUMMARY
---------------------------------------------
A comprehensive LangGraph multi-agent system was successfully designed and implemented.
The system includes planning, execution, review, and human approval steps with
a full React control plane for monitoring and interaction.

---------------------------------------------
  IMPLEMENTATION DETAILS
---------------------------------------------
1. LangGraph StateGraph with 5 agent nodes
2. Persistent checkpointing via SqliteSaver
3. Vector-backed memory store for semantic search
4. Tool sandboxing with subprocess isolation
5. FastAPI backend with async background jobs
6. React frontend with run management UI

---------------------------------------------
  REVIEW ASSESSMENT
---------------------------------------------
{review}

---------------------------------------------
  CONCLUSIONS & NEXT STEPS
---------------------------------------------
- System is production-ready for development use
- Consider adding authentication for production deployment
- Monitor background job performance at scale
- Add WebSocket support for real-time updates

============================================="""
