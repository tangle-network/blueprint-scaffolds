export type NodeName = 'planner' | 'executor' | 'reviewer' | 'human_approval' | 'finalizer';
export type RunStatus = 'running' | 'awaiting_approval' | 'completed' | 'failed';

export interface NodeTransition {
  from: NodeName | null;
  to: NodeName;
  timestamp: string;
  summary: string;
}

export interface StateSnapshot {
  node: NodeName;
  timestamp: string;
  state: Record<string, unknown>;
}

export interface Run {
  id: string;
  title: string;
  status: RunStatus;
  created_at: string;
  updated_at: string;
  transitions: NodeTransition[];
  snapshots: StateSnapshot[];
  artifact: string | null;
}

export interface ApprovalRequest {
  run_id: string;
  node: string;
  summary: string;
  details: Record<string, unknown>;
}

export interface NewRunRequest {
  title: string;
  task_description: string;
  workflow_type: string;
}

const API_BASE = '/api';

async function request<T>(path: string, opts?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...opts,
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`API error ${res.status}: ${text}`);
  }
  return res.json();
}

export const api = {
  listRuns: () => request<Run[]>('/runs'),
  getRun: (id: string) => request<Run>(`/runs/${id}`),
  createRun: (body: NewRunRequest) =>
    request<Run>('/runs', { method: 'POST', body: JSON.stringify(body) }),
  approveRun: (id: string, approved: boolean, feedback?: string) =>
    request<Run>(`/runs/${id}/approve`, {
      method: 'POST',
      body: JSON.stringify({ approved, feedback }),
    }),
  getPendingApprovals: () => request<ApprovalRequest[]>('/approvals'),
  getState: (id: string) => request<StateSnapshot[]>(`/runs/${id}/state`),
};
