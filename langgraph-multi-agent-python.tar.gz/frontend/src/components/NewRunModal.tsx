import { useState } from 'react';
import { NewRunRequest } from '../api';

interface Props {
  onSubmit: (req: NewRunRequest) => void;
  onClose: () => void;
}

const WORKFLOWS = [
  { value: 'research_implementation', label: 'Research & Implementation' },
  { value: 'code_review', label: 'Code Review Pipeline' },
  { value: 'documentation', label: 'Documentation Generator' },
];

export default function NewRunModal({ onSubmit, onClose }: Props) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [workflow, setWorkflow] = useState(WORKFLOWS[0].value);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await onSubmit({ title, task_description: description, workflow_type: workflow });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <h2>Create New Run</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Title</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Research LangGraph patterns"
              required
            />
          </div>
          <div className="form-group">
            <label>Task Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe the task for the multi-agent system..."
              rows={4}
              required
            />
          </div>
          <div className="form-group">
            <label>Workflow Type</label>
            <select value={workflow} onChange={(e) => setWorkflow(e.target.value)}>
              {WORKFLOWS.map((w) => (
                <option key={w.value} value={w.value}>
                  {w.label}
                </option>
              ))}
            </select>
          </div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <button type="button" className="btn" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={submitting}>
              {submitting ? 'Creating...' : 'Create Run'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
