interface Props {
  count: number;
}

export default function ApprovalBadge({ count }: Props) {
  if (count === 0) return null;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
      <span style={{ fontSize: 13 }}>Approvals</span>
      <span className="approval-count">{count}</span>
    </div>
  );
}
