import React, { useState } from 'react';
import { Run, ApprovalRequest, NodeName } from '../api';

interface Props {
  run: Run;
  approvals: ApprovalRequest[];
  onApprove: (runId: string, approved: boolean, feedback?: string) => void;
  onRefresh: () => void;
}

const NODE_ORDER: NodeName[] = ['planner', 'executor', 'reviewer', 'human_approval', 'finalizer'];
const NODE_ICONS: Record<NodeName, string> = {
  planner: '🧠',
  executor: '⚙️',
  reviewer: '🔍',
  human_approval: '👤',
  finalizer: '✅',
};
const NODE_LABELS: Record<NodeName, string> = {
  planner: 'Planner',
  executor: 'Executor',
  reviewer: 'Reviewer',
  human_approval: 'Approval',
  finalizer: 'Finalizer',
};

export default function RunDetail({ run, approvals, onApprove }: Props) {
  const currentNode = run.transitions.length > 0
    ? run.transitions[run.transitions.length - 1].to
    : null;
  const completedNodes = new Set(
    run.transitions.map((t) => t.to).filter(Boolean)
  );
  const pendingApproval = approvals.find((a) => a.run_id === run.id);

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8 }}>
        <h2 style={{ fontSize: 20, fontWeight: 700 }}>{run.title}</h2>
        <span className={`status-badge status-${run.status}`}>
          {run.status.replace('_', ' ')}
        </span>
      </div>
      <p style={{ fontSize: 13, color: 'var(--text-dim)', marginBottom: 16 }}>
        Created {new Date(run.created_at).toLocaleString()} · Updated {new Date(run.updated_at).toLocaleString()}
      </p>

      <div className="workflow-visual">
        {NODE_ORDER.map((node, i) => {
          const isActive = currentNode === node;
          const isCompleted = completedNodes.has(node) && !isActive;
          return (
            <React.Fragment key={node}>
              <div className={`wf-node ${isActive ? 'active' : ''} ${isCompleted ? 'completed' : ''}`}>
                <span className="icon">{NODE_ICONS[node]}</span>
                <span className="label">{NODE_LABELS[node]}</span>
              </div>
              {i < NODE_ORDER.length - 1 && (
                <div
                  className={`wf-arrow ${
                    isCompleted || (isActive && i === NODE_ORDER.indexOf(currentNode!))
                      ? 'completed'
                      : ''
                  }`}
                />
              )}
            </React.Fragment>
          );
        })}
      </div>

      {pendingApproval && (
        <ApprovalPanel
          approval={pendingApproval}
          onApprove={(approved, feedback) => onApprove(run.id, approved, feedback)}
        />
      )}

      {run.artifact && (
        <div className="card">
          <h3>📋 Final Artifact</h3>
          <div className="artifact-view">{run.artifact}</div>
        </div>
      )}

      <div className="card">
        <h3>📜 Node Transitions</h3>
        <div className="timeline">
          {run.transitions.map((t, i) => (
            <div key={i} className="timeline-item">
              <div
                className="timeline-dot"
                style={{
                  borderColor: 'var(--primary)',
                  background: 'var(--surface-2)',
                }}
              >
                {NODE_ICONS[t.to]}
              </div>
              <div className="timeline-content">
                <div className="tl-header">
                  {t.from ? `${NODE_LABELS[t.from]} → ${NODE_LABELS[t.to]}` : `Start → ${NODE_LABELS[t.to]}`}
                </div>
                <div className="tl-time">{new Date(t.timestamp).toLocaleString()}</div>
                <div className="tl-body">{t.summary}</div>
              </div>
            </div>
          ))}
          {run.transitions.length === 0 && (
            <div style={{ color: 'var(--text-dim)', fontSize: 13 }}>
              Waiting for first transition...
            </div>
          )}
        </div>
      </div>

      <div className="card">
        <h3>📊 State Snapshots</h3>
        {run.snapshots.length > 0 ? (
          run.snapshots.map((snap, i) => (
            <div key={i} style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 12, color: 'var(--text-dim)', marginBottom: 4 }}>
                {NODE_LABELS[snap.node]} @ {new Date(snap.timestamp).toLocaleString()}
              </div>
              <div className="state-viewer">
                {JSON.stringify(snap.state, null, 2)}
              </div>
            </div>
          ))
        ) : (
          <div style={{ color: 'var(--text-dim)', fontSize: 13 }}>No snapshots yet.</div>
        )}
      </div>
    </div>
  );
}

function ApprovalPanel({
  approval,
  onApprove,
}: {
  approval: ApprovalRequest;
  onApprove: (approved: boolean, feedback?: string) => void;
}) {
  const [feedback, setFeedback] = useState('');

  return (
    <div className="approval-panel">
      <h3>⏳ Human Approval Required</h3>
      <p>{approval.summary}</p>
      {approval.details && (
        <div className="state-viewer" style={{ marginBottom: 12 }}>
          {JSON.stringify(approval.details, null, 2)}
        </div>
      )}
      <div className="form-group">
        <label>Feedback (optional)</label>
        <textarea
          value={feedback}
          onChange={(e) => setFeedback(e.target.value)}
          placeholder="Add feedback for the agents..."
        />
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <button
          className="btn btn-success"
          onClick={() => onApprove(true, feedback)}
        >
          ✓ Approve
        </button>
        <button
          className="btn btn-danger"
          onClick={() => onApprove(false, feedback)}
        >
          ✗ Reject
        </button>
      </div>
    </div>
  );
}

