import { Run } from '../api';

interface Props {
  runs: Run[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  loading: boolean;
}

const statusLabel: Record<string, string> = {
  running: 'Running',
  awaiting_approval: 'Approval',
  completed: 'Done',
  failed: 'Failed',
};

export default function RunList({ runs, selectedId, onSelect, loading }: Props) {
  if (loading) {
    return <div className="run-list">Loading...</div>;
  }

  if (runs.length === 0) {
    return (
      <div style={{ color: 'var(--text-dim)', fontSize: 13, padding: '8px 0' }}>
        No runs yet. Create one to get started.
      </div>
    );
  }

  return (
    <div className="run-list">
      {runs.map((run) => (
        <div
          key={run.id}
          className={`run-item ${selectedId === run.id ? 'active' : ''}`}
          onClick={() => onSelect(run.id)}
        >
          <div className="title">{run.title}</div>
          <div className="meta">
            <span className={`status-badge status-${run.status}`}>
              {statusLabel[run.status] || run.status}
            </span>
            <span>{new Date(run.created_at).toLocaleTimeString()}</span>
          </div>
        </div>
      ))}
    </div>
  );
}
