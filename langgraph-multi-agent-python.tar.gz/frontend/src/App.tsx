import { useState, useEffect, useCallback } from 'react';
import { Run, ApprovalRequest, NewRunRequest, api } from './api';
import RunList from './components/RunList';
import RunDetail from './components/RunDetail';
import NewRunModal from './components/NewRunModal';
import ApprovalBadge from './components/ApprovalBadge';

export default function App() {
  const [runs, setRuns] = useState<Run[]>([]);
  const [selectedRunId, setSelectedRunId] = useState<string | null>(null);
  const [selectedRun, setSelectedRun] = useState<Run | null>(null);
  const [showNewRun, setShowNewRun] = useState(false);
  const [approvals, setApprovals] = useState<ApprovalRequest[]>([]);
  const [loading, setLoading] = useState(true);

  const refreshRuns = useCallback(async () => {
    try {
      const data = await api.listRuns();
      setRuns(data);
      setLoading(false);
    } catch {
      setLoading(false);
    }
  }, []);

  const refreshApprovals = useCallback(async () => {
    try {
      const data = await api.getPendingApprovals();
      setApprovals(data);
    } catch { /* empty */ }
  }, []);

  const refreshSelectedRun = useCallback(async () => {
    if (!selectedRunId) return;
    try {
      const data = await api.getRun(selectedRunId);
      setSelectedRun(data);
    } catch { /* empty */ }
  }, [selectedRunId]);

  useEffect(() => {
    refreshRuns();
    refreshApprovals();
    const interval = setInterval(() => {
      refreshRuns();
      refreshApprovals();
      refreshSelectedRun();
    }, 3000);
    return () => clearInterval(interval);
  }, [refreshRuns, refreshApprovals, refreshSelectedRun]);

  const handleCreateRun = async (req: NewRunRequest) => {
    const run = await api.createRun(req);
    setShowNewRun(false);
    setSelectedRunId(run.id);
    refreshRuns();
  };

  const handleApprove = async (runId: string, approved: boolean, feedback?: string) => {
    await api.approveRun(runId, approved, feedback);
    refreshSelectedRun();
    refreshApprovals();
    refreshRuns();
  };

  const handleSelectRun = (id: string) => {
    setSelectedRunId(id);
    api.getRun(id).then(setSelectedRun).catch(() => {});
  };

  return (
    <div className="app">
      <div className="header">
        <h1>Multi-Agent Control Plane</h1>
        <div className="header-actions">
          <ApprovalBadge count={approvals.length} />
          <button className="btn btn-primary" onClick={() => setShowNewRun(true)}>
            + New Run
          </button>
        </div>
      </div>
      <div className="sidebar">
        <h2>Runs ({runs.length})</h2>
        <RunList
          runs={runs}
          selectedId={selectedRunId}
          onSelect={handleSelectRun}
          loading={loading}
        />
      </div>
      <div className="main">
        {selectedRun ? (
          <RunDetail
            run={selectedRun}
            approvals={approvals}
            onApprove={handleApprove}
            onRefresh={refreshSelectedRun}
          />
        ) : (
          <div className="empty-state">
            <div className="icon">🤖</div>
            <h3>Multi-Agent System</h3>
            <p>Select a run from the sidebar or create a new one to get started.</p>
          </div>
        )}
      </div>
      {showNewRun && (
        <NewRunModal
          onSubmit={handleCreateRun}
          onClose={() => setShowNewRun(false)}
        />
      )}
    </div>
  );
}
