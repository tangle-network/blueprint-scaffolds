export type NodeName =
  | "planner"
  | "executor"
  | "reviewer"
  | "human_approval"
  | "finalizer";

export type RunStatus =
  | "pending"
  | "running"
  | "waiting_approval"
  | "approved"
  | "rejected"
  | "completed"
  | "failed";

export interface NodeTransition {
  from_node: NodeName | null;
  to_node: NodeName;
  timestamp: string;
  output_snapshot: Record<string, unknown> | null;
}

export interface RunState {
  run_id: string;
  title: string;
  description: string;
  workflow_type: string;
  status: RunStatus;
  current_node: NodeName | null;
  plan: string | null;
  execution_result: string | null;
  review: string | null;
  approval_status: string | null;
  final_artifact: string | null;
  transitions: NodeTransition[];
  created_at: string;
  updated_at: string;
}

export interface RunSummary {
  run_id: string;
  title: string;
  status: RunStatus;
  current_node: NodeName | null;
  workflow_type: string;
  created_at: string;
  updated_at: string;
}

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "";

async function fetchAPI<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
}

export async function getRuns(): Promise<RunSummary[]> {
  return fetchAPI<RunSummary[]>("/api/runs");
}

export async function getRun(runId: string): Promise<RunState> {
  return fetchAPI<RunState>(`/api/runs/${runId}`);
}

export async function createRun(
  title: string,
  description: string,
): Promise<RunState> {
  return fetchAPI<RunState>("/api/runs", {
    method: "POST",
    body: JSON.stringify({ title, description }),
  });
}

export async function approveRun(
  runId: string,
  approved: boolean,
  feedback?: string,
): Promise<RunState> {
  return fetchAPI<RunState>(`/api/runs/${runId}/approve`, {
    method: "POST",
    body: JSON.stringify({ run_id: runId, approved, feedback }),
  });
}

const MOCK_RUNS: RunState[] = [
  {
    run_id: "demo-001",
    title: "REST API Design for E-Commerce Platform",
    description:
      "Research and implement a scalable REST API architecture for an e-commerce platform with payment processing, inventory management, and order tracking.",
    workflow_type: "research_implementation",
    status: "completed",
    current_node: "finalizer",
    plan:
      "# Implementation Plan: REST API Design for E-Commerce Platform\n\n## Research Summary\nComprehensive analysis of e-commerce API patterns including Stripe integration, inventory event sourcing, and order state machines.\n\n## Phase 1: Architecture Design\n- Define system boundaries and interfaces\n- Choose technology stack and frameworks\n- Design data models and API contracts\n\n## Phase 2: Core Implementation\n- Implement domain logic and business rules\n- Build API endpoints and service layer\n- Create database schemas and migrations\n\n## Phase 3: Testing & Verification\n- Write unit tests for core modules\n- Integration tests for API endpoints\n- Performance benchmarks and load testing\n\n## Phase 4: Deployment\n- Containerize the application\n- Set up CI/CD pipeline\n- Configure monitoring and alerting",
    execution_result:
      "Executed plan for: REST API Design for E-Commerce Platform\nAll phases initiated. Key results documented.",
    review:
      '## Review Summary\n\n**Completeness:** 8/10 - Plan covers all major phases.\n**Feasibility:** 9/10 - Technology choices are well-suited.\n**Risk Assessment:** Medium - Timeline may be tight for Phase 3.\n\n### Recommendations\n1. Add rollback strategy for deployment phase\n2. Include security audit in Phase 3\n3. Consider incremental rollout strategy\n\n### Verdict: APPROVED_WITH_SUGGESTIONS\n\n## Human Feedback\nLooks good. Please add more detail on the payment processing security requirements.',
    approval_status: "approved",
    final_artifact:
      "# Final Deliverable\n\n## Implementation Plan\n\nAll phases documented and approved.\n\n## Review Sign-off\n\nVerdict: APPROVED_WITH_SUGGESTIONS\n\n## Approval Status\n✅ Approved for implementation",
    transitions: [
      { from_node: null, to_node: "planner", timestamp: "2025-01-15T10:00:00Z", output_snapshot: null },
      { from_node: "planner", to_node: "executor", timestamp: "2025-01-15T10:00:02Z", output_snapshot: { plan_length: 450 } },
      { from_node: "executor", to_node: "reviewer", timestamp: "2025-01-15T10:00:03Z", output_snapshot: { executed: true } },
      { from_node: "reviewer", to_node: "human_approval", timestamp: "2025-01-15T10:00:04Z", output_snapshot: { verdict: "APPROVED_WITH_SUGGESTIONS" } },
      { from_node: "human_approval", to_node: "finalizer", timestamp: "2025-01-15T10:05:00Z", output_snapshot: { approved: true } },
      { from_node: "finalizer", to_node: "finalizer", timestamp: "2025-01-15T10:05:01Z", output_snapshot: { artifact_length: 320 } },
    ],
    created_at: "2025-01-15T10:00:00Z",
    updated_at: "2025-01-15T10:05:01Z",
  },
  {
    run_id: "demo-002",
    title: "ML Pipeline for Sentiment Analysis",
    description:
      "Build a machine learning pipeline for real-time sentiment analysis of customer reviews with model training, evaluation, and deployment.",
    workflow_type: "research_implementation",
    status: "waiting_approval",
    current_node: "human_approval",
    plan:
      "# Implementation Plan: ML Pipeline for Sentiment Analysis\n\n## Research Summary\nTransformer-based models (BERT, RoBERTa) achieve 95%+ accuracy on sentiment benchmarks.\n\n## Phase 1: Architecture Design\n- Define model architecture and data pipeline\n- Choose ML framework (PyTorch + HuggingFace)\n- Design feature extraction pipeline\n\n## Phase 2: Core Implementation\n- Implement data preprocessing and augmentation\n- Build model training loop with hyperparameter tuning\n- Create inference API endpoint\n\n## Phase 3: Testing & Verification\n- Model evaluation on held-out test set\n- A/B testing framework integration\n- Latency benchmarks for real-time inference\n\n## Phase 4: Deployment\n- Model serving with TorchServe\n- Kubernetes deployment with autoscaling\n- Model monitoring and drift detection",
    execution_result:
      "Executed plan for: ML Pipeline for Sentiment Analysis\nAll phases initiated. Key results documented.",
    review:
      "## Review Summary\n\n**Completeness:** 9/10 - Excellent coverage of ML lifecycle.\n**Feasibility:** 7/10 - Resource requirements may need adjustment.\n**Risk Assessment:** Medium-High - Model performance uncertainty.\n\n### Recommendations\n1. Add fallback strategy for model failures\n2. Include cost estimation for GPU training\n3. Plan for model versioning and rollback\n\n### Verdict: APPROVED_WITH_SUGGESTIONS",
    approval_status: null,
    final_artifact: null,
    transitions: [
      { from_node: null, to_node: "planner", timestamp: "2025-01-15T11:00:00Z", output_snapshot: null },
      { from_node: "planner", to_node: "executor", timestamp: "2025-01-15T11:00:03Z", output_snapshot: { plan_length: 520 } },
      { from_node: "executor", to_node: "reviewer", timestamp: "2025-01-15T11:00:04Z", output_snapshot: { executed: true } },
      { from_node: "reviewer", to_node: "human_approval", timestamp: "2025-01-15T11:00:05Z", output_snapshot: { verdict: "APPROVED_WITH_SUGGESTIONS" } },
    ],
    created_at: "2025-01-15T11:00:00Z",
    updated_at: "2025-01-15T11:00:05Z",
  },
  {
    run_id: "demo-003",
    title: "Authentication Microservice",
    description:
      "Design and implement an OAuth2/OIDC authentication microservice with JWT tokens, refresh flow, and role-based access control.",
    workflow_type: "research_implementation",
    status: "running",
    current_node: "executor",
    plan:
      "# Implementation Plan: Authentication Microservice\n\n## Research Summary\nOAuth2/OIDC with JWT is the industry standard. Keycloak and Auth0 are leading solutions.\n\n## Phase 1: Architecture Design\n- Design token lifecycle and rotation strategy\n- Define RBAC permission model\n- Plan multi-tenant support\n\n## Phase 2: Core Implementation\n- Implement OAuth2 authorization server\n- Build JWT issuance and validation\n- Create user management CRUD API\n\n## Phase 3: Testing & Verification\n- Security penetration testing\n- Token expiration and refresh flow tests\n- Rate limiting and brute-force protection tests\n\n## Phase 4: Deployment\n- Deploy as standalone microservice\n- Configure API gateway integration\n- Set up audit logging",
    execution_result: null,
    review: null,
    approval_status: null,
    final_artifact: null,
    transitions: [
      { from_node: null, to_node: "planner", timestamp: "2025-01-15T12:00:00Z", output_snapshot: null },
      { from_node: "planner", to_node: "executor", timestamp: "2025-01-15T12:00:02Z", output_snapshot: { plan_length: 380 } },
    ],
    created_at: "2025-01-15T12:00:00Z",
    updated_at: "2025-01-15T12:00:02Z",
  },
];

const mockSummaries: RunSummary[] = MOCK_RUNS.map((r) => ({
  run_id: r.run_id,
  title: r.title,
  status: r.status,
  current_node: r.current_node,
  workflow_type: r.workflow_type,
  created_at: r.created_at,
  updated_at: r.updated_at,
}));

export function getMockRuns(): RunSummary[] {
  return mockSummaries;
}

export function getMockRun(runId: string): RunState | undefined {
  return MOCK_RUNS.find((r) => r.run_id === runId);
}
