"use client"

import { RunStatus } from "@/lib/api"

const statusConfig: Record<RunStatus, { label: string; className: string }> = {
  pending: { label: "Pending", className: "bg-yellow-100 text-yellow-800 border-yellow-200" },
  running: { label: "Running", className: "bg-blue-100 text-blue-800 border-blue-200" },
  waiting_approval: { label: "Awaiting Approval", className: "bg-orange-100 text-orange-800 border-orange-200" },
  approved: { label: "Approved", className: "bg-green-100 text-green-800 border-green-200" },
  rejected: { label: "Rejected", className: "bg-red-100 text-red-800 border-red-200" },
  completed: { label: "Completed", className: "bg-green-100 text-green-800 border-green-200" },
  failed: { label: "Failed", className: "bg-red-100 text-red-800 border-red-200" },
}

export function StatusBadge({ status }: { status: RunStatus }) {
  const config = statusConfig[status] || statusConfig.pending
  return (
    <span className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold ${config.className}`}>
      {config.label}
    </span>
  )
}
