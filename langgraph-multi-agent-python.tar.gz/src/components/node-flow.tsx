"use client"

import { NodeName, NodeTransition } from "@/lib/api"
import { CheckCircle, Circle, ArrowRight } from "lucide-react"
import { cn } from "@/lib/utils"

const NODE_LABELS: Record<string, string> = {
  planner: "Planner",
  executor: "Executor",
  reviewer: "Reviewer",
  human_approval: "Human Approval",
  finalizer: "Finalizer",
}

const NODES_ORDER: NodeName[] = ["planner", "executor", "reviewer", "human_approval", "finalizer"]

export function NodeFlow({ transitions, currentNode }: { transitions: NodeTransition[]; currentNode: NodeName | null }) {
  const visitedNodes = new Set(transitions.map((t) => t.to_node))
  const currentNodeIdx = currentNode ? NODES_ORDER.indexOf(currentNode) : -1

  return (
    <div className="flex items-center gap-1 overflow-x-auto py-2">
      {NODES_ORDER.map((node, idx) => {
        const isVisited = visitedNodes.has(node)
        const isCurrent = node === currentNode
        return (
          <div key={node} className="flex items-center gap-1">
            <div
              className={cn(
                "flex items-center gap-2 rounded-md border px-3 py-1.5 text-sm",
                isCurrent && "border-primary bg-primary/10 font-medium text-primary",
                isVisited && !isCurrent && "border-green-300 bg-green-50 text-green-700",
                !isVisited && !isCurrent && "border-muted bg-muted/50 text-muted-foreground"
              )}
            >
              {isVisited && !isCurrent ? (
                <CheckCircle className="h-3.5 w-3.5 text-green-600" />
              ) : isCurrent ? (
                <Circle className="h-3.5 w-3.5 fill-primary text-primary" />
              ) : (
                <Circle className="h-3.5 w-3.5" />
              )}
              {NODE_LABELS[node]}
            </div>
            {idx < NODES_ORDER.length - 1 && (
              <ArrowRight className="h-4 w-4 shrink-0 text-muted-foreground" />
            )}
          </div>
        )
      })}
    </div>
  )
}
