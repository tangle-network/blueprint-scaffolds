"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, XCircle } from "lucide-react"

interface ApprovalPanelProps {
  runId: string
  onApprove: (runId: string, approved: boolean, feedback: string) => void
}

export function ApprovalPanel({ runId, onApprove }: ApprovalPanelProps) {
  const [feedback, setFeedback] = useState("")
  const [submitting, setSubmitting] = useState(false)

  const handleDecision = (approved: boolean) => {
    setSubmitting(true)
    onApprove(runId, approved, feedback)
    setSubmitting(false)
  }

  return (
    <Card className="border-orange-200 bg-orange-50/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <span className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-orange-100">
            <span className="h-2 w-2 rounded-full bg-orange-500" />
          </span>
          Human Approval Required
        </CardTitle>
        <CardDescription>
          Review the plan and execution results above, then approve or reject with optional feedback.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Textarea
          placeholder="Optional feedback for the agents..."
          value={feedback}
          onChange={(e) => setFeedback(e.target.value)}
          rows={3}
        />
        <div className="flex gap-2">
          <Button
            onClick={() => handleDecision(true)}
            disabled={submitting}
            className="bg-green-600 hover:bg-green-700"
          >
            <CheckCircle className="mr-2 h-4 w-4" />
            Approve
          </Button>
          <Button
            variant="destructive"
            onClick={() => handleDecision(false)}
            disabled={submitting}
          >
            <XCircle className="mr-2 h-4 w-4" />
            Reject
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
