"use client"

import { NodeTransition } from "@/lib/api"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { GitBranch } from "lucide-react"
import { cn } from "@/lib/utils"

const NODE_COLORS: Record<string, string> = {
  planner: "bg-blue-500",
  executor: "bg-purple-500",
  reviewer: "bg-yellow-500",
  human_approval: "bg-orange-500",
  finalizer: "bg-green-500",
}

export function TransitionTimeline({ transitions }: { transitions: NodeTransition[] }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <GitBranch className="h-5 w-5" />
          Node Transitions
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-0">
          {transitions.map((t, idx) => (
            <div key={idx} className="flex gap-3">
              <div className="flex flex-col items-center">
                <div className={cn("h-3 w-3 rounded-full", NODE_COLORS[t.to_node] || "bg-gray-400")} />
                {idx < transitions.length - 1 && <div className="w-px flex-1 bg-border" />}
              </div>
              <div className="pb-4">
                <div className="flex items-center gap-2">
                  {t.from_node && (
                    <span className="text-xs text-muted-foreground">{t.from_node}</span>
                  )}
                  <span className="text-xs text-muted-foreground">&rarr;</span>
                  <span className="text-sm font-medium">{t.to_node}</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  {new Date(t.timestamp).toLocaleString()}
                </p>
                {t.output_snapshot && (
                  <div className="mt-1 rounded bg-muted px-2 py-1 text-xs font-mono">
                    {JSON.stringify(t.output_snapshot)}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
