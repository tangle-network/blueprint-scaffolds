"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { StatusBadge } from "@/components/status-badge"
import { CreateRunDialog } from "@/components/create-run-dialog"
import { NodeFlow } from "@/components/node-flow"
import { getMockRuns, type RunSummary, type RunState } from "@/lib/api"
import { RefreshCw, ArrowRight } from "lucide-react"

export default function HomePage() {
  const [runs, setRuns] = useState<RunSummary[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadRuns()
  }, [])

  function loadRuns() {
    setLoading(true)
    setRuns(getMockRuns())
    setLoading(false)
  }

  function handleCreateRun(title: string, description: string) {
    loadRuns()
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Workflow Runs</h2>
          <p className="text-muted-foreground">
            Monitor and manage multi-agent LangGraph workflows.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={loadRuns}>
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh
          </Button>
          <CreateRunDialog onSubmit={handleCreateRun} />
        </div>
      </div>

      {loading ? (
        <div className="grid gap-4">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader>
                <div className="h-5 w-48 rounded bg-muted" />
                <div className="h-4 w-72 rounded bg-muted" />
              </CardHeader>
            </Card>
          ))}
        </div>
      ) : runs.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <p className="text-lg font-medium text-muted-foreground">No workflow runs yet</p>
            <p className="text-sm text-muted-foreground">Create a new run to get started.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {runs.map((run) => (
            <Link key={run.run_id} href={`/runs/${run.run_id}`}>
              <Card className="cursor-pointer transition-shadow hover:shadow-md">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <CardTitle className="text-base">{run.title}</CardTitle>
                      <StatusBadge status={run.status} />
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="font-mono text-xs">
                        {run.run_id}
                      </Badge>
                      <ArrowRight className="h-4 w-4 text-muted-foreground" />
                    </div>
                  </div>
                  <CardDescription>
                    {new Date(run.created_at).toLocaleString()}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <NodeFlow transitions={[]} currentNode={run.current_node} />
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  )
}
