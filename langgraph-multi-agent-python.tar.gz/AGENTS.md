# AGENTS.md

Build a Python LangGraph multi-agent system with planning, execution, review, and human approval steps.

## What's here

This project was scaffolded by starter-foundry. The user's prompt drove the choices below — read their prompt first, it takes priority over everything in this file.

- **Family:** `agent-service-py`
- **Layers:** `framework:agent-service-py`, `capability:agent-langgraph`, `capability:agent-multi-agent`, `database:sqlite`, `sdk:none`, `auth:none`, `payments:none`, `queue:none`

### Architecture notes
- Agent control loop: plan → act → reflect
- Tool registration
- Memory/state management
- HTTP health endpoint
- Define graph nodes as functions that transform GraphState.
- Use conditional edges for branching logic (route to different nodes based on state).
- Enable checkpointing for durable workflows that survive restarts.
- Human-in-the-loop: add interrupt_before on nodes that need approval.

## Getting started

```bash
python3 app.py
```

Key files: `app.py`, `agent.config.json`

## Suggested build plan

These are starting points — adapt them to the user's actual needs.

- **Components:** GraphBuilder, NodeFunction, CheckpointStore
- **Data models:** GraphState, NodeResult, Checkpoint
- **Integrations:** LangGraph, LangChain, Checkpointing (SQLite/Postgres)

## How to use this scaffold

This is a starting point, not a contract. You own every file.

- **Customize freely.** Replace components, change the layout, swap the color scheme — whatever fits the user's product.
- **The scaffold saves you setup time** — Tailwind, shadcn/ui, path aliases, and framework config are ready. Don't redo them.
- **Check `.starter-foundry/compose-report.json`** if you want to see which layer wrote which file.
- **Update this file** as the project evolves. Delete sections that no longer apply.
