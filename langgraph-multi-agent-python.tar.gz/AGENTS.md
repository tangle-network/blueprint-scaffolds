# AGENTS.md

## Goal

Build a Python LangGraph multi-agent system with planning, execution, review, and human approval steps.

## Stack

- Family: `agent-service-py`
- Layers: `capability:agent-langgraph`, `capability:agent-multi-agent`, `database:sqlite`, `sdk:none`, `auth:none`, `payments:none`, `queue:none`

## Architecture

- Agent control loop: plan → act → reflect
- Tool registration
- Memory/state management
- HTTP health endpoint
- Define graph nodes as functions that transform GraphState.
- Use conditional edges for branching logic (route to different nodes based on state).
- Enable checkpointing for durable workflows that survive restarts.
- Human-in-the-loop: add interrupt_before on nodes that need approval.

## Entry Points

- `app.py`
- `agent.config.json`

## Commands

- `python3 app.py`

## Build Plan

Components: GraphBuilder, NodeFunction, CheckpointStore
Data models: GraphState, NodeResult, Checkpoint
Integrations: LangGraph, LangChain, Checkpointing (SQLite/Postgres)

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
