import { ExecutionFlow } from "./components/ExecutionFlow";
import { Hero } from "./components/Hero";
import { MetricGrid } from "./components/MetricGrid";
import { OperatorGrid } from "./components/OperatorGrid";
import { TaskTable } from "./components/TaskTable";
import { executionPhases, metrics, operators, rustModules, tasks } from "./data/network";

export default function App() {
  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand-lockup">
          <span className="brand-mark" />
          <div>
            <p className="brand-title">Keeper Network AVS</p>
            <p className="brand-subtitle">Reliable DeFi automation on EigenLayer</p>
          </div>
        </div>
        <nav className="nav-links">
          <a href="#tasks">Tasks</a>
          <a href="#operators">Operators</a>
          <a href="#architecture">Architecture</a>
        </nav>
      </header>

      <main>
        <Hero activeTasks={tasks.length} operatorCount={operators.length} />
        <MetricGrid metrics={metrics} />
        <TaskTable tasks={tasks} />
        <OperatorGrid operators={operators} />
        <div id="architecture">
          <ExecutionFlow phases={executionPhases} rustModules={rustModules} />
        </div>
      </main>
    </div>
  );
}
