export type TaskType = "liquidation" | "rebalancing" | "yield_harvesting" | "order_execution";

export type TaskStatus =
  | "pending"
  | "assigned"
  | "executing"
  | "completed"
  | "failed"
  | "fallback_triggered";

export type Protocol = "aave" | "compound" | "vault";

export type SLATier = "critical" | "high" | "medium" | "low";

export interface KeeperTask {
  id: string;
  type: TaskType;
  status: TaskStatus;
  protocol: Protocol;
  targetAddress: string;
  createdBy: string;
  createdAt: number;
  executedAt?: number;
  completedAt?: number;
  gasUsed?: bigint;
  gasCostUsd?: number;
  reward?: number;
  assignedOperator: string;
  fallbackOperator?: string;
  slaTier: SLATier;
  slaDeadline: number;
  params: TaskParams;
  retries: number;
  maxRetries: number;
  txHash?: string;
}

export interface TaskParams {
  tokenAddress?: string;
  amount?: string;
  healthFactor?: number;
  threshold?: number;
  slippageBps?: number;
  vaultId?: string;
  orderId?: string;
  destToken?: string;
}

export interface Operator {
  id: string;
  address: string;
  stakeWeightedScore: number;
  totalStake: bigint;
  activeStake: bigint;
  tasksCompleted: number;
  tasksFailed: number;
  successRate: number;
  avgExecutionTimeMs: number;
  uptime: number;
  registeredAt: number;
  lastActiveAt: number;
  slaScore: number;
  gasEfficiency: number;
  delegatedStake: bigint;
  supportedProtocols: Protocol[];
  supportedTaskTypes: TaskType[];
  status: "active" | "inactive" | "slashed" | "deregistered";
  currentLoad: number;
  maxConcurrentTasks: number;
}

export interface SLACommitment {
  id: string;
  operatorId: string;
  taskType: TaskType;
  tier: SLATier;
  maxExecutionTimeMs: number;
  maxGasCost: number;
  uptimeRequirement: number;
  penaltyBps: number;
  rewardBps: number;
}

export interface GasCoverage {
  baseGasLimit: bigint;
  priorityFeeGwei: number;
  maxFeeGwei: number;
  coveragePercent: number;
  estimatedCostUsd: number;
  actualCostUsd?: number;
  reimbursed?: boolean;
}

export interface FallbackExecution {
  taskId: string;
  primaryOperator: string;
  fallbackOperator: string;
  triggeredAt: number;
  reason: "timeout" | "failure" | "gas_exceeded" | "operator_offline";
  fallbackCompletedAt?: number;
  fallbackTxHash?: string;
}

export interface ProtocolHealth {
  protocol: Protocol;
  status: "healthy" | "degraded" | "down";
  latencyMs: number;
  pendingTasks: number;
  lastCheckedAt: number;
  gasPriceGwei: number;
}

export interface NetworkStats {
  totalOperators: number;
  activeOperators: number;
  totalStake: bigint;
  tasksLast24h: number;
  successRate: number;
  avgGasCost: number;
  slaCompliance: number;
  totalRewardsDistributed: number;
}
