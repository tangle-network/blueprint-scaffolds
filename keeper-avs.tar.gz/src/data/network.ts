export type TaskType = "Liquidations" | "Rebalancing" | "Yield Harvesting" | "Order Execution";

export type TaskRecord = {
  id: string;
  type: TaskType;
  protocol: string;
  target: string;
  cadence: string;
  stakeWeight: number;
  gasCoverage: string;
  sla: string;
  redundancy: string;
  fallback: string;
  status: "Ready" | "Queued" | "Failing Over";
};

export type OperatorRecord = {
  id: string;
  name: string;
  region: string;
  stake: string;
  uptime: string;
  automationFocus: string;
  slashedRisk: string;
  fillRate: string;
};

export type MetricRecord = {
  label: string;
  value: string;
  detail: string;
};

export const metrics: MetricRecord[] = [
  {
    label: "Secured TVL",
    value: "$2.4B",
    detail: "Automation coverage spanning lending markets, vaults, and execution relays.",
  },
  {
    label: "Median Response",
    value: "4.2s",
    detail: "Stake-weighted keeper routing with redundant executors per critical task.",
  },
  {
    label: "Gas Reserve",
    value: "18,400 gwei",
    detail: "Pre-funded execution buffers covering congestion spikes and retries.",
  },
  {
    label: "SLA Backing",
    value: "99.95%",
    detail: "Operator commitments enforced via AVS performance scoring and fallback routing.",
  },
];

export const tasks: TaskRecord[] = [
  {
    id: "TASK-041",
    type: "Liquidations",
    protocol: "Aave v3",
    target: "ETH / stablecoin health factor band",
    cadence: "Event-driven",
    stakeWeight: 42,
    gasCoverage: "120% reserve on L1 and L2",
    sla: "< 6s breach response",
    redundancy: "3 operators hot-standby",
    fallback: "Escalates to threshold-signed relay",
    status: "Ready",
  },
  {
    id: "TASK-073",
    type: "Rebalancing",
    protocol: "Compound III",
    target: "USDC utilization guardrails",
    cadence: "5 minute windows",
    stakeWeight: 27,
    gasCoverage: "Dynamic gas rebate bucket",
    sla: "< 30s rebalance completion",
    redundancy: "2 active + 1 shadow",
    fallback: "Routes to off-chain simulation queue",
    status: "Queued",
  },
  {
    id: "TASK-118",
    type: "Yield Harvesting",
    protocol: "Vault Aggregator",
    target: "Delta-neutral basis vault",
    cadence: "Profit threshold 35 bps",
    stakeWeight: 18,
    gasCoverage: "Harvest reserve linked to vault fees",
    sla: "2 missed windows per quarter max",
    redundancy: "Dual region operator pair",
    fallback: "Vault guardian can force harvest",
    status: "Ready",
  },
  {
    id: "TASK-145",
    type: "Order Execution",
    protocol: "RFQ + TWAP Router",
    target: "Treasury hedge rollovers",
    cadence: "Time-weighted slices",
    stakeWeight: 13,
    gasCoverage: "MEV-aware execution budget",
    sla: "< 15 bps slippage envelope",
    redundancy: "Primary / backup route split",
    fallback: "Circuit breaker pauses stale quotes",
    status: "Failing Over",
  },
];

export const operators: OperatorRecord[] = [
  {
    id: "OP-12",
    name: "Atlas Keepers",
    region: "Virginia / Frankfurt",
    stake: "58.4k ETH delegated",
    uptime: "99.98%",
    automationFocus: "Aave liquidations and emergency unwind flows",
    slashedRisk: "Low",
    fillRate: "97.6%",
  },
  {
    id: "OP-19",
    name: "Northstar Ops",
    region: "Oregon / Tokyo",
    stake: "44.1k ETH delegated",
    uptime: "99.93%",
    automationFocus: "Compound rebalancing and gas-aware routing",
    slashedRisk: "Low",
    fillRate: "95.4%",
  },
  {
    id: "OP-27",
    name: "Harbor Automation",
    region: "Dublin / Singapore",
    stake: "31.7k ETH delegated",
    uptime: "99.88%",
    automationFocus: "Vault harvesting and cross-chain settlement",
    slashedRisk: "Medium",
    fillRate: "93.8%",
  },
];

export const executionPhases = [
  {
    title: "Signal Detection",
    description: "Watchers index protocol events, oracle deltas, and vault thresholds to create signed task intents.",
  },
  {
    title: "Stake-Weighted Assignment",
    description: "The AVS scheduler ranks operators by delegated stake, live SLA score, and recent execution latency.",
  },
  {
    title: "Redundant Execution",
    description: "Primary and secondary keepers race against bounded windows with replay protection and nonce fencing.",
  },
  {
    title: "Fallback Settlement",
    description: "If task delivery degrades, the network escalates to circuit-breaker relays and protocol guardians.",
  },
];

export const rustModules = [
  {
    file: "scheduler.rs",
    role: "Computes task assignment with stake-weighted scoring, gas budgets, and SLA penalties.",
  },
  {
    file: "executor.rs",
    role: "Runs signed call bundles against Aave, Compound, and vault adapters with retry guards.",
  },
  {
    file: "fallback.rs",
    role: "Promotes standby operators, enforces duplicate suppression, and triggers guardian routes.",
  },
];
