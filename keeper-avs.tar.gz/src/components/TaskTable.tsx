import type { TaskRecord } from "../data/network";

type TaskTableProps = {
  tasks: TaskRecord[];
};

export function TaskTable({ tasks }: TaskTableProps) {
  return (
    <section id="tasks" className="panel section-block">
      <div className="section-heading">
        <div>
          <p className="eyebrow">Task Explorer</p>
          <h2>Automation queues across lending and vault strategies</h2>
        </div>
        <p className="section-copy">
          Each task defines stake-weighted routing, gas reserve policy, SLA thresholds, and a fallback plan.
        </p>
      </div>
      <div className="task-table">
        {tasks.map((task) => (
          <article className="task-row" key={task.id}>
            <div className="task-header">
              <div>
                <p className="task-id">{task.id}</p>
                <h3>{task.type}</h3>
              </div>
              <span className={`status-pill status-${task.status.toLowerCase().replace(/\s+/g, "-")}`}>
                {task.status}
              </span>
            </div>
            <dl>
              <div>
                <dt>Protocol</dt>
                <dd>{task.protocol}</dd>
              </div>
              <div>
                <dt>Target</dt>
                <dd>{task.target}</dd>
              </div>
              <div>
                <dt>Cadence</dt>
                <dd>{task.cadence}</dd>
              </div>
              <div>
                <dt>Stake Weight</dt>
                <dd>{task.stakeWeight}%</dd>
              </div>
              <div>
                <dt>Gas Coverage</dt>
                <dd>{task.gasCoverage}</dd>
              </div>
              <div>
                <dt>SLA</dt>
                <dd>{task.sla}</dd>
              </div>
              <div>
                <dt>Redundancy</dt>
                <dd>{task.redundancy}</dd>
              </div>
              <div>
                <dt>Fallback</dt>
                <dd>{task.fallback}</dd>
              </div>
            </dl>
          </article>
        ))}
      </div>
    </section>
  );
}
