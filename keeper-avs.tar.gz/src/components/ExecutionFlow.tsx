type ExecutionFlowProps = {
  phases: Array<{
    title: string;
    description: string;
  }>;
  rustModules: Array<{
    file: string;
    role: string;
  }>;
};

export function ExecutionFlow({ phases, rustModules }: ExecutionFlowProps) {
  return (
    <section className="flow-layout">
      <article className="panel section-block">
        <div className="section-heading">
          <div>
            <p className="eyebrow">Execution Engine</p>
            <h2>Rust operator software for deterministic task handling</h2>
          </div>
          <p className="section-copy">
            The operator stack keeps assignment, execution, and failover isolated so duplicate actions do not leak
            into DeFi positions.
          </p>
        </div>
        <div className="timeline">
          {phases.map((phase, index) => (
            <div className="timeline-step" key={phase.title}>
              <span className="timeline-index">0{index + 1}</span>
              <div>
                <h3>{phase.title}</h3>
                <p>{phase.description}</p>
              </div>
            </div>
          ))}
        </div>
      </article>
      <article className="panel code-panel">
        <p className="eyebrow">Rust Modules</p>
        <div className="code-list">
          {rustModules.map((module) => (
            <div className="code-item" key={module.file}>
              <code>{module.file}</code>
              <p>{module.role}</p>
            </div>
          ))}
        </div>
      </article>
    </section>
  );
}
