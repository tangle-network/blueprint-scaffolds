import type { OperatorRecord } from "../data/network";

type OperatorGridProps = {
  operators: OperatorRecord[];
};

export function OperatorGrid({ operators }: OperatorGridProps) {
  return (
    <section id="operators" className="section-split">
      <div className="panel section-block">
        <div className="section-heading">
          <div>
            <p className="eyebrow">Operator Stats</p>
            <h2>Restaked operators ranked for execution reliability</h2>
          </div>
        </div>
        <div className="operator-grid">
          {operators.map((operator) => (
            <article className="operator-card" key={operator.id}>
              <div className="operator-topline">
                <div>
                  <p className="task-id">{operator.id}</p>
                  <h3>{operator.name}</h3>
                </div>
                <span className="risk-chip">{operator.slashedRisk} risk</span>
              </div>
              <p className="operator-focus">{operator.automationFocus}</p>
              <dl>
                <div>
                  <dt>Region</dt>
                  <dd>{operator.region}</dd>
                </div>
                <div>
                  <dt>Delegated stake</dt>
                  <dd>{operator.stake}</dd>
                </div>
                <div>
                  <dt>Uptime</dt>
                  <dd>{operator.uptime}</dd>
                </div>
                <div>
                  <dt>Fill rate</dt>
                  <dd>{operator.fillRate}</dd>
                </div>
              </dl>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
