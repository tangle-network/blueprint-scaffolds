import type { MetricRecord } from "../data/network";

type MetricGridProps = {
  metrics: MetricRecord[];
};

export function MetricGrid({ metrics }: MetricGridProps) {
  return (
    <section className="metric-grid">
      {metrics.map((metric) => (
        <article className="metric-card panel" key={metric.label}>
          <p className="metric-label">{metric.label}</p>
          <strong className="metric-value">{metric.value}</strong>
          <p className="metric-detail">{metric.detail}</p>
        </article>
      ))}
    </section>
  );
}
