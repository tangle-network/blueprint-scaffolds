type HeroProps = {
  activeTasks: number;
  operatorCount: number;
};

export function Hero({ activeTasks, operatorCount }: HeroProps) {
  return (
    <section className="hero panel">
      <div className="hero-copy">
        <p className="eyebrow">EigenLayer AVS</p>
        <h1>Keeper Network for reliable DeFi automation.</h1>
        <p className="hero-text">
          Stake-backed operators execute liquidations, rebalancing, harvesting, and order flow with gas coverage,
          SLA commitments, and fallback execution paths.
        </p>
        <div className="hero-actions">
          <a href="#tasks" className="button button-primary">
            Explore task flow
          </a>
          <a href="#operators" className="button button-secondary">
            Review operators
          </a>
        </div>
      </div>
      <div className="hero-card">
        <div className="stat-ribbon">
          <span>Live tasks</span>
          <strong>{activeTasks}</strong>
        </div>
        <div className="stat-ribbon">
          <span>Operators</span>
          <strong>{operatorCount}</strong>
        </div>
        <div className="stat-ribbon">
          <span>Protocols</span>
          <strong>3 integrated</strong>
        </div>
      </div>
    </section>
  );
}
