import {
  PaymentRequirements,
  PaymentAuthorization,
  PaymentResponse,
  TransactionRecord,
  USDC_BASE,
} from "./types.js";
import { WalletManager } from "./wallet.js";
import { SpendingLimits } from "./limits.js";
import { TransactionStore } from "./store.js";

const MAX_RETRIES = 3;
const RETRY_DELAY_MS = 1000;

export interface PaymentHandlerResult {
  success: boolean;
  status: number;
  data?: unknown;
  transaction?: TransactionRecord;
  error?: string;
  paymentRequired?: PaymentRequirements;
}

function parsePaymentRequirements(response: Response): PaymentRequirements | null {
  const wwwAuth = response.headers.get("WWW-Authenticate");
  if (!wwwAuth) return null;

  try {
    if (wwwAuth.startsWith("x402 ")) {
      const jsonStr = wwwAuth.slice(5);
      return JSON.parse(jsonStr) as PaymentRequirements;
    }

    const xPayment = response.headers.get("X-Payment-Requirements");
    if (xPayment) {
      return JSON.parse(xPayment) as PaymentRequirements;
    }
  } catch {
    return null;
  }

  return null;
}

async function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export class X402PaymentHandler {
  private wallet: WalletManager;
  private limits: SpendingLimits;
  private store: TransactionStore;
  private rateLimitMap: Map<string, number[]> = new Map();
  private maxRequestsPerMinute: number;

  constructor(
    wallet: WalletManager,
    limits: SpendingLimits,
    store: TransactionStore,
    maxRequestsPerMinute = 30,
  ) {
    this.wallet = wallet;
    this.limits = limits;
    this.store = store;
    this.maxRequestsPerMinute = maxRequestsPerMinute;
  }

  private checkRateLimit(url: string): boolean {
    const now = Date.now();
    const windowMs = 60_000;
    const timestamps = this.rateLimitMap.get(url) || [];
    const recent = timestamps.filter((t) => now - t < windowMs);
    this.rateLimitMap.set(url, recent);

    if (recent.length >= this.maxRequestsPerMinute) {
      return false;
    }
    recent.push(now);
    return true;
  }

  async fetchWithPayment(
    url: string,
    options: RequestInit = {},
    skipPayment = false,
  ): Promise<PaymentHandlerResult> {
    if (!this.checkRateLimit(url)) {
      return {
        success: false,
        status: 429,
        error: "Rate limit exceeded for this endpoint. Try again later.",
      };
    }

    try {
      const response = await fetch(url, {
        ...options,
        headers: {
          ...(options.headers || {}),
        },
      });

      if (response.status === 402 && !skipPayment) {
        return this.handle402Response(url, options, response);
      }

      if (response.ok) {
        const data = await this.parseResponseBody(response);
        return {
          success: true,
          status: response.status,
          data,
        };
      }

      return {
        success: false,
        status: response.status,
        error: `HTTP ${response.status}: ${response.statusText}`,
      };
    } catch (err) {
      return {
        success: false,
        status: 0,
        error: err instanceof Error ? err.message : "Unknown network error",
      };
    }
  }

  private async handle402Response(
    url: string,
    options: RequestInit,
    originalResponse: Response,
  ): Promise<PaymentHandlerResult> {
    const requirements = parsePaymentRequirements(originalResponse);
    if (!requirements) {
      const body = await this.parseResponseBody(originalResponse);
      return {
        success: false,
        status: 402,
        error: "402 Payment Required but no payment requirements found in response headers",
        data: body,
      };
    }

    const limitCheck = this.limits.checkAll(requirements);
    if (!limitCheck.allowed) {
      return {
        success: false,
        status: 402,
        error: `Payment blocked by spending limits: ${limitCheck.reasons.join("; ")}`,
        paymentRequired: requirements,
      };
    }

    console.log(
      `[x402] Payment required: $${requirements.amount} USDC to ${requirements.recipient.slice(0, 10)}...`,
    );

    let lastError: string | undefined;
    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
      try {
        const authorization = await this.wallet.createPaymentAuthorization(requirements);

        const record = this.store.add(
          url,
          (options.method || "GET").toUpperCase(),
          requirements.amount,
          requirements.token || USDC_BASE,
          requirements.recipient,
          authorization,
        );

        console.log(`[x402] Transaction ${record.id}: paying $${requirements.amount} (attempt ${attempt})`);

        const paymentHeader = this.encodePaymentHeader(authorization);

        const retryResponse = await fetch(url, {
          ...options,
          headers: {
            ...(options.headers || {}),
            "X-PAYMENT": paymentHeader,
          },
        });

        if (retryResponse.ok) {
          const data = await this.parseResponseBody(retryResponse);
          this.store.updateStatus(record.id, "confirmed", undefined, retryResponse.status);
          console.log(`[x402] Transaction ${record.id}: confirmed`);

          return {
            success: true,
            status: retryResponse.status,
            data,
            transaction: this.store.get(record.id),
          };
        }

        if (retryResponse.status === 402) {
          lastError = "Payment was rejected by the server after retry";
          this.store.updateStatus(record.id, "failed", undefined, retryResponse.status);
          if (attempt < MAX_RETRIES) {
            await delay(RETRY_DELAY_MS * attempt);
            continue;
          }
        } else {
          lastError = `Server returned ${retryResponse.status} after payment`;
          this.store.updateStatus(record.id, "failed", undefined, retryResponse.status);
          break;
        }
      } catch (err) {
        lastError = err instanceof Error ? err.message : "Payment signing failed";
        if (attempt < MAX_RETRIES) {
          await delay(RETRY_DELAY_MS * attempt);
        }
      }
    }

    return {
      success: false,
      status: 402,
      error: lastError || "Payment failed after retries",
    };
  }

  private encodePaymentHeader(auth: PaymentAuthorization): string {
    const payload = {
      signature: auth.signature,
      amount: auth.amount,
      recipient: auth.recipient,
      token: auth.token,
      nonce: auth.nonce,
      timestamp: auth.timestamp,
      wallet: auth.walletAddress,
    };
    return Buffer.from(JSON.stringify(payload)).toString("base64");
  }

  private async parseResponseBody(response: Response): Promise<unknown> {
    const contentType = response.headers.get("content-type") || "";
    if (contentType.includes("application/json")) {
      try {
        return await response.json();
      } catch {
        return null;
      }
    }
    try {
      return await response.text();
    } catch {
      return null;
    }
  }

  getTransactionStore(): TransactionStore {
    return this.store;
  }

  getSpendingLimits(): SpendingLimits {
    return this.limits;
  }

  getWallet(): WalletManager {
    return this.wallet;
  }
}
