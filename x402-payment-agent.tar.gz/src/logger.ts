import fs from "fs";
import path from "path";
import type { TransactionRecord } from "./types.js";

const LOG_DIR = path.join(process.cwd(), "logs");
const LOG_FILE = path.join(LOG_DIR, "transactions.json");

export class TransactionLogger {
  private records: TransactionRecord[] = [];
  private flushTimer: ReturnType<typeof setTimeout> | null = null;

  constructor() {
    this.load();
  }

  private load() {
    try {
      if (fs.existsSync(LOG_FILE)) {
        const data = fs.readFileSync(LOG_FILE, "utf-8");
        this.records = JSON.parse(data);
      }
    } catch {
      this.records = [];
    }
  }

  private flush() {
    try {
      if (!fs.existsSync(LOG_DIR)) {
        fs.mkdirSync(LOG_DIR, { recursive: true });
      }
      fs.writeFileSync(LOG_FILE, JSON.stringify(this.records, null, 2));
    } catch (err) {
      console.error("Failed to flush transaction log:", err);
    }
  }

  private scheduleFlush() {
    if (this.flushTimer) clearTimeout(this.flushTimer);
    this.flushTimer = setTimeout(() => this.flush(), 500);
  }

  add(record: Omit<TransactionRecord, "id" | "timestamp">): TransactionRecord {
    const entry: TransactionRecord = {
      ...record,
      id: `tx_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
      timestamp: Date.now(),
    };
    this.records.push(entry);
    this.scheduleFlush();
    return entry;
  }

  updateStatus(id: string, status: TransactionRecord["status"], error?: string, txHash?: string) {
    const record = this.records.find((r) => r.id === id);
    if (record) {
      record.status = status;
      if (error) record.error = error;
      if (txHash) record.txHash = txHash;
      this.scheduleFlush();
    }
  }

  getRecords(limit?: number): TransactionRecord[] {
    const sorted = [...this.records].sort((a, b) => b.timestamp - a.timestamp);
    return limit ? sorted.slice(0, limit) : sorted;
  }

  getDailyTotal(): number {
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);
    const dayStart = startOfDay.getTime();

    return this.records
      .filter((r) => r.timestamp >= dayStart && r.status === "confirmed")
      .reduce((sum, r) => sum + Number(r.amount) / 1e6, 0);
  }

  getWeeklyTotal(): number {
    const now = Date.now();
    const weekStart = now - 7 * 24 * 60 * 60 * 1000;

    return this.records
      .filter((r) => r.timestamp >= weekStart && r.status === "confirmed")
      .reduce((sum, r) => sum + Number(r.amount) / 1e6, 0);
  }

  getSpendingSummary(): {
    dailyTotal: number;
    weeklyTotal: number;
    totalTransactions: number;
    confirmedTransactions: number;
    failedTransactions: number;
  } {
    return {
      dailyTotal: this.getDailyTotal(),
      weeklyTotal: this.getWeeklyTotal(),
      totalTransactions: this.records.length,
      confirmedTransactions: this.records.filter((r) => r.status === "confirmed").length,
      failedTransactions: this.records.filter((r) => r.status === "failed").length,
    };
  }
}
