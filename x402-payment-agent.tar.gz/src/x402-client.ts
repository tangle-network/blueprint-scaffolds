import type { PaymentRequirements } from "./types.js";

interface Parsed402Response {
  statusCode: number;
  paymentRequirements: PaymentRequirements;
  accepts: string;
  rawHeaders: Record<string, string>;
}

export function parse402Response(response: Response): Parsed402Response | null {
  if (response.status !== 402) {
    return null;
  }

  const paymentHeader = response.headers.get("X-Payment-Requirements")
    || response.headers.get("x-payment-requirements");

  if (!paymentHeader) {
    const WwwAuthenticate = response.headers.get("WWW-Authenticate")
      || response.headers.get("www-authenticate");
    if (WwwAuthenticate?.startsWith("x402")) {
      const encoded = WwwAuthenticate.replace("x402 ", "");
      try {
        const decoded = JSON.parse(Buffer.from(encoded, "base64").toString("utf-8"));
        return {
          statusCode: 402,
          paymentRequirements: normalizePaymentRequirements(decoded),
          accepts: response.headers.get("Accept") || "application/json",
          rawHeaders: Object.fromEntries(response.headers.entries()),
        };
      } catch {
        return null;
      }
    }
    return null;
  }

  try {
    const decoded = JSON.parse(Buffer.from(paymentHeader, "base64").toString("utf-8"));
    return {
      statusCode: 402,
      paymentRequirements: normalizePaymentRequirements(decoded),
      accepts: response.headers.get("Accept") || "application/json",
      rawHeaders: Object.fromEntries(response.headers.entries()),
    };
  } catch {
    const tryDirect = JSON.parse(paymentHeader);
    return {
      statusCode: 402,
      paymentRequirements: normalizePaymentRequirements(tryDirect),
      accepts: response.headers.get("Accept") || "application/json",
      rawHeaders: Object.fromEntries(response.headers.entries()),
    };
  }
}

function normalizePaymentRequirements(raw: Record<string, unknown>): PaymentRequirements {
  return {
    version: (raw.version as number) || 1,
    recipient: (raw.recipient ?? raw.payTo ?? raw.pay_to) as `0x${string}`,
    amount: String(raw.amount ?? raw.maxAmountRequired ?? raw.max_amount_required ?? "0"),
    token: (raw.token ?? raw.tokenAddress ?? raw.token_address ?? "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913") as `0x${string}`,
    tokenName: (raw.tokenName ?? raw.token_name ?? "USDC") as string,
    network: (raw.network ?? "base-mainnet") as string,
    resource: (raw.resource ?? "") as string,
    description: raw.description as string | undefined,
    expiresAt: raw.expiresAt as number | undefined,
    payTo: (raw.payTo ?? raw.pay_to) as `0x${string}` | undefined,
    usdAmountMax: (raw.usdAmountMax ?? raw.usd_amount_max) as string | undefined,
  };
}

export function buildPaymentHeader(paymentPayload: {
  signature: `0x${string}`;
  authorization: string;
  payload: Record<string, unknown>;
}): string {
  const encoded = Buffer.from(JSON.stringify(paymentPayload)).toString("base64");
  return encoded;
}
