import { createPublicClient, http } from "viem";
import { base } from "viem/chains";
import type { AppConfig } from "../config.js";

export class OnchainVerifier {
  private readonly client;

  constructor(config: AppConfig) {
    this.client = createPublicClient({
      chain: base,
      transport: http(config.baseRpcUrl),
    });
  }

  async verify(transactionHash?: string, network?: string): Promise<boolean> {
    if (!transactionHash || !transactionHash.startsWith("0x")) {
      return false;
    }

    if (network !== "eip155:8453") {
      return false;
    }

    try {
      const receipt = await this.client.getTransactionReceipt({
        hash: transactionHash as `0x${string}`,
      });
      return receipt.status === "success";
    } catch {
      return false;
    }
  }
}
