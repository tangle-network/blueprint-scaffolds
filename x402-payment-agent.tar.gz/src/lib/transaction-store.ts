import { mkdir, readFile, appendFile } from "node:fs/promises";
import { dirname, isAbsolute, join } from "node:path";
import type { TransactionRecord } from "../types.js";

export class TransactionStore {
  private readonly absolutePath: string;

  constructor(logPath: string, baseDir: string = process.cwd()) {
    this.absolutePath = isAbsolute(logPath) ? logPath : join(baseDir, logPath);
  }

  async list(): Promise<TransactionRecord[]> {
    try {
      const raw = await readFile(this.absolutePath, "utf8");
      return raw
        .split("\n")
        .filter(Boolean)
        .map((line) => JSON.parse(line) as TransactionRecord);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") {
        return [];
      }

      throw error;
    }
  }

  async append(record: TransactionRecord): Promise<void> {
    await mkdir(dirname(this.absolutePath), { recursive: true });
    await appendFile(this.absolutePath, `${JSON.stringify(record)}\n`, "utf8");
  }
}
