import type { AppConfig } from "../config.js";
import type {
  Notification,
  PaymentDecision,
  SpendingSnapshot,
  TransactionRecord,
} from "../types.js";

function startOfDay(now: Date): number {
  return new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
}

function startOfRollingWindow(days: number, now: Date): number {
  return now.getTime() - days * 24 * 60 * 60 * 1000;
}

export class SpendingControls {
  private readonly paymentTimestamps: number[] = [];

  constructor(private readonly config: AppConfig) {}

  getSnapshot(records: TransactionRecord[], now: Date = new Date()): SpendingSnapshot {
    const dayFloor = startOfDay(now);
    const weekFloor = startOfRollingWindow(7, now);

    let dailySpentUsd = 0;
    let weeklySpentUsd = 0;

    for (const record of records) {
      const createdAt = new Date(record.createdAt).getTime();
      if (createdAt >= dayFloor) {
        dailySpentUsd += record.amountUsd;
      }
      if (createdAt >= weekFloor) {
        weeklySpentUsd += record.amountUsd;
      }
    }

    return {
      dailySpentUsd,
      weeklySpentUsd,
      dailyLimitUsd: this.config.dailySpendLimitUsd,
      weeklyLimitUsd: this.config.weeklySpendLimitUsd,
      remainingDailyUsd: Math.max(this.config.dailySpendLimitUsd - dailySpentUsd, 0),
      remainingWeeklyUsd: Math.max(this.config.weeklySpendLimitUsd - weeklySpentUsd, 0),
    };
  }

  evaluatePayment(input: {
    amountUsd: number;
    recipient: string;
    priorRecords: TransactionRecord[];
    notifications: Notification[];
  }): PaymentDecision {
    const notifications = [...input.notifications];
    const recipient = input.recipient.toLowerCase();
    const snapshot = this.getSnapshot(input.priorRecords);

    if (input.amountUsd > this.config.maxPaymentUsd) {
      return {
        approved: false,
        reason: `Payment exceeds MAX_PAYMENT_USD (${this.config.maxPaymentUsd}).`,
        notifications,
      };
    }

    if (
      this.config.payeeWhitelist.size > 0 &&
      !this.config.payeeWhitelist.has(recipient)
    ) {
      return {
        approved: false,
        reason: `Recipient ${input.recipient} is not on the whitelist.`,
        notifications,
      };
    }

    if (snapshot.dailySpentUsd + input.amountUsd > this.config.dailySpendLimitUsd) {
      return {
        approved: false,
        reason: "Daily spending limit would be exceeded.",
        notifications,
      };
    }

    if (snapshot.weeklySpentUsd + input.amountUsd > this.config.weeklySpendLimitUsd) {
      return {
        approved: false,
        reason: "Weekly spending limit would be exceeded.",
        notifications,
      };
    }

    const minuteAgo = Date.now() - 60_000;
    while (this.paymentTimestamps.length > 0 && this.paymentTimestamps[0] < minuteAgo) {
      this.paymentTimestamps.shift();
    }

    if (this.paymentTimestamps.length >= this.config.paymentRateLimitPerMinute) {
      return {
        approved: false,
        reason: "Payment rate limit exceeded for the last minute.",
        notifications,
      };
    }

    if (input.amountUsd >= this.config.expensiveOperationUsd) {
      notifications.push({
        level: "warning",
        message: `Upcoming payment of $${input.amountUsd.toFixed(2)} exceeds the notification threshold.`,
        createdAt: new Date().toISOString(),
      });

      if (!this.config.autoApproveExpensive) {
        return {
          approved: false,
          approvalRequired: true,
          reason: "Manual approval required for expensive operation.",
          notifications,
        };
      }
    }

    return {
      approved: true,
      notifications,
    };
  }

  recordApprovedPayment(): void {
    this.paymentTimestamps.push(Date.now());
  }
}
