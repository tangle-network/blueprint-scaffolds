import { createAnthropic } from "@ai-sdk/anthropic";
import { createOpenAI } from "@ai-sdk/openai";
import type { LanguageModel } from "ai";
import type { AppConfig } from "../config.js";

export function createLanguageModel(config: AppConfig): LanguageModel {
  if (config.aiProvider === "openai") {
    if (!config.openAIApiKey) {
      throw new Error("OPENAI_API_KEY is missing.");
    }

    return createOpenAI({
      apiKey: config.openAIApiKey,
    })(config.aiModel);
  }

  if (!config.anthropicApiKey) {
    throw new Error("ANTHROPIC_API_KEY is missing.");
  }

  return createAnthropic({
    apiKey: config.anthropicApiKey,
  })(config.aiModel);
}
