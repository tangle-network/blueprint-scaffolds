import { randomUUID } from "node:crypto";
import { decodePaymentResponseHeader, wrapFetchWithPaymentFromConfig } from "@x402/fetch";
import { ExactEvmScheme } from "@x402/evm";
import { privateKeyToAccount } from "viem/accounts";
import type { PaymentRequired } from "@x402/fetch";
import type { AppConfig } from "../config.js";
import type {
  Notification,
  PremiumRequestInput,
  PremiumRequestResult,
  TransactionRecord,
} from "../types.js";
import { OnchainVerifier } from "./onchain.js";
import { SpendingControls } from "./spending-controls.js";
import { TransactionStore } from "./transaction-store.js";

function toUsdAmount(amountAtomic: string, decimals: number): number {
  return Number(amountAtomic) / 10 ** decimals;
}

function decodePaymentRequiredHeader(header: string): PaymentRequired {
  return JSON.parse(Buffer.from(header, "base64").toString("utf8")) as PaymentRequired;
}

function previewBody(body: string): string {
  return body.length > 400 ? `${body.slice(0, 397)}...` : body;
}

export class PremiumHttpClient {
  private readonly paymentFetch;
  private readonly verifier;

  constructor(
    private readonly config: AppConfig,
    private readonly store: TransactionStore,
    private readonly controls: SpendingControls,
  ) {
    const account = config.walletPrivateKey
      ? privateKeyToAccount(config.walletPrivateKey)
      : null;

    this.paymentFetch = account
      ? wrapFetchWithPaymentFromConfig(fetch, {
          schemes: [
            {
              network: "eip155:8453",
              client: new ExactEvmScheme(account, {
                rpcUrl: config.baseRpcUrl,
              }),
            },
          ],
        })
      : null;
    this.verifier = new OnchainVerifier(config);
  }

  async fetchPremiumResource(
    input: PremiumRequestInput,
    task?: string,
  ): Promise<PremiumRequestResult> {
    if (!this.paymentFetch) {
      throw new Error("Wallet is not configured. Set WALLET_PRIVATE_KEY.");
    }

    const notifications: Notification[] = [];
    const initialResponse = await fetch(input.url, {
      method: input.method ?? "GET",
      headers: input.headers,
      body: input.body,
    });

    if (initialResponse.status !== 402) {
      const body = await initialResponse.text();
      return {
        ok: initialResponse.ok,
        status: initialResponse.status,
        statusText: initialResponse.statusText,
        body,
        contentType: initialResponse.headers.get("content-type"),
        notifications,
      };
    }

    const paymentRequiredHeader = initialResponse.headers.get("payment-required");
    if (!paymentRequiredHeader) {
      throw new Error("402 response missing PAYMENT-REQUIRED header.");
    }

    const paymentRequired = decodePaymentRequiredHeader(paymentRequiredHeader);
    const selectedRequirement = this.selectRequirement(paymentRequired);
    const amountUsd = toUsdAmount(selectedRequirement.amount, this.config.usdcDecimals);
    const priorRecords = await this.store.list();
    const decision = this.controls.evaluatePayment({
      amountUsd,
      recipient: selectedRequirement.payTo,
      priorRecords,
      notifications,
    });

    notifications.push(...decision.notifications);
    if (!decision.approved) {
      return {
        ok: false,
        status: 402,
        statusText: decision.approvalRequired ? "Approval Required" : "Payment Rejected",
        body: decision.reason ?? "Payment rejected by policy.",
        contentType: "text/plain",
        notifications,
      };
    }

    this.controls.recordApprovedPayment();

    const paidResponse = await this.paymentFetch(input.url, {
      method: input.method ?? "GET",
      headers: input.headers,
      body: input.body,
    });

    const body = await paidResponse.text();
    const transaction = await this.createTransactionRecord({
      task,
      input,
      paymentRequired,
      amountUsd,
      response: paidResponse,
      responseBody: body,
    });

    if (transaction) {
      await this.store.append(transaction);
    }

    return {
      ok: paidResponse.ok,
      status: paidResponse.status,
      statusText: paidResponse.statusText,
      body,
      contentType: paidResponse.headers.get("content-type"),
      payment: transaction,
      notifications,
    };
  }

  private selectRequirement(paymentRequired: PaymentRequired) {
    const requirement = paymentRequired.accepts.find(
      (candidate) =>
        candidate.network === "eip155:8453" && candidate.scheme === "exact",
    );

    if (!requirement) {
      throw new Error("No supported Base mainnet exact payment option returned by server.");
    }

    return requirement;
  }

  private async createTransactionRecord(input: {
    task?: string;
    input: PremiumRequestInput;
    paymentRequired: PaymentRequired;
    amountUsd: number;
    response: Response;
    responseBody: string;
  }): Promise<TransactionRecord | undefined> {
    const header = input.response.headers.get("payment-response");
    const requirement = this.selectRequirement(input.paymentRequired);

    if (!header) {
      return undefined;
    }

    const settlement = decodePaymentResponseHeader(header);
    const verifiedOnChain = await this.verifier.verify(
      settlement.transaction,
      settlement.network,
    );

    return {
      id: randomUUID(),
      createdAt: new Date().toISOString(),
      url: input.input.url,
      method: input.input.method ?? "GET",
      task: input.task,
      resource: input.paymentRequired.resource.url,
      network: requirement.network,
      asset: requirement.asset,
      amountAtomic: requirement.amount,
      amountUsd: input.amountUsd,
      recipient: requirement.payTo,
      payer: settlement.payer,
      transactionHash: settlement.transaction,
      verifiedOnChain,
      responseStatus: input.response.status,
      responseBodyPreview: previewBody(input.responseBody),
    };
  }
}
