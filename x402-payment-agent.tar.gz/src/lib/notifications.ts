import type { Notification, NotificationLevel } from "../types.js";

export class NotificationCollector {
  private readonly items: Notification[] = [];

  add(level: NotificationLevel, message: string): void {
    this.items.push({
      level,
      message,
      createdAt: new Date().toISOString(),
    });
  }

  drain(): Notification[] {
    return [...this.items];
  }
}
