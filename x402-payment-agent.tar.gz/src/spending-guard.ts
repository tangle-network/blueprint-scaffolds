import type { PaymentRequirements, SpendingConfig } from "./types.js";
import { TransactionLogger } from "./logger.js";

export class SpendingGuard {
  private lastPaymentAttempt = new Map<string, number>();
  private rateLimitMs: number;

  constructor(
    private config: SpendingConfig,
    private logger: TransactionLogger,
    rateLimitMs = 5000
  ) {
    this.rateLimitMs = rateLimitMs;
  }

  validate(requirements: PaymentRequirements): {
    allowed: boolean;
    reason?: string;
  } {
    const amountUsd = this.toUsd(requirements.amount);

    if (amountUsd > this.config.maxPaymentPerRequest) {
      return {
        allowed: false,
        reason: `Payment of $${amountUsd.toFixed(2)} exceeds per-request limit of $${this.config.maxPaymentPerRequest}`,
      };
    }

    if (requirements.recipient) {
      const recipientLower = requirements.recipient.toLowerCase();
      if (
        this.config.allowedRecipients.length > 0 &&
        !this.config.allowedRecipients.includes(recipientLower)
      ) {
        return {
          allowed: false,
          reason: `Recipient ${requirements.recipient} is not in the allowed recipients whitelist`,
        };
      }
    }

    const dailyTotal = this.logger.getDailyTotal();
    if (dailyTotal + amountUsd > this.config.dailyLimit) {
      return {
        allowed: false,
        reason: `Payment of $${amountUsd.toFixed(2)} would exceed daily limit ($${dailyTotal.toFixed(2)}/$${this.config.dailyLimit})`,
      };
    }

    const weeklyTotal = this.logger.getWeeklyTotal();
    if (weeklyTotal + amountUsd > this.config.weeklyLimit) {
      return {
        allowed: false,
        reason: `Payment of $${amountUsd.toFixed(2)} would exceed weekly limit ($${weeklyTotal.toFixed(2)}/$${this.config.weeklyLimit})`,
      };
    }

    const recipient = requirements.recipient.toLowerCase();
    const lastAttempt = this.lastPaymentAttempt.get(recipient) ?? 0;
    if (Date.now() - lastAttempt < this.rateLimitMs) {
      return {
        allowed: false,
        reason: `Rate limited: too many payment attempts to ${requirements.recipient}`,
      };
    }

    return { allowed: true };
  }

  recordAttempt(recipient: string) {
    this.lastPaymentAttempt.set(recipient.toLowerCase(), Date.now());
  }

  private toUsd(amount: string): number {
    const raw = BigInt(amount);
    return Number(raw) / 1e6;
  }
}
