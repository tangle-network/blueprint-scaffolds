import {
  createWalletClient,
  http,
  type WalletClient,
  type Account,
  type PublicClient,
  createPublicClient,
  formatUnits,
} from "viem";
import { base } from "viem/chains";
import {
  AgentConfig,
  PaymentAuthorization,
  PaymentRequirements,
  BASE_MAINNET_CHAIN_ID,
  USDC_DECIMALS,
  X402_PAYMENT_DOMAIN,
  PAYMENT_TYPES,
} from "./types.js";

export class WalletManager {
  private walletClient: WalletClient;
  private publicClient: PublicClient;
  private account: Account;
  private nonceCounter: bigint;

  constructor(config: AgentConfig) {
    this.walletClient = createWalletClient({
      account: config.walletPrivateKey as `0x${string}`,
      chain: base,
      transport: http(config.baseRpcUrl),
    });

    this.publicClient = createPublicClient({
      chain: base,
      transport: http(config.baseRpcUrl),
    });

    this.account = this.walletClient.account;
    this.nonceCounter = BigInt(Date.now());
  }

  getAddress(): `0x${string}` {
    return this.account.address;
  }

  getWalletClient(): WalletClient {
    return this.walletClient;
  }

  getPublicClient(): PublicClient {
    return this.publicClient;
  }

  private nextNonce(): bigint {
    this.nonceCounter += 1n;
    return this.nonceCounter;
  }

  async createPaymentAuthorization(
    requirements: PaymentRequirements,
  ): Promise<PaymentAuthorization> {
    const nonce = this.nextNonce().toString();
    const timestamp = Math.floor(Date.now() / 1000);
    const amountWei = this.usdcToWei(requirements.amount);

    const signature = await this.walletClient.signTypedData({
      account: this.account,
      domain: {
        name: X402_PAYMENT_DOMAIN.name,
        version: X402_PAYMENT_DOMAIN.version,
        chainId: BASE_MAINNET_CHAIN_ID,
        verifyingContract: X402_PAYMENT_DOMAIN.verifyingContract,
      },
      types: PAYMENT_TYPES,
      primaryType: "Payment",
      message: {
        amount: amountWei,
        recipient: requirements.recipient,
        token: requirements.token,
        nonce: BigInt(nonce),
        timestamp: BigInt(timestamp),
      },
    });

    return {
      signature,
      amount: requirements.amount,
      recipient: requirements.recipient,
      token: requirements.token,
      nonce,
      timestamp,
      walletAddress: this.account.address,
    };
  }

  private usdcToWei(usdcAmount: string): bigint {
    const parts = usdcAmount.split(".");
    const whole = parts[0] || "0";
    const fractional = (parts[1] || "").padEnd(USDC_DECIMALS, "0").slice(0, USDC_DECIMALS);
    return BigInt(whole + fractional);
  }

  static weiToUsdc(wei: bigint): string {
    return formatUnits(wei, USDC_DECIMALS);
  }

  async getBalance(): Promise<string> {
    return "0";
  }
}
