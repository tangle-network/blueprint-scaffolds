import { createPublicClient, createWalletClient, http, type Hex, type Address } from "viem";
import { base } from "viem/chains";
import { privateKeyToAccount } from "viem/accounts";
import type { PaymentRequirements, PaymentPayload } from "./types.js";

const ERC20_ABI = [
  {
    name: "transfer",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "to", type: "address" },
      { name: "amount", type: "uint256" },
    ],
    outputs: [{ name: "", type: "bool" }],
  },
  {
    name: "approve",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "spender", type: "address" },
      { name: "amount", type: "uint256" },
    ],
    outputs: [{ name: "", type: "bool" }],
  },
  {
    name: "balanceOf",
    type: "function",
    stateMutability: "view",
    inputs: [{ name: "account", type: "address" }],
    outputs: [{ name: "", type: "uint256" }],
  },
  {
    name: "allowance",
    type: "function",
    stateMutability: "view",
    inputs: [
      { name: "owner", type: "address" },
      { name: "spender", type: "address" },
    ],
    outputs: [{ name: "", type: "uint256" }],
  },
] as const;

export class WalletManager {
  private walletClient;
  private publicClient;
  private account;
  private tokenAddress: Address;

  constructor(privateKey: Hex, rpcUrl: string, tokenAddress: Address, walletAddress: Address) {
    this.account = privateKeyToAccount(privateKey);
    this.tokenAddress = tokenAddress;

    this.publicClient = createPublicClient({
      chain: base,
      transport: http(rpcUrl),
    });

    this.walletClient = createWalletClient({
      account: this.account,
      chain: base,
      transport: http(rpcUrl),
    });
  }

  get address(): Address {
    return this.account.address;
  }

  async getTokenBalance(): Promise<bigint> {
    const balance = await this.publicClient.readContract({
      address: this.tokenAddress,
      abi: ERC20_ABI,
      functionName: "balanceOf",
      args: [this.account.address],
    });
    return balance as bigint;
  }

  async signPayment(requirements: PaymentRequirements): Promise<PaymentPayload> {
    const nonce = BigInt(Date.now()).toString();
    const timestamp = Math.floor(Date.now() / 1000).toString();

    const payload = {
      version: requirements.version || 1,
      recipient: requirements.recipient,
      amount: requirements.amount,
      token: requirements.token,
      nonce,
      timestamp,
      network: requirements.network || "base-mainnet",
    };

    const message = this.encodePaymentMessage(payload);

    const signature = await this.account.signMessage({
      message: { raw: Buffer.from(message, "hex") },
    });

    return {
      signature,
      authorization: `x402 ${this.account.address}`,
      payload,
    };
  }

  async transferTokens(to: Address, amount: string): Promise<Hex> {
    const hash = await this.walletClient.writeContract({
      address: this.tokenAddress,
      abi: ERC20_ABI,
      functionName: "transfer",
      args: [to, BigInt(amount)],
    });

    const receipt = await this.publicClient.waitForTransactionReceipt({ hash });
    if (receipt.status !== "success") {
      throw new Error(`Token transfer failed: ${hash}`);
    }

    return hash;
  }

  async approveSpending(spender: Address, amount: string): Promise<Hex> {
    const hash = await this.walletClient.writeContract({
      address: this.tokenAddress,
      abi: ERC20_ABI,
      functionName: "approve",
      args: [spender, BigInt(amount)],
    });

    await this.publicClient.waitForTransactionReceipt({ hash });
    return hash;
  }

  private encodePaymentMessage(payload: PaymentPayload["payload"]): string {
    const fields = [
      payload.version.toString(),
      payload.recipient.toLowerCase(),
      payload.amount,
      payload.token.toLowerCase(),
      payload.nonce,
      payload.timestamp,
      payload.network,
    ];
    return Buffer.from(fields.join(":")).toString("hex");
  }
}
