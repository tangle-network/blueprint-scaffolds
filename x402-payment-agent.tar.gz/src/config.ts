import type { AgentConfig, SpendingConfig } from "./types.js";

function required(name: string): string {
  const val = process.env[name];
  if (!val) throw new Error(`Missing required environment variable: ${name}`);
  return val;
}

function optional(name: string, fallback: string): string {
  return process.env[name] ?? fallback;
}

export function loadConfig(): AgentConfig {
  const privateKey = required("PRIVATE_KEY") as `0x${string}`;
  const openaiApiKey = required("OPENAI_API_KEY");
  const rpcUrl = optional("RPC_URL", "https://mainnet.base.org");
  const paymentTokenAddress = optional(
    "PAYMENT_TOKEN_ADDRESS",
    "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913"
  ) as `0x${string}`;
  const walletAddress = optional("WALLET_ADDRESS", "") as `0x${string}`;

  const spending: SpendingConfig = {
    maxPaymentPerRequest: Number(optional("MAX_PAYMENT_PER_REQUEST", "10")),
    dailyLimit: Number(optional("DAILY_SPENDING_LIMIT", "100")),
    weeklyLimit: Number(optional("WEEKLY_SPENDING_LIMIT", "500")),
    allowedRecipients: optional("ALLOWED_RECIPIENTS", "")
      .split(",")
      .map((s) => s.trim().toLowerCase())
      .filter(Boolean),
  };

  return {
    openaiApiKey,
    privateKey,
    rpcUrl,
    paymentTokenAddress,
    walletAddress,
    spending,
  };
}
