import { config as loadDotEnv } from "dotenv";
import { z } from "zod";
import type { ProviderName } from "./types.js";

loadDotEnv();

const envSchema = z.object({
  PORT: z.coerce.number().int().positive().default(3000),
  OPENAI_API_KEY: z.string().optional(),
  ANTHROPIC_API_KEY: z.string().optional(),
  AI_PROVIDER: z.enum(["openai", "anthropic"]).default("openai"),
  AI_MODEL: z.string().default("gpt-4.1-mini"),
  WALLET_PRIVATE_KEY: z.string().regex(/^0x[a-fA-F0-9]{64}$/).optional(),
  BASE_RPC_URL: z.string().url().default("https://mainnet.base.org"),
  MAX_PAYMENT_USD: z.coerce.number().positive().default(2),
  DAILY_SPEND_LIMIT_USD: z.coerce.number().positive().default(10),
  WEEKLY_SPEND_LIMIT_USD: z.coerce.number().positive().default(30),
  EXPENSIVE_OPERATION_USD: z.coerce.number().positive().default(1),
  AUTO_APPROVE_EXPENSIVE: z
    .enum(["true", "false"])
    .default("false")
    .transform((value) => value === "true"),
  PAYEE_WHITELIST: z.string().default(""),
  PAYMENT_RATE_LIMIT_PER_MINUTE: z.coerce.number().int().positive().default(10),
  USDC_DECIMALS: z.coerce.number().int().min(0).max(18).default(6),
  TRANSACTION_LOG_PATH: z.string().default("transactions.log"),
});

export type AppConfig = {
  port: number;
  aiProvider: ProviderName;
  aiModel: string;
  openAIApiKey?: string;
  anthropicApiKey?: string;
  walletPrivateKey?: `0x${string}`;
  baseRpcUrl: string;
  maxPaymentUsd: number;
  dailySpendLimitUsd: number;
  weeklySpendLimitUsd: number;
  expensiveOperationUsd: number;
  autoApproveExpensive: boolean;
  payeeWhitelist: Set<string>;
  paymentRateLimitPerMinute: number;
  usdcDecimals: number;
  transactionLogPath: string;
};

export function loadConfig(): AppConfig {
  const parsed = envSchema.parse(process.env);

  return {
    port: parsed.PORT,
    aiProvider: parsed.AI_PROVIDER,
    aiModel: parsed.AI_MODEL,
    openAIApiKey: parsed.OPENAI_API_KEY,
    anthropicApiKey: parsed.ANTHROPIC_API_KEY,
    walletPrivateKey: parsed.WALLET_PRIVATE_KEY as `0x${string}` | undefined,
    baseRpcUrl: parsed.BASE_RPC_URL,
    maxPaymentUsd: parsed.MAX_PAYMENT_USD,
    dailySpendLimitUsd: parsed.DAILY_SPEND_LIMIT_USD,
    weeklySpendLimitUsd: parsed.WEEKLY_SPEND_LIMIT_USD,
    expensiveOperationUsd: parsed.EXPENSIVE_OPERATION_USD,
    autoApproveExpensive: parsed.AUTO_APPROVE_EXPENSIVE,
    payeeWhitelist: new Set(
      parsed.PAYEE_WHITELIST.split(",")
        .map((entry) => entry.trim().toLowerCase())
        .filter(Boolean),
    ),
    paymentRateLimitPerMinute: parsed.PAYMENT_RATE_LIMIT_PER_MINUTE,
    usdcDecimals: parsed.USDC_DECIMALS,
    transactionLogPath: parsed.TRANSACTION_LOG_PATH,
  };
}

export function assertRuntimeSecrets(config: AppConfig): void {
  if (!config.walletPrivateKey) {
    throw new Error("WALLET_PRIVATE_KEY is required for payment-enabled requests.");
  }

  if (config.aiProvider === "openai" && !config.openAIApiKey) {
    throw new Error("OPENAI_API_KEY is required when AI_PROVIDER=openai.");
  }

  if (config.aiProvider === "anthropic" && !config.anthropicApiKey) {
    throw new Error("ANTHROPIC_API_KEY is required when AI_PROVIDER=anthropic.");
  }
}
