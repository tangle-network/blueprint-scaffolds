import { AgentConfig, SpendingConfig } from "./types.js";

function parseEnvBoolean(value: string | undefined, defaultValue: boolean): boolean {
  if (value === undefined) return defaultValue;
  return value.toLowerCase() === "true" || value === "1";
}

function parseEnvAddresses(value: string | undefined): `0x${string}`[] {
  if (!value || value.trim() === "") return [];
  return value
    .split(",")
    .map((addr) => addr.trim() as `0x${string}`)
    .filter((addr) => addr.startsWith("0x") && addr.length === 42);
}

export function loadConfig(): AgentConfig {
  const privateKey = process.env.PRIVATE_KEY;
  if (!privateKey) {
    throw new Error("PRIVATE_KEY environment variable is required");
  }

  const openaiApiKey = process.env.OPENAI_API_KEY;
  if (!openaiApiKey) {
    throw new Error("OPENAI_API_KEY environment variable is required");
  }

  const spending: SpendingConfig = {
    maxPerRequest: parseFloat(process.env.MAX_PAYMENT_PER_REQUEST || "5.00"),
    dailyLimit: parseFloat(process.env.DAILY_SPENDING_LIMIT || "50.00"),
    weeklyLimit: parseFloat(process.env.WEEKLY_SPENDING_LIMIT || "200.00"),
    allowedRecipients: parseEnvAddresses(process.env.ALLOWED_RECIPIENTS),
  };

  if (spending.maxPerRequest <= 0 || isNaN(spending.maxPerRequest)) {
    throw new Error("MAX_PAYMENT_PER_REQUEST must be a positive number");
  }
  if (spending.dailyLimit <= 0 || isNaN(spending.dailyLimit)) {
    throw new Error("DAILY_SPENDING_LIMIT must be a positive number");
  }

  return {
    walletPrivateKey: privateKey as `0x${string}`,
    openaiApiKey,
    baseRpcUrl: process.env.BASE_RPC_URL || "https://mainnet.base.org",
    agentModel: process.env.AGENT_MODEL || "gpt-4o",
    spending,
  };
}
