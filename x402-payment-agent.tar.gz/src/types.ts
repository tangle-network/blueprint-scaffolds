export interface PaymentRequirements {
  version: number;
  recipient: `0x${string}`;
  amount: string;
  token: `0x${string}`;
  tokenName: string;
  network: string;
  resource: string;
  description?: string;
  expiresAt?: number;
  maxAmountRequired?: string;
  payTo?: `0x${string}`;
  usdAmountMax?: string;
}

export interface PaymentPayload {
  signature: `0x${string}`;
  authorization: string;
  payload: {
    version: number;
    recipient: `0x${string}`;
    amount: string;
    token: `0x${string}`;
    nonce: string;
    timestamp: string;
    network: string;
  };
}

export interface TransactionRecord {
  id: string;
  timestamp: number;
  recipient: string;
  amount: string;
  token: string;
  tokenName: string;
  resource: string;
  txHash?: string;
  status: "pending" | "confirmed" | "failed";
  error?: string;
}

export interface SpendingConfig {
  maxPaymentPerRequest: number;
  dailyLimit: number;
  weeklyLimit: number;
  allowedRecipients: string[];
}

export interface AgentConfig {
  openaiApiKey: string;
  privateKey: `0x${string}`;
  rpcUrl: string;
  paymentTokenAddress: `0x${string}`;
  walletAddress: `0x${string}`;
  spending: SpendingConfig;
}

export interface AgentTool {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
  execute: (args: Record<string, unknown>) => Promise<string>;
}
