export type ProviderName = "openai" | "anthropic";

export type SpendWindow = "daily" | "weekly";

export type NotificationLevel = "info" | "warning" | "critical";

export type Notification = {
  level: NotificationLevel;
  message: string;
  createdAt: string;
};

export type PaymentDecision = {
  approved: boolean;
  reason?: string;
  approvalRequired?: boolean;
  notifications: Notification[];
};

export type TransactionRecord = {
  id: string;
  createdAt: string;
  url: string;
  method: string;
  task?: string;
  resource: string;
  network: string;
  asset: string;
  amountAtomic: string;
  amountUsd: number;
  recipient: string;
  payer?: string;
  transactionHash?: string;
  verifiedOnChain: boolean;
  responseStatus: number;
  responseBodyPreview?: string;
};

export type SpendingSnapshot = {
  dailySpentUsd: number;
  weeklySpentUsd: number;
  dailyLimitUsd: number;
  weeklyLimitUsd: number;
  remainingDailyUsd: number;
  remainingWeeklyUsd: number;
};

export type PremiumRequestInput = {
  url: string;
  method?: "GET" | "POST";
  headers?: Record<string, string>;
  body?: string;
  purpose: string;
};

export type PremiumRequestResult = {
  ok: boolean;
  status: number;
  statusText: string;
  body: string;
  contentType: string | null;
  payment?: TransactionRecord;
  notifications: Notification[];
};

export type AgentRunResult = {
  task: string;
  text: string;
  notifications: Notification[];
  transactions: TransactionRecord[];
};
