export interface PaymentRequirements {
  amount: string;
  recipient: `0x${string}`;
  token: `0x${string}`;
  network: string;
  description?: string;
  expiresAt?: number;
}

export interface PaymentAuthorization {
  signature: `0x${string}`;
  amount: string;
  recipient: `0x${string}`;
  token: `0x${string}`;
  nonce: string;
  timestamp: number;
  walletAddress: `0x${string}`;
}

export interface TransactionRecord {
  id: string;
  timestamp: number;
  url: string;
  method: string;
  amount: string;
  token: `0x${string}`;
  recipient: `0x${string}`;
  status: "pending" | "confirmed" | "failed";
  txHash?: `0x${string}`;
  authorization: PaymentAuthorization;
  responseStatus?: number;
  metadata?: Record<string, unknown>;
}

export interface PaymentResponse {
  success: boolean;
  data?: unknown;
  status: number;
  transaction?: TransactionRecord;
  error?: string;
}

export interface SpendingConfig {
  maxPerRequest: number;
  dailyLimit: number;
  weeklyLimit: number;
  allowedRecipients: `0x${string}`[];
}

export interface AgentConfig {
  walletPrivateKey: `0x${string}`;
  openaiApiKey: string;
  baseRpcUrl: string;
  agentModel: string;
  spending: SpendingConfig;
}

export interface AgentTool {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
  execute: (args: Record<string, unknown>) => Promise<unknown>;
}

export interface EIP712Domain {
  name: string;
  version: string;
  chainId: number;
  verifyingContract: `0x${string}`;
}

export const BASE_MAINNET_CHAIN_ID = 8453;
export const USDC_BASE = "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913" as `0x${string}`;
export const USDC_DECIMALS = 6;

export const X402_PAYMENT_DOMAIN: EIP712Domain = {
  name: "x402 Payment",
  version: "1",
  chainId: BASE_MAINNET_CHAIN_ID,
  verifyingContract: "0x0000000000000000000000000000000000000001" as `0x${string}`,
};

export const PAYMENT_TYPES = {
  Payment: [
    { name: "amount", type: "uint256" },
    { name: "recipient", type: "address" },
    { name: "token", type: "address" },
    { name: "nonce", type: "uint256" },
    { name: "timestamp", type: "uint256" },
  ],
} as const;
