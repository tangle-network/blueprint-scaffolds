import express from "express";
import { z } from "zod";
import { assertRuntimeSecrets, loadConfig } from "./config.js";
import { X402Agent } from "./agent.js";
import { createLanguageModel } from "./lib/ai-model.js";
import { PremiumHttpClient } from "./lib/payment-client.js";
import { SpendingControls } from "./lib/spending-controls.js";
import { TransactionStore } from "./lib/transaction-store.js";

const runBodySchema = z.object({
  task: z.string().min(1),
});

async function main() {
  const config = loadConfig();
  const app = express();

  app.use(express.json({ limit: "1mb" }));

  const store = new TransactionStore(config.transactionLogPath);
  const controls = new SpendingControls(config);

  app.get("/health", async (_request, response) => {
    const transactions = await store.list();
    response.json({
      ok: true,
      transactions: transactions.length,
      budget: controls.getSnapshot(transactions),
    });
  });

  app.get("/transactions", async (_request, response) => {
    response.json(await store.list());
  });

  app.post("/agent/run", async (request, response) => {
    try {
      const body = runBodySchema.parse(request.body);
      assertRuntimeSecrets(config);

      const model = createLanguageModel(config);
      const premiumClient = new PremiumHttpClient(config, store, controls);
      const agent = new X402Agent(model, premiumClient, store, controls);
      const result = await agent.run(body.task);

      response.json(result);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Unknown error";
      response.status(400).json({
        error: message,
      });
    }
  });

  app.listen(config.port, () => {
    console.log(`x402 agent listening on http://localhost:${config.port}`);
  });
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
