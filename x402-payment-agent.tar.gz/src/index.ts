import * as readline from "readline";
import { loadConfig } from "./config.js";
import { WalletManager } from "./wallet.js";
import { TransactionStore } from "./store.js";
import { SpendingLimits } from "./limits.js";
import { X402Agent } from "./agent.js";

function createReadlineInterface() {
  return readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });
}

async function main() {
  console.log("=== x402 Payment Agent ===\n");

  let config;
  try {
    config = loadConfig();
  } catch (err) {
    console.error("Configuration error:", err instanceof Error ? err.message : err);
    console.error("\nRequired environment variables:");
    console.error("  PRIVATE_KEY      - Ethereum wallet private key (0x-prefixed)");
    console.error("  OPENAI_API_KEY   - OpenAI API key");
    console.error("\nOptional:");
    console.error("  BASE_RPC_URL           - Base mainnet RPC URL (default: https://mainnet.base.org)");
    console.error("  AGENT_MODEL            - OpenAI model name (default: gpt-4o)");
    console.error("  MAX_PAYMENT_PER_REQUEST - Max USDC per payment (default: 5.00)");
    console.error("  DAILY_SPENDING_LIMIT    - Daily spending limit in USDC (default: 50.00)");
    console.error("  WEEKLY_SPENDING_LIMIT   - Weekly spending limit in USDC (default: 200.00)");
    console.error("  ALLOWED_RECIPIENTS      - Comma-separated list of allowed payment recipient addresses");
    process.exit(1);
  }

  const store = new TransactionStore();
  const limits = new SpendingLimits(config.spending, store);

  let wallet: WalletManager;
  try {
    wallet = new WalletManager(config);
    console.log(`Wallet address: ${wallet.getAddress()}`);
  } catch (err) {
    console.error("Wallet initialization error:", err instanceof Error ? err.message : err);
    process.exit(1);
  }

  const spendingConfig = limits.getConfig();
  console.log(`Spending limits: $${spendingConfig.maxPerRequest}/request, $${spendingConfig.dailyLimit}/day, $${spendingConfig.weeklyLimit}/week`);
  console.log(`Model: ${config.agentModel}`);
  console.log("\nType your request and press Enter. Type 'exit' to quit.\n");

  const agent = new X402Agent(config, wallet, store, limits);

  if (process.argv.length > 2) {
    const query = process.argv.slice(2).join(" ");
    console.log(`Query: ${query}\n`);
    try {
      const result = await agent.run(query);
      console.log(`\nAgent: ${result}\n`);
    } catch (err) {
      console.error("Agent error:", err instanceof Error ? err.message : err);
    }
    return;
  }

  const readline = createReadlineInterface();

  const prompt = () => {
    readline.question("You: ", async (input: string) => {
      const trimmed = input.trim();
      if (!trimmed) {
        prompt();
        return;
      }

      if (trimmed.toLowerCase() === "exit" || trimmed.toLowerCase() === "quit") {
        console.log("Goodbye!");
        readline.close();
        process.exit(0);
      }

      if (trimmed.toLowerCase() === "history") {
        const history = agent.getConversationHistory();
        for (const msg of history) {
          console.log(`[${msg.role}]: ${msg.content?.slice(0, 200)}`);
        }
        prompt();
        return;
      }

      if (trimmed.toLowerCase() === "stats") {
        const stats = store.getStats();
        console.log("Transaction Stats:", JSON.stringify(stats, null, 2));
        prompt();
        return;
      }

      if (trimmed.toLowerCase() === "reset") {
        agent.resetConversation();
        console.log("Conversation reset.");
        prompt();
        return;
      }

      try {
        const result = await agent.run(trimmed);
        console.log(`\nAgent: ${result}\n`);
      } catch (err) {
        console.error("Agent error:", err instanceof Error ? err.message : err);
      }

      prompt();
    });
  };

  prompt();
}

main().catch((err) => {
  console.error("Fatal error:", err);
  process.exit(1);
});
