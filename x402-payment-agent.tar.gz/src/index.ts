import { loadConfig } from "./config.js";
import { X402Agent } from "./agent.js";

async function main() {
  const args = process.argv.slice(2);

  if (args.length === 0) {
    console.log("x402 AI Agent — autonomous payment agent for premium HTTP services");
    console.log("");
    console.log("Usage: node dist/index.js \"<your request>\"");
    console.log("");
    console.log("Example:");
    console.log('  node dist/index.js "Fetch premium weather data from https://api.example.com/weather"');
    console.log("");
    console.log("Environment variables required:");
    console.log("  PRIVATE_KEY     — Ethereum private key (hex)");
    console.log("  OPENAI_API_KEY  — OpenAI API key");
    process.exit(1);
  }

  const config = loadConfig();
  const agent = new X402Agent(config);

  const userMessage = args.join(" ");
  console.log(`[x402-agent] Processing: ${userMessage}`);
  console.log("");

  try {
    const result = await agent.run(userMessage);
    console.log(result);
  } catch (err) {
    console.error("[x402-agent] Error:", err instanceof Error ? err.message : err);
    process.exit(1);
  }
}

main();
