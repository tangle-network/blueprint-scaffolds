import { TransactionRecord, PaymentAuthorization } from "./types.js";
import { randomUUID } from "crypto";

export class TransactionStore {
  private transactions: Map<string, TransactionRecord> = new Map();

  add(
    url: string,
    method: string,
    amount: string,
    token: `0x${string}`,
    recipient: `0x${string}`,
    authorization: PaymentAuthorization,
  ): TransactionRecord {
    const record: TransactionRecord = {
      id: randomUUID(),
      timestamp: Date.now(),
      url,
      method,
      amount,
      token,
      recipient,
      status: "pending",
      authorization,
    };
    this.transactions.set(record.id, record);
    return record;
  }

  updateStatus(id: string, status: TransactionRecord["status"], txHash?: `0x${string}`, responseStatus?: number): void {
    const record = this.transactions.get(id);
    if (record) {
      record.status = status;
      if (txHash) record.txHash = txHash;
      if (responseStatus !== undefined) record.responseStatus = responseStatus;
    }
  }

  get(id: string): TransactionRecord | undefined {
    return this.transactions.get(id);
  }

  getAll(): TransactionRecord[] {
    return Array.from(this.transactions.values()).sort((a, b) => b.timestamp - a.timestamp);
  }

  getRecent(count: number): TransactionRecord[] {
    return this.getAll().slice(0, count);
  }

  getDailyTotal(): number {
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);
    const dayStart = startOfDay.getTime();

    let total = 0;
    for (const tx of this.transactions.values()) {
      if (tx.timestamp >= dayStart && (tx.status === "confirmed" || tx.status === "pending")) {
        total += parseFloat(tx.amount);
      }
    }
    return total;
  }

  getWeeklyTotal(): number {
    const now = Date.now();
    const weekStart = now - 7 * 24 * 60 * 60 * 1000;

    let total = 0;
    for (const tx of this.transactions.values()) {
      if (tx.timestamp >= weekStart && (tx.status === "confirmed" || tx.status === "pending")) {
        total += parseFloat(tx.amount);
      }
    }
    return total;
  }

  getStats(): {
    totalTransactions: number;
    totalSpent: number;
    pendingCount: number;
    confirmedCount: number;
    failedCount: number;
  } {
    let totalSpent = 0;
    let pendingCount = 0;
    let confirmedCount = 0;
    let failedCount = 0;

    for (const tx of this.transactions.values()) {
      if (tx.status === "confirmed" || tx.status === "pending") {
        totalSpent += parseFloat(tx.amount);
      }
      if (tx.status === "pending") pendingCount++;
      else if (tx.status === "confirmed") confirmedCount++;
      else if (tx.status === "failed") failedCount++;
    }

    return {
      totalTransactions: this.transactions.size,
      totalSpent,
      pendingCount,
      confirmedCount,
      failedCount,
    };
  }
}
