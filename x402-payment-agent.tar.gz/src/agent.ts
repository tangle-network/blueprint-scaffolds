import OpenAI from "openai";
import { X402PaymentHandler } from "./payment.js";
import { TransactionStore } from "./store.js";
import { WalletManager } from "./wallet.js";
import { SpendingLimits } from "./limits.js";
import { AgentConfig } from "./types.js";

export interface AgentMessage {
  role: "system" | "user" | "assistant" | "tool";
  content: string;
  tool_call_id?: string;
  tool_calls?: OpenAI.Chat.Completions.ChatCompletionMessageToolCall[];
}

const SYSTEM_PROMPT = `You are an autonomous AI agent capable of paying for premium HTTP services using the x402 payment protocol.

You have access to tools that let you:
- Fetch URLs (with automatic x402 payment handling)
- Check your spending limits and transaction history
- Get wallet information

When you encounter a paid resource:
1. You will be informed of the payment requirement
2. The system will automatically check spending limits before paying
3. Payments are made in USDC on Base mainnet
4. All transactions are logged for auditing

Always inform the user before making payments. Report the amount, recipient, and purpose.
If a payment fails or is blocked by limits, explain why and suggest alternatives.

Be helpful, concise, and transparent about all payment operations.`;

interface ToolDefinition {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
  handler: (args: Record<string, unknown>) => Promise<string>;
}

export class X402Agent {
  private openai: OpenAI;
  private paymentHandler: X402PaymentHandler;
  private wallet: WalletManager;
  private store: TransactionStore;
  private limits: SpendingLimits;
  private model: string;
  private tools: Map<string, ToolDefinition>;
  private conversationHistory: AgentMessage[];

  constructor(
    config: AgentConfig,
    wallet: WalletManager,
    store: TransactionStore,
    limits: SpendingLimits,
  ) {
    this.openai = new OpenAI({ apiKey: config.openaiApiKey });
    this.wallet = wallet;
    this.store = store;
    this.limits = limits;
    this.model = config.agentModel;
    this.paymentHandler = new X402PaymentHandler(wallet, limits, store);
    this.tools = new Map();
    this.conversationHistory = [];
    this.registerTools();
  }

  private registerTools(): void {
    this.tools.set("fetch_url", {
      name: "fetch_url",
      description:
        "Fetch a URL with automatic x402 payment handling. If the server requires payment (HTTP 402), the system will automatically negotiate and pay using USDC on Base mainnet, subject to spending limits.",
      parameters: {
        type: "object",
        properties: {
          url: {
            type: "string",
            description: "The URL to fetch",
          },
          method: {
            type: "string",
            description: "HTTP method (GET, POST, PUT, DELETE)",
            enum: ["GET", "POST", "PUT", "DELETE"],
            default: "GET",
          },
          body: {
            type: "string",
            description: "Request body as a JSON string (for POST/PUT)",
          },
          headers: {
            type: "object",
            description: "Additional request headers",
            additionalProperties: { type: "string" },
          },
        },
        required: ["url"],
      },
      handler: async (args) => {
        const url = args.url as string;
        const method = (args.method as string) || "GET";
        const body = args.body as string | undefined;
        const headers = args.headers as Record<string, string> | undefined;

        const options: RequestInit = {
          method,
          headers: headers || {},
        };

        if (body && (method === "POST" || method === "PUT")) {
          (options.headers as Record<string, string>)["Content-Type"] =
            (options.headers as Record<string, string>)["Content-Type"] || "application/json";
          options.body = body;
        }

        const result = await this.paymentHandler.fetchWithPayment(url, options);

        return JSON.stringify(result, null, 2);
      },
    });

    this.tools.set("check_spending", {
      name: "check_spending",
      description:
        "Check current spending limits, daily/weekly usage, and remaining budget before making paid requests.",
      parameters: {
        type: "object",
        properties: {},
      },
      handler: async () => {
        const daily = this.limits.checkDailyLimit();
        const weekly = this.limits.checkWeeklyLimit();
        const config = this.limits.getConfig();
        const stats = this.store.getStats();

        return JSON.stringify(
          {
            perRequestLimit: `$${config.maxPerRequest.toFixed(2)}`,
            daily: {
              limit: `$${config.dailyLimit.toFixed(2)}`,
              spent: `$${daily.spent.toFixed(2)}`,
              remaining: `$${daily.remaining.toFixed(2)}`,
              allowed: daily.allowed,
            },
            weekly: {
              limit: `$${config.weeklyLimit.toFixed(2)}`,
              spent: `$${weekly.spent.toFixed(2)}`,
              remaining: `$${weekly.remaining.toFixed(2)}`,
              allowed: weekly.allowed,
            },
            allTimeStats: stats,
            allowedRecipients:
              config.allowedRecipients.length > 0
                ? config.allowedRecipients
                : "All recipients allowed",
          },
          null,
          2,
        );
      },
    });

    this.tools.set("transaction_history", {
      name: "transaction_history",
      description: "Get recent transaction history showing all x402 payments made.",
      parameters: {
        type: "object",
        properties: {
          count: {
            type: "number",
            description: "Number of recent transactions to return (default: 10)",
          },
        },
      },
      handler: async (args) => {
        const count = (args.count as number) || 10;
        const transactions = this.store.getRecent(count);
        return JSON.stringify(
          {
            count: transactions.length,
            transactions: transactions.map((tx) => ({
              id: tx.id,
              timestamp: new Date(tx.timestamp).toISOString(),
              url: tx.url,
              method: tx.method,
              amount: `$${tx.amount}`,
              recipient: tx.recipient,
              status: tx.status,
              txHash: tx.txHash || "N/A",
            })),
          },
          null,
          2,
        );
      },
    });

    this.tools.set("wallet_info", {
      name: "wallet_info",
      description: "Get wallet address and balance information.",
      parameters: {
        type: "object",
        properties: {},
      },
      handler: async () => {
        const address = this.wallet.getAddress();
        return JSON.stringify(
          {
            address,
            network: "Base Mainnet",
            chainId: 8453,
            paymentToken: "USDC",
          },
          null,
          2,
        );
      },
    });
  }

  private getToolDefinitions(): OpenAI.Chat.Completions.ChatCompletionTool[] {
    return Array.from(this.tools.values()).map((tool) => ({
      type: "function" as const,
      function: {
        name: tool.name,
        description: tool.description,
        parameters: tool.parameters,
      },
    }));
  }

  async run(userMessage: string, maxIterations = 10): Promise<string> {
    this.conversationHistory.push({
      role: "user",
      content: userMessage,
    });

    for (let i = 0; i < maxIterations; i++) {
      const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
        { role: "system", content: SYSTEM_PROMPT },
        ...this.conversationHistory.map((msg) => {
          if (msg.role === "tool") {
            return {
              role: "tool" as const,
              content: msg.content,
              tool_call_id: msg.tool_call_id!,
            };
          }
          if (msg.role === "assistant" && msg.tool_calls) {
            return {
              role: "assistant" as const,
              content: msg.content || null,
              tool_calls: msg.tool_calls,
            };
          }
          return {
            role: msg.role as "system" | "user" | "assistant",
            content: msg.content,
          };
        }),
      ];

      const response = await this.openai.chat.completions.create({
        model: this.model,
        messages,
        tools: this.getToolDefinitions(),
        tool_choice: "auto",
      });

      const choice = response.choices[0];
      if (!choice?.message) {
        return "Error: No response from AI model.";
      }

      const assistantMessage = choice.message;

      if (assistantMessage.tool_calls && assistantMessage.tool_calls.length > 0) {
        this.conversationHistory.push({
          role: "assistant",
          content: assistantMessage.content || "",
          tool_calls: assistantMessage.tool_calls,
        });

        for (const toolCall of assistantMessage.tool_calls) {
          const toolName = toolCall.function.name;
          const tool = this.tools.get(toolName);

          if (!tool) {
            this.conversationHistory.push({
              role: "tool",
              content: JSON.stringify({ error: `Unknown tool: ${toolName}` }),
              tool_call_id: toolCall.id,
            });
            continue;
          }

          try {
            const args = JSON.parse(toolCall.function.arguments);
            console.log(`[agent] Calling tool: ${toolName}`, JSON.stringify(args));
            const result = await tool.handler(args);
            this.conversationHistory.push({
              role: "tool",
              content: result,
              tool_call_id: toolCall.id,
            });
          } catch (err) {
            const error = err instanceof Error ? err.message : "Tool execution failed";
            console.error(`[agent] Tool error (${toolName}):`, error);
            this.conversationHistory.push({
              role: "tool",
              content: JSON.stringify({ error }),
              tool_call_id: toolCall.id,
            });
          }
        }
      } else {
        this.conversationHistory.push({
          role: "assistant",
          content: assistantMessage.content || "",
        });
        return assistantMessage.content || "No response generated.";
      }
    }

    return "Agent reached maximum iteration limit. Please try again with a more specific request.";
  }

  getConversationHistory(): AgentMessage[] {
    return [...this.conversationHistory];
  }

  resetConversation(): void {
    this.conversationHistory = [];
  }
}
