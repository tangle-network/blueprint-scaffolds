import OpenAI from "openai";
import type { AgentConfig, AgentTool } from "./types.js";
import { WalletManager } from "./wallet.js";
import { TransactionLogger } from "./logger.js";
import { SpendingGuard } from "./spending-guard.js";
import { X402FetchClient } from "./x402-fetch.js";

type ToolCallFunction = {
  name: string;
  arguments: string;
};

type ChatCompletionMessageToolCall = {
  id: string;
  type: "function";
  function: ToolCallFunction;
};

export class X402Agent {
  private openai: OpenAI;
  private wallet: WalletManager;
  private logger: TransactionLogger;
  private guard: SpendingGuard;
  private fetchClient: X402FetchClient;
  private tools: Map<string, AgentTool> = new Map();
  private conversationHistory: OpenAI.ChatCompletionMessageParam[] = [];

  constructor(config: AgentConfig) {
    this.openai = new OpenAI({ apiKey: config.openaiApiKey });
    this.wallet = new WalletManager(
      config.privateKey,
      config.rpcUrl,
      config.paymentTokenAddress,
      config.walletAddress
    );
    this.logger = new TransactionLogger();
    this.guard = new SpendingGuard(config.spending, this.logger);
    this.fetchClient = new X402FetchClient(this.wallet, this.guard, this.logger);

    this.registerDefaultTools();
  }

  private registerDefaultTools() {
    this.registerTool({
      name: "fetch_paid_resource",
      description:
        "Fetch a resource from a URL that may require x402 payment. Automatically handles 402 Payment Required responses by signing and submitting payment. Returns the response body as text.",
      parameters: {
        type: "object",
        properties: {
          url: { type: "string", description: "The URL to fetch" },
          method: {
            type: "string",
            description: "HTTP method",
            enum: ["GET", "POST", "PUT", "DELETE"],
            default: "GET",
          },
          body: { type: "string", description: "Request body (for POST/PUT)" },
        },
        required: ["url"],
      },
      execute: async (args) => {
        const url = args.url as string;
        const method = (args.method as string) || "GET";
        const body = args.body as string | undefined;

        try {
          const opts: RequestInit = { method };
          if (body) opts.body = body;

          const response = await this.fetchClient.paidFetch(url, opts);

          const contentType = response.headers.get("content-type") ?? "";
          const text = await response.text();

          return JSON.stringify({
            status: response.status,
            contentType,
            body: text.slice(0, 10000),
            truncated: text.length > 10000,
          });
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          return JSON.stringify({ error: msg });
        }
      },
    });

    this.registerTool({
      name: "check_wallet_balance",
      description: "Check the USDC token balance of the agent wallet.",
      parameters: { type: "object", properties: {} },
      execute: async () => {
        try {
          const balance = await this.wallet.getTokenBalance();
          const balanceUsd = Number(balance) / 1e6;
          return JSON.stringify({
            address: this.wallet.address,
            balanceRaw: balance.toString(),
            balanceUsd: balanceUsd.toFixed(6),
            token: "USDC",
          });
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          return JSON.stringify({ error: msg });
        }
      },
    });

    this.registerTool({
      name: "get_spending_summary",
      description: "Get a summary of spending: daily total, weekly total, and transaction counts.",
      parameters: { type: "object", properties: {} },
      execute: async () => {
        return JSON.stringify(this.logger.getSpendingSummary());
      },
    });

    this.registerTool({
      name: "get_transaction_history",
      description: "Get recent transaction history with details about each payment.",
      parameters: {
        type: "object",
        properties: {
          limit: {
            type: "number",
            description: "Max number of transactions to return",
            default: 10,
          },
        },
      },
      execute: async (args) => {
        const limit = (args.limit as number) || 10;
        return JSON.stringify(this.logger.getRecords(limit));
      },
    });
  }

  registerTool(tool: AgentTool) {
    this.tools.set(tool.name, tool);
  }

  private getToolDefinitions(): OpenAI.ChatCompletionTool[] {
    return Array.from(this.tools.values()).map((tool) => ({
      type: "function" as const,
      function: {
        name: tool.name,
        description: tool.description,
        parameters: tool.parameters as OpenAI.FunctionDefinition["parameters"],
      },
    }));
  }

  async run(userMessage: string): Promise<string> {
    this.conversationHistory.push({
      role: "user",
      content: userMessage,
    });

    const systemMessage: OpenAI.ChatCompletionSystemMessageParam = {
      role: "system",
      content: `You are an AI agent that can access premium HTTP resources by paying with USDC via the x402 payment protocol on Base mainnet. Your wallet address is ${this.wallet.address}.

Before making any payment:
1. Check if the cost is within spending limits
2. Inform the user what you're about to pay for and how much
3. Use the fetch_paid_resource tool which handles payments automatically

Always explain what you're doing before taking actions that cost money. If a payment fails, explain the error to the user and suggest alternatives.`,
    };

    const messages: OpenAI.ChatCompletionMessageParam[] = [
      systemMessage,
      ...this.conversationHistory,
    ];

    let iterations = 0;
    const maxIterations = 20;

    while (iterations < maxIterations) {
      iterations++;

      const completion = await this.openai.chat.completions.create({
        model: "gpt-4o",
        messages,
        tools: this.getToolDefinitions(),
        tool_choice: "auto",
      });

      const choice = completion.choices[0];
      if (!choice) throw new Error("No response from OpenAI");

      const assistantMessage = choice.message;
      messages.push(assistantMessage);

      if (assistantMessage.content) {
        this.conversationHistory.push({
          role: "assistant",
          content: assistantMessage.content,
        });
      }

      if (!assistantMessage.tool_calls || assistantMessage.tool_calls.length === 0) {
        return assistantMessage.content || "No response generated.";
      }

      for (const toolCall of assistantMessage.tool_calls as ChatCompletionMessageToolCall[]) {
        const tool = this.tools.get(toolCall.function.name);
        if (!tool) {
          messages.push({
            role: "tool",
            tool_call_id: toolCall.id,
            content: JSON.stringify({ error: `Unknown tool: ${toolCall.function.name}` }),
          });
          continue;
        }

        let args: Record<string, unknown>;
        try {
          args = JSON.parse(toolCall.function.arguments);
        } catch {
          args = {};
        }

        console.log(
          `[x402-agent] Tool call: ${toolCall.function.name}(${JSON.stringify(args)})`
        );

        try {
          const result = await tool.execute(args);
          messages.push({
            role: "tool",
            tool_call_id: toolCall.id,
            content: result,
          });
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          messages.push({
            role: "tool",
            tool_call_id: toolCall.id,
            content: JSON.stringify({ error: msg }),
          });
        }
      }
    }

    return "Agent reached maximum tool call iterations. Please try again with a more specific request.";
  }
}
