import { generateText, stepCountIs, tool } from "ai";
import { z } from "zod";
import type { LanguageModel } from "ai";
import type { PremiumHttpClient } from "./lib/payment-client.js";
import type { SpendingControls } from "./lib/spending-controls.js";
import type { TransactionStore } from "./lib/transaction-store.js";
import type { AgentRunResult, Notification } from "./types.js";

const SYSTEM_PROMPT = `You are an autonomous agent that can retrieve premium HTTP resources.
Use tools when you need paid or protected data.
Before making an expensive payment, warn the user clearly.
Never claim a payment succeeded unless the tool confirms it.
If payment is blocked by policy, explain the limit that blocked it.
Keep the final answer concise and operational.`;

export class X402Agent {
  constructor(
    private readonly model: LanguageModel,
    private readonly premiumClient: PremiumHttpClient,
    private readonly store: TransactionStore,
    private readonly controls: SpendingControls,
  ) {}

  async run(task: string): Promise<AgentRunResult> {
    const notifications: Notification[] = [];

    const result = await generateText({
      model: this.model,
      system: SYSTEM_PROMPT,
      prompt: task,
      stopWhen: stepCountIs(6),
      tools: {
        fetch_premium_resource: tool({
          description:
            "Fetch a premium or x402-protected HTTP resource and automatically handle x402 payments when allowed.",
          inputSchema: z.object({
            url: z.string().url(),
            method: z.enum(["GET", "POST"]).default("GET"),
            headers: z.record(z.string(), z.string()).optional(),
            body: z.string().optional(),
            purpose: z.string().min(3),
          }),
          execute: async (input) => {
            const outcome = await this.premiumClient.fetchPremiumResource(input, task);
            notifications.push(...outcome.notifications);
            return outcome;
          },
        }),
        get_spending_status: tool({
          description: "Read the current spending totals and remaining budget.",
          inputSchema: z.object({}),
          execute: async () => {
            const transactions = await this.store.list();
            return this.controls.getSnapshot(transactions);
          },
        }),
        get_transaction_history: tool({
          description: "List prior premium-resource payments and their verification state.",
          inputSchema: z.object({
            limit: z.number().int().positive().max(20).default(10),
          }),
          execute: async ({ limit }) => {
            const transactions = await this.store.list();
            return transactions.slice(-limit).reverse();
          },
        }),
      },
    });

    const transactions = await this.store.list();

    return {
      task,
      text: result.text,
      notifications,
      transactions,
    };
  }
}
