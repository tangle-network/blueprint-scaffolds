import type { PaymentPayload } from "./types.js";
import { parse402Response, buildPaymentHeader } from "./x402-client.js";
import { WalletManager } from "./wallet.js";
import { SpendingGuard } from "./spending-guard.js";
import { TransactionLogger } from "./logger.js";

export interface X402FetchOptions extends RequestInit {
  maxRetries?: number;
  requireConfirmation?: boolean;
}

export class X402FetchClient {
  private wallet: WalletManager;
  private guard: SpendingGuard;
  private logger: TransactionLogger;

  constructor(wallet: WalletManager, guard: SpendingGuard, logger: TransactionLogger) {
    this.wallet = wallet;
    this.guard = guard;
    this.logger = logger;
  }

  async paidFetch(url: string, options: X402FetchOptions = {}): Promise<Response> {
    const { maxRetries = 1, requireConfirmation = false, ...fetchOpts } = options;

    let response = await fetch(url, {
      ...fetchOpts,
      headers: {
        ...fetchOpts.headers,
        "X-Payment-Protocol": "x402",
      },
    });

    if (response.status !== 402) {
      return response;
    }

    const parsed = parse402Response(response);
    if (!parsed) {
      throw new Error(
        `Received 402 but could not parse payment requirements from ${url}`
      );
    }

    const { paymentRequirements } = parsed;
    this.guard.recordAttempt(paymentRequirements.recipient);

    const validation = this.guard.validate(paymentRequirements);
    if (!validation.allowed) {
      throw new Error(`Payment blocked: ${validation.reason}`);
    }

    if (requireConfirmation) {
      const amountUsd = Number(paymentRequirements.amount) / 1e6;
      console.log(
        `[x402] Confirm payment: $${amountUsd.toFixed(2)} USDC to ${paymentRequirements.recipient} for ${paymentRequirements.resource || url}`
      );
    }

    const record = this.logger.add({
      recipient: paymentRequirements.recipient,
      amount: paymentRequirements.amount,
      token: paymentRequirements.token,
      tokenName: paymentRequirements.tokenName,
      resource: paymentRequirements.resource || url,
      status: "pending",
    });

    try {
      const paymentPayload: PaymentPayload = await this.wallet.signPayment(
        paymentRequirements
      );

      const paymentHeader = buildPaymentHeader(paymentPayload);

      for (let attempt = 0; attempt <= maxRetries; attempt++) {
        const retryResponse = await fetch(url, {
          ...fetchOpts,
          headers: {
            ...fetchOpts.headers,
            "X-Payment": paymentHeader,
            "X-Payment-Protocol": "x402",
            Authorization: paymentPayload.authorization,
          },
        });

        if (retryResponse.status !== 402) {
          this.logger.updateStatus(record.id, "confirmed");
          return retryResponse;
        }

        if (attempt === maxRetries) {
          this.logger.updateStatus(record.id, "failed", "Server still returning 402 after payment");
          throw new Error("Payment was submitted but server still requires payment");
        }
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      this.logger.updateStatus(record.id, "failed", message);
      throw err;
    }

    throw new Error("Unexpected state in payment flow");
  }
}
