import { SpendingConfig, PaymentRequirements } from "./types.js";
import { TransactionStore } from "./store.js";

export class SpendingLimits {
  private config: SpendingConfig;
  private store: TransactionStore;

  constructor(config: SpendingConfig, store: TransactionStore) {
    this.config = config;
    this.store = store;
  }

  checkPerRequest(amount: string): { allowed: boolean; reason?: string } {
    const amountNum = parseFloat(amount);
    if (isNaN(amountNum)) {
      return { allowed: false, reason: "Invalid payment amount" };
    }
    if (amountNum > this.config.maxPerRequest) {
      return {
        allowed: false,
        reason: `Amount $${amountNum} exceeds per-request limit of $${this.config.maxPerRequest}`,
      };
    }
    return { allowed: true };
  }

  checkDailyLimit(): { allowed: boolean; spent: number; remaining: number } {
    const spent = this.store.getDailyTotal();
    const remaining = Math.max(0, this.config.dailyLimit - spent);
    return {
      allowed: spent < this.config.dailyLimit,
      spent,
      remaining,
    };
  }

  checkWeeklyLimit(): { allowed: boolean; spent: number; remaining: number } {
    const spent = this.store.getWeeklyTotal();
    const remaining = Math.max(0, this.config.weeklyLimit - spent);
    return {
      allowed: spent < this.config.weeklyLimit,
      spent,
      remaining,
    };
  }

  checkRecipient(recipient: `0x${string}`): { allowed: boolean; reason?: string } {
    if (this.config.allowedRecipients.length === 0) {
      return { allowed: true };
    }
    const normalized = recipient.toLowerCase();
    const found = this.config.allowedRecipients.some(
      (addr) => addr.toLowerCase() === normalized,
    );
    if (!found) {
      return {
        allowed: false,
        reason: `Recipient ${recipient} is not in the allowed recipients whitelist`,
      };
    }
    return { allowed: true };
  }

  checkAll(requirements: PaymentRequirements): { allowed: boolean; reasons: string[] } {
    const reasons: string[] = [];

    const perReq = this.checkPerRequest(requirements.amount);
    if (!perReq.allowed && perReq.reason) reasons.push(perReq.reason);

    const recipient = this.checkRecipient(requirements.recipient);
    if (!recipient.allowed && recipient.reason) reasons.push(recipient.reason);

    const daily = this.checkDailyLimit();
    if (!daily.allowed) {
      reasons.push(
        `Daily spending limit reached ($${daily.spent.toFixed(2)} / $${this.config.dailyLimit.toFixed(2)})`,
      );
    }

    const weekly = this.checkWeeklyLimit();
    if (!weekly.allowed) {
      reasons.push(
        `Weekly spending limit reached ($${weekly.spent.toFixed(2)} / $${this.config.weeklyLimit.toFixed(2)})`,
      );
    }

    return {
      allowed: reasons.length === 0,
      reasons,
    };
  }

  getConfig(): SpendingConfig {
    return { ...this.config };
  }
}
