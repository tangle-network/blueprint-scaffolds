# AGENTS.md

## Goal

Create an AI agent that can autonomously pay for premium HTTP services using the x402 payment protocol.

## Stack

- Family: `x402-service`
- Layers: `database:sqlite`, `sdk:none`, `auth:none`, `payments:none`, `queue:none`

## Entry Points

- `server.mjs`
- `x402.config.json`

## Commands

- `node server.mjs`

## Rules

- Build on top of the prepared scaffold. Do not replace the architecture.
- Use the entry points and validated commands before exploring broadly.
- Extend owned files. Check file ownership in `.starter-foundry/compose-report.json`.
- Run the dev server to verify changes hot-reload correctly.
