# x402 Autonomous Agent

Node.js and TypeScript service that runs an AI agent with tool calling, fetches x402-protected HTTP resources, pays for them on Base mainnet using USDC, and records every settlement for audit.

## Features

- Vercel AI SDK agent with tool calling
- Automatic x402 payment retry for HTTP 402 responses
- Wallet signing through `viem`
- Per-request, daily, weekly, whitelist, and rate-limit controls
- On-chain verification of recorded transaction hashes on Base
- Notification path for expensive operations before payment

## Endpoints

- `GET /health`
- `GET /transactions`
- `POST /agent/run`

### Example request

```bash
curl -X POST http://localhost:3000/agent/run \
  -H 'content-type: application/json' \
  -d '{
    "task": "Fetch https://example.com/premium and summarize the premium data."
  }'
```

## Environment

Copy `.env.example` to `.env` and set:

- `WALLET_PRIVATE_KEY`
- `OPENAI_API_KEY` or `ANTHROPIC_API_KEY`
- `PAYEE_WHITELIST` if you want to restrict recipients

When `AUTO_APPROVE_EXPENSIVE=false`, payments above `EXPENSIVE_OPERATION_USD` are blocked and returned as approval-required notifications.
